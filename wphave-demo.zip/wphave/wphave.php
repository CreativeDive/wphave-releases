<?php

/**
 * Plugin Name: WPHAVE
 * Description: A unified system for building and managing WordPress websites with consistent design, workflows, performance, and control.
 * Version: 1.0.112
 * Requires at least: 7.1
 * Requires PHP: 8.3
 * Author: Martin Jost
 * Author URI: https://wphave.com
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wphave
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) {
	exit(); // Exit if accessed directly
}

if (!class_exists('WPHAVE_Plugin')):
	/**
	 * Bootstrap the WPHAVE plugin runtime.
	 *
	 * Runtime modules are grouped by request scope so normal frontend requests
	 * do not load management-only services.
	 */

	class WPHAVE_Plugin {
		/** @var WPHAVE_Feature_Loader|null */

		private $feature_loader = null;

		/**
		 * Minimum supported MySQL version.
		 *
		 * WordPress does not provide plugin header fields for database runtime
		 * requirements, so MySQL and MariaDB remain explicit plugin metadata.
		 *
		 * @var string
		 */

		var $mysql_version = '8.0';

		/**
		 * Minimum supported MariaDB version.
		 *
		 * @var string
		 */

		var $mariadb_version = '10.11';

		/**
		 * Plugin slug.
		 *
		 * @var string
		 */

		var $plugin = 'wphave';

		/**
		 * Plugin namespace.
		 *
		 * @var string
		 */

		var $namespace = 'wphave';

		/**
		 * Plugin author name.
		 *
		 * @var string
		 */

		var $author = 'Martin Jost';

		/**
		 * Plugin author URL.
		 *
		 * @var string
		 */

		var $author_url = 'https://wphave.com';

		/**
		 * Create the plugin container without loading runtime modules.
		 *
		 * Initialization remains explicit so wphave() can enforce one shared
		 * instance before loading hooks and services.
		 *
		 * @return void
		 */

		function __construct() {
			/* Do nothing here */
		}

		/**
		 * Define plugin constants and load the request-specific runtime.
		 *
		 * @return void
		 */

		function initialize() {
			// Resolve plugin metadata before defining the shared runtime constants.

			// Since WordPress 5.8, Core reads the minimum WordPress and PHP
			// requirements from the main plugin file. Keep these values exclusively
			// in the official headers above so runtime and update metadata cannot drift.
			// @https://developer.wordpress.org/plugins/plugin-basics/header-requirements/
			$headers = get_file_data(__FILE__, [
				// Current wphave version
				'Version' => 'Version',
				// Minimal required WordPress version
				'RequiresWP' => 'Requires at least',
				// Minimal required PHP version
				'RequiresPHP' => 'Requires PHP',
			]);

			$wordpress_version = $headers['RequiresWP'];
			$php_version = $headers['RequiresPHP'];
			$mysql_version = $this->mysql_version;
			$mariadb_version = $this->mariadb_version;
			$namespace = $this->namespace;
			$author = $this->author;
			$author_url = $this->author_url;
			$plugin = $this->plugin;
			$basename = plugin_basename(__FILE__);

			// Constants form the shared contract for all subsequently loaded modules.

			if (!defined('WPHAVE_VERSION')) {
				$version = $headers['Version'];

				define('WPHAVE_VERSION', $version ?: '0.0.0');
			}

			define('WPHAVE_WP_VERSION', $wordpress_version);
			define('WPHAVE_PHP_VERSION', $php_version);
			define('WPHAVE_MYSQL_VERSION', $mysql_version);
			define('WPHAVE_MARIADB_VERSION', $mariadb_version);
			define('WPHAVE_NAMESPACE', $namespace);
			define('WPHAVE_AUTHOR_URL', $author_url);
			define('WPHAVE_AUTHOR_NAME', $author);
			define('WPHAVE_PLUGIN_NAME', $plugin);
			define('WPHAVE_BASENAME', $basename);
			// PLUGIN IDENTITY INVARIANT: The loaded main file is authoritative.
			// Reconstructing it from the installation directory breaks renamed,
			// staged and WordPress-generated release directories.
			define('WPHAVE_FILE_PATH', __FILE__);

			define('WPHAVE_DEFAULT_THEME_SLUG', 'wphave');
			define('WPHAVE_DEFAULT_CHILD_THEME_SLUG', 'wphave-child');
			define('WPHAVE_ADMIN_PAGE_SLUG', 'workspace');

			define('WPHAVE_REQUEST_MEMOIZATION', true);
			define('WPHAVE_EVENTS_TRACK', false);
			define('WPHAVE_EVENTS_TRACK_FLAG', 'ALL'); // <-- ALL, GET, UPDATE, CACHE, INCLUDE, CHECK, ASSETS, RESTORE

			define('WPHAVE_MAIN_COLOR', '#222222');
			define('WPHAVE_MAIN_COLOR_SECOND', '#2C2C2C');
			define('WPHAVE_MAIN_COLOR_TERTIARY', '#272727');
			define('WPHAVE_MAIN_COLOR_ACCENT', '#A29581');
			define('WPHAVE_DEFAULT_WIDTH', 1170);
			define('WPHAVE_BREAKPOINT_MOBILE', 768);
			define('WPHAVE_BREAKPOINT_TABLET', 992);
			// Bootstrap fallbacks must match the locally bundled default font assets.
			define('WPHAVE_FONT_TITLE', 'Inter');
			define('WPHAVE_FONT_TEXT', 'Poppins');

			$this->load_core_runtime();
			if (self::request_needs_frontend_runtime(wp_doing_cron())) {
				$this->load_frontend_runtime();
			}

			if ($this->is_management_request()) {
				$this->load_management_runtime();
			}

			if ($this->is_worker_request()) {
				$this->load_worker_runtime();
			}

			add_action('init', [$this, 'wphave_init'], 5);
		}

		/**
		 * Detect REST requests during early plugin bootstrap.
		 *
		 * REST_REQUEST is not guaranteed to be defined while plugins are loaded,
		 * so URL checks keep REST-only modules available for route registration.
		 *
		 * @return bool Whether the current request targets the REST API.
		 */

		function is_rest_request() {
			if (defined('REST_REQUEST') && REST_REQUEST) {
				return true;
			}

			if (isset($_GET['rest_route'])) {
				$rest_route = $_GET['rest_route'];

				/*
				 * SECURITY/PERFORMANCE INVARIANT: A query key alone is not a REST
				 * signal. WordPress non-pretty REST routes are scalar absolute paths;
				 * malformed input must stay on the frontend runtime boundary.
				 */
				if (is_string($rest_route) && str_starts_with($rest_route, '/')) {
					return true;
				}
			}

			$request_uri = isset($_SERVER['REQUEST_URI']) ? (string) $_SERVER['REQUEST_URI'] : '';
			$request_path = wp_parse_url($request_uri, PHP_URL_PATH);
			if (!is_string($request_path) || '' === $request_path) {
				return false;
			}

			$rest_prefix = function_exists('rest_get_url_prefix')
				? rest_get_url_prefix()
				: 'wp-json';
			$home_path = wp_parse_url(home_url('/'), PHP_URL_PATH);
			$home_path = is_string($home_path) ? trim($home_path, '/') : '';
			$rest_path =
				'/' . ('' !== $home_path ? $home_path . '/' : '') . trim($rest_prefix, '/');

			/*
			 * PERFORMANCE INVARIANT: Only the canonical REST root may load the
			 * management runtime. A frontend slug that merely contains the REST
			 * prefix must remain on the public hot path.
			 */
			return $request_path === $rest_path || str_starts_with($request_path, $rest_path . '/');
		}

		/**
		 * Determine whether management-only modules are required.
		 *
		 * @return bool Whether the request needs admin, REST, AJAX or CLI services.
		 */

		function is_management_request() {
			return self::request_needs_management_runtime(
				is_admin(),
				wp_doing_ajax(),
				wp_doing_cron(),
				defined('WP_CLI') && WP_CLI,
				$this->is_rest_request(),
			);
		}

		/**
		 * Resolve the management runtime from explicit request signals.
		 *
		 * PERFORMANCE INVARIANT: Cron owns the worker composition only. It must
		 * not load REST controllers, admin screens or editor management modules.
		 * CLI remains a management context because supported commands inspect the
		 * same services that back the Workspace.
		 *
		 * @param bool $is_admin WordPress admin request signal.
		 * @param bool $is_ajax WordPress AJAX request signal.
		 * @param bool $is_cron WordPress Cron request signal.
		 * @param bool $is_cli WordPress CLI request signal.
		 * @param bool $is_rest WordPress REST request signal.
		 * @return bool Whether management modules are required.
		 */

		public static function request_needs_management_runtime(
			bool $is_admin,
			bool $is_ajax,
			bool $is_cron,
			bool $is_cli,
			bool $is_rest,
		): bool {
			if ($is_cron) {
				return false;
			}

			return $is_admin || $is_ajax || $is_cli || $is_rest;
		}

		/**
		 * Determine whether public rendering modules belong to this request.
		 *
		 * PERFORMANCE INVARIANT: WP-Cron executes persisted worker callbacks and
		 * must not initialize blocks, navigation, public tracking or presentation
		 * features. Every WPHAVE-owned callback composes its dependencies through
		 * the worker registry instead.
		 *
		 * @param bool $is_cron WordPress Cron request signal.
		 * @return bool Whether public rendering modules are required.
		 */

		public static function request_needs_frontend_runtime(bool $is_cron): bool {
			return !$is_cron;
		}

		function is_worker_request() {
			return wp_doing_cron() || (defined('WP_CLI') && WP_CLI);
		}

		/**
		 * Load the minimal runtime shared by every request type.
		 *
		 * Keep this group small because it is always part of the frontend hot path.
		 *
		 * @return void
		 */

		function load_core_runtime() {
			// BOOTSTRAP INVARIANT: The path helpers are defined by this include, so the
			// first core include must be anchored to the plugin file itself.
			include_once __DIR__ . '/inc/helpers/init.php';
			require_once __DIR__ . '/inc/features/loader.php';

			$feature_registry = require __DIR__ . '/inc/features/registry.php';
			$this->feature_loader = new WPHAVE_Feature_Loader($feature_registry);
			$this->feature_loader->load('core');

			include_once __DIR__ . '/inc/background-jobs/functions.php';
			include_once __DIR__ . '/inc/user/avatar-resolver.php';
			include_once __DIR__ . '/inc/lifecycle.php';

			// PHP-only Pro gates run on public requests as well. Load the compact
			// verifier here so outage continuity still requires genuine broker-
			// signed proof instead of trusting editable WordPress option flags.
			include_once __DIR__ . '/inc/data/options/mutations.php';

			// Feature gates read workspace settings through the canonical data API.
			// Load it before any optional runtime is selected so frontend and app
			// requests resolve the same persisted state.
			include_once __DIR__ . '/inc/data/data.php';

			// TEMPORARY PRERELEASE CUTOVER: remove this include together with
			if (wphave_request_inspector_feature_enabled()) {
				include_once __DIR__ . '/inc/optimize/monitoring/request-inspector/bootstrap.php';
			}

			if (
				isset($_SERVER['HTTP_X_WPHAVE_PROFILE']) &&
				(wphave_request_profiler_feature_enabled() ||
					wphave_request_inspector_feature_enabled())
			) {
				include_once __DIR__ .
					'/inc/optimize/monitoring/request-profiler/request-profiler.php';
			}

			include_once __DIR__ . '/inc/data/database-metadata.php';
			include_once __DIR__ . '/inc/data/database-schema-manager.php';
			include_once __DIR__ . '/inc/site/init.php';
			include_once __DIR__ . '/inc/theme/functions.php';

			include_once __DIR__ . '/inc/site/styles/init.php';
			include_once __DIR__ . '/inc/ui/icons.php';
			// Shared feature capabilities must also resolve for frontend navigation.
			include_once __DIR__ . '/inc/admin/user/access/manager.php';
			include_once __DIR__ . '/inc/admin/user/access/role-labels.php';
			include_once __DIR__ . '/inc/admin/user/preferences-manager.php';
			include_once __DIR__ . '/inc/admin/frontend-editor-routing.php';
			include_once __DIR__ . '/inc/admin/frontend-admin-bar.php';

			include_once __DIR__ . '/inc/assets/register.php';
			include_once __DIR__ . '/inc/assets/enqueue.php';
		}

		/**
		 * Load modules that can affect public requests and rendering.
		 *
		 * @return void
		 */

		function load_frontend_runtime() {
			include_once __DIR__ . '/inc/blocks/styles/manager.php';
			include_once __DIR__ . '/inc/blocks/css-classes/manager.php';
			include_once __DIR__ . '/inc/blocks/init.php';
			include_once __DIR__ . '/inc/optimize/functions.php';

			include_once __DIR__ . '/inc/site/functions.php';
			include_once __DIR__ . '/inc/site/templates/functions.php';
			include_once __DIR__ . '/inc/site/navigations/manager.php';
			include_once __DIR__ . '/inc/site/template-parts/functions.php';
			$this->feature_loader->load('frontend');
		}

		/**
		 * Load modules required by management request contexts.
		 *
		 * These services are excluded from plain frontend requests to keep the
		 * public hot path smaller.
		 *
		 * @return void
		 */

		function load_management_runtime() {
			if (
				wphave_request_profiler_feature_enabled() ||
				wphave_request_inspector_feature_enabled()
			) {
				include_once __DIR__ .
					'/inc/optimize/monitoring/request-profiler/request-profiler.php';
			}

			include_once __DIR__ . '/inc/update/functions.php';
			include_once __DIR__ . '/inc/data/options/wp-options.php';
			include_once __DIR__ . '/inc/data/options/app-notice-status.php';
			include_once __DIR__ . '/inc/optimize/htaccess-manager.php';
			include_once __DIR__ . '/inc/optimize/transients/manager.php';

			include_once __DIR__ . '/inc/editor/functions.php';

			include_once __DIR__ . '/inc/admin/functions.php';
			include_once __DIR__ . '/inc/admin/command-search.php';
			include_once __DIR__ . '/inc/admin/pages/interface.php';
			include_once __DIR__ . '/inc/admin/pages/editor-autosaves.php';
			include_once __DIR__ . '/inc/admin/pages/editor-auto-drafts.php';
			include_once __DIR__ . '/inc/site/templates/admin/admin.php';
			include_once __DIR__ . '/inc/site/template-parts/admin/admin.php';
			include_once __DIR__ . '/inc/site/navigations/admin/admin.php';
			$this->feature_loader->load('management');
		}

		/**
		 * Load scheduled and command-line worker services.
		 *
		 * The updater participates in Core's scheduled update checks but is not a
		 * product feature worker, so it remains the one explicit shared dependency.
		 *
		 * @return void
		 */

		function load_worker_runtime() {
			include_once __DIR__ . '/inc/update/functions.php';
			$this->feature_loader->load('worker');
		}

		/**
		 * Initialize services that require WordPress plugins and themes to be loaded.
		 *
		 * @return void
		 */

		function wphave_init() {
			$basename = plugin_basename(__FILE__);
			$slug = dirname($basename);

			load_plugin_textdomain('wphave', null, $slug . '/languages');

			/*
			 * The WPHAVE plugin and theme intentionally share one product-facing
			 * text domain. WordPress' just-in-time textdomain registry can therefore
			 * resolve the domain to the active theme directory during REST requests.
			 * Load the plugin catalog explicitly so PHP-generated API payloads use
			 * the same locale as the WPHAVE interface.
			 */
			$locale = determine_locale();
			$catalogs = [
				WP_LANG_DIR . '/plugins/wphave-' . $locale . '.mo',
				wphave_dir() . 'languages/wphave-' . $locale . '.mo',
			];

			foreach ($catalogs as $catalog) {
				if (is_readable($catalog)) {
					load_textdomain('wphave', $catalog, $locale);
					break;
				}
			}
		}
	} // end class

	/**
	 * Return the shared WPHAVE plugin instance.
	 *
	 * @return WPHAVE_Plugin Initialized plugin instance.
	 */

	if (!function_exists('wphave')):
		function wphave() {
			// Globals
			global $wphave;

			// Initialize
			if (!isset($wphave)) {
				$wphave = new WPHAVE_Plugin();
				$wphave->initialize();
			}

			// Return
			return $wphave;
		}
	endif;

	register_activation_hook(__FILE__, ['WPHAVE_Lifecycle', 'activate']);
	register_deactivation_hook(__FILE__, ['WPHAVE_Lifecycle', 'deactivate']);

	// Initialize
	wphave();
endif;
