<?php

/** Local, source-backed maintenance evidence; never substitutes for compatibility. */
if (!defined('ABSPATH')) {
	exit();
}

final class WPHAVE_Runtime_Support {
	public static function catalog(): array {
		static $catalog = null;
		if ($catalog === null) {
			$path = __DIR__ . '/support-catalog.json';
			$decoded = is_readable($path)
				? json_decode((string) file_get_contents($path), true)
				: null;
			$catalog = is_array($decoded) && !self::validate($decoded) ? $decoded : [];
		}
		return $catalog;
	}

	private static function date($value): ?int {
		if (!is_string($value)) {
			return null;
		}
		$date = DateTimeImmutable::createFromFormat('!Y-m-d', $value, new DateTimeZone('UTC'));
		return $date && $date->format('Y-m-d') === $value ? $date->getTimestamp() : null;
	}

	/** Pass a clock for release audits; runtime validation does not reject stale evidence. */
	public static function validate(array $catalog, ?int $now = null): array {
		$errors = [];
		if (($catalog['schemaVersion'] ?? null) !== 1 || !is_array($catalog['products'] ?? null)) {
			return ['Unsupported or missing runtime catalog schema.'];
		}
		$products = [];
		foreach ($catalog['products'] as $product) {
			if (!is_array($product) || !is_string($product['id'] ?? null)) {
				$errors[] = 'Invalid product record.';
				continue;
			}
			$id = $product['id'];
			if (!in_array($id, ['php', 'mysql', 'mariadb'], true) || isset($products[$id])) {
				$errors[] = 'Unknown or duplicate runtime product: ' . $id;
			}
			$products[$id] = true;
			if (
				!is_string($product['label'] ?? null) ||
				empty($product['label']) ||
				!is_array($product['branches'] ?? null)
			) {
				$errors[] = 'Missing product label or branches: ' . $id;
				continue;
			}
			$branches = [];
			foreach ($product['branches'] as $entry) {
				if (
					!is_array($entry) ||
					!is_string($entry['branch'] ?? null) ||
					!is_string($entry['sourceUrl'] ?? null)
				) {
					$errors[] = 'Invalid branch record: ' . $id;
					continue;
				}
				$branch = $entry['branch'];
				$key = $id . ' ' . $branch;
				if (
					!is_string($branch) ||
					!preg_match('/^\d+\.\d+$/D', $branch) ||
					isset($branches[$branch])
				) {
					$errors[] = 'Invalid or duplicate branch: ' . $key;
				}
				$branches[$branch] = true;
				$url = parse_url($entry['sourceUrl'] ?? '');
				$hosts = [
					'php' => ['www.php.net'],
					'mysql' => ['www.mysql.com', 'dev.mysql.com', 'www.oracle.com'],
					'mariadb' => ['mariadb.org', 'mariadb.com'],
				];
				if (
					($url['scheme'] ?? '') !== 'https' ||
					!in_array($url['host'] ?? '', $hosts[$id] ?? [], true) ||
					isset($url['user']) ||
					isset($url['pass'])
				) {
					$errors[] = 'Missing official HTTPS source: ' . $key;
				}
				$verified = self::date($entry['lastVerified'] ?? null);
				$review = self::date($entry['reviewOn'] ?? null);
				if (
					$verified === null ||
					$review === null ||
					$review <= $verified ||
					$review - $verified > 90 * 86400
				) {
					$errors[] = 'Invalid review interval (maximum 90 days): ' . $key;
				}
				$end = $entry['securityUntil'] ?? null;
				$through = $entry['maintainedThrough'] ?? null;
				if (
					($end === null) === ($through === null) ||
					self::date($end ?? $through) === null
				) {
					$errors[] =
						'Specify exactly one confirmed support end or maintenance window: ' . $key;
				}
				if (
					$through !== null &&
					$verified !== null &&
					self::date($through) !== null &&
					self::date($through) < $verified
				) {
					$errors[] = 'Maintenance window predates verification: ' . $key;
				}
				if ($now !== null && ($verified > $now || $review <= $now)) {
					$errors[] =
						'Review official source and update evidence: ' .
						$key .
						' (due ' .
						($entry['reviewOn'] ?? '?') .
						'): ' .
						$entry['sourceUrl'];
				}
			}
			if (
				!is_string($product['recommendedBranch'] ?? null) ||
				!isset($branches[$product['recommendedBranch']])
			) {
				$errors[] = 'Recommendation references a missing branch: ' . $id;
			} elseif (
				$now !== null &&
				self::evaluate($id, $product['recommendedBranch'], $now, $catalog)[
					'securityStatus'
				] !== 'supported'
			) {
				$errors[] = 'Recommendation is not backed by current maintenance evidence: ' . $id;
			}
		}
		if (count($products) !== 3) {
			$errors[] = 'PHP, MySQL and MariaDB must all be covered.';
		}
		return $errors;
	}

	public static function product(string $id, ?array $catalog = null): array {
		foreach (($catalog ?? self::catalog())['products'] ?? [] as $product) {
			if (($product['id'] ?? null) === $id) {
				return $product;
			}
		}
		return [];
	}

	public static function evaluate(
		string $product,
		string $branch,
		?int $now = null,
		?array $catalog = null,
	): array {
		$now ??= time();
		$result = [
			'securityStatus' => 'unknown',
			'securityUntil' => null,
			'supportEvidence' => null,
		];
		foreach (self::product($product, $catalog)['branches'] ?? [] as $entry) {
			if ($entry['branch'] !== $branch) {
				continue;
			}
			$end = self::date($entry['securityUntil'] ?? null);
			$through = self::date($entry['maintainedThrough'] ?? null);
			$verified = self::date($entry['lastVerified'] ?? null);
			$review = self::date($entry['reviewOn'] ?? null);
			$stale = $review === null || $now >= $review;
			$known = $verified !== null && $verified <= $now;
			// Confirmed historical EOL survives an overdue review. Overdue review alone never means EOL.
			$status =
				$known && $end !== null && $now >= $end + 86400
					? 'ended'
					: ($known && !$stale && ($end ?? ($through ?? 0)) + 86400 > $now
						? 'supported'
						: 'unknown');
			return [
				'securityStatus' => $status,
				'securityUntil' => $entry['securityUntil'] ?? null,
				'supportEvidence' => [
					'product' => self::product($product, $catalog)['label'],
					'branch' => $branch,
					'sourceUrl' => $entry['sourceUrl'],
					'lastVerified' => $entry['lastVerified'],
					'reviewOn' => $entry['reviewOn'],
					'reviewOverdue' => $stale,
					'securityUntil' => $entry['securityUntil'] ?? null,
				],
			];
		}
		return $result;
	}

	public static function recommended(string $product, ?int $now = null): ?string {
		$branch = self::product($product)['recommendedBranch'] ?? null;
		return $branch && self::evaluate($product, $branch, $now)['securityStatus'] === 'supported'
			? $branch
			: null;
	}
}
