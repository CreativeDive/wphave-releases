<?php

/**
 * Central vocabulary for AI pattern metadata, prompts, validation, and matching.
 */

if ( ! function_exists( 'wphave_ai_pattern_taxonomy' ) ) :

	function wphave_ai_pattern_taxonomy(): array {
		return array(
			'roles' => array(
				'hero',
				'section',
				'content',
				'cta',
				'card',
				'wide-card',
				'feature-grid',
				'stats',
				'proof',
				'steps',
				'process',
				'testimonial',
				'faq',
				'pricing',
				'form',
				'navigation',
				'header',
				'footer',
				'chip',
				'badge',
				'table',
			),
			'layout' => array(
				'centered',
				'asymmetric',
				'split',
				'stacked',
				'grid',
				'bento',
				'swiper',
				'masonry',
				'overlay',
				'visual-grid',
				'media-overlay',
				'text-media',
				'wide-card',
				'compact-card',
				'panel',
				'contrast-panel',
				'list',
				'table',
				'columns',
				'featured',
			),
			'width' => array(
				'narrow',
				'content-width',
				'wide',
				'full-width',
			),
			'visual' => array(
				'none',
				'image',
				'image-grid',
				'gallery',
				'product-preview',
				'device-preview',
				'abstract-panel',
				'background-media',
				'overlay',
				'icon',
				'badge',
				'stat-card',
				'numbers',
				'cards',
				'quote',
				'list',
				'color-background',
				'pattern-background',
			),
			'content' => array(
				'heading',
				'body',
				'actions',
				'items',
				'badges',
				'media',
				'icons',
				'stats',
				'steps',
				'quote',
				'cite',
				'questions',
				'pricing',
				'form-fields',
			),
			'intent' => array(
				'first-viewport',
				'conversion',
				'explanation',
				'comparison',
				'trust-building',
				'trust',
				'proof',
				'credibility',
				'feature-summary',
				'process',
				'explain-process',
				'conversion-support',
				'lead-capture',
				'navigation',
				'announcement',
				'brand-story',
				'campaign',
				'product-showcase',
				'social-proof',
				'reusable-snippet',
			),
			'treatment' => array(
				'framed',
				'unframed',
				'soft-surface',
				'strong-contrast',
				'cinematic',
				'overlay',
				'background-media',
				'pattern-background',
				'angled-composition',
				'floating-elements',
				'layered',
				'bordered',
				'shadowed',
				'minimal',
				'structured',
				'editorial',
				'compact',
				'dense',
				'spacious',
				'visual-impact',
			),
			'contentFit' => array(
				'visuals' => array('none', 'single', 'multiple', 'background', 'icon'),
			),
			'layoutFit' => array(
				'width' => array('narrow', 'content-width', 'wide', 'full-width'),
				'density' => array('compact', 'balanced', 'spacious'),
				'contrast' => array('soft', 'balanced', 'high'),
			),
		);
	}

endif;

if ( ! function_exists( 'wphave_ai_pattern_taxonomy_values' ) ) :

	/**
	 * Ai pattern taxonomy values.
	 *
	 * @param string $key Key.
	 * @return array Ai pattern taxonomy values.
	 */

	function wphave_ai_pattern_taxonomy_values( string $key ): array {
		$taxonomy = wphave_ai_pattern_taxonomy();

		return $taxonomy[$key] ?? array();
	}

endif;

if ( ! function_exists( 'wphave_ai_pattern_normalize_terms' ) ) :

	/**
	 * Ai pattern normalize terms.
	 *
	 * @param mixed $terms Terms.
	 * @param string $taxonomy_key Taxonomy key.
	 * @return array Ai pattern normalize terms.
	 */

	function wphave_ai_pattern_normalize_terms( $terms, string $taxonomy_key ): array {
		$allowed = wphave_ai_pattern_taxonomy_values( $taxonomy_key );

		if( ! is_array( $allowed ) ) {
			return array();
		}

		return array_values( array_unique( array_filter( array_map( function( $term ) use ( $allowed ) {
			$term = sanitize_key( $term );

			return in_array( $term, $allowed, true ) ? $term : '';
		}, (array) $terms ) ) ) );
	}

endif;

if ( ! function_exists( 'wphave_ai_pattern_taxonomy_prompt' ) ) :

	/**
	 * Ai pattern taxonomy prompt.
	 *
	 * @return string Ai pattern taxonomy prompt.
	 */

	function wphave_ai_pattern_taxonomy_prompt(): string {
		$taxonomy = wphave_ai_pattern_taxonomy();
		$lines = array();

		foreach( array('roles', 'layout', 'width', 'visual', 'content', 'intent', 'treatment') as $key ) {
			$lines[] = $key . ': ' . implode( ', ', $taxonomy[$key] ?? array() );
		}

		return implode( "\n", $lines );
	}

endif;
