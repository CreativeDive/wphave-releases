<?php
/**
 * Terminology: WPHAVE Components are WordPress synced patterns; WPHAVE Patterns
 * are unsynced patterns. Components may expose explicitly enabled Pattern
 * Overrides for per-instance content. Overrides are optional, not a type filter.
 * See docs/pattern-handling-architecture.md for the shared terminology contract.
 *
 * Partition the native wp_block collection before pagination. No parameter means
 * the complete catalog, preserving Core and Inserter consumers. Permissions stay
 * with the native REST controller; arbitrary meta queries are never exposed.
 */
add_filter( 'rest_wp_block_collection_params', static function( $params ) {
	$params['wphave_pattern_type'] = array(
		'description' => 'Limit reusable blocks to components or independent patterns.',
		'type'        => 'string',
		'enum'        => array( 'components', 'patterns' ),
	);

	return $params;
} );

add_filter( 'rest_wp_block_query', static function( $args, $request ) {
	$type = $request->get_param( 'wphave_pattern_type' );

	if ( ! in_array( $type, array( 'components', 'patterns' ), true ) ) {
		return $args;
	}

	// Core treats every value other than "unsynced", including missing legacy
	// metadata, as synced. Keep the collection and editor classification aligned.
	$clause = array(
		'key'     => 'wp_pattern_sync_status',
		'value'   => 'unsynced',
		'compare' => $type === 'patterns' ? '=' : '!=',
	);
	$partition = $type === 'components'
		? array(
			'relation' => 'OR',
			$clause,
			array( 'key' => 'wp_pattern_sync_status', 'compare' => 'NOT EXISTS' ),
		)
		: array( $clause );

	$args['meta_query'] = empty( $args['meta_query'] )
		? $partition
		: array( 'relation' => 'AND', $args['meta_query'], $partition );

	return $args;
}, 10, 2 );
