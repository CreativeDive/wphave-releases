<?php

/**
 * Function to add categories for the WPHAVE block pattern.
 */

if (!function_exists('wphave_add_block_pattern_categories')):
	function wphave_add_block_pattern_categories() {
		if (!function_exists('register_block_pattern_category')) {
			return;
		}

		$categories = [
			'wphave-icon-cards' => [
				'tag' => 'icon-cards',
				'label' => __('Icon Cards', 'wphave'),
			],
			'wphave-content-cards' => [
				'tag' => 'content-cards',
				'release' => 'patternContentCards',
				'label' => __('Content Cards', 'wphave'),
			],
			'wphave-content-toggling' => [
				'tag' => 'content-toggling',
				'release' => 'patternContentToggling',
				'label' => __('Content Toggling', 'wphave'),
			],
			'wphave-pricing-cards' => [
				'tag' => 'pricing-cards',
				'label' => __('Pricing Cards', 'wphave'),
			],
			'wphave-content-sections' => [
				'tag' => 'content-sections',
				'release' => 'patternContentSections',
				'label' => __('Content Sections', 'wphave'),
			],
			'wphave-link-pages' => [
				'tag' => 'link-pages',
				'release' => 'patternLinkPages',
				'label' => __('Link Pages', 'wphave'),
			],
			'wphave-gallery' => [
				'tag' => 'galleries',
				'label' => __('Galleries', 'wphave'),
			],
			'wphave-cta' => [
				'tag' => 'cta',
				'release' => 'patternCallToActions',
				'label' => __('Call to Actions', 'wphave'),
			],
			/*'wphave-blog-posts' => array(
                'tag' => 'blog',
                'label' => __( 'Blog Posts', 'wphave' )
            ),*/

			/*'wphave-team' => array(
                'tag' => 'team',
                'label' => __( 'Team', 'wphave' )
            ),*/

			/*'wphave-testimonials' => array(
                'tag' => 'testimonials',
                'release' => 'patternTestimonials',
                'label' => __( 'Testimonials', 'wphave' )
            ),*/

			/*'wphave-coming-soon' => array(
                'tag' => 'coming-soon',
                'label' => __( 'Coming Soon', 'wphave' )
            ),*/

			/*'wphave-popups' => array(
                'tag' => 'popups',
                'label' => __( 'Popups', 'wphave' )
            ),*/

			'wphave-tables' => [
				'tag' => 'tables',
				'release' => 'patternTables',
				'label' => __('Tables', 'wphave'),
			],
			'wphave-footer' => [
				'tag' => 'footer',
				'label' => __('Footers', 'wphave'),
			],
			'wphave-header' => [
				'tag' => 'header',
				'label' => __('Headers', 'wphave'),
			],
			'wphave-navigation' => [
				'tag' => 'navigation',
				'label' => __('Navigations', 'wphave'),
			],
			'wphave-hero' => [
				'tag' => 'hero',
				'label' => __('Heros', 'wphave'),
			],
			'wphave-announcement-bar' => [
				'tag' => 'announcement-bar',
				'label' => __('Announcement Bar', 'wphave'),
			],
			'wphave-feature-list-section' => [
				'tag' => 'feature-list-section',
				'label' => __('Feature List Section', 'wphave'),
			],
			'wphave-gallery-sections' => [
				'tag' => 'gallery-sections',
				'label' => __('Gallery Sections', 'wphave'),
			],
			'wphave-mockup-sections' => [
				'tag' => 'mockup-sections',
				'label' => __('Mockup Sections', 'wphave'),
			],
			'wphave-stats' => [
				'tag' => 'stats',
				'label' => __('Stats / Proof Numbers', 'wphave'),
			],
			'wphave-process' => [
				'tag' => 'process',
				'label' => __('Process / Steps', 'wphave'),
			],
			'wphave-testimonials' => [
				'tag' => 'testimonials',
				'release' => 'patternTestimonials',
				'label' => __('Testimonials', 'wphave'),
			],
			'wphave-layout' => [
				'tag' => 'layouts',
				'label' => __('Layouts', 'wphave'),
			],
			'wphave-templates' => [
				'tag' => 'templates',
				'label' => __('Templates', 'wphave'),
			],
			'wphave-forms' => [
				'tag' => 'forms',
				'label' => __('Forms', 'wphave'),
			],
			'wphave-block-styles' => [
				'tag' => 'block-styles',
				'label' => __('Block Styles', 'wphave'),
			],
		];

		foreach ($categories as $slug => $data) {
			if (isset($data['release']) && !wphave_release_feature_ready($data['release'])) {
				continue;
			}
			$tag = $data['tag'] ?? 'untagged';
			$label = $data['label'] ?? 'n/a';

			// Register wp pattern category
			register_block_pattern_category($slug, ['label' => $label]);

			// Register wphave pattern groups
			wphave_register_pattern_group($tag, $slug, $slug);
		}
	}
endif;

/**
 * Collect block patterns for the AI layout workflow.
 *
 * @param array $args
 * @return array
 */

if (!function_exists('wphave_ai_block_pattern_collection')):
	function wphave_ai_block_pattern_collection($args = []) {
		$patterns = wphave_block_pattern_collection($args);
		$role = $args['role'] ?? '';
		$layout = $args['layout'] ?? '';
		$width = $args['width'] ?? '';
		$visual = $args['visual'] ?? '';
		$intent = $args['intent'] ?? '';
		$treatment = $args['treatment'] ?? '';
		$ai_patterns = [];

		foreach ($patterns as $pattern) {
			$ai = $pattern['ai'] ?? [];

			if (empty($ai['enabled'])) {
				continue;
			}

			if (
				$role &&
				(!is_array($ai['roles'] ?? null) || !in_array($role, $ai['roles'], true))
			) {
				continue;
			}

			if (
				$layout &&
				(!is_array($ai['layout'] ?? null) || !in_array($layout, $ai['layout'], true))
			) {
				continue;
			}

			if (
				$width &&
				(!is_array($ai['width'] ?? null) || !in_array($width, $ai['width'], true))
			) {
				continue;
			}

			if (
				$visual &&
				(!is_array($ai['visual'] ?? null) || !in_array($visual, $ai['visual'], true))
			) {
				continue;
			}

			if (
				$intent &&
				(!is_array($ai['intent'] ?? null) || !in_array($intent, $ai['intent'], true))
			) {
				continue;
			}

			if (
				$treatment &&
				(!is_array($ai['treatment'] ?? null) ||
					!in_array($treatment, $ai['treatment'], true))
			) {
				continue;
			}

			$normalized = wphave_normalize_ai_block_pattern($pattern, count($ai_patterns));

			if ($normalized) {
				$ai_patterns[] = $normalized;
			}
		}

		return $ai_patterns;
	}
endif;

if (!function_exists('wphave_normalize_ai_block_pattern')):
	/**
	 * Normalize ai block pattern.
	 *
	 * @param mixed $pattern Pattern.
	 * @param int $index Index.
	 */

	function wphave_normalize_ai_block_pattern($pattern, int $index = 0) {
		$ai = $pattern['ai'] ?? [];
		$key = sanitize_key($pattern['key'] ?? ($ai['key'] ?? ''));
		$roles = wphave_ai_pattern_normalize_terms($ai['roles'] ?? [], 'roles');
		$layout = wphave_ai_pattern_normalize_terms($ai['layout'] ?? [], 'layout');
		$width = wphave_ai_pattern_normalize_terms($ai['width'] ?? [], 'width');
		$visual = wphave_ai_pattern_normalize_terms($ai['visual'] ?? [], 'visual');
		$content = wphave_ai_pattern_normalize_terms($ai['content'] ?? [], 'content');
		$intent = wphave_ai_pattern_normalize_terms($ai['intent'] ?? [], 'intent');
		$treatment = wphave_ai_pattern_normalize_terms($ai['treatment'] ?? [], 'treatment');

		return [
			'key' =>
				$key ?:
				'pattern-' .
					($index + 1) .
					'-' .
					substr(md5((string) ($pattern['content'] ?? '')), 0, 8),
			'title' => $pattern['title'] ?? '',
			'tags' => $pattern['tags'] ?? [],
			'viewportWidth' => $pattern['viewportWidth'] ?? 1000,
			'content' => $pattern['content'] ?? '',
			'ai' => [
				'roles' => $roles,
				'layout' => $layout,
				'width' => $width,
				'visual' => $visual,
				'content' => $content,
				'intent' => $intent,
				'treatment' => $treatment,
				'description' => sanitize_text_field($ai['description'] ?? ''),
			],
		];
	}
endif;

add_action('init', 'wphave_add_block_pattern_categories');

/**
 * Remove editor-only pattern provenance from copied block markup.
 *
 * Registered pattern identity belongs to register_block_pattern(), not to the
 * attributes of blocks contained by that pattern. Other block metadata remains
 * untouched.
 *
 * @param string $content Serialized block content.
 * @return string
 */

if (!function_exists('wphave_normalize_registered_pattern_content')):
	function wphave_normalize_registered_pattern_content($content) {
		if (
			!is_string($content) ||
			'' === $content ||
			false === strpos($content, '"metadata"') ||
			(false === strpos($content, '"patternName"') &&
				false === strpos($content, '"categories"'))
		) {
			return $content;
		}

		$normalize_blocks = static function ($blocks) use (&$normalize_blocks) {
			foreach ($blocks as &$block) {
				$metadata = $block['attrs']['metadata'] ?? null;

				if (is_array($metadata)) {
					unset($metadata['patternName'], $metadata['categories']);

					if (isset($metadata['name']) && '' === trim((string) $metadata['name'])) {
						unset($metadata['name']);
					}

					if (empty($metadata)) {
						unset($block['attrs']['metadata']);
					} else {
						$block['attrs']['metadata'] = $metadata;
					}
				}

				if (!empty($block['innerBlocks'])) {
					$block['innerBlocks'] = $normalize_blocks($block['innerBlocks']);
				}
			}
			unset($block);

			return $blocks;
		};

		$blocks = parse_blocks($content);

		if (empty($blocks)) {
			return $content;
		}

		return serialize_blocks($normalize_blocks($blocks));
	}
endif;

/**
 * Functions to register a wphave block pattern group.
 */

if (!function_exists('wphave_register_pattern_group')):
	function wphave_register_pattern_group($tag, $category, $prefix) {
		$patterns = wphave_block_pattern_collection(['tags' => [$tag]]);
		$category_data = WP_Block_Pattern_Categories_Registry::get_instance()->get_registered(
			$category,
		);
		$category_label = $category_data['label'] ?? __('Pattern', 'wphave');

		$i = 1;
		foreach ($patterns as $data) {
			$title = trim((string) ($data['title'] ?? ''));
			if ($title === '') {
				// Preserve authored titles; name otherwise anonymous catalog variants.
				$title = sprintf(
					/* translators: 1: Pattern category, 2: Variant number. */
					__('%1$s %2$d', 'wphave'),
					$category_label,
					$i,
				);
			}
			$description = sanitize_text_field(
				$data['description'] ?? ($data['ai']['description'] ?? ''),
			);
			$keywords = $data['keywords'] ?? [];
			$content = wphave_normalize_registered_pattern_content($data['content'] ?? '');
			$viewportWidth = $data['viewportWidth'] ?? 1000;
			$inserter = $data['inserter'] ?? false;

			register_block_pattern('wphave/' . $prefix . '-pattern-' . $i, [
				'title' => $title,
				'description' => $description,
				'categories' => [$category],
				'keywords' => $keywords,
				'inserter' => $inserter,
				'viewportWidth' => $viewportWidth,
				'content' => $content,
				//'blockTypes' => array( 'core/post-content' ), // <-- Using "core/post-content" adds the block pattern category "Starter Content"
			]);

			$i++;
		}
	}
endif;

/**
 * Functions to store all the wphave patterns from the collection.
 */

if (!function_exists('wphave_block_pattern_collection')):
	function wphave_block_pattern_collection($args = []) {
		$tags = $args['tags'] ?? false;

		// CACHE INVARIANT: Build the complete collection once per request; category calls filter this shared snapshot.
		static $pattern_collection = null;

		if ($pattern_collection === null) {
			$content_width = wphave_data_get('site_globals', 'layout.width', 1300) ?? 1300;
			$pattern_collection = [];

			$pattern_collection = array_merge(
				wphave_block_pattern_collection_icon_cards(['width' => $content_width]),
				$pattern_collection,
			);
			$pattern_collection = array_merge(
				wphave_block_pattern_collection_content_cards(['width' => $content_width]),
				$pattern_collection,
			);
			$pattern_collection = array_merge(
				wphave_block_pattern_collection_content_sections(['width' => $content_width]),
				$pattern_collection,
			);
			$pattern_collection = array_merge(
				wphave_block_pattern_collection_link_pages(['width' => $content_width]),
				$pattern_collection,
			);
			$pattern_collection = array_merge(
				wphave_block_pattern_collection_call_to_actions(['width' => $content_width]),
				$pattern_collection,
			);
			$pattern_collection = array_merge(
				wphave_block_pattern_collection_tables(['width' => $content_width]),
				$pattern_collection,
			);
			$pattern_collection = array_merge(
				wphave_block_pattern_collection_pricing_cards(['width' => $content_width]),
				$pattern_collection,
			);
			$pattern_collection = array_merge(
				wphave_block_pattern_collection_content_toggling(['width' => $content_width]),
				$pattern_collection,
			);
			$pattern_collection = array_merge(
				wphave_block_pattern_collection_footer(['width' => $content_width]),
				$pattern_collection,
			);
			$pattern_collection = array_merge(
				wphave_block_pattern_collection_header(['width' => $content_width]),
				$pattern_collection,
			);
			$pattern_collection = array_merge(
				wphave_block_pattern_collection_hero(['width' => $content_width]),
				$pattern_collection,
			);
			$pattern_collection = array_merge(
				wphave_block_pattern_collection_announcement_bar(['width' => $content_width]),
				$pattern_collection,
			);
			$pattern_collection = array_merge(
				wphave_block_pattern_collection_feature_list_section(['width' => $content_width]),
				$pattern_collection,
			);
			$pattern_collection = array_merge(
				wphave_block_pattern_collection_gallery_sections(['width' => $content_width]),
				$pattern_collection,
			);
			$pattern_collection = array_merge(
				wphave_block_pattern_collection_mockup_sections(['width' => $content_width]),
				$pattern_collection,
			);
			$pattern_collection = array_merge(
				wphave_block_pattern_collection_stats(['width' => $content_width]),
				$pattern_collection,
			);
			$pattern_collection = array_merge(
				wphave_block_pattern_collection_process(['width' => $content_width]),
				$pattern_collection,
			);
			$pattern_collection = array_merge(
				wphave_block_pattern_collection_testimonials(['width' => $content_width]),
				$pattern_collection,
			);

			// Coming-soon patterns require the theme-bound add-on post type and render pipeline.
			if (!wphave_use_fse()) {
				if (WPHAVE_Add_On_Manager::is_current('coming-soon')) {
					$pattern_collection = array_merge(
						wphave_block_pattern_collection_coming_soon(['width' => $content_width]),
						$pattern_collection,
					);
				}
			}
		}

		$patterns = $pattern_collection;

		if ($tags) {
			$pattern_filtered = [];
			foreach ($patterns as $pattern) {
				$pattern_tags = $pattern['tags'] ?? [];

				$has_tag_match = array_intersect($tags, $pattern_tags);
				if (!empty($has_tag_match)) {
					$pattern_filtered[] = $pattern;
				}
			}
			return $pattern_filtered;
		}

		return $patterns;
	}
endif;
