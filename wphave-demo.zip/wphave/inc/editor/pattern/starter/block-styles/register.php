<?php

/**
 * Register theme-aware starter designs for reusable Block Styles.
 */

if( ! function_exists( 'wphave_block_styles_starter_patterns' ) ) :

	function wphave_block_styles_starter_patterns() {

		if( ! function_exists( 'register_block_pattern' ) ) {
			return;
		}

		$surface = 'var(--wphave-site-color-background)';
		$surface_subtle = 'var(--wphave-site-color-background-contrast-1)';
		$border_subtle = 'var(--wphave-site-color-background-contrast-2)';
		$accent = 'var(--wphave-site-color-accent)';
		$padding = 'var(--wphave-site-padding-m) var(--wphave-site-padding-m) var(--wphave-site-padding-m) var(--wphave-site-padding-m)';
		$corners = 'var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners)';
		$border = array(
			'width' => '1px 1px 1px 1px',
			'style' => 'solid solid solid solid',
			'color' => "$border_subtle $border_subtle $border_subtle $border_subtle",
		);

		$patterns = array(
			'wphave/block-style-soft-card' => array(
				'title' => __( 'Soft Card', 'wphave' ),
				'description' => __( 'A calm card surface with subtle border, spacing and shadow.', 'wphave' ),
				'attrs' => array(
					'dimensions' => array( 'spacing' => array( 'padding' => $padding ) ),
					'background' => array( 'color' => array( 'base' => $surface ) ),
					'frame' => array( 'corners' => $corners, 'border' => $border ),
					'shadow' => array(
						'outset' => array(
							'shift' => array( 'x' => '0rem', 'y' => '0.375rem' ),
							'blur' => '1.5rem',
							'spread' => '-0.75rem',
							'color' => 'rgb(15,23,42)',
							'opacity' => '0.14',
						),
					),
				),
			),
			'wphave/block-style-floating-card' => array(
				'title' => __( 'Floating Card', 'wphave' ),
				'description' => __( 'A slightly more elevated card for featured content.', 'wphave' ),
				'attrs' => array(
					'dimensions' => array( 'spacing' => array( 'padding' => $padding ) ),
					'background' => array( 'color' => array( 'base' => $surface ) ),
					'frame' => array( 'corners' => '18px 18px 18px 18px' ),
					'shadow' => array(
						'outset' => array(
							'shift' => array( 'x' => '0rem', 'y' => '0.75rem' ),
							'blur' => '2.25rem',
							'spread' => '-0.875rem',
							'color' => 'rgb(15,23,42)',
							'opacity' => '0.18',
						),
					),
				),
			),
			'wphave/block-style-subtle-panel' => array(
				'title' => __( 'Subtle Panel', 'wphave' ),
				'description' => __( 'A quiet tinted surface for grouped supporting content.', 'wphave' ),
				'attrs' => array(
					'dimensions' => array( 'spacing' => array( 'padding' => $padding ) ),
					'background' => array( 'color' => array( 'base' => $surface_subtle ) ),
					'frame' => array( 'corners' => $corners, 'border' => $border ),
				),
			),
			'wphave/block-style-accent-callout' => array(
				'title' => __( 'Accent Callout', 'wphave' ),
				'description' => __( 'A restrained callout with an accent edge.', 'wphave' ),
				'attrs' => array(
					'dimensions' => array( 'spacing' => array( 'padding' => $padding ) ),
					'background' => array( 'color' => array( 'base' => $surface_subtle ) ),
					'frame' => array(
						'corners' => '8px 8px 8px 8px',
						'border' => array(
							'width' => '0 0 0 4px',
							'style' => 'none none none solid',
							'color' => "transparent transparent transparent $accent",
						),
					),
				),
			),
			'wphave/block-style-spacious-section' => array(
				'title' => __( 'Spacious Section', 'wphave' ),
				'description' => __( 'Balanced vertical spacing for reusable page sections.', 'wphave' ),
				'attrs' => array(
					'dimensions' => array(
						'spacing' => array(
							'padding' => 'var(--wphave-site-padding-3xl) 0 var(--wphave-site-padding-3xl) 0',
						),
					),
				),
			),
		);

		foreach( $patterns as $name => $pattern ) {
			$content = '<!-- wp:wphave/style ' . serialize_block_attributes(
				array( 'wphave' => $pattern['attrs'] )
			) . ' /-->';

			register_block_pattern(
				$name,
				array(
					'title' => $pattern['title'],
					'description' => $pattern['description'],
					'categories' => array( 'wphave-block-styles' ),
					'keywords' => array( 'style', 'design', 'global' ),
					'viewportWidth' => 500,
					'content' => wphave_normalize_registered_pattern_content( $content ),
					'postTypes' => array( 'wphave-block-styles' ),
					'blockTypes' => array( 'core/post-content' ),
				)
			);
		}

	}

endif;

add_action( 'init', 'wphave_block_styles_starter_patterns', 22 );
