<?php

/**
 * Central bootstrap for editor starter patterns.
 *
 * Starter layouts are creation-time choices for WPHAVE-owned post types. They
 * intentionally live outside the general inserter pattern categories.
 */

require_once __DIR__ . '/add-ons/register.php';
require_once __DIR__ . '/block-styles/register.php';
require_once __DIR__ . '/forms/register.php';
require_once __DIR__ . '/templates/register.php';
require_once wphave_dir() . 'inc/background-jobs/lock.php';
require_once __DIR__ . '/synced-library/catalog.php';
require_once __DIR__ . '/synced-library/rest-controller.php';
