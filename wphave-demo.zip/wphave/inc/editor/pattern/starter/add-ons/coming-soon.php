<?php

/**
 * Return Coming Soon starter layouts.
 */

function wphave_add_on_patterns_coming_soon() {
	return array(
		'coming-soon-minimal' => array(
			'title' => __( 'Minimal Launch', 'wphave' ),
			'category' => 'wphave-addon-coming-soon',
			'viewportWidth' => 1100,
			'content' => '<!-- wp:wphave/coming-soon {"wphave":{"classNames":"ly ly-stk"}} -->
<!-- wp:wphave/heading {"wphave":{"settings":{"headingLevel":"h1"}},"content":"Something new is coming"} /-->

<!-- wp:wphave/paragraph {"content":"We are preparing the website and will be online soon."} /-->
<!-- /wp:wphave/coming-soon -->',
		),
		'coming-soon-launch' => array(
			'title' => __( 'Launch Announcement', 'wphave' ),
			'category' => 'wphave-addon-coming-soon',
			'viewportWidth' => 1100,
			'content' => '<!-- wp:wphave/coming-soon {"wphave":{"classNames":"ly ly-stk"}} -->
<!-- wp:wphave/paragraph {"content":"Launching soon"} /-->

<!-- wp:wphave/heading {"wphave":{"settings":{"headingLevel":"h1"}},"content":"A better experience is on its way"} /-->

<!-- wp:wphave/paragraph {"content":"We are putting the finishing touches on our new website. Please check back shortly."} /-->
<!-- /wp:wphave/coming-soon -->',
		),
		'coming-soon-aurora' => array(
			'title' => __( 'Aurora Launch', 'wphave' ),
			'category' => 'wphave-addon-coming-soon',
			'viewportWidth' => 1100,
			'content' => '<!-- wp:wphave/coming-soon {"wphave":{"classNames":"pa ly ly-stk ly-co-pos bg txta tx-co","styles":"--pa: 5rem 3rem 5rem 3rem;--pa-top: 5rem;--pa-right: 3rem;--pa-bottom: 5rem;--pa-left: 3rem;--ly-co-pos-h: center;--ly-co-pos-v: center;--txta: center;--tx-co: #ffffff","dimensions":{"spacing":{"padding":"5rem 3rem 5rem 3rem"}},"layout":{"stacked":{"contentPosition":"center","gap":"var(--wphave-site-gap-size-l)"}},"stylesLayout":"--ly-gap: var(--wphave-site-gap-size-l)","text":{"align":"center","colors":{"text":"#ffffff"}},"background":{"layers":[{"gradient":{"type":"linear","angle":135,"colorStops":[{"color":"#111827","position":0},{"color":"#312e81","position":48},{"color":"#db2777","position":100}]}}]},"stylesBackgrounds":["--bg-grd: linear-gradient(135deg, #111827 0%, #312e81 48%, #db2777 100%)"]}} -->
<!-- wp:wphave/paragraph {"wphave":{"classNames":"tf-fs tf-fs-text-xs","text":{"typeface":{"size":{"type":"text-xs"}}}},"content":"PRIVATE PREVIEW · LAUNCHING SOON"} /-->

<!-- wp:wphave/heading {"wphave":{"settings":{"headingLevel":"h1"},"classNames":"tf-fs tf-fs-title-xl","text":{"typeface":{"size":{"type":"title-xl"}}}},"content":"Ideas need a little darkness before they glow."} /-->

<!-- wp:wphave/paragraph {"content":"A new digital experience is taking shape. Follow the light and meet us here soon."} /-->

<!-- wp:wphave/button {"content":"Notify me at launch"} /-->
<!-- /wp:wphave/coming-soon -->',
		),
		'coming-soon-editorial' => array(
			'title' => __( 'Editorial Countdown', 'wphave' ),
			'category' => 'wphave-addon-coming-soon',
			'viewportWidth' => 1100,
			'content' => '<!-- wp:wphave/coming-soon {"wphave":{"classNames":"pa ly ly-stk bg-co bg","styles":"--pa: 4rem 4rem 4rem 4rem;--pa-top: 4rem;--pa-right: 4rem;--pa-bottom: 4rem;--pa-left: 4rem;--bg-co: #f4efe6","dimensions":{"spacing":{"padding":"4rem 4rem 4rem 4rem"}},"background":{"color":{"base":"#f4efe6"}}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-gr ly-col-2 ly-m-col-1","layout":{"type":"grid","grid":{"columns":2,"gapX":"4rem","gapY":"2rem","alignVertical":"end"},"stacked":{"columns":1}},"stylesLayout":"--ly-col: 2;--ly-column-gap: 4rem;--ly-row-gap: 2rem;--ly-valign: end;--ly-m-col: 1"}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk","layout":{"stacked":{"gap":"var(--wphave-site-gap-size-m)"}},"stylesLayout":"--ly-gap: var(--wphave-site-gap-size-m)"}} -->
<!-- wp:wphave/paragraph {"content":"ISSUE NO. 01 · COMING SOON"} /-->

<!-- wp:wphave/heading {"wphave":{"settings":{"headingLevel":"h1"}},"content":"The next chapter starts here."} /-->

<!-- wp:wphave/paragraph {"content":"A considered space for stories, ideas and work worth remembering."} /-->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"classNames":"pa ly ly-stk bg-co bg br","styles":"--pa: 2rem 2rem 2rem 2rem;--pa-top: 2rem;--pa-right: 2rem;--pa-bottom: 2rem;--pa-left: 2rem;--bg-co: #151515;--br: 0.25rem 0.25rem 0.25rem 0.25rem;--tx-co: #ffffff","dimensions":{"spacing":{"padding":"2rem 2rem 2rem 2rem"}},"background":{"color":{"base":"#151515"}},"frame":{"corners":"0.25rem 0.25rem 0.25rem 0.25rem"},"text":{"colors":{"text":"#ffffff"}}}} -->
<!-- wp:wphave/paragraph {"content":"OPENING"} /-->

<!-- wp:wphave/heading {"wphave":{"settings":{"headingLevel":"h2"}},"content":"Soon / 2026"} /-->

<!-- wp:wphave/paragraph {"content":"Leave this page open. We are almost ready."} /-->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/coming-soon -->',
		),
	);
}
