<?php

/**
 * Return Popup starter layouts.
 */

function wphave_add_on_patterns_popup() {
	return array(
		'popup-announcement' => array(
			'title' => __( 'Announcement', 'wphave' ),
			'category' => 'wphave-addon-popup',
			'viewportWidth' => 600,
			'content' => '<!-- wp:wphave/popup -->
<!-- wp:wphave/heading {"wphave":{"settings":{"headingLevel":"h2"}},"content":"Important announcement"} /-->

<!-- wp:wphave/paragraph {"content":"Share a concise update with your visitors here."} /-->

<!-- wp:wphave/button {"content":"Learn more"} /-->
<!-- /wp:wphave/popup -->',
		),
		'popup-newsletter' => array(
			'title' => __( 'Newsletter Invitation', 'wphave' ),
			'category' => 'wphave-addon-popup',
			'viewportWidth' => 600,
			'content' => '<!-- wp:wphave/popup -->
<!-- wp:wphave/heading {"wphave":{"settings":{"headingLevel":"h2"}},"content":"Stay in the loop"} /-->

<!-- wp:wphave/paragraph {"content":"Invite visitors to subscribe and receive your latest news."} /-->

<!-- wp:wphave/button {"content":"Subscribe"} /-->
<!-- /wp:wphave/popup -->',
		),
		'popup-midnight' => array(
			'title' => __( 'Midnight Editorial', 'wphave' ),
			'category' => 'wphave-addon-popup',
			'viewportWidth' => 600,
			'content' => '<!-- wp:wphave/popup -->
<!-- wp:wphave/group {"wphave":{"classNames":"pa ly ly-stk bg-co bg br tx-co","styles":"--pa: 3rem 3rem 3rem 3rem;--pa-top: 3rem;--pa-right: 3rem;--pa-bottom: 3rem;--pa-left: 3rem;--bg-co: #101014;--br: 0.5rem 0.5rem 0.5rem 0.5rem;--tx-co: #f7f4ed","dimensions":{"spacing":{"padding":"3rem 3rem 3rem 3rem"}},"background":{"color":{"base":"#101014"}},"frame":{"corners":"0.5rem 0.5rem 0.5rem 0.5rem"},"text":{"colors":{"text":"#f7f4ed"}}}} -->
<!-- wp:wphave/paragraph {"content":"THE SUNDAY EDIT · 05"} /-->

<!-- wp:wphave/heading {"wphave":{"settings":{"headingLevel":"h2"}},"content":"Good ideas deserve a quiet place to land."} /-->

<!-- wp:wphave/paragraph {"content":"One thoughtful email with design, business and culture worth your attention."} /-->

<!-- wp:wphave/button {"content":"Join the list"} /-->

<!-- wp:wphave/paragraph {"content":"No noise. Unsubscribe whenever you like."} /-->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/popup -->',
		),
		'popup-color-block' => array(
			'title' => __( 'Color Block Offer', 'wphave' ),
			'category' => 'wphave-addon-popup',
			'viewportWidth' => 700,
			'content' => '<!-- wp:wphave/popup -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-gr ly-col-2 ly-m-col-1 bg-co bg br ofw","styles":"--ly-col: 2;--ly-column-gap: 0rem;--ly-row-gap: 0rem;--ly-m-col: 1;--bg-co: #f7f7f2;--br: 1.25rem 1.25rem 1.25rem 1.25rem;--ofw: clip","layout":{"type":"grid","grid":{"columns":2,"gapX":"0rem","gapY":"0rem"},"stacked":{"columns":1}},"stylesLayout":"--ly-col: 2;--ly-column-gap: 0rem;--ly-row-gap: 0rem;--ly-m-col: 1","background":{"color":{"base":"#f7f7f2"}},"frame":{"corners":"1.25rem 1.25rem 1.25rem 1.25rem"},"dimensions":{"overflow":"clip"}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"pa ly ly-stk bg-co bg","styles":"--pa: 3rem 2.5rem 3rem 2.5rem;--pa-top: 3rem;--pa-right: 2.5rem;--pa-bottom: 3rem;--pa-left: 2.5rem;--bg-co: #ff5c35","dimensions":{"spacing":{"padding":"3rem 2.5rem 3rem 2.5rem"}},"background":{"color":{"base":"#ff5c35"}}}} -->
<!-- wp:wphave/paragraph {"content":"MEMBER WEEK"} /-->

<!-- wp:wphave/heading {"wphave":{"settings":{"headingLevel":"h2"}},"content":"20% off your next favorite thing."} /-->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"classNames":"pa ly ly-stk","styles":"--pa: 3rem 2.5rem 3rem 2.5rem;--pa-top: 3rem;--pa-right: 2.5rem;--pa-bottom: 3rem;--pa-left: 2.5rem","dimensions":{"spacing":{"padding":"3rem 2.5rem 3rem 2.5rem"}}}} -->
<!-- wp:wphave/paragraph {"content":"A small thank-you for being here. Use the offer before Sunday night."} /-->

<!-- wp:wphave/button {"content":"Unlock offer"} /-->

<!-- wp:wphave/paragraph {"content":"Terms apply · One use per customer"} /-->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/popup -->',
		),
	);
}
