<?php

/**
 * Return Maintenance starter layouts.
 */

function wphave_add_on_patterns_maintenance() {
	return array(
		'maintenance-minimal' => array(
			'title' => __( 'Short Maintenance Notice', 'wphave' ),
			'category' => 'wphave-addon-maintenance',
			'viewportWidth' => 1100,
			'content' => '<!-- wp:wphave/maintenance {"wphave":{"classNames":"ly ly-stk"}} -->
<!-- wp:wphave/heading {"wphave":{"settings":{"headingLevel":"h1"}},"content":"We will be back shortly"} /-->

<!-- wp:wphave/paragraph {"content":"The website is temporarily unavailable while we perform scheduled maintenance."} /-->
<!-- /wp:wphave/maintenance -->',
		),
		'maintenance-detailed' => array(
			'title' => __( 'Detailed Maintenance Notice', 'wphave' ),
			'category' => 'wphave-addon-maintenance',
			'viewportWidth' => 1100,
			'content' => '<!-- wp:wphave/maintenance {"wphave":{"classNames":"ly ly-stk"}} -->
<!-- wp:wphave/paragraph {"content":"Scheduled maintenance"} /-->

<!-- wp:wphave/heading {"wphave":{"settings":{"headingLevel":"h1"}},"content":"We are improving the website"} /-->

<!-- wp:wphave/paragraph {"content":"Our services are temporarily unavailable. Please try again later. Thank you for your patience."} /-->
<!-- /wp:wphave/maintenance -->',
		),
		'maintenance-status-console' => array(
			'title' => __( 'Status Console', 'wphave' ),
			'category' => 'wphave-addon-maintenance',
			'viewportWidth' => 1100,
			'content' => '<!-- wp:wphave/maintenance {"wphave":{"classNames":"pa ly ly-stk ly-co-pos bg-co bg tx-co","styles":"--pa: 4rem 2rem 4rem 2rem;--pa-top: 4rem;--pa-right: 2rem;--pa-bottom: 4rem;--pa-left: 2rem;--ly-co-pos-h: center;--ly-co-pos-v: center;--bg-co: #090d12;--tx-co: #d7ffe7","dimensions":{"spacing":{"padding":"4rem 2rem 4rem 2rem"}},"layout":{"stacked":{"contentPosition":"center"}},"background":{"color":{"base":"#090d12"}},"text":{"colors":{"text":"#d7ffe7"}}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"wi pa ly ly-stk bg-co bg br bso","styles":"--wi: 720px;--pa: 2.5rem 2.5rem 2.5rem 2.5rem;--pa-top: 2.5rem;--pa-right: 2.5rem;--pa-bottom: 2.5rem;--pa-left: 2.5rem;--bg-co: #101820;--br: 1rem 1rem 1rem 1rem;--bso: 0rem 1.5rem 4rem -1rem rgba(0,0,0,0.65)","dimensions":{"width":{"custom":"720px"},"spacing":{"padding":"2.5rem 2.5rem 2.5rem 2.5rem"}},"background":{"color":{"base":"#101820"}},"frame":{"corners":"1rem 1rem 1rem 1rem"},"shadow":{"outset":{"shift":{"x":"0rem","y":"1.5rem"},"blur":"4rem","spread":"-1rem","color":"rgb(0,0,0)","opacity":0.65}}}} -->
<!-- wp:wphave/paragraph {"content":"● SYSTEM STATUS / MAINTENANCE IN PROGRESS"} /-->

<!-- wp:wphave/heading {"wphave":{"settings":{"headingLevel":"h1"}},"content":"Deploying a better version."} /-->

<!-- wp:wphave/paragraph {"content":"Core services are temporarily paused while the update completes. No action is required."} /-->

<!-- wp:wphave/group {"wphave":{"classNames":"pa bg-co bg br","styles":"--pa: 1rem 1rem 1rem 1rem;--pa-top: 1rem;--pa-right: 1rem;--pa-bottom: 1rem;--pa-left: 1rem;--bg-co: #17242d;--br: 0.5rem 0.5rem 0.5rem 0.5rem","dimensions":{"spacing":{"padding":"1rem 1rem 1rem 1rem"}},"background":{"color":{"base":"#17242d"}},"frame":{"corners":"0.5rem 0.5rem 0.5rem 0.5rem"}}} -->
<!-- wp:wphave/paragraph {"content":"Next update: shortly · Status: all systems monitored"} /-->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/maintenance -->',
		),
		'maintenance-friendly' => array(
			'title' => __( 'Friendly Workshop', 'wphave' ),
			'category' => 'wphave-addon-maintenance',
			'viewportWidth' => 1100,
			'content' => '<!-- wp:wphave/maintenance {"wphave":{"classNames":"pa ly ly-stk ly-co-pos bg-co bg txta","styles":"--pa: 4rem 2rem 4rem 2rem;--pa-top: 4rem;--pa-right: 2rem;--pa-bottom: 4rem;--pa-left: 2rem;--ly-co-pos-h: center;--ly-co-pos-v: center;--bg-co: #fff4d8;--txta: center","dimensions":{"spacing":{"padding":"4rem 2rem 4rem 2rem"}},"layout":{"stacked":{"contentPosition":"center","gap":"var(--wphave-site-gap-size-m)"}},"stylesLayout":"--ly-gap: var(--wphave-site-gap-size-m)","background":{"color":{"base":"#fff4d8"}},"text":{"align":"center"}}} -->
<!-- wp:wphave/heading {"wphave":{"settings":{"headingLevel":"h1"}},"content":"Tools out. Ideas in."} /-->

<!-- wp:wphave/paragraph {"content":"We have closed the doors for a moment to make everything smoother, faster and a little more delightful."} /-->

<!-- wp:wphave/group {"wphave":{"classNames":"pa bg-co bg br","styles":"--pa: 1.25rem 2rem 1.25rem 2rem;--pa-top: 1.25rem;--pa-right: 2rem;--pa-bottom: 1.25rem;--pa-left: 2rem;--bg-co: #ffffff;--br: 999px 999px 999px 999px","dimensions":{"spacing":{"padding":"1.25rem 2rem 1.25rem 2rem"}},"background":{"color":{"base":"#ffffff"}},"frame":{"corners":"999px 999px 999px 999px"}}} -->
<!-- wp:wphave/paragraph {"content":"Expected back soon · Thanks for your patience"} /-->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/maintenance -->',
		),
	);
}
