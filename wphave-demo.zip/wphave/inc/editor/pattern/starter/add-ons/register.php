<?php

/**
 * Register starter layouts for add-ons that benefit from visual preselection.
 */

require_once __DIR__ . '/announcement-bar.php';
require_once __DIR__ . '/coming-soon.php';
require_once __DIR__ . '/maintenance.php';
require_once __DIR__ . '/cta-slide-in.php';
require_once __DIR__ . '/popup.php';

if ( ! function_exists( 'wphave_add_on_starter_block_patterns' ) ) :

	function wphave_add_on_starter_block_patterns() {
		if( ! function_exists( 'register_block_pattern' ) ) {
			return;
		}

		$categories = array(
			'wphave-addon-announcement-bar' => __( 'Announcement Bar Layouts', 'wphave' ),
			'wphave-addon-coming-soon' => __( 'Coming Soon Layouts', 'wphave' ),
			'wphave-addon-maintenance' => __( 'Maintenance Layouts', 'wphave' ),
			'wphave-addon-cta-slide-in' => __( 'CTA Slide-In Layouts', 'wphave' ),
			'wphave-addon-popup' => __( 'Popup Layouts', 'wphave' ),
		);

		foreach( $categories as $category => $label ) {
			register_block_pattern_category( $category, array( 'label' => $label ) );
		}

		$patterns = array_merge(
			wphave_add_on_patterns_announcement_bar(),
			wphave_add_on_patterns_coming_soon(),
			wphave_add_on_patterns_maintenance(),
			wphave_add_on_patterns_cta_slide_in(),
			wphave_add_on_patterns_popup()
		);

		foreach( $patterns as $name => $pattern ) {
			register_block_pattern(
				'wphave/add-on-' . $name,
				array(
					'title' => $pattern['title'],
					'categories' => array( $pattern['category'] ),
					'viewportWidth' => $pattern['viewportWidth'],
					'content' => wphave_normalize_registered_pattern_content( $pattern['content'] ),
					'postTypes' => array( 'wphave-add-ons' ),
					'blockTypes' => array( 'core/post-content' ),
				)
			);
		}
	}

endif;

add_action( 'init', 'wphave_add_on_starter_block_patterns', 22 );
