<?php

/**
 * Return Cta Slide In starter layouts.
 */

function wphave_add_on_patterns_cta_slide_in() {
	return array(
		'cta-slide-in-compact' => array(
			'title' => __( 'Compact Call to Action', 'wphave' ),
			'category' => 'wphave-addon-cta-slide-in',
			'viewportWidth' => 500,
			'content' => '<!-- wp:wphave/cta-slide-in -->
<!-- wp:wphave/heading {"wphave":{"settings":{"headingLevel":"h3"}},"content":"Ready to get started?"} /-->

<!-- wp:wphave/paragraph {"content":"Discover how we can help with your next project."} /-->

<!-- wp:wphave/button {"content":"Learn more"} /-->
<!-- /wp:wphave/cta-slide-in -->',
		),
		'cta-slide-in-offer' => array(
			'title' => __( 'Promotional Offer', 'wphave' ),
			'category' => 'wphave-addon-cta-slide-in',
			'viewportWidth' => 500,
			'content' => '<!-- wp:wphave/cta-slide-in -->
<!-- wp:wphave/paragraph {"content":"Limited offer"} /-->

<!-- wp:wphave/heading {"wphave":{"settings":{"headingLevel":"h3"}},"content":"Do not miss this opportunity"} /-->

<!-- wp:wphave/button {"content":"View offer"} /-->
<!-- /wp:wphave/cta-slide-in -->',
		),
		'cta-slide-in-glass' => array(
			'title' => __( 'Glass Gradient Card', 'wphave' ),
			'category' => 'wphave-addon-cta-slide-in',
			'viewportWidth' => 500,
			'content' => '<!-- wp:wphave/cta-slide-in -->
<!-- wp:wphave/group {"wphave":{"classNames":"pa ly ly-stk bg br bso tx-co","styles":"--pa: 2rem 2rem 2rem 2rem;--pa-top: 2rem;--pa-right: 2rem;--pa-bottom: 2rem;--pa-left: 2rem;--br: 1.25rem 1.25rem 1.25rem 1.25rem;--bso: 0rem 1.25rem 3rem -1rem rgba(37,23,96,0.55);--tx-co: #ffffff","dimensions":{"spacing":{"padding":"2rem 2rem 2rem 2rem"}},"frame":{"corners":"1.25rem 1.25rem 1.25rem 1.25rem"},"shadow":{"outset":{"shift":{"x":"0rem","y":"1.25rem"},"blur":"3rem","spread":"-1rem","color":"rgb(37,23,96)","opacity":0.55}},"text":{"colors":{"text":"#ffffff"}},"background":{"layers":[{"gradient":{"type":"linear","angle":135,"colorStops":[{"color":"#7c3aed","position":0},{"color":"#2563eb","position":100}]}}]},"stylesBackgrounds":["--bg-grd: linear-gradient(135deg, #7c3aed 0%, #2563eb 100%)"]}} -->
<!-- wp:wphave/paragraph {"content":"NEW · ONE MINUTE READ"} /-->

<!-- wp:wphave/heading {"wphave":{"settings":{"headingLevel":"h3"}},"content":"Turn curious visitors into confident customers."} /-->

<!-- wp:wphave/paragraph {"content":"See the simple framework behind clearer, higher-converting pages."} /-->

<!-- wp:wphave/button {"content":"Open the guide"} /-->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/cta-slide-in -->',
		),
		'cta-slide-in-ticket' => array(
			'title' => __( 'Event Ticket', 'wphave' ),
			'category' => 'wphave-addon-cta-slide-in',
			'viewportWidth' => 500,
			'content' => '<!-- wp:wphave/cta-slide-in -->
<!-- wp:wphave/group {"wphave":{"classNames":"pa ly ly-stk bg-co bg br","styles":"--pa: 2rem 2rem 2rem 2rem;--pa-top: 2rem;--pa-right: 2rem;--pa-bottom: 2rem;--pa-left: 2rem;--bg-co: #ffec99;--br: 0.25rem 0.25rem 0.25rem 0.25rem","dimensions":{"spacing":{"padding":"2rem 2rem 2rem 2rem"}},"background":{"color":{"base":"#ffec99"}},"frame":{"corners":"0.25rem 0.25rem 0.25rem 0.25rem"}}} -->
<!-- wp:wphave/paragraph {"content":"LIVE SESSION · THURSDAY 18:00"} /-->

<!-- wp:wphave/heading {"wphave":{"settings":{"headingLevel":"h3"}},"content":"Build a homepage people remember."} /-->

<!-- wp:wphave/paragraph {"content":"A practical 45-minute session with real examples and a focused Q&A."} /-->

<!-- wp:wphave/button {"content":"Reserve a seat"} /-->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/cta-slide-in -->',
		),
	);
}
