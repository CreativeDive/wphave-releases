<?php

/**
 * Returns registered template starter patterns.
 *
 * Each future template category lives in its own file and contributes through
 * this aggregate using the filters below.
 *
 * @return array<string,array> Pattern definitions keyed by stable suffix.
 */
function wphave_template_starter_patterns_subscriber_confirmation() {
    $category = wphave_template_starter_families()['subscriber_confirmation']['category'];

    return [
        'subscriber-confirmation-default' => [
            'title' => __( 'Subscriber Confirmation', 'wphave' ),
            'description' => __( 'A centered confirmation status with a return action.', 'wphave' ),
            'category' => $category,
            'family' => 'subscriber_confirmation',
            'variant' => 'default',
            'recommended' => true,
            'viewportWidth' => 720,
            'content' => wphave_basic_template_content( 'subscriber_confirmation' ),
        ],
    ];
}
