<?php

/**
 * Return shared starter patterns for singular content templates.
 *
 * @return array<string,array>
 */
function wphave_template_starter_patterns_singular() {
    $category = wphave_template_starter_families()['singular']['category'];

    return [
        'singular-content-standard' => [
            'title' => __( 'Content Standard', 'wphave' ),
            'description' => __( 'A neutral single-content layout suitable for custom content types.', 'wphave' ),
            'category' => $category,
            'family' => 'singular',
            'variant' => 'content-standard',
            'recommended' => true,
            'content' => '<!-- wp:wphave/title /-->
<!-- wp:wphave/subtitle /-->
<!-- wp:wphave/featured-image /-->
<!-- wp:wphave/content /-->',
        ],
        'singular-post-editorial' => [
            'title' => __( 'Post Editorial', 'wphave' ),
            'description' => __( 'An editorial post layout with taxonomy, author, date, reading time and comments.', 'wphave' ),
            'category' => $category,
            'family' => 'singular',
            'variant' => 'post-editorial',
            'recommended' => false,
            'content' => '<!-- wp:wphave/title /-->
<!-- wp:wphave/subtitle /-->
<!-- wp:wphave/taxonomy-terms /-->
<!-- wp:wphave/date /-->
<!-- wp:wphave/meta-author /-->
<!-- wp:wphave/meta-read-time /-->
<!-- wp:wphave/featured-image /-->
<!-- wp:wphave/content /-->
<!-- wp:wphave/comments /-->',
        ],
    ];
}
