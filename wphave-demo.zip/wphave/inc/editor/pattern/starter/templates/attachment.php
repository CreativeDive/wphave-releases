<?php

/** Media pages reuse the same Content slot contract as the runtime fallback. */
function wphave_template_starter_patterns_attachment() {
	return [
		'attachment-standard' => [
			'title' => __('Media Page', 'wphave'),
			'description' => __('A media preview with title, caption and description.', 'wphave'),
			'category' => wphave_template_starter_families()['attachment']['category'],
			'family' => 'attachment',
			'variant' => 'standard',
			'recommended' => true,
			'content' => WPHAVE_Template_Base::get_template_content('attachment'),
		],
	];
}
