<?php

/**
 * Return shared archive starter patterns.
 *
 * The archive family is intentionally context-neutral. WordPress resolves the
 * current author, date, post type or taxonomy while the same layout remains
 * reusable across every archive template id.
 *
 * @return array<string,array>
 */

function wphave_template_starter_patterns_archive() {
    $category = wphave_template_starter_families()['archive']['category'];

    return [
        'archive-grid' => [
            'title' => __( 'Archive Grid', 'wphave' ),
            'description' => __( 'A responsive three-column archive with images, summaries and pagination.', 'wphave' ),
            'category' => $category,
            'family' => 'archive',
            'variant' => 'grid',
            'recommended' => true,
            'content' => '<!-- wp:wphave/title /-->
<!-- wp:wphave/subtitle /-->
<!-- wp:wphave/loop -->
    <!-- wp:wphave/loop-template {"wphave":{"layout":{"type":"grid","grid":{"columns":3,"gridRowHeight":"auto","alignVertical":"stretch","alignHorizontal":"stretch"}},"classNames":"ly ly-gr ly-col-3 ly-gr-m ly-m-col-1","stylesLayout":"--ly-column-gap: var(--wphave-site-layout-gap);--ly-row-gap: var(--wphave-site-layout-gap);--ly-col: 3;--ly-valign: stretch;--ly-halign: stretch;--ly-m-col: 1","mobile":{"layout":{"grid":{"columns":1}}}}} -->
        <!-- wp:wphave/featured-image /-->
        <!-- wp:wphave/title {"wphave":{"settings":{"headingLevel":"h3"}}} /-->
        <!-- wp:wphave/excerpt /-->
        <!-- wp:wphave/read-more /-->
    <!-- /wp:wphave/loop-template -->
<!-- /wp:wphave/loop -->
<!-- wp:wphave/loop-empty /-->
<!-- wp:wphave/loop-pagination /-->',
        ],
        'archive-list' => [
            'title' => __( 'Archive List', 'wphave' ),
            'description' => __( 'A compact chronological archive with metadata, summaries and pagination.', 'wphave' ),
            'category' => $category,
            'family' => 'archive',
            'variant' => 'list',
            'recommended' => false,
            'content' => '<!-- wp:wphave/title /-->
<!-- wp:wphave/subtitle /-->
<!-- wp:wphave/loop -->
    <!-- wp:wphave/loop-template -->
        <!-- wp:wphave/date /-->
        <!-- wp:wphave/title {"wphave":{"settings":{"headingLevel":"h3"}}} /-->
        <!-- wp:wphave/excerpt /-->
        <!-- wp:wphave/read-more /-->
    <!-- /wp:wphave/loop-template -->
<!-- /wp:wphave/loop -->
<!-- wp:wphave/loop-empty /-->
<!-- wp:wphave/loop-pagination /-->',
        ],
    ];
}
