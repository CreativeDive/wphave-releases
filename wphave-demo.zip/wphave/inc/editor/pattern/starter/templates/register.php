<?php

/** Registers starter layouts for WPHAVE template types. */

require_once __DIR__ . '/registry.php';
require_once __DIR__ . '/attachment.php';
require_once __DIR__ . '/archive.php';
require_once __DIR__ . '/commerce.php';
require_once __DIR__ . '/custom.php';
require_once __DIR__ . '/page.php';
require_once __DIR__ . '/singular.php';
require_once __DIR__ . '/system.php';
require_once __DIR__ . '/subscriber-confirmation.php';

if (!function_exists('wphave_template_starter_block_patterns')):
	function wphave_template_starter_block_patterns() {
		if (!function_exists('register_block_pattern')) {
			return;
		}

		$categories = [];

		foreach (wphave_template_starter_families() as $definition) {
			$categories[$definition['category']] = $definition['label'];
		}

		$categories = apply_filters('wphave_template_starter_pattern_categories', $categories);

		foreach ($categories as $category => $label) {
			register_block_pattern_category($category, ['label' => $label]);
		}

		$patterns = array_merge(
			wphave_template_starter_patterns_attachment(),
			wphave_template_starter_patterns_archive(),
			wphave_template_starter_patterns_commerce(),
			wphave_template_starter_patterns_custom(),
			wphave_template_starter_patterns_page(),
			wphave_template_starter_patterns_singular(),
			wphave_template_starter_patterns_system(),
			wphave_template_starter_patterns_subscriber_confirmation(),
		);
		$patterns = apply_filters('wphave_template_starter_patterns', $patterns);

		foreach ($patterns as $name => $pattern) {
			register_block_pattern('wphave/template-' . $name, [
				'title' => $pattern['title'],
				'description' => $pattern['description'] ?? '',
				'categories' => [$pattern['category']],
				'viewportWidth' => $pattern['viewportWidth'] ?? wphave_block_pattern_width(),
				'content' => wphave_normalize_registered_pattern_content($pattern['content']),
				'postTypes' => [WPHAVE_Templates::POST_TYPE],
				'blockTypes' => ['core/post-content'],
			]);
		}
	}
endif;

add_action('init', 'wphave_template_starter_block_patterns', 22);
