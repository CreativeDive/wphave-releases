<?php

/**
 * Return block-first WooCommerce starter patterns.
 *
 * Each transactional route owns its category so a Cart template can never be
 * initialized with a Checkout or Account block contract.
 *
 * @return array<string,array>
 */

function wphave_template_starter_patterns_commerce() {
    $families = wphave_template_starter_families();

    return [
        'commerce-product-standard' => [
            'title' => __( 'Product Standard', 'wphave' ),
            'description' => __( 'A block-first product detail layout with gallery, purchase controls and product details.', 'wphave' ),
            'category' => $families['commerce_product']['category'],
            'family' => 'commerce_product',
            'variant' => 'standard',
            'recommended' => true,
            'content' => wphave_basic_template_content( 'post_type_product' ),
        ],
        'commerce-archive-grid' => [
            'title' => __( 'Product Archive Grid', 'wphave' ),
            'description' => __( 'A product collection with result count, sorting and a responsive purchase grid.', 'wphave' ),
            'category' => $families['commerce_archive']['category'],
            'family' => 'commerce_archive',
            'variant' => 'grid',
            'recommended' => true,
            'content' => wphave_basic_template_content( 'shop' ),
        ],
        'commerce-cart-standard' => [
            'title' => __( 'Cart Standard', 'wphave' ),
            'description' => __( 'The canonical WooCommerce Cart block with store notices.', 'wphave' ),
            'category' => $families['commerce_cart']['category'],
            'family' => 'commerce_cart',
            'variant' => 'standard',
            'recommended' => true,
            'content' => wphave_basic_template_content( 'cart' ),
        ],
        'commerce-checkout-standard' => [
            'title' => __( 'Checkout Standard', 'wphave' ),
            'description' => __( 'The canonical WooCommerce Checkout block with store notices.', 'wphave' ),
            'category' => $families['commerce_checkout']['category'],
            'family' => 'commerce_checkout',
            'variant' => 'standard',
            'recommended' => true,
            'content' => wphave_basic_template_content( 'checkout' ),
        ],
        'commerce-account-standard' => [
            'title' => __( 'Account Standard', 'wphave' ),
            'description' => __( 'A safe account layout that renders the canonical page content and store notices.', 'wphave' ),
            'category' => $families['commerce_account']['category'],
            'family' => 'commerce_account',
            'variant' => 'standard',
            'recommended' => true,
            'content' => wphave_basic_template_content( 'account' ),
        ],
        'commerce-confirmation-standard' => [
            'title' => __( 'Order Confirmation Standard', 'wphave' ),
            'description' => __( 'A safe order confirmation layout that delegates order output to WooCommerce.', 'wphave' ),
            'category' => $families['commerce_confirmation']['category'],
            'family' => 'commerce_confirmation',
            'variant' => 'standard',
            'recommended' => true,
            'content' => wphave_basic_template_content( 'thank_you' ),
        ],
    ];
}
