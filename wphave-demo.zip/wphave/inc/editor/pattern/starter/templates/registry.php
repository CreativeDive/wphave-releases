<?php

/**
 * Central metadata registry for template starter families.
 *
 * Pattern content remains in focused provider files. This registry owns the
 * stable contract shared by the Templates catalog and the editor pattern UI.
 */

if (!function_exists('wphave_template_starter_families')):
	function wphave_template_starter_families() {
		$families = [
			'archive' => [
				'category' => 'wphave-template-archive',
				'label' => __('Archive Layouts', 'wphave'),
				'recommended_variant' => 'grid',
				'variants' => [
					'grid' => 'wphave/template-archive-grid',
					'list' => 'wphave/template-archive-list',
				],
			],
			'singular' => [
				'category' => 'wphave-template-singular',
				'label' => __('Single Content Layouts', 'wphave'),
				'recommended_variant' => 'content-standard',
				'variants' => [
					'content-standard' => 'wphave/template-singular-content-standard',
					'post-editorial' => 'wphave/template-singular-post-editorial',
				],
			],
			'attachment' => [
				'category' => 'wphave-template-attachment',
				'label' => __('Media Page Layouts', 'wphave'),
				'recommended_variant' => 'standard',
				'variants' => ['standard' => 'wphave/template-attachment-standard'],
			],
			'page' => [
				'category' => 'wphave-template-page',
				'label' => __('Page Layouts', 'wphave'),
				'recommended_variant' => 'standard',
				'variants' => [
					'standard' => 'wphave/template-page-standard',
				],
			],
			'system_search' => [
				'category' => 'wphave-template-system-search',
				'label' => __('Search Layouts', 'wphave'),
				'recommended_variant' => 'results',
				'variants' => [
					'results' => 'wphave/template-system-search-results',
				],
			],
			'system_not_found' => [
				'category' => 'wphave-template-system-not-found',
				'label' => __('Not Found Layouts', 'wphave'),
				'recommended_variant' => 'helpful',
				'variants' => [
					'helpful' => 'wphave/template-system-not-found-helpful',
				],
			],
			'system_protected' => [
				'category' => 'wphave-template-system-protected',
				'label' => __('Password Protected Layouts', 'wphave'),
				'recommended_variant' => 'centered',
				'variants' => [
					'centered' => 'wphave/template-system-protected-centered',
				],
			],
			'subscriber_confirmation' => [
				'category' => 'wphave-template-subscriber-confirmation',
				'label' => __('Subscriber Confirmation Layouts', 'wphave'),
				'recommended_variant' => 'default',
				'variants' => [
					'default' => 'wphave/template-subscriber-confirmation-default',
				],
			],
			'commerce_product' => [
				'category' => 'wphave-template-commerce-product',
				'label' => __('Product Layouts', 'wphave'),
				'recommended_variant' => 'standard',
				'variants' => [
					'standard' => 'wphave/template-commerce-product-standard',
				],
			],
			'commerce_archive' => [
				'category' => 'wphave-template-commerce-archive',
				'label' => __('Product Archive Layouts', 'wphave'),
				'recommended_variant' => 'grid',
				'variants' => [
					'grid' => 'wphave/template-commerce-archive-grid',
				],
			],
			'commerce_cart' => [
				'category' => 'wphave-template-commerce-cart',
				'label' => __('Cart Layouts', 'wphave'),
				'recommended_variant' => 'standard',
				'variants' => [
					'standard' => 'wphave/template-commerce-cart-standard',
				],
			],
			'commerce_checkout' => [
				'category' => 'wphave-template-commerce-checkout',
				'label' => __('Checkout Layouts', 'wphave'),
				'recommended_variant' => 'standard',
				'variants' => [
					'standard' => 'wphave/template-commerce-checkout-standard',
				],
			],
			'commerce_account' => [
				'category' => 'wphave-template-commerce-account',
				'label' => __('Account Layouts', 'wphave'),
				'recommended_variant' => 'standard',
				'variants' => [
					'standard' => 'wphave/template-commerce-account-standard',
				],
			],
			'commerce_confirmation' => [
				'category' => 'wphave-template-commerce-confirmation',
				'label' => __('Order Confirmation Layouts', 'wphave'),
				'recommended_variant' => 'standard',
				'variants' => [
					'standard' => 'wphave/template-commerce-confirmation-standard',
				],
			],
			'custom' => [
				'category' => 'wphave-template-custom',
				'label' => __('Custom Template Layouts', 'wphave'),
				'recommended_variant' => 'full-width',
				'variants' => [
					'full-width' => 'wphave/template-custom-full-width',
					'centered' => 'wphave/template-custom-centered',
					'content-canvas' => 'wphave/template-custom-content-canvas',
				],
			],
		];

		return apply_filters('wphave_template_starter_families', $families);
	}
endif;

if (!function_exists('wphave_template_starter_contract')):
	/**
	 * Return the catalog-facing contract for one starter family.
	 *
	 * @param string $family Family identifier.
	 * @param array  $args Contract overrides.
	 * @return array
	 */
	function wphave_template_starter_contract($family, $args = []) {
		$definition = wphave_template_starter_families()[$family] ?? [];

		if (!$definition) {
			return [];
		}

		$variants = $definition['variants'] ?? [];
		$recommended_variant =
			$args['recommended_variant'] ?? ($definition['recommended_variant'] ?? '');

		if (!isset($variants[$recommended_variant])) {
			$recommended_variant = $definition['recommended_variant'] ?? '';
		}

		return [
			'starter_family' => $family,
			'starter_pattern_category' => $definition['category'],
			'starter_recommended_pattern' => $variants[$recommended_variant] ?? '',
			'starter_variants' => array_keys($variants),
		];
	}
endif;
