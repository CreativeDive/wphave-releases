<?php

/**
 * Return neutral starter patterns for independently assigned templates.
 *
 * @return array<string,array>
 */
function wphave_template_starter_patterns_custom() {
    $category = wphave_template_starter_families()['custom']['category'];

    return [
        'custom-full-width' => [
            'title' => __( 'Full Width', 'wphave' ),
            'description' => __( 'A neutral full-width canvas for the assigned content.', 'wphave' ),
            'category' => $category,
            'family' => 'custom',
            'variant' => 'full-width',
            'recommended' => true,
            'content' => '<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked"},"features":{"size":"full"},"classNames":"bsz-full ly ly-stk"}} -->
    <!-- wp:wphave/content /-->
<!-- /wp:wphave/group -->',
        ],
        'custom-centered' => [
            'title' => __( 'Centered Content', 'wphave' ),
            'description' => __( 'A narrow centered canvas for focused reading experiences.', 'wphave' ),
            'category' => $category,
            'family' => 'custom',
            'variant' => 'centered',
            'recommended' => false,
            'content' => '<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"contentPosition":"center"}},"dimensions":{"innerWidth":{"limit":"max","custom":"720px"}},"styles":"--wi-in: 720px;--ly-co-pos-h: center;--ly-co-pos-v: center","classNames":"wi-in ly ly-stk ly-co-pos"}} -->
    <!-- wp:wphave/content /-->
<!-- /wp:wphave/group -->',
        ],
        'custom-content-canvas' => [
            'title' => __( 'Content Canvas', 'wphave' ),
            'description' => __( 'A contained content surface with spacing and a subtle background.', 'wphave' ),
            'category' => $category,
            'family' => 'custom',
            'variant' => 'content-canvas',
            'recommended' => false,
            'content' => '<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked"},"dimensions":{"spacing":{"padding":"var(--wphave-site-padding-xl)"}},"background":{"color":{"base":"var(--wphave-site-color-background-contrast-1)"}},"styles":"--pa: var(--wphave-site-padding-xl);--bg-co: var(--wphave-site-color-background-contrast-1)","classNames":"pa bg-co bg ly ly-stk"}} -->
    <!-- wp:wphave/content /-->
<!-- /wp:wphave/group -->',
        ],
    ];
}
