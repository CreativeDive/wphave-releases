<?php

/**
 * Return starter patterns for public system contexts.
 *
 * Each context has a dedicated family because its required runtime blocks are
 * incompatible with the other system screens.
 *
 * @return array<string,array>
 */
function wphave_template_starter_patterns_system() {
    $families = wphave_template_starter_families();
    $not_found_title = wp_json_encode( __( 'Page not found', 'wphave' ) );
    $not_found_message = wp_json_encode( __( 'The requested page could not be found. Try searching for the content you need.', 'wphave' ) );
    $protected_title = wp_json_encode( __( 'Protected content', 'wphave' ) );
    $protected_message = wp_json_encode( __( 'Enter the password to view this content.', 'wphave' ) );

    return [
        'system-search-results' => [
            'title' => __( 'Search Results', 'wphave' ),
            'description' => __( 'A complete search screen with form, result list, empty state and pagination.', 'wphave' ),
            'category' => $families['system_search']['category'],
            'family' => 'system_search',
            'variant' => 'results',
            'recommended' => true,
            'content' => '<!-- wp:wphave/search-form /-->
<!-- wp:wphave/title /-->
<!-- wp:wphave/loop -->
    <!-- wp:wphave/loop-template -->
        <!-- wp:wphave/title {"wphave":{"settings":{"headingLevel":"h3"}}} /-->
        <!-- wp:wphave/excerpt /-->
        <!-- wp:wphave/read-more /-->
    <!-- /wp:wphave/loop-template -->
<!-- /wp:wphave/loop -->
<!-- wp:wphave/loop-empty /-->
<!-- wp:wphave/loop-pagination /-->',
        ],
        'system-not-found-helpful' => [
            'title' => __( 'Helpful Not Found', 'wphave' ),
            'description' => __( 'A clear not-found message followed by a search action.', 'wphave' ),
            'category' => $families['system_not_found']['category'],
            'family' => 'system_not_found',
            'variant' => 'helpful',
            'recommended' => true,
            'content' => '<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"contentPosition":"center"}},"classNames":"ly ly-stk ly-co-pos","styles":"--ly-co-pos-h: center;--ly-co-pos-v: center"}} -->
    <!-- wp:wphave/heading {"content":' . $not_found_title . '} /-->
    <!-- wp:wphave/paragraph {"content":' . $not_found_message . '} /-->
    <!-- wp:wphave/search-form /-->
<!-- /wp:wphave/group -->',
        ],
        'system-protected-centered' => [
            'title' => __( 'Centered Password Form', 'wphave' ),
            'description' => __( 'A focused password prompt for protected posts and pages.', 'wphave' ),
            'category' => $families['system_protected']['category'],
            'family' => 'system_protected',
            'variant' => 'centered',
            'recommended' => true,
            'content' => '<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"contentPosition":"center"}},"classNames":"ly ly-stk ly-co-pos","styles":"--ly-co-pos-h: center;--ly-co-pos-v: center"}} -->
    <!-- wp:wphave/heading {"content":' . $protected_title . '} /-->
    <!-- wp:wphave/paragraph {"content":' . $protected_message . '} /-->
    <!-- wp:wphave/password-protected-form /-->
<!-- /wp:wphave/group -->',
        ],
    ];
}
