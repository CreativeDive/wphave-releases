<?php

/**
 * Return the metadata-free Page starter pattern.
 *
 * @return array<string,array>
 */
function wphave_template_starter_patterns_page() {
    $category = wphave_template_starter_families()['page']['category'];

    return [
        'page-standard' => [
            'title' => __( 'Page Standard', 'wphave' ),
            'description' => __( 'A focused page layout with title, introduction and main content.', 'wphave' ),
            'category' => $category,
            'family' => 'page',
            'variant' => 'standard',
            'recommended' => true,
            'content' => '<!-- wp:wphave/title /-->
<!-- wp:wphave/subtitle /-->
<!-- wp:wphave/content /-->',
        ],
    ];
}
