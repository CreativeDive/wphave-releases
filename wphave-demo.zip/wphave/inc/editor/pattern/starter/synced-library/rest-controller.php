<?php

final class WPHAVE_Synced_Pattern_Library_REST_Controller {
	private const META_KEY = '_wphave_pattern_library_key';
	private const LOCK_KEY = 'wphave_synced_pattern_library_install_lock';
	private const LOCK_TTL = MINUTE_IN_SECONDS;
	private const ROUTE = '/patterns/synced-library';

	public static function register_routes(): void {
		register_rest_route(
			'wphave/v1',
			self::ROUTE,
			array(
				array(
					'methods' => WP_REST_Server::READABLE,
					'callback' => array( __CLASS__, 'get_catalog' ),
					'permission_callback' => array( __CLASS__, 'can_install' ),
				),
				array(
					'methods' => WP_REST_Server::CREATABLE,
					'callback' => array( __CLASS__, 'install' ),
					'permission_callback' => array( __CLASS__, 'can_install' ),
					'args' => array(
						'keys' => array(
							'type' => 'array',
							'required' => true,
							'maxItems' => 20,
							'items' => array(
								'type' => 'string',
								'pattern' => '^[a-z0-9-]+$',
							),
						),
					),
				),
			)
		);
	}

	public static function can_install(): bool {
		$post_type = get_post_type_object( 'wp_block' );
		$capability = $post_type?->cap?->create_posts ?? 'edit_posts';

		return wphave_release_feature_ready( 'syncedPatternLibraryInstaller' ) && current_user_can( $capability );
	}

	public static function get_catalog() {
		$authorization = self::require_install_access();

		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		return new WP_REST_Response( self::catalog_response(), 200 );
	}

	public static function install( WP_REST_Request $request ) {
		$authorization = self::require_install_access();

		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$lock_token = WPHAVE_Background_Job_Lock::acquire( self::LOCK_KEY, self::LOCK_TTL );

		if ( ! $lock_token ) {
			return new WP_Error(
				'wphave_pattern_library_busy',
				__( 'Another Synced Pattern installation is already running.', 'wphave' ),
				array( 'status' => 409 )
			);
		}

		$created_ids = array();

		try {
			$catalog = wphave_synced_pattern_library_catalog();
			$installed = self::installed_keys();
			$keys = array_values( array_unique( array_map( 'sanitize_key', (array) $request->get_param( 'keys' ) ) ) );

			foreach ( $keys as $key ) {
				if ( isset( $installed[$key] ) ) {
					continue;
				}

				if ( ! isset( $catalog[$key] ) ) {
					throw new InvalidArgumentException( __( 'The requested Synced Pattern is not part of the installable catalog.', 'wphave' ) );
				}

				$pattern = $catalog[$key];
				$post_id = wp_insert_post(
					wp_slash(
						array(
							'post_type' => 'wp_block',
							'post_status' => 'publish',
							'post_title' => $pattern['title'],
							'post_content' => $pattern['content'],
						)
					),
					true
				);

				if ( is_wp_error( $post_id ) ) {
					throw new RuntimeException( $post_id->get_error_message() );
				}

				$created_ids[] = $post_id;

				if ( ! add_post_meta( $post_id, self::META_KEY, $key, true ) ) {
					throw new RuntimeException( __( 'The Synced Pattern provenance could not be stored.', 'wphave' ) );
				}
			}
		} catch ( Throwable $error ) {
			foreach ( array_reverse( $created_ids ) as $post_id ) {
				wp_delete_post( $post_id, true );
			}

			return new WP_Error(
				'wphave_pattern_library_install_failed',
				$error->getMessage(),
				array( 'status' => $error instanceof InvalidArgumentException ? 400 : 500 )
			);
		} finally {
			// CONCURRENCY INVARIANT: Cleanup is ownership-bound. A timed-out
			// installer cannot release the lease acquired by its successor.
			WPHAVE_Background_Job_Lock::release( self::LOCK_KEY, $lock_token );
		}

		$response = self::catalog_response();
		$response['installedCount'] = count( $created_ids );

		return new WP_REST_Response( $response, 201 );
	}

	private static function require_install_access() {
		// AUTHORIZATION INVARIANT: REST permission callbacks are only an early
		// dispatch gate. Both public callbacks must re-authorize before catalog
		// disclosure, database queries, lock acquisition, or wp_block creation.
		if ( self::can_install() ) {
			return true;
		}

		return new WP_Error(
			'wphave_pattern_library_forbidden',
			__( 'You are not allowed to access the Synced Pattern library.', 'wphave' ),
			array( 'status' => 403 )
		);
	}

	private static function catalog_response(): array {
		$installed = self::installed_keys();
		$patterns = array();

		foreach ( wphave_synced_pattern_library_catalog() as $key => $pattern ) {
			$patterns[] = array(
				'key' => $key,
				'title' => $pattern['title'],
				'description' => $pattern['description'],
				'content' => $pattern['content'],
				'viewportWidth' => 500,
				'installed' => isset( $installed[$key] ),
			);
		}

		return array( 'patterns' => $patterns );
	}

	private static function installed_keys(): array {
		$post_ids = get_posts(
			array(
				'post_type' => 'wp_block',
				'post_status' => 'any',
				'posts_per_page' => -1,
				'fields' => 'ids',
				'no_found_rows' => true,
				'meta_query' => array(
					array(
						'key' => self::META_KEY,
						'compare' => 'EXISTS',
					),
				),
			)
		);
		$installed = array();

		foreach ( $post_ids as $post_id ) {
			$key = sanitize_key( get_post_meta( $post_id, self::META_KEY, true ) );

			if ( $key ) {
				$installed[$key] = true;
			}
		}

		return $installed;
	}

}

add_action( 'rest_api_init', array( 'WPHAVE_Synced_Pattern_Library_REST_Controller', 'register_routes' ) );
