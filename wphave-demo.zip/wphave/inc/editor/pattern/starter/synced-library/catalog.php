<?php

/**
 * Return the versioned starter catalog for user-installed Synced Patterns.
 *
 * The serialized editor export is the source of truth. Do not rebuild these
 * Patterns from PHP block builders: doing so would create a second design
 * representation that cannot round-trip through the editor reliably.
 *
 * @return array<string, array<string, string>>
 */

function wphave_synced_pattern_library_catalog(): array {

	$override = static function( string $name ): string {
		return '"metadata":' . wp_json_encode(
			array(
				'name' => $name,
				'bindings' => array(
					'__default' => array(
						'source' => 'core/pattern-overrides',
					),
				),
			)
		);
	};

	return array(
		'notification-box' => array(
			'title' => __( 'Notification Box', 'wphave' ),
			'description' => __( 'A reusable notice with an overridable title and message.', 'wphave' ),
			'content' => '<!-- wp:wphave/group {"wphave":{"background":{"color":{"base":"var(\u002d\u002dwphave-site-color-palette-pastel-orange)"}},"dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-xs) var(\u002d\u002dwphave-site-padding-xs) var(\u002d\u002dwphave-site-padding-xs) var(\u002d\u002dwphave-site-padding-xs)"}},"frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"},"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"space-between"}},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-xs) var(\u002d\u002dwphave-site-padding-xs) var(\u002d\u002dwphave-site-padding-xs) var(\u002d\u002dwphave-site-padding-xs);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-xs);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-xs);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-xs);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-xs);\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-palette-pastel-orange);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners);\u002d\u002dtxta: none;\u002d\u002dtx-co: #8b6e34","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: center;\u002d\u002dly-halign: space-between;\u002d\u002dly-fl-direction: row","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-xs);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-xs)","classNames":"pa ly ly-fl bg-co bg br txta tx-co","text":{"align":"none","colors":{"text":"#8b6e34"}}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-xs)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-xs)"}} -->
<!-- wp:wphave/paragraph {"wphave":{"settings":{"headingLevel":"h3","textStyle":"headings"},"text":{"typeface":{"size":{"type":"text-s"}}},"classNames":"wphave-fstyle-headings tf-fs tf-fs-text-s"},"content":"Good to know",' . $override( 'title' ) . '} /-->

<!-- wp:wphave/paragraph {"wphave":{"text":{"typeface":{"size":{"type":"text-s"}}},"classNames":"tf-fs tf-fs-text-s"},"content":"Add a concise and helpful notification message.",' . $override( 'message' ) . '} /-->
<!-- /wp:wphave/group -->

<!-- wp:wphave/icon {"wphave":{"styles":"\u002d\u002dwi: 32px;\u002d\u002dicon-inner-width: 100%;\u002d\u002dicon-color: #9d7d3c","settings":{"colors":{"icon":"#9d7d3c"},"width":"100%"},"dimensions":{"width":{"limit":"max","custom":"32px"}},"classNames":"wi"},"icon":{"key":"ph-circle-wavy-warning","svg":"\u003csvg xmlns=\u0022http://www.w3.org/2000/svg\u0022 width=\u002224\u0022 height=\u002224\u0022 viewBox=\u00220 0 256 256\u0022\u003e\u003cpath fill=\u0022currentColor\u0022 d=\u0022M225.9 102.8c-3.8-3.9-7.7-8-9.2-11.5s-1.4-8.7-1.5-14c-.1-9.7-.3-20.8-8-28.5s-18.8-7.9-28.5-8c-5.3-.1-10.7-.2-14-1.5s-7.6-5.4-11.5-9.2C146.3 23.5 138.4 16 128 16s-18.3 7.5-25.2 14.1c-3.9 3.8-8 7.7-11.5 9.2s-8.7 1.4-14 1.5c-9.7.1-20.8.3-28.5 8s-7.9 18.8-8 28.5c-.1 5.3-.2 10.7-1.5 14s-5.4 7.6-9.2 11.5C23.5 109.7 16 117.6 16 128s7.5 18.3 14.1 25.2c3.8 3.9 7.7 8 9.2 11.5s1.4 8.7 1.5 14c.1 9.7.3 20.8 8 28.5s18.8 7.9 28.5 8c5.3.1 10.7.2 14 1.5s7.6 5.4 11.5 9.2c6.9 6.6 14.8 14.1 25.2 14.1s18.3-7.5 25.2-14.1c3.9-3.8 8-7.7 11.5-9.2s8.7-1.4 14-1.5c9.7-.1 20.8-.3 28.5-8s7.9-18.8 8-28.5c.1-5.3.2-10.7 1.5-14s5.4-7.6 9.2-11.5c6.6-6.9 14.1-14.8 14.1-25.2s-7.5-18.3-14.1-25.2Zm-11.6 39.3c-4.8 5-9.7 10.2-12.4 16.5s-2.6 13.1-2.7 19.8s-.2 14.4-3.3 17.5s-10.4 3.2-17.5 3.3s-13.7.2-19.8 2.7s-11.5 7.6-16.5 12.4S132 224 128 224s-9.1-4.9-14.1-9.7s-10.2-9.7-16.5-12.4s-13.1-2.6-19.8-2.7s-14.4-.2-17.5-3.3s-3.2-10.4-3.3-17.5s-.2-13.7-2.7-19.8s-7.6-11.5-12.4-16.5S32 132 32 128s4.9-9.1 9.7-14.1s9.7-10.2 12.4-16.5s2.6-13.1 2.7-19.8s.2-14.4 3.3-17.5s10.4-3.2 17.5-3.3s13.7-.2 19.8-2.7s11.5-7.6 16.5-12.4S124 32 128 32s9.1 4.9 14.1 9.7s10.2 9.7 16.5 12.4s13.1 2.6 19.8 2.7s14.4.2 17.5 3.3s3.2 10.4 3.3 17.5s.2 13.7 2.7 19.8s7.6 11.5 12.4 16.5S224 124 224 128s-4.9 9.1-9.7 14.1ZM120 136V80a8 8 0 0 1 16 0v56a8 8 0 0 1-16 0Zm20 36a12 12 0 1 1-12-12a12 12 0 0 1 12 12Z\u0022/\u003e\u003c/svg\u003e"}} /-->
<!-- /wp:wphave/group -->',
		),
		'badge' => array(
			'title' => __( 'Badge', 'wphave' ),
			'description' => __( 'A compact reusable label for statuses and highlights.', 'wphave' ),
			'content' => '<!-- wp:wphave/group {"wphave":{"background":{"color":{"base":"var(--wphave-site-color-accent-subtle-5)"}},"dimensions":{"spacing":{"padding":"4px 12px 4px 12px"},"width":{"limit":"max","custom":"fit-content"}},"frame":{"corners":"var(--wphave-site-corner-l) var(--wphave-site-corner-l) var(--wphave-site-corner-l) var(--wphave-site-corner-l)","border":{"width":"1px 1px 1px 1px","style":"solid solid solid solid","color":"var(--wphave-site-color-accent) var(--wphave-site-color-accent) var(--wphave-site-color-accent) var(--wphave-site-color-accent)"}},"layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-layout-gap)","gapY":"var(--wphave-site-layout-gap)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"start"}},"styles":"--wi: fit-content;--pa: 4px 12px 4px 12px;--pa-top: 4px;--pa-right: 12px;--pa-bottom: 4px;--pa-left: 12px;--bg-co: var(--wphave-site-color-accent-subtle-5);--bo-width: 1px 1px 1px 1px;--bo-style: solid solid solid solid;--bo-color: var(--wphave-site-color-accent) var(--wphave-site-color-accent) var(--wphave-site-color-accent) var(--wphave-site-color-accent);--br: var(--wphave-site-corner-l) var(--wphave-site-corner-l) var(--wphave-site-corner-l) var(--wphave-site-corner-l)","stylesLayout":"--ly-column-gap: var(--wphave-site-layout-gap);--ly-row-gap: var(--wphave-site-layout-gap);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: start;--ly-fl-direction: row","stylesChild":"--left-spacing-inherit: 12px;--right-spacing-inherit: 12px","classNames":"wi pa ly ly-fl ly-fl-wp bg-co bg bo br"}} -->' . "\n" .
				'<!-- wp:wphave/paragraph {"wphave":{"text":{"typeface":{"size":{"type":"text-xs"}}},"colors":{"text":"var(--wphave-site-color-accent-subtle-10)"}},"classNames":"is-bold tx-co tf-fs tf-fs-text-xs","styles":"--tx-co: var(--wphave-site-color-accent-subtle-10)","settings":{"formats":["bold"]},"content":"New",' . $override( 'label' ) . '} /-->' . "\n" .
				'<!-- /wp:wphave/group -->',
		),
		'call-to-action' => array(
			'title' => __( 'Call to Action', 'wphave' ),
			'description' => __( 'A consistent CTA with overridable copy and button content.', 'wphave' ),
			'content' => '<!-- wp:wphave/group {"wphave":{"background":{"color":{"base":"var(--wphave-site-color-background-contrast-2)"}},"dimensions":{"spacing":{"padding":"var(--wphave-site-padding-m)"}},"frame":{"corners":"var(--wphave-site-corner-s) var(--wphave-site-corner-s) var(--wphave-site-corner-s) var(--wphave-site-corner-s)"},"layout":{"type":"stacked","stacked":{"gap":"var(--wphave-site-gap-size-xs)"}}}} -->' . "\n" .
				'<!-- wp:wphave/heading {"content":"Ready to get started?",' . $override( 'title' ) . '} /-->' . "\n" .
				'<!-- wp:wphave/paragraph {"content":"Explain the next step in one clear sentence.",' . $override( 'description' ) . '} /-->' . "\n" .
				'<!-- wp:wphave/button {"content":"Get started",' . $override( 'action' ) . '} /-->' . "\n" .
				'<!-- /wp:wphave/group -->',
		),
		'stat-card' => array(
			'title' => __( 'Stat Card', 'wphave' ),
			'description' => __( 'A reusable metric card with overridable value and label.', 'wphave' ),
			'content' => '<!-- wp:wphave/group {"wphave":{"background":{"color":{"base":"var(--wphave-site-color-background-contrast-1)"}},"dimensions":{"spacing":{"padding":"var(--wphave-site-padding-s)"}},"frame":{"corners":"var(--wphave-site-corner-s) var(--wphave-site-corner-s) var(--wphave-site-corner-s) var(--wphave-site-corner-s)"},"layout":{"type":"stacked","stacked":{"gap":"var(--wphave-site-gap-size-xs)"}}}} -->' . "\n" .
				'<!-- wp:wphave/heading {"content":"42%",' . $override( 'value' ) . '} /-->' . "\n" .
				'<!-- wp:wphave/paragraph {"content":"Conversion increase",' . $override( 'label' ) . '} /-->' . "\n" .
				'<!-- /wp:wphave/group -->',
		),
	);
}
