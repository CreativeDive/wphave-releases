<?php

/**
 * Function to add starter block patterns, which are available for "wphave-forms".
 */

if (!function_exists('wphave_forms_starter_block_pattern')):
	function wphave_forms_starter_block_pattern() {
		// Form patterns are theme-independent and remain available in compatibility mode.
		// Root forms inherit block.json layout defaults; inner groups own custom layouts.

		if (!function_exists('register_block_pattern')) {
			return;
		}

		$patterns = [];

		$pattern = '<!-- wp:wphave/form {"formId":"form_ce118e45"} -->
<!-- wp:wphave/form-input {"name":"field_9007e270","inputId":"wphave-field-9007e270","label":"Name","required":true} /-->

<!-- wp:wphave/form-input {"name":"field_da19f728","inputId":"wphave-field-da19f728","label":"Email","required":true,"inputType":"email"} /-->

<!-- wp:wphave/form-textarea {"name":"field_d48168db","inputId":"wphave-field-d48168db","label":"Message","required":true} /-->

<!-- wp:wphave/form-submit-button /-->
<!-- /wp:wphave/form -->';

		$patterns[] = [
			'title' => __('Contact Form', 'wphave'),
			'categories' => ['wphave-forms'],
			'keywords' => '',
			'viewportWidth' => 500,
			'content' => $pattern,
		];

		$pattern = '<!-- wp:wphave/form {"formId":"form_ce118e45"} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-fl ly-fl-wp","layout":{"type":"flex","flex":{"gapX":"0rem","gapY":"0rem","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"fill","alignVertical":"end","alignHorizontal":"space-between"}},"stylesLayout":"--ly-column-gap: 0rem;--ly-row-gap: 0rem;--ly-fl-wrap: wrap;--ly-fl-itm: 1 0 0;--ly-valign: end;--ly-halign: space-between;--ly-fl-direction: row"}} -->
<!-- wp:wphave/form-input {"name":"field_b1c26ad6","inputId":"wphave-field-b1c26ad6","label":"Email","required":true,"inputType":"email"} /-->

<!-- wp:wphave/form-submit-button {"wphave":{"frame":{"corners":"0 5px 5px 0"},"styles":"\u002d\u002dwi: fit-content;\u002d\u002dbr: 0 5px 5px 0","classNames":"wi br","dimensions":{"width":{"limit":"max","custom":"fit-content"}}}} /-->
<!-- /wp:wphave/group -->

<!-- wp:wphave/form-checkbox {"name":"field_43b708a9","inputId":"wphave-field-43b708a9","label":"I agree to receive emails and accept the privacy policy.","required":true} /-->
<!-- /wp:wphave/form -->';

		$patterns[] = [
			'title' => __('Subscription Form', 'wphave'),
			'categories' => ['wphave-forms'],
			'keywords' => '',
			'viewportWidth' => 500,
			'content' => $pattern,
		];

		$pattern = '<!-- wp:wphave/form {"formId":"form_ce118e45"} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-gr ly-col-2","layout":{"type":"grid","grid":{"gapX":"var(--wphave-site-layout-gap)","gapY":"var(--wphave-site-layout-gap)","columns":2,"keepColumns":"auto","gridRowHeight":"auto","alignVertical":"stretch","alignHorizontal":"space-between"}},"stylesLayout":"--ly-row-gap: var(--wphave-site-layout-gap);--ly-column-gap: var(--wphave-site-layout-gap);--ly-col: 2;--ly-valign: stretch;--ly-halign: space-between"}} -->
<!-- wp:wphave/form-input {"help":"First","name":"field_70f985a6","inputId":"wphave-field-70f985a6","label":"Name","required":true} /-->

<!-- wp:wphave/form-input {"help":"Last","name":"field_a869a495","inputId":"wphave-field-a869a495","label":"Last Name","hideLabel":true,"required":true} /-->
<!-- /wp:wphave/group -->

<!-- wp:wphave/form-input {"name":"field_65947c08","inputId":"wphave-field-65947c08","label":"Email","required":true,"inputType":"email"} /-->

<!-- wp:wphave/form-radio-group {"name":"field_a50454d3","inputId":"wphave-field-a50454d3","label":"Which department do you have a suggestion for?","required":true,"options":[{"label":"Sales","value":"sales"},{"label":"Customer Support","value":"customer-support"},{"label":"Product Development","value":"product-development"},{"label":"Other","value":"other"}]} /-->

<!-- wp:wphave/form-input {"name":"field_fea40d95","inputId":"wphave-field-fea40d95","label":"Subject","required":true} /-->

<!-- wp:wphave/form-textarea {"name":"field_4145fbf3","inputId":"wphave-field-4145fbf3","label":"Comment or Message","required":true} /-->

<!-- wp:wphave/form-submit-button /-->
<!-- /wp:wphave/form -->';

		$patterns[] = [
			'title' => __('Suggestion Form', 'wphave'),
			'categories' => ['wphave-forms'],
			'keywords' => '',
			'viewportWidth' => 500,
			'content' => $pattern,
		];

		// Register the form patterns.

		$i = 1;

		foreach ($patterns as $pattern => $data) {
			$title = isset($data['title']) ? $data['title'] : '';
			$categories = isset($data['categories']) ? $data['categories'] : '';
			$keywords = isset($data['keywords']) ? $data['keywords'] : '';
			$content = wphave_normalize_registered_pattern_content(
				isset($data['content']) ? $data['content'] : '',
			);
			$viewport_width = isset($data['viewportWidth']) ? $data['viewportWidth'] : '';

			register_block_pattern('wphave/wphave-forms-pattern-' . $i, [
				'title' => $title,
				'categories' => $categories,
				'keywords' => $keywords,
				'viewportWidth' => $viewport_width ?: wphave_block_pattern_width(),
				'content' => $content,
				'postTypes' => ['wphave-forms'],
				'blockTypes' => ['core/post-content'],
			]);

			$i++;
		}
	}
endif;

add_action('init', 'wphave_forms_starter_block_pattern', 22);
