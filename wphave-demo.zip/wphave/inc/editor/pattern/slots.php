<?php

/**
 * Server-side helpers for editor-authored block patterns.
 */

if (!function_exists('wphave_pattern_slot_value')):
	function wphave_pattern_slot_value(
		array $slots,
		string $slot,
		string $fallback = '',
		string $text_type = '',
	) {
		$slot = sanitize_text_field($slot);
		$parts = array_filter(explode('.', $slot), function ($part) {
			return $part !== '';
		});
		$value = $slots;

		foreach ($parts as $part) {
			if (is_array($value) && array_key_exists($part, $value)) {
				$value = $value[$part];
				continue;
			}

			return wphave_pattern_slot_fallback($slot, $fallback, $text_type);
		}

		if (is_array($value)) {
			return wphave_pattern_slot_fallback($slot, $fallback, $text_type);
		}

		$value = trim((string) $value);

		return $value === '' ? wphave_pattern_slot_fallback($slot, $fallback, $text_type) : $value;
	}
endif;

if (!function_exists('wphave_pattern_slot_fallback')):
	/**
	 * Pattern slot fallback.
	 *
	 * @param string $slot Slot.
	 * @param string $fallback Fallback.
	 * @param string $text_type Text type.
	 */

	function wphave_pattern_slot_fallback(
		string $slot,
		string $fallback = '',
		string $text_type = '',
	) {
		if (function_exists('wphave_pattern_text_variant')) {
			$text_type = sanitize_key($text_type);
			if ($text_type) {
				return wphave_pattern_slot_has_index($slot)
					? wphave_pattern_text_variant(
						$text_type,
						wphave_pattern_slot_index($slot),
						$fallback,
					)
					: wphave_pattern_text($text_type, $fallback);
			}

			if ($slot === 'eyebrow' || str_ends_with($slot, '.eyebrow')) {
				return wphave_pattern_slot_has_index($slot)
					? wphave_pattern_text_variant(
						'eyebrow',
						wphave_pattern_slot_index($slot),
						$fallback,
					)
					: wphave_pattern_text('eyebrow', $fallback);
			}

			if (str_starts_with($slot, 'items.') && str_ends_with($slot, '.title')) {
				return wphave_pattern_text_variant(
					'proof-title',
					wphave_pattern_slot_index($slot),
					$fallback,
				);
			}

			if (str_starts_with($slot, 'items.') && str_ends_with($slot, '.text')) {
				return wphave_pattern_text_variant(
					'proof-text',
					wphave_pattern_slot_index($slot),
					$fallback,
				);
			}

			if (str_starts_with($slot, 'stats.') && str_ends_with($slot, '.value')) {
				return wphave_pattern_text_variant(
					'stat',
					wphave_pattern_slot_index($slot),
					$fallback,
				);
			}

			if (str_starts_with($slot, 'stats.') && str_ends_with($slot, '.label')) {
				return wphave_pattern_text_variant(
					'stat-label',
					wphave_pattern_slot_index($slot),
					$fallback,
				);
			}

			if (str_starts_with($slot, 'stats.') && str_ends_with($slot, '.suffix')) {
				return wphave_pattern_text_variant(
					'stat-suffix',
					wphave_pattern_slot_index($slot),
					$fallback,
				);
			}

			if (str_starts_with($slot, 'stats.') && str_ends_with($slot, '.text')) {
				return wphave_pattern_text_variant(
					'proof-text',
					wphave_pattern_slot_index($slot),
					$fallback,
				);
			}

			if (str_starts_with($slot, 'steps.') && str_ends_with($slot, '.title')) {
				return wphave_pattern_text_variant(
					'step-title',
					wphave_pattern_slot_index($slot),
					$fallback,
				);
			}

			if (str_starts_with($slot, 'steps.') && str_ends_with($slot, '.text')) {
				return wphave_pattern_text_variant(
					'step-text',
					wphave_pattern_slot_index($slot),
					$fallback,
				);
			}

			if (str_starts_with($slot, 'testimonials.') && str_ends_with($slot, '.quote')) {
				return wphave_pattern_text_variant(
					'quote',
					wphave_pattern_slot_index($slot),
					$fallback,
				);
			}

			if (
				str_starts_with($slot, 'testimonials.') &&
				(str_ends_with($slot, '.cite') || str_ends_with($slot, '.role'))
			) {
				return wphave_pattern_text_variant(
					'quote-cite',
					wphave_pattern_slot_index($slot),
					$fallback,
				);
			}

			if ($slot === 'heading' || str_ends_with($slot, '.title')) {
				return wphave_pattern_slot_has_index($slot)
					? wphave_pattern_text_variant(
						'heading',
						wphave_pattern_slot_index($slot),
						$fallback,
					)
					: wphave_pattern_text('heading', $fallback);
			}

			if (
				$slot === 'body' ||
				$slot === 'lead' ||
				$slot === 'text' ||
				str_ends_with($slot, '.text')
			) {
				return wphave_pattern_slot_has_index($slot)
					? wphave_pattern_text_variant(
						'text',
						wphave_pattern_slot_index($slot),
						$fallback,
					)
					: wphave_pattern_text('text', $fallback);
			}

			if (str_starts_with($slot, 'actions.') && str_ends_with($slot, '.label')) {
				return wphave_pattern_slot_rotating_text('button', $fallback);
			}
		}

		return $fallback;
	}
endif;

if (!function_exists('wphave_pattern_slot_rotating_text')):
	/**
	 * Pattern slot rotating text.
	 *
	 * @param string $type Type.
	 * @param string $fallback Fallback.
	 * @return string Pattern slot rotating text.
	 */

	function wphave_pattern_slot_rotating_text(string $type, string $fallback = ''): string {
		static $offsets = [];
		static $counters = [];

		if (!function_exists('wphave_pattern_text_variants')) {
			return $fallback;
		}

		// PERFORMANCE: A rotating slot needs one text group, not the full catalog.
		// Passing its type avoids unrelated translations; offsets and counters below
		// retain their existing lifecycle, and gettext still runs on every lookup.
		$variants = wphave_pattern_text_variants($type);
		$suggestions = array_values($variants[$type] ?? []);

		if (empty($suggestions)) {
			return $fallback;
		}

		if (!isset($offsets[$type])) {
			$offsets[$type] = wp_rand(0, count($suggestions) - 1);
			$counters[$type] = 0;
		}

		$index = ($offsets[$type] + $counters[$type]) % count($suggestions);
		$counters[$type]++;

		return $suggestions[$index];
	}
endif;

if (!function_exists('wphave_pattern_slot_has_index')):
	/**
	 * Pattern slot has index.
	 *
	 * @param string $slot Slot.
	 * @return bool Pattern slot has index.
	 */

	function wphave_pattern_slot_has_index(string $slot): bool {
		return (bool) preg_match('/\.(\d+)\./', $slot);
	}
endif;

if (!function_exists('wphave_pattern_slot_index')):
	/**
	 * Pattern slot index.
	 *
	 * @param string $slot Slot.
	 * @return int Pattern slot index.
	 */

	function wphave_pattern_slot_index(string $slot): int {
		if (preg_match('/\.(\d+)\./', $slot, $matches)) {
			return absint($matches[1]);
		}

		return 0;
	}
endif;

if (!function_exists('wphave_pattern_slot_block')):
	/**
	 * Pattern slot block.
	 *
	 * @param string $name Name.
	 * @param array $attrs Attrs.
	 * @param string $inner Inner.
	 * @return string Pattern slot block.
	 */

	function wphave_pattern_slot_block(
		string $name,
		array $attrs = [],
		string $inner = '',
	): string {
		$block_name = str_contains($name, '/') ? $name : 'wphave/' . $name;
		$attrs = array_filter($attrs, function ($value) {
			return $value !== null && $value !== [];
		});
		$serialized_attrs = !empty($attrs)
			? ' ' . wp_json_encode($attrs, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
			: '';

		if ($inner === '') {
			return '<!-- wp:' . $block_name . $serialized_attrs . ' /-->';
		}

		return '<!-- wp:' .
			$block_name .
			$serialized_attrs .
			' -->' .
			"\n" .
			trim($inner) .
			"\n" .
			'<!-- /wp:' .
			$block_name .
			' -->';
	}
endif;

if (!function_exists('wphave_pattern_slot_type')):
	/**
	 * Pattern slot type.
	 *
	 * @param string $slot Slot.
	 * @return string Pattern slot type.
	 */

	function wphave_pattern_slot_type(string $slot): string {
		if ($slot === 'eyebrow' || str_ends_with($slot, '.eyebrow')) {
			return 'badge';
		}

		if ($slot === 'heading' || str_ends_with($slot, '.title')) {
			return 'heading';
		}

		if (str_starts_with($slot, 'actions.') && str_ends_with($slot, '.label')) {
			return 'button';
		}

		if ($slot === 'icon' || str_ends_with($slot, '.icon')) {
			return 'icon';
		}

		if ($slot === 'image' || str_ends_with($slot, '.image')) {
			return 'image';
		}

		if ($slot === 'spacer' || str_ends_with($slot, '.spacer')) {
			return 'spacer';
		}

		if ($slot === 'step' || str_ends_with($slot, '.step')) {
			return 'step';
		}

		if (str_starts_with($slot, 'stats.') && str_ends_with($slot, '.value')) {
			return 'paragraph';
		}

		return 'paragraph';
	}
endif;

if (!function_exists('wphave_pattern_slot_sequence_id')):
	/**
	 * Pattern slot sequence ID.
	 *
	 * @param string $group Group.
	 * @return string Pattern slot sequence ID.
	 */

	function wphave_pattern_slot_sequence_id(string $group = 'steps'): string {
		static $sequence_ids = [];

		$group = sanitize_key($group ?: 'steps');

		if (!isset($sequence_ids[$group])) {
			$sequence_ids[$group] = $group . '-' . wp_rand(1000, 9999) . '-' . wp_rand(1000, 9999);
		}

		return $sequence_ids[$group];
	}
endif;

if (!function_exists('wphave_pattern_slot')):
	/**
	 * Pattern slot.
	 *
	 * @param string $slot Slot.
	 * @param string $type Type.
	 * @param array $args Function arguments.
	 * @param array $slots Slots.
	 * @return string Pattern slot.
	 */

	function wphave_pattern_slot(
		string $slot,
		$type = null,
		array $args = [],
		array $slots = [],
	): string {
		if (is_array($type)) {
			if (
				empty($args) &&
				array_intersect(array_keys($type), [
					'eyebrow',
					'heading',
					'body',
					'lead',
					'text',
					'items',
					'actions',
				])
			) {
				$slots = $type;
				$args = [];
			} else {
				$slots = $args;
				$args = $type;
			}

			$type = null;
		}

		$fallback = sanitize_text_field((string) ($args['fallback'] ?? ''));
		$text_type = sanitize_key((string) ($args['textType'] ?? ''));
		$content = wphave_pattern_slot_value($slots, $slot, $fallback, $text_type);
		$attrs = is_array($args['attrs'] ?? null) ? $args['attrs'] : [];
		$type = sanitize_key((string) ($type ?: wphave_pattern_slot_type($slot)));

		if (
			str_starts_with($slot, 'stats.') &&
			str_ends_with($slot, '.suffix') &&
			$content === ''
		) {
			return '';
		}

		if ($type === 'badge') {
			$badge_attrs = array_replace_recursive(
				[
					'wphave' => [
						'dimensions' => [
							'overflow' => 'clip',
							'spacing' => [
								'padding' =>
									'var(--wphave-site-padding-xxs) var(--wphave-site-padding-xs) var(--wphave-site-padding-xxs) var(--wphave-site-padding-xs)',
							],
							'width' => [
								'custom' => 'fit-content',
							],
						],
						'frame' => [
							'corners' =>
								'var(--wphave-site-corner-xs) var(--wphave-site-corner-xs) var(--wphave-site-corner-xs) var(--wphave-site-corner-xs)',
						],
						'layout' => [
							'stacked' => [
								'gap' => '0rem',
							],
						],
						'background' => [
							'color' => [
								'base' => 'var(--wphave-site-color-background-contrast-2)',
							],
						],
						'styles' =>
							'--wi: fit-content;--pa: var(--wphave-site-padding-xxs) var(--wphave-site-padding-xs) var(--wphave-site-padding-xxs) var(--wphave-site-padding-xs);--pa-top: var(--wphave-site-padding-xxs);--pa-right: var(--wphave-site-padding-xs);--pa-bottom: var(--wphave-site-padding-xxs);--pa-left: var(--wphave-site-padding-xs);--ofw: clip;--bg-co: var(--wphave-site-color-background-contrast-2);--br: var(--wphave-site-corner-xs) var(--wphave-site-corner-xs) var(--wphave-site-corner-xs) var(--wphave-site-corner-xs)',
						'classNames' => 'wi pa ofw bg-co bg br',
					],
				],
				$attrs,
			);

			$badge_label = wphave_pattern_slot_block('paragraph', [
				'wphave' => [
					'settings' => [
						'formats' => ['bold', 'uppercase'],
					],
					'text' => [
						'typeface' => [
							'size' => [
								'type' => 'text-xs',
							],
						],
					],
					'classNames' => 'is-bold is-uppercase tf-fs tf-fs-text-xs',
				],
				'content' => sanitize_text_field($content),
			]);

			return wphave_pattern_slot_block('group', $badge_attrs, $badge_label);
		}

		if ($type === 'heading') {
			$level = sanitize_key((string) ($args['level'] ?? 'h2'));
			$size = sanitize_key((string) ($args['size'] ?? 'title-s'));

			return wphave_pattern_slot_block(
				'heading',
				array_replace_recursive(
					[
						'wphave' => [
							'settings' => ['headingLevel' => $level],
							'text' => [
								'typeface' => [
									'size' => ['type' => $size],
								],
							],
							'classNames' => 'tf-fs tf-fs-' . $size,
						],
						'content' => sanitize_text_field($content),
					],
					$attrs,
				),
			);
		}

		if ($type === 'button') {
			return wphave_pattern_slot_block(
				'button',
				array_merge($attrs, [
					'content' => sanitize_text_field($content),
				]),
			);
		}

		if ($type === 'counter') {
			$number = preg_replace('/[^0-9.\-]/', '', $content);
			$number = $number === '' || $number === '-' || $number === '.' ? 0 : $number + 0;
			$counter_attrs = array_replace_recursive(
				[
					'wphave' => [
						'text' => [
							'typeface' => [
								'size' => [
									'type' => 'title-m',
								],
							],
						],
						'classNames' => 'is-bold tf-fs tf-fs-title-m',
						'settings' => [
							'formats' => ['bold'],
							'start' => 0,
						],
					],
					'number' => $number,
				],
				$attrs,
			);

			return wphave_pattern_slot_block('counter', $counter_attrs);
		}

		if ($type === 'icon') {
			$icon_attrs = array_replace_recursive(
				[
					'wphave' => [
						'dimensions' => [
							'width' => [
								'custom' => 'fit-content',
							],
						],
						'styles' => '--wi: fit-content',
						'classNames' => 'wi',
					],
					'icon' => [
						'key' => 'fa6-regular-circle-check',
						'svg' =>
							'<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 512 512"><path fill="currentColor" d="M243.8 339.8c-10.9 10.9-28.7 10.9-39.6 0l-64-64c-10.9-10.9-10.9-28.7 0-39.6c10.9-10.9 28.7-10.9 39.6 0l44.2 44.2l108.2-108.2c10.9-10.9 28.7-10.9 39.6 0c10.9 10.9 10.9 28.7 0 39.6l-128 128zM512 256c0 141.4-114.6 256-256 256S0 397.4 0 256S114.6 0 256 0s256 114.6 256 256zM256 48C141.1 48 48 141.1 48 256s93.1 208 208 208s208-93.1 208-208S370.9 48 256 48z"/></svg>',
					],
				],
				$attrs,
			);

			return wphave_pattern_slot_block('icon', $icon_attrs);
		}

		if ($type === 'image') {
			$ratio = sanitize_text_field((string) ($args['ratio'] ?? '4/3'));
			$image_attrs = array_replace_recursive(
				[
					'wphave' => [
						'dimensions' => [
							'aspectRatio' => [
								'ratio' => $ratio,
							],
							'overflow' => 'clip',
						],
						'styles' =>
							'--asrt: ' .
							$ratio .
							';--ofw: clip;--br: var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners);--object-position: center',
						'classNames' => 'asrt ofw br',
						'frame' => [
							'corners' =>
								'var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners)',
						],
					],
				],
				$attrs,
			);

			if (is_numeric($content)) {
				$image_attrs['image'] = absint($content);
			} elseif (filter_var($content, FILTER_VALIDATE_URL)) {
				$image_attrs['url'] = esc_url_raw($content);
			}

			return wphave_pattern_slot_block('image', $image_attrs);
		}

		if ($type === 'spacer') {
			$ratio = sanitize_text_field((string) ($args['ratio'] ?? '75/1'));
			$spacer_attrs = array_replace_recursive(
				[
					'wphave' => [
						'settings' => [
							'aspectRatio' => $ratio,
						],
						'styles' => '--aspect-ratio: ' . $ratio,
					],
				],
				$attrs,
			);

			return wphave_pattern_slot_block('spacer', $spacer_attrs);
		}

		if ($type === 'step') {
			$sequence_id = sanitize_key(
				(string) ($args['sequenceId'] ?? ($args['sequence_id'] ?? '')),
			);
			$sequence_group = sanitize_key((string) ($args['sequenceGroup'] ?? 'steps'));
			$step_attrs = array_replace_recursive(
				[
					'sequenceId' =>
						$sequence_id ?: wphave_pattern_slot_sequence_id($sequence_group),
					'wphave' => [
						'settings' => [
							'formats' => ['bold'],
							'leadingZero' => true,
						],
						'text' => [
							'typeface' => [
								'size' => [
									'type' => 'default',
								],
							],
						],
						'classNames' => 'is-bold tf-fs',
					],
				],
				$attrs,
			);
			$step_attrs['sequenceId'] =
				$sequence_id ?: wphave_pattern_slot_sequence_id($sequence_group);

			return wphave_pattern_slot_block('step', $step_attrs);
		}

		$size = sanitize_key((string) ($args['size'] ?? ''));
		if ($size) {
			$attrs = array_merge(
				[
					'wphave' => [
						'text' => [
							'typeface' => [
								'size' => ['type' => $size],
							],
						],
						'classNames' => 'tf-fs tf-fs-' . $size,
					],
				],
				$attrs,
			);
		}

		return wphave_pattern_slot_block(
			'paragraph',
			array_merge($attrs, [
				'content' => sanitize_text_field($content),
			]),
		);
	}
endif;

/*

<!-- wp:wphave/heading {"wphave":{"settings":{"headingLevel":"h1"},"text":{"typeface":{"size":{"type":"title-xl"}}},"classNames":"tf-fs tf-fs-title-xl"},"content":"Create layouts that stay consistent"} /-->

<!-- wp:wphave/heading {"wphave":{"settings":{"headingLevel":"h1"},"text":{"typeface":{"size":{"type":"title-xl"}}}},"content":"Create layouts that stay consistent"} /-->

*/
