<?php

/**
 * Return reusable text suggestions grouped by use case.
 *
 * @param string|null $type Optional group; null returns the complete catalog.
 * @return array
 */

if (!function_exists('wphave_pattern_text_variants')):
	function wphave_pattern_text_variants($type = null) {
		// PERFORMANCE: A slot requests one group, but building the whole catalog
		// translated all 123 suggestions on every call (366 calls during bootstrap).
		// Cache only factories, never translations: each selected group still runs
		// gettext under the current locale and filters. No argument preserves the
		// complete ordered catalog; unknown groups preserve the empty fallback.
		// Measured 2026-09-10: median of five 1,000-heading batches fell from
		// 92.23 ms to 7.88 ms; this is a helper benchmark, not dashboard latency.
		// Evidence and regression coverage: docs/architecture/workspace-performance-audit.md.
		static $groups = null;
		$groups ??= [
			'heading' => static fn() => [
				__('Build pages faster with reusable sections', 'wphave'),
				__('A smarter way to organize content', 'wphave'),
				__('Designed for modern websites', 'wphave'),
				__('Create layouts that stay consistent', 'wphave'),
				__('Everything your next section needs', 'wphave'),
				__('Medium length hero heading goes here', 'wphave'),
				__('Long heading is what you see here in this hero section', 'wphave'),
				__('A strong editorial headline with room to breathe', 'wphave'),
				__('A clear headline for a focused page introduction', 'wphave'),
				__('A cinematic hero headline goes here', 'wphave'),
				__('A confident statement that sets up the whole page', 'wphave'),
			],
			'full-width-heading' => static fn() => [
				__('Scale faster', 'wphave'),
				__('Work smarter', 'wphave'),
				__('Build better', 'wphave'),
				__('Stay focused', 'wphave'),
				__('Move forward', 'wphave'),
			],
			'short-heading' => static fn() => [
				__('Scale faster', 'wphave'),
				__('Work smarter', 'wphave'),
				__('Build better', 'wphave'),
				__('Stay focused', 'wphave'),
				__('Move forward', 'wphave'),
				__('Launch cleaner', 'wphave'),
				__('Ship smarter', 'wphave'),
				__('Grow with clarity', 'wphave'),
			],
			'text' => static fn() => [
				__(
					'Combine polished visuals, clear messaging, and focused actions in one reusable section.',
					'wphave',
				),
				__(
					'Create flexible sections with reusable parts that keep every layout consistent.',
					'wphave',
				),
				__(
					'Use modular content pieces to move faster without rebuilding the same structure again.',
					'wphave',
				),
				__(
					'Keep your layout system clean, flexible, and ready for future pattern variations.',
					'wphave',
				),
				__(
					'Start with a structured foundation and adapt the details for every page context.',
					'wphave',
				),
				__(
					'Supporting copy explains the offer, audience and outcome with enough detail for a confident first decision.',
					'wphave',
				),
				__(
					'A concise introduction explains the value and gives visitors a reason to continue.',
					'wphave',
				),
				__(
					'A direct statement explains why this matters and what visitors can do next.',
					'wphave',
				),
				__(
					'Use this hero when the page needs a more mature, story-led introduction with a clear next step.',
					'wphave',
				),
				__(
					'A restrained supporting paragraph keeps the message direct and gives the page a calm rhythm.',
					'wphave',
				),
				__(
					'This layout is intended for strong visual openings where the message should feel immediate and immersive.',
					'wphave',
				),
				__(
					'Use this hero when the content should lead with measurable credibility and a direct narrative.',
					'wphave',
				),
			],
			'text-columns' => static fn() => [
				__(
					'Use this paragraph to create a balanced text rhythm across two columns. It gives supporting content enough length to show how longer copy behaves inside the layout while keeping the component simple and reusable for different sections.',
					'wphave',
				),
				__(
					'Longer editorial content becomes easier to scan when it is distributed across multiple columns. This component keeps the structure minimal, so it can be dropped into existing patterns without adding wrappers or additional layout decisions.',
					'wphave',
				),
				__(
					'A text column component is useful for compact introductions, service explanations, and descriptive content areas. The paragraph stays flexible while the column setting makes the visual behavior clear directly inside the pattern preview.',
					'wphave',
				),
			],
			'quote' => static fn() => [
				__(
					'The system helped us move from scattered sections to a reusable structure that feels consistent on every page.',
					'wphave',
				),
				__(
					'Reusable components made it much easier to explore different layouts without losing the clarity of the content.',
					'wphave',
				),
				__(
					'The strongest patterns are the ones that keep the message focused while leaving enough flexibility for every context.',
					'wphave',
				),
			],
			'quote-cite' => static fn() => [
				__('Product Team', 'wphave'),
				__('Design Lead', 'wphave'),
				__('Editorial Team', 'wphave'),
			],
			'marquee' => static fn() => [
				__(
					'New templates available · Faster page building · Reusable design components ·',
					'wphave',
				),
				__('Fresh updates · Flexible layouts · Consistent content systems ·', 'wphave'),
				__(
					'Build sections faster · Keep every page consistent · Move from idea to layout ·',
					'wphave',
				),
			],
			'button' => static fn() => [
				__('Learn more', 'wphave'),
				__('Explore', 'wphave'),
				__('Get started', 'wphave'),
				__('View details', 'wphave'),
				__('See feature', 'wphave'),
				__('Compare options', 'wphave'),
				__('Start now', 'wphave'),
				__('Book a call', 'wphave'),
				__('Read the story', 'wphave'),
				__('Contact', 'wphave'),
				__('See more', 'wphave'),
			],
			'eyebrow' => static fn() => [
				__('Overview', 'wphave'),
				__('Highlights', 'wphave'),
				__('Why it matters', 'wphave'),
				__('For your workflow', 'wphave'),
				__('Built to scale', 'wphave'),
				__('New offer', 'wphave'),
				__('Featured', 'wphave'),
				__('Premium', 'wphave'),
				__('Perspective', 'wphave'),
				__('Now open', 'wphave'),
			],
			'badge' => static fn() => [
				__('New', 'wphave'),
				__('Featured', 'wphave'),
				__('Popular', 'wphave'),
				__('Updated', 'wphave'),
				__('Available now', 'wphave'),
				__('Limited offer', 'wphave'),
			],
			'stat' => static fn() => [
				__('98%', 'wphave'),
				__('24k', 'wphave'),
				__('4.9', 'wphave'),
				__('12+', 'wphave'),
				__('3x', 'wphave'),
			],
			'stat-number' => static fn() => [
				__('98', 'wphave'),
				__('24', 'wphave'),
				__('4.9', 'wphave'),
				__('12', 'wphave'),
				__('3', 'wphave'),
			],
			'stat-suffix' => static fn() => [
				__('%', 'wphave'),
				__('k', 'wphave'),
				__('', 'wphave'),
				__('+', 'wphave'),
				__('x', 'wphave'),
			],
			'stat-label' => static fn() => [
				__('Faster production', 'wphave'),
				__('Active projects', 'wphave'),
				__('Average rating', 'wphave'),
				__('Reusable sections', 'wphave'),
				__('Improved workflow', 'wphave'),
			],
			'step-title' => static fn() => [
				__('Plan the structure', 'wphave'),
				__('Shape the message', 'wphave'),
				__('Build the sections', 'wphave'),
				__('Review the result', 'wphave'),
				__('Launch with confidence', 'wphave'),
			],
			'step-text' => static fn() => [
				__(
					'Start with the main goal, audience, and the pages that need to support the visitor journey.',
					'wphave',
				),
				__(
					'Turn the raw idea into clear section copy, priorities, and calls to action.',
					'wphave',
				),
				__(
					'Assemble reusable layout sections that keep the page structured without making it feel repetitive.',
					'wphave',
				),
				__(
					'Check the flow, remove weak spots, and refine the details before the page is applied.',
					'wphave',
				),
				__(
					'Move from planning into a complete page structure that can be edited further in WordPress.',
					'wphave',
				),
			],
			'proof-title' => static fn() => [
				__('First proof point', 'wphave'),
				__('Second proof point', 'wphave'),
				__('Clarity', 'wphave'),
				__('Momentum', 'wphave'),
				__('Trust', 'wphave'),
				__('Useful note', 'wphave'),
				__('Second note', 'wphave'),
			],
			'proof-text' => static fn() => [
				__('Short supporting detail for the first proof point.', 'wphave'),
				__('Short supporting detail for the second proof point.', 'wphave'),
				__('Short supporting proof or feature explanation.', 'wphave'),
				__('A highlighted item gives the layout a stronger visual rhythm.', 'wphave'),
				__('A final support point closes the hero argument.', 'wphave'),
				__('Short contextual support for visitors.', 'wphave'),
				__('Another detail can answer a common objection.', 'wphave'),
				__('First metric or proof point.', 'wphave'),
				__('Second metric or proof point.', 'wphave'),
				__('Third metric or proof point.', 'wphave'),
				__('Fourth metric or proof point.', 'wphave'),
			],
		];

		if (null !== $type) {
			return isset($groups[$type]) ? [$type => $groups[$type]()] : [];
		}

		$variants = [];
		foreach ($groups as $group => $resolve) {
			$variants[$group] = $resolve();
		}

		return $variants;
	}
endif;

/**
 * Return a deterministic text suggestion for a use case.
 *
 * @param string $type The suggestion use case.
 * @param int $index The suggestion offset.
 * @param string $fallback Optional fallback text.
 * @return string
 */

if (!function_exists('wphave_pattern_text_variant')):
	function wphave_pattern_text_variant($type, $index = 0, $fallback = '') {
		// PERFORMANCE: Resolve this group only; index wrapping and fallback below
		// still operate on the same ordered suggestions as the full catalog.
		$variants = wphave_pattern_text_variants($type);
		$suggestions = array_values($variants[$type] ?? []);

		if (empty($suggestions)) {
			return $fallback;
		}

		$index = absint($index);

		return $suggestions[$index % count($suggestions)];
	}
endif;

/**
 * Return one or more random text suggestions for a use case.
 *
 * @param string $type The suggestion use case.
 * @param int $count Number of suggestions to return.
 * @return array
 */

if (!function_exists('wphave_pattern_text_suggestions')):
	function wphave_pattern_text_suggestions($type, $count = 1) {
		// PERFORMANCE: Translate only the requested group. Keep random selection
		// outside the factories so each call retains its existing choice behavior.
		$variants = wphave_pattern_text_variants($type);
		$suggestions = $variants[$type] ?? [];
		$count = max(1, (int) $count);

		if (empty($suggestions)) {
			return [];
		}

		$selected = [];

		while (count($selected) < $count) {
			$remaining = array_values(array_diff($suggestions, $selected));

			if (empty($remaining)) {
				$remaining = $suggestions;
			}

			$selected[] = $remaining[wp_rand(0, count($remaining) - 1)];
		}

		return $selected;
	}
endif;

/**
 * Return a random text suggestion for a use case.
 *
 * @param string $type The suggestion use case.
 * @param string $fallback Optional fallback text.
 * @return string
 */

if (!function_exists('wphave_pattern_text')):
	function wphave_pattern_text($type, $fallback = '') {
		$suggestions = wphave_pattern_text_suggestions($type);

		return $suggestions[0] ?? $fallback;
	}
endif;
