<?php

/**
 * Functions to group similar wphave block patterns.
 */

if ( ! function_exists( 'wphave_block_pattern_collection_coming_soon' ) ) :

	function wphave_block_pattern_collection_coming_soon( $args = array() ) {

        $content_width = isset( $args['width'] ) ? (int) $args['width'] : 1300;

        $patterns = array();

        $patterns[] = array(
            'tags' => array('coming-soon'),
            'title' => '',
            'viewportWidth' => $content_width,
            'content' => ''
        );

        return $patterns;

	}

endif;