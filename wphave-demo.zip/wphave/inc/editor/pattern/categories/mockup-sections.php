<?php

/**
 * Functions to group mockup section block patterns.
 */

if ( ! function_exists( 'wphave_block_pattern_collection_mockup_sections' ) ) :

	function wphave_block_pattern_collection_mockup_sections( $args = array() ) {

        $content_width = isset( $args['width'] ) ? (int) $args['width'] : 1300;
        $slots = is_array( $args['slots'] ?? null ) ? $args['slots'] : array();

        $patterns = array();

        $patterns[] = array(
            'key' => 'mockup-section-1',
            'tags' => array('mockup-sections'),
            'title' => __( 'Mockup Section Centered Browser Frame', 'wphave' ),
            'keywords' => array('mockup', 'browser', 'product', 'software', 'preview'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('section', 'content'),
                'layout' => array('centered', 'stacked'),
                'visual' => array('device-preview'),
                'content' => array('heading', 'body', 'actions', 'media'),
                'intent' => array('product-showcase'),
                'treatment' => array('soft-surface', 'visual-impact'),
                'description' => 'A centered product or software mockup section with headline, supporting copy, actions, and a wide browser frame preview.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-full wi-in pa ofw ly ly-stk ly-co-pos bg-co bg","dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-3xl) var(\u002d\u002dwphave-site-spacing) 0 var(\u002d\u002dwphave-site-spacing)"},"innerWidth":{"custom":"100%"},"overflow":"clip"},"features":{"size":"full"},"styles":"\u002d\u002dwi-in: 100%;\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-3xl) var(\u002d\u002dwphave-site-spacing) 0 var(\u002d\u002dwphave-site-spacing);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-3xl);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-spacing);\u002d\u002dpa-bottom: 0;\u002d\u002dpa-left: var(\u002d\u002dwphave-site-spacing);\u002d\u002dofw: clip;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background-contrast-1)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-spacing);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-spacing)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background-contrast-1)"}},"layout":{"stacked":{"contentPosition":"center"},"type":"stacked"}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"wi ly ly-stk ly-co-pos txta wi-t","dimensions":{"width":{"limit":"max","custom":"768px"}},"styles":"\u002d\u002dwi: 768px;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center;\u002d\u002dtxta: center;\u002d\u002dwi-t: 85%","text":{"align":"center"},"layout":{"stacked":{"contentPosition":"center"},"type":"stacked"},"tablet":{"dimensions":{"width":{"custom":"85%"}}}}} -->
' . wphave_pattern_slot( 'heading', array( 'level' => 'h2', 'size' => 'title-l' ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-m' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"\u002d\u002dwi: fit-content","classNames":"wi ly ly-fl","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-m)","gapY":"var(\u002d\u002dwphave-site-gap-size-m)","flexWrap":"no-wrap","flexDirection":"row","flexItemSizing":"auto"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-direction: row;\u002d\u002dly-fl-itm: 0 1 auto"}} -->
' . wphave_pattern_slot( 'actions.0.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'size' => '0' ), 'styles' => '\u002d\u002dbtn-size-scale: 0' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'actions.1.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'variant' => 'secondary', 'size' => '0' ), 'styles' => '\u002d\u002dbtn-size-scale: 0' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/spacer {"wphave":{"settings":{"aspectRatio":"75/1"},"styles":"\u002d\u002daspect-ratio: 75/1"}} /-->

<!-- wp:wphave/browser-frame {"wphave":{"classNames":"bsz-content","settings":{"frame":false,"size":"large","tabs":false},"features":{"size":"content"}},"url":"https://wordpress.org"} -->
' . wphave_pattern_slot( 'image', 'image', array( 'ratio' => '21/9', 'attrs' => array( 'wphave' => array( 'styles' => '\u002d\u002dasrt: 21/9;\u002d\u002dofw: clip;\u002d\u002dbr: 0px 0px 0px 0px;\u002d\u002dobject-position: center', 'dimensions' => array( 'aspectRatio' => array( 'ratio' => '21/9' ), 'overflow' => 'clip' ), 'frame' => array( 'corners' => '0px 0px 0px 0px' ), 'classNames' => 'asrt ofw br' ) ) ), $slots ) . '
<!-- /wp:wphave/browser-frame -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'mockup-section-2',
            'tags' => array('mockup-sections'),
            'title' => __( 'Mockup Section Split Device', 'wphave' ),
            'keywords' => array('mockup', 'device', 'product', 'software', 'preview'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('section', 'content'),
                'layout' => array('split', 'text-media'),
                'visual' => array('device-preview'),
                'content' => array('heading', 'body', 'actions', 'media'),
                'intent' => array('product-showcase'),
                'treatment' => array('unframed', 'visual-impact'),
                'description' => 'A split mockup section with eyebrow, headline, supporting copy, actions, and a large device preview.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"wi-in pa ofw ly ly-gr ly-col-2","dimensions":{"overflow":"clip","innerWidth":{"limit":"max","custom":"100%"},"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-3xl) 0 var(\u002d\u002dwphave-site-padding-3xl) 0"}},"styles":"\u002d\u002dwi-in: 100%;\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-3xl) 0 var(\u002d\u002dwphave-site-padding-3xl) 0;\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-3xl);\u002d\u002dpa-right: 0;\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-3xl);\u002d\u002dpa-left: 0;\u002d\u002dofw: clip","layout":{"type":"grid","grid":{"gapX":"var(\u002d\u002dwphave-site-gap-size-4xl)","gapY":"var(\u002d\u002dwphave-site-gap-size-3xl)","columns":2,"keepColumns":"auto","gridRowHeight":"auto","alignVertical":"stretch","alignHorizontal":"space-between"}},"stylesLayout":"\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-col: 2;\u002d\u002dly-valign: stretch;\u002d\u002dly-halign: stretch","stylesChild":"\u002d\u002dleft-spacing-inherit: 0;\u002d\u002dright-spacing-inherit: 0"}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"wi ly ly-stk ly-co-pos wi-m","dimensions":{"width":{"limit":"max","custom":"680px"}},"styles":"\u002d\u002dwi: 680px;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: start;\u002d\u002dwi-m: 90%","layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-m)","contentPosition":"left"}},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-m)","mobile":{"dimensions":{"width":{"custom":"90%"}}}}} -->
' . wphave_pattern_slot( 'eyebrow', $slots ) . '

' . wphave_pattern_slot( 'heading', array( 'level' => 'h2', 'size' => 'title-l' ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-m' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"\u002d\u002dwi: fit-content","classNames":"wi ly ly-fl ly-fl-wp","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-m)","gapY":"var(\u002d\u002dwphave-site-gap-size-s)","flexWrap":"wrap","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-fl-wrap: wrap;\u002d\u002dly-fl-direction: row;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: center"}} -->
' . wphave_pattern_slot( 'actions.0.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'size' => '0' ), 'styles' => '\u002d\u002dbtn-size-scale: 0' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'actions.1.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'variant' => 'secondary', 'size' => '0' ), 'styles' => '\u002d\u002dbtn-size-scale: 0' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/device {"wphave":{"settings":{"device":"ipad-pro"}}} /-->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'mockup-section-3',
            'tags' => array('mockup-sections'),
            'title' => __( 'Mockup Section Overlapping Browser Frames', 'wphave' ),
            'keywords' => array('mockup', 'device', 'product', 'software', 'preview'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('section', 'content'),
                'layout' => array('centered', 'overlay'),
                'visual' => array('device-preview'),
                'content' => array('heading', 'body', 'actions', 'media'),
                'intent' => array('product-showcase'),
                'treatment' => array('strong-contrast', 'layered', 'visual-impact'),
                'description' => 'A high contrast mockup section with centered headline, actions, and two overlapping browser frame previews.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-wide wi-in pa ofw ly ly-stk ly-co-pos bg-co bg br tx-co","dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-3xl) var(\u002d\u002dwphave-site-spacing) 0 var(\u002d\u002dwphave-site-spacing)"},"innerWidth":{"custom":"100%"},"overflow":"clip"},"features":{"size":"wide"},"styles":"\u002d\u002dwi-in: 100%;\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-3xl) var(\u002d\u002dwphave-site-spacing) 0 var(\u002d\u002dwphave-site-spacing);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-3xl);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-spacing);\u002d\u002dpa-bottom: 0;\u002d\u002dpa-left: var(\u002d\u002dwphave-site-spacing);\u002d\u002dofw: clip;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-primary);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners);\u002d\u002dtx-co: var(\u002d\u002dwphave-site-color-primary-subtle-10)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-spacing);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-spacing)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-primary)"}},"layout":{"stacked":{"contentPosition":"center"},"type":"stacked"},"text":{"colors":{"text":"var(\u002d\u002dwphave-site-color-primary-subtle-10)"}},"frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"wi ly ly-stk ly-co-pos txta wi-t","dimensions":{"width":{"limit":"max","custom":"768px"}},"styles":"\u002d\u002dwi: 768px;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center;\u002d\u002dtxta: center;\u002d\u002dwi-t: 85%","text":{"align":"center"},"layout":{"stacked":{"contentPosition":"center"},"type":"stacked"},"tablet":{"dimensions":{"width":{"custom":"85%"}}}}} -->
' . wphave_pattern_slot( 'heading', array( 'level' => 'h2', 'size' => 'title-l' ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-m' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"\u002d\u002dwi: fit-content","classNames":"wi ly ly-fl ly-fl-wp","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-m)","gapY":"var(\u002d\u002dwphave-site-gap-size-m)","flexWrap":"wrap","flexDirection":"row","flexItemSizing":"auto","alignHorizontal":"center","alignVertical":"center"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-fl-wrap: wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: center;\u002d\u002dly-halign: center;\u002d\u002dly-fl-direction: row"}} -->
' . wphave_pattern_slot( 'actions.0.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'size' => '0' ), 'styles' => '\u002d\u002dbtn-size-scale: 0' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'actions.1.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'variant' => 'secondary', 'size' => '0' ), 'styles' => '\u002d\u002dbtn-size-scale: 0' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/spacer {"wphave":{"settings":{"aspectRatio":"75/1"},"styles":"\u002d\u002daspect-ratio: 75/1"}} /-->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked"},"classNames":"wi ly ly-stk","dimensions":{"width":{"custom":"100%"}},"styles":"\u002d\u002dwi: 100%"}} -->
<!-- wp:wphave/browser-frame {"wphave":{"classNames":"wi pos","settings":{"frame":false,"size":"medium","tabs":false},"dimensions":{"width":{"custom":"66.67%"},"position":{"type":"absolute","inset":{"top":"auto","right":"0","bottom":"0","left":"auto"}}},"styles":"\u002d\u002dwi: 66.67%;\u002d\u002dpos: absolute;\u002d\u002dpos-ins: auto 0 0 auto"}} -->
' . wphave_pattern_slot( 'images.0.image', 'image', array( 'ratio' => '21/9', 'attrs' => array( 'wphave' => array( 'styles' => '\u002d\u002dasrt: 21/9;\u002d\u002dofw: clip;\u002d\u002dbr: 0px 0px 0px 0px;\u002d\u002dobject-position: center', 'dimensions' => array( 'aspectRatio' => array( 'ratio' => '21/9' ), 'overflow' => 'clip' ), 'frame' => array( 'corners' => '0px 0px 0px 0px' ), 'classNames' => 'asrt ofw br' ) ) ), $slots ) . '
<!-- /wp:wphave/browser-frame -->

<!-- wp:wphave/browser-frame {"wphave":{"classNames":"wi","settings":{"frame":false,"size":"large","tabs":false},"dimensions":{"width":{"limit":"max","custom":"66.67%"}},"styles":"\u002d\u002dwi: 66.67%"}} -->
' . wphave_pattern_slot( 'images.1.image', 'image', array( 'ratio' => '4/2', 'attrs' => array( 'wphave' => array( 'styles' => '\u002d\u002dasrt: 4/2;\u002d\u002dofw: clip;\u002d\u002dbr: 0px 0px 0px 0px;\u002d\u002dobject-position: center', 'dimensions' => array( 'aspectRatio' => array( 'ratio' => '4/2' ), 'overflow' => 'clip' ), 'frame' => array( 'corners' => '0px 0px 0px 0px' ), 'classNames' => 'asrt ofw br' ) ) ), $slots ) . '
<!-- /wp:wphave/browser-frame -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'mockup-section-4',
            'tags' => array('mockup-sections'),
            'title' => __( 'Mockup Section Split Display Preview', 'wphave' ),
            'keywords' => array('mockup', 'device', 'product', 'software', 'preview'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('section', 'content'),
                'layout' => array('split', 'text-media'),
                'visual' => array('device-preview'),
                'content' => array('heading', 'body', 'actions', 'media'),
                'intent' => array('product-showcase'),
                'treatment' => array('framed', 'visual-impact'),
                'description' => 'A split mockup section with eyebrow, headline, supporting copy, actions, and an oversized desktop display preview.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"wi-in pa ofw ly ly-fl bg-co bg br ly-fl-m","dimensions":{"overflow":"clip","innerWidth":{"limit":"max","custom":"100%"},"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl)"}},"styles":"\u002d\u002dwi-in: 100%;\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background-contrast-1);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-xxl)","gapY":"var(\u002d\u002dwphave-site-gap-size-xxl)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"start","alignHorizontal":"start"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-xxl);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-xxl);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: start;\u002d\u002dly-halign: start;\u002d\u002dly-fl-direction: row;\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-gap-size-xxl);\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-gap-size-xxl);\u002d\u002dly-m-fl-wrap: no-wrap;\u002d\u002dly-m-fl-itm: 0 1 auto;\u002d\u002dly-m-valign: start;\u002d\u002dly-m-halign: start;\u002d\u002dly-m-fl-direction: column-reverse","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-xxl)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background-contrast-1)"}},"frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"},"mobile":{"layout":{"flex":{"flexDirection":"column-reverse"}}}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"wi ly ly-stk ly-co-pos wi-m","dimensions":{"width":{"limit":"max","custom":"680px"}},"styles":"\u002d\u002dwi: 680px;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: start;\u002d\u002dwi-m: 90%","layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-m)","contentPosition":"left"}},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-m)","mobile":{"dimensions":{"width":{"custom":"90%"}}}}} -->
' . wphave_pattern_slot( 'eyebrow', $slots ) . '

' . wphave_pattern_slot( 'heading', array( 'level' => 'h2', 'size' => 'title-l' ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-m' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"\u002d\u002dwi: fit-content","classNames":"wi ly ly-fl ly-fl-wp","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-m)","gapY":"var(\u002d\u002dwphave-site-gap-size-s)","flexWrap":"wrap","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-fl-wrap: wrap;\u002d\u002dly-fl-direction: row;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: center"}} -->
' . wphave_pattern_slot( 'actions.0.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'size' => '0' ), 'styles' => '\u002d\u002dbtn-size-scale: 0' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'actions.1.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'variant' => 'secondary', 'size' => '0' ), 'styles' => '\u002d\u002dbtn-size-scale: 0' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/device {"wphave":{"settings":{"device":"pro-display-xdr"},"dimensions":{"spacing":{"margin":"0px -13rem 0px auto"}},"styles":"\u002d\u002dma: 0px -13rem 0px auto;\u002d\u002dma-top: 0px;\u002d\u002dma-right: -13rem;\u002d\u002dma-bottom: 0px;\u002d\u002dma-left: auto;\u002d\u002dwi-m: 80%;\u002d\u002dma-m: 0px auto 0px auto;\u002d\u002dma-m-top: 0px;\u002d\u002dma-m-right: auto;\u002d\u002dma-m-bottom: 0px;\u002d\u002dma-m-left: auto","classNames":"ma wi-m ma-m","mobile":{"dimensions":{"spacing":{"margin":"0px auto 0px auto"},"width":{"limit":"max","custom":"80%"}}}}} /-->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'mockup-section-5',
            'tags' => array('mockup-sections'),
            'title' => __( 'Mockup Section Dark Device Stage', 'wphave' ),
            'keywords' => array('mockup', 'device', 'product', 'software', 'preview'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('section', 'content'),
                'layout' => array('centered', 'stacked'),
                'visual' => array('device-preview'),
                'content' => array('heading', 'body', 'actions', 'media'),
                'intent' => array('product-showcase'),
                'treatment' => array('strong-contrast', 'visual-impact'),
                'description' => 'A dark full-width mockup section with centered headline, supporting copy, actions, spacing, and a laptop preview stage.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-full wi-in pa ofw ly ly-stk ly-co-pos bg-co bg tx-co","dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-3xl) var(\u002d\u002dwphave-site-spacing) 0 var(\u002d\u002dwphave-site-spacing)"},"innerWidth":{"custom":"100%"},"overflow":"clip"},"features":{"size":"full"},"styles":"\u002d\u002dwi-in: 100%;\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-3xl) var(\u002d\u002dwphave-site-spacing) 0 var(\u002d\u002dwphave-site-spacing);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-3xl);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-spacing);\u002d\u002dpa-bottom: 0;\u002d\u002dpa-left: var(\u002d\u002dwphave-site-spacing);\u002d\u002dofw: clip;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background-contrast-10);\u002d\u002dtx-co: var(\u002d\u002dwphave-site-color-background-subtle-10)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-spacing);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-spacing)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background-contrast-10)"}},"layout":{"stacked":{"contentPosition":"center"},"type":"stacked"},"text":{"colors":{"text":"var(\u002d\u002dwphave-site-color-background-subtle-10)"}}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"wi ly ly-stk ly-co-pos txta wi-t","dimensions":{"width":{"limit":"max","custom":"768px"}},"styles":"\u002d\u002dwi: 768px;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center;\u002d\u002dtxta: center;\u002d\u002dwi-t: 85%","text":{"align":"center"},"layout":{"stacked":{"contentPosition":"center"},"type":"stacked"},"tablet":{"dimensions":{"width":{"custom":"85%"}}}}} -->
' . wphave_pattern_slot( 'heading', array( 'level' => 'h2', 'size' => 'title-l' ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-m' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"\u002d\u002dwi: fit-content","classNames":"wi ly ly-fl","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-m)","gapY":"var(\u002d\u002dwphave-site-gap-size-m)","flexWrap":"no-wrap","flexDirection":"row","flexItemSizing":"auto"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-direction: row;\u002d\u002dly-fl-itm: 0 1 auto"}} -->
' . wphave_pattern_slot( 'actions.0.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'size' => '0' ), 'styles' => '\u002d\u002dbtn-size-scale: 0' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'actions.1.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'variant' => 'secondary', 'size' => '0' ), 'styles' => '\u002d\u002dbtn-size-scale: 0' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/spacer {"wphave":{"settings":{"aspectRatio":"75/1"},"styles":"\u002d\u002daspect-ratio: 75/1"}} /-->

<!-- wp:wphave/device {"wphave":{"settings":{"device":"macbook"}}} /-->
<!-- /wp:wphave/group -->'
        );

        return $patterns;

	}

endif;
