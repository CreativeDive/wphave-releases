<?php

/**
 * Functions to group hero block patterns.
 */

if ( ! function_exists( 'wphave_block_pattern_collection_hero' ) ) :

	function wphave_block_pattern_collection_hero( $args = array() ) {

        $content_width = isset( $args['width'] ) ? (int) $args['width'] : 1300;
        $slots = is_array( $args['slots'] ?? null ) ? $args['slots'] : array();
        $patterns = array();

        $patterns[] = array(
            'key' => 'hero-1',
            'tags' => array('hero'),
            'title' => __( 'Hero Cinematic Center', 'wphave' ),
            'keywords' => array('hero', 'cinematic', 'centered', 'background', 'overlay', 'cta', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('hero'),
                'layout' => array('centered', 'stacked'),
                'width' => array('full-width'),
                'visual' => array('background-media', 'overlay'),
                'content' => array('heading', 'body', 'actions'),
                'intent' => array('first-viewport', 'conversion', 'brand-story'),
                'treatment' => array('cinematic', 'strong-contrast', 'minimal'),
                'description' => 'Full-width cinematic hero with centered headline, supporting copy and two primary actions on a dark media overlay.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-full pa asrt ofw ly ly-stk ly-co-pos bg-co bg txta tx-co","features":{"size":"full"},"dimensions":{"overflow":"clip","spacing":{"padding":"var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl)"},"aspectRatio":{"ratio":"21/9"}},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dasrt: 21/9;\u002d\u002dofw: clip;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-palette-black);\u002d\u002dtxta: none;\u002d\u002dtx-co: var(\u002d\u002dwphave-site-color-palette-white)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-xxl)","text":{"align":"none","colors":{"text":"var(\u002d\u002dwphave-site-color-palette-white)"}},"layout":{"stacked":{"contentPosition":"center"},"type":"stacked"},"background":{"color":{"base":"var(\u002d\u002dwphave-site-color-palette-black)"},"layers":[{"overlay":{"type":"cover","color":"#000000","opacity":"0.45"},"media":{"image":{"type":"custom","data":{"id":null,"focal":{"top":50,"left":50}}}}}]},"stylesBackgrounds":["\u002d\u002dbg-mda-img-pos: 50% 50%;\u002d\u002dov-co: #000000;\u002d\u002dov-op: 0.45;\u002d\u002dov-bg: var(\u002d\u002dov-co)"]}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"contentPosition":"center"}},"classNames":"wi ly ly-stk ly-co-pos txta","styles":"\u002d\u002dwi: 582px;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center;\u002d\u002dtxta: center","dimensions":{"width":{"limit":"max","custom":"582px"}},"text":{"align":"center"}}} -->
' . wphave_pattern_slot( 'heading', array( 'level' => 'h1', 'size' => 'title-m' ), $slots ) . '

' . wphave_pattern_slot( 'body', $slots ) . '

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"\u002d\u002dwi: fit-content","classNames":"wi ly ly-fl ly-fl-wp","layout":{"type":"flex","flex":{"gapX":"1rem","gapY":"1rem","flexWrap":"wrap","alignHorizontal":"center"}},"stylesLayout":"\u002d\u002dly-column-gap: 1rem;\u002d\u002dly-row-gap: 1rem;\u002d\u002dly-fl-wrap: wrap;\u002d\u002dly-halign: center"}} -->
' . wphave_pattern_slot( 'actions.0.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'actions.1.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'variant' => 'ghost', 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'hero-2',
            'tags' => array('hero'),
            'title' => __( 'Hero Cinematic Corner', 'wphave' ),
            'keywords' => array('hero', 'cinematic', 'corner', 'bottom', 'background', 'overlay', 'cta', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('hero'),
                'layout' => array('asymmetric', 'stacked'),
                'width' => array('full-width'),
                'visual' => array('background-media', 'overlay'),
                'content' => array('heading', 'body', 'actions'),
                'intent' => array('first-viewport', 'conversion', 'campaign'),
                'treatment' => array('cinematic', 'strong-contrast', 'editorial'),
                'description' => 'Full-width media hero with copy anchored to the lower right for campaign, portfolio or premium landing pages.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-full pa asrt ofw ly ly-stk ly-co-pos bg-co bg txta tx-co","features":{"size":"full"},"dimensions":{"overflow":"clip","spacing":{"padding":"var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl)"},"aspectRatio":{"ratio":"21/9"}},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dasrt: 21/9;\u002d\u002dofw: clip;\u002d\u002dly-co-pos-h: end;\u002d\u002dly-co-pos-v: end;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-palette-black);\u002d\u002dtxta: none;\u002d\u002dtx-co: var(\u002d\u002dwphave-site-color-palette-white)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-xxl)","text":{"align":"none","colors":{"text":"var(\u002d\u002dwphave-site-color-palette-white)"}},"layout":{"stacked":{"contentPosition":"bottom-right"},"type":"stacked"},"background":{"color":{"base":"var(\u002d\u002dwphave-site-color-palette-black)"},"layers":[{"overlay":{"type":"cover","color":"#000000","opacity":"0.45"},"media":{"image":{"type":"custom","data":{"id":null,"focal":{"top":50,"left":50}}}}}]},"stylesBackgrounds":["\u002d\u002dbg-mda-img-pos: 50% 50%;\u002d\u002dov-co: #000000;\u002d\u002dov-op: 0.45;\u002d\u002dov-bg: var(\u002d\u002dov-co)"]}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"contentPosition":"bottom-left"}},"classNames":"wi ly ly-stk ly-co-pos","styles":"\u002d\u002dwi: 582px;\u002d\u002dly-co-pos-h: end;\u002d\u002dly-co-pos-v: start","dimensions":{"width":{"limit":"max","custom":"582px"}}}} -->
' . wphave_pattern_slot( 'heading', array( 'level' => 'h1', 'size' => 'title-m' ), $slots ) . '

' . wphave_pattern_slot( 'body', $slots ) . '

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"\u002d\u002dwi: fit-content","classNames":"wi ly ly-fl ly-fl-wp","layout":{"type":"flex","flex":{"gapX":"1rem","gapY":"1rem","flexWrap":"wrap","alignHorizontal":"center"}},"stylesLayout":"\u002d\u002dly-column-gap: 1rem;\u002d\u002dly-row-gap: 1rem;\u002d\u002dly-fl-wrap: wrap;\u002d\u002dly-halign: center"}} -->
' . wphave_pattern_slot( 'actions.0.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'actions.1.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'variant' => 'ghost', 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'hero-3',
            'tags' => array('hero'),
            'title' => __( 'Hero Cinematic Split Caption', 'wphave' ),
            'keywords' => array('hero', 'cinematic', 'split', 'caption', 'background', 'overlay', 'cta', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('hero'),
                'layout' => array('split', 'asymmetric'),
                'width' => array('full-width'),
                'visual' => array('background-media', 'overlay'),
                'content' => array('heading', 'body', 'actions'),
                'intent' => array('first-viewport', 'conversion', 'brand-story'),
                'treatment' => array('cinematic', 'editorial', 'strong-contrast'),
                'description' => 'Full-width cinematic hero that separates the main headline and supporting caption across the background image.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-full pa asrt ofw ly ly-stk ly-co-pos bg-co bg txta tx-co","features":{"size":"full"},"dimensions":{"overflow":"clip","spacing":{"padding":"96px var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl)"},"aspectRatio":{"ratio":"21/9"}},"styles":"\u002d\u002dpa: 96px var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-top: 96px;\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dasrt: 21/9;\u002d\u002dofw: clip;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: end;\u002d\u002dly-co-pos-h: space-between;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-palette-black);\u002d\u002dtxta: none;\u002d\u002dtx-co: var(\u002d\u002dwphave-site-color-palette-white)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-xxl)","text":{"align":"none","colors":{"text":"var(\u002d\u002dwphave-site-color-palette-white)"}},"layout":{"stacked":{"contentPosition":"right","contentDistribution":"space-between"},"type":"stacked"},"background":{"color":{"base":"var(\u002d\u002dwphave-site-color-palette-black)"},"layers":[{"overlay":{"type":"cover","color":"#000000","opacity":"0.45"},"media":{"image":{"type":"custom","data":{"id":null,"focal":{"top":50,"left":50}}}}}]},"stylesBackgrounds":["\u002d\u002dbg-mda-img-pos: 50% 50%;\u002d\u002dov-co: #000000;\u002d\u002dov-op: 0.45;\u002d\u002dov-bg: var(\u002d\u002dov-co)"]}} -->
' . wphave_pattern_slot( 'heading', array( 'level' => 'h1', 'size' => 'title-m', 'attrs' => array( 'classNames' => 'hd-left wi tf-fs', 'wphave' => array( 'settings' => array( 'headingLevel' => 'h1' ), 'text' => array( 'typeface' => array( 'size' => array( 'type' => 'title-m' ) ) ), 'features' => array( 'horizontalDirection' => 'left' ), 'dimensions' => array( 'width' => array( 'custom' => '16ch' ) ), 'styles' => '--wi: 16ch' ) ) ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"contentPosition":"bottom-left"}},"classNames":"hd-right wi ly ly-stk ly-co-pos","styles":"\u002d\u002dwi: 582px;\u002d\u002dly-co-pos-h: end;\u002d\u002dly-co-pos-v: start","dimensions":{"width":{"limit":"max","custom":"582px"}},"features":{"horizontalDirection":"right"}}} -->
' . wphave_pattern_slot( 'body', $slots ) . '

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"\u002d\u002dwi: fit-content","classNames":"wi ly ly-fl ly-fl-wp","layout":{"type":"flex","flex":{"gapX":"1rem","gapY":"1rem","flexWrap":"wrap","alignHorizontal":"center"}},"stylesLayout":"\u002d\u002dly-column-gap: 1rem;\u002d\u002dly-row-gap: 1rem;\u002d\u002dly-fl-wrap: wrap;\u002d\u002dly-halign: center"}} -->
' . wphave_pattern_slot( 'actions.0.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'actions.1.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'variant' => 'ghost', 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'hero-4',
            'tags' => array('hero'),
            'title' => __( 'Hero Editorial Proof Stack', 'wphave' ),
            'keywords' => array('hero', 'editorial', 'proof', 'metrics', 'grid', 'actions', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('hero', 'proof'),
                'layout' => array('stacked', 'grid'),
                'width' => array('full-width'),
                'visual' => array('numbers', 'cards'),
                'content' => array('heading', 'body', 'actions', 'items'),
                'intent' => array('first-viewport', 'conversion', 'proof', 'credibility'),
                'treatment' => array('editorial', 'spacious', 'minimal'),
                'description' => 'Editorial full-width hero with a focused text introduction, action row and a four-column proof grid underneath.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-full pa ofw ly ly-stk bg-co bg","features":{"size":"full"},"dimensions":{"overflow":"clip","spacing":{"padding":"var(\u002d\u002dwphave-site-gap-size-4xl) var(\u002d\u002dwphave-site-spacing) var(\u002d\u002dwphave-site-gap-size-3xl) var(\u002d\u002dwphave-site-spacing)"}},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-gap-size-4xl) var(\u002d\u002dwphave-site-spacing) var(\u002d\u002dwphave-site-gap-size-3xl) var(\u002d\u002dwphave-site-spacing);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-spacing);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-spacing);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-spacing);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-spacing)","layout":{"stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-3xl)"},"type":"stacked"},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-3xl)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background)"}}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"wi ly ly-stk wi-m","dimensions":{"width":{"custom":"820px"}},"styles":"\u002d\u002dwi: 820px;\u002d\u002dwi-m: 100%","mobile":{"dimensions":{"width":{"custom":"100%"}}},"layout":{"type":"stacked"}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk","layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'eyebrow', $slots ) . '
<!-- /wp:wphave/group -->

' . wphave_pattern_slot( 'heading', array( 'level' => 'h1', 'size' => 'title-xl' ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-l' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"\u002d\u002dwi: fit-content","classNames":"wi ly ly-fl","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-m)","gapY":"var(\u002d\u002dwphave-site-gap-size-m)","flexWrap":"no-wrap","flexDirection":"row","flexItemSizing":"auto"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-direction: row;\u002d\u002dly-fl-itm: 0 1 auto"}} -->
' . wphave_pattern_slot( 'actions.0.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'actions.1.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'variant' => 'secondary', 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/spacer {"wphave":{"settings":{"aspectRatio":"75/1"},"styles":"\u002d\u002daspect-ratio: 75/1"}} /-->

<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-gr ly-nowrap ly-gr-t ly-t-col-2 ly-gr-m ly-m-col-1","layout":{"type":"grid","grid":{"columns":4,"keepColumns":"nowrap"}},"stylesLayout":"\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-col: 4;\u002d\u002dly-t-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-t-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-t-col: 2;\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-col: 1","tablet":{"layout":{"grid":{"columns":2}}},"mobile":{"layout":{"grid":{"columns":1}}}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk","layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'items.0.title', array( 'level' => 'h3', 'size' => 'title-xxs' ), $slots ) . '

' . wphave_pattern_slot( 'items.0.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk","layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'items.1.title', array( 'level' => 'h3', 'size' => 'title-xxs' ), $slots ) . '

' . wphave_pattern_slot( 'items.1.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk","layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'items.2.title', array( 'level' => 'h3', 'size' => 'title-xxs' ), $slots ) . '

' . wphave_pattern_slot( 'items.2.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk","layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'items.3.title', array( 'level' => 'h3', 'size' => 'title-xxs' ), $slots ) . '

' . wphave_pattern_slot( 'items.3.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'hero-5',
            'tags' => array('hero'),
            'title' => __( 'Hero Grid Areas Proof Aside', 'wphave' ),
            'keywords' => array('hero', 'grid areas', 'proof', 'aside', 'editorial', 'actions', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('hero', 'proof'),
                'layout' => array('grid', 'asymmetric'),
                'width' => array('full-width'),
                'visual' => array('numbers', 'cards'),
                'content' => array('heading', 'body', 'actions', 'items'),
                'intent' => array('first-viewport', 'conversion', 'proof', 'credibility'),
                'treatment' => array('editorial', 'structured', 'spacious'),
                'description' => 'Asymmetric grid-area hero with a broad text lead and a proof stack placed as a supporting aside.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-full pa ofw ly ly-gra bg-co bg ly-gra-m","features":{"size":"full"},"dimensions":{"overflow":"clip","spacing":{"padding":"var(\u002d\u002dwphave-site-gap-size-4xl) var(\u002d\u002dwphave-site-spacing) var(\u002d\u002dwphave-site-gap-size-3xl) var(\u002d\u002dwphave-site-spacing)"}},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-gap-size-4xl) var(\u002d\u002dwphave-site-spacing) var(\u002d\u002dwphave-site-gap-size-3xl) var(\u002d\u002dwphave-site-spacing);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-spacing);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-spacing);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-spacing);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-spacing)","layout":{"type":"gridAreas","gridAreas":{"gapX":"var(\u002d\u002dwphave-site-gap-size-4xl)","gapY":"var(\u002d\u002dwphave-site-gap-size-4xl)","areas":{"columns":3,"rows":2,"areas":[{"id":"c1","label":"1","x":1,"y":1,"w":2,"h":2},{"id":"c2","label":"2","x":3,"y":1,"w":1,"h":2}],"rowHeight":"auto"}}},"stylesLayout":"\u002d\u002dly-gra-template: \u0022c1 c1 c2\u0022 \u0022c1 c1 c2\u0022;\u002d\u002dly-gra-columns: 3;\u002d\u002dly-gra-rows: 2;\u002d\u002dly-gra-row-height: minmax(min-content, auto);\u002d\u002dly-gra-area-1: c1;\u002d\u002dly-gra-area-2: c2;\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-m-gra-template: \u0022c1\u0022 \u0022.\u0022 \u0022c2\u0022;\u002d\u002dly-m-gra-columns: 1;\u002d\u002dly-m-gra-rows: 3;\u002d\u002dly-m-gra-row-height: minmax(min-content, auto);\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-gap-size-4xl)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background)"}},"mobile":{"layout":{"gridAreas":{"areas":{"columns":1,"rows":3,"areas":[{"id":"c1","label":"1","x":1,"y":1,"w":1,"h":1},{"id":"c2","label":"2","x":1,"y":3,"w":1,"h":1}],"rowHeight":"auto"}}}}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"wi ly ly-stk wi-m ma-m","dimensions":{"width":{"custom":"820px"}},"styles":"\u002d\u002dwi: 820px;\u002d\u002dwi-m: 100%;\u002d\u002dma-m: 0 auto var(\u002d\u002dwphave-site-margin-l) auto;\u002d\u002dma-m-top: 0;\u002d\u002dma-m-right: auto;\u002d\u002dma-m-bottom: var(\u002d\u002dwphave-site-margin-l);\u002d\u002dma-m-left: auto","mobile":{"dimensions":{"width":{"custom":"100%"},"spacing":{"margin":"0 auto var(\u002d\u002dwphave-site-margin-l) auto"}}},"layout":{"type":"stacked"}}} -->
' . wphave_pattern_slot( 'heading', array( 'level' => 'h1', 'size' => 'title-xl' ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-l' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"\u002d\u002dwi: fit-content","classNames":"wi ly ly-fl","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-m)","gapY":"var(\u002d\u002dwphave-site-gap-size-m)","flexWrap":"no-wrap","flexDirection":"row","flexItemSizing":"auto"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-direction: row;\u002d\u002dly-fl-itm: 0 1 auto"}} -->
' . wphave_pattern_slot( 'actions.0.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'actions.1.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'variant' => 'secondary', 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk","layout":{"type":"stacked"},"tablet":{"layout":{"grid":{"columns":2}}},"mobile":{"layout":{"grid":{"columns":1}}}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk","layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'items.0.title', array( 'level' => 'h3', 'size' => 'title-xxs' ), $slots ) . '

' . wphave_pattern_slot( 'items.0.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk","layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'items.1.title', array( 'level' => 'h3', 'size' => 'title-xxs' ), $slots ) . '

' . wphave_pattern_slot( 'items.1.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk","layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'items.2.title', array( 'level' => 'h3', 'size' => 'title-xxs' ), $slots ) . '

' . wphave_pattern_slot( 'items.2.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk","layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'items.3.title', array( 'level' => 'h3', 'size' => 'title-xxs' ), $slots ) . '

' . wphave_pattern_slot( 'items.3.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'hero-6',
            'tags' => array('hero'),
            'title' => __( 'Hero Split Image Offset', 'wphave' ),
            'keywords' => array('hero', 'split', 'image', 'offset', 'media', 'actions', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('hero'),
                'layout' => array('split', 'grid'),
                'width' => array('full-width'),
                'visual' => array('image'),
                'content' => array('heading', 'body', 'actions', 'media'),
                'intent' => array('first-viewport', 'conversion', 'product-showcase'),
                'treatment' => array('spacious', 'editorial', 'visual-impact'),
                'description' => 'Split hero with a generous text column and a rounded image panel, suited for product, service and brand introductions.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-full pa ofw ly ly-gr ly-col-2 bg-co bg ly-gr-m ly-m-col-1","features":{"size":"full"},"dimensions":{"overflow":"clip","spacing":{"padding":"var(\u002d\u002dwphave-site-padding-3xl) var(\u002d\u002dwphave-site-spacing) 128px var(\u002d\u002dwphave-site-spacing)"}},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-3xl) var(\u002d\u002dwphave-site-spacing) 128px var(\u002d\u002dwphave-site-spacing);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-3xl);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-spacing);\u002d\u002dpa-bottom: 128px;\u002d\u002dpa-left: var(\u002d\u002dwphave-site-spacing);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-spacing);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-spacing)","layout":{"type":"grid","grid":{"gapX":"var(\u002d\u002dwphave-site-gap-size-4xl)","gapY":"var(\u002d\u002dwphave-site-gap-size-4xl)","columns":2,"keepColumns":"auto","gridRowHeight":"auto","alignVertical":"center","alignHorizontal":"space-between"}},"stylesLayout":"\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-col: 2;\u002d\u002dly-valign: center;\u002d\u002dly-halign: space-between;\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-m-col: 1;\u002d\u002dly-m-valign: center;\u002d\u002dly-m-halign: space-between","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background)"}},"mobile":{"layout":{"gridAreas":{"areas":{"columns":1,"rows":3,"areas":[{"id":"c1","label":"1","x":1,"y":1,"w":1,"h":1},{"id":"c2","label":"2","x":1,"y":3,"w":1,"h":1}],"rowHeight":"auto"}},"grid":{"columns":1}}}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"wi ly ly-stk wi-m","dimensions":{"width":{"custom":"820px"}},"styles":"\u002d\u002dwi: 820px;\u002d\u002dwi-m: 100%","mobile":{"dimensions":{"width":{"custom":"100%"}}},"layout":{"type":"stacked"}}} -->
' . wphave_pattern_slot( 'heading', array( 'level' => 'h1', 'size' => 'title-l' ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-m' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"\u002d\u002dwi: fit-content","classNames":"wi ly ly-fl","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-m)","gapY":"var(\u002d\u002dwphave-site-gap-size-m)","flexWrap":"no-wrap","flexDirection":"row","flexItemSizing":"auto"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-direction: row;\u002d\u002dly-fl-itm: 0 1 auto"}} -->
' . wphave_pattern_slot( 'actions.0.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'actions.1.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'variant' => 'secondary', 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/image {"wphave":{"dimensions":{"overflow":"clip"},"frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"},"styles":"\u002d\u002dofw: clip;\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners);\u002d\u002dobject-position: center","classNames":"ofw br"}} /-->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'hero-7',
            'tags' => array('hero'),
            'title' => __( 'Hero Edge Media Split', 'wphave' ),
            'keywords' => array('hero', 'split', 'edge media', 'image', 'full width', 'actions', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('hero'),
                'layout' => array('split', 'grid'),
                'width' => array('full-width'),
                'visual' => array('image'),
                'content' => array('heading', 'body', 'actions', 'media'),
                'intent' => array('first-viewport', 'conversion', 'product-showcase'),
                'treatment' => array('editorial', 'visual-impact', 'spacious'),
                'description' => 'Full-width split hero with centered copy on one side and an edge-to-edge image column on the other.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-full wi-in pa ofw ly ly-gr ly-col-2 bg-co bg ly-gr-m ly-m-col-1","features":{"size":"full"},"dimensions":{"overflow":"clip","spacing":{"padding":"0 0 0 0"},"innerWidth":{"limit":"max","custom":"100%"}},"styles":"\u002d\u002dwi-in: 100%;\u002d\u002dpa: 0 0 0 0;\u002d\u002dpa-top: 0;\u002d\u002dpa-right: 0;\u002d\u002dpa-bottom: 0;\u002d\u002dpa-left: 0;\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background)","stylesChild":"\u002d\u002dleft-spacing-inherit: 0;\u002d\u002dright-spacing-inherit: 0","layout":{"type":"grid","grid":{"gapX":"var(\u002d\u002dwphave-site-gap-size-4xl)","gapY":"var(\u002d\u002dwphave-site-gap-size-4xl)","columns":2,"keepColumns":"auto","gridRowHeight":"auto","alignVertical":"stretch","alignHorizontal":"space-between"}},"stylesLayout":"\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-col: 2;\u002d\u002dly-valign: stretch;\u002d\u002dly-halign: space-between;\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-m-col: 1;\u002d\u002dly-m-valign: stretch;\u002d\u002dly-m-halign: space-between","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background)"}},"mobile":{"layout":{"gridAreas":{"areas":{"columns":1,"rows":3,"areas":[{"id":"c1","label":"1","x":1,"y":1,"w":1,"h":1},{"id":"c2","label":"2","x":1,"y":3,"w":1,"h":1}],"rowHeight":"auto"}},"grid":{"columns":1}}}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"wi-in pa ly ly-stk ly-co-pos wi-m","styles":"\u002d\u002dwi-in: 607px;\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-top) var(\u002d\u002dwphave-site-padding-right) var(\u002d\u002dwphave-site-padding-bottom) var(\u002d\u002dwphave-site-padding-left);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-top);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-right);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-bottom);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-left);\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center;\u002d\u002dwi-m: 100%","mobile":{"dimensions":{"width":{"custom":"100%"}}},"layout":{"type":"stacked","stacked":{"contentPosition":"center"}},"dimensions":{"innerWidth":{"limit":"max","custom":"607px"},"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-top) var(\u002d\u002dwphave-site-padding-right) var(\u002d\u002dwphave-site-padding-bottom) var(\u002d\u002dwphave-site-padding-left)"}},"stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-left);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-right)"}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked"},"classNames":"ly ly-stk"}} -->
' . wphave_pattern_slot( 'heading', array( 'level' => 'h1', 'size' => 'title-l' ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-m' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"\u002d\u002dwi: fit-content","classNames":"wi ly ly-fl","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-m)","gapY":"var(\u002d\u002dwphave-site-gap-size-m)","flexWrap":"no-wrap","flexDirection":"row","flexItemSizing":"auto"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-direction: row;\u002d\u002dly-fl-itm: 0 1 auto"}} -->
' . wphave_pattern_slot( 'actions.0.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'actions.1.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'variant' => 'secondary', 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/image {"wphave":{"dimensions":{"overflow":"clip"},"styles":"\u002d\u002dofw: clip;\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) 0 0 var(\u002d\u002dwphave-site-corners);\u002d\u002dofw-m: clip;\u002d\u002dbr-m: 0px 0px 0px 0px;\u002d\u002dobject-position: center","classNames":"ofw br ofw-m br-m","frame":{"corners":"var(\u002d\u002dwphave-site-corners) 0 0 var(\u002d\u002dwphave-site-corners)"},"mobile":{"dimensions":{"overflow":"clip"},"frame":{"corners":"0px 0px 0px 0px"}}}} /-->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'hero-8',
            'tags' => array('hero'),
            'title' => __( 'Hero Centered Media Stage', 'wphave' ),
            'keywords' => array('hero', 'centered', 'media', 'stage', 'image', 'actions', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('hero'),
                'layout' => array('centered', 'stacked'),
                'width' => array('full-width'),
                'visual' => array('image'),
                'content' => array('heading', 'body', 'actions', 'media'),
                'intent' => array('first-viewport', 'conversion', 'product-showcase'),
                'treatment' => array('spacious', 'minimal', 'visual-impact'),
                'description' => 'Centered hero with a compact content stack and a broad media stage underneath for clear product or service introductions.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-full wi-in pa ofw ly ly-stk ly-co-pos txta","features":{"size":"full"},"dimensions":{"innerWidth":{"custom":"1180px"},"overflow":"clip","spacing":{"padding":"var(\u002d\u002dwphave-site-gap-size-4xl) var(\u002d\u002dwphave-site-spacing) var(\u002d\u002dwphave-site-gap-size-3xl) var(\u002d\u002dwphave-site-spacing)"}},"styles":"\u002d\u002dwi-in: 1180px;\u002d\u002dpa: var(\u002d\u002dwphave-site-gap-size-4xl) var(\u002d\u002dwphave-site-spacing) var(\u002d\u002dwphave-site-gap-size-3xl) var(\u002d\u002dwphave-site-spacing);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-spacing);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-spacing);\u002d\u002dofw: clip;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center;\u002d\u002dtxta: center","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-spacing);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-spacing)","text":{"align":"center"},"layout":{"stacked":{"contentPosition":"center","gap":"var(\u002d\u002dwphave-site-gap-size-l)"},"type":"stacked"},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-l)"}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"wi ly ly-stk ly-co-pos","dimensions":{"width":{"custom":"760px"}},"styles":"\u002d\u002dwi: 760px;\u002d\u002dwi-m: 100%;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center","mobile":{"dimensions":{"width":{"custom":"100%"}}},"layout":{"stacked":{"contentPosition":"center","gap":"var(\u002d\u002dwphave-site-gap-size-m)"}},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-m)"}} -->
' . wphave_pattern_slot( 'eyebrow', $slots ) . '

' . wphave_pattern_slot( 'heading', array( 'level' => 'h1', 'size' => 'title-xl' ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-l' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"\u002d\u002dwi: fit-content","classNames":"wi ly ly-fl","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-m)","gapY":"var(\u002d\u002dwphave-site-gap-size-m)","flexWrap":"no-wrap","alignVertical":"center","alignHorizontal":"center","flexDirection":"row","flexItemSizing":"auto"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-valign: center;\u002d\u002dly-halign: center;\u002d\u002dly-fl-direction: row;\u002d\u002dly-fl-itm: 0 1 auto"}} -->
' . wphave_pattern_slot( 'actions.0.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'actions.1.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'variant' => 'secondary', 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/spacer {"wphave":{"settings":{"aspectRatio":"75/1"},"styles":"\u002d\u002daspect-ratio: 75/1"}} /-->

<!-- wp:wphave/image {"wphave":{"classNames":"wi asrt ofw br","dimensions":{"aspectRatio":{"ratio":"21/9"},"overflow":"clip","width":{"limit":"max","custom":"100%"}},"styles":"\u002d\u002dwi: 100%;\u002d\u002dasrt: 21/9;\u002d\u002dofw: clip;\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners);\u002d\u002dobject-position: center","frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"}}} /-->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'hero-9',
            'tags' => array('hero'),
            'title' => __( 'Hero Dark Media Dock', 'wphave' ),
            'keywords' => array('hero', 'dark', 'centered', 'media', 'dock', 'actions', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('hero'),
                'layout' => array('centered', 'stacked'),
                'width' => array('full-width'),
                'visual' => array('image'),
                'content' => array('heading', 'body', 'actions', 'media'),
                'intent' => array('first-viewport', 'conversion', 'campaign'),
                'treatment' => array('strong-contrast', 'spacious', 'visual-impact'),
                'description' => 'High-contrast centered hero with copy above and a docked full-width media panel, useful for premium launch or campaign pages.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-full wi-in pa ofw ly ly-stk ly-co-pos bg-co bg txta tx-co","features":{"size":"full"},"dimensions":{"innerWidth":{"custom":"1180px"},"overflow":"clip","spacing":{"padding":"var(\u002d\u002dwphave-site-gap-size-4xl) var(\u002d\u002dwphave-site-spacing) 0 var(\u002d\u002dwphave-site-spacing)"}},"styles":"\u002d\u002dwi-in: 1180px;\u002d\u002dpa: var(\u002d\u002dwphave-site-gap-size-4xl) var(\u002d\u002dwphave-site-spacing) 0 var(\u002d\u002dwphave-site-spacing);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-spacing);\u002d\u002dpa-bottom: 0;\u002d\u002dpa-left: var(\u002d\u002dwphave-site-spacing);\u002d\u002dofw: clip;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background-contrast-10);\u002d\u002dtxta: center;\u002d\u002dtx-co: var(\u002d\u002dwphave-site-color-background-subtle-10)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-spacing);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-spacing)","text":{"align":"center","colors":{"text":"var(\u002d\u002dwphave-site-color-background-subtle-10)"}},"layout":{"stacked":{"contentPosition":"center","gap":"var(\u002d\u002dwphave-site-gap-size-l)"},"type":"stacked"},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-l)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background-contrast-10)"}}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"wi ly ly-stk ly-co-pos","dimensions":{"width":{"custom":"760px"}},"styles":"\u002d\u002dwi: 760px;\u002d\u002dwi-m: 100%;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center","mobile":{"dimensions":{"width":{"custom":"100%"}}},"layout":{"stacked":{"contentPosition":"center","gap":"var(\u002d\u002dwphave-site-gap-size-m)"}},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-m)"}} -->
' . wphave_pattern_slot( 'eyebrow', $slots ) . '

' . wphave_pattern_slot( 'heading', array( 'level' => 'h1', 'size' => 'title-xl' ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-l' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"\u002d\u002dwi: fit-content","classNames":"wi ly ly-fl","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-m)","gapY":"var(\u002d\u002dwphave-site-gap-size-m)","flexWrap":"no-wrap","alignVertical":"center","alignHorizontal":"center","flexDirection":"row","flexItemSizing":"auto"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-valign: center;\u002d\u002dly-halign: center;\u002d\u002dly-fl-direction: row;\u002d\u002dly-fl-itm: 0 1 auto"}} -->
' . wphave_pattern_slot( 'actions.0.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'actions.1.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'variant' => 'secondary', 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/spacer {"wphave":{"settings":{"aspectRatio":"75/1"},"styles":"\u002d\u002daspect-ratio: 75/1"}} /-->

<!-- wp:wphave/image {"wphave":{"classNames":"wi asrt ofw br","dimensions":{"width":{"custom":"100%"},"aspectRatio":{"ratio":"21/9"},"overflow":"clip"},"styles":"\u002d\u002dwi: 100%;\u002d\u002dasrt: 21/9;\u002d\u002dofw: clip;\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) 0 0;\u002d\u002dobject-position: center","frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) 0 0"}}} /-->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'hero-10',
            'tags' => array('hero'),
            'title' => __( 'Hero Dark Framed Media', 'wphave' ),
            'keywords' => array('hero', 'dark', 'framed', 'media', 'centered', 'actions', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('hero'),
                'layout' => array('centered', 'stacked', 'panel'),
                'width' => array('content-width', 'wide'),
                'visual' => array('image'),
                'content' => array('heading', 'body', 'actions', 'media'),
                'intent' => array('first-viewport', 'conversion', 'product-showcase'),
                'treatment' => array('strong-contrast', 'framed', 'visual-impact'),
                'description' => 'Rounded high-contrast hero panel with centered messaging and an image area docked to the lower edge.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"wi-in pa ofw ly ly-stk ly-co-pos bg-co bg br txta tx-co","dimensions":{"innerWidth":{"custom":"1180px"},"overflow":"clip","spacing":{"padding":"var(\u002d\u002dwphave-site-gap-size-4xl) var(\u002d\u002dwphave-site-spacing) 0 var(\u002d\u002dwphave-site-spacing)"}},"styles":"\u002d\u002dwi-in: 1180px;\u002d\u002dpa: var(\u002d\u002dwphave-site-gap-size-4xl) var(\u002d\u002dwphave-site-spacing) 0 var(\u002d\u002dwphave-site-spacing);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-spacing);\u002d\u002dpa-bottom: 0;\u002d\u002dpa-left: var(\u002d\u002dwphave-site-spacing);\u002d\u002dofw: clip;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background-contrast-10);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners);\u002d\u002dtxta: center;\u002d\u002dtx-co: var(\u002d\u002dwphave-site-color-background-subtle-10)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-spacing);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-spacing)","text":{"align":"center","colors":{"text":"var(\u002d\u002dwphave-site-color-background-subtle-10)"}},"layout":{"stacked":{"contentPosition":"center","gap":"var(\u002d\u002dwphave-site-gap-size-l)"},"type":"stacked"},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-l)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background-contrast-10)"}},"frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"wi ly ly-stk ly-co-pos","dimensions":{"width":{"custom":"760px"}},"styles":"\u002d\u002dwi: 760px;\u002d\u002dwi-m: 100%;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center","mobile":{"dimensions":{"width":{"custom":"100%"}}},"layout":{"stacked":{"contentPosition":"center","gap":"var(\u002d\u002dwphave-site-gap-size-m)"}},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-m)"}} -->
' . wphave_pattern_slot( 'eyebrow', $slots ) . '

' . wphave_pattern_slot( 'heading', array( 'level' => 'h1', 'size' => 'title-l' ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-m' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"\u002d\u002dwi: fit-content","classNames":"wi ly ly-fl","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-m)","gapY":"var(\u002d\u002dwphave-site-gap-size-m)","flexWrap":"no-wrap","alignVertical":"center","alignHorizontal":"center","flexDirection":"row","flexItemSizing":"auto"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-valign: center;\u002d\u002dly-halign: center;\u002d\u002dly-fl-direction: row;\u002d\u002dly-fl-itm: 0 1 auto"}} -->
' . wphave_pattern_slot( 'actions.0.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'actions.1.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'variant' => 'secondary', 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/spacer {"wphave":{"settings":{"aspectRatio":"75/1"},"styles":"\u002d\u002daspect-ratio: 75/1"}} /-->

<!-- wp:wphave/image {"wphave":{"classNames":"wi asrt ofw br","dimensions":{"width":{"custom":"100%"},"aspectRatio":{"ratio":"21/9"},"overflow":"clip"},"styles":"\u002d\u002dwi: 100%;\u002d\u002dasrt: 21/9;\u002d\u002dofw: clip;\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) 0 0;\u002d\u002dobject-position: center","frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) 0 0"}}} /-->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'hero-11',
            'tags' => array('hero'),
            'title' => __( 'Hero Wide Contrast Callout', 'wphave' ),
            'keywords' => array('hero', 'wide', 'contrast', 'callout', 'centered', 'actions', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('hero'),
                'layout' => array('centered', 'stacked', 'panel'),
                'width' => array('wide'),
                'visual' => array('color-background'),
                'content' => array('heading', 'body', 'actions'),
                'intent' => array('first-viewport', 'conversion', 'campaign'),
                'treatment' => array('strong-contrast', 'framed', 'minimal'),
                'description' => 'Wide rounded contrast hero without media, focused on a strong headline, short supporting copy and two actions.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-wide wi-in pa ofw ly ly-stk ly-co-pos bg-co bg br txta tx-co","dimensions":{"innerWidth":{"custom":"1180px"},"overflow":"clip","spacing":{"padding":"var(\u002d\u002dwphave-site-padding-4xl) var(\u002d\u002dwphave-site-spacing) var(\u002d\u002dwphave-site-padding-4xl) var(\u002d\u002dwphave-site-spacing)"}},"styles":"\u002d\u002dwi-in: 1180px;\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-4xl) var(\u002d\u002dwphave-site-spacing) var(\u002d\u002dwphave-site-padding-4xl) var(\u002d\u002dwphave-site-spacing);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-4xl);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-spacing);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-4xl);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-spacing);\u002d\u002dofw: clip;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background-contrast-10);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners);\u002d\u002dtxta: center;\u002d\u002dtx-co: var(\u002d\u002dwphave-site-color-background-subtle-10)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-spacing);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-spacing)","text":{"align":"center","colors":{"text":"var(\u002d\u002dwphave-site-color-background-subtle-10)"}},"layout":{"stacked":{"contentPosition":"center","gap":"var(\u002d\u002dwphave-site-gap-size-l)"},"type":"stacked"},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-l)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background-contrast-10)"}},"frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"},"features":{"size":"wide"}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"wi ly ly-stk ly-co-pos wi-m","dimensions":{"width":{"custom":"760px"}},"styles":"\u002d\u002dwi: 760px;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center;\u002d\u002dwi-m: 100%","mobile":{"dimensions":{"width":{"custom":"100%"}}},"layout":{"stacked":{"contentPosition":"center","gap":"var(\u002d\u002dwphave-site-gap-size-m)"},"type":"stacked"},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-m)"}} -->
' . wphave_pattern_slot( 'eyebrow', $slots ) . '

' . wphave_pattern_slot( 'heading', array( 'level' => 'h1', 'size' => 'title-l' ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-m' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"\u002d\u002dwi: fit-content","classNames":"wi ly ly-fl","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-m)","gapY":"var(\u002d\u002dwphave-site-gap-size-m)","flexWrap":"no-wrap","alignVertical":"center","alignHorizontal":"center","flexDirection":"row","flexItemSizing":"auto"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-valign: center;\u002d\u002dly-halign: center;\u002d\u002dly-fl-direction: row;\u002d\u002dly-fl-itm: 0 1 auto"}} -->
' . wphave_pattern_slot( 'actions.0.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'actions.1.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'variant' => 'secondary', 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'hero-12',
            'tags' => array('hero'),
            'title' => __( 'Hero Gallery Rail', 'wphave' ),
            'keywords' => array('hero', 'centered', 'gallery', 'image rail', 'media', 'actions', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('hero', 'gallery'),
                'layout' => array('centered', 'stacked', 'horizontal-media'),
                'width' => array('full-width'),
                'visual' => array('image-rail', 'media'),
                'content' => array('eyebrow', 'heading', 'body', 'actions', 'images'),
                'intent' => array('first-viewport', 'brand-story', 'visual-browse'),
                'treatment' => array('spacious', 'editorial', 'media-forward'),
                'description' => 'Centered hero with a compact text introduction and a wide horizontal image rail for visually rich pages.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-full wi-in pa ofw ly ly-stk ly-co-pos txta","features":{"size":"full"},"dimensions":{"innerWidth":{"custom":"1180px"},"overflow":"clip","spacing":{"padding":"var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-spacing) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-spacing)"}},"styles":"\u002d\u002dwi-in: 1180px;\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-spacing) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-spacing);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-spacing);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-spacing);\u002d\u002dofw: clip;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center;\u002d\u002dtxta: center","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-spacing);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-spacing)","text":{"align":"center"},"layout":{"stacked":{"contentPosition":"center","gap":"var(\u002d\u002dwphave-site-gap-size-4xl)"},"type":"stacked"},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-4xl)"}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"wi ly ly-stk ly-co-pos wi-m","dimensions":{"width":{"custom":"760px"}},"styles":"\u002d\u002dwi: 760px;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center;\u002d\u002dwi-m: 100%","mobile":{"dimensions":{"width":{"custom":"100%"}}},"layout":{"stacked":{"contentPosition":"center","gap":"var(\u002d\u002dwphave-site-gap-size-m)"},"type":"stacked"},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-m)"}} -->
' . wphave_pattern_slot( 'eyebrow', $slots ) . '

' . wphave_pattern_slot( 'heading', array( 'level' => 'h1', 'size' => 'title-xl' ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-l' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"\u002d\u002dwi: fit-content","classNames":"wi ly ly-fl","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-m)","gapY":"var(\u002d\u002dwphave-site-gap-size-m)","flexWrap":"no-wrap","alignVertical":"center","alignHorizontal":"center","flexDirection":"row","flexItemSizing":"auto"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-valign: center;\u002d\u002dly-halign: center;\u002d\u002dly-fl-direction: row;\u002d\u002dly-fl-itm: 0 1 auto"}} -->
' . wphave_pattern_slot( 'actions.0.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'actions.1.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'variant' => 'secondary', 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"no-shrink","alignVertical":"start","alignHorizontal":"center"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 1 0 auto;\u002d\u002dly-valign: start;\u002d\u002dly-halign: center;\u002d\u002dly-fl-direction: row"}} -->
' . wphave_pattern_slot( 'images.0.image', 'image', array( 'ratio' => '1/1', 'attrs' => array( 'wphave' => array( 'dimensions' => array( 'width' => array( 'limit' => 'max', 'custom' => '30%' ) ), 'styles' => '--wi: 30%;--asrt: 1/1;--ofw: clip;--br: var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners);--object-position: center', 'classNames' => 'wi asrt ofw br' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'images.1.image', 'image', array( 'ratio' => '1/1', 'attrs' => array( 'wphave' => array( 'dimensions' => array( 'width' => array( 'limit' => 'max', 'custom' => '30%' ) ), 'styles' => '--wi: 30%;--asrt: 1/1;--ofw: clip;--br: var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners);--object-position: center', 'classNames' => 'wi asrt ofw br' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'images.2.image', 'image', array( 'ratio' => '1/1', 'attrs' => array( 'wphave' => array( 'dimensions' => array( 'width' => array( 'limit' => 'max', 'custom' => '30%' ) ), 'styles' => '--wi: 30%;--asrt: 1/1;--ofw: clip;--br: var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners);--object-position: center', 'classNames' => 'wi asrt ofw br' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'images.3.image', 'image', array( 'ratio' => '1/1', 'attrs' => array( 'wphave' => array( 'dimensions' => array( 'width' => array( 'limit' => 'max', 'custom' => '30%' ) ), 'styles' => '--wi: 30%;--asrt: 1/1;--ofw: clip;--br: var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners);--object-position: center', 'classNames' => 'wi asrt ofw br' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'images.4.image', 'image', array( 'ratio' => '1/1', 'attrs' => array( 'wphave' => array( 'dimensions' => array( 'width' => array( 'limit' => 'max', 'custom' => '30%' ) ), 'styles' => '--wi: 30%;--asrt: 1/1;--ofw: clip;--br: var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners);--object-position: center', 'classNames' => 'wi asrt ofw br' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'images.5.image', 'image', array( 'ratio' => '1/1', 'attrs' => array( 'wphave' => array( 'dimensions' => array( 'width' => array( 'limit' => 'max', 'custom' => '30%' ) ), 'styles' => '--wi: 30%;--asrt: 1/1;--ofw: clip;--br: var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners);--object-position: center', 'classNames' => 'wi asrt ofw br' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'hero-13',
            'tags' => array('hero'),
            'title' => __( 'Hero Staggered Media Rail', 'wphave' ),
            'keywords' => array('hero', 'left aligned', 'staggered', 'gallery', 'media rail', 'actions', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('hero', 'gallery'),
                'layout' => array('asymmetric', 'stacked', 'horizontal-media'),
                'width' => array('full-width'),
                'visual' => array('staggered-images', 'media'),
                'content' => array('eyebrow', 'heading', 'body', 'actions', 'images'),
                'intent' => array('first-viewport', 'portfolio', 'brand-story'),
                'treatment' => array('editorial', 'asymmetric', 'media-forward'),
                'description' => 'Left-aligned hero introduction with generous whitespace and a staggered horizontal media rail underneath.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-full wi-in pa ofw ly ly-stk ly-co-pos txta","features":{"size":"full"},"dimensions":{"innerWidth":{"custom":"1180px"},"overflow":"clip","spacing":{"padding":"var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-spacing) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-spacing)"}},"styles":"\u002d\u002dwi-in: 1180px;\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-spacing) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-spacing);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-spacing);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-spacing);\u002d\u002dofw: clip;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center;\u002d\u002dtxta: none","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-spacing);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-spacing)","text":{"align":"none"},"layout":{"stacked":{"contentPosition":"center","gap":"var(\u002d\u002dwphave-site-gap-size-4xl)"},"type":"stacked"},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-4xl)"}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"contentPosition":"left","gap":"var(\u002d\u002dwphave-site-gap-size-m)"}},"classNames":"hd-left wi ly ly-stk ly-co-pos wi-t","styles":"\u002d\u002dwi: 60%;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: start;\u002d\u002dwi-t: 90%","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-m)","dimensions":{"width":{"limit":"max","custom":"60%"}},"features":{"horizontalDirection":"left"},"tablet":{"dimensions":{"width":{"custom":"90%"}}}}} -->
' . wphave_pattern_slot( 'eyebrow', $slots ) . '

' . wphave_pattern_slot( 'heading', array( 'level' => 'h1', 'size' => 'title-l' ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-m' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"\u002d\u002dwi: fit-content","classNames":"wi ly ly-fl","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-m)","gapY":"var(\u002d\u002dwphave-site-gap-size-m)","flexWrap":"no-wrap","alignVertical":"center","alignHorizontal":"center","flexDirection":"row","flexItemSizing":"auto"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-valign: center;\u002d\u002dly-halign: center;\u002d\u002dly-fl-direction: row;\u002d\u002dly-fl-itm: 0 1 auto"}} -->
' . wphave_pattern_slot( 'actions.0.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'actions.1.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'variant' => 'secondary', 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/spacer {"wphave":{"settings":{"aspectRatio":"75/1"},"styles":"\u002d\u002daspect-ratio: 75/1"}} /-->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"no-shrink","alignVertical":"start","alignHorizontal":"center"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 1 0 auto;\u002d\u002dly-valign: start;\u002d\u002dly-halign: center;\u002d\u002dly-fl-direction: row"}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked"},"classNames":"wi pa ly ly-stk","dimensions":{"spacing":{"padding":"0px 0px 0px 0px"},"width":{"limit":"max","custom":"30%"}},"styles":"\u002d\u002dwi: 30%;\u002d\u002dpa: 0px 0px 0px 0px;\u002d\u002dpa-top: 0px;\u002d\u002dpa-right: 0px;\u002d\u002dpa-bottom: 0px;\u002d\u002dpa-left: 0px","stylesChild":"\u002d\u002dleft-spacing-inherit: 0px;\u002d\u002dright-spacing-inherit: 0px"}} -->
<!-- wp:wphave/spacer {"wphave":{"settings":{"aspectRatio":"10/1"},"styles":"\u002d\u002daspect-ratio: 10/1"}} /-->

' . wphave_pattern_slot( 'images.0.image', 'image', array( 'ratio' => '1/1' ), $slots ) . '
<!-- /wp:wphave/group -->

' . wphave_pattern_slot( 'images.1.image', 'image', array( 'ratio' => '1/1', 'attrs' => array( 'wphave' => array( 'dimensions' => array( 'width' => array( 'limit' => 'max', 'custom' => '30%' ) ), 'styles' => '--wi: 30%;--asrt: 1/1;--ofw: clip;--br: var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners);--object-position: center', 'classNames' => 'wi asrt ofw br' ) ) ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked"},"classNames":"wi pa ly ly-stk","dimensions":{"spacing":{"padding":"0px 0px 0px 0px"},"width":{"limit":"max","custom":"30%"}},"styles":"\u002d\u002dwi: 30%;\u002d\u002dpa: 0px 0px 0px 0px;\u002d\u002dpa-top: 0px;\u002d\u002dpa-right: 0px;\u002d\u002dpa-bottom: 0px;\u002d\u002dpa-left: 0px","stylesChild":"\u002d\u002dleft-spacing-inherit: 0px;\u002d\u002dright-spacing-inherit: 0px"}} -->
<!-- wp:wphave/spacer {"wphave":{"settings":{"aspectRatio":"10/1"},"styles":"\u002d\u002daspect-ratio: 10/1"}} /-->

' . wphave_pattern_slot( 'images.2.image', 'image', array( 'ratio' => '1/1' ), $slots ) . '
<!-- /wp:wphave/group -->

' . wphave_pattern_slot( 'images.3.image', 'image', array( 'ratio' => '9/16', 'attrs' => array( 'wphave' => array( 'dimensions' => array( 'width' => array( 'limit' => 'max', 'custom' => '30%' ), 'spacing' => array( 'margin' => '-29% auto 0px auto' ) ), 'styles' => '--wi: 30%;--ma: -29% auto 0px auto;--ma-top: -29%;--ma-right: auto;--ma-bottom: 0px;--ma-left: auto;--asrt: 9/16;--ofw: clip;--br: var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners);--ma-t: 0px auto 0px auto;--ma-t-top: 0px;--ma-t-right: auto;--ma-t-bottom: 0px;--ma-t-left: auto;--asrt-t: 1/1;--object-position: center', 'classNames' => 'wi ma asrt ofw br ma-t asrt-t', 'tablet' => array( 'dimensions' => array( 'spacing' => array( 'margin' => '0px auto 0px auto' ), 'aspectRatio' => array( 'ratio' => '1/1' ) ) ) ) ) ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked"},"classNames":"wi pa ly ly-stk","dimensions":{"spacing":{"padding":"0px 0px 0px 0px"},"width":{"custom":"30%"}},"styles":"\u002d\u002dwi: 30%;\u002d\u002dpa: 0px 0px 0px 0px;\u002d\u002dpa-top: 0px;\u002d\u002dpa-right: 0px;\u002d\u002dpa-bottom: 0px;\u002d\u002dpa-left: 0px","stylesChild":"\u002d\u002dleft-spacing-inherit: 0px;\u002d\u002dright-spacing-inherit: 0px"}} -->
<!-- wp:wphave/spacer {"wphave":{"settings":{"aspectRatio":"10/1"},"styles":"\u002d\u002daspect-ratio: 10/1"}} /-->

' . wphave_pattern_slot( 'images.4.image', 'image', array( 'ratio' => '1/1' ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        return $patterns;

	}

endif;
