<?php

/**
 * Functions to group gallery section block patterns.
 */

if ( ! function_exists( 'wphave_block_pattern_collection_gallery_sections' ) ) :

	function wphave_block_pattern_collection_gallery_sections( $args = array() ) {

        $content_width = isset( $args['width'] ) ? (int) $args['width'] : 1300;
        $slots = is_array( $args['slots'] ?? null ) ? $args['slots'] : array();
        $patterns = array();

        $patterns[] = array(
            'key' => 'gallery-section-1',
            'tags' => array('gallery-sections'),
            'title' => __( 'Gallery Section Editorial Masonry', 'wphave' ),
            'keywords' => array('gallery', 'section', 'masonry', 'editorial', 'images', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('gallery', 'section', 'visual-story'),
                'layout' => array('split', 'grid', 'masonry'),
                'width' => array('wide'),
                'visual' => array('image-grid', 'gallery'),
                'content' => array('eyebrow', 'heading', 'body', 'actions', 'images'),
                'intent' => array('visual-proof', 'brand-story', 'portfolio'),
                'treatment' => array('editorial', 'spacious', 'visual-impact'),
                'description' => 'Editorial gallery section with a text introduction and an asymmetric image grid.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"wi-in ofw ly ly-gr ly-col-2 ly-gr-m ly-m-col-1","dimensions":{"overflow":"clip","innerWidth":{"limit":"max","custom":"100%"}},"styles":"--wi-in: 100%;--ofw: clip","layout":{"type":"grid","grid":{"gapX":"var(--wphave-site-gap-size-4xl)","gapY":"var(--wphave-site-gap-size-3xl)","columns":2,"keepColumns":"auto","gridRowHeight":"auto","alignVertical":"center","alignHorizontal":"space-between"}},"stylesLayout":"--ly-row-gap: var(--wphave-site-gap-size-3xl);--ly-column-gap: var(--wphave-site-gap-size-4xl);--ly-col: 2;--ly-valign: center;--ly-halign: space-between;--ly-m-row-gap: var(--wphave-site-gap-size-3xl);--ly-m-column-gap: var(--wphave-site-gap-size-3xl);--ly-m-col: 1;--ly-m-valign: stretch;--ly-m-halign: space-between","mobile":{"layout":{"grid":{"columns":1}}}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"wi ly ly-stk ly-co-pos","dimensions":{"width":{"limit":"max","custom":"680px"}},"styles":"--wi: 680px;--ly-co-pos-h: start;--ly-co-pos-v: center","layout":{"type":"stacked","stacked":{"gap":"var(--wphave-site-gap-size-m)","contentPosition":"left"}},"stylesLayout":"--ly-gap: var(--wphave-site-gap-size-m)"}} -->
' . wphave_pattern_slot( 'eyebrow', $slots ) . '

' . wphave_pattern_slot( 'heading', array( 'level' => 'h2', 'size' => 'title-l' ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-m' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"--wi: fit-content","classNames":"wi ly ly-fl ly-fl-wp","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-gap-size-m)","gapY":"var(--wphave-site-gap-size-s)","flexWrap":"wrap","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-gap-size-m);--ly-row-gap: var(--wphave-site-gap-size-s);--ly-fl-wrap: wrap;--ly-fl-direction: row;--ly-fl-itm: 0 1 auto;--ly-valign: center"}} -->
' . wphave_pattern_slot( 'actions.0.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'actions.1.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'variant' => 'secondary', 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-gr ly-col-2 ly-nowrap ly-gr-m ly-m-col-2","layout":{"type":"grid","grid":{"gapX":"var(--wphave-site-gap-size-m)","gapY":"var(--wphave-site-gap-size-m)","columns":2,"keepColumns":"nowrap","gridRowHeight":"auto","alignVertical":"stretch","alignHorizontal":"space-between"}},"stylesLayout":"--ly-row-gap: var(--wphave-site-gap-size-m);--ly-column-gap: var(--wphave-site-gap-size-m);--ly-col: 2;--ly-valign: stretch;--ly-halign: space-between;--ly-m-row-gap: var(--wphave-site-gap-size-m);--ly-m-column-gap: var(--wphave-site-gap-size-m);--ly-m-col: 2;--ly-m-valign: stretch;--ly-m-halign: space-between","mobile":{"layout":{"grid":{"columns":2}}}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk","layout":{"type":"stacked","stacked":{"gap":"var(--wphave-site-gap-size-m)"}},"stylesLayout":"--ly-gap: var(--wphave-site-gap-size-m)"}} -->
' . wphave_pattern_slot( 'items.0.image', 'image', array( 'ratio' => '4/5' ), $slots ) . '

' . wphave_pattern_slot( 'items.1.image', 'image', array( 'ratio' => '1/1' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk","layout":{"type":"stacked","stacked":{"gap":"var(--wphave-site-gap-size-m)"}},"stylesLayout":"--ly-gap: var(--wphave-site-gap-size-m)"}} -->
' . wphave_pattern_slot( 'spacer', 'spacer', array( 'ratio' => '8/1' ), $slots ) . '

' . wphave_pattern_slot( 'items.2.image', 'image', array( 'ratio' => '1/1' ), $slots ) . '

' . wphave_pattern_slot( 'items.3.image', 'image', array( 'ratio' => '4/5' ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'gallery-section-2',
            'tags' => array('gallery-sections'),
            'title' => __( 'Gallery Section Horizontal Image Rail', 'wphave' ),
            'keywords' => array('gallery', 'section', 'horizontal rail', 'image rail', 'portfolio', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('gallery', 'section', 'visual-story'),
                'layout' => array('stacked', 'flex', 'rail'),
                'width' => array('wide'),
                'visual' => array('image-rail', 'gallery'),
                'content' => array('heading', 'body', 'actions', 'images'),
                'intent' => array('portfolio', 'visual-proof', 'brand-story'),
                'treatment' => array('structured', 'soft-surface', 'visual-impact'),
                'description' => 'Wide gallery section with a horizontal image rail above text and actions.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-wide wi-in pa ofw ly ly-stk bg-co bg br","dimensions":{"overflow":"clip","innerWidth":{"limit":"max","custom":"100%"},"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl)"}},"styles":"\u002d\u002dwi-in: 100%;\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background-contrast-1);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-3xl)"}},"background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background-contrast-1)"}},"stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-xl)","frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"},"features":{"size":"wide"},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-3xl)"}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"no-shrink","alignVertical":"stretch","alignHorizontal":"start"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 1 0 auto;\u002d\u002dly-valign: stretch;\u002d\u002dly-halign: start;\u002d\u002dly-fl-direction: row","classNames":"ly ly-fl"}} -->
' . wphave_pattern_slot( 'items.0.image', 'image', array( 'ratio' => '3/4', 'attrs' => array( 'wphave' => array( 'dimensions' => array( 'width' => array( 'limit' => 'max', 'custom' => '21%' ) ), 'styles' => '--wi: 21%;--asrt: 3/4;--ofw: clip;--br: var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners);--object-position: center', 'classNames' => 'wi asrt ofw br' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'items.1.image', 'image', array( 'ratio' => '4/3', 'attrs' => array( 'wphave' => array( 'dimensions' => array( 'width' => array( 'limit' => 'max', 'custom' => '31%' ) ), 'styles' => '--wi: 31%;--asrt: 4/3;--ofw: clip;--br: var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners);--object-position: center', 'classNames' => 'wi asrt ofw br' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'items.2.image', 'image', array( 'ratio' => '1/1', 'attrs' => array( 'wphave' => array( 'dimensions' => array( 'width' => array( 'limit' => 'max', 'custom' => '24%' ) ), 'styles' => '--wi: 24%;--asrt: 1/1;--ofw: clip;--br: var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners);--object-position: center', 'classNames' => 'wi asrt ofw br' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'items.3.image', 'image', array( 'ratio' => '16/9', 'attrs' => array( 'wphave' => array( 'dimensions' => array( 'width' => array( 'limit' => 'max', 'custom' => '25%' ) ), 'styles' => '--wi: 25%;--asrt: 16/9;--ofw: clip;--br: var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners);--object-position: center', 'classNames' => 'wi asrt ofw br' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-l)"}},"classNames":"wi ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-l)","dimensions":{"width":{"limit":"max","custom":"999px"}},"styles":"\u002d\u002dwi: 999px"}} -->
' . wphave_pattern_slot( 'heading', array( 'level' => 'h2', 'size' => 'title-m' ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-m' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"\u002d\u002dwi: fit-content","classNames":"wi ly ly-fl","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-m)","gapY":"var(\u002d\u002dwphave-site-gap-size-m)","flexWrap":"no-wrap","flexDirection":"row","flexItemSizing":"auto"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-direction: row;\u002d\u002dly-fl-itm: 0 1 auto"}} -->
' . wphave_pattern_slot( 'actions.0.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'actions.1.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'variant' => 'secondary', 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'gallery-section-3',
            'tags' => array('gallery-sections'),
            'title' => __( 'Gallery Section Simple Image Grid', 'wphave' ),
            'keywords' => array('gallery', 'section', 'image grid', 'three columns', 'portfolio', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('gallery', 'section', 'visual-proof'),
                'layout' => array('stacked', 'grid'),
                'width' => array('wide'),
                'visual' => array('image-grid', 'gallery'),
                'content' => array('heading', 'body', 'images'),
                'intent' => array('portfolio', 'visual-proof', 'showcase'),
                'treatment' => array('structured', 'soft-surface', 'minimal'),
                'description' => 'Simple gallery section with an intro and a clean three-column image grid.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"pa ofw ly ly-stk bg-co bg br","dimensions":{"overflow":"clip","spacing":{"padding":"var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl)"}},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background-contrast-1);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","layout":{"type":"stacked"},"background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background-contrast-1)"}},"stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-xl)","frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-l)"}},"classNames":"wi ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-l)","dimensions":{"width":{"limit":"max","custom":"999px"}},"styles":"\u002d\u002dwi: 999px"}} -->
' . wphave_pattern_slot( 'heading', array( 'level' => 'h2', 'size' => 'title-m' ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-m' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"grid","grid":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","columns":3,"keepColumns":"nowrap","gridRowHeight":"auto","alignVertical":"stretch","alignHorizontal":"stretch"}},"stylesLayout":"\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-col: 3;\u002d\u002dly-valign: stretch;\u002d\u002dly-halign: stretch","classNames":"ly ly-gr ly-nowrap"}} -->
' . wphave_pattern_slot( 'items.0.image', 'image', array( 'ratio' => '1/1' ), $slots ) . '

' . wphave_pattern_slot( 'items.1.image', 'image', array( 'ratio' => '1/1' ), $slots ) . '

' . wphave_pattern_slot( 'items.2.image', 'image', array( 'ratio' => '1/1' ), $slots ) . '

' . wphave_pattern_slot( 'items.3.image', 'image', array( 'ratio' => '1/1' ), $slots ) . '

' . wphave_pattern_slot( 'items.4.image', 'image', array( 'ratio' => '1/1' ), $slots ) . '

' . wphave_pattern_slot( 'items.5.image', 'image', array( 'ratio' => '1/1' ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'gallery-section-4',
            'tags' => array('gallery-sections'),
            'title' => __( 'Gallery Section Animated Marquee', 'wphave' ),
            'keywords' => array('gallery', 'section', 'marquee', 'animated rail', 'image carousel', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('gallery', 'section', 'visual-story'),
                'layout' => array('stacked', 'marquee', 'rail'),
                'width' => array('full-width'),
                'visual' => array('image-rail', 'gallery', 'motion'),
                'content' => array('heading', 'body', 'images'),
                'intent' => array('portfolio', 'visual-proof', 'brand-story'),
                'treatment' => array('spacious', 'visual-impact', 'cinematic'),
                'description' => 'Full-width gallery section with two animated image rails and centered introductory copy.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-full wi-in pa ofw ly ly-stk","dimensions":{"overflow":"clip","spacing":{"padding":"var(\u002d\u002dwphave-site-padding-xxl) 0 var(\u002d\u002dwphave-site-padding-xxl) 0"},"innerWidth":{"limit":"max","custom":"100%"}},"styles":"\u002d\u002dwi-in: 100%;\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-xxl) 0 var(\u002d\u002dwphave-site-padding-xxl) 0;\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-right: 0;\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-left: 0;\u002d\u002dofw: clip","layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-4xl)"}},"features":{"size":"full"},"stylesChild":"\u002d\u002dleft-spacing-inherit: 0;\u002d\u002dright-spacing-inherit: 0","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-4xl)"}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-l)"}},"classNames":"bsz-content hd-center pa ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-l)","features":{"size":"content","horizontalDirection":"center"},"dimensions":{"spacing":{"padding":"0 var(\u002d\u002dwphave-site-padding-xxl) 0 var(\u002d\u002dwphave-site-padding-xxl)"}},"styles":"\u002d\u002dpa: 0 var(\u002d\u002dwphave-site-padding-xxl) 0 var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-top: 0;\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-bottom: 0;\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-xxl)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-xxl)"}} -->
' . wphave_pattern_slot( 'heading', array( 'level' => 'h2', 'size' => 'title-m', 'attrs' => array( 'wphave' => array( 'dimensions' => array( 'width' => array( 'custom' => '17ch' ) ), 'styles' => '--wi: 17ch', 'classNames' => 'wi tf-fs tf-fs-title-m' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-m', 'attrs' => array( 'wphave' => array( 'dimensions' => array( 'width' => array( 'limit' => 'max', 'custom' => '694px' ) ), 'styles' => '--wi: 694px', 'classNames' => 'wi tf-fs tf-fs-text-m' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"animated","flexDirection":"row","flexItemSizing":"auto","alignVertical":"start","alignHorizontal":"start","animation":{"duration":"31s"}}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: start;\u002d\u002dly-halign: start;\u002d\u002dly-fl-direction: row;\u002d\u002dly-fl-ani-dur: 31s","classNames":"ofw ly ly-fl ly-fl-ani","dimensions":{"overflow":"hidden"},"styles":"\u002d\u002dofw: hidden"}} -->
' . wphave_pattern_slot( 'items.0.image', 'image', array( 'ratio' => '4/3' ), $slots ) . '

' . wphave_pattern_slot( 'items.1.image', 'image', array( 'ratio' => '4/3' ), $slots ) . '

' . wphave_pattern_slot( 'items.2.image', 'image', array( 'ratio' => '4/3' ), $slots ) . '

' . wphave_pattern_slot( 'items.3.image', 'image', array( 'ratio' => '4/3' ), $slots ) . '

' . wphave_pattern_slot( 'items.4.image', 'image', array( 'ratio' => '4/3' ), $slots ) . '

' . wphave_pattern_slot( 'items.5.image', 'image', array( 'ratio' => '4/3' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"animated","flexDirection":"row","flexItemSizing":"auto","alignVertical":"start","alignHorizontal":"start","animation":{"duration":"31s","direction":"reverse"}}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: start;\u002d\u002dly-halign: start;\u002d\u002dly-fl-direction: row;\u002d\u002dly-fl-ani-dur: 31s;\u002d\u002dly-fl-ani-dir: reverse","classNames":"ofw ly ly-fl ly-fl-ani","dimensions":{"overflow":"hidden"},"styles":"\u002d\u002dofw: hidden"}} -->
' . wphave_pattern_slot( 'items.6.image', 'image', array( 'ratio' => '4/3' ), $slots ) . '

' . wphave_pattern_slot( 'items.7.image', 'image', array( 'ratio' => '4/3' ), $slots ) . '

' . wphave_pattern_slot( 'items.8.image', 'image', array( 'ratio' => '4/3' ), $slots ) . '

' . wphave_pattern_slot( 'items.9.image', 'image', array( 'ratio' => '4/3' ), $slots ) . '

' . wphave_pattern_slot( 'items.10.image', 'image', array( 'ratio' => '4/3' ), $slots ) . '

' . wphave_pattern_slot( 'items.11.image', 'image', array( 'ratio' => '4/3' ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'gallery-section-5',
            'tags' => array('gallery-sections'),
            'title' => __( 'Gallery Section Featured Left Mosaic', 'wphave' ),
            'keywords' => array('gallery', 'section', 'featured image', 'mosaic', 'grid areas', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('gallery', 'section', 'visual-proof'),
                'layout' => array('grid-areas', 'featured', 'mosaic'),
                'width' => array('full-width'),
                'visual' => array('image-grid', 'gallery', 'large-media'),
                'content' => array('heading', 'body', 'images'),
                'intent' => array('portfolio', 'visual-proof', 'product-showcase'),
                'treatment' => array('structured', 'spacious', 'visual-impact'),
                'description' => 'Full-width gallery section with a large featured image on the left and two supporting images on the right.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-full pa ofw ly ly-stk","dimensions":{"overflow":"clip","spacing":{"padding":"var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-spacing) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-spacing)"}},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-spacing) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-spacing);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-spacing);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-spacing);\u002d\u002dofw: clip","layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-4xl)"}},"features":{"size":"full"},"stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-spacing);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-spacing)","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-4xl)"}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-l)"}},"classNames":"bsz-content hd-center ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-l)","features":{"size":"content","horizontalDirection":"center"}}} -->
' . wphave_pattern_slot( 'heading', array( 'level' => 'h2', 'size' => 'title-m', 'attrs' => array( 'wphave' => array( 'dimensions' => array( 'width' => array( 'custom' => '17ch' ) ), 'styles' => '--wi: 17ch', 'classNames' => 'wi tf-fs tf-fs-title-m' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-m', 'attrs' => array( 'wphave' => array( 'dimensions' => array( 'width' => array( 'limit' => 'max', 'custom' => '694px' ) ), 'styles' => '--wi: 694px', 'classNames' => 'wi tf-fs tf-fs-text-m' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"gridAreas","gridAreas":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","areas":{"columns":3,"rows":2,"areas":[{"id":"c1","label":"1","x":1,"y":1,"w":2,"h":2},{"id":"c2","label":"2","x":3,"y":1,"w":1,"h":1},{"id":"c3","label":"3","x":3,"y":2,"w":1,"h":1}],"rowHeight":"auto"},"alignVertical":"stretch","alignHorizontal":"stretch"}},"stylesLayout":"\u002d\u002dly-gra-template: \u0022c1 c1 c2\u0022 \u0022c1 c1 c3\u0022;\u002d\u002dly-gra-columns: 3;\u002d\u002dly-gra-rows: 2;\u002d\u002dly-gra-row-height: minmax(min-content, auto);\u002d\u002dly-gra-area-1: c1;\u002d\u002dly-gra-area-2: c2;\u002d\u002dly-gra-area-3: c3;\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-valign: stretch;\u002d\u002dly-halign: stretch","classNames":"ofw ly ly-gra","dimensions":{"overflow":"hidden"},"styles":"\u002d\u002dofw: hidden"}} -->
' . wphave_pattern_slot( 'items.0.image', 'image', array( 'ratio' => '4/3' ), $slots ) . '

' . wphave_pattern_slot( 'items.1.image', 'image', array( 'ratio' => '1/1' ), $slots ) . '

' . wphave_pattern_slot( 'items.2.image', 'image', array( 'ratio' => '1/1' ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'gallery-section-6',
            'tags' => array('gallery-sections'),
            'title' => __( 'Gallery Section Featured Right Mosaic', 'wphave' ),
            'keywords' => array('gallery', 'section', 'featured image', 'mosaic', 'grid areas', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('gallery', 'section', 'visual-proof'),
                'layout' => array('grid-areas', 'featured', 'mosaic'),
                'width' => array('full-width'),
                'visual' => array('image-grid', 'gallery', 'large-media'),
                'content' => array('heading', 'body', 'images'),
                'intent' => array('portfolio', 'visual-proof', 'product-showcase'),
                'treatment' => array('structured', 'spacious', 'visual-impact'),
                'description' => 'Full-width gallery section with two supporting images on the left and a large featured image on the right.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-full pa ofw ly ly-stk","dimensions":{"overflow":"clip","spacing":{"padding":"var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-spacing) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-spacing)"}},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-spacing) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-spacing);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-spacing);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-spacing);\u002d\u002dofw: clip","layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-4xl)"}},"features":{"size":"full"},"stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-spacing);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-spacing)","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-4xl)"}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-l)"}},"classNames":"bsz-content hd-center ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-l)","features":{"size":"content","horizontalDirection":"center"}}} -->
' . wphave_pattern_slot( 'heading', array( 'level' => 'h2', 'size' => 'title-m', 'attrs' => array( 'wphave' => array( 'dimensions' => array( 'width' => array( 'custom' => '17ch' ) ), 'styles' => '--wi: 17ch', 'classNames' => 'wi tf-fs tf-fs-title-m' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-m', 'attrs' => array( 'wphave' => array( 'dimensions' => array( 'width' => array( 'limit' => 'max', 'custom' => '694px' ) ), 'styles' => '--wi: 694px', 'classNames' => 'wi tf-fs tf-fs-text-m' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"gridAreas","gridAreas":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","areas":{"columns":3,"rows":2,"areas":[{"id":"c1","label":"1","x":1,"y":1,"w":1,"h":1},{"id":"c2","label":"2","x":1,"y":2,"w":1,"h":1},{"id":"c3","label":"3","x":2,"y":1,"w":2,"h":2}],"rowHeight":"auto"},"alignVertical":"stretch","alignHorizontal":"stretch"}},"stylesLayout":"\u002d\u002dly-gra-template: \u0022c1 c3 c3\u0022 \u0022c2 c3 c3\u0022;\u002d\u002dly-gra-columns: 3;\u002d\u002dly-gra-rows: 2;\u002d\u002dly-gra-row-height: minmax(min-content, auto);\u002d\u002dly-gra-area-1: c1;\u002d\u002dly-gra-area-2: c2;\u002d\u002dly-gra-area-3: c3;\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-valign: stretch;\u002d\u002dly-halign: stretch","classNames":"ofw ly ly-gra","dimensions":{"overflow":"hidden"},"styles":"\u002d\u002dofw: hidden"}} -->
' . wphave_pattern_slot( 'items.0.image', 'image', array( 'ratio' => '1/1' ), $slots ) . '

' . wphave_pattern_slot( 'items.1.image', 'image', array( 'ratio' => '1/1' ), $slots ) . '

' . wphave_pattern_slot( 'items.2.image', 'image', array( 'ratio' => '4/3' ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        return $patterns;

	}

endif;
