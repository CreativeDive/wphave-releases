<?php

/**
 * Functions to group feature list section block patterns.
 */

if ( ! function_exists( 'wphave_block_pattern_collection_feature_list_section' ) ) :

	function wphave_block_pattern_collection_feature_list_section( $args = array() ) {

        $content_width = isset( $args['width'] ) ? (int) $args['width'] : 1300;
        $slots = is_array( $args['slots'] ?? null ) ? $args['slots'] : array();
        $patterns = array();

        $patterns[] = array(
            'key' => 'feature-list-section-1',
            'tags' => array('feature-list-section'),
            'title' => __( 'Feature List Centered Six Cards', 'wphave' ),
            'keywords' => array('features', 'feature list', 'centered', 'six cards', 'icons', 'grid', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('feature-grid', 'section', 'content'),
                'layout' => array('centered', 'grid', 'compact-card'),
                'width' => array('wide'),
                'visual' => array('icon', 'cards'),
                'content' => array('heading', 'body', 'items', 'icons'),
                'intent' => array('feature-summary', 'explanation'),
                'treatment' => array('structured', 'spacious', 'soft-surface'),
                'description' => 'Centered feature list section with six icon-led cards for capabilities, benefits or service highlights.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"wi-in ofw ly ly-stk","dimensions":{"overflow":"clip","innerWidth":{"limit":"max","custom":"100%"}},"styles":"\u002d\u002dwi-in: 100%;\u002d\u002dofw: clip","layout":{"type":"stacked"},"mobile":{"layout":{"gridAreas":{"areas":{"columns":1,"rows":3,"areas":[{"id":"c1","label":"1","x":1,"y":1,"w":1,"h":1},{"id":"c2","label":"2","x":1,"y":3,"w":1,"h":1}],"rowHeight":"auto"}},"grid":{"columns":1}}}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)","contentPosition":"center"}},"classNames":"hd-center wi pa ly ly-stk ly-co-pos txta","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"width":{"limit":"max","custom":"999px"},"spacing":{"padding":"0px 0px 0px 0px"}},"styles":"\u002d\u002dwi: 999px;\u002d\u002dpa: 0px 0px 0px 0px;\u002d\u002dpa-top: 0px;\u002d\u002dpa-right: 0px;\u002d\u002dpa-bottom: 0px;\u002d\u002dpa-left: 0px;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center;\u002d\u002dtxta: center","features":{"horizontalDirection":"center"},"stylesChild":"\u002d\u002dleft-spacing-inherit: 0px;\u002d\u002dright-spacing-inherit: 0px","text":{"align":"center"}}} -->
' . wphave_pattern_slot( 'heading', array( 'level' => 'h2', 'size' => 'title-l' ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-m' ), $slots ) . '
<!-- /wp:wphave/group -->

' . wphave_pattern_slot( 'spacer', 'spacer', array( 'ratio' => '75/1' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"grid","grid":{"gapX":"var(\u002d\u002dwphave-site-gap-size-3xl)","gapY":"var(\u002d\u002dwphave-site-gap-size-3xl)","columns":3,"keepColumns":"nowrap","gridRowHeight":"auto","alignVertical":"stretch","alignHorizontal":"space-between"}},"classNames":"ly ly-gr ly-nowrap ly-gr-m ly-m-col-1","stylesLayout":"\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-col: 3;\u002d\u002dly-valign: stretch;\u002d\u002dly-halign: space-between;\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-m-col: 1;\u002d\u002dly-m-valign: stretch;\u002d\u002dly-m-halign: space-between","mobile":{"layout":{"grid":{"columns":1}}}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"pa ofw ly ly-stk bg-co bg br","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m)"},"overflow":"clip"},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background-contrast-1);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-m)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background-contrast-1)"}},"frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"}}} -->
' . wphave_pattern_slot( 'items.0.icon', 'icon', array(), $slots ) . '

' . wphave_pattern_slot( 'items.0.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.0.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"pa ofw ly ly-stk bg-co bg br","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m)"},"overflow":"clip"},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-m)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background)"}},"frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"}}} -->
' . wphave_pattern_slot( 'items.1.icon', 'icon', array(), $slots ) . '

' . wphave_pattern_slot( 'items.1.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.1.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"pa ofw ly ly-stk bg-co bg br","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m)"},"overflow":"clip"},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background-contrast-1);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-m)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background-contrast-1)"}},"frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"}}} -->
' . wphave_pattern_slot( 'items.2.icon', 'icon', array(), $slots ) . '

' . wphave_pattern_slot( 'items.2.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.2.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"pa ofw ly ly-stk bg-co bg br","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m)"},"overflow":"clip"},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-m)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background)"}},"frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"}}} -->
' . wphave_pattern_slot( 'items.3.icon', 'icon', array(), $slots ) . '

' . wphave_pattern_slot( 'items.3.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.3.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"pa ofw ly ly-stk bg-co bg br","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m)"},"overflow":"clip"},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background-contrast-1);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-m)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background-contrast-1)"}},"frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"}}} -->
' . wphave_pattern_slot( 'items.4.icon', 'icon', array(), $slots ) . '

' . wphave_pattern_slot( 'items.4.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.4.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"pa ofw ly ly-stk bg-co bg br","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m)"},"overflow":"clip"},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-m)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background)"}},"frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"}}} -->
' . wphave_pattern_slot( 'items.5.icon', 'icon', array(), $slots ) . '

' . wphave_pattern_slot( 'items.5.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.5.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'feature-list-section-2',
            'tags' => array('feature-list-section'),
            'title' => __( 'Feature List Split Action Stack', 'wphave' ),
            'keywords' => array('features', 'feature list', 'split', 'actions', 'single column', 'icons', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('feature-grid', 'section', 'content', 'cta'),
                'layout' => array('split', 'grid', 'list'),
                'width' => array('wide'),
                'visual' => array('icon', 'cards'),
                'content' => array('heading', 'body', 'actions', 'items', 'icons'),
                'intent' => array('feature-summary', 'explanation', 'conversion-support'),
                'treatment' => array('editorial', 'structured', 'spacious'),
                'description' => 'Split feature list section with an action-led intro and three stacked feature cards.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"wi-in ofw ly ly-gr ly-col-2 ly-gr-m ly-m-col-1","dimensions":{"overflow":"clip","innerWidth":{"limit":"max","custom":"100%"}},"styles":"\u002d\u002dwi-in: 100%;\u002d\u002dofw: clip","layout":{"type":"grid","grid":{"gapX":"var(\u002d\u002dwphave-site-gap-size-4xl)","gapY":"var(\u002d\u002dwphave-site-gap-size-4xl)","columns":2,"keepColumns":"auto","gridRowHeight":"auto","alignVertical":"stretch","alignHorizontal":"space-between"}},"mobile":{"layout":{"gridAreas":{"areas":{"columns":1,"rows":3,"areas":[{"id":"c1","label":"1","x":1,"y":1,"w":1,"h":1},{"id":"c2","label":"2","x":1,"y":3,"w":1,"h":1}],"rowHeight":"auto"}},"grid":{"columns":1}}},"stylesLayout":"\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-col: 2;\u002d\u002dly-valign: stretch;\u002d\u002dly-halign: space-between;\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-m-col: 1;\u002d\u002dly-m-valign: stretch;\u002d\u002dly-m-halign: space-between"}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)","contentPosition":"left"}},"classNames":"hd-center wi pa ly ly-stk ly-co-pos txta","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"width":{"limit":"max","custom":"999px"},"spacing":{"padding":"0px 0px 0px 0px"}},"styles":"\u002d\u002dwi: 999px;\u002d\u002dpa: 0px 0px 0px 0px;\u002d\u002dpa-top: 0px;\u002d\u002dpa-right: 0px;\u002d\u002dpa-bottom: 0px;\u002d\u002dpa-left: 0px;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: start;\u002d\u002dtxta: none","features":{"horizontalDirection":"center"},"stylesChild":"\u002d\u002dleft-spacing-inherit: 0px;\u002d\u002dright-spacing-inherit: 0px","text":{"align":"none"}}} -->
' . wphave_pattern_slot( 'heading', array( 'level' => 'h2', 'size' => 'title-l' ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-m' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"\u002d\u002dwi: fit-content","classNames":"wi ly ly-fl","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-m)","gapY":"var(\u002d\u002dwphave-site-gap-size-m)","flexWrap":"no-wrap","flexDirection":"row","flexItemSizing":"auto"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-direction: row;\u002d\u002dly-fl-itm: 0 1 auto"}} -->
' . wphave_pattern_slot( 'actions.0.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'size' => '0' ), 'styles' => '\u002d\u002dbtn-size-scale: 0' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'actions.1.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'variant' => 'secondary', 'size' => '0' ), 'styles' => '\u002d\u002dbtn-size-scale: 0' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"grid","grid":{"gapX":"var(\u002d\u002dwphave-site-gap-size-3xl)","gapY":"var(\u002d\u002dwphave-site-gap-size-3xl)","columns":1,"keepColumns":"nowrap","gridRowHeight":"auto","alignVertical":"stretch","alignHorizontal":"space-between"}},"classNames":"ly ly-gr ly-nowrap ly-gr-m ly-m-col-1","stylesLayout":"\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-col: 1;\u002d\u002dly-valign: stretch;\u002d\u002dly-halign: space-between;\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-m-col: 1;\u002d\u002dly-m-valign: stretch;\u002d\u002dly-m-halign: space-between","mobile":{"layout":{"grid":{"columns":1}}}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"pa ofw ly ly-stk bg-co bg br","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m)"},"overflow":"clip"},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-m)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background)"}},"frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"}}} -->
' . wphave_pattern_slot( 'items.0.icon', 'icon', array(), $slots ) . '

' . wphave_pattern_slot( 'items.0.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.0.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"pa ofw ly ly-stk bg-co bg br","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m)"},"overflow":"clip"},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background-contrast-1);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-m)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background-contrast-1)"}},"frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"}}} -->
' . wphave_pattern_slot( 'items.1.icon', 'icon', array(), $slots ) . '

' . wphave_pattern_slot( 'items.1.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.1.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"pa ofw ly ly-stk bg-co bg br","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m)"},"overflow":"clip"},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-m)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background)"}},"frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"}}} -->
' . wphave_pattern_slot( 'items.2.icon', 'icon', array(), $slots ) . '

' . wphave_pattern_slot( 'items.2.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.2.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'feature-list-section-3',
            'tags' => array('feature-list-section'),
            'title' => __( 'Feature List Editorial Split', 'wphave' ),
            'keywords' => array('features', 'feature list', 'editorial', 'split', 'icons', 'actions', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('feature-grid', 'section', 'content'),
                'layout' => array('split', 'grid', 'list'),
                'width' => array('wide'),
                'visual' => array('icon', 'list'),
                'content' => array('heading', 'body', 'actions', 'items', 'icons'),
                'intent' => array('feature-summary', 'explanation', 'conversion-support'),
                'treatment' => array('editorial', 'minimal', 'spacious'),
                'description' => 'Editorial split feature section with a compact intro, action buttons and four icon-led feature items.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"wi-in ofw ly ly-gr ly-col-2 ly-gr-m ly-m-col-1","dimensions":{"overflow":"clip","innerWidth":{"limit":"max","custom":"100%"}},"styles":"\u002d\u002dwi-in: 100%;\u002d\u002dofw: clip","layout":{"type":"grid","grid":{"gapX":"var(\u002d\u002dwphave-site-gap-size-4xl)","gapY":"var(\u002d\u002dwphave-site-gap-size-4xl)","columns":2,"keepColumns":"auto","gridRowHeight":"auto","alignVertical":"center","alignHorizontal":"space-between"}},"stylesLayout":"\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-col: 2;\u002d\u002dly-valign: center;\u002d\u002dly-halign: space-between;\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-m-col: 1;\u002d\u002dly-m-valign: center;\u002d\u002dly-m-halign: space-between","mobile":{"layout":{"gridAreas":{"areas":{"columns":1,"rows":3,"areas":[{"id":"c1","label":"1","x":1,"y":1,"w":1,"h":1},{"id":"c2","label":"2","x":1,"y":3,"w":1,"h":1}],"rowHeight":"auto"}},"grid":{"columns":1}}}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked"},"classNames":"ly ly-stk"}} -->
' . wphave_pattern_slot( 'heading', array( 'level' => 'h2', 'size' => 'title-m' ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-m' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"\u002d\u002dwi: fit-content","classNames":"wi ly ly-fl","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-m)","gapY":"var(\u002d\u002dwphave-site-gap-size-m)","flexWrap":"no-wrap","flexDirection":"row","flexItemSizing":"auto"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-direction: row;\u002d\u002dly-fl-itm: 0 1 auto"}} -->
' . wphave_pattern_slot( 'actions.0.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'size' => '0' ), 'styles' => '\u002d\u002dbtn-size-scale: 0' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'actions.1.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'variant' => 'secondary', 'size' => '0' ), 'styles' => '\u002d\u002dbtn-size-scale: 0' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"grid","grid":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","columns":2,"keepColumns":"nowrap","gridRowHeight":"auto","alignVertical":"stretch","alignHorizontal":"space-between"}},"classNames":"ly ly-gr ly-nowrap ly-gr-m ly-m-col-1","stylesLayout":"\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-col: 2;\u002d\u002dly-valign: stretch;\u002d\u002dly-halign: space-between;\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-col: 1;\u002d\u002dly-m-valign: stretch;\u002d\u002dly-m-halign: space-between","mobile":{"layout":{"grid":{"columns":1}}}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'items.0.icon', 'icon', array(), $slots ) . '

' . wphave_pattern_slot( 'items.0.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.0.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'items.1.icon', 'icon', array(), $slots ) . '

' . wphave_pattern_slot( 'items.1.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.1.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'items.2.icon', 'icon', array(), $slots ) . '

' . wphave_pattern_slot( 'items.2.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.2.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'items.3.icon', 'icon', array(), $slots ) . '

' . wphave_pattern_slot( 'items.3.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.3.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'feature-list-section-4',
            'tags' => array('feature-list-section'),
            'title' => __( 'Feature List Wide Two Column Cards', 'wphave' ),
            'keywords' => array('features', 'feature list', 'wide', 'two column', 'cards', 'icons', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('feature-grid', 'section', 'content'),
                'layout' => array('stacked', 'grid', 'wide-card'),
                'width' => array('wide'),
                'visual' => array('icon', 'cards'),
                'content' => array('heading', 'body', 'actions', 'items', 'icons'),
                'intent' => array('feature-summary', 'explanation', 'conversion-support'),
                'treatment' => array('soft-surface', 'structured', 'spacious'),
                'description' => 'Wide soft-surface feature section with intro actions and four icon cards in a two-column grid.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-wide wi-in pa ofw ly ly-stk bg-co bg br","dimensions":{"overflow":"clip","innerWidth":{"limit":"max","custom":"100%"},"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl)"}},"styles":"\u002d\u002dwi-in: 100%;\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background-contrast-1);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","layout":{"type":"stacked"},"background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background-contrast-1)"}},"mobile":{"layout":{"gridAreas":{"areas":{"columns":1,"rows":3,"areas":[{"id":"c1","label":"1","x":1,"y":1,"w":1,"h":1},{"id":"c2","label":"2","x":1,"y":3,"w":1,"h":1}],"rowHeight":"auto"}},"grid":{"columns":1}}},"stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-xl)","frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"},"features":{"size":"wide"}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"wi ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"width":{"limit":"max","custom":"999px"}},"styles":"\u002d\u002dwi: 999px"}} -->
' . wphave_pattern_slot( 'heading', array( 'level' => 'h2', 'size' => 'title-l' ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-m' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"\u002d\u002dwi: fit-content","classNames":"wi ly ly-fl","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-m)","gapY":"var(\u002d\u002dwphave-site-gap-size-m)","flexWrap":"no-wrap","flexDirection":"row","flexItemSizing":"auto"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-direction: row;\u002d\u002dly-fl-itm: 0 1 auto"}} -->
' . wphave_pattern_slot( 'actions.0.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'size' => '0' ), 'styles' => '\u002d\u002dbtn-size-scale: 0' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'actions.1.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'variant' => 'secondary', 'size' => '0' ), 'styles' => '\u002d\u002dbtn-size-scale: 0' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

' . wphave_pattern_slot( 'spacer', 'spacer', array( 'ratio' => '75/1' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"grid","grid":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","columns":2,"keepColumns":"nowrap","gridRowHeight":"auto","alignVertical":"stretch","alignHorizontal":"space-between"}},"classNames":"ly ly-gr ly-nowrap ly-gr-m ly-m-col-1","stylesLayout":"\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-col: 2;\u002d\u002dly-valign: stretch;\u002d\u002dly-halign: space-between;\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-col: 1;\u002d\u002dly-m-valign: stretch;\u002d\u002dly-m-halign: space-between","mobile":{"layout":{"grid":{"columns":1}}}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'items.0.icon', 'icon', array(), $slots ) . '

' . wphave_pattern_slot( 'items.0.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.0.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'items.1.icon', 'icon', array(), $slots ) . '

' . wphave_pattern_slot( 'items.1.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.1.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'items.2.icon', 'icon', array(), $slots ) . '

' . wphave_pattern_slot( 'items.2.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.2.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'items.3.icon', 'icon', array(), $slots ) . '

' . wphave_pattern_slot( 'items.3.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.3.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'feature-list-section-5',
            'tags' => array('feature-list-section'),
            'title' => __( 'Feature List Wide Three Column Cards', 'wphave' ),
            'keywords' => array('features', 'feature list', 'wide', 'three column', 'cards', 'icons', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('feature-grid', 'section', 'content'),
                'layout' => array('stacked', 'grid', 'compact-card'),
                'width' => array('wide'),
                'visual' => array('icon', 'cards'),
                'content' => array('heading', 'body', 'actions', 'items', 'icons'),
                'intent' => array('feature-summary', 'explanation', 'conversion-support'),
                'treatment' => array('soft-surface', 'structured', 'dense'),
                'description' => 'Wide feature section with intro actions and three compact icon cards for concise product, service or value summaries.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-wide wi-in pa ofw ly ly-stk bg-co bg br","dimensions":{"overflow":"clip","innerWidth":{"limit":"max","custom":"100%"},"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl)"}},"styles":"\u002d\u002dwi-in: 100%;\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background-contrast-1);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","layout":{"type":"stacked"},"background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background-contrast-1)"}},"mobile":{"layout":{"gridAreas":{"areas":{"columns":1,"rows":3,"areas":[{"id":"c1","label":"1","x":1,"y":1,"w":1,"h":1},{"id":"c2","label":"2","x":1,"y":3,"w":1,"h":1}],"rowHeight":"auto"}},"grid":{"columns":1}}},"stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-xl)","frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"},"features":{"size":"wide"}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"wi ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"width":{"limit":"max","custom":"999px"}},"styles":"\u002d\u002dwi: 999px"}} -->
' . wphave_pattern_slot( 'heading', array( 'level' => 'h2', 'size' => 'title-l' ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-m' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"\u002d\u002dwi: fit-content","classNames":"wi ly ly-fl","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-m)","gapY":"var(\u002d\u002dwphave-site-gap-size-m)","flexWrap":"no-wrap","flexDirection":"row","flexItemSizing":"auto"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-direction: row;\u002d\u002dly-fl-itm: 0 1 auto"}} -->
' . wphave_pattern_slot( 'actions.0.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'size' => '0' ), 'styles' => '\u002d\u002dbtn-size-scale: 0' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'actions.1.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'variant' => 'secondary', 'size' => '0' ), 'styles' => '\u002d\u002dbtn-size-scale: 0' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

' . wphave_pattern_slot( 'spacer', 'spacer', array( 'ratio' => '75/1' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"grid","grid":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","columns":3,"keepColumns":"nowrap","gridRowHeight":"auto","alignVertical":"stretch","alignHorizontal":"space-between"}},"classNames":"ly ly-gr ly-nowrap ly-gr-m ly-m-col-1","stylesLayout":"\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-col: 3;\u002d\u002dly-valign: stretch;\u002d\u002dly-halign: space-between;\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-col: 1;\u002d\u002dly-m-valign: stretch;\u002d\u002dly-m-halign: space-between","mobile":{"layout":{"grid":{"columns":1}}}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"pa ofw ly ly-stk bg-co bg br","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m)"},"overflow":"clip"},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-m)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background)"}},"frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"}}} -->
' . wphave_pattern_slot( 'items.0.icon', 'icon', array(), $slots ) . '

' . wphave_pattern_slot( 'items.0.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.0.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"pa ofw ly ly-stk bg-co bg br","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m)"},"overflow":"clip"},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-m)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background)"}},"frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"}}} -->
' . wphave_pattern_slot( 'items.1.icon', 'icon', array(), $slots ) . '

' . wphave_pattern_slot( 'items.1.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.1.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"pa ofw ly ly-stk bg-co bg br","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m)"},"overflow":"clip"},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-m)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background)"}},"frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"}}} -->
' . wphave_pattern_slot( 'items.2.icon', 'icon', array(), $slots ) . '

' . wphave_pattern_slot( 'items.2.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.2.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'feature-list-section-6',
            'tags' => array('feature-list-section'),
            'title' => __( 'Feature List Stretch Proof Grid', 'wphave' ),
            'keywords' => array('features', 'feature list', 'proof', 'stretch heading', 'cta', 'icons', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('feature-grid', 'section', 'content', 'proof', 'cta'),
                'layout' => array('stacked', 'grid', 'featured'),
                'width' => array('wide'),
                'visual' => array('icon', 'cards'),
                'content' => array('heading', 'body', 'actions', 'items', 'icons'),
                'intent' => array('feature-summary', 'proof', 'conversion-support'),
                'treatment' => array('structured', 'spacious', 'visual-impact'),
                'description' => 'Wide proof-oriented feature section with a stretched heading, three proof points and a closing CTA row.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-wide wi-in pa ofw ly ly-stk bg-co bg br","dimensions":{"overflow":"clip","innerWidth":{"limit":"max","custom":"100%"},"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl)"}},"styles":"\u002d\u002dwi-in: 100%;\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background-contrast-1);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","layout":{"type":"stacked"},"background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background-contrast-1)"}},"mobile":{"layout":{"gridAreas":{"areas":{"columns":1,"rows":3,"areas":[{"id":"c1","label":"1","x":1,"y":1,"w":1,"h":1},{"id":"c2","label":"2","x":1,"y":3,"w":1,"h":1}],"rowHeight":"auto"}},"grid":{"columns":1}}},"stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-xxl)","frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"},"features":{"size":"wide"}}} -->
' . wphave_pattern_slot( 'heading', array( 'level' => 'h2', 'size' => 'title-l', 'textType' => 'short-heading', 'attrs' => array( 'wphave' => array( 'classNames' => 'txt-str txt-str-true tf-fs tf-fs-title-l', 'features' => array( 'textStretch' => true ) ) ) ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"grid","grid":{"gapX":"var(\u002d\u002dwphave-site-gap-size-3xl)","gapY":"var(\u002d\u002dwphave-site-gap-size-3xl)","columns":3,"keepColumns":"nowrap","gridRowHeight":"auto","alignVertical":"stretch","alignHorizontal":"space-between"}},"classNames":"ly ly-gr ly-nowrap ly-gr-m ly-m-col-1","stylesLayout":"\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-col: 3;\u002d\u002dly-valign: stretch;\u002d\u002dly-halign: space-between;\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-m-col: 1;\u002d\u002dly-m-valign: stretch;\u002d\u002dly-m-halign: space-between","mobile":{"layout":{"grid":{"columns":1}}}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'items.0.icon', 'icon', array(), $slots ) . '

' . wphave_pattern_slot( 'items.0.title', array( 'level' => 'h3', 'size' => 'title-xxs' ), $slots ) . '

' . wphave_pattern_slot( 'items.0.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'items.1.icon', 'icon', array(), $slots ) . '

' . wphave_pattern_slot( 'items.1.title', array( 'level' => 'h3', 'size' => 'title-xxs' ), $slots ) . '

' . wphave_pattern_slot( 'items.1.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'items.2.icon', 'icon', array(), $slots ) . '

' . wphave_pattern_slot( 'items.2.title', array( 'level' => 'h3', 'size' => 'title-xxs' ), $slots ) . '

' . wphave_pattern_slot( 'items.2.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

' . wphave_pattern_slot( 'spacer', 'spacer', array( 'ratio' => '75/1' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)","contentPosition":"right"}},"classNames":"ly ly-stk ly-co-pos","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","styles":"\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: end"}} -->
' . wphave_pattern_slot( 'body', array(), $slots ) . '

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"\u002d\u002dwi: fit-content","classNames":"wi ly ly-fl","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-m)","gapY":"var(\u002d\u002dwphave-site-gap-size-m)","flexWrap":"no-wrap","flexDirection":"row","flexItemSizing":"auto"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-direction: row;\u002d\u002dly-fl-itm: 0 1 auto"}} -->
' . wphave_pattern_slot( 'actions.0.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'size' => '0' ), 'styles' => '\u002d\u002dbtn-size-scale: 0' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'actions.1.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'variant' => 'secondary', 'size' => '0' ), 'styles' => '\u002d\u002dbtn-size-scale: 0' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'feature-list-section-7',
            'tags' => array('feature-list-section'),
            'title' => __( 'Feature List Media Cards', 'wphave' ),
            'keywords' => array('features', 'feature list', 'media cards', 'images', 'grid', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('feature-grid', 'section', 'content', 'media'),
                'layout' => array('intro-grid', 'media-card-grid'),
                'width' => array('wide'),
                'visual' => array('image', 'cards'),
                'content' => array('heading', 'body', 'items', 'images'),
                'intent' => array('feature-summary', 'visual-explanation'),
                'treatment' => array('structured', 'media-led', 'spacious'),
                'description' => 'Two-column intro followed by three image-led feature cards for visual service, product or benefit summaries.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"wi-in pa ofw ly ly-stk","dimensions":{"overflow":"clip","innerWidth":{"limit":"max","custom":"100%"},"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-xl) 0 var(\u002d\u002dwphave-site-padding-xl) 0"}},"styles":"\u002d\u002dwi-in: 100%;\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-xl) 0 var(\u002d\u002dwphave-site-padding-xl) 0;\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-right: 0;\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-left: 0;\u002d\u002dofw: clip","layout":{"type":"stacked"},"mobile":{"layout":{"gridAreas":{"areas":{"columns":1,"rows":3,"areas":[{"id":"c1","label":"1","x":1,"y":1,"w":1,"h":1},{"id":"c2","label":"2","x":1,"y":3,"w":1,"h":1}],"rowHeight":"auto"}},"grid":{"columns":1}}},"stylesChild":"\u002d\u002dleft-spacing-inherit: 0;\u002d\u002dright-spacing-inherit: 0"}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"grid","grid":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","columns":2,"keepColumns":"auto","gridRowHeight":"auto","alignVertical":"start","alignHorizontal":"start"}},"classNames":"pa ly ly-gr ly-col-2 txta","stylesLayout":"\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-col: 2;\u002d\u002dly-valign: start;\u002d\u002dly-halign: start","dimensions":{"spacing":{"padding":"0px 0px 0px 0px"}},"styles":"\u002d\u002dpa: 0px 0px 0px 0px;\u002d\u002dpa-top: 0px;\u002d\u002dpa-right: 0px;\u002d\u002dpa-bottom: 0px;\u002d\u002dpa-left: 0px;\u002d\u002dtxta: none","features":{"horizontalDirection":"none"},"stylesChild":"\u002d\u002dleft-spacing-inherit: 0px;\u002d\u002dright-spacing-inherit: 0px","text":{"align":"none"}}} -->
' . wphave_pattern_slot( 'heading', array( 'level' => 'h2', 'size' => 'default' ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

' . wphave_pattern_slot( 'spacer', 'spacer', array( 'ratio' => '75/1' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"grid","grid":{"gapX":"var(\u002d\u002dwphave-site-gap-size-3xl)","gapY":"var(\u002d\u002dwphave-site-gap-size-3xl)","columns":3,"keepColumns":"nowrap","gridRowHeight":"auto","alignVertical":"stretch","alignHorizontal":"space-between"}},"classNames":"ly ly-gr ly-nowrap ly-gr-m ly-m-col-1","stylesLayout":"\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-col: 3;\u002d\u002dly-valign: stretch;\u002d\u002dly-halign: space-between;\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-m-col: 1;\u002d\u002dly-m-valign: stretch;\u002d\u002dly-m-halign: space-between","mobile":{"layout":{"grid":{"columns":1}}}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ofw ly ly-stk bg-co bg","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"overflow":"clip"},"styles":"\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background)"}}}} -->
' . wphave_pattern_slot( 'items.0.image', 'image', array(), $slots ) . '

' . wphave_pattern_slot( 'items.0.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.0.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ofw ly ly-stk bg-co bg","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"overflow":"clip"},"styles":"\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background)"}}}} -->
' . wphave_pattern_slot( 'items.1.image', 'image', array(), $slots ) . '

' . wphave_pattern_slot( 'items.1.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.1.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ofw ly ly-stk bg-co bg","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"overflow":"clip"},"styles":"\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background)"}}}} -->
' . wphave_pattern_slot( 'items.2.image', 'image', array(), $slots ) . '

' . wphave_pattern_slot( 'items.2.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.2.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'feature-list-section-8',
            'tags' => array('feature-list-section'),
            'title' => __( 'Feature List Editorial Media Grid', 'wphave' ),
            'keywords' => array('features', 'feature list', 'editorial', 'media grid', 'images', 'actions', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('feature-grid', 'section', 'content', 'media', 'cta'),
                'layout' => array('headline', 'media-card-grid', 'cta-row'),
                'width' => array('wide'),
                'visual' => array('image', 'cards'),
                'content' => array('heading', 'body', 'actions', 'items', 'images'),
                'intent' => array('feature-summary', 'visual-explanation', 'conversion-support'),
                'treatment' => array('editorial', 'media-led', 'spacious'),
                'description' => 'Editorial feature list with a strong full-width headline, three image cards and a closing text/action row.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"wi-in pa ofw ly ly-stk","dimensions":{"overflow":"clip","innerWidth":{"limit":"max","custom":"100%"},"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-xl) 0 var(\u002d\u002dwphave-site-padding-xl) 0"}},"styles":"\u002d\u002dwi-in: 100%;\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-xl) 0 var(\u002d\u002dwphave-site-padding-xl) 0;\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-right: 0;\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-left: 0;\u002d\u002dofw: clip","layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-3xl)"}},"mobile":{"layout":{"gridAreas":{"areas":{"columns":1,"rows":3,"areas":[{"id":"c1","label":"1","x":1,"y":1,"w":1,"h":1},{"id":"c2","label":"2","x":1,"y":3,"w":1,"h":1}],"rowHeight":"auto"}},"grid":{"columns":1}}},"stylesChild":"\u002d\u002dleft-spacing-inherit: 0;\u002d\u002dright-spacing-inherit: 0","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-m-gap: var(\u002d\u002dwphave-site-gap-size-3xl)"}} -->
' . wphave_pattern_slot( 'heading', array( 'level' => 'h2', 'size' => 'title-l', 'attrs' => array( 'wphave' => array( 'classNames' => 'wi tf-fs tf-fs-title-l', 'dimensions' => array( 'width' => array( 'custom' => '80%' ) ), 'styles' => '\u002d\u002dwi: 80%' ) ) ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"grid","grid":{"gapX":"var(\u002d\u002dwphave-site-gap-size-3xl)","gapY":"var(\u002d\u002dwphave-site-gap-size-3xl)","columns":3,"keepColumns":"nowrap","gridRowHeight":"auto","alignVertical":"stretch","alignHorizontal":"space-between"}},"classNames":"ly ly-gr ly-nowrap ly-gr-m ly-m-col-1","stylesLayout":"\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-col: 3;\u002d\u002dly-valign: stretch;\u002d\u002dly-halign: space-between;\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-m-col: 1;\u002d\u002dly-m-valign: stretch;\u002d\u002dly-m-halign: space-between","mobile":{"layout":{"grid":{"columns":1}}}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ofw ly ly-stk bg-co bg","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"overflow":"clip"},"styles":"\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background)"}}}} -->
' . wphave_pattern_slot( 'items.0.image', 'image', array(), $slots ) . '

' . wphave_pattern_slot( 'items.0.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.0.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ofw ly ly-stk bg-co bg","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"overflow":"clip"},"styles":"\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background)"}}}} -->
' . wphave_pattern_slot( 'items.1.image', 'image', array(), $slots ) . '

' . wphave_pattern_slot( 'items.1.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.1.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ofw ly ly-stk bg-co bg","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"overflow":"clip"},"styles":"\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background)"}}}} -->
' . wphave_pattern_slot( 'items.2.image', 'image', array(), $slots ) . '

' . wphave_pattern_slot( 'items.2.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.2.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"start"}},"classNames":"pa ly ly-fl txta ly-fl-m","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: center;\u002d\u002dly-halign: start;\u002d\u002dly-fl-direction: row;\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-fl-wrap: no-wrap;\u002d\u002dly-m-fl-itm: 0 1 auto;\u002d\u002dly-m-valign: start;\u002d\u002dly-m-halign: center;\u002d\u002dly-m-fl-direction: column","dimensions":{"spacing":{"padding":"0px 0px 0px 0px"}},"styles":"\u002d\u002dpa: 0px 0px 0px 0px;\u002d\u002dpa-top: 0px;\u002d\u002dpa-right: 0px;\u002d\u002dpa-bottom: 0px;\u002d\u002dpa-left: 0px;\u002d\u002dtxta: none","features":{"horizontalDirection":"none"},"stylesChild":"\u002d\u002dleft-spacing-inherit: 0px;\u002d\u002dright-spacing-inherit: 0px","text":{"align":"none"},"mobile":{"layout":{"flex":{"flexDirection":"column"}}}}} -->
' . wphave_pattern_slot( 'body', array( 'size' => 'text-s' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"classNames":"wi ly ly-fl","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-m)","gapY":"var(\u002d\u002dwphave-site-gap-size-m)","flexWrap":"no-wrap","flexDirection":"row","flexItemSizing":"auto"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-fl-direction: row","dimensions":{"width":{"custom":"fit-content"}},"styles":"\u002d\u002dwi: fit-content"}} -->
' . wphave_pattern_slot( 'actions.0.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'size' => '0', 'whiteSpace' => 'nowrap' ), 'styles' => '\u002d\u002dtxt-whsp: nowrap;\u002d\u002dbtn-size-scale: 0', 'classNames' => 'is-white-space' ) ) ), $slots ) . '

' . wphave_pattern_slot( 'actions.1.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'variant' => 'secondary', 'size' => '0', 'whiteSpace' => 'nowrap' ), 'styles' => '\u002d\u002dtxt-whsp: nowrap;\u002d\u002dbtn-size-scale: 0', 'classNames' => 'is-white-space' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'feature-list-section-9',
            'tags' => array('feature-list-section'),
            'title' => __( 'Feature List Alternating Media Rows', 'wphave' ),
            'keywords' => array('features', 'feature list', 'alternating rows', 'media rows', 'images', 'grid areas', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('feature-grid', 'section', 'content', 'media'),
                'layout' => array('stacked', 'split', 'grid-areas'),
                'width' => array('full'),
                'visual' => array('image', 'cards'),
                'content' => array('heading', 'body', 'items', 'images'),
                'intent' => array('feature-summary', 'visual-explanation'),
                'treatment' => array('structured', 'media-led', 'soft-surface'),
                'description' => 'Full-width feature section with a compact intro and four alternating image/text rows for visual feature summaries.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-full pa ofw ly ly-stk bg-co bg","dimensions":{"overflow":"clip","spacing":{"padding":"var(\u002d\u002dwphave-site-padding-xxl) 0 var(\u002d\u002dwphave-site-padding-xxl) 0"}},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-xxl) 0 var(\u002d\u002dwphave-site-padding-xxl) 0;\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-right: 0;\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-left: 0;\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background-contrast-1)","layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-3xl)"}},"mobile":{"layout":{"gridAreas":{"areas":{"columns":1,"rows":3,"areas":[{"id":"c1","label":"1","x":1,"y":1,"w":1,"h":1},{"id":"c2","label":"2","x":1,"y":3,"w":1,"h":1}],"rowHeight":"auto"}},"grid":{"columns":1}}},"stylesChild":"\u002d\u002dleft-spacing-inherit: 0;\u002d\u002dright-spacing-inherit: 0","features":{"size":"full"},"background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background-contrast-1)"}},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-m-gap: var(\u002d\u002dwphave-site-gap-size-3xl)"}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-l)"}},"classNames":"wi pa ly ly-stk txta","dimensions":{"spacing":{"padding":"0px 0px 0px 0px"},"width":{"custom":"800px"}},"styles":"\u002d\u002dwi: 800px;\u002d\u002dpa: 0px 0px 0px 0px;\u002d\u002dpa-top: 0px;\u002d\u002dpa-right: 0px;\u002d\u002dpa-bottom: 0px;\u002d\u002dpa-left: 0px;\u002d\u002dtxta: none","features":{"horizontalDirection":"none"},"stylesChild":"\u002d\u002dleft-spacing-inherit: 0px;\u002d\u002dright-spacing-inherit: 0px","text":{"align":"none"},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-l)"}} -->
' . wphave_pattern_slot( 'heading', array( 'level' => 'h2', 'size' => 'title-m' ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"grid","grid":{"gapX":"var(\u002d\u002dwphave-site-gap-size-3xl)","gapY":"var(\u002d\u002dwphave-site-gap-size-3xl)","columns":2,"keepColumns":"nowrap","gridRowHeight":"auto","alignVertical":"center","alignHorizontal":"space-between"}},"classNames":"ly ly-gr ly-nowrap ly-gr-m ly-m-col-1","stylesLayout":"\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-col: 2;\u002d\u002dly-valign: center;\u002d\u002dly-halign: space-between;\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-m-col: 1;\u002d\u002dly-m-valign: center;\u002d\u002dly-m-halign: space-between","mobile":{"layout":{"grid":{"columns":1}}}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"gridAreas","gridAreas":{"gapX":"var(\u002d\u002dwphave-site-gap-size-l)","gapY":"var(\u002d\u002dwphave-site-gap-size-l)","areas":{"columns":3,"rows":1,"areas":[{"id":"c1","label":"1","x":1,"y":1,"w":1,"h":1},{"id":"c2","label":"2","x":2,"y":1,"w":2,"h":1}],"rowHeight":"auto"},"alignVertical":"center","alignHorizontal":"stretch"}},"classNames":"pa ofw ly ly-gra bg-co bg br","stylesLayout":"\u002d\u002dly-gra-template: \u0022c1 c2 c2\u0022;\u002d\u002dly-gra-columns: 3;\u002d\u002dly-gra-rows: 1;\u002d\u002dly-gra-row-height: minmax(min-content, auto);\u002d\u002dly-gra-area-1: c1;\u002d\u002dly-gra-area-2: c2;\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-l);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-l);\u002d\u002dly-valign: center;\u002d\u002dly-halign: stretch","dimensions":{"overflow":"clip","spacing":{"padding":"var(\u002d\u002dwphave-site-padding-s) var(\u002d\u002dwphave-site-padding-s) var(\u002d\u002dwphave-site-padding-s) var(\u002d\u002dwphave-site-padding-s)"}},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-s) var(\u002d\u002dwphave-site-padding-s) var(\u002d\u002dwphave-site-padding-s) var(\u002d\u002dwphave-site-padding-s);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-s);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-s);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-s);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-s);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background)"}},"stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-s);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-s)","frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"}}} -->
' . wphave_pattern_slot( 'items.0.image', 'image', array( 'ratio' => '1/1' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'items.0.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.0.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"gridAreas","gridAreas":{"gapX":"var(\u002d\u002dwphave-site-gap-size-l)","gapY":"var(\u002d\u002dwphave-site-gap-size-l)","areas":{"columns":3,"rows":1,"areas":[{"id":"c1","label":"1","x":1,"y":1,"w":1,"h":1},{"id":"c2","label":"2","x":2,"y":1,"w":2,"h":1}],"rowHeight":"auto"},"alignVertical":"center","alignHorizontal":"stretch"}},"classNames":"pa ofw ly ly-gra br","stylesLayout":"\u002d\u002dly-gra-template: \u0022c1 c2 c2\u0022;\u002d\u002dly-gra-columns: 3;\u002d\u002dly-gra-rows: 1;\u002d\u002dly-gra-row-height: minmax(min-content, auto);\u002d\u002dly-gra-area-1: c1;\u002d\u002dly-gra-area-2: c2;\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-l);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-l);\u002d\u002dly-valign: center;\u002d\u002dly-halign: stretch","dimensions":{"overflow":"clip","spacing":{"padding":"var(\u002d\u002dwphave-site-padding-s) var(\u002d\u002dwphave-site-padding-s) var(\u002d\u002dwphave-site-padding-s) var(\u002d\u002dwphave-site-padding-s)"}},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-s) var(\u002d\u002dwphave-site-padding-s) var(\u002d\u002dwphave-site-padding-s) var(\u002d\u002dwphave-site-padding-s);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-s);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-s);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-s);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-s);\u002d\u002dofw: clip;\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-s);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-s)","frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"}}} -->
' . wphave_pattern_slot( 'items.1.image', 'image', array( 'ratio' => '1/1' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'items.1.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.1.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"gridAreas","gridAreas":{"gapX":"var(\u002d\u002dwphave-site-gap-size-l)","gapY":"var(\u002d\u002dwphave-site-gap-size-l)","areas":{"columns":3,"rows":1,"areas":[{"id":"c1","label":"1","x":1,"y":1,"w":1,"h":1},{"id":"c2","label":"2","x":2,"y":1,"w":2,"h":1}],"rowHeight":"auto"},"alignVertical":"center","alignHorizontal":"stretch"}},"classNames":"pa ofw ly ly-gra br","stylesLayout":"\u002d\u002dly-gra-template: \u0022c1 c2 c2\u0022;\u002d\u002dly-gra-columns: 3;\u002d\u002dly-gra-rows: 1;\u002d\u002dly-gra-row-height: minmax(min-content, auto);\u002d\u002dly-gra-area-1: c1;\u002d\u002dly-gra-area-2: c2;\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-l);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-l);\u002d\u002dly-valign: center;\u002d\u002dly-halign: stretch","dimensions":{"overflow":"clip","spacing":{"padding":"var(\u002d\u002dwphave-site-padding-s) var(\u002d\u002dwphave-site-padding-s) var(\u002d\u002dwphave-site-padding-s) var(\u002d\u002dwphave-site-padding-s)"}},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-s) var(\u002d\u002dwphave-site-padding-s) var(\u002d\u002dwphave-site-padding-s) var(\u002d\u002dwphave-site-padding-s);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-s);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-s);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-s);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-s);\u002d\u002dofw: clip;\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-s);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-s)","frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"}}} -->
' . wphave_pattern_slot( 'items.2.image', 'image', array( 'ratio' => '1/1' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'items.2.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.2.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"gridAreas","gridAreas":{"gapX":"var(\u002d\u002dwphave-site-gap-size-l)","gapY":"var(\u002d\u002dwphave-site-gap-size-l)","areas":{"columns":3,"rows":1,"areas":[{"id":"c1","label":"1","x":1,"y":1,"w":1,"h":1},{"id":"c2","label":"2","x":2,"y":1,"w":2,"h":1}],"rowHeight":"auto"},"alignVertical":"center","alignHorizontal":"stretch"}},"classNames":"pa ofw ly ly-gra bg-co bg br","stylesLayout":"\u002d\u002dly-gra-template: \u0022c1 c2 c2\u0022;\u002d\u002dly-gra-columns: 3;\u002d\u002dly-gra-rows: 1;\u002d\u002dly-gra-row-height: minmax(min-content, auto);\u002d\u002dly-gra-area-1: c1;\u002d\u002dly-gra-area-2: c2;\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-l);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-l);\u002d\u002dly-valign: center;\u002d\u002dly-halign: stretch","dimensions":{"overflow":"clip","spacing":{"padding":"var(\u002d\u002dwphave-site-padding-s) var(\u002d\u002dwphave-site-padding-s) var(\u002d\u002dwphave-site-padding-s) var(\u002d\u002dwphave-site-padding-s)"}},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-s) var(\u002d\u002dwphave-site-padding-s) var(\u002d\u002dwphave-site-padding-s) var(\u002d\u002dwphave-site-padding-s);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-s);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-s);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-s);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-s);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background)"}},"stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-s);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-s)","frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"}}} -->
' . wphave_pattern_slot( 'items.3.image', 'image', array( 'ratio' => '1/1' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'items.3.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.3.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'feature-list-section-10',
            'tags' => array('feature-list-section'),
            'title' => __( 'Feature List Dark Marquee Rows', 'wphave' ),
            'keywords' => array('features', 'feature list', 'dark', 'marquee', 'media rows', 'images', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('feature-grid', 'section', 'content', 'media'),
                'layout' => array('stacked', 'animated-flex', 'grid-areas'),
                'width' => array('wide'),
                'visual' => array('image', 'cards'),
                'content' => array('heading', 'body', 'items', 'images'),
                'intent' => array('feature-summary', 'visual-explanation', 'brand-story'),
                'treatment' => array('strong-contrast', 'media-led', 'visual-impact'),
                'description' => 'Dark feature list section with an intro and horizontally animated media rows for high-impact feature highlights.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"wi-in pa ofw ly ly-stk bg-co bg br tx-co","dimensions":{"overflow":"clip","innerWidth":{"limit":"max","custom":"100%"},"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-xxl) 0 var(\u002d\u002dwphave-site-padding-xxl) 0"}},"styles":"\u002d\u002dwi-in: 100%;\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-xxl) 0 var(\u002d\u002dwphave-site-padding-xxl) 0;\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-right: 0;\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-left: 0;\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background-contrast-10);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners);\u002d\u002dtx-co: var(\u002d\u002dwphave-site-color-background-subtle-10)","layout":{"type":"stacked"},"mobile":{"layout":{"gridAreas":{"areas":{"columns":1,"rows":3,"areas":[{"id":"c1","label":"1","x":1,"y":1,"w":1,"h":1},{"id":"c2","label":"2","x":1,"y":3,"w":1,"h":1}],"rowHeight":"auto"}},"grid":{"columns":1}}},"stylesChild":"\u002d\u002dleft-spacing-inherit: 0;\u002d\u002dright-spacing-inherit: 0","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background-contrast-10)"}},"frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"},"text":{"colors":{"text":"var(\u002d\u002dwphave-site-color-background-subtle-10)"}}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-l)"}},"classNames":"wi pa ly ly-stk txta","dimensions":{"spacing":{"padding":"0 var(\u002d\u002dwphave-site-padding-xxl) 0 var(\u002d\u002dwphave-site-padding-xxl)"},"width":{"custom":"80%"}},"styles":"\u002d\u002dwi: 80%;\u002d\u002dpa: 0 var(\u002d\u002dwphave-site-padding-xxl) 0 var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-top: 0;\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-bottom: 0;\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dtxta: none","features":{"horizontalDirection":"none"},"stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-xxl)","text":{"align":"none"},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-l)"}} -->
' . wphave_pattern_slot( 'heading', array( 'level' => 'h2', 'size' => 'title-m' ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

' . wphave_pattern_slot( 'spacer', 'spacer', array( 'ratio' => '75/1' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"animated","flexDirection":"row","flexItemSizing":"auto","alignVertical":"start","alignHorizontal":"start","animation":{"itemWidth":"6%","duration":"26s"}}},"classNames":"ofw ly ly-fl ly-fl-ani ly-fl-m","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: start;\u002d\u002dly-halign: start;\u002d\u002dly-fl-direction: row;\u002d\u002dly-fl-ani-dur: 26s;\u002d\u002dly-fl-ani-itm: 6%;\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-fl-wrap: no-wrap;\u002d\u002dly-m-fl-itm: 0 1 auto;\u002d\u002dly-m-valign: start;\u002d\u002dly-m-halign: start;\u002d\u002dly-m-fl-direction: row","mobile":{"layout":{"grid":{"columns":1}}},"dimensions":{"overflow":"hidden"},"styles":"\u002d\u002dofw: hidden"}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"gridAreas","gridAreas":{"gapX":"var(\u002d\u002dwphave-site-gap-size-l)","gapY":"var(\u002d\u002dwphave-site-gap-size-l)","areas":{"columns":3,"rows":1,"areas":[{"id":"c1","label":"1","x":1,"y":1,"w":1,"h":1},{"id":"c2","label":"2","x":2,"y":1,"w":2,"h":1}],"rowHeight":"auto"},"alignVertical":"center","alignHorizontal":"stretch"}},"classNames":"ofw ly ly-gra","stylesLayout":"\u002d\u002dly-gra-template: \u0022c1 c2 c2\u0022;\u002d\u002dly-gra-columns: 3;\u002d\u002dly-gra-rows: 1;\u002d\u002dly-gra-row-height: minmax(min-content, auto);\u002d\u002dly-gra-area-1: c1;\u002d\u002dly-gra-area-2: c2;\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-l);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-l);\u002d\u002dly-valign: center;\u002d\u002dly-halign: stretch","dimensions":{"overflow":"clip"},"styles":"\u002d\u002dofw: clip"}} -->
' . wphave_pattern_slot( 'items.0.image', 'image', array( 'ratio' => '3/2' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'items.0.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.0.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"gridAreas","gridAreas":{"gapX":"var(\u002d\u002dwphave-site-gap-size-l)","gapY":"var(\u002d\u002dwphave-site-gap-size-l)","areas":{"columns":3,"rows":1,"areas":[{"id":"c1","label":"1","x":1,"y":1,"w":1,"h":1},{"id":"c2","label":"2","x":2,"y":1,"w":2,"h":1}],"rowHeight":"auto"},"alignVertical":"center","alignHorizontal":"stretch"}},"classNames":"ofw ly ly-gra","stylesLayout":"\u002d\u002dly-gra-template: \u0022c1 c2 c2\u0022;\u002d\u002dly-gra-columns: 3;\u002d\u002dly-gra-rows: 1;\u002d\u002dly-gra-row-height: minmax(min-content, auto);\u002d\u002dly-gra-area-1: c1;\u002d\u002dly-gra-area-2: c2;\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-l);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-l);\u002d\u002dly-valign: center;\u002d\u002dly-halign: stretch","dimensions":{"overflow":"clip"},"styles":"\u002d\u002dofw: clip"}} -->
' . wphave_pattern_slot( 'items.1.image', 'image', array( 'ratio' => '3/2' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'items.1.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.1.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"gridAreas","gridAreas":{"gapX":"var(\u002d\u002dwphave-site-gap-size-l)","gapY":"var(\u002d\u002dwphave-site-gap-size-l)","areas":{"columns":3,"rows":1,"areas":[{"id":"c1","label":"1","x":1,"y":1,"w":1,"h":1},{"id":"c2","label":"2","x":2,"y":1,"w":2,"h":1}],"rowHeight":"auto"},"alignVertical":"center","alignHorizontal":"stretch"}},"classNames":"ofw ly ly-gra","stylesLayout":"\u002d\u002dly-gra-template: \u0022c1 c2 c2\u0022;\u002d\u002dly-gra-columns: 3;\u002d\u002dly-gra-rows: 1;\u002d\u002dly-gra-row-height: minmax(min-content, auto);\u002d\u002dly-gra-area-1: c1;\u002d\u002dly-gra-area-2: c2;\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-l);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-l);\u002d\u002dly-valign: center;\u002d\u002dly-halign: stretch","dimensions":{"overflow":"clip"},"styles":"\u002d\u002dofw: clip"}} -->
' . wphave_pattern_slot( 'items.2.image', 'image', array( 'ratio' => '3/2' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'items.2.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.2.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"gridAreas","gridAreas":{"gapX":"var(\u002d\u002dwphave-site-gap-size-l)","gapY":"var(\u002d\u002dwphave-site-gap-size-l)","areas":{"columns":3,"rows":1,"areas":[{"id":"c1","label":"1","x":1,"y":1,"w":1,"h":1},{"id":"c2","label":"2","x":2,"y":1,"w":2,"h":1}],"rowHeight":"auto"},"alignVertical":"center","alignHorizontal":"stretch"}},"classNames":"ofw ly ly-gra","stylesLayout":"\u002d\u002dly-gra-template: \u0022c1 c2 c2\u0022;\u002d\u002dly-gra-columns: 3;\u002d\u002dly-gra-rows: 1;\u002d\u002dly-gra-row-height: minmax(min-content, auto);\u002d\u002dly-gra-area-1: c1;\u002d\u002dly-gra-area-2: c2;\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-l);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-l);\u002d\u002dly-valign: center;\u002d\u002dly-halign: stretch","dimensions":{"overflow":"clip"},"styles":"\u002d\u002dofw: clip"}} -->
' . wphave_pattern_slot( 'items.3.image', 'image', array( 'ratio' => '3/2' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'items.3.title', array( 'level' => 'h3', 'size' => 'title-xs' ), $slots ) . '

' . wphave_pattern_slot( 'items.3.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        return $patterns;

	}

endif;
