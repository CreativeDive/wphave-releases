<?php

/**
 * Functions to group link page block patterns.
 */

if (!function_exists('wphave_block_pattern_collection_link_pages')):
	function wphave_block_pattern_collection_link_pages($args = []) {
		if (!wphave_release_feature_ready('patternLinkPages')) {
			return [];
		}

		$content_width = isset($args['width']) ? (int) $args['width'] : 1300;

		$patterns = [];

		$patterns[] = [
			'key' => 'link-page-1',
			'tags' => ['link-pages'],
			'title' => __('Simple Link Page', 'wphave'),
			'keywords' => ['link page', 'link in bio', 'profile', 'social links'],
			'viewportWidth' => $content_width,
			'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"wi pa ly ly-stk ly-co-pos txta","dimensions":{"width":{"limit":"max","custom":"640px"},"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-m)"}},"styles":"\u002d\u002dwi: 640px;\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-l);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-l);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center;\u002d\u002dtxta: center","layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-m)","contentPosition":"center"}},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-m)","text":{"align":"center"},"stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-m)"}}} -->
<!-- wp:wphave/heading {"wphave":{"text":{"typeface":{"size":{"type":"title-m"}}},"classNames":"tf-fs tf-fs-title-m"},"content":"Your Name"} /-->

<!-- wp:wphave/paragraph {"content":"A short introduction that tells visitors who you are and what they can find here."} /-->

<!-- wp:wphave/button {"wphave":{"dimensions":{"width":{"custom":"100%"}},"styles":"\u002d\u002dwi: 100%","classNames":"wi"},"content":"Visit my website"} /-->

<!-- wp:wphave/button {"wphave":{"settings":{"variant":"secondary"},"dimensions":{"width":{"custom":"100%"}},"styles":"\u002d\u002dwi: 100%","classNames":"wi"},"content":"View my work"} /-->

<!-- wp:wphave/button {"wphave":{"settings":{"variant":"secondary"},"dimensions":{"width":{"custom":"100%"}},"styles":"\u002d\u002dwi: 100%","classNames":"wi"},"content":"Get in touch"} /-->
<!-- /wp:wphave/group -->',
		];

		return $patterns;
	}
endif;
