<?php

/**
 * Functions to group similar wphave block patterns.
 */

if ( ! function_exists( 'wphave_block_pattern_collection_header' ) ) :

	function wphave_block_pattern_collection_header( $args = array() ) {

        $content_width = isset( $args['width'] ) ? (int) $args['width'] : 1300;

        $patterns = array();

        $patterns[] = array(
            'tags' => array('header'),
            'title' => '',
            'viewportWidth' => $content_width,
            'content' => '<!-- wp:wphave/group {"wphave":{"dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-xs) var(\u002d\u002dwphave-site-padding-xs) var(\u002d\u002dwphave-site-padding-xs) var(\u002d\u002dwphave-site-padding-xs)"},"overflow":"clip"},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-xs) var(\u002d\u002dwphave-site-padding-xs) var(\u002d\u002dwphave-site-padding-xs) var(\u002d\u002dwphave-site-padding-xs);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-xs);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-xs);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-xs);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-xs);\u002d\u002dofw: clip;\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-xs);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-xs)","classNames":"pa ofw ly ly-fl br ly-fl-t ly-fl-m","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"space-between"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: center;\u002d\u002dly-halign: space-between;\u002d\u002dly-fl-direction: row;\u002d\u002dly-t-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-t-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-t-fl-wrap: no-wrap;\u002d\u002dly-t-fl-itm: 0 1 auto;\u002d\u002dly-t-valign: center;\u002d\u002dly-t-halign: space-between;\u002d\u002dly-t-fl-direction: row;\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-fl-wrap: no-wrap;\u002d\u002dly-m-fl-itm: 0 1 auto;\u002d\u002dly-m-valign: center;\u002d\u002dly-m-halign: space-between;\u002d\u002dly-m-fl-direction: row","frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"}}} -->
<!-- wp:wphave/site-logo {"wphave":{"dimensions":{"width":{"custom":"105px"}},"styles":"\u002d\u002dwi: 105px","classNames":"wi"}} /-->

<!-- wp:wphave/navigation -->
<!-- wp:wphave/navigation-link {"content":"Home"} /-->

<!-- wp:wphave/navigation-link {"content":"About"} /-->

<!-- wp:wphave/navigation-link {"content":"Contact"} /-->
<!-- /wp:wphave/navigation -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'tags' => array('header'),
            'title' => '',
            'viewportWidth' => $content_width,
            'content' => '<!-- wp:wphave/group {"wphave":{"dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-xs) var(\u002d\u002dwphave-site-padding-xs) var(\u002d\u002dwphave-site-padding-xs) var(\u002d\u002dwphave-site-padding-xs)"},"overflow":"clip"},"background":{"color":{"base":"var(\u002d\u002dwphave-site-color-palette-black)"}},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-xs) var(\u002d\u002dwphave-site-padding-xs) var(\u002d\u002dwphave-site-padding-xs) var(\u002d\u002dwphave-site-padding-xs);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-xs);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-xs);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-xs);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-xs);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-palette-black);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-xs);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-xs)","classNames":"pa ofw ly ly-fl bg-co bg br ly-fl-t ly-fl-m","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"space-between"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: center;\u002d\u002dly-halign: space-between;\u002d\u002dly-fl-direction: row;\u002d\u002dly-t-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-t-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-t-fl-wrap: no-wrap;\u002d\u002dly-t-fl-itm: 0 1 auto;\u002d\u002dly-t-valign: center;\u002d\u002dly-t-halign: space-between;\u002d\u002dly-t-fl-direction: row;\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-fl-wrap: no-wrap;\u002d\u002dly-m-fl-itm: 0 1 auto;\u002d\u002dly-m-valign: center;\u002d\u002dly-m-halign: space-between;\u002d\u002dly-m-fl-direction: row","frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"}}} -->
<!-- wp:wphave/site-logo {"wphave":{"dimensions":{"width":{"custom":"105px"}},"styles":"\u002d\u002dwi: 105px","classNames":"wi"}} /-->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"start"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-fl-wrap: wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: center;\u002d\u002dly-halign: start;\u002d\u002dly-fl-direction: row;\u002d\u002dly-t-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-t-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-t-fl-wrap: wrap;\u002d\u002dly-t-fl-itm: 0 1 auto;\u002d\u002dly-t-valign: center;\u002d\u002dly-t-halign: start;\u002d\u002dly-t-fl-direction: row;\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-fl-wrap: wrap;\u002d\u002dly-m-fl-itm: 0 1 auto;\u002d\u002dly-m-valign: center;\u002d\u002dly-m-halign: start;\u002d\u002dly-m-fl-direction: row","classNames":"ly ly-fl ly-fl-wp ly-fl-t ly-t-fl-wp ly-fl-m ly-m-fl-wp"}} -->
<!-- wp:wphave/navigation {"wphave":{"settings":{"colors":{"text":"var(\u002d\u002dwphave-site-color-palette-white)"}},"styles":"\u002d\u002dnav-menu-text-color: var(\u002d\u002dwphave-site-color-palette-white)"}} -->
<!-- wp:wphave/navigation-link {"content":"Home"} /-->

<!-- wp:wphave/navigation-link {"content":"About"} /-->

<!-- wp:wphave/navigation-link {"content":"Contact"} /-->
<!-- /wp:wphave/navigation -->

<!-- wp:wphave/button {"wphave":{"mobile":{"visibility":{"visually":"hidden"}},"classNames":"vby-vis-m-h"},"content":"Explore"} /-->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'tags' => array('header'),
            'title' => '',
            'viewportWidth' => $content_width,
            'content' => '<!-- wp:wphave/group {"wphave":{"dimensions":{"spacing":{"padding":"16px var(\u002d\u002dwphave-site-padding-xs) var(\u002d\u002dwphave-site-padding-xs) var(\u002d\u002dwphave-site-padding-xs)"},"overflow":"clip"},"styles":"\u002d\u002dpa: 16px var(\u002d\u002dwphave-site-padding-xs) var(\u002d\u002dwphave-site-padding-xs) var(\u002d\u002dwphave-site-padding-xs);\u002d\u002dpa-top: 16px;\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-xs);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-xs);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-xs);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background);\u002d\u002dbo-width: 0 0 1px 0;\u002d\u002dbo-style: none none solid none;\u002d\u002dbo-color: transparent transparent var(\u002d\u002dwphave-site-color-background-contrast-3) transparent","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-xs);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-xs)","classNames":"bsz-full pa ofw ly ly-fl bg-co bg bo ly-fl-t ly-fl-m","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"space-between"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: center;\u002d\u002dly-halign: space-between;\u002d\u002dly-fl-direction: row;\u002d\u002dly-t-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-t-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-t-fl-wrap: no-wrap;\u002d\u002dly-t-fl-itm: 0 1 auto;\u002d\u002dly-t-valign: center;\u002d\u002dly-t-halign: space-between;\u002d\u002dly-t-fl-direction: row;\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-fl-wrap: no-wrap;\u002d\u002dly-m-fl-itm: 0 1 auto;\u002d\u002dly-m-valign: center;\u002d\u002dly-m-halign: space-between;\u002d\u002dly-m-fl-direction: row","features":{"size":"full"},"background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background)"}},"frame":{"border":{"width":"0 0 1px 0","style":"none none solid none","color":"transparent transparent var(\u002d\u002dwphave-site-color-background-contrast-3) transparent"}}}} -->
<!-- wp:wphave/site-logo {"wphave":{"dimensions":{"width":{"custom":"105px"}},"styles":"\u002d\u002dwi: 105px","classNames":"wi"}} /-->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"start"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-fl-wrap: wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: center;\u002d\u002dly-halign: start;\u002d\u002dly-fl-direction: row;\u002d\u002dly-t-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-t-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-t-fl-wrap: wrap;\u002d\u002dly-t-fl-itm: 0 1 auto;\u002d\u002dly-t-valign: center;\u002d\u002dly-t-halign: start;\u002d\u002dly-t-fl-direction: row;\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-fl-wrap: wrap;\u002d\u002dly-m-fl-itm: 0 1 auto;\u002d\u002dly-m-valign: center;\u002d\u002dly-m-halign: start;\u002d\u002dly-m-fl-direction: row","classNames":"ly ly-fl ly-fl-wp ly-fl-t ly-t-fl-wp ly-fl-m ly-m-fl-wp"}} -->
<!-- wp:wphave/navigation -->
<!-- wp:wphave/navigation-link {"content":"Home"} /-->

<!-- wp:wphave/navigation-link {"content":"About"} /-->

<!-- wp:wphave/navigation-link {"content":"Contact"} /-->
<!-- /wp:wphave/navigation -->

<!-- wp:wphave/button {"content":"Explore"} /-->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'tags' => array('header'),
            'title' => '',
            'viewportWidth' => $content_width,
            'content' => '<!-- wp:wphave/group {"wphave":{"dimensions":{"spacing":{"padding":"16px var(\u002d\u002dwphave-site-padding-xs) var(\u002d\u002dwphave-site-padding-xs) var(\u002d\u002dwphave-site-padding-xs)"},"overflow":"clip"},"styles":"\u002d\u002dpa: 16px var(\u002d\u002dwphave-site-padding-xs) var(\u002d\u002dwphave-site-padding-xs) var(\u002d\u002dwphave-site-padding-xs);\u002d\u002dpa-top: 16px;\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-xs);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-xs);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-xs);\u002d\u002dofw: clip;\u002d\u002dbg-co: #3e3e3e","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-xs);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-xs)","classNames":"bsz-full pa ofw ly ly-fl bg-co bg ly-fl-t ly-fl-m","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"space-between"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: center;\u002d\u002dly-halign: space-between;\u002d\u002dly-fl-direction: row;\u002d\u002dly-t-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-t-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-t-fl-wrap: no-wrap;\u002d\u002dly-t-fl-itm: 0 1 auto;\u002d\u002dly-t-valign: center;\u002d\u002dly-t-halign: space-between;\u002d\u002dly-t-fl-direction: row;\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-fl-wrap: no-wrap;\u002d\u002dly-m-fl-itm: 0 1 auto;\u002d\u002dly-m-valign: center;\u002d\u002dly-m-halign: space-between;\u002d\u002dly-m-fl-direction: row","features":{"size":"full"},"background":{"color":{"base":"#3e3e3e"}}}} -->
<!-- wp:wphave/site-logo {"wphave":{"dimensions":{"width":{"custom":"105px"}},"styles":"\u002d\u002dwi: 105px","classNames":"wi"}} /-->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"start"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-fl-wrap: wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: center;\u002d\u002dly-halign: start;\u002d\u002dly-fl-direction: row;\u002d\u002dly-t-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-t-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-t-fl-wrap: wrap;\u002d\u002dly-t-fl-itm: 0 1 auto;\u002d\u002dly-t-valign: center;\u002d\u002dly-t-halign: start;\u002d\u002dly-t-fl-direction: row;\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-fl-wrap: wrap;\u002d\u002dly-m-fl-itm: 0 1 auto;\u002d\u002dly-m-valign: center;\u002d\u002dly-m-halign: start;\u002d\u002dly-m-fl-direction: row","classNames":"ly ly-fl ly-fl-wp ly-fl-t ly-t-fl-wp ly-fl-m ly-m-fl-wp"}} -->
<!-- wp:wphave/navigation {"wphave":{"settings":{"colors":{"text":"var(\u002d\u002dwphave-site-color-palette-white)"}},"styles":"\u002d\u002dnav-menu-text-color: var(\u002d\u002dwphave-site-color-palette-white)"}} -->
<!-- wp:wphave/navigation-link {"content":"Home"} /-->

<!-- wp:wphave/navigation-link {"content":"About"} /-->

<!-- wp:wphave/navigation-link {"content":"Contact"} /-->
<!-- /wp:wphave/navigation -->

<!-- wp:wphave/button {"content":"Explore"} /-->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        return $patterns;

	}

endif;