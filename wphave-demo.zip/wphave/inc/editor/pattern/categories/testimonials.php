<?php

/**
 * Functions to group testimonial block patterns.
 */

if (!function_exists('wphave_block_pattern_collection_testimonials')):
	function wphave_block_pattern_collection_testimonials($args = []) {
		if (!wphave_release_feature_ready('patternTestimonials')) {
			return [];
		}

		$content_width = isset($args['width']) ? (int) $args['width'] : 1300;
		$slots = is_array($args['slots'] ?? null) ? $args['slots'] : [];
		$patterns = [];

		$patterns[] = [
			'key' => 'testimonial-featured-split',
			'tags' => ['testimonials', 'proof'],
			'title' => __('Testimonial Featured Split', 'wphave'),
			'keywords' => ['testimonial', 'quote', 'proof', 'split'],
			'viewportWidth' => $content_width,
			'ai' => [
				'enabled' => true,
				'roles' => ['testimonial', 'proof', 'section'],
				'layout' => ['split', 'featured'],
				'width' => ['full'],
				'visual' => ['quote', 'card'],
				'content' => ['heading', 'body', 'quote', 'cite'],
				'intent' => ['trust', 'social-proof'],
				'treatment' => ['editorial', 'spacious', 'framed'],
				'description' =>
					'Featured testimonial split with intro copy and a large quote card.',
			],
			'content' =>
				'<!-- wp:wphave/group {"wphave":{"classNames":"bsz-full wi-in pa ofw ly ly-fl bg-co bg ly-fl-t ly-fl-m ly-fl-dtn-vtl","features":{"size":"full"},"dimensions":{"innerWidth":{"custom":"1180px"},"overflow":"clip","spacing":{"padding":"var(--wphave-site-gap-size-4xl) var(--wphave-site-spacing) var(--wphave-site-gap-size-4xl) var(--wphave-site-spacing)"}},"styles":"--wi-in: 1180px;--pa: var(--wphave-site-gap-size-4xl) var(--wphave-site-spacing) var(--wphave-site-gap-size-4xl) var(--wphave-site-spacing);--pa-top: var(--wphave-site-gap-size-4xl);--pa-right: var(--wphave-site-spacing);--pa-bottom: var(--wphave-site-gap-size-4xl);--pa-left: var(--wphave-site-spacing);--ofw: clip;--bg-co: var(--wphave-site-color-background)","stylesChild":"--left-spacing-inherit: var(--wphave-site-spacing);--right-spacing-inherit: var(--wphave-site-spacing)","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-gap-size-4xl)","gapY":"var(--wphave-site-gap-size-3xl)","flexWrap":"no-wrap","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"space-between"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-gap-size-4xl);--ly-row-gap: var(--wphave-site-gap-size-3xl);--ly-fl-wrap: no-wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: space-between;--ly-fl-direction: row;--ly-m-fl-direction: column;--ly-m-halign: start","background":{"color":{"base":"var(--wphave-site-color-background)"}}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"wi ly ly-stk","dimensions":{"width":{"custom":"40%"}},"mobile":{"dimensions":{"width":{"custom":"100%"}}},"styles":"--wi: 40%;--wi-m: 100%","layout":{"stacked":{"gap":"var(--wphave-site-gap-size-l)"}},"stylesLayout":"--ly-gap: var(--wphave-site-gap-size-l)"}} -->
' .
				wphave_pattern_slot('eyebrow', $slots) .
				'
' .
				wphave_pattern_slot('heading', ['level' => 'h2', 'size' => 'title-l'], $slots) .
				'
' .
				wphave_pattern_slot('body', ['size' => 'text-l'], $slots) .
				'
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"classNames":"wi pa ofw ly ly-stk bg-co bg br","dimensions":{"width":{"custom":"52%"},"overflow":"clip","spacing":{"padding":"var(--wphave-site-gap-size-3xl) var(--wphave-site-gap-size-3xl) var(--wphave-site-gap-size-3xl) var(--wphave-site-gap-size-3xl)"}},"mobile":{"dimensions":{"width":{"custom":"100%"}}},"styles":"--wi: 52%;--wi-m: 100%;--pa: var(--wphave-site-gap-size-3xl) var(--wphave-site-gap-size-3xl) var(--wphave-site-gap-size-3xl) var(--wphave-site-gap-size-3xl);--ofw: clip;--bg-co: var(--wphave-site-color-background-contrast-1);--br: var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners)","background":{"color":{"base":"var(--wphave-site-color-background-contrast-1)"}},"frame":{"corners":"var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners)"},"layout":{"stacked":{"gap":"var(--wphave-site-gap-size-l)"}},"stylesLayout":"--ly-gap: var(--wphave-site-gap-size-l)","stylesChild":"--left-spacing-inherit: var(--wphave-site-gap-size-3xl);--right-spacing-inherit: var(--wphave-site-gap-size-3xl)"}} -->
' .
				wphave_pattern_slot(
					'testimonials.0.quote',
					'paragraph',
					['size' => 'title-xs'],
					$slots,
				) .
				'
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk","layout":{"stacked":{"gap":"var(--wphave-site-gap-size-xs)"}},"stylesLayout":"--ly-gap: var(--wphave-site-gap-size-xs)"}} -->
' .
				wphave_pattern_slot(
					'testimonials.0.cite',
					['level' => 'h3', 'size' => 'title-2xs'],
					$slots,
				) .
				'
' .
				wphave_pattern_slot('testimonials.0.role', 'paragraph', [], $slots) .
				'
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->',
		];

		$patterns[] = [
			'key' => 'testimonials-grid',
			'tags' => ['testimonials', 'proof'],
			'title' => __('Testimonials Grid', 'wphave'),
			'keywords' => ['testimonial', 'quotes', 'grid'],
			'viewportWidth' => $content_width,
			'ai' => [
				'enabled' => true,
				'roles' => ['testimonial', 'proof', 'section'],
				'layout' => ['centered', 'grid'],
				'width' => ['content-width'],
				'visual' => ['quote', 'cards'],
				'content' => ['heading', 'body', 'quote', 'cite'],
				'intent' => ['trust', 'social-proof'],
				'treatment' => ['minimal', 'structured'],
				'description' => 'Centered testimonial section with three quote cards.',
			],
			'content' =>
				'<!-- wp:wphave/group {"wphave":{"classNames":"bsz-full wi-in pa ofw ly ly-stk ly-co-pos bg-co bg txta","features":{"size":"full"},"dimensions":{"innerWidth":{"custom":"1180px"},"overflow":"clip","spacing":{"padding":"var(--wphave-site-gap-size-4xl) var(--wphave-site-spacing) var(--wphave-site-gap-size-4xl) var(--wphave-site-spacing)"}},"styles":"--wi-in: 1180px;--pa: var(--wphave-site-gap-size-4xl) var(--wphave-site-spacing) var(--wphave-site-gap-size-4xl) var(--wphave-site-spacing);--pa-top: var(--wphave-site-gap-size-4xl);--pa-right: var(--wphave-site-spacing);--pa-bottom: var(--wphave-site-gap-size-4xl);--pa-left: var(--wphave-site-spacing);--ofw: clip;--ly-co-pos-h: center;--ly-co-pos-v: center;--bg-co: var(--wphave-site-color-background-contrast-1);--txta: center","stylesChild":"--left-spacing-inherit: var(--wphave-site-spacing);--right-spacing-inherit: var(--wphave-site-spacing)","text":{"align":"center"},"layout":{"stacked":{"contentPosition":"center","gap":"var(--wphave-site-gap-size-3xl)"}},"stylesLayout":"--ly-gap: var(--wphave-site-gap-size-3xl)","background":{"color":{"base":"var(--wphave-site-color-background-contrast-1)"}}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"wi ly ly-stk ly-co-pos","dimensions":{"width":{"custom":"760px"}},"mobile":{"dimensions":{"width":{"custom":"100%"}}},"styles":"--wi: 760px;--wi-m: 100%;--ly-co-pos-h: center;--ly-co-pos-v: center","layout":{"stacked":{"contentPosition":"center","gap":"var(--wphave-site-gap-size-m)"}},"stylesLayout":"--ly-gap: var(--wphave-site-gap-size-m)"}} -->' .
				wphave_pattern_slot('eyebrow', $slots) .
				wphave_pattern_slot('heading', ['level' => 'h2', 'size' => 'title-l'], $slots) .
				wphave_pattern_slot('body', $slots) .
				'<!-- /wp:wphave/group -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-gr ly-gr-m","layout":{"type":"grid","grid":{"columns":3,"gapX":"var(--wphave-site-gap-size-m)","gapY":"var(--wphave-site-gap-size-m)","alignVertical":"stretch"}},"stylesLayout":"--ly-col: 3;--ly-m-col: 1;--ly-column-gap: var(--wphave-site-gap-size-m);--ly-row-gap: var(--wphave-site-gap-size-m);--ly-valign: stretch"}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"pa ly ly-stk bg-co bg br","dimensions":{"spacing":{"padding":"var(--wphave-site-gap-size-xl) var(--wphave-site-gap-size-xl) var(--wphave-site-gap-size-xl) var(--wphave-site-gap-size-xl)"}},"styles":"--pa: var(--wphave-site-gap-size-xl) var(--wphave-site-gap-size-xl) var(--wphave-site-gap-size-xl) var(--wphave-site-gap-size-xl);--bg-co: var(--wphave-site-color-background);--br: var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners)","background":{"color":{"base":"var(--wphave-site-color-background)"}},"frame":{"corners":"var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners)"},"layout":{"stacked":{"gap":"var(--wphave-site-gap-size-l)"}},"stylesLayout":"--ly-gap: var(--wphave-site-gap-size-l)"}} -->' .
				wphave_pattern_slot('testimonials.0.quote', 'paragraph', [], $slots) .
				wphave_pattern_slot(
					'testimonials.0.cite',
					['level' => 'h3', 'size' => 'title-2xs'],
					$slots,
				) .
				'<!-- /wp:wphave/group -->
<!-- wp:wphave/group {"wphave":{"classNames":"pa ly ly-stk bg-co bg br","dimensions":{"spacing":{"padding":"var(--wphave-site-gap-size-xl) var(--wphave-site-gap-size-xl) var(--wphave-site-gap-size-xl) var(--wphave-site-gap-size-xl)"}},"styles":"--pa: var(--wphave-site-gap-size-xl) var(--wphave-site-gap-size-xl) var(--wphave-site-gap-size-xl) var(--wphave-site-gap-size-xl);--bg-co: var(--wphave-site-color-accent);--br: var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners)","background":{"color":{"base":"var(--wphave-site-color-accent)"}},"frame":{"corners":"var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners)"},"layout":{"stacked":{"gap":"var(--wphave-site-gap-size-l)"}},"stylesLayout":"--ly-gap: var(--wphave-site-gap-size-l)"}} -->' .
				wphave_pattern_slot('testimonials.1.quote', 'paragraph', [], $slots) .
				wphave_pattern_slot(
					'testimonials.1.cite',
					['level' => 'h3', 'size' => 'title-2xs'],
					$slots,
				) .
				'<!-- /wp:wphave/group -->
<!-- wp:wphave/group {"wphave":{"classNames":"pa ly ly-stk bg-co bg br","dimensions":{"spacing":{"padding":"var(--wphave-site-gap-size-xl) var(--wphave-site-gap-size-xl) var(--wphave-site-gap-size-xl) var(--wphave-site-gap-size-xl)"}},"styles":"--pa: var(--wphave-site-gap-size-xl) var(--wphave-site-gap-size-xl) var(--wphave-site-gap-size-xl) var(--wphave-site-gap-size-xl);--bg-co: var(--wphave-site-color-background);--br: var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners)","background":{"color":{"base":"var(--wphave-site-color-background)"}},"frame":{"corners":"var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners)"},"layout":{"stacked":{"gap":"var(--wphave-site-gap-size-l)"}},"stylesLayout":"--ly-gap: var(--wphave-site-gap-size-l)"}} -->' .
				wphave_pattern_slot('testimonials.2.quote', 'paragraph', [], $slots) .
				wphave_pattern_slot(
					'testimonials.2.cite',
					['level' => 'h3', 'size' => 'title-2xs'],
					$slots,
				) .
				'<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->',
		];

		return $patterns;
	}
endif;
