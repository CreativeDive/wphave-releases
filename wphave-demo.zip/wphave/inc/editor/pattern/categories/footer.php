<?php

/**
 * Functions to group similar wphave block patterns.
 */

if ( ! function_exists( 'wphave_block_pattern_collection_footer' ) ) :

	function wphave_block_pattern_collection_footer( $args = array() ) {

        $spacing = 300;
        $content_width = isset( $args['width'] ) ? (int) $args['width'] : 1300;

        $patterns = array();

        $patterns[] = array(
            'tags' => array('footer'),
            'title' => '',
            'viewportWidth' => $content_width + $spacing,
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-full pa ly ly-fl ly-fl-wp txta tf-fs tf-fs-text-xs ly-fl-t ly-t-fl-wp ly-fl-dtn-vtl","features":{"size":"full"},"dimensions":{"spacing":{"padding":"var(--wphave-site-padding-top) var(--wphave-site-padding-right) var(--wphave-site-padding-bottom) var(--wphave-site-padding-left)"}},"styles":"--pa: var(--wphave-site-padding-top) var(--wphave-site-padding-right) var(--wphave-site-padding-bottom) var(--wphave-site-padding-left);--pa-top: var(--wphave-site-padding-top);--pa-right: var(--wphave-site-padding-right);--pa-bottom: var(--wphave-site-padding-bottom);--pa-left: var(--wphave-site-padding-left);--txta: none","stylesChild":"--left-spacing-inherit: var(--wphave-site-padding-left);--right-spacing-inherit: var(--wphave-site-padding-right)","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-layout-gap)","gapY":"var(--wphave-site-layout-gap)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"space-between"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-layout-gap);--ly-row-gap: var(--wphave-site-layout-gap);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: space-between;--ly-fl-direction: row;--ly-t-column-gap: var(--wphave-site-layout-gap);--ly-t-row-gap: var(--wphave-site-layout-gap);--ly-t-fl-wrap: wrap;--ly-t-fl-itm: 0 1 auto;--ly-t-valign: center;--ly-t-halign: center;--ly-t-fl-direction: column","text":{"align":"none","typeface":{"size":{"type":"text-xs"}}},"tablet":{"layout":{"stacked":{"flexDirection":"column","alignHorizontal":"center"}}}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-fl ly-fl-wp txta ly-fl-t ly-t-fl-wp","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-gap-size-s)","gapY":"var(--wphave-site-gap-size-s)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"center"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-gap-size-s);--ly-row-gap: var(--wphave-site-gap-size-s);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: center;--ly-fl-direction: row;--ly-t-column-gap: var(--wphave-site-gap-size-s);--ly-t-row-gap: var(--wphave-site-gap-size-s);--ly-t-fl-wrap: wrap;--ly-t-fl-itm: 0 1 auto;--ly-t-valign: center;--ly-t-halign: center;--ly-t-fl-direction: row","tablet":{"layout":{"stacked":{"alignHorizontal":"center"}}},"text":{"align":"center"},"styles":"--txta: center"}} -->
<!-- wp:wphave/site-logo {"wphave":{"settings":{"imageSize":"auto"},"dimensions":{"width":{"custom":"100px"}},"styles":"\u002d\u002dwi: 100px","classNames":"wi"}} /-->

<!-- wp:wphave/group {"wphave":{"classNames":"wi hgt ofw ly ly-stk bo vby-oty-m vby-vis-m-h","frame":{"border":{"width":"0 0 0 1px","style":"none none none solid","color":"transparent transparent transparent var(\u002d\u002dwphave-site-color-background-contrast-3)"}},"styles":"\u002d\u002dwi: 1px;\u002d\u002dhgt: 26px;\u002d\u002dofw: hidden;\u002d\u002dbo-width: 0 0 0 1px;\u002d\u002dbo-style: none none none solid;\u002d\u002dbo-color: transparent transparent transparent var(\u002d\u002dwphave-site-color-background-contrast-3);\u002d\u002dvby-oty-m: 1","dimensions":{"width":{"limit":"max","custom":"1px"},"overflow":"hidden","height":{"custom":"26px"}},"mobile":{"visibility":{"opacity":1,"visually":"hidden"}}}} /-->

<!-- wp:wphave/paragraph {"wphave":{"text":{"typeface":{"size":{"type":"text-xs"}}},"classNames":"tf-fs tf-fs-text-xs"},"content":"\u003cspan class=\u0022rt-char\u0022\u003e©\u003c/span\u003eCopyright by \u003cspan data-source=\u0022general\u0022 data-post-id=\u0022\u0022 data-field=\u0022site_title\u0022 data-field-name=\u0022\u0022 class=\u0022rt-dyd\u0022\u003e{{site_title}}\u003c/span\u003e\u003cspan class=\u0022rt-char\u0022\u003e−\u003c/span\u003e2020 - \u003cspan data-source=\u0022general\u0022 data-post-id=\u0022\u0022 data-field=\u0022current_year\u0022 data-field-name=\u0022\u0022 class=\u0022rt-dyd\u0022\u003e{{current_year}}\u003c/span\u003e","metadata":{"name":"Copyright row"}} /-->
<!-- /wp:wphave/group -->

<!-- wp:wphave/navigation {"wphave":{"settings":{"collapseBehavior":"never"}}} -->
<!-- wp:wphave/navigation-link {"content":"Terms and Conditions"} /-->

<!-- wp:wphave/navigation-separator {"wphave":{"settings":{"colors":{"bg":"var(\u002d\u002dwphave-site-color-background-contrast-3)"}},"styles":"\u002d\u002dnav-menu-separator-color: var(\u002d\u002dwphave-site-color-background-contrast-3)"}} /-->

<!-- wp:wphave/navigation-link {"content":"Data Privacy"} /-->

<!-- wp:wphave/navigation-separator {"wphave":{"settings":{"colors":{"bg":"var(\u002d\u002dwphave-site-color-background-contrast-3)"}},"styles":"\u002d\u002dnav-menu-separator-color: var(\u002d\u002dwphave-site-color-background-contrast-3)"}} /-->

<!-- wp:wphave/navigation-link {"content":"License Terms"} /-->
<!-- /wp:wphave/navigation -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'tags' => array('footer'),
            'title' => '',
            'viewportWidth' => $content_width + $spacing,
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-full pa ly ly-fl ly-fl-wp txta tf-fs tf-fs-text-xs ly-fl-t ly-t-fl-wp ly-fl-dtn-vtl","features":{"size":"full"},"dimensions":{"spacing":{"padding":"var(--wphave-site-padding-top) var(--wphave-site-padding-right) var(--wphave-site-padding-bottom) var(--wphave-site-padding-left)"}},"styles":"--pa: var(--wphave-site-padding-top) var(--wphave-site-padding-right) var(--wphave-site-padding-bottom) var(--wphave-site-padding-left);--pa-top: var(--wphave-site-padding-top);--pa-right: var(--wphave-site-padding-right);--pa-bottom: var(--wphave-site-padding-bottom);--pa-left: var(--wphave-site-padding-left);--txta: none","stylesChild":"--left-spacing-inherit: var(--wphave-site-padding-left);--right-spacing-inherit: var(--wphave-site-padding-right)","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-layout-gap)","gapY":"var(--wphave-site-layout-gap)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"center"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-layout-gap);--ly-row-gap: var(--wphave-site-layout-gap);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: center;--ly-fl-direction: row;--ly-t-column-gap: var(--wphave-site-layout-gap);--ly-t-row-gap: var(--wphave-site-layout-gap);--ly-t-fl-wrap: wrap;--ly-t-fl-itm: 0 1 auto;--ly-t-valign: center;--ly-t-halign: center;--ly-t-fl-direction: column","text":{"align":"none","typeface":{"size":{"type":"text-xs"}}},"tablet":{"layout":{"stacked":{"flexDirection":"column","alignHorizontal":"center"}}}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"wi ly ly-fl ly-fl-wp ly-fl-t ly-t-fl-wp ly-fl-dtn-vtl","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-layout-gap)","gapY":"var(--wphave-site-layout-gap)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"space-between"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-layout-gap);--ly-row-gap: var(--wphave-site-layout-gap);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: space-between;--ly-fl-direction: row;--ly-t-column-gap: var(--wphave-site-layout-gap);--ly-t-row-gap: var(--wphave-site-layout-gap);--ly-t-fl-wrap: wrap;--ly-t-fl-itm: 0 1 auto;--ly-t-valign: center;--ly-t-halign: center;--ly-t-fl-direction: column","dimensions":{"width":{"custom":"100%"}},"styles":"--wi: 100%","tablet":{"layout":{"stacked":{"flexDirection":"column","alignHorizontal":"center"}}}}} -->
<!-- wp:wphave/site-logo {"wphave":{"settings":{"imageSize":"auto"},"dimensions":{"width":{"custom":"100px"}},"styles":"\u002d\u002dwi: 100px","classNames":"wi"}} /-->

<!-- wp:wphave/paragraph {"content":"Insert Social Icons Block here"} /-->
<!-- /wp:wphave/group -->

<!-- wp:wphave/line {"wphave":{"settings":{"size":"1px","colors":{"line":"var(\u002d\u002dwphave-site-color-background-contrast-2)"}},"styles":"\u002d\u002dline-size: 1px;\u002d\u002dline-color: var(\u002d\u002dwphave-site-color-background-contrast-2)"}} /-->

<!-- wp:wphave/group {"wphave":{"classNames":"wi ly ly-fl ly-fl-wp ly-fl-t ly-t-fl-wp ly-fl-dtn-vtl","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-layout-gap)","gapY":"var(--wphave-site-layout-gap)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"space-between"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-layout-gap);--ly-row-gap: var(--wphave-site-layout-gap);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: space-between;--ly-fl-direction: row;--ly-t-column-gap: var(--wphave-site-layout-gap);--ly-t-row-gap: var(--wphave-site-layout-gap);--ly-t-fl-wrap: wrap;--ly-t-fl-itm: 0 1 auto;--ly-t-valign: center;--ly-t-halign: center;--ly-t-fl-direction: column","dimensions":{"width":{"custom":"100%"}},"styles":"--wi: 100%","tablet":{"layout":{"stacked":{"alignHorizontal":"center","flexDirection":"column"}}}}} -->
<!-- wp:wphave/paragraph {"wphave":{"text":{"typeface":{"size":{"type":"text-xs"}}},"classNames":"tf-fs tf-fs-text-xs"},"content":"\u003cspan class=\u0022rt-char\u0022\u003e©\u003c/span\u003eCopyright by \u003cspan data-source=\u0022general\u0022 data-post-id=\u0022\u0022 data-field=\u0022site_title\u0022 data-field-name=\u0022\u0022 class=\u0022rt-dyd\u0022\u003e{{site_title}}\u003c/span\u003e\u003cspan class=\u0022rt-char\u0022\u003e−\u003c/span\u003e2020 - \u003cspan data-source=\u0022general\u0022 data-post-id=\u0022\u0022 data-field=\u0022current_year\u0022 data-field-name=\u0022\u0022 class=\u0022rt-dyd\u0022\u003e{{current_year}}\u003c/span\u003e","metadata":{"name":"Copyright row"}} /-->

<!-- wp:wphave/navigation {"wphave":{"settings":{"collapseBehavior":"never"}}} -->
<!-- wp:wphave/navigation-link {"content":"Terms and Conditions"} /-->

<!-- wp:wphave/navigation-separator {"wphave":{"settings":{"colors":{"bg":"var(\u002d\u002dwphave-site-color-background-contrast-3)"}},"styles":"\u002d\u002dnav-menu-separator-color: var(\u002d\u002dwphave-site-color-background-contrast-3)"}} /-->

<!-- wp:wphave/navigation-link {"content":"Data Privacy"} /-->

<!-- wp:wphave/navigation-separator {"wphave":{"settings":{"colors":{"bg":"var(\u002d\u002dwphave-site-color-background-contrast-3)"}},"styles":"\u002d\u002dnav-menu-separator-color: var(\u002d\u002dwphave-site-color-background-contrast-3)"}} /-->

<!-- wp:wphave/navigation-link {"content":"License Terms"} /-->
<!-- /wp:wphave/navigation -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'tags' => array('footer'),
            'title' => '',
            'viewportWidth' => $content_width + $spacing,
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-full pa ly ly-stk txta","features":{"size":"full"},"dimensions":{"spacing":{"padding":"var(--wphave-site-padding-top) var(--wphave-site-padding-right) var(--wphave-site-padding-bottom) var(--wphave-site-padding-left)"}},"styles":"--pa: var(--wphave-site-padding-top) var(--wphave-site-padding-right) var(--wphave-site-padding-bottom) var(--wphave-site-padding-left);--pa-top: var(--wphave-site-padding-top);--pa-right: var(--wphave-site-padding-right);--pa-bottom: var(--wphave-site-padding-bottom);--pa-left: var(--wphave-site-padding-left);--txta: none","stylesChild":"--left-spacing-inherit: var(--wphave-site-padding-left);--right-spacing-inherit: var(--wphave-site-padding-right)","layout":{},"text":{"align":"none"}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-fl ly-fl-wp txta tf-fs tf-fs-text-s ly-fl-t ly-t-fl-wp ly-fl-dtn-vtl","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-gap-size-3xl)","gapY":"var(--wphave-site-gap-size-3xl)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"start","alignHorizontal":"space-between"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-gap-size-3xl);--ly-row-gap: var(--wphave-site-gap-size-3xl);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: start;--ly-halign: space-between;--ly-fl-direction: row;--ly-t-column-gap: var(--wphave-site-gap-size-3xl);--ly-t-row-gap: var(--wphave-site-gap-size-3xl);--ly-t-fl-wrap: wrap;--ly-t-fl-itm: 0 1 auto;--ly-t-valign: center;--ly-t-halign: start;--ly-t-fl-direction: column","text":{"align":"none","typeface":{"size":{"type":"text-s"}}},"styles":"--txta: none","tablet":{"layout":{"stacked":{"flexDirection":"column","alignHorizontal":"center"}}}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk ly-t-co-pos txta-t","layout":{},"tablet":{"layout":{"stacked":{"flexDirection":"column","alignHorizontal":"center","contentPosition":"center"}},"text":{"align":"center"}},"styles":"--ly-t-co-pos-h: center;--ly-t-co-pos-v: center;--txta-t: center"}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk ly-t-co-pos","layout":{"stacked":{"gap":"var(--wphave-site-gap-size-s)"}},"stylesLayout":"--ly-gap: var(--wphave-site-gap-size-s);--ly-t-gap: var(--wphave-site-gap-size-s)","tablet":{"layout":{"stacked":{"contentPosition":"center"}}},"styles":"--ly-t-co-pos-h: center;--ly-t-co-pos-v: center"}} -->
<!-- wp:wphave/site-logo {"wphave":{"settings":{"imageSize":"auto"},"dimensions":{"width":{"custom":"100px"}},"styles":"\u002d\u002dwi: 100px","classNames":"wi"}} /-->

<!-- wp:wphave/paragraph {"content":"Lorem ipsum dolor sit amet, consectetuer adipiscing."} /-->
<!-- /wp:wphave/group -->

<!-- wp:wphave/paragraph {"content":"Insert Social Icons Block here"} /-->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-fl ly-fl-wp","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-gap-size-4xl)","gapY":"var(--wphave-site-gap-size-4xl)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"start","alignHorizontal":"start"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-gap-size-4xl);--ly-row-gap: var(--wphave-site-gap-size-4xl);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: start;--ly-halign: start;--ly-fl-direction: row"}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk"}} -->
<!-- wp:wphave/paragraph {"wphave":{"settings":{"formats":["bold","uppercase"]},"classNames":"is-bold is-uppercase tx-co tf-fs tf-fs-text-xs","text":{"typeface":{"size":{"type":"text-xs"}},"colors":{"text":"var(\u002d\u002dwphave-site-color-text-subtle-5)"}},"styles":"\u002d\u002dtx-co: var(\u002d\u002dwphave-site-color-text-subtle-5)"},"content":"Product"} /-->

<!-- wp:wphave/navigation {"wphave":{"settings":{"collapseBehavior":"never"},"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-xs)","gapY":"var(\u002d\u002dwphave-site-gap-size-xs)","flexDirection":"column"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-xs);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-xs);\u002d\u002dly-fl-direction: column"}} -->
<!-- wp:wphave/navigation-link {"content":"Overview"} /-->

<!-- wp:wphave/navigation-link {"content":"Features"} /-->

<!-- wp:wphave/navigation-link {"content":"Solutions"} /-->

<!-- wp:wphave/navigation-link {"content":"Tutorials"} /-->
<!-- /wp:wphave/navigation -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk"}} -->
<!-- wp:wphave/paragraph {"wphave":{"settings":{"formats":["bold","uppercase"]},"classNames":"is-bold is-uppercase tx-co tf-fs tf-fs-text-xs","text":{"typeface":{"size":{"type":"text-xs"}},"colors":{"text":"var(\u002d\u002dwphave-site-color-text-subtle-5)"}},"styles":"\u002d\u002dtx-co: var(\u002d\u002dwphave-site-color-text-subtle-5)"},"content":"Ressources"} /-->

<!-- wp:wphave/navigation {"wphave":{"settings":{"collapseBehavior":"never"},"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-xs)","gapY":"var(\u002d\u002dwphave-site-gap-size-xs)","flexDirection":"column"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-xs);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-xs);\u002d\u002dly-fl-direction: column"}} -->
<!-- wp:wphave/navigation-link {"content":"Blog"} /-->

<!-- wp:wphave/navigation-link {"content":"Newsletter"} /-->

<!-- wp:wphave/navigation-link {"content":"Events"} /-->

<!-- wp:wphave/navigation-link {"content":"Help center"} /-->

<!-- wp:wphave/navigation-link {"content":"Support"} /-->
<!-- /wp:wphave/navigation -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk"}} -->
<!-- wp:wphave/paragraph {"wphave":{"settings":{"formats":["bold","uppercase"]},"classNames":"is-bold is-uppercase tx-co tf-fs tf-fs-text-xs","text":{"typeface":{"size":{"type":"text-xs"}},"colors":{"text":"var(\u002d\u002dwphave-site-color-text-subtle-5)"}},"styles":"\u002d\u002dtx-co: var(\u002d\u002dwphave-site-color-text-subtle-5)"},"content":"Company"} /-->

<!-- wp:wphave/navigation {"wphave":{"settings":{"collapseBehavior":"never"},"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-xs)","gapY":"var(\u002d\u002dwphave-site-gap-size-xs)","flexDirection":"column"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-xs);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-xs);\u002d\u002dly-fl-direction: column"}} -->
<!-- wp:wphave/navigation-link {"content":"About us"} /-->

<!-- wp:wphave/navigation-link {"content":"Careers"} /-->

<!-- wp:wphave/navigation-link {"content":"Press"} /-->

<!-- wp:wphave/navigation-link {"content":"Media kit"} /-->

<!-- wp:wphave/navigation-link {"content":"Contact"} /-->
<!-- /wp:wphave/navigation -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/line {"wphave":{"settings":{"size":"1px","colors":{"line":"var(\u002d\u002dwphave-site-color-background-contrast-2)"}},"styles":"\u002d\u002dline-size: 1px;\u002d\u002dline-color: var(\u002d\u002dwphave-site-color-background-contrast-2)"}} /-->

<!-- wp:wphave/group {"wphave":{"classNames":"wi ly ly-fl ly-fl-wp txta tf-fs tf-fs-text-xs ly-fl-t ly-t-fl-wp ly-fl-dtn-vtl","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-layout-gap)","gapY":"var(--wphave-site-layout-gap)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"space-between"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-layout-gap);--ly-row-gap: var(--wphave-site-layout-gap);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: space-between;--ly-fl-direction: row;--ly-t-column-gap: var(--wphave-site-layout-gap);--ly-t-row-gap: var(--wphave-site-layout-gap);--ly-t-fl-wrap: wrap;--ly-t-fl-itm: 0 1 auto;--ly-t-valign: center;--ly-t-halign: center;--ly-t-fl-direction: column","dimensions":{"width":{"custom":"100%"}},"styles":"--wi: 100%;--txta: none","tablet":{"layout":{"stacked":{"alignHorizontal":"center","flexDirection":"column"}}},"text":{"align":"none","typeface":{"size":{"type":"text-xs"}}}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-fl ly-fl-wp txta ly-fl-t ly-t-fl-wp","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-gap-size-s)","gapY":"var(--wphave-site-gap-size-s)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"center"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-gap-size-s);--ly-row-gap: var(--wphave-site-gap-size-s);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: center;--ly-fl-direction: row;--ly-t-column-gap: var(--wphave-site-gap-size-s);--ly-t-row-gap: var(--wphave-site-gap-size-s);--ly-t-fl-wrap: wrap;--ly-t-fl-itm: 0 1 auto;--ly-t-valign: center;--ly-t-halign: center;--ly-t-fl-direction: row","tablet":{"layout":{"stacked":{"alignHorizontal":"center"}}},"text":{"align":"center"},"styles":"--txta: center"}} -->
<!-- wp:wphave/paragraph {"content":"\u003cspan class=\u0022rt-char\u0022\u003e©\u003c/span\u003eCopyright by \u003cspan data-source=\u0022general\u0022 data-post-id=\u0022\u0022 data-field=\u0022site_title\u0022 data-field-name=\u0022\u0022 class=\u0022rt-dyd\u0022\u003e{{site_title}}\u003c/span\u003e\u003cspan class=\u0022rt-char\u0022\u003e−\u003c/span\u003e2020 - \u003cspan data-source=\u0022general\u0022 data-post-id=\u0022\u0022 data-field=\u0022current_year\u0022 data-field-name=\u0022\u0022 class=\u0022rt-dyd\u0022\u003e{{current_year}}\u003c/span\u003e","metadata":{"name":"Copyright row"}} /-->
<!-- /wp:wphave/group -->

<!-- wp:wphave/navigation {"wphave":{"settings":{"collapseBehavior":"never"}}} -->
<!-- wp:wphave/navigation-link {"content":"Terms and Conditions"} /-->

<!-- wp:wphave/navigation-separator {"wphave":{"settings":{"colors":{"bg":"var(\u002d\u002dwphave-site-color-background-contrast-3)"}},"styles":"\u002d\u002dnav-menu-separator-color: var(\u002d\u002dwphave-site-color-background-contrast-3)"}} /-->

<!-- wp:wphave/navigation-link {"content":"Data Privacy"} /-->

<!-- wp:wphave/navigation-separator {"wphave":{"settings":{"colors":{"bg":"var(\u002d\u002dwphave-site-color-background-contrast-3)"}},"styles":"\u002d\u002dnav-menu-separator-color: var(\u002d\u002dwphave-site-color-background-contrast-3)"}} /-->

<!-- wp:wphave/navigation-link {"content":"License Terms"} /-->
<!-- /wp:wphave/navigation -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'tags' => array('footer'),
            'title' => '',
            'viewportWidth' => $content_width + $spacing,
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-full wi-in pa ly ly-stk ly-co-pos txta","features":{"size":"full"},"dimensions":{"spacing":{"padding":"var(--wphave-site-padding-top) 0 var(--wphave-site-padding-bottom) 0"},"innerWidth":{"custom":"100%"}},"styles":"--wi-in: 100%;--pa: var(--wphave-site-padding-top) 0 var(--wphave-site-padding-bottom) 0;--pa-top: var(--wphave-site-padding-top);--pa-right: 0;--pa-bottom: var(--wphave-site-padding-bottom);--pa-left: 0;--ly-co-pos-h: center;--ly-co-pos-v: center;--txta: none","stylesChild":"--left-spacing-inherit: 0;--right-spacing-inherit: 0","layout":{"stacked":{"contentPosition":"center"}},"text":{"align":"none"}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"wi pa ly ly-stk ly-co-pos","dimensions":{"width":{"custom":"100%"},"spacing":{"padding":"0 var(--wphave-site-padding-right) 0 var(--wphave-site-spacing)"}},"styles":"--wi: 100%;--pa: 0 var(--wphave-site-padding-right) 0 var(--wphave-site-spacing);--pa-top: 0;--pa-right: var(--wphave-site-padding-right);--pa-bottom: 0;--pa-left: var(--wphave-site-spacing);--ly-co-pos-h: center;--ly-co-pos-v: center","layout":{"stacked":{"contentPosition":"center"}},"stylesChild":"--left-spacing-inherit: var(--wphave-site-spacing);--right-spacing-inherit: var(--wphave-site-padding-right)"}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"bsz-content ly ly-fl ly-fl-wp ly-fl-t ly-t-fl-wp ly-fl-dtn-vtl","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-gap-size-3xl)","gapY":"var(--wphave-site-gap-size-3xl)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"start","alignHorizontal":"space-between"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-gap-size-3xl);--ly-row-gap: var(--wphave-site-gap-size-3xl);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: start;--ly-halign: space-between;--ly-fl-direction: row;--ly-t-column-gap: var(--wphave-site-gap-size-3xl);--ly-t-row-gap: var(--wphave-site-gap-size-3xl);--ly-t-fl-wrap: wrap;--ly-t-fl-itm: 0 1 auto;--ly-t-valign: center;--ly-t-halign: start;--ly-t-fl-direction: column","tablet":{"layout":{"stacked":{"flexDirection":"column","alignHorizontal":"center"}}},"features":{"size":"content"}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk ly-t-co-pos txta-t","layout":{},"tablet":{"layout":{"stacked":{"flexDirection":"column","alignHorizontal":"center","contentPosition":"center"}},"text":{"align":"center"}},"styles":"--ly-t-co-pos-h: center;--ly-t-co-pos-v: center;--txta-t: center"}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk ly-t-co-pos","layout":{"stacked":{"gap":"var(--wphave-site-gap-size-s)"}},"stylesLayout":"--ly-gap: var(--wphave-site-gap-size-s);--ly-t-gap: var(--wphave-site-gap-size-s)","tablet":{"layout":{"stacked":{"contentPosition":"center"}}},"styles":"--ly-t-co-pos-h: center;--ly-t-co-pos-v: center"}} -->
<!-- wp:wphave/site-logo {"wphave":{"settings":{"imageSize":"auto"},"dimensions":{"width":{"custom":"100px"}},"styles":"\u002d\u002dwi: 100px","classNames":"wi"}} /-->

<!-- wp:wphave/paragraph {"content":"Lorem ipsum dolor sit amet, consectetuer adipiscing."} /-->
<!-- /wp:wphave/group -->

<!-- wp:wphave/paragraph {"content":"Insert Social Icons Block here"} /-->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-fl ly-fl-wp","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-gap-size-4xl)","gapY":"var(--wphave-site-gap-size-4xl)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"start","alignHorizontal":"start"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-gap-size-4xl);--ly-row-gap: var(--wphave-site-gap-size-4xl);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: start;--ly-halign: start;--ly-fl-direction: row"}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk"}} -->
<!-- wp:wphave/paragraph {"wphave":{"settings":{"formats":["bold","uppercase"]},"classNames":"is-bold is-uppercase tx-co tf-fs tf-fs-text-xs","text":{"typeface":{"size":{"type":"text-xs"}},"colors":{"text":"var(\u002d\u002dwphave-site-color-text-subtle-5)"}},"styles":"\u002d\u002dtx-co: var(\u002d\u002dwphave-site-color-text-subtle-5)"},"content":"Product"} /-->

<!-- wp:wphave/navigation {"wphave":{"settings":{"collapseBehavior":"never"},"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-xs)","gapY":"var(\u002d\u002dwphave-site-gap-size-xs)","flexDirection":"column"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-xs);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-xs);\u002d\u002dly-fl-direction: column"}} -->
<!-- wp:wphave/navigation-link {"content":"Overview"} /-->

<!-- wp:wphave/navigation-link {"content":"Features"} /-->

<!-- wp:wphave/navigation-link {"content":"Real time Preview"} /-->

<!-- wp:wphave/navigation-link {"content":"Tutorials"} /-->
<!-- /wp:wphave/navigation -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk"}} -->
<!-- wp:wphave/paragraph {"wphave":{"settings":{"formats":["bold","uppercase"]},"classNames":"is-bold is-uppercase tx-co tf-fs tf-fs-text-xs","text":{"typeface":{"size":{"type":"text-xs"}},"colors":{"text":"var(\u002d\u002dwphave-site-color-text-subtle-5)"}},"styles":"\u002d\u002dtx-co: var(\u002d\u002dwphave-site-color-text-subtle-5)"},"content":"Ressources"} /-->

<!-- wp:wphave/navigation {"wphave":{"settings":{"collapseBehavior":"never"},"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-xs)","gapY":"var(\u002d\u002dwphave-site-gap-size-xs)","flexDirection":"column"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-xs);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-xs);\u002d\u002dly-fl-direction: column"}} -->
<!-- wp:wphave/navigation-link {"content":"Blog"} /-->

<!-- wp:wphave/navigation-link {"content":"Newsletter"} /-->

<!-- wp:wphave/navigation-link {"content":"Events"} /-->

<!-- wp:wphave/navigation-link {"content":"Help center"} /-->

<!-- wp:wphave/navigation-link {"content":"Support"} /-->
<!-- /wp:wphave/navigation -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk"}} -->
<!-- wp:wphave/paragraph {"wphave":{"settings":{"formats":["bold","uppercase"]},"classNames":"is-bold is-uppercase tx-co tf-fs tf-fs-text-xs","text":{"typeface":{"size":{"type":"text-xs"}},"colors":{"text":"var(\u002d\u002dwphave-site-color-text-subtle-5)"}},"styles":"\u002d\u002dtx-co: var(\u002d\u002dwphave-site-color-text-subtle-5)"},"content":"Company"} /-->

<!-- wp:wphave/navigation {"wphave":{"settings":{"collapseBehavior":"never"},"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-xs)","gapY":"var(\u002d\u002dwphave-site-gap-size-xs)","flexDirection":"column"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-xs);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-xs);\u002d\u002dly-fl-direction: column"}} -->
<!-- wp:wphave/navigation-link {"content":"About us"} /-->

<!-- wp:wphave/navigation-link {"content":"Careers"} /-->

<!-- wp:wphave/navigation-link {"content":"Press"} /-->

<!-- wp:wphave/navigation-link {"content":"Media kit"} /-->

<!-- wp:wphave/navigation-link {"content":"Contact"} /-->
<!-- /wp:wphave/navigation -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"classNames":"wi pa ly ly-stk ly-co-pos bg-co bg txta tf-fs tf-fs-text-xs","layout":{"stacked":{"contentPosition":"center"}},"dimensions":{"width":{"custom":"100%"},"spacing":{"padding":"var(--wphave-site-padding-top) var(--wphave-site-padding-right) var(--wphave-site-padding-bottom) var(--wphave-site-padding-left)"}},"styles":"--wi: 100%;--pa: var(--wphave-site-padding-top) var(--wphave-site-padding-right) var(--wphave-site-padding-bottom) var(--wphave-site-padding-left);--pa-top: var(--wphave-site-padding-top);--pa-right: var(--wphave-site-padding-right);--pa-bottom: var(--wphave-site-padding-bottom);--pa-left: var(--wphave-site-padding-left);--ly-co-pos-h: center;--ly-co-pos-v: center;--bg-co: var(--wphave-site-color-background-contrast-1);--txta: none","text":{"align":"none","typeface":{"size":{"type":"text-xs"}}},"background":{"color":{"base":"var(--wphave-site-color-background-contrast-1)"}},"stylesChild":"--left-spacing-inherit: var(--wphave-site-padding-left);--right-spacing-inherit: var(--wphave-site-padding-right)"}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"bsz-content ly ly-fl ly-fl-wp ly-fl-t ly-t-fl-wp","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-layout-gap)","gapY":"var(--wphave-site-layout-gap)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"space-between"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-layout-gap);--ly-row-gap: var(--wphave-site-layout-gap);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: space-between;--ly-fl-direction: row;--ly-t-column-gap: var(--wphave-site-layout-gap);--ly-t-row-gap: var(--wphave-site-layout-gap);--ly-t-fl-wrap: wrap;--ly-t-fl-itm: 0 1 auto;--ly-t-valign: center;--ly-t-halign: center;--ly-t-fl-direction: row","features":{"size":"content"},"tablet":{"layout":{"stacked":{"alignHorizontal":"center"}}}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-fl ly-fl-wp txta ly-fl-t ly-t-fl-wp","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-gap-size-s)","gapY":"var(--wphave-site-gap-size-s)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"center"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-gap-size-s);--ly-row-gap: var(--wphave-site-gap-size-s);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: center;--ly-fl-direction: row;--ly-t-column-gap: var(--wphave-site-gap-size-s);--ly-t-row-gap: var(--wphave-site-gap-size-s);--ly-t-fl-wrap: wrap;--ly-t-fl-itm: 0 1 auto;--ly-t-valign: center;--ly-t-halign: center;--ly-t-fl-direction: row","tablet":{"layout":{"stacked":{"alignHorizontal":"center"}}},"text":{"align":"center"},"styles":"--txta: center"}} -->
<!-- wp:wphave/paragraph {"content":"\u003cspan class=\u0022rt-char\u0022\u003e©\u003c/span\u003eCopyright by \u003cspan data-source=\u0022general\u0022 data-post-id=\u0022\u0022 data-field=\u0022site_title\u0022 data-field-name=\u0022\u0022 class=\u0022rt-dyd\u0022\u003e{{site_title}}\u003c/span\u003e\u003cspan class=\u0022rt-char\u0022\u003e−\u003c/span\u003e2020 - \u003cspan data-source=\u0022general\u0022 data-post-id=\u0022\u0022 data-field=\u0022current_year\u0022 data-field-name=\u0022\u0022 class=\u0022rt-dyd\u0022\u003e{{current_year}}\u003c/span\u003e","metadata":{"name":"Copyright row"}} /-->
<!-- /wp:wphave/group -->

<!-- wp:wphave/navigation {"wphave":{"settings":{"collapseBehavior":"never"}}} -->
<!-- wp:wphave/navigation-link {"content":"Terms and Conditions"} /-->

<!-- wp:wphave/navigation-separator {"wphave":{"settings":{"colors":{"bg":"var(\u002d\u002dwphave-site-color-background-contrast-3)"}},"styles":"\u002d\u002dnav-menu-separator-color: var(\u002d\u002dwphave-site-color-background-contrast-3)"}} /-->

<!-- wp:wphave/navigation-link {"content":"Data Privacy"} /-->

<!-- wp:wphave/navigation-separator {"wphave":{"settings":{"colors":{"bg":"var(\u002d\u002dwphave-site-color-background-contrast-3)"}},"styles":"\u002d\u002dnav-menu-separator-color: var(\u002d\u002dwphave-site-color-background-contrast-3)"}} /-->

<!-- wp:wphave/navigation-link {"content":"License Terms"} /-->
<!-- /wp:wphave/navigation -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'tags' => array('footer'),
            'title' => '',
            'viewportWidth' => $content_width + $spacing,
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-content pa ofw ly ly-stk bg-co bg br","dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-top) var(\u002d\u002dwphave-site-padding-right) var(\u002d\u002dwphave-site-padding-bottom) var(\u002d\u002dwphave-site-padding-left)"},"overflow":"clip"},"background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background-contrast-1)"}},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-top) var(\u002d\u002dwphave-site-padding-right) var(\u002d\u002dwphave-site-padding-bottom) var(\u002d\u002dwphave-site-padding-left);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-top);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-right);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-bottom);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-left);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background-contrast-1);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-left);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-right)","frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"},"features":{"size":"content"}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"wi ly ly-fl ly-fl-wp ly-fl-t ly-t-fl-wp ly-fl-dtn-vtl","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-layout-gap)","gapY":"var(--wphave-site-layout-gap)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"space-between"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-layout-gap);--ly-row-gap: var(--wphave-site-layout-gap);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: space-between;--ly-fl-direction: row;--ly-t-column-gap: var(--wphave-site-layout-gap);--ly-t-row-gap: var(--wphave-site-layout-gap);--ly-t-fl-wrap: wrap;--ly-t-fl-itm: 0 1 auto;--ly-t-valign: center;--ly-t-halign: center;--ly-t-fl-direction: column","dimensions":{"width":{"custom":"100%"}},"styles":"--wi: 100%","tablet":{"layout":{"stacked":{"flexDirection":"column","alignHorizontal":"center"}}}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk ly-t-co-pos","tablet":{"layout":{"stacked":{"contentPosition":"center"}}},"styles":"--ly-t-co-pos-h: center;--ly-t-co-pos-v: center"}} -->
<!-- wp:wphave/site-logo {"wphave":{"settings":{"imageSize":"auto"},"dimensions":{"width":{"custom":"100px"}},"styles":"\u002d\u002dwi: 100px","classNames":"wi"}} /-->

<!-- wp:wphave/paragraph {"content":"Insert Social Icons Block here"} /-->
<!-- /wp:wphave/group -->

<!-- wp:wphave/navigation {"wphave":{"settings":{"collapseBehavior":"never"},"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-s)","gapY":"var(\u002d\u002dwphave-site-gap-size-s)","flexDirection":"row"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-fl-direction: row"}} -->
<!-- wp:wphave/navigation-link {"content":"Overview"} /-->

<!-- wp:wphave/navigation-separator {"wphave":{"settings":{"colors":{"bg":"var(\u002d\u002dwphave-site-color-background-contrast-3)"}},"styles":"\u002d\u002dnav-menu-separator-color: var(\u002d\u002dwphave-site-color-background-contrast-3)"}} /-->

<!-- wp:wphave/navigation-link {"content":"Features"} /-->

<!-- wp:wphave/navigation-separator {"wphave":{"settings":{"colors":{"bg":"var(\u002d\u002dwphave-site-color-background-contrast-3)"}},"styles":"\u002d\u002dnav-menu-separator-color: var(\u002d\u002dwphave-site-color-background-contrast-3)"}} /-->

<!-- wp:wphave/navigation-link {"content":"Solutions"} /-->

<!-- wp:wphave/navigation-separator {"wphave":{"settings":{"colors":{"bg":"var(\u002d\u002dwphave-site-color-background-contrast-3)"}},"styles":"\u002d\u002dnav-menu-separator-color: var(\u002d\u002dwphave-site-color-background-contrast-3)"}} /-->

<!-- wp:wphave/navigation-link {"content":"Tutorials"} /-->
<!-- /wp:wphave/navigation -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/line {"wphave":{"settings":{"size":"1px","colors":{"line":"var(\u002d\u002dwphave-site-color-background-contrast-2)"}},"styles":"\u002d\u002dline-size: 1px;\u002d\u002dline-color: var(\u002d\u002dwphave-site-color-background-contrast-2)"}} /-->

<!-- wp:wphave/group {"wphave":{"classNames":"wi ly ly-fl ly-fl-wp txta tf-fs tf-fs-text-xs ly-fl-t ly-t-fl-wp ly-fl-dtn-vtl txta-t","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-layout-gap)","gapY":"var(--wphave-site-layout-gap)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"space-between"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-layout-gap);--ly-row-gap: var(--wphave-site-layout-gap);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: space-between;--ly-fl-direction: row;--ly-t-column-gap: var(--wphave-site-layout-gap);--ly-t-row-gap: var(--wphave-site-layout-gap);--ly-t-fl-wrap: wrap;--ly-t-fl-itm: 0 1 auto;--ly-t-valign: center;--ly-t-halign: center;--ly-t-fl-direction: column","dimensions":{"width":{"custom":"100%"}},"styles":"--wi: 100%;--txta: none;--txta-t: center","tablet":{"layout":{"stacked":{"alignHorizontal":"center","flexDirection":"column"}},"text":{"align":"center"}},"text":{"align":"none","typeface":{"size":{"type":"text-xs"}}}}} -->
<!-- wp:wphave/paragraph {"wphave":{"text":{"typeface":{"size":{"type":"text-xs"}}},"classNames":"tf-fs tf-fs-text-xs"},"content":"\u003cspan class=\u0022rt-char\u0022\u003e©\u003c/span\u003eCopyright by \u003cspan data-source=\u0022general\u0022 data-post-id=\u0022\u0022 data-field=\u0022site_title\u0022 data-field-name=\u0022\u0022 class=\u0022rt-dyd\u0022\u003e{{site_title}}\u003c/span\u003e\u003cspan class=\u0022rt-char\u0022\u003e−\u003c/span\u003e2020 - \u003cspan data-source=\u0022general\u0022 data-post-id=\u0022\u0022 data-field=\u0022current_year\u0022 data-field-name=\u0022\u0022 class=\u0022rt-dyd\u0022\u003e{{current_year}}\u003c/span\u003e","metadata":{"name":"Copyright row"}} /-->

<!-- wp:wphave/navigation {"wphave":{"settings":{"collapseBehavior":"never"}}} -->
<!-- wp:wphave/navigation-link {"content":"Terms and Conditions"} /-->

<!-- wp:wphave/navigation-separator {"wphave":{"settings":{"colors":{"bg":"var(\u002d\u002dwphave-site-color-background-contrast-3)"}},"styles":"\u002d\u002dnav-menu-separator-color: var(\u002d\u002dwphave-site-color-background-contrast-3)"}} /-->

<!-- wp:wphave/navigation-link {"content":"Data Privacy"} /-->

<!-- wp:wphave/navigation-separator {"wphave":{"settings":{"colors":{"bg":"var(\u002d\u002dwphave-site-color-background-contrast-3)"}},"styles":"\u002d\u002dnav-menu-separator-color: var(\u002d\u002dwphave-site-color-background-contrast-3)"}} /-->

<!-- wp:wphave/navigation-link {"content":"License Terms"} /-->
<!-- /wp:wphave/navigation -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'tags' => array('footer'),
            'title' => '',
            'viewportWidth' => $content_width + $spacing,
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-full pa ly ly-stk bg txta","features":{"size":"full"},"dimensions":{"spacing":{"padding":"var(--wphave-site-padding-top) var(--wphave-site-padding-right) var(--wphave-site-padding-bottom) var(--wphave-site-padding-left)"}},"styles":"--pa: var(--wphave-site-padding-top) var(--wphave-site-padding-right) var(--wphave-site-padding-bottom) var(--wphave-site-padding-left);--pa-top: var(--wphave-site-padding-top);--pa-right: var(--wphave-site-padding-right);--pa-bottom: var(--wphave-site-padding-bottom);--pa-left: var(--wphave-site-padding-left);--txta: none","stylesChild":"--left-spacing-inherit: var(--wphave-site-padding-left);--right-spacing-inherit: var(--wphave-site-padding-right)","layout":{},"text":{"align":"none"},"background":{"layers":[{"gradient":[{"gradient":{"type":"radial","position":"top-left","colorStops":[{"color":"var(--wphave-site-color-accent-subtle-10)","position":11},{"color":"var(--wphave-site-color-palette-transparent)","position":29}],"radialShape":"circle"}},{"gradient":{"type":"radial","position":"bottom-right","colorStops":[{"color":"var(--wphave-site-color-accent-subtle-10)","position":-17},{"color":"var(--wphave-site-color-palette-transparent)","position":46}],"radialShape":"circle"}}]}]},"stylesBackgrounds":["--bg-grd: radial-gradient(circle at top left, var(--wphave-site-color-accent-subtle-10) 11%, var(--wphave-site-color-palette-transparent) 29%),radial-gradient(circle at bottom right, var(--wphave-site-color-accent-subtle-10) -17%, var(--wphave-site-color-palette-transparent) 46%)"],"classNamesBackground":[""]}} -->
<!-- wp:wphave/spacer {"wphave":{"settings":{"aspectRatio":"20/1"},"styles":"\u002d\u002daspect-ratio: 20/1"}} /-->

<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-fl ly-fl-wp ly-fl-m ly-m-fl-wp ly-fl-dtn-vtl","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-layout-gap)","gapY":"var(--wphave-site-layout-gap)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"space-between"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-layout-gap);--ly-row-gap: var(--wphave-site-layout-gap);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: space-between;--ly-fl-direction: row;--ly-m-column-gap: var(--wphave-site-layout-gap);--ly-m-row-gap: var(--wphave-site-layout-gap);--ly-m-fl-wrap: wrap;--ly-m-fl-itm: 0 1 auto;--ly-m-valign: center;--ly-m-halign: center;--ly-m-fl-direction: column","mobile":{"layout":{"stacked":{"alignHorizontal":"center","flexDirection":"column"}}}}} -->
<!-- wp:wphave/heading {"wphave":{"settings":{"headingLevel":"h6"},"text":{"typeface":{"size":{"type":"title-m"}}},"classNames":"tf-fs tf-fs-title-m"},"content":"Ready to get started?\u003cbr\u003e\u003cmark data-text=\u0022var(\u002d\u002dwphave-site-color-accent)\u0022 style=\u0022\u002d\u002drt-thl-co: var(\u002d\u002dwphave-site-color-accent)\u0022 class=\u0022rt-thl\u0022\u003eTalk to us today\u003c/mark\u003e"} /-->

<!-- wp:wphave/button {"wphave":{"settings":{"size":"5"},"styles":"--size-scale: 5"},"content":"Contact us"} /-->
<!-- /wp:wphave/group -->

<!-- wp:wphave/spacer {"wphave":{"settings":{"aspectRatio":"10/1"},"styles":"\u002d\u002daspect-ratio: 10/1"}} /-->

<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-fl ly-fl-wp ly-fl-t ly-t-fl-wp ly-fl-dtn-vtl","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-gap-size-3xl)","gapY":"var(--wphave-site-gap-size-3xl)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"start","alignHorizontal":"space-between"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-gap-size-3xl);--ly-row-gap: var(--wphave-site-gap-size-3xl);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: start;--ly-halign: space-between;--ly-fl-direction: row;--ly-t-column-gap: var(--wphave-site-gap-size-3xl);--ly-t-row-gap: var(--wphave-site-gap-size-3xl);--ly-t-fl-wrap: wrap;--ly-t-fl-itm: 0 1 auto;--ly-t-valign: center;--ly-t-halign: start;--ly-t-fl-direction: column","tablet":{"layout":{"stacked":{"flexDirection":"column","alignHorizontal":"center"}}}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk ly-t-co-pos txta-t","layout":{},"tablet":{"layout":{"stacked":{"flexDirection":"column","alignHorizontal":"center","contentPosition":"center"}},"text":{"align":"center"}},"styles":"--ly-t-co-pos-h: center;--ly-t-co-pos-v: center;--txta-t: center"}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk ly-t-co-pos","layout":{"stacked":{"gap":"var(--wphave-site-gap-size-s)"}},"stylesLayout":"--ly-gap: var(--wphave-site-gap-size-s);--ly-t-gap: var(--wphave-site-gap-size-s)","tablet":{"layout":{"stacked":{"contentPosition":"center"}}},"styles":"--ly-t-co-pos-h: center;--ly-t-co-pos-v: center"}} -->
<!-- wp:wphave/site-logo {"wphave":{"settings":{"imageSize":"auto"},"dimensions":{"width":{"custom":"100px"}},"styles":"\u002d\u002dwi: 100px","classNames":"wi"}} /-->

<!-- wp:wphave/paragraph {"content":"Lorem ipsum dolor sit amet, consectetuer adipiscing."} /-->
<!-- /wp:wphave/group -->

<!-- wp:wphave/paragraph {"content":"Insert Social Icons Block here"} /-->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-fl ly-fl-wp","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-gap-size-4xl)","gapY":"var(--wphave-site-gap-size-4xl)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"start","alignHorizontal":"start"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-gap-size-4xl);--ly-row-gap: var(--wphave-site-gap-size-4xl);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: start;--ly-halign: start;--ly-fl-direction: row"}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk"}} -->
<!-- wp:wphave/paragraph {"wphave":{"settings":{"formats":["bold","uppercase"]},"classNames":"is-bold is-uppercase tx-co tf-fs tf-fs-text-xs","text":{"typeface":{"size":{"type":"text-xs"}},"colors":{"text":"var(\u002d\u002dwphave-site-color-text-subtle-5)"}},"styles":"\u002d\u002dtx-co: var(\u002d\u002dwphave-site-color-text-subtle-5)"},"content":"Product"} /-->

<!-- wp:wphave/navigation {"wphave":{"settings":{"collapseBehavior":"never"},"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-xs)","gapY":"var(\u002d\u002dwphave-site-gap-size-xs)","flexDirection":"column"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-xs);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-xs);\u002d\u002dly-fl-direction: column"}} -->
<!-- wp:wphave/navigation-link {"content":"Overview"} /-->

<!-- wp:wphave/navigation-link {"content":"Features"} /-->

<!-- wp:wphave/navigation-link {"content":"Solutions"} /-->

<!-- wp:wphave/navigation-link {"content":"Tutorials"} /-->
<!-- /wp:wphave/navigation -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk"}} -->
<!-- wp:wphave/paragraph {"wphave":{"settings":{"formats":["bold","uppercase"]},"classNames":"is-bold is-uppercase tx-co tf-fs tf-fs-text-xs","text":{"typeface":{"size":{"type":"text-xs"}},"colors":{"text":"var(\u002d\u002dwphave-site-color-text-subtle-5)"}},"styles":"\u002d\u002dtx-co: var(\u002d\u002dwphave-site-color-text-subtle-5)"},"content":"Ressources"} /-->

<!-- wp:wphave/navigation {"wphave":{"settings":{"collapseBehavior":"never"},"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-xs)","gapY":"var(\u002d\u002dwphave-site-gap-size-xs)","flexDirection":"column"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-xs);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-xs);\u002d\u002dly-fl-direction: column"}} -->
<!-- wp:wphave/navigation-link {"content":"Blog"} /-->

<!-- wp:wphave/navigation-link {"content":"Newsletter"} /-->

<!-- wp:wphave/navigation-link {"content":"Events"} /-->

<!-- wp:wphave/navigation-link {"content":"Help center"} /-->

<!-- wp:wphave/navigation-link {"content":"Support"} /-->
<!-- /wp:wphave/navigation -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk"}} -->
<!-- wp:wphave/paragraph {"wphave":{"settings":{"formats":["bold","uppercase"]},"classNames":"is-bold is-uppercase tx-co tf-fs tf-fs-text-xs","text":{"typeface":{"size":{"type":"text-xs"}},"colors":{"text":"var(\u002d\u002dwphave-site-color-text-subtle-5)"}},"styles":"\u002d\u002dtx-co: var(\u002d\u002dwphave-site-color-text-subtle-5)"},"content":"Company"} /-->

<!-- wp:wphave/navigation {"wphave":{"settings":{"collapseBehavior":"never"},"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-xs)","gapY":"var(\u002d\u002dwphave-site-gap-size-xs)","flexDirection":"column"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-xs);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-xs);\u002d\u002dly-fl-direction: column"}} -->
<!-- wp:wphave/navigation-link {"content":"About us"} /-->

<!-- wp:wphave/navigation-link {"content":"Careers"} /-->

<!-- wp:wphave/navigation-link {"content":"Press"} /-->

<!-- wp:wphave/navigation-link {"content":"Media kit"} /-->

<!-- wp:wphave/navigation-link {"content":"Contact"} /-->
<!-- /wp:wphave/navigation -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/line {"wphave":{"settings":{"size":"1px","colors":{"line":"var(\u002d\u002dwphave-site-color-background-contrast-2)"}},"styles":"\u002d\u002dline-size: 1px;\u002d\u002dline-color: var(\u002d\u002dwphave-site-color-background-contrast-2)"}} /-->

<!-- wp:wphave/group {"wphave":{"classNames":"wi ly ly-fl ly-fl-wp txta tf-fs tf-fs-text-xs ly-fl-t ly-t-fl-wp ly-fl-dtn-vtl","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-layout-gap)","gapY":"var(--wphave-site-layout-gap)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"space-between"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-layout-gap);--ly-row-gap: var(--wphave-site-layout-gap);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: space-between;--ly-fl-direction: row;--ly-t-column-gap: var(--wphave-site-layout-gap);--ly-t-row-gap: var(--wphave-site-layout-gap);--ly-t-fl-wrap: wrap;--ly-t-fl-itm: 0 1 auto;--ly-t-valign: center;--ly-t-halign: center;--ly-t-fl-direction: column","dimensions":{"width":{"custom":"100%"}},"styles":"--wi: 100%;--txta: none","tablet":{"layout":{"stacked":{"alignHorizontal":"center","flexDirection":"column"}}},"text":{"align":"none","typeface":{"size":{"type":"text-xs"}}}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-fl ly-fl-wp txta ly-fl-t ly-t-fl-wp","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-gap-size-s)","gapY":"var(--wphave-site-gap-size-s)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"center"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-gap-size-s);--ly-row-gap: var(--wphave-site-gap-size-s);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: center;--ly-fl-direction: row;--ly-t-column-gap: var(--wphave-site-gap-size-s);--ly-t-row-gap: var(--wphave-site-gap-size-s);--ly-t-fl-wrap: wrap;--ly-t-fl-itm: 0 1 auto;--ly-t-valign: center;--ly-t-halign: center;--ly-t-fl-direction: row","tablet":{"layout":{"stacked":{"alignHorizontal":"center"}}},"text":{"align":"center"},"styles":"--txta: center"}} -->
<!-- wp:wphave/paragraph {"content":"\u003cspan class=\u0022rt-char\u0022\u003e©\u003c/span\u003eCopyright by \u003cspan data-source=\u0022general\u0022 data-post-id=\u0022\u0022 data-field=\u0022site_title\u0022 data-field-name=\u0022\u0022 class=\u0022rt-dyd\u0022\u003e{{site_title}}\u003c/span\u003e\u003cspan class=\u0022rt-char\u0022\u003e−\u003c/span\u003e2020 - \u003cspan data-source=\u0022general\u0022 data-post-id=\u0022\u0022 data-field=\u0022current_year\u0022 data-field-name=\u0022\u0022 class=\u0022rt-dyd\u0022\u003e{{current_year}}\u003c/span\u003e","metadata":{"name":"Copyright row"}} /-->
<!-- /wp:wphave/group -->

<!-- wp:wphave/navigation {"wphave":{"settings":{"collapseBehavior":"never"}}} -->
<!-- wp:wphave/navigation-link {"content":"Terms and Conditions"} /-->

<!-- wp:wphave/navigation-separator {"wphave":{"settings":{"colors":{"bg":"var(\u002d\u002dwphave-site-color-background-contrast-3)"}},"styles":"\u002d\u002dnav-menu-separator-color: var(\u002d\u002dwphave-site-color-background-contrast-3)"}} /-->

<!-- wp:wphave/navigation-link {"content":"Data Privacy"} /-->

<!-- wp:wphave/navigation-separator {"wphave":{"settings":{"colors":{"bg":"var(\u002d\u002dwphave-site-color-background-contrast-3)"}},"styles":"\u002d\u002dnav-menu-separator-color: var(\u002d\u002dwphave-site-color-background-contrast-3)"}} /-->

<!-- wp:wphave/navigation-link {"content":"License Terms"} /-->
<!-- /wp:wphave/navigation -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/spacer {"wphave":{"settings":{"aspectRatio":"20/1"},"styles":"\u002d\u002daspect-ratio: 20/1"}} /-->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'tags' => array('footer'),
            'title' => '',
            'viewportWidth' => $content_width + $spacing,
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-full pa ly ly-stk bg txta","features":{"size":"full"},"dimensions":{"spacing":{"padding":"var(--wphave-site-padding-top) var(--wphave-site-padding-right) var(--wphave-site-padding-bottom) var(--wphave-site-padding-left)"}},"styles":"--pa: var(--wphave-site-padding-top) var(--wphave-site-padding-right) var(--wphave-site-padding-bottom) var(--wphave-site-padding-left);--pa-top: var(--wphave-site-padding-top);--pa-right: var(--wphave-site-padding-right);--pa-bottom: var(--wphave-site-padding-bottom);--pa-left: var(--wphave-site-padding-left);--txta: none","stylesChild":"--left-spacing-inherit: var(--wphave-site-padding-left);--right-spacing-inherit: var(--wphave-site-padding-right)","layout":{},"text":{"align":"none"},"background":{"layers":[{"gradient":{"type":"linear","angle":178,"position":"custom","colorStops":[{"color":"var(--wphave-site-color-palette-transparent)","position":0},{"color":"var(--wphave-site-color-background-contrast-2)","position":161}]},"cssPattern":{"type":"1","size":"88px","color":"var(--wphave-site-color-background-contrast-4)","opacity":1,"dotSize":"1px","strokeWidth":"1px"},"mask":{"gradient":{"type":"simple","simple":{"preset":"verticalReverse","stops":{"min":0,"max":52}}}}}]},"stylesBackgrounds":["--bg-grd: linear-gradient(178deg, var(--wphave-site-color-palette-transparent) 0%, var(--wphave-site-color-background-contrast-2) 161%);--cssp-bg-si: 88px;--cssp-bg-si-wu: 88;--cssp-bg-co: var(--wphave-site-color-background-contrast-4);--cssp-bg-co-55: rgba(NaN, NaN, NaN, 0.55);--cssp-bg-op: 1;--cssp-bg-do-si: 1px;--cssp-bg-sw: 1px;--cssp-bg-img:  repeating-linear-gradient( -45deg, var(--cssp-bg-co), var(--cssp-bg-co) var(--cssp-bg-sw), transparent var(--cssp-bg-sw), transparent var(--cssp-bg-si) ) ;--bg-msk-grd: linear-gradient(to top, black var(--msk-grd-st-start), transparent var(--msk-grd-st-end));--msk-grd-st-end: 52%;--msk-grd-st-start: 0%"],"classNamesBackground":["bg-msk bg-msk-grd bg-msk-grd-sim"]}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-fl ly-fl-wp ly-fl-m ly-m-fl-wp ly-fl-dtn-vtl","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-layout-gap)","gapY":"var(--wphave-site-layout-gap)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"space-between"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-layout-gap);--ly-row-gap: var(--wphave-site-layout-gap);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: space-between;--ly-fl-direction: row;--ly-m-column-gap: var(--wphave-site-layout-gap);--ly-m-row-gap: var(--wphave-site-layout-gap);--ly-m-fl-wrap: wrap;--ly-m-fl-itm: 0 1 auto;--ly-m-valign: center;--ly-m-halign: center;--ly-m-fl-direction: column","mobile":{"layout":{"stacked":{"alignHorizontal":"center","flexDirection":"column"}}}}} /-->

<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-fl ly-fl-wp ly-fl-t ly-t-fl-wp ly-fl-dtn-vtl","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-gap-size-3xl)","gapY":"var(--wphave-site-gap-size-3xl)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"start","alignHorizontal":"space-between"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-gap-size-3xl);--ly-row-gap: var(--wphave-site-gap-size-3xl);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: start;--ly-halign: space-between;--ly-fl-direction: row;--ly-t-column-gap: var(--wphave-site-gap-size-3xl);--ly-t-row-gap: var(--wphave-site-gap-size-3xl);--ly-t-fl-wrap: wrap;--ly-t-fl-itm: 0 1 auto;--ly-t-valign: center;--ly-t-halign: start;--ly-t-fl-direction: column","tablet":{"layout":{"stacked":{"flexDirection":"column","alignHorizontal":"center"}}}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk ly-t-co-pos txta-t","layout":{},"tablet":{"layout":{"stacked":{"flexDirection":"column","alignHorizontal":"center","contentPosition":"center"}},"text":{"align":"center"}},"styles":"--ly-t-co-pos-h: center;--ly-t-co-pos-v: center;--txta-t: center"}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk ly-t-co-pos","tablet":{"layout":{"stacked":{"contentPosition":"center"}}},"styles":"--ly-t-co-pos-h: center;--ly-t-co-pos-v: center"}} -->
<!-- wp:wphave/site-logo {"wphave":{"settings":{"imageSize":"auto"},"dimensions":{"width":{"custom":"100px"}},"styles":"\u002d\u002dwi: 100px","classNames":"wi"}} /-->

<!-- wp:wphave/paragraph {"wphave":{"settings":{"fontStyle":"h1"},"classNames":"wphave-fstyle-heading-h1"},"content":"Wanna work with us?\u003cbr\u003e\u003cmark style=\u0022\u002d\u002drt-thl-co: var(\u002d\u002dwphave-site-color-accent)\u0022 data-text=\u0022var(\u002d\u002dwphave-site-color-accent)\u0022 class=\u0022rt-thl\u0022\u003eGet in touch!\u003c/mark\u003e"} /-->

<!-- wp:wphave/button {"wphave":{"settings":{"size":"0"},"styles":"--size-scale: 0"},"content":"Contact us"} /-->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-fl ly-fl-wp","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-gap-size-4xl)","gapY":"var(--wphave-site-gap-size-4xl)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"start","alignHorizontal":"start"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-gap-size-4xl);--ly-row-gap: var(--wphave-site-gap-size-4xl);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: start;--ly-halign: start;--ly-fl-direction: row"}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk"}} -->
<!-- wp:wphave/paragraph {"wphave":{"settings":{"formats":["bold","uppercase"]},"classNames":"is-bold is-uppercase tx-co tf-fs tf-fs-text-xs","text":{"typeface":{"size":{"type":"text-xs"}},"colors":{"text":"var(\u002d\u002dwphave-site-color-text-subtle-5)"}},"styles":"\u002d\u002dtx-co: var(\u002d\u002dwphave-site-color-text-subtle-5)"},"content":"Product"} /-->

<!-- wp:wphave/navigation {"wphave":{"settings":{"collapseBehavior":"never"},"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-xs)","gapY":"var(\u002d\u002dwphave-site-gap-size-xs)","flexDirection":"column"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-xs);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-xs);\u002d\u002dly-fl-direction: column"}} -->
<!-- wp:wphave/navigation-link {"content":"Overview"} /-->

<!-- wp:wphave/navigation-link {"content":"Features"} /-->

<!-- wp:wphave/navigation-link {"content":"Solutions"} /-->

<!-- wp:wphave/navigation-link {"content":"Tutorials"} /-->
<!-- /wp:wphave/navigation -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk"}} -->
<!-- wp:wphave/paragraph {"wphave":{"settings":{"formats":["bold","uppercase"]},"classNames":"is-bold is-uppercase tx-co tf-fs tf-fs-text-xs","text":{"typeface":{"size":{"type":"text-xs"}},"colors":{"text":"var(\u002d\u002dwphave-site-color-text-subtle-5)"}},"styles":"\u002d\u002dtx-co: var(\u002d\u002dwphave-site-color-text-subtle-5)"},"content":"Ressources"} /-->

<!-- wp:wphave/navigation {"wphave":{"settings":{"collapseBehavior":"never"},"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-xs)","gapY":"var(\u002d\u002dwphave-site-gap-size-xs)","flexDirection":"column"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-xs);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-xs);\u002d\u002dly-fl-direction: column"}} -->
<!-- wp:wphave/navigation-link {"content":"Blog"} /-->

<!-- wp:wphave/navigation-link {"content":"Newsletter"} /-->

<!-- wp:wphave/navigation-link {"content":"Events"} /-->

<!-- wp:wphave/navigation-link {"content":"Help center"} /-->

<!-- wp:wphave/navigation-link {"content":"Support"} /-->
<!-- /wp:wphave/navigation -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk"}} -->
<!-- wp:wphave/paragraph {"wphave":{"settings":{"formats":["bold","uppercase"]},"classNames":"is-bold is-uppercase tx-co tf-fs tf-fs-text-xs","text":{"typeface":{"size":{"type":"text-xs"}},"colors":{"text":"var(\u002d\u002dwphave-site-color-text-subtle-5)"}},"styles":"\u002d\u002dtx-co: var(\u002d\u002dwphave-site-color-text-subtle-5)"},"content":"Company"} /-->

<!-- wp:wphave/navigation {"wphave":{"settings":{"collapseBehavior":"never"},"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-xs)","gapY":"var(\u002d\u002dwphave-site-gap-size-xs)","flexDirection":"column"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-xs);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-xs);\u002d\u002dly-fl-direction: column"}} -->
<!-- wp:wphave/navigation-link {"content":"About us"} /-->

<!-- wp:wphave/navigation-link {"content":"Careers"} /-->

<!-- wp:wphave/navigation-link {"content":"Press"} /-->

<!-- wp:wphave/navigation-link {"content":"Media kit"} /-->

<!-- wp:wphave/navigation-link {"content":"Contact"} /-->
<!-- /wp:wphave/navigation -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/spacer {"wphave":{"settings":{"aspectRatio":"35/1"},"styles":"\u002d\u002daspect-ratio: 35/1"}} /-->

<!-- wp:wphave/group {"wphave":{"classNames":"wi ly ly-fl ly-fl-wp txta tf-fs tf-fs-text-xs ly-fl-t ly-t-fl-wp ly-fl-dtn-vtl","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-layout-gap)","gapY":"var(--wphave-site-layout-gap)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"space-between"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-layout-gap);--ly-row-gap: var(--wphave-site-layout-gap);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: space-between;--ly-fl-direction: row;--ly-t-column-gap: var(--wphave-site-layout-gap);--ly-t-row-gap: var(--wphave-site-layout-gap);--ly-t-fl-wrap: wrap;--ly-t-fl-itm: 0 1 auto;--ly-t-valign: center;--ly-t-halign: center;--ly-t-fl-direction: column","dimensions":{"width":{"custom":"100%"}},"styles":"--wi: 100%;--txta: none","tablet":{"layout":{"stacked":{"alignHorizontal":"center","flexDirection":"column"}}},"text":{"align":"none","typeface":{"size":{"type":"text-xs"}}}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-fl ly-fl-wp txta ly-fl-t ly-t-fl-wp","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-gap-size-s)","gapY":"var(--wphave-site-gap-size-s)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"center"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-gap-size-s);--ly-row-gap: var(--wphave-site-gap-size-s);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: center;--ly-fl-direction: row;--ly-t-column-gap: var(--wphave-site-gap-size-s);--ly-t-row-gap: var(--wphave-site-gap-size-s);--ly-t-fl-wrap: wrap;--ly-t-fl-itm: 0 1 auto;--ly-t-valign: center;--ly-t-halign: center;--ly-t-fl-direction: row","tablet":{"layout":{"stacked":{"alignHorizontal":"center"}}},"text":{"align":"center"},"styles":"--txta: center"}} -->
<!-- wp:wphave/paragraph {"content":"\u003cspan class=\u0022rt-char\u0022\u003e©\u003c/span\u003eCopyright by \u003cspan data-source=\u0022general\u0022 data-post-id=\u0022\u0022 data-field=\u0022site_title\u0022 data-field-name=\u0022\u0022 class=\u0022rt-dyd\u0022\u003e{{site_title}}\u003c/span\u003e\u003cspan class=\u0022rt-char\u0022\u003e−\u003c/span\u003e2020 - \u003cspan data-source=\u0022general\u0022 data-post-id=\u0022\u0022 data-field=\u0022current_year\u0022 data-field-name=\u0022\u0022 class=\u0022rt-dyd\u0022\u003e{{current_year}}\u003c/span\u003e","metadata":{"name":"Copyright row"}} /-->
<!-- /wp:wphave/group -->

<!-- wp:wphave/navigation {"wphave":{"settings":{"collapseBehavior":"never"}}} -->
<!-- wp:wphave/navigation-link {"content":"Terms and Conditions"} /-->

<!-- wp:wphave/navigation-separator {"wphave":{"settings":{"colors":{"bg":"var(\u002d\u002dwphave-site-color-background-contrast-3)"}},"styles":"\u002d\u002dnav-menu-separator-color: var(\u002d\u002dwphave-site-color-background-contrast-3)"}} /-->

<!-- wp:wphave/navigation-link {"content":"Data Privacy"} /-->

<!-- wp:wphave/navigation-separator {"wphave":{"settings":{"colors":{"bg":"var(\u002d\u002dwphave-site-color-background-contrast-3)"}},"styles":"\u002d\u002dnav-menu-separator-color: var(\u002d\u002dwphave-site-color-background-contrast-3)"}} /-->

<!-- wp:wphave/navigation-link {"content":"License Terms"} /-->
<!-- /wp:wphave/navigation -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/spacer {"wphave":{"settings":{"aspectRatio":"35/1"},"styles":"\u002d\u002daspect-ratio: 35/1"}} /-->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'tags' => array('footer'),
            'title' => '',
            'viewportWidth' => $content_width + $spacing,
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-full pa ly ly-stk txta","features":{"size":"full"},"dimensions":{"spacing":{"padding":"var(--wphave-site-padding-top) var(--wphave-site-padding-right) var(--wphave-site-padding-bottom) var(--wphave-site-padding-left)"}},"styles":"--pa: var(--wphave-site-padding-top) var(--wphave-site-padding-right) var(--wphave-site-padding-bottom) var(--wphave-site-padding-left);--pa-top: var(--wphave-site-padding-top);--pa-right: var(--wphave-site-padding-right);--pa-bottom: var(--wphave-site-padding-bottom);--pa-left: var(--wphave-site-padding-left);--txta: left","stylesChild":"--left-spacing-inherit: var(--wphave-site-padding-left);--right-spacing-inherit: var(--wphave-site-padding-right)","layout":{},"text":{"align":"left"}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-fl ly-fl-wp ly-fl-dtn-vtl txta ly-fl-m ly-m-fl-wp ly-fl-dtn-vtl","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-layout-gap)","gapY":"var(--wphave-site-layout-gap)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"column","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"center"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-layout-gap);--ly-row-gap: var(--wphave-site-layout-gap);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: center;--ly-fl-direction: column;--ly-m-column-gap: var(--wphave-site-layout-gap);--ly-m-row-gap: var(--wphave-site-layout-gap);--ly-m-fl-wrap: wrap;--ly-m-fl-itm: 0 1 auto;--ly-m-valign: center;--ly-m-halign: center;--ly-m-fl-direction: column","mobile":{"layout":{"stacked":{"alignHorizontal":"center","flexDirection":"column"}}},"text":{"align":"center"},"styles":"--txta: center"}} -->
<!-- wp:wphave/heading {"wphave":{"settings":{"headingLevel":"h6"},"text":{"typeface":{"size":{"type":"title-m"}}},"classNames":"tf-fs tf-fs-title-m"},"content":"Ready to get started?\u003cbr\u003e\u003cmark data-text=\u0022var(\u002d\u002dwphave-site-color-accent)\u0022 style=\u0022\u002d\u002drt-thl-co: var(\u002d\u002dwphave-site-color-accent)\u0022 class=\u0022rt-thl\u0022\u003eTalk to us today\u003c/mark\u003e"} /-->

<!-- wp:wphave/button {"wphave":{"settings":{"size":"5"},"styles":"--size-scale: 5"},"content":"Contact us"} /-->
<!-- /wp:wphave/group -->

<!-- wp:wphave/spacer {"wphave":{"settings":{"aspectRatio":"75/1"},"styles":"\u002d\u002daspect-ratio: 75/1"}} /-->

<!-- wp:wphave/line {"wphave":{"settings":{"size":"1px","colors":{"line":"var(\u002d\u002dwphave-site-color-background-contrast-2)"}},"styles":"\u002d\u002dline-size: 1px;\u002d\u002dline-color: var(\u002d\u002dwphave-site-color-background-contrast-2)"}} /-->

<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-fl ly-fl-wp txta tf-fs tf-fs-text-s ly-fl-t ly-t-fl-wp ly-fl-dtn-vtl","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-gap-size-3xl)","gapY":"var(--wphave-site-gap-size-3xl)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"space-between"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-gap-size-3xl);--ly-row-gap: var(--wphave-site-gap-size-3xl);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: space-between;--ly-fl-direction: row;--ly-t-column-gap: var(--wphave-site-gap-size-3xl);--ly-t-row-gap: var(--wphave-site-gap-size-3xl);--ly-t-fl-wrap: wrap;--ly-t-fl-itm: 0 1 auto;--ly-t-valign: center;--ly-t-halign: center;--ly-t-fl-direction: column","text":{"align":"none","typeface":{"size":{"type":"text-s"}}},"styles":"--txta: none","tablet":{"layout":{"stacked":{"flexDirection":"column","alignHorizontal":"center"}}}}} -->
<!-- wp:wphave/site-logo {"wphave":{"settings":{"imageSize":"auto"},"dimensions":{"width":{"custom":"100px"}},"styles":"\u002d\u002dwi: 100px","classNames":"wi"}} /-->

<!-- wp:wphave/navigation {"wphave":{"settings":{"collapseBehavior":"never"},"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-m)","gapY":"var(\u002d\u002dwphave-site-gap-size-m)","flexDirection":"row"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-fl-direction: row"}} -->
<!-- wp:wphave/navigation-link {"content":"Overview"} /-->

<!-- wp:wphave/navigation-separator {"wphave":{"settings":{"colors":{"bg":"var(\u002d\u002dwphave-site-color-background-contrast-3)"}},"styles":"\u002d\u002dnav-menu-separator-color: var(\u002d\u002dwphave-site-color-background-contrast-3)"}} /-->

<!-- wp:wphave/navigation-link {"content":"Features"} /-->

<!-- wp:wphave/navigation-separator {"wphave":{"settings":{"colors":{"bg":"var(\u002d\u002dwphave-site-color-background-contrast-3)"}},"styles":"\u002d\u002dnav-menu-separator-color: var(\u002d\u002dwphave-site-color-background-contrast-3)"}} /-->

<!-- wp:wphave/navigation-link {"content":"Solutions"} /-->

<!-- wp:wphave/navigation-separator {"wphave":{"settings":{"colors":{"bg":"var(\u002d\u002dwphave-site-color-background-contrast-3)"}},"styles":"\u002d\u002dnav-menu-separator-color: var(\u002d\u002dwphave-site-color-background-contrast-3)"}} /-->

<!-- wp:wphave/navigation-link {"content":"Tutorials"} /-->
<!-- /wp:wphave/navigation -->

<!-- wp:wphave/paragraph {"content":"Insert Social Icons Block here"} /-->
<!-- /wp:wphave/group -->

<!-- wp:wphave/line {"wphave":{"settings":{"size":"1px","colors":{"line":"var(\u002d\u002dwphave-site-color-background-contrast-2)"}},"styles":"\u002d\u002dline-size: 1px;\u002d\u002dline-color: var(\u002d\u002dwphave-site-color-background-contrast-2)"}} /-->

<!-- wp:wphave/group {"wphave":{"classNames":"wi ly ly-fl ly-fl-wp txta tf-fs tf-fs-text-xs ly-fl-t ly-t-fl-wp ly-fl-dtn-vtl","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-layout-gap)","gapY":"var(--wphave-site-layout-gap)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"space-between"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-layout-gap);--ly-row-gap: var(--wphave-site-layout-gap);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: space-between;--ly-fl-direction: row;--ly-t-column-gap: var(--wphave-site-layout-gap);--ly-t-row-gap: var(--wphave-site-layout-gap);--ly-t-fl-wrap: wrap;--ly-t-fl-itm: 0 1 auto;--ly-t-valign: center;--ly-t-halign: center;--ly-t-fl-direction: column","dimensions":{"width":{"custom":"100%"}},"styles":"--wi: 100%;--txta: none","tablet":{"layout":{"stacked":{"alignHorizontal":"center","flexDirection":"column"}}},"text":{"align":"none","typeface":{"size":{"type":"text-xs"}}}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-fl ly-fl-wp txta ly-fl-t ly-t-fl-wp","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-gap-size-s)","gapY":"var(--wphave-site-gap-size-s)","flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"center"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-gap-size-s);--ly-row-gap: var(--wphave-site-gap-size-s);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: center;--ly-fl-direction: row;--ly-t-column-gap: var(--wphave-site-gap-size-s);--ly-t-row-gap: var(--wphave-site-gap-size-s);--ly-t-fl-wrap: wrap;--ly-t-fl-itm: 0 1 auto;--ly-t-valign: center;--ly-t-halign: center;--ly-t-fl-direction: row","tablet":{"layout":{"stacked":{"alignHorizontal":"center"}}},"text":{"align":"center"},"styles":"--txta: center"}} -->
<!-- wp:wphave/paragraph {"content":"\u003cspan class=\u0022rt-char\u0022\u003e©\u003c/span\u003eCopyright by \u003cspan data-source=\u0022general\u0022 data-post-id=\u0022\u0022 data-field=\u0022site_title\u0022 data-field-name=\u0022\u0022 class=\u0022rt-dyd\u0022\u003e{{site_title}}\u003c/span\u003e\u003cspan class=\u0022rt-char\u0022\u003e−\u003c/span\u003e2020 - \u003cspan data-source=\u0022general\u0022 data-post-id=\u0022\u0022 data-field=\u0022current_year\u0022 data-field-name=\u0022\u0022 class=\u0022rt-dyd\u0022\u003e{{current_year}}\u003c/span\u003e","metadata":{"name":"Copyright row"}} /-->
<!-- /wp:wphave/group -->

<!-- wp:wphave/navigation {"wphave":{"settings":{"collapseBehavior":"never"}}} -->
<!-- wp:wphave/navigation-link {"content":"Terms and Conditions"} /-->

<!-- wp:wphave/navigation-separator {"wphave":{"settings":{"colors":{"bg":"var(\u002d\u002dwphave-site-color-background-contrast-3)"}},"styles":"\u002d\u002dnav-menu-separator-color: var(\u002d\u002dwphave-site-color-background-contrast-3)"}} /-->

<!-- wp:wphave/navigation-link {"content":"Data Privacy"} /-->

<!-- wp:wphave/navigation-separator {"wphave":{"settings":{"colors":{"bg":"var(\u002d\u002dwphave-site-color-background-contrast-3)"}},"styles":"\u002d\u002dnav-menu-separator-color: var(\u002d\u002dwphave-site-color-background-contrast-3)"}} /-->

<!-- wp:wphave/navigation-link {"content":"License Terms"} /-->
<!-- /wp:wphave/navigation -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        return $patterns;

	}

endif;
