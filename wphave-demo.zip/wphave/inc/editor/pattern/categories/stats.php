<?php

/**
 * Functions to group stats and proof number block patterns.
 */

if ( ! function_exists( 'wphave_block_pattern_collection_stats' ) ) :

	function wphave_block_pattern_collection_stats( $args = array() ) {

        $content_width = isset( $args['width'] ) ? (int) $args['width'] : 1300;
        $slots = is_array( $args['slots'] ?? null ) ? $args['slots'] : array();
        $patterns = array();
        $button_small = array(
            'attrs' => array(
                'wphave' => array(
                    'settings' => array(
                        'size' => '0',
                    ),
                    'styles' => '\u002d\u002dbtn-size-scale: 0',
                ),
            ),
        );
        $button_small_secondary = array_replace_recursive( $button_small, array(
            'attrs' => array(
                'wphave' => array(
                    'settings' => array(
                        'variant' => 'secondary',
                    ),
                ),
            ),
        ) );
        $stat_value_m = array(
            'attrs' => array(
                'wphave' => array(
                    'settings' => array(
                        'formats' => array('bold'),
                    ),
                    'text' => array(
                        'typeface' => array(
                            'size' => array(
                                'type' => 'title-m',
                            ),
                        ),
                    ),
                    'classNames' => 'is-bold tf-fs tf-fs-title-m',
                ),
            ),
        );
        $stat_value_l = array_replace_recursive( $stat_value_m, array(
            'attrs' => array(
                'wphave' => array(
                    'text' => array(
                        'typeface' => array(
                            'size' => array(
                                'type' => 'title-l',
                            ),
                        ),
                    ),
                    'classNames' => 'is-bold tf-fs tf-fs-title-l',
                ),
            ),
        ) );
        $stat_value_xl = array_replace_recursive( $stat_value_m, array(
            'attrs' => array(
                'wphave' => array(
                    'text' => array(
                        'typeface' => array(
                            'size' => array(
                                'type' => 'title-xl',
                            ),
                        ),
                    ),
                    'classNames' => 'is-bold tf-fs tf-fs-title-xl',
                ),
            ),
        ) );
        $stat_suffix = array(
            'textType' => 'stat-suffix',
            'attrs' => array(
                'wphave' => array(
                    'settings' => array(
                        'formats' => array('bold'),
                    ),
                    'text' => array(
                        'typeface' => array(
                            'size' => array(
                                'type' => 'text-3xl',
                            ),
                        ),
                    ),
                    'classNames' => 'is-bold tf-fs tf-fs-text-3xl',
                ),
            ),
        );

        $patterns[] = array(
            'key' => 'stats-section-1',
            'tags' => array('stats', 'proof'),
            'title' => __( 'Stats Split Metrics Grid', 'wphave' ),
            'keywords' => array('stats', 'proof', 'metrics', 'numbers', 'split', 'grid'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('stats', 'proof', 'section'),
                'layout' => array('split', 'grid'),
                'width' => array('wide'),
                'visual' => array('numbers'),
                'content' => array('heading', 'body', 'actions', 'stats'),
                'intent' => array('proof', 'credibility', 'conversion-support'),
                'treatment' => array('structured', 'spacious'),
                'description' => 'Split proof section with intro copy and four compact metrics in a two-column grid.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"wi-in ofw ly ly-gr ly-col-2 ly-gr-m ly-m-col-1","dimensions":{"overflow":"clip","innerWidth":{"limit":"max","custom":"100%"}},"styles":"\u002d\u002dwi-in: 100%;\u002d\u002dofw: clip","layout":{"type":"grid","grid":{"gapX":"var(\u002d\u002dwphave-site-gap-size-4xl)","gapY":"var(\u002d\u002dwphave-site-gap-size-4xl)","columns":2,"keepColumns":"auto","gridRowHeight":"auto","alignVertical":"center","alignHorizontal":"space-between"}},"stylesLayout":"\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-col: 2;\u002d\u002dly-valign: center;\u002d\u002dly-halign: space-between;\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-m-col: 1;\u002d\u002dly-m-valign: center;\u002d\u002dly-m-halign: space-between","mobile":{"layout":{"gridAreas":{"areas":{"columns":1,"rows":3,"areas":[{"id":"c1","label":"1","x":1,"y":1,"w":1,"h":1},{"id":"c2","label":"2","x":1,"y":3,"w":1,"h":1}],"rowHeight":"auto"}},"grid":{"columns":1}}}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked"},"classNames":"ly ly-stk"}} -->
' . wphave_pattern_slot( 'heading', array( 'level' => 'h2' ), $slots ) . '

' . wphave_pattern_slot( 'body', $slots ) . '

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"\u002d\u002dwi: fit-content","classNames":"wi ly ly-fl","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-m)","gapY":"var(\u002d\u002dwphave-site-gap-size-m)","flexWrap":"no-wrap","flexDirection":"row","flexItemSizing":"auto"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-direction: row;\u002d\u002dly-fl-itm: 0 1 auto"}} -->
' . wphave_pattern_slot( 'actions.0.label', $button_small, $slots ) . '

' . wphave_pattern_slot( 'actions.1.label', $button_small_secondary, $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"grid","grid":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","columns":2,"keepColumns":"nowrap","gridRowHeight":"auto","alignVertical":"stretch","alignHorizontal":"space-between"}},"classNames":"ly ly-gr ly-nowrap ly-gr-m ly-m-col-1","stylesLayout":"\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-col: 2;\u002d\u002dly-valign: stretch;\u002d\u002dly-halign: space-between;\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-col: 1;\u002d\u002dly-m-valign: stretch;\u002d\u002dly-m-halign: space-between","mobile":{"layout":{"grid":{"columns":1}}}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-xs)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-xs)"}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-s)","gapY":"var(\u002d\u002dwphave-site-gap-size-s)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"baseline","alignHorizontal":"start"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: baseline;\u002d\u002dly-halign: start;\u002d\u002dly-fl-direction: row"}} -->
' . wphave_pattern_slot( 'stats.0.value', 'counter', array_replace_recursive( $stat_value_m, array( 'textType' => 'stat-number' ) ), $slots ) . '

' . wphave_pattern_slot( 'stats.0.suffix', $stat_suffix, $slots ) . '
<!-- /wp:wphave/group -->

' . wphave_pattern_slot( 'stats.0.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-xs)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-xs)"}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-s)","gapY":"var(\u002d\u002dwphave-site-gap-size-s)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"baseline","alignHorizontal":"start"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: baseline;\u002d\u002dly-halign: start;\u002d\u002dly-fl-direction: row"}} -->
' . wphave_pattern_slot( 'stats.1.value', 'counter', array_replace_recursive( $stat_value_m, array( 'textType' => 'stat-number' ) ), $slots ) . '

' . wphave_pattern_slot( 'stats.1.suffix', $stat_suffix, $slots ) . '
<!-- /wp:wphave/group -->

' . wphave_pattern_slot( 'stats.1.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-xs)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-xs)"}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-s)","gapY":"var(\u002d\u002dwphave-site-gap-size-s)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"baseline","alignHorizontal":"start"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: baseline;\u002d\u002dly-halign: start;\u002d\u002dly-fl-direction: row"}} -->
' . wphave_pattern_slot( 'stats.2.value', 'counter', array_replace_recursive( $stat_value_m, array( 'textType' => 'stat-number' ) ), $slots ) . '

' . wphave_pattern_slot( 'stats.2.suffix', $stat_suffix, $slots ) . '
<!-- /wp:wphave/group -->

' . wphave_pattern_slot( 'stats.2.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-xs)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-xs)"}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-s)","gapY":"var(\u002d\u002dwphave-site-gap-size-s)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"baseline","alignHorizontal":"start"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: baseline;\u002d\u002dly-halign: start;\u002d\u002dly-fl-direction: row"}} -->
' . wphave_pattern_slot( 'stats.3.value', 'counter', array_replace_recursive( $stat_value_m, array( 'textType' => 'stat-number' ) ), $slots ) . '

' . wphave_pattern_slot( 'stats.3.suffix', $stat_suffix, $slots ) . '
<!-- /wp:wphave/group -->

' . wphave_pattern_slot( 'stats.3.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'stats-section-2',
            'tags' => array('stats', 'proof'),
            'title' => __( 'Stats Wide Metrics Panel', 'wphave' ),
            'keywords' => array('stats', 'proof', 'metrics', 'panel', 'wide', 'grid'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('stats', 'proof', 'section', 'card'),
                'layout' => array('stacked', 'grid', 'panel'),
                'width' => array('wide'),
                'visual' => array('numbers', 'cards'),
                'content' => array('heading', 'body', 'actions', 'stats'),
                'intent' => array('trust-building', 'proof', 'credibility'),
                'treatment' => array('framed', 'soft-surface', 'structured'),
                'description' => 'Wide framed stats panel with lead copy and a grouped metric grid.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-wide wi-in pa ofw ly ly-stk bg-co bg br","dimensions":{"overflow":"clip","innerWidth":{"limit":"max","custom":"100%"},"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl)"}},"styles":"\u002d\u002dwi-in: 100%;\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background-contrast-1);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-3xl)"}},"background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background-contrast-1)"}},"mobile":{"layout":{"gridAreas":{"areas":{"columns":1,"rows":3,"areas":[{"id":"c1","label":"1","x":1,"y":1,"w":1,"h":1},{"id":"c2","label":"2","x":1,"y":3,"w":1,"h":1}],"rowHeight":"auto"}},"grid":{"columns":1}}},"stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-xl)","frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"},"features":{"size":"wide"},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-m-gap: var(\u002d\u002dwphave-site-gap-size-3xl)"}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"wi ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"width":{"limit":"max","custom":"999px"}},"styles":"\u002d\u002dwi: 999px"}} -->
' . wphave_pattern_slot( 'heading', array( 'level' => 'h2', 'size' => 'title-l' ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-m' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"\u002d\u002dwi: fit-content","classNames":"wi ly ly-fl","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-m)","gapY":"var(\u002d\u002dwphave-site-gap-size-m)","flexWrap":"no-wrap","flexDirection":"row","flexItemSizing":"auto"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-direction: row;\u002d\u002dly-fl-itm: 0 1 auto"}} -->
' . wphave_pattern_slot( 'actions.0.label', $button_small, $slots ) . '

' . wphave_pattern_slot( 'actions.1.label', $button_small_secondary, $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"grid","grid":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","columns":2,"keepColumns":"nowrap","gridRowHeight":"auto","alignVertical":"stretch","alignHorizontal":"space-between"}},"classNames":"pa ofw ly ly-gr ly-nowrap bg-co bg br ly-gr-m ly-m-col-1","stylesLayout":"\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-col: 2;\u002d\u002dly-valign: stretch;\u002d\u002dly-halign: space-between;\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-col: 1;\u002d\u002dly-m-valign: stretch;\u002d\u002dly-m-halign: space-between","mobile":{"layout":{"grid":{"columns":1}}},"dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-top) var(\u002d\u002dwphave-site-padding-right) var(\u002d\u002dwphave-site-padding-bottom) var(\u002d\u002dwphave-site-padding-left)"},"overflow":"clip"},"background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background)"}},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-top) var(\u002d\u002dwphave-site-padding-right) var(\u002d\u002dwphave-site-padding-bottom) var(\u002d\u002dwphave-site-padding-left);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-top);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-right);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-bottom);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-left);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-left);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-right)","frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-xs)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-xs)"}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-s)","gapY":"var(\u002d\u002dwphave-site-gap-size-s)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"baseline","alignHorizontal":"start"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: baseline;\u002d\u002dly-halign: start;\u002d\u002dly-fl-direction: row"}} -->
' . wphave_pattern_slot( 'stats.0.value', $stat_value_m, $slots ) . '
<!-- /wp:wphave/group -->

' . wphave_pattern_slot( 'stats.0.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-xs)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-xs)"}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-s)","gapY":"var(\u002d\u002dwphave-site-gap-size-s)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"baseline","alignHorizontal":"start"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: baseline;\u002d\u002dly-halign: start;\u002d\u002dly-fl-direction: row"}} -->
' . wphave_pattern_slot( 'stats.1.value', $stat_value_m, $slots ) . '
<!-- /wp:wphave/group -->

' . wphave_pattern_slot( 'stats.1.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-xs)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-xs)"}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-s)","gapY":"var(\u002d\u002dwphave-site-gap-size-s)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"baseline","alignHorizontal":"start"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: baseline;\u002d\u002dly-halign: start;\u002d\u002dly-fl-direction: row"}} -->
' . wphave_pattern_slot( 'stats.2.value', $stat_value_m, $slots ) . '
<!-- /wp:wphave/group -->

' . wphave_pattern_slot( 'stats.2.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-xs)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-xs)"}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-s)","gapY":"var(\u002d\u002dwphave-site-gap-size-s)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"baseline","alignHorizontal":"start"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: baseline;\u002d\u002dly-halign: start;\u002d\u002dly-fl-direction: row"}} -->
' . wphave_pattern_slot( 'stats.3.value', $stat_value_m, $slots ) . '
<!-- /wp:wphave/group -->

' . wphave_pattern_slot( 'stats.3.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'stats-section-3',
            'tags' => array('stats', 'proof'),
            'title' => __( 'Stats Contrast Metrics Panel', 'wphave' ),
            'keywords' => array('stats', 'proof', 'metrics', 'contrast', 'dark', 'numbers'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('stats', 'proof', 'section'),
                'layout' => array('stacked', 'grid', 'contrast-panel'),
                'width' => array('wide'),
                'visual' => array('numbers', 'color-background'),
                'content' => array('heading', 'body', 'actions', 'stats'),
                'intent' => array('proof', 'trust-building', 'conversion-support'),
                'treatment' => array('strong-contrast', 'structured', 'spacious'),
                'description' => 'High-contrast stats panel for strong proof moments and campaign sections.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-wide wi-in pa ofw ly ly-stk bg-co bg br tx-co","dimensions":{"overflow":"clip","innerWidth":{"limit":"max","custom":"100%"},"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl)"}},"styles":"\u002d\u002dwi-in: 100%;\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background-contrast-10);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners);\u002d\u002dtx-co: var(\u002d\u002dwphave-site-color-background-subtle-10)","layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-4xl)"}},"background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background-contrast-10)"}},"mobile":{"layout":{"gridAreas":{"areas":{"columns":1,"rows":3,"areas":[{"id":"c1","label":"1","x":1,"y":1,"w":1,"h":1},{"id":"c2","label":"2","x":1,"y":3,"w":1,"h":1}],"rowHeight":"auto"}},"grid":{"columns":1}}},"stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-xl)","frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"},"features":{"size":"wide"},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-m-gap: var(\u002d\u002dwphave-site-gap-size-4xl)","text":{"colors":{"text":"var(\u002d\u002dwphave-site-color-background-subtle-10)"}}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"wi ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"width":{"limit":"max","custom":"999px"}},"styles":"\u002d\u002dwi: 999px"}} -->
' . wphave_pattern_slot( 'heading', array( 'level' => 'h2', 'size' => 'title-l' ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-m' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"\u002d\u002dwi: fit-content","classNames":"wi ly ly-fl","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-m)","gapY":"var(\u002d\u002dwphave-site-gap-size-m)","flexWrap":"no-wrap","flexDirection":"row","flexItemSizing":"auto"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-direction: row;\u002d\u002dly-fl-itm: 0 1 auto"}} -->
' . wphave_pattern_slot( 'actions.0.label', $button_small, $slots ) . '

' . wphave_pattern_slot( 'actions.1.label', $button_small_secondary, $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"grid","grid":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","columns":3,"keepColumns":"nowrap","gridRowHeight":"auto","alignVertical":"stretch","alignHorizontal":"space-between"}},"classNames":"ly ly-gr ly-nowrap ly-gr-m ly-m-col-1","stylesLayout":"\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-col: 3;\u002d\u002dly-valign: stretch;\u002d\u002dly-halign: space-between;\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-col: 1;\u002d\u002dly-m-valign: stretch;\u002d\u002dly-m-halign: space-between","mobile":{"layout":{"grid":{"columns":1}}}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-xs)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-xs)"}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-s)","gapY":"var(\u002d\u002dwphave-site-gap-size-s)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"baseline","alignHorizontal":"start"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: baseline;\u002d\u002dly-halign: start;\u002d\u002dly-fl-direction: row"}} -->
' . wphave_pattern_slot( 'stats.0.value', $stat_value_m, $slots ) . '
<!-- /wp:wphave/group -->

' . wphave_pattern_slot( 'stats.0.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-xs)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-xs)"}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-s)","gapY":"var(\u002d\u002dwphave-site-gap-size-s)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"baseline","alignHorizontal":"start"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: baseline;\u002d\u002dly-halign: start;\u002d\u002dly-fl-direction: row"}} -->
' . wphave_pattern_slot( 'stats.1.value', $stat_value_m, $slots ) . '
<!-- /wp:wphave/group -->

' . wphave_pattern_slot( 'stats.1.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-xs)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-xs)"}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-s)","gapY":"var(\u002d\u002dwphave-site-gap-size-s)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"baseline","alignHorizontal":"start"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: baseline;\u002d\u002dly-halign: start;\u002d\u002dly-fl-direction: row"}} -->
' . wphave_pattern_slot( 'stats.2.value', $stat_value_m, $slots ) . '
<!-- /wp:wphave/group -->

' . wphave_pattern_slot( 'stats.2.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'stats-section-4',
            'tags' => array('stats', 'proof'),
            'title' => __( 'Stats Proof Card Grid', 'wphave' ),
            'keywords' => array('stats', 'proof', 'numbers', 'cards', 'grid'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('stats', 'proof', 'section', 'card'),
                'layout' => array('stacked', 'grid', 'compact-card'),
                'width' => array('wide'),
                'visual' => array('stat-card', 'numbers', 'cards'),
                'content' => array('heading', 'body', 'actions', 'stats'),
                'intent' => array('proof', 'credibility', 'trust-building'),
                'treatment' => array('framed', 'soft-surface', 'structured'),
                'description' => 'Stats section with three proof cards, varied visual weight and optional spacer panels.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-wide wi-in pa ofw ly ly-stk bg-co bg br","dimensions":{"overflow":"clip","innerWidth":{"limit":"max","custom":"100%"},"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl)"}},"styles":"\u002d\u002dwi-in: 100%;\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl) var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background-contrast-1);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","layout":{"type":"stacked"},"background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background-contrast-1)"}},"mobile":{"layout":{"gridAreas":{"areas":{"columns":1,"rows":3,"areas":[{"id":"c1","label":"1","x":1,"y":1,"w":1,"h":1},{"id":"c2","label":"2","x":1,"y":3,"w":1,"h":1}],"rowHeight":"auto"}},"grid":{"columns":1}}},"stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-xl)","frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"},"features":{"size":"wide"}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"wi ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"width":{"limit":"max","custom":"999px"}},"styles":"\u002d\u002dwi: 999px"}} -->
' . wphave_pattern_slot( 'heading', array( 'level' => 'h2', 'size' => 'title-l' ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-m' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"\u002d\u002dwi: fit-content","classNames":"wi ly ly-fl","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-m)","gapY":"var(\u002d\u002dwphave-site-gap-size-m)","flexWrap":"no-wrap","flexDirection":"row","flexItemSizing":"auto"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-direction: row;\u002d\u002dly-fl-itm: 0 1 auto"}} -->
' . wphave_pattern_slot( 'actions.0.label', $button_small, $slots ) . '

' . wphave_pattern_slot( 'actions.1.label', $button_small_secondary, $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"grid","grid":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","columns":3,"keepColumns":"nowrap","gridRowHeight":"auto","alignVertical":"end","alignHorizontal":"space-between"}},"classNames":"ly ly-gr ly-nowrap ly-gr-m ly-m-col-1","stylesLayout":"\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-col: 3;\u002d\u002dly-valign: end;\u002d\u002dly-halign: space-between;\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-col: 1;\u002d\u002dly-m-valign: end;\u002d\u002dly-m-halign: space-between","mobile":{"layout":{"grid":{"columns":1}}}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-xs)"}},"classNames":"pa ofw ly ly-stk bg-co bg br","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-xs)","dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m)"},"overflow":"clip"},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-m)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background)"}},"frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-s)","gapY":"var(\u002d\u002dwphave-site-gap-size-s)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"baseline","alignHorizontal":"start"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: baseline;\u002d\u002dly-halign: start;\u002d\u002dly-fl-direction: row"}} -->
' . wphave_pattern_slot( 'stats.0.value', 'counter', array_replace_recursive( $stat_value_m, array( 'textType' => 'stat-number' ) ), $slots ) . '

' . wphave_pattern_slot( 'stats.0.suffix', $stat_suffix, $slots ) . '
<!-- /wp:wphave/group -->

' . wphave_pattern_slot( 'stats.0.label', array( 'level' => 'h3', 'size' => 'title-xxs' ), $slots ) . '

' . wphave_pattern_slot( 'stats.0.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-xs)"}},"classNames":"pa ofw ly ly-stk bg-co bg br","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-xs)","dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m)"},"overflow":"clip"},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-m)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background)"}},"frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"}}} -->
<!-- wp:wphave/spacer /-->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-s)","gapY":"var(\u002d\u002dwphave-site-gap-size-s)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"baseline","alignHorizontal":"start"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: baseline;\u002d\u002dly-halign: start;\u002d\u002dly-fl-direction: row"}} -->
' . wphave_pattern_slot( 'stats.1.value', 'counter', array_replace_recursive( $stat_value_l, array( 'textType' => 'stat-number' ) ), $slots ) . '

' . wphave_pattern_slot( 'stats.1.suffix', $stat_suffix, $slots ) . '
<!-- /wp:wphave/group -->

' . wphave_pattern_slot( 'stats.1.label', array( 'level' => 'h3', 'size' => 'title-xxs' ), $slots ) . '

' . wphave_pattern_slot( 'stats.1.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-xs)"}},"classNames":"pa ofw ly ly-stk bg-co bg br","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-xs)","dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m)"},"overflow":"clip"},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-m)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background)"}},"frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"}}} -->
<!-- wp:wphave/spacer {"wphave":{"settings":{"aspectRatio":"10/1"},"styles":"\u002d\u002daspect-ratio: 10/1"}} /-->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-s)","gapY":"var(\u002d\u002dwphave-site-gap-size-s)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"baseline","alignHorizontal":"start"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: baseline;\u002d\u002dly-halign: start;\u002d\u002dly-fl-direction: row"}} -->
' . wphave_pattern_slot( 'stats.2.value', 'counter', array_replace_recursive( $stat_value_xl, array( 'textType' => 'stat-number' ) ), $slots ) . '

' . wphave_pattern_slot( 'stats.2.suffix', $stat_suffix, $slots ) . '
<!-- /wp:wphave/group -->

' . wphave_pattern_slot( 'stats.2.label', array( 'level' => 'h3', 'size' => 'title-xxs' ), $slots ) . '

' . wphave_pattern_slot( 'stats.2.text', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'stats-section-5',
            'tags' => array('stats', 'proof'),
            'title' => __( 'Stats Rising Proof Cards', 'wphave' ),
            'keywords' => array('stats', 'proof', 'numbers', 'cards', 'full-width'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('stats', 'proof', 'section', 'card'),
                'layout' => array('centered', 'grid', 'featured'),
                'width' => array('full-width'),
                'visual' => array('stat-card', 'numbers'),
                'content' => array('heading', 'body', 'actions', 'stats'),
                'intent' => array('proof', 'social-proof', 'credibility'),
                'treatment' => array('spacious', 'soft-surface', 'editorial'),
                'description' => 'Full-width centered proof section with bottom-aligned metric cards.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-full pa ofw ly ly-stk bg-co bg","dimensions":{"overflow":"clip","spacing":{"padding":"var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xl) 0 var(\u002d\u002dwphave-site-padding-xl)"}},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xl) 0 var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dpa-bottom: 0;\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background-contrast-1)","layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-4xl)"}},"background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background-contrast-1)"}},"mobile":{"layout":{"gridAreas":{"areas":{"columns":1,"rows":3,"areas":[{"id":"c1","label":"1","x":1,"y":1,"w":1,"h":1},{"id":"c2","label":"2","x":1,"y":3,"w":1,"h":1}],"rowHeight":"auto"}},"grid":{"columns":1}}},"stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-xl);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-xl)","features":{"size":"full"},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-m-gap: var(\u002d\u002dwphave-site-gap-size-4xl)"}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)","contentPosition":"center"}},"classNames":"hd-center wi ly ly-stk ly-co-pos txta","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"width":{"limit":"max","custom":"999px"}},"styles":"\u002d\u002dwi: 999px;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center;\u002d\u002dtxta: center","features":{"horizontalDirection":"center"},"text":{"align":"center"}}} -->
' . wphave_pattern_slot( 'heading', array( 'level' => 'h2', 'size' => 'title-l' ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-m' ), $slots ) . '

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"\u002d\u002dwi: fit-content","classNames":"wi ly ly-fl","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-m)","gapY":"var(\u002d\u002dwphave-site-gap-size-m)","flexWrap":"no-wrap","flexDirection":"row","flexItemSizing":"auto"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-direction: row;\u002d\u002dly-fl-itm: 0 1 auto"}} -->
' . wphave_pattern_slot( 'actions.0.label', $button_small, $slots ) . '

' . wphave_pattern_slot( 'actions.1.label', $button_small_secondary, $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"grid","grid":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","columns":3,"keepColumns":"nowrap","gridRowHeight":"auto","alignVertical":"end","alignHorizontal":"space-between"}},"classNames":"ly ly-gr ly-nowrap ly-gr-m ly-m-col-1","stylesLayout":"\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-col: 3;\u002d\u002dly-valign: end;\u002d\u002dly-halign: space-between;\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-m-col: 1;\u002d\u002dly-m-valign: end;\u002d\u002dly-m-halign: space-between","mobile":{"layout":{"grid":{"columns":1}}}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"pa ofw ly ly-stk bg-co bg br","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m)"},"overflow":"clip"},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) 0 0","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-m)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background)"}},"frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) 0 0"}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-s)","gapY":"var(\u002d\u002dwphave-site-gap-size-s)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"baseline","alignHorizontal":"start"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: baseline;\u002d\u002dly-halign: start;\u002d\u002dly-fl-direction: row"}} -->
' . wphave_pattern_slot( 'stats.0.value', $stat_value_m, $slots ) . '
<!-- /wp:wphave/group -->

' . wphave_pattern_slot( 'stats.0.label', array( 'level' => 'h3', 'size' => 'title-xxs' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"pa ofw ly ly-stk bg-co bg br","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m)"},"overflow":"clip"},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) 0 0","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-m)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background)"}},"frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) 0 0"}}} -->
<!-- wp:wphave/spacer {"wphave":{"settings":{"aspectRatio":"21/9"},"styles":"\u002d\u002daspect-ratio: 21/9"}} /-->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-s)","gapY":"var(\u002d\u002dwphave-site-gap-size-s)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"baseline","alignHorizontal":"start"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: baseline;\u002d\u002dly-halign: start;\u002d\u002dly-fl-direction: row"}} -->
' . wphave_pattern_slot( 'stats.1.value', $stat_value_xl, $slots ) . '
<!-- /wp:wphave/group -->

' . wphave_pattern_slot( 'stats.1.label', array( 'level' => 'h3', 'size' => 'title-xxs' ), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"pa ofw ly ly-stk bg-co bg br","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m)"},"overflow":"clip"},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) 0 0","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-m)","background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background)"}},"frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) 0 0"}}} -->
<!-- wp:wphave/spacer {"wphave":{"settings":{"aspectRatio":"10/1"},"styles":"\u002d\u002daspect-ratio: 10/1"}} /-->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-s)","gapY":"var(\u002d\u002dwphave-site-gap-size-s)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"baseline","alignHorizontal":"start"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: baseline;\u002d\u002dly-halign: start;\u002d\u002dly-fl-direction: row"}} -->
' . wphave_pattern_slot( 'stats.2.value', $stat_value_l, $slots ) . '
<!-- /wp:wphave/group -->

' . wphave_pattern_slot( 'stats.2.label', array( 'level' => 'h3', 'size' => 'title-xxs' ), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        return $patterns;

	}

endif;
