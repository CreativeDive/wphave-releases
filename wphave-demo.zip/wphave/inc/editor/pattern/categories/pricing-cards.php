<?php

/**
 * Functions to group similar wphave block patterns.
 */

if ( ! function_exists( 'wphave_block_pattern_collection_pricing_cards' ) ) :

	function wphave_block_pattern_collection_pricing_cards( $args = array() ) {

        $content_width = isset( $args['width'] ) ? (int) $args['width'] : 1300;

        $patterns = array();

        return $patterns;

	}

endif;
