<?php

/**
 * Functions to group process and step block patterns.
 */

if ( ! function_exists( 'wphave_block_pattern_collection_process' ) ) :

	function wphave_block_pattern_collection_process( $args = array() ) {

        $content_width = isset( $args['width'] ) ? (int) $args['width'] : 1300;
        $slots = is_array( $args['slots'] ?? null ) ? $args['slots'] : array();
        $patterns = array();

        $step_sequence_ids = array();

        for( $i = 1; $i <= 7; $i++ ) {
            $step_sequence_ids['step-sections-' . $i] = 'step-sections-' . $i . '-' . wp_rand( 1000, 9999 );
        }
        $patterns[] = array(
            'key' => 'step-sections-1',
            'tags' => array('process', 'steps'),
            'title' => __( 'Step Sections Numbered Cards', 'wphave' ),
            'keywords' => array('process', 'steps', 'workflow', 'section', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('process', 'steps'),
                'layout' => array('grid'),
                'content' => array('heading', 'body', 'steps', 'media'),
                'intent' => array('process', 'explain-process'),
                'treatment' => array('framed', 'structured'),
                'description' => 'A centered process section with three large numbered cards for simple onboarding, service flows, or guided product steps.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"wi-in pa ofw ly ly-stk ly-co-pos bg-co bg br txta","dimensions":{"overflow":"clip","innerWidth":{"limit":"max","custom":"100%"},"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl)"}},"styles":"\u002d\u002dwi-in: 100%;\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dofw: clip;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background-contrast-1);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners);\u002d\u002dtxta: center","layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-3xl)","contentPosition":"center"}},"background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background-contrast-1)"}},"stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-xxl)","frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-3xl)","text":{"align":"center"}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-m)"}},"classNames":"wi ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-m)","dimensions":{"width":{"limit":"max","custom":"999px"}},"styles":"\u002d\u002dwi: 999px"}} -->
' . wphave_pattern_slot( 'heading', 'heading', array (
  'size' => 'title-m',
), $slots ) . '

' . wphave_pattern_slot( 'body', 'body', array (
  'size' => 'default',
), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"grid","grid":{"gapX":"var(\u002d\u002dwphave-site-gap-size-3xl)","gapY":"var(\u002d\u002dwphave-site-gap-size-3xl)","columns":3,"keepColumns":"nowrap","gridRowHeight":"auto","alignVertical":"stretch","alignHorizontal":"stretch"}},"classNames":"ly ly-gr ly-nowrap ly-gr-m ly-m-col-1","stylesLayout":"\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-col: 3;\u002d\u002dly-valign: stretch;\u002d\u002dly-halign: stretch;\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-m-col: 1;\u002d\u002dly-m-valign: stretch;\u002d\u002dly-m-halign: stretch","mobile":{"layout":{"grid":{"columns":1}}}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"contentPosition":"center"}},"classNames":"ly ly-stk ly-co-pos","styles":"\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center"}} -->
' . wphave_pattern_slot( 'steps.1.step', 'step', array (
  'sequenceId' => $step_sequence_ids['step-sections-1'],
  'attrs' =>
  array (
    'wphave' =>
    array (
      'dimensions' =>
      array (
        'spacing' =>
        array (
          'padding' => 'var(--wphave-site-padding-s) var(--wphave-site-padding-s) var(--wphave-site-padding-s) var(--wphave-site-padding-s)',
        ),
        'aspectRatio' =>
        array (
          'ratio' => '1/1',
        ),
      ),
      'background' =>
      array (
        'color' =>
        array (
          'base' => 'var(--wphave-site-color-background)',
        ),
      ),
      'styles' => '--pa: var(--wphave-site-padding-s) var(--wphave-site-padding-s) var(--wphave-site-padding-s) var(--wphave-site-padding-s);--pa-top: var(--wphave-site-padding-s);--pa-right: var(--wphave-site-padding-s);--pa-bottom: var(--wphave-site-padding-s);--pa-left: var(--wphave-site-padding-s);--asrt: 1/1;--bg-co: var(--wphave-site-color-background);--br: 100px 100px 100px 100px;--numberColor: var(--wphave-site-color-accent)',
      'stylesChild' => '--left-spacing-inherit: var(--wphave-site-padding-s);--right-spacing-inherit: var(--wphave-site-padding-s)',
      'classNames' => 'pa asrt bg-co bg br tf-fs tf-fs-text-3xl',
      'frame' =>
      array (
        'corners' => '100px 100px 100px 100px',
      ),
      'text' =>
      array (
        'typeface' =>
        array (
          'size' =>
          array (
            'type' => 'text-3xl',
          ),
        ),
      ),
      'settings' =>
      array (
        'connector' =>
        array (
          'enabled' => true,
          'color' => 'var(--wphave-site-color-background)',
          'width' => '4px',
          'style' => 'solid',
          'dashGap' => 4,
          'shape' => 'curved',
          'curveTension' => 0.75,
          'animation' => 'none',
          'animationSpeed' => 2,
          'zIndex' => 1,
        ),
        'colors' =>
        array (
          'count' => 'var(--wphave-site-color-accent)',
        ),
        'leadingZero' => false,
      ),
    ),
  ),
), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"skl ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"stackLevel":{"level":2}},"styles":"\u002d\u002dskl: 2"}} -->
' . wphave_pattern_slot( 'steps.1.title', 'heading', array (
  'level' => 'h3',
  'size' => 'title-xxs',
), $slots ) . '

' . wphave_pattern_slot( 'steps.1.text', 'body', array('size' => 'text-s'), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"contentPosition":"center"}},"classNames":"ly ly-stk ly-co-pos","styles":"\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center"}} -->
' . wphave_pattern_slot( 'steps.2.step', 'step', array (
  'sequenceId' => $step_sequence_ids['step-sections-1'],
  'attrs' =>
  array (
    'wphave' =>
    array (
      'dimensions' =>
      array (
        'spacing' =>
        array (
          'padding' => 'var(--wphave-site-padding-s) var(--wphave-site-padding-s) var(--wphave-site-padding-s) var(--wphave-site-padding-s)',
        ),
        'aspectRatio' =>
        array (
          'ratio' => '1/1',
        ),
      ),
      'background' =>
      array (
        'color' =>
        array (
          'base' => 'var(--wphave-site-color-background)',
        ),
      ),
      'styles' => '--pa: var(--wphave-site-padding-s) var(--wphave-site-padding-s) var(--wphave-site-padding-s) var(--wphave-site-padding-s);--pa-top: var(--wphave-site-padding-s);--pa-right: var(--wphave-site-padding-s);--pa-bottom: var(--wphave-site-padding-s);--pa-left: var(--wphave-site-padding-s);--asrt: 1/1;--bg-co: var(--wphave-site-color-background);--br: 100px 100px 100px 100px;--numberColor: var(--wphave-site-color-accent)',
      'stylesChild' => '--left-spacing-inherit: var(--wphave-site-padding-s);--right-spacing-inherit: var(--wphave-site-padding-s)',
      'classNames' => 'pa asrt bg-co bg br tf-fs tf-fs-text-3xl',
      'frame' =>
      array (
        'corners' => '100px 100px 100px 100px',
      ),
      'text' =>
      array (
        'typeface' =>
        array (
          'size' =>
          array (
            'type' => 'text-3xl',
          ),
        ),
      ),
      'settings' =>
      array (
        'colors' =>
        array (
          'count' => 'var(--wphave-site-color-accent)',
        ),
        'leadingZero' => false,
      ),
    ),
  ),
), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"skl ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"stackLevel":{"level":2}},"styles":"\u002d\u002dskl: 2"}} -->
' . wphave_pattern_slot( 'steps.2.title', 'heading', array (
  'level' => 'h3',
  'size' => 'title-xxs',
), $slots ) . '

' . wphave_pattern_slot( 'steps.2.text', 'body', array('size' => 'text-s'), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"contentPosition":"center"}},"classNames":"ly ly-stk ly-co-pos","styles":"\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center"}} -->
' . wphave_pattern_slot( 'steps.3.step', 'step', array (
  'sequenceId' => $step_sequence_ids['step-sections-1'],
  'attrs' =>
  array (
    'wphave' =>
    array (
      'dimensions' =>
      array (
        'spacing' =>
        array (
          'padding' => 'var(--wphave-site-padding-s) var(--wphave-site-padding-s) var(--wphave-site-padding-s) var(--wphave-site-padding-s)',
        ),
        'aspectRatio' =>
        array (
          'ratio' => '1/1',
        ),
      ),
      'background' =>
      array (
        'color' =>
        array (
          'base' => 'var(--wphave-site-color-background)',
        ),
      ),
      'styles' => '--pa: var(--wphave-site-padding-s) var(--wphave-site-padding-s) var(--wphave-site-padding-s) var(--wphave-site-padding-s);--pa-top: var(--wphave-site-padding-s);--pa-right: var(--wphave-site-padding-s);--pa-bottom: var(--wphave-site-padding-s);--pa-left: var(--wphave-site-padding-s);--asrt: 1/1;--bg-co: var(--wphave-site-color-background);--br: 100px 100px 100px 100px;--numberColor: var(--wphave-site-color-accent)',
      'stylesChild' => '--left-spacing-inherit: var(--wphave-site-padding-s);--right-spacing-inherit: var(--wphave-site-padding-s)',
      'classNames' => 'pa asrt bg-co bg br tf-fs tf-fs-text-3xl',
      'frame' =>
      array (
        'corners' => '100px 100px 100px 100px',
      ),
      'text' =>
      array (
        'typeface' =>
        array (
          'size' =>
          array (
            'type' => 'text-3xl',
          ),
        ),
      ),
      'settings' =>
      array (
        'colors' =>
        array (
          'count' => 'var(--wphave-site-color-accent)',
        ),
        'leadingZero' => false,
      ),
    ),
  ),
), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"skl ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"stackLevel":{"level":2}},"styles":"\u002d\u002dskl: 2"}} -->
' . wphave_pattern_slot( 'steps.3.title', 'heading', array (
  'level' => 'h3',
  'size' => 'title-xxs',
), $slots ) . '

' . wphave_pattern_slot( 'steps.3.text', 'body', array('size' => 'text-s'), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'step-sections-2',
            'tags' => array('process', 'steps'),
            'title' => __( 'Step Sections Accent Process', 'wphave' ),
            'keywords' => array('process', 'steps', 'workflow', 'section', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('process', 'steps'),
                'layout' => array('grid'),
                'content' => array('heading', 'body', 'steps', 'media'),
                'intent' => array('process', 'explain-process'),
                'treatment' => array('strong-contrast', 'structured'),
                'description' => 'A high contrast accent process with connected circular steps, compact copy, and a closing text/action area.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"wi-in pa ofw ly ly-stk ly-co-pos bg-co bg br txta tx-co","dimensions":{"overflow":"clip","innerWidth":{"limit":"max","custom":"100%"},"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl)"}},"styles":"\u002d\u002dwi-in: 100%;\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl) var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dofw: clip;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-accent);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners);\u002d\u002dtxta: center;\u002d\u002dtx-co: var(\u002d\u002dwphave-site-color-accent-contrast-10)","layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-4xl)","contentPosition":"center"}},"background":{"color":{"base":"var(\u002d\u002dwphave-site-color-accent)"}},"stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-xxl)","frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-4xl)","text":{"align":"center","colors":{"text":"var(\u002d\u002dwphave-site-color-accent-contrast-10)"}}}} -->
' . wphave_pattern_slot( 'heading', 'heading', array (
  'size' => 'title-m',
), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"grid","grid":{"gapX":"var(\u002d\u002dwphave-site-gap-size-3xl)","gapY":"var(\u002d\u002dwphave-site-gap-size-3xl)","columns":3,"keepColumns":"nowrap","gridRowHeight":"auto","alignVertical":"stretch","alignHorizontal":"stretch"}},"classNames":"ly ly-gr ly-nowrap ly-gr-m ly-m-col-1","stylesLayout":"\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-col: 3;\u002d\u002dly-valign: stretch;\u002d\u002dly-halign: stretch;\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-m-col: 1;\u002d\u002dly-m-valign: stretch;\u002d\u002dly-m-halign: stretch","mobile":{"layout":{"grid":{"columns":1}}}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"contentPosition":"center"}},"classNames":"ly ly-stk ly-co-pos","styles":"\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center"}} -->
' . wphave_pattern_slot( 'steps.1.step', 'step', array (
  'sequenceId' => $step_sequence_ids['step-sections-2'],
  'attrs' =>
  array (
    'wphave' =>
    array (
      'dimensions' =>
      array (
        'spacing' =>
        array (
          'padding' => 'var(--wphave-site-padding-xxs) var(--wphave-site-padding-xxs) var(--wphave-site-padding-xxs) var(--wphave-site-padding-xxs)',
        ),
        'aspectRatio' =>
        array (
          'ratio' => '1/1',
        ),
      ),
      'background' =>
      array (
        'color' =>
        array (
          'base' => 'var(--wphave-site-color-accent-subtle-10)',
        ),
      ),
      'styles' => '--pa: var(--wphave-site-padding-xxs) var(--wphave-site-padding-xxs) var(--wphave-site-padding-xxs) var(--wphave-site-padding-xxs);--pa-top: var(--wphave-site-padding-xxs);--pa-right: var(--wphave-site-padding-xxs);--pa-bottom: var(--wphave-site-padding-xxs);--pa-left: var(--wphave-site-padding-xxs);--asrt: 1/1;--bg-co: var(--wphave-site-color-accent-subtle-10);--br: 100px 100px 100px 100px;--numberColor: var(--wphave-site-color-accent)',
      'stylesChild' => '--left-spacing-inherit: var(--wphave-site-padding-xxs);--right-spacing-inherit: var(--wphave-site-padding-xxs)',
      'classNames' => 'pa asrt bg-co bg br tf-fs tf-fs-text-3xl',
      'frame' =>
      array (
        'corners' => '100px 100px 100px 100px',
      ),
      'text' =>
      array (
        'typeface' =>
        array (
          'size' =>
          array (
            'type' => 'text-3xl',
          ),
        ),
      ),
      'settings' =>
      array (
        'colors' =>
        array (
          'count' => 'var(--wphave-site-color-accent)',
        ),
        'connector' =>
        array (
          'enabled' => true,
          'color' => 'var(--wphave-site-color-accent-subtle-10)',
          'width' => '2px',
          'style' => 'dashed',
          'dashGap' => 3,
          'shape' => 'straight',
          'curveTension' => 0.75,
          'animation' => 'draw',
          'animationSpeed' => 2,
          'zIndex' => 0,
        ),
        'leadingZero' => false,
      ),
    ),
  ),
), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"skl ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"stackLevel":{"level":2}},"styles":"\u002d\u002dskl: 2"}} -->
' . wphave_pattern_slot( 'steps.1.title', 'heading', array (
  'level' => 'h3',
  'size' => 'title-xxs',
), $slots ) . '

' . wphave_pattern_slot( 'steps.1.text', 'body', array('size' => 'text-s'), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"contentPosition":"center"}},"classNames":"ly ly-stk ly-co-pos","styles":"\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center"}} -->
' . wphave_pattern_slot( 'steps.2.step', 'step', array (
  'sequenceId' => $step_sequence_ids['step-sections-2'],
  'attrs' =>
  array (
    'wphave' =>
    array (
      'dimensions' =>
      array (
        'spacing' =>
        array (
          'padding' => 'var(--wphave-site-padding-xs) var(--wphave-site-padding-xs) var(--wphave-site-padding-xs) var(--wphave-site-padding-xs)',
        ),
        'aspectRatio' =>
        array (
          'ratio' => '1/1',
        ),
      ),
      'background' =>
      array (
        'color' =>
        array (
          'base' => 'var(--wphave-site-color-accent-subtle-10)',
        ),
      ),
      'styles' => '--pa: var(--wphave-site-padding-xs) var(--wphave-site-padding-xs) var(--wphave-site-padding-xs) var(--wphave-site-padding-xs);--pa-top: var(--wphave-site-padding-xs);--pa-right: var(--wphave-site-padding-xs);--pa-bottom: var(--wphave-site-padding-xs);--pa-left: var(--wphave-site-padding-xs);--asrt: 1/1;--bg-co: var(--wphave-site-color-accent-subtle-10);--br: 100px 100px 100px 100px;--numberColor: var(--wphave-site-color-accent)',
      'stylesChild' => '--left-spacing-inherit: var(--wphave-site-padding-xs);--right-spacing-inherit: var(--wphave-site-padding-xs)',
      'classNames' => 'pa asrt bg-co bg br tf-fs tf-fs-text-3xl',
      'frame' =>
      array (
        'corners' => '100px 100px 100px 100px',
      ),
      'text' =>
      array (
        'typeface' =>
        array (
          'size' =>
          array (
            'type' => 'text-3xl',
          ),
        ),
      ),
      'settings' =>
      array (
        'colors' =>
        array (
          'count' => 'var(--wphave-site-color-accent)',
        ),
        'leadingZero' => false,
      ),
    ),
  ),
), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"skl ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"stackLevel":{"level":2}},"styles":"\u002d\u002dskl: 2"}} -->
' . wphave_pattern_slot( 'steps.2.title', 'heading', array (
  'level' => 'h3',
  'size' => 'title-xxs',
), $slots ) . '

' . wphave_pattern_slot( 'steps.2.text', 'body', array('size' => 'text-s'), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"contentPosition":"center"}},"classNames":"ly ly-stk ly-co-pos","styles":"\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center"}} -->
' . wphave_pattern_slot( 'steps.3.step', 'step', array (
  'sequenceId' => $step_sequence_ids['step-sections-2'],
  'attrs' =>
  array (
    'wphave' =>
    array (
      'dimensions' =>
      array (
        'spacing' =>
        array (
          'padding' => 'var(--wphave-site-padding-s) var(--wphave-site-padding-s) var(--wphave-site-padding-s) var(--wphave-site-padding-s)',
        ),
        'aspectRatio' =>
        array (
          'ratio' => '1/1',
        ),
      ),
      'background' =>
      array (
        'color' =>
        array (
          'base' => 'var(--wphave-site-color-accent-subtle-10)',
        ),
      ),
      'styles' => '--pa: var(--wphave-site-padding-s) var(--wphave-site-padding-s) var(--wphave-site-padding-s) var(--wphave-site-padding-s);--pa-top: var(--wphave-site-padding-s);--pa-right: var(--wphave-site-padding-s);--pa-bottom: var(--wphave-site-padding-s);--pa-left: var(--wphave-site-padding-s);--asrt: 1/1;--bg-co: var(--wphave-site-color-accent-subtle-10);--br: 100px 100px 100px 100px;--numberColor: var(--wphave-site-color-accent)',
      'stylesChild' => '--left-spacing-inherit: var(--wphave-site-padding-s);--right-spacing-inherit: var(--wphave-site-padding-s)',
      'classNames' => 'pa asrt bg-co bg br tf-fs tf-fs-text-3xl',
      'frame' =>
      array (
        'corners' => '100px 100px 100px 100px',
      ),
      'text' =>
      array (
        'typeface' =>
        array (
          'size' =>
          array (
            'type' => 'text-3xl',
          ),
        ),
      ),
      'settings' =>
      array (
        'colors' =>
        array (
          'count' => 'var(--wphave-site-color-accent)',
        ),
        'leadingZero' => false,
      ),
    ),
  ),
), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"skl ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"stackLevel":{"level":2}},"styles":"\u002d\u002dskl: 2"}} -->
' . wphave_pattern_slot( 'steps.3.title', 'heading', array (
  'level' => 'h3',
  'size' => 'title-xxs',
), $slots ) . '

' . wphave_pattern_slot( 'steps.3.text', 'body', array('size' => 'text-s'), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"contentPosition":"center","gap":"var(\u002d\u002dwphave-site-gap-size-m)"}},"classNames":"ly ly-stk ly-co-pos","styles":"\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-m)"}} -->
' . wphave_pattern_slot( 'body', 'body', array (
  'size' => 'default',
), $slots ) . '

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"\u002d\u002dwi: fit-content","classNames":"wi ly ly-fl","layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-m)","gapY":"var(\u002d\u002dwphave-site-gap-size-m)","flexWrap":"no-wrap","flexDirection":"row","flexItemSizing":"auto"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-direction: row;\u002d\u002dly-fl-itm: 0 1 auto"}} -->
<!-- wp:wphave/button {"wphave":{"settings":{"size":"0"},"styles":"\u005cu002d\u005cu002dbtn-size-scale: 0"},"content":"Contact"} /-->

<!-- wp:wphave/button {"wphave":{"settings":{"variant":"secondary","size":"0"},"styles":"\u005cu002d\u005cu002dbtn-size-scale: 0"},"content":"See more"} /-->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'step-sections-3',
            'tags' => array('process', 'steps'),
            'title' => __( 'Step Sections Dark Timeline', 'wphave' ),
            'keywords' => array('process', 'steps', 'workflow', 'section', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('process', 'steps'),
                'layout' => array('split', 'list'),
                'content' => array('heading', 'body', 'steps'),
                'intent' => array('process', 'explain-process'),
                'treatment' => array('editorial', 'structured'),
                'description' => 'A split timeline process that alternates step groups around a central editorial heading for richer workflows.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"wi-in pa ofw ly ly-stk ly-co-pos br txta","dimensions":{"overflow":"clip","innerWidth":{"limit":"max","custom":"100%"},"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-xxl) 0 var(\u002d\u002dwphave-site-padding-xxl) 0"}},"styles":"\u002d\u002dwi-in: 100%;\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-xxl) 0 var(\u002d\u002dwphave-site-padding-xxl) 0;\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-right: 0;\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-left: 0;\u002d\u002dofw: clip;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center;\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners);\u002d\u002dtxta: center","layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-l)","contentPosition":"center"}},"stylesChild":"\u002d\u002dleft-spacing-inherit: 0;\u002d\u002dright-spacing-inherit: 0","frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-l)","text":{"align":"center"}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-4xl)","gapY":"var(\u002d\u002dwphave-site-gap-size-4xl)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"evenly","alignVertical":"start","alignHorizontal":"start"}},"classNames":"ly ly-fl ly-fl-m","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 1 1 auto;\u002d\u002dly-valign: start;\u002d\u002dly-halign: start;\u002d\u002dly-fl-direction: row;\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-m-fl-wrap: no-wrap;\u002d\u002dly-m-fl-itm: 1 1 auto;\u002d\u002dly-m-valign: start;\u002d\u002dly-m-halign: start;\u002d\u002dly-m-fl-direction: column","mobile":{"layout":{"grid":{"columns":1},"flex":{"flexDirection":"column"}}}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"contentPosition":"center"}},"classNames":"ly ly-stk ly-co-pos","styles":"\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center"}} -->
' . wphave_pattern_slot( 'steps.1.step', 'step', array (
  'sequenceId' => $step_sequence_ids['step-sections-3'],
  'attrs' =>
  array (
    'wphave' =>
    array (
      'dimensions' =>
      array (
        'spacing' =>
        array (
          'padding' => 'var(--wphave-site-padding-xs) var(--wphave-site-padding-xs) var(--wphave-site-padding-xs) var(--wphave-site-padding-xs)',
        ),
        'aspectRatio' =>
        array (
          'ratio' => '1/1',
        ),
      ),
      'background' =>
      array (
        'color' =>
        array (
          'base' => 'var(--wphave-site-color-background-contrast-10)',
        ),
      ),
      'styles' => '--pa: var(--wphave-site-padding-xs) var(--wphave-site-padding-xs) var(--wphave-site-padding-xs) var(--wphave-site-padding-xs);--pa-top: var(--wphave-site-padding-xs);--pa-right: var(--wphave-site-padding-xs);--pa-bottom: var(--wphave-site-padding-xs);--pa-left: var(--wphave-site-padding-xs);--asrt: 1/1;--bg-co: var(--wphave-site-color-background-contrast-10);--br: 100px 100px 100px 100px;--numberColor: var(--wphave-site-color-background-subtle-10)',
      'stylesChild' => '--left-spacing-inherit: var(--wphave-site-padding-xs);--right-spacing-inherit: var(--wphave-site-padding-xs)',
      'classNames' => 'is-bold pa asrt bg-co bg br tf-fs tf-fs-text-m',
      'frame' =>
      array (
        'corners' => '100px 100px 100px 100px',
      ),
      'settings' =>
      array (
        'connector' =>
        array (
          'enabled' => true,
          'width' => '2px',
          'style' => 'dashed',
          'dashGap' => 3,
          'shape' => 'straight',
          'curveTension' => 0.75,
          'animation' => 'none',
          'animationSpeed' => 2,
          'zIndex' => 0,
        ),
        'colors' =>
        array (
          'count' => 'var(--wphave-site-color-background-subtle-10)',
        ),
        'formats' =>
        array (
          0 => 'bold',
        ),
        'leadingZero' => false,
      ),
      'text' =>
      array (
        'typeface' =>
        array (
          'size' =>
          array (
            'type' => 'text-m',
          ),
        ),
      ),
    ),
  ),
), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"skl ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"stackLevel":{"level":2}},"styles":"\u002d\u002dskl: 2"}} -->
' . wphave_pattern_slot( 'heading', 'heading', array (
  'size' => 'title-xxs',
), $slots ) . '

' . wphave_pattern_slot( 'steps.1.text', 'body', array('size' => 'text-s'), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"contentPosition":"center"}},"classNames":"ly ly-stk ly-co-pos","styles":"\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center"}} -->
' . wphave_pattern_slot( 'steps.2.step', 'step', array (
  'sequenceId' => $step_sequence_ids['step-sections-3'],
  'attrs' =>
  array (
    'wphave' =>
    array (
      'dimensions' =>
      array (
        'spacing' =>
        array (
          'padding' => 'var(--wphave-site-padding-xs) var(--wphave-site-padding-xs) var(--wphave-site-padding-xs) var(--wphave-site-padding-xs)',
        ),
        'aspectRatio' =>
        array (
          'ratio' => '1/1',
        ),
      ),
      'background' =>
      array (
        'color' =>
        array (
          'base' => 'var(--wphave-site-color-background-contrast-10)',
        ),
      ),
      'styles' => '--pa: var(--wphave-site-padding-xs) var(--wphave-site-padding-xs) var(--wphave-site-padding-xs) var(--wphave-site-padding-xs);--pa-top: var(--wphave-site-padding-xs);--pa-right: var(--wphave-site-padding-xs);--pa-bottom: var(--wphave-site-padding-xs);--pa-left: var(--wphave-site-padding-xs);--asrt: 1/1;--bg-co: var(--wphave-site-color-background-contrast-10);--br: 100px 100px 100px 100px;--numberColor: var(--wphave-site-color-background-subtle-10)',
      'stylesChild' => '--left-spacing-inherit: var(--wphave-site-padding-xs);--right-spacing-inherit: var(--wphave-site-padding-xs)',
      'classNames' => 'is-bold pa asrt bg-co bg br tf-fs tf-fs-text-m',
      'frame' =>
      array (
        'corners' => '100px 100px 100px 100px',
      ),
      'settings' =>
      array (
        'colors' =>
        array (
          'count' => 'var(--wphave-site-color-background-subtle-10)',
        ),
        'formats' =>
        array (
          0 => 'bold',
        ),
        'leadingZero' => false,
      ),
      'text' =>
      array (
        'typeface' =>
        array (
          'size' =>
          array (
            'type' => 'text-m',
          ),
        ),
      ),
    ),
  ),
), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"skl ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"stackLevel":{"level":2}},"styles":"\u002d\u002dskl: 2"}} -->
' . wphave_pattern_slot( 'steps.1.title', 'heading', array (
  'level' => 'h3',
  'size' => 'title-xxs',
), $slots ) . '

' . wphave_pattern_slot( 'steps.2.text', 'body', array('size' => 'text-s'), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"contentPosition":"center"}},"classNames":"ly ly-stk ly-co-pos","styles":"\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center"}} -->
' . wphave_pattern_slot( 'steps.3.step', 'step', array (
  'sequenceId' => $step_sequence_ids['step-sections-3'],
  'attrs' =>
  array (
    'wphave' =>
    array (
      'dimensions' =>
      array (
        'spacing' =>
        array (
          'padding' => 'var(--wphave-site-padding-xs) var(--wphave-site-padding-xs) var(--wphave-site-padding-xs) var(--wphave-site-padding-xs)',
        ),
        'aspectRatio' =>
        array (
          'ratio' => '1/1',
        ),
      ),
      'background' =>
      array (
        'color' =>
        array (
          'base' => 'var(--wphave-site-color-background-contrast-10)',
        ),
      ),
      'styles' => '--pa: var(--wphave-site-padding-xs) var(--wphave-site-padding-xs) var(--wphave-site-padding-xs) var(--wphave-site-padding-xs);--pa-top: var(--wphave-site-padding-xs);--pa-right: var(--wphave-site-padding-xs);--pa-bottom: var(--wphave-site-padding-xs);--pa-left: var(--wphave-site-padding-xs);--asrt: 1/1;--bg-co: var(--wphave-site-color-background-contrast-10);--br: 100px 100px 100px 100px;--numberColor: var(--wphave-site-color-background-subtle-10)',
      'stylesChild' => '--left-spacing-inherit: var(--wphave-site-padding-xs);--right-spacing-inherit: var(--wphave-site-padding-xs)',
      'classNames' => 'is-bold pa asrt bg-co bg br tf-fs tf-fs-text-m',
      'frame' =>
      array (
        'corners' => '100px 100px 100px 100px',
      ),
      'settings' =>
      array (
        'colors' =>
        array (
          'count' => 'var(--wphave-site-color-background-subtle-10)',
        ),
        'formats' =>
        array (
          0 => 'bold',
        ),
        'leadingZero' => false,
      ),
      'text' =>
      array (
        'typeface' =>
        array (
          'size' =>
          array (
            'type' => 'text-m',
          ),
        ),
      ),
    ),
  ),
), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"skl ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"stackLevel":{"level":2}},"styles":"\u002d\u002dskl: 2"}} -->
' . wphave_pattern_slot( 'steps.2.title', 'heading', array (
  'level' => 'h3',
  'size' => 'title-xxs',
), $slots ) . '

' . wphave_pattern_slot( 'steps.3.text', 'body', array('size' => 'text-s'), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/spacer {"wphave":{"settings":{"aspectRatio":"75/1"},"styles":"\u002d\u002daspect-ratio: 75/1"}} /-->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-m)"}},"classNames":"wi ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-m)","dimensions":{"width":{"limit":"max","custom":"999px"}},"styles":"\u002d\u002dwi: 999px"}} -->
' . wphave_pattern_slot( 'heading', 'heading', array (
  'size' => 'title-m',
), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/spacer {"wphave":{"settings":{"aspectRatio":"75/1"},"styles":"\u002d\u002daspect-ratio: 75/1"}} /-->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-gap-size-4xl)","gapY":"var(\u002d\u002dwphave-site-gap-size-4xl)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row-reverse","flexItemSizing":"evenly","alignVertical":"start","alignHorizontal":"start"}},"classNames":"ly ly-fl ly-fl-m","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 1 1 auto;\u002d\u002dly-valign: start;\u002d\u002dly-halign: start;\u002d\u002dly-fl-direction: row-reverse;\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-m-fl-wrap: no-wrap;\u002d\u002dly-m-fl-itm: 1 1 auto;\u002d\u002dly-m-valign: start;\u002d\u002dly-m-halign: start;\u002d\u002dly-m-fl-direction: column","mobile":{"layout":{"grid":{"columns":1},"flex":{"flexDirection":"column"}}}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"contentPosition":"center"}},"classNames":"ly ly-stk ly-co-pos","styles":"\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center"}} -->
' . wphave_pattern_slot( 'steps.4.step', 'step', array (
  'sequenceId' => $step_sequence_ids['step-sections-3'],
  'attrs' =>
  array (
    'wphave' =>
    array (
      'dimensions' =>
      array (
        'spacing' =>
        array (
          'padding' => 'var(--wphave-site-padding-xs) var(--wphave-site-padding-xs) var(--wphave-site-padding-xs) var(--wphave-site-padding-xs)',
        ),
        'aspectRatio' =>
        array (
          'ratio' => '1/1',
        ),
      ),
      'background' =>
      array (
        'color' =>
        array (
          'base' => 'var(--wphave-site-color-background-contrast-10)',
        ),
      ),
      'styles' => '--pa: var(--wphave-site-padding-xs) var(--wphave-site-padding-xs) var(--wphave-site-padding-xs) var(--wphave-site-padding-xs);--pa-top: var(--wphave-site-padding-xs);--pa-right: var(--wphave-site-padding-xs);--pa-bottom: var(--wphave-site-padding-xs);--pa-left: var(--wphave-site-padding-xs);--asrt: 1/1;--bg-co: var(--wphave-site-color-background-contrast-10);--br: 100px 100px 100px 100px;--numberColor: var(--wphave-site-color-background-subtle-10)',
      'stylesChild' => '--left-spacing-inherit: var(--wphave-site-padding-xs);--right-spacing-inherit: var(--wphave-site-padding-xs)',
      'classNames' => 'is-bold pa asrt bg-co bg br tf-fs tf-fs-text-m',
      'frame' =>
      array (
        'corners' => '100px 100px 100px 100px',
      ),
      'settings' =>
      array (
        'colors' =>
        array (
          'count' => 'var(--wphave-site-color-background-subtle-10)',
        ),
        'formats' =>
        array (
          0 => 'bold',
        ),
        'leadingZero' => false,
      ),
      'text' =>
      array (
        'typeface' =>
        array (
          'size' =>
          array (
            'type' => 'text-m',
          ),
        ),
      ),
    ),
  ),
), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"skl ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"stackLevel":{"level":2}},"styles":"\u002d\u002dskl: 2"}} -->
' . wphave_pattern_slot( 'steps.3.title', 'heading', array (
  'level' => 'h3',
  'size' => 'title-xxs',
), $slots ) . '

' . wphave_pattern_slot( 'steps.4.text', 'body', array('size' => 'text-s'), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"contentPosition":"center"}},"classNames":"ly ly-stk ly-co-pos","styles":"\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center"}} -->
' . wphave_pattern_slot( 'steps.5.step', 'step', array (
  'sequenceId' => $step_sequence_ids['step-sections-3'],
  'attrs' =>
  array (
    'wphave' =>
    array (
      'dimensions' =>
      array (
        'spacing' =>
        array (
          'padding' => 'var(--wphave-site-padding-xs) var(--wphave-site-padding-xs) var(--wphave-site-padding-xs) var(--wphave-site-padding-xs)',
        ),
        'aspectRatio' =>
        array (
          'ratio' => '1/1',
        ),
      ),
      'background' =>
      array (
        'color' =>
        array (
          'base' => 'var(--wphave-site-color-background-contrast-10)',
        ),
      ),
      'styles' => '--pa: var(--wphave-site-padding-xs) var(--wphave-site-padding-xs) var(--wphave-site-padding-xs) var(--wphave-site-padding-xs);--pa-top: var(--wphave-site-padding-xs);--pa-right: var(--wphave-site-padding-xs);--pa-bottom: var(--wphave-site-padding-xs);--pa-left: var(--wphave-site-padding-xs);--asrt: 1/1;--bg-co: var(--wphave-site-color-background-contrast-10);--br: 100px 100px 100px 100px;--numberColor: var(--wphave-site-color-background-subtle-10)',
      'stylesChild' => '--left-spacing-inherit: var(--wphave-site-padding-xs);--right-spacing-inherit: var(--wphave-site-padding-xs)',
      'classNames' => 'is-bold pa asrt bg-co bg br tf-fs tf-fs-text-m',
      'frame' =>
      array (
        'corners' => '100px 100px 100px 100px',
      ),
      'settings' =>
      array (
        'colors' =>
        array (
          'count' => 'var(--wphave-site-color-background-subtle-10)',
        ),
        'formats' =>
        array (
          0 => 'bold',
        ),
        'leadingZero' => false,
      ),
      'text' =>
      array (
        'typeface' =>
        array (
          'size' =>
          array (
            'type' => 'text-m',
          ),
        ),
      ),
    ),
  ),
), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"skl ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"stackLevel":{"level":2}},"styles":"\u002d\u002dskl: 2"}} -->
' . wphave_pattern_slot( 'steps.4.title', 'heading', array (
  'level' => 'h3',
  'size' => 'title-xxs',
), $slots ) . '

' . wphave_pattern_slot( 'steps.5.text', 'body', array('size' => 'text-s'), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"contentPosition":"center"}},"classNames":"ly ly-stk ly-co-pos","styles":"\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center"}} -->
' . wphave_pattern_slot( 'steps.6.step', 'step', array (
  'sequenceId' => $step_sequence_ids['step-sections-3'],
  'attrs' =>
  array (
    'wphave' =>
    array (
      'dimensions' =>
      array (
        'spacing' =>
        array (
          'padding' => 'var(--wphave-site-padding-xs) var(--wphave-site-padding-xs) var(--wphave-site-padding-xs) var(--wphave-site-padding-xs)',
        ),
        'aspectRatio' =>
        array (
          'ratio' => '1/1',
        ),
      ),
      'background' =>
      array (
        'color' =>
        array (
          'base' => 'var(--wphave-site-color-background-contrast-10)',
        ),
      ),
      'styles' => '--pa: var(--wphave-site-padding-xs) var(--wphave-site-padding-xs) var(--wphave-site-padding-xs) var(--wphave-site-padding-xs);--pa-top: var(--wphave-site-padding-xs);--pa-right: var(--wphave-site-padding-xs);--pa-bottom: var(--wphave-site-padding-xs);--pa-left: var(--wphave-site-padding-xs);--asrt: 1/1;--bg-co: var(--wphave-site-color-background-contrast-10);--br: 100px 100px 100px 100px;--numberColor: var(--wphave-site-color-background-subtle-10)',
      'stylesChild' => '--left-spacing-inherit: var(--wphave-site-padding-xs);--right-spacing-inherit: var(--wphave-site-padding-xs)',
      'classNames' => 'is-bold pa asrt bg-co bg br tf-fs tf-fs-text-m',
      'frame' =>
      array (
        'corners' => '100px 100px 100px 100px',
      ),
      'settings' =>
      array (
        'colors' =>
        array (
          'count' => 'var(--wphave-site-color-background-subtle-10)',
        ),
        'formats' =>
        array (
          0 => 'bold',
        ),
        'leadingZero' => false,
      ),
      'text' =>
      array (
        'typeface' =>
        array (
          'size' =>
          array (
            'type' => 'text-m',
          ),
        ),
      ),
    ),
  ),
), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"skl ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"stackLevel":{"level":2}},"styles":"\u002d\u002dskl: 2"}} -->
' . wphave_pattern_slot( 'steps.5.title', 'heading', array (
  'level' => 'h3',
  'size' => 'title-xxs',
), $slots ) . '

' . wphave_pattern_slot( 'steps.6.text', 'body', array('size' => 'text-s'), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'step-sections-4',
            'tags' => array('process', 'steps'),
            'title' => __( 'Step Sections Minimal Columns', 'wphave' ),
            'keywords' => array('process', 'steps', 'workflow', 'section', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('process', 'steps'),
                'layout' => array('columns'),
                'content' => array('heading', 'body', 'steps'),
                'intent' => array('process', 'explain-process'),
                'treatment' => array('minimal', 'structured'),
                'description' => 'A clean three column process section with large numbers and short explanatory copy.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"wi-in pa ofw ly ly-stk txta","dimensions":{"overflow":"clip","innerWidth":{"limit":"max","custom":"100%"},"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-xxl) 0 var(\u002d\u002dwphave-site-padding-xxl) 0"}},"styles":"\u002d\u002dwi-in: 100%;\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-xxl) 0 var(\u002d\u002dwphave-site-padding-xxl) 0;\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-right: 0;\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-left: 0;\u002d\u002dofw: clip;\u002d\u002dtxta: none","layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-3xl)"}},"stylesChild":"\u002d\u002dleft-spacing-inherit: 0;\u002d\u002dright-spacing-inherit: 0","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-3xl)","text":{"align":"none"}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-m)"}},"classNames":"wi ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-m)","dimensions":{"width":{"limit":"max","custom":"999px"}},"styles":"\u002d\u002dwi: 999px"}} -->
' . wphave_pattern_slot( 'heading', 'heading', array (
  'size' => 'title-m',
), $slots ) . '

' . wphave_pattern_slot( 'body', 'body', array (
  'size' => 'default',
), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"grid","grid":{"gapX":"var(\u002d\u002dwphave-site-gap-size-3xl)","gapY":"var(\u002d\u002dwphave-site-gap-size-3xl)","columns":3,"keepColumns":"nowrap","gridRowHeight":"auto","alignVertical":"stretch","alignHorizontal":"stretch"}},"classNames":"ly ly-gr ly-nowrap ly-gr-m ly-m-col-1","stylesLayout":"\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-col: 3;\u002d\u002dly-valign: stretch;\u002d\u002dly-halign: stretch;\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-m-col: 1;\u002d\u002dly-m-valign: stretch;\u002d\u002dly-m-halign: stretch","mobile":{"layout":{"grid":{"columns":1}}}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked"},"classNames":"ly ly-stk"}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'steps.1.step', 'step', array (
  'sequenceId' => $step_sequence_ids['step-sections-4'],
  'attrs' =>
  array (
    'wphave' =>
    array (
      'text' =>
      array (
        'typeface' =>
        array (
          'size' =>
          array (
            'type' => 'text-3xl',
          ),
        ),
      ),
      'classNames' => 'is-bold tf-fs tf-fs-text-3xl',
      'settings' =>
      array (
        'formats' =>
        array (
          0 => 'bold',
        ),
        'colors' =>
        array (
          'count' => 'var(--wphave-site-color-background-contrast-6)',
        ),
        'leadingZero' => true,
        'connector' =>
        array (
          'enabled' => false,
          'color' => 'var(--wphave-site-color-background-contrast-3)',
          'width' => '6px',
          'style' => 'dotted',
          'dashGap' => 1,
          'shape' => 'curved',
          'curveTension' => 0.75,
          'animation' => 'none',
          'animationSpeed' => 2,
          'zIndex' => 1,
        ),
      ),
      'styles' => '--numberColor: var(--wphave-site-color-background-contrast-6)',
    ),
  ),
), $slots ) . '

' . wphave_pattern_slot( 'steps.1.title', 'heading', array (
  'level' => 'h3',
  'size' => 'title-xxs',
), $slots ) . '

' . wphave_pattern_slot( 'steps.1.text', 'body', array('size' => 'text-s'), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked"},"classNames":"ly ly-stk"}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'steps.2.step', 'step', array (
  'sequenceId' => $step_sequence_ids['step-sections-4'],
  'attrs' =>
  array (
    'wphave' =>
    array (
      'text' =>
      array (
        'typeface' =>
        array (
          'size' =>
          array (
            'type' => 'text-3xl',
          ),
        ),
      ),
      'classNames' => 'is-bold tf-fs tf-fs-text-3xl',
      'settings' =>
      array (
        'formats' =>
        array (
          0 => 'bold',
        ),
        'colors' =>
        array (
          'count' => 'var(--wphave-site-color-background-contrast-6)',
        ),
        'leadingZero' => true,
      ),
      'styles' => '--numberColor: var(--wphave-site-color-background-contrast-6)',
    ),
  ),
), $slots ) . '

' . wphave_pattern_slot( 'steps.2.title', 'heading', array (
  'level' => 'h3',
  'size' => 'title-xxs',
), $slots ) . '

' . wphave_pattern_slot( 'steps.2.text', 'body', array('size' => 'text-s'), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked"},"classNames":"ly ly-stk"}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'steps.3.step', 'step', array (
  'sequenceId' => $step_sequence_ids['step-sections-4'],
  'attrs' =>
  array (
    'wphave' =>
    array (
      'text' =>
      array (
        'typeface' =>
        array (
          'size' =>
          array (
            'type' => 'text-3xl',
          ),
        ),
      ),
      'classNames' => 'is-bold tf-fs tf-fs-text-3xl',
      'settings' =>
      array (
        'formats' =>
        array (
          0 => 'bold',
        ),
        'colors' =>
        array (
          'count' => 'var(--wphave-site-color-background-contrast-6)',
        ),
        'leadingZero' => true,
      ),
      'styles' => '--numberColor: var(--wphave-site-color-background-contrast-6)',
    ),
  ),
), $slots ) . '

' . wphave_pattern_slot( 'steps.3.title', 'heading', array (
  'level' => 'h3',
  'size' => 'title-xxs',
), $slots ) . '

' . wphave_pattern_slot( 'steps.3.text', 'body', array('size' => 'text-s'), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'step-sections-5',
            'tags' => array('process', 'steps'),
            'title' => __( 'Step Sections Card Grid', 'wphave' ),
            'keywords' => array('process', 'steps', 'workflow', 'section', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('process', 'steps'),
                'layout' => array('grid'),
                'content' => array('heading', 'body', 'steps'),
                'intent' => array('process', 'explain-process'),
                'treatment' => array('framed', 'structured'),
                'description' => 'A card based process grid with oversized step numbers and contained copy for practical workflows.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"wi-in pa ofw ly ly-stk txta","dimensions":{"overflow":"clip","innerWidth":{"limit":"max","custom":"100%"},"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-xxl) 0 var(\u002d\u002dwphave-site-padding-xxl) 0"}},"styles":"\u002d\u002dwi-in: 100%;\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-xxl) 0 var(\u002d\u002dwphave-site-padding-xxl) 0;\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-right: 0;\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-xxl);\u002d\u002dpa-left: 0;\u002d\u002dofw: clip;\u002d\u002dtxta: none","layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-3xl)"}},"stylesChild":"\u002d\u002dleft-spacing-inherit: 0;\u002d\u002dright-spacing-inherit: 0","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-3xl)","text":{"align":"none"}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-m)"}},"classNames":"wi ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-m)","dimensions":{"width":{"limit":"max","custom":"999px"}},"styles":"\u002d\u002dwi: 999px"}} -->
' . wphave_pattern_slot( 'heading', 'heading', array (
  'size' => 'title-m',
), $slots ) . '

' . wphave_pattern_slot( 'body', 'body', array (
  'size' => 'default',
), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"grid","grid":{"gapX":"var(\u002d\u002dwphave-site-gap-size-3xl)","gapY":"var(\u002d\u002dwphave-site-gap-size-3xl)","columns":3,"keepColumns":"nowrap","gridRowHeight":"auto","alignVertical":"stretch","alignHorizontal":"stretch"}},"classNames":"ly ly-gr ly-nowrap ly-gr-m ly-m-col-1","stylesLayout":"\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-col: 3;\u002d\u002dly-valign: stretch;\u002d\u002dly-halign: stretch;\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-gap-size-3xl);\u002d\u002dly-m-col: 1;\u002d\u002dly-m-valign: stretch;\u002d\u002dly-m-halign: stretch","mobile":{"layout":{"grid":{"columns":1}}}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked"},"classNames":"ly ly-stk"}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"pa ofw ly ly-stk bg-co bg br","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m)"},"overflow":"clip"},"background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background-contrast-1)"}},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background-contrast-1);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-m)","frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"}}} -->
' . wphave_pattern_slot( 'steps.1.step', 'step', array (
  'sequenceId' => $step_sequence_ids['step-sections-5'],
  'attrs' =>
  array (
    'wphave' =>
    array (
      'text' =>
      array (
        'typeface' =>
        array (
          'size' =>
          array (
            'type' => 'text-3xl',
          ),
        ),
      ),
      'classNames' => 'is-bold tf-fs tf-fs-text-3xl',
      'settings' =>
      array (
        'formats' =>
        array (
          0 => 'bold',
        ),
        'colors' =>
        array (
          'count' => 'var(--wphave-site-color-background-contrast-6)',
        ),
        'leadingZero' => true,
      ),
      'styles' => '--numberColor: var(--wphave-site-color-background-contrast-6)',
    ),
  ),
), $slots ) . '

' . wphave_pattern_slot( 'steps.1.title', 'heading', array (
  'level' => 'h3',
  'size' => 'title-xxs',
), $slots ) . '

' . wphave_pattern_slot( 'steps.1.text', 'body', array('size' => 'text-s'), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"pa ofw ly ly-stk bg-co bg br","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m)"},"overflow":"clip"},"background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background-contrast-1)"}},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background-contrast-1);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-m)","frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'steps.2.step', 'step', array (
  'sequenceId' => $step_sequence_ids['step-sections-5'],
  'attrs' =>
  array (
    'wphave' =>
    array (
      'text' =>
      array (
        'typeface' =>
        array (
          'size' =>
          array (
            'type' => 'text-3xl',
          ),
        ),
      ),
      'classNames' => 'is-bold tf-fs tf-fs-text-3xl',
      'settings' =>
      array (
        'formats' =>
        array (
          0 => 'bold',
        ),
        'colors' =>
        array (
          'count' => 'var(--wphave-site-color-background-contrast-6)',
        ),
        'leadingZero' => true,
      ),
      'styles' => '--numberColor: var(--wphave-site-color-background-contrast-6)',
    ),
  ),
), $slots ) . '

' . wphave_pattern_slot( 'steps.2.title', 'heading', array (
  'level' => 'h3',
  'size' => 'title-xxs',
), $slots ) . '

' . wphave_pattern_slot( 'steps.2.text', 'body', array('size' => 'text-s'), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"pa ofw ly ly-stk bg-co bg br","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m)"},"overflow":"clip"},"background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background-contrast-1)"}},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m) var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background-contrast-1);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)","stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-m);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-m)","frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'steps.3.step', 'step', array (
  'sequenceId' => $step_sequence_ids['step-sections-5'],
  'attrs' =>
  array (
    'wphave' =>
    array (
      'text' =>
      array (
        'typeface' =>
        array (
          'size' =>
          array (
            'type' => 'text-3xl',
          ),
        ),
      ),
      'classNames' => 'is-bold tf-fs tf-fs-text-3xl',
      'settings' =>
      array (
        'formats' =>
        array (
          0 => 'bold',
        ),
        'colors' =>
        array (
          'count' => 'var(--wphave-site-color-background-contrast-6)',
        ),
        'leadingZero' => true,
      ),
      'styles' => '--numberColor: var(--wphave-site-color-background-contrast-6)',
    ),
  ),
), $slots ) . '

' . wphave_pattern_slot( 'steps.3.title', 'heading', array (
  'level' => 'h3',
  'size' => 'title-xxs',
), $slots ) . '

' . wphave_pattern_slot( 'steps.3.text', 'body', array('size' => 'text-s'), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'step-sections-6',
            'tags' => array('process', 'steps'),
            'title' => __( 'Step Sections Media Split', 'wphave' ),
            'keywords' => array('process', 'steps', 'workflow', 'section', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('process', 'steps'),
                'layout' => array('split', 'text-media'),
                'visual' => array('image'),
                'content' => array('heading', 'body', 'steps', 'media'),
                'intent' => array('process', 'explain-process'),
                'treatment' => array('unframed', 'structured'),
                'description' => 'A process section with a split content column and supporting image for service, onboarding, or planning flows.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"layout":{"type":"grid","grid":{"gapX":"var(\u002d\u002dwphave-site-gap-size-4xl)","gapY":"var(\u002d\u002dwphave-site-gap-size-4xl)","columns":2,"keepColumns":"auto","gridRowHeight":"auto","alignVertical":"center","alignHorizontal":"stretch"}},"classNames":"pa ly ly-gr ly-col-2","stylesLayout":"\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-col: 2;\u002d\u002dly-valign: center;\u002d\u002dly-halign: stretch","dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-3xl) 0 var(\u002d\u002dwphave-site-padding-3xl) 0"}},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-3xl) 0 var(\u002d\u002dwphave-site-padding-3xl) 0;\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-3xl);\u002d\u002dpa-right: 0;\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-3xl);\u002d\u002dpa-left: 0","stylesChild":"\u002d\u002dleft-spacing-inherit: 0;\u002d\u002dright-spacing-inherit: 0"}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"wi-in ofw ly ly-stk ly-co-pos txta","dimensions":{"overflow":"clip","innerWidth":{"limit":"max","custom":"100%"}},"styles":"\u002d\u002dwi-in: 100%;\u002d\u002dofw: clip;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center;\u002d\u002dtxta: none","layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-4xl)","contentPosition":"center"}},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-4xl)","text":{"align":"none"}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-m)"}},"classNames":"wi ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-m)","dimensions":{"width":{"limit":"max","custom":"999px"}},"styles":"\u002d\u002dwi: 999px"}} -->
' . wphave_pattern_slot( 'heading', 'heading', array (
  'size' => 'title-m',
), $slots ) . '

' . wphave_pattern_slot( 'body', 'body', array (
  'size' => 'default',
), $slots ) . '
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked"},"classNames":"ly ly-stk","mobile":{"layout":{"grid":{"columns":1}}}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"start","alignHorizontal":"space-between"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: start;\u002d\u002dly-halign: space-between;\u002d\u002dly-fl-direction: row"}} -->
' . wphave_pattern_slot( 'steps.1.step', 'step', array (
  'sequenceId' => $step_sequence_ids['step-sections-6'],
  'attrs' =>
  array (
    'wphave' =>
    array (
      'dimensions' =>
      array (
        'aspectRatio' =>
        array (
          'ratio' => '1/1',
        ),
        'width' =>
        array (
          'limit' => 'max',
          'custom' => '48px',
        ),
      ),
      'background' =>
      array (
        'color' =>
        array (
          'base' => 'var(--wphave-site-color-background-contrast-10)',
        ),
      ),
      'styles' => '--wi: 48px;--asrt: 1/1;--bg-co: var(--wphave-site-color-background-contrast-10);--br: var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners);--numberColor: var(--wphave-site-color-background-subtle-10)',
      'classNames' => 'wi asrt bg-co bg br',
      'frame' =>
      array (
        'corners' => 'var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners)',
      ),
      'settings' =>
      array (
        'colors' =>
        array (
          'count' => 'var(--wphave-site-color-background-subtle-10)',
        ),
        'leadingZero' => false,
      ),
    ),
  ),
), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'steps.1.title', 'heading', array (
  'level' => 'h3',
  'size' => 'title-xxs',
), $slots ) . '

' . wphave_pattern_slot( 'steps.1.text', 'body', array('size' => 'text-s'), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"start","alignHorizontal":"space-between"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: start;\u002d\u002dly-halign: space-between;\u002d\u002dly-fl-direction: row"}} -->
' . wphave_pattern_slot( 'steps.2.step', 'step', array (
  'sequenceId' => $step_sequence_ids['step-sections-6'],
  'attrs' =>
  array (
    'wphave' =>
    array (
      'dimensions' =>
      array (
        'aspectRatio' =>
        array (
          'ratio' => '1/1',
        ),
        'width' =>
        array (
          'limit' => 'max',
          'custom' => '48px',
        ),
      ),
      'background' =>
      array (
        'color' =>
        array (
          'base' => 'var(--wphave-site-color-background-contrast-10)',
        ),
      ),
      'styles' => '--wi: 48px;--asrt: 1/1;--bg-co: var(--wphave-site-color-background-contrast-10);--br: var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners);--numberColor: var(--wphave-site-color-background-subtle-10)',
      'classNames' => 'wi asrt bg-co bg br',
      'frame' =>
      array (
        'corners' => 'var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners)',
      ),
      'settings' =>
      array (
        'colors' =>
        array (
          'count' => 'var(--wphave-site-color-background-subtle-10)',
        ),
        'leadingZero' => false,
      ),
    ),
  ),
), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'steps.2.title', 'heading', array (
  'level' => 'h3',
  'size' => 'title-xxs',
), $slots ) . '

' . wphave_pattern_slot( 'steps.2.text', 'body', array('size' => 'text-s'), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"start","alignHorizontal":"space-between"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: start;\u002d\u002dly-halign: space-between;\u002d\u002dly-fl-direction: row"}} -->
' . wphave_pattern_slot( 'steps.3.step', 'step', array (
  'sequenceId' => $step_sequence_ids['step-sections-6'],
  'attrs' =>
  array (
    'wphave' =>
    array (
      'dimensions' =>
      array (
        'aspectRatio' =>
        array (
          'ratio' => '1/1',
        ),
        'width' =>
        array (
          'limit' => 'max',
          'custom' => '48px',
        ),
      ),
      'background' =>
      array (
        'color' =>
        array (
          'base' => 'var(--wphave-site-color-background-contrast-10)',
        ),
      ),
      'styles' => '--wi: 48px;--asrt: 1/1;--bg-co: var(--wphave-site-color-background-contrast-10);--br: var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners);--numberColor: var(--wphave-site-color-background-subtle-10)',
      'classNames' => 'wi asrt bg-co bg br',
      'frame' =>
      array (
        'corners' => 'var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners)',
      ),
      'settings' =>
      array (
        'colors' =>
        array (
          'count' => 'var(--wphave-site-color-background-subtle-10)',
        ),
        'leadingZero' => false,
      ),
    ),
  ),
), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'steps.3.title', 'heading', array (
  'level' => 'h3',
  'size' => 'title-xxs',
), $slots ) . '

' . wphave_pattern_slot( 'steps.3.text', 'body', array('size' => 'text-s'), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

' . wphave_pattern_slot( 'image', 'image', array('attrs' => array (
  'wphave' =>
  array (
    'dimensions' =>
    array (
      'overflow' => 'clip',
    ),
    'frame' =>
    array (
      'corners' => 'var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners)',
    ),
    'styles' => '--ofw: clip;--br: var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners);--object-position: center',
    'classNames' => 'ofw br',
  ),
)), $slots ) . '
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'step-sections-7',
            'tags' => array('process', 'steps'),
            'title' => __( 'Step Sections Editorial List', 'wphave' ),
            'keywords' => array('process', 'steps', 'workflow', 'section', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('process', 'steps'),
                'layout' => array('split', 'list'),
                'content' => array('heading', 'body', 'steps'),
                'intent' => array('process', 'explain-process'),
                'treatment' => array('editorial', 'minimal'),
                'description' => 'An editorial two column process list with compact numbered rows beside a large heading block.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"layout":{"type":"grid","grid":{"gapX":"var(\u002d\u002dwphave-site-gap-size-4xl)","gapY":"var(\u002d\u002dwphave-site-gap-size-4xl)","columns":2,"keepColumns":"auto","gridRowHeight":"auto","alignVertical":"center","alignHorizontal":"stretch"}},"classNames":"pa ly ly-gr ly-col-2","stylesLayout":"\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-col: 2;\u002d\u002dly-valign: center;\u002d\u002dly-halign: stretch","dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-3xl) 0 var(\u002d\u002dwphave-site-padding-3xl) 0"}},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-3xl) 0 var(\u002d\u002dwphave-site-padding-3xl) 0;\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-3xl);\u002d\u002dpa-right: 0;\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-3xl);\u002d\u002dpa-left: 0","stylesChild":"\u002d\u002dleft-spacing-inherit: 0;\u002d\u002dright-spacing-inherit: 0"}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"wi-in ofw ly ly-stk ly-co-pos txta","dimensions":{"overflow":"clip","innerWidth":{"limit":"max","custom":"100%"}},"styles":"\u002d\u002dwi-in: 100%;\u002d\u002dofw: clip;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center;\u002d\u002dtxta: none","layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-4xl)","contentPosition":"center"}},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-4xl)","text":{"align":"none"}}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-m)"}},"classNames":"wi ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-m)","dimensions":{"width":{"limit":"max","custom":"999px"}},"styles":"\u002d\u002dwi: 999px"}} -->
' . wphave_pattern_slot( 'heading', 'heading', array (
  'size' => 'title-l',
), $slots ) . '

' . wphave_pattern_slot( 'body', 'body', array (
  'size' => 'default',
), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-xl)"}},"classNames":"ly ly-stk","mobile":{"layout":{"grid":{"columns":1}}},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-xl);\u002d\u002dly-m-gap: var(\u002d\u002dwphave-site-gap-size-xl)"}} -->
<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"start","alignHorizontal":"space-between"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: start;\u002d\u002dly-halign: space-between;\u002d\u002dly-fl-direction: row"}} -->
' . wphave_pattern_slot( 'steps.1.step', 'step', array (
  'sequenceId' => $step_sequence_ids['step-sections-7'],
  'attrs' =>
  array (
    'wphave' =>
    array (
      'classNames' => 'wi pa asrt bg-co bg br',
      'dimensions' =>
      array (
        'width' =>
        array (
          'limit' => 'max',
          'custom' => '53px',
        ),
        'aspectRatio' =>
        array (
          'ratio' => '1/1',
        ),
        'spacing' =>
        array (
          'padding' => '0.5rem 0.5rem 0.5rem 0.5rem',
        ),
      ),
      'styles' => '--wi: 53px;--pa: 0.5rem 0.5rem 0.5rem 0.5rem;--pa-top: 0.5rem;--pa-right: 0.5rem;--pa-bottom: 0.5rem;--pa-left: 0.5rem;--asrt: 1/1;--bg-co: var(--wphave-site-color-background-contrast-2);--br: 100px 100px 100px 100px',
      'background' =>
      array (
        'color' =>
        array (
          'base' => 'var(--wphave-site-color-background-contrast-2)',
        ),
      ),
      'stylesChild' => '--left-spacing-inherit: 0.5rem;--right-spacing-inherit: 0.5rem',
      'frame' =>
      array (
        'corners' => '100px 100px 100px 100px',
      ),
      'settings' =>
      array (
        'leadingZero' => false,
      ),
    ),
  ),
), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'steps.1.title', 'heading', array (
  'level' => 'h3',
  'size' => 'title-xxs',
), $slots ) . '

' . wphave_pattern_slot( 'steps.1.text', 'body', array('size' => 'text-s'), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"start","alignHorizontal":"space-between"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: start;\u002d\u002dly-halign: space-between;\u002d\u002dly-fl-direction: row"}} -->
' . wphave_pattern_slot( 'steps.2.step', 'step', array (
  'sequenceId' => $step_sequence_ids['step-sections-7'],
  'attrs' =>
  array (
    'wphave' =>
    array (
      'classNames' => 'wi pa asrt bg-co bg br',
      'dimensions' =>
      array (
        'width' =>
        array (
          'limit' => 'max',
          'custom' => '53px',
        ),
        'aspectRatio' =>
        array (
          'ratio' => '1/1',
        ),
        'spacing' =>
        array (
          'padding' => '0.5rem 0.5rem 0.5rem 0.5rem',
        ),
      ),
      'styles' => '--wi: 53px;--pa: 0.5rem 0.5rem 0.5rem 0.5rem;--pa-top: 0.5rem;--pa-right: 0.5rem;--pa-bottom: 0.5rem;--pa-left: 0.5rem;--asrt: 1/1;--bg-co: var(--wphave-site-color-background-contrast-2);--br: 100px 100px 100px 100px',
      'background' =>
      array (
        'color' =>
        array (
          'base' => 'var(--wphave-site-color-background-contrast-2)',
        ),
      ),
      'stylesChild' => '--left-spacing-inherit: 0.5rem;--right-spacing-inherit: 0.5rem',
      'frame' =>
      array (
        'corners' => '100px 100px 100px 100px',
      ),
      'settings' =>
      array (
        'leadingZero' => false,
      ),
    ),
  ),
), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'steps.2.title', 'heading', array (
  'level' => 'h3',
  'size' => 'title-xxs',
), $slots ) . '

' . wphave_pattern_slot( 'steps.2.text', 'body', array('size' => 'text-s'), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"gapX":"var(\u002d\u002dwphave-site-layout-gap)","gapY":"var(\u002d\u002dwphave-site-layout-gap)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"start","alignHorizontal":"space-between"}},"classNames":"ly ly-fl","stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-layout-gap);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: start;\u002d\u002dly-halign: space-between;\u002d\u002dly-fl-direction: row"}} -->
' . wphave_pattern_slot( 'steps.3.step', 'step', array (
  'sequenceId' => $step_sequence_ids['step-sections-7'],
  'attrs' =>
  array (
    'wphave' =>
    array (
      'classNames' => 'wi pa asrt bg-co bg br',
      'dimensions' =>
      array (
        'width' =>
        array (
          'limit' => 'max',
          'custom' => '53px',
        ),
        'aspectRatio' =>
        array (
          'ratio' => '1/1',
        ),
        'spacing' =>
        array (
          'padding' => '0.5rem 0.5rem 0.5rem 0.5rem',
        ),
      ),
      'styles' => '--wi: 53px;--pa: 0.5rem 0.5rem 0.5rem 0.5rem;--pa-top: 0.5rem;--pa-right: 0.5rem;--pa-bottom: 0.5rem;--pa-left: 0.5rem;--asrt: 1/1;--bg-co: var(--wphave-site-color-background-contrast-2);--br: 100px 100px 100px 100px',
      'background' =>
      array (
        'color' =>
        array (
          'base' => 'var(--wphave-site-color-background-contrast-2)',
        ),
      ),
      'stylesChild' => '--left-spacing-inherit: 0.5rem;--right-spacing-inherit: 0.5rem',
      'frame' =>
      array (
        'corners' => '100px 100px 100px 100px',
      ),
      'settings' =>
      array (
        'leadingZero' => false,
      ),
    ),
  ),
), $slots ) . '

<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"classNames":"ly ly-stk","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
' . wphave_pattern_slot( 'steps.3.title', 'heading', array (
  'level' => 'h3',
  'size' => 'title-xxs',
), $slots ) . '

' . wphave_pattern_slot( 'steps.3.text', 'body', array('size' => 'text-s'), $slots ) . '
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->'
        );

        return $patterns;

	}

endif;
