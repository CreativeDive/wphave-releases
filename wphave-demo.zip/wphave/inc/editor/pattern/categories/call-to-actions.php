<?php

/**
 * Functions to group similar wphave block patterns.
 */

if (!function_exists('wphave_block_pattern_collection_call_to_actions')):
	function wphave_block_pattern_collection_call_to_actions($args = []) {
		if (!wphave_release_feature_ready('patternCallToActions')) {
			return [];
		}

		$content_width = isset($args['width']) ? (int) $args['width'] : 1300;

		$patterns = [];

		$patterns[] = [
			'tags' => ['cta'],
			'title' => '',
			'viewportWidth' => $content_width,
			'ai' => [
				'enabled' => true,
				'roles' => ['cta', 'section', 'wide-card'],
				'layout' => ['split', 'panel'],
				'width' => ['content-width'],
				'visual' => ['none'],
				'content' => ['heading', 'body', 'actions'],
				'intent' => ['conversion', 'lead-capture'],
				'treatment' => ['framed', 'soft-surface'],
				'description' =>
					'Inline CTA with compact headline, supporting text, and two horizontal actions.',
			],
			'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"wi-in pa ofw ly ly-fl bg-co bg br txta ly-fl-t ly-fl-m ly-fl-dtn-vtl","dimensions":{"overflow":"clip","innerWidth":{"custom":"100%"},"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-l)"}},"styles":"\u002d\u002dwi-in: 100%;\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-l);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-l);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-l);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-l);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-l);\u002d\u002dofw: clip;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-background-contrast-1);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners);\u002d\u002dtxta: none","text":{"align":"none"},"frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"},"layout":{"type":"flex","flex":{"flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"space-between","gapX":"var(\u002d\u002dwphave-site-gap-size-4xl)","gapY":"var(\u002d\u002dwphave-site-gap-size-4xl)"}},"background":{"color":{"base":"var(\u002d\u002dwphave-site-color-background-contrast-1)"}},"stylesLayout":"\u002d\u002dly-column-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-row-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-fl-wrap: no-wrap;\u002d\u002dly-fl-itm: 0 1 auto;\u002d\u002dly-valign: center;\u002d\u002dly-halign: space-between;\u002d\u002dly-fl-direction: row;\u002d\u002dly-t-column-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-t-row-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-t-fl-wrap: no-wrap;\u002d\u002dly-t-fl-itm: 0 1 auto;\u002d\u002dly-t-valign: center;\u002d\u002dly-t-halign: space-between;\u002d\u002dly-t-fl-direction: row;\u002d\u002dly-m-column-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-m-row-gap: var(\u002d\u002dwphave-site-gap-size-4xl);\u002d\u002dly-m-fl-wrap: no-wrap;\u002d\u002dly-m-fl-itm: 0 1 auto;\u002d\u002dly-m-valign: space-between;\u002d\u002dly-m-halign: center;\u002d\u002dly-m-fl-direction: column","mobile":{"layout":{"stacked":{"flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"column","flexItemSizing":"auto","alignVertical":"start","alignHorizontal":"start"},"flex":{"flexDirection":"column"}}},"stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-l);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-l)"}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"wi ly ly-stk ly-co-pos ly-t-co-pos wi-m ly-m-co-pos ly-ho-co-pos ly-stcy-co-pos ly-vwpt-co-pos","styles":"\u002d\u002dwi: 50%;\u002d\u002dly-co-pos-h: start;\u002d\u002dly-co-pos-v: start;\u002d\u002dly-t-co-pos-h: start;\u002d\u002dly-t-co-pos-v: start;\u002d\u002dwi-m: 100%;\u002d\u002dly-m-co-pos-h: start;\u002d\u002dly-m-co-pos-v: start;\u002d\u002dly-ho-co-pos-h: start;\u002d\u002dly-ho-co-pos-v: start;\u002d\u002dly-stcy-co-pos-h: start;\u002d\u002dly-stcy-co-pos-v: start;\u002d\u002dly-vwpt-co-pos-h: start;\u002d\u002dly-vwpt-co-pos-v: start","layout":{"stacked":{"contentPosition":"top-left","gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-t-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-m-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-ho-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-stcy-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-vwpt-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"width":{"custom":"50%"}},"mobile":{"dimensions":{"width":{"custom":"100%"}}}}} -->
<!-- wp:wphave/heading {"wphave":{"settings":{"headingLevel":"h6"},"text":{"typeface":{"size":{"type":"title-xs"}}},"classNames":"tf-fs tf-fs-title-xs"},"content":"Start your 30-day free trial"} /-->

<!-- wp:wphave/paragraph {"wphave":{"text":{"typeface":{"size":{"type":"default"}}},"classNames":"tf-fs"},"content":"Join over 4,000+ startups already growing with Untitled."} /-->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"--wi: fit-content","classNames":"ly ly-fl ly-fl-wp wi","layout":{"type":"flex","flex":{"flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"start","gapX":"1rem","gapY":"1rem"}},"stylesLayout":"--ly-column-gap: 1rem;--ly-row-gap: 1rem;--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: start;--ly-fl-direction: row"}} -->
<!-- wp:wphave/button {"content":"Join us Now"} /-->

<!-- wp:wphave/button {"wphave":{"settings":{"variant":"secondary"}},"content":"Explore"} /-->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->',
		];

		$patterns[] = [
			'tags' => ['cta'],
			'title' => '',
			'viewportWidth' => $content_width,
			'ai' => [
				'enabled' => true,
				'roles' => ['cta', 'section'],
				'layout' => ['centered', 'panel'],
				'width' => ['content-width'],
				'visual' => ['color-background'],
				'content' => ['heading', 'body', 'actions'],
				'intent' => ['conversion', 'lead-capture'],
				'treatment' => ['framed', 'strong-contrast', 'visual-impact'],
				'description' =>
					'Centered high-emphasis CTA with accent background pattern, short copy, and paired actions.',
			],
			'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"pa ofw ly ly-stk ly-co-pos bg-co bg br txta tx-co ly-t-co-pos ly-m-co-pos ly-ho-co-pos ly-stcy-co-pos ly-vwpt-co-pos","dimensions":{"overflow":"clip","spacing":{"padding":"var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-l)"}},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-l);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-l);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-l);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-l);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-l);\u002d\u002dofw: clip;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-accent);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners);\u002d\u002dtxta: center;\u002d\u002dtx-co: var(\u002d\u002dwphave-site-color-palette-white);\u002d\u002dly-t-co-pos-h: center;\u002d\u002dly-t-co-pos-v: center;\u002d\u002dly-m-co-pos-h: center;\u002d\u002dly-m-co-pos-v: center;\u002d\u002dly-ho-co-pos-h: center;\u002d\u002dly-ho-co-pos-v: center;\u002d\u002dly-stcy-co-pos-h: center;\u002d\u002dly-stcy-co-pos-v: center;\u002d\u002dly-vwpt-co-pos-h: center;\u002d\u002dly-vwpt-co-pos-v: center","text":{"align":"center","colors":{"text":"var(\u002d\u002dwphave-site-color-palette-white)"}},"frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"},"layout":{"stacked":{"contentPosition":"center","gap":"var(\u002d\u002dwphave-site-gap-size-l)"}},"background":{"color":{"base":"var(\u002d\u002dwphave-site-color-accent)"}},"stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-l);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-l)","stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-l);\u002d\u002dly-t-gap: var(\u002d\u002dwphave-site-gap-size-l);\u002d\u002dly-m-gap: var(\u002d\u002dwphave-site-gap-size-l);\u002d\u002dly-ho-gap: var(\u002d\u002dwphave-site-gap-size-l);\u002d\u002dly-stcy-gap: var(\u002d\u002dwphave-site-gap-size-l);\u002d\u002dly-vwpt-gap: var(\u002d\u002dwphave-site-gap-size-l)"}} -->
<!-- wp:wphave/spacer {"wphave":{"settings":{"aspectRatio":"35/1"},"styles":"\u002d\u002daspect-ratio: 35/1"}} /-->

<!-- wp:wphave/group {"wphave":{"classNames":"wi ly ly-stk ly-co-pos ly-t-co-pos wi-m ly-m-co-pos ly-ho-co-pos ly-stcy-co-pos ly-vwpt-co-pos","styles":"\u002d\u002dwi: 50%;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center;\u002d\u002dly-t-co-pos-h: center;\u002d\u002dly-t-co-pos-v: center;\u002d\u002dwi-m: 100%;\u002d\u002dly-m-co-pos-h: center;\u002d\u002dly-m-co-pos-v: center;\u002d\u002dly-ho-co-pos-h: center;\u002d\u002dly-ho-co-pos-v: center;\u002d\u002dly-stcy-co-pos-h: center;\u002d\u002dly-stcy-co-pos-v: center;\u002d\u002dly-vwpt-co-pos-h: center;\u002d\u002dly-vwpt-co-pos-v: center","layout":{"stacked":{"contentPosition":"center","gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-t-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-m-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-ho-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-stcy-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-vwpt-gap: var(\u002d\u002dwphave-site-gap-size-s)","dimensions":{"width":{"custom":"50%"}},"mobile":{"dimensions":{"width":{"custom":"100%"}}}}} -->
<!-- wp:wphave/heading {"wphave":{"settings":{"headingLevel":"h6"},"text":{"typeface":{"size":{"type":"title-s"}}},"classNames":"tf-fs tf-fs-title-s"},"content":"Start your 30-day free trial"} /-->

<!-- wp:wphave/paragraph {"wphave":{"text":{"typeface":{"size":{"type":"default"}}},"classNames":"tf-fs"},"content":"Join over 4,000+ startups already growing with Untitled."} /-->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"--wi: fit-content","classNames":"ly ly-fl ly-fl-wp wi","layout":{"type":"flex","flex":{"flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"start","gapX":"1rem","gapY":"1rem"}},"stylesLayout":"--ly-column-gap: 1rem;--ly-row-gap: 1rem;--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: start;--ly-fl-direction: row"}} -->
<!-- wp:wphave/button {"wphave":{"settings":{"variant":"secondary"}},"content":"Join us Now"} /-->

<!-- wp:wphave/button {"wphave":{"settings":{"variant":"secondary"}},"content":"Explore"} /-->
<!-- /wp:wphave/group -->

<!-- wp:wphave/spacer {"wphave":{"settings":{"aspectRatio":"35/1"},"styles":"\u002d\u002daspect-ratio: 35/1"}} /-->
<!-- /wp:wphave/group -->',
		];

		$patterns[] = [
			'tags' => ['cta'],
			'title' => '',
			'viewportWidth' => $content_width,
			'ai' => [
				'enabled' => true,
				'roles' => ['cta', 'section'],
				'layout' => ['centered', 'panel'],
				'width' => ['wide'],
				'visual' => ['background-media'],
				'content' => ['heading', 'body', 'actions'],
				'intent' => ['conversion', 'lead-capture'],
				'treatment' => ['framed', 'overlay', 'background-media', 'visual-impact'],
				'description' =>
					'Centered high-emphasis CTA with accent background pattern, short copy, and paired actions.',
			],
			'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-wide wi-in pa ofw ly ly-stk bg br txta","dimensions":{"overflow":"clip","spacing":{"padding":"var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-l)"},"innerWidth":{"limit":"max","custom":"90%"}},"styles":"\u002d\u002dwi-in: 90%;\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-l);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-l);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-l);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-l);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-l);\u002d\u002dofw: clip;\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners);\u002d\u002dtxta: none","text":{"align":"none"},"background":{"layers":[{"media":{"image":{"type":"custom","data":{"id":null,"focal":{"top":50,"left":50}},"size":"auto"}},"overlay":{"type":"cover","axis":"0%","color":"#000000","opacity":"0.35"}}]},"mobile":{"layout":{"stacked":{"flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"column","flexItemSizing":"auto","alignVertical":"start","alignHorizontal":"start"}}},"stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-l);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-l)","stylesBackgrounds":["\u002d\u002dbg-mda-img-pos: 50% 50%;\u002d\u002dov-ax: 0%;\u002d\u002dov-co: #000000;\u002d\u002dov-op: 0.35;\u002d\u002dov-bg: var(\u002d\u002dov-co)"],"features":{"size":"wide"},"frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"}}} -->
<!-- wp:wphave/spacer /-->

<!-- wp:wphave/group {"wphave":{"classNames":"wi ly ly-stk ly-co-pos tx-co ly-t-co-pos wi-m ly-m-co-pos ly-ho-co-pos ly-stcy-co-pos ly-vwpt-co-pos","styles":"\u002d\u002dwi: 60%;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: start;\u002d\u002dtx-co: var(\u002d\u002dwphave-site-color-palette-white);\u002d\u002dly-t-co-pos-h: center;\u002d\u002dly-t-co-pos-v: start;\u002d\u002dwi-m: 100%;\u002d\u002dly-m-co-pos-h: center;\u002d\u002dly-m-co-pos-v: start;\u002d\u002dly-ho-co-pos-h: center;\u002d\u002dly-ho-co-pos-v: start;\u002d\u002dly-stcy-co-pos-h: center;\u002d\u002dly-stcy-co-pos-v: start;\u002d\u002dly-vwpt-co-pos-h: center;\u002d\u002dly-vwpt-co-pos-v: start","layout":{"stacked":{"contentPosition":"left","gap":"var(\u002d\u002dwphave-site-gap-size-m)"}},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-t-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-m-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-ho-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-stcy-gap: var(\u002d\u002dwphave-site-gap-size-m);\u002d\u002dly-vwpt-gap: var(\u002d\u002dwphave-site-gap-size-m)","dimensions":{"width":{"custom":"60%"}},"mobile":{"dimensions":{"width":{"custom":"100%"}}},"text":{"colors":{"text":"var(\u002d\u002dwphave-site-color-palette-white)"}}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk","layout":{"stacked":{"gap":"var(\u002d\u002dwphave-site-gap-size-s)"}},"stylesLayout":"\u002d\u002dly-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-t-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-m-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-ho-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-stcy-gap: var(\u002d\u002dwphave-site-gap-size-s);\u002d\u002dly-vwpt-gap: var(\u002d\u002dwphave-site-gap-size-s)"}} -->
<!-- wp:wphave/heading {"wphave":{"settings":{"headingLevel":"h6"},"text":{"typeface":{"size":{"type":"title-m"}}},"classNames":"tf-fs tf-fs-title-m"},"content":"Start your 30-day free trial"} /-->

<!-- wp:wphave/paragraph {"wphave":{"text":{"typeface":{"size":{"type":"default"}}},"classNames":"tf-fs"},"content":"Join over 4,000+ startups already growing with Untitled."} /-->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"--wi: fit-content","classNames":"ly ly-fl ly-fl-wp wi","layout":{"type":"flex","flex":{"flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"start","gapX":"1rem","gapY":"1rem"}},"stylesLayout":"--ly-column-gap: 1rem;--ly-row-gap: 1rem;--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: start;--ly-fl-direction: row"}} -->
<!-- wp:wphave/button {"wphave":{"settings":{"variant":"secondary"}},"content":"Join us Now"} /-->

<!-- wp:wphave/button {"wphave":{"settings":{"variant":"secondary"}},"content":"Explore"} /-->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->

<!-- wp:wphave/spacer /-->
<!-- /wp:wphave/group -->',
		];

		$patterns[] = [
			'tags' => ['cta'],
			'title' => '',
			'viewportWidth' => $content_width,
			'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"wi-in pa ofw ly ly-stk ly-co-pos bg br txta ly-t-co-pos wi-in-m pa-m ly-m-co-pos ly-ho-co-pos ly-stcy-co-pos ly-vwpt-co-pos","dimensions":{"overflow":"clip","spacing":{"padding":"var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-l) 0 var(\u002d\u002dwphave-site-padding-l)"},"innerWidth":{"custom":"90%"}},"styles":"\u002d\u002dwi-in: 90%;\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-l) 0 var(\u002d\u002dwphave-site-padding-l);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-l);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-l);\u002d\u002dpa-bottom: 0;\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-l);\u002d\u002dofw: clip;\u002d\u002dly-co-pos-h: end;\u002d\u002dly-co-pos-v: end;\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners);\u002d\u002dtxta: none;\u002d\u002dly-t-co-pos-h: end;\u002d\u002dly-t-co-pos-v: end;\u002d\u002dwi-in-m: 100%;\u002d\u002dpa-m: 20rem var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-l);\u002d\u002dpa-m-top: 20rem;\u002d\u002dpa-m-right: var(\u002d\u002dwphave-site-padding-l);\u002d\u002dpa-m-bottom: var(\u002d\u002dwphave-site-padding-l);\u002d\u002dpa-m-left: var(\u002d\u002dwphave-site-padding-l);\u002d\u002dly-m-co-pos-h: end;\u002d\u002dly-m-co-pos-v: end;\u002d\u002dly-ho-co-pos-h: end;\u002d\u002dly-ho-co-pos-v: end;\u002d\u002dly-stcy-co-pos-h: end;\u002d\u002dly-stcy-co-pos-v: end;\u002d\u002dly-vwpt-co-pos-h: end;\u002d\u002dly-vwpt-co-pos-v: end","text":{"align":"none"},"layout":{"stacked":{"contentPosition":"bottom-right"}},"background":{"layers":[{"media":{"image":{"type":"custom","data":{"id":null,"focal":{"top":50,"left":50}}}}}]},"stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-l);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-l);\u002d\u002dleft-spacing-inherit-m: var(\u002d\u002dwphave-site-padding-l);\u002d\u002dright-spacing-inherit-m: var(\u002d\u002dwphave-site-padding-l)","stylesBackgrounds":["\u002d\u002dbg-mda-img-pos: 50% 50%"],"frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"},"mobile":{"dimensions":{"spacing":{"padding":"20rem var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-l)"},"innerWidth":{"limit":"max","custom":"100%"}}}}} -->
<!-- wp:wphave/spacer /-->

<!-- wp:wphave/group {"wphave":{"classNames":"wi pa ofw ly ly-stk ly-co-pos bg-co bg br tx-co ly-t-co-pos wi-m ofw-m ly-m-co-pos br-m ly-ho-co-pos ly-stcy-co-pos ly-vwpt-co-pos","styles":"\u002d\u002dwi: 50%;\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-l);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-l);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-l);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-l);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-l);\u002d\u002dofw: clip;\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: start;\u002d\u002dbg-co: var(\u002d\u002dwphave-site-color-primary);\u002d\u002dbr: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) 0 0;\u002d\u002dtx-co: var(\u002d\u002dwphave-site-color-palette-white);\u002d\u002dly-t-co-pos-h: center;\u002d\u002dly-t-co-pos-v: start;\u002d\u002dwi-m: 100%;\u002d\u002dofw-m: clip;\u002d\u002dly-m-co-pos-h: center;\u002d\u002dly-m-co-pos-v: start;\u002d\u002dbr-m: var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners);\u002d\u002dly-ho-co-pos-h: center;\u002d\u002dly-ho-co-pos-v: start;\u002d\u002dly-stcy-co-pos-h: center;\u002d\u002dly-stcy-co-pos-v: start;\u002d\u002dly-vwpt-co-pos-h: center;\u002d\u002dly-vwpt-co-pos-v: start","layout":{"stacked":{"contentPosition":"left"}},"dimensions":{"width":{"custom":"50%"},"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-l) var(\u002d\u002dwphave-site-padding-l)"},"overflow":"clip"},"mobile":{"dimensions":{"width":{"custom":"100%"},"overflow":"clip"},"frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners)"}},"text":{"colors":{"text":"var(\u002d\u002dwphave-site-color-palette-white)"}},"background":{"color":{"base":"var(\u002d\u002dwphave-site-color-primary)"}},"stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-l);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-l)","frame":{"corners":"var(\u002d\u002dwphave-site-corners) var(\u002d\u002dwphave-site-corners) 0 0"}}} -->
<!-- wp:wphave/heading {"wphave":{"settings":{"headingLevel":"h6"},"text":{"typeface":{"size":{"type":"title-m"}}},"classNames":"tf-fs tf-fs-title-m"},"content":"Start your 30-day free trial"} /-->

<!-- wp:wphave/paragraph {"wphave":{"text":{"typeface":{"size":{"type":"default"}}},"classNames":"tf-fs"},"content":"Join over 4,000+ startups already growing with Untitled."} /-->

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"--wi: fit-content","classNames":"ly ly-fl ly-fl-wp wi","layout":{"type":"flex","flex":{"flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"start","gapX":"1rem","gapY":"1rem"}},"stylesLayout":"--ly-column-gap: 1rem;--ly-row-gap: 1rem;--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: start;--ly-fl-direction: row"}} -->
<!-- wp:wphave/button {"wphave":{"settings":{"variant":"primary"}},"content":"Join us Now"} /-->

<!-- wp:wphave/button {"wphave":{"settings":{"variant":"primary"}},"content":"Explore"} /-->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->',
		];

		$patterns[] = [
			'tags' => ['cta'],
			'title' => '',
			'viewportWidth' => $content_width,
			'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-wide wi-in pa ofw ly ly-stk ly-co-pos bg br txta pa-m","dimensions":{"overflow":"clip","spacing":{"padding":"0 3rem 0 3rem"},"innerWidth":{"custom":"100%"}},"styles":"--wi-in: 100%;--pa: 0 3rem 0 3rem;--pa-top: 0;--pa-right: 3rem;--pa-bottom: 0;--pa-left: 3rem;--ofw: clip;--ly-co-pos-h: center;--ly-co-pos-v: center;--br: var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners);--txta: none;--pa-m: 20rem var(--wphave-site-padding-right) var(--wphave-site-padding-bottom) var(--wphave-site-padding-left);--pa-m-top: 20rem;--pa-m-right: var(--wphave-site-padding-right);--pa-m-bottom: var(--wphave-site-padding-bottom);--pa-m-left: var(--wphave-site-padding-left)","text":{"align":"none"},"layout":{"stacked":{"contentPosition":"center"}},"background":{"layers":[{"media":{"image":{"type":"custom","data":{"id":7301},"size":"auto"}}}]},"stylesChild":"--left-spacing-inherit: 3rem;--right-spacing-inherit: 3rem;--left-spacing-inherit-m: var(--wphave-site-padding-left);--right-spacing-inherit-m: var(--wphave-site-padding-right)","stylesBackgrounds":[""],"classNamesBackground":[""],"features":{"size":"wide"},"frame":{"corners":"var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners)"},"mobile":{"dimensions":{"spacing":{"padding":"20rem var(--wphave-site-padding-right) var(--wphave-site-padding-bottom) var(--wphave-site-padding-left)"}}}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"wi pa ofw ly ly-stk ly-co-pos bg-co bg tx-co wi-m ofw-m br-m","styles":"--wi: 470px;--pa: 4rem 4rem 4rem 4rem;--pa-top: 4rem;--pa-right: 4rem;--pa-bottom: 4rem;--pa-left: 4rem;--ofw: clip;--ly-co-pos-h: center;--ly-co-pos-v: start;--bg-co: var(--wphave-site-color-primary);--tx-co: var(--wphave-site-color-palette-white);--wi-m: 100%;--ofw-m: clip;--br-m: var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners)","layout":{"stacked":{"contentPosition":"left"}},"dimensions":{"width":{"custom":"470px"},"spacing":{"padding":"4rem 4rem 4rem 4rem"},"overflow":"clip"},"mobile":{"dimensions":{"width":{"custom":"100%"},"overflow":"clip"},"frame":{"corners":"var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners)"}},"text":{"colors":{"text":"var(--wphave-site-color-palette-white)"}},"background":{"color":{"base":"var(--wphave-site-color-primary)"}},"stylesChild":"--left-spacing-inherit: 4rem;--right-spacing-inherit: 4rem"}} -->
<!-- wp:wphave/heading {"wphave":{"settings":{"headingLevel":"h6"},"text":{"typeface":{"size":{"type":"title-m"}}},"classNames":"tf-fs tf-fs-title-m"},"content":"Start your 30-day free trial"} /-->

<!-- wp:wphave/paragraph {"wphave":{"text":{"typeface":{"size":{"type":"default"}}},"classNames":"tf-fs"},"content":"Join over 4,000+ startups already growing with Untitled."} /-->

<!-- wp:wphave/group {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"--wi: fit-content","classNames":"ly ly-fl ly-fl-wp wi","layout":{"type":"flex","flex":{"flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"start","gapX":"1rem","gapY":"1rem"}},"stylesLayout":"--ly-column-gap: 1rem;--ly-row-gap: 1rem;--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: start;--ly-fl-direction: row"}} -->
<!-- wp:wphave/button {"wphave":{"settings":{"variant":"primary"}},"content":"Join us Now"} /-->

<!-- wp:wphave/button {"wphave":{"settings":{"variant":"primary"}},"content":"Explore"} /-->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->',
		];

		$patterns[] = [
			'tags' => ['cta'],
			'title' => '',
			'viewportWidth' => $content_width,
			'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"wi-in pa ofw ly ly-fl bg-co bg br txta tx-co ly-m-fl-wp ly-fl-dtn-vtl","dimensions":{"overflow":"clip","innerWidth":{"custom":"100%"},"spacing":{"padding":"0 0 0 0"}},"styles":"--wi-in: 100%;--pa: 0 0 0 0;--pa-top: 0;--pa-right: 0;--pa-bottom: 0;--pa-left: 0;--ofw: clip;--bg-co: #592dd0;--br: var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners);--txta: none;--tx-co: var(--wphave-site-color-palette-white)","text":{"align":"none","colors":{"text":"var(--wphave-site-color-palette-white)"}},"frame":{"corners":"var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners)"},"layout":{"type":"flex","flex":{"flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"stretch","alignHorizontal":"space-between"}},"background":{"color":{"base":"#592dd0"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-layout-gap);--ly-row-gap: var(--wphave-site-layout-gap);--ly-fl-wrap: no-wrap;--ly-fl-itm: 0 1 auto;--ly-valign: stretch;--ly-halign: space-between;--ly-fl-direction: row;--ly-m-column-gap: var(--wphave-site-layout-gap);--ly-m-row-gap: var(--wphave-site-layout-gap);--ly-m-fl-wrap: wrap;--ly-m-fl-itm: 0 1 auto;--ly-m-valign: start;--ly-m-halign: start;--ly-m-fl-direction: column","mobile":{"layout":{"stacked":{"flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"column","flexItemSizing":"auto","alignVertical":"start","alignHorizontal":"start"}}},"stylesChild":"--left-spacing-inherit: 0;--right-spacing-inherit: 0"}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"wi pa ly ly-stk ly-co-pos wi-m","styles":"--wi: 50%;--pa: 3rem 3rem 3rem 3rem;--pa-top: 3rem;--pa-right: 3rem;--pa-bottom: 3rem;--pa-left: 3rem;--ly-co-pos-h: center;--ly-co-pos-v: start;--wi-m: 100%","layout":{"stacked":{"contentPosition":"left","gap":"var(--wphave-site-gap-size-s)"}},"stylesLayout":"--ly-gap: var(--wphave-site-gap-size-s)","dimensions":{"width":{"custom":"50%"},"spacing":{"padding":"3rem 3rem 3rem 3rem"}},"mobile":{"dimensions":{"width":{"custom":"100%"}}},"stylesChild":"--left-spacing-inherit: 3rem;--right-spacing-inherit: 3rem"}} -->
<!-- wp:wphave/heading {"wphave":{"settings":{"headingLevel":"h6"},"text":{"typeface":{"size":{"type":"title-xs"}}},"classNames":"tf-fs tf-fs-title-xs"},"content":"Start your 30-day free trial"} /-->

<!-- wp:wphave/paragraph {"wphave":{"text":{"typeface":{"size":{"type":"default"}}},"classNames":"tf-fs"},"content":"Join over 4,000+ startups already growing with Untitled."} /-->
<!-- /wp:wphave/group -->

<!-- wp:wphave/group {"wphave":{"background":{"layers":[{"gradient":{"type":"radial","position":{"x":104,"y":38},"colorStops":[{"color":"#582dd0","position":10},{"color":"#130c3d","position":89}],"radialShape":"circle"},"mask":{"geometric":{"type":"slanted","shapes":"rounded","slanted":"left-top","slantedOffset":"34%"}}}]},"styles":"--wi: fit-content;--pa: var(--wphave-site-spacing) var(--wphave-site-spacing) var(--wphave-site-spacing) var(--wphave-site-spacing);--pa-top: var(--wphave-site-spacing);--pa-right: var(--wphave-site-spacing);--pa-bottom: var(--wphave-site-spacing);--pa-left: var(--wphave-site-spacing);--bso: 0rem 0.5rem 0.813rem -0.438rem rgba(0,0,0, 0.19);--tx-co: var(--wphave-site-color-palette-white);--wi-m: 100%","classNames":"wi pa ly ly-fl bg bso tx-co wi-m ly-m-fl-wp","shadow":{"outset":{"shift":{"x":"0rem","y":"0.5rem"},"blur":"0.813rem","spread":"-0.438rem","color":"rgb(0,0,0)","opacity":0.19}},"stylesBackgrounds":["--bg-grd: radial-gradient(circle at 104% 38%, #582dd0 10%, #130c3d 89%);--bg-msk-clp: polygon(var(--msk-gm-sl-oft) 0,100% 0,100% 100%,0 100%);--msk-gm-sl-oft: 34%"],"classNamesBackground":["bg-msk bg-msk-clp"],"layout":{"type":"flex","flex":{"flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"start"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-layout-gap);--ly-row-gap: var(--wphave-site-layout-gap);--ly-fl-wrap: no-wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: start;--ly-fl-direction: row;--ly-m-column-gap: var(--wphave-site-layout-gap);--ly-m-row-gap: var(--wphave-site-layout-gap);--ly-m-fl-wrap: wrap;--ly-m-fl-itm: 0 1 auto;--ly-m-valign: center;--ly-m-halign: start;--ly-m-fl-direction: row","dimensions":{"width":{"custom":"fit-content"},"spacing":{"padding":"var(--wphave-site-spacing) var(--wphave-site-spacing) var(--wphave-site-spacing) var(--wphave-site-spacing)"}},"stylesChild":"--left-spacing-inherit: var(--wphave-site-spacing);--right-spacing-inherit: var(--wphave-site-spacing)","text":{"colors":{"text":"var(--wphave-site-color-palette-white)"}},"mobile":{"dimensions":{"width":{"custom":"100%"}},"layout":{"stacked":{"flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"start"}}}},"metadata":{"name":"Chip"}} -->
<!-- wp:wphave/icon {"wphave":{"dimensions":{"width":{"custom":"92px","min":"92px"},"overflow":"clip"},"styles":"\u002d\u002dwi: 92px;\u002d\u002dwi-min: 92px;\u002d\u002dofw: clip;\u002d\u002dbo-width: 2px 2px 2px 2px;\u002d\u002dbo-style: solid solid solid solid;\u002d\u002dbo-color: #4f29bc #4f29bc #4f29bc #4f29bc;\u002d\u002dbr: 50% 50% 50% 50%;\u002d\u002dicon-inner-width: 60%;\u002d\u002dicon-color: var(\u002d\u002dwphave-site-color-palette-white)","classNames":"wi ofw bg bo br","settings":{"colors":{"icon":"var(\u002d\u002dwphave-site-color-palette-white)"},"width":"60%"},"background":{"layers":[{"gradient":{"type":"radial","position":{"x":50,"y":10},"radialSize":{"x":140,"y":107},"radialShape":"size","colorStops":[{"color":"rgba(102, 51, 238, 1)","position":33},{"color":"rgba(0, 3, 20, 1)","position":105}]}}]},"stylesBackgrounds":["\u002d\u002dbg-grd: radial-gradient(140% 107% at 50% 10%, rgba(102, 51, 238, 1) 33%, rgba(0, 3, 20, 1) 105%)"],"classNamesBackground":[""],"frame":{"corners":"50% 50% 50% 50%","border":{"width":"2px 2px 2px 2px","style":"solid solid solid solid","color":"#4f29bc #4f29bc #4f29bc #4f29bc"}}},"icon":{"key":"mdi-play-circle-outline","svg":"\u003csvg xmlns=\u0022http://www.w3.org/2000/svg\u0022 width=\u002224\u0022 height=\u002224\u0022 viewBox=\u00220 0 24 24\u0022\u003e\u003cpath fill=\u0022currentColor\u0022 d=\u0022M12 20c-4.41 0-8-3.59-8-8s3.59-8 8-8s8 3.59 8 8s-3.59 8-8 8m0-18A10 10 0 0 0 2 12a10 10 0 0 0 10 10a10 10 0 0 0 10-10A10 10 0 0 0 12 2m-2 14.5l6-4.5l-6-4.5v9Z\u0022/\u003e\u003c/svg\u003e"}} /-->

<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-stk","layout":{"stacked":{"gap":"0.1rem"}},"stylesLayout":"--ly-gap: 0.1rem"}} -->
<!-- wp:wphave/paragraph {"wphave":{"text":{"typeface":{"size":{"type":"text-m"}}},"classNames":"is-bold is-white-space tf-fs tf-fs-text-m","settings":{"whiteSpace":"nowrap","formats":["bold"]},"styles":"\u002d\u002dtxt-whsp: nowrap"},"content":"Watch the Video"} /-->

<!-- wp:wphave/paragraph {"wphave":{"text":{"typeface":{"size":{"type":"default"}}},"classNames":"tf-fs vby-oty vby-vis","visibility":{"opacity":0.75,"visually":"visible"},"styles":"\u002d\u002dvby-oty: 0.75"},"content":"120 Minutes"} /-->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->
<!-- /wp:wphave/group -->',
		];

		$patterns[] = [
			'tags' => ['cta'],
			'title' => '',
			'viewportWidth' => $content_width,
			'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"wi-in pa ofw ly ly-fl bg-co bg br txta tx-co ly-m-fl-wp","dimensions":{"overflow":"clip","innerWidth":{"custom":"100%"},"spacing":{"padding":"3rem 3rem 3rem 3rem"}},"styles":"--wi-in: 100%;--pa: 3rem 3rem 3rem 3rem;--pa-top: 3rem;--pa-right: 3rem;--pa-bottom: 3rem;--pa-left: 3rem;--ofw: clip;--bg-co: var(--wphave-site-color-palette-royal);--br: var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners);--txta: none;--tx-co: var(--wphave-site-color-palette-white)","text":{"align":"none","colors":{"text":"var(--wphave-site-color-palette-white)"}},"frame":{"corners":"var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners)"},"layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-layout-gap)","gapY":"var(--wphave-site-layout-gap)","flexWrap":"no-wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"start"}},"background":{"color":{"base":"var(--wphave-site-color-palette-royal)"},"layers":[{"decoration":[{"deco":{"type":"18","rotate":"53deg","size":"133%","position":{"x":"7%","y":"71%"},"colors":{"deco":"#1b145b"},"blur":"17px","opacity":0.54}}],"gradient":{"type":"linear","angle":39,"position":"left","colorStops":[{"color":"rgba(23, 16, 87, 1)","position":-1},{"color":"var(--wphave-site-color-palette-royal)","position":99}]}}]},"mobile":{"layout":{"stacked":{"flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"column-reverse","flexItemSizing":"auto","alignVertical":"start","alignHorizontal":"start","gapX":"var(--wphave-site-gap-size-4xl)","gapY":"var(--wphave-site-gap-size-4xl)"}}},"stylesChild":"--left-spacing-inherit: 3rem;--right-spacing-inherit: 3rem","stylesBackgrounds":["--bg-grd: linear-gradient(39deg, rgba(23, 16, 87, 1) -1%, var(--wphave-site-color-palette-royal) 99%)"],"classNamesBackground":[""],"stylesLayout":"--ly-column-gap: var(--wphave-site-layout-gap);--ly-row-gap: var(--wphave-site-layout-gap);--ly-fl-wrap: no-wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: start;--ly-fl-direction: row;--ly-m-column-gap: var(--wphave-site-gap-size-4xl);--ly-m-row-gap: var(--wphave-site-gap-size-4xl);--ly-m-fl-wrap: wrap;--ly-m-fl-itm: 0 1 auto;--ly-m-valign: start;--ly-m-halign: start;--ly-m-fl-direction: column-reverse"}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"wi ly ly-stk wi-m ly-m-co-pos txta-m","styles":"--wi: 50%;--wi-m: 100%;--ly-m-co-pos-h: center;--ly-m-co-pos-v: center;--txta-m: center","dimensions":{"width":{"custom":"50%"}},"mobile":{"dimensions":{"width":{"custom":"100%"}},"layout":{"stacked":{"contentPosition":"center"}},"text":{"align":"center"}}}} -->
<!-- wp:wphave/heading {"wphave":{"settings":{"headingLevel":"h6"},"text":{"typeface":{"size":{"type":"title-m"}}},"classNames":"tf-fs tf-fs-title-m"},"content":"Start your 30-day free trial"} /-->

<!-- wp:wphave/paragraph {"wphave":{"text":{"typeface":{"size":{"type":"default"}}},"classNames":"tf-fs"},"content":"Join over 4,000+ startups already growing with Untitled."} /-->

<!-- wp:wphave/button {"wphave":{"dimensions":{"width":{"custom":"fit-content"}},"styles":"--wi: fit-content","classNames":"wi hd-m-center","mobile":{"features":{"horizontalDirection":"center"}},"settings":{"variant":"primary"}},"content":"Join us Now"} /-->
<!-- /wp:wphave/group -->

<!-- wp:wphave/device {"wphave":{"settings":{"device":"macbook"},"background":{"layers":[{"gradient":{"type":"linear","angle":0,"position":"top","colorStops":[{"color":"rgba(207, 217, 223, 1)","position":0},{"color":"rgba(226, 235, 240, 1)","position":100}]}}]},"stylesBackgrounds":["\u002d\u002dbg-grd: linear-gradient(0deg, rgba(207, 217, 223, 1) 0%, rgba(226, 235, 240, 1) 100%)"],"classNames":"ma bg wi-m ma-m","classNamesBackground":[""],"dimensions":{"spacing":{"margin":"0px -15% 0px auto"}},"styles":"\u002d\u002dma: 0px -15% 0px auto;\u002d\u002dma-top: 0px;\u002d\u002dma-right: -15%;\u002d\u002dma-bottom: 0px;\u002d\u002dma-left: auto;\u002d\u002dwi-m: 80%;\u002d\u002dma-m: 0px auto 0px auto;\u002d\u002dma-m-top: 0px;\u002d\u002dma-m-right: auto;\u002d\u002dma-m-bottom: 0px;\u002d\u002dma-m-left: auto","mobile":{"dimensions":{"spacing":{"margin":"0px auto 0px auto"},"width":{"custom":"80%"}}}}} /-->
<!-- /wp:wphave/group -->',
		];

		return $patterns;
	}
endif;
