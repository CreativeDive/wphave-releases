<?php

/**
 * Functions to group similar wphave block patterns.
 */

if (!function_exists('wphave_block_pattern_collection_content_toggling')):
	function wphave_block_pattern_collection_content_toggling($args = []) {
		if (!wphave_release_feature_ready('patternContentToggling')) {
			return [];
		}

		$content_width = isset($args['width']) ? (int) $args['width'] : 1300;

		$patterns = [];

		$patterns[] = [
			'tags' => ['content-toggling'],
			'title' => '',
			'viewportWidth' => 800,
			'content' => '<!-- wp:wphave/accordion {"wphave":{"settings":{"mode":"toggle"},"frame":{"border":{"width":"1px 1px 1px 1px","style":"solid solid solid solid","color":"var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3)"}},"styles":"\u002d\u002dbo-width: 1px 1px 1px 1px;\u002d\u002dbo-style: solid solid solid solid;\u002d\u002dbo-color: var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3)","classNames":"bo"}} -->
<!-- wp:wphave/accordion-item {"wphave":{"features":{"draft":false}}} -->
<!-- wp:wphave/accordion-title {"wphave":{"frame":{"border":{"width":"0 0 1px 0","style":"none none solid none","color":"transparent transparent var(\u002d\u002dwphave-site-color-background-contrast-3) transparent"}},"styles":"\u002d\u002dpa: 11px 16px 10px 16px;\u002d\u002dpa-top: 11px;\u002d\u002dpa-right: 16px;\u002d\u002dpa-bottom: 10px;\u002d\u002dpa-left: 16px;\u002d\u002dbo-width: 0 0 1px 0;\u002d\u002dbo-style: none none solid none;\u002d\u002dbo-color: transparent transparent var(\u002d\u002dwphave-site-color-background-contrast-3) transparent;\u002d\u002dtx-co-act: var(\u002d\u002dwphave-site-color-accent)","classNames":"pa bo tx-co-act","dimensions":{"spacing":{"padding":"11px 16px 10px 16px"}},"stylesChild":"\u002d\u002dleft-spacing-inherit: 16px;\u002d\u002dright-spacing-inherit: 16px","active":{"text":{"colors":{"text":"var(\u002d\u002dwphave-site-color-accent)"}}},"settings":{"initialOpened":true}},"content":"\u003cstrong\u003eTitel 1\u003c/strong\u003e"} /-->

<!-- wp:wphave/accordion-content -->
<!-- wp:wphave/paragraph {"wphave":{"dimensions":{"spacing":{"padding":"16px 16px 16px 16px"}},"styles":"\u002d\u002dpa: 16px 16px 16px 16px;\u002d\u002dpa-top: 16px;\u002d\u002dpa-right: 16px;\u002d\u002dpa-bottom: 16px;\u002d\u002dpa-left: 16px;\u002d\u002dbo-width: 0 0 1px 0;\u002d\u002dbo-style: none none solid none;\u002d\u002dbo-color: transparent transparent var(\u002d\u002dwphave-site-color-background-contrast-3) transparent","stylesChild":"\u002d\u002dleft-spacing-inherit: 16px;\u002d\u002dright-spacing-inherit: 16px","classNames":"pa bo","frame":{"border":{"width":"0 0 1px 0","style":"none none solid none","color":"transparent transparent var(\u002d\u002dwphave-site-color-background-contrast-3) transparent"}}},"content":"Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum.","placeholder":"Text hier eingeben ..."} /-->
<!-- /wp:wphave/accordion-content -->
<!-- /wp:wphave/accordion-item -->

<!-- wp:wphave/accordion-item -->
<!-- wp:wphave/accordion-title {"wphave":{"frame":{"border":{"width":"0 0 1px 0","style":"none none solid none","color":"transparent transparent var(\u002d\u002dwphave-site-color-background-contrast-3) transparent"}},"styles":"\u002d\u002dpa: 11px 16px 10px 16px;\u002d\u002dpa-top: 11px;\u002d\u002dpa-right: 16px;\u002d\u002dpa-bottom: 10px;\u002d\u002dpa-left: 16px;\u002d\u002dbo-width: 0 0 1px 0;\u002d\u002dbo-style: none none solid none;\u002d\u002dbo-color: transparent transparent var(\u002d\u002dwphave-site-color-background-contrast-3) transparent;\u002d\u002dtx-co-act: var(\u002d\u002dwphave-site-color-accent)","classNames":"pa bo tx-co-act","dimensions":{"spacing":{"padding":"11px 16px 10px 16px"}},"stylesChild":"\u002d\u002dleft-spacing-inherit: 16px;\u002d\u002dright-spacing-inherit: 16px","active":{"text":{"colors":{"text":"var(\u002d\u002dwphave-site-color-accent)"}}},"settings":{"initialOpened":true}},"content":"\u003cstrong\u003eTitel 2\u003c/strong\u003e"} /-->

<!-- wp:wphave/accordion-content -->
<!-- wp:wphave/paragraph {"wphave":{"dimensions":{"spacing":{"padding":"16px 16px 16px 16px"}},"styles":"\u002d\u002dpa: 16px 16px 16px 16px;\u002d\u002dpa-top: 16px;\u002d\u002dpa-right: 16px;\u002d\u002dpa-bottom: 16px;\u002d\u002dpa-left: 16px;\u002d\u002dbo-width: 0 0 1px 0;\u002d\u002dbo-style: none none solid none;\u002d\u002dbo-color: transparent transparent var(\u002d\u002dwphave-site-color-background-contrast-3) transparent","stylesChild":"\u002d\u002dleft-spacing-inherit: 16px;\u002d\u002dright-spacing-inherit: 16px","classNames":"pa bo","frame":{"border":{"width":"0 0 1px 0","style":"none none solid none","color":"transparent transparent var(\u002d\u002dwphave-site-color-background-contrast-3) transparent"}}},"content":"Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. Maecenas malesuada. Praesent congue erat at massa.","placeholder":"Text hier eingeben ..."} /-->
<!-- /wp:wphave/accordion-content -->
<!-- /wp:wphave/accordion-item -->

<!-- wp:wphave/accordion-item -->
<!-- wp:wphave/accordion-title {"wphave":{"frame":{"border":{"width":"0 0 1px 0","style":"none none solid none","color":"transparent transparent var(\u002d\u002dwphave-site-color-background-contrast-3) transparent"}},"styles":"\u002d\u002dpa: 11px 16px 10px 16px;\u002d\u002dpa-top: 11px;\u002d\u002dpa-right: 16px;\u002d\u002dpa-bottom: 10px;\u002d\u002dpa-left: 16px;\u002d\u002dbo-width: 0 0 1px 0;\u002d\u002dbo-style: none none solid none;\u002d\u002dbo-color: transparent transparent var(\u002d\u002dwphave-site-color-background-contrast-3) transparent;\u002d\u002dtx-co-act: var(\u002d\u002dwphave-site-color-accent)","classNames":"pa bo tx-co-act","dimensions":{"spacing":{"padding":"11px 16px 10px 16px"}},"stylesChild":"\u002d\u002dleft-spacing-inherit: 16px;\u002d\u002dright-spacing-inherit: 16px","active":{"text":{"colors":{"text":"var(\u002d\u002dwphave-site-color-accent)"}}},"settings":{"initialOpened":true}},"content":"\u003cstrong\u003eTitel 3\u003c/strong\u003e"} /-->

<!-- wp:wphave/accordion-content -->
<!-- wp:wphave/paragraph {"wphave":{"dimensions":{"spacing":{"padding":"16px 16px 16px 16px"}},"styles":"\u002d\u002dpa: 16px 16px 16px 16px;\u002d\u002dpa-top: 16px;\u002d\u002dpa-right: 16px;\u002d\u002dpa-bottom: 16px;\u002d\u002dpa-left: 16px","stylesChild":"\u002d\u002dleft-spacing-inherit: 16px;\u002d\u002dright-spacing-inherit: 16px","classNames":"pa"},"content":"Phasellus magna. In hac habitasse platea dictumst. Curabitur at lacus ac velit ornare lobortis. Curabitur a felis in nunc fringilla tristique. Morbi mattis ullamcorper velit. Phasellus gravida semper nisi.","placeholder":"Text hier eingeben ..."} /-->
<!-- /wp:wphave/accordion-content -->
<!-- /wp:wphave/accordion-item -->
<!-- /wp:wphave/accordion -->',
		];

		$patterns[] = [
			'tags' => ['content-toggling'],
			'title' => '',
			'viewportWidth' => 800,
			'content' => '<!-- wp:wphave/accordion {"wphave":{"settings":{"mode":"accordion","gap":"var(\u002d\u002dwphave-site-layout-gap)"},"styles":"\u002d\u002dgap: var(\u002d\u002dwphave-site-layout-gap)"}} -->
<!-- wp:wphave/accordion-item -->
<!-- wp:wphave/accordion-title {"wphave":{"frame":{"border":{"width":"1px 1px 1px 1px","style":"solid solid solid solid","color":"var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3)"},"corners":"36px 36px 36px 36px"},"styles":"\u002d\u002dpa: 14px 24px 14px 24px;\u002d\u002dpa-top: 14px;\u002d\u002dpa-right: 24px;\u002d\u002dpa-bottom: 14px;\u002d\u002dpa-left: 24px;\u002d\u002dofw: clip;\u002d\u002dbo-width: 1px 1px 1px 1px;\u002d\u002dbo-style: solid solid solid solid;\u002d\u002dbo-color: var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3);\u002d\u002dbr: 36px 36px 36px 36px;\u002d\u002dtx-co-act: var(\u002d\u002dwphave-site-color-accent)","classNames":"pa ofw bo br tx-co-act","dimensions":{"spacing":{"padding":"14px 24px 14px 24px"},"overflow":"clip"},"stylesChild":"\u002d\u002dleft-spacing-inherit: 24px;\u002d\u002dright-spacing-inherit: 24px","active":{"text":{"colors":{"text":"var(\u002d\u002dwphave-site-color-accent)"}}},"settings":{"initialOpened":true}},"content":"\u003cstrong\u003eTitel 1\u003c/strong\u003e"} /-->

<!-- wp:wphave/accordion-content -->
<!-- wp:wphave/paragraph {"wphave":{"dimensions":{"spacing":{"padding":"11px 11px 0 11px"}},"styles":"\u002d\u002dpa: 11px 11px 0 11px;\u002d\u002dpa-top: 11px;\u002d\u002dpa-right: 11px;\u002d\u002dpa-bottom: 0;\u002d\u002dpa-left: 11px","stylesChild":"\u002d\u002dleft-spacing-inherit: 11px;\u002d\u002dright-spacing-inherit: 11px","classNames":"pa"},"content":"Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum.","placeholder":"Text hier eingeben ..."} /-->
<!-- /wp:wphave/accordion-content -->
<!-- /wp:wphave/accordion-item -->

<!-- wp:wphave/accordion-item -->
<!-- wp:wphave/accordion-title {"wphave":{"frame":{"border":{"width":"1px 1px 1px 1px","style":"solid solid solid solid","color":"var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3)"},"corners":"36px 36px 36px 36px"},"styles":"\u002d\u002dpa: 14px 24px 14px 24px;\u002d\u002dpa-top: 14px;\u002d\u002dpa-right: 24px;\u002d\u002dpa-bottom: 14px;\u002d\u002dpa-left: 24px;\u002d\u002dofw: clip;\u002d\u002dbo-width: 1px 1px 1px 1px;\u002d\u002dbo-style: solid solid solid solid;\u002d\u002dbo-color: var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3);\u002d\u002dbr: 36px 36px 36px 36px;\u002d\u002dtx-co-act: var(\u002d\u002dwphave-site-color-accent)","classNames":"pa ofw bo br tx-co-act","dimensions":{"spacing":{"padding":"14px 24px 14px 24px"},"overflow":"clip"},"stylesChild":"\u002d\u002dleft-spacing-inherit: 24px;\u002d\u002dright-spacing-inherit: 24px","active":{"text":{"colors":{"text":"var(\u002d\u002dwphave-site-color-accent)"}}}},"content":"\u003cstrong\u003eTitel 2\u003c/strong\u003e"} /-->

<!-- wp:wphave/accordion-content -->
<!-- wp:wphave/paragraph {"wphave":{"dimensions":{"spacing":{"padding":"11px 11px 0 11px"}},"styles":"\u002d\u002dpa: 11px 11px 0 11px;\u002d\u002dpa-top: 11px;\u002d\u002dpa-right: 11px;\u002d\u002dpa-bottom: 0;\u002d\u002dpa-left: 11px","stylesChild":"\u002d\u002dleft-spacing-inherit: 11px;\u002d\u002dright-spacing-inherit: 11px","classNames":"pa"},"content":"Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. Maecenas malesuada. Praesent congue erat at massa.","placeholder":"Text hier eingeben ..."} /-->
<!-- /wp:wphave/accordion-content -->
<!-- /wp:wphave/accordion-item -->

<!-- wp:wphave/accordion-item -->
<!-- wp:wphave/accordion-title {"wphave":{"frame":{"border":{"width":"1px 1px 1px 1px","style":"solid solid solid solid","color":"var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3)"},"corners":"36px 36px 36px 36px"},"styles":"\u002d\u002dpa: 14px 24px 14px 24px;\u002d\u002dpa-top: 14px;\u002d\u002dpa-right: 24px;\u002d\u002dpa-bottom: 14px;\u002d\u002dpa-left: 24px;\u002d\u002dofw: clip;\u002d\u002dbo-width: 1px 1px 1px 1px;\u002d\u002dbo-style: solid solid solid solid;\u002d\u002dbo-color: var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3);\u002d\u002dbr: 36px 36px 36px 36px;\u002d\u002dtx-co-act: var(\u002d\u002dwphave-site-color-accent)","classNames":"pa ofw bo br tx-co-act","dimensions":{"spacing":{"padding":"14px 24px 14px 24px"},"overflow":"clip"},"stylesChild":"\u002d\u002dleft-spacing-inherit: 24px;\u002d\u002dright-spacing-inherit: 24px","active":{"text":{"colors":{"text":"var(\u002d\u002dwphave-site-color-accent)"}}}},"content":"\u003cstrong\u003eTitel 3\u003c/strong\u003e"} /-->

<!-- wp:wphave/accordion-content -->
<!-- wp:wphave/paragraph {"wphave":{"dimensions":{"spacing":{"padding":"11px 11px 0 11px"}},"styles":"\u002d\u002dpa: 11px 11px 0 11px;\u002d\u002dpa-top: 11px;\u002d\u002dpa-right: 11px;\u002d\u002dpa-bottom: 0;\u002d\u002dpa-left: 11px","stylesChild":"\u002d\u002dleft-spacing-inherit: 11px;\u002d\u002dright-spacing-inherit: 11px","classNames":"pa"},"content":"Phasellus magna. In hac habitasse platea dictumst. Curabitur at lacus ac velit ornare lobortis. Curabitur a felis in nunc fringilla tristique. Morbi mattis ullamcorper velit. Phasellus gravida semper nisi.","placeholder":"Text hier eingeben ..."} /-->
<!-- /wp:wphave/accordion-content -->
<!-- /wp:wphave/accordion-item -->
<!-- /wp:wphave/accordion -->',
		];

		$patterns[] = [
			'tags' => ['content-toggling'],
			'title' => '',
			'viewportWidth' => 800,
			'content' => '<!-- wp:wphave/tabs -->
<!-- wp:wphave/tabs-item -->
<!-- wp:wphave/tabs-title {"wphave":{"frame":{"border":{"width":"1px 1px 0 1px","style":"solid solid none solid","color":"var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3) transparent var(\u002d\u002dwphave-site-color-background-contrast-3)"}},"styles":"\u002d\u002dpa: 13px 16px 13px 16px;\u002d\u002dpa-top: 13px;\u002d\u002dpa-right: 16px;\u002d\u002dpa-bottom: 13px;\u002d\u002dpa-left: 16px;\u002d\u002dbo-width: 1px 1px 0 1px;\u002d\u002dbo-style: solid solid none solid;\u002d\u002dbo-color: var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3) transparent var(\u002d\u002dwphave-site-color-background-contrast-3);\u002d\u002dtx-co-act: var(\u002d\u002dwphave-site-color-accent)","classNames":"pa bo tx-co-act","dimensions":{"spacing":{"padding":"13px 16px 13px 16px"}},"stylesChild":"\u002d\u002dleft-spacing-inherit: 16px;\u002d\u002dright-spacing-inherit: 16px","active":{"text":{"colors":{"text":"var(\u002d\u002dwphave-site-color-accent)"}}}},"content":"Tab 1"} /-->

<!-- wp:wphave/tabs-content {"wphave":{"frame":{"border":{"width":"1px 1px 1px 1px","style":"solid solid solid solid","color":"var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3)"}},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-top) var(\u002d\u002dwphave-site-padding-right) var(\u002d\u002dwphave-site-padding-bottom) var(\u002d\u002dwphave-site-padding-left);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-top);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-right);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-bottom);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-left);\u002d\u002dbo-width: 1px 1px 1px 1px;\u002d\u002dbo-style: solid solid solid solid;\u002d\u002dbo-color: var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3)","classNames":"pa bo","dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-top) var(\u002d\u002dwphave-site-padding-right) var(\u002d\u002dwphave-site-padding-bottom) var(\u002d\u002dwphave-site-padding-left)"}},"stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-left);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-right)"}} -->
<!-- wp:wphave/paragraph {"content":"Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum.","placeholder":"Text hier eingeben ..."} /-->
<!-- /wp:wphave/tabs-content -->
<!-- /wp:wphave/tabs-item -->

<!-- wp:wphave/tabs-item -->
<!-- wp:wphave/tabs-title {"wphave":{"frame":{"border":{"width":"1px 1px 0 1px","style":"solid solid none solid","color":"var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3) transparent var(\u002d\u002dwphave-site-color-background-contrast-3)"}},"styles":"\u002d\u002dpa: 13px 16px 13px 16px;\u002d\u002dpa-top: 13px;\u002d\u002dpa-right: 16px;\u002d\u002dpa-bottom: 13px;\u002d\u002dpa-left: 16px;\u002d\u002dbo-width: 1px 1px 0 1px;\u002d\u002dbo-style: solid solid none solid;\u002d\u002dbo-color: var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3) transparent var(\u002d\u002dwphave-site-color-background-contrast-3);\u002d\u002dtx-co-act: var(\u002d\u002dwphave-site-color-accent)","classNames":"pa bo tx-co-act","dimensions":{"spacing":{"padding":"13px 16px 13px 16px"}},"stylesChild":"\u002d\u002dleft-spacing-inherit: 16px;\u002d\u002dright-spacing-inherit: 16px","active":{"text":{"colors":{"text":"var(\u002d\u002dwphave-site-color-accent)"}}}},"content":"Tab 2"} /-->

<!-- wp:wphave/tabs-content {"wphave":{"frame":{"border":{"width":"1px 1px 1px 1px","style":"solid solid solid solid","color":"var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3)"}},"styles":"\u002d\u002dpa: var(\u002d\u002dwphave-site-padding-top) var(\u002d\u002dwphave-site-padding-right) var(\u002d\u002dwphave-site-padding-bottom) var(\u002d\u002dwphave-site-padding-left);\u002d\u002dpa-top: var(\u002d\u002dwphave-site-padding-top);\u002d\u002dpa-right: var(\u002d\u002dwphave-site-padding-right);\u002d\u002dpa-bottom: var(\u002d\u002dwphave-site-padding-bottom);\u002d\u002dpa-left: var(\u002d\u002dwphave-site-padding-left);\u002d\u002dbo-width: 1px 1px 1px 1px;\u002d\u002dbo-style: solid solid solid solid;\u002d\u002dbo-color: var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3) var(\u002d\u002dwphave-site-color-background-contrast-3)","classNames":"pa bo","dimensions":{"spacing":{"padding":"var(\u002d\u002dwphave-site-padding-top) var(\u002d\u002dwphave-site-padding-right) var(\u002d\u002dwphave-site-padding-bottom) var(\u002d\u002dwphave-site-padding-left)"}},"stylesChild":"\u002d\u002dleft-spacing-inherit: var(\u002d\u002dwphave-site-padding-left);\u002d\u002dright-spacing-inherit: var(\u002d\u002dwphave-site-padding-right)"}} -->
<!-- wp:wphave/paragraph {"content":"Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. Maecenas malesuada. Praesent congue erat at massa.","placeholder":"Text hier eingeben ..."} /-->
<!-- /wp:wphave/tabs-content -->
<!-- /wp:wphave/tabs-item -->
<!-- /wp:wphave/tabs -->',
		];

		return $patterns;
	}
endif;
