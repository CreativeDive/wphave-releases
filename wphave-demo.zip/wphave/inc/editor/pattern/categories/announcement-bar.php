<?php

/**
 * Functions to group announcement bar block patterns.
 */

if ( ! function_exists( 'wphave_block_pattern_collection_announcement_bar' ) ) :

	function wphave_block_pattern_collection_announcement_bar( $args = array() ) {

        $content_width = isset( $args['width'] ) ? (int) $args['width'] : 1300;
        $slots = is_array( $args['slots'] ?? null ) ? $args['slots'] : array();
        $patterns = array();

        $patterns[] = array(
            'key' => 'announcement-bar-1',
            'tags' => array('announcement-bar'),
            'title' => __( 'Announcement Bar Inline Action', 'wphave' ),
            'keywords' => array('announcement', 'bar', 'notice', 'inline', 'action', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('section', 'cta', 'badge'),
                'layout' => array('split', 'stacked'),
                'width' => array('content-width'),
                'visual' => array('badge'),
                'content' => array('badges', 'body', 'actions'),
                'intent' => array('announcement', 'conversion-support'),
                'treatment' => array('framed', 'compact', 'soft-surface'),
                'description' => 'Compact announcement bar with a badge, short message and a single inline action.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"wi-in pa ofw ly ly-fl ly-fl-wp bg-co bg br ly-fl-m","dimensions":{"innerWidth":{"custom":"100%"},"overflow":"clip","spacing":{"padding":"var(--wphave-site-padding-s) var(--wphave-site-padding-m) var(--wphave-site-padding-s) var(--wphave-site-padding-m)"}},"styles":"--wi-in: 100%;--pa: var(--wphave-site-padding-s) var(--wphave-site-padding-m) var(--wphave-site-padding-s) var(--wphave-site-padding-m);--pa-top: var(--wphave-site-padding-s);--pa-right: var(--wphave-site-padding-m);--pa-bottom: var(--wphave-site-padding-s);--pa-left: var(--wphave-site-padding-m);--ofw: clip;--bg-co: var(--wphave-site-color-background-contrast-1);--br: var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners)","stylesChild":"--left-spacing-inherit: var(--wphave-site-padding-m);--right-spacing-inherit: var(--wphave-site-padding-m)","background":{"color":{"base":"var(--wphave-site-color-background-contrast-1)"}},"frame":{"corners":"var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners) var(--wphave-site-corners)"},"layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-gap-size-m)","gapY":"var(--wphave-site-gap-size-s)","flexWrap":"wrap","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"space-between"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-gap-size-m);--ly-row-gap: var(--wphave-site-gap-size-s);--ly-fl-wrap: wrap;--ly-fl-direction: row;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: space-between;--ly-m-column-gap: var(--wphave-site-gap-size-s);--ly-m-row-gap: var(--wphave-site-gap-size-s);--ly-m-fl-wrap: wrap;--ly-m-fl-direction: column;--ly-m-fl-itm: 0 1 auto;--ly-m-valign: start;--ly-m-halign: start","mobile":{"layout":{"flex":{"flexDirection":"column","alignHorizontal":"start"}}}}} -->
<!-- wp:wphave/group {"wphave":{"classNames":"ly ly-fl ly-fl-wp","layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-gap-size-s)","gapY":"var(--wphave-site-gap-size-xs)","flexWrap":"wrap","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-gap-size-s);--ly-row-gap: var(--wphave-site-gap-size-xs);--ly-fl-wrap: wrap;--ly-fl-direction: row;--ly-fl-itm: 0 1 auto;--ly-valign: center"}} -->
' . wphave_pattern_slot( 'eyebrow', $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-s' ), $slots ) . '
<!-- /wp:wphave/group -->

' . wphave_pattern_slot( 'actions.0.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'variant' => 'ghost', 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->'
        );

        $patterns[] = array(
            'key' => 'announcement-bar-2',
            'tags' => array('announcement-bar'),
            'title' => __( 'Announcement Bar Centered Notice', 'wphave' ),
            'keywords' => array('announcement', 'bar', 'notice', 'centered', 'pill', 'slots'),
            'viewportWidth' => $content_width,
            'ai' => array(
                'enabled' => true,
                'roles' => array('section', 'cta', 'badge'),
                'layout' => array('centered', 'stacked'),
                'width' => array('full-width'),
                'visual' => array('badge', 'color-background'),
                'content' => array('badges', 'body', 'actions'),
                'intent' => array('announcement', 'conversion-support'),
                'treatment' => array('strong-contrast', 'compact', 'minimal'),
                'description' => 'Full-width centered announcement strip with compact message and a subtle action.',
            ),
            'content' => '<!-- wp:wphave/group {"wphave":{"classNames":"bsz-full wi-in pa ofw ly ly-fl ly-fl-wp ly-fl-m bg-co bg txta tx-co","features":{"size":"full"},"dimensions":{"innerWidth":{"custom":"100%"},"overflow":"clip","spacing":{"padding":"var(--wphave-site-padding-s) var(--wphave-site-spacing) var(--wphave-site-padding-s) var(--wphave-site-spacing)"}},"styles":"--wi-in: 100%;--pa: var(--wphave-site-padding-s) var(--wphave-site-spacing) var(--wphave-site-padding-s) var(--wphave-site-spacing);--pa-top: var(--wphave-site-padding-s);--pa-right: var(--wphave-site-spacing);--pa-bottom: var(--wphave-site-padding-s);--pa-left: var(--wphave-site-spacing);--ofw: clip;--bg-co: var(--wphave-site-color-primary);--txta: center;--tx-co: var(--wphave-site-color-palette-white)","stylesChild":"--left-spacing-inherit: var(--wphave-site-spacing);--right-spacing-inherit: var(--wphave-site-spacing)","text":{"align":"center","colors":{"text":"var(--wphave-site-color-palette-white)"}},"background":{"color":{"base":"var(--wphave-site-color-primary)"}},"layout":{"type":"flex","flex":{"gapX":"var(--wphave-site-gap-size-s)","gapY":"var(--wphave-site-gap-size-xs)","flexWrap":"wrap","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"center"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-gap-size-s);--ly-row-gap: var(--wphave-site-gap-size-xs);--ly-fl-wrap: wrap;--ly-fl-direction: row;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: center;--ly-m-column-gap: var(--wphave-site-gap-size-xs);--ly-m-row-gap: var(--wphave-site-gap-size-xs);--ly-m-fl-wrap: wrap;--ly-m-fl-direction: row;--ly-m-fl-itm: 0 1 auto;--ly-m-valign: center;--ly-m-halign: center","mobile":{"layout":{"flex":{"alignHorizontal":"center"}}}}} -->
' . wphave_pattern_slot( 'eyebrow', array( 'attrs' => array( 'wphave' => array( 'background' => array( 'color' => array( 'base' => 'var(--wphave-site-color-palette-white)' ) ), 'styles' => '--wi: fit-content;--pa: var(--wphave-site-padding-xxs) var(--wphave-site-padding-xs) var(--wphave-site-padding-xxs) var(--wphave-site-padding-xs);--pa-top: var(--wphave-site-padding-xxs);--pa-right: var(--wphave-site-padding-xs);--pa-bottom: var(--wphave-site-padding-xxs);--pa-left: var(--wphave-site-padding-xs);--ofw: clip;--bg-co: var(--wphave-site-color-palette-white);--br: var(--wphave-site-corner-xs) var(--wphave-site-corner-xs) var(--wphave-site-corner-xs) var(--wphave-site-corner-xs)', 'text' => array( 'colors' => array( 'text' => 'var(--wphave-site-color-primary)' ) ) ) ) ), $slots ) . '

' . wphave_pattern_slot( 'body', array( 'size' => 'text-s' ), $slots ) . '

' . wphave_pattern_slot( 'actions.0.label', array( 'attrs' => array( 'wphave' => array( 'settings' => array( 'variant' => 'ghost', 'size' => '0' ), 'styles' => '--btn-size-scale: 0' ) ) ), $slots ) . '
<!-- /wp:wphave/group -->'
        );

        return $patterns;

	}

endif;
