<?php

/**
 * Identify Synced Patterns installed from the optional WPHAVE starter library.
 * The identifier is provenance only: installed Patterns remain user-owned and
 * are never overwritten automatically.
 */

function wphave_register_pattern_library_meta() {
	register_post_meta(
		'wp_block',
		'_wphave_pattern_library_key',
		array(
			'auth_callback' => static function( $allowed, $meta_key, $post_id, $user_id = 0 ) {
				// AUTHORIZATION INVARIANT: The internal library identity follows the exact
				// reusable block object. Generic edit_posts access cannot relabel another
				// user's pattern through the Core REST meta surface.
				$user_id = absint( $user_id ?: get_current_user_id() );

				return $user_id > 0 && user_can( $user_id, 'edit_post', absint( $post_id ) );
			},
			'sanitize_callback' => 'sanitize_key',
			'show_in_rest' => true,
			'single' => true,
			'type' => 'string',
		)
	);
}

add_action( 'init', 'wphave_register_pattern_library_meta' );

/**
 * Include files.
 */

if ( ! function_exists( 'wphave_block_pattern_width' ) ) :

	function wphave_block_pattern_width() {

		$content_width = wphave_data_get( 'site_globals', 'layout.width', WPHAVE_DEFAULT_WIDTH );

		return (int)$content_width;

	}

endif;

require_once __DIR__ . '/collection.php';
include ( __DIR__ . '/ai-taxonomy.php' );
include ( __DIR__ . '/text-variants.php' );
include ( __DIR__ . '/slots.php' );
include ( __DIR__ . '/register.php' );
require_once __DIR__ . '/starter/functions.php';
include ( __DIR__ . '/categories/tables.php' );
include ( __DIR__ . '/categories/footer.php' );
include ( __DIR__ . '/categories/header.php' );
include ( __DIR__ . '/categories/hero.php' );
include ( __DIR__ . '/categories/announcement-bar.php' );
include ( __DIR__ . '/categories/stats.php' );
include ( __DIR__ . '/categories/process.php' );
include ( __DIR__ . '/categories/testimonials.php' );
include ( __DIR__ . '/categories/feature-list-section.php' );
include ( __DIR__ . '/categories/gallery-sections.php' );
include ( __DIR__ . '/categories/mockup-sections.php' );
include ( __DIR__ . '/categories/icon-cards.php' );
include ( __DIR__ . '/categories/content-cards.php' );
include ( __DIR__ . '/categories/content-toggling.php' );
include ( __DIR__ . '/categories/pricing-cards.php' );
include ( __DIR__ . '/categories/content-sections.php' );
include ( __DIR__ . '/categories/link-pages.php' );
include ( __DIR__ . '/categories/call-to-actions.php' );
include ( __DIR__ . '/categories/coming-soon.php' );
