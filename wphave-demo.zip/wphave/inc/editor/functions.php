<?php

/**
 * Function to disallow the access to the WordPress FSE site editor, because FSE is not supported using the "wphave" plugin.
 */

include ( __DIR__ . '/enqueue.php' );
include ( __DIR__ . '/pattern/functions.php' );


/**
 * Function to disallow the access to the WordPress FSE site editor, because FSE is not supported using the "wphave" plugin.
 */

if ( ! function_exists( 'wphave_fse_site_editor_redirect' ) ) :

	function wphave_fse_site_editor_redirect() {

        if( wphave_use_fse() ) {
            return; // Stop here, if FSE is enabled
        }

		global $pagenow;

		if( $pagenow == 'site-editor.php' || isset( $_GET['post_type'] ) && $_GET['post_type'] === 'wp_template_part' ) {
			wp_safe_redirect(
				admin_url( 'admin.php?page=' . WPHAVE_ADMIN_PAGE_SLUG . '&screen=pages' )
			);
		  	exit;
		}

	}

endif;

add_action('init', 'wphave_fse_site_editor_redirect');


/**
 * Add a new block category to WP block selection.
 */

if ( ! function_exists( 'wphave_add_block_categories' ) ) :

	function wphave_add_block_categories( $block_categories, $editor_context ) {

		// ! Notice: Custom icon is added in "editor.js"
		$is_post_editor = isset( $editor_context->post ) ? $editor_context->post : '';

		if( $is_post_editor ) {
			array_push(
				$block_categories,
				array(
					'slug' => 'theme-woocommerce',
					'title' => __( 'Theme', 'wphave' ) . ' ' . __( 'WooCommerce', 'wphave' ),
				),
				array(
					'slug' => 'wphave-post-type',
					'title' => __( 'Post Type', 'wphave' ),
				),
				array(
					'slug' => 'wphave-taxonomy',
					'title' => __( 'Taxonomy & Terms', 'wphave' ),
				),
				array(
					'slug' => 'wphave-other',
					'title' =>  __( 'Other', 'wphave' ),
				)
			);
		}

        $leading_categories = array(
            array(
                'slug' => 'wphave-structure',
                'title' => __( 'Structure', 'wphave' ),
            ),
            array(
                'slug' => 'wphave-loop',
                'title' => __( 'Loop', 'wphave' ),
            ),
            array(
                'slug' => 'wphave-meta',
                'title' => __( 'Meta', 'wphave' ),
            ),
            array(
                'slug' => 'wphave-woocommerce-template',
                'title' => __( 'Template', 'wphave' ),
            ),
            array(
                'slug' => 'wphave-add-on',
                'title' => __( 'Add-Ons', 'wphave' ),
            ),
            array(
                'slug' => 'wphave-text',
                'title' =>  __( 'Text', 'wphave' ),
            ),
            array(
                'slug' => 'wphave-layout',
                'title' =>  __( 'Layout', 'wphave' ),
            ),
            array(
                'slug' => 'wphave-elements',
                'title' =>  __( 'Elements', 'wphave' ),
            ),
            array(
                'slug' => 'wphave-media',
                'title' =>  __( 'Media', 'wphave' ),
            ),
            array(
                'slug' => 'wphave-form',
                'title' =>  __( 'Form', 'wphave' ),
            ),
            array(
                'slug' => 'wphave-content-toggling',
                'title' =>  __( 'Content Toggling', 'wphave' ),
            ),
            array(
                'slug' => 'wphave-site',
                'title' =>  __( 'Site', 'wphave' ),
            ),
            array(
                'slug' => 'wphave-misc',
                'title' =>  __( 'Misc', 'wphave' ),
            ),
            array(
                'slug' => 'wphave-code',
                'title' =>  __( 'Code', 'wphave' ),
            ),
        );

        foreach( array_reverse( $leading_categories ) as $leading_category ) {
            array_unshift( $block_categories, $leading_category );
        }

		return $block_categories;

	}

endif;

add_filter( 'block_categories_all', 'wphave_add_block_categories', PHP_INT_MAX, 2 );


/**
 * Filter to manage global block editor settings.
 */

if ( ! function_exists( 'wphave_block_editor_settings' ) ) :

	function wphave_block_editor_settings( $settings, $editor_context ) {

        if( wphave_use_fse() ) {
            return $settings; // Return unchanged, if FSE is enabled
        }

        if( ! wphave_data_get( 'site_settings', 'editor.settings.openverse' ) ) {
            // Disabled by default
            $settings['enableOpenverseMediaCategory'] = false;
        }

        return $settings;

    }

endif;

add_filter( 'block_editor_settings_all', 'wphave_block_editor_settings', 10, 2 );


/**
 * Disable the automatic search for blocks in the WordPress block directory while searching for blocks in the inserter.
 */

if ( ! function_exists( 'wphave_disable_block_directory' ) ) :

	function wphave_disable_block_directory() {

        if( wphave_use_fse() ) {
            return; // Stop here, if FSE is enabled
        }

        // Disabled by default
		if( wphave_data_get( 'site_settings', 'editor.settings.block_directory' ) ) {
			// Stop here, if the block directory is manually enabled
			return;
		}

		// Otherwise we disable automatic search in the WordPress block directory
		remove_action( 'enqueue_block_editor_assets', 'wp_enqueue_editor_block_directory_assets' );
		remove_action( 'enqueue_block_editor_assets', 'gutenberg_enqueue_block_editor_assets_block_directory' );

	}

endif;

add_action( 'admin_init', 'wphave_disable_block_directory' );


/**
 * Resolve block types disabled globally through WPHAVE site settings.
 *
	 * OWNERSHIP INVARIANT: The server-side policy is authoritative even before the editor UI loads.
 * `src/block-editor/hiddenBlockTypes.js` additionally mirrors this policy into
 * WordPress Core preferences because Core's block manager reads its visibility
 * state there. That bridge preserves separately owned personal exclusions.
 *
 * @param array $visibility Block visibility settings grouped by namespace.
 * @return array Disabled block names.
 */

if ( ! function_exists( 'wphave_resolve_globally_hidden_block_types' ) ) :

	function wphave_resolve_globally_hidden_block_types( $visibility ) {

		$hidden_block_types = array();

		foreach( array( 'core', 'wphave', 'woocommerce' ) as $group ) {
			foreach( (array) ( $visibility[$group] ?? array() ) as $block_name => $is_enabled ) {
				if( ! $is_enabled ) {
					$hidden_block_types[] = $block_name;
				}
			}
		}

		return array_values( array_unique( $hidden_block_types ) );

	}

endif;


/**
 * Get the global WPHAVE block visibility policy.
 *
 * @return array Disabled block names.
 */

if ( ! function_exists( 'wphave_get_globally_hidden_block_types' ) ) :

	function wphave_get_globally_hidden_block_types() {

		$visibility = wphave_data_get( 'site_settings', 'editor.blocks', array() );

		return wphave_resolve_globally_hidden_block_types( is_array( $visibility ) ? $visibility : array() );

	}

endif;


/**
 * Intersect registered blocks with all insertion restrictions.
 *
 * @param array      $registered_blocks Registered block type objects.
 * @param array|bool $allowed_block_types Restrictions established by previous filters.
 * @param string     $post_type Current post type.
 * @param array      $globally_hidden Block names disabled through WPHAVE.
 * @return array|bool Effective allowed block types.
 */

if ( ! function_exists( 'wphave_filter_allowed_registered_blocks' ) ) :

	function wphave_filter_allowed_registered_blocks( $registered_blocks, $allowed_block_types, $post_type, $globally_hidden ) {

		if( false === $allowed_block_types ) {
			return false;
		}

		$previously_allowed = is_array( $allowed_block_types ) ? array_fill_keys( $allowed_block_types, true ) : null;
		$globally_hidden = array_fill_keys( $globally_hidden, true );
		$blocks_allowed = array();

		foreach( $registered_blocks as $registered_block ) {
			$is_structural_child = array_filter( array_merge( (array) ( $registered_block->parent ?? array() ), (array) ( $registered_block->ancestor ?? array() ) ), static function( $owner ) {
					return is_string( $owner ) && '' !== $owner;
				} );
			$is_wphave_addon = str_starts_with( (string) $registered_block->name, 'wphave/' )
				&& 'wphave-add-on' === (string) ( $registered_block->category ?? '' );

			if( $is_structural_child || $is_wphave_addon ) {
				unset( $globally_hidden[$registered_block->name] );
			}

			if( is_array( $previously_allowed ) && ! isset( $previously_allowed[$registered_block->name] ) ) {
				continue;
			}

			$supported_post_types = $registered_block->supports['postTypes'] ?? array();

			if(
				! isset( $globally_hidden[$registered_block->name] ) &&
				( ! $supported_post_types || in_array( $post_type, $supported_post_types, true ) )
			) {
				$blocks_allowed[] = $registered_block->name;
			}
		}

		return $blocks_allowed;

	}

endif;


/**
 * Limit block insertion without modifying personal WordPress preferences.
 *
 * The effective set is the intersection of restrictions established by
 * previous filters, WPHAVE post-type support and the global WPHAVE site policy.
 * Existing blocks remain renderable; this filter controls inserter availability.
 */

if ( ! function_exists( 'wphave_allowed_blocks_by_post_type' ) ) :

	function wphave_allowed_blocks_by_post_type( $allowed_block_types, $block_editor_context ) {

        $is_wphave_page = WPHAVE_Admin_Interface::is_app_page();

        if( $is_wphave_page ) {
            // Bail early! In our app we can't work with serverside allowed block restrictions.
            // The custom inserter applies the same site policy locally.
            return $allowed_block_types;
        }

		// Get all registered blocks.
		$reg_blocks = WP_Block_Type_Registry::get_instance()->get_all_registered();

		// Get the current post type
		$postType = $block_editor_context->post->post_type ?? '';

		return wphave_filter_allowed_registered_blocks(
			$reg_blocks,
			$allowed_block_types,
			$postType,
			wphave_get_globally_hidden_block_types()
		);

	}

endif;

// Run after other policies so WPHAVE intersects their result instead of
// accidentally re-enabling a block rejected by an earlier filter.
add_filter( 'allowed_block_types_all', 'wphave_allowed_blocks_by_post_type', PHP_INT_MAX, 2 );
