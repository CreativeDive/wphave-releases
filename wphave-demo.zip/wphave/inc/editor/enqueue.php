<?php

/**
 * Whether the current editor document has a live React Global Styles owner.
 *
 * Link Style interaction rules must come from exactly one owner. The live
 * owner replaces its stylesheet when a draft changes, while server-injected
 * rules cannot be removed when the user selects Default.
 *
 * @return bool
 */

if ( ! function_exists( 'wphave_editor_uses_live_global_styles' ) ) :

	function wphave_editor_uses_live_global_styles() {
		if ( WPHAVE_Admin_Interface::is_app_page() ) {
			return true;
		}

		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

		return $screen && 'post' === $screen->base && $screen->is_block_editor();
	}

endif;


/**
 * Load wphave JS/CSS assets in WP block editor only.
 */

if ( ! function_exists( 'wphave_block_editor_assets' ) ) :

    function wphave_block_editor_assets() {

        if( ! WPHAVE_Admin_Interface::is_app_page() ) {
            wp_enqueue_script('wphave-block-editor');

            $screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

            // Core-editor adapters are intentionally isolated from both the
            // WPHAVE app and the Site Editor. Generic block behavior remains
            // available through wphave-block-editor in every editor context.
            if( $screen && 'post' === $screen->base && $screen->is_block_editor() ) {
                wp_enqueue_script('wphave-core-post-editor');
                wp_enqueue_style('wphave-core-post-editor');
            }
        }

        $global_variables = WPHAVE_Global_Styles::compose_global_styles_string([], array(
            'global_vars' => false, // <-- Already loaded via "block_editor_settings_all" filter
            'color_mode_vars' => false,
            'color_context_vars' => false,
			'include_link_styles' => ! wphave_editor_uses_live_global_styles(),
        ));

        wp_add_inline_style( 'wphave-block-editor', $global_variables );

    }

endif;

if( is_admin() ) {
	add_action( 'enqueue_block_assets', 'wphave_block_editor_assets' );
}


/**
 * We use the "block_editor_settings_all" filter to load our global styles inside the block editor.
 */

if ( ! function_exists( 'wphave_block_editor_global_styles' ) ) :

	function wphave_block_editor_global_styles( $settings ) {

        // Get our global styles
        $global_variables = WPHAVE_Global_Styles::compose_global_styles_string( [], array(
			'include_link_styles' => ! wphave_editor_uses_live_global_styles(),
		) );

        $global_styles = array(
            'css' => $global_variables,
            'isGlobalStyles' => false, // <-- With "true" set, these styles not loading in the editor !
            '__unstableType' => 'presets',
        );

        // ! Note: It's important to put our styles at the very beginning of the array,
        // otherwise the core styles will overwrite ours in some cases
        array_unshift( $settings['styles'], $global_styles );

		$duotone_filters = wphave_svg_duotones_filter('all');

		if( $duotone_filters ) {
			$svg_assets = array(
				'assets' => $duotone_filters,
				'isGlobalStyles' => false,
				'__unstableType' => 'svgs',
			);

			array_unshift( $settings['styles'], $svg_assets );
		}

		/*$clippaths = wphave_print_clip_path_shapes();

        $svg_assets = array(
            'assets' => $clippaths,
            'isGlobalStyles' => false,
            '__unstableType' => 'svgs',
        );

        array_unshift( $settings['styles'], $svg_assets );*/


        return $settings;

    }

endif;

add_filter( 'block_editor_settings_all', 'wphave_block_editor_global_styles' );


/**
 * Enqueue the additional assets required by WPHAVE editor screens.
 */

if ( ! function_exists( 'wphave_block_editor_additional_assets' ) ) :

	function wphave_block_editor_additional_assets() {

        global $pagenow;
        $is_wphave_block_ui_overview_page = $pagenow == 'admin.php' && isset( $_GET['page'] ) && $_GET['page'] === 'wphave-dev-block-ui';

		if( ! WPHAVE_Admin_Interface::is_app_page() && ! wphave_is_block_editor() && ! $is_wphave_block_ui_overview_page ) {
			return;
		}

        $clippaths = wphave_print_clip_path_shapes();

        echo wp_kses_post( $clippaths );

	}

endif;

add_action('admin_footer', 'wphave_block_editor_additional_assets');
