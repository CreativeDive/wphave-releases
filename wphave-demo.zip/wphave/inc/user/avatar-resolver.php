<?php

/**
 * Shared Gravatar policy for WordPress and WPHAVE avatar output.
 *
 * WordPress avatar URLs are usually loaded by the visitor's browser. Returning
 * a remote URL therefore discloses request metadata to the avatar provider and
 * can expose an email-derived identifier in REST or preloaded application data.
 * All WPHAVE consumers must use this resolver instead of calling
 * get_avatar_url() directly.
 */

if (!defined('ABSPATH')) {
	exit();
}

if (!class_exists('WPHAVE_Avatar_Resolver')):
	class WPHAVE_Avatar_Resolver {
		private static ?string $scope = null;

		/** Explicit callers retain their policy even inside REST or editor rendering. */
		public static function with_scope(string $scope, callable $callback) {
			$previous = self::$scope;
			self::$scope = $scope;
			try {
				return $callback();
			} finally {
				self::$scope = $previous;
			}
		}

		private static function current_gravatar_enabled(): bool {
			$scope = self::$scope ?? (is_admin() ? 'interface' : 'frontend');
			return $scope === 'interface'
				? self::gravatar_enabled()
				: self::frontend_gravatar_enabled();
		}

		public static function filter_url($url) {
			return is_string($url) &&
				!self::current_gravatar_enabled() &&
				self::is_gravatar_url($url)
				? ''
				: $url;
		}

		/** Also covers pre_get_avatar_data short circuits and direct data consumers. */
		public static function filter_data($args) {
			if (is_array($args) && isset($args['url'])) {
				$args['url'] = self::filter_url($args['url']);
				if ($args['url'] === '') {
					$args['found_avatar'] = false;
				}
			}
			return $args;
		}

		/** pre_get_avatar can bypass URL resolution; enforce the policy on final markup. */
		public static function filter_markup($html) {
			if (!is_string($html) || $html === '' || self::current_gravatar_enabled()) {
				return $html;
			}
			$processor = new WP_HTML_Tag_Processor($html);
			while ($processor->next_tag()) {
				foreach (['src', 'srcset', 'data-src', 'data-srcset'] as $attribute) {
					$value = $processor->get_attribute($attribute);
					if (!is_string($value)) {
						continue;
					}
					foreach (preg_split('/[\s,]+/', $value) as $url) {
						if (self::is_gravatar_url($url)) {
							return '';
						}
					}
				}
			}
			return $html;
		}

		/**
		 * Resolve an avatar URL according to the WPHAVE interface policy.
		 *
		 * Only Gravatar URLs are controlled by this setting. Local avatars and URLs
		 * supplied by other avatar integrations remain unchanged. The empty string
		 * is the stable contract for WPHAVE UI consumers to render their existing
		 * neutral placeholder.
		 *
		 * @param mixed $identity User ID, email, WP_User, WP_Post or WP_Comment.
		 * @param array $args WordPress avatar arguments.
		 * @return string Allowed avatar URL or an empty string.
		 */

		public static function get_url($identity, array $args = []): string {
			$url = self::with_scope('interface', static function () use ($identity, $args) {
				return get_avatar_url($identity, $args);
			});
			$url = is_string($url) ? $url : '';

			if ($url === '' || self::gravatar_enabled() || !self::is_gravatar_url($url)) {
				return $url;
			}

			return '';
		}

		/**
		 * Determine whether the WPHAVE interface may load Gravatar images.
		 *
		 * Gravatar is disabled by default. The setting belongs to Experience >
		 * Interface and does not modify WordPress' global show_avatars option.
		 *
		 * @return bool
		 */

		public static function gravatar_enabled(): bool {
			$enabled = function_exists('wphave_data_get')
				? (bool) wphave_data_get(
					'site_settings',
					'advanced.ui.avatars.gravatarEnabled',
					false,
				)
				: false;

			return (bool) apply_filters('wphave_ui_gravatar_enabled', $enabled);
		}

		/**
		 * Determine whether WPHAVE renders colorful initial placeholders.
		 *
		 * @return bool
		 */

		public static function colorful_placeholders_enabled(): bool {
			$enabled = function_exists('wphave_data_get')
				? (bool) wphave_data_get(
					'site_settings',
					'advanced.ui.avatars.colorfulPlaceholdersEnabled',
					true,
				)
				: true;

			return (bool) apply_filters('wphave_ui_colorful_avatar_placeholders_enabled', $enabled);
		}

		/**
		 * Determine whether public WPHAVE blocks may load Gravatar images.
		 *
		 * This policy is deliberately independent from the administration-interface
		 * preference and from WordPress' global show_avatars option.
		 *
		 * @return bool
		 */

		public static function frontend_gravatar_enabled(): bool {
			$enabled = function_exists('wphave_data_get')
				? (bool) wphave_data_get(
					'site_settings',
					'advanced.privacy.avatars.gravatarEnabled',
					false,
				)
				: false;

			return (bool) apply_filters('wphave_frontend_gravatar_enabled', $enabled);
		}

		/**
		 * Check whether a generated avatar URL is allowed in public WPHAVE output.
		 *
		 * @param string $url Generated avatar URL.
		 * @return bool
		 */

		public static function frontend_url_allowed(string $url): bool {
			return self::frontend_gravatar_enabled() || !self::is_gravatar_url($url);
		}

		/**
		 * Check whether a URL targets Gravatar.
		 *
		 * @param string $url Avatar URL.
		 * @return bool
		 */

		private static function is_gravatar_url(string $url): bool {
			$host = wp_parse_url($url, PHP_URL_HOST);
			$host = is_string($host) ? strtolower(rtrim($host, '.')) : '';

			return $host === 'gravatar.com' || substr($host, -13) === '.gravatar.com';
		}
	}
endif;

/**
 * Resolve an avatar URL for WPHAVE output.
 *
 * @param mixed $identity User identity supported by WordPress avatars.
 * @param array $args WordPress avatar arguments.
 * @return string
 */

function wphave_get_avatar_url($identity, array $args = []): string {
	return WPHAVE_Avatar_Resolver::get_url($identity, $args);
}

// Run after local-avatar providers and ordinary third-party avatar filters.
add_filter('get_avatar_url', [WPHAVE_Avatar_Resolver::class, 'filter_url'], PHP_INT_MAX);
add_filter('get_avatar_data', [WPHAVE_Avatar_Resolver::class, 'filter_data'], PHP_INT_MAX);
add_filter('get_avatar', [WPHAVE_Avatar_Resolver::class, 'filter_markup'], PHP_INT_MAX);
