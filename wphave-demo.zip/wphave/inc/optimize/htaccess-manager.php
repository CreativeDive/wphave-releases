<?php

/**
 * Provides a centralized interface for managing the WordPress `.htaccess` file.
 *
 * Handles existence and permission checks, marker-scoped modifications, and
 * generation of browser-cache and compression rules.
 *
 * All changes are restricted to explicitly managed `BEGIN` and `END` blocks.
 * Unrelated directives and the WordPress core block must never be overwritten.
 */

if (!defined('ABSPATH')) {
	exit();
}

require_once wphave_dir() . 'inc/features/security/atomic-file.php';
require_once wphave_dir() . 'inc/features/security/file-identity.php';
require_once wphave_dir() . 'inc/features/security/conditional-file.php';
require_once wphave_dir() . 'inc/features/security/file-mutex.php';

class WPHAVE_Htaccess_Manager {
	private $path;

	/**
	 * Initialize the managed `.htaccess` path.
	 *
	 * @param string|null $path Explicit file path, or null for the WordPress root.
	 */

	public function __construct($path = null) {
		$this->path = is_string($path) && $path !== '' ? $path : ABSPATH . '.htaccess';
	}

	/**
	 * Determine whether the root `.htaccess` file exists.
	 *
	 * @return bool Whether the file exists.
	 */

	public function exists() {
		return file_exists($this->path);
	}

	/**
	 * Determine whether automatic updates may write to `.htaccess`.
	 *
	 * @return bool Whether the file is writable.
	 */

	public function is_writable() {
		return !is_link($this->path) && is_writable($this->path);
	}

	/**
	 * Observes one absent or coherent regular-file revision.
	 *
	 * @return array<string, mixed>|false
	 */

	private function observe() {
		if (!file_exists($this->path) && !is_link($this->path)) {
			return [
				'existed' => false,
				'contents' => '',
				'checksum' => '',
				'permissions' => 0644,
			];
		}

		try {
			$identity = WPHAVE_Security_File_Identity::read(
				$this->path,
				__('The .htaccess file changed while it was being read.', 'wphave'),
			);
		} catch (RuntimeException $error) {
			return false;
		}

		$identity['existed'] = true;

		return $identity;
	}

	/**
	 * Publishes a new revision against an absent or exact observed target.
	 */

	private function publish(array $original, string $contents) {
		do_action('wphave_htaccess_before_publication', $this->path, $original, $contents);
		$error_message = __(
			'The .htaccess file changed before the managed revision could be published.',
			'wphave',
		);

		try {
			if ($original['existed']) {
				return WPHAVE_Security_Conditional_File::write_if_matches(
					$this->path,
					$original['checksum'],
					$contents,
					$error_message,
					$original['permissions'],
				);
			}

			return WPHAVE_Security_Conditional_File::write_new(
				$this->path,
				$contents,
				$error_message,
				$original['permissions'],
			);
		} catch (RuntimeException $error) {
			return false;
		}
	}

	/**
	 * Restores only while the exact WPHAVE-published revision remains live.
	 */

	private function rollback(array $original, string $published_checksum): bool {
		$error_message = __('The managed .htaccess revision changed before rollback.', 'wphave');

		try {
			if ($original['existed']) {
				WPHAVE_Security_Conditional_File::write_if_matches(
					$this->path,
					$published_checksum,
					$original['contents'],
					$error_message,
					$original['permissions'],
				);
			} else {
				WPHAVE_Security_Conditional_File::remove_if_matches(
					$this->path,
					$published_checksum,
					$error_message,
				);
			}
		} catch (RuntimeException $error) {
			return false;
		}

		return true;
	}

	/**
	 * Serializes WPHAVE writers without assuming external writers use the mutex.
	 */

	private function with_mutex(callable $callback) {
		$lock_path =
			trailingslashit(get_temp_dir()) .
			'wphave-htaccess-' .
			hash('sha256', wp_normalize_path($this->path)) .
			'.lock';

		try {
			return WPHAVE_Security_File_Mutex::run($lock_path, $callback);
		} catch (WPHAVE_Security_File_Mutex_Exception $error) {
			return false;
		}
	}

	/**
	 * Read the complete `.htaccess` file.
	 *
	 * @return string|false File contents, or false when unavailable.
	 */

	public function get_content() {
		$observation = $this->observe();

		return is_array($observation) && $observation['existed'] ? $observation['contents'] : false;
	}

	/**
	 * Create a missing `.htaccess` file with the default WordPress rules.
	 *
	 * Preserving the core rewrite block prevents broken pretty permalinks on
	 * fresh installations. Existing files are never replaced.
	 *
	 * @return bool Whether the file exists or was created successfully.
	 */

	public function create_if_missing() {
		return $this->with_mutex(function () {
			$original = $this->observe();
			if (!is_array($original)) {
				return false;
			}
			if ($original['existed']) {
				return true;
			}

			// SECURITY INVARIANT: First server-configuration publication is create-only.
			return false !== $this->publish($original, $this->get_default_wp_htaccess() . "\n\n");
		});
	}

	/**
	 * Create the root file and remove it again when the public site fails.
	 *
	 * @param string $verification_url Public site URL.
	 * @return bool Whether the new file was created and verified.
	 */

	public function create_root_if_missing_verified($verification_url) {
		return $this->with_mutex(function () use ($verification_url) {
			$original = $this->observe();
			if (!is_array($original) || $original['existed']) {
				return false;
			}

			$published = $this->publish($original, $this->get_default_wp_htaccess() . "\n\n");
			if (false === $published) {
				return false;
			}

			if ($this->verify_server_response($verification_url)) {
				return true;
			}

			// SECURITY INVARIANT: Failed verification removes only the exact revision
			// created by this request. A later file at the path is preserved.
			$this->rollback($original, $published);

			return false;
		});
	}

	/**
	 * Create an empty managed file without adding WordPress root rewrite rules.
	 *
	 * This is used for directory-local protection such as the uploads folder.
	 * Existing files are preserved unchanged.
	 *
	 * @return bool Whether the file exists or was created successfully.
	 */

	public function create_empty_if_missing() {
		return $this->with_mutex(function () {
			$original = $this->observe();

			if (!is_array($original)) {
				return false;
			}

			if ($original['existed']) {
				return true;
			}

			return false !== $this->publish($original, '');
		});
	}

	/**
	 * Provide existence, writability, and path diagnostics for the UI.
	 *
	 * @return array File status data.
	 */

	public function get_status() {
		return [
			'exists' => $this->exists(),
			'writable' => $this->exists() ? $this->is_writable() : false,
			'path' => $this->path,
		];
	}

	/**
	 * Insert or replace a marker-scoped block in `.htaccess`.
	 *
	 * Existing `# BEGIN {name}` and `# END {name}` content is replaced; a
	 * missing block is appended. Publication requires the observed file digest.
	 *
	 * @param string $name Managed block name.
	 * @param string $content Block contents.
	 * @return bool Whether the block already matched or was written successfully.
	 */

	public function upsert_block($name, $content) {
		return $this->mutate_block($name, $content);
	}

	/**
	 * Remove a marker-scoped block without changing unrelated directives.
	 *
	 * Publication requires the exact regular-file revision used for parsing.
	 *
	 * @param string $name Managed block name.
	 * @return bool Whether the block was absent or removed successfully.
	 */

	public function remove_block($name) {
		return $this->mutate_block($name, null);
	}

	/**
	 * Applies one marker transformation against a coherent observed revision.
	 */

	private function mutate_block(string $name, ?string $content): bool {
		return $this->with_mutex(function () use ($name, $content): bool {
			$original = $this->observe();
			if (!is_array($original) || !$original['existed'] || !$this->is_writable()) {
				return false;
			}

			$updated = $this->transform_block($original['contents'], $name, $content);
			if (!is_string($updated)) {
				return false;
			}

			if ($original['contents'] === $updated) {
				return true;
			}

			// SECURITY INVARIANT: Marker parsing and replacement authorize mutation of
			// only the exact regular-file revision from which the new contents derive.
			return false !== $this->publish($original, $updated);
		});
	}

	/**
	 * Produces marker-scoped contents without touching the filesystem.
	 */

	private function transform_block(string $data, string $name, ?string $content) {
		$start = "# BEGIN {$name}";
		$end = "# END {$name}";

		if (null === $content) {
			$updated = preg_replace(
				"/\n?" . preg_quote($start, '/') . '.*?' . preg_quote($end, '/') . "\n?/s",
				'',
				$data,
			);

			return is_string($updated) ? $updated : false;
		}

		$block = $start . "\n" . trim($content) . "\n" . $end;
		$pattern = '/' . preg_quote($start, '/') . '.*?' . preg_quote($end, '/') . '/s';
		$updated = preg_match($pattern, $data)
			? preg_replace($pattern, $block, $data)
			: rtrim($data) . "\n\n" . $block . "\n";

		return is_string($updated) ? $updated : false;
	}

	/**
	 * Apply or remove a marker block and verify that the web server remains usable.
	 *
	 * The exact previous file state is restored when the write fails, the loopback
	 * request cannot be completed, or the server responds with a 5xx status. A file
	 * created exclusively for the attempted change is removed during rollback.
	 *
	 * @param string      $name Marker name.
	 * @param string|null $content New block content, or null to remove the block.
	 * @param string      $verification_url Public URL handled by this `.htaccess` file.
	 * @param bool        $create_if_missing Whether an empty file may be created.
	 * @return bool Whether the change was applied and verified.
	 */

	public function update_block_verified(
		$name,
		$content,
		$verification_url,
		$create_if_missing = false,
	) {
		return $this->with_mutex(function () use (
			$name,
			$content,
			$verification_url,
			$create_if_missing,
		): bool {
			$original = $this->observe();
			if (!is_array($original)) {
				return false;
			}

			if (!$original['existed'] && !$create_if_missing) {
				return false;
			}

			if ($original['existed'] && !$this->is_writable()) {
				return false;
			}

			$updated = $this->transform_block($original['contents'], $name, $content);
			if (!is_string($updated)) {
				return false;
			}

			if ($original['existed'] && $original['contents'] === $updated) {
				return true;
			}

			$published = $this->publish($original, $updated);
			if (false === $published) {
				return false;
			}

			if ($this->verify_server_response($verification_url)) {
				return true;
			}

			// SECURITY INVARIANT: Health-check rollback is authorized by the digest
			// published above, never by the pathname or the stale pre-write snapshot alone.
			$this->rollback($original, $published);

			return false;
		});
	}

	/**
	 * Verify that a changed server configuration does not produce an error response.
	 *
	 * Network failures are treated as unsafe because the new configuration could not
	 * be proven healthy. Redirects and ordinary 4xx responses are acceptable because
	 * protected or missing paths commonly return those statuses.
	 *
	 * @param string $url Public verification URL.
	 * @return bool Whether the server returned a non-5xx HTTP response.
	 */

	private function verify_server_response($url) {
		$override = apply_filters('wphave_htaccess_verification_result', null, $url, $this->path);
		if (is_bool($override)) {
			return $override;
		}

		if (!wp_http_validate_url($url)) {
			return false;
		}

		$response = wp_safe_remote_get(
			add_query_arg('wphave_htaccess_check', wp_generate_uuid4(), $url),
			[
				'timeout' => 8,
				'redirection' => 0,
				'limit_response_size' => 1024,
				'sslverify' => apply_filters('https_local_ssl_verify', false, $url),
				'headers' => [
					'Cache-Control' => 'no-cache, no-store',
				],
			],
		);

		if (is_wp_error($response)) {
			return false;
		}

		$status = (int) wp_remote_retrieve_response_code($response);

		return $status >= 200 && $status < 500;
	}

	/**
	 * Determine whether a managed block exists.
	 *
	 * @param string $name Managed block name.
	 * @return bool Whether the opening marker exists.
	 */

	public function has_block($name) {
		if (!$this->exists()) {
			return false;
		}

		$data = $this->get_content();
		if (!is_string($data)) {
			return false;
		}

		return strpos($data, "# BEGIN {$name}") !== false;
	}

	/**
	 * Read the inner content of a managed block.
	 *
	 * @param string $name Managed block name.
	 * @return string Block content, or an empty string when it is unavailable.
	 */

	public function get_block($name) {
		if (!$this->exists()) {
			return '';
		}

		$data = $this->get_content();
		if (!is_string($data)) {
			return '';
		}

		$pattern = "/# BEGIN {$name}\n(.*?)\n# END {$name}/s";

		if (preg_match($pattern, $data, $matches)) {
			return trim($matches[1]);
		}

		return '';
	}

	/**
	 * Generate managed `.htaccess` rules from performance and security settings.
	 *
	 * @param array $settings Performance settings.
	 * @return string Generated rule blocks.
	 */

	public function generate($settings = []) {
		$blocks = [];

		// Asset Cache
		if (!empty($settings['asset_cache']['enabled'])) {
			$ttl = $this->map_ttl($settings['asset_cache']['ttl'] ?? '1_year');

			$blocks[] = $this->generate_cache_block($ttl);

			$gzip = $settings['asset_cache']['gzip'] ?? false;

			if ($gzip) {
				$blocks[] = $this->generate_gzip_block();
			}
		}

		if (!empty($settings['security']['disable_directory_listing'])) {
			$blocks[] = "<IfModule mod_autoindex.c>\nOptions -Indexes\n</IfModule>";
		}

		if (!empty($settings['security']['protect_sensitive_files'])) {
			$blocks[] =
				"<FilesMatch \"^(?:wp-config\\.php(?:\\..+)?|\\.env(?:\\..*)?|\\.htaccess|\\.htpasswd|debug\\.log|error_log|php\\.ini|\\.user\\.ini)$\">\nRequire all denied\n</FilesMatch>";
		}

		return implode("\n\n", $blocks);
	}

	/**
	 * Convert a duration in seconds to an Apache expiration expression.
	 *
	 * @param int $seconds Cache lifetime in seconds.
	 * @return string Apache-compatible duration.
	 */

	private function ttl_to_apache($seconds) {
		if ($seconds >= 31536000) {
			return '1 year';
		}

		if ($seconds >= 2592000) {
			return '1 month';
		}

		if ($seconds >= 604800) {
			return '1 week';
		}

		if ($seconds >= 86400) {
			return '1 day';
		}

		if ($seconds >= 3600) {
			return '1 hour';
		}

		return $seconds . ' seconds';
	}

	/**
	 * Map a configured cache-lifetime key to seconds.
	 *
	 * @param string $ttl_key Cache-lifetime setting key.
	 * @return int Cache lifetime in seconds.
	 */

	private function map_ttl($ttl_key) {
		$map = [
			'1_hour' => 3600,
			'1_day' => 86400,
			'1_week' => 604800,
			'1_month' => 2592000,
			'6_months' => 15552000,
			'1_year' => 31536000,
		];

		return $map[$ttl_key] ?? 31536000;
	}

	/**
	 * Return the default WordPress rewrite rules for a newly created file.
	 *
	 * These rules are required for pretty permalinks. Their WordPress-managed
	 * marker block must not be modified by WPHAVE after creation.
	 *
	 * @return string Default WordPress `.htaccess` contents.
	 */

	private function get_default_wp_htaccess() {
		return "# BEGIN WordPress
# The directives (lines) between \"BEGIN WordPress\" and \"END WordPress\" are
# dynamically generated, and should only be modified via WordPress filters.
# Any changes to the directives between these markers will be overwritten.
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteRule .* - [E=HTTP_AUTHORIZATION:%{HTTP:Authorization}]
    RewriteBase /
    RewriteRule ^index\\.php$ - [L]
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteRule . /index.php [L]
</IfModule>

# END WordPress";
	}

	/**
	 * Generate browser-cache rules for static assets.
	 *
	 * @param int $ttl_seconds Cache lifetime in seconds.
	 * @return string Apache cache directives.
	 */

	public function generate_cache_block($ttl_seconds = 31536000) {
		$ttl_apache = $this->ttl_to_apache($ttl_seconds);

		return "## ASSET CACHE

<IfModule mod_expires.c>
    ExpiresActive On

    # Images
    ExpiresByType image/jpeg \"access plus {$ttl_apache}\"
    ExpiresByType image/png \"access plus {$ttl_apache}\"
    ExpiresByType image/gif \"access plus {$ttl_apache}\"
    ExpiresByType image/webp \"access plus {$ttl_apache}\"
    ExpiresByType image/svg+xml \"access plus {$ttl_apache}\"

    # CSS & JS
    ExpiresByType text/css \"access plus {$ttl_apache}\"
    ExpiresByType application/javascript \"access plus {$ttl_apache}\"

    # Fonts
    ExpiresByType font/woff2 \"access plus {$ttl_apache}\"
</IfModule>

<IfModule mod_headers.c>
    <FilesMatch \"\\.(jpg|jpeg|png|gif|webp|svg|css|js|woff2)$\">
        Header set Cache-Control \"public, max-age={$ttl_seconds}, immutable\"
    </FilesMatch>
</IfModule>";
	}

	/**
	 * Generate gzip rules for text-based responses.
	 *
	 * @return string Apache compression directives.
	 */

	public function generate_gzip_block() {
		return "## GZIP

<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/plain text/html text/xml text/css application/javascript application/json application/xml image/svg+xml
</IfModule>";
	}
}

/**
 * Determine whether the current request may inspect root server configuration.
 *
 * @return bool Whether status access is authorized.
 */

function wphave_htaccess_can_view() {
	return current_user_can('manage_options');
}

/**
 * Determine whether the current request may create root server configuration.
 *
 * @return bool Whether verified creation is authorized.
 */

function wphave_htaccess_can_create() {
	return wphave_htaccess_can_view() &&
		function_exists('wphave_has_pro_access') &&
		wphave_has_pro_access();
}

/**
 * Return the stable authorization failure for `.htaccess` operations.
 *
 * @return WP_Error Authorization failure.
 */

function wphave_htaccess_forbidden() {
	return new WP_Error(
		'wphave_htaccess_forbidden',
		__('You are not allowed to manage server configuration.', 'wphave'),
		['status' => 403],
	);
}

/**
 * Return the current `.htaccess` status for the REST API.
 *
 * The UI uses this response to display file existence, writability, and path.
 *
 * @return array|WP_Error REST response data or a verified creation error.
 */

function wphave_get_htaccess_status() {
	// AUTHORIZATION INVARIANT: Root server-configuration status is private; every executable callback rechecks authority before constructing a manager or disclosing path and writability state.
	if (!wphave_htaccess_can_view()) {
		return wphave_htaccess_forbidden();
	}

	$htaccess = new WPHAVE_Htaccess_Manager();

	return [
		'success' => true,
		'status' => $htaccess->get_status(),
	];
}

/**
 * Create a missing `.htaccess` file for the REST API.
 *
 * Existing files are never overwritten. This endpoint is only a fallback for
 * servers where WordPress has not created the file itself.
 *
 * @return array REST response data.
 */

function wphave_create_htaccess() {
	// AUTHORIZATION INVARIANT: Creating root server configuration requires both administrative authority and Pro access immediately before any filesystem inspection or mutation.
	if (!wphave_htaccess_can_create()) {
		return wphave_htaccess_forbidden();
	}

	$htaccess = new WPHAVE_Htaccess_Manager();

	if (!$htaccess->exists()) {
		$created = $htaccess->create_root_if_missing_verified(site_url('/wp-login.php'));

		if (!$created) {
			return new WP_Error(
				'wphave_htaccess_create_failed',
				__(
					'The .htaccess file could not be created safely. No new file was retained.',
					'wphave',
				),
				['status' => 500],
			);
		}

		return [
			'success' => true,
			'message' => __('The .htaccess file was created and verified.', 'wphave'),
			'status' => $htaccess->get_status(),
		];
	}

	return new WP_Error('wphave_htaccess_exists', __('.htaccess file already exists.', 'wphave'), [
		'status' => 409,
	]);
}

/**
 * Synchronize the managed `.htaccess` block with current settings.
 *
 * Asset-cache, gzip and security rules are generated inside the WPHAVE marker block.
 * Disabling the feature removes that block, while a missing `.htaccess` file
 * is left untouched. This runs automatically after settings updates.
 *
 * @param array|null $site_settings Fresh site settings from the option update.
 * @return bool Whether all requested server rules were applied and verified.
 */

function wphave_sync_htaccess($site_settings = null) {
	if (is_array($site_settings)) {
		$settings = $site_settings['advanced']['performance'] ?? [];
		$security = $site_settings['advanced']['security'] ?? [];
	} else {
		$settings = wphave_data_get('site_settings', 'advanced.performance', []);
		$security = wphave_data_get('site_settings', 'advanced.security', []);
	}

	$enabled = $settings['asset_cache'] ?? false;
	$ttl = $settings['asset_cache_ttl'] ?? '1_year';
	$gzip = $settings['asset_cache_gzip'] ?? false;
	$uploads_verified = wphave_sync_uploads_htaccess(!empty($security['block_executable_uploads']));

	if (!$uploads_verified) {
		return false;
	}

	$htaccess = new WPHAVE_Htaccess_Manager();
	$content = $htaccess->generate([
		'asset_cache' => [
			'enabled' => $enabled,
			'ttl' => $ttl,
			'gzip' => $gzip,
		],
		'security' => [
			'disable_directory_listing' => !empty($security['disable_directory_listing']),
			'protect_sensitive_files' => !empty($security['protect_sensitive_files']),
		],
	]);

	if (!$htaccess->exists()) {
		$verified = trim($content) === '';
		wphave_record_htaccess_result('root', $verified);

		return $verified;
	}

	$verified = $htaccess->update_block_verified(
		'WPHAVE',
		trim($content) === '' ? null : $content,
		site_url('/wp-login.php'),
	);

	wphave_record_htaccess_result('root', $verified);

	return $verified;
}

/**
 * Synchronize executable-file protection inside the active uploads directory.
 *
 * A directory-local file is required so PHP remains executable everywhere else.
 * Only the WPHAVE marker block is added or removed; unrelated rules are retained.
 *
 * @param bool $enabled Whether executable uploads should be blocked.
 * @return bool Whether the requested state was applied successfully.
 */

function wphave_sync_uploads_htaccess($enabled) {
	$uploads = wp_get_upload_dir();
	$directory = (string) ($uploads['basedir'] ?? '');

	if ($directory === '' || !is_dir($directory)) {
		return false;
	}

	$htaccess = new WPHAVE_Htaccess_Manager(trailingslashit($directory) . '.htaccess');
	$content =
		"<FilesMatch \"\\.(?:php(?:[3-8]|s)?|phtml|phar)$\">\nRequire all denied\n</FilesMatch>";
	$verification_url =
		trailingslashit(wphave_public_url($uploads['baseurl'] ?? '')) . 'wphave-security-check.php';
	$verified =
		!$enabled && !$htaccess->exists()
			? true
			: $htaccess->update_block_verified(
				'WPHAVE Upload Security',
				$enabled ? $content : null,
				$verification_url,
				$enabled,
			);

	wphave_record_htaccess_result('uploads', $verified);

	return $verified;
}

/**
 * Store the last verification outcome without triggering another settings sync.
 *
 * @param string $scope Root or uploads configuration scope.
 * @param bool   $success Whether the server accepted the change.
 * @return void
 */

function wphave_record_htaccess_result($scope, $success) {
	$status = get_option('wphave_htaccess_verification', []);
	$status = is_array($status) ? $status : [];
	$status[$scope] = [
		'success' => (bool) $success,
		'checked_at' => current_time('mysql', true),
	];

	update_option('wphave_htaccess_verification', $status, false);
}

/**
 * Apply `.htaccess` settings before persisting the shared WPHAVE option.
 *
 * Only settings backed by managed server rules participate. When verification
 * fails, those keys retain their previous values while unrelated settings from
 * the same request are still saved. This keeps the UI consistent with the
 * effective server configuration.
 *
 * @param mixed $value Updated option value.
 * @param mixed $old_value Previous option value.
 * @return mixed Safe option value.
 */

function wphave_htaccess_sync_before_update($value, $old_value) {
	if (!is_array($value) || !is_array($old_value)) {
		return $value;
	}

	$site_settings = $value['wphave_settings'] ?? null;
	$old_site_settings = $old_value['wphave_settings'] ?? null;

	if (!is_array($site_settings) || !is_array($old_site_settings)) {
		return $value;
	}

	$paths = [
		['advanced', 'performance', 'asset_cache'],
		['advanced', 'performance', 'asset_cache_ttl'],
		['advanced', 'performance', 'asset_cache_gzip'],
		['advanced', 'security', 'disable_directory_listing'],
		['advanced', 'security', 'protect_sensitive_files'],
		['advanced', 'security', 'block_executable_uploads'],
	];

	$changed = false;
	foreach ($paths as $path) {
		if (
			wphave_htaccess_array_value($site_settings, $path) !==
			wphave_htaccess_array_value($old_site_settings, $path)
		) {
			$changed = true;
			break;
		}
	}

	if (!$changed || wphave_sync_htaccess($site_settings)) {
		return $value;
	}

	wphave_sync_htaccess($old_site_settings);

	foreach ($paths as $path) {
		wphave_htaccess_restore_array_value($site_settings, $old_site_settings, $path);
	}

	$value['wphave_settings'] = $site_settings;

	return $value;
}

add_filter('pre_update_option_wphave_data', 'wphave_htaccess_sync_before_update', 10, 2);

/**
 * Read a nested array value for change detection.
 *
 * @param array $data Source data.
 * @param array $path Nested keys.
 * @return mixed Stored value, or null when absent.
 */

function wphave_htaccess_array_value($data, $path) {
	foreach ($path as $key) {
		if (!is_array($data) || !array_key_exists($key, $data)) {
			return null;
		}

		$data = $data[$key];
	}

	return $data;
}

/**
 * Restore one managed nested value from the previous settings snapshot.
 *
 * @param array $target Mutable new settings.
 * @param array $source Previous settings.
 * @param array $path Nested keys.
 * @return void
 */

function wphave_htaccess_restore_array_value(&$target, $source, $path) {
	$source_cursor = $source;
	$last_key = array_pop($path);
	$source_exists = true;

	foreach ($path as $key) {
		if (!is_array($source_cursor) || !array_key_exists($key, $source_cursor)) {
			$source_exists = false;
			break;
		}

		$source_cursor = $source_cursor[$key];
	}

	$source_exists =
		$source_exists && is_array($source_cursor) && array_key_exists($last_key, $source_cursor);
	$target_cursor = &$target;

	foreach ($path as $key) {
		if (!isset($target_cursor[$key]) || !is_array($target_cursor[$key])) {
			$target_cursor[$key] = [];
		}
		$target_cursor = &$target_cursor[$key];
	}

	if ($source_exists) {
		$target_cursor[$last_key] = $source_cursor[$last_key];
	} else {
		unset($target_cursor[$last_key]);
	}
}

/**
 * Register the REST routes used to inspect and manage `.htaccess`.
 *
 * Endpoints expose status and verified file creation. Every route
 * requires `manage_options` because the callbacks can disclose paths or modify
 * server configuration.
 *
 * @return void
 */

function wphave_htaccess_rest_routes() {
	register_rest_route('wphave/v1', '/htaccess/create', [
		'methods' => 'POST',
		'callback' => 'wphave_create_htaccess',
		'permission_callback' => 'wphave_htaccess_can_create',
	]);

	register_rest_route('wphave/v1', '/htaccess/status', [
		'methods' => 'GET',
		'callback' => 'wphave_get_htaccess_status',
		'permission_callback' => 'wphave_htaccess_can_view',
	]);
}

add_action('rest_api_init', 'wphave_htaccess_rest_routes');
