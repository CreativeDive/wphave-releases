<?php

/**
 * Configure the WordPress Core speculative loading feature.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

if( ! class_exists( 'WPHAVE_Speculative_Loading' ) ) :

	class WPHAVE_Speculative_Loading {

		/**
		 * Register the Core configuration filter when WordPress supports it.
		 *
		 * @return void
		 */

		public static function init(): void {

			add_filter( 'wp_speculation_rules_configuration', array( __CLASS__, 'configure' ) );

		}

		/**
		 * Preserve Core's context checks while applying the selected frontend policy.
		 *
		 * Core returns null for contexts where speculative loading is unsafe, such
		 * as logged-in visits or sites without pretty permalinks. Custom eagerness
		 * must not turn the feature back on in those contexts.
		 *
		 * @param array|null $configuration WordPress speculative loading configuration.
		 * @return array|null
		 */

		public static function configure( $configuration ) {
			// Security invariant: missing license authority preserves Core's safe configuration.
			if( ! function_exists( 'wphave_optimization_has_pro_access' ) || ! wphave_optimization_has_pro_access() ) return $configuration;

			$mode = wphave_data_get( 'site_settings', 'advanced.performance.speculative_loading', 'default' );

			if( 'disabled' === $mode ) {
				return null;
			}

			if( 'custom' !== $mode || null === $configuration ) {
				return $configuration;
			}

			$eagerness = wphave_data_get( 'site_settings', 'advanced.performance.speculative_loading_eagerness', 'conservative' );
			$allowed_eagerness = array( 'conservative', 'moderate', 'eager' );

			if( ! in_array( $eagerness, $allowed_eagerness, true ) ) {
				$eagerness = 'conservative';
			}

			// WPHAVE deliberately exposes prefetch only; prerender executes the target page and its scripts ahead of navigation.
			return array(
				'mode' => 'prefetch',
				'eagerness' => $eagerness,
			);

		}

	}

	WPHAVE_Speculative_Loading::init();

endif;
