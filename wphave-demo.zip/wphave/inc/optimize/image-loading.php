<?php

/**
 * Optimize image loading attributes after the complete layout is rendered.
 */

class WPHAVE_Image_Loading {

	/**
	 * Register frontend image-loading filters.
	 *
	 * @return void
	 */

	public static function init() {
		add_filter( 'wphave_ready_renderd_block_content', array( __CLASS__, 'optimize' ), 20 );
		add_filter( 'wp_lazy_loading_enabled', array( __CLASS__, 'control_wordpress_lazy_loading' ), 10, 3 );
	}

	/**
	 * Determine whether the current image may be the primary LCP candidate.
	 *
	 * @param WP_HTML_Tag_Processor $processor Processor positioned at an IMG tag.
	 * @return bool Whether the image is eligible for prioritization.
	 */

	public static function is_priority_candidate( $processor ) {
		$class = strtolower( (string) $processor->get_attribute( 'class' ) );
		$excluded_classes = array( 'avatar', 'custom-logo', 'emoji', 'icon', 'site-logo', 'wphave-placeholder-image' );

		foreach( $excluded_classes as $excluded_class ) {
			if( preg_match( '/(?:^|\s)' . preg_quote( $excluded_class, '/' ) . '(?:\s|$)/', $class ) ) {
				return false;
			}
		}

		$width = (int) $processor->get_attribute( 'width' );
		$height = (int) $processor->get_attribute( 'height' );

		return ! ( $width && $height && max( $width, $height ) < 256 );
	}

	/**
	 * Apply deterministic loading attributes to rendered image markup.
	 *
	 * @param string $content Rendered HTML content.
	 * @param bool $optimize_above_the_fold Whether to prioritize early content images.
	 * @return string Updated HTML content.
	 */

	public static function update( $content, $optimize_above_the_fold = true ) {
		if( stripos( $content, '<img' ) === false || ! class_exists( 'WP_HTML_Tag_Processor' ) ) {
			return $content;
		}

		$processor = new WP_HTML_Tag_Processor( $content );
		$priority_candidate = 0;

		while( $processor->next_tag( 'IMG' ) ) {
			if( ! $optimize_above_the_fold ) {
				if( $processor->get_attribute( 'loading' ) === null ) {
					$processor->set_attribute( 'loading', 'lazy' );
				}
				continue;
			}

			// Cached markup can contain a priority value from a different render order.
			if( strtolower( (string) $processor->get_attribute( 'fetchpriority' ) ) === 'high' ) {
				$processor->remove_attribute( 'fetchpriority' );
			}

			if( ! self::is_priority_candidate( $processor ) ) {
				continue;
			}

			$priority_candidate++;
			if( $priority_candidate === 1 ) {
				$processor->set_attribute( 'loading', 'eager' );
				$processor->set_attribute( 'fetchpriority', 'high' );
			} elseif( $priority_candidate === 2 ) {
				$processor->set_attribute( 'loading', 'eager' );
				$processor->set_attribute( 'fetchpriority', 'auto' );
			} else {
				$processor->set_attribute( 'loading', 'lazy' );
				$processor->set_attribute( 'fetchpriority', 'auto' );
			}
		}

		return $processor->get_updated_html();
	}

	/**
	 * Optimize images in their final header, content and footer DOM order.
	 *
	 * @param string $content Fully rendered WPHAVE page content.
	 * @return string Content with deterministic loading attributes.
	 */

	public static function optimize( $content ) {
		// Security invariant: a missing entitlement authority is a denial, never an implicit Pro grant.
		if( ! function_exists( 'wphave_optimization_has_pro_access' ) || ! wphave_optimization_has_pro_access() ) return $content;

		$is_enabled = (bool) wphave_data_get( 'site_settings', 'advanced.performance.lazy_loading', true );
		if( ! $is_enabled || wphave_use_fse() ) {
			return $content;
		}

		$optimize_above_the_fold = (bool) wphave_data_get( 'site_settings', 'advanced.performance.image_loading_above_the_fold', true );
		return self::update( $content, $optimize_above_the_fold );
	}

	/**
	 * Coordinate WordPress core lazy loading with the WPHAVE strategy.
	 *
	 * @param bool $default WordPress default decision.
	 * @param string $tag_name HTML tag name.
	 * @param string $context WordPress rendering context.
	 * @return bool Whether WordPress should add lazy-loading attributes.
	 */

	public static function control_wordpress_lazy_loading( $default, $tag_name, $context ) {
		// Security invariant: Core behavior remains authoritative unless Pro access is proven.
		if( ! function_exists( 'wphave_optimization_has_pro_access' ) || ! wphave_optimization_has_pro_access() ) return $default;

		$is_enabled = (bool) wphave_data_get( 'site_settings', 'advanced.performance.lazy_loading', true );
		$optimize_above_the_fold = (bool) wphave_data_get( 'site_settings', 'advanced.performance.image_loading_above_the_fold', true );

		if( wphave_use_fse() ) {
			return $default;
		}
		if( ! $is_enabled && $tag_name === 'img' ) {
			return false;
		}
		if( $is_enabled && $optimize_above_the_fold && $tag_name === 'img' ) {
			return false;
		}

		return $default;
	}

}

WPHAVE_Image_Loading::init();
