<?php

if( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if( ! class_exists( 'WPHAVE_Internal_Post_Type_Cache' ) ) :

	/**
	 * Manages cache metadata for WPHAVE internal feature post types.
	 *
	 * Internal post types drive global product areas such as templates,
	 * template parts, navigations, forms and add-ons. Several frontend and app
	 * flows only need to know whether these areas contain data or which IDs
	 * exist. This class keeps those lookups centralized and prevents public
	 * frontend requests from writing option/transient cache data while still
	 * allowing them to read existing caches and calculate fallback data.
	 */

	class WPHAVE_Internal_Post_Type_Cache {

		/**
		 * Shared transient bucket used by internal post type feature caches.
		 *
		 * @var string
		 */

		const CACHE_BUCKET = 'post_type_features_data';

		/**
		 * Cache key for the has-posts map.
		 *
		 * @var string
		 */

		const KEY_HAS_POSTS = 'has_posts';

		/**
		 * Cache key for post IDs grouped by internal post type.
		 *
		 * @var string
		 */

		const KEY_POST_IDS = 'post_ids_by_post_type';

		/**
		 * Post types awaiting a controlled cache rebuild at the end of the
		 * current write-capable request.
		 *
		 * @var array
		 */

		private static $pending_rebuilds = array();

		/**
		 * Whether the shutdown rebuilder has already been registered.
		 *
		 * @var bool
		 */

		private static $rebuild_scheduled = false;

		/**
		 * Return WPHAVE internal post types that participate in feature caches.
		 *
		 * @return array
		 */

		public static function post_types() {

			return array_keys( self::feature_definitions() );

		}

		/**
		 * Authoritative ownership map for shared feature-cache entries.
		 *
		 * wphave-add-blocks is intentionally excluded. It is temporary taxonomy
		 * term block storage, not a normal feature post type.
		 *
		 * @return array
		 */

		private static function feature_definitions() {

			return array(
				'wphave-templates' => array(
					'key' => 'wphave_templates',
					'builder' => array( 'WPHAVE_Templates', 'get_custom_template_data' ),
				),
				'wphave-template-part' => array(
					'key' => 'wphave_template_part',
					'builder' => array( 'WPHAVE_Template_Parts', 'get_template_parts_data' ),
				),
				'wphave-navigations' => array(
					'key' => 'wphave_navigations',
					'builder' => array( 'WPHAVE_Navigation_Manager', 'get_navigations' ),
				),
				'wphave-add-ons' => array(
					'key' => 'wphave_add_ons',
					'builder' => array( 'WPHAVE_Add_On_Manager', 'get_data' ),
				),
				'wphave-forms' => array(
					'key' => 'wphave_forms',
					'builder' => array( 'WPHAVE_Form_Manager', 'get_data' ),
				),
			);

		}

		/**
		 * Check whether cache writes are expected and controlled in this request.
		 *
		 * Public frontend rendering may read existing caches and calculate
		 * fallback data, but should not update wp_options/transients while a
		 * page is being delivered.
		 *
		 * @return bool
		 */

		public static function can_write() {

			return is_admin()
				|| wp_doing_ajax()
				|| wp_doing_cron()
				|| ( defined( 'REST_REQUEST' ) && REST_REQUEST )
				|| ( defined( 'WP_CLI' ) && WP_CLI );

		}

		/**
		 * Build and cache the has-posts map for internal feature post types.
		 *
		 * This is intentionally lazy and should not run on init. It is only
		 * needed by code paths that need to know whether an internal feature post
		 * type has data.
		 *
		 * @return array Map of internal post type names to yes/no values.
		 */

		public static function has_posts_map() {

			$cached = wphave_has_cached_data( self::CACHE_BUCKET, array(
				'key' => self::KEY_HAS_POSTS,
				'block_editor_cache' => true,
			) );

			if( $cached ) {
				return $cached;
			}

			wphave_events( 'CACHE', 'Internal post type has-posts map.' );

			$save_data = array();

			foreach( self::post_types() as $post_type ) {
				$has_post = get_posts( array(
					'post_type' => $post_type,
					'fields' => 'ids',
					'numberposts' => 1,
					'post_status' => 'publish',
					'suppress_filters' => false,
					'cache_results' => true,
					'update_post_meta_cache' => false,
					'update_post_term_cache' => false,
				) );

				$save_data[$post_type] = $has_post ? 'yes' : 'no';
			}

			wphave_save_query( $save_data, self::CACHE_BUCKET, array(
				'key' => self::KEY_HAS_POSTS,
				'block_editor_cache' => true,
				'frontend_write' => false,
			) );

			return $save_data;

		}

		/**
		 * Check whether an internal WPHAVE post type has published posts.
		 *
		 * @param string $post_type Internal post type name.
		 * @return bool
		 */

		public static function has_posts( $post_type ) {

			if( ! in_array( $post_type, self::post_types(), true ) ) {
				return false;
			}

			$data = self::has_posts_map();

			return isset( $data[$post_type] ) && $data[$post_type] === 'yes';

		}

		/**
		 * Return cached post IDs for one or more internal post types.
		 *
		 * For one post type, the missing cache entry is rebuilt only for that
		 * type. For multiple post types, only already cached IDs are combined.
		 *
		 * @param string|array $post_type Internal post type name or list.
		 * @return array
		 */

		public static function post_ids( $post_type ) {

			$cached = wphave_has_cached_data( self::CACHE_BUCKET, array(
				'key' => self::KEY_POST_IDS,
				'block_editor_cache' => true,
			) ) ?: array();

			if( is_array( $post_type ) ) {
				$ids = array();

				foreach( $post_type as $type ) {
					if( array_key_exists( $type, $cached ) && is_array( $cached[$type] ) ) {
						$ids = array_merge( $ids, $cached[$type] );
					}
				}

				return $ids;
			}

			if( array_key_exists( $post_type, $cached ) && is_array( $cached[$post_type] ) ) {
				return $cached[$post_type];
			}

			return self::rebuild_post_ids( $post_type );

		}

		/**
		 * Rebuild cached post IDs for one internal post type.
		 *
		 * @param string $post_type Internal post type name.
		 * @return array
		 */

		public static function rebuild_post_ids( $post_type ) {

			if( ! in_array( $post_type, self::post_types(), true ) ) {
				return array();
			}

			$cached = wphave_has_cached_data( self::CACHE_BUCKET, array(
				'key' => self::KEY_POST_IDS,
				'block_editor_cache' => true,
			) ) ?: array();

			if( array_key_exists( $post_type, $cached ) && is_array( $cached[$post_type] ) ) {
				return $cached[$post_type];
			}

			$post_ids = self::query_post_ids( $post_type );
			if( self::can_write() ) {
				self::persist_post_type_indexes( $post_type, $post_ids );
			}

			return $post_ids;

		}

		/**
		 * Query published IDs for one internal post type without touching any
		 * secondary query cache. The shared feature bucket is the sole owner.
		 *
		 * @param string $post_type Internal post type name.
		 * @return array
		 */

		private static function query_post_ids( $post_type ) {

			return get_posts( array(
				'post_type' => $post_type,
				'fields' => 'ids',
				'posts_per_page' => -1,
				'post_status' => 'publish',
				'suppress_filters' => false,
				'cache_results' => true,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
			) );

		}

		/**
		 * Atomically update only one post type inside the shared index maps.
		 * Sibling entries must survive concurrent feature saves.
		 *
		 * @param string $post_type Internal post type name.
		 * @param array $post_ids Published post IDs.
		 * @return void
		 */

		private static function persist_post_type_indexes( $post_type, $post_ids ) {

			$transient_name = wphave_wp_query_cache_transient( self::CACHE_BUCKET );
			WPHAVE_Query_Transient_Cache::mutate_nested_transient( $transient_name, function( $transient ) use ( $post_type, $post_ids ) {
				$transient[self::KEY_HAS_POSTS] = is_array( $transient[self::KEY_HAS_POSTS] ?? null ) ? $transient[self::KEY_HAS_POSTS] : array();
				$transient[self::KEY_POST_IDS] = is_array( $transient[self::KEY_POST_IDS] ?? null ) ? $transient[self::KEY_POST_IDS] : array();
				$transient[WPHAVE_Query_Transient_Cache::KEY_GLOBAL_POST_IDS] = is_array( $transient[WPHAVE_Query_Transient_Cache::KEY_GLOBAL_POST_IDS] ?? null ) ? $transient[WPHAVE_Query_Transient_Cache::KEY_GLOBAL_POST_IDS] : array();
				$transient[self::KEY_HAS_POSTS][$post_type] = $post_ids ? 'yes' : 'no';
				$transient[self::KEY_POST_IDS][$post_type] = array_values( array_map( 'absint', $post_ids ) );
				$transient[WPHAVE_Query_Transient_Cache::KEY_GLOBAL_POST_IDS][$post_type] = $transient[self::KEY_POST_IDS][$post_type];
				return $transient;
			}, 30 * DAY_IN_SECONDS );

		}

		/**
		 * Invalidate cached data for an internal post type.
		 *
		 * Only the affected entries are removed. A write-capable request rebuilds
		 * them at shutdown, after WordPress and REST meta persistence has finished.
		 * Public frontend requests remain read-only.
		 *
		 * @param string $post_type Internal post type name.
		 * @return void
		 */

		public static function invalidate( $post_type ) {

			if( ! in_array( $post_type, self::post_types(), true ) ) {
				return;
			}

			// DATA INTEGRITY INVARIANT: Every mutation must remove current cache
			// entries, even when a rebuild is already queued. A read between two
			// mutations may have repopulated them; only rebuild scheduling is deduped.

			$transient_name = wphave_wp_query_cache_transient( self::CACHE_BUCKET );
			$feature_key = self::feature_definitions()[$post_type]['key'];
			WPHAVE_Query_Transient_Cache::mutate_nested_transient( $transient_name, function( $transient ) use ( $post_type, $feature_key ) {
				if( is_array( $transient[self::KEY_HAS_POSTS] ?? null ) ) {
					unset( $transient[self::KEY_HAS_POSTS][$post_type] );
				}
				if( is_array( $transient[self::KEY_POST_IDS] ?? null ) ) {
					unset( $transient[self::KEY_POST_IDS][$post_type] );
				}
				if( is_array( $transient[WPHAVE_Query_Transient_Cache::KEY_GLOBAL_POST_IDS] ?? null ) ) {
					unset( $transient[WPHAVE_Query_Transient_Cache::KEY_GLOBAL_POST_IDS][$post_type] );
				}
				unset( $transient[$feature_key] );
				return $transient;
			}, 30 * DAY_IN_SECONDS );

			self::schedule_rebuild( $post_type );

		}

		/**
		 * Queue one post type for rebuilding once per request.
		 *
		 * @param string $post_type Internal post type name.
		 * @return void
		 */

		private static function schedule_rebuild( $post_type ) {

			if( ! self::can_write() || ! in_array( $post_type, self::post_types(), true ) ) {
				return;
			}

			self::$pending_rebuilds[$post_type] = true;
			if( self::$rebuild_scheduled ) {
				return;
			}

			self::$rebuild_scheduled = true;
			add_action( 'shutdown', array( __CLASS__, 'rebuild_pending' ), 5 );

		}

		/**
		 * Rebuild all invalidated feature entries after the write request has
		 * completed. Indexes are persisted before feature builders run so their
		 * public cache-first APIs never repeat the ID query.
		 *
		 * @return void
		 */

		public static function rebuild_pending() {

			$post_types = array_keys( self::$pending_rebuilds );
			self::$pending_rebuilds = array();

			foreach( $post_types as $post_type ) {
				self::rebuild( $post_type );
			}

		}

		/**
		 * Rebuild the indexes and feature payload for one internal post type.
		 *
		 * @param string $post_type Internal post type name.
		 * @return void
		 */

		public static function rebuild( $post_type ) {

			if( ! self::can_write() || ! in_array( $post_type, self::post_types(), true ) ) {
				return;
			}

			$post_ids = self::query_post_ids( $post_type );
			self::persist_post_type_indexes( $post_type, $post_ids );

			$builder = self::feature_definitions()[$post_type]['builder'];
			if( is_callable( $builder ) ) {
				call_user_func( $builder );
			}

		}

		/**
		 * Repair incomplete legacy buckets from a write-capable admin request.
		 * This is a cheap key inspection; actual queries run once at shutdown.
		 *
		 * @return void
		 */

		public static function ensure_complete_cache() {

			if( ! self::can_write() ) {
				return;
			}

			$transient_name = wphave_wp_query_cache_transient( self::CACHE_BUCKET );
			$transient = get_transient( $transient_name );
			$transient = is_array( $transient ) ? $transient : array();
			$has_posts = is_array( $transient[self::KEY_HAS_POSTS] ?? null ) ? $transient[self::KEY_HAS_POSTS] : array();
			$post_ids = is_array( $transient[self::KEY_POST_IDS] ?? null ) ? $transient[self::KEY_POST_IDS] : array();

			foreach( self::feature_definitions() as $post_type => $definition ) {
				$feature_key = $definition['key'];
				if( ! array_key_exists( $post_type, $has_posts ) || ! array_key_exists( $post_type, $post_ids ) || ! array_key_exists( $feature_key, $transient ) ) {
					self::schedule_rebuild( $post_type );
				}
			}

		}

		/**
		 * Invalidate caches after a status transition.
		 *
		 * @param string $new_status New post status.
		 * @param string $old_status Previous post status.
		 * @param WP_Post $post Post object.
		 * @return void
		 */

		public static function invalidate_on_transition( $new_status, $old_status, $post ) {

			if( ! $post instanceof WP_Post ) {
				return;
			}

			self::invalidate( $post->post_type );

		}

		/**
		 * Invalidate caches after an internal post has been deleted.
		 *
		 * @param int $post_id Deleted post ID.
		 * @param WP_Post $post Deleted post object.
		 * @return void
		 */

		public static function invalidate_on_delete( $post_id, $post ) {

			if( ! $post instanceof WP_Post ) {
				return;
			}

			self::invalidate( $post->post_type );

		}

		/**
		 * Register cache invalidation hooks.
		 *
		 * @return void
		 */

		public static function init() {

			add_action( 'transition_post_status', array( __CLASS__, 'invalidate_on_transition' ), 10, 3 );
			add_action( 'delete_post', array( __CLASS__, 'invalidate_on_delete' ), 10, 2 );
			add_action( 'admin_init', array( __CLASS__, 'ensure_complete_cache' ), 20 );

		}

	}

endif;

if( ! function_exists( 'wphave_internal_post_types' ) ) :

	/**
	 * Internal post types.
	 */

	function wphave_internal_post_types() {

		return WPHAVE_Internal_Post_Type_Cache::post_types();

	}

endif;

if( ! function_exists( 'wphave_internal_post_type_cache_can_write' ) ) :

	/**
	 * Internal post type cache can write.
	 */

	function wphave_internal_post_type_cache_can_write() {

		return WPHAVE_Internal_Post_Type_Cache::can_write();

	}

endif;

if( ! function_exists( 'wphave_internal_post_types_init' ) ) :

	/**
	 * Internal post types init.
	 */

	function wphave_internal_post_types_init() {

		return WPHAVE_Internal_Post_Type_Cache::has_posts_map();

	}

endif;

if( ! function_exists( 'wphave_is_internal_post_type' ) ) :

	/**
	 * Is internal post type.
	 *
	 * @param string $post_type Post type.
	 */

	function wphave_is_internal_post_type( $post_type ) {

		return WPHAVE_Internal_Post_Type_Cache::has_posts( $post_type );

	}

endif;

if( ! function_exists( 'wphave_internal_post_type_all_ids' ) ) :

	/**
	 * Internal post type all IDs.
	 *
	 * @param string $post_type Post type.
	 */

	function wphave_internal_post_type_all_ids( $post_type ) {

		return WPHAVE_Internal_Post_Type_Cache::post_ids( $post_type );

	}

endif;

if( ! function_exists( 'wphave_internal_post_types_cache' ) ) :

	/**
	 * Internal post types cache.
	 *
	 * @param string $post_type Post type.
	 */

	function wphave_internal_post_types_cache( $post_type ) {

		return WPHAVE_Internal_Post_Type_Cache::rebuild_post_ids( $post_type );

	}

endif;

if( ! function_exists( 'wphave_internal_post_type_cache_delete' ) ) :

	/**
	 * Internal post type cache delete.
	 *
	 * @param string $post_type Post type.
	 */

	function wphave_internal_post_type_cache_delete( $post_type ) {

		WPHAVE_Internal_Post_Type_Cache::invalidate( $post_type );

	}

endif;

if( ! function_exists( 'wphave_internal_post_type_cache_delete_action' ) ) :

	/**
	 * Internal post type cache delete action.
	 *
	 * @param string $new_status New status.
	 * @param string $old_status Old status.
	 * @param mixed $post Post.
	 */

	function wphave_internal_post_type_cache_delete_action( $new_status, $old_status, $post ) {

		WPHAVE_Internal_Post_Type_Cache::invalidate_on_transition( $new_status, $old_status, $post );

	}

endif;

if( ! function_exists( 'wphave_internal_post_type_delete_action' ) ) :

	/**
	 * Internal post type delete action.
	 *
	 * @param int $post_id Post ID.
	 * @param mixed $post Post.
	 */

	function wphave_internal_post_type_delete_action( $post_id, $post ) {

		WPHAVE_Internal_Post_Type_Cache::invalidate_on_delete( $post_id, $post );

	}

endif;

WPHAVE_Internal_Post_Type_Cache::init();
