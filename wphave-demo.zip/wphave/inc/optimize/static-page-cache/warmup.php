<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Static_Page_Cache_Warmup {

/**
     * Trigger non-blocking cache generation for a post URL.
     *
     *  IMPORTANT:
     *  - Non-blocking request
     *  - Used after manual invalidation
     *
     * @param int $post_id Post ID.
     * @return void
     */

    private function warmup_single( $post_id ) {
        $url = get_permalink( $post_id );

		// SECURITY INVARIANT: Filtered permalinks are data, not network
		// authority. Validate exact origin immediately before the HTTP sink.
        if( ! $this->is_warmup_url_allowed( $url ) ) return;

		// SECURITY INVARIANT: Warmup requests use Core's SSRF validation, never
		// follow response-controlled redirects and never weaken TLS validation.
        wp_safe_remote_get($url, [
            'timeout' => 5,
            'blocking' => false,
			'redirection' => 0,
			'sslverify' => true,
        ]);
    }

	/**
	 * Decide whether a cache-warmup URL belongs to the exact configured origin.
	 *
	 * Persisted queue entries and WordPress permalink filters cross a trust
	 * boundary before cron dereferences them. Scheme, host, effective port and
	 * URL credentials therefore form one indivisible authorization decision.
	 *
	 * @param mixed $url Candidate warmup URL.
	 * @return bool
	 */

	public function is_warmup_url_allowed( $url ): bool {
		if( ! is_string( $url ) || '' === $url ) return false;

		$site = wp_parse_url( home_url( '/' ) );
		$candidate = wp_parse_url( $url );
		if( ! is_array( $site ) || ! is_array( $candidate ) ) return false;

		$site_scheme = strtolower( (string) ( $site['scheme'] ?? '' ) );
		$candidate_scheme = strtolower( (string) ( $candidate['scheme'] ?? '' ) );
		$site_host = strtolower( (string) ( $site['host'] ?? '' ) );
		$candidate_host = strtolower( (string) ( $candidate['host'] ?? '' ) );
		$site_port = (int) ( $site['port'] ?? ( 'https' === $site_scheme ? 443 : 80 ) );
		$candidate_port = (int) ( $candidate['port'] ?? ( 'https' === $candidate_scheme ? 443 : 80 ) );

		// SECURITY INVARIANT: Cache warmup is strictly same-origin. Stored state
		// cannot authorize another scheme, host, port or credential-bearing URL.
		return in_array( $candidate_scheme, array( 'http', 'https' ), true )
			&& $site_scheme === $candidate_scheme
			&& '' !== $site_host
			&& hash_equals( $site_host, $candidate_host )
			&& $site_port === $candidate_port
			&& empty( $candidate['user'] )
			&& empty( $candidate['pass'] );
	}

/**
     * Stop the warmup process through its internal lifecycle state.
     *
     *  This method:
     *  - Marks warmup as not running
     *  - Clears the remaining queue
     *  - Persists the updated state
     *
     *  IMPORTANT:
     *  - Does NOT unschedule the cron job directly
     *  - Cron will terminate automatically on next run
     *  - Used internally when queue is fully processed
     *
     *  DIFFERENCE TO cancel_warmup():
     *  - stop_warmup() → internal lifecycle handling
     *  - cancel_warmup() → manual user-triggered interruption (includes cron cleanup)
     *
     * @return void
     */

    public function stop_warmup() {
        $warmup = $this->get_warmup_data();
        $warmup['running'] = false;
        $this->save_cache_section( 'warmup', $warmup );
        $this->set_warmup_queue([]);
    }

/**
     * Cancel warmup immediately in response to a user action.
     *
     *  This includes:
     *  - Clearing the warmup queue
     *  - Resetting progress tracking
     *  - Unscheduling the cron job
     *
     *  IMPORTANT:
     *  - Safe to call at any time
     *  - Used by UI to allow manual interruption
     *
     * @return void
     */

    public function cancel_warmup() {
        // Clear queue
        $warmup = [
            'queue' => [],
            'total' => 0,
            'running' => false,
            'generation' => wp_generate_uuid4(),
            'state' => 'cancelled',
            'scheduled_at' => 0,
            'deferred_reason' => '',
            'strategy' => $this->warmup_strategy,
        ];
        $this->save_cache_section( 'warmup', $warmup );

        // Cron stoppen
        wp_clear_scheduled_hook('wphave_process_warmup_queue');
    }

/**
     * Build and schedule the prioritized cache-warmup queue.
     *
     *  This ensures that critical pages are cached proactively
     *  after invalidation.
     *
     *  IMPORTANT:
     *  - Prioritizes homepage
     *  - Limits queue size
     *  - Schedules background processing via WP Cron
     *  - Executes first batch immediately (no cron delay)
     *  - Ensures instant UI feedback and faster cache rebuild
     *
     * @param bool          $manual    Whether the warmup was explicitly requested.
     * @param callable|null $authorize Optional final authority check for user-triggered work.
     * @return bool True after queueing; false when final authorization is denied.
     */

    public function enqueue_warmup_urls(bool $manual = false, ?callable $authorize = null) {
        $urls = [];

        // Blog page
        $posts_page_id = get_option('page_for_posts');
        if( $posts_page_id ) {
            $urls[] = get_permalink( $posts_page_id );
        }

        // All pages
        $pages = get_pages();

        foreach( $pages as $page ) {
            $urls[] = get_permalink( $page->ID );
        }

        // Posts
        $posts = get_posts([
            'numberposts' => 20,
            'post_status' => 'publish'
        ]);

        foreach( $posts as $post ) {
            $urls[] = get_permalink( $post );
        }

        // Categories
        $categories = get_terms([
            'taxonomy' => 'category',
            'hide_empty' => true
        ]);

        foreach( $categories as $cat ) {
            $urls[] = get_term_link( $cat );
        }

        $priority = [
            // Home page has top priority
            home_url('/'),
        ];

        $queue = array_unique(array_merge($priority, $urls));

        // Limit protects against server overload
        $queue = array_slice($queue, 0, $this->warmup_limit);

        $warmup = [
            'queue' => $queue,
            'total' => count($queue),
            'running' => true,
            'generation' => wp_generate_uuid4(),
            'state' => 'scheduled',
            'scheduled_at' => 0,
            'deferred_reason' => '',
            'strategy' => $manual ? 'manual' : $this->warmup_strategy,
        ];
        $scheduled_at = $this->warmup_start_timestamp($manual);
        $warmup['scheduled_at'] = $scheduled_at;
        $warmup['deferred_reason'] = $manual || $this->warmup_strategy === 'immediate' ? '' : ($this->warmup_strategy === 'quiet_hours' ? 'quiet_hours' : 'debounce');

        // AUTHORIZATION/BACKGROUND INVARIANT: URL discovery invokes WordPress
        // filters and can outlive the authority checked by a REST route. A
        // user-triggered warmup must therefore repeat its supplied policy after
        // discovery and immediately before queue, Cron, or outbound-I/O state is
        // committed. Internal invalidation paths deliberately supply no user
        // policy because they run from trusted lifecycle hooks, not a request.
        if ( $authorize && ! call_user_func( $authorize ) ) {
            return false;
        }

        $this->save_cache_section( 'warmup', $warmup );
        if( $scheduled_at <= time() ) {
            do_action('wphave_process_warmup_queue');
            $current = $this->get_warmup_data();
            if( !empty($current['running']) && ($current['generation'] ?? '') === $warmup['generation'] && !wp_next_scheduled('wphave_process_warmup_queue') ) $this->schedule_warmup(time() + MINUTE_IN_SECONDS, $warmup['generation']);
        } else {
            $this->schedule_warmup($scheduled_at, $warmup['generation']);
        }

        return true;
    }

/**
     * Return the current warmup queue state.
     *
     *  Includes:
     *  - queue: remaining URLs
     *  - total: initial queue size
     *  - running: whether warmup is currently active
     *
     * @return array Warmup state.
     */

    public function get_warmup_data() {
        $current = get_option(self::STATE_OPTION, []);
        return $current['warmup'] ?? [
            'queue' => [],
            'total' => 0,
            'running' => false,
            'generation' => '',
            'state' => 'idle',
            'scheduled_at' => 0,
            'deferred_reason' => '',
            'strategy' => $this->warmup_strategy,
        ];
    }

/**
     * Persist the remaining warmup queue.
     *
     *  IMPORTANT:
     *  - Does NOT update total → total represents initial workload
     *  - Does NOT modify running state
     *
     * @param array $queue Remaining URLs.
     * @param string $generation Warmup generation observed by the worker.
     * @return void
     */

    public function set_warmup_queue(array $queue, string $generation = '') {
        $this->mutate_cache_data(function( $current ) use ( $queue, $generation ) {
            $current['warmup'] = is_array($current['warmup'] ?? null) ? $current['warmup'] : [];
			// CONCURRENCY INVARIANT: A superseded worker must never overwrite the
			// queue owned by the currently active warmup generation.
            if( $generation && (string) ($current['warmup']['generation'] ?? '') !== $generation ) {
                return $current;
            }
            $current['warmup']['queue'] = array_values($queue);
            return $current;
        });
    }

/** Schedule exactly one future worker execution for the active generation. */
    public function schedule_warmup(int $timestamp, string $generation) {
        $scheduled = false;
        $saved = $this->mutate_cache_data(function( $current ) use ( $timestamp, $generation, &$scheduled ) {
            if( (string) ($current['warmup']['generation'] ?? '') !== $generation ) return $current;

            $previous_event = wp_get_scheduled_event('wphave_process_warmup_queue');
            wp_clear_scheduled_hook('wphave_process_warmup_queue');
            $result = wp_schedule_single_event(max(time() + 1, $timestamp), 'wphave_process_warmup_queue');
            $scheduled = !is_wp_error($result) && $result !== false;
            if( !$scheduled ) {
                $restored = $previous_event
                    && false === $previous_event->schedule
                    && wp_schedule_single_event(
                        (int) $previous_event->timestamp,
                        'wphave_process_warmup_queue',
                        [],
                        true
                    );

                // AVAILABILITY INVARIANT: Replacing a wake-up must not strand an
                // active queue. If WordPress rejects the new event, the previous
                // single event remains the executable fallback for current state.
                if( $restored && !is_wp_error($restored) ) {
                    $current['warmup']['state'] = 'scheduled';
                    $current['warmup']['scheduled_at'] = (int) $previous_event->timestamp;
                    $current['warmup']['deferred_reason'] = 'scheduling_retry_fallback';
                } else {
                    $current['warmup']['running'] = false;
                    $current['warmup']['state'] = 'failed';
                    $current['warmup']['scheduled_at'] = 0;
                    $current['warmup']['deferred_reason'] = 'scheduling_failed';
                }
            }
            return $current;
        });
        return $saved && $scheduled;
    }

/** Persist why and until when an active generation is waiting. */
    public function defer_warmup(string $generation, int $timestamp, string $reason) {
        $deferred = false;
        $saved = $this->mutate_cache_data(function( $current ) use ( $generation, $timestamp, $reason, &$deferred ) {
            $current['warmup'] = is_array($current['warmup'] ?? null) ? $current['warmup'] : [];
            if( (string) ($current['warmup']['generation'] ?? '') !== $generation ) return $current;
            $current['warmup']['state'] = 'scheduled';
            $current['warmup']['scheduled_at'] = $timestamp;
            $current['warmup']['deferred_reason'] = sanitize_key($reason);
            $deferred = true;
            return $current;
        });
        return $saved && $deferred;
    }

/** Mark the generation as actively processing a batch. */
    public function mark_warmup_running(string $generation) {
        $running = false;
        $saved = $this->mutate_cache_data(function( $current ) use ( $generation, &$running ) {
            $current['warmup'] = is_array($current['warmup'] ?? null) ? $current['warmup'] : [];
            if( (string) ($current['warmup']['generation'] ?? '') !== $generation ) return $current;
            $current['warmup']['state'] = 'running';
            $current['warmup']['scheduled_at'] = 0;
            $current['warmup']['deferred_reason'] = '';
            $running = true;
            return $current;
        });
        return $saved && $running;
    }

/** Return the first execution time for the selected strategy. */
    private function warmup_start_timestamp(bool $manual): int {
        if( $manual || $this->warmup_strategy === 'immediate' ) return time();
        if( $this->warmup_strategy === 'quiet_hours' ) return $this->next_quiet_warmup_timestamp();
        return time() + 5 * MINUTE_IN_SECONDS;
    }

/** Check whether a quiet-hours generation must wait for its configured window. */
    public function should_wait_for_quiet_hours(array $warmup): bool {
        return ($warmup['strategy'] ?? '') === 'quiet_hours' && !$this->is_within_quiet_hours();
    }

/** Return whether the current local WordPress time falls inside the configured window. */
    public function is_within_quiet_hours(?DateTimeImmutable $now = null): bool {
        $now = $now ?: current_datetime();
        $current = $now->format('H:i');
        if( $this->warmup_quiet_start < $this->warmup_quiet_end ) return $current >= $this->warmup_quiet_start && $current < $this->warmup_quiet_end;
        return $current >= $this->warmup_quiet_start || $current < $this->warmup_quiet_end;
    }

/** Calculate the next quiet-window start in the WordPress timezone. */
    public function next_quiet_warmup_timestamp(?DateTimeImmutable $now = null): int {
        $now = $now ?: current_datetime();
        if( $this->is_within_quiet_hours($now) ) return time() + MINUTE_IN_SECONDS;
        [$hour, $minute] = array_map('intval', explode(':', $this->warmup_quiet_start));
        $next = $now->setTime($hour, $minute);
        if( $next <= $now ) $next = $next->modify('+1 day');
        return $next->getTimestamp();
    }

/** Conservatively detect high host load where adaptive processing should pause. */
    public function is_server_busy(): bool {
        if( ! function_exists('sys_getloadavg') ) return false;
        $load = sys_getloadavg();
        if( ! is_array($load) || ! isset($load[0]) ) return false;
        $cores = 0;
        if( is_readable('/sys/devices/system/cpu/online') ) {
            $online = trim((string) file_get_contents('/sys/devices/system/cpu/online'));
            if( preg_match('/^0-(\d+)$/', $online, $matches) ) $cores = (int) $matches[1] + 1;
        }
        if( !$cores && is_readable('/proc/cpuinfo') ) {
            $cpuinfo = (string) file_get_contents('/proc/cpuinfo');
            $cores = preg_match_all('/^processor\s*:/m', $cpuinfo);
        }
        $threshold = max(1.0, (float) apply_filters('wphave_cache_warmup_load_threshold', max(4.0, $cores * 1.5), $cores));
        return (float) $load[0] >= $threshold;
    }

/** Normalize a user-provided 24-hour time without accepting arbitrary strings. */
    private function normalize_warmup_time($value, string $fallback): string {
        $value = is_string($value) ? $value : '';
        return preg_match('/^(?:[01]\\d|2[0-3]):[0-5]\\d$/', $value) ? $value : $fallback;
    }

/**
     * Atomically finish the warmup generation processed by a worker.
     *
     * A newer warmup may replace the queue while an older worker is still
     * active. The generation guard prevents that worker from stopping or
     * reporting completion for the newer run.
     *
     * @param string $generation Warmup generation observed by the worker.
     * @return bool Whether this generation was marked as completed.
     */

    public function complete_warmup(string $generation) {
        $completed = false;
        $saved = $this->mutate_cache_data(function( $current ) use ( $generation, &$completed ) {
            $current['warmup'] = is_array($current['warmup'] ?? null) ? $current['warmup'] : [];
            if( ! $generation || (string) ($current['warmup']['generation'] ?? '') !== $generation ) {
                return $current;
            }
            $current['warmup']['queue'] = [];
            $current['warmup']['running'] = false;
            $current['warmup']['state'] = 'completed';
            $current['warmup']['scheduled_at'] = 0;
            $current['warmup']['deferred_reason'] = '';
            $completed = true;
            return $current;
        });
        return $saved && $completed;
    }

}
