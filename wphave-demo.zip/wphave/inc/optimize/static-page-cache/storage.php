<?php

require_once __DIR__ . '/search-form-boundary.php';

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Static_Page_Cache_Storage {
	private ?string $prepared_cache_directory = null;
	private ?string $prepared_cache_epoch = null;
	private ?string $prepared_cache_namespace = null;
	private ?string $prepared_cache_authority = null;
	private const STATE_OPTION = 'wphave_cache_data';
	private const STATE_LOCK_OPTION = 'wphave_cache_data_lock';
	private const INVALIDATION_PENDING_OPTION = 'wphave_cache_invalidation_pending';
	// SECURITY INVARIANT (SEC-21): Readers and writers share this policy namespace.
	// Never fall back to older entries: they may contain shared submission identities.
	// Changing the name also excludes their gzip siblings without requiring Cron.
	// SEC-22: Old cached HTML may already contain executable SVG animation.
	// CACHE POLICY INVARIANT: Cached HTML predating the external SVG-reference
	// filter may still request remote resources; a new document namespace makes
	// those old files unreachable before the output filter can run again.
	// COOKIE BOUNDARY INVARIANT: Old generations may contain visitor-specific
	// like or rating state. Namespace replacement makes them unreachable even
	// to later cookie-free visitors before they are cleaned up.
	private const CACHE_DOCUMENT = 'index.cookies-v8.html';
	private const MAX_CONSENT_DOCUMENTS_PER_URL = 64;
	private const CONSENT_DOCUMENT_PATTERN = '/^index\.cookies-v8-consent-[a-f0-9]{64}\.html$/D';

	/**
	 * Persist cache metadata in the WordPress database.
	 *
	 *  This includes:
	 *  - Cache version
	 *  - Cache statistics (hits/misses)
	 *  - Warmup queue state
	 *
	 *  IMPORTANT:
	 *  - Uses autoload = false → prevents unnecessary memory usage
	 *  - Called frequently → must stay lightweight
	 *
	 * @return void
	 */

	private function mutate_cache_data(callable $mutation) {
		$token = false;
		$deadline = microtime(true) + 0.5;

		do {
			$token = WPHAVE_Background_Job_Lock::acquire(self::STATE_LOCK_OPTION, 10);
			if ($token) {
				break;
			}

			usleep(10000);
		} while (microtime(true) < $deadline);

		// SECURITY INVARIANT: Cache state mutation begins only while this call
		// owns the exact token it published. Observing an existing lock or a
		// successor's lock never grants mutation authority.
		if (!$token) {
			return false;
		}

		try {
			$current = get_option(self::STATE_OPTION, []);
			$current = is_array($current) ? $current : [];
			$next = $mutation($current);

			if (!is_array($next)) {
				return false;
			}

			// CONCURRENCY INVARIANT: A mutation may commit only after atomically
			// proving that its lease still belongs to this request.
			if (!WPHAVE_Background_Job_Lock::refresh(self::STATE_LOCK_OPTION, $token)) {
				return false;
			}

			if ($next !== $current && !update_option(self::STATE_OPTION, $next, false)) {
				return false;
			}
			$this->cache_data = $next;
			$this->version = (int) ($next['version'] ?? $this->version);
			return true;
		} finally {
			WPHAVE_Background_Job_Lock::release(self::STATE_LOCK_OPTION, $token);
		}
	}

	private function save_cache_section(string $section, $value) {
		return $this->mutate_cache_data(function ($current) use ($section, $value) {
			$current[$section] = $value;
			return $current;
		});
	}

	private function has_pending_invalidation(): bool {
		return (string) get_option(self::INVALIDATION_PENDING_OPTION, '') !== '';
	}

	/** Respect the WordPress-wide page-cache veto at every delivery boundary. */
	private function page_cache_is_forbidden(): bool {
		return defined('DONOTCACHEPAGE') && DONOTCACHEPAGE;
	}

	/** Refuse symlinks in every cache directory below the trusted temp parent. */
	private function cache_directory_is_safe(string $directory): bool {
		$parent = realpath($this->private_cache_parent());
		if (!is_string($parent)) {
			return false;
		}
		$parent = rtrim($parent, DIRECTORY_SEPARATOR);
		$directory = rtrim($directory, DIRECTORY_SEPARATOR);
		if (
			$directory !== $parent &&
			!str_starts_with($directory, $parent . DIRECTORY_SEPARATOR)
		) {
			return false;
		}
		$relative = ltrim(substr($directory, strlen($parent)), DIRECTORY_SEPARATOR);
		$cursor = $parent;
		foreach ($relative === '' ? [] : explode(DIRECTORY_SEPARATOR, $relative) as $segment) {
			if ($segment === '' || $segment === '.' || $segment === '..') {
				return false;
			}
			$cursor .= DIRECTORY_SEPARATOR . $segment;
			if (is_link($cursor) || (file_exists($cursor) && !is_dir($cursor))) {
				return false;
			}
		}
		return true;
	}

	/** Empty means no invalidation yet; null means the marker is unsafe or in flight. */
	private function read_cache_epoch(string $directory): ?string {
		if (!$this->cache_directory_is_safe($directory)) {
			return null;
		}
		$marker = $directory . '/.wphave-url-epoch';
		if (!file_exists($marker) && !is_link($marker)) {
			return '';
		}
		try {
			$observed = WPHAVE_Security_File_Identity::read_bounded(
				$marker,
				64,
				false,
				'Cache invalidation marker is unsafe.',
			);
		} catch (RuntimeException $error) {
			return null;
		}
		$token = $observed['content'];
		return !$observed['truncated'] && preg_match('/^[a-f0-9-]{36}$/D', $token)
			? $token
			: null;
	}

	/** Capture the URL generation before rendering can observe stale content. */
	private function remember_cache_epoch(string $file): bool {
		$directory = dirname($file);
		if ($this->prepared_cache_directory === $directory) {
			return $this->prepared_cache_epoch !== null;
		}
		$this->prepared_cache_directory = $directory;
		$this->prepared_cache_epoch = $this->read_cache_epoch($directory);
		return $this->prepared_cache_epoch !== null;
	}

	/** Keep response-header decisions observable in isolated cache tests. */
	protected function emit_cache_header(string $header, bool $replace = true): void {
		if (!headers_sent()) {
			header($header, $replace);
		}
	}

	/** A cache hit must own the complete body and still be able to set its headers. */
	private function early_response_is_pristine(): bool {
		if (headers_sent()) {
			return false;
		}

		foreach (ob_get_status(true) as $buffer) {
			if (($buffer['buffer_used'] ?? 0) > 0) {
				return false;
			}
		}

		return true;
	}

	/** Refuse a hit selected before another request advanced the generation. */
	private function cache_generation_is_current(): bool {
		$current = get_option(self::STATE_OPTION, []);
		if (!is_array($current) || (int) ($current['version'] ?? 0) !== $this->version) {
			return false;
		}

		return $this->cache_dir !== '' && $this->cache_dir === $this->build_cache_dir();
	}

	/** Recheck the selected document after operations that may interleave invalidation. */
	private function cache_hit_is_current(string $file): bool {
		return $this->early_response_is_pristine() &&
			$this->cache_generation_is_current() &&
			!$this->has_pending_invalidation() &&
			$this->read_cache_epoch(dirname($file)) === $this->prepared_cache_epoch;
	}

	/** Core's later send_headers() must choose the same representation as a hit. */
	private function site_html_type_is_supported(): bool {
		return strcasecmp((string) get_option('html_type', 'text/html'), 'text/html') === 0;
	}

	private function mark_cache_invalidation_pending(string $token): bool {
		update_option(self::INVALIDATION_PENDING_OPTION, $token, false);
		return get_option(self::INVALIDATION_PENDING_OPTION, '') === $token;
	}

	private function clear_cache_invalidation_pending(string $token): void {
		global $wpdb;

		// INVALIDATION ORDER INVARIANT: Delete only our own marker. A newer
		// invalidation may have replaced it while this request held the state lock.
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s",
				self::INVALIDATION_PENDING_OPTION,
				$token,
			),
		);
		wp_cache_delete(self::INVALIDATION_PENDING_OPTION, 'options');
	}

	/**
	 * Serve an existing static HTML cache file as early as possible.
	 *
	 *  This drastically reduces load by bypassing WordPress completely
	 *  for cacheable requests.
	 *
	 *  IMPORTANT:
	 *  - Runs on 'init' with priority 0 (very early)
	 *  - Sends proper headers (cache + gzip)
	 *  - Terminates execution immediately (exit)
	 *
	 * @return void
	 */

	public function maybe_serve_cache() {
		if ($this->page_cache_is_forbidden()) {
			return;
		}
		// A prior bootstrap hook may have selected a redirect or error response.
		// Never attach cached HTML to a status other than the stored 200 response.
		$response_status = http_response_code();
		// PHP reports false before any explicit status is set. The implicit
		// response in that state is 200 and must remain eligible for a hit.
		if (false !== $response_status && 200 !== $response_status) {
			return;
		}
		if (!$this->is_early_cacheable_request()) {
			return;
		}
		if (!$this->cache_generation_is_current()) {
			return;
		}
		if (!$this->early_response_is_pristine()) {
			return;
		}
		// Headers sent by earlier bootstrap hooks are part of the response policy.
		// A static hit cannot replay a private response or its cookie safely.
		$early_headers = $this->current_response_headers();
		$charset = (string) get_option('blog_charset', 'UTF-8');
		if (
			!$this->site_html_type_is_supported() ||
			!preg_match('/^[A-Za-z0-9._-]+$/D', $charset) ||
			$this->response_has_private_headers($early_headers) ||
			!$this->response_matches_site_html_charset($early_headers, $charset, true)
		) {
			return;
		}

		$file = $this->get_cache_file_path();
		if (!$file || !$this->remember_cache_epoch($file)) {
			return;
		}

		if (file_exists($file)) {
			$accepts_gzip = $this->request_accepts_gzip();
			$gzip_path = $file . '.gz';
			$serve_gzip = $accepts_gzip && file_exists($gzip_path);
			$response_path = $serve_gzip ? $gzip_path : $file;

			try {
				$response = WPHAVE_Security_File_Identity::open_stream(
					$response_path,
					__('The static cache entry changed before it could be served.', 'wphave'),
				);
			} catch (RuntimeException $error) {
				// CACHE DELIVERY INVARIANT: An unsafe, missing, linked or racing
				// cache node is a miss. WordPress renders the request normally.
				return;
			}
			if (!$this->cache_hit_is_current($file)) {
				WPHAVE_Security_File_Identity::close($response);
				return;
			}

			$this->increment_stat('hits');
			if (!$this->cache_hit_is_current($file)) {
				WPHAVE_Security_File_Identity::close($response);
				return;
			}

			header('X-WPHAVE-CACHE: HIT');
			// The init hit exits before WordPress sends its usual HTML header.
			// Keep the stored representation explicit for clients and proxies.
			if (!$this->response_is_html($early_headers)) {
				header('Content-Type: text/html; charset=' . $charset);
			}

			// INTERMEDIARY INVARIANT: Consent has its own local file variant. A
			// proxy must also distinguish Cookie before replaying this response.
			header('Vary: Cookie, Accept-Encoding');

			// SHARED-CACHE INVARIANT: A page may become private immediately after
			// publication. An external proxy has no access to our version bump, so
			// it must revalidate every response and may never serve stale HTML.
			header('Cache-Control: public, max-age=0, s-maxage=0, must-revalidate');
			header('Expires: ' . gmdate('D, d M Y H:i:s', time()) . ' GMT');

			$is_head = $_SERVER['REQUEST_METHOD'] === 'HEAD';

			if ($serve_gzip) {
				header('Content-Encoding: gzip');
			}
			header('Content-Length: ' . $response['bytes']);

			// CACHE STREAM INVARIANT: Encoding, length and response bytes all
			// describe the exact locked regular-file revision opened above.
			if (!$is_head) {
				fpassthru($response['handle']);
			}

			WPHAVE_Security_File_Identity::close($response);

			// ! Without this early exit, WordPress would still continue running.
			exit();
		}
	}

	/**
	 * Prepare cache state and miss handling before the output pipeline runs.
	 *
	 *  This method replaces the old "start_buffering" logic and is now
	 *  responsible for early cache-related decisions WITHOUT starting
	 *  its own output buffer.
	 *
	 *  - Determines whether the current request is cacheable
	 *  - Detects cache MISS (no existing cache file)
	 *  - Sets appropriate HTTP headers for non-cached responses
	 *  - Defers miss statistics until the final response passes storage checks
	 *
	 *  This method DOES NOT start output buffering anymore.
	 *
	 *  Buffering is now handled globally by:
	 *
	 *      WPHAVE_Output_Buffer
	 *
	 *  The cache system is integrated into that pipeline and only:
	 *
	 *  - prepares state here (early phase)
	 *  - writes cache later via buffer callback (store_cache)
	 *
	 *  1. maybe_serve_cache() → serves existing cache (early exit)
	 *  2. maybe_prepare_cache() → detects MISS + sets headers
	 *  3. Output buffer pipeline runs
	 *  4. store_cache() → writes final HTML
	 *
	 *  - Consent processing runs BEFORE cache storage (in buffer pipeline)
	 *  - Cache always stores FINAL processed HTML
	 *  - This ensures:
	 *
	 *      ✔ No executable tracking scripts are cached
	 *      ✔ GDPR-compliant output is persisted
	 *
	 *  For cache MISS:
	 *  - Prevent browser caching during generation phase
	 *  - Ensures fresh content delivery
	 *
	 * @return void
	 */

	public function maybe_prepare_cache() {
		if ($this->page_cache_is_forbidden()) {
			return;
		}
		if (!$this->is_cacheable_request_after_query()) {
			return;
		}
		// RENDER GENERATION INVARIANT: This response may only publish into the
		// namespace that was current before WordPress rendered its body.
		$this->prepared_cache_namespace = $this->cache_dir;
		$this->prepared_cache_authority = $this->cache_authority();

		$file = $this->get_cache_file_path();
		// A missing or unsafe cache file can still fall through to a live response.
		// Declare the consent dimension there as well, while retaining any
		// origin-declared dimension for the final-response safety check.
		$this->emit_cache_header('Vary: Cookie, Accept-Encoding', false);
		if (!$file || !$this->remember_cache_epoch($file)) {
			// A damaged or interrupted URL epoch cannot authorize a shared
			// representation at an intermediary either.
			$this->emit_cache_header('Cache-Control: private, no-store, max-age=0');
			return;
		}

		// MISS detection (nur wenn KEIN Cache existiert)
		if (
			!file_exists($file) &&
			!$this->response_has_cache_control_header($this->current_response_headers())
		) {
			// Browser soll NICHT cachen → wir generieren gerade neu
			$this->emit_cache_header('Cache-Control: ' . self::CACHE_MISS_CONTROL);

		}
	}

	/**
	 * Build a versioned cache-directory path for the current host.
	 *
	 *  Example:
	 *  /wp-content/cache/wphave-static/domain.com/v3/
	 *
	 *  IMPORTANT:
	 *  - Versioning allows instant global cache invalidation
	 *  - Host-based separation supports multisite/multi-domain setups
	 *
	 * @return string Versioned cache-directory path.
	 */

	private function build_cache_dir() {
		$base_dir = $this->cache_base_dir();

		if ($base_dir === '') {
			return '';
		}

		$version = (int) $this->version;

		return trailingslashit($base_dir . $this->cache_authority() . '/v' . $version);
	}

	/** Return the canonical directory that owns every static-cache namespace. */

	private function cache_base_dir() {
		$parent = $this->private_cache_parent();
		$parent = is_string($parent) ? realpath($parent) : false;
		if (!is_string($parent) || !is_dir($parent)) {
			return '';
		}
		$site_root = realpath(ABSPATH);
		$content_root = realpath(WP_CONTENT_DIR);
		if (!is_string($site_root) || !is_string($content_root)) {
			return '';
		}
		$identity = hash('sha256', $site_root . '|' . $content_root . '|' . get_current_blog_id());
		$private = rtrim($parent, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR .
			'wphave-static-' . $identity;
		foreach ([$site_root, $content_root, $_SERVER['DOCUMENT_ROOT'] ?? ''] as $web_root) {
			$web_root = is_string($web_root) && $web_root !== '' ? realpath($web_root) : false;
			if (
				is_string($web_root) &&
				(str_starts_with($private, rtrim($web_root, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR) ||
					$private === $web_root)
			) {
				return '';
			}
		}

		if (!is_dir($private) && !@mkdir($private, 0700)) {
			return '';
		}
		$stat = @lstat($private);
		// CACHE CONFIDENTIALITY INVARIANT: HTML never lives under a public URL
		// or in a shared temp directory readable by another system account.
		if (
			is_link($private) ||
			!is_array($stat) ||
			!is_dir($private) ||
			($stat['mode'] & 0077) !== 0 ||
			(function_exists('posix_geteuid') && $stat['uid'] !== posix_geteuid())
		) {
			return '';
		}
		return trailingslashit(wp_normalize_path($private));
	}

	/** Keep private cache selection testable without changing production policy. */
	protected function private_cache_parent(): string {
		return sys_get_temp_dir();
	}

	/** Remove prior web-addressable HTML, including obsolete document namespaces. */
	private function cleanup_legacy_public_cache(): bool {
		$content_root = realpath(WP_CONTENT_DIR);
		if (!is_string($content_root)) {
			return false;
		}
		$legacy = $content_root . '/cache/wphave-static';
		if (!file_exists($legacy) && !is_link($legacy)) {
			return true;
		}
		if (is_link($legacy) || !is_dir($legacy)) {
			return false;
		}
		// MIGRATION INVARIANT: Only the exact former WPHAVE cache root may be
		// removed. A symlink never redirects cleanup into another data tree.
		$this->delete_dir($legacy);
		return !file_exists($legacy) && !is_link($legacy);
	}

	/** Return the configured public authority used for cache isolation. */
	protected function cache_release_version(): string {
		return defined('WPHAVE_VERSION') ? (string) WPHAVE_VERSION : '';
	}

	private function cache_authority() {
		$site_url = home_url();
		$host = (string) (parse_url($site_url, PHP_URL_HOST) ?: 'default');
		$scheme = strtolower((string) parse_url($site_url, PHP_URL_SCHEME));
		$port = (int) (parse_url($site_url, PHP_URL_PORT) ?: ('https' === $scheme ? 443 : 80));
		$charset = strtolower((string) get_option('blog_charset', 'UTF-8'));
		$authority = $scheme . '://' . strtolower($host) . ':' . $port . '|' . $charset;
		$release_authority = $authority . '|' . $this->cache_release_version();

		// CACHE AUTHORITY INVARIANT: A new plugin release may change markup,
		// assets or consent behavior without changing saved site settings.
		// Never replay its predecessor's HTML or derive identity from request Host.
		return sanitize_file_name($host) . '-' . substr(hash('sha256', $release_authority), 0, 16);
	}

	/** Retire private authorities from previous cache identity policies. */
	private function cleanup_legacy_authority_cache(): void {
		$base_dir = $this->cache_base_dir();
		if ($base_dir === '') {
			return;
		}
		$site_url = home_url();
		$host = (string) (parse_url($site_url, PHP_URL_HOST) ?: 'default');
		$scheme = strtolower((string) parse_url($site_url, PHP_URL_SCHEME));
		$port = (int) (parse_url($site_url, PHP_URL_PORT) ?: ('https' === $scheme ? 443 : 80));
		$default_port = 'https' === $scheme ? 443 : 80;
		$legacy = sanitize_file_name($host . ($port !== $default_port ? '-' . $port : ''));
		$remaining = 128;
		if ($legacy !== $this->cache_authority()) {
			$remaining -= $this->delete_dir($base_dir . $legacy, $remaining);
		}
		// Authority directories are owned by this site's private cache root.
		// Reclaim older schemes, charsets and releases without touching the
		// current namespace or a child URL directory inside it.
		$prefix = sanitize_file_name($host) . '-';
		$current_authority = $this->cache_authority();
		try {
			foreach (new DirectoryIterator($base_dir) as $entry) {
				if ($remaining <= 0) {
					break;
				}
				$name = $entry->getFilename();
				if (
					$entry->isLink() ||
					!$entry->isDir() ||
					$name === $current_authority ||
					!preg_match('/^' . preg_quote($prefix, '/') . '[a-f0-9]{16}$/D', $name)
				) {
					continue;
				}
				$remaining -= $this->delete_dir($entry->getPathname(), $remaining);
			}
		} catch (UnexpectedValueException $error) {
			// Cleanup is optional; old namespaces remain unreadable by identity.
		}
	}

	/**
	 * Store the generated HTML in the static cache.
	 *
	 *  Includes:
	 *  - Atomic file writes
	 *  - File locking to prevent race conditions
	 *  - Optional gzip compression
	 *
	 *  IMPORTANT:
	 *  - Prevents duplicate writes via lock files
	 *  - Uses temp files + rename (atomic)
	 *
	 * @param string $html Final processed HTML.
	 * @return string Unchanged HTML for the output-buffer pipeline.
	 */

	public function store_cache($html) {
		// INVALIDATION INVARIANT: A failed version bump must also stop new
		// writes until a later successful invalidation clears its marker.
		if ($this->has_pending_invalidation()) {
			return $html;
		}
		// Rendering discovers nested/reusable time rules after the early cacheability decision.
		if (
			class_exists('WPHAVE_Block_Conditions_Runtime') &&
			WPHAVE_Block_Conditions_Runtime::has_scheduled_output()
		) {
			$this->record_bypass('scheduled_output');
			return $html;
		}
		// A renderer may define the veto after request eligibility was memoized.
		// Keep the explicit scheduled-output diagnosis above this generic veto.
		if ($this->page_cache_is_forbidden()) {
			return $html;
		}
		if (!$this->is_cacheable_request_after_query()) {
			return $html;
		}
		if (
			($this->prepared_cache_namespace !== null &&
				$this->prepared_cache_namespace !== $this->cache_dir) ||
			($this->prepared_cache_authority !== null &&
				$this->prepared_cache_authority !== $this->cache_authority())
		) {
			return $html;
		}
		if (http_response_code() !== 200) {
			$this->record_bypass('response_status');
			return $html;
		}

		/*
		 * CACHE CONFIDENTIALITY INVARIANT: Application response privacy is
		 * authoritative. A response which creates a cookie or declares itself
		 * private/no-store can never be promoted into anonymous shared state.
		 */
		$response_headers = $this->current_response_headers();
		$private_header_reason = $this->response_private_header_reason($response_headers);
		if (null !== $private_header_reason) {
			$this->record_bypass($private_header_reason);
			return $html;
		}
		if (!$this->response_is_html($response_headers)) {
			$this->record_bypass('non_html');
			return $html;
		}
		$charset = (string) get_option('blog_charset', 'UTF-8');
		if (
			!preg_match('/^[A-Za-z0-9._-]+$/D', $charset) ||
			!$this->response_matches_site_html_charset($response_headers, $charset, false)
		) {
			$this->record_bypass('non_html');
			return $html;
		}

		// SECURITY INVARIANT (SEC-21): Form state belongs to an individual visit.
		// Consent elsewhere in the document cannot authorize sharing another form's
		// nonce or delivery identity. Conservatively exclude all forms, including
		// consent-only forms, and identity fields even without a surrounding form.
		foreach (['_wpnonce', '_wphave_form_nonce', '_wphave_submission_id'] as $marker) {
			if (stripos($html, $marker) !== false) {
				$this->record_bypass('form_state');
				return $html;
			}
		}
		if (
			stripos($html, '<form') !== false &&
			!WPHAVE_Static_Page_Cache_Search_Form_Boundary::allows($html)
		) {
			$this->record_bypass('form_state');
			return $html;
		}

		// Prevents, for example, AJAX or fragment HTML from being cached.
		if (stripos($html, '<html') === false || stripos($html, '</html>') === false) {
			$this->record_bypass('incomplete_html');
			return $html;
		}

		$file = $this->get_cache_file_path();
		if (!$file || !$this->remember_cache_epoch($file)) {
			return $html;
		}
		$dir = dirname($file);
		if (!$this->cache_directory_is_safe($dir)) {
			return $html;
		}

		if (!file_exists($dir)) {
			wp_mkdir_p($dir);
		}
		if (!$this->cache_directory_is_safe($dir)) {
			return $html;
		}

		if (file_exists($file)) {
			return $html;
		}

		// A request is a cache miss only when its final response is safe to
		// store. Forms, private headers and other excluded output must not
		// depress the hit rate of pages that can actually use this cache.
		$this->increment_stat('misses');

		// PUBLICATION INVARIANT: Only the writer that commits the final HTML file
		// may count a publication. A concurrent writer or aborted epoch must not.
		$published = false;
		try {
			// All consent variants of one URL share a publication lock with URL
			// invalidation. Compare the pre-render epoch while holding that lock.
			WPHAVE_Security_File_Mutex::run($dir . '/.wphave-url.lock', function () use (
				$dir,
				$file,
				&$html,
				&$published,
			): void {
				if (
					$this->read_cache_epoch($dir) !== $this->prepared_cache_epoch ||
					$this->has_pending_invalidation()
				) {
					return;
				}
				if (!$this->consent_variant_capacity_available($dir, $file)) {
					return;
				}
				// Keep the existing per-file lock for same-variant publication.
				WPHAVE_Security_File_Mutex::run($file . '.lock', function () use (
					$file,
					&$html,
					&$published,
				): void {
					if (file_exists($file)) {
						return;
					}
					$html = $this->compressed ? (string) new wphave_html_compression($html) : $html;
					$mode = WPHAVE_Security_File_Permissions::for_new_public_file($file);
					$gzip_identity = null;
					// PUBLICATION INVARIANT: No incomplete cache entry becomes serveable.
					// I/O failure preserves the response and leaves a retryable cache miss.
					if (strlen($html) > 1024) {
						$gz = gzencode($html, 6);
						if (false === $gz) {
							throw new RuntimeException('Cache compression failed.');
						}
						WPHAVE_Security_Atomic_File::write(
							$file . '.gz',
							$gz,
							'Compressed cache write failed.',
							$mode,
						);
						$gzip_identity = @lstat($file . '.gz');
					} elseif (is_file($file . '.gz') && !@unlink($file . '.gz')) {
						throw new RuntimeException('Obsolete compressed cache could not be removed.');
					}
					try {
						WPHAVE_Security_Atomic_File::write_new($file, $html, 'Cache write failed.', $mode);
						$published = true;
					} catch (RuntimeException $error) {
						// The gzip sibling is only useful with its owning HTML document.
						// Compare inode identity so cleanup cannot remove a replacement.
						if (is_array($gzip_identity)) {
							clearstatcache(true, $file . '.gz');
							$current = @lstat($file . '.gz');
							if (
								is_array($current) &&
								$current['dev'] === $gzip_identity['dev'] &&
								$current['ino'] === $gzip_identity['ino']
							) {
								@unlink($file . '.gz');
							}
						}
						throw $error;
					}
					clearstatcache(true, $file);
				});
			});
		} catch (RuntimeException $error) {
			// CACHE INVARIANT: Keep the live response, but expose a bounded reason
			// code so repeated misses caused by failed publication are diagnosable.
			try {
				$this->record_storage_failure($error);
			} catch (Throwable $diagnostic_error) {
				// Optional metrics must not turn a cache failure into a page failure.
			}
		}
		if ($published) {
			try {
				$this->increment_stat('publications');
			} catch (Throwable $diagnostic_error) {
				// A committed cache file remains valid even if its metric cannot persist.
			}
		}

		return $html;
	}

	/** Bound exact-cookie variants without merging different consent responses. */
	private function consent_variant_capacity_available(string $directory, string $file): bool {
		if (!preg_match(self::CONSENT_DOCUMENT_PATTERN, basename($file))) {
			return true;
		}

		// This check runs under the URL publication lock shared by all variants.
		// The browser still receives the live response when the cap is reached.
		$count = 0;
		foreach (new DirectoryIterator($directory) as $entry) {
			if (
				$entry->isFile() &&
				preg_match(self::CONSENT_DOCUMENT_PATTERN, $entry->getFilename())
			) {
				++$count;
				if ($count >= self::MAX_CONSENT_DOCUMENTS_PER_URL) {
					return false;
				}
			}
		}
		return true;
	}

	/**
	 * Determine whether the current request is safe to cache.
	 *
	 *  This is the MOST critical part of the system.
	 *
	 *  IMPORTANT:
	 *  - Prevents caching of dynamic / user-specific content
	 *  - Protects WooCommerce, sessions, and logged-in users
	 *
	 * @return bool Whether the request may be cached.
	 */

	private function evaluate_early_cacheability() {
		$uri = $_SERVER['REQUEST_URI'] ?? '/';

		if ($this->page_cache_is_forbidden()) {
			return false;
		}

		// INVALIDATION INVARIANT: A failed version bump may leave an old file
		// on disk. Never serve it while the durable pending marker exists.
		if ($this->has_pending_invalidation()) {
			return false;
		}

		// WP-CLI inherits a synthetic GET request. Serving cached HTML here would
		// terminate commands before they execute and can also emit invalid headers.
		if (defined('WP_CLI') && WP_CLI) {
			return false;
		}

		/*
		 * A validated Request Profiler session must execute the complete WordPress
		 * lifecycle. Serving or storing a static response would terminate the
		 * request during init and produce an incomplete, misleading profile.
		 * Invalid profiling headers do not bypass caching because is_active() only
		 * becomes true after token and exact-target validation.
		 */
		if (class_exists('WPHAVE_Request_Profiler') && WPHAVE_Request_Profiler::is_active()) {
			return false;
		}

		/*
		 * Access modes must be evaluated before an existing HTML file can be
		 * served at `init`. Their content hooks run later on `wp`, so allowing
		 * an early cache hit here would expose the regular website and end the
		 * request before Coming Soon or Maintenance can replace its content.
		 *
		 * These temporary documents are deliberately not stored in the normal
		 * page cache either. Maintenance must preserve its 503 response, and
		 * both modes must disappear immediately when their add-on is disabled.
		 */

		if (class_exists('WPHAVE_Maintenance_Mode') && WPHAVE_Maintenance_Mode::is_active()) {
			return false;
		}
		if (class_exists('WPHAVE_Coming_Soon') && WPHAVE_Coming_Soon::is_active()) {
			return false;
		}

		// Only GET/HEAD → never cache POST!
		if (!in_array($_SERVER['REQUEST_METHOD'], ['GET', 'HEAD'])) {
			return false;
		}

		/*
		 * CACHE AUTHORITY INVARIANT: Cache identity comes from the WordPress site
		 * selected during bootstrap, never from an untrusted Host header. Foreign
		 * authorities may neither consume nor populate that site's cache files.
		 */
		$site_url = home_url();
		if (
			!$this->request_host_matches_site((string) ($_SERVER['HTTP_HOST'] ?? ''), $site_url) ||
			!$this->request_scheme_matches_site($site_url, is_ssl())
		) {
			return false;
		}

		/*
		 * CACHE CONFIDENTIALITY INVARIANT: A request carrying credentials must
		 * never read from or write to the shared anonymous page cache. WordPress
		 * login cookies are only one authentication mechanism; REST clients,
		 * reverse proxies and integrations may authenticate through these server
		 * variables before WordPress has established a logged-in cookie session.
		 */
		if ($this->has_request_credentials()) {
			return false;
		}

		if ($this->has_visitor_cookies()) {
			return false;
		}

		if (preg_match('/\.(txt|xml)$/', $uri)) {
			return false;
		}

		// Query parameters can generate dynamic content.
		if ($this->has_disallowed_query_params()) {
			return false;
		}
		if ($this->has_noncanonical_cache_path()) {
			return false;
		}

		if (!empty($_POST)) {
			return false;
		}

		// Logged in users
		if (is_user_logged_in()) {
			return false;
		}

		// Admin
		if (is_admin()) {
			return false;
		}

		// Customizer
		if (is_customize_preview()) {
			return false;
		}

		// Static files
		if (
			preg_match(
				'/\.(js|css|json|xml|txt|map|png|jpg|jpeg|gif|svg|webp|ico|woff|woff2|ttf|eot)$/i',
				$uri,
			)
		) {
			return false;
		}

		if (defined('DOING_AJAX') && DOING_AJAX) {
			return false;
		}

		if (defined('REST_REQUEST') && REST_REQUEST) {
			return false;
		}

		// Core paths
		if (strpos($uri, '/wp-json/') !== false) {
			return false;
		}
		if (strpos($uri, '/wp-admin/') !== false) {
			return false;
		}
		if (strpos($uri, '/wp-content/') !== false) {
			return false;
		}
		if (strpos($uri, '/wp-includes/') !== false) {
			return false;
		}

		// Custom excluded URLs
		if ($this->is_excluded_url($uri)) {
			return false;
		}

		// WooCommerce logic
		if (class_exists('WPHAVE_WooCommerce')) {
			$woo = WPHAVE_WooCommerce::context();
			if (WPHAVE_WooCommerce::is_cart_checkout_or_account()) {
				return false;
			}
			if (!empty($woo['is_thank_you'])) {
				return false;
			}

			// WooCommerce Edge Case: Add-to-cart may NEVER be cached
			if (WPHAVE_WooCommerce::is_add_to_cart_request()) {
				return false;
			}

			// CRITICAL: prevents incorrect shopping carts in the cache
			if (WPHAVE_WooCommerce::has_active_cart_session()) {
				return false;
			}
		}

		return apply_filters('wphave_should_cache_request', true);
	}

	/**
	 * Check only request state that is authoritative before the main query.
	 *
	 * Cache hits run on init, where conditional tags and the queried object are
	 * not available yet. Files can only exist after passing the complete
	 * post-query storage check, so this early gate deliberately contains no
	 * query-dependent conditions.
	 *
	 * @return bool Whether an existing cache artifact may be served.
	 */

	private function is_early_cacheable_request() {
		return $this->evaluate_early_cacheability();
	}

	/**
	 * Return the request-level cached result of the post-query evaluation.
	 *
	 *  Ensures that the expensive evaluation logic only runs once
	 *  per request.
	 *
	 *  IMPORTANT:
	 *  - Prevents redundant computation
	 *  - Improves performance
	 *
	 * @return bool Whether the request may be cached.
	 */

	private function is_cacheable_request_after_query() {
		if ($this->is_cacheable_after_query !== null) {
			return $this->is_cacheable_after_query;
		}

		if (
			!$this->evaluate_early_cacheability() ||
			is_404() ||
			is_feed() ||
			is_preview() ||
			is_attachment()
		) {
			$this->is_cacheable_after_query = false;
			return false;
		}

		$post = get_queried_object();
		if (is_singular() && (!($post instanceof WP_Post) || 'publish' !== $post->post_status)) {
			$this->is_cacheable_after_query = false;
			return false;
		}

		if ($post instanceof WP_Post && post_password_required($post)) {
			$this->is_cacheable_after_query = false;
			return false;
		}

		$this->is_cacheable_after_query = true;
		return true;
	}

	/**
	 * Resolve the cache-file path for the current request.
	 *
	 *  Example:
	 *  /about/ → /cache/.../about/<current policy document>
	 *
	 *  IMPORTANT:
	 *  - Uses clean directory structure (SEO-like URLs)
	 *  - Avoids query string duplication
	 *
	 * @return string Absolute cache-file path.
	 */

	private function get_cache_file_path() {
		if ($this->cache_dir === '') {
			return null;
		}

		$variant = $this->consent_cache_variant();
		if (null === $variant) {
			return null;
		}
		$document = '' === $variant
			? self::CACHE_DOCUMENT
			: 'index.cookies-v8-consent-' . $variant . '.html';

		$path = $this->normalize_cache_url_path($_SERVER['REQUEST_URI'] ?? '/');
		if ($path === null) {
			return null;
		}

		if (empty($path)) {
			return $this->cache_dir . $document;
		}

		return $this->cache_dir . $path . '/' . $document;
	}

	/**
	 * Convert a request URL into a traversal-safe relative cache path.
	 *
	 * @param string $url Request URI or absolute URL.
	 * @return string|null Normalized relative path, or null when unsafe.
	 */

	private function normalize_cache_url_path($url) {
		$path = parse_url($url, PHP_URL_PATH);
		if (!is_string($path)) {
			return null;
		}
		// CACHE KEY INVARIANT: One pathname must map to one representation.
		// Decoding escapes or dropping repeated slashes aliases distinct request
		// targets, whose WordPress routing and access rules may differ.
		if (str_contains($path, '%') || str_contains($path, '//')) {
			return null;
		}

		$path = rawurldecode($path);
		if (
			strpos($path, "\0") !== false ||
			strpos($path, '\\') !== false ||
			preg_match('/[\x00-\x1F\x7F]/', $path)
		) {
			return null;
		}

		$segments = [];
		foreach (explode('/', trim($path, '/')) as $segment) {
			if ($segment === '') {
				continue;
			}
			if ($segment === '.' || $segment === '..') {
				return null;
			}
			$segments[] = rawurlencode($segment);
		}

		if (in_array('', $segments, true)) {
			return null;
		}
		return implode('/', $segments);
	}

	/**
	 * Delete a cache directory and all of its contents recursively.
	 *
	 *  IMPORTANT:
	 *  - Used for cache invalidation
	 *  - Must handle nested structures safely
	 *
	 * @param string $dir Absolute cache-directory path.
	 * @param int $maximum_entries Maximum entries to attempt in this call.
	 * @return int Number of entries attempted; callers can resume later.
	 */

	private function delete_dir($dir, int $maximum_entries = PHP_INT_MAX): int {
		if ($maximum_entries < 1 || is_link($dir) || !is_dir($dir)) {
			return 0;
		}
		$processed = 0;
		try {
			$files = new RecursiveIteratorIterator(
				new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS),
				RecursiveIteratorIterator::CHILD_FIRST,
			);

			// DELETE INVARIANT: Never follow a child symlink out of the exact
			// cache tree during invalidation or public-cache migration.
			foreach ($files as $file) {
				if ($processed >= $maximum_entries) {
					break;
				}
				$path = $file->getPathname();

				if ($file->isLink() || !$file->isDir()) {
					@unlink($path);
				} else {
					@rmdir($path);
				}
				++$processed;
			}
		} catch (UnexpectedValueException $error) {
			return $processed;
		}

		@rmdir($dir);
		return $processed;
	}

	/**
	 * Delete only the cache documents corresponding to a URL.
	 *
	 *  IMPORTANT:
	 *  - Maps URL → filesystem path
	 *  - Preserves child URL directories at every depth
	 *
	 * @param string $url Absolute frontend URL.
	 * @return void
	 */

	private function delete_cache_by_url($url) {
		if ($this->cache_dir === '') {
			return;
		}
		$path = $this->normalize_cache_url_path($url);
		if ($path === null) {
			return;
		}

		// Any URL can be a parent of other URLs, including the home path of a
		// subdirectory installation. Never recursively delete its directory.
		$dir = $this->cache_dir . $path;
		if (!$this->cache_directory_is_safe($dir)) {
			$this->invalidate_all();
			return;
		}
		if (!is_dir($dir)) {
			wp_mkdir_p($dir);
		}
		if (!$this->cache_directory_is_safe($dir) || !is_dir($dir)) {
			$this->invalidate_all();
			return;
		}
		try {
			WPHAVE_Security_File_Mutex::run($dir . '/.wphave-url.lock', function () use ($dir): void {
				$token = wp_generate_uuid4();
				$marker = $dir . '/.wphave-url-epoch';
				// An interrupted invalidation remains visibly unsafe to readers.
				WPHAVE_Security_Atomic_File::write(
					$marker,
					'!' . $token,
					'Cache URL invalidation could not begin.',
				);
				foreach (new DirectoryIterator($dir) as $entry) {
					if (
						!preg_match(
							'/^index\.cookies-v8(?:-consent-[a-f0-9]{64})?\.html(?:\.gz)?$/D',
							$entry->getFilename(),
						) ||
						(!$entry->isFile() && !$entry->isLink())
					) {
						continue;
					}
					if (!@unlink($entry->getPathname()) && file_exists($entry->getPathname())) {
						throw new RuntimeException('Cache URL document could not be removed.');
					}
				}
				WPHAVE_Security_Atomic_File::write(
					$marker,
					$token,
					'Cache URL invalidation could not finish.',
				);
			});
		} catch (RuntimeException $error) {
			$this->invalidate_all();
		}
	}

	/**
	 * Remove outdated versioned cache directories.
	 *
	 *  Keeps only a limited number of recent versions to avoid
	 *  unnecessary disk usage.
	 *
	 *  IMPORTANT:
	 *  - Prevents disk bloat
	 *  - Safe cleanup (keeps recent versions)
	 *
	 * @param int $current_version Version that was current before invalidation.
	 * @return void
	 */

	private function cleanup_old_cache_versions($current_version) {
		$base_dir = $this->cache_base_dir();

		if ($base_dir === '') {
			return;
		}

		$path = trailingslashit($base_dir . $this->cache_authority());

		if (!is_dir($path)) {
			return;
		}

		// Security mechanism: retains last versions
		$keep_versions = 2;

		$cache_directories = glob($path . 'v*');

		foreach (is_array($cache_directories) ? $cache_directories : [] as $dir) {
			if (!preg_match('/v(\d+)$/', $dir, $matches)) {
				continue;
			}

			$version = (int) $matches[1];

			if ($version < $current_version - $keep_versions) {
				$this->delete_dir($dir);
			}
		}
	}
}
