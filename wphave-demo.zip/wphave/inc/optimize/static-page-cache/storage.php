<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Static_Page_Cache_Storage {
	private const STATE_OPTION = 'wphave_cache_data';
	private const STATE_LOCK_OPTION = 'wphave_cache_data_lock';
	private const INVALIDATION_PENDING_OPTION = 'wphave_cache_invalidation_pending';
	// SECURITY INVARIANT (SEC-21): Readers and writers share this policy namespace.
	// Never fall back to older entries: they may contain shared submission identities.
	// Changing the name also excludes their gzip siblings without requiring Cron.
	// SEC-22: Old cached HTML may already contain executable SVG animation.
	// CACHE POLICY INVARIANT: Cached HTML predating the external SVG-reference
	// filter may still request remote resources; a new document namespace makes
	// those old files unreachable before the output filter can run again.
	// COOKIE BOUNDARY INVARIANT: Old generations may contain visitor-specific
	// like or rating state. Namespace replacement makes them unreachable even
	// to later cookie-free visitors before they are cleaned up.
	private const CACHE_DOCUMENT = 'index.cookies-v5.html';

	/**
	 * Persist cache metadata in the WordPress database.
	 *
	 *  This includes:
	 *  - Cache version
	 *  - Cache statistics (hits/misses)
	 *  - Warmup queue state
	 *
	 *  IMPORTANT:
	 *  - Uses autoload = false → prevents unnecessary memory usage
	 *  - Called frequently → must stay lightweight
	 *
	 * @return void
	 */

	private function mutate_cache_data(callable $mutation) {
		$token = false;
		$deadline = microtime(true) + 0.5;

		do {
			$token = WPHAVE_Background_Job_Lock::acquire(self::STATE_LOCK_OPTION, 10);
			if ($token) {
				break;
			}

			usleep(10000);
		} while (microtime(true) < $deadline);

		// SECURITY INVARIANT: Cache state mutation begins only while this call
		// owns the exact token it published. Observing an existing lock or a
		// successor's lock never grants mutation authority.
		if (!$token) {
			return false;
		}

		try {
			$current = get_option(self::STATE_OPTION, []);
			$current = is_array($current) ? $current : [];
			$next = $mutation($current);

			if (!is_array($next)) {
				return false;
			}

			// CONCURRENCY INVARIANT: A mutation may commit only after atomically
			// proving that its lease still belongs to this request.
			if (!WPHAVE_Background_Job_Lock::refresh(self::STATE_LOCK_OPTION, $token)) {
				return false;
			}

			if ($next !== $current && !update_option(self::STATE_OPTION, $next, false)) {
				return false;
			}
			$this->cache_data = $next;
			$this->version = (int) ($next['version'] ?? $this->version);
			return true;
		} finally {
			WPHAVE_Background_Job_Lock::release(self::STATE_LOCK_OPTION, $token);
		}
	}

	private function save_cache_section(string $section, $value) {
		return $this->mutate_cache_data(function ($current) use ($section, $value) {
			$current[$section] = $value;
			return $current;
		});
	}

	private function has_pending_invalidation(): bool {
		return (string) get_option(self::INVALIDATION_PENDING_OPTION, '') !== '';
	}

	private function mark_cache_invalidation_pending(string $token): bool {
		update_option(self::INVALIDATION_PENDING_OPTION, $token, false);
		return get_option(self::INVALIDATION_PENDING_OPTION, '') === $token;
	}

	private function clear_cache_invalidation_pending(string $token): void {
		global $wpdb;

		// INVALIDATION ORDER INVARIANT: Delete only our own marker. A newer
		// invalidation may have replaced it while this request held the state lock.
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s",
				self::INVALIDATION_PENDING_OPTION,
				$token,
			),
		);
		wp_cache_delete(self::INVALIDATION_PENDING_OPTION, 'options');
	}

	/**
	 * Serve an existing static HTML cache file as early as possible.
	 *
	 *  This drastically reduces load by bypassing WordPress completely
	 *  for cacheable requests.
	 *
	 *  IMPORTANT:
	 *  - Runs on 'init' with priority 0 (very early)
	 *  - Sends proper headers (cache + gzip)
	 *  - Terminates execution immediately (exit)
	 *
	 * @return void
	 */

	public function maybe_serve_cache() {
		if (!$this->is_early_cacheable_request()) {
			return;
		}

		$file = $this->get_cache_file_path();

		if ($file && file_exists($file)) {
			$accepts_gzip = strpos($_SERVER['HTTP_ACCEPT_ENCODING'] ?? '', 'gzip') !== false;
			$gzip_path = $file . '.gz';
			$serve_gzip = $accepts_gzip && file_exists($gzip_path);
			$response_path = $serve_gzip ? $gzip_path : $file;

			try {
				$response = WPHAVE_Security_File_Identity::open_stream(
					$response_path,
					__('The static cache entry changed before it could be served.', 'wphave'),
				);
			} catch (RuntimeException $error) {
				// CACHE DELIVERY INVARIANT: An unsafe, missing, linked or racing
				// cache node is a miss. WordPress renders the request normally.
				return;
			}

			$this->increment_stat('hits');

			header('X-WPHAVE-CACHE: HIT');

			header('Vary: Accept-Encoding');

			// SHARED-CACHE INVARIANT: A page may become private immediately after
			// publication. An external proxy has no access to our version bump, so
			// it must revalidate every response and may never serve stale HTML.
			header('Cache-Control: public, max-age=0, s-maxage=0, must-revalidate');
			header('Expires: ' . gmdate('D, d M Y H:i:s', time()) . ' GMT');

			$is_head = $_SERVER['REQUEST_METHOD'] === 'HEAD';

			if ($serve_gzip) {
				header('Content-Encoding: gzip');
			}
			header('Content-Length: ' . $response['bytes']);

			// CACHE STREAM INVARIANT: Encoding, length and response bytes all
			// describe the exact locked regular-file revision opened above.
			if (!$is_head) {
				fpassthru($response['handle']);
			}

			WPHAVE_Security_File_Identity::close($response);

			// ! Without this early exit, WordPress would still continue running.
			exit();
		}
	}

	/**
	 * Prepare cache state and miss handling before the output pipeline runs.
	 *
	 *  This method replaces the old "start_buffering" logic and is now
	 *  responsible for early cache-related decisions WITHOUT starting
	 *  its own output buffer.
	 *
	 *  - Determines whether the current request is cacheable
	 *  - Detects cache MISS (no existing cache file)
	 *  - Sets appropriate HTTP headers for non-cached responses
	 *  - Tracks cache statistics (misses)
	 *
	 *  This method DOES NOT start output buffering anymore.
	 *
	 *  Buffering is now handled globally by:
	 *
	 *      WPHAVE_Output_Buffer
	 *
	 *  The cache system is integrated into that pipeline and only:
	 *
	 *  - prepares state here (early phase)
	 *  - writes cache later via buffer callback (store_cache)
	 *
	 *  1. maybe_serve_cache() → serves existing cache (early exit)
	 *  2. maybe_prepare_cache() → detects MISS + sets headers
	 *  3. Output buffer pipeline runs
	 *  4. store_cache() → writes final HTML
	 *
	 *  - Consent processing runs BEFORE cache storage (in buffer pipeline)
	 *  - Cache always stores FINAL processed HTML
	 *  - This ensures:
	 *
	 *      ✔ No executable tracking scripts are cached
	 *      ✔ GDPR-compliant output is persisted
	 *
	 *  For cache MISS:
	 *  - Prevent browser caching during generation phase
	 *  - Ensures fresh content delivery
	 *
	 * @return void
	 */

	public function maybe_prepare_cache() {
		if (!$this->is_cacheable_request_after_query()) {
			return;
		}

		$file = $this->get_cache_file_path();
		if (!$file) {
			return;
		}

		// MISS detection (nur wenn KEIN Cache existiert)
		if (!file_exists($file)) {
			// Browser soll NICHT cachen → wir generieren gerade neu
			header('Cache-Control: ' . self::CACHE_MISS_CONTROL);

			// Statistik
			$this->increment_stat('misses');
		}
	}

	/**
	 * Build a versioned cache-directory path for the current host.
	 *
	 *  Example:
	 *  /wp-content/cache/wphave-static/domain.com/v3/
	 *
	 *  IMPORTANT:
	 *  - Versioning allows instant global cache invalidation
	 *  - Host-based separation supports multisite/multi-domain setups
	 *
	 * @return string Versioned cache-directory path.
	 */

	private function build_cache_dir() {
		$base_dir = $this->cache_base_dir();

		if ($base_dir === '') {
			return '';
		}

		$version = (int) $this->version;

		return trailingslashit($base_dir . $this->cache_authority() . '/v' . $version);
	}

	/** Return the canonical directory that owns every static-cache namespace. */

	private function cache_base_dir() {
		$parent = $this->private_cache_parent();
		$parent = is_string($parent) ? realpath($parent) : false;
		if (!is_string($parent) || !is_dir($parent)) {
			return '';
		}
		$site_root = realpath(ABSPATH);
		$content_root = realpath(WP_CONTENT_DIR);
		if (!is_string($site_root) || !is_string($content_root)) {
			return '';
		}
		$identity = hash('sha256', $site_root . '|' . $content_root . '|' . get_current_blog_id());
		$private = rtrim($parent, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR .
			'wphave-static-' . $identity;
		foreach ([$site_root, $content_root, $_SERVER['DOCUMENT_ROOT'] ?? ''] as $web_root) {
			$web_root = is_string($web_root) && $web_root !== '' ? realpath($web_root) : false;
			if (
				is_string($web_root) &&
				(str_starts_with($private, rtrim($web_root, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR) ||
					$private === $web_root)
			) {
				return '';
			}
		}

		if (!is_dir($private) && !@mkdir($private, 0700)) {
			return '';
		}
		$stat = @lstat($private);
		// CACHE CONFIDENTIALITY INVARIANT: HTML never lives under a public URL
		// or in a shared temp directory readable by another system account.
		if (
			is_link($private) ||
			!is_array($stat) ||
			!is_dir($private) ||
			($stat['mode'] & 0077) !== 0 ||
			(function_exists('posix_geteuid') && $stat['uid'] !== posix_geteuid())
		) {
			return '';
		}
		return trailingslashit(wp_normalize_path($private));
	}

	/** Keep private cache selection testable without changing production policy. */
	protected function private_cache_parent(): string {
		return sys_get_temp_dir();
	}

	/** Remove prior web-addressable HTML, including obsolete document namespaces. */
	private function cleanup_legacy_public_cache(): bool {
		$content_root = realpath(WP_CONTENT_DIR);
		if (!is_string($content_root)) {
			return false;
		}
		$legacy = $content_root . '/cache/wphave-static';
		if (!file_exists($legacy) && !is_link($legacy)) {
			return true;
		}
		if (is_link($legacy) || !is_dir($legacy)) {
			return false;
		}
		// MIGRATION INVARIANT: Only the exact former WPHAVE cache root may be
		// removed. A symlink never redirects cleanup into another data tree.
		$this->delete_dir($legacy);
		return !file_exists($legacy) && !is_link($legacy);
	}

	/** Return the configured public authority used for cache isolation. */

	private function cache_authority() {
		$site_url = home_url();
		$host = (string) (parse_url($site_url, PHP_URL_HOST) ?: 'default');
		$scheme = strtolower((string) parse_url($site_url, PHP_URL_SCHEME));
		$port = (int) (parse_url($site_url, PHP_URL_PORT) ?: ('https' === $scheme ? 443 : 80));
		$default_port = 'https' === $scheme ? 443 : 80;
		$authority = $host . ($port !== $default_port ? '-' . $port : '');

		// CACHE AUTHORITY INVARIANT: Creation and cleanup use configured site
		// identity, never the untrusted request Host header.
		return sanitize_file_name($authority);
	}

	/**
	 * Store the generated HTML in the static cache.
	 *
	 *  Includes:
	 *  - Atomic file writes
	 *  - File locking to prevent race conditions
	 *  - Optional gzip compression
	 *
	 *  IMPORTANT:
	 *  - Prevents duplicate writes via lock files
	 *  - Uses temp files + rename (atomic)
	 *
	 * @param string $html Final processed HTML.
	 * @return string Unchanged HTML for the output-buffer pipeline.
	 */

	public function store_cache($html) {
		// INVALIDATION INVARIANT: A failed version bump must also stop new
		// writes until a later successful invalidation clears its marker.
		if ($this->has_pending_invalidation()) {
			return $html;
		}
		// Rendering discovers nested/reusable time rules after the early cacheability decision.
		if (
			class_exists('WPHAVE_Block_Conditions_Runtime') &&
			WPHAVE_Block_Conditions_Runtime::has_scheduled_output()
		) {
			return $html;
		}
		if (!$this->is_cacheable_request_after_query() || http_response_code() !== 200) {
			return $html;
		}

		/*
		 * CACHE CONFIDENTIALITY INVARIANT: Application response privacy is
		 * authoritative. A response which creates a cookie or declares itself
		 * private/no-store can never be promoted into anonymous shared state.
		 */
		$response_headers = $this->current_response_headers();
		if (
			$this->response_has_private_headers($response_headers) ||
			!$this->response_is_html($response_headers)
		) {
			return $html;
		}

		// SECURITY INVARIANT (SEC-21): Form state belongs to an individual visit.
		// Consent elsewhere in the document cannot authorize sharing another form's
		// nonce or delivery identity. Conservatively exclude all forms, including
		// consent-only forms, and identity fields even without a surrounding form.
		foreach (['_wpnonce', '_wphave_form_nonce', '_wphave_submission_id', '<form'] as $marker) {
			if (stripos($html, $marker) !== false) {
				return $html;
			}
		}

		// Prevents, for example, AJAX or fragment HTML from being cached.
		if (stripos($html, '<html') === false) {
			return $html;
		}

		$file = $this->get_cache_file_path();
		if (!$file) {
			return $html;
		}
		$dir = dirname($file);

		if (!file_exists($dir)) {
			wp_mkdir_p($dir);
		}

		if (file_exists($file)) {
			return $html;
		}

		try {
			// CONCURRENCY INVARIANT: Hold an inode-bound mutex through publication.
			// Never expire/unlink a pathname lock that another writer may still own.
			WPHAVE_Security_File_Mutex::run($file . '.lock', function () use ($file, &$html): void {
				if (file_exists($file)) {
					return;
				}
				$html = $this->compressed ? (string) new wphave_html_compression($html) : $html;
				$mode = WPHAVE_Security_File_Permissions::for_new_public_file($file);
				// PUBLICATION INVARIANT: No incomplete cache entry becomes serveable.
				// I/O failure preserves the response and leaves a retryable cache miss.
				if (strlen($html) > 1024) {
					$gz = gzencode($html, 6);
					if (false === $gz) {
						throw new RuntimeException('Cache compression failed.');
					}
					WPHAVE_Security_Atomic_File::write(
						$file . '.gz',
						$gz,
						'Compressed cache write failed.',
						$mode,
					);
				} elseif (is_file($file . '.gz') && !@unlink($file . '.gz')) {
					throw new RuntimeException('Obsolete compressed cache could not be removed.');
				}
				WPHAVE_Security_Atomic_File::write_new($file, $html, 'Cache write failed.', $mode);
				clearstatcache(true, $file);
			});
		} catch (RuntimeException $error) {
			// CACHE INVARIANT: Optional cache storage never fails the live response.
		}

		return $html;
	}

	/**
	 * Determine whether the current request is safe to cache.
	 *
	 *  This is the MOST critical part of the system.
	 *
	 *  IMPORTANT:
	 *  - Prevents caching of dynamic / user-specific content
	 *  - Protects WooCommerce, sessions, and logged-in users
	 *
	 * @return bool Whether the request may be cached.
	 */

	private function evaluate_early_cacheability() {
		$uri = $_SERVER['REQUEST_URI'] ?? '/';

		// INVALIDATION INVARIANT: A failed version bump may leave an old file
		// on disk. Never serve it while the durable pending marker exists.
		if ($this->has_pending_invalidation()) {
			return false;
		}

		// WP-CLI inherits a synthetic GET request. Serving cached HTML here would
		// terminate commands before they execute and can also emit invalid headers.
		if (defined('WP_CLI') && WP_CLI) {
			return false;
		}

		/*
		 * A validated Request Profiler session must execute the complete WordPress
		 * lifecycle. Serving or storing a static response would terminate the
		 * request during init and produce an incomplete, misleading profile.
		 * Invalid profiling headers do not bypass caching because is_active() only
		 * becomes true after token and exact-target validation.
		 */
		if (class_exists('WPHAVE_Request_Profiler') && WPHAVE_Request_Profiler::is_active()) {
			return false;
		}

		/*
		 * Access modes must be evaluated before an existing HTML file can be
		 * served at `init`. Their content hooks run later on `wp`, so allowing
		 * an early cache hit here would expose the regular website and end the
		 * request before Coming Soon or Maintenance can replace its content.
		 *
		 * These temporary documents are deliberately not stored in the normal
		 * page cache either. Maintenance must preserve its 503 response, and
		 * both modes must disappear immediately when their add-on is disabled.
		 */

		if (class_exists('WPHAVE_Maintenance_Mode') && WPHAVE_Maintenance_Mode::is_active()) {
			return false;
		}
		if (class_exists('WPHAVE_Coming_Soon') && WPHAVE_Coming_Soon::is_active()) {
			return false;
		}

		// Only GET/HEAD → never cache POST!
		if (!in_array($_SERVER['REQUEST_METHOD'], ['GET', 'HEAD'])) {
			return false;
		}

		/*
		 * CACHE AUTHORITY INVARIANT: Cache identity comes from the WordPress site
		 * selected during bootstrap, never from an untrusted Host header. Foreign
		 * authorities may neither consume nor populate that site's cache files.
		 */
		if (!$this->request_host_matches_site((string) ($_SERVER['HTTP_HOST'] ?? ''), home_url())) {
			return false;
		}

		/*
		 * CACHE CONFIDENTIALITY INVARIANT: A request carrying credentials must
		 * never read from or write to the shared anonymous page cache. WordPress
		 * login cookies are only one authentication mechanism; REST clients,
		 * reverse proxies and integrations may authenticate through these server
		 * variables before WordPress has established a logged-in cookie session.
		 */
		if ($this->has_request_credentials()) {
			return false;
		}

		if ($this->has_visitor_cookies()) {
			return false;
		}

		if (preg_match('/\.(txt|xml)$/', $uri)) {
			return false;
		}

		// Query parameters can generate dynamic content.
		if ($this->has_disallowed_query_params()) {
			return false;
		}
		if ($this->has_noncanonical_cache_path()) {
			return false;
		}

		if (!empty($_POST)) {
			return false;
		}

		// Logged in users
		if (is_user_logged_in()) {
			return false;
		}

		// Admin
		if (is_admin()) {
			return false;
		}

		// Customizer
		if (is_customize_preview()) {
			return false;
		}

		// Static files
		if (
			preg_match(
				'/\.(js|css|json|xml|txt|map|png|jpg|jpeg|gif|svg|webp|ico|woff|woff2|ttf|eot)$/i',
				$uri,
			)
		) {
			return false;
		}

		if (defined('DOING_AJAX') && DOING_AJAX) {
			return false;
		}

		if (defined('REST_REQUEST') && REST_REQUEST) {
			return false;
		}

		// Core paths
		if (strpos($uri, '/wp-json/') !== false) {
			return false;
		}
		if (strpos($uri, '/wp-admin/') !== false) {
			return false;
		}
		if (strpos($uri, '/wp-content/') !== false) {
			return false;
		}
		if (strpos($uri, '/wp-includes/') !== false) {
			return false;
		}

		// Custom excluded URLs
		if ($this->is_excluded_url($uri)) {
			return false;
		}

		// WooCommerce logic
		if (class_exists('WPHAVE_WooCommerce')) {
			$woo = WPHAVE_WooCommerce::context();
			if (WPHAVE_WooCommerce::is_cart_checkout_or_account()) {
				return false;
			}
			if (!empty($woo['is_thank_you'])) {
				return false;
			}

			// WooCommerce Edge Case: Add-to-cart may NEVER be cached
			if (WPHAVE_WooCommerce::is_add_to_cart_request()) {
				return false;
			}

			// CRITICAL: prevents incorrect shopping carts in the cache
			if (WPHAVE_WooCommerce::has_active_cart_session()) {
				return false;
			}
		}

		return apply_filters('wphave_should_cache_request', true);
	}

	/**
	 * Check only request state that is authoritative before the main query.
	 *
	 * Cache hits run on init, where conditional tags and the queried object are
	 * not available yet. Files can only exist after passing the complete
	 * post-query storage check, so this early gate deliberately contains no
	 * query-dependent conditions.
	 *
	 * @return bool Whether an existing cache artifact may be served.
	 */

	private function is_early_cacheable_request() {
		return $this->evaluate_early_cacheability();
	}

	/**
	 * Return the request-level cached result of the post-query evaluation.
	 *
	 *  Ensures that the expensive evaluation logic only runs once
	 *  per request.
	 *
	 *  IMPORTANT:
	 *  - Prevents redundant computation
	 *  - Improves performance
	 *
	 * @return bool Whether the request may be cached.
	 */

	private function is_cacheable_request_after_query() {
		if ($this->is_cacheable_after_query !== null) {
			return $this->is_cacheable_after_query;
		}

		if (
			!$this->evaluate_early_cacheability() ||
			is_404() ||
			is_feed() ||
			is_preview() ||
			is_attachment()
		) {
			$this->is_cacheable_after_query = false;
			return false;
		}

		$post = get_queried_object();
		if (is_singular() && (!($post instanceof WP_Post) || 'publish' !== $post->post_status)) {
			$this->is_cacheable_after_query = false;
			return false;
		}

		if ($post instanceof WP_Post && post_password_required($post)) {
			$this->is_cacheable_after_query = false;
			return false;
		}

		$this->is_cacheable_after_query = true;
		return true;
	}

	/**
	 * Resolve the cache-file path for the current request.
	 *
	 *  Example:
	 *  /about/ → /cache/.../about/<current policy document>
	 *
	 *  IMPORTANT:
	 *  - Uses clean directory structure (SEO-like URLs)
	 *  - Avoids query string duplication
	 *
	 * @return string Absolute cache-file path.
	 */

	private function get_cache_file_path() {
		if ($this->cache_dir === '') {
			return null;
		}

		$path = $this->normalize_cache_url_path($_SERVER['REQUEST_URI'] ?? '/');
		if ($path === null) {
			return null;
		}

		if (empty($path)) {
			return $this->cache_dir . self::CACHE_DOCUMENT;
		}

		return $this->cache_dir . $path . '/' . self::CACHE_DOCUMENT;
	}

	/**
	 * Convert a request URL into a traversal-safe relative cache path.
	 *
	 * @param string $url Request URI or absolute URL.
	 * @return string|null Normalized relative path, or null when unsafe.
	 */

	private function normalize_cache_url_path($url) {
		$path = parse_url($url, PHP_URL_PATH);
		if (!is_string($path)) {
			return null;
		}
		// CACHE KEY INVARIANT: One pathname must map to one representation.
		// Decoding escapes or dropping repeated slashes aliases distinct request
		// targets, whose WordPress routing and access rules may differ.
		if (str_contains($path, '%') || str_contains($path, '//')) {
			return null;
		}

		$path = rawurldecode($path);
		if (
			strpos($path, "\0") !== false ||
			strpos($path, '\\') !== false ||
			preg_match('/[\x00-\x1F\x7F]/', $path)
		) {
			return null;
		}

		$segments = [];
		foreach (explode('/', trim($path, '/')) as $segment) {
			if ($segment === '') {
				continue;
			}
			if ($segment === '.' || $segment === '..') {
				return null;
			}
			$segments[] = rawurlencode($segment);
		}

		if (in_array('', $segments, true)) {
			return null;
		}
		return implode('/', $segments);
	}

	/**
	 * Delete a cache directory and all of its contents recursively.
	 *
	 *  IMPORTANT:
	 *  - Used for cache invalidation
	 *  - Must handle nested structures safely
	 *
	 * @param string $dir Absolute cache-directory path.
	 * @return void
	 */

	private function delete_dir($dir) {
		if (is_link($dir) || !is_dir($dir)) {
			return;
		}
		try {
			$files = new RecursiveIteratorIterator(
				new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS),
				RecursiveIteratorIterator::CHILD_FIRST,
			);

			// DELETE INVARIANT: Never follow a child symlink out of the exact
			// cache tree during invalidation or public-cache migration.
			foreach ($files as $file) {
				$path = $file->getPathname();

				if ($file->isLink() || !$file->isDir()) {
					@unlink($path);
				} else {
					@rmdir($path);
				}
			}
		} catch (UnexpectedValueException $error) {
			return;
		}

		@rmdir($dir);
	}

	/**
	 * Delete the cache directory corresponding to a URL.
	 *
	 *  IMPORTANT:
	 *  - Maps URL → filesystem path
	 *  - Handles root path separately
	 *
	 * @param string $url Absolute frontend URL.
	 * @return void
	 */

	private function delete_cache_by_url($url) {
		$path = $this->normalize_cache_url_path($url);
		if ($path === null) {
			return;
		}

		// Handle root path
		if ($path === '') {
			$dir = $this->cache_dir;
		} else {
			$dir = $this->cache_dir . $path;
		}

		$this->delete_dir($dir);
	}

	/**
	 * Remove outdated versioned cache directories.
	 *
	 *  Keeps only a limited number of recent versions to avoid
	 *  unnecessary disk usage.
	 *
	 *  IMPORTANT:
	 *  - Prevents disk bloat
	 *  - Safe cleanup (keeps recent versions)
	 *
	 * @param int $current_version Version that was current before invalidation.
	 * @return void
	 */

	private function cleanup_old_cache_versions($current_version) {
		$base_dir = $this->cache_base_dir();

		if ($base_dir === '') {
			return;
		}

		$path = trailingslashit($base_dir . $this->cache_authority());

		if (!is_dir($path)) {
			return;
		}

		// Security mechanism: retains last versions
		$keep_versions = 2;

		$cache_directories = glob($path . 'v*');

		foreach (is_array($cache_directories) ? $cache_directories : [] as $dir) {
			if (!preg_match('/v(\d+)$/', $dir, $matches)) {
				continue;
			}

			$version = (int) $matches[1];

			if ($version < $current_version - $keep_versions) {
				$this->delete_dir($dir);
			}
		}
	}
}
