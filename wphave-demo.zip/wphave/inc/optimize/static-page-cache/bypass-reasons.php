<?php

/** Stable reason codes shared by cache recording and Site Health projection. */
final class WPHAVE_Static_Cache_Bypass_Reasons {
	public const HEALTH_EVIDENCE = [
		'form_state',
		'scheduled_output',
		'response_cookie',
		'private_response',
		'non_html',
		'incomplete_html',
	];

	public static function is_health_evidence(string $reason): bool {
		return in_array($reason, self::HEALTH_EVIDENCE, true);
	}
}
