<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Static_Page_Cache_REST {

/**
     * Clear and warm a single post cache through the REST API.
     *
     * @param WP_REST_Request $request REST request.
     * @return array Operation result.
     */

    public static function rest_clear_post( $request ) {
        // AUTHORIZATION INVARIANT: Post invalidation and synchronous warmup are
        // privileged cache mutations. Direct invocation repeats the route policy.
        if( ! function_exists( 'wphave_cache_rest_manage_permission' ) || ! wphave_cache_rest_manage_permission() ) {
            return function_exists( 'wphave_cache_rest_forbidden' )
                ? wphave_cache_rest_forbidden()
                : new WP_Error( 'wphave_cache_forbidden', __( 'You are not allowed to manage the static page cache.', 'wphave' ), [ 'status' => 403 ] );
        }

        global $wphave_cache_instance;

        $post_id = (int) $request->get_param('id');

        if( ! $post_id || ! $wphave_cache_instance ) {
            return ['success' => false];
        }

        $wphave_cache_instance->invalidate_post( $post_id );
        $wphave_cache_instance->warmup_single( $post_id );

        return ['success' => true];
    }

/**
     * Clear the entire cache through the REST API.
     *
     * @return array Operation result.
     */

    public static function rest_clear_all() {
        // AUTHORIZATION INVARIANT: Global invalidation repeats capability and
        // entitlement checks immediately before touching cache generations.
        if( ! function_exists( 'wphave_cache_rest_manage_permission' ) || ! wphave_cache_rest_manage_permission() ) {
            return function_exists( 'wphave_cache_rest_forbidden' )
                ? wphave_cache_rest_forbidden()
                : new WP_Error( 'wphave_cache_forbidden', __( 'You are not allowed to manage the static page cache.', 'wphave' ), [ 'status' => 403 ] );
        }

        global $wphave_cache_instance;

        if( $wphave_cache_instance ) {
            $wphave_cache_instance->invalidate_all();
        }

        return ['success' => true];
    }

}
