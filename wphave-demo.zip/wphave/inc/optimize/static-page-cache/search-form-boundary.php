<?php

if (!defined('ABSPATH')) {
	exit();
}

/** Admit only search forms whose submitted state is public and request-local. */
final class WPHAVE_Static_Page_Cache_Search_Form_Boundary {
	private const ALLOWED_ELEMENTS = [
		'input',
		'button',
		'div',
		'label',
		'span',
		'br',
		'strong',
		'em',
		'svg',
		'path',
		'g',
		'use',
		'circle',
		'rect',
		'line',
		'polyline',
		'polygon',
		'ellipse',
	];

	public static function allows(string $html): bool {
		// Parse only pages with forms. A bounded parse keeps a global search form
		// from turning cache publication into unbounded HTML parser work.
		if (!class_exists('DOMDocument') || strlen($html) > 4 * 1024 * 1024) {
			return false;
		}
		$markup = self::visible_markup($html);
		if ($markup === null) {
			return false;
		}
		$opening_count = preg_match_all('/<form(?:\s|>|\/)/i', $markup);
		$closing_count = preg_match_all('/<\/form\s*>/i', $markup);
		if (!$opening_count || $opening_count !== $closing_count || $opening_count > 16) {
			return false;
		}

		try {
			$document = new DOMDocument();
			$parsed = @$document->loadHTML(
				'<?xml encoding="UTF-8">' . $html,
				LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING,
			);
		} catch (Throwable $error) {
			return false;
		}
		if (!$parsed) {
			return false;
		}
		$forms = $document->getElementsByTagName('form');
		if ($forms->length !== $opening_count) {
			return false;
		}
		// HTML permits controls outside a form to join it by form="id". Such
		// fields would escape the descendant check and change the submitted state.
		foreach ($document->getElementsByTagName('*') as $element) {
			if ($element->hasAttribute('form')) {
				return false;
			}
		}
		foreach ($forms as $form) {
			if (!self::is_public_search_form($form)) {
				return false;
			}
		}
		return true;
	}

	/** Count form tags only outside comments, scripts and styles. */
	private static function visible_markup(string $html): ?string {
		$pattern = '~<!--|-->|</?(?:script|style)\b[^>]*>~i';
		$markup = '';
		$offset = 0;
		$state = '';
		$tokens = 0;
		while (true) {
			$found = preg_match($pattern, $html, $matches, PREG_OFFSET_CAPTURE, $offset);
			if ($found === false) {
				return null;
			}
			if ($found === 0) {
				break;
			}
			if (++$tokens > 8192) {
				return null;
			}
			[$token, $position] = $matches[0];
			$lower = strtolower($token);
			if ($state === '') {
				$markup .= substr($html, $offset, $position - $offset);
				if ($token === '<!--') {
					$state = 'comment';
				} elseif (str_starts_with($lower, '<script')) {
					$state = 'script';
				} elseif (str_starts_with($lower, '<style')) {
					$state = 'style';
				} else {
					$markup .= $token;
				}
			} elseif (
				($state === 'comment' && $token === '-->') ||
				($state === 'script' && str_starts_with($lower, '</script')) ||
				($state === 'style' && str_starts_with($lower, '</style'))
			) {
				$state = '';
			}
			$offset = $position + strlen($token);
		}
		if ($state !== '') {
			return null;
		}
		return $markup . substr($html, $offset);
	}

	private static function is_public_search_form(DOMElement $form): bool {
		if (
			strtolower($form->getAttribute('role')) !== 'search' ||
			strtolower($form->getAttribute('method')) !== 'get' ||
			$form->getAttribute('action') !== home_url('/') ||
			$form->hasAttribute('target') ||
			self::has_dynamic_attributes($form)
		) {
			return false;
		}

		$search_fields = 0;
		$controls = 0;
		foreach ($form->getElementsByTagName('*') as $element) {
			if (self::has_dynamic_attributes($element)) {
				return false;
			}
			$tag = strtolower($element->tagName);
			if (!in_array($tag, self::ALLOWED_ELEMENTS, true)) {
				return false;
			}
			if (!in_array($tag, ['input', 'button'], true)) {
				continue;
			}
			if (++$controls > 32 || self::has_submission_override($element)) {
				return false;
			}
			if ($tag === 'button') {
				if (
					$element->hasAttribute('name') ||
					!in_array(strtolower($element->getAttribute('type')), ['', 'submit', 'button'], true)
				) {
					return false;
				}
				continue;
			}
			if ($tag !== 'input') {
				return false;
			}
			$name = $element->getAttribute('name');
			$type = strtolower($element->getAttribute('type'));
			if ($name === 's' && in_array($type, ['search', 'text'], true)) {
				// A filled search field can depend on an uncached request or visitor.
				if ($element->getAttribute('value') !== '' || ++$search_fields !== 1) {
					return false;
				}
			} elseif ($name === '' && in_array($type, ['submit', 'button'], true)) {
				continue;
			} elseif (
				!in_array($name, ['post_type', 'post_type[]'], true) ||
				$type !== 'hidden' ||
				!self::is_public_post_type($element->getAttribute('value'))
			) {
				return false;
			}
		}
		return $search_fields === 1;
	}

	private static function has_dynamic_attributes(DOMElement $element): bool {
		// Search markup is shared HTML. Data and event attributes can carry a
		// nonce or visitor state even when the submitted fields look harmless.
		foreach ($element->attributes as $attribute) {
			$name = strtolower($attribute->name);
			if (
				str_starts_with($name, 'data-') ||
				preg_match('/^on[a-z]+$/D', $name) ||
				str_contains($name, 'nonce')
			) {
				return true;
			}
		}
		return false;
	}

	private static function has_submission_override(DOMElement $element): bool {
		foreach (['form', 'formaction', 'formmethod', 'formenctype', 'formtarget'] as $attribute) {
			if ($element->hasAttribute($attribute)) {
				return true;
			}
		}
		return false;
	}

	private static function is_public_post_type(string $name): bool {
		if (!preg_match('/^[a-z0-9_-]{1,32}$/D', $name) || !function_exists('get_post_type_object')) {
			return false;
		}
		$type = get_post_type_object($name);
		return is_object($type) && !empty($type->publicly_queryable);
	}
}
