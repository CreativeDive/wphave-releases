<?php

require_once wphave_dir() . 'inc/background-jobs/lock.php';
require_once wphave_dir() . 'inc/features/security/file-identity.php';
require_once __DIR__ . '/storage.php';
require_once __DIR__ . '/runtime.php';
require_once __DIR__ . '/warmup.php';
require_once __DIR__ . '/rest.php';

/**
 * Initializes the static cache system by loading settings,
 *  preparing cache metadata, and registering all required hooks.
 *
 *  This is the central bootstrap of the caching logic.
 *
 *  IMPORTANT:
 *  - Loads persisted cache state (versioning, stats, warmup queue)
 *  - Builds versioned cache directory
 *  - Registers early cache delivery (init hook)
 */

if (!defined('ABSPATH')) {
	exit();
}

class WPHAVE_Static_Page_Cache {
	use WPHAVE_Static_Page_Cache_Storage,
		WPHAVE_Static_Page_Cache_Runtime,
		WPHAVE_Static_Page_Cache_Warmup,
		WPHAVE_Static_Page_Cache_REST;

	private $enabled;
	private $exclude;
	private $cache_dir;
	private $compressed;
	private $version;
	private $auto_renew;
	private $warmup_intensity;
	private $warmup_strategy;
	private $warmup_quiet_start;
	private $warmup_quiet_end;
	private $cache_data = [];
	private $warmup_limit = 100;
	private $is_cacheable_after_query = null;
	private $attachment_cache_invalidated = false;
	private $add_on_cache_invalidated = false;
	private $global_cache_invalidated = false;

	/**
	 * Initialize the static page cache service.
	 */

	public function __construct() {
		$settings = wphave_data_get('site_settings', 'advanced.performance', []);
		$has_pro_access =
			function_exists('wphave_optimization_has_pro_access') &&
			wphave_optimization_has_pro_access();
		$enabled = $has_pro_access && ($settings['static_cache'] ?? false);
		$exclude = $settings['static_cache_exclude'] ?? [];
		$compressed = $settings['static_cache_compressed'] ?? false;
		$auto_cache_renew = $settings['static_cache_auto_renew'] ?? false;
		$warmup_intensity = $settings['static_cache_warmup_intensity'] ?? 'low';
		$warmup_strategy =
			$settings['static_cache_warmup_strategy'] ??
			($auto_cache_renew ? 'adaptive' : 'manual');
		if ($auto_cache_renew && $warmup_strategy === 'manual') {
			$warmup_strategy = 'adaptive';
		}

		$this->enabled = $enabled;
		$this->exclude = $exclude;
		$this->compressed = $compressed;
		$this->auto_renew = $auto_cache_renew;
		$this->warmup_intensity = $warmup_intensity;
		$this->warmup_strategy = in_array(
			$warmup_strategy,
			['adaptive', 'immediate', 'quiet_hours', 'manual'],
			true,
		)
			? $warmup_strategy
			: 'adaptive';
		$this->warmup_quiet_start = $this->normalize_warmup_time(
			$settings['static_cache_warmup_quiet_start'] ?? '02:00',
			'02:00',
		);
		$this->warmup_quiet_end = $this->normalize_warmup_time(
			$settings['static_cache_warmup_quiet_end'] ?? '05:00',
			'05:00',
		);

		$this->cache_data = get_option('wphave_cache_data', []);

		$this->cache_data = wp_parse_args($this->cache_data, [
			'version' => 1,
			'stats' => [],
			'warmup' => [],
		]);

		$this->cache_data['warmup'] = wp_parse_args($this->cache_data['warmup'], [
			'queue' => [],
			'total' => 0,
			'running' => false,
			'generation' => '',
			'state' => 'idle',
			'scheduled_at' => 0,
			'deferred_reason' => '',
			'strategy' => $this->warmup_strategy,
		]);

		$this->version = (int) ($this->cache_data['version'] ?? 1);
		$this->cache_dir = $this->build_cache_dir();

		/*
		 * CACHE INTEGRITY INVARIANT: Invalidation is maintenance, not a Pro
		 * capability. Keep these hooks active when the stored setting is off, the
		 * entitlement expires, or Cron performs a content mutation. Otherwise an
		 * old cache generation could become reachable again after reactivation.
		 */
		$this->register_invalidation_hooks();

		/*
		 * PERFORMANCE INVARIANT: Cron needs the cache state machine for warmup
		 * batches, but never public delivery or output processing. Invalidation was
		 * registered above because scheduled content changes must remain coherent.
		 * The initialized instance remains available to the worker callback.
		 */
		if (wp_doing_cron()) {
			return;
		}

		/*
		 * The static cache currently depends on the deterministic WPHAVE render
		 * and output-buffer pipeline. Third-party themes may emit user-specific
		 * or late output which cannot yet be cached safely.
		 */

		$is_cache_enabled = $this->enabled && !wphave_use_fse();

		if (!$is_cache_enabled) {
			// Bail early, if not enabled !
			return;
		}

		add_action('init', [$this, 'maybe_serve_cache'], 0);

		add_action('template_redirect', [$this, 'maybe_prepare_cache'], 1);

		/*
		 * Register static cache writer in global output pipeline.
		 * Runs LATE to store the FINAL processed HTML (after consent, optimization, etc).
		 *
		 * Important:
		 * - Must run after all HTML transformations
		 * - Stores exactly what the user receives
		 * - Internally validates cacheability (request safety)
		 *
		 * This ensures cache always contains the fully processed output.
		 */

		WPHAVE_Output_Buffer::instance()->register(
			[$this, 'store_cache'],
			100, // <-- Priority must be higher than wphave consent buffer priority !
		);

		/*
		 * Ensure global output buffer is started.
		 *
		 * This acts as a safety fallback in case no other component
		 * initialized the buffer earlier.
		 *
		 * IMPORTANT:
		 * - Required for cache + consent pipeline to function
		 * - Prevents missing buffer → no processing / no cache write
		 * - Safe to call multiple times (internally guarded)
		 */

		add_action(
			'template_redirect',
			function () {
				WPHAVE_Output_Buffer::instance()->start();
			},
			0,
		);
	}

	/**
	 * Register mutation observers independently from cache delivery entitlement.
	 *
	 * @return void
	 */
	private function register_invalidation_hooks() {
		add_action('wphave_frontend_output_changed', [$this, 'invalidate_frontend_output']);
		add_action('save_post', [$this, 'invalidate_post']);
		add_action('wphave_page_color_context_changed', [$this, 'invalidate_post']);
		add_action('save_post_wphave-add-ons', [$this, 'invalidate_add_on_change']);
		add_action('before_delete_post', [$this, 'invalidate_add_on_change']);
		add_action(
			'save_post_wphave-template-part',
			[$this, 'invalidate_template_part_change'],
			10,
			3,
		);
		add_action(
			'delete_post_wphave-template-part',
			[$this, 'invalidate_template_part_change'],
			10,
			2,
		);
		add_action('deleted_post', [$this, 'invalidate_post']);
		add_action('switch_theme', [$this, 'invalidate_all']);
		add_action('wp_update_nav_menu', [$this, 'invalidate_all']);
		add_action('edit_attachment', [$this, 'invalidate_attachment']);
		add_action('delete_attachment', [$this, 'invalidate_attachment']);
		add_filter(
			'wp_update_attachment_metadata',
			[$this, 'invalidate_attachment_metadata'],
			10,
			2,
		);
		add_action('post_updated', [$this, 'handle_post_updated'], 10, 3);
	}
}

/**
 * Instantiate the shared static-cache service after plugins are loaded.
 *
 *  This ensures:
 *  - All dependencies (WooCommerce, plugins, filters) are available
 *  - Global cache instance is accessible across the system
 *
 *  IMPORTANT:
 *  - Uses global instance → shared state across hooks
 *  - Must run AFTER plugins are loaded
 *
 * @return void
 */

if (!function_exists('wphave_cache_init')):
	function wphave_cache_init() {
		global $wphave_cache_instance;
		$wphave_cache_instance = new WPHAVE_Static_Page_Cache();
	}
endif;

add_action('plugins_loaded', 'wphave_cache_init');

/**
 * Register administrative REST routes for cache management and monitoring.
 *
 *  Includes:
 *  - Clear entire cache
 *  - Clear single post cache
 *  - Retrieve cache metrics
 *  - Retrieve warmup status
 *
 *  IMPORTANT:
 *  - Restricted to admin users only
 *  - Used for UI integration (dashboard, controls)
 *
 * @return void
 */

if (!function_exists('wphave_cache_rest_routes')):
	/**
	 * Determine whether the current administrator may mutate the Pro cache.
	 *
	 * Read-only status endpoints remain available so the interface can explain
	 * existing cache state after a license expires.
	 *
	 * @return bool Whether cache mutations are permitted.
	 */

	function wphave_cache_rest_manage_permission() {
		return current_user_can('manage_options') &&
			function_exists('wphave_optimization_has_pro_access') &&
			wphave_optimization_has_pro_access();
	}

	/** Return a stable denial for direct cache callback invocation. */
	function wphave_cache_rest_forbidden() {
		return new WP_Error(
			'wphave_cache_forbidden',
			__('You are not allowed to manage the static page cache.', 'wphave'),
			['status' => 403],
		);
	}

	/**
	 * Return the cache metrics projection used by REST consumers.
	 *
	 * @return array Cache hit and miss metrics.
	 */

	function wphave_cache_get_metrics_data() {
		// AUTHORIZATION INVARIANT: Cache metrics disclose operational behavior.
		// Repeat the administrator-only route policy before reading cache state.
		if (!current_user_can('manage_options')) {
			return wphave_cache_rest_forbidden();
		}

		global $wphave_cache_instance;

		$metrics = $wphave_cache_instance ? $wphave_cache_instance->get_stats() : [];

		// AUTHORIZATION INVARIANT: Option reads and cache projections cross
		// filterable boundaries. Operational data is released only while the live
		// administrator authority still holds at the final response boundary.
		if (!current_user_can('manage_options')) {
			return wphave_cache_rest_forbidden();
		}

		return $metrics;
	}

	/**
	 * Return the cache lifecycle projection used by REST consumers.
	 *
	 * @return array Cache configuration and warmup state.
	 */

	function wphave_cache_get_status_data() {
		// AUTHORIZATION INVARIANT: Warmup queue and scheduling state remain
		// administrator-only even when this callback is invoked outside REST.
		if (!current_user_can('manage_options')) {
			return wphave_cache_rest_forbidden();
		}

		$settings = wphave_data_get('site_settings', 'advanced.performance', []);
		$has_pro_access =
			function_exists('wphave_optimization_has_pro_access') &&
			wphave_optimization_has_pro_access();
		$is_cache_enabled = $has_pro_access && ($settings['static_cache'] ?? false);

		global $wphave_cache_instance;
		$cache = $wphave_cache_instance ? $wphave_cache_instance->get_warmup_data() : [];
		$queue = $cache['queue'] ?? [];
		$total = (int) ($cache['total'] ?? 0);
		$remaining = count($queue);
		$active = !empty($cache['running']);
		$state = sanitize_key($cache['state'] ?? ($active ? 'running' : 'idle'));

		$status = [
			'enabled' => (bool) $is_cache_enabled,
			'queue' => $remaining,
			'total' => $total,
			'processed' => max(0, $total - $remaining),
			'active' => $active,
			'running' => $active && $state === 'running',
			'pending' => $active && $state !== 'running',
			'state' => $state,
			'scheduledAt' => !empty($cache['scheduled_at'])
				? gmdate('c', (int) $cache['scheduled_at'])
				: '',
			'deferredReason' => sanitize_key($cache['deferred_reason'] ?? ''),
			'strategy' => sanitize_key($cache['strategy'] ?? 'manual'),
		];

		// AUTHORIZATION INVARIANT: The final status release repeats administrator
		// authority after every filterable settings and cache-state read.
		if (!current_user_can('manage_options')) {
			return wphave_cache_rest_forbidden();
		}

		return $status;
	}

	/** Return the protected cache status and metrics aggregate. */

	function wphave_cache_get_overview_data() {
		// AUTHORIZATION INVARIANT: An aggregate callback is an independent trust
		// boundary. It must fail closed itself instead of returning a successful
		// container whose protected child projections happen to contain errors.
		if (!current_user_can('manage_options')) {
			return wphave_cache_rest_forbidden();
		}

		$status = wphave_cache_get_status_data();
		if (is_wp_error($status)) {
			return $status;
		}

		$metrics = wphave_cache_get_metrics_data();
		if (is_wp_error($metrics) || !current_user_can('manage_options')) {
			return is_wp_error($metrics) ? $metrics : wphave_cache_rest_forbidden();
		}

		return [
			'status' => $status,
			'metrics' => $metrics,
		];
	}

	function wphave_cache_rest_routes() {
		// Clear the complete cache through POST /wphave/v1/cache/clear-all.

		register_rest_route('wphave/v1', '/cache/clear-all', [
			'methods' => 'POST',
			'callback' => ['WPHAVE_Static_Page_Cache', 'rest_clear_all'],
			'permission_callback' => 'wphave_cache_rest_manage_permission',
		]);

		// Cancel the active warmup through POST /wphave/v1/cache/cancel-warmup.

		register_rest_route('wphave/v1', '/cache/cancel-warmup', [
			'methods' => 'POST',
			'callback' => 'wphave_cache_rest_cancel_warmup',
			'permission_callback' => 'wphave_cache_rest_manage_permission',
		]);

		// Start one explicit warmup immediately, including in Manual mode.

		register_rest_route('wphave/v1', '/cache/start-warmup', [
			'methods' => 'POST',
			'callback' => 'wphave_cache_rest_start_warmup',
			'permission_callback' => 'wphave_cache_rest_manage_permission',
		]);

		// Clear one post cache through POST /wphave/v1/cache/clear-post.

		register_rest_route('wphave/v1', '/cache/clear-post', [
			'methods' => 'POST',
			'callback' => ['WPHAVE_Static_Page_Cache', 'rest_clear_post'],
			'permission_callback' => 'wphave_cache_rest_manage_permission',
		]);

		// Return hit, miss, and hit-rate metrics through GET /wphave/v1/cache/metrics.

		register_rest_route('wphave/v1', '/cache/metrics', [
			'methods' => 'GET',
			'callback' => 'wphave_cache_get_metrics_data',
			'permission_callback' => function () {
				return current_user_can('manage_options');
			},
		]);

		// Return cache enablement and warmup progress through GET /wphave/v1/cache/status.

		register_rest_route('wphave/v1', '/cache/status', [
			'methods' => 'GET',
			'callback' => 'wphave_cache_get_status_data',
			'permission_callback' => function () {
				return current_user_can('manage_options');
			},
		]);

		// Return the status and metrics required by the cache-control workspace.

		register_rest_route('wphave/v1', '/cache/overview', [
			'methods' => WP_REST_Server::READABLE,
			'callback' => 'wphave_cache_get_overview_data',
			'permission_callback' => function () {
				return current_user_can('manage_options');
			},
		]);
	}

	/** Cancel active warmup work after repeating the Pro management boundary. */
	function wphave_cache_rest_cancel_warmup() {
		// AUTHORIZATION INVARIANT: Cancellation mutates persisted queue and Cron
		// state, so direct invocation repeats capability and entitlement checks.
		if (!wphave_cache_rest_manage_permission()) {
			return wphave_cache_rest_forbidden();
		}

		global $wphave_cache_instance;
		if ($wphave_cache_instance) {
			$wphave_cache_instance->cancel_warmup();
		}

		return ['success' => true];
	}

	/** Start explicit warmup work after repeating the Pro management boundary. */
	function wphave_cache_rest_start_warmup() {
		// AUTHORIZATION INVARIANT: Warmup can schedule Cron and outbound requests.
		// No settings read or work scheduling occurs before final authorization.
		if (!wphave_cache_rest_manage_permission()) {
			return wphave_cache_rest_forbidden();
		}

		global $wphave_cache_instance;
		$settings = wphave_data_get('site_settings', 'advanced.performance', []);
		if (empty($settings['static_cache'])) {
			return new WP_Error(
				'wphave_cache_disabled',
				__('Static page cache must be enabled before starting a warmup.', 'wphave'),
				['status' => 409],
			);
		}
		if ($wphave_cache_instance) {
			$result = $wphave_cache_instance->enqueue_warmup_urls(
				true,
				'wphave_cache_rest_manage_permission',
			);
			if (false === $result) {
				return wphave_cache_rest_forbidden();
			}
		}

		return ['success' => (bool) $wphave_cache_instance];
	}
endif;

add_action('rest_api_init', 'wphave_cache_rest_routes');

/**
 * Process the cache-warmup queue in controlled batches.
 *
 *  This gradually rebuilds the cache after invalidation.
 *
 *  IMPORTANT:
 *  - Prevents server overload (batch processing)
 *  - Uses non-blocking HTTP requests
 *  - Automatically stops when queue is empty
 *
 *  PROCESS FLOW:
 *  1. Abort if warmup was cancelled (running = false)
 *  2. Stop completely when queue is empty
 *  3. Process next batch of URLs
 *  4. Persist remaining queue
 *
 *  STATE:
 *  - Controlled via cache_data['warmup']['running']
 *
 * @return void
 */

if (!function_exists('wphave_cache_process_warmup')):
	function wphave_cache_process_warmup() {
		global $wphave_cache_instance;

		// Safety check → prevents fatal errors
		if (!$wphave_cache_instance) {
			return;
		}

		$worker_token = WPHAVE_Background_Job_Lock::acquire(
			'wphave_cache_warmup_worker_lock',
			MINUTE_IN_SECONDS,
		);
		if (!$worker_token) {
			$warmup = $wphave_cache_instance->get_warmup_data();
			$generation = (string) ($warmup['generation'] ?? '');
			if (!empty($warmup['running']) && $generation) {
				$next_run = time() + MINUTE_IN_SECONDS;
				if ($wphave_cache_instance->defer_warmup($generation, $next_run, 'worker_busy')) {
					$wphave_cache_instance->schedule_warmup($next_run, $generation);
				}
			}
			return;
		}

		try {
			$warmup = $wphave_cache_instance->get_warmup_data();

			// Stop cron if cancelled
			if (empty($warmup['running'])) {
				wp_clear_scheduled_hook('wphave_process_warmup_queue');
				return;
			}

			$generation = (string) ($warmup['generation'] ?? '');
			if ($wphave_cache_instance->should_wait_for_quiet_hours($warmup)) {
				$next_run = $wphave_cache_instance->next_quiet_warmup_timestamp();
				if ($wphave_cache_instance->defer_warmup($generation, $next_run, 'quiet_hours')) {
					$wphave_cache_instance->schedule_warmup($next_run, $generation);
				}
				return;
			}
			if (
				($warmup['strategy'] ?? '') === 'adaptive' &&
				$wphave_cache_instance->is_server_busy()
			) {
				$next_run = time() + 5 * MINUTE_IN_SECONDS;
				if ($wphave_cache_instance->defer_warmup($generation, $next_run, 'server_load')) {
					$wphave_cache_instance->schedule_warmup($next_run, $generation);
				}
				return;
			}

			if (!$wphave_cache_instance->mark_warmup_running($generation)) {
				return;
			}

			$queue = $warmup['queue'] ?? [];

			// STOP: If queue is empty
			if (empty($queue)) {
				$wphave_cache_instance->stop_warmup();

				wp_clear_scheduled_hook('wphave_process_warmup_queue');
				return;
			}

			$batch_size = $wphave_cache_instance->get_batch_size();

			// Only process a limited number of URLs per run
			$batch = array_splice($queue, 0, $batch_size);

			foreach ($batch as $url) {
				// SECURITY INVARIANT: The persisted queue is untrusted at the delayed
				// cron boundary. Re-authorize exact origin immediately at the sink.
				if (!$wphave_cache_instance->is_warmup_url_allowed($url)) {
					continue;
				}

				// Non-blocking → does not delay cron execution
				// SECURITY INVARIANT: Warmup requests use Core's SSRF validation,
				// never follow redirects and never weaken TLS validation.
				wp_safe_remote_get($url, [
					'timeout' => 5,
					'blocking' => false, // Non-blocking → faster cron
					'redirection' => 0,
					'sslverify' => true,
				]);
			}

			// Remove duplicates & normalize array
			$queue = array_values(array_unique($queue));

			// One warmup spans multiple worker batches. Emit one semantic completion only after the final batch.
			if (empty($queue)) {
				if ($wphave_cache_instance->complete_warmup($generation)) {
					wp_clear_scheduled_hook('wphave_process_warmup_queue');
					do_action(
						'wphave_cache_warmup_completed',
						$generation,
						absint($warmup['total'] ?? count($batch)),
					);
				}
			} else {
				$wphave_cache_instance->set_warmup_queue(
					$queue,
					(string) ($warmup['generation'] ?? ''),
				);
				$next_run = time() + MINUTE_IN_SECONDS;
				if ($wphave_cache_instance->defer_warmup($generation, $next_run, 'next_batch')) {
					$wphave_cache_instance->schedule_warmup($next_run, $generation);
				}
			}
		} finally {
			// SECURITY INVARIANT: An expired warmup worker cannot release the lock
			// of a successor; cleanup authority remains bound to this worker token.
			WPHAVE_Background_Job_Lock::release('wphave_cache_warmup_worker_lock', $worker_token);
		}
	}
endif;
