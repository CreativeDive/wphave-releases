<?php

/** Register the static-cache warmup processor only for worker requests. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * WORKER INVARIANT: Cron does not load the public frontend composition. The
 * cache worker therefore owns only its entitlement and cache dependencies
 * instead of pulling the public optimization pipeline into Cron.
 */
require_once dirname( __DIR__ ) . '/access.php';
require_once __DIR__ . '/cache.php';

add_action( 'wphave_process_warmup_queue', 'wphave_cache_process_warmup' );
