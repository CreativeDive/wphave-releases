<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Static_Page_Cache_Runtime {

/**
     * Detect request credentials exposed through common web-server SAPIs.
     *
     * @return bool Whether the request carries an authorization credential.
     */

    private function has_request_credentials() {
        $credential_variables = [
            'HTTP_AUTHORIZATION',
            'REDIRECT_HTTP_AUTHORIZATION',
            'PHP_AUTH_USER',
            'PHP_AUTH_PW',
            'PHP_AUTH_DIGEST',
        ];

        foreach( $credential_variables as $variable ) {
            if( isset( $_SERVER[$variable] ) && (string) $_SERVER[$variable] !== '' ) {
                return true;
            }
        }

        return false;
    }

/**
     * Detect response headers which prohibit anonymous shared storage.
     *
     * @param array $headers Response header lines.
     * @return bool Whether the response is private or establishes a cookie.
     */

    private function response_has_private_headers( array $headers ) {
        foreach( $headers as $header ) {
            if( ! is_string( $header ) ) {
                continue;
            }

            if( stripos( $header, 'Set-Cookie:' ) === 0 ) {
                return true;
            }

            if(
                stripos( $header, 'Cache-Control:' ) === 0
                && preg_match( '/(?:^|[,\s])(?:private|no-store)(?:$|[,;\s])/i', substr( $header, 14 ) )
            ) {
                return true;
            }
        }

        return false;
    }

/**
     * Compare the request authority with the site WordPress already resolved.
     *
     * @param string $request_host Raw HTTP Host header.
     * @param string $site_url Configured site URL.
     * @return bool Whether host and effective port match exactly.
     */

    private function request_host_matches_site( string $request_host, string $site_url ): bool {
        $site = parse_url( $site_url );

        if( ! is_array( $site ) || '' === $request_host ) {
            return false;
        }

        $scheme = strtolower( (string) ( $site['scheme'] ?? '' ) );
        if( ! in_array( $scheme, [ 'http', 'https' ], true ) ) return false;

        $request = parse_url( $scheme . '://' . $request_host );
        if(
            ! is_array( $request )
            || ! empty( $request['user'] )
            || ! empty( $request['pass'] )
            || isset( $request['path'] )
            || isset( $request['query'] )
            || isset( $request['fragment'] )
        ) {
            return false;
        }

        $site_host = strtolower( (string) ( $site['host'] ?? '' ) );
        $request_host_name = strtolower( (string) ( $request['host'] ?? '' ) );
        $default_port = 'https' === $scheme ? 443 : 80;
        $site_port = (int) ( $site['port'] ?? $default_port );
        $request_port = (int) ( $request['port'] ?? $default_port );

        return '' !== $site_host
            && hash_equals( $site_host, $request_host_name )
            && $site_port === $request_port;
    }

/**
     * Invalidate frontend output using the settings that were just persisted.
     *
     * The cache service is created before an admin REST write. Reloading the
     * renewal flag prevents disabling the cache from starting an obsolete
     * warmup, and lets enabling it prepare the new cache generation.
     *
     * @return void
     */

    public function invalidate_frontend_output() {
        $settings = wphave_data_get( 'site_settings', 'advanced.performance', [] );
        $this->auto_renew = ! empty( $settings['static_cache_auto_renew'] );
        $strategy = $settings['static_cache_warmup_strategy'] ?? ($this->auto_renew ? 'adaptive' : 'manual');
        if( $this->auto_renew && $strategy === 'manual' ) $strategy = 'adaptive';
        $this->warmup_strategy = in_array($strategy, ['adaptive', 'immediate', 'quiet_hours', 'manual'], true) ? $strategy : 'adaptive';
        $this->warmup_quiet_start = $this->normalize_warmup_time($settings['static_cache_warmup_quiet_start'] ?? '02:00', '02:00');
        $this->warmup_quiet_end = $this->normalize_warmup_time($settings['static_cache_warmup_quiet_end'] ?? '05:00', '05:00');
        $this->invalidate_all();
    }

/**
     * Determine whether a URI must be excluded from caching.
     *
     *  Includes:
     *  - Default critical paths (cart, checkout, login, etc.)
     *  - User-defined exclusions from settings
     *
     *  IMPORTANT:
     *  - Prevents caching of dynamic or sensitive pages
     *  - Works via substring matching (strpos)
     *
     * @param string $uri Request URI.
     * @return bool Whether the URI is excluded.
     */

    private function is_excluded_url( $uri ) {
        $excluded = [
            '/cart',
            '/checkout',
            '/my-account',
            '/login',
            '/register',
        ];

        $user_excluded_urls = [];
        foreach( $this->exclude as $user_url ) {
            $url = $user_url['url'] ?? '';
            if ( ! empty( $url ) ) {
                $user_excluded_urls[] = $url;
            }
        }

        $excluded = array_merge($excluded, $user_excluded_urls);

        foreach( $excluded as $path ) {
            // Substring match → deliberately simple & performant
            if( strpos($uri, $path) !== false ) {
                return true;
            }
        }

        return false;
    }

/**
     * Determine whether the request contains disallowed query parameters.
     *
     *  Only known tracking parameters (e.g. UTM) are allowed.
     *
     *  IMPORTANT:
     *  - Prevents caching of dynamic URLs with filters/search/etc.
     *  - Avoids cache fragmentation
     *
     * @return bool Whether an unsupported parameter is present.
     */

    private function has_disallowed_query_params() {
        if( empty( $_GET ) ) return false;

        // Allowed params (will ignored)
        $allowed = [
            'utm_source',
            'utm_medium',
            'utm_campaign',
            'utm_term',
            'utm_content',
            'fbclid',
            'gclid',
        ];

        // Any unknown query parameter → cache is disabled.
        foreach( $_GET as $key => $value ) {
            $key = strtolower( $key );
            if( ! in_array($key, $allowed, true) ) {
                return true; // bocked
            }
        }

        return false; // passed
    }

/**
     * Delete the cache for a post URL and its dependent views.
     *
     *  IMPORTANT:
     *  - Called on save/delete
     *  - Ensures content updates are reflected immediately
     *
     * @param int $post_id Post ID.
     * @return void
     */

    public function invalidate_post( $post_id ) {
        $url = get_permalink( $post_id );
        if( ! $url ) return;

        $this->delete_cache_by_url( $url );
        $this->invalidate_dependencies( $post_id );
    }

/**
     * Invalidate the entire cache by incrementing its version.
     *
     *  This instantly invalidates all existing cache files without deleting them immediately.
     *
     *  IMPORTANT:
     *  - Version bump is extremely fast (O(1))
     *  - Old cache is cleaned up asynchronously
     *
     * @return void
     */

    public function invalidate_all() {
		if( $this->global_cache_invalidated ) {
			return;
		}

		$this->global_cache_invalidated = true;
        $old_version = $this->version;
        wp_clear_scheduled_hook('wphave_process_warmup_queue');
		// CACHE INVARIANT: Publishing a new version makes every old cache file
		// unreachable before best-effort asynchronous cleanup begins.
        $this->mutate_cache_data(function( $current ) {
            $current['version'] = max( 1, (int) ($current['version'] ?? 1) + 1 );
            $current['stats'] = [];
            $current['warmup'] = [
                'queue' => [],
                'total' => 0,
            'running' => false,
            'generation' => wp_generate_uuid4(),
            'state' => 'idle',
            'scheduled_at' => 0,
            'deferred_reason' => '',
            'strategy' => $this->warmup_strategy,
            ];
            return $current;
        });

        $this->cache_dir = $this->build_cache_dir();

        // Start cache warmup (delayed)
        // Only if manually enabled !
		// ENTITLEMENT INVARIANT: Maintenance may invalidate without Pro, but it
		// must never turn that maintenance path into cache generation work.
        if ($this->enabled && $this->auto_renew && $this->warmup_strategy !== 'manual') {
            $this->enqueue_warmup_urls();
        }

        // Older versions will be cleaned up later
        $this->cleanup_old_cache_versions($old_version);
    }

/**
     * Invalidate every rendered page after a shared template part changes.
     *
     * Headers, footers and general parts have no meaningful public permalink;
     * one part may affect an unknown set of pages, so URL-level invalidation is
     * insufficient. Autosaves and revisions never represent published output.
     *
     * @param int $post_id Template-part post ID.
     * @param mixed $post Saved or deleted post object.
     * @param bool $update Whether WordPress updated an existing post.
     * @return void
     */

    public function invalidate_template_part_change( $post_id, $post = null, $update = true ) {
		if(
			function_exists( 'wphave_doing_wp_save_post_action' )
			&& wphave_doing_wp_save_post_action( $post_id, $post, array( 'auto-draft', 'auto-save', 'revision' ) )
		) {
			return;
		}

		$this->invalidate_all();
    }

/**
     * Invalidate every page when a global add-on changes.
     *
     * Add-ons may alter output or public access across arbitrary URLs. Clearing
     * only the add-on post permalink would leave unrelated cached pages stale,
     * especially when Coming Soon or Maintenance is activated or deactivated.
     *
     * @param int $post_id Changed or deleted post ID.
     * @return void
     */

    public function invalidate_add_on_change( $post_id ) {
        if( $this->add_on_cache_invalidated || 'wphave-add-ons' !== get_post_type( $post_id ) ) {
            return;
        }

        $this->add_on_cache_invalidated = true;
        $this->invalidate_all();
    }

/**
     * Invalidate rendered pages after attachment metadata changes.
     *
     * Responsive image markup depends on attachment dimensions and generated
     * subsizes, while one attachment may occur on an unknown number of pages.
     *
     * @param array $metadata Updated attachment metadata.
     * @param int $attachment_id Attachment ID.
     * @return array Unmodified attachment metadata.
     */

    public function invalidate_attachment_metadata( $metadata, $attachment_id ) {
        $this->invalidate_attachment( $attachment_id );

        return $metadata;
    }

/**
     * Invalidate rendered pages once per attachment-changing request.
     *
     * WordPress may fire both attachment and metadata hooks for one operation.
     * The guard prevents multiple static-cache version bumps for the same change.
     *
     * @param int $attachment_id Attachment ID.
     * @return void
     */

    public function invalidate_attachment( $attachment_id ) {
        if( $this->attachment_cache_invalidated ) {
            return;
        }

        $this->attachment_cache_invalidated = true;
        $this->invalidate_all();
    }

/**
     * Remove obsolete cache files after a post permalink changes.
     *
     *  IMPORTANT:
     *  - Prevents orphaned cache files
     *
     * @param int $post_id Post ID.
     * @param WP_Post $post_after Updated post object.
     * @param WP_Post $post_before Previous post object.
     * @return void
     */

    public function handle_post_updated( $post_id, $post_after, $post_before ) {
        if( ! $post_after || ! $post_before ) return;

        $old_url = get_permalink( $post_before );
        $new_url = get_permalink( $post_after );

        if( $old_url && $new_url && $old_url !== $new_url ) {
            $this->delete_cache_by_url( $old_url );
        }

        $this->invalidate_dependencies( $post_id );
    }

/**
     * Clear cached listings and archives affected by a content change.
     *
     *  Includes:
     *  - Homepage
     *  - Blog page
     *  - Archives
     *  - Taxonomies
     *
     *  IMPORTANT:
     *  - Prevents stale listings (e.g. blog overview)
     *
     * @param int $post_id Changed post ID.
     * @return void
     */

    private function invalidate_dependencies( $post_id ) {
        // Homepage
        $this->delete_cache_by_url( home_url('/') );

        // Blog page
        $posts_page_id = get_option('page_for_posts');
        if( $posts_page_id ) {
            $this->delete_cache_by_url( get_permalink( $posts_page_id ) );
        }

        // Post type archive
        $post_type = get_post_type( $post_id );
        if( $post_type ) {
            $archive = get_post_type_archive_link( $post_type );
            if( $archive ) {
                $this->delete_cache_by_url( $archive );
            }
        }

        // Taxonomies
        $taxonomies = get_object_taxonomies( $post_type );

        foreach( $taxonomies as $taxonomy ) {
            $terms = get_the_terms( $post_id, $taxonomy );

            if( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
                foreach( $terms as $term ) {
                    $this->delete_cache_by_url( get_term_link( $term ) );
                }
            }
        }

        // Pagination (optional expansion later)
        $this->delete_cache_by_url( home_url('/page/2/') );
    }

/**
     * Return the number of URLs processed per cron run.
     *
     *  Based on configured intensity.
     *
     * @return int Warmup batch size.
     */

    public function get_batch_size() {
        if( $this->warmup_intensity === 'high' ) return 10;
        if( $this->warmup_intensity === 'medium' ) return 5;

        return 3;
    }

/**
     * Increment and persist a cache metric.
     *
     *  IMPORTANT:
     *  - Used for analytics
     *
     * @param string $key Metric key.
     * @return void
     */

    private function increment_stat( $key ) {
        $this->mutate_cache_data(function( $current ) use ( $key ) {
            $current['stats'] = is_array($current['stats'] ?? null) ? $current['stats'] : [];
            $current['stats'][$key] = (int) ($current['stats'][$key] ?? 0) + 1;
            return $current;
        });
    }

/**
     * Return cache hit, miss, total, and hit-rate metrics.
     *
     *  Includes:
     *  - Hits
     *  - Misses
     *  - Hit rate
     *
     *  IMPORTANT:
     *  - Used for monitoring cache effectiveness
     *
     * @return array Cache metrics.
     */

    public function get_stats() {
        $current = get_option(self::STATE_OPTION, []);
        $stats = is_array($current) ? ($current['stats'] ?? []) : [];

        $hits = $stats['hits'] ?? 0;
        $misses = $stats['misses'] ?? 0;

        $total = $hits + $misses;
        $hit_rate = $total > 0 ? round(($hits / $total) * 100) : 0;

        return [
            'hits' => $hits,
            'misses' => $misses,
            'total' => $total,
            'hit_rate' => $hit_rate,
        ];
    }

}
