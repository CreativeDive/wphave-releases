<?php

require_once __DIR__ . '/bypass-reasons.php';

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Static_Page_Cache_Runtime {
	private const CACHE_MISS_CONTROL = 'no-cache, must-revalidate, max-age=0, wphave-cache-miss';

	/** Capture the response representation at the final publication boundary. */
	protected function current_response_headers(): array {
		return headers_list();
	}

	/**
	 * Return the exact, bounded consent representation or refuse visitor cookies.
	 *
	 * The raw header and PHP's parsed view must agree. Unknown keys, malformed
	 * values and every other cookie keep the original fail-closed boundary.
	 */
	private function consent_cache_variant(): ?string {
		$quoted_header = $_SERVER['HTTP_COOKIE'] ?? '';
		if (!is_string($quoted_header) || strlen($quoted_header) > 6144) {
			return null;
		}
		// wp_magic_quotes() changes both superglobals before the init cache hook.
		$raw_header = stripslashes($quoted_header);
		if ('' === trim($raw_header) && empty($_COOKIE)) {
			return '';
		}
		if (
			count($_COOKIE) !== 1 ||
			!array_key_exists('wphave_consent', $_COOKIE) ||
			!is_string($_COOKIE['wphave_consent']) ||
			!preg_match('/^wphave_consent=([^;\s]+)$/D', trim($raw_header), $matches)
		) {
			return null;
		}

		$quoted_cookie = $_COOKIE['wphave_consent'];
		// Compare the decoded header with the same unescaped value consumed by
		// WPHAVE_Consent_Config::has_consent(), or every real consent request
		// would be rejected despite passing synthetic unslashed tests.
		$cookie = stripslashes($quoted_cookie);
		if (
			strlen($quoted_cookie) > 4096 ||
			rawurldecode($matches[1]) !== $cookie ||
			!class_exists('WPHAVE_Consent_Config')
		) {
			return null;
		}

		$config = new WPHAVE_Consent_Config();
		if (!$config->is_enabled()) {
			return null;
		}

		$categories = array_column($config->get_categories(), 'key');
		$allowed = array_fill_keys(array_merge($categories, ['__all']), true);
		$values = json_decode($cookie, true);
		// CACHE CAPACITY INVARIANT: The browser writes compact JSON. Reject
		// alternate spellings of the same state so whitespace and escape sequences
		// cannot multiply cache files without changing consent semantics.
		if (
			!is_array($values) ||
			!$values ||
			count($values) > count($allowed) ||
			json_encode($values) !== $cookie
		) {
			return null;
		}
		foreach ($values as $key => $value) {
			if (!is_string($key) || !isset($allowed[$key]) || !is_bool($value)) {
				return null;
			}
		}

		// COOKIE VARIANT INVARIANT: The body may contain server-selected consent
		// controls and analytics mode. Keep exact valid states in separate files;
		// never replay a cookie-free or differently consented representation.
		return hash('sha256', $cookie);
	}

	private function has_visitor_cookies(): bool {
		return null === $this->consent_cache_variant();
	}

	/** Select gzip only when Accept-Encoding assigns it a positive quality. */
	private function request_accepts_gzip(): bool {
		$header = $_SERVER['HTTP_ACCEPT_ENCODING'] ?? '';
		if (!is_string($header) || strlen($header) > 1024) {
			return false;
		}

		$explicit = null;
		$wildcard = false;
		foreach (explode(',', $header) as $part) {
			$part = trim($part);
			if (
				!preg_match(
					'/^(gzip|\*)(?:\s*;\s*q\s*=\s*(0(?:\.\d{0,3})?|1(?:\.0{0,3})?))?$/iD',
					$part,
					$matches,
				)
			) {
				if (preg_match('/^gzip(?:\s*;|$)/iD', $part)) {
					$explicit = false;
				}
				continue;
			}
			$allowed = !isset($matches[2]) || (float) $matches[2] > 0;
			if (strtolower($matches[1]) === 'gzip') {
				// Conflicting duplicates fail closed rather than relying on order.
				$explicit = ($explicit ?? true) && $allowed;
			} else {
				$wildcard = $wildcard || $allowed;
			}
		}
		return $explicit ?? $wildcard;
	}

	/**
	 * Detect request credentials exposed through common web-server SAPIs.
	 *
	 * @return bool Whether the request carries an authorization credential.
	 */

	private function has_request_credentials() {
		// PASSWORD CACHE INVARIANT: Even anonymous readers can unlock private
		// page content with WordPress' post-password cookie. Bypass shared cache
		// reads and writes before the query; validating the password comes later.
		if (defined('COOKIEHASH') && array_key_exists('wp-postpass_' . COOKIEHASH, $_COOKIE)) {
			return true;
		}

		$credential_variables = [
			'HTTP_AUTHORIZATION',
			'REDIRECT_HTTP_AUTHORIZATION',
			'PHP_AUTH_USER',
			'PHP_AUTH_PW',
			'PHP_AUTH_DIGEST',
		];

		foreach ($credential_variables as $variable) {
			if (isset($_SERVER[$variable]) && (string) $_SERVER[$variable] !== '') {
				return true;
			}
		}

		return false;
	}

	/**
	 * Detect response headers which prohibit anonymous shared storage.
	 *
	 * @param array $headers Response header lines.
	 * @return string|null The most actionable private-header reason, if any.
	 */
	private function response_private_header_reason(array $headers): ?string {
		$has_private_header = false;
		foreach ($headers as $header) {
			if (!is_string($header)) {
				continue;
			}

			if (stripos($header, 'Set-Cookie:') === 0) {
				return 'response_cookie';
			}

			foreach (
				[
					'Content-Encoding:',
					'Content-Range:',
					'Transfer-Encoding:',
					'Content-Security-Policy:',
					'Content-Security-Policy-Report-Only:',
					'Content-Disposition:',
					'X-Frame-Options:',
					'X-Content-Type-Options:',
					'Referrer-Policy:',
					'Permissions-Policy:',
					'Cross-Origin-Opener-Policy:',
					'Cross-Origin-Embedder-Policy:',
					'Cross-Origin-Resource-Policy:',
					'X-Robots-Tag:',
				] as $protected_header
			) {
				// RESPONSE REPRESENTATION/POLICY INVARIANT: The file cache stores
				// decoded HTML bytes, not an origin's encoding or range framing, and
				// cannot silently strip a policy when replaying the body later.
				if (stripos($header, $protected_header) === 0) {
					$has_private_header = true;
				}
			}

			if (stripos($header, 'Vary:') === 0) {
				$dimensions = array_map('trim', explode(',', substr($header, 5)));
				// CACHE VARIANCE INVARIANT: Consent is represented by its own
				// bounded local document and gzip by a sibling. All other origin
				// variants remain unsupported.
				foreach ($dimensions as $dimension) {
					if (!in_array(strtolower($dimension), ['cookie', 'accept-encoding'], true)) {
						$has_private_header = true;
					}
				}
			}

			if (stripos($header, 'Cache-Control:') === 0) {
				// CACHE DIRECTIVE INVARIANT: This store cannot honor origin TTLs or
				// revalidation directives. Only the exact no-cache header emitted by
				// our own miss path may accompany a new public cache document.
				if (trim(substr($header, 14)) !== self::CACHE_MISS_CONTROL) {
					$has_private_header = true;
				}
			}
			if (
				stripos($header, 'Expires:') === 0 ||
				stripos($header, 'Pragma:') === 0 ||
				stripos($header, 'Surrogate-Control:') === 0
			) {
				// CACHE DIRECTIVE INVARIANT: Legacy and intermediary TTL policies
				// also cannot be represented by this path-only file cache.
				$has_private_header = true;
			}
		}

		return $has_private_header ? 'private_response' : null;
	}

	/** Whether the response carries a header the shared cache cannot replay. */
	private function response_has_private_headers(array $headers): bool {
		return null !== $this->response_private_header_reason($headers);
	}

	/** Preserve an origin cache policy so the final storage gate can reject it. */
	private function response_has_cache_control_header(array $headers): bool {
		foreach ($headers as $header) {
			if (is_string($header) && stripos($header, 'Cache-Control:') === 0) {
				return true;
			}
		}
		return false;
	}

	/** Admit only an explicit HTML representation to the shared document cache. */
	private function response_is_html(array $headers): bool {
		$seen = false;
		foreach ($headers as $header) {
			if (!is_string($header) || stripos($header, 'Content-Type:') !== 0) {
				continue;
			}
			$seen = true;
			// REPRESENTATION INVARIANT: A JSON/text response containing the bytes
			// "<html" is still not a browser document and must not be served later
			// as cached text/html under this URL path.
			if (!preg_match('~^text/html(?:\s*;|\s*$)~i', trim(substr($header, 13)))) {
				return false;
			}
		}
		return $seen;
	}

	/** A stored HTML body must replay with the configured WordPress charset. */
	private function response_matches_site_html_charset(
		array $headers,
		string $charset,
		bool $allow_missing,
	): bool {
		$seen = false;
		foreach ($headers as $header) {
			if (!is_string($header) || stripos($header, 'Content-Type:') !== 0) {
				continue;
			}
			$seen = true;
			if (
				!preg_match(
					'/^text\/html\s*;\s*charset\s*=\s*([A-Za-z0-9._-]+)\s*$/iD',
					trim(substr($header, 13)),
					$matches,
				) ||
				strcasecmp($matches[1], $charset) !== 0
			) {
				return false;
			}
		}
		return $seen || $allow_missing;
	}

	/**
	 * Compare the request authority with the site WordPress already resolved.
	 *
	 * @param string $request_host Raw HTTP Host header.
	 * @param string $site_url Configured site URL.
	 * @return bool Whether host and effective port match exactly.
	 */

	private function request_host_matches_site(string $request_host, string $site_url): bool {
		$site = parse_url($site_url);

		if (!is_array($site) || '' === $request_host) {
			return false;
		}

		$scheme = strtolower((string) ($site['scheme'] ?? ''));
		if (!in_array($scheme, ['http', 'https'], true)) {
			return false;
		}

		$request = parse_url($scheme . '://' . $request_host);
		if (
			!is_array($request) ||
			!empty($request['user']) ||
			!empty($request['pass']) ||
			isset($request['path']) ||
			isset($request['query']) ||
			isset($request['fragment'])
		) {
			return false;
		}

		$site_host = strtolower((string) ($site['host'] ?? ''));
		$request_host_name = strtolower((string) ($request['host'] ?? ''));
		$default_port = 'https' === $scheme ? 443 : 80;
		$site_port = (int) ($site['port'] ?? $default_port);
		$request_port = (int) ($request['port'] ?? $default_port);

		return '' !== $site_host &&
			hash_equals($site_host, $request_host_name) &&
			$site_port === $request_port;
	}

	/** A hit at init must not bypass a later HTTP-to-HTTPS redirect. */
	private function request_scheme_matches_site(string $site_url, bool $request_is_ssl): bool {
		$scheme = strtolower((string) parse_url($site_url, PHP_URL_SCHEME));
		return $request_is_ssl ? $scheme === 'https' : $scheme === 'http';
	}

	/**
	 * Invalidate frontend output using the settings that were just persisted.
	 *
	 * The cache service is created before an admin REST write. Reloading the
	 * renewal flag prevents disabling the cache from starting an obsolete
	 * warmup, and lets enabling it prepare the new cache generation.
	 *
	 * @return void
	 */

	public function invalidate_frontend_output() {
		$settings = wphave_data_get('site_settings', 'advanced.performance', []);
		// The service was constructed before this settings write. Warmup and
		// status must use the committed switch, while a failed legacy-cache
		// cleanup remains a hard delivery veto for this request.
		$this->enabled =
			!empty($settings['static_cache']) &&
			$this->cache_storage_ready &&
			function_exists('wphave_optimization_has_pro_access') &&
			wphave_optimization_has_pro_access();
		$this->exclude = is_array($settings['static_cache_exclude'] ?? null)
			? $settings['static_cache_exclude']
			: [];
		$this->compressed = !empty($settings['static_cache_compressed']);
		$this->warmup_intensity = $settings['static_cache_warmup_intensity'] ?? 'low';
		$this->auto_renew = !empty($settings['static_cache_auto_renew']);
		$strategy =
			$settings['static_cache_warmup_strategy'] ??
			($this->auto_renew ? 'adaptive' : 'manual');
		if ($this->auto_renew && $strategy === 'manual') {
			$strategy = 'adaptive';
		}
		$this->warmup_strategy = in_array(
			$strategy,
			['adaptive', 'immediate', 'quiet_hours', 'manual'],
			true,
		)
			? $strategy
			: 'adaptive';
		$this->warmup_quiet_start = $this->normalize_warmup_time(
			$settings['static_cache_warmup_quiet_start'] ?? '02:00',
			'02:00',
		);
		$this->warmup_quiet_end = $this->normalize_warmup_time(
			$settings['static_cache_warmup_quiet_end'] ?? '05:00',
			'05:00',
		);
		// Each committed resource change needs its own generation. Another
		// request may publish between two saves in this PHP request, so the
		// per-request duplicate guard cannot cover both changes.
		$this->global_cache_invalidated = false;
		$this->invalidate_all();
	}

	/**
	 * Determine whether a URI must be excluded from caching.
	 *
	 *  Includes:
	 *  - Default critical paths (cart, checkout, login, etc.)
	 *  - User-defined exclusions from settings
	 *
	 *  IMPORTANT:
	 *  - Prevents caching of dynamic or sensitive pages
	 *  - Works via substring matching (strpos)
	 *
	 * @param string $uri Request URI.
	 * @return bool Whether the URI is excluded.
	 */

	private function is_excluded_url($uri) {
		$excluded = ['/cart', '/checkout', '/my-account', '/login', '/register'];

		foreach (is_array($this->exclude) ? $this->exclude : [] as $entry) {
			$path = $this->cache_exclusion_path(is_array($entry) ? ($entry['url'] ?? null) : null);
			if ($path !== null) {
				$excluded[] = $path;
			}
		}

		foreach ($excluded as $path) {
			$offset = 0;
			while (($match = strpos($uri, $path, $offset)) !== false) {
				if (
					$path === '/' ||
					!isset($uri[$match + strlen($path)]) ||
					$uri[$match + strlen($path)] === '/'
				) {
					return true;
				}
				$offset = $match + strlen($path);
			}
		}

		return false;
	}

	/** Normalize an exclusion to a path on this site, rejecting foreign URLs. */
	private function cache_exclusion_path($value): ?string {
		if (!is_string($value) || trim($value) === '') {
			return null;
		}
		$value = trim($value);
		if (preg_match('~^https?://~i', $value)) {
			$site = parse_url(home_url('/'));
			$candidate = parse_url($value);
			if (!is_array($site) || !is_array($candidate)) {
				return null;
			}
			$site_scheme = strtolower((string) ($site['scheme'] ?? ''));
			$candidate_scheme = strtolower((string) ($candidate['scheme'] ?? ''));
			$site_port = (int) ($site['port'] ?? ($site_scheme === 'https' ? 443 : 80));
			$candidate_port = (int) ($candidate['port'] ?? ($candidate_scheme === 'https' ? 443 : 80));
			if (
				isset($candidate['user']) ||
				isset($candidate['pass']) ||
				$candidate_scheme !== $site_scheme ||
				strtolower((string) ($candidate['host'] ?? '')) !==
					strtolower((string) ($site['host'] ?? '')) ||
				$candidate_port !== $site_port
			) {
				return null;
			}
			$value = (string) ($candidate['path'] ?? '/');
		} elseif (str_contains($value, '://') || str_starts_with($value, '//')) {
			return null;
		} else {
			$value = (string) (parse_url($value, PHP_URL_PATH) ?: '');
		}
		if ($value === '') {
			return null;
		}
		return '/' . trim($value, '/');
	}

	/**
	 * Determine whether the request contains disallowed query parameters.
	 *
	 *  The cache key contains only the URL path. Even attribution parameters
	 *  may change HTML rendered by another WordPress component, so no query
	 *  string can safely share the path-only public document.
	 *
	 * @return bool Whether any query string is present.
	 */

	private function has_disallowed_query_params() {
		// CACHE INVARIANT: A path-only cache key is never used for query-bearing
		// requests, including raw parameters PHP omitted from $_GET.
		$uri = $_SERVER['REQUEST_URI'] ?? '';
		return !empty($_GET) ||
			!empty($_SERVER['QUERY_STRING']) ||
			(is_string($uri) && strpos($uri, '?') !== false);
	}

	/** Reject request spellings that alias a canonical cache directory. */
	private function has_noncanonical_cache_path(): bool {
		$path = parse_url((string) ($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH);

		// CACHE KEY INVARIANT: The on-disk key cannot distinguish /page from
		// /page/. Only slash-terminated document paths may enter this cache;
		// WordPress still handles other routes through its normal pipeline.
		return !is_string($path) || '' === $path || !str_ends_with($path, '/');
	}

	/**
	 * Delete the cache for a post URL and its dependent views.
	 *
	 *  IMPORTANT:
	 *  - Called on save/delete
	 *  - Ensures content updates are reflected immediately
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */

	public function invalidate_post($post_id) {
		$url = get_permalink($post_id);
		if (!$url) {
			return;
		}

		$this->delete_cache_by_url($url);
		$this->invalidate_dependencies($post_id);
	}

	/** Advance the generation before WordPress commits a new HTML representation. */
	private function invalidate_for_html_representation_change($new_value, $old_value) {
		if ((string) $new_value !== (string) $old_value) {
			// A second edit in this request must bump the generation again. A
			// concurrent render may have filled the former representation
			// between the first option write and a later switch back.
			$this->global_cache_invalidated = false;
			$this->invalidate_all();
		}

		return $new_value;
	}

	/** Invalidate before WordPress commits a different HTML charset. */
	public function invalidate_for_charset_change($new_charset, $old_charset) {
		return $this->invalidate_for_html_representation_change($new_charset, $old_charset);
	}

	/** Keep Core's configured document type aligned with cached HTML. */
	public function invalidate_for_html_type_change($new_type, $old_type) {
		return $this->invalidate_for_html_representation_change($new_type, $old_type);
	}

	/**
	 * Invalidate the entire cache by incrementing its version.
	 *
	 *  This instantly invalidates all existing cache files without deleting them immediately.
	 *
	 *  IMPORTANT:
	 *  - Version bump is extremely fast (O(1))
	 *  - Old cache is cleaned up asynchronously
	 *
	 * @return void
	 */

	public function invalidate_all() {
		if ($this->global_cache_invalidated) {
			return;
		}

		$invalidation_token = wp_generate_uuid4();
		if (!$this->mark_cache_invalidation_pending($invalidation_token)) {
			return;
		}

		$old_version = $this->version;
		// Do not clear the shared single Cron event before the state commit.
		// A failed mutation must retain the old queue's wake-up; after a
		// successful reset the old event is inert or replaced by the new run.
		// INVALIDATION INVARIANT: A durable marker blocks reads and writes
		// before the version bump. Failed lock acquisition or persistence leaves
		// the marker intact, so an old public file cannot become reachable.
		$saved = $this->mutate_cache_data(function ($current) {
			$current['version'] = max(1, (int) ($current['version'] ?? 1) + 1);
			$current['stats'] = [];
			$current['warmup'] = [
				'queue' => [],
				'total' => 0,
				'running' => false,
				'generation' => wp_generate_uuid4(),
				'state' => 'idle',
				'scheduled_at' => 0,
				'deferred_reason' => '',
				'strategy' => $this->warmup_strategy,
			];
			return $current;
		});
		if (!$saved) {
			return;
		}

		$this->global_cache_invalidated = true;
		$this->clear_cache_invalidation_pending($invalidation_token);

		$this->cache_dir = $this->build_cache_dir();

		// Start cache warmup (delayed)
		// Only if manually enabled !
		// ENTITLEMENT INVARIANT: Maintenance may invalidate without Pro, but it
		// must never turn that maintenance path into cache generation work.
		if ($this->enabled && $this->auto_renew && $this->warmup_strategy !== 'manual') {
			$this->enqueue_warmup_urls();
		}

		// Older versions will be cleaned up later
		$this->cleanup_old_cache_versions($old_version);
	}

	/**
	 * Invalidate every rendered page after a shared template part changes.
	 *
	 * Headers, footers and general parts have no meaningful public permalink;
	 * one part may affect an unknown set of pages, so URL-level invalidation is
	 * insufficient. Autosaves and revisions never represent published output.
	 *
	 * @param int $post_id Template-part post ID.
	 * @param mixed $post Saved or deleted post object.
	 * @param bool $update Whether WordPress updated an existing post.
	 * @return void
	 */

	public function invalidate_template_part_change($post_id, $post = null, $update = true) {
		if (
			function_exists('wphave_doing_wp_save_post_action') &&
			wphave_doing_wp_save_post_action($post_id, $post, [
				'auto-draft',
				'auto-save',
				'revision',
			])
		) {
			return;
		}

		$this->invalidate_all();
	}

	/**
	 * Invalidate every page when a global add-on changes.
	 *
	 * Add-ons may alter output or public access across arbitrary URLs. Clearing
	 * only the add-on post permalink would leave unrelated cached pages stale,
	 * especially when Coming Soon or Maintenance is activated or deactivated.
	 *
	 * @param int $post_id Changed or deleted post ID.
	 * @return void
	 */

	public function invalidate_add_on_change($post_id) {
		if ($this->add_on_cache_invalidated || 'wphave-add-ons' !== get_post_type($post_id)) {
			return;
		}

		$this->add_on_cache_invalidated = true;
		$this->invalidate_all();
	}

	/**
	 * Invalidate rendered pages after attachment metadata changes.
	 *
	 * Responsive image markup depends on attachment dimensions and generated
	 * subsizes, while one attachment may occur on an unknown number of pages.
	 *
	 * @param array $metadata Updated attachment metadata.
	 * @param int $attachment_id Attachment ID.
	 * @return array Unmodified attachment metadata.
	 */

	public function invalidate_attachment_metadata($metadata, $attachment_id) {
		$this->invalidate_attachment($attachment_id);

		return $metadata;
	}

	/**
	 * Invalidate rendered pages once per attachment-changing request.
	 *
	 * WordPress may fire both attachment and metadata hooks for one operation.
	 * The guard prevents multiple static-cache version bumps for the same change.
	 *
	 * @param int $attachment_id Attachment ID.
	 * @return void
	 */

	public function invalidate_attachment($attachment_id) {
		if ($this->attachment_cache_invalidated) {
			return;
		}

		$this->attachment_cache_invalidated = true;
		$this->invalidate_all();
	}

	/**
	 * Remove obsolete cache files after a post permalink changes.
	 *
	 *  IMPORTANT:
	 *  - Prevents orphaned cache files
	 *
	 * @param int $post_id Post ID.
	 * @param WP_Post $post_after Updated post object.
	 * @param WP_Post $post_before Previous post object.
	 * @return void
	 */

	public function handle_post_updated($post_id, $post_after, $post_before) {
		if (!$post_after || !$post_before) {
			return;
		}

		$old_url = get_permalink($post_before);
		$new_url = get_permalink($post_after);

		if ($old_url && $new_url && $old_url !== $new_url) {
			$this->delete_cache_by_url($old_url);
		}

		$this->invalidate_dependencies($post_id);
	}

	/**
	 * Clear cached listings and archives affected by a content change.
	 *
	 *  Includes:
	 *  - Homepage
	 *  - Blog page
	 *  - Archives
	 *  - Taxonomies
	 *
	 *  IMPORTANT:
	 *  - Prevents stale listings (e.g. blog overview)
	 *
	 * @param int $post_id Changed post ID.
	 * @return void
	 */

	private function invalidate_dependencies($post_id) {
		// Homepage
		$this->delete_cache_by_url(home_url('/'));

		// Blog page
		$posts_page_id = get_option('page_for_posts');
		if ($posts_page_id) {
			$this->delete_cache_by_url(get_permalink($posts_page_id));
		}

		// Post type archive
		$post_type = get_post_type($post_id);
		if ($post_type) {
			$archive = get_post_type_archive_link($post_type);
			if ($archive) {
				$this->delete_cache_by_url($archive);
			}
		}

		// Taxonomies
		$taxonomies = get_object_taxonomies($post_type);

		foreach ($taxonomies as $taxonomy) {
			$terms = get_the_terms($post_id, $taxonomy);

			if (!empty($terms) && !is_wp_error($terms)) {
				foreach ($terms as $term) {
					$this->delete_cache_by_url(get_term_link($term));
				}
			}
		}

		// Pagination (optional expansion later)
		$this->delete_cache_by_url(home_url('/page/2/'));
	}

	/**
	 * Return the number of URLs processed per cron run.
	 *
	 *  Based on configured intensity.
	 *
	 * @return int Warmup batch size.
	 */

	public function get_batch_size() {
		if ($this->warmup_intensity === 'high') {
			return 10;
		}
		if ($this->warmup_intensity === 'medium') {
			return 5;
		}

		return 3;
	}

	/**
	 * Increment and persist a cache metric.
	 *
	 *  IMPORTANT:
	 *  - Used for analytics
	 *
	 * @param string $key Metric key.
	 * @return void
	 */

	private function increment_stat($key) {
		$this->mutate_cache_data(function ($current) use ($key) {
			$current['stats'] = is_array($current['stats'] ?? null) ? $current['stats'] : [];
			$current['stats'][$key] = (int) ($current['stats'][$key] ?? 0) + 1;
			return $current;
		});
	}

	/** Count a deliberately uncached final response without storing its URL or content. */
	private function record_bypass(string $reason): void {
		$this->mutate_cache_data(function ($current) use ($reason) {
			$current['stats'] = is_array($current['stats'] ?? null) ? $current['stats'] : [];
			$reasons = is_array($current['stats']['bypass_reasons'] ?? null)
				? $current['stats']['bypass_reasons']
				: [];
			$reasons[$reason] = (int) ($reasons[$reason] ?? 0) + 1;
			$current['stats']['bypass_reasons'] = $reasons;
			if (WPHAVE_Static_Cache_Bypass_Reasons::is_health_evidence($reason)) {
				// HEALTH EVIDENCE INVARIANT: Store only a generation and observation
				// time. A URL, form value or response body is never diagnostic state.
				$recent = is_array($current['stats']['recent_bypasses'] ?? null)
					? $current['stats']['recent_bypasses']
					: [];
				$recent[$reason] = [
					'version' => (int) ($current['version'] ?? 1),
					'last_seen' => time(),
				];
				$current['stats']['recent_bypasses'] = $recent;
			}
			return $current;
		});
	}

	/**
	 * DIAGNOSTIC INVARIANT: Persist only fixed failure categories. Exception text
	 * can contain absolute paths and must never enter administrator metrics.
	 * These counters describe failed writes, not failed public responses.
	 */
	private function record_storage_failure(RuntimeException $error): void {
		$reason = 'publication_failed';
		if (
			$error instanceof WPHAVE_Security_File_Mutex_Exception &&
			in_array(
				$error->reason(),
				[
					WPHAVE_Security_File_Mutex::BUSY,
					WPHAVE_Security_File_Mutex::INVALID,
					WPHAVE_Security_File_Mutex::UNAVAILABLE,
				],
				true,
			)
		) {
			$reason = 'lock_' . $error->reason();
		}
		$this->mutate_cache_data(function ($current) use ($reason) {
			$current['stats'] = is_array($current['stats'] ?? null) ? $current['stats'] : [];
			$reasons = is_array($current['stats']['storage_failure_reasons'] ?? null)
				? $current['stats']['storage_failure_reasons']
				: [];
			$reasons[$reason] = (int) ($reasons[$reason] ?? 0) + 1;
			$current['stats']['storage_failure_reasons'] = $reasons;
			return $current;
		});
	}

	/**
	 * Return cache hit, miss, total, and hit-rate metrics.
	 *
	 *  Includes:
	 *  - Hits
	 *  - Misses
	 *  - Hit rate
	 *
	 *  IMPORTANT:
	 *  - Used for monitoring cache effectiveness
	 *
	 * @return array Cache metrics.
	 */

	public function get_stats() {
		$current = get_option(self::STATE_OPTION, []);
		$stats = is_array($current) && is_array($current['stats'] ?? null)
			? $current['stats']
			: [];

		$hits = max(0, (int) ($stats['hits'] ?? 0));
		$misses = max(0, (int) ($stats['misses'] ?? 0));

		// METRIC INVARIANT: A miss is eligible dynamic HTML, not proof that a
		// document was published. Keep publications outside the hit-rate divisor.
		$total = $hits + $misses;
		$hit_rate = $total > 0 ? round(($hits / $total) * 100) : 0;

		return [
			'hits' => $hits,
			'misses' => $misses,
			'publications' => (int) ($stats['publications'] ?? 0),
			'total' => $total,
			'hit_rate' => $hit_rate,
			'bypass_reasons' => is_array($stats['bypass_reasons'] ?? null)
				? $stats['bypass_reasons']
				: [],
			'storage_failure_reasons' => is_array($stats['storage_failure_reasons'] ?? null)
				? $stats['storage_failure_reasons']
				: [],
		];
	}
}
