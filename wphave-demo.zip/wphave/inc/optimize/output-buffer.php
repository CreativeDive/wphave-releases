<?php

/**
 * Centralized HTML output processing pipeline.
 *
 *  This class provides a unified buffering layer that allows multiple
 *  independent systems (e.g. cache, consent, optimization) to hook into
 *  the final HTML output in a controlled and predictable way.
 *
 *  Instead of using multiple nested ob_start() calls across different features,
 *  this class creates a SINGLE output buffer and processes the HTML through
 *  a prioritized callback pipeline.
 *
 *  Benefits:
 *
 *  - Prevents buffer conflicts (no nested buffering chaos)
 *  - Ensures deterministic execution order via priorities
 *  - Allows independent systems to remain decoupled
 *  - Works whether "wphave caching" is enabled or not
 *  - Works whether "wphave consent" is enabled or not
 *
 *  1. WordPress renders the full HTML page
 *  2. Output is captured by this buffer
 *  3. HTML is passed through registered callbacks (sorted by priority)
 *  4. Final processed HTML is returned to the browser
 *
 *  Example pipeline:
 *
 *      [Consent Processor]  → blocks scripts & embeds
 *      [Optimization]       → minify, clean HTML
 *      [Static Cache]       → stores final HTML
 *
 *  The static cache system hooks into this buffer instead of creating its own.
 *
 *  Important:
 *
 *  - Cache MUST run late (high priority, e.g. 100)
 *  - Cache stores the FINAL HTML after all transformations
 *  - Cache must internally validate if request is cacheable
 *
 *  This ensures:
 *
 *  ✔ Cached HTML always reflects consent-modified output
 *  ✔ No duplicate buffering layers
 *  ✔ Works even if cache is disabled
 *
 *  The consent system modifies HTML BEFORE caching.
 *
 *  It:
 *  - blocks scripts (type="text/plain")
 *  - replaces embeds with placeholders
 *  - injects UI (banner, modal)
 *
 *  Important:
 *
 *  - Must run BEFORE cache
 *  - Must NOT depend on caching being active
 *
 *  This ensures:
 *
 *  ✔ No tracking scripts are cached in executable form
 *  ✔ GDPR compliance is enforced at HTML level
 *  ✔ Same behavior with and without cache
 *
 *  - One buffer. No exceptions.
 *  - Features register themselves (no tight coupling)
 *  - Execution order is explicit (priority-based)
 *  - Each feature is responsible for its own guards (e.g. cacheability)
 *
 *  Register a processor:
 *
 *      WPHAVE_Output_Buffer::instance()->register(
 *          [ $object, 'method' ],
 *          20
 *      );
 *
 *  Priority:
 *      lower = earlier
 *      higher = later
 */

class WPHAVE_Output_Buffer {

    /**
     * Singleton instance.
     *
     * @var WPHAVE_Output_Buffer|null
     */

    private static $instance = null;

    /**
     * Registered processing callbacks.
     *
     * Each item:
     * [
     *   'callback' => callable,
     *   'priority' => int
     * ]
     *
     * @var array
     */

    private $callbacks = [];

    /**
     * Whether buffering has already started.
     *
     * Prevents duplicate ob_start() calls.
     *
     * @var bool
     */

    private $started = false;

    /**
     * Returns singleton instance.
     *
     * @return WPHAVE_Output_Buffer
     */

    public static function instance() {
        if( !self::$instance ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Registers a new HTML processing callback.
     *
     * @param callable $callback Function that receives and returns HTML
     * @param int $priority Execution order (lower = earlier)
     * @return void
     */

    public function register( $callback, $priority = 10 ) {
        $this->callbacks[] = [
            'callback' => $callback,
            'priority' => $priority,
        ];
    }

    /**
     * Starts output buffering.
     *
     * This should run as early as possible in frontend requests.
     *
     * @return void
     */

    public function start() {
        if( $this->started ) return;

        // Skip buffering for non-frontend contexts
        if(
            is_admin() ||
            wp_doing_ajax() ||
            wp_doing_cron() ||
            is_feed() ||
            (defined('REST_REQUEST') && REST_REQUEST) ||
            (defined('WP_CLI') && WP_CLI) ||
            (defined('XMLRPC_REQUEST') && XMLRPC_REQUEST)
         ) {
            return;
        }

        usort( $this->callbacks, function( $a, $b ) {
            return $a['priority'] <=> $b['priority'];
        } );

        ob_start([$this, 'process']);
        $this->started = true;
    }

    /**
     * Processes final HTML output.
     *
     * Executes all registered callbacks in order.
     *
     * @param string $html Final rendered HTML
     * @return string Modified HTML
     */

    public function process( $html ) {
        foreach( $this->callbacks as $item ) {
            $callback = $item['callback'];

            if( is_callable( $callback ) ) {
                $html = call_user_func( $callback, $html );
            }
        }

        return $html;
    }
}

/**
 * Bootstrap buffer early in frontend lifecycle.
 *
 * Runs on template_redirect with priority 0
 * to ensure full page output is captured.
 */

if ( ! function_exists( 'wphave_output_buffer_init' ) ) :

	function wphave_output_buffer_init() {
        WPHAVE_Output_Buffer::instance()->start();
    }

endif;

add_filter('template_redirect', 'wphave_output_buffer_init', 0);
