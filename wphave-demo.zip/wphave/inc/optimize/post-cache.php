<?php

/**
 * Class WPHAVE_Post_Cache
 *
 * Handles full post caching including:
 * - Static data (images, layout, etc.)
 * - Dynamic data (analytics)
 *
 * Optimized for performance and minimal DB queries.
 *
 * @package WPHAVE
 */

final class WPHAVE_Post_Cache {
	/** Per-site generation for invalidating database and external cache entries. */
	private const GENERATION_OPTION = 'wphave_post_cache_generation';
	/**
	 * Transient expiration (14 days)
	 */

	const EXPIRATION = 14 * DAY_IN_SECONDS;

	/**
	 * Boot class
	 */

	public static function init() {
		add_action('shutdown', [__CLASS__, 'maybe_create'], PHP_INT_MAX);
		add_action('wphave_page_color_context_changed', [__CLASS__, 'delete_cache']);

		add_action('rest_api_init', [__CLASS__, 'register_rest_routes']);

		add_action('save_post', [__CLASS__, 'delete_cache_on_save'], 10, 3);
		add_action('edit_attachment', [__CLASS__, 'delete_all_cache']);
		add_action('delete_attachment', [__CLASS__, 'delete_all_cache']);
		add_filter(
			'wp_update_attachment_metadata',
			[__CLASS__, 'delete_cache_on_attachment_metadata_update'],
			10,
			2,
		);
		add_action('added_post_meta', [__CLASS__, 'delete_cache_on_attachment_alt_change'], 10, 4);
		add_action(
			'updated_post_meta',
			[__CLASS__, 'delete_cache_on_attachment_alt_change'],
			10,
			4,
		);
		add_action(
			'deleted_post_meta',
			[__CLASS__, 'delete_cache_on_attachment_alt_change'],
			10,
			4,
		);
	}

	/**
	 * REST permission check
	 *
	 * @return bool
	 */

	public static function rest_permission() {
		return current_user_can('manage_options') &&
			function_exists('wphave_optimization_has_pro_access') &&
			wphave_optimization_has_pro_access();
	}

	/**
	 * Require the complete REST cache-management policy at the final boundary.
	 *
	 * AUTHORIZATION INVARIANT: REST permission callbacks are only an early
	 * dispatch gate. Public REST callbacks repeat capability and Pro authority
	 * immediately before invalidation. Internal invalidators remain callable
	 * by trusted WordPress save and attachment hooks.
	 *
	 * @return true|WP_Error
	 */

	private static function require_rest_permission() {
		if (!self::rest_permission()) {
			return new WP_Error(
				'wphave_post_cache_forbidden',
				__('You are not allowed to invalidate the post cache.', 'wphave'),
				['status' => 403],
			);
		}

		return true;
	}

	/**
	 * Get cache key name for a post
	 *
	 * @param int|null $post_id
	 * @return string
	 */

	public static function get_cache_name($post_id = null) {
		$post_id = $post_id ?: (get_queried_object_id() ?: 0);

		if (!$post_id) {
			return '';
		}

		// A generation also invalidates entries held only in Redis/Memcached.
		$generation = (string) get_option(self::GENERATION_OPTION, 'initial');
		return 'post_cache_' . $generation . '_' . $post_id;
	}

	/**
	 * Check if post cache is enabled
	 *
	 * @return bool
	 */

	public static function is_enabled() {
		$has_pro_access =
			function_exists('wphave_optimization_has_pro_access') &&
			wphave_optimization_has_pro_access();

		return $has_pro_access &&
			(bool) wphave_data_get('site_settings', 'advanced.performance.post_cache', true);
	}

	/**
	 * Get cached data
	 *
	 * @param int|null $post_id
	 * @return array|false
	 */

	public static function get_cache($post_id = null) {
		if (!self::is_enabled()) {
			return false;
		}

		$cache = wphave_has_cached_data(self::get_cache_name($post_id));

		return $cache ?: false;
	}

	/**
	 * Create full post cache (only if not existing)
	 *
	 * @param int|null $post_id
	 * @return void
	 */

	public static function create_cache($post_id = null) {
		if (!self::is_enabled()) {
			return;
		}

		$post_id = $post_id ?: (get_queried_object_id() ?: 0);

		$cache = self::get_cache($post_id);

		// CACHE INVARIANT: The first render does not freeze the image-key set.
		// Later variants and disclosure fragments merge into the same entry.
		if ($cache) {
			$images = apply_filters('wphave_post_images', []) ?: [];
			if ($images) {
				$cache['images'] = array_replace_recursive($cache['images'] ?? [], $images);
			}

			// Analytics remains request-dependent and is refreshed separately.
			self::update_cache_analytics($post_id, $cache);
			return;
		}

		$cache = [];

		// STATIC DATA
		// Post images
		$cache['images'] = apply_filters('wphave_post_images', []) ?: [];

		// DYNAMIC DATA
		// Post analytics
		$cache['analytics'] = wphave_get_post_analytics_data($post_id);

		// Store cache
		set_transient(
			wphave_wp_query_cache_transient(self::get_cache_name($post_id)),
			$cache,
			self::EXPIRATION,
		);
	}

	/**
	 * Update ONLY analytics part of the cache
	 *
	 * Keeps images and static data intact.
	 *
	 * @param int $post_id
	 * @return void
	 */

	public static function update_cache_analytics($post_id, $cache = null) {
		if (!self::is_enabled()) {
			return;
		}

		if (!$cache) {
			$cache = self::get_cache($post_id);
		}

		if (!$cache) {
			return; // nothing to update
		}

		$cache['analytics'] = wphave_get_post_analytics_data($post_id);

		set_transient(
			wphave_wp_query_cache_transient(self::get_cache_name($post_id)),
			$cache,
			self::EXPIRATION,
		);
	}

	/**
	 * Delete post cache
	 *
	 * Used only when content/layout changes.
	 *
	 * @param int|null $post_id
	 * @return void
	 */

	public static function delete_cache($post_id = null) {
		$post_id = $post_id ?: (get_queried_object_id() ?: 0);

		delete_transient(wphave_wp_query_cache_transient(self::get_cache_name($post_id)));
	}

	/**
	 * Delete the post cache for a saved post.
	 *
	 * Autosaves, revisions and AJAX saves are ignored. New posts are skipped
	 * because no existing rendered post cache can exist yet.
	 *
	 * @param int $post_id Saved post ID.
	 * @param WP_Post $post Saved post object.
	 * @param bool $update Whether this is an update of an existing post.
	 * @return void
	 */

	public static function delete_cache_on_save($post_id, $post, $update) {
		if (!$update) {
			return;
		}

		if (
			wphave_doing_wp_save_post_action($post_id, $post, [
				'auto-draft',
				'auto-save',
				'ajax',
				'revision',
			])
		) {
			return;
		}

		self::delete_cache($post_id);
	}

	/**
	 * Delete cached image markup after attachment metadata changes.
	 *
	 * Image markup contains attachment-derived alt text, dimensions and source
	 * candidates. Because an attachment may be referenced by many posts and no
	 * reverse reference index exists, all post caches must be invalidated.
	 *
	 * @param array $metadata Updated attachment metadata.
	 * @param int $attachment_id Attachment ID.
	 * @return array Unmodified attachment metadata.
	 */

	public static function delete_cache_on_attachment_metadata_update($metadata, $attachment_id) {
		self::delete_all_cache();

		return $metadata;
	}

	/**
	 * Delete cached image output after attachment alt text changes directly.
	 *
	 * REST and third-party integrations may update attachment meta without
	 * regenerating image metadata. Listen to the exact alt key so cached empty
	 * and non-empty accessibility text cannot become stale.
	 *
	 * @param int $meta_id Metadata row ID.
	 * @param int $attachment_id Attachment ID.
	 * @param string $meta_key Metadata key.
	 * @param mixed $meta_value Metadata value.
	 * @return void
	 */

	public static function delete_cache_on_attachment_alt_change(
		$meta_id,
		$attachment_id,
		$meta_key,
		$meta_value,
	) {
		if ($meta_key === '_wp_attachment_image_alt') {
			WPHAVE_Image_Renderer::invalidate_alt($attachment_id);
			self::delete_all_cache();
		}
	}

	/**
	 * Auto-create cache on shutdown
	 *
	 * @return void
	 */

	public static function maybe_create() {
		if (!self::is_enabled()) {
			return;
		}

		$post_id = get_queried_object_id();

		if (!$post_id || !is_singular()) {
			return;
		}

		self::create_cache($post_id);
	}

	/**
	 * Get post views (cached)
	 *
	 * @param int|null $post_id
	 * @param string $type recent|lifetime
	 * @return int
	 */

	public static function get_views($post_id = null, $type = 'recent') {
		$post_id = $post_id ?: (get_queried_object_id() ?: 0);

		$cache = self::get_cache($post_id);

		if (!$cache || empty($cache['analytics'])) {
			return 0;
		}

		return $type === 'lifetime'
			? (int) ($cache['analytics']['views_lifetime'] ?? 0)
			: (int) ($cache['analytics']['views_recent'] ?? 0);
	}

	/**
	 * REST: Delete single post cache
	 *
	 * @param WP_REST_Request $request
	 * @return array|WP_Error
	 */

	public static function rest_delete_post_cache($request) {
		$authorized = self::require_rest_permission();

		if (is_wp_error($authorized)) {
			return $authorized;
		}

		$post_id = (int) $request['id'];

		if (!$post_id) {
			return new WP_Error('invalid_post', 'Invalid post ID', ['status' => 400]);
		}

		self::delete_cache($post_id);

		return [
			'success' => true,
			'post_id' => $post_id,
		];
	}

	/**
	 * Delete all post cache transients.
	 *
	 * The optional argument accepts IDs supplied by attachment actions.
	 *
	 * @param int $attachment_id Optional attachment ID.
	 * @return void
	 */

	public static function delete_all_cache($attachment_id = 0) {
		global $wpdb;

		// New lookups must never reuse an entry stored in an external object cache.
		update_option(self::GENERATION_OPTION, wp_generate_uuid4(), false);
		$prefix = '_transient_' . wphave_wp_query_cache_transient('post_cache_');
		$names = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
				$wpdb->esc_like($prefix) . '%',
			),
		);
		// Use the WordPress API so already-loaded option caches are invalidated too.
		foreach ($names as $name) {
			delete_transient(substr($name, strlen('_transient_')));
		}
	}

	/**
	 * REST: Delete all post cache entries.
	 *
	 * @return array|WP_Error REST response data or authorization failure.
	 */

	public static function rest_delete_all_cache() {
		$authorized = self::require_rest_permission();

		if (is_wp_error($authorized)) {
			return $authorized;
		}

		self::delete_all_cache();

		return [
			'success' => true,
			'message' => 'All post cache cleared',
		];
	}

	/**
	 * Register REST routes for cache invalidation
	 *
	 * @return void
	 */

	public static function register_rest_routes() {
		register_rest_route('wphave/v1', '/post-cache/post/(?P<id>\d+)', [
			'methods' => 'DELETE',
			'callback' => [__CLASS__, 'rest_delete_post_cache'],
			'permission_callback' => [__CLASS__, 'rest_permission'],
		]);

		register_rest_route('wphave/v1', '/post-cache/all', [
			'methods' => 'DELETE',
			'callback' => [__CLASS__, 'rest_delete_all_cache'],
			'permission_callback' => [__CLASS__, 'rest_permission'],
		]);
	}
}

/**
 * Init
 */

function wphave_post_cache_init() {
	WPHAVE_Post_Cache::init();
}

add_action('plugins_loaded', 'wphave_post_cache_init');
