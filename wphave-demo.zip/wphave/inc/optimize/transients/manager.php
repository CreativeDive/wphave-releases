<?php

/**
 * Provides REST endpoints for inspecting and deleting WordPress transients.
 *
 * The list endpoint intentionally returns metadata and short previews only.
 * Full values are loaded on demand through the inspect endpoint because
 * transients can be large or contain sensitive third-party payloads.
 */

if( ! defined('ABSPATH') ) exit;

require_once wphave_dir() . 'inc/features/security/boundaries/serialization.php';

class WPHAVE_Transient_Manager {

	const PREVIEW_LENGTH = 220;
	const MAX_BULK_DELETE_ITEMS = 200;
	const EXPIRED_DELETE_BATCH_SIZE = 200;

	/**
	 * Bootstraps the Transient Manager REST routes.
	 */

	public static function init() {
		add_action( 'rest_api_init', [ __CLASS__, 'register_routes' ] );
	}

	/**
	 * Restrict access to administrators or users with the explicit transient capability.
	 */

	public static function permissions_check() {
		return is_user_logged_in() && ( current_user_can('manage_options') || current_user_can('wphave_manage_transients') );
	}

	/** Require Transient Manager authority at the executable callback boundary. */

	private static function require_permission() {
		// AUTHORIZATION INVARIANT: REST route permission is an early transport
		// gate, not reusable authority. Every executable endpoint repeats the
		// dedicated capability check before reading values or mutating storage.
		if ( self::permissions_check() ) {
			return true;
		}

		return new WP_Error(
			'wphave_transients_forbidden',
			__( 'You are not allowed to manage transients.', 'wphave' ),
			array( 'status' => 403 )
		);
	}

	/** Execute an optional authorization guard at a domain commit boundary. */

	private static function authorize_commit( $authorization_guard ) {
		if ( ! is_callable( $authorization_guard ) ) {
			return true;
		}

		$authorization = call_user_func( $authorization_guard );

		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		return $authorization
			? true
			: new WP_Error(
				'wphave_transients_forbidden',
				__( 'You are not allowed to manage transients.', 'wphave' ),
				array( 'status' => 403 )
			);
	}

	/**
	 * Return transient metadata for the manager table.
	 */

	public static function get_transients_endpoint() {
		$authorization = self::require_permission();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$items = self::get_transients();
		if( is_wp_error( $items ) ) {
			return $items;
		}

		// AUTHORIZATION/TRANSIENT-LIST-RESPONSE INVARIANT: Normal and network
		// transient metadata are projected through filterable database boundaries.
		// Revalidate the canonical management policy after both inventories are
		// materialized and immediately before private names and metadata are released.
		$authorization = self::require_permission();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		return rest_ensure_response( [
			'items' => $items,
		] );
	}

	/**
	 * Return the complete transient value for an explicit inspect action.
	 */

	public static function inspect_transient_endpoint( WP_REST_Request $request ) {
		$authorization = self::require_permission();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$item = self::prepare_transient_reference( $request->get_params() );

		if( is_wp_error( $item ) ) {
			return $item;
		}

		$details = self::get_transient_details( $item['name'], $item['type'] );

		if( ! $details ) {
			return new WP_Error(
				'tm_transient_not_found',
				__('Transient not found.', 'wphave'),
				[ 'status' => 404 ]
			);
		}

		// AUTHORIZATION/TRANSIENT-INSPECT-RESPONSE INVARIANT: Existence checks,
		// Core value loading and storage metadata queries cross filterable database,
		// option and serialization boundaries. Revalidate management authority after
		// full projection and before releasing the complete transient value.
		$authorization = self::require_permission();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		return rest_ensure_response( $details );
	}

	/**
	 * Delete a single transient by name and type.
	 */

	public static function delete_transient_endpoint( WP_REST_Request $request ) {
		$authorization = self::require_permission();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$item = self::prepare_transient_reference( $request->get_params() );

		if( is_wp_error( $item ) ) {
			return $item;
		}

		// AUTHORIZATION/TRANSIENT-DELETE INVARIANT: Type and name normalization
		// cross filterable WordPress sanitizer boundaries. Revalidate management
		// authority for the fully resolved reference immediately before Core or raw
		// storage deletion begins.
		$authorization = self::require_permission();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$deleted = self::delete_transient_item( $item['name'], $item['type'] );

		if( ! $deleted ) {
			return new WP_Error(
				'tm_transient_not_found',
				__('Transient not found.', 'wphave'),
				[ 'status' => 404 ]
			);
		}

		return rest_ensure_response( [
			'success' => true,
		] );
	}

	/**
	 * Delete all expired normal and site transients.
	 */

	public static function delete_expired_endpoint() {
		$authorization = self::require_permission();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$result = self::delete_expired_transients( array( __CLASS__, 'require_permission' ) );
		if( is_wp_error( $result ) ) {
			return $result;
		}

		$items = null;
		if( ! $result['has_more'] ) {
			$items = self::get_transients();
			if( is_wp_error( $items ) ) {
				return $items;
			}
		}

		// AUTHORIZATION/TRANSIENT-EXPIRED-RESPONSE INVARIANT: Cleanup progress and
		// any refreshed private inventory cross post-commit database boundaries.
		// Revalidate management authority after projection and immediately before
		// releasing either operational state or transient metadata.
		$authorization = self::require_permission();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		return rest_ensure_response( [
			'deleted' => $result['deleted'],
			'hasMore' => $result['has_more'],
			'items' => $items,
		] );
	}

	/**
	 * Delete multiple selected transients.
	 */

	public static function bulk_delete_endpoint( WP_REST_Request $request ) {
		$authorization = self::require_permission();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$items = $request->get_param( 'items' );

		if( ! is_array( $items ) ) {
			return new WP_Error(
				'tm_invalid_items',
				__('Invalid items payload.', 'wphave'),
				[ 'status' => 400 ]
			);
		}

		if( count( $items ) > self::MAX_BULK_DELETE_ITEMS ) {
			return new WP_Error(
				'tm_too_many_items',
				__('Too many transients selected for one bulk delete action.', 'wphave'),
				[ 'status' => 400 ]
			);
		}

		$deleted = self::bulk_delete_transients( $items, array( __CLASS__, 'require_permission' ) );
		if ( is_wp_error( $deleted ) ) {
			return $deleted;
		}

		$transients = self::get_transients();
		if( is_wp_error( $transients ) ) {
			return $transients;
		}

		// AUTHORIZATION/TRANSIENT-BULK-RESPONSE INVARIANT: The refreshed inventory
		// is a separate private read after the batch commit. Revalidate the canonical
		// management policy after its full projection and immediately before release.
		$authorization = self::require_permission();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		return rest_ensure_response( [
			'deleted' => $deleted,
			'items' => $transients,
		] );
	}

	/**
	 * Build a metadata list for normal and site transients without loading full values.
	 */

	public static function get_transients() {
		$normal_items = self::get_transients_by_type( 'normal' );
		if( is_wp_error( $normal_items ) ) {
			return $normal_items;
		}

		$site_items = self::get_transients_by_type( 'site' );
		if( is_wp_error( $site_items ) ) {
			return $site_items;
		}

		$items = array_merge( $normal_items, $site_items );

		usort( $items, function ( $a, $b ) {
			return $b['size'] <=> $a['size'];
		});

		return array_values( $items );
	}

	/**
	 * Query one transient family and map value rows to timeout rows.
	 */

	private static function get_transients_by_type( string $type ) {
		global $wpdb;

		$storage = self::storage_contract( $type );
		$prefix = self::option_prefix( $type );
		$timeout_prefix = self::timeout_option_prefix( $type );
		$value_like = $wpdb->esc_like( $prefix ) . '%';
		$timeout_like = $wpdb->esc_like( $timeout_prefix ) . '%';
		$scope_sql = $storage['scope_sql'];
		$scope_arguments = $storage['scope_arguments'];
		$autoload_select = $storage['autoload_column']
			? $storage['autoload_column'] . ' AS autoload'
			: "'' AS autoload";

		$wpdb->last_error = '';
		$values = $wpdb->get_results(
			$wpdb->prepare(
				"
				SELECT {$storage['name_column']} AS option_name, {$autoload_select}, LENGTH({$storage['value_column']}) AS size, SUBSTRING({$storage['value_column']}, 1, %d) AS preview
				FROM {$storage['table']}
				WHERE {$scope_sql} {$storage['name_column']} LIKE %s
				AND {$storage['name_column']} NOT LIKE %s
				",
				array_merge( $scope_arguments, array( self::PREVIEW_LENGTH, $value_like, $timeout_like ) )
			),
			ARRAY_A
		);
		if( null === $values || $wpdb->last_error ) {
			return self::storage_error();
		}

		$wpdb->last_error = '';
		$timeouts = $wpdb->get_results(
			$wpdb->prepare(
				"
				SELECT {$storage['name_column']} AS option_name, {$storage['value_column']} AS option_value
				FROM {$storage['table']}
				WHERE {$scope_sql} {$storage['name_column']} LIKE %s
				",
				array_merge( $scope_arguments, array( $timeout_like ) )
			),
			ARRAY_A
		);
		if( null === $timeouts || $wpdb->last_error ) {
			return self::storage_error();
		}

		$timeout_map = [];

		foreach( $timeouts ?: [] as $row ) {
			$name = self::strip_option_prefix( $row['option_name'], $type, true );
			$timeout_map[ $name ] = (int) $row['option_value'];
		}

		$items = [];
		$now = time();

		foreach( $values ?: [] as $row ) {
			$name = self::strip_option_prefix( $row['option_name'], $type );
			$timeout = $timeout_map[ $name ] ?? null;
			$size = (int) $row['size'];

			$items[] = [
				'name' => $name,
				'type' => $type,
				'type_label' => $type === 'site' ? __('Site transient', 'wphave') : __('Transient', 'wphave'),
				'timeout' => $timeout,
				'expires_at' => $timeout ?: null,
				'is_expired' => $timeout ? $timeout < $now : false,
				'size' => $size,
				'autoload' => $row['autoload'] ?? '',
				'value_type' => self::guess_value_type( (string) $row['preview'], $size ),
				'value_preview' => '',
				'has_value' => true,
			];
		}

		return $items;
	}

	/**
	 * Fetch one full transient value only after the user explicitly asks to inspect it.
	 */

	private static function get_transient_details( string $name, string $type ) {
		if( ! self::transient_exists( $name, $type ) ) {
			return null;
		}

		$value = $type === 'site' ? get_site_transient( $name ) : get_transient( $name );
		$meta = self::get_transient_meta( $name, $type );

		return [
			'name' => $name,
			'type' => $type,
			'type_label' => $type === 'site' ? __('Site transient', 'wphave') : __('Transient', 'wphave'),
			'value' => $value,
			'value_type' => gettype( $value ),
			'value_preview' => self::build_preview( $value ),
			'size' => $meta['size'],
			'timeout' => $meta['timeout'],
			'expires_at' => $meta['timeout'] ?: null,
			'is_expired' => $meta['timeout'] ? $meta['timeout'] < time() : false,
			'autoload' => $meta['autoload'],
		];
	}

	/**
	 * Delete one normal or site transient and verify that at least one row changed.
	 */

	public static function delete_transient_item( string $name, string $type = 'normal' ) {
		$exists = self::transient_exists( $name, $type );
		$deleted = $type === 'site' ? delete_site_transient( $name ) : delete_transient( $name );

		if( $deleted ) {
			return true;
		}

		$value_deleted = self::delete_storage_row( self::option_prefix( $type ) . $name, $type );
		$timeout_deleted = self::delete_storage_row( self::timeout_option_prefix( $type ) . $name, $type );

		return $exists && ( (int) $value_deleted + (int) $timeout_deleted ) > 0;
	}

	/**
	 * Delete one bounded batch of expired transients from timeout-row candidates.
	 *
	 * @return array{deleted:int,has_more:bool}|WP_Error Cleanup progress or failure.
	 */

	public static function delete_expired_transients( $authorization_guard = null ) {
		$candidates = array();
		foreach( array( 'normal', 'site' ) as $type ) {
			$type_candidates = self::expired_candidates( $type, self::EXPIRED_DELETE_BATCH_SIZE + 1 );
			if( is_wp_error( $type_candidates ) ) {
				return $type_candidates;
			}

			foreach( $type_candidates as $name ) {
				$candidates[] = array(
					'name' => $name,
					'type' => $type,
				);
			}
		}

		$candidates = array_slice( $candidates, 0, self::EXPIRED_DELETE_BATCH_SIZE );

		// AUTHORIZATION/TRANSIENT-EXPIRED-CLEANUP INVARIANT: Candidate discovery
		// crosses filterable normal and network database boundaries. An endpoint
		// caller must revalidate its canonical policy after the complete bounded
		// candidate set is known and immediately before the first deletion. The
		// optional guard keeps this reusable domain operation policy-neutral.
		$authorization = self::authorize_commit( $authorization_guard );
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$deleted = 0;
		foreach( $candidates as $candidate ) {
			if( self::delete_transient_item( $candidate['name'], $candidate['type'] ) ) {
				++$deleted;
			}
		}

		$has_more = false;
		foreach( array( 'normal', 'site' ) as $type ) {
			$remaining = self::expired_candidates( $type, 1 );
			if( is_wp_error( $remaining ) ) {
				return $remaining;
			}
			if( $remaining ) {
				$has_more = true;
				break;
			}
		}

		return array(
			'deleted' => $deleted,
			'has_more' => $has_more,
		);
	}

	/** Read one bounded set of expired names without loading transient values. */

	private static function expired_candidates( string $type, int $limit ) {
		global $wpdb;
		$storage = self::storage_contract( $type );
		$timeout_prefix = self::timeout_option_prefix( $type );
		$scope_sql = $storage['scope_sql'];
		$wpdb->last_error = '';
		$rows = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT {$storage['name_column']} FROM {$storage['table']} WHERE {$scope_sql} {$storage['name_column']} LIKE %s AND CAST({$storage['value_column']} AS SIGNED) < %d ORDER BY {$storage['name_column']} ASC LIMIT %d",
				array_merge(
					$storage['scope_arguments'],
					array(
						$wpdb->esc_like( $timeout_prefix ) . '%',
						time(),
						max( 1, $limit ),
					)
				)
			)
		);

		// RESILIENCE INVARIANT: Unknown candidate state aborts the mutation.
		if( null === $rows || $wpdb->last_error ) {
			return self::storage_error();
		}

		return array_map(
			static fn( string $option_name ): string => self::strip_option_prefix( $option_name, $type, true ),
			$rows
		);
	}

	/**
	 * Delete selected transients after sanitizing every submitted reference.
	 */

	public static function bulk_delete_transients( array $items, $authorization_guard = null ) {
		$prepared_items = array();

		foreach( $items as $item ) {
			$prepared = self::prepare_transient_reference( is_array( $item ) ? $item : [] );

			if( is_wp_error( $prepared ) ) {
				continue;
			}

			$prepared_items[] = $prepared;
		}

		// AUTHORIZATION/TRANSIENT-BULK-DELETE INVARIANT: Every selected reference
		// is normalized before mutation because WordPress sanitizers are filterable.
		// Endpoint callers must revalidate their canonical policy once projection is
		// complete and before the first item is deleted; no partially authorized
		// batch may be committed. The optional guard preserves internal API policy.
		$authorization = self::authorize_commit( $authorization_guard );
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$deleted = 0;
		foreach( $prepared_items as $prepared ) {
			if ( self::delete_transient_item( $prepared['name'], $prepared['type'] ) ) {
				$deleted++;
			}
		}

		return $deleted;
	}

	/**
	 * Normalize and validate a transient reference from REST input.
	 */

	private static function prepare_transient_reference( array $data ) {
		$type = sanitize_key( $data['type'] ?? 'normal' );
		$name = self::sanitize_transient_name( $data['name'] ?? '', $type );

		if( ! in_array( $type, [ 'normal', 'site' ], true ) ) {
			return new WP_Error(
				'tm_invalid_type',
				__('Invalid transient type.', 'wphave'),
				[ 'status' => 400 ]
			);
		}

		if( ! $name ) {
			return new WP_Error(
				'tm_missing_name',
				__('Missing transient name.', 'wphave'),
				[ 'status' => 400 ]
			);
		}

		return [
			'name' => $name,
			'type' => $type,
		];
	}

	/**
	 * Sanitize a transient name and strip option-table prefixes if they were submitted.
	 */

	private static function sanitize_transient_name( $name, string $type ) {
		$name = sanitize_text_field( wp_unslash( $name ) );
		$name = self::strip_known_prefixes( $name );

		$maximum_length = 'site' === $type ? 167 : 172;
		if( ! $name || strlen( $name ) > $maximum_length ) {
			return '';
		}

		return $name;
	}

	/**
	 * Remove known option-name prefixes from submitted transient names.
	 */

	private static function strip_known_prefixes( string $name ) {
		foreach( [ '_site_transient_timeout_', '_site_transient_', '_transient_timeout_', '_transient_' ] as $prefix ) {
			if( strpos( $name, $prefix ) === 0 ) {
				return substr( $name, strlen( $prefix ) );
			}
		}

		return $name;
	}

	/**
	 * Return one transient's option-table metadata.
	 */

	private static function get_transient_meta( string $name, string $type ) {
		global $wpdb;
		$storage = self::storage_contract( $type );
		$scope_sql = $storage['scope_sql'];
		$scope_arguments = $storage['scope_arguments'];
		$autoload_select = $storage['autoload_column']
			? $storage['autoload_column'] . ' AS autoload'
			: "'' AS autoload";

		$value_row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT LENGTH({$storage['value_column']}) AS size, {$autoload_select} FROM {$storage['table']} WHERE {$scope_sql} {$storage['name_column']} = %s LIMIT 1",
				array_merge( $scope_arguments, array( self::option_prefix( $type ) . $name ) )
			),
			ARRAY_A
		);
		$timeout = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT {$storage['value_column']} FROM {$storage['table']} WHERE {$scope_sql} {$storage['name_column']} = %s LIMIT 1",
				array_merge( $scope_arguments, array( self::timeout_option_prefix( $type ) . $name ) )
			)
		);

		return [
			'size' => isset( $value_row['size'] ) ? (int) $value_row['size'] : 0,
			'autoload' => $value_row['autoload'] ?? '',
			'timeout' => $timeout ? (int) $timeout : null,
		];
	}

	/**
	 * Check whether the transient value or timeout row exists.
	 */

	private static function transient_exists( string $name, string $type ) {
		global $wpdb;
		$storage = self::storage_contract( $type );

		return (bool) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT {$storage['id_column']} FROM {$storage['table']} WHERE {$storage['scope_sql']} {$storage['name_column']} IN (%s, %s) LIMIT 1",
				array_merge(
					$storage['scope_arguments'],
					array(
						self::option_prefix( $type ) . $name,
						self::timeout_option_prefix( $type ) . $name,
					)
				)
			)
		);
	}

	/**
	 * Resolve the canonical WordPress storage boundary for one transient family.
	 *
	 * STORAGE INVARIANT: Network transients belong to the current network's
	 * sitemeta rows on Multisite. Every raw read and fallback delete must share
	 * this contract so inspection cannot drift from Core's site-option APIs.
	 */

	private static function storage_contract( string $type ): array {
		global $wpdb;

		if( 'site' === $type && is_multisite() ) {
			return array(
				'table' => $wpdb->sitemeta,
				'id_column' => 'meta_id',
				'name_column' => 'meta_key',
				'value_column' => 'meta_value',
				'autoload_column' => '',
				'scope_sql' => 'site_id = %d AND ',
				'scope_arguments' => array( get_current_network_id() ),
			);
		}

		return array(
			'table' => $wpdb->options,
			'id_column' => 'option_id',
			'name_column' => 'option_name',
			'value_column' => 'option_value',
			'autoload_column' => 'autoload',
			'scope_sql' => '',
			'scope_arguments' => array(),
		);
	}

	/** Return a generic database error without exposing option payloads or SQL. */

	private static function storage_error(): WP_Error {
		return new WP_Error(
			'wphave_transient_storage_unavailable',
			__( 'Transient storage could not be read. Please try again.', 'wphave' ),
			array( 'status' => 500 )
		);
	}

	/** Delete one raw storage row after Core could not remove an orphan pair. */

	private static function delete_storage_row( string $option_name, string $type ) {
		global $wpdb;
		$storage = self::storage_contract( $type );
		$where = array( $storage['name_column'] => $option_name );
		$formats = array( '%s' );

		if( 'site' === $type && is_multisite() ) {
			$network_id = get_current_network_id();
			$where['site_id'] = $network_id;
			$formats[] = '%d';
			wp_cache_delete( $network_id . ':' . $option_name, 'site-options' );
		} else {
			wp_cache_delete( $option_name, 'options' );
			wp_cache_delete( 'alloptions', 'options' );
		}

		return $wpdb->delete( $storage['table'], $where, $formats );
	}

	/**
	 * Build a safe short preview from a full PHP value.
	 */

	private static function build_preview( $value ) {
		if( is_array( $value ) || is_object( $value ) ) {
			$preview = wp_json_encode( $value );
		} elseif( is_bool( $value ) ) {
			$preview = $value ? 'true' : 'false';
		} elseif( null === $value ) {
			$preview = 'null';
		} else {
			$preview = (string) $value;
		}

		return function_exists('mb_substr') ? mb_substr($preview, 0, self::PREVIEW_LENGTH) : substr($preview, 0, self::PREVIEW_LENGTH);
	}

	/**
	 * Guess the value type without loading large payloads into PHP memory.
	 */

	private static function guess_value_type( string $value, int $size ) {
		if( $size > self::PREVIEW_LENGTH ) {
			return 'large';
		}

		// SECURITY INVARIANT: The diagnostic type preview treats transient
		// payloads as data and never invokes magic methods from stored objects.
		return gettype( wphave_maybe_unserialize_without_classes( $value ) );
	}

	/**
	 * Return the option prefix for normal or site transient values.
	 */

	private static function option_prefix( string $type ) {
		return $type === 'site' ? '_site_transient_' : '_transient_';
	}

	/**
	 * Return the option prefix for normal or site transient timeouts.
	 */

	private static function timeout_option_prefix( string $type ) {
		return $type === 'site' ? '_site_transient_timeout_' : '_transient_timeout_';
	}

	/**
	 * Strip the option prefix from a raw option name.
	 */

	private static function strip_option_prefix( string $option_name, string $type, bool $timeout = false ) {
		$prefix = $timeout ? self::timeout_option_prefix( $type ) : self::option_prefix( $type );

		return substr( $option_name, strlen( $prefix ) );
	}

	/**
	 * Truncate text safely when multibyte support is available.
	 */

	private static function truncate( string $value, int $length ) {
		return function_exists('mb_substr') ? mb_substr($value, 0, $length) : substr($value, 0, $length);
	}

	/**
	 * Register all REST API endpoints used by the Transient Manager.
	 */

	public static function register_routes() {
		register_rest_route( 'wphave/v1', '/transients', [
			'methods' => WP_REST_Server::READABLE,
			'callback' => [ __CLASS__, 'get_transients_endpoint' ],
			'permission_callback' => [ __CLASS__, 'permissions_check' ],
		]);

		register_rest_route( 'wphave/v1', '/transients-inspect', [
			'methods' => WP_REST_Server::CREATABLE,
			'callback' => [ __CLASS__, 'inspect_transient_endpoint' ],
			'permission_callback' => [ __CLASS__, 'permissions_check' ],
		]);

		register_rest_route( 'wphave/v1', '/transients-delete', [
			'methods' => WP_REST_Server::CREATABLE,
			'callback' => [ __CLASS__, 'delete_transient_endpoint' ],
			'permission_callback' => [ __CLASS__, 'permissions_check' ],
		]);

		register_rest_route( 'wphave/v1', '/transients-delete-expired', [
			'methods' => WP_REST_Server::CREATABLE,
			'callback' => [ __CLASS__, 'delete_expired_endpoint' ],
			'permission_callback' => [ __CLASS__, 'permissions_check' ],
		]);

		register_rest_route( 'wphave/v1', '/transients-bulk-delete', [
			'methods' => WP_REST_Server::CREATABLE,
			'callback' => [ __CLASS__, 'bulk_delete_endpoint' ],
			'permission_callback' => [ __CLASS__, 'permissions_check' ],
		]);
	}
}

/**
 * Initialize the transient manager after plugins are loaded.
 *
 * @return void
 */

if ( ! function_exists( 'wphave_transient_manager_init' ) ) :

	function wphave_transient_manager_init() {
        WPHAVE_Transient_Manager::init();
    }

endif;

add_action('plugins_loaded', 'wphave_transient_manager_init');
