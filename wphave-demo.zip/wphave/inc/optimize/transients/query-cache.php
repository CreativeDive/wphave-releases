<?php

if( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Flatten scalar values from a collection of sub-arrays.
 *
 * Nested array values are skipped and duplicate scalar values are removed.
 * Non-array input is returned unchanged for compatibility with existing callers.
 *
 * @param mixed $array Collection to flatten.
 * @return array|mixed Flattened values, or the original non-array value.
 */

if ( ! function_exists( 'wphave_move_sub_array_to_level_1' ) ) :

	function wphave_move_sub_array_to_level_1( $array ) {

		if( ! is_array( $array ) ) {
			return $array;
		}

		$new_array = array();

		foreach( $array as $subarr ) {

		   foreach( $subarr as $key => $value ) {

			  if( is_array( $value ) ) {
				 continue;
			  }

			  $new_array[] = $value;

		   }

		}

		$new_array = array_unique( $new_array );

		return $new_array;

	}

endif;

if( ! class_exists( 'WPHAVE_Query_Transient_Cache' ) ) :

	/**
	 * Centralizes WPHAVE query transient naming, reads, writes and post ID caches.
	 *
	 * This class is deliberately low-level. Feature-specific cache ownership
	 * remains in the feature classes, while this class provides the shared
	 * transient naming convention and the common admin/frontend write rules.
	 */

	class WPHAVE_Query_Transient_Cache {

		/**
		 * Shared transient bucket used by post-type related feature caches.
		 *
		 * @var string
		 */

		const POST_TYPE_FEATURES_BUCKET = 'post_type_features_data';

		/**
		 * Cache key for global post IDs grouped by post type.
		 *
		 * @var string
		 */

		const KEY_GLOBAL_POST_IDS = 'global_posts_ids';

		/**
		 * Default query transient expiration.
		 *
		 * @var int
		 */

		const DEFAULT_EXPIRATION = 14 * DAY_IN_SECONDS;

		/**
		 * Build the shared transient name for WPHAVE query caches.
		 *
		 * Keeping the prefix centralized prevents cache consumers from hardcoding
		 * transient names in multiple places.
		 *
		 * @param string $name Cache name without the WPHAVE query cache prefix.
		 * @return string Fully prefixed transient name.
		 */

		public static function transient_name( $name ) {

			return WPHAVE_NAMESPACE . '_wp_query_cache_' . $name;

		}

		/**
		 * Build and cache post IDs grouped by post type.
		 *
		 * This is intentionally lazy. It can be expensive when no post type is
		 * passed, because it queries all public post types and WPHAVE internal
		 * post types. Do not attach this to a global hook such as init.
		 *
		 * @param array|string $args Optional query arguments.
		 * @return array Post IDs grouped by post type, a single post type ID list, or a flattened ID list.
		 */

		public static function all_post_ids( $args = '' ) {

			$args = is_array( $args ) ? $args : array();

			$post_type = isset( $args['post_type'] ) && $args['post_type'] ? $args['post_type'] : ''; // <-- "any" for all post types or the post type name like "post, page" for specific post type(s)
			$requested_post_type = $post_type;
			$post_status = isset( $args['post_status'] ) && $args['post_status'] ? $args['post_status'] : 'publish';
			$all_in_one = isset( $args['all_in_one'] ) && $args['all_in_one'] ? $args['all_in_one'] : '';

			if( $post_type ) {
				$all_in_one = false;
			}

			$cached = self::get( self::POST_TYPE_FEATURES_BUCKET, array(
				'key' => self::KEY_GLOBAL_POST_IDS,
				'block_editor_cache' => true,
			) );

			// List all public post types
			$args = array(
			   'public' => true,
			);

			$public_post_types_array = array();

			// Get all public post types
			$public_post_types = get_post_types( $args, 'names' );
			foreach( $public_post_types as $public_post_type ) {
				$public_post_types_array[] = $public_post_type;
			}

			// List all allowed post types features
			$post_type_features = wphave_internal_post_types();

			// Merge public and wphave post type features to one array
			$post_types = array_merge( $public_post_types_array, $post_type_features );

			$save_data = array();

			// Check if we have cached results
			if( $cached ) {

				// Check if a post type is passed
				if( $post_type ) {
					if( isset( $cached[$post_type] ) ) {
						// Return the cached data
						// Get all post ids of a specific post
						return $cached[$post_type];
					}
				} else {
					// Return the cached data
					// Get all post ids of all post types
					if( $all_in_one ) {
						return wphave_move_sub_array_to_level_1( $cached );
					}

					return $cached;
				}
			}

			$args = array(
				'post_type' => $post_type,
				'fields' => 'ids', // Only get post IDs
				'posts_per_page' => -1, // Get all posts without limitation
				'post_status' => $post_status,
				'suppress_filters' => false,
				'cache_results'	=> true,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
			);

			// Check if a post type is passed
			if( $post_type ) {
				// Get the current post type
				$args['post_type'] = $post_type;

				// Add all post ids by post type
				$save_data[$post_type] = get_posts( $args );
			} else {
				// Otherwise create the cache yet
				// Check for all post types
				foreach( $post_types as $current_post_type ) {
					// Get the current post type
					$args['post_type'] = $current_post_type;

					// Add all post ids by post type
					$save_data[$current_post_type] = get_posts( $args );
				}
			}

			// Save/Cache the WP Query to transient
			if( $requested_post_type && is_array( $cached ) ) {
				$save_data = array_merge( $cached, $save_data );

				if( ! function_exists( 'wphave_internal_post_type_cache_can_write' ) || wphave_internal_post_type_cache_can_write() ) {
					$transient_name = self::transient_name( self::POST_TYPE_FEATURES_BUCKET );
					$transient_data = get_transient( $transient_name ) ?: array();
					$transient_data[self::KEY_GLOBAL_POST_IDS] = $save_data;
					set_transient( $transient_name, $transient_data, self::DEFAULT_EXPIRATION );
				}
			} else {
				self::save( $save_data, self::POST_TYPE_FEATURES_BUCKET, array(
					'key' => self::KEY_GLOBAL_POST_IDS,
					'block_editor_cache' => true,
					'frontend_write' => false,
				) );
			}

			// Check if a post type is passed
			if( $requested_post_type ) {
				if( isset( $save_data[$requested_post_type] ) ) {
					// Return the raw data
					// Get all post ids of a specific post
					return $save_data[$requested_post_type];
				}
			}

			// Return the raw data
			// Get all post ids of all post types

			if( $all_in_one ) {
				return wphave_move_sub_array_to_level_1( $save_data );
			}

			return $save_data;

		}

		/**
		 * Save query data to a WPHAVE query transient.
		 *
		 * By default, query data is not written while editing in wp-admin. Pass
		 * admin_cache or block_editor_cache when the cache is explicitly needed
		 * there. When key is provided, data is stored as a nested entry inside
		 * the transient.
		 *
		 * @param mixed $query_data Data to cache.
		 * @param string $name Cache name without the WPHAVE query cache prefix.
		 * @param array $args Optional cache arguments.
		 * @return mixed Cached data on success, false when skipped or empty.
		 */

			public static function save( $query_data, $name, $args = '' ) {

			$args = is_array( $args ) ? $args : array();

			$admin_cache = isset( $args['admin_cache'] ) ? $args['admin_cache'] : '';
			$block_editor_cache = isset( $args['block_editor_cache'] ) ? $args['block_editor_cache'] : '';
			$post_type = isset( $args['post_type'] ) ? $args['post_type'] : '';
			$transient_key = isset( $args['key'] ) ? $args['key'] : '';
			$expiration_time = isset( $args['expiration'] ) ? $args['expiration'] : self::DEFAULT_EXPIRATION;
			$frontend_write = array_key_exists( 'frontend_write', $args ) ? (bool) $args['frontend_write'] : true;

			$admin_cache = ( $admin_cache ?: $block_editor_cache );
			// SECURITY INVARIANT: Callers that disable frontend writes may populate the
			// shared bucket only inside the explicitly recognized internal write context.
			$can_write_cache = $frontend_write || ( function_exists( 'wphave_internal_post_type_cache_can_write' ) && wphave_internal_post_type_cache_can_write() );

			if( ! $name || ( wphave_is_block_editor() && ! $admin_cache ) ) {
				// Stop if the name is not yet defined, that avoids adding transients with missing post ID
				// ! Notice: Do not cache the query for admin post edit page
				return false;
			}

			// Get the passed post type
			if( $post_type && function_exists( 'wphave_prevent_nested_cache_by_post_type' ) && wphave_prevent_nested_cache_by_post_type( $post_type ) ) {
				// We use a custom post type to provide side wide features, which are totally cached. So we don't need to cache single blocks with own queries.
				// To prevent the caching of single block queries, we define a list of custom post types with no nested caching.
				return false;
			}

			// Get transient name
			$transient_name = self::transient_name( $name );

				// Save nested transient
				if( $transient_key ) {
					$stored_data = get_transient( $transient_name );

					// Cache hits are read-only and never need the mutation lock.
					// The locked callback checks again after a miss so concurrent
					// creators still cannot overwrite sibling cache entries.
					if( is_array( $stored_data ) && array_key_exists( $transient_key, $stored_data ) ) {
						return $stored_data;
					}

					if( ! $can_write_cache ) return $query_data;

					$data = self::mutate_nested_transient( $transient_name, function( $stored_data ) use ( $query_data, $transient_key ) {
						if( array_key_exists( $transient_key, $stored_data ) ) {
							return $stored_data;
						}

						$stored_data[$transient_key] = $query_data;
						return $stored_data;
					}, $expiration_time );

			// Save default transient
			} else {

				// Transient does not exist, so get the WP Query data save it as transient
				if( false === ( $data = get_transient( $transient_name ) ) ) {

					if( ! $can_write_cache ) {
						return $query_data;
					}

					$data = $query_data;

					// Do not set empty transient
					if( ! empty( $data ) ) {
						// Cache data and save as transient
						set_transient( $transient_name, $data, $expiration_time );
					}

				}

			}

			if( $data ) {
				return $data;
			}

				return false;

			}

			/**
			 * Serialize mutations of a shared transient collection.
			 *
			 * @param string $transient_name Full transient name.
			 * @param callable $mutation Mutation receiving the current array.
			 * @param int $expiration Expiration in seconds.
			 * @return array Resulting collection.
			 */

			public static function mutate_nested_transient( string $transient_name, callable $mutation, int $expiration = self::DEFAULT_EXPIRATION ): array {
				global $wpdb;

				$lock_name = 'wphave_qt_' . md5( $transient_name );
				$acquired = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 2)', $lock_name ) );
				if( $acquired !== 1 ) {
					return [];
				}

				try {
					$current = get_transient( $transient_name );
					$current = is_array( $current ) ? $current : [];
					$next = $mutation( $current );
					if( ! is_array( $next ) ) return $current;
					if( $next === $current ) return $current;

					if( empty( $next ) ) {
						delete_transient( $transient_name );
					} else {
						set_transient( $transient_name, $next, $expiration );
					}

					return $next;
				} finally {
					$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock_name ) );
				}
			}

			public static function delete_nested_transient_key( string $transient_name, string $key, int $expiration = self::DEFAULT_EXPIRATION ): void {
				self::mutate_nested_transient( $transient_name, function( $current ) use ( $key ) {
					unset( $current[$key] );
					return $current;
				}, $expiration );
			}

		/**
		 * Read query data from a WPHAVE query transient.
		 *
		 * The same admin rules as save() are applied. This avoids using frontend
		 * query caches inside editor/admin screens unless explicitly allowed.
		 *
		 * @param string $name Cache name without the WPHAVE query cache prefix.
		 * @param array $args Optional cache arguments.
		 * @return mixed Cached data, or false when missing/skipped.
		 */

		public static function get( $name, $args = '' ) {

			$args = is_array( $args ) ? $args : array();

			$admin_cache = isset( $args['admin_cache'] ) ? $args['admin_cache'] : '';
			$block_editor_cache = isset( $args['block_editor_cache'] ) ? $args['block_editor_cache'] : '';
			$transient_key = isset( $args['key'] ) ? $args['key'] : '';

			$admin_cache = ( $admin_cache ?: $block_editor_cache );

			/**
			 * WPHAVE all post ids init.
			 */

			// Check if we are currently in the block editor screen
			$is_block_editor = ( wphave_is_block_editor() || is_admin() );

			/**
			 * WPHAVE all post ids init.
			 */

			if( ! $name || ( $is_block_editor && ! $admin_cache ) ) {
				// Stop here, if the name is not yet defined, that avoids adding transients with missing post ID
				// ! Notice: Do not cache the query for admin post edit page
				return false;
			}

			/**
			 * WPHAVE all post ids init.
			 */

			// Get transient name
			$transient_name = self::transient_name( $name );

			// Get nested transient
			if( $transient_key ) {

				$transient_parent = get_transient( $transient_name );

				// An empty array is a valid cached result for feature post types
				// without published entries. Only a missing key is a cache miss.
				if( is_array( $transient_parent ) && array_key_exists( $transient_key, $transient_parent ) ) {
					return $transient_parent[$transient_key];
				}

			// Get default transient
			} else {

				$data = get_transient( $transient_name );

				if( ! empty( $data ) ) {
					return $data;
				}

			}

			// Data is not cached, get WP Query data directly
			return false;

		}

	}

endif;

if( ! function_exists( 'wphave_all_post_ids_init' ) ) :

	function wphave_all_post_ids_init( $args = '' ) {

		return WPHAVE_Query_Transient_Cache::all_post_ids( $args );

	}

endif;

if( ! function_exists( 'wphave_all_post_ids' ) ) :

	/**
	 * All post IDs.
	 *
	 * @param array $args Function arguments.
	 */

	function wphave_all_post_ids( $args = array() ) {

		return WPHAVE_Query_Transient_Cache::all_post_ids( $args );

	}

endif;

if( ! function_exists( 'wphave_wp_query_cache_transient' ) ) :

	/**
	 * Wp query cache transient.
	 *
	 * @param string $name Name.
	 */

	function wphave_wp_query_cache_transient( $name ) {

		return WPHAVE_Query_Transient_Cache::transient_name( $name );

	}

endif;

if( ! function_exists( 'wphave_save_query' ) ) :

	/**
	 * Save query.
	 *
	 * @param mixed $query_data Query data.
	 * @param string $name Name.
	 * @param array $args Function arguments.
	 */

	function wphave_save_query( $query_data, $name, $args = '' ) {

		return WPHAVE_Query_Transient_Cache::save( $query_data, $name, $args );

	}

endif;

if( ! function_exists( 'wphave_has_cached_data' ) ) :

	/**
	 * Has cached data.
	 *
	 * @param string $name Name.
	 * @param array $args Function arguments.
	 */

	function wphave_has_cached_data( $name, $args = '' ) {

		return WPHAVE_Query_Transient_Cache::get( $name, $args );

	}

endif;
