<?php

/** Optimization entitlement boundary shared by request and worker runtimes. */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

if( ! function_exists( 'wphave_optimization_has_pro_access' ) ) {

	/**
	 * Determine whether Optimization Pro features may run on this installation.
	 *
	 * @return bool Whether a valid Pro entitlement is available.
	 */

	function wphave_optimization_has_pro_access() {
		return function_exists( 'wphave_has_pro_access' ) && wphave_has_pro_access();
	}
}
