<?php

/**
 * Shared CSS processing utilities for generated WPHAVE assets.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Minify generated CSS while preserving quoted values and unit-sensitive zeros.
 *
 * @param string $css Stylesheet content.
 * @return string Minified stylesheet content.
 */

if ( ! function_exists( 'wphave_minify_css' ) ) :

	function wphave_minify_css( $css ) {

		// Remove comments
		$css = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $css);

		// Backup values within single or double quotes
		preg_match_all('/(\'[^\']*?\'|"[^"]*?")/ims', $css, $hit, PREG_PATTERN_ORDER);
		for( $i=0; $i < count($hit[1]); $i++ ) {
			$css = wphave_replace($hit[1][$i], '##########' . $i . '##########', $css);
		}

		// Remove traling semicolon of selector's last property
		$css = preg_replace('/;[\s\r\n\t]*?}[\s\r\n\t]*/ims', "}\r\n", $css);

		// Remove any whitespace between semicolon and property-name
		$css = preg_replace('/;[\s\r\n\t]*?([\r\n]?[^\s\r\n\t])/ims', ';$1', $css);

		// Remove any whitespace surrounding property-colon
		$css = preg_replace('/[\s\r\n\t]*:[\s\r\n\t]*?([^\s\r\n\t])/ims', ':$1', $css);

		// Remove any whitespace surrounding selector-comma
		$css = preg_replace('/[\s\r\n\t]*,[\s\r\n\t]*?([^\s\r\n\t])/ims', ',$1', $css);

		// Remove any whitespace surrounding opening parenthesis
		$css = preg_replace('/[\s\r\n\t]*{[\s\r\n\t]*?([^\s\r\n\t])/ims', '{$1', $css);

		// Remove any whitespace between numbers and units
		$css = preg_replace('/([\d\.]+)[\s\r\n\t]+(px|em|pt|%)/ims', '$1$2', $css);

		// Shorten zero-values
        /*
        * !!! IMPORTANT: Do not shorten zero-values at all.
        * This breaks css calc() because '0' without a 'unit' can't be calculated!
        * !!! IMPORTANT: Do not shorten zero-values with percentage "0%".
        * This would break specific cases like:
        * "@keyframes animationName { 0% {...} }" --> The "%" suffix for step 0 is required !
        * "hsl(0, 0%, 100%) or hsla(0, 0%, 100%, 1)" --> The "%" suffix for value 2 and 3 is required !
        */

        //$css = preg_replace('/([^\d\.]0)(px|em|pt|in|cm|mm|pc|ex|ch|rem|vw|vh|dvw|dvh)/ims', '$1', $css);

		// Constrain multiple whitespaces
		$css = preg_replace('/\p{Zs}+/ims',' ', $css);

		// Remove newlines
		$css = wphave_replace(array("\r\n", "\r", "\n"), '', $css);

		// Remove a tab
		$css = wphave_replace("\t", " ", $css);

		// Restore backupped values within single or double quotes
		for( $i=0; $i < count($hit[1]); $i++ ) {
			$css = wphave_replace('##########' . $i . '##########', $hit[1][$i], $css);
		}

		// Merge multiple whitespaces to only one whitespace
		$css = preg_replace('/\s+/', ' ', $css);

  		return $css;

	}

endif;
