<?php

/**
 * Bootstrap frontend optimization services in their established load order.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/access.php';

/**
 * Prevent direct option writes from changing Pro-only optimization settings.
 *
 * The interface is not a security boundary. Restoring the stored values here
 * also protects writes made through the shared settings REST resource.
 *
 * @param mixed $value Updated WPHAVE data.
 * @param mixed $old_value Previously stored WPHAVE data.
 * @return mixed Entitlement-safe WPHAVE data.
 */

function wphave_restrict_optimization_settings( $value, $old_value ) {
	if( wphave_optimization_has_pro_access() || ! is_array( $value ) || ! is_array( $old_value ) ) return $value;

	$new_settings = $value['wphave_settings']['advanced']['performance'] ?? null;
	$old_settings = $old_value['wphave_settings']['advanced']['performance'] ?? null;

	if( ! is_array( $new_settings ) ) return $value;

	if( is_array( $old_settings ) ) {
		$value['wphave_settings']['advanced']['performance'] = $old_settings;
	} else {
		unset( $value['wphave_settings']['advanced']['performance'] );
	}

	return $value;
}

add_filter( 'pre_update_option_wphave_data', 'wphave_restrict_optimization_settings', 9, 2 );

require_once __DIR__ . '/css.php';
require_once __DIR__ . '/output-buffer.php';
require_once __DIR__ . '/request-memoization.php';
require_once __DIR__ . '/static-page-cache/cache.php';
require_once __DIR__ . '/post-cache.php';
require_once __DIR__ . '/transients/query-cache.php';
require_once __DIR__ . '/redirects/manager.php';
require_once __DIR__ . '/redirects/404-monitor.php';
require_once __DIR__ . '/compress-html.php';
require_once __DIR__ . '/post-types.php';
require_once __DIR__ . '/image-loading.php';
require_once __DIR__ . '/speculative-loading.php';
