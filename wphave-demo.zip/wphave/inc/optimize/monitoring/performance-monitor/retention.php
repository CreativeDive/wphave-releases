<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Bounded background retention for ephemeral continuous-monitor events. */
final class WPHAVE_Performance_Monitor_Retention {

	public const CLEANUP_HOOK = 'wphave_performance_monitor_cleanup';
	public const SCHEDULE_OPTION = 'wphave_performance_monitor_cleanup_schedule';
	public const LAST_CLEANUP_OPTION = 'wphave_performance_monitor_last_cleanup';

	private const RETAIN_PER_KIND = 200;
	private const DELETE_BATCH_SIZE = 500;
	private const MAX_BATCHES_PER_KIND = 4;
	private static bool $schedule_registered = false;
	private static bool $worker_registered = false;

	/** Register lightweight recurring-event reconciliation once per request. */
	public static function register_schedule(): void {
		if ( self::$schedule_registered ) {
			return;
		}

		self::$schedule_registered = true;
		add_action( 'wp_loaded', array( __CLASS__, 'sync_schedule' ) );
	}

	/** Register the destructive retention callback only in worker contexts. */
	public static function register_worker(): void {
		if ( self::$worker_registered ) {
			return;
		}

		self::$worker_registered = true;
		add_action( self::CLEANUP_HOOK, array( __CLASS__, 'run_scheduled_cleanup' ) );
	}

	public static function run_scheduled_cleanup(): void {
		self::run_guarded_cleanup();
	}

	/** Run eventual cleanup from an authorized monitor read when cron is delayed. */
	public static function maybe_cleanup(): void {
		if( 'table' !== WPHAVE_Performance_Monitor_Storage_Selector::active_storage() ) {
			return;
		}

		self::run_guarded_cleanup();
	}

	/**
	 * Recheck and execute retention under one cross-request boundary.
	 *
	 * CONCURRENCY INVARIANT: The due check lives inside the same lock as pruning
	 * and timestamp publication. Requests queued behind a completed cleanup must
	 * observe its timestamp and skip duplicate database work.
	 *
	 * @return array|null Cleanup result, or null when another run made it unnecessary.
	 */
	private static function run_guarded_cleanup(): ?array {
		$result = WPHAVE_Option_Mutations::with_lock( self::LAST_CLEANUP_OPTION, static function() {
			$last_cleanup = (int) get_option( self::LAST_CLEANUP_OPTION, 0 );

			if( $last_cleanup > time() - HOUR_IN_SECONDS ) {
				return null;
			}

			$cleanup = self::cleanup();
			if( ! $cleanup['failed'] ) {
				update_option( self::LAST_CLEANUP_OPTION, time(), false );
			}

			return $cleanup;
		} );

		return is_wp_error( $result ) ? null : $result;
	}

	public static function sync_schedule(): bool {
		$enabled =
			WPHAVE_Performance_Monitor_Schema::validate() &&
			function_exists('wphave_performance_monitor_feature_enabled') &&
			wphave_performance_monitor_feature_enabled();

		return WPHAVE_Background_Job_Scheduler::sync_recurring(
			self::CLEANUP_HOOK,
			self::SCHEDULE_OPTION,
			$enabled,
			'hourly',
			time() + HOUR_IN_SECONDS,
			'v1'
		);
	}

	/**
	 * Prune bounded batches while preserving independent request/client windows.
	 *
	 * @return array{request:int,client:int,failed:bool} Deleted rows and failure state.
	 */
	public static function cleanup(): array {
		$request_deleted = self::prune_kind( 'request' );
		$client_deleted = self::prune_kind( 'client' );

		return array(
			'request' => max( 0, (int) $request_deleted ),
			'client' => max( 0, (int) $client_deleted ),
			'failed' => null === $request_deleted || null === $client_deleted,
		);
	}

	/** Return deleted rows, or null when the database state is unknown. */
	private static function prune_kind( string $kind ): ?int {
		global $wpdb;

		$table = $wpdb->prefix . WPHAVE_Performance_Monitor_Schema::TABLE;
		$deleted = 0;

		for( $batch = 0; $batch < self::MAX_BATCHES_PER_KIND; $batch++ ) {
			$wpdb->last_error = '';
			$threshold_id = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT id FROM {$table} WHERE event_kind = %s ORDER BY id DESC LIMIT 1 OFFSET %d",
					$kind,
					self::RETAIN_PER_KIND - 1
				)
			);

			/*
			 * RESILIENCE INVARIANT: An empty candidate set is a successful no-op;
			 * a failed read leaves retention state unknown and must remain retryable.
			 */
			if( $wpdb->last_error ) {
				return null;
			}

			if( ! $threshold_id ) {
				break;
			}

			$result = $wpdb->query(
				$wpdb->prepare(
					"DELETE FROM {$table} WHERE event_kind = %s AND id < %d LIMIT %d",
					$kind,
					(int) $threshold_id,
					self::DELETE_BATCH_SIZE
				)
			);

			if( false === $result ) {
				return null;
			}

			if( 0 === $result ) {
				break;
			}

			$deleted += (int) $result;

			if( $result < self::DELETE_BATCH_SIZE ) {
				break;
			}
		}

		return $deleted;
	}
}
