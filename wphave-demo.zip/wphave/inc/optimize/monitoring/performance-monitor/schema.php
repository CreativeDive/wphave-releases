<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Owns the append-only continuous-monitor table contract. */
final class WPHAVE_Performance_Monitor_Schema {

	public const DB_VERSION = '1.0.0';
	public const VERSION_OPTION = 'wphave_performance_monitor_db_version';
	public const TABLE = 'wphave_monitor_events';

	/** Create or reconcile the event table through the shared schema manager. */
	public static function install(): void {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table = $wpdb->prefix . self::TABLE;
		$charset = $wpdb->get_charset_collate();
		$sql = "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			event_uuid char(36) NOT NULL,
			recorded_at datetime NOT NULL,
			recorded_at_ms bigint(20) unsigned NOT NULL DEFAULT 0,
			event_kind varchar(20) NOT NULL,
			event_type varchar(50) NOT NULL DEFAULT '',
			navigation_id varchar(80) NOT NULL DEFAULT '',
			source varchar(20) NOT NULL DEFAULT '',
			screen varchar(100) NOT NULL DEFAULT '',
			label varchar(240) NOT NULL DEFAULT '',
			method varchar(12) NOT NULL DEFAULT '',
			status smallint(5) unsigned NOT NULL DEFAULT 0,
			duration_ms decimal(12,2) unsigned NOT NULL DEFAULT 0,
			memory_peak_bytes bigint(20) unsigned NOT NULL DEFAULT 0,
			query_count int(10) unsigned NOT NULL DEFAULT 0,
			payload longtext DEFAULT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY event_uuid (event_uuid),
			KEY event_kind_id (event_kind,id),
			KEY navigation_id (navigation_id,id),
			KEY recorded_at (recorded_at,id)
		) {$charset};";

		dbDelta( $sql );
		WPHAVE_Database_Metadata::invalidate( $table );
	}

	/** Verify the table structure required by the monitor store. */
	public static function validate(): bool {
		global $wpdb;

		$table = $wpdb->prefix . self::TABLE;
		if ( ! WPHAVE_Database_Metadata::table_exists( $table ) ) {
			return false;
		}

		$required = array(
			'id',
			'event_uuid',
			'recorded_at',
			'recorded_at_ms',
			'event_kind',
			'event_type',
			'navigation_id',
			'source',
			'screen',
			'label',
			'method',
			'status',
			'duration_ms',
			'memory_peak_bytes',
			'query_count',
			'payload',
		);

		$columns = WPHAVE_Database_Metadata::column_names( $table );

		return array_diff( $required, $columns ) === array();
	}
}
