<?php

/** Bootstrap Performance Monitor retention execution. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * WORKER INVARIANT: Retention needs schema selection and atomic option locks,
 * but never legacy history, cutover writers or repository instrumentation.
 */
require_once __DIR__ . '/runtime.php';
WPHAVE_Performance_Monitor_Runtime::load_worker();

if ( WPHAVE_Database_Schema_Manager::runtime_compatible( 'performance_monitor' ) ) {
	WPHAVE_Performance_Monitor_Retention::register_schedule();
	WPHAVE_Performance_Monitor_Retention::register_worker();
}
