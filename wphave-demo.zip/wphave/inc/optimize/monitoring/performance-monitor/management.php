<?php

/** Bootstrap Performance Monitor storage and schedule reconciliation. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/bootstrap.php';

if ( WPHAVE_Database_Schema_Manager::runtime_compatible( 'performance_monitor' ) ) {
	WPHAVE_Performance_Monitor_Retention::register_schedule();
}
