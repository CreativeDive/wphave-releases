<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Append-only table repository for the monitor store. */
final class WPHAVE_Performance_Monitor_Table_Repository implements WPHAVE_Performance_Monitor_Event_Repository, WPHAVE_Performance_Monitor_Cursor_Repository {

	private const HISTORY_LIMIT = 160;
	private const MAX_BATCH_EVENTS = 20;
	private const MAX_PAYLOAD_BYTES = 65535;
	private ?int $read_cursor = null;

	public function append( array $event, ?callable $authorize = null ) {
		return $this->append_many( array( $event ), $authorize );
	}

	public function append_many(array $events, ?callable $authorize = null) {
		global $wpdb;

		$rows = [];
		foreach (array_slice($events, 0, self::MAX_BATCH_EVENTS) as $event) {
			$row = $this->event_to_row($event);
			if (!empty($row)) {
				$rows[] = $row;
			}
		}

		if (empty($rows)) {
			return 0;
		}

		$placeholders = [];
		$values = [];
		foreach ($rows as $row) {
			$placeholders[] = '(%s,%s,%d,%s,%s,%s,%s,%s,%s,%s,%d,%f,%d,%d,%s)';
			array_push($values, ...array_values($row));
		}

		$sql =
			'INSERT INTO ' .
			$this->table_name() .
			' ' .
			'(event_uuid,recorded_at,recorded_at_ms,event_kind,event_type,navigation_id,source,screen,label,method,status,duration_ms,memory_peak_bytes,query_count,payload) VALUES ' .
			implode(',', $placeholders) .
			' ON DUPLICATE KEY UPDATE event_uuid = event_uuid';

		// AUTHORIZATION/PERFORMANCE-MONITOR-APPEND-COMMIT INVARIANT: The
		// final policy runs after normalization and immediately before the insert.
		if ($authorize) {
			$authorization = call_user_func($authorize);
			if (is_wp_error($authorization) || !$authorization) {
				return is_wp_error($authorization)
					? $authorization
					: new WP_Error('wphave_performance_monitor_forbidden');
			}
		}

		/*
		 * DATA-INTEGRITY INVARIANT: Collector retries are idempotent per UUID.
		 * A duplicate keeps its first accepted payload while unrelated new rows in
		 * the same batch must still commit. Other SQL failures remain visible.
		 */
		$result = $wpdb->query($wpdb->prepare($sql, $values));

		if (false === $result) {
			return new WP_Error(
				'wphave_performance_monitor_event_write_failed',
				__('The performance event could not be stored.', 'wphave'),
				['status' => 500]
			);
		}

		return (int) $result;
	}

	public function history(): array {
		global $wpdb;

		$wpdb->last_error = '';
		$requests = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM ' . $this->table_name() . ' WHERE event_kind = %s ORDER BY id DESC LIMIT %d',
				'request',
				self::HISTORY_LIMIT
			),
			ARRAY_A
		);
		$this->assert_read_succeeded();

		$wpdb->last_error = '';
		$clients = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM ' . $this->table_name() . ' WHERE event_kind = %s ORDER BY id DESC LIMIT %d',
				'client',
				self::HISTORY_LIMIT
			),
			ARRAY_A
		);
		$this->assert_read_succeeded();
		$rows = array_merge( $requests ?: array(), $clients ?: array() );

		usort( $rows, static fn( $left, $right ) => (int) $left['id'] <=> (int) $right['id'] );

		return array_values( array_map( array( $this, 'row_to_event' ), $rows ) );
	}

	public function changes_after( int $cursor ): array {
		global $wpdb;

		$wpdb->last_error = '';
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM ' . $this->table_name() . ' WHERE id > %d ORDER BY id ASC LIMIT %d',
				max( 0, $cursor ),
				2 * self::HISTORY_LIMIT
			),
			ARRAY_A
		);
		$this->assert_read_succeeded();
		$rows = $rows ?: array();
		$this->read_cursor = ! empty( $rows )
			? (int) end( $rows )['id']
			: max( 0, $cursor );

		return array_values( array_map( array( $this, 'row_to_event' ), $rows ) );
	}

	public function latest_cursor(): int {
		global $wpdb;

		if( null !== $this->read_cursor ) {
			return $this->read_cursor;
		}

		$wpdb->last_error = '';
		$cursor = $wpdb->get_var( 'SELECT MAX(id) FROM ' . $this->table_name() );
		$this->assert_read_succeeded();

		return (int) $cursor;
	}

	public function clear(?callable $authorize = null) {
		global $wpdb;

		// AUTHORIZATION/PERFORMANCE-MONITOR-CLEAR-COMMIT INVARIANT: The
		// current caller must still own deletion before any stored event is removed.
		if ($authorize) {
			$authorization = call_user_func($authorize);
			if (is_wp_error($authorization) || !$authorization) {
				return is_wp_error($authorization)
					? $authorization
					: new WP_Error('wphave_performance_monitor_forbidden');
			}
		}

		$result = $wpdb->query('DELETE FROM ' . $this->table_name());
		$this->read_cursor = 0;

		return false === $result
			? new WP_Error(
				'wphave_performance_monitor_clear_failed',
				__('The performance history could not be cleared.', 'wphave'),
				['status' => 500]
			)
			: true;
	}

	private function event_to_row( array $event ): array {
		$event = WPHAVE_Monitoring_Event_Normalizer::normalize( $event );
		if ( empty( $event ) ) {
			return array();
		}

		$timestamp = $this->timestamp( $event['timestamp'] ?? '' );
		$payload = array(
			'url' => (string) ( $event['url'] ?? '' ),
			'slowQueries' => is_array( $event['slowQueries'] ?? null ) ? $event['slowQueries'] : array(),
			'queryProfile' => is_array( $event['queryProfile'] ?? null ) ? $event['queryProfile'] : array(),
			'metadata' => is_array( $event['metadata'] ?? null ) ? $event['metadata'] : array(),
		);

		return array(
			'event_uuid' => sanitize_text_field( (string) ( $event['id'] ?? wp_generate_uuid4() ) ),
			'recorded_at' => gmdate( 'Y-m-d H:i:s', (int) floor( $timestamp / 1000 ) ),
			'recorded_at_ms' => $timestamp,
			'event_kind' => ( $event['type'] ?? '' ) === 'request' ? 'request' : 'client',
			'event_type' => sanitize_key( (string) ( $event['eventType'] ?? '' ) ),
			'navigation_id' => sanitize_text_field( (string) ( $event['navigationId'] ?? '' ) ),
			'source' => sanitize_key( (string) ( $event['source'] ?? '' ) ),
			'screen' => sanitize_key( (string) ( $event['screen'] ?? '' ) ),
			'label' => WPHAVE_Security_Normalizer::diagnostic_text( $event['label'] ?? '', 240 ),
			'method' => substr( strtoupper( sanitize_text_field( (string) ( $event['method'] ?? '' ) ) ), 0, 12 ),
			'status' => max( 0, min( 65535, (int) ( $event['status'] ?? 0 ) ) ),
			'duration_ms' => max( 0, round( (float) ( $event['durationMs'] ?? 0 ), 2 ) ),
			'memory_peak_bytes' => max( 0, (int) ( $event['memoryPeakBytes'] ?? 0 ) ),
			'query_count' => max( 0, (int) ( $event['queryCount'] ?? 0 ) ),
			'payload' => $this->encode_payload( $payload ),
		);
	}

	private function row_to_event( array $row ): array {
		$payload = json_decode( (string) ( $row['payload'] ?? '' ), true );
		$payload = is_array( $payload ) ? $payload : array();
		$milliseconds = max( 0, (int) ( $row['recorded_at_ms'] ?? 0 ) );

		$event = array(
			'id' => (string) ( $row['event_uuid'] ?? '' ),
			'type' => ( $row['event_kind'] ?? '' ) === 'request' ? 'request' : 'client',
			'eventType' => (string) ( $row['event_type'] ?? '' ),
			'navigationId' => (string) ( $row['navigation_id'] ?? '' ),
			'source' => (string) ( $row['source'] ?? '' ),
			'label' => (string) ( $row['label'] ?? '' ),
			'screen' => (string) ( $row['screen'] ?? '' ),
			'url' => (string) ( $payload['url'] ?? '' ),
			'method' => (string) ( $row['method'] ?? '' ),
			'status' => (int) ( $row['status'] ?? 0 ),
			'timestamp' => $this->iso_timestamp( $milliseconds ),
			'durationMs' => (float) ( $row['duration_ms'] ?? 0 ),
			'memoryPeakBytes' => (int) ( $row['memory_peak_bytes'] ?? 0 ),
			'queryCount' => (int) ( $row['query_count'] ?? 0 ),
			'slowQueries' => is_array( $payload['slowQueries'] ?? null ) ? $payload['slowQueries'] : array(),
			'queryProfile' => is_array( $payload['queryProfile'] ?? null ) ? $payload['queryProfile'] : array(),
			'metadata' => is_array( $payload['metadata'] ?? null ) ? $payload['metadata'] : array(),
		);

		return WPHAVE_Monitoring_Event_Normalizer::normalize( $event );
	}

	private function encode_payload( array $payload ): string {
		$json = wp_json_encode( $payload );
		if ( is_string( $json ) && strlen( $json ) <= self::MAX_PAYLOAD_BYTES ) {
			return $json;
		}

		$payload['queryProfile'] = array();
		$payload['slowQueries'] = array();
		$payload['metadata'] = array( 'payloadTruncated' => true );
		$json = wp_json_encode( $payload );

		return is_string( $json ) ? substr( $json, 0, self::MAX_PAYLOAD_BYTES ) : '{}';
	}

	private function timestamp( $timestamp ): int {
		try {
			$date = new DateTimeImmutable( sanitize_text_field( (string) $timestamp ) );
			return (int) $date->format( 'Uv' );
		} catch ( Exception $exception ) {
			return (int) floor( microtime( true ) * 1000 );
		}
	}

	private function iso_timestamp( int $milliseconds ): string {
		$seconds = (int) floor( $milliseconds / 1000 );
		$remainder = $milliseconds % 1000;

		return gmdate( 'Y-m-d\TH:i:s', $seconds ) . sprintf( '.%03dZ', $remainder );
	}

	private function table_name(): string {
		global $wpdb;

		return $wpdb->prefix . WPHAVE_Performance_Monitor_Schema::TABLE;
	}

	/**
	 * Keep storage outages distinct from legitimate empty result sets.
	 *
	 * RESILIENCE INVARIANT: A failed cursor read may never advance or confirm the
	 * caller's cursor. The REST boundary converts this internal exception into a
	 * retryable response without exposing database details.
	 */
	private function assert_read_succeeded(): void {
		global $wpdb;

		if ( $wpdb->last_error ) {
			throw new RuntimeException( 'Performance monitor storage read failed.' );
		}
	}
}
