<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Compose Performance Monitor storage capabilities monotonically by context. */
final class WPHAVE_Performance_Monitor_Runtime {

	private static bool $worker_loaded = false;
	private static bool $storage_loaded = false;

	/** Load the complete repository runtime used by interactive storage. */
	public static function load(): void {
		self::load_worker();
		if (self::$storage_loaded) {
			return;
		}

		self::$storage_loaded = true;
		require_once wphave_dir() . 'inc/optimize/monitoring/event-normalizer.php';
		require_once __DIR__ . '/event-repository.php';
		require_once __DIR__ . '/table-repository.php';
		require_once __DIR__ . '/instrumented-repository.php';
	}

	/** Load only schema selection and retention required by Cron. */
	public static function load_worker(): void {
		if ( self::$worker_loaded ) {
			return;
		}

		self::$worker_loaded = true;
		require_once wphave_dir() . 'inc/data/options/mutations.php';
		require_once __DIR__ . '/schema.php';
		require_once __DIR__ . '/storage-selector.php';
		require_once __DIR__ . '/retention.php';

		WPHAVE_Database_Schema_Manager::register(
			array(
				'id' => 'performance_monitor',
				'label' => 'Performance monitor events',
				'version' => WPHAVE_Performance_Monitor_Schema::DB_VERSION,
				'option' => WPHAVE_Performance_Monitor_Schema::VERSION_OPTION,
				'tables' => array( WPHAVE_Performance_Monitor_Schema::TABLE ),
				'callback' => array( 'WPHAVE_Performance_Monitor_Schema', 'install' ),
				'validator' => array( 'WPHAVE_Performance_Monitor_Schema', 'validate' ),
			)
		);
	}
}
