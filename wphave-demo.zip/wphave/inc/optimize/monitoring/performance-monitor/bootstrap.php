<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/runtime.php';
WPHAVE_Performance_Monitor_Runtime::load();
