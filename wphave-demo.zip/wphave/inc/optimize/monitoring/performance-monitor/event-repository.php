<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Persistence boundary for bounded continuous-monitor events. */
interface WPHAVE_Performance_Monitor_Event_Repository {

	/** Append one already prepared event. */
	public function append( array $event, ?callable $authorize = null );

	/** Append a bounded collection and return the accepted count or WP_Error. */
	public function append_many( array $events, ?callable $authorize = null );

	/** Return the bounded request/client history in chronological order. */
	public function history(): array;

	/** Clear only continuous-monitor history after an optional final commit guard. */
	public function clear( ?callable $authorize = null );
}

/** Optional cursor reads supported by append-only monitor repositories. */
interface WPHAVE_Performance_Monitor_Cursor_Repository {

	/** Return normalized events inserted after the opaque numeric cursor. */
	public function changes_after( int $cursor ): array;

	/** Return the latest insertion cursor without loading event payloads. */
	public function latest_cursor(): int;
}
