<?php
if (!defined('ABSPATH')) {
	exit();
}
/** Resolve the platform's single monitor store after schema validation. */
final class WPHAVE_Performance_Monitor_Storage_Selector {
	public static function active_storage(): string {
		return WPHAVE_Performance_Monitor_Schema::validate() ? 'table' : 'unavailable';
	}
	public static function repository(): WPHAVE_Performance_Monitor_Event_Repository {
		// STORAGE INVARIANT: Missing or invalid tables fail closed; reads and writes never switch to options.
		if ('table' !== self::active_storage()) {
			throw new RuntimeException(
				'The performance monitor schema requires an explicit update.'
			);
		}
		return new WPHAVE_Performance_Monitor_Instrumented_Repository(
			new WPHAVE_Performance_Monitor_Table_Repository()
		);
	}
}
