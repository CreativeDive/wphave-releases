<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Emits opt-in, request-local timing signals around monitor storage operations. */
final class WPHAVE_Performance_Monitor_Instrumented_Repository implements WPHAVE_Performance_Monitor_Event_Repository, WPHAVE_Performance_Monitor_Cursor_Repository {

	public const TIMING_HOOK = 'wphave/performance_monitor/storage_operation';

	private WPHAVE_Performance_Monitor_Event_Repository $repository;

	public function __construct( WPHAVE_Performance_Monitor_Event_Repository $repository ) {
		$this->repository = $repository;
	}

	public function append( array $event, ?callable $authorize = null ) {
		return $this->measure( 'append', fn() => $this->repository->append( $event, $authorize ) );
	}

	public function append_many( array $events, ?callable $authorize = null ) {
		return $this->measure( 'append_many', fn() => $this->repository->append_many( $events, $authorize ) );
	}

	public function history(): array {
		return $this->measure( 'history', fn() => $this->repository->history() );
	}

	public function clear( ?callable $authorize = null ) {
		return $this->measure( 'clear', fn() => $this->repository->clear( $authorize ) );
	}

	public function changes_after( int $cursor ): array {
		if( ! $this->supports_cursor() ) {
			return array();
		}

		return $this->measure( 'changes_after', fn() => $this->repository->changes_after( $cursor ) );
	}

	public function latest_cursor(): int {
		if( ! $this->supports_cursor() ) {
			return 0;
		}

		return $this->measure( 'latest_cursor', fn() => $this->repository->latest_cursor() );
	}

	public function supports_cursor(): bool {
		return $this->repository instanceof WPHAVE_Performance_Monitor_Cursor_Repository;
	}

	/**
	 * Measure only when a diagnostics consumer explicitly observes the hook.
	 *
	 * The signal is intentionally request-local. Persisting it here would create
	 * recursive telemetry and add a second write to the monitored operation.
	 *
	 * @param string   $operation Repository operation name.
	 * @param callable $callback Repository operation.
	 * @return mixed Repository result.
	 */
	private function measure( string $operation, callable $callback ) {
		if ( ! has_action( self::TIMING_HOOK ) ) {
			return $callback();
		}

		$started_at = hrtime( true );

		try {
			$result = $callback();
		} catch ( Throwable $error ) {
			$this->emit_timing( $operation, $started_at, false );
			throw $error;
		}

		$this->emit_timing( $operation, $started_at, ! is_wp_error( $result ) );

		return $result;
	}

	private function emit_timing(string $operation, int $started_at, bool $successful): void {
		do_action(self::TIMING_HOOK, [
			'operation' => $operation,
			'durationMs' => round((hrtime(true) - $started_at) / 1000000, 3),
			'successful' => $successful,
			'repository' => 'table'
		]);
	}
}
