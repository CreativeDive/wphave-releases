<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/event-normalizer.php';

if ( ! class_exists( 'WPHAVE_Performance_Monitor' ) ) :

	/**
	 * Collects lightweight app performance events for the internal monitor UI.
	 */

	class WPHAVE_Performance_Monitor {

		const MAX_EVENTS = 320;
		const MAX_REQUEST_EVENTS = 160;
		const MAX_CLIENT_EVENTS = 160;
		const MAX_CLIENT_BATCH_EVENTS = 20;
		const MAX_METADATA_DEPTH = 3;
		const MAX_METADATA_KEYS = 24;
		const SLOW_QUERY_MS = 50;
		const QUERY_PROFILE_MIN_QUERIES = 80;
		const QUERY_PROFILE_MIN_DURATION_MS = 800;

		private static $admin_screen = '';

		/**
		 * Register WordPress hooks used by the monitor.
		 */

		public static function init(): void {
			add_action( 'current_screen', [ __CLASS__, 'set_current_screen' ] );
			add_action( 'rest_api_init', [ __CLASS__, 'register_rest_routes' ] );
			add_action( 'shutdown', [ __CLASS__, 'record_shutdown_event' ], PHP_INT_MAX );
		}

		/**
		 * Check whether monitor recording and REST access are enabled.
		 */

		public static function is_feature_enabled(): bool {
			return function_exists( 'wphave_performance_monitor_feature_enabled' ) && wphave_performance_monitor_feature_enabled();
		}

		/**
		 * Store the current admin screen id for request attribution.
		 *
		 * @param WP_Screen|null $screen Current WordPress screen object.
		 */

		public static function set_current_screen( $screen ): void {
			if( is_object( $screen ) && ! empty( $screen->id ) ) {
				self::$admin_screen = sanitize_key( $screen->id );
			}
		}

		/**
		 * Register monitor read, write and clear REST routes.
		 */

		public static function register_rest_routes(): void {
			register_rest_route( 'wphave/v1', '/performance-monitor', [
				'methods' => WP_REST_Server::READABLE,
				'callback' => [ __CLASS__, 'get_monitor_endpoint' ],
				'permission_callback' => [ __CLASS__, 'can_view_monitor' ],
				'args' => [
					'afterId' => [
						'type' => 'integer',
						'minimum' => 0,
						'required' => false,
					],
				],
			] );

			register_rest_route( 'wphave/v1', '/performance-monitor/event', [
				'methods' => WP_REST_Server::CREATABLE,
				'callback' => [ __CLASS__, 'record_client_event_endpoint' ],
				'permission_callback' => [ __CLASS__, 'can_view_monitor' ],
				'args' => [
					'id' => [
						'type' => 'string',
						'format' => 'uuid',
						'required' => false,
					],
					'screen' => [
						'type' => 'string',
						'required' => false,
					],
					'eventType' => [
						'type' => 'string',
						'required' => false,
					],
					'navigationId' => [
						'type' => 'string',
						'required' => false,
					],
					'label' => [
						'type' => 'string',
						'required' => false,
					],
					'url' => [
						'type' => 'string',
						'required' => false,
					],
					'method' => [
						'type' => 'string',
						'required' => false,
					],
					'status' => [
						'type' => 'integer',
						'required' => false,
					],
					'durationMs' => [
						'type' => 'number',
						'required' => false,
					],
					'metadata' => [
						'type' => 'object',
						'required' => false,
					],
				],
			] );

			register_rest_route( 'wphave/v1', '/performance-monitor/clear', [
				'methods' => WP_REST_Server::CREATABLE,
				'callback' => [ __CLASS__, 'clear_events_endpoint' ],
				'permission_callback' => [ __CLASS__, 'can_view_monitor' ],
			] );
		}

		/**
		 * Check whether the current user may view and mutate monitor data.
		 */

		public static function can_view_monitor(): bool {
			return self::is_feature_enabled() && is_user_logged_in() && ( current_user_can( 'wphave_view_system_status' ) || current_user_can( 'manage_options' ) );
		}

		/**
		 * Require monitor authority at the final data boundary.
		 *
		 * AUTHORIZATION INVARIANT: REST permission callbacks are only an early
		 * dispatch gate. Every public monitor callback repeats the complete
		 * feature, authentication and capability policy before diagnostics are
		 * disclosed, appended or cleared.
		 *
		 * @return true|WP_Error
		 */

		private static function require_monitor_access() {
			if( ! self::can_view_monitor() ) {
				return new WP_Error(
					'wphave_performance_monitor_forbidden',
					__( 'You are not allowed to access the performance monitor.', 'wphave' ),
					array( 'status' => 403 )
				);
			}

			return true;
		}

		/**
		 * Return the current monitor history and aggregated summary.
		 */

		public static function get_monitor_endpoint( ?WP_REST_Request $request = null ): WP_REST_Response|WP_Error {
			$authorized = self::require_monitor_access();

			if( is_wp_error( $authorized ) ) {
				return $authorized;
			}

			WPHAVE_Performance_Monitor_Retention::maybe_cleanup();
			$repository = self::repository();
			$cursor_supported = $repository instanceof WPHAVE_Performance_Monitor_Instrumented_Repository
				&& $repository->supports_cursor();
			$is_delta = $cursor_supported && $request && $request->has_param( 'afterId' );

			try {
				$events = $is_delta
					? $repository->changes_after( max( 0, (int) $request->get_param( 'afterId' ) ) )
					: $repository->history();
				$summary_events = $is_delta && ! empty( $events )
					? $repository->history()
					: $events;
				$cursor = $cursor_supported ? $repository->latest_cursor() : 0;
			} catch( Throwable $error ) {
				// RESILIENCE INVARIANT: An unavailable store is not an empty delta.
				// Returning 503 keeps the client's last confirmed cursor retryable.
				return new WP_Error(
					'wphave_performance_monitor_storage_unavailable',
					__( 'The performance monitor history is temporarily unavailable.', 'wphave' ),
					array( 'status' => 503 )
				);
			}

			// AUTHORIZATION/PERFORMANCE-MONITOR-RESPONSE INVARIANT: Retention,
			// repository selection, history reads and summary projection cross
			// filterable storage and instrumentation boundaries. Revalidate the
			// complete monitor policy after projection and immediately before private
			// diagnostic history is released.
			$authorized = self::require_monitor_access();
			if ( is_wp_error( $authorized ) ) {
				return $authorized;
			}

			return rest_ensure_response( [
				'generatedAt' => self::current_timestamp(),
				'summary' => $is_delta && empty( $events )
					? null
					: self::build_summary( $summary_events ),
				'history' => array_values( $events ),
				'cursorSupported' => $cursor_supported,
				'cursor' => $cursor,
				'isDelta' => $is_delta,
				'queriesAvailable' => defined( 'SAVEQUERIES' ) && SAVEQUERIES,
				'limits' => [
					'maxEvents' => self::MAX_EVENTS,
					'maxRequestEvents' => self::MAX_REQUEST_EVENTS,
					'maxClientEvents' => self::MAX_CLIENT_EVENTS,
					'slowQueryMs' => self::SLOW_QUERY_MS,
				],
			] );
		}

		/**
		 * Record one or more client-side monitor events.
		 *
		 * @param WP_REST_Request $request REST request containing a single event or an events batch.
		 */

		public static function record_client_event_endpoint( WP_REST_Request $request ): WP_REST_Response|WP_Error {
			$authorized = self::require_monitor_access();

			if( is_wp_error( $authorized ) ) {
				return $authorized;
			}

			$events = $request->get_param( 'events' );

			if( is_array( $events ) && ! empty( $events ) ) {
				$prepared = [];

				foreach( array_slice( $events, 0, self::MAX_CLIENT_BATCH_EVENTS ) as $event ) {
					if( is_array( $event ) ) {
						$prepared[] = self::prepare_client_event( $event );
					}
				}

				// AUTHORIZATION/PERFORMANCE-MONITOR-EVENT-COMMIT INVARIANT: Client
				// event normalization invokes filterable WordPress sanitizers. Revalidate
				// the complete monitor policy after every bounded event is prepared and
				// immediately before the repository append begins.
				$authorized = self::require_monitor_access();
				if ( is_wp_error( $authorized ) ) {
					return $authorized;
				}

				$result = self::persist_events( $prepared, static function() {
					return self::require_monitor_access();
				} );
				if ( is_wp_error( $result ) && 'wphave_performance_monitor_forbidden' === $result->get_error_code() ) {
					return $result;
				}

				return rest_ensure_response( [
					'recorded' => is_wp_error( $result ) ? 0 : (int) $result,
					'storageAvailable' => ! is_wp_error( $result ),
				] );
			}

			$prepared = self::prepare_client_event( $request->get_params() );

			// The same event-commit invariant applies to the single-event contract.
			$authorized = self::require_monitor_access();
			if ( is_wp_error( $authorized ) ) {
				return $authorized;
			}

			$result = self::persist_events( [ $prepared ], static function() {
				return self::require_monitor_access();
			} );
			if ( is_wp_error( $result ) && 'wphave_performance_monitor_forbidden' === $result->get_error_code() ) {
				return $result;
			}

			return rest_ensure_response( [
				'recorded' => ! is_wp_error( $result ) && 1 === (int) $result,
				'storageAvailable' => ! is_wp_error( $result ),
			] );
		}

		/**
		 * Normalize a client-submitted event before it is persisted.
		 *
		 * @param array $data Raw event data from the REST request.
		 */

		private static function prepare_client_event( array $data ): array {
			$event_id = sanitize_text_field( (string) ( $data['id'] ?? '' ) );
			if( ! wp_is_uuid( $event_id, 4 ) ) {
				$event_id = wp_generate_uuid4();
			}
			$screen = sanitize_key( (string) ( $data['screen'] ?? '' ) );
			$event_type = sanitize_key( (string) ( $data['eventType'] ?? '' ) );
			$navigation_id = sanitize_text_field( (string) ( $data['navigationId'] ?? '' ) );
			$label = self::sanitize_event_text( (string) ( $data['label'] ?? '' ) );
			$url = self::sanitize_event_url( (string) ( $data['url'] ?? '' ) );
			$method = sanitize_text_field( (string) ( $data['method'] ?? '' ) );
			$status = (int) ( $data['status'] ?? 200 );
			$duration_ms = (float) ( $data['durationMs'] ?? 0 );
			$timestamp = self::normalize_timestamp( $data['timestamp'] ?? '' );
			$metadata = $data['metadata'] ?? [];

			if( ! is_array( $metadata ) ) {
				$metadata = [];
			}

			$metadata = self::sanitize_metadata( $metadata );

			return [
				// DATA-INTEGRITY INVARIANT: A validated client UUID survives transport
				// retries so the append-only repository can deduplicate the same event.
				'id' => strtolower( $event_id ),
				'type' => 'client',
				'eventType' => $event_type ? $event_type : 'screen',
				'navigationId' => $navigation_id,
				'source' => 'app',
				'label' => $label ? $label : ( $screen ? $screen : __( 'App event', 'wphave' ) ),
				'screen' => $screen,
				'url' => $url,
				'method' => $method ? strtoupper( $method ) : 'CLIENT',
				'status' => $status ?: 200,
				'timestamp' => $timestamp,
				'durationMs' => max( 0, round( $duration_ms, 2 ) ),
				'memoryPeakBytes' => memory_get_peak_usage( true ),
				'queryCount' => 0,
				'slowQueries' => [],
				'metadata' => $metadata,
			];
		}

		/**
		 * Clear the stored monitor history.
		 */

		public static function clear_events_endpoint() {
			$authorized = self::require_monitor_access();

			if( is_wp_error( $authorized ) ) {
				return $authorized;
			}

			$repository = self::repository();

			try {
				$result = $repository->clear( static function() {
					return self::require_monitor_access();
				} );
			} catch( Throwable $error ) {
				$result = new WP_Error(
					'wphave_performance_monitor_storage_failed',
					__( 'The performance monitor history could not be cleared.', 'wphave' ),
					[ 'status' => 503 ]
				);
			}

			if( is_wp_error( $result ) ) {
				return $result;
			}

			return rest_ensure_response( [
				'cleared' => true,
				'summary' => self::build_summary( [] ),
				'history' => [],
				'cursorSupported' => $repository instanceof WPHAVE_Performance_Monitor_Instrumented_Repository
					&& $repository->supports_cursor(),
				'cursor' => 0,
				'isDelta' => false,
			] );
		}

		/**
		 * Record timing, memory and query data for the current PHP request.
		 */

		public static function record_shutdown_event(): void {
			if( ! self::is_feature_enabled() ) {
				return;
			}

			if( ! self::should_record_current_request() ) {
				return;
			}

			global $wpdb;

			$start = isset( $_SERVER['REQUEST_TIME_FLOAT'] ) ? (float) $_SERVER['REQUEST_TIME_FLOAT'] : WPHAVE_START_TIME;
			$duration = max( 0, round( ( microtime( true ) - $start ) * 1000, 2 ) );
			$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? self::sanitize_event_url( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
			$method = isset( $_SERVER['REQUEST_METHOD'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) : '';
			$status = function_exists( 'http_response_code' ) ? (int) http_response_code() : 200;
			$query_count = isset( $wpdb->num_queries ) ? (int) $wpdb->num_queries : 0;
			$source = self::get_request_source();
			$label = self::get_request_label( $source, $request_uri );
			$screen = self::$admin_screen;

			if( ! $screen && isset( $_SERVER['HTTP_X_WPHAVE_SCREEN'] ) ) {
				$screen = sanitize_key( wp_unslash( $_SERVER['HTTP_X_WPHAVE_SCREEN'] ) );
			}

			$metadata = [];

			if( ! empty( $_SERVER['HTTP_X_WPHAVE_BACKGROUND'] ) ) {
				$metadata['background'] = true;
			}

			$event = [
				'id' => wp_generate_uuid4(),
				'type' => 'request',
				'source' => $source,
				'label' => $label,
				'screen' => $screen,
				'url' => $request_uri,
				'method' => $method,
				'status' => $status ?: 200,
				'timestamp' => self::current_timestamp(),
				'durationMs' => $duration,
				'memoryPeakBytes' => memory_get_peak_usage( true ),
				'queryCount' => $query_count,
				'slowQueries' => self::get_slow_queries(),
				'queryProfile' => self::get_query_profile( $query_count, $duration ),
				'metadata' => $metadata,
				'navigationId' => isset( $_SERVER['HTTP_X_WPHAVE_NAVIGATION_ID'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_WPHAVE_NAVIGATION_ID'] ) ) : '',
			];

			self::persist_events( [ $event ] );
		}

		/**
		 * Sanitize bounded client metadata recursively.
		 *
		 * @param array $metadata Raw metadata payload.
		 * @param int $depth Current recursion depth.
		 */

		private static function sanitize_metadata( array $metadata, int $depth = 0 ): array {
			if( $depth >= self::MAX_METADATA_DEPTH ) {
				return [];
			}

			$output = [];
			$count = 0;

			foreach( $metadata as $key => $value ) {
				if( $count >= self::MAX_METADATA_KEYS ) {
					break;
				}

				$clean_key = sanitize_key( (string) $key );

				if( $clean_key === '' ) {
					continue;
				}

				if( is_array( $value ) ) {
					$output[ $clean_key ] = self::sanitize_metadata( $value, $depth + 1 );
					$count++;
					continue;
				}

				if( is_bool( $value ) || is_numeric( $value ) ) {
					$output[ $clean_key ] = $value;
					$count++;
					continue;
				}

				$output[ $clean_key ] = $clean_key === 'path' ? self::sanitize_event_url( (string) $value ) : self::sanitize_event_text( (string) $value );
				$count++;
			}

			return $output;
		}

		/**
		 * Sanitize monitor text while preserving URL query separators like commas.
		 */

		private static function sanitize_event_text( string $value, int $max_length = 240 ): string {
			return WPHAVE_Security_Normalizer::diagnostic_text( $value, $max_length );
		}

		/**
		 * Sanitize a monitor URL or REST path without stripping encoded field lists.
		 */

		private static function sanitize_event_url( string $value, int $max_length = 500 ): string {
			return WPHAVE_Security_Normalizer::diagnostic_url( $value, $max_length );
		}

		/**
		 * Convert incoming timestamps to canonical UTC ISO-8601 strings.
		 *
		 * @param mixed $timestamp Client-provided timestamp.
		 */

		private static function normalize_timestamp( $timestamp ): string {
			$timestamp = sanitize_text_field( (string) $timestamp );

			if( $timestamp ) {
				try {
					$date = new DateTimeImmutable( $timestamp );

					return $date
						->setTimezone( new DateTimeZone( 'UTC' ) )
						->format( 'Y-m-d\TH:i:s.v\Z' );
				} catch( Exception $exception ) {
					// Fall through to a trustworthy server-generated timestamp.
				}
			}

			return self::current_timestamp();
		}

		/**
		 * Return the current UTC time with millisecond precision.
		 */

		private static function current_timestamp(): string {
			$now = microtime( true );
			$seconds = (int) floor( $now );
			$milliseconds = (int) floor( ( $now - $seconds ) * 1000 );

			return gmdate( 'Y-m-d\TH:i:s', $seconds ) . sprintf( '.%03dZ', $milliseconds );
		}

		/**
		 * Decide whether the current request should be stored in the monitor history.
		 */

		private static function should_record_current_request(): bool {
			if( ! is_user_logged_in() || wp_doing_cron() ) {
				return false;
			}

			$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';

			if( strpos( $request_uri, '/wphave/v1/performance-monitor' ) !== false ) {
				return false;
			}

			if( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
				return strpos( $request_uri, '/wphave/v1/' ) !== false || strpos( $request_uri, 'wp-json' ) !== false;
			}

			return is_admin() || wp_doing_ajax();
		}

		/**
		 * Resolve a broad request source label.
		 */

		private static function get_request_source(): string {
			if( wp_doing_ajax() ) {
				return 'ajax';
			}

			if( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
				return 'rest';
			}

			if( is_admin() ) {
				return 'admin';
			}

			return 'frontend';
		}

		/**
		 * Build a human-readable label for the current request.
		 *
		 * @param string $source Request source.
		 * @param string $request_uri Current request URI.
		 */

		private static function get_request_label( string $source, string $request_uri ): string {
			if( self::$admin_screen ) {
				return self::$admin_screen;
			}

			if( wp_doing_ajax() && isset( $_REQUEST['action'] ) ) {
				return sanitize_key( wphave_request_string( $_REQUEST, 'action' ) );
			}

			$path = WPHAVE_Security_Normalizer::request_path( $request_uri );

			if( '/' !== $path ) {
				return $path;
			}

			return $source;
		}

		/**
		 * Return the slowest SQL queries when SAVEQUERIES is enabled.
		 */

		private static function get_slow_queries(): array {
			global $wpdb;

			if( ! defined( 'SAVEQUERIES' ) || ! SAVEQUERIES || empty( $wpdb->queries ) || ! is_array( $wpdb->queries ) ) {
				return [];
			}

			$slow_queries = [];

			foreach( $wpdb->queries as $query ) {
				if( ! is_array( $query ) || count( $query ) < 2 ) {
					continue;
				}

				$duration_ms = round( (float) $query[1] * 1000, 2 );

				if( $duration_ms < self::SLOW_QUERY_MS ) {
					continue;
				}

				$sql = WPHAVE_Security_Normalizer::sql_shape( $query[0], 240 );
				$slow_queries[] = [
					'durationMs' => $duration_ms,
					'sql' => substr( $sql, 0, 240 ),
					'caller' => isset( $query[2] ) ? substr( (string) $query[2], 0, 180 ) : '',
				];
			}

			usort( $slow_queries, function( $a, $b ) {
				return $b['durationMs'] <=> $a['durationMs'];
			} );

			return array_slice( $slow_queries, 0, 5 );
		}

		/**
		 * Build a compact query profile for unusually heavy requests.
		 *
		 * @param int $query_count Total query count for the request.
		 * @param float $duration_ms Request duration in milliseconds.
		 */

		private static function get_query_profile( int $query_count, float $duration_ms = 0 ): array {
			global $wpdb;

			if( ( $query_count < self::QUERY_PROFILE_MIN_QUERIES && $duration_ms < self::QUERY_PROFILE_MIN_DURATION_MS ) || ! defined( 'SAVEQUERIES' ) || ! SAVEQUERIES || empty( $wpdb->queries ) || ! is_array( $wpdb->queries ) ) {
				return [];
			}

			$top_queries = [];
			$callers = [];
			$patterns = [];
			$total_duration_ms = 0;

			foreach( $wpdb->queries as $query ) {
				if( ! is_array( $query ) || count( $query ) < 2 ) {
					continue;
				}

				$sql = WPHAVE_Security_Normalizer::sql_shape( $query[0], 240 );
				$caller = isset( $query[2] ) ? (string) $query[2] : 'unknown';
				$duration_ms = round( (float) $query[1] * 1000, 2 );
				$total_duration_ms += $duration_ms;

				$caller_key = substr( $caller, 0, 180 );

				if( ! isset( $callers[ $caller_key ] ) ) {
					$callers[ $caller_key ] = [
						'caller' => $caller_key,
						'count' => 0,
						'durationMs' => 0,
					];
				}

				$callers[ $caller_key ]['count']++;
				$callers[ $caller_key ]['durationMs'] += $duration_ms;

				$pattern = self::normalize_query_pattern( $sql );

				if( ! isset( $patterns[ $pattern ] ) ) {
					$patterns[ $pattern ] = [
						'pattern' => substr( $pattern, 0, 220 ),
						'count' => 0,
						'durationMs' => 0,
						'example' => substr( $sql, 0, 220 ),
					];
				}

				$patterns[ $pattern ]['count']++;
				$patterns[ $pattern ]['durationMs'] += $duration_ms;

				$top_queries[] = [
					'durationMs' => $duration_ms,
					'sql' => substr( $sql, 0, 240 ),
					'caller' => $caller_key,
				];
			}

			usort( $top_queries, function( $a, $b ) {
				return $b['durationMs'] <=> $a['durationMs'];
			} );

			$callers = array_values( $callers );
			usort( $callers, function( $a, $b ) {
				if( $b['count'] === $a['count'] ) {
					return $b['durationMs'] <=> $a['durationMs'];
				}

				return $b['count'] <=> $a['count'];
			} );

			$patterns = array_values( array_filter( $patterns, function( $pattern ) {
				return (int) $pattern['count'] > 1;
			} ) );
			usort( $patterns, function( $a, $b ) {
				if( $b['count'] === $a['count'] ) {
					return $b['durationMs'] <=> $a['durationMs'];
				}

				return $b['count'] <=> $a['count'];
			} );

			return [
				'totalDurationMs' => round( $total_duration_ms, 2 ),
				'topQueries' => array_slice( $top_queries, 0, 8 ),
				'topCallers' => array_slice( array_map( [ __CLASS__, 'round_query_profile_item' ], $callers ), 0, 8 ),
				'repeatedPatterns' => array_slice( array_map( [ __CLASS__, 'round_query_profile_item' ], $patterns ), 0, 8 ),
			];
		}

		/**
		 * Replace query literals with placeholders to group repeated query shapes.
		 *
		 * @param string $sql Raw SQL query.
		 */

		private static function normalize_query_pattern( string $sql ): string {
			return WPHAVE_Security_Normalizer::sql_shape( $sql, 220 );
		}

		/**
		 * Round duration values inside query profile items.
		 *
		 * @param array $item Query profile item.
		 */

		private static function round_query_profile_item( array $item ): array {
			if( isset( $item['durationMs'] ) ) {
				$item['durationMs'] = round( (float) $item['durationMs'], 2 );
			}

			return $item;
		}

		/**
		 * Resolve the table store through the schema readiness boundary.
		 */
		private static function repository(): WPHAVE_Performance_Monitor_Event_Repository {
			return WPHAVE_Performance_Monitor_Storage_Selector::repository();
		}

		/**
		 * Persist a bounded batch without allowing diagnostics to fail product work.
		 *
		 * @param array $events Prepared monitor events.
		 * @return int|WP_Error Accepted event count or a contained storage error.
		 */
		private static function persist_events( array $events, ?callable $authorize = null ) {
			if( empty( $events ) ) {
				return 0;
			}

			try {
				return self::repository()->append_many( $events, $authorize );
			} catch( Throwable $error ) {
				return new WP_Error(
					'wphave_performance_monitor_storage_failed',
					__( 'The performance measurement could not be stored.', 'wphave' )
				);
			}
		}

		/**
		 * Build aggregate values consumed by the monitor UI.
		 *
		 * @param array $events Stored monitor events.
		 */

		private static function build_summary( array $events ): array {
			$request_events = array_values( array_filter( $events, function( $event ) {
				return ( $event['type'] ?? '' ) === 'request';
			} ) );
			$latest_event = ! empty( $events ) ? end( $events ) : null;
			$latest_request = ! empty( $request_events ) ? end( $request_events ) : null;
			$slowest = self::get_top_events( $request_events, 'durationMs', 5 );
			$heaviest = self::get_top_events( $request_events, 'memoryPeakBytes', 5 );
			$most_queries = self::get_top_events( $request_events, 'queryCount', 5 );

			return [
				'totalEvents' => count( $events ),
				'totalRequests' => count( $request_events ),
				// Keep the legacy key request-scoped: every metric beside it is also
				// aggregated exclusively from server request events.
				'latest' => $latest_request,
				'latestRequest' => $latest_request,
				'latestEvent' => $latest_event,
				'averages' => [
					'durationMs' => self::average( $request_events, 'durationMs' ),
					'memoryPeakBytes' => self::average( $request_events, 'memoryPeakBytes' ),
					'queryCount' => self::average( $request_events, 'queryCount' ),
				],
				'peaks' => [
					'durationMs' => self::max_value( $request_events, 'durationMs' ),
					'memoryPeakBytes' => self::max_value( $request_events, 'memoryPeakBytes' ),
					'queryCount' => self::max_value( $request_events, 'queryCount' ),
				],
				'slowest' => $slowest,
				'heaviest' => $heaviest,
				'mostQueries' => $most_queries,
				'statusCounts' => self::count_by_status( $request_events ),
				'sourceCounts' => self::count_by_key( $events, 'source' ),
			];
		}

		/**
		 * Calculate the average value for a numeric event key.
		 *
		 * @param array $events Events to aggregate.
		 * @param string $key Numeric event key.
		 */

		private static function average( array $events, string $key ): float {
			if( empty( $events ) ) {
				return 0;
			}

			$total = array_reduce( $events, function( $carry, $event ) use ( $key ) {
				return $carry + (float) ( $event[ $key ] ?? 0 );
			}, 0 );

			return round( $total / count( $events ), 2 );
		}

		/**
		 * Return the maximum numeric value for an event key.
		 *
		 * @param array $events Events to aggregate.
		 * @param string $key Numeric event key.
		 */

		private static function max_value( array $events, string $key ): float {
			if( empty( $events ) ) {
				return 0;
			}

			return (float) max( array_map( function( $event ) use ( $key ) {
				return (float) ( $event[ $key ] ?? 0 );
			}, $events ) );
		}

		/**
		 * Return events sorted by a numeric value in descending order.
		 *
		 * @param array $events Events to sort.
		 * @param string $key Numeric event key.
		 * @param int $limit Maximum number of events to return.
		 */

		private static function get_top_events( array $events, string $key, int $limit ): array {
			usort( $events, function( $a, $b ) use ( $key ) {
				return (float) ( $b[ $key ] ?? 0 ) <=> (float) ( $a[ $key ] ?? 0 );
			} );

			return array_slice( $events, 0, $limit );
		}

		/**
		 * Group request events by HTTP status class.
		 *
		 * @param array $events Request events.
		 */

		private static function count_by_status( array $events ): array {
			$counts = [
				'2xx' => 0,
				'3xx' => 0,
				'4xx' => 0,
				'5xx' => 0,
			];

			foreach( $events as $event ) {
				$status = (int) ( $event['status'] ?? 200 );
				$key = floor( $status / 100 ) . 'xx';

				if( isset( $counts[ $key ] ) ) {
					$counts[ $key ]++;
				}
			}

			return $counts;
		}

		/**
		 * Count events grouped by a scalar event key.
		 *
		 * @param array $events Events to count.
		 * @param string $key Event key to group by.
		 */

		private static function count_by_key( array $events, string $key ): array {
			$counts = [];

			foreach( $events as $event ) {
				$value = (string) ( $event[ $key ] ?? 'unknown' );
				$counts[ $value ] = ( $counts[ $value ] ?? 0 ) + 1;
			}

			ksort( $counts );

			return $counts;
		}

	}

endif;

if( ! defined( 'WPHAVE_START_TIME' ) ) {
	define( 'WPHAVE_START_TIME', microtime( true ) );
}

if( method_exists( 'WPHAVE_Performance_Monitor', 'init' ) ) {
	WPHAVE_Performance_Monitor::init();
}
