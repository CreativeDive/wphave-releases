<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Bounded WordPress-native diagnostics for one authorized profiler request.
 * Values from options, mail, headers and query variables are never persisted.
 */
final class WPHAVE_Request_Profiler_WordPress_Diagnostics {

	const MAX_DEBUG_CALLS = 40;
	const MAX_REDIRECTS = 20;
	const MAX_MAIL_EVENTS = 20;
	const MAX_AUTOLOAD_OPTIONS = 30;
	const MAX_TRANSIENT_EVENTS = 50;
	const MAX_CAPABILITY_CHECKS = 80;
	const MAX_TEXT_DOMAINS = 60;

	private static $debug_calls = array();
	private static $redirects = array();
	private static $mail = array();
	private static $transients = array();
	private static $capability_checks = array();
	private static $capture_capabilities = false;
	private static $capturing_capability = false;

	public static function start( $capture_capabilities = false ) {
		self::$capture_capabilities = (bool) $capture_capabilities;
		add_action( 'deprecated_function_run', array( __CLASS__, 'deprecated_function' ), 10, 3 );
		add_action( 'deprecated_argument_run', array( __CLASS__, 'deprecated_argument' ), 10, 3 );
		add_action( 'doing_it_wrong_run', array( __CLASS__, 'doing_it_wrong' ), 10, 3 );
		add_filter( 'wp_redirect', array( __CLASS__, 'capture_redirect' ), PHP_INT_MAX, 2 );
		add_action( 'wp_mail_succeeded', array( __CLASS__, 'mail_succeeded' ) );
		add_action( 'wp_mail_failed', array( __CLASS__, 'mail_failed' ) );
		add_action( 'setted_transient', array( __CLASS__, 'transient_set' ), 10, 3 );
		add_action( 'deleted_transient', array( __CLASS__, 'transient_deleted' ) );
		add_action( 'setted_site_transient', array( __CLASS__, 'site_transient_set' ), 10, 3 );
		add_action( 'deleted_site_transient', array( __CLASS__, 'site_transient_deleted' ) );
		if( self::$capture_capabilities ) {
			add_filter( 'user_has_cap', array( __CLASS__, 'capture_capability_check' ), PHP_INT_MAX, 4 );
		}
	}

	public static function deprecated_function( $function, $replacement, $version ) {
		self::append_debug_call( 'deprecated-function', $function, $replacement, $version );
	}

	public static function deprecated_argument( $function, $message, $version ) {
		self::append_debug_call( 'deprecated-argument', $function, $message, $version );
	}

	public static function doing_it_wrong( $function, $message, $version ) {
		self::append_debug_call( 'doing-it-wrong', $function, $message, $version );
	}

	public static function capture_redirect( $location, $status ) {
		if( count( self::$redirects ) < self::MAX_REDIRECTS ) {
			self::$redirects[] = array(
				'status' => (int) $status,
				'target' => self::safe_url_shape( $location ),
				'atMs' => self::elapsed(),
			);
		}
		return $location;
	}

	public static function mail_succeeded( $mail_data ) {
		self::append_mail( 'sent', is_array( $mail_data ) ? count( (array) ( $mail_data['to'] ?? array() ) ) : 0, '' );
	}

	public static function mail_failed( $error ) {
		self::append_mail( 'failed', 0, is_wp_error( $error ) ? $error->get_error_code() : 'unknown' );
	}

	public static function snapshot() {
		return array(
			'debugCalls' => array_values( self::$debug_calls ),
			'redirects' => array_values( self::$redirects ),
			'mail' => array_values( self::$mail ),
			'objectCache' => self::object_cache_snapshot(),
			'autoloadOptions' => self::autoload_options_snapshot(),
			'cron' => self::cron_snapshot(),
			'mainQuery' => self::main_query_snapshot(),
			'template' => self::template_snapshot(),
			'languages' => self::language_snapshot(),
			'transients' => array_values( self::$transients ),
			'capabilities' => array(
				'enabled' => self::$capture_capabilities,
				'items' => array_values( self::$capability_checks ),
			),
			'runtime' => self::runtime_snapshot(),
		);
	}

	public static function transient_set( $name, $value, $expiration ) {
		self::append_transient( 'set', 'site', $name, $value, $expiration );
	}

	public static function transient_deleted( $name ) {
		self::append_transient( 'delete', 'site', $name, null, 0 );
	}

	public static function site_transient_set( $name, $value, $expiration ) {
		self::append_transient( 'set', 'network', $name, $value, $expiration );
	}

	public static function site_transient_deleted( $name ) {
		self::append_transient( 'delete', 'network', $name, null, 0 );
	}

	public static function capture_capability_check( $allcaps, $caps, $args, $user ) {
		if( self::$capturing_capability || count( self::$capability_checks ) >= self::MAX_CAPABILITY_CHECKS ) {
			return $allcaps;
		}
		self::$capturing_capability = true;
		$origin = WPHAVE_Request_Profiler_Diagnostics::source_descriptor_from_trace();
		foreach( array_slice( array_values( array_unique( array_map( 'sanitize_key', (array) $caps ) ) ), 0, 10 ) as $capability ) {
			self::$capability_checks[] = array(
				'capability' => $capability,
				'granted' => ! empty( $allcaps[$capability] ),
				'userId' => is_object( $user ) ? (int) $user->ID : 0,
				'component' => $origin['component'],
				'source' => $origin['source'],
				'atMs' => self::elapsed(),
			);
			if( count( self::$capability_checks ) >= self::MAX_CAPABILITY_CHECKS ) {
				break;
			}
		}
		self::$capturing_capability = false;
		return $allcaps;
	}

	private static function append_transient( $action, $scope, $name, $value, $expiration ) {
		if( count( self::$transients ) >= self::MAX_TRANSIENT_EVENTS ) {
			return;
		}
		$origin = WPHAVE_Request_Profiler_Diagnostics::source_descriptor_from_trace();
		self::$transients[] = array(
			'action' => sanitize_key( $action ),
			'scope' => sanitize_key( $scope ),
			'name' => substr( sanitize_key( (string) $name ), 0, 172 ),
			'sizeBytes' => null === $value ? 0 : strlen( maybe_serialize( $value ) ),
			'expiration' => max( 0, (int) $expiration ),
			'component' => $origin['component'],
			'source' => $origin['source'],
			'atMs' => self::elapsed(),
		);
	}

	private static function append_debug_call( $type, $function, $detail, $version ) {
		if( count( self::$debug_calls ) >= self::MAX_DEBUG_CALLS ) {
			return;
		}
		$origin = WPHAVE_Request_Profiler_Diagnostics::source_descriptor_from_trace();
		self::$debug_calls[] = array(
			'type' => sanitize_key( $type ),
			'function' => substr( sanitize_text_field( (string) $function ), 0, 180 ),
			'detail' => substr( sanitize_text_field( wp_strip_all_tags( (string) $detail ) ), 0, 300 ),
			'version' => substr( sanitize_text_field( (string) $version ), 0, 40 ),
			'component' => $origin['component'],
			'source' => $origin['source'],
			'atMs' => self::elapsed(),
		);
	}

	private static function append_mail( $status, $recipient_count, $error_code ) {
		if( count( self::$mail ) >= self::MAX_MAIL_EVENTS ) {
			return;
		}
		self::$mail[] = array(
			'status' => sanitize_key( $status ),
			'recipientCount' => max( 0, (int) $recipient_count ),
			'errorCode' => sanitize_key( $error_code ),
			'atMs' => self::elapsed(),
		);
	}

	private static function object_cache_snapshot() {
		$cache = $GLOBALS['wp_object_cache'] ?? null;
		$hits = is_object( $cache ) && isset( $cache->cache_hits ) ? (int) $cache->cache_hits : null;
		$misses = is_object( $cache ) && isset( $cache->cache_misses ) ? (int) $cache->cache_misses : null;
		$total = (int) $hits + (int) $misses;
		return array(
			'persistent' => wp_using_ext_object_cache(),
			'hits' => $hits,
			'misses' => $misses,
			'hitRate' => $total > 0 ? round( (int) $hits / $total * 100, 1 ) : null,
			'groups' => is_object( $cache ) && is_array( $cache->cache ?? null ) ? count( $cache->cache ) : null,
			'opcodeCache' => array(
				'enabled' => function_exists( 'opcache_get_status' ) && false !== opcache_get_status( false ),
				'extensionLoaded' => extension_loaded( 'Zend OPcache' ),
			),
		);
	}

	private static function autoload_options_snapshot() {
		$options = function_exists( 'wp_load_alloptions' ) ? wp_load_alloptions() : array();
		$items = array();
		foreach( is_array( $options ) ? $options : array() as $name => $value ) {
			$items[] = array(
				'name' => substr( sanitize_key( $name ), 0, 180 ),
				'sizeBytes' => strlen( maybe_serialize( $value ) ),
			);
		}
		usort( $items, fn( $a, $b ) => $b['sizeBytes'] <=> $a['sizeBytes'] );
		return array(
			'count' => count( $items ),
			'totalBytes' => array_sum( array_column( $items, 'sizeBytes' ) ),
			'largest' => array_slice( $items, 0, self::MAX_AUTOLOAD_OPTIONS ),
		);
	}

	private static function cron_snapshot() {
		$cron = function_exists( '_get_cron_array' ) ? _get_cron_array() : array();
		$events = 0;
		$next = null;
		foreach( is_array( $cron ) ? $cron : array() as $timestamp => $hooks ) {
			$events += is_array( $hooks ) ? count( $hooks ) : 0;
			$next = null === $next ? (int) $timestamp : min( $next, (int) $timestamp );
		}
		return array(
			'eventCount' => $events,
			'nextRunAt' => $next ? gmdate( 'c', $next ) : '',
			'overdue' => $next ? $next < time() : false,
		);
	}

	private static function main_query_snapshot() {
		$query = $GLOBALS['wp_query'] ?? null;
		if( ! $query instanceof WP_Query ) {
			return array( 'available' => false );
		}
		$true_conditionals = array();
		$false_conditionals = array();
		$conditionals = array( 'is_404', 'is_admin', 'is_archive', 'is_attachment', 'is_author', 'is_blog_admin', 'is_category', 'is_comment_feed', 'is_customize_preview', 'is_date', 'is_day', 'is_embed', 'is_favicon', 'is_feed', 'is_front_page', 'is_home', 'is_login', 'is_month', 'is_network_admin', 'is_page', 'is_page_template', 'is_paged', 'is_post_type_archive', 'is_preview', 'is_privacy_policy', 'is_robots', 'is_rtl', 'is_search', 'is_single', 'is_singular', 'is_ssl', 'is_sticky', 'is_tag', 'is_tax', 'is_time', 'is_trackback', 'is_user_admin', 'is_year' );
		foreach( $conditionals as $conditional ) {
			if( function_exists( $conditional ) ) {
				if( $conditional() ) {
					$true_conditionals[] = $conditional;
				} else {
					$false_conditionals[] = $conditional;
				}
			}
		}
		$queried_object = get_queried_object();
		$query_variables = array();
		foreach( array_slice( (array) $query->query_vars, 0, 80, true ) as $name => $value ) {
			$query_variables[] = array(
				'name' => sanitize_key( (string) $name ),
				'type' => gettype( $value ),
				'count' => is_array( $value ) ? count( $value ) : null,
				'isEmpty' => empty( $value ),
			);
		}
		return array(
			'available' => true,
			'postCount' => (int) $query->post_count,
			'foundPosts' => (int) $query->found_posts,
			'maxPages' => (int) $query->max_num_pages,
			'conditionals' => $true_conditionals,
			'trueConditionals' => $true_conditionals,
			'falseConditionals' => $false_conditionals,
			'queryVariableNames' => array_slice( array_values( array_map( 'sanitize_key', array_keys( (array) $query->query_vars ) ) ), 0, 80 ),
			'queryVariables' => $query_variables,
			'queriedObject' => array(
				'type' => is_object( $queried_object ) ? sanitize_key( get_class( $queried_object ) ) : gettype( $queried_object ),
				'id' => is_object( $queried_object ) ? (int) ( $queried_object->ID ?? $queried_object->term_id ?? 0 ) : 0,
			),
		);
	}

	private static function template_snapshot() {
		$theme = wp_get_theme();
		$parent = $theme->parent();
		$template = (string) get_page_template_slug();
		$hierarchy = array_values( array_filter( array_unique( array(
			$template,
			is_front_page() ? 'front-page' : '',
			is_home() ? 'home' : '',
			is_singular() ? 'singular' : '',
			is_page() ? 'page' : '',
			is_single() ? 'single' : '',
			is_archive() ? 'archive' : '',
			'index',
		) ) ) );
		$body_classes = function_exists( 'get_body_class' ) ? get_body_class() : array();
		return array(
			'theme' => sanitize_text_field( $theme->get_stylesheet() ),
			'parentTheme' => $parent ? sanitize_text_field( $parent->get_stylesheet() ) : '',
			'templateSlug' => substr( sanitize_text_field( $template ), 0, 220 ),
			'hierarchy' => array_slice( array_map( 'sanitize_text_field', $hierarchy ), 0, 30 ),
			'bodyClasses' => array_slice( array_values( array_map( 'sanitize_html_class', $body_classes ) ), 0, 80 ),
			'templateParts' => self::template_parts_snapshot(),
		);
	}

	private static function template_parts_snapshot() {
		if( ! function_exists( 'get_block_templates' ) ) {
			return array();
		}
		$parts = get_block_templates( array(), 'wp_template_part' );
		return array_slice( array_values( array_map( function( $part ) {
			return array(
				'slug' => sanitize_key( (string) ( $part->slug ?? '' ) ),
				'theme' => sanitize_key( (string) ( $part->theme ?? '' ) ),
				'area' => sanitize_key( (string) ( $part->area ?? '' ) ),
			);
		}, is_array( $parts ) ? $parts : array() ) ), 0, 40 );
	}

	private static function language_snapshot() {
		$domains = array();
		$files = array();
		$locale = function_exists( 'determine_locale' ) ? determine_locale() : get_locale();
		$registry = $GLOBALS['wp_textdomain_registry'] ?? null;
		foreach( array_keys( is_array( $GLOBALS['l10n'] ?? null ) ? $GLOBALS['l10n'] : array() ) as $domain ) {
			$domains[] = array(
				'domain' => substr( sanitize_key( (string) $domain ), 0, 160 ),
				'loaded' => is_textdomain_loaded( (string) $domain ),
			);
			if( is_object( $registry ) && method_exists( $registry, 'get' ) ) {
				$directory = (string) $registry->get( (string) $domain, $locale );
				foreach( array( 'mo', 'l10n.php' ) as $extension ) {
					$path = trailingslashit( $directory ) . $locale . '.' . $extension;
					if( $directory && is_file( $path ) && is_readable( $path ) ) {
						$source = WPHAVE_Request_Profiler_Diagnostics::source_descriptor( $path );
						$files[] = array(
							'domain' => substr( sanitize_key( (string) $domain ), 0, 160 ),
							'format' => sanitize_key( $extension ),
							'file' => $source['source'],
							'component' => $source['component'],
							'sizeBytes' => (int) filesize( $path ),
						);
					}
				}
			}
		}
		return array(
			'locale' => get_locale(),
			'userLocale' => get_user_locale(),
			'determinedLocale' => $locale,
			'isRtl' => is_rtl(),
			'domains' => array_slice( $domains, 0, self::MAX_TEXT_DOMAINS ),
			'files' => array_slice( $files, 0, self::MAX_TEXT_DOMAINS ),
		);
	}

	private static function runtime_snapshot() {
		return array(
			'php' => array(
				'version' => PHP_VERSION,
				'sapi' => PHP_SAPI,
				'memoryLimitBytes' => wp_convert_hr_to_bytes( (string) ini_get( 'memory_limit' ) ),
				'maxExecutionSeconds' => (int) ini_get( 'max_execution_time' ),
				'uploadMaxBytes' => wp_convert_hr_to_bytes( (string) ini_get( 'upload_max_filesize' ) ),
				'postMaxBytes' => wp_convert_hr_to_bytes( (string) ini_get( 'post_max_size' ) ),
				'displayErrors' => (bool) ini_get( 'display_errors' ),
				'logErrors' => (bool) ini_get( 'log_errors' ),
				'extensionCount' => count( get_loaded_extensions() ),
			),
			'database' => array(
				'serverVersion' => isset( $GLOBALS['wpdb'] ) ? sanitize_text_field( $GLOBALS['wpdb']->db_version() ) : '',
				'clientVersion' => function_exists( 'mysqli_get_client_info' ) ? sanitize_text_field( mysqli_get_client_info() ) : '',
			),
			'wordpress' => array(
				'environmentType' => function_exists( 'wp_get_environment_type' ) ? wp_get_environment_type() : '',
				'developmentMode' => function_exists( 'wp_get_development_mode' ) ? wp_get_development_mode() : '',
				'wpDebug' => defined( 'WP_DEBUG' ) && WP_DEBUG,
				'wpDebugDisplay' => defined( 'WP_DEBUG_DISPLAY' ) && WP_DEBUG_DISPLAY,
				'wpDebugLog' => defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG,
				'scriptDebug' => defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG,
			),
			'server' => array(
				'software' => substr( sanitize_text_field( wp_unslash( $_SERVER['SERVER_SOFTWARE'] ?? '' ) ), 0, 180 ),
				'os' => PHP_OS_FAMILY,
				'architecture' => php_uname( 'm' ),
			),
		);
	}

	private static function safe_url_shape( $url ) {
		$parts = wp_parse_url( (string) $url );
		if( ! is_array( $parts ) ) {
			return '';
		}
		return substr( sanitize_text_field( (string) ( $parts['host'] ?? '' ) . (string) ( $parts['path'] ?? '/' ) ), 0, 320 );
	}

	private static function elapsed() {
		return isset( $_SERVER['REQUEST_TIME_FLOAT'] )
			? round( max( 0, microtime( true ) - (float) $_SERVER['REQUEST_TIME_FLOAT'] ) * 1000, 2 )
			: 0;
	}
}
