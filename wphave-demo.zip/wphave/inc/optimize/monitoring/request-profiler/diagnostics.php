<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once wphave_dir() . 'inc/features/security/boundaries/index.php';

/**
 * Bounded deep diagnostics that exist only during an authorized profiler run.
 */
final class WPHAVE_Request_Profiler_Diagnostics {

	const MAX_HTTP_REQUESTS = 50;
	const MAX_ERRORS = 30;
	const MAX_HOOKS = 100;
	const MAX_CALLBACKS_PER_HOOK = 20;
	const MAX_ASSETS = 150;

	private static $started = false;
	private static $http_requests = array();
	private static $errors = array();
	private static $previous_error_handler = null;

	public static function start() {
		if( self::$started ) {
			return;
		}

		self::$started = true;
		add_filter( 'http_request_args', array( __CLASS__, 'start_http_request' ), PHP_INT_MIN, 2 );
		add_action( 'http_api_debug', array( __CLASS__, 'finish_http_request' ), PHP_INT_MAX, 5 );
		self::$previous_error_handler = set_error_handler( array( __CLASS__, 'capture_php_error' ) );
		add_action( 'shutdown', array( __CLASS__, 'capture_fatal_error' ), PHP_INT_MIN );
	}

	public static function start_http_request( $args, $url ) {
		if( is_array( $args ) ) {
			$args['_wphave_profiler_started'] = microtime( true );
		}
		return $args;
	}

	public static function finish_http_request( $response, $context, $transport, $args, $url ) {
		if( 'response' !== $context || count( self::$http_requests ) >= self::MAX_HTTP_REQUESTS ) {
			return;
		}

		$started = is_array( $args ) ? (float) ( $args['_wphave_profiler_started'] ?? 0 ) : 0;
		$method = is_array( $args ) ? strtoupper( sanitize_key( (string) ( $args['method'] ?? 'GET' ) ) ) : 'GET';
		$status = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );
		$error = is_wp_error( $response ) ? sanitize_key( (string) $response->get_error_code() ) : '';

		self::$http_requests[] = array(
			'method' => $method,
			'endpoint' => self::safe_endpoint( $url ),
			'status' => $status,
			'durationMs' => $started ? round( max( 0, microtime( true ) - $started ) * 1000, 2 ) : null,
			'errorCode' => $error,
			'transport' => is_object( $transport ) ? sanitize_text_field( get_class( $transport ) ) : '',
		);
	}

	public static function capture_php_error( $type, $message, $file, $line ) {
		$is_test_message = class_exists( 'WPHAVE_Request_Inspector_Test_Signals' )
			&& WPHAVE_Request_Inspector_Test_Signals::is_test_message( $message );
		if( $is_test_message || error_reporting() & $type ) {
			self::append_error( $type, $message, $file, $line, false );
		}
		if( $is_test_message ) {
			return true;
		}
		if( is_callable( self::$previous_error_handler ) ) {
			return (bool) call_user_func( self::$previous_error_handler, $type, $message, $file, $line );
		}
		return false;
	}

	public static function capture_fatal_error() {
		$error = error_get_last();
		$fatal_types = array( E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR, E_RECOVERABLE_ERROR );
		if( is_array( $error ) && in_array( (int) ( $error['type'] ?? 0 ), $fatal_types, true ) ) {
			self::append_error(
				(int) $error['type'],
				(string) ( $error['message'] ?? '' ),
				(string) ( $error['file'] ?? '' ),
				(int) ( $error['line'] ?? 0 ),
				true
			);
		}
	}

	public static function snapshot() {
		return array(
			'httpRequests' => array_values( self::$http_requests ),
			'phpErrors' => array_values( self::$errors ),
			'hooks' => self::hook_snapshot(),
			'assets' => self::asset_snapshot(),
		);
	}

	private static function append_error( $type, $message, $file, $line, $fatal ) {
		if( count( self::$errors ) >= self::MAX_ERRORS ) {
			return;
		}

		// SECURITY INVARIANT: Runtime errors are treated as secret-bearing input.
		// Quoted values, URLs and the installation root are removed before diagnostic
		// normalization or persistence can expose them to an inspector client.
		$message = preg_replace( '/([\'\"])[^\'\"]{1,240}\1/', '$1[redacted]$1', (string) $message );
		$message = preg_replace( '~https?://[^\s]+~i', '[url]', (string) $message );
		$message = wp_normalize_path( (string) $message );
		$root_spellings = array_filter(
			array_unique(
				array(
					untrailingslashit( wp_normalize_path( ABSPATH ) ),
					wphave_wordpress_root_path(),
				)
			)
		);
		usort( $root_spellings, static fn( $left, $right ) => strlen( $right ) <=> strlen( $left ) );

		// REDACTION IDENTITY INVARIANT: PHP may report either the configured
		// ABSPATH spelling or its real symlink target. Neither physical root may
		// survive into a persisted browser-visible profiler message.
		$message = str_replace( $root_spellings, '', $message );
		self::$errors[] = array(
			'type' => (int) $type,
			'label' => self::error_label( $type ),
			'message' => WPHAVE_Security_Normalizer::diagnostic_text( $message, 500 ),
			'file' => self::safe_file( $file ),
			'line' => max( 0, (int) $line ),
			'fatal' => (bool) $fatal,
		);
	}

	private static function hook_snapshot() {
		$actions = is_array( $GLOBALS['wp_actions'] ?? null ) ? $GLOBALS['wp_actions'] : array();
		$filters = is_array( $GLOBALS['wp_filter'] ?? null ) ? $GLOBALS['wp_filter'] : array();
		$hooks = array();
		$first_fire_order = 0;

		foreach( $actions as $name => $fires ) {
			if( ! is_string( $name ) || ! preg_match( '/^[A-Za-z][A-Za-z0-9_.:-]{0,79}$/', $name ) ) {
				continue;
			}
			$callbacks = array();
			$callback_count = 0;
			$hook = $filters[$name] ?? null;
			if( $hook instanceof WP_Hook ) {
				foreach( $hook->callbacks as $priority => $items ) {
					foreach( $items as $item ) {
						$callback_count++;
						if( count( $callbacks ) >= self::MAX_CALLBACKS_PER_HOOK ) {
							continue;
						}
						$descriptor = self::callback_descriptor( $item['function'] ?? null );
						$callbacks[] = array(
							'priority' => (int) $priority,
							'callback' => $descriptor['callback'],
							'component' => $descriptor['component'],
							'source' => $descriptor['source'],
							'acceptedArgs' => (int) ( $item['accepted_args'] ?? 0 ),
						);
					}
				}
			}
			$hooks[] = array(
				'name' => $name,
				'fires' => max( 0, (int) $fires ),
				'callbackCount' => $callback_count,
				'callbacks' => $callbacks,
				'firstFireOrder' => $first_fire_order++,
			);
		}

		// wp_actions preserves first insertion order, which is the actual order in
		// which each hook first fired during this request. Keep that sequence intact.
		return array_slice( $hooks, 0, self::MAX_HOOKS );
	}

	private static function asset_snapshot() {
		return array(
			'scripts' => self::dependency_snapshot( $GLOBALS['wp_scripts'] ?? null, 'script' ),
			'styles' => self::dependency_snapshot( $GLOBALS['wp_styles'] ?? null, 'style' ),
		);
	}

	private static function dependency_snapshot( $registry, $type ) {
		if( ! $registry instanceof WP_Dependencies ) {
			return array();
		}
		$items = array();
		$queued_handles = array_values( array_unique( $registry->queue ) );
		$dependent_counts = array_fill_keys( $queued_handles, 0 );
		foreach( $queued_handles as $candidate_handle ) {
			$candidate = $registry->registered[$candidate_handle] ?? null;
			if( ! is_object( $candidate ) ) {
				continue;
			}
			foreach( (array) ( $candidate->deps ?? array() ) as $dependency_handle ) {
				if( array_key_exists( $dependency_handle, $dependent_counts ) ) {
					$dependent_counts[$dependency_handle]++;
				}
			}
		}
		foreach( array_slice( $queued_handles, 0, self::MAX_ASSETS ) as $handle ) {
			$dependency = $registry->registered[$handle] ?? null;
			if( ! is_object( $dependency ) ) {
				continue;
			}
			$source = (string) ( $dependency->src ?? '' );
			$items[] = array(
				'handle' => sanitize_key( $handle ),
				'source' => self::safe_asset_source( $source ),
				'host' => substr( sanitize_text_field( (string) wp_parse_url( $source, PHP_URL_HOST ) ), 0, 180 ),
				'component' => self::asset_component( $source ),
				'dependencies' => array_values( array_map( 'sanitize_key', (array) ( $dependency->deps ?? array() ) ) ),
				// STORAGE INVARIANT: Consumers display only the relationship count.
				// Persisting every reverse edge duplicated the dependency graph and made
				// each bounded profile substantially more expensive to serialize.
				'dependentCount' => (int) ( $dependent_counts[$handle] ?? 0 ),
				'type' => $type,
				'state' => in_array( $handle, (array) $registry->done, true ) ? 'done' : 'queued',
				'position' => 'script' === $type && isset( $dependency->extra['group'] ) && 1 === (int) $dependency->extra['group'] ? 'footer' : 'header',
				'version' => sanitize_text_field( (string) ( $dependency->ver ?? '' ) ),
			);
		}
		return $items;
	}

	private static function asset_component( $source ) {
		$path = (string) wp_parse_url( $source, PHP_URL_PATH );
		if( preg_match( '#/wp-content/plugins/([^/]+)/#', $path, $matches ) ) {
			return 'plugin:' . sanitize_key( $matches[1] );
		}
		if( preg_match( '#/wp-content/mu-plugins/([^/]+)/#', $path, $matches ) ) {
			return 'mu-plugin:' . sanitize_key( $matches[1] );
		}
		if( preg_match( '#/wp-content/themes/([^/]+)/#', $path, $matches ) ) {
			return 'theme:' . sanitize_key( $matches[1] );
		}
		if( str_contains( $path, '/wp-admin/' ) || str_contains( $path, '/wp-includes/' ) ) {
			return 'wordpress-core';
		}
		return 'external-or-inline';
	}

	private static function callback_descriptor( $callback ) {
		$label = 'unknown';
		$reflection = null;
		if( is_string( $callback ) ) {
			$label = $callback;
			if( function_exists( $callback ) ) {
				$reflection = new ReflectionFunction( $callback );
			}
		} elseif( is_array( $callback ) && count( $callback ) >= 2 ) {
			$owner = is_object( $callback[0] ) ? get_class( $callback[0] ) : (string) $callback[0];
			$label = $owner . '::' . (string) $callback[1];
			if( method_exists( $callback[0], (string) $callback[1] ) ) {
				$reflection = new ReflectionMethod( $callback[0], (string) $callback[1] );
			}
		} elseif( $callback instanceof Closure ) {
			$label = 'Closure';
			$reflection = new ReflectionFunction( $callback );
		} elseif( is_object( $callback ) ) {
			$label = get_class( $callback ) . '::__invoke';
			if( method_exists( $callback, '__invoke' ) ) {
				$reflection = new ReflectionMethod( $callback, '__invoke' );
			}
		}

		$origin = $reflection && $reflection->getFileName()
			? self::source_descriptor( $reflection->getFileName() )
			: array( 'component' => 'internal', 'source' => '' );

		return array(
			'callback' => substr( sanitize_text_field( $label ), 0, 220 ),
			'component' => $origin['component'],
			'source' => $origin['source'],
		);
	}

	public static function describe_callback( $callback ) {
		return self::callback_descriptor( $callback );
	}

	/**
	 * Convert one absolute runtime file into a portable component and source.
	 */
	public static function source_descriptor( $file ) {
		$resolved_file = realpath( (string) $file );
		$file = wp_normalize_path( $resolved_file ?: (string) $file );
		$root = wphave_wordpress_root_path();
		$inside_root = '' !== $root && ( $file === $root || str_starts_with( $file, trailingslashit( $root ) ) );
		$source = $inside_root ? ltrim( substr( $file, strlen( $root ) ), '/' ) : basename( $file );
		$component = 'application';
		if( preg_match( '~/wp-content/plugins/([^/]+)/~', $file, $match ) ) {
			$component = 'plugin:' . sanitize_key( $match[1] );
		} elseif( preg_match( '~/wp-content/mu-plugins/([^/]+)~', $file, $match ) ) {
			$component = 'mu-plugin:' . sanitize_key( $match[1] );
		} elseif( preg_match( '~/wp-content/themes/([^/]+)/~', $file, $match ) ) {
			$component = 'theme:' . sanitize_key( $match[1] );
		} elseif( strpos( $file, '/wp-admin/' ) !== false || strpos( $file, '/wp-includes/' ) !== false ) {
			$component = 'wordpress-core';
		}

		return array(
			'component' => $component,
			'source' => substr( sanitize_text_field( $source ), 0, 300 ),
		);
	}

	public static function source_descriptor_from_trace() {
		foreach( debug_backtrace( DEBUG_BACKTRACE_IGNORE_ARGS, 30 ) as $frame ) {
			$file = (string) ( $frame['file'] ?? '' );
			if(
				! $file
				|| str_contains( $file, 'request-profiler-' )
				|| str_contains( $file, '/wp-includes/functions.php' )
				|| str_contains( $file, '/wp-includes/class-wp-hook.php' )
			) {
				continue;
			}
			return self::source_descriptor( $file );
		}
		return array( 'component' => 'unknown', 'source' => '' );
	}

	private static function safe_endpoint( $url ) {
		$host = strtolower( (string) wp_parse_url( (string) $url, PHP_URL_HOST ) );
		$path = (string) wp_parse_url( (string) $url, PHP_URL_PATH );
		// SECURITY INVARIANT: Profiling records endpoint topology only. Query strings,
		// fragments, credentials and request payloads never enter the snapshot.
		return substr( sanitize_text_field( $host . ( $path ?: '/' ) ), 0, 320 );
	}

	private static function safe_asset_source( $source ) {
		$source = preg_replace( '/[?#].*$/', '', (string) $source );
		return substr( sanitize_text_field( $source ), 0, 320 );
	}

	private static function safe_file( $file ) {
		$resolved_file = realpath( (string) $file );
		$file = wp_normalize_path( $resolved_file ?: (string) $file );
		$root = wphave_wordpress_root_path();
		$inside_root = '' !== $root && ( $file === $root || str_starts_with( $file, trailingslashit( $root ) ) );
		$safe_file = $inside_root ? ltrim( substr( $file, strlen( $root ) ), '/' ) : basename( $file );

		return substr( sanitize_text_field( $safe_file ), 0, 300 );
	}

	private static function error_label( $type ) {
		$labels = array(
			E_ERROR => 'error',
			E_WARNING => 'warning',
			E_PARSE => 'parse',
			E_NOTICE => 'notice',
			E_CORE_ERROR => 'core-error',
			E_CORE_WARNING => 'core-warning',
			E_COMPILE_ERROR => 'compile-error',
			E_COMPILE_WARNING => 'compile-warning',
			E_USER_ERROR => 'user-error',
			E_USER_WARNING => 'user-warning',
			E_USER_NOTICE => 'user-notice',
			E_RECOVERABLE_ERROR => 'recoverable-error',
			E_DEPRECATED => 'deprecated',
			E_USER_DEPRECATED => 'user-deprecated',
		);
		return $labels[(int) $type] ?? 'unknown';
	}
}
