<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/diagnostics.php';
require_once __DIR__ . '/wordpress-diagnostics.php';
require_once wphave_dir() . 'inc/features/security/boundaries/index.php';

/**
 * Profiles explicitly authorized WordPress requests without turning normal
 * frontend traffic into permanent monitoring.
 *
 * The app Performance Monitor owns continuous WPHAVE app diagnostics. This
 * profiler deliberately uses a separate store and activates only for a
 * short-lived bearer token sent through a request header.
 */

class WPHAVE_Request_Profiler {

	const OPTION_KEY = 'wphave_request_profiler_profiles';
	const SUMMARY_OPTION_KEY = 'wphave_request_profiler_summaries';
	const SUMMARY_DIRTY_KEY = 'wphave_request_profiler_summaries_dirty';
	const SESSION_PREFIX = 'wphave_request_profile_';
	const MAX_PROFILES = 30;
	const MAX_ARCHIVE_BYTES = 8 * MB_IN_BYTES;
	const MAX_TARGET_PROFILES = 10;
	const MAX_RUNS = 10;
	const MAX_CAPTURED_QUERIES = 500;
	const MAX_BLOCK_INSTANCES = 150;
	const SESSION_TTL = 10 * MINUTE_IN_SECONDS;
	const PROFILE_TTL = DAY_IN_SECONDS;

	private static $active = false;
	private static $token = '';
	private static $session = array();
	private static $run_number = 1;
	private static $request_start = 0;
	private static $collector_started = 0;
	private static $collector_duration = 0;
	private static $milestones = array();
	private static $hook_starts = array();
	private static $hook_durations = array();
	private static $block_stack = array();
	private static $blocks = array();
	private static $block_instances = array();
	private static $block_sequence = 0;
	private static $queries = array();
	private static $query_overflow_count = 0;
	private static $query_profile = null;
	private static $template = '';
	private static $runtime_save_queries = false;
	private static $custom_logs = array();
	private static $custom_spans = array();
	private static $open_spans = array();

	/**
	 * Register the REST controller and activate collectors only for tokenized requests.
	 */

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_rest_routes' ) );

		$token = isset( $_SERVER['HTTP_X_WPHAVE_PROFILE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_WPHAVE_PROFILE'] ) ) : '';
		if( ! preg_match( '/^[a-f0-9]{32}$/', $token ) ) {
			return;
		}

		$session = get_transient( self::SESSION_PREFIX . hash( 'sha256', $token ) );
		if( ! is_array( $session ) || empty( $session['remaining'] ) || empty( $session['userId'] ) ) {
			return;
		}
		if( ! self::request_matches_session_target( $session ) ) {
			return;
		}

		self::$active = true;
		self::$token = $token;
		self::$session = $session;
		$requested_run = isset( $_SERVER['HTTP_X_WPHAVE_PROFILE_RUN'] ) ? absint( $_SERVER['HTTP_X_WPHAVE_PROFILE_RUN'] ) : 0;
		$derived_run = max( 1, (int) ( $session['totalRuns'] ?? 1 ) - (int) $session['remaining'] + 1 );
		self::$run_number = $requested_run >= 1 && $requested_run <= (int) ( $session['totalRuns'] ?? 1 ) ? $requested_run : $derived_run;
		self::$request_start = isset( $_SERVER['REQUEST_TIME_FLOAT'] ) ? (float) $_SERVER['REQUEST_TIME_FLOAT'] : microtime( true );
		self::$collector_started = microtime( true );
		self::$milestones['profilerLoaded'] = self::elapsed();

		self::enable_query_details();
		self::register_collectors();
	}

	/**
	 * Enable WordPress query logging only inside this authorized profiler request.
	 * Existing bootstrap queries remain outside timing coverage and are disclosed
	 * through timedCount and coveragePercent.
	 */
	private static function enable_query_details() {
		if( ! defined( 'SAVEQUERIES' ) ) {
			define( 'SAVEQUERIES', true );
			self::$runtime_save_queries = true;
		}
	}

	/**
	 * Register profiler management endpoints.
	 */

	public static function register_rest_routes() {
		register_rest_route( 'wphave/v1', '/request-profiler', array(
			'methods' => WP_REST_Server::READABLE,
			'callback' => array( __CLASS__, 'get_profiles_endpoint' ),
			'permission_callback' => array( __CLASS__, 'can_manage' ),
			'args' => array(
				'measurementId' => array(
					'type' => 'string',
					'required' => false,
				),
				'details' => array(
					'type' => 'boolean',
					'default' => true,
				),
				'url' => array(
					'type' => 'string',
					'required' => false,
				),
			),
		) );

		register_rest_route( 'wphave/v1', '/request-profiler/start', array(
			'methods' => WP_REST_Server::CREATABLE,
			'callback' => array( __CLASS__, 'start_session_endpoint' ),
			'permission_callback' => array( __CLASS__, 'can_manage' ),
			'args' => array(
				'url' => array(
					'type' => 'string',
					'required' => true,
				),
				'runs' => array(
					'type' => 'integer',
					'default' => 3,
					'minimum' => 1,
					'maximum' => self::MAX_RUNS,
				),
				'capabilities' => array(
					'type' => 'boolean',
					'default' => false,
				),
			),
		) );

		register_rest_route( 'wphave/v1', '/request-profiler/stop', array(
			'methods' => WP_REST_Server::CREATABLE,
			'callback' => array( __CLASS__, 'stop_session_endpoint' ),
			'permission_callback' => array( __CLASS__, 'can_manage' ),
			'args' => array(
				'token' => array(
					'type' => 'string',
					'required' => true,
				),
			),
		) );

		register_rest_route( 'wphave/v1', '/request-profiler/clear', array(
			'methods' => WP_REST_Server::CREATABLE,
			'callback' => array( __CLASS__, 'clear_profiles_endpoint' ),
			'permission_callback' => array( __CLASS__, 'can_manage' ),
		) );
	}

	/**
	 * Restrict profiles and bearer-token creation to system-status administrators.
	 */

	public static function can_manage() {
		$feature_enabled = (
			function_exists( 'wphave_request_profiler_feature_enabled' )
			&& wphave_request_profiler_feature_enabled()
		) || (
			function_exists( 'wphave_request_inspector_feature_enabled' )
			&& wphave_request_inspector_feature_enabled()
		);

		return $feature_enabled
			&& is_user_logged_in()
			&& ( current_user_can( 'wphave_view_system_status' ) || current_user_can( 'manage_options' ) );
	}

	/**
	 * Report whether the current request carries a valid, target-bound profiling
	 * session. Runtime services may use this to avoid short-circuiting WordPress
	 * before the profiler has collected a complete lifecycle.
	 *
	 * @return bool Whether profiling is active for the current request.
	 */

	public static function is_active() {
		return self::$active;
	}

	/**
	 * Record a bounded, value-free developer diagnostic during an active capture.
	 */
	public static function log( $level, $message, $context = array() ) {
		if( ! self::$active || count( self::$custom_logs ) >= 100 ) {
			return;
		}
		$allowed_levels = array( 'debug', 'info', 'warning', 'error' );
		$level = sanitize_key( (string) $level );
		$origin = WPHAVE_Request_Profiler_Diagnostics::source_descriptor_from_trace();
		self::$custom_logs[] = array(
			'level' => in_array( $level, $allowed_levels, true ) ? $level : 'info',
			'message' => WPHAVE_Security_Redactor::error_text( $message, 500 ),
			'contextKeys' => array_slice( array_values( array_map( 'sanitize_key', array_keys( is_array( $context ) ? $context : array() ) ) ), 0, 30 ),
			'component' => $origin['component'],
			'source' => $origin['source'],
			'atMs' => self::elapsed(),
		);
	}

	public static function start_span( $name ) {
		if( ! self::$active || count( self::$open_spans ) >= 50 ) {
			return '';
		}
		$id = substr( hash( 'sha256', wp_generate_uuid4() ), 0, 16 );
		self::$open_spans[$id] = array(
			'name' => substr( sanitize_text_field( (string) $name ), 0, 180 ),
			'started' => microtime( true ),
			'startMs' => self::elapsed(),
		);
		return $id;
	}

	public static function end_span( $id ) {
		$id = sanitize_key( (string) $id );
		if( ! self::$active || ! isset( self::$open_spans[$id] ) || count( self::$custom_spans ) >= 50 ) {
			return;
		}
		$span = self::$open_spans[$id];
		unset( self::$open_spans[$id] );
		$origin = WPHAVE_Request_Profiler_Diagnostics::source_descriptor_from_trace();
		self::$custom_spans[] = array(
			'name' => $span['name'],
			'startMs' => $span['startMs'],
			'endMs' => self::elapsed(),
			'durationMs' => round( max( 0, microtime( true ) - $span['started'] ) * 1000, 2 ),
			'component' => $origin['component'],
			'source' => $origin['source'],
		);
	}

	/**
	 * Return stored profiles and aggregate information for the profiler screen.
	 */

	public static function get_profiles_endpoint( WP_REST_Request $request ) {
		$authorization = self::require_manage_access();
		if( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$include_details = rest_sanitize_boolean( $request->get_param( 'details' ) );
		$measurement_id = sanitize_text_field( (string) $request->get_param( 'measurementId' ) );
		$profiles = $include_details
			? self::get_profiles( $measurement_id )
			: self::get_profile_summaries();
		$target_url = (string) $request->get_param( 'url' );
		if( $target_url ) {
			$target_url = self::normalize_target_url( $target_url );
			if( is_wp_error( $target_url ) ) {
				return $target_url;
			}
			$target_key = self::sanitize_profile_url( $target_url );
			$profiles = array_values( array_filter( $profiles, function( $profile ) use ( $target_key ) {
				return hash_equals( $target_key, self::sanitize_profile_url( (string) ( $profile['url'] ?? '' ) ) );
			} ) );
			$profiles = array_slice( $profiles, -self::MAX_TARGET_PROFILES );
		}
		if( $measurement_id ) {
			// FILTER INVARIANT: Measurement selection applies equally to compact and
			// detailed contracts. It must not depend on detail-only aggregate state.
			$profiles = array_values( array_filter(
				$profiles,
				fn( $profile ) => hash_equals(
					$measurement_id,
					(string) ( $profile['measurementId'] ?? '' )
				)
			) );
		}
		$measurements = $include_details ? self::build_measurements( $profiles ) : array();

		// AUTHORIZATION INVARIANT: Profile archives, summaries and URL normalization
		// cross filterable storage and routing boundaries. Revalidate live diagnostic
		// authority after collection and immediately before releasing any projection.
		$authorization = self::require_manage_access();
		if( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		return self::private_response( array(
			'generatedAt' => gmdate( 'c' ),
			'profiles' => array_values( $profiles ),
			'summary' => self::build_summary( $profiles ),
			'measurements' => $include_details ? $measurements : array(),
			'limits' => array(
				'maxProfiles' => self::MAX_PROFILES,
				'maxArchiveBytes' => self::MAX_ARCHIVE_BYTES,
				'maxTargetProfiles' => self::MAX_TARGET_PROFILES,
				'maxRuns' => self::MAX_RUNS,
				'sessionTtl' => self::SESSION_TTL,
				'profileTtl' => self::PROFILE_TTL,
			),
		) );
	}

	/**
	 * Return only the fields required by the always-visible inspector bar.
	 * Detailed diagnostics are fetched lazily when the panel is opened.
	 */
	private static function profile_summary( $profile ) {
		return array(
			'id' => (string) ( $profile['id'] ?? '' ),
			'measurementId' => (string) ( $profile['measurementId'] ?? '' ),
			'timestamp' => (string) ( $profile['timestamp'] ?? '' ),
			'method' => (string) ( $profile['method'] ?? 'GET' ),
			'url' => (string) ( $profile['url'] ?? '/' ),
			'status' => (int) ( $profile['status'] ?? 200 ),
			'durationMs' => (float) ( $profile['durationMs'] ?? 0 ),
			'memoryPeakBytes' => (int) ( $profile['memoryPeakBytes'] ?? 0 ),
			'queryProfile' => array(
				'count' => (int) ( $profile['queryProfile']['count'] ?? 0 ),
			),
			'health' => self::profile_health_summary( $profile ),
		);
	}

	/**
	 * Reduce detailed diagnostics to bounded counters for the persistent bar.
	 *
	 * The compact endpoint must not expose messages, paths, query text, or remote
	 * endpoints. It only reports enough information to make failures visible
	 * before the user opens the lazily loaded analysis panel.
	 */
	private static function profile_health_summary( $profile ) {
		$critical = 0;
		$warnings = 0;
		$categories = array(
			'php' => 0,
			'http' => 0,
			'database' => 0,
			'request' => 0,
		);

		$status = (int) ( $profile['status'] ?? 0 );
		if( $status >= 500 ) {
			++$critical;
			++$categories['request'];
		} elseif( $status >= 400 ) {
			++$warnings;
			++$categories['request'];
		}

		$php_errors = is_array( $profile['diagnostics']['phpErrors'] ?? null )
			? $profile['diagnostics']['phpErrors']
			: array();
		foreach( $php_errors as $php_error ) {
			if( ! empty( $php_error['fatal'] ) ) {
				++$critical;
			} else {
				++$warnings;
			}
			++$categories['php'];
		}

		$http_requests = is_array( $profile['diagnostics']['httpRequests'] ?? null )
			? $profile['diagnostics']['httpRequests']
			: array();
		foreach( $http_requests as $http_request ) {
			$http_status = (int) ( $http_request['status'] ?? 0 );
			if( ! empty( $http_request['errorCode'] ) || $http_status >= 500 ) {
				++$critical;
				++$categories['http'];
			} elseif( $http_status >= 400 ) {
				++$warnings;
				++$categories['http'];
			}
		}

		$queries = is_array( $profile['queryProfile']['items'] ?? null )
			? $profile['queryProfile']['items']
			: array();
		foreach( $queries as $query ) {
			$duration = (float) ( $query['durationMs'] ?? 0 );
			if( $duration >= 50 ) {
				++$critical;
				++$categories['database'];
			} elseif( $duration >= 10 ) {
				++$warnings;
				++$categories['database'];
			}
		}

		$n_plus_one_candidates = is_array( $profile['queryProfile']['nPlusOneCandidates'] ?? null )
			? $profile['queryProfile']['nPlusOneCandidates']
			: array();
		foreach( $n_plus_one_candidates as $candidate ) {
			++$warnings;
			++$categories['database'];
		}

		return array(
			'version' => 2,
			'critical' => $critical,
			'warnings' => $warnings,
			'total' => $critical + $warnings,
			'categories' => $categories,
		);
	}

	/**
	 * Prevent browsers and shared proxies from caching private diagnostics or
	 * short-lived bearer tokens returned by profiler management endpoints.
	 */
	private static function private_response( $data ) {
		$response = rest_ensure_response( $data );
		$response->header( 'Cache-Control', 'no-store, no-cache, must-revalidate, private' );
		$response->header( 'Pragma', 'no-cache' );
		$response->header( 'X-Content-Type-Options', 'nosniff' );
		return $response;
	}

	/**
	 * Create a bounded recording session and return its tokenized URL.
	 */

	public static function start_session_endpoint( WP_REST_Request $request ) {
		$authorization = self::require_manage_access();
		if( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$url = self::normalize_target_url( (string) $request->get_param( 'url' ) );
		if( is_wp_error( $url ) ) {
			return $url;
		}

		$runs = min( self::MAX_RUNS, max( 1, absint( $request->get_param( 'runs' ) ) ) );
		try {
			$token = bin2hex( random_bytes( 16 ) );
		} catch( Throwable $error ) {
			return new WP_Error( 'wphave_profiler_token_unavailable', __( 'A secure profiling session could not be created.', 'wphave' ), array( 'status' => 500 ) );
		}
		$measurement_id = wp_generate_uuid4();
		$session = array(
			'measurementId' => $measurement_id,
			'userId' => get_current_user_id(),
			'createdAt' => time(),
			'expiresAt' => time() + self::SESSION_TTL,
			'remaining' => $runs,
			'totalRuns' => $runs,
			'targetUrl' => $url,
			'captureCapabilities' => (bool) $request->get_param( 'capabilities' ),
		);

		// AUTHORIZATION INVARIANT: Target normalization resolves filterable WordPress
		// origins. Revalidate live profiler authority after that boundary and directly
		// before persisting a bearer session that can activate privileged diagnostics.
		$authorization = self::require_manage_access();
		if( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		if( ! set_transient( self::SESSION_PREFIX . hash( 'sha256', $token ), $session, self::SESSION_TTL ) ) {
			return new WP_Error( 'wphave_profiler_session_unavailable', __( 'The profiling session could not be created.', 'wphave' ), array( 'status' => 500 ) );
		}

		return self::private_response( array(
			'token' => $token,
			'measurementId' => $measurement_id,
			'targetUrl' => $url,
			'requestedRuns' => $runs,
			'remaining' => $runs,
			'expiresAt' => gmdate( 'c', $session['expiresAt'] ),
		) );
	}

	/**
	 * Stop one recording session without affecting captured profiles.
	 */

	public static function stop_session_endpoint( WP_REST_Request $request ) {
		$authorization = self::require_manage_access();
		if( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$token = sanitize_text_field( (string) $request->get_param( 'token' ) );
		// AUTHORIZATION INVARIANT: Token normalization invokes WordPress filters.
		// Repeat live profiler authority after normalization and immediately before
		// acquiring the mutation lock or deleting the owner-bound bearer session.
		$authorization = self::require_manage_access();
		if( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		if( preg_match( '/^[a-f0-9]{32}$/', $token ) ) {
			$session_key = self::SESSION_PREFIX . hash( 'sha256', $token );
			$result = WPHAVE_Option_Mutations::with_lock( $session_key, static function() use ( $session_key ) {
				$session = get_transient( $session_key );
				if( is_array( $session ) && (int) ( $session['userId'] ?? 0 ) === get_current_user_id() ) {
					delete_transient( $session_key );
				}

				return true;
			} );
			if( is_wp_error( $result ) ) {
				return $result;
			}
		}

		return self::private_response( array( 'stopped' => true ) );
	}

	/**
	 * Clear profiler history without touching Performance Monitor data.
	 */

	public static function clear_profiles_endpoint() {
		$authorization = self::require_manage_access();
		if( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$result = WPHAVE_Option_Mutations::with_lock( self::OPTION_KEY, static function() {
			// AUTHORIZATION INVARIANT: Archive reads and writes invoke WordPress option
			// filters. Each transformation revalidates live profiler authority inside
			// the held lock and immediately before its corresponding option commit.
			$profiles = WPHAVE_Option_Mutations::mutate( self::OPTION_KEY, static function() {
				$authorization = self::require_manage_access();
				return is_wp_error( $authorization ) ? $authorization : array();
			} );
			if( is_wp_error( $profiles ) ) {
				return $profiles;
			}

			$summary = WPHAVE_Option_Mutations::mutate( self::SUMMARY_OPTION_KEY, static function() {
				$authorization = self::require_manage_access();
				return is_wp_error( $authorization ) ? $authorization : array();
			} );
			if( is_wp_error( $summary ) ) {
				set_transient( self::SUMMARY_DIRTY_KEY, 1, self::PROFILE_TTL );
				return $summary;
			}

			delete_transient( self::SUMMARY_DIRTY_KEY );

			return true;
		} );
		if( is_wp_error( $result ) ) {
			return $result;
		}
		$authorization = self::require_manage_access();
		if( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		return self::private_response( array(
			'generatedAt' => gmdate( 'c' ),
			'cleared' => true,
			'profiles' => array(),
			'summary' => self::build_summary( array() ),
			'measurements' => array(),
			'limits' => array(
				'maxProfiles' => self::MAX_PROFILES,
				'maxArchiveBytes' => self::MAX_ARCHIVE_BYTES,
				'maxTargetProfiles' => self::MAX_TARGET_PROFILES,
				'maxRuns' => self::MAX_RUNS,
				'sessionTtl' => self::SESSION_TTL,
				'profileTtl' => self::PROFILE_TTL,
			),
		) );
	}

	private static function require_manage_access() {
		// AUTHORIZATION INVARIANT: The REST permission callback is only an early
		// transport gate. Every public management callback must re-authorize before
		// diagnostic disclosure, token/session handling, locks, or global deletion.
		if( self::can_manage() ) {
			return true;
		}

		return new WP_Error(
			'wphave_request_profiler_forbidden',
			__( 'You are not allowed to manage request profiles.', 'wphave' ),
			array( 'status' => 403 )
		);
	}

	/**
	 * Validate a same-site frontend or wp-admin target.
	 */

	private static function normalize_target_url( $url ) {
		$url = esc_url_raw( trim( $url ) );
		if( ! $url ) {
			return new WP_Error( 'wphave_profiler_invalid_url', __( 'Enter a valid URL to profile.', 'wphave' ), array( 'status' => 400 ) );
		}

		$target = wp_parse_url( $url );
		$allowed_origins = array( wp_parse_url( home_url( '/' ) ), wp_parse_url( admin_url( '/' ) ) );
		$origin_allowed = array_filter( $allowed_origins, fn( $origin ) => self::origins_match( $target, $origin ) );
		// SECURITY INVARIANT: Profiler targets are active authenticated requests, so
		// same-origin alone is insufficient. Credentials and action-bearing WordPress
		// endpoints are rejected before a capture session can be issued.
		if(
			! is_array( $target )
			|| ! $origin_allowed
			|| isset( $target['user'] )
			|| isset( $target['pass'] )
			|| self::is_unsafe_capture_target( $target )
		) {
			return new WP_Error( 'wphave_profiler_external_url', __( 'Only URLs from this WordPress installation can be profiled.', 'wphave' ), array( 'status' => 400 ) );
		}

		return preg_replace( '/#.*$/', '', $url );
	}

	/**
	 * Reject targets that may execute authenticated WordPress actions. The UI
	 * applies the same check, but this server boundary remains authoritative.
	 */
	private static function is_unsafe_capture_target( $target ) {
		$path = strtolower( (string) ( $target['path'] ?? '/' ) );
		$basename = basename( $path );
		if( in_array( $basename, array( 'admin-post.php', 'admin-ajax.php', 'wp-login.php', 'xmlrpc.php' ), true ) ) {
			return true;
		}

		$query = array();
		parse_str( (string) ( $target['query'] ?? '' ), $query );
		foreach( array_keys( $query ) as $key ) {
			$key = strtolower( (string) $key );
			if(
				'action' === $key
				|| 'security' === $key
				|| 'nonce' === $key
				|| '_wpnonce' === $key
				|| '_ajax_nonce' === $key
				|| str_ends_with( $key, '_nonce' )
			) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Compare URL origins while respecting explicit and default ports.
	 */

	private static function origins_match( $target, $allowed ) {
		if( ! is_array( $target ) || ! is_array( $allowed ) ) {
			return false;
		}
		$target_host = strtolower( (string) ( $target['host'] ?? '' ) );
		$allowed_host = strtolower( (string) ( $allowed['host'] ?? '' ) );
		$target_scheme = strtolower( (string) ( $target['scheme'] ?? '' ) );
		$allowed_scheme = strtolower( (string) ( $allowed['scheme'] ?? '' ) );
		$target_port = (int) ( $target['port'] ?? ( $target_scheme === 'https' ? 443 : 80 ) );
		$allowed_port = (int) ( $allowed['port'] ?? ( $allowed_scheme === 'https' ? 443 : 80 ) );

		return $target_host
			&& hash_equals( $allowed_host, $target_host )
			&& hash_equals( $allowed_scheme, $target_scheme )
			&& $target_port === $allowed_port;
	}

	/**
	 * Keep a bearer token scoped to the exact URL authorized by its creator.
	 */

	private static function request_matches_session_target( $session ) {
		$target = wp_parse_url( (string) ( $session['targetUrl'] ?? '' ) );
		$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		$current = wp_parse_url( $request_uri );
		if( ! is_array( $target ) || ! is_array( $current ) ) {
			return false;
		}

		// parse_str() normalizes dots, spaces, duplicate keys and array notation.
		// Compare the raw query so the bearer token stays bound to one exact URL.
		return ( $target['path'] ?? '/' ) === ( $current['path'] ?? '/' )
			&& (string) ( $target['query'] ?? '' ) === (string) ( $current['query'] ?? '' );
	}

	/**
	 * Attach detailed collectors only after a valid recording token was resolved.
	 */

	private static function register_collectors() {
		WPHAVE_Request_Profiler_Diagnostics::start();
		WPHAVE_Request_Profiler_WordPress_Diagnostics::start( ! empty( self::$session['captureCapabilities'] ) );
		if( class_exists( 'WPHAVE_Request_Inspector_Test_Signals' ) ) {
			WPHAVE_Request_Inspector_Test_Signals::consume_and_attach(
				(int) ( self::$session['userId'] ?? 0 )
			);
		}
		foreach( array( 'init', 'wp', 'template_redirect', 'wp_enqueue_scripts', 'wp_head', 'wp_footer' ) as $hook ) {
			add_action( $hook, function() use ( $hook ) {
				self::start_hook( $hook );
			}, PHP_INT_MIN );
			add_action( $hook, function() use ( $hook ) {
				self::end_hook( $hook );
			}, PHP_INT_MAX );
		}

		add_filter( 'render_block_data', array( __CLASS__, 'start_block' ), PHP_INT_MIN, 3 );
		add_filter( 'render_block', array( __CLASS__, 'end_block' ), PHP_INT_MAX, 3 );
		add_filter( 'the_content', array( __CLASS__, 'start_content' ), 8 );
		add_filter( 'the_content', array( __CLASS__, 'end_content' ), PHP_INT_MAX );
		add_filter( 'template_include', array( __CLASS__, 'capture_template' ), PHP_INT_MAX );
		// Keep tokenized measurements independent from tools that clear wpdb's public query log.
		add_filter( 'log_query_custom_data', array( __CLASS__, 'capture_query' ), PHP_INT_MAX, 5 );
		// Snapshot before shutdown dispatchers such as Query Monitor cease and clear wpdb's query log.
		add_action( 'shutdown', array( __CLASS__, 'snapshot_query_profile' ), PHP_INT_MIN );
		add_action( 'shutdown', array( __CLASS__, 'finish' ), PHP_INT_MAX );
	}

	private static function start_hook( $hook ) {
		$started = microtime( true );
		self::$milestones[$hook . 'Start'] = self::elapsed();
		self::$hook_starts[$hook] = microtime( true );
		self::$collector_duration += microtime( true ) - $started;
	}

	private static function end_hook( $hook ) {
		$started = microtime( true );
		$hook_started = self::$hook_starts[$hook] ?? $started;
		self::$hook_durations[$hook] = round( max( 0, ( $started - $hook_started ) * 1000 ), 2 );
		self::$milestones[$hook . 'End'] = self::elapsed();
		self::$collector_duration += microtime( true ) - $started;
	}

	public static function start_content( $content ) {
		self::$hook_starts['the_content'] = microtime( true );
		return $content;
	}

	public static function end_content( $content ) {
		if( isset( self::$hook_starts['the_content'] ) ) {
			$duration = round( max( 0, ( microtime( true ) - self::$hook_starts['the_content'] ) * 1000 ), 2 );
			self::$hook_durations['the_content'] = max( (float) ( self::$hook_durations['the_content'] ?? 0 ), $duration );
		}
		return $content;
	}

	/**
	 * Capture a portable template label without persisting an absolute server path.
	 *
	 * @param string $template Resolved WordPress template path.
	 * @return string Unmodified template path.
	 */
	public static function capture_template( $template ) {
		self::$template = self::template_label( $template );
		return $template;
	}

	/**
	 * Start one inclusive block span. Nested block time remains part of its parent.
	 */

	public static function start_block( $parsed_block ) {
		$started = microtime( true );
		$block_name = isset( $parsed_block['blockName'] ) && is_string( $parsed_block['blockName'] ) ? sanitize_text_field( $parsed_block['blockName'] ) : '';
		self::$block_stack[] = array(
			// A null blockName represents freeform HTML in parse_blocks(), not a
			// rendered block instance. Keep its span for stack symmetry only.
			'name' => $block_name,
			'started' => $started,
			'depth' => count( self::$block_stack ),
			'id' => ++self::$block_sequence,
			'parentId' => self::$block_stack ? (int) ( end( self::$block_stack )['id'] ?? 0 ) : 0,
			'attributeKeys' => array_slice( array_values( array_map( 'sanitize_key', array_keys( is_array( $parsed_block['attrs'] ?? null ) ? $parsed_block['attrs'] : array() ) ) ), 0, 40 ),
		);
		self::$collector_duration += microtime( true ) - $started;
		return $parsed_block;
	}

	/**
	 * Complete the current inclusive block span and aggregate it by block type.
	 */

	public static function end_block( $block_content, $block, $instance = null ) {
		$collector_started = microtime( true );
		$span = array_pop( self::$block_stack );
		$fallback_name = isset( $block['blockName'] ) && is_string( $block['blockName'] ) ? sanitize_text_field( $block['blockName'] ) : '';
		$name = is_array( $span ) ? $span['name'] : $fallback_name;
		$duration = is_array( $span ) ? max( 0, ( $collector_started - $span['started'] ) * 1000 ) : 0;
		$depth = is_array( $span ) ? (int) $span['depth'] : 0;

		if( ! $name ) {
			self::$collector_duration += microtime( true ) - $collector_started;
			return $block_content;
		}

		if( ! isset( self::$blocks[$name] ) ) {
			self::$blocks[$name] = array(
				'name' => $name,
				'count' => 0,
				'durationMs' => 0,
				'maxDurationMs' => 0,
				'maxDepth' => 0,
			);
		}

		self::$blocks[$name]['count']++;
		self::$blocks[$name]['durationMs'] += $duration;
		self::$blocks[$name]['maxDurationMs'] = max( self::$blocks[$name]['maxDurationMs'], $duration );
		self::$blocks[$name]['maxDepth'] = max( self::$blocks[$name]['maxDepth'], $depth );
		if( count( self::$block_instances ) < self::MAX_BLOCK_INSTANCES ) {
			$registry = class_exists( 'WP_Block_Type_Registry' ) ? WP_Block_Type_Registry::get_instance() : null;
			$registered = $registry ? $registry->get_registered( $name ) : null;
			$callback = is_object( $registered ) ? ( $registered->render_callback ?? null ) : null;
			$descriptor = WPHAVE_Request_Profiler_Diagnostics::describe_callback( $callback );
			self::$block_instances[] = array(
				'id' => (int) ( $span['id'] ?? 0 ),
				'parentId' => (int) ( $span['parentId'] ?? 0 ),
				'depth' => $depth,
				'name' => $name,
				'durationMs' => round( $duration, 2 ),
				'attributeKeys' => (array) ( $span['attributeKeys'] ?? array() ),
				'contextKeys' => is_object( $instance ) ? array_slice( array_values( array_map( 'sanitize_key', array_keys( (array) ( $instance->context ?? array() ) ) ) ), 0, 40 ) : array(),
				'renderCallback' => $descriptor['callback'],
				'component' => $descriptor['component'],
				'source' => $descriptor['source'],
				'innerHtmlBytes' => strlen( (string) ( $block['innerHTML'] ?? '' ) ),
			);
		}
		self::$collector_duration += microtime( true ) - $collector_started;

		return $block_content;
	}

	/**
	 * Persist the completed request once and consume one session run.
	 */

	public static function finish() {
		if( ! self::$active ) {
			return;
		}
		if( ! self::is_capture_complete() ) {
			return;
		}

		$finish_started = microtime( true );
		$total_duration = round( max( 0, ( $finish_started - self::$request_start ) * 1000 ), 2 );
		$blocks = array_values( array_map( function( $block ) {
			$block['durationMs'] = round( (float) $block['durationMs'], 2 );
			$block['maxDurationMs'] = round( (float) $block['maxDurationMs'], 2 );
			$block['averageDurationMs'] = $block['count'] ? round( $block['durationMs'] / $block['count'], 2 ) : 0;
			return $block;
		}, self::$blocks ) );
		usort( $blocks, fn( $a, $b ) => $b['durationMs'] <=> $a['durationMs'] );

		$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		$status = function_exists( 'http_response_code' ) ? (int) http_response_code() : 200;
		$request = self::get_request_summary( $request_uri );
		$response = self::get_response_summary( $status, $total_duration );
		$route = self::get_route_summary();
		$authorization = self::get_authorization_summary();
		$events = self::get_event_summary();
		$diagnostics = WPHAVE_Request_Profiler_Diagnostics::snapshot();
		$wordpress_diagnostics = WPHAVE_Request_Profiler_WordPress_Diagnostics::snapshot();
		$profile = array(
			'id' => wp_generate_uuid4(),
			'measurementId' => sanitize_text_field( (string) ( self::$session['measurementId'] ?? '' ) ),
			'runNumber' => self::$run_number,
			'requestedRuns' => (int) ( self::$session['totalRuns'] ?? 1 ),
			'timestamp' => gmdate( 'c' ),
			'context' => self::get_context(),
			'method' => isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( sanitize_key( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ) : 'GET',
			'url' => self::sanitize_profile_url( $request_uri ),
			'status' => $status > 0 ? $status : 200,
			'durationMs' => $total_duration,
			'memoryPeakBytes' => memory_get_peak_usage( true ),
			'request' => $request,
			'route' => $route,
			'authorization' => $authorization,
			'response' => $response,
			'timeline' => array(
				'receivedMs' => 0,
				'matchedMs' => self::matched_milestone(),
				'respondedMs' => $total_duration,
			),
			'template' => self::$template,
			'events' => $events,
			'diagnostics' => $diagnostics,
			'wordpressDiagnostics' => $wordpress_diagnostics,
			'developerDiagnostics' => array(
				'logs' => array_values( self::$custom_logs ),
				'spans' => array_values( self::$custom_spans ),
			),
			'queryProfile' => self::$query_profile ?? self::get_query_profile(),
			'hookDurations' => self::$hook_durations,
			'milestones' => self::$milestones,
			'blocks' => array_slice( $blocks, 0, 30 ),
			'blockInstances' => array_values( self::$block_instances ),
			'blockCount' => array_sum( array_column( $blocks, 'count' ) ),
			'collectorOverheadMs' => round( ( self::$collector_duration + microtime( true ) - $finish_started ) * 1000, 2 ),
			'environment' => array(
				'wordpress' => isset( $GLOBALS['wp_version'] ) ? sanitize_text_field( $GLOBALS['wp_version'] ) : '',
				'wphave' => defined( 'WPHAVE_VERSION' ) ? WPHAVE_VERSION : '',
				'gutenberg' => defined( 'GUTENBERG_VERSION' ) ? GUTENBERG_VERSION : '',
				'php' => PHP_VERSION,
				'wpDebug' => defined( 'WP_DEBUG' ) && WP_DEBUG,
				'saveQueries' => defined( 'SAVEQUERIES' ) && SAVEQUERIES,
				'saveQueriesMode' => self::$runtime_save_queries ? 'profiler-session' : ( ( defined( 'SAVEQUERIES' ) && SAVEQUERIES ) ? 'global' : 'disabled' ),
			),
		);

		self::commit_profile( $profile );
	}

	/**
	 * Build a secret-safe request summary. Header values, cookies and bodies are
	 * intentionally excluded from the profile contract.
	 */
	private static function get_request_summary( $request_uri ) {
		$parts = wp_parse_url( (string) $request_uri );
		$query = array();
		parse_str( (string) ( $parts['query'] ?? '' ), $query );

		return array(
			'host' => substr( sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ?? '' ) ), 0, 180 ),
			'path' => WPHAVE_Security_Normalizer::request_path( $request_uri, 300 ),
			'queryParameterCount' => count( $query ),
			'contentType' => substr( sanitize_text_field( wp_unslash( $_SERVER['CONTENT_TYPE'] ?? '' ) ), 0, 160 ),
			'sizeBytes' => max( 0, (int) ( $_SERVER['CONTENT_LENGTH'] ?? 0 ) ),
			'protocol' => substr( sanitize_text_field( wp_unslash( $_SERVER['SERVER_PROTOCOL'] ?? '' ) ), 0, 20 ),
			'isSecure' => is_ssl(),
			'headers' => self::safe_request_headers(),
		);
	}

	private static function safe_request_headers() {
		$map = array(
			'HTTP_ACCEPT' => 'accept',
			'HTTP_ACCEPT_ENCODING' => 'accept-encoding',
			'HTTP_ACCEPT_LANGUAGE' => 'accept-language',
			'HTTP_CACHE_CONTROL' => 'cache-control',
			'HTTP_SEC_FETCH_DEST' => 'sec-fetch-dest',
			'HTTP_SEC_FETCH_MODE' => 'sec-fetch-mode',
			'HTTP_SEC_FETCH_SITE' => 'sec-fetch-site',
			'HTTP_USER_AGENT' => 'user-agent',
		);
		$headers = array();
		foreach( $map as $server_key => $label ) {
			if( isset( $_SERVER[$server_key] ) ) {
				$headers[$label] = substr( sanitize_text_field( wp_unslash( $_SERVER[$server_key] ) ), 0, 240 );
			}
		}
		return $headers;
	}

	/**
	 * Derive response metadata from safe, non-secret response headers.
	 */
	private static function get_response_summary( $status, $duration ) {
		$content_type = '';
		$content_length = 0;
		$safe_headers = array();
		foreach( headers_list() as $header ) {
			list( $name, $value ) = array_pad( explode( ':', $header, 2 ), 2, '' );
			$name = strtolower( trim( $name ) );
			if( in_array( $name, array( 'cache-control', 'content-encoding', 'content-type', 'expires', 'location', 'vary', 'x-redirect-by' ), true ) ) {
				$safe_headers[$name] = 'location' === $name
					? self::sanitize_profile_url( trim( $value ) )
					: substr( sanitize_text_field( trim( $value ) ), 0, 240 );
			}
			if( stripos( $header, 'Content-Type:' ) === 0 ) {
				$content_type = trim( substr( $header, strlen( 'Content-Type:' ) ) );
			}
			if( stripos( $header, 'Content-Length:' ) === 0 ) {
				$content_length = max( 0, (int) trim( substr( $header, strlen( 'Content-Length:' ) ) ) );
			}
		}

		return array(
			'status' => $status > 0 ? (int) $status : 200,
			'contentType' => substr( sanitize_text_field( $content_type ), 0, 160 ),
			'sizeBytes' => $content_length,
			'sizeAvailable' => $content_length > 0,
			'durationMs' => (float) $duration,
			'headers' => $safe_headers,
		);
	}

	/**
	 * Describe WordPress rewrite resolution without exposing query values.
	 */
	private static function get_route_summary() {
		$wp = $GLOBALS['wp'] ?? null;
		$route = '';
		if( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			$route = (string) ( $wp->query_vars['rest_route'] ?? $wp->request ?? '' );
		} elseif( wp_doing_ajax() ) {
			$route = 'admin-ajax.php';
		} elseif( is_admin() ) {
			$route = isset( $GLOBALS['pagenow'] ) ? (string) $GLOBALS['pagenow'] : 'wp-admin';
		} elseif( is_object( $wp ) ) {
			$route = (string) ( $wp->request ?? '' );
		}

		return array(
			'name' => substr( sanitize_text_field( $route ?: '/' ), 0, 240 ),
			'matchedRule' => is_object( $wp ) ? substr( sanitize_text_field( (string) ( $wp->matched_rule ?? '' ) ), 0, 240 ) : '',
			'queryVariableCount' => is_object( $wp ) && is_array( $wp->query_vars ?? null ) ? count( $wp->query_vars ) : 0,
			'template' => self::$template,
			'ajaxAction' => wp_doing_ajax() ? sanitize_key( wphave_request_string( $_REQUEST, 'action' ) ) : '',
			'currentScreen' => is_admin() && function_exists( 'get_current_screen' ) && get_current_screen() ? sanitize_key( get_current_screen()->id ) : '',
			'restRoute' => defined( 'REST_REQUEST' ) && REST_REQUEST ? substr( sanitize_text_field( (string) ( $wp->query_vars['rest_route'] ?? '' ) ), 0, 240 ) : '',
		);
	}

	/**
	 * Store authorization shape only; never persist user identity or cookies.
	 */
	private static function get_authorization_summary() {
		$user = wp_get_current_user();
		$roles = $user instanceof WP_User ? array_values( array_map( 'sanitize_key', $user->roles ) ) : array();

		return array(
			'authenticated' => $user instanceof WP_User && $user->exists(),
			'method' => $user instanceof WP_User && $user->exists() ? 'wordpress-session' : 'anonymous',
			'roles' => array_slice( $roles, 0, 6 ),
		);
	}

	/**
	 * Summarize fired WordPress actions using hook names that cannot contain
	 * paths, email addresses or other freeform values.
	 */
	private static function get_event_summary() {
		$actions = is_array( $GLOBALS['wp_actions'] ?? null ) ? $GLOBALS['wp_actions'] : array();
		$items = array();
		foreach( $actions as $name => $count ) {
			if( ! is_string( $name ) || ! preg_match( '/^[A-Za-z][A-Za-z0-9_.:-]{0,79}$/', $name ) ) {
				continue;
			}
			$items[] = array(
				'name' => $name,
				'count' => max( 0, (int) $count ),
			);
		}

		usort( $items, fn( $a, $b ) => $b['count'] <=> $a['count'] ?: strcmp( $a['name'], $b['name'] ) );

		return array(
			'uniqueCount' => count( $items ),
			'fireCount' => array_sum( array_column( $items, 'count' ) ),
			'items' => array_slice( $items, 0, 60 ),
		);
	}

	private static function matched_milestone() {
		foreach( array( 'wpEnd', 'template_redirectEnd', 'initEnd' ) as $milestone ) {
			if( isset( self::$milestones[$milestone] ) ) {
				return (float) self::$milestones[$milestone];
			}
		}
		return 0;
	}

	private static function template_label( $template ) {
		$template = wp_normalize_path( (string) $template );
		$content_dir = wp_normalize_path( WP_CONTENT_DIR );
		if( $template && strpos( $template, $content_dir . '/' ) === 0 ) {
			return substr( ltrim( substr( $template, strlen( $content_dir ) ), '/' ), 0, 300 );
		}

		return $template ? substr( basename( $template ), 0, 180 ) : '';
	}

	/**
	 * Reject partial shutdown captures. An early response handler can terminate
	 * PHP during init; persisting that request would make an incomplete run look
	 * successful and leave Lifecycle, Blocks and query details misleadingly
	 * empty. The session run remains available so the client can retry it.
	 *
	 * @return bool Whether the universal init phase completed.
	 */

	private static function is_capture_complete() {
		return isset( self::$milestones['initStart'], self::$milestones['initEnd'] )
			&& self::$milestones['initEnd'] >= self::$milestones['initStart'];
	}

	private static function elapsed() {
		return round( max( 0, ( microtime( true ) - self::$request_start ) * 1000 ), 2 );
	}

	private static function get_context() {
		if( wp_doing_ajax() ) {
			return 'ajax';
		}
		if( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return 'rest';
		}
		if( is_admin() ) {
			return function_exists( 'get_current_screen' ) && get_current_screen() ? 'wp-admin' : 'admin';
		}
		return 'frontend';
	}

	/**
	 * Remove the bearer token and truncate the stored request URL.
	 */

	private static function sanitize_profile_url( $url ) {
		return WPHAVE_Security_Normalizer::diagnostic_url( $url, 500 );
	}

	/**
	 * Aggregate query timing and normalized shapes without storing query values.
	 */

	public static function snapshot_query_profile() {
		$started = microtime( true );
		self::$query_profile = self::get_query_profile();
		self::$collector_duration += microtime( true ) - $started;
	}

	/**
	 * Capture query timing while wpdb logs it. Query Monitor may clear the
	 * public wpdb log immediately afterwards for requests without its UI.
	 */

	public static function capture_query( $query_data, $query, $query_time, $query_callstack, $query_start ) {
		$started = microtime( true );
		if( count( self::$queries ) >= self::MAX_CAPTURED_QUERIES ) {
			self::$query_overflow_count++;
			self::$collector_duration += microtime( true ) - $started;
			return $query_data;
		}

		global $wpdb;
		$ended_at = self::elapsed();
		$duration_ms = max( 0, (float) $query_time * 1000 );
		$start_ms = (float) $query_start > 0
			? max( 0, ( (float) $query_start - self::$request_start ) * 1000 )
			: max( 0, $ended_at - $duration_ms );
		self::$queries[] = array(
			(string) $query,
			(float) $query_time,
			sanitize_text_field( (string) $query_callstack ),
			self::query_origin( debug_backtrace( DEBUG_BACKTRACE_IGNORE_ARGS, 40 ) ),
			array(
				'startMs' => round( $start_ms, 2 ),
				'endMs' => round( $ended_at, 2 ),
				'rows' => null,
				'resultRows' => null,
				'error' => '',
			),
		);
		self::$collector_duration += microtime( true ) - $started;
		return $query_data;
	}

	private static function get_query_profile() {
		global $wpdb;

		$save_queries = defined( 'SAVEQUERIES' ) && SAVEQUERIES;
		$queries = self::$queries;
		$profile = array(
			'count' => isset( $wpdb->num_queries ) ? (int) $wpdb->num_queries : 0,
			'timedCount' => count( $queries ),
			'coveragePercent' => isset( $wpdb->num_queries ) && (int) $wpdb->num_queries > 0 ? round( min( 100, count( $queries ) / (int) $wpdb->num_queries * 100 ), 1 ) : 100,
			'durationMs' => 0,
			'items' => array(),
			'repeatedPatterns' => array(),
			'available' => $save_queries,
			'detailsMode' => $save_queries ? ( self::$runtime_save_queries ? 'profiler' : 'global' ) : 'unavailable',
			'itemLimit' => 100,
			'captureLimit' => self::MAX_CAPTURED_QUERIES,
			'captureTruncatedCount' => self::$query_overflow_count,
			'truncatedCount' => 0,
			'lastDatabaseError' => substr( sanitize_text_field( (string) ( $wpdb->last_error ?? '' ) ), 0, 300 ),
		);
		if( ! $save_queries ) {
			return $profile;
		}

		$patterns = array();
		$items = array();
		foreach( $queries as $query ) {
			if( ! is_array( $query ) || count( $query ) < 2 ) {
				continue;
			}
			$duration = (float) $query[1] * 1000;
			$profile['durationMs'] += $duration;
			$normalized = self::normalize_query_shape( (string) $query[0] );
			$fingerprint = substr( hash( 'sha256', $normalized ), 0, 16 );
			$caller = self::query_caller_label( (string) ( $query[2] ?? '' ) );
			$origin = is_array( $query[3] ?? null ) ? $query[3] : array();
			if(
				'plugin:query-monitor' === ( $origin['component'] ?? '' )
				&& preg_match( '/\bWPHAVE_/i', $caller )
			) {
				$origin = array(
					'component' => 'plugin:wphave',
					'source' => '',
				);
			}
			$metadata = is_array( $query[4] ?? null ) ? $query[4] : array();
			$query_type = strtoupper( (string) strtok( ltrim( $normalized ), " \t\r\n" ) );
			$items[] = array(
				'fingerprint' => $fingerprint,
				'pattern' => substr( $normalized, 0, 500 ),
				'durationMs' => round( $duration, 2 ),
				'caller' => $caller,
				'component' => (string) ( $origin['component'] ?? 'unknown' ),
				'source' => (string) ( $origin['source'] ?? '' ),
				'type' => preg_match( '/^[A-Z]{2,16}$/', $query_type ) ? $query_type : 'OTHER',
				'startMs' => isset( $metadata['startMs'] ) ? (float) $metadata['startMs'] : null,
				'endMs' => isset( $metadata['endMs'] ) ? (float) $metadata['endMs'] : null,
				'rowsAffected' => isset( $metadata['rows'] ) ? (int) $metadata['rows'] : null,
				'resultRows' => isset( $metadata['resultRows'] ) ? (int) $metadata['resultRows'] : null,
				'error' => (string) ( $metadata['error'] ?? '' ),
			);
			if( ! isset( $patterns[$fingerprint] ) ) {
				$patterns[$fingerprint] = array(
					'fingerprint' => $fingerprint,
					'pattern' => substr( $normalized, 0, 220 ),
					'count' => 0,
					'durationMs' => 0,
					'callers' => array(),
				);
			}
			$patterns[$fingerprint]['count']++;
			$patterns[$fingerprint]['durationMs'] += $duration;
			if( $caller ) {
				$patterns[$fingerprint]['callers'][$caller] = (int) ( $patterns[$fingerprint]['callers'][$caller] ?? 0 ) + 1;
			}
		}

		$patterns = array_values( array_filter( $patterns, fn( $item ) => $item['count'] > 1 ) );
		usort( $patterns, fn( $a, $b ) => $b['durationMs'] <=> $a['durationMs'] );
		$profile['durationMs'] = round( $profile['durationMs'], 2 );
		usort( $items, fn( $a, $b ) => $b['durationMs'] <=> $a['durationMs'] );
		$profile['items'] = array_slice( $items, 0, 100 );
		$profile['truncatedCount'] = max( 0, count( $items ) - count( $profile['items'] ) );
		$profile['repeatedPatterns'] = array_slice( array_map( function( $item ) {
			$item['durationMs'] = round( $item['durationMs'], 2 );
			arsort( $item['callers'] );
			$item['topCaller'] = $item['callers'] ? (string) array_key_first( $item['callers'] ) : '';
			$item['topCallerCount'] = $item['callers'] ? (int) reset( $item['callers'] ) : 0;
			$item['callerCount'] = count( $item['callers'] );
			unset( $item['callers'] );
			return $item;
		}, $patterns ), 0, 8 );
		$profile['components'] = self::aggregate_queries_by_component( $items );
		$profile['nPlusOneCandidates'] = self::detect_n_plus_one_candidates( $profile['repeatedPatterns'] );

		return $profile;
	}

	private static function aggregate_queries_by_component( $items ) {
		$components = array();
		foreach( $items as $item ) {
			$name = (string) ( $item['component'] ?? 'unknown' );
			if( ! isset( $components[$name] ) ) {
				$components[$name] = array( 'component' => $name, 'count' => 0, 'durationMs' => 0, 'errors' => 0 );
			}
			$components[$name]['count']++;
			$components[$name]['durationMs'] += (float) ( $item['durationMs'] ?? 0 );
			$components[$name]['errors'] += empty( $item['error'] ) ? 0 : 1;
		}
		foreach( $components as &$component ) {
			$component['durationMs'] = round( $component['durationMs'], 2 );
		}
		unset( $component );
		usort( $components, fn( $a, $b ) => $b['durationMs'] <=> $a['durationMs'] );
		return array_values( $components );
	}

	private static function detect_n_plus_one_candidates( $patterns ) {
		$candidates = array_filter( $patterns, function( $pattern ) {
			$count = (int) ( $pattern['count'] ?? 0 );
			$top_caller_count = (int) ( $pattern['topCallerCount'] ?? 0 );
			$top_caller = (string) ( $pattern['topCaller'] ?? '' );
			$dominant_threshold = max( 5, (int) ceil( $count * 0.6 ) );

			return $count >= 5
				&& $top_caller_count >= $dominant_threshold
				&& ! self::is_generic_query_caller( $top_caller )
				&& preg_match( '/^SELECT\b/i', (string) ( $pattern['pattern'] ?? '' ) );
		} );
		return array_values( array_map( function( $pattern ) {
			return array(
				'fingerprint' => $pattern['fingerprint'],
				'pattern' => $pattern['pattern'],
				'count' => $pattern['count'],
				'durationMs' => $pattern['durationMs'],
				'reason' => 'Repeated SELECT shape within one request',
				'confidence' => (int) $pattern['count'] >= 10 ? 'high' : 'medium',
			);
		}, $candidates ) );
	}

	/**
	 * Whether a caller identifies shared WordPress database infrastructure
	 * instead of the application callsite responsible for a query.
	 *
	 * Different option and transient reads normalize to the same SQL shape. A
	 * dominant Core cache wrapper must therefore never establish an N+1 issue on
	 * its own; the pattern remains visible as informational diagnostics instead.
	 *
	 * @param string $caller Query caller label.
	 * @return bool
	 */
	private static function is_generic_query_caller( $caller ) {
		$caller = trim( $caller );

		if ( '' === $caller ) {
			return true;
		}

		return (bool) preg_match(
			'/^(?:QM_DB|wpdb)->|^(?:wp_prime_option_caches|get_option|get_site_option|get_transient|get_site_transient|wp_cache_get)(?:\(|$)/i',
			$caller
		);
	}

	/**
	 * Resolve the first application frame above wpdb to a portable component and
	 * source label. Absolute paths never enter the stored profile.
	 */
	private static function query_origin( $frames ) {
		$core_fallback = null;
		$instrumentation_fallback = null;
		foreach( (array) $frames as $frame ) {
			$file = wp_normalize_path( (string) ( $frame['file'] ?? '' ) );
			if(
				! $file
				|| strpos( $file, '/wp-includes/class-wpdb.php' ) !== false
				|| strpos( $file, '/inc/optimize/monitoring/request-profiler/request-profiler.php' ) !== false
			) {
				continue;
			}

			$descriptor = WPHAVE_Request_Profiler_Diagnostics::source_descriptor( $file );
			// Database drop-ins and profilers proxy wpdb calls. They are useful as
			// a fallback, but attributing every query to the observer hides the
			// plugin, theme, or core feature that actually initiated the query.
			if( 'plugin:query-monitor' === $descriptor['component'] ) {
				$instrumentation_fallback = $instrumentation_fallback ?: $descriptor;
				continue;
			}
			if( 'wordpress-core' === $descriptor['component'] ) {
				$core_fallback = $core_fallback ?: $descriptor;
				continue;
			}
			return $descriptor;
		}

		return $core_fallback ?: (
			$instrumentation_fallback ?: array(
				'component' => 'unknown',
				'source' => '',
			)
		);
	}

	/**
	 * Reduce one SQL statement to a value-free shape safe for storage.
	 */

	private static function normalize_query_shape( $query ) {
		return WPHAVE_Security_Normalizer::sql_shape( $query );
	}

	/**
	 * Prefer the nearest WPHAVE frame so the UI and AI report identify the
	 * responsible feature instead of exposing an unreadable complete stack.
	 */

	private static function query_caller_label( $callstack ) {
		$frames = array_values( array_filter( array_map( 'trim', explode( ',', sanitize_text_field( $callstack ) ) ) ) );
		foreach( array_reverse( $frames ) as $frame ) {
			if( stripos( $frame, 'WPHAVE_' ) !== false || stripos( $frame, 'wphave_' ) !== false ) {
				return substr( $frame, 0, 180 );
			}
		}
		foreach( array_reverse( $frames ) as $frame ) {
			if( stripos( $frame, 'QM_DB->query' ) === false && stripos( $frame, 'wpdb->query' ) === false ) {
				return substr( $frame, 0, 180 );
			}
		}
		return '';
	}

	/**
	 * Persist one unique run and consume its session allowance as one operation.
	 *
	 * CONCURRENCY INVARIANT: Parallel requests for one profiler token may never
	 * consume the same allowance independently or advance the session for a
	 * duplicate run. A lock failure leaves both archive and allowance untouched,
	 * so the client can safely retry the run.
	 *
	 * @param array $profile Completed request profile.
	 * @return array|WP_Error Updated profile archive or lock failure.
	 */
	private static function commit_profile( $profile ) {
		$key = self::SESSION_PREFIX . hash( 'sha256', self::$token );

		return WPHAVE_Option_Mutations::with_lock( $key, function() use ( $profile, $key ) {
			// LIFECYCLE INVARIANT: A stop that wins the session lock is final.
			// In-flight shutdown callbacks may not archive data or resurrect state.
			if( ! is_array( get_transient( $key ) ) ) {
				return new WP_Error(
					'wphave_profiler_session_inactive',
					__( 'The profiling session is no longer active.', 'wphave' ),
					array( 'status' => 409 )
				);
			}

			// STORAGE INVARIANT: Archive and compact projection share one ordering
			// boundary with history clearing, so neither can survive as an orphan.
			$result = WPHAVE_Option_Mutations::with_lock(
				self::OPTION_KEY,
				fn() => self::append_profile( $profile )
			);
			if( is_wp_error( $result ) ) {
				return $result;
			}
			if( empty( $result['inserted'] ) ) {
				return $result['profiles'];
			}

			self::consume_session_run( $key );

			return $result['profiles'];
		} );
	}

	/**
	 * Consume the allowance while the caller owns the profiler-session lock.
	 * A storage failure closes the short-lived session instead of leaving an
	 * already archived run paired with reusable allowance.
	 *
	 * @param string $key Hashed transient key for the active session.
	 */
	private static function consume_session_run( $key ) {
		$current = get_transient( $key );
		if( ! is_array( $current ) ) {
			return;
		}

		$current_remaining = (int) ( $current['remaining'] ?? 0 );
		$remaining = max( 0, min( $current_remaining, (int) ( self::$session['totalRuns'] ?? 1 ) - self::$run_number ) );
		if( $remaining < 1 ) {
			delete_transient( $key );
			return;
		}
		$current['remaining'] = $remaining;
		if( ! set_transient( $key, $current, max( 1, (int) $current['expiresAt'] - time() ) ) ) {
			// DATA-INTEGRITY INVARIANT: Once the archive accepted a run, stale
			// allowance must never survive a failed session-state write.
			delete_transient( $key );
		}
	}

	private static function get_profiles( $measurement_id = '' ) {
		$profiles = get_option( self::OPTION_KEY, array() );
		if( ! is_array( $profiles ) ) {
			return array();
		}

		$profiles = array_filter( $profiles, array( __CLASS__, 'is_profile_fresh' ) );
		if( $measurement_id ) {
			// PERFORMANCE INVARIANT: Normalize only the requested measurement. Stored
			// profiles can contain expensive derived diagnostics that are irrelevant
			// to the capture poll waiting for one newly completed run.
			$profiles = array_filter(
				$profiles,
				fn( $profile ) => hash_equals(
					(string) $measurement_id,
					(string) ( $profile['measurementId'] ?? '' )
				)
			);
		}
		return array_values( array_map( array( __CLASS__, 'normalize_profile' ), $profiles ) );
	}

	/**
	 * Read the small projection used by the bar without loading or unserializing
	 * the potentially multi-megabyte diagnostic archive on every page.
	 */
	private static function get_profile_summaries() {
		$summaries = get_option( self::SUMMARY_OPTION_KEY, null );
		$projection_dirty = (bool) get_transient( self::SUMMARY_DIRTY_KEY );
		$has_current_schema = is_array( $summaries ) && ! array_filter(
			$summaries,
			fn( $summary ) => ! is_array( $summary['health'] ?? null )
				|| 2 !== (int) ( $summary['health']['version'] ?? 0 )
		);
		if( $has_current_schema && ! $projection_dirty ) {
			return array_values( array_filter( $summaries, array( __CLASS__, 'is_profile_fresh' ) ) );
		}

		$fallback = is_array( $summaries )
			? array_values( array_filter( $summaries, array( __CLASS__, 'is_profile_fresh' ) ) )
			: array();
		$result = WPHAVE_Option_Mutations::with_lock( self::OPTION_KEY, static function() {
			// RECOVERY INVARIANT: Reading the canonical archive and publishing its
			// projection share the archive -> summary lock order used by commits and
			// clears. A stale rebuild can therefore never overwrite a newer commit.
			$profiles = self::get_profiles();
			$rebuilt = array_map( array( __CLASS__, 'profile_summary' ), $profiles );

			$stored = WPHAVE_Option_Mutations::mutate(
				self::SUMMARY_OPTION_KEY,
				static fn() => $rebuilt
			);
			if( is_wp_error( $stored ) ) {
				return $stored;
			}

			delete_transient( self::SUMMARY_DIRTY_KEY );

			return $stored;
		} );

		if( is_wp_error( $result ) ) {
			return $fallback;
		}

		return $result;
	}

	private static function is_profile_fresh( $profile ) {
		$timestamp = is_array( $profile ) ? strtotime( (string) ( $profile['timestamp'] ?? '' ) ) : false;
		return $timestamp !== false && $timestamp >= time() - self::PROFILE_TTL;
	}

	/**
	 * Normalize legacy profile fields at the storage boundary so every consumer
	 * receives the current canonical data contract.
	 */

	private static function normalize_profile( $profile ) {
		if( ! is_array( $profile ) ) {
			return array();
		}

		$blocks = is_array( $profile['blocks'] ?? null ) ? $profile['blocks'] : array();
		$profile['blocks'] = array_values( array_filter( $blocks, function( $block ) {
			$name = is_array( $block ) ? trim( (string) ( $block['name'] ?? '' ) ) : '';
			return $name && strtolower( $name ) !== 'unknown';
		} ) );
		$profile['blockCount'] = array_sum( array_map( fn( $block ) => (int) ( $block['count'] ?? 0 ), $profile['blocks'] ) );
		$profile['blockInstances'] = is_array( $profile['blockInstances'] ?? null ) ? array_values( $profile['blockInstances'] ) : array();
		$hook_durations = is_array( $profile['hookDurations'] ?? null ) ? $profile['hookDurations'] : array();
		if( isset( $hook_durations['theContent'] ) ) {
			$hook_durations['the_content'] = max( (float) ( $hook_durations['the_content'] ?? 0 ), (float) $hook_durations['theContent'] );
			unset( $hook_durations['theContent'] );
		}
		$profile['hookDurations'] = $hook_durations;
		$profile['request'] = is_array( $profile['request'] ?? null ) ? $profile['request'] : array(
			'host' => '',
			'path' => (string) ( $profile['url'] ?? '/' ),
			'queryParameterCount' => 0,
			'contentType' => '',
			'sizeBytes' => 0,
			'protocol' => '',
			'isSecure' => false,
		);
		$profile['response'] = is_array( $profile['response'] ?? null ) ? $profile['response'] : array(
			'status' => (int) ( $profile['status'] ?? 200 ),
			'contentType' => '',
			'sizeBytes' => 0,
			'sizeAvailable' => false,
			'durationMs' => (float) ( $profile['durationMs'] ?? 0 ),
		);
		$profile['route'] = is_array( $profile['route'] ?? null ) ? $profile['route'] : array(
			'name' => (string) ( $profile['url'] ?? '/' ),
			'matchedRule' => '',
			'queryVariableCount' => 0,
			'template' => (string) ( $profile['template'] ?? '' ),
		);
		$profile['authorization'] = is_array( $profile['authorization'] ?? null ) ? $profile['authorization'] : array(
			'authenticated' => false,
			'method' => 'unknown',
			'roles' => array(),
		);
		$profile['events'] = is_array( $profile['events'] ?? null ) ? $profile['events'] : array(
			'uniqueCount' => 0,
			'fireCount' => 0,
			'items' => array(),
		);
		$profile['timeline'] = is_array( $profile['timeline'] ?? null ) ? $profile['timeline'] : array(
			'receivedMs' => 0,
			'matchedMs' => (float) ( $profile['milestones']['wpEnd'] ?? 0 ),
			'respondedMs' => (float) ( $profile['durationMs'] ?? 0 ),
		);
		$profile['diagnostics'] = is_array( $profile['diagnostics'] ?? null ) ? $profile['diagnostics'] : array(
			'httpRequests' => array(),
			'phpErrors' => array(),
			'hooks' => array(),
			'assets' => array(
				'scripts' => array(),
				'styles' => array(),
			),
		);
		$profile['queryProfile'] = is_array( $profile['queryProfile'] ?? null ) ? $profile['queryProfile'] : array();
		$profile['queryProfile'] += array(
			'count' => 0,
			'timedCount' => 0,
			'coveragePercent' => 0,
			'durationMs' => 0,
			'items' => array(),
			'repeatedPatterns' => array(),
			'available' => false,
			'detailsMode' => 'unavailable',
			'components' => array(),
			'nPlusOneCandidates' => array(),
			'itemLimit' => 100,
			'captureLimit' => self::MAX_CAPTURED_QUERIES,
			'captureTruncatedCount' => 0,
			'truncatedCount' => 0,
			'lastDatabaseError' => '',
		);
		// Re-evaluate stored profiles so heuristic improvements apply without
		// deleting historical captures or persisting a data migration.
		$profile['queryProfile']['nPlusOneCandidates'] = self::detect_n_plus_one_candidates(
			$profile['queryProfile']['repeatedPatterns']
		);
		$profile['wordpressDiagnostics'] = is_array( $profile['wordpressDiagnostics'] ?? null ) ? $profile['wordpressDiagnostics'] : array();
		$profile['developerDiagnostics'] = is_array( $profile['developerDiagnostics'] ?? null ) ? $profile['developerDiagnostics'] : array(
			'logs' => array(),
			'spans' => array(),
		);
		return $profile;
	}

	private static function append_profile( $profile ) {
		$inserted = false;
		$result = WPHAVE_Option_Mutations::mutate( self::OPTION_KEY, function( $profiles ) use ( $profile, &$inserted ) {
			$profiles = array_values( array_filter( $profiles, array( __CLASS__, 'is_profile_fresh' ) ) );
			$duplicate = array_filter( $profiles, function( $stored_profile ) use ( $profile ) {
				return ( $stored_profile['measurementId'] ?? '' ) === $profile['measurementId'] && (int) ( $stored_profile['runNumber'] ?? 0 ) === $profile['runNumber'];
			} );
			if( $duplicate ) {
				return $profiles;
			}
			$profiles[] = $profile;
			$profiles = self::bound_profile_archive( $profiles );
			if( is_wp_error( $profiles ) ) {
				return $profiles;
			}
			$inserted = true;

			return $profiles;
		} );
		if( is_wp_error( $result ) ) {
			return $result;
		}
		if( ! $inserted ) {
			return array(
				'inserted' => false,
				'profiles' => $result,
			);
		}

		$summary = self::profile_summary( $profile );
		$summary_result = WPHAVE_Option_Mutations::mutate(
			self::SUMMARY_OPTION_KEY,
			fn( $summaries ) => self::synchronize_profile_summaries(
				$summaries,
				$result,
				$summary
			)
		);
		if( is_wp_error( $summary_result ) ) {
			// CACHE INVARIANT: Lock contention may mark a projection stale, but must
			// never delete a concurrently committed summary. The next read rebuilds
			// through the same serialized boundary from the canonical archive.
			set_transient( self::SUMMARY_DIRTY_KEY, 1, self::PROFILE_TTL );
		}

		return array(
			'inserted' => $inserted,
			'profiles' => $result,
		);
	}

	/**
	 * Bound the canonical archive by count and serialized storage size.
	 *
	 * STORAGE INVARIANT: A diagnostics-heavy request may reduce retained history,
	 * but it may never make the shared option grow without limit. Eviction always
	 * removes the oldest complete profile; partial profile truncation would corrupt
	 * the diagnostic contract and make comparisons unreliable.
	 *
	 * @param array $profiles Chronological profile archive.
	 * @return array|WP_Error Bounded archive or an oversized-profile failure.
	 */
	private static function bound_profile_archive( $profiles ) {
		$profiles = array_values( array_slice( $profiles, -self::MAX_PROFILES ) );
		$serialized_profiles = array_map( 'serialize', $profiles );
		while(
			count( $profiles ) > 1
			&& self::serialized_array_size( $serialized_profiles ) > self::MAX_ARCHIVE_BYTES
		) {
			array_shift( $profiles );
			array_shift( $serialized_profiles );
		}

		if( self::serialized_array_size( $serialized_profiles ) > self::MAX_ARCHIVE_BYTES ) {
			return new WP_Error(
				'wphave_profiler_profile_too_large',
				__( 'The completed request profile exceeds the safe diagnostic storage limit.', 'wphave' ),
				array( 'status' => 507 )
			);
		}

		return $profiles;
	}

	/**
	 * Calculate the exact PHP serialization size of a zero-indexed array from
	 * already serialized values.
	 *
	 * PERFORMANCE INVARIANT: Archive eviction may inspect every retained profile,
	 * but it must serialize each diagnostic payload at most once. Re-serializing a
	 * multi-megabyte suffix after every eviction makes storage cleanup quadratic.
	 *
	 * @param array $serialized_values Serialized array values in canonical order.
	 * @return int Exact byte size produced by serialize() for the containing array.
	 */
	private static function serialized_array_size( $serialized_values ) {
		$count = count( $serialized_values );
		$size = strlen( 'a:' . $count . ':{' ) + 1;
		foreach( $serialized_values as $index => $serialized_value ) {
			$size += strlen( 'i:' . $index . ';' ) + strlen( $serialized_value );
		}

		return $size;
	}

	/** Keep the compact projection aligned with the canonical bounded archive. */
	private static function synchronize_profile_summaries( $summaries, $profiles, $summary ) {
		$profile_ids = array_fill_keys(
			array_values( array_filter( array_column( $profiles, 'id' ), 'is_string' ) ),
			true
		);
		$summaries = array_values( array_filter(
			$summaries,
			fn( $stored ) => isset( $profile_ids[(string) ( $stored['id'] ?? '' )] )
				&& ( $stored['id'] ?? '' ) !== $summary['id']
				&& self::is_profile_fresh( $stored )
		) );
		$summaries[] = $summary;

		// PROJECTION INVARIANT: Byte-budget or TTL eviction from the canonical
		// archive removes the corresponding bar row in the same commit workflow.
		return array_values( array_slice( $summaries, -self::MAX_PROFILES ) );
	}

	/**
	 * Derive measurement groups from the bounded flat archive. Keeping one
	 * canonical profile collection avoids nested concurrent option mutations.
	 */

	private static function build_measurements( $profiles ) {
		$measurements = array();
		foreach( $profiles as $profile ) {
			$measurement_id = (string) ( $profile['measurementId'] ?? '' );
			if( ! $measurement_id ) {
				$measurement_id = 'legacy-' . (string) ( $profile['id'] ?? wp_generate_uuid4() );
			}
			if( ! isset( $measurements[$measurement_id] ) ) {
				$measurements[$measurement_id] = array(
					'id' => $measurement_id,
					'targetUrl' => (string) ( $profile['url'] ?? '' ),
					'createdAt' => (string) ( $profile['timestamp'] ?? '' ),
					'requestedRuns' => (int) ( $profile['requestedRuns'] ?? 1 ),
					'profileIds' => array(),
					'profiles' => array(),
				);
			}
			$measurements[$measurement_id]['profileIds'][] = (string) ( $profile['id'] ?? '' );
			$measurements[$measurement_id]['profiles'][] = $profile;
		}

		return array_values( array_map( function( $measurement ) {
			$measurement['completedRuns'] = count( $measurement['profiles'] );
			$measurement['summary'] = self::build_summary( $measurement['profiles'] );
			unset( $measurement['profiles'] );
			return $measurement;
		}, $measurements ) );
	}

	private static function build_summary( $profiles ) {
		$count = count( $profiles );
		$durations = array_map( fn( $profile ) => (float) ( $profile['durationMs'] ?? 0 ), $profiles );
		sort( $durations );
		$median = 0;
		if( $count ) {
			$middle = (int) floor( $count / 2 );
			$median = $count % 2 ? $durations[$middle] : ( $durations[$middle - 1] + $durations[$middle] ) / 2;
		}

		return array(
			'totalProfiles' => $count,
			'medianDurationMs' => round( $median, 2 ),
			'averageDurationMs' => $count ? round( array_sum( $durations ) / $count, 2 ) : 0,
			'peakDurationMs' => $count ? max( $durations ) : 0,
			'latestProfileId' => $count ? (string) ( $profiles[$count - 1]['id'] ?? '' ) : '',
			'latestTimestamp' => $count ? (string) ( $profiles[$count - 1]['timestamp'] ?? '' ) : '',
		);
	}
}

WPHAVE_Request_Profiler::init();
