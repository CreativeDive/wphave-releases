<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * One-shot, non-production diagnostics used to verify the complete Inspector
 * error pipeline without breaking or polluting the rendered response.
 */

final class WPHAVE_Request_Inspector_Test_Signals {

	const TRANSIENT_PREFIX = 'wphave_request_inspector_test_signals_';
	const TTL = 10 * MINUTE_IN_SECONDS;
	const MESSAGE_PREFIX = '[WPHAVE Inspector Test]';

	public static function is_available() {
		$environment = function_exists( 'wp_get_environment_type' ) ? wp_get_environment_type() : 'production';
		return in_array( $environment, array( 'local', 'development', 'staging' ), true )
			|| self::has_trusted_local_site_host();
	}

	public static function arm( $user_id ) {
		$user_id = absint( $user_id );

		// SECURITY INVARIANT: Synthetic PHP diagnostics are available only in trusted
		// non-production environments, are bound to the current authorized user and
		// are consumed once before emission to prevent persistent error loops.
		if(
			! self::is_available()
			|| ! $user_id
			|| get_current_user_id() !== $user_id
			|| ! ( current_user_can( 'wphave_view_system_status' ) || current_user_can( 'manage_options' ) )
		) {
			return false;
		}

		return (bool) set_transient( self::key( $user_id ), '1', self::TTL );
	}

	public static function is_armed( $user_id ) {
		return self::is_available() && (bool) get_transient( self::key( absint( $user_id ) ) );
	}

	/**
	 * Consume the armed state before attaching emitters to an authorized profile.
	 * A failed or repeated request can therefore never create an error loop.
	 */

	public static function consume_and_attach( $user_id ) {
		$user_id = absint( $user_id );
		if( ! self::is_armed( $user_id ) ) {
			return false;
		}

		delete_transient( self::key( $user_id ) );
		add_action( 'init', array( __CLASS__, 'emit' ), PHP_INT_MAX );
		return true;
	}

	public static function emit() {
		trigger_error( self::MESSAGE_PREFIX . ' Safe diagnostic notice.', E_USER_NOTICE );
		trigger_error( self::MESSAGE_PREFIX . ' Safe diagnostic warning.', E_USER_WARNING );
		trigger_error( self::MESSAGE_PREFIX . ' Safe diagnostic deprecation.', E_USER_DEPRECATED );
	}

	public static function is_test_message( $message ) {
		return strpos( (string) $message, self::MESSAGE_PREFIX ) === 0;
	}

	private static function key( $user_id ) {
		return self::TRANSIENT_PREFIX . absint( $user_id );
	}

	/**
	 * Recognize conventional local-development hosts from WordPress' trusted
	 * configured URL instead of the request Host header.
	 */

	private static function has_trusted_local_site_host() {
		$host = strtolower( (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ) );
		if( in_array( $host, array( 'localhost', '127.0.0.1', '::1' ), true ) ) {
			return true;
		}

		return (bool) preg_match( '/\.(?:local|test|localhost)$/', $host );
	}
}
