<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Central authorization policy for the request inspector.
 */

class WPHAVE_Request_Inspector_Access_Policy {

	/**
	 * Check whether the current user may access request diagnostics.
	 *
	 * @return bool Whether access is allowed.
	 */

	public static function can_access() {
		// PRIVACY INVARIANT: Request traces can contain URLs, timing and operational
		// metadata. The feature flag controls availability, never disclosure; an
		// authenticated Site Status capability remains independently required.
		return function_exists( 'wphave_request_inspector_feature_enabled' )
			&& wphave_request_inspector_feature_enabled()
			&& is_user_logged_in()
			&& ( current_user_can( 'wphave_view_system_status' ) || current_user_can( 'manage_options' ) );
	}

	/**
	 * Check whether the current user may run the explicitly enabled inspector.
	 *
	 * @return bool Whether the inspector is enabled.
	 */

	public static function is_enabled() {
		return self::can_access();
	}
}
