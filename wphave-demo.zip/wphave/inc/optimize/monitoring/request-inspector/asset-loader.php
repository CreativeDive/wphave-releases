<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Loads the isolated inspector runtime only for an authorized, opted-in user.
 */

class WPHAVE_Request_Inspector_Asset_Loader {

	/**
	 * Register frontend and WordPress admin hooks.
	 *
	 * @return void
	 */

	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue' ), PHP_INT_MAX );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue' ), PHP_INT_MAX );
	}

	/**
	 * Enqueue the inspector shell and provide only non-sensitive runtime data.
	 *
	 * @return void
	 */

	public static function enqueue() {
		if( ! WPHAVE_Request_Inspector_Access_Policy::is_enabled() ) {
			return;
		}

		wp_enqueue_script( 'wphave-request-inspector' );
		wp_enqueue_style( 'wphave-request-inspector' );

		wp_set_script_translations(
			'wphave-request-inspector',
			'wphave',
			wphave_dir() . 'languages'
		);

		self::enqueue_panel_translations();

		$config = array(
			'adminUrl' => admin_url( '/' ),
			'homeUrl' => home_url( '/' ),
			'nonce' => wp_create_nonce( 'wp_rest' ),
			'restUrl' => esc_url_raw( rest_url( 'wphave/v1/' ) ),
			'currentUrl' => self::current_url(),
			'environment' => wp_get_environment_type(),
			'testSignalsAvailable' => WPHAVE_Request_Inspector_Test_Signals::is_available(),
			'labels' => array(
				'open' => __( 'Open request inspector', 'wphave' ),
				'close' => __( 'Close request inspector', 'wphave' ),
				'capture' => __( 'Capture request', 'wphave' ),
				'capturing' => __( 'Capturing request…', 'wphave' ),
				'noProfile' => __( 'Capture this URL to inspect its request.', 'wphave' ),
				'error' => __( 'The request could not be inspected.', 'wphave' ),
			),
		);

		wp_add_inline_script(
			'wphave-request-inspector',
			'window.WPHAVE_REQUEST_INSPECTOR = ' . wp_json_encode( $config ) . ';',
			'before'
		);
	}

	/**
	 * Load translations for the lazy panel chunk into the shared i18n domain.
	 *
	 * WordPress only attaches a Jed catalog to registered script handles. The
	 * panel remains a webpack-managed lazy chunk. Its content-hashed filename
	 * prevents stale diagnostics after an update, so the matching catalog is
	 * resolved from the built artifact before the entry runs.
	 *
	 * @return void
	 */

	private static function enqueue_panel_translations() {
		$locale = function_exists( 'determine_locale' ) ? determine_locale() : get_locale();
		$locale = sanitize_file_name( (string) $locale );
		$chunks = glob( wphave_dir() . 'build/request-inspector-panel/bundle.*.js' );
		$chunk_path = is_array( $chunks ) && count( $chunks ) === 1 ? reset( $chunks ) : '';
		if( ! $chunk_path ) {
			return;
		}
		$relative_chunk = ltrim( str_replace( wp_normalize_path( wphave_dir() ), '', wp_normalize_path( $chunk_path ) ), '/' );
		$catalog_path = wphave_dir() . 'languages/wphave-' . $locale . '-' . md5( $relative_chunk ) . '.json';
		if( ! is_readable( $catalog_path ) ) {
			return;
		}

		$catalog = json_decode( (string) file_get_contents( $catalog_path ), true );
		$messages = $catalog['locale_data']['messages'] ?? null;
		if( ! is_array( $messages ) ) {
			return;
		}

		wp_add_inline_script(
			'wphave-request-inspector',
			'wp.i18n.setLocaleData(' . wp_json_encode( $messages ) . ', "wphave");',
			'before'
		);
	}

	/**
	 * Return the current same-site URL without credentials or fragments.
	 *
	 * @return string Current request URL.
	 */

	private static function current_url() {
		$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
		$request_uri = '/' . ltrim( preg_replace( '/#.*$/', '', $request_uri ), '/' );

		return esc_url_raw( home_url( $request_uri ) );
	}
}
