<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/access-policy.php';
require_once __DIR__ . '/asset-loader.php';
require_once __DIR__ . '/test-signals.php';

/**
 * Coordinates request-inspector entry points without owning profiler logic.
 */

class WPHAVE_Request_Inspector {

	/**
	 * Register the opt-in control and conditional asset runtime.
	 *
	 * @return void
	 */

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_rest_routes' ) );
		WPHAVE_Request_Inspector_Asset_Loader::init();
	}

	/**
	 * Register Inspector-owned development actions without coupling them to the
	 * WordPress admin bar.
	 *
	 * @return void
	 */

	public static function register_rest_routes() {
		register_rest_route( 'wphave/v1', '/request-inspector/test-signals', array(
			'methods' => WP_REST_Server::CREATABLE,
			'callback' => array( __CLASS__, 'arm_test_signals_endpoint' ),
			'permission_callback' => array( __CLASS__, 'can_run_test_signals' ),
		) );
	}

	/**
	 * Restrict synthetic signals to an enabled Inspector in a safe environment.
	 *
	 * @return bool Whether the current request may arm test signals.
	 */

	public static function can_run_test_signals() {
		return WPHAVE_Request_Inspector_Access_Policy::is_enabled()
			&& WPHAVE_Request_Inspector_Test_Signals::is_available();
	}

	/**
	 * Arm safe, one-shot PHP diagnostics for the next Inspector capture.
	 *
	 * @return WP_REST_Response|WP_Error REST response or a bounded failure.
	 */

	public static function arm_test_signals_endpoint() {
		if( ! WPHAVE_Request_Inspector_Test_Signals::arm( get_current_user_id() ) ) {
			return new WP_Error(
				'wphave_test_signals_not_armed',
				__( 'The diagnostic test signals could not be prepared.', 'wphave' ),
				array( 'status' => 500 )
			);
		}

		return rest_ensure_response( array( 'armed' => true ) );
	}
}

WPHAVE_Request_Inspector::init();
