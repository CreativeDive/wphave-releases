<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once wphave_dir() . 'inc/features/security/boundaries/index.php';

/**
 * Applies the central security boundary to the monitoring event schema.
 */
final class WPHAVE_Monitoring_Event_Normalizer {

	public static function normalize( $event ) {
		if ( ! is_array( $event ) ) {
			return array();
		}

		$event['label'] = WPHAVE_Security_Normalizer::diagnostic_text( $event['label'] ?? '' );
		$event['url'] = WPHAVE_Security_Normalizer::diagnostic_url( $event['url'] ?? '' );
		$event['slowQueries'] = self::query_items( $event['slowQueries'] ?? array(), 'sql', 240 );

		$query_profile = is_array( $event['queryProfile'] ?? null ) ? $event['queryProfile'] : array();
		$query_profile['topQueries'] = self::query_items( $query_profile['topQueries'] ?? array(), 'sql', 240 );
		$query_profile['repeatedPatterns'] = self::query_items(
			$query_profile['repeatedPatterns'] ?? array(),
			'pattern',
			220,
			'example'
		);
		$event['queryProfile'] = $query_profile;

		return $event;
	}

	private static function query_items( $items, $primary_key, $max_length, $secondary_key = '' ) {
		if ( ! is_array( $items ) ) {
			return array();
		}

		return array_values(
			array_map(
				function( $item ) use ( $primary_key, $secondary_key, $max_length ) {
					if ( ! is_array( $item ) ) {
						return array();
					}

					$item[ $primary_key ] = WPHAVE_Security_Normalizer::sql_shape( $item[ $primary_key ] ?? '', $max_length );
					if ( $secondary_key ) {
						$item[ $secondary_key ] = WPHAVE_Security_Normalizer::sql_shape( $item[ $secondary_key ] ?? '', $max_length );
					}
					if ( isset( $item['caller'] ) ) {
						$item['caller'] = WPHAVE_Security_Normalizer::diagnostic_text( $item['caller'], 180 );
					}

					return $item;
				},
				$items
			)
		);
	}
}
