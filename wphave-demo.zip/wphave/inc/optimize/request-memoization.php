<?php

/**
 * Read values from caller-owned request-local memoization arrays.
 *
 * This helper is not the static page cache. It only reads from request-local arrays
 * maintained by material, SVG and style helpers so identical generated snippets
 * do not need to be recalculated multiple times in the same request.
 *
 * @param array $cache Caller-owned request-local memoization array.
 * @param string $cache_key Cache key to read from the memoization array.
 * @param array $args {
 *     Optional read arguments.
 *
 * @type string $output Output mode. The special value `all` bypasses request-local memoization.
 * }
 * @return mixed Cached value when available, otherwise false.
 */

if ( ! function_exists( 'wphave_request_memoization_read' ) ) :

	function wphave_request_memoization_read( $cache, $cache_key, $args = array() ) {

		if( ! WPHAVE_REQUEST_MEMOIZATION ) {
			// Enable / disable request-local memoization in config.
			return false;
		}

		$output = isset( $args['output'] ) ? $args['output'] : '';

		if( $output === 'all' ) {
			return false;
		}

		if( isset( $cache[ $cache_key ] ) ) {
			// Reuse the already generated value for this request.
			return $cache[ $cache_key ];
		}

		return false;

	}

endif;
