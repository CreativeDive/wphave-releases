<?php

/**
 * Redirect-focused view of the existing WPHAVE Analytics 404 data.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPHAVE_Redirect_404_Monitor {

	/** Option containing intentionally ignored request paths. */
	const IGNORED_OPTION = 'wphave_redirect_404_ignored';

	/** Maximum number of aggregated analytics URLs read per request. */
	const MAX_SOURCE_ROWS = 500;

	/** Maximum number of ignored paths retained in the option. */
	const MAX_IGNORED_PATHS = 500;

	/**
	 * Register the monitor REST endpoints.
	 */

	public static function init(): void {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * Register read and ignore-state routes.
	 */

	public static function register_routes(): void {
		register_rest_route( 'wphave/v1', '/redirects/404-monitor', array(
			'methods' => WP_REST_Server::READABLE,
			'callback' => array( __CLASS__, 'list_endpoint' ),
			'permission_callback' => array( 'WPHAVE_Redirect_Manager', 'permissions_check' ),
			'args' => array(
				'days' => array( 'type' => 'integer', 'default' => 30, 'minimum' => 1, 'maximum' => 365 ),
				'context' => array( 'type' => 'string', 'default' => 'full', 'enum' => array( 'summary', 'full' ) )
			)
		) );

		register_rest_route( 'wphave/v1', '/redirects/404-monitor/ignore', array(
			'methods' => WP_REST_Server::EDITABLE,
			'callback' => array( __CLASS__, 'ignore_endpoint' ),
			'permission_callback' => array( 'WPHAVE_Redirect_Manager', 'permissions_check' ),
			'args' => array(
				'path' => array( 'type' => 'string', 'required' => true ),
				'ignored' => array( 'type' => 'boolean', 'required' => true )
			)
		) );
	}

	/**
	 * Require Redirect management authority at the final monitor boundary.
	 *
	 * AUTHORIZATION INVARIANT: Route permission callbacks are only an early
	 * dispatch gate. Both public monitor callbacks repeat the canonical Redirect
	 * policy before private analytics disclosure or global ignore-state mutation.
	 *
	 * @return true|WP_Error
	 */
	private static function require_manage_access() {
		if( ! WPHAVE_Redirect_Manager::permissions_check() ) {
			return new WP_Error(
				'wphave_redirect_404_forbidden',
				__( 'You are not allowed to manage redirect diagnostics.', 'wphave' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Return aggregated missing paths from the analytics daily table.
	 */

	public static function list_endpoint( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$authorized = self::require_manage_access();
		if( is_wp_error( $authorized ) ) {
			return $authorized;
		}

		$days = max( 1, min( 365, absint( $request->get_param( 'days' ) ?: 30 ) ) );
		$context = 'summary' === $request->get_param( 'context' ) ? 'summary' : 'full';
		$items = self::items( $days );
		$analytics_available = self::analytics_table_exists();

		// AUTHORIZATION/404-MONITOR-RESPONSE INVARIANT: Analytics aggregation,
		// ignored-state projection and redirect matching cross filterable database
		// and option boundaries. Revalidate Redirect management authority after the
		// complete report is materialized and before summary or full disclosure.
		$authorized = self::require_manage_access();
		if( is_wp_error( $authorized ) ) {
			return $authorized;
		}

		if ( 'summary' === $context ) {
			return rest_ensure_response( array(
				'openCount' => count( array_filter( $items, static fn( array $item ): bool => empty( $item['resolved'] ) && empty( $item['ignored'] ) ) ),
				'days' => $days,
				'analyticsAvailable' => $analytics_available
			) );
		}

		return rest_ensure_response( array(
			'items' => $items,
			'days' => $days,
			'analyticsAvailable' => $analytics_available
		) );
	}

	/**
	 * Persist whether an intentional missing path should be ignored.
	 */

	public static function ignore_endpoint( WP_REST_Request $request ) {
		$authorized = self::require_manage_access();
		if( is_wp_error( $authorized ) ) {
			return $authorized;
		}

		$path = self::normalize_path( (string) $request->get_param( 'path' ) );

		if ( ! $path ) {
			return new WP_Error( 'wphave_redirect_404_invalid_path', __( 'Choose a valid missing URL.', 'wphave' ), array( 'status' => 400 ) );
		}

		$ignored = self::ignored_paths();

		if ( $request->get_param( 'ignored' ) ) {
			$ignored[] = $path;
			$ignored = array_slice( array_values( array_unique( $ignored ) ), -self::MAX_IGNORED_PATHS );
		} else {
			$ignored = array_values( array_diff( $ignored, array( $path ) ) );
		}

		// AUTHORIZATION/404-IGNORE-MUTATION INVARIANT: Path normalization and the
		// existing option snapshot cross filterable WordPress boundaries. Repeat the
		// canonical Redirect policy immediately before replacing global ignore state.
		$authorized = self::require_manage_access();
		if( is_wp_error( $authorized ) ) {
			return $authorized;
		}

		update_option( self::IGNORED_OPTION, $ignored, false );

		return rest_ensure_response( array( 'path' => $path, 'ignored' => in_array( $path, $ignored, true ) ) );
	}

	/**
	 * Aggregate stored analytics rows by normalized request path.
	 */

	private static function items( int $days ): array {
		if ( ! self::analytics_table_exists() ) {
			return array();
		}

		global $wpdb;

		$table = $wpdb->prefix . WPHAVE_Analytics::DAILY_TABLE;
		$threshold = current_datetime()->modify( sprintf( '-%d days', $days ) )->format( 'Y-m-d' );
		$sql = "SELECT object_url,
				MAX(NULLIF(referrer_domain, '')) AS referrer_domain,
				SUM(views) AS views,
				SUM(unique_visitors) AS unique_visitors,
				SUM(sessions) AS sessions,
				MAX(view_date) AS last_seen
			FROM {$table}
			WHERE view_date >= %s
				AND ((object_type = 'error' AND object_subtype = '404') OR object_type = '404')
			GROUP BY object_url
			ORDER BY views DESC
			LIMIT %d";
		$rows = $wpdb->get_results( $wpdb->prepare(
			$sql,
			$threshold,
			self::MAX_SOURCE_ROWS
		), ARRAY_A );
		$items = array();
		$ignored = self::ignored_paths();

		foreach ( $rows ?: array() as $row ) {
			$path = self::normalize_path( (string) ( $row['object_url'] ?? '' ) );

			if ( ! $path ) {
				continue;
			}

			if ( ! isset( $items[ $path ] ) ) {
				$items[ $path ] = array(
					'id' => hash( 'sha256', $path ),
					'path' => $path,
					'views' => 0,
					'unique_visitors' => 0,
					'sessions' => 0,
					'last_seen' => '',
					'referrer_domain' => '',
					'ignored' => in_array( $path, $ignored, true ),
					'resolved' => false,
					'redirect' => null
				);
			}

			$items[ $path ]['views'] += absint( $row['views'] ?? 0 );
			$items[ $path ]['unique_visitors'] += absint( $row['unique_visitors'] ?? 0 );
			$items[ $path ]['sessions'] += absint( $row['sessions'] ?? 0 );
			$items[ $path ]['last_seen'] = max( $items[ $path ]['last_seen'], (string) ( $row['last_seen'] ?? '' ) );

			if ( ! $items[ $path ]['referrer_domain'] && ! empty( $row['referrer_domain'] ) ) {
				$items[ $path ]['referrer_domain'] = sanitize_text_field( $row['referrer_domain'] );
			}
		}

		$redirects = WPHAVE_Redirect_Manager::match_urls( array_keys( $items ) );

		foreach ( $items as $path => &$item ) {
			$redirect = $redirects[ $path ] ?? null;
			$item['resolved'] = ! empty( $redirect['enabled'] );
			$item['redirect'] = $redirect;
		}
		unset( $item );

		return array_values( $items );
	}

	/**
	 * Normalize a tracked URL to a request path without its query.
	 */

	private static function normalize_path( string $url ): string {
		// DATA INVARIANT: The 404 monitor stores path identity only. Scheme, host,
		// credentials, query and fragment never participate in ignore authority, and
		// malformed or root-only inputs cannot create a wildcard-like entry.
		$url = trim( $url );
		$parts = wp_parse_url( $url );
		$path = is_array( $parts ) ? (string) ( $parts['path'] ?? '' ) : '';

		if ( ! $path && str_starts_with( $url, '/' ) ) {
			$path = strtok( $url, '?' );
		}

		if ( ! $path ) {
			return '';
		}

		$path = '/' . ltrim( sanitize_text_field( $path ), '/' );
		$path = rtrim( $path, '/' ) ?: '/';

		return substr( $path, 0, 512 );
	}

	/**
	 * Return the bounded list of intentionally ignored paths.
	 */

	private static function ignored_paths(): array {
		$paths = get_option( self::IGNORED_OPTION, array() );

		return is_array( $paths ) ? array_slice( array_values( array_filter( array_map( 'strval', $paths ) ) ), -self::MAX_IGNORED_PATHS ) : array();
	}

	/**
	 * Check whether the analytics aggregate table is available.
	 */

	private static function analytics_table_exists(): bool {
		if ( ! class_exists( 'WPHAVE_Analytics' ) ) {
			return false;
		}

		global $wpdb;

		$table = $wpdb->prefix . WPHAVE_Analytics::DAILY_TABLE;

		return WPHAVE_Database_Metadata::table_exists( $table );
	}
}

WPHAVE_Redirect_404_Monitor::init();
