<?php

/**
 * WPHAVE Redirect Manager.
 */

if (!defined('ABSPATH')) {
	exit();
}

class WPHAVE_Redirect_Manager {
	const VERSION = '1.0.0';
	const DB_VERSION = '1.0.0';
	const TABLE = 'wphave_redirects';
	const REGEX_MATCH_LIMIT = 100;
	const REGEX_PATTERN_MAX_LENGTH = 256;
	const MAX_BULK_IDS = 200;
	const MAX_TARGET_URL_LENGTH = 2048;
	const OPTION_HAS_ACTIVE_REDIRECTS = 'wphave_redirect_manager_has_active_redirects';

	private static ?bool $table_exists = null;
	private static ?bool $required_columns_exist = null;
	private static ?bool $has_active_redirects = null;

	/**
	 * Register database checks, frontend redirect handling and REST endpoints.
	 */

	public static function init(): void {
		if (self::has_active_redirects()) {
			add_action('template_redirect', [__CLASS__, 'maybe_redirect'], 1);
		}

		add_action('rest_api_init', [__CLASS__, 'register_routes']);
	}

	/**
	 * Restrict redirect management to trusted site administrators or explicit redirect managers.
	 */

	public static function permissions_check(): bool {
		return is_user_logged_in() &&
			(current_user_can('manage_options') || current_user_can('wphave_manage_redirects'));
	}

	/**
	 * Require Redirect authority at the final HTTP callback boundary.
	 *
	 * AUTHORIZATION INVARIANT: REST permission callbacks are only an early
	 * dispatch gate. Every public manager callback repeats the canonical policy
	 * before catalog disclosure, matching diagnostics or database mutation.
	 * Frontend matching uses separate read-only methods.
	 *
	 * @return true|WP_Error
	 */
	private static function require_manage_access() {
		if (!self::permissions_check()) {
			return new WP_Error(
				'wphave_redirect_forbidden',
				__('You are not allowed to manage redirects.', 'wphave'),
				['status' => 403],
			);
		}

		return true;
	}

	/**
	 * Public schema validator for the central database schema manager.
	 */

	public static function schema_ready(): bool {
		return self::table_exists() && self::required_columns_exist();
	}

	/**
	 * Return the redirect that currently matches a URL or path.
	 *
	 * This is the stable integration boundary used by the 404 monitor. Runtime
	 * matching remains owned by the redirect manager.
	 */

	public static function match_url(string $url, bool $enabled_only = false): ?array {
		if (!self::schema_ready()) {
			return null;
		}

		$match = self::find_redirect(self::normalize_source_path($url), $enabled_only);

		return $match ? self::format_row($match) : null;
	}

	/**
	 * Resolve multiple normalized paths with one redirect-table query.
	 *
	 * The result uses the same exact, prefix and bounded-regex precedence as
	 * the runtime matcher while avoiding one SQL query per administrative
	 * report row.
	 */

	public static function match_urls(array $paths, bool $enabled_only = false): array {
		if (!self::schema_ready()) {
			return [];
		}

		$paths = array_values(array_unique(array_filter(array_map('strval', $paths))));

		if (!$paths) {
			return [];
		}

		global $wpdb;

		$where = $enabled_only ? 'WHERE enabled = 1' : '';
		$rows = $wpdb->get_results(
			'SELECT * FROM ' .
				self::table_name() .
				" {$where} ORDER BY FIELD(match_type, 'exact', 'prefix', 'regex'), CHAR_LENGTH(source_path) DESC, id ASC",
			ARRAY_A,
		);
		$matches = [];

		foreach ($paths as $path) {
			$regex_count = 0;

			foreach ($rows ?: [] as $row) {
				if (($row['match_type'] ?? '') === 'regex') {
					$regex_count++;

					if ($regex_count > self::REGEX_MATCH_LIMIT) {
						break;
					}
				}

				if (self::matches($row, $path)) {
					$matches[$path] = self::format_row($row);
					break;
				}
			}
		}

		return $matches;
	}

	/**
	 * Create the redirects table used by the runtime matcher and admin UI.
	 */

	public static function install(): void {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table = self::table_name();
		$charset = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            source_path varchar(512) NOT NULL DEFAULT '',
            target_url text NOT NULL,
            status_code smallint(3) unsigned NOT NULL DEFAULT 301,
            match_type varchar(20) NOT NULL DEFAULT 'exact',
            preserve_query tinyint(1) unsigned NOT NULL DEFAULT 1,
            enabled tinyint(1) unsigned NOT NULL DEFAULT 1,
            hits bigint(20) unsigned NOT NULL DEFAULT 0,
            last_hit datetime DEFAULT NULL,
            notes text DEFAULT NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY (id),
            KEY enabled_match (enabled, match_type),
            KEY source_path (source_path(191)),
            KEY hits (hits)
        ) {$charset};";

		dbDelta($sql);
		self::reset_table_exists_cache();
		self::refresh_active_redirects_flag();
		// The shared manager commits this version only after validation succeeds.
	}

	/**
	 * Register the admin REST API used by the Redirect Manager screen.
	 */

	public static function register_routes(): void {
		register_rest_route('wphave/v1', '/redirects', [
			'methods' => 'GET',
			'callback' => [__CLASS__, 'list_endpoint'],
			'permission_callback' => [__CLASS__, 'permissions_check'],
		]);

		register_rest_route('wphave/v1', '/redirects', [
			'methods' => 'POST',
			'callback' => [__CLASS__, 'save_endpoint'],
			'permission_callback' => [__CLASS__, 'permissions_check'],
		]);

		register_rest_route('wphave/v1', '/redirects/(?P<id>\d+)', [
			'methods' => 'DELETE',
			'callback' => [__CLASS__, 'delete_endpoint'],
			'permission_callback' => [__CLASS__, 'permissions_check'],
		]);

		register_rest_route('wphave/v1', '/redirects/bulk', [
			'methods' => 'POST',
			'callback' => [__CLASS__, 'bulk_endpoint'],
			'permission_callback' => [__CLASS__, 'permissions_check'],
		]);

		register_rest_route('wphave/v1', '/redirects/test', [
			'methods' => 'POST',
			'callback' => [__CLASS__, 'test_endpoint'],
			'permission_callback' => [__CLASS__, 'permissions_check'],
		]);
	}

	/**
	 * Return all redirects for the admin manager.
	 */

	public static function list_endpoint(): WP_REST_Response|WP_Error {
		$authorized = self::require_manage_access();
		if (is_wp_error($authorized)) {
			return $authorized;
		}

		$payload = [
			'items' => self::list_items(),
			'schemaUpdateRequired' => !self::schema_ready(),
		];

		// AUTHORIZATION/REDIRECT-CATALOG-RESPONSE INVARIANT: Redirect-table and
		// schema projection cross filterable database boundaries. Revalidate the
		// canonical management policy after materialization and before private
		// routing configuration leaves the server.
		$authorized = self::require_manage_access();
		if (is_wp_error($authorized)) {
			return $authorized;
		}

		return rest_ensure_response($payload);
	}

	/**
	 * Create or update one redirect after validation and conflict checks.
	 */

	public static function save_endpoint(WP_REST_Request $request) {
		$authorized = self::require_manage_access();
		if (is_wp_error($authorized)) {
			return $authorized;
		}

		if (!self::schema_ready()) {
			return self::schema_unavailable_error();
		}

		$data = $request->get_json_params();
		$data = is_array($data) ? $data : [];
		$id = absint($data['id'] ?? 0);
		$prepared = self::prepare_redirect_data($data);

		if (is_wp_error($prepared)) {
			return $prepared;
		}

		// DATA INTEGRITY INVARIANT: A redirect may be persisted only after both
		// conflict and loop state were read successfully. An unreadable routing
		// graph is unknown state, never evidence that the proposed edge is safe.
		$conflict_exists = self::redirect_conflict_exists(
			$prepared['source_path'],
			$prepared['match_type'],
			$id,
		);

		if (is_wp_error($conflict_exists)) {
			return $conflict_exists;
		}

		if ($conflict_exists) {
			return new WP_Error(
				'wphave_redirect_duplicate_source',
				__('A redirect with the same source path and match type already exists.', 'wphave'),
				['status' => 409],
			);
		}

		$creates_loop = self::creates_redirect_chain_loop(
			$prepared['source_path'],
			$prepared['target_url'],
			$id,
		);

		if (is_wp_error($creates_loop)) {
			return $creates_loop;
		}

		if ($creates_loop) {
			return new WP_Error(
				'wphave_redirect_chain_loop',
				__('This redirect would create a redirect loop with another redirect.', 'wphave'),
				['status' => 409],
			);
		}

		// AUTHORIZATION/REDIRECT-SAVE INVARIANT: Input normalization, uniqueness
		// discovery and redirect-graph traversal cross sanitizer and database filter
		// boundaries. The initial REST/callback decision is not a lease; repeat the
		// canonical management policy immediately before insert or update.
		$authorized = self::require_manage_access();
		if (is_wp_error($authorized)) {
			return $authorized;
		}

		global $wpdb;

		$table = self::table_name();
		$now = current_time('mysql');

		if ($id) {
			if (!self::get_redirect($id)) {
				return new WP_Error(
					'wphave_redirect_not_found',
					__('Redirect not found.', 'wphave'),
					['status' => 404],
				);
			}

			$prepared['updated_at'] = $now;
			$updated = $wpdb->update($table, $prepared, ['id' => $id], self::formats($prepared), [
				'%d',
			]);

			if ($updated === false) {
				return new WP_Error(
					'wphave_redirect_update_failed',
					__('Redirect could not be updated.', 'wphave'),
					['status' => 500],
				);
			}
		} else {
			$prepared['created_at'] = $now;
			$prepared['updated_at'] = $now;
			$inserted = $wpdb->insert($table, $prepared, self::formats($prepared));

			if (!$inserted) {
				return new WP_Error(
					'wphave_redirect_create_failed',
					__('Redirect could not be created.', 'wphave'),
					['status' => 500],
				);
			}

			$id = (int) $wpdb->insert_id;
		}

		self::refresh_active_redirects_flag();

		return rest_ensure_response([
			'item' => self::get_redirect($id),
		]);
	}

	/**
	 * Delete one redirect and report missing records as explicit errors.
	 */

	public static function delete_endpoint(WP_REST_Request $request) {
		$authorized = self::require_manage_access();
		if (is_wp_error($authorized)) {
			return $authorized;
		}

		if (!self::schema_ready()) {
			return self::schema_unavailable_error();
		}

		global $wpdb;

		$id = absint($request->get_param('id'));

		if (!$id) {
			return new WP_Error(
				'wphave_redirect_missing_id',
				__('Missing redirect ID.', 'wphave'),
				['status' => 400],
			);
		}

		if (!self::get_redirect($id)) {
			return new WP_Error('wphave_redirect_not_found', __('Redirect not found.', 'wphave'), [
				'status' => 404,
			]);
		}

		// AUTHORIZATION/REDIRECT-DELETE INVARIANT: Exact-row discovery crosses a
		// filterable database boundary. Revalidate the canonical Redirect policy
		// after resolving the requested ID and immediately before irreversible SQL
		// deletion.
		$authorized = self::require_manage_access();
		if (is_wp_error($authorized)) {
			return $authorized;
		}

		$deleted = $wpdb->delete(self::table_name(), ['id' => $id], ['%d']);

		if ($deleted === false) {
			return new WP_Error(
				'wphave_redirect_delete_failed',
				__('Redirect could not be deleted.', 'wphave'),
				['status' => 500],
			);
		}

		self::refresh_active_redirects_flag();

		return rest_ensure_response([
			'deleted' => (bool) $deleted,
		]);
	}

	/**
	 * Apply a controlled bulk action to selected redirect IDs.
	 */

	public static function bulk_endpoint(WP_REST_Request $request) {
		$authorized = self::require_manage_access();
		if (is_wp_error($authorized)) {
			return $authorized;
		}

		if (!self::schema_ready()) {
			return self::schema_unavailable_error();
		}

		$ids = array_values(
			array_unique(array_filter(array_map('absint', (array) $request->get_param('ids')))),
		);
		$action = sanitize_key($request->get_param('action') ?? '');

		if (!$ids) {
			return new WP_Error(
				'wphave_redirect_bulk_missing_ids',
				__('No redirects selected.', 'wphave'),
				['status' => 400],
			);
		}

		if (count($ids) > self::MAX_BULK_IDS) {
			return new WP_Error(
				'wphave_redirect_bulk_too_many_ids',
				__('Too many redirects selected for one bulk action.', 'wphave'),
				['status' => 400],
			);
		}

		if (!in_array($action, ['enable', 'disable', 'delete', 'reset_hits'], true)) {
			return new WP_Error(
				'wphave_redirect_bulk_invalid_action',
				__('Invalid bulk action.', 'wphave'),
				['status' => 400],
			);
		}

		// AUTHORIZATION/REDIRECT-BULK INVARIANT: ID and action normalization cross
		// filterable request/sanitizer boundaries. Revalidate the canonical Redirect
		// policy after the complete bounded batch is projected and before constructing
		// or executing any dynamic SQL mutation.
		$authorized = self::require_manage_access();
		if (is_wp_error($authorized)) {
			return $authorized;
		}

		global $wpdb;

		$table = self::table_name();
		// SECURITY INVARIANT: Every dynamic SQL fragment below is derived from fixed
		// internal identifiers; all request-controlled IDs and values use placeholders.
		$placeholders = implode(',', array_fill(0, count($ids), '%d'));
		$now = current_time('mysql');

		if ($action === 'delete') {
			$affected = $wpdb->query(
				$wpdb->prepare("DELETE FROM {$table} WHERE id IN ({$placeholders})", $ids),
			);
		} else {
			$data = [
				'updated_at' => $now,
			];

			if ($action === 'enable') {
				$data['enabled'] = 1;
			}

			if ($action === 'disable') {
				$data['enabled'] = 0;
			}

			if ($action === 'reset_hits') {
				$data['hits'] = 0;
				$data['last_hit'] = null;
			}

			$set = [];
			$values = [];

			foreach ($data as $key => $value) {
				$set[] =
					"{$key} = " .
					($value === null
						? 'NULL'
						: (in_array($key, ['enabled', 'hits'], true)
							? '%d'
							: '%s'));

				if ($value !== null) {
					$values[] = $value;
				}
			}

			$affected = $wpdb->query(
				$wpdb->prepare(
					"UPDATE {$table} SET " . implode(', ', $set) . " WHERE id IN ({$placeholders})",
					array_merge($values, $ids),
				),
			);
		}

		if ($affected === false) {
			return new WP_Error(
				'wphave_redirect_bulk_failed',
				__('Bulk action could not be completed.', 'wphave'),
				['status' => 500],
			);
		}

		self::refresh_active_redirects_flag();

		return rest_ensure_response([
			'updated' => (int) $affected,
			'items' => self::list_items(),
		]);
	}

	/**
	 * Test an arbitrary URL against all redirects, including disabled items.
	 */

	public static function test_endpoint(WP_REST_Request $request) {
		$authorized = self::require_manage_access();
		if (is_wp_error($authorized)) {
			return $authorized;
		}

		if (!self::schema_ready()) {
			return self::schema_unavailable_error();
		}

		$url = esc_url_raw($request->get_param('url') ?? '');
		$match = self::find_redirect(self::normalize_source_path($url), false);

		// AUTHORIZATION/REDIRECT-TEST-RESPONSE INVARIANT: URL normalization and
		// routing-table matching cross filterable sanitizer and database boundaries.
		// Revalidate management authority after resolving the rule and immediately
		// before disclosing its configuration and enabled state.
		$authorized = self::require_manage_access();
		if (is_wp_error($authorized)) {
			return $authorized;
		}

		return rest_ensure_response([
			'matched' => (bool) $match,
			'wouldRedirect' => $match && !empty($match['enabled']),
			'item' => $match ? self::format_row($match) : null,
		]);
	}

	/**
	 * Run on frontend requests and perform the first matching redirect.
	 */

	public static function maybe_redirect(): void {
		if (is_admin() || wp_doing_ajax() || wp_doing_cron() || is_user_admin()) {
			return;
		}

		if (!self::has_active_redirects()) {
			return;
		}

		$path = self::get_current_path();

		if (!$path || self::is_excluded_path($path)) {
			return;
		}

		$redirect = self::find_redirect($path);

		if (!$redirect) {
			return;
		}

		$target = self::build_target_url($redirect, $_SERVER['QUERY_STRING'] ?? '');

		if (!$target || self::is_same_url($target)) {
			return;
		}

		self::record_hit((int) $redirect['id']);
		wp_redirect($target, (int) $redirect['status_code'], 'WPHAVE Redirect Manager');
		exit();
	}

	/**
	 * Find the first matching redirect with one runtime query.
	 *
	 * Exact and prefix candidates are filtered in SQL. Regex rules are loaded
	 * last and evaluated in PHP with a hard limit because they are intentionally
	 * advanced and more expensive than deterministic path comparisons.
	 */

	private static function find_redirect(string $path, bool $enabled_only = true): ?array {
		global $wpdb;

		$table = self::table_name();
		$exact_candidates = array_values(
			array_filter(
				array_unique([
					$path,
					rtrim($path, '/') ?: '/',
					$path === '/' ? '/' : trailingslashit($path),
				]),
			),
		);
		$exact_placeholders = implode(',', array_fill(0, count($exact_candidates), '%s'));
		$where = [
			"( ( match_type = 'exact' AND source_path IN ({$exact_placeholders}) ) OR ( match_type = 'prefix' AND %s LIKE CONCAT(source_path, '%%') ) OR match_type = 'regex' )",
		];
		$params = array_merge($exact_candidates, [$path]);

		if ($enabled_only) {
			array_unshift($where, 'enabled = %d');
			array_unshift($params, 1);
		}

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE " .
					implode(' AND ', $where) .
					" ORDER BY FIELD(match_type, 'exact', 'prefix', 'regex'), CHAR_LENGTH(source_path) DESC, id ASC",
				$params,
			),
			ARRAY_A,
		);

		$regex_count = 0;

		foreach ($rows ?: [] as $row) {
			if (($row['match_type'] ?? '') === 'regex') {
				$regex_count++;

				if ($regex_count > self::REGEX_MATCH_LIMIT) {
					break;
				}
			}

			if (self::matches($row, $path)) {
				return $row;
			}
		}

		return null;
	}

	/**
	 * Check one redirect row against a normalized request path.
	 */

	private static function matches(array $row, string $path): bool {
		$source = (string) ($row['source_path'] ?? '');
		$type = (string) ($row['match_type'] ?? 'exact');

		if ($type === 'prefix') {
			return strpos($path, $source) === 0;
		}

		if ($type === 'regex') {
			return @preg_match('#' . str_replace('#', '\#', $source) . '#', $path) === 1;
		}

		return rtrim($path, '/') === rtrim($source, '/');
	}

	/**
	 * Sanitize incoming redirect data and reject invalid or unsafe values.
	 */

	private static function prepare_redirect_data(array $data) {
		$target_raw = (string) ($data['target_url'] ?? '');
		$target_url = self::normalize_target_url($target_raw);
		$status_code = absint($data['status_code'] ?? 301);
		$match_type = sanitize_key($data['match_type'] ?? 'exact');
		$source_path = self::normalize_source_path(
			(string) ($data['source_path'] ?? ''),
			$match_type,
		);

		// SECURITY INVARIANT: Redirect rows become executable routing policy only
		// after source, target, status and match semantics pass one closed validation
		// contract. Persistence never stores a partially accepted rule.
		if (!$source_path) {
			return new WP_Error(
				'wphave_redirect_missing_source',
				__('Missing source path.', 'wphave'),
				['status' => 400],
			);
		}

		if (!$target_url) {
			return new WP_Error(
				'wphave_redirect_missing_target',
				__('Missing target URL.', 'wphave'),
				['status' => 400],
			);
		}

		if (strlen($target_raw) > self::MAX_TARGET_URL_LENGTH) {
			return new WP_Error(
				'wphave_redirect_target_too_long',
				__('The target URL is too long.', 'wphave'),
				['status' => 400],
			);
		}

		if (!in_array($status_code, [301, 302, 307, 308], true)) {
			$status_code = 301;
		}

		if (!in_array($match_type, ['exact', 'prefix', 'regex'], true)) {
			$match_type = 'exact';
		}

		if ($match_type === 'regex' && strlen($source_path) > self::REGEX_PATTERN_MAX_LENGTH) {
			return new WP_Error(
				'wphave_redirect_regex_too_long',
				__('The regular expression is too long.', 'wphave'),
				['status' => 400],
			);
		}

		if (
			$match_type === 'regex' &&
			@preg_match('#' . str_replace('#', '\#', $source_path) . '#', '') === false
		) {
			return new WP_Error(
				'wphave_redirect_invalid_regex',
				__('The regular expression is invalid.', 'wphave'),
				['status' => 400],
			);
		}

		if (self::target_points_to_source($source_path, $target_url)) {
			return new WP_Error(
				'wphave_redirect_loop',
				__('The target points to the source and would create a redirect loop.', 'wphave'),
				['status' => 400],
			);
		}

		return [
			'source_path' => $source_path,
			'target_url' => $target_url,
			'status_code' => $status_code,
			'match_type' => $match_type,
			'preserve_query' => empty($data['preserve_query']) ? 0 : 1,
			'enabled' => empty($data['enabled']) ? 0 : 1,
			'notes' => sanitize_textarea_field($data['notes'] ?? ''),
		];
	}

	/**
	 * Normalize source input to a path-like value suitable for matching.
	 */

	private static function normalize_source_path(
		string $path,
		string $match_type = 'exact',
	): string {
		$path = trim(wp_unslash($path));

		if (!$path) {
			return '';
		}

		if ($match_type === 'regex') {
			return substr(sanitize_text_field($path), 0, 512);
		}

		if (preg_match('#^https?://#i', $path)) {
			$parts = wp_parse_url($path);
			$path = $parts['path'] ?? '/';
		} elseif (strpos($path, '?') !== false) {
			$parts = wp_parse_url($path);
			$path = $parts['path'] ?? '/';
		}

		$path = '/' . ltrim($path, '/');

		if ($match_type === 'exact') {
			$path = rtrim($path, '/') ?: '/';
		}

		return substr(sanitize_text_field($path), 0, 512);
	}

	/**
	 * Normalize target input to an absolute HTTP(S) URL.
	 */

	private static function normalize_target_url(string $url): string {
		$url = trim(wp_unslash($url));

		if (!$url) {
			return '';
		}

		if (strpos($url, '/') === 0) {
			return esc_url_raw(home_url($url));
		}

		if (!preg_match('#^https?://#i', $url)) {
			return '';
		}

		return esc_url_raw($url);
	}

	/**
	 * Build the final redirect target and optionally preserve the query string.
	 */

	private static function build_target_url(array $redirect, string $query_string): string {
		$target = (string) ($redirect['target_url'] ?? '');

		if (empty($redirect['preserve_query']) || !$query_string) {
			return $target;
		}

		return add_query_arg(
			[],
			$target . (strpos($target, '?') === false ? '?' : '&') . $query_string,
		);
	}

	/**
	 * Return the current request path without query parameters.
	 */

	private static function get_current_path(): string {
		$request_uri = $_SERVER['REQUEST_URI'] ?? '/';
		$parts = wp_parse_url($request_uri);
		$path = $parts['path'] ?? '/';

		return '/' . ltrim($path, '/');
	}

	/**
	 * Exclude WordPress internals from redirect matching.
	 */

	private static function is_excluded_path(string $path): bool {
		foreach (
			['/wp-admin', '/wp-login.php', '/wp-json', '/xmlrpc.php', '/wp-cron.php']
			as $excluded
		) {
			if (strpos($path, $excluded) === 0) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Prevent redirecting to the same URL path.
	 */

	private static function is_same_url(string $target): bool {
		$current = home_url(self::get_current_path());

		return untrailingslashit($current) === untrailingslashit(strtok($target, '?'));
	}

	/**
	 * Detect direct source-to-target loops before saving.
	 */

	private static function target_points_to_source(string $source_path, string $target_url): bool {
		$target_parts = wp_parse_url($target_url);
		$home_parts = wp_parse_url(home_url('/'));

		if (
			!empty($target_parts['host']) &&
			!empty($home_parts['host']) &&
			strtolower($target_parts['host']) !== strtolower($home_parts['host'])
		) {
			return false;
		}

		$target_path = self::normalize_source_path($target_url);

		return rtrim($target_path, '/') === rtrim($source_path, '/');
	}

	/**
	 * Prevent ambiguous redirect definitions with the same source and match mode.
	 */

	private static function redirect_conflict_exists(
		string $source_path,
		string $match_type,
		int $exclude_id = 0,
	): bool|WP_Error {
		global $wpdb;

		$table = self::table_name();
		$exclude_sql = $exclude_id ? $wpdb->prepare('AND id <> %d', $exclude_id) : '';
		$wpdb->last_error = '';

		$conflicting_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$table} WHERE source_path = %s AND match_type = %s {$exclude_sql} LIMIT 1",
				$source_path,
				$match_type,
			),
		);

		if ('' !== $wpdb->last_error) {
			return new WP_Error(
				'wphave_redirect_conflict_check_failed',
				__('Redirect conflicts could not be checked.', 'wphave'),
				['status' => 503],
			);
		}

		return (bool) $conflicting_id;
	}

	/**
	 * Detect simple internal exact-match redirect chains that would loop.
	 *
	 * Direct self-loops are handled separately. This follows exact internal
	 * redirects for a few hops to catch common cases such as /a -> /b and
	 * /b -> /a without adding expensive graph traversal to every save.
	 */

	private static function creates_redirect_chain_loop(
		string $source_path,
		string $target_url,
		int $exclude_id = 0,
	): bool|WP_Error {
		global $wpdb;

		$target_path = self::get_internal_target_path($target_url);

		if (!$target_path) {
			return false;
		}

		$visited = [rtrim($source_path, '/') ?: '/'];
		$current_path = $target_path;
		$table = self::table_name();

		for ($i = 0; $i < 8; $i++) {
			$normalized_current = rtrim($current_path, '/') ?: '/';

			if (in_array($normalized_current, $visited, true)) {
				return true;
			}

			$visited[] = $normalized_current;
			$exclude_sql = $exclude_id ? $wpdb->prepare('AND id <> %d', $exclude_id) : '';
			$wpdb->last_error = '';
			$row = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT id, target_url FROM {$table} WHERE source_path = %s AND match_type = 'exact' {$exclude_sql} LIMIT 1",
					$current_path,
				),
				ARRAY_A,
			);

			if ('' !== $wpdb->last_error) {
				return new WP_Error(
					'wphave_redirect_loop_check_failed',
					__('Redirect loops could not be checked.', 'wphave'),
					['status' => 503],
				);
			}

			if (!$row) {
				return false;
			}

			$current_path = self::get_internal_target_path((string) $row['target_url']);

			if (!$current_path) {
				return false;
			}
		}

		return false;
	}

	/**
	 * Return a normalized local path for targets pointing to this site.
	 */

	private static function get_internal_target_path(string $target_url): string {
		$target_parts = wp_parse_url($target_url);
		$home_parts = wp_parse_url(home_url('/'));

		if (
			!empty($target_parts['host']) &&
			!empty($home_parts['host']) &&
			strtolower($target_parts['host']) !== strtolower($home_parts['host'])
		) {
			return '';
		}

		return self::normalize_source_path($target_url);
	}

	/**
	 * Increment hit counters after a redirect has been selected.
	 */

	private static function record_hit(int $id): void {
		global $wpdb;

		$wpdb->query(
			$wpdb->prepare(
				'UPDATE ' .
					self::table_name() .
					' SET hits = hits + 1, last_hit = %s WHERE id = %d',
				current_time('mysql'),
				$id,
			),
		);
	}

	/**
	 * Fetch and format one redirect row by ID.
	 */

	private static function get_redirect(int $id): ?array {
		global $wpdb;

		$row = $wpdb->get_row(
			$wpdb->prepare('SELECT * FROM ' . self::table_name() . ' WHERE id = %d', $id),
			ARRAY_A,
		);

		return $row ? self::format_row($row) : null;
	}

	/**
	 * Cast database values into the shape expected by JavaScript.
	 */

	private static function format_row(array $row): array {
		return [
			'id' => (int) $row['id'],
			'source_path' => $row['source_path'],
			'target_url' => $row['target_url'],
			'status_code' => (int) $row['status_code'],
			'match_type' => $row['match_type'],
			'preserve_query' => (bool) $row['preserve_query'],
			'enabled' => (bool) $row['enabled'],
			'hits' => (int) $row['hits'],
			'last_hit' => $row['last_hit'],
			'notes' => $row['notes'],
			'created_at' => $row['created_at'],
			'updated_at' => $row['updated_at'],
		];
	}

	/**
	 * Return wpdb format tokens for redirect row writes.
	 */

	private static function formats(array $data): array {
		$formats = [];

		foreach (array_keys($data) as $key) {
			$formats[] = in_array($key, ['status_code', 'preserve_query', 'enabled'], true)
				? '%d'
				: '%s';
		}

		return $formats;
	}

	/**
	 * Return the prefixed redirects table name.
	 */

	private static function table_name(): string {
		global $wpdb;

		return $wpdb->prefix . self::TABLE;
	}

	/**
	 * Check whether the redirects table exists before runtime reads.
	 */

	private static function table_exists(): bool {
		if (self::$table_exists === null) {
			$table = self::table_name();
			self::$table_exists = WPHAVE_Database_Metadata::table_exists($table);
		}

		return self::$table_exists;
	}

	/**
	 * Check required columns that are used by runtime queries and admin writes.
	 */

	private static function required_columns_exist(): bool {
		if (self::$required_columns_exist !== null) {
			return self::$required_columns_exist;
		}

		global $wpdb;

		$columns = $wpdb->get_col('SHOW COLUMNS FROM ' . self::table_name(), 0);

		if (!is_array($columns)) {
			self::$required_columns_exist = false;

			return self::$required_columns_exist;
		}

		foreach (
			[
				'id',
				'source_path',
				'target_url',
				'status_code',
				'match_type',
				'preserve_query',
				'enabled',
				'hits',
				'last_hit',
				'created_at',
				'updated_at',
			]
			as $column
		) {
			if (!in_array($column, $columns, true)) {
				self::$required_columns_exist = false;

				return self::$required_columns_exist;
			}
		}

		$indexes = array_unique((array) $wpdb->get_col('SHOW INDEX FROM ' . self::table_name(), 2));
		self::$required_columns_exist =
			in_array('PRIMARY', $indexes, true) &&
			in_array('enabled_match', $indexes, true) &&
			in_array('source_path', $indexes, true);

		return self::$required_columns_exist;
	}

	/**
	 * Reset the table existence cache after installation.
	 */

	public static function reset_table_exists_cache(): void {
		self::$table_exists = null;
		self::$required_columns_exist = null;
		self::$has_active_redirects = null;
	}

	/**
	 * Check whether any enabled redirect exists before registering frontend work.
	 */

	private static function has_active_redirects(): bool {
		if (self::$has_active_redirects !== null) {
			return self::$has_active_redirects;
		}

		$stored = get_option(self::OPTION_HAS_ACTIVE_REDIRECTS, null);

		if ($stored !== null) {
			self::$has_active_redirects = (bool) $stored;

			return self::$has_active_redirects;
		}

		return self::refresh_active_redirects_flag();
	}

	/**
	 * Recalculate and persist the lightweight frontend redirect gate.
	 */

	private static function refresh_active_redirects_flag(): bool {
		if (!self::table_exists() || !self::required_columns_exist()) {
			self::$has_active_redirects = false;
			update_option(self::OPTION_HAS_ACTIVE_REDIRECTS, 0, true);

			return self::$has_active_redirects;
		}

		global $wpdb;

		self::$has_active_redirects = (bool) $wpdb->get_var(
			'SELECT 1 FROM ' . self::table_name() . ' WHERE enabled = 1 LIMIT 1',
		);

		update_option(self::OPTION_HAS_ACTIVE_REDIRECTS, self::$has_active_redirects ? 1 : 0, true);

		return self::$has_active_redirects;
	}

	/**
	 * Return a consistent error while the redirects schema needs an update.
	 */

	private static function schema_unavailable_error(): WP_Error {
		return new WP_Error(
			'wphave_redirect_schema_update_required',
			__(
				'Redirect database tables need to be updated before this feature can be used.',
				'wphave',
			),
			['status' => 503],
		);
	}

	/**
	 * Return all redirects ordered for the manager table.
	 */

	private static function list_items(): array {
		if (!self::table_exists()) {
			return [];
		}

		global $wpdb;

		$rows = $wpdb->get_results(
			'SELECT * FROM ' .
				self::table_name() .
				' ORDER BY enabled DESC, hits DESC, updated_at DESC',
			ARRAY_A,
		);

		return array_map([__CLASS__, 'format_row'], $rows ?: []);
	}
}

// TENANCY INVARIANT: Request-local readiness and routing caches cannot cross sites.
add_action('switch_blog', ['WPHAVE_Redirect_Manager', 'reset_table_exists_cache']);

WPHAVE_Database_Schema_Manager::register([
	'id' => 'redirects',
	'label' => 'Redirect table',
	'version' => WPHAVE_Redirect_Manager::DB_VERSION,
	'option' => 'wphave_redirect_manager_db_version',
	'tables' => [WPHAVE_Redirect_Manager::TABLE],
	'callback' => ['WPHAVE_Redirect_Manager', 'install'],
	'validator' => ['WPHAVE_Redirect_Manager', 'schema_ready'],
]);

add_action('plugins_loaded', static function (): void {
	if (!WPHAVE_Database_Schema_Manager::runtime_compatible('redirects')) {
		return;
	}

	WPHAVE_Redirect_Manager::init();
});
