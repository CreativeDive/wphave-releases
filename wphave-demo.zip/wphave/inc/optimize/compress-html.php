<?php

/**
 * Safe HTML minification class designed for production usage.
 *
 * Key principles:
 * - Never break layout or inline spacing
 * - Protect sensitive tags (script, style, pre, textarea)
 * - Avoid aggressive whitespace removal in text nodes
 * - Allow controlled inline CSS/JS compression
 *
 * IMPORTANT:
 * HTML minification should be conservative. Most compression
 * benefits already come from gzip/brotli.
 */

class WPHAVE_HTML_Compression {
	/**
	 * Initialize the component.
	 *
	 * @var string Final processed HTML
	 */

	protected string $html = '';

	/**
	 * Initialize the component.
	 *
	 * @var bool Remove HTML comments
	 */

	protected bool $removeComments = true;

	/**
	 * Initialize the component.
	 *
	 * @var bool Append debug info comment
	 */

	protected bool $addInfoComment = false;

	/**
	 * Initialize the component.
	 *
	 * @var bool Whether inline JS should be minified (risky!)
	 */

	protected bool $compressInlineJs = false;

	/**
	 * Initialize the component.
	 *
	 * @var bool Whether inline CSS should be minified
	 */

	protected bool $compressInlineCss = true;

	/**
	 * Constructor.
	 *
	 * @param string $html Raw HTML
	 * @param array $options Configuration options
	 */

	public function __construct(string $html, array $options = []) {
		$this->removeComments = $options['remove_comments'] ?? true;
		$this->addInfoComment = $options['info_comment'] ?? false;
		$this->compressInlineJs = $options['compress_inline_js'] ?? false;
		$this->compressInlineCss = $options['compress_inline_css'] ?? true;

		$this->html = $this->compress($html);
	}

	/**
	 * Return compressed HTML as string.
	 */

	public function __toString(): string {
		return $this->html;
	}

	/**
	 * Main compression pipeline.
	 *
	 * @param string $html
	 * @return string
	 */

	private function compress(string $html): string {
		if (trim($html) === '') {
			return $html;
		}

		$rawHtml = $html;
		$placeholders = [];

		// Protect custom no-compression blocks
		$html = $this->protectNoCompressionBlocks($html, $placeholders);

		// Protect and optionally process special tags
		$html = $this->protectSpecialTags($html, $placeholders);

		// Remove HTML comments (safe)
		if ($this->removeComments) {
			$html = $this->removeHtmlComments($html);
		}

		// Compress remaining HTML structure
		$html = $this->compressHtmlTokens($html);

		// Restore protected content
		$html = strtr($html, $placeholders);

		// Optional debug info
		if ($this->addInfoComment) {
			$html .= "\n" . $this->buildInfoComment($rawHtml, $html);
		}

		return $html;
	}

	/**
	 * Protect explicitly marked no-compression blocks.
	 */

	private function protectNoCompressionBlocks(string $html, array &$placeholders): string {
		return preg_replace_callback(
			'/<!--\s*wp-html-compression no compression\s*-->(.*?)<!--\s*wp-html-compression no compression\s*-->/is',
			function ($match) use (&$placeholders) {
				$key = $this->placeholderKey(count($placeholders));

				// Only keep inner content (strip control comments)
				$placeholders[$key] = $match[1];

				return $key;
			},
			$html,
		);
	}

	/**
	 * Protect and optionally compress script, style, pre, textarea.
	 */

	private function protectSpecialTags(string $html, array &$placeholders): string {
		// SCRIPT tags
		$html = preg_replace_callback(
			'/<script\b[^>]*>[\s\S]*?<\/script>/i',
			function ($match) use (&$placeholders) {
				$content = $this->compressInlineJs
					? $this->compressScriptTagSafely($match[0])
					: $match[0];

				$key = $this->placeholderKey(count($placeholders));
				$placeholders[$key] = $content;

				return $key;
			},
			$html,
		);

		// STYLE tags
		$html = preg_replace_callback(
			'/<style\b[^>]*>[\s\S]*?<\/style>/i',
			function ($match) use (&$placeholders) {
				$content = $this->compressInlineCss
					? $this->compressStyleTag($match[0])
					: $match[0];

				$key = $this->placeholderKey(count($placeholders));
				$placeholders[$key] = $content;

				return $key;
			},
			$html,
		);

		// PRE + TEXTAREA → always protected (never modified)
		$html = preg_replace_callback(
			'/<(pre|textarea)\b[^>]*>[\s\S]*?<\/\1>/i',
			function ($match) use (&$placeholders) {
				$key = $this->placeholderKey(count($placeholders));
				$placeholders[$key] = $match[0];

				return $key;
			},
			$html,
		);

		return $html;
	}

	/**
	 * Remove non-conditional HTML comments.
	 */

	private function removeHtmlComments(string $html): string {
		return preg_replace(
			'/<!--(?!\s*(?:\[if\s|<!|>|wphave:scheduled-block\s*--))(?:(?!-->).)*-->/s',
			'',
			$html,
		);
	}

	/**
	 * Compress HTML outside protected areas.
	 */

	private function compressHtmlTokens(string $html): string {
		$tokens = preg_split('/(<[^>]+>)/', $html, -1, PREG_SPLIT_DELIM_CAPTURE);

		if (!is_array($tokens)) {
			return $html;
		}

		$output = '';
		foreach ($tokens as $token) {
			if ($token === '') {
				continue;
			}

			if (str_starts_with($token, '<')) {
				$output .= $this->compressHtmlTag($token);
			} else {
				$output .= $this->compressTextNode($token);
			}
		}

		// Remove whitespace between tags (safe for block elements,
		// but may affect inline elements visually)
		$output = preg_replace('/>\s+</', '><', $output);
		$output = preg_replace('/\n+/', '', $output);

		return trim($output);
	}

	/**
	 * Compress a single HTML tag safely.
	 */

	private function compressHtmlTag(string $tag): string {
		// Normalize whitespace but keep quoted attributes intact
		$tag = preg_replace_callback(
			'/"[^"]*"|\'[^\']*\'|\s+/',
			function ($match) {
				$value = $match[0];

				// Keep quoted strings untouched
				if ($value[0] === '"' || $value[0] === "'") {
					return $value;
				}

				return ' ';
			},
			$tag,
		);

		// Remove trailing space before closing tag
		$tag = preg_replace('/\s+>$/', '>', $tag);

		// Normalize self-closing tags
		$tag = str_replace(' />', '/>', $tag);

		return $tag;
	}

	/**
	 * Compress text nodes safely.
	 *
	 * IMPORTANT:
	 * - Do NOT remove line breaks completely
	 * - Preserve layout-sensitive whitespace
	 */

	private function compressTextNode(string $text): string {
		// If text is only whitespace → remove completely
		if (trim($text) === '') {
			return '';
		}

		// Only normalize spaces/tabs (keep line breaks!)
		return preg_replace('/[ \t]+/', ' ', $text);
	}

	/**
	 * Compress inline CSS safely.
	 */

	private function compressStyleTag(string $styleTag): string {
		return preg_replace_callback(
			'/(<style\b[^>]*>)(.*?)(<\/style>)/is',
			function ($match) {
				$css = $match[2];

				// Remove comments
				$css = preg_replace('!/\*.*?\*/!s', '', $css);

				// Normalize whitespace
				$css = preg_replace('/\s*([{}:;,>])\s*/', '$1', $css);

				return $match[1] . trim($css) . $match[3];
			},
			$styleTag,
		);
	}

	/**
	 * Safely compress inline JavaScript.
	 *
	 * WARNING:
	 * JS minification via regex is NOT safe in all cases.
	 */

	private function compressScriptTagSafely(string $scriptTag): string {
		return preg_replace_callback(
			'/(<script\b[^>]*>)(.*?)(<\/script>)/is',
			function ($match) {
				$js = $match[2];

				// Protect strings
				$placeholders = [];

				$js = preg_replace_callback(
					'/(["\'`])(?:(?=(\\\\?))\2.)*?\1/s',
					function ($m) use (&$placeholders) {
						$key = '%%JS_STRING_' . count($placeholders) . '%%';
						$placeholders[$key] = $m[0];

						return $key;
					},
					$js,
				);

				// Remove line breaks
				$js = str_replace(["\r", "\n", "\t"], '', $js);

				// Normalize spaces
				$js = preg_replace('/\s+/', ' ', $js);

				// Restore strings
				$js = strtr($js, $placeholders);

				return $match[1] . trim($js) . $match[3];
			},
			$scriptTag,
		);
	}

	/**
	 * Build debug info comment.
	 */

	private function buildInfoComment(string $raw, string $compressed): string {
		$rawBytes = strlen($raw);
		$compressedBytes = strlen($compressed);

		$savings = $rawBytes > 0 ? round((($rawBytes - $compressedBytes) / $rawBytes) * 100, 2) : 0;

		return sprintf(
			'<!-- HTML compressed: %s%% saved (%d → %d bytes) -->',
			$savings,
			$rawBytes,
			$compressedBytes,
		);
	}

	/**
	 * Generate placeholder key.
	 */

	private function placeholderKey(int $index): string {
		return '%%WPHAVE_HTML_COMPRESSION_' . $index . '%%';
	}
}

/**
 * Compress rendered HTML using the configured WPHAVE compression rules.
 *
 * @param string $html Rendered HTML markup.
 * @return string Compressed HTML markup.
 */

if (!function_exists('wphave_html_compression')):
	function wphave_html_compression(string $html): string {
		if (function_exists('wphave_events')) {
			wphave_events('OUTPUT', 'Compress the HTML output of the entire site.');
		}

		return (string) new WPHAVE_HTML_Compression($html, [
			'remove_comments' => true,
			'info_comment' => defined('WP_DEBUG') && WP_DEBUG,
			'compress_inline_css' => true,
			'compress_inline_js' => true,
		]);
	}
endif;
