<?php

/**
 * Lightweight opt-in event logging for WPHAVE runtime diagnostics.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once wphave_dir() . 'inc/features/security/boundaries/index.php';

/**
 * Write a runtime diagnostic event when event tracking is enabled.
 *
 * @param string $flag Event category flag.
 * @param string $note Diagnostic message.
 * @return bool|null False when tracking is disabled, otherwise null.
 */

if ( ! function_exists( 'wphave_events' ) ) :

	function wphave_events( $flag, $note ) {

		if( ! WPHAVE_EVENTS_TRACK ) {
			return false;
		}

		// Output specific events only
		if( WPHAVE_EVENTS_TRACK_FLAG === $flag ) {
			error_log( '[' . sanitize_key( $flag ) . '] ' . WPHAVE_Security_Redactor::error_text( $note, 1000 ) );
		}

		if( WPHAVE_EVENTS_TRACK_FLAG !== 'ALL' ) {
			return;
		}

		// Output all events
		error_log( '[' . sanitize_key( $flag ) . '] ' . WPHAVE_Security_Redactor::error_text( $note, 1000 ) );

	}

endif;
