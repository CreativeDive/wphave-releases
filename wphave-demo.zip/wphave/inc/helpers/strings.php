<?php

/**
 * Shared null-safe and multibyte-aware string helpers.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Replace values without passing null to PHP's str_replace().
 *
 * @param string|array|null $search  Value or values to search for.
 * @param string|array|null $replace Replacement value or values.
 * @param string|array|null $string  Subject to process.
 * @return string|array|null Processed subject or the unchanged subject for null input.
 */

if ( ! function_exists( 'wphave_replace' ) ) :

	function wphave_replace( $search, $replace, $string ) {

		if( $search === null || $replace === null || $string === null ) {
			return $string;
		}

		return str_replace( $search, $replace, $string );

	}

endif;


/**
 * Determine whether a string contains the given value.
 *
 * @param mixed  $value  Value to inspect.
 * @param string $string String to find.
 * @return bool Whether the value contains the string.
 */

if ( ! function_exists( 'wphave_str_contains' ) ) :

	function wphave_str_contains( $value, $string ) {

        if( ! is_string( $value ) || ! $value ) {
            return false;
        }

		if( strpos( $value, $string ) !== false ) {
            return true;
        }

        return false;

	}

endif;


/**
 * Return a multibyte-safe string length when mbstring is available.
 *
 * @param string $string Input string.
 * @return int String length.
 */

function wphave_strlen( $string ) {
    // Fallback if "mbstring" is not available
    return function_exists( 'mb_strlen' )
        ? mb_strlen( $string )
        : strlen( $string );
}

/**
 * Return a multibyte-safe substring when mbstring is available.
 *
 * @param string $string Input string.
 * @param int $start Start offset.
 * @param int|null $length Optional length.
 * @return string
 */

function wphave_substr( $string, $start, $length = null ) {
    // Fallback if "mbstring" is not available
    return function_exists( 'mb_substr' )
        ? mb_substr( $string, $start, $length )
        : substr( $string, $start, $length );
}
