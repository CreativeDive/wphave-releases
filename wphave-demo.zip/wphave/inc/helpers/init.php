<?php

/**
 * Bootstrap the shared WPHAVE runtime helpers.
 *
 * Keep this file limited to deterministic includes. Runtime decisions belong
 * to their respective context, feature or diagnostics modules.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/paths.php';
require_once dirname( __DIR__ ) . '/theme/context.php';
require_once dirname( __DIR__ ) . '/features/feature-gates.php';
require_once __DIR__ . '/request-context.php';
require_once __DIR__ . '/post-save-context.php';
require_once dirname( __DIR__ ) . '/features/runtime-context.php';
require_once __DIR__ . '/events.php';

require_once __DIR__ . '/filesystem.php';
require_once __DIR__ . '/strings.php';
require_once dirname( __DIR__ ) . '/ui/layers/close-button.php';
require_once dirname( __DIR__ ) . '/ui/layers/functions.php';
