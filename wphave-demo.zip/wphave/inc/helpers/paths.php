<?php

/**
 * Plugin path and controlled runtime include helpers.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Resolve the canonical public scheme for browser-facing WPHAVE resources.
 *
 * The configured home URL is authoritative because TLS commonly terminates at a
 * reverse proxy before WordPress. Request-derived helpers may therefore report
 * HTTP while the browser document and every usable asset URL must remain HTTPS.
 *
 * @return string HTTP or HTTPS.
 */

if ( ! function_exists( 'wphave_public_url_scheme' ) ) :

	function wphave_public_url_scheme() {
		$scheme = wp_parse_url( home_url(), PHP_URL_SCHEME );

		return in_array( $scheme, array( 'http', 'https' ), true )
			? $scheme
			: ( is_ssl() ? 'https' : 'http' );
	}

endif;

/**
 * Align an existing public URL with the canonical browser-facing scheme.
 *
 * @param string $url Absolute HTTP(S) URL supplied by WordPress or a provider.
 * @return string Scheme-normalized URL, or the original non-HTTP URL.
 */

if ( ! function_exists( 'wphave_public_url' ) ) :

	function wphave_public_url( $url ) {
		$url = (string) $url;
		$scheme = wp_parse_url( $url, PHP_URL_SCHEME );

		if( ! in_array( $scheme, array( 'http', 'https' ), true ) ) {
			return $url;
		}

		// PUBLIC ORIGIN INVARIANT: Only the transport scheme is canonicalized.
		// Provider, CDN and multisite hosts plus their complete paths remain owned
		// by WordPress and must never be rewritten to the home URL host.
		return set_url_scheme( $url, wphave_public_url_scheme() );
	}

endif;

/**
 * Build a browser-loadable URL relative to the WPHAVE plugin directory.
 *
 * @param string $path Optional plugin-relative asset path.
 * @return string Absolute public plugin URL.
 */

if ( ! function_exists( 'wphave_asset_url' ) ) :

	function wphave_asset_url( $path = '' ) {
		$base_url = wphave_public_url( plugin_dir_url( WPHAVE_FILE_PATH ) );

		// PUBLIC ASSET URL INVARIANT: Preserve the host and complete plugin base
		// supplied by WordPress (including CDN filters), normalize only its public
		// scheme, and prevent a caller's leading slash from discarding that base.
		return trailingslashit( $base_url ) . ltrim( (string) $path, '/' );
	}

endif;


/**
 * Resolve the canonical WordPress installation root.
 *
 * @return string Canonical absolute root without a trailing slash, or empty.
 */

if ( ! function_exists( 'wphave_wordpress_root_path' ) ) :

	function wphave_wordpress_root_path() {
		$root = realpath( ABSPATH );

		return false !== $root && is_dir( $root )
			? untrailingslashit( wp_normalize_path( $root ) )
			: '';
	}

endif;


/**
 * Resolve a file below the canonical WordPress installation root.
 *
 * @param string $path WordPress-root-relative file path.
 * @return string Absolute filesystem path, or an empty string when invalid.
 */

if ( ! function_exists( 'wphave_wordpress_file_path' ) ) :

	function wphave_wordpress_file_path( $path ) {
		$path = ltrim( wp_normalize_path( (string) $path ), '/' );

		if( '' === $path || str_contains( $path, "\0" ) || preg_match( '#(?:^|/)\.\.(?:/|$)#', $path ) ) {
			return '';
		}

		$root = wphave_wordpress_root_path();

		// WORDPRESS FILE IDENTITY INVARIANT: Readers, status probes and writers
		// name one canonical installation root. An unresolved root fails closed;
		// no operation falls back to a process-relative path.
		return '' !== $root
			? trailingslashit( $root ) . $path
			: '';
	}

endif;


/**
 * Resolve a public home-root file only when WordPress proves its filesystem map.
 *
 * @param string $path Home-root-relative file path.
 * @return string Absolute filesystem path, or an empty string when unknown.
 */

if ( ! function_exists( 'wphave_public_home_file_path' ) ) :

	function wphave_public_home_file_path( $path ) {
		$path = ltrim( wp_normalize_path( (string) $path ), '/' );

		if( '' === $path || str_contains( $path, "\0" ) || preg_match( '#(?:^|/)\.\.(?:/|$)#', $path ) ) {
			return '';
		}

		$home_path = '/' . trim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
		$site_path = '/' . trim( (string) wp_parse_url( site_url( '/' ), PHP_URL_PATH ), '/' );

		// PUBLIC HOME FILE INVARIANT: ABSPATH is the filesystem counterpart of
		// site_url(), not necessarily home_url(). A differing URL base path leaves
		// the public document-root mapping unknown and therefore disables local
		// fallback instead of reading an unrelated WordPress-root file.
		if( untrailingslashit( $home_path ) !== untrailingslashit( $site_path ) ) {
			return '';
		}

		return wphave_wordpress_file_path( $path );
	}

endif;


/**
 * Build a filesystem path relative to the WPHAVE plugin directory.
 *
 * @param string $path Optional relative path.
 * @return string Absolute plugin filesystem path.
 */

if ( ! function_exists( 'wphave_dir' ) ) :

	function wphave_dir( $path = '' ) {
		// FILESYSTEM PATH INVARIANT: Server-side file operations resolve only from
		// the installed plugin directory and never derive paths from public URLs.
		return plugin_dir_path( WPHAVE_FILE_PATH ) . ltrim( (string) $path, '/\\' );

	}

endif;


/**
 * Include an existing PHP file once.
 *
 * @param string $file_path Absolute file path.
 * @param bool   $required  Whether to use require_once instead of include_once.
 * @return bool Whether the file existed and was included.
 */

if ( ! function_exists( 'wphave_include_file' ) ) :

	function wphave_include_file( $file_path, $required = false ) {

		if( ! is_string( $file_path ) || ! file_exists( $file_path ) ) {
			return false;
		}

		if( $required ) {
			require_once $file_path;
		} else {
			include_once $file_path;
		}

		return true;

	}

endif;
