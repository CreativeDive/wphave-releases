<?php

/**
 * Resolve the WordPress upload directory with an optional safe subfolder.
 *
 * @param array|string $args Optional arguments containing a subfolder value.
 * @return array Upload base directory, URL and error state.
 */

if ( ! function_exists( 'wphave_get_upload_dir' ) ) :

	function wphave_get_upload_dir( $args = '' ) {

		$args = is_array( $args ) ? $args : array();
		$subfolder = trim( wp_normalize_path( (string) ( $args['subfolder'] ?? '' ) ), '/' );
		$subfolder_parts = array_filter( explode( '/', $subfolder ), 'strlen' );
		// SECURITY INVARIANT: Each path component is reduced to a filename before
		// joining, so caller input cannot introduce traversal outside the upload root.
		$subfolder_parts = array_map( 'sanitize_file_name', $subfolder_parts );
		$subfolder_parts = array_filter( $subfolder_parts, 'strlen' );
		$subfolder = implode( '/', $subfolder_parts );
		$upload_dir = wp_get_upload_dir();

		if( ! empty( $upload_dir['error'] ) ) {
			return array(
				'basedir' => '',
				'baseurl' => '',
				'error' => $upload_dir['error'],
			);
		}

		$file_path = $upload_dir['basedir'];
		$file_url = wphave_public_url( $upload_dir['baseurl'] );

		if( $subfolder ) {
			$file_path = path_join( $file_path, $subfolder );
			$file_url = trailingslashit( $file_url ) . $subfolder;
		}

		// UPLOAD ORIGIN INVARIANT: Preserve WordPress' upload/CDN host and path,
		// while aligning its scheme with the public document to prevent mixed content.
		return array(
			'basedir' => $file_path,
			'baseurl' => $file_url,
			'error' => false,
		);

	}

endif;

/**
 * Initialize and return the WordPress filesystem transport.
 *
 * The filesystem bootstrap is loaded explicitly because callers may run on
 * frontend requests where the administration helper is not available yet.
 *
 * @return WP_Filesystem_Base|false Filesystem transport or false on failure.
 */

if ( ! function_exists( 'wphave_file_system' ) ) :

	function wphave_file_system() {

		if( ! function_exists('WP_Filesystem') ) {
			// We have to include this WordPress file, if "WP_Filesystem()" is called outside of wp admin.
			require_once( ABSPATH . 'wp-admin/includes/file.php' );
		}

		// Initialize the WordPress filesystem before exposing the global transport.
		global $wp_filesystem;
		if( ! WP_Filesystem() || ! is_object( $wp_filesystem ) ) {
			return false;
		}

		return $wp_filesystem;

	}

endif;
