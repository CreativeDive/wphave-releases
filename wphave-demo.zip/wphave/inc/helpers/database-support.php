<?php

/** Database compatibility and upstream maintenance policy for all diagnostics. */
if (!defined('ABSPATH')) {
	exit();
}

require_once dirname(__DIR__) . '/runtime/support.php';

final class WPHAVE_Database_Support {
	public static function is_sqlite($database): bool {
		return is_object($database) && is_a($database, 'WP_SQLite_DB');
	}

	/** Use the server banner: db_version() can retain MariaDB's 5.5.5 prefix. */
	public static function current($database): array {
		$sqlite = self::is_sqlite($database);
		$version = method_exists($database, 'db_version') ? (string) $database->db_version() : '';
		$server =
			!$sqlite && method_exists($database, 'db_server_info')
				? (string) $database->db_server_info()
				: '';
		$type = $sqlite ? 'SQLite' : (stripos($server, 'mariadb') !== false ? 'MariaDB' : 'MySQL');
		return self::evaluate($server ?: $version, $type);
	}

	public static function evaluate(string $version, string $type, ?int $now = null): array {
		$now ??= time();
		$sqlite = $type === 'SQLite';
		$maria = $type === 'MariaDB';
		$minimum = $sqlite ? null : ($maria ? WPHAVE_MARIADB_VERSION : WPHAVE_MYSQL_VERSION);
		$recommended = $sqlite
			? null
			: WPHAVE_Runtime_Support::recommended($maria ? 'mariadb' : 'mysql', $now);
		$raw = $maria ? preg_replace('/^5\.5\.5-/', '', $version) : $version;
		$stable =
			preg_match('/^(\d+\.\d+)(?:\.\d+)?(?=$|[-+\s])/', $raw, $match) === 1 &&
			!preg_match('/(?:alpha|beta|rc\d|preview|dev)/i', $raw);
		$release = $stable ? $match[0] : '';
		$branch = $stable ? $match[1] : '';
		$compatible = $sqlite || ($stable && version_compare($release, $minimum, '>='));
		$support = $sqlite
			? [
				'securityStatus' => 'not-applicable',
				'securityUntil' => null,
				'supportEvidence' => null,
			]
			: WPHAVE_Runtime_Support::evaluate($maria ? 'mariadb' : 'mysql', $branch, $now);
		// Forks/managed-service banners do not establish the vendor's own policy.
		if (!$sqlite && preg_match('/percona|aurora|tidb|vitess|oceanbase/i', $version)) {
			$support = [
				'securityStatus' => 'unknown',
				'securityUntil' => null,
				'supportEvidence' => null,
			];
		}
		return [
			'type' => $type,
			'version' => $release ?: $version,
			'versionKnown' => $stable,
			'isSqlite' => $sqlite,
			'minVersion' => $minimum,
			'recommendedVersion' => $recommended,
			'compatible' => $compatible,
			'recommended' =>
				!$sqlite &&
				$compatible &&
				$support['securityStatus'] === 'supported' &&
				$recommended !== null &&
				version_compare($branch, $recommended, '>='),
			...$support,
		];
	}
}
