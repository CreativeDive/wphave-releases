<?php

/** Global revision retention guidance, shared by all diagnostic consumers. */
if (!defined('ABSPATH')) {
	exit();
}

final class WPHAVE_Revision_Policy {
	public static function current(): array {
		return self::evaluate(defined('WP_POST_REVISIONS') ? WP_POST_REVISIONS : true);
	}

	public static function evaluate($value): array {
		// Match WordPress: true and negative integers mean unlimited; false means zero.
		$valid =
			is_bool($value) ||
			is_int($value) ||
			(is_string($value) && preg_match('/^-?\d+$/D', $value));
		$count = $value === true ? -1 : (int) $value;
		$state = !$valid
			? 'unknown'
			: ($count < 0
				? 'unlimited'
				: ($count === 0
					? 'disabled'
					: 'limited'));
		return [
			'state' => $state,
			'status' => in_array($state, ['disabled', 'unknown'], true) ? 'info' : 'ok',
			'value' => match ($state) {
				'disabled' => __('Disabled', 'wphave'),
				'unlimited' => __('Unlimited', 'wphave'),
				'limited' => (string) $count,
				default => __('Unknown', 'wphave'),
			},
			'hint' => __(
				'Revisions preserve recovery history. Consider 10 revisions per post as a starting point; other positive limits and unlimited history are valid choices. The global setting can be overridden per post type or post. This setting alone does not establish a performance problem.',
				'wphave',
			),
		];
	}
}
