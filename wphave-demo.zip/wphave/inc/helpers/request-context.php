<?php

/**
 * Read one scalar string from a request collection.
 *
 * INPUT INVARIANT: PHP query and form syntax can turn any expected scalar into
 * an array. Callers must reject that shape before WordPress string sanitizers,
 * URL helpers or numeric normalizers receive it.
 *
 * @param array  $source Request collection such as $_GET, $_POST or $_REQUEST.
 * @param string $key Request key.
 * @param string $default Value returned for missing or non-string input.
 * @return string Unslashed scalar request value.
 */
function wphave_request_string( array $source, string $key, string $default = '' ): string {
	if( ! array_key_exists( $key, $source ) || ! is_string( $source[$key] ) ) {
		return $default;
	}

	return wp_unslash( $source[$key] );
}

/**
 * Resolve the current WordPress admin, editor and post-type context.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return the current WordPress admin screen when it is available.
 *
 * @return WP_Screen|false Current screen object or false outside a valid admin screen.
 */

if ( ! function_exists( 'wphave_current_screen' ) ) :

	function wphave_current_screen() {

		if( ! is_admin() || ! function_exists('get_current_screen') ) {
			// Current screen is not always available
			// Do not continue here, because "get_current_screen" is only a backend function
			return false;
		}

        global $current_screen;

		$screen = $current_screen ?? get_current_screen();

        if( ! is_object( $screen ) ) {
            return false;
        }

		return $screen;

	}

endif;


/**
 * Determine whether the current admin screen uses the block editor.
 *
 * @return bool Whether the current screen is a block editor.
 */

if ( ! function_exists( 'wphave_is_block_editor' ) ) :

    function wphave_is_block_editor() {

        if( ! is_admin() ) {
            return false;
        }

        $current_screen = wphave_current_screen();

		if( $current_screen ) {
			if( method_exists( $current_screen, 'is_block_editor' ) && $current_screen->is_block_editor() ) {
				return true;
			}
		}

		return false;

    }

endif;


/**
 * Resolve the current post type from the available request context.
 *
 * Explicit post IDs take priority, followed by sanitized request values,
 * global post state and the current admin screen.
 *
 * @param int|string $post_id Optional post ID.
 * @return string|null Post type name or null when it cannot be resolved.
 */

if ( ! function_exists( 'wphave_current_post_type' ) ) :

	function wphave_current_post_type( $post_id = '' ) {
		if( $post_id ) {
			return get_post_type( absint( $post_id ) );
		}

		if( isset( $_REQUEST['post'] ) ) {
			$request_post_id = absint( wphave_request_string( $_REQUEST, 'post' ) );
			if( $request_post_id ) {
				return get_post_type( $request_post_id );
			}
		}

		if( isset( $_REQUEST['post_type'] ) ) {
			$request_post_type = sanitize_key( wphave_request_string( $_REQUEST, 'post_type' ) );
			if( post_type_exists( $request_post_type ) ) {
				return $request_post_type;
			}
		}

		global $post;
		if( $post instanceof WP_Post ) {
			return $post->post_type;
		}

		global $typenow;
		if( $typenow && post_type_exists( $typenow ) ) {
			return sanitize_key( $typenow );
		}

		$current_screen = wphave_current_screen();
		if( $current_screen && ! empty( $current_screen->post_type ) ) {
			return sanitize_key( $current_screen->post_type );
		}

		return null;

	}

endif;
