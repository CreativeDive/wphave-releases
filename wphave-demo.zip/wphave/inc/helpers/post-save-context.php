<?php

/**
 * Resolve the current WordPress post-save request context.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Determine whether the current post save matches one of the given actions.
 *
 * @param int     $post_id      Post ID being saved.
 * @param WP_Post $post         Post object being saved.
 * @param array   $save_actions Save action identifiers to match.
 * @return bool Whether the current save action is in the supplied list.
 */

if ( ! function_exists( 'wphave_doing_wp_save_post_action' ) ) :

    function wphave_doing_wp_save_post_action( $post_id, $post, $save_actions = array() ) {

		// If a specific post save action will performed, stop here and return
		$save_action = wphave_wp_save_post_action( $post_id, $post );

		if( in_array( $save_action, $save_actions ) ) {
			return true;
		}

		return false;

    }

endif;


/**
 * Resolve the current WordPress post-save action.
 *
 * @param int     $post_id Post ID being saved.
 * @param WP_Post $post    Post object being saved.
 * @return string|false Save action identifier or false for a regular save.
 */

if ( ! function_exists( 'wphave_wp_save_post_action' ) ) :

    function wphave_wp_save_post_action( $post_id, $post ) {

		// Creating auto draft
		if( isset( $post->post_status ) && 'auto-draft' === $post->post_status ) {
			return 'auto-draft';
		}

		// Auto saving
		if( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) {
			return 'auto-save';
		}

		// AJAX
		if( defined('DOING_AJAX') && DOING_AJAX ) {
			return 'ajax';
		}

		// Saving post revision
		if( false !== wp_is_post_revision( $post_id ) ) {
			return 'revision';
		}

		// Rest request
		if( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return 'rest';
		}

		return false;

    }

endif;
