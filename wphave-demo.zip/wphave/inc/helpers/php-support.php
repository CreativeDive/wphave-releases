<?php

/** PHP release policy shared by diagnostics and the security scanner. */
if (!defined('ABSPATH')) {
	exit();
}

require_once dirname(__DIR__) . '/runtime/support.php';

final class WPHAVE_PHP_Support {
	/** Review against https://www.php.net/supported-versions.php for each release. */
	public static function evaluate(string $version = PHP_VERSION, ?int $now = null): array {
		$minimum = WPHAVE_PHP_VERSION;
		$recommended = WPHAVE_Runtime_Support::recommended('php', $now);
		$now ??= time();
		$stable =
			preg_match('/^(\d+\.\d+)(\.\d+)?(?:[-+~][0-9A-Za-z.+~_-]+)?$/D', $version, $match) ===
				1 && !preg_match('/(?:alpha|beta|rc|dev)/i', $version);
		$release = $stable ? $match[1] . ($match[2] ?? '.0') : '';
		$branch = $stable ? $match[1] : '';
		$support = WPHAVE_Runtime_Support::evaluate('php', $branch, $now);

		return [
			'minVersion' => $minimum,
			'recommendedVersion' => $recommended,
			'supportedVersions' => array_values(
				array_filter(
					array_column(
						WPHAVE_Runtime_Support::product('php')['branches'] ?? [],
						'branch',
					),
					static fn($branch) => version_compare($branch, $minimum, '>='),
				),
			),
			'compatible' => $stable && version_compare($release, $minimum, '>='),
			'recommended' =>
				$stable && $branch === $recommended && $support['securityStatus'] === 'supported',
			...$support,
		];
	}
}
