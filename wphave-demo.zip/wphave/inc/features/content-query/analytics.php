<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * Return recent and lifetime analytics for a post.
 *
 *  - Recent views (last 30 days)
 *  - Lifetime views (all time)
 *
 * @param int $post_id
 * @return array
 */

if ( ! function_exists( 'wphave_get_post_analytics_data' ) ) :

    function wphave_get_post_analytics_data( $post_id ) {

        global $wpdb;

        $table = $wpdb->prefix . 'wphave_analytics_daily';
        $recent_threshold = current_datetime()->modify('-30 days')->format('Y-m-d');

        $row = $wpdb->get_row(
            $wpdb->prepare(
                "
                SELECT
                    SUM(views) as lifetime,
                    SUM(CASE
                        WHEN view_date >= %s
                        THEN views ELSE 0
                    END) as recent
                FROM {$table}
                WHERE post_id = %d
                ",
                $recent_threshold,
                $post_id
            )
        );

        return [
            'views_recent' => (int) ( $row->recent ?? 0 ),
            'views_lifetime' => (int) ( $row->lifetime ?? 0 ),
        ];

    }

endif;


/**
 * Update the post analytics cache.
 *
 * @return void
 */

if ( ! function_exists( 'wphave_update_post_analytics_cache' ) ) :

    function wphave_update_post_analytics_cache() {

        global $wpdb;

        $table = $wpdb->prefix . 'wphave_analytics_daily';
        $recent_threshold = current_datetime()->modify('-2 days')->format('Y-m-d');

        $post_ids = $wpdb->get_col(
            $wpdb->prepare(
                "
                SELECT DISTINCT post_id
                FROM {$table}
                WHERE view_date >= %s
                ",
                $recent_threshold
            )
        );

        if( empty( $post_ids ) ) {
            return;
        }

        foreach( $post_ids as $post_id ) {
            WPHAVE_Post_Cache::update_cache_analytics( $post_id );
        }

    }

endif;

add_action( 'wphave_analytics_aggregate_daily', 'wphave_update_post_analytics_cache' );


/**
 * Return post views for the requested period.
 *
 *  - recent (default)
 *  - lifetime
 *
 * @param int|null $post_id
 * @param string $type recent|lifetime
 * @return int
 */

if ( ! function_exists( 'wphave_post_views' ) ) :

    function wphave_post_views( $post_id = null, $type = 'recent' ) {

        return WPHAVE_Post_Cache::get_views( $post_id, $type );

    }

endif;


/**
 * Return the total post views.
 *
 * @param int|null $post_id
 * @return int
 */

if ( ! function_exists( 'wphave_post_views_total' ) ) :

    function wphave_post_views_total( $post_id = null ) {

        return WPHAVE_Post_Cache::get_views( $post_id, 'lifetime' );

    }

endif;
