<?php

/**
 * Expose WordPress random ordering to the Loop editor preview.
 *
 * WordPress accepts `rand` in WP_Query but omits it from post REST collection
 * parameters. The frontend Loop already uses WP_Query; this adapter lets the
 * editor request the same ordering for public content types.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function wphave_random_order_collection_params( $params ) {
	if ( isset( $params['orderby']['enum'] ) && is_array( $params['orderby']['enum'] ) ) {
		$params['orderby']['enum'][] = 'rand';
		$params['orderby']['enum'] = array_values( array_unique( $params['orderby']['enum'] ) );
	}

	return $params;
}

function wphave_random_order_query( $args, $request ) {
	if ( $request->get_param( 'orderby' ) === 'rand' ) {
		$args['orderby'] = 'rand';
	}

	return $args;
}

function wphave_register_random_order_rest_filters() {
	foreach ( get_post_types( array( 'public' => true, 'show_in_rest' => true ), 'names' ) as $post_type ) {
		add_filter( "rest_{$post_type}_collection_params", 'wphave_random_order_collection_params' );
		add_filter( "rest_{$post_type}_query", 'wphave_random_order_query', 10, 2 );
	}
}

add_action( 'rest_api_init', 'wphave_register_random_order_rest_filters', 9 );
