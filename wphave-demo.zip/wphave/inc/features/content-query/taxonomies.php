<?php

/**
 * Output the parent terms of a post type item.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Output the parent terms of a post type item.
 */

if ( ! function_exists( 'wphave_get_taxonomy_terms' ) ) :

	function wphave_get_taxonomy_terms( $post_id, $taxonomy, $args = '' ) {

		$args = is_array( $args ) ? $args : array();
		$post_id = absint( $post_id );
		$taxonomy = sanitize_key( $taxonomy );
		$limit = max( 0, absint( $args['limit'] ?? $args['depth'] ?? 0 ) );
		$cache_key = md5( wp_json_encode( array(
			'post_id' => $post_id,
			'taxonomy' => $taxonomy,
			'limit' => $limit,
		) ) );

		static $request_cache = array();

		if( array_key_exists( $cache_key, $request_cache ) ) {
			return $request_cache[$cache_key];
		}

		if( ! $post_id || ! taxonomy_exists( $taxonomy ) ) {
			$request_cache[$cache_key] = array();
			return array();
		}

		$terms = get_the_terms( $post_id, $taxonomy );

		if( ! $terms || is_wp_error( $terms ) ) {
			$request_cache[$cache_key] = array();
			return array();
		}

		if( $limit ) {
			$terms = array_slice( $terms, 0, $limit );
		}

		$data = array();

		foreach( $terms as $term ) {
			$term_link = get_term_link( $term );

			if( is_wp_error( $term_link ) || ! $term->name ) {
				continue;
			}

			$data[] = array(
				'id' => absint( $term->term_id ),
				'taxonomy' => sanitize_key( $term->taxonomy ),
				'url' => esc_url_raw( $term_link ),
				'name' => $term->name,
				'description' => $term->description,
			);
		}

		$request_cache[$cache_key] = $data;

		return $data;

	}

endif;


/**
 * Output categories for a post of a specific post type.
 */

if ( ! function_exists( 'wphave_get_categories' ) ) :

	function wphave_get_categories( $post_id, $args = '' ) {
		$args = is_array( $args ) ? $args : array();
		$raw = isset( $args['list'] ) ? $args['list'] : '';
		$depth = absint( $args['depth'] ?? 0 );

		$taxonomy = 'category';
		$post_type = get_post_type( $post_id );

		if( post_type_exists( $post_type ) ) {

			$tax_args = array(
				'object_type' => array( $post_type ),
			);

			// Get the taxonomies by the current post type
			$taxonomies = get_taxonomies( $tax_args, 'names' );

			if( is_array( $taxonomies ) ) {

				// We use the first listed taxonomy (in most cases the category taxonomy)
				$taxonomies = array_values( $taxonomies );

				foreach( $taxonomies as $tax ) {
					if( wphave_str_contains( $tax, 'category' ) || wphave_str_contains( $tax, '_cat' ) ) {
						$taxonomy = $tax;
						break;
					}
				}

			}

		}

        $categories = get_the_terms( $post_id, $taxonomy );

		if( ! empty( $categories ) && ! is_wp_error( $categories ) ) {

			$i = 0;

			$the_cats = array();

			if( $raw ) {
				foreach( $categories as $category ) {
					$the_cats[] = $category->name;

					$i+=1;

					if( $depth ) {
						if( $i === $depth ) {
							break; // limit categories to 2 items
						}
					}

				}
				return implode( ', ', $the_cats );
			}

        	foreach( $categories as $category ) {

				$the_cats[$i]['taxonomy'] = $category->taxonomy;
				$term_link = get_term_link( $category );
				if( is_wp_error( $term_link ) ) {
					continue;
				}
				$the_cats[$i]['id'] = $category->term_id;
				$the_cats[$i]['url'] = $term_link;
				$the_cats[$i]['name'] = $category->name;

                $i+=1;

				if( $depth ) {
					if( $i === $depth ) {
						break; // limit categories to 2 items
					}
				}

			}

			return $the_cats;

		}

		// No categories found
		return false;

	}

endif;


/**
 * Output tags for a post of a specific post type.
 */

if ( ! function_exists( 'wphave_get_tags' ) ) :

	function wphave_get_tags( $post_id, $args = '' ) {
		$args = is_array( $args ) ? $args : array();
		$raw = isset( $args['list'] ) ? $args['list'] : '';
		$depth = absint( $args['depth'] ?? 0 );

		$taxonomy = 'post_tag';
		$post_type = get_post_type( $post_id );

		if( post_type_exists( $post_type ) ) {

			$tax_args = array(
				'object_type' => array( $post_type ),
			);

			// Get the taxonomies by the current post type
			$taxonomies = get_taxonomies( $tax_args, 'names' );

			if( is_array( $taxonomies ) ) {

				// We use the first listed taxonomy (in most cases the category taxonomy)
				$taxonomies = array_values( $taxonomies );

				foreach( $taxonomies as $tax ) {
					if( wphave_str_contains( $tax, '_tag' ) || wphave_str_contains( $tax, 'post_tag' ) ) {
						$taxonomy = $tax;
						break;
					}
				}

			}

		}

		$tags = get_the_terms( $post_id, $taxonomy );

		if( ! empty( $tags ) && ! is_wp_error( $tags ) ) {

			$i = 0;

			$the_tags = array();

			if( $raw ) {
				foreach( $tags as $tag ) {
					$the_tags[] = $tag->name;

					$i+=1;

					if( $depth ) {
						if( $i === $depth ) {
							break; // limit tags to 2 items
						}
					}

				}
				return implode( ', ', $the_tags );
			}

        	foreach( $tags as $tag ) {

				$the_tags[$i]['taxonomy'] = $tag->taxonomy;
				$term_link = get_term_link( $tag );
				if( is_wp_error( $term_link ) ) {
					continue;
				}
				$the_tags[$i]['id'] = $tag->term_id;
				$the_tags[$i]['url'] = $term_link;
				$the_tags[$i]['name'] = $tag->name;

                $i+=1;

				if( $depth ) {
					if( $i === $depth ) {
						break; // limit tags to 2 items
					}
				}

			}

			return $the_tags;

		}

		// No tags found
		return false;

	}

endif;
