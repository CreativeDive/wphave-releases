<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Function to output all post types with slug and data.
 */

if ( ! function_exists( 'wphave_get_all_post_types' ) ) :

	function wphave_get_all_post_types() {

		$post_args = array(
			'public' => true, // --> Only include public post types
		);

		// Get post types
		$post_types = get_post_types( $post_args, 'objects' );

		// Define a list of disallowed post types
		$disallowed_post_types = array(
			'attachment',
		);

		$results = array();

		if( $post_types ) {
			foreach( $post_types as $post_type_slug => $data ) {

				if( in_array( $post_type_slug, $disallowed_post_types) ) {
					unset( $post_types[$post_type_slug] );
					continue;
				}

				$results[$post_type_slug] = $data;

			}
		}

		return $results;

	}

endif;


/**
 * Function to check if a specific post with the passed title already exists.
 */

if ( ! function_exists( 'wphave_post_with_title_exists' ) ) :

	function wphave_post_with_title_exists( $title, $post_types = ['post'] ) {

		// Check if a post/page with the title already exists
        $query = new WP_Query( [
            'post_type' => $post_types,
            'post_status' => 'any',
            'title' => $title,
            'posts_per_page' => 1,
        ] );

        if( $query->have_posts() ) {
            return true; // post/page already exists
        }

		return false;

	}

endif;


/**
 * Function to get the excerpt of a post outside the loop.
 */

if ( ! function_exists( 'wphave_get_excerpt' ) ) :

	function wphave_get_excerpt( $post_id ) {

		global $post;

		$previous_post = $post;
		$post = get_post( $post_id );

		if( ! $post ) {
			$post = $previous_post;

			if( $post instanceof WP_Post ) {
				setup_postdata( $post );
			}

			return false;
		}

		setup_postdata( $post );

		$excerpt = get_the_excerpt();

		$post = $previous_post;

		if( $post instanceof WP_Post ) {
			setup_postdata( $post );
		} else {
			wp_reset_postdata();
		}

		if( $excerpt ) {
			return $excerpt;
		}

		return false;

	}

endif;


/**
 * Function to calculate the reading time of a post.
 */

if ( ! function_exists( 'wphave_reading_time' ) ) :

    function wphave_reading_time( $post = null, $wpm = 275 ) {

        // Get the main content
        $content = get_post_field( 'post_content', $post );

        // Clean up content
		// --> Remove HTML tags
		// --> Remove Shortcode tags
        $content_summary = strip_tags( strip_shortcodes( $content ) );

		// Get word count
		$word_count = count( preg_split( '/\s+/', trim( $content_summary ), -1, PREG_SPLIT_NO_EMPTY ) );

		if( preg_match( "/[\x{4e00}-\x{9fa5}]+/u", $content_summary ) ) {
			$cjk_count = preg_match_all( '/[\x{4e00}-\x{9fff}]/u', $content_summary );
			$latin_content = preg_replace( '/[\x{4e00}-\x{9fff}]/u', ' ', $content_summary );
			$word_count = (int) $cjk_count + str_word_count( (string) $latin_content );
		}

        // Calculate reading time
		$reading_time = ceil( $word_count / max( 1, absint( $wpm ) ) );

        return sprintf( /* translators: %s: contextual value. */
        esc_html__( '%s min', 'wphave' ), $reading_time );

    }

endif;
