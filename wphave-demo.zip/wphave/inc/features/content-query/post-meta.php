<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * Output the last modification or release date of a post.
 */

if ( ! function_exists( 'wphave_date' ) ) :

	function wphave_date( $post_id, $format = '' ) {

        $format = ( $format ? $format : get_option('date_format') );

        return get_the_date( $format, $post_id );

        // Show last modified date instead of the published date
        //return get_post_modified_time( $format, false, $post_id, true );

	}

endif;


/**
 * Output the last modification or release date <time> of a post.
 */

if ( ! function_exists( 'wphave_date_time' ) ) :

	function wphave_date_time( $post_id = '' ) {

        return get_the_date( DATE_W3C, $post_id );

        // Show last modified date <time> instead of the published date <time>
        //return get_the_modified_date( DATE_W3C, $post_id );

	}

endif;


/**
 * Function to output the post meta part for comments.
 */

if ( ! function_exists( 'wphave_post_meta_comments' ) ) :

	function wphave_post_meta_comments( $args = '' ) {

		$hide = $args['hide'] ?? '';
		$post_id = $args['post_id'] ?? get_the_ID();
		$label = $args['label'] ?? 'text';
		$icon = $args['icon'] ?? true;
		$icon_visibility = $args['icon_visibility'] ?? true;
		$link = $args['link'] ?? true;
		$comments_count = get_comments_number( $post_id );
		$comments_url = get_permalink( $post_id ) . '#comments';

		if( $hide ) {
			return;
		}

        $icon_output = $icon ? wp_kses_post( $icon ) : wphave_svg_ui_icon('comment', array('class' => 'icon'));

		if( $label === 'count' ) {

            if( $icon_visibility ) {
                echo $icon_output; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            } ?>

            <span class="meta-link"<?php if( $link ) { ?> onclick="location.href='<?php echo esc_url( $comments_url ); ?>';"<?php } ?>>
                <?php echo esc_html( $comments_count ); ?>
            </span>

		<?php

		} else {

            if( $icon_visibility ) {
                echo $icon_output; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            }

            if( $link ) { ?>
                <a href="<?php echo esc_url( $comments_url ); ?>">
            <?php }
                    if( (int) $comments_count === 0 ) {
                        echo esc_html__( 'No comments', 'wphave' );
                    } elseif( (int) $comments_count === 1 ) {
                        echo esc_html__( 'One comment', 'wphave' );
                    } else {
                        echo esc_html( sprintf( /* translators: %s: contextual value. */
                        __( '%s comments', 'wphave' ), number_format_i18n( $comments_count ) ) );
                    }
            if( $link ) { ?>
                </a>
            <?php }

		}

	}

endif;


/**
 * Function to output the post meta part for reading time.
 */

if ( ! function_exists( 'wphave_post_meta_reading_time' ) ) :

	function wphave_post_meta_reading_time( $args = '' ) {

		$hide = $args['hide'] ?? '';
		$post_id = $args['post_id'] ?? get_the_ID();
		$label = $args['label'] ?? 'text';
		$icon = $args['icon'] ?? '';
		$icon_visibility = $args['icon_visibility'] ?? true;

		if( $hide ) {
			return;
		}

        $icon_output = $icon ? wp_kses_post( $icon ) : wphave_svg_ui_icon('clock', array('class' => 'icon'));

		// Get the time
		$time = wphave_reading_time( $post_id );

		if( $label === 'count' ) {

            if( $icon_visibility ) {
                echo $icon_output; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            } ?>

            <span>
                <?php echo esc_html( $time ); ?>
            </span>

		<?php

		} else {

            if( $icon_visibility ) {
                echo $icon_output; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            } ?>

            <span>
                <?php echo esc_html( $time ) . ' ' . esc_html__('Reading Time', 'wphave'); ?>
            </span>

		<?php }

	}

endif;


/**
 * Function to output the post meta part for views.
 */

if ( ! function_exists( 'wphave_post_meta_views' ) ) :

	function wphave_post_meta_views( $args = '' ) {

		$hide = $args['hide'] ?? '';
		$post_id = $args['post_id'] ?? get_the_ID();
		$label = $args['label'] ?? 'text';
		$icon = $args['icon'] ?? '';
		$icon_visibility = $args['icon_visibility'] ?? true;

		if( $hide ) {
			return;
		}

        $icon_output = $icon ? wp_kses_post( $icon ) : wphave_svg_ui_icon('eye', array('class' => 'icon'));

		// Get the count
		$count = wphave_post_views_total( $post_id );

		// Get the post view label
		$text = __( 'Views', 'wphave' );
		if( $count == 1 ) {
			$text = __( 'View', 'wphave' );
		}

		if( $label === 'count' ) {

            if( $icon_visibility ) {
                echo $icon_output; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            } ?>

            <span>
                <?php echo esc_html( $count ); ?>
            </span>

		<?php

		} else {

            if( $icon_visibility ) {
                echo $icon_output; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            } ?>

            <span>
                <?php echo esc_html( $count ) . ' ' . esc_html( $text ); ?>
            </span>

		<?php }

	}

endif;


/**
 * Function to output the post meta part for rating score.
 */

if ( ! function_exists( 'wphave_post_meta_rating' ) ) :

	function wphave_post_meta_rating( $args = '' ) {

		$hide = $args['hide'] ?? '';
		$post_id = $args['post_id'] ?? get_the_ID();
		$label = $args['label'] ?? 'text';
		$icon = $args['icon'] ?? '';
		$icon_visibility = $args['icon_visibility'] ?? true;

		if( $hide ) {
			return;
		}

        $icon_output = $icon ? wp_kses_post( $icon ) : wphave_svg_ui_icon('star-outline', array('class' => 'icon'));

		// Get the count
		$count = wphave_post_ratings()->rating_score( absint( $post_id ) );

		if( $label === 'count' ) {

            if( $icon_visibility ) {
                echo $icon_output; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            } ?>

            <span>
                <?php echo esc_html( $count ); ?>
            </span>

		<?php

		} else {

            if( $icon_visibility ) {
                echo $icon_output; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            } ?>

            <span>
                <?php if( $count > 0 ) {
                    echo esc_html( $count ) . ' ' . esc_html__('Score', 'wphave');
                } else {
                    echo esc_html__('No Score', 'wphave');
                } ?>
            </span>

		<?php }

	}

endif;


/**
 * Function to output the post meta part for likes.
 */

if ( ! function_exists( 'wphave_post_meta_likes' ) ) :

	function wphave_post_meta_likes( $args = '' ) {

		$hide = $args['hide'] ?? '';
		$post_id = $args['post_id'] ?? get_the_ID();
		$label = $args['label'] ?? 'text';
		$icon = $args['icon'] ?? '';
		$icon_visibility = $args['icon_visibility'] ?? true;

		if( $hide ) {
			return;
		}

        $icon_output = $icon ? wp_kses_post( $icon ) : wphave_svg_ui_icon('heart-outline', array('class' => 'icon'));

		if( $label === 'count' ) {

            if( $icon_visibility ) {
                echo $icon_output; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            } ?>

            <span>
                <?php echo wphave_post_likes()->count_label( absint( $post_id ), array( 'hide_label' => true ) ); ?>
            </span>

		<?php

		} else {

            if( $icon_visibility ) {
                echo $icon_output; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            } ?>

            <span>
                <?php echo wphave_post_likes()->count_label( absint( $post_id ) ); ?>
            </span>

		<?php }

	}

endif;


/**
 * Function to output the post meta part for author.
 */

if ( ! function_exists( 'wphave_post_meta_author' ) ) :

	function wphave_post_meta_author( $args = '' ) {

		$hide = $args['hide'] ?? '';
		$post_id = $args['post_id'] ?? get_the_ID();
		$link = $args['link'] ?? true;
		$label = $args['label'] ?? 'text';
		$icon = $args['icon'] ?? '';
		$avatar_type = $args['avatar_type'] ?? 'avatar';
		$avatar_visibility = $args['avatar_visibility'] ?? true;

		if( $hide ) {
			return;
		}

        $icon_output = $icon ? wp_kses_post( $icon ) : wphave_svg_ui_icon('user', array('class' => 'icon'));

		$post = get_post( $post_id );
		$author_id = isset( $post->post_author ) ? $post->post_author : '';
		$author_url = get_author_posts_url( $author_id );
		$author_mail = get_the_author_meta( 'user_email', $author_id );
		$author_name = get_the_author_meta( 'display_name' , $author_id );
		$load_avatars = get_option('show_avatars');

		if( $label === 'count' ) { ?>

            <span class="meta-link" onclick="location.href='<?php echo esc_url( $author_url ); ?>';" title="<?php echo esc_attr__( 'Author', 'wphave' ) . ': ' . esc_attr( $author_name ); ?>">
                <?php if( $avatar_type === 'avatar' ) {
                    echo wphave_get_avatar( array(
                        'user_mail' => $author_mail,
                        'size' => 'thumbnail',
                        'gravatar_size' => 46,
                    ) );
                } else {
                    echo $icon_output; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                } ?>
            </span>

		<?php

		} else {

            if( $avatar_visibility ) {
                if( $avatar_type === 'icon' || ! $load_avatars ) {
                    echo $icon_output; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                } else {
                    echo wphave_get_avatar( array(
                        'user_mail' => $author_mail,
                        'size' => 'thumbnail',
                        'gravatar_size' => 36,
                    ) );
                }
            } ?>

            <span>
                <?php if( $link ) { ?>
                    <a href="<?php echo esc_url( $author_url ); ?>">
                <?php }
                        echo esc_html( $author_name );
                if( $link ) { ?>
                    </a>
                <?php } ?>
            </span>

		<?php }

	}

endif;
