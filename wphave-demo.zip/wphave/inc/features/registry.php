<?php

/**
 * Return the canonical WPHAVE feature bootstrap registry.
 */

if (!defined('ABSPATH')) {
	exit();
}

return [
	'multisite' => [
		'entrypoints' => [
			'core' => wphave_dir() . 'inc/admin/features/multisite/lifecycle.php',
			'management' => wphave_dir() . 'inc/admin/features/multisite/bootstrap.php',
			'worker' => wphave_dir() . 'inc/admin/features/multisite/bootstrap.php',
		],
	],
	'activity' => [
		'entrypoints' => [
			'core' => wphave_dir() . 'inc/admin/features/activity/lifecycle.php',
			'frontend' => wphave_dir() . 'inc/admin/features/activity/frontend.php',
			'management' => wphave_dir() . 'inc/admin/features/activity/management.php',
			'worker' => wphave_dir() . 'inc/admin/features/activity/worker.php',
		],
		'gate' => 'wphave_activity_feature_enabled',
		'gated_contexts' => ['frontend', 'management', 'worker'],
	],
	'presence' => [
		'entrypoints' => [
			'worker' => wphave_dir() . 'inc/admin/user/presence/worker.php',
		],
		'gate' => 'wphave_presence_feature_enabled',
	],
	'revisions' => [
		'entrypoints' => [
			'management' => wphave_dir() . 'inc/admin/features/revisions/bootstrap.php',
		],
	],
	'content-query' => [
		'entrypoints' => ['core' => wphave_dir() . 'inc/features/content-query/bootstrap.php'],
	],
	'media' => [
		'entrypoints' => [
			'core' => wphave_dir() . 'inc/features/media/bootstrap.php',
			'management' => wphave_dir() . 'inc/features/media/management.php',
		],
		'dependencies' => ['security'],
	],
	'security' => [
		'entrypoints' => [
			'core' => wphave_dir() . 'inc/features/security/core.php',
			'frontend' => wphave_dir() . 'inc/features/security/frontend.php',
			'management' => wphave_dir() . 'inc/features/security/management.php',
			'worker' => wphave_dir() . 'inc/features/security/worker.php',
		],
	],
	'content-types' => [
		'entrypoints' => [
			'core' => wphave_dir() . 'inc/features/content-types/bootstrap.php',
			'management' => wphave_dir() . 'inc/features/content-types/management.php',
		],
	],
	'content-models' => [
		'entrypoints' => [
			'core' => wphave_dir() . 'inc/features/content-models/bootstrap.php',
			'management' => wphave_dir() . 'inc/features/content-models/management.php',
		],
		'gate' => 'wphave_content_models_feature_enabled',
	],
	'documents' => [
		'entrypoints' => [
			'core' => wphave_dir() . 'inc/admin/features/documents/bootstrap.php',
			'management' => wphave_dir() . 'inc/admin/features/documents/management.php',
		],
		'gate' => 'wphave_documents_feature_enabled',
	],
	'social' => [
		'entrypoints' => ['core' => wphave_dir() . 'inc/features/social/bootstrap.php'],
	],
	'forms' => [
		'entrypoints' => [
			'frontend' => wphave_dir() . 'inc/features/forms/bootstrap.php',
			'management' => wphave_dir() . 'inc/features/forms/management.php',
		],
	],
	'seo' => [
		'entrypoints' => ['frontend' => wphave_dir() . 'inc/features/seo/bootstrap.php'],
	],
	'add-ons' => [
		'entrypoints' => [
			'frontend' => wphave_dir() . 'inc/features/add-ons/bootstrap.php',
			'management' => wphave_dir() . 'inc/features/add-ons/management.php',
		],
		'dependencies' => ['seo'],
	],
	'maintenance' => [
		'entrypoints' => ['frontend' => wphave_dir() . 'inc/features/maintenance/bootstrap.php'],
	],
	'account' => [
		'entrypoints' => ['frontend' => wphave_dir() . 'inc/features/account/bootstrap.php'],
	],
	'smtp' => [
		'entrypoints' => ['frontend' => wphave_dir() . 'inc/admin/features/smtp/bootstrap.php'],
	],
	'schema' => [
		'entrypoints' => [
			'frontend' => wphave_dir() . 'inc/features/schema/bootstrap.php',
			'management' => wphave_dir() . 'inc/features/schema/management.php',
		],
	],
	'analytics' => [
		'entrypoints' => [
			'frontend' => wphave_dir() . 'inc/features/analytics/bootstrap.php',
			'worker' => wphave_dir() . 'inc/features/analytics/worker.php',
		],
		'dependencies' => ['forms'],
	],
	'audience' => [
		'entrypoints' => [
			'frontend' => wphave_dir() . 'inc/features/audience/bootstrap.php',
			'worker' => wphave_dir() . 'inc/features/audience/worker.php',
		],
		'dependencies' => ['forms'],
	],
	'campaigns' => [
		'entrypoints' => [
			'core' => wphave_dir() . 'inc/admin/features/campaigns/bootstrap.php',
			'management' => wphave_dir() . 'inc/admin/features/campaigns/management.php',
			'worker' => wphave_dir() . 'inc/admin/features/campaigns/worker.php',
		],
		'dependencies' => ['audience'],
		'gate' => 'wphave_campaigns_feature_enabled',
	],
	'fonts' => [
		'entrypoints' => [
			'frontend' => wphave_dir() . 'inc/features/fonts/bootstrap.php',
			'management' => wphave_dir() . 'inc/features/fonts/management.php',
			'worker' => wphave_dir() . 'inc/features/fonts/worker.php',
		],
	],
	'privacy' => [
		'entrypoints' => [
			'core' => wphave_dir() . 'inc/features/privacy/core.php',
			'frontend' => wphave_dir() . 'inc/features/privacy/bootstrap.php',
			'management' => wphave_dir() . 'inc/features/privacy/management.php',
			'worker' => wphave_dir() . 'inc/features/privacy/worker.php',
		],
	],
	'custom-code' => [
		'entrypoints' => ['frontend' => wphave_dir() . 'inc/features/custom-code/bootstrap.php'],
	],
	'woocommerce' => [
		'entrypoints' => [
			'core' => wphave_dir() . 'inc/features/woocommerce/core.php',
			'frontend' => wphave_dir() . 'inc/features/woocommerce/bootstrap.php',
			'management' => wphave_dir() . 'inc/features/woocommerce/management.php',
			'worker' => wphave_dir() . 'inc/features/woocommerce/reporting/bootstrap.php',
		],
		'dependencies' => ['content-types', 'analytics', 'privacy'],
	],
	'background-job-feature-lifecycle' => [
		'entrypoints' => [
			'core' => wphave_dir() . 'inc/background-jobs/feature-lifecycle/bootstrap.php',
		],
		'dependencies' => ['woocommerce'],
	],
	'live-search' => [
		'entrypoints' => ['frontend' => wphave_dir() . 'inc/features/live-search/bootstrap.php'],
	],
	'brand-assets' => [
		'entrypoints' => [
			'frontend' => wphave_dir() . 'inc/features/brand-assets/frontend.php',
			'management' => wphave_dir() . 'inc/features/brand-assets/management.php',
		],
		'dependencies' => ['security'],
	],
	'link-processing' => [
		'entrypoints' => [
			'frontend' => wphave_dir() . 'inc/features/link-processing/bootstrap.php',
		],
	],
	'taxonomies' => [
		'entrypoints' => ['management' => wphave_dir() . 'inc/features/taxonomies/bootstrap.php'],
	],
	'static-publishing' => [
		'entrypoints' => [
			'management' => wphave_dir() . 'inc/admin/features/static-publishing/bootstrap.php',
		],
		'gate' => 'wphave_static_publishing_feature_enabled',
	],
	'backup' => [
		'entrypoints' => [
			'management' => wphave_dir() . 'inc/admin/features/backup/bootstrap.php',
			'worker' => wphave_dir() . 'inc/admin/features/backup/worker.php',
		],
		'gate' => 'wphave_backup_feature_enabled',
	],
	'client-support' => [
		'entrypoints' => [
			'management' => wphave_dir() . 'inc/admin/features/client-support/bootstrap.php',
		],
	],
	'comments' => [
		'entrypoints' => [
			'management' => wphave_dir() . 'inc/admin/features/comments/bootstrap.php',
		],
	],
	'content-audit' => [
		'entrypoints' => [
			'management' => wphave_dir() . 'inc/admin/features/content-audit/management.php',
			'worker' => wphave_dir() . 'inc/admin/features/content-audit/worker.php',
		],
		'dependencies' => ['schema'],
	],
	'notes' => [
		'entrypoints' => ['management' => wphave_dir() . 'inc/admin/features/notes/bootstrap.php'],
		'gate' => 'wphave_notes_feature_enabled',
	],
	'review-notes' => [
		'entrypoints' => ['management' => wphave_dir() . 'inc/features/review-notes/bootstrap.php'],
		'gate' => 'wphave_review_notes_feature_enabled',
	],
	'notifications' => [
		'entrypoints' => [
			'management' => wphave_dir() . 'inc/admin/features/notifications/bootstrap.php',
		],
		'dependencies' => ['comments', 'audience'],
	],
	'overview' => [
		'entrypoints' => [
			'management' => wphave_dir() . 'inc/admin/features/overview/bootstrap.php',
		],
	],
	'performance-monitor-storage' => [
		'entrypoints' => [
			'management' =>
				wphave_dir() . 'inc/optimize/monitoring/performance-monitor/management.php',
			'worker' => wphave_dir() . 'inc/optimize/monitoring/performance-monitor/worker.php',
		],
	],
	'static-cache-workers' => [
		'entrypoints' => [
			'worker' => wphave_dir() . 'inc/optimize/static-page-cache/worker.php',
		],
	],
	'playground' => [
		'entrypoints' => [
			'management' => wphave_dir() . 'inc/admin/features/playground/bootstrap.php',
		],
	],
	'system-info' => [
		'entrypoints' => [
			'management' => wphave_dir() . 'inc/admin/features/system-info/bootstrap.php',
		],
	],
	'site-compositions' => [
		'entrypoints' => [
			'management' => wphave_dir() . 'inc/admin/features/site-compositions/bootstrap.php',
		],
	],
	'planner' => [
		'entrypoints' => [
			'management' => wphave_dir() . 'inc/admin/features/planner/bootstrap.php',
		],
		'dependencies' => ['site-compositions'],
		'gate' => 'wphave_planner_feature_enabled',
	],
	'ai' => [
		'entrypoints' => [
			'frontend' => wphave_dir() . 'inc/admin/features/ai/frontend.php',
			'management' => wphave_dir() . 'inc/admin/features/ai/bootstrap.php',
		],
		'dependencies' => ['planner', 'site-compositions'],
		'gate' => 'wphave_ai_feature_enabled',
	],
];
