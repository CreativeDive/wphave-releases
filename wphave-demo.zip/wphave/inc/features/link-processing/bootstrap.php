<?php

/**
 * Load specific JS/CSS assets.
 */

if ( ! function_exists( 'wphave_link_processing_assets' ) ) :

	function wphave_link_processing_assets() {

        // Check if external links should be opened in new tab
		$external_links = wphave_data_get( 'site_settings', 'general.external_links_in_new_tab' );

        // Check if url parameter should be remain
		$append_params = wphave_data_get( 'site_settings', 'advanced.parameter.state' ) ?: 'disabled';

		if( $append_params === 'disabled' && ! $external_links ) {
            // Bail early if both features are disabled.
			return;
		}

		$parameters = wphave_data_get( 'site_settings', 'advanced.parameter.list', array() ) ?: array();
		$allowed_params = array();

		if( is_array( $parameters ) ) {
			foreach( $parameters as $parameter ) {
				$param = isset( $parameter['params'] ) ? sanitize_key( $parameter['params'] ) : '';

				if( ! empty( $param ) ) {
					$allowed_params[] = $param;
				}
			}
		}

		$home_url = wp_parse_url( home_url() );
		$internal_domain = $home_url['host'] ?? '';

        $path = 'inc/features/link-processing/script.js';

		wp_register_script(
			'wphave-link-processor', wphave_asset_url( $path ), array(), WPHAVE_Asset_Registry::version( $path ), true
		);

		wp_localize_script(
			'wphave-link-processor',
			'locVar',
			array(
				'internal_domain' => $internal_domain,
				'tracking_mode' => wphave_privacy_can_process( WPHAVE_Privacy_Manager::PURPOSE_ANALYTICS_ATTRIBUTION ) ? 'sessions' : 'aggregate',

                // Parameter Feature
				'parameter_append' => $append_params,
				'allowed_parameters' => array_values( array_unique( $allowed_params ) ),
				'limit_parameters' => (bool) wphave_data_get( 'site_settings', 'advanced.parameter.limit' ),
				'attribution_mode' => wphave_data_get( 'site_settings', 'advanced.parameter.attribution', 'last' ),

                // External Links Feature
				'external_links' => (bool) wphave_data_get( 'site_settings', 'general.external_links_in_new_tab' ),
				'audience_lead_proof_url' => rest_url( 'wphave/v1/audience/public-proof/lead' ),
			)
		);

		wp_enqueue_script( 'wphave-link-processor' );

	}

endif;

add_action( 'wp_enqueue_scripts', 'wphave_link_processing_assets' );
