﻿/**
 * Process frontend links and preserve approved attribution parameters.
 *
 * Responsibilities:
 * - URL parameter propagation (UTM etc.)
 * - External links target="_blank"
 * - Security (noopener, noreferrer)
 * - Dynamic DOM updates
 */

(function () {
	'use strict';

	if (typeof locVar === 'undefined') {
		return;
	}

	/* Configuration. */

	const config = {
		internalDomain: locVar.internal_domain || window.location.hostname,
		hasAttributionConsent: locVar.tracking_mode === 'sessions',
		audienceLeadProofUrl:
			locVar.audience_lead_proof_url || '/wp-json/wphave/v1/audience/public-proof/lead',

		// Parameter Feature
		parameterMode: locVar.parameter_append || 'disabled', // disabled | internal | external | all
		allowedParameters: Array.isArray(locVar.allowed_parameters)
			? locVar.allowed_parameters
			: [],
		limitParameters: !!locVar.limit_parameters,
		attributionMode: locVar.attribution_mode || 'last',

		// External Links Feature
		externalLinks: !!locVar.external_links // boolean
	};

	/* Storage keys for persisted parameters. */
	const STORAGE_KEY = 'wphave_params';
	const STORAGE_LAST = 'wphave_params_last';
	const STORAGE_FIRST = 'wphave_params_first';

	/* Skip the complete runtime when no related feature is enabled. */
	if (config.parameterMode === 'disabled' && !config.externalLinks) {
		return;
	}

	/* URL helpers. */

	const SKIPPED_PROTOCOLS = ['mailto:', 'tel:', 'javascript:', 'data:'];

	function shouldSkipHref(href) {
		if (!href || typeof href !== 'string') return true;

		const trimmed = href.trim();
		const normalized = trimmed.toLowerCase();

		if (!trimmed || trimmed.startsWith('#')) return true;

		return SKIPPED_PROTOCOLS.some((p) => normalized.startsWith(p));
	}

	function getUrlObject(href) {
		try {
			return new URL(href, window.location.origin);
		} catch {
			return null;
		}
	}

	function isInternal(url) {
		const hostname = url.hostname.toLowerCase();
		const currentHostname = window.location.hostname.toLowerCase();
		const configuredHostname = String(config.internalDomain || '').toLowerCase();
		const sameTransport =
			url.protocol === window.location.protocol && url.port === window.location.port;

		return (
			sameTransport &&
			(hostname === currentHostname ||
				(configuredHostname && hostname === configuredHostname))
		);
	}

	function isExternal(url) {
		return !isInternal(url);
	}

	function isExternalParameterAllowed(key) {
		// CREDENTIAL INVARIANT: A mistaken settings entry must not turn common
		// authentication fields into outbound query parameters. The allowlist is
		// necessary, but known credential names remain forbidden independently.
		const sensitiveName =
			/(?:^|[_-])(?:token|nonce|password|passwd|pwd|secret|session|auth|authorization|api[_-]?key|key|code)(?:$|[_-])/i;
		return config.allowedParameters.includes(key) && !sensitiveName.test(key);
	}

	/* Parameter handling. */

	function getCurrentParameters() {
		const currentUrl = new URL(window.location.href);

		const urlParams = [];

		// PARAMETER INVARIANT: An enabled allowlist with zero entries denies every
		// parameter. An empty list must never silently become "forward all".
		const hasWhitelist = config.limitParameters;

		/**
		 * Collect params from URL
		 */
		currentUrl.searchParams.forEach((value, key) => {
			if (hasWhitelist && !config.allowedParameters.includes(key)) {
				return;
			}

			urlParams.push([key, value]);
		});

		/**
		 * Apply tracking logic (first + last touch)
		 */
		return config.hasAttributionConsent ? processTracking(urlParams) : urlParams;
	}

	function shouldApplyParameters(url) {
		const internal = isInternal(url);

		switch (config.parameterMode) {
			case 'internal':
				return internal;
			case 'external':
				return !internal;
			case 'all':
				return true;
			default:
				return false;
		}
	}

	function applyParameters(url, currentParams) {
		let changed = false;

		currentParams.forEach(([key, value]) => {
			if (!url.searchParams.has(key)) {
				url.searchParams.set(key, value);
				changed = true;
			}
		});

		return changed;
	}

	/* Session parameter persistence. */

	/**
	 * Save attribution parameters in session storage.
	 *
	 * @param {Array} params Parameter entries to persist.
	 * @return {void}
	 */
	function saveParamsToSession(params) {
		if (!config.hasAttributionConsent || !params || !params.length) return;

		try {
			const existing = getParamsFromSession();

			const merged = mergeParams(existing, params);

			sessionStorage.setItem(STORAGE_KEY, JSON.stringify(merged));
		} catch {
			// silently fail (private mode etc.)
		}
	}

	/**
	 * Retrieve attribution parameters from session storage.
	 *
	 * @return {Array} Persisted parameter entries.
	 */
	function getParamsFromSession() {
		if (!config.hasAttributionConsent) return [];

		try {
			const stored = sessionStorage.getItem(STORAGE_KEY);

			if (!stored) return [];

			return JSON.parse(stored);
		} catch (e) {
			return [];
		}
	}

	/**
	 * Merge two parameter arrays.
	 *
	 * Priority:
	 * - current URL params override session params
	 *
	 * @param {Array} base Existing parameter entries.
	 * @param {Array} incoming New parameter entries.
	 * @return {Array} Merged parameter entries.
	 */
	function mergeParams(base = [], incoming = []) {
		const map = new Map();

		base.forEach(([key, value]) => {
			map.set(key, value);
		});

		incoming.forEach(([key, value]) => {
			map.set(key, value);
		});

		return Array.from(map.entries());
	}

	/* First- and last-touch storage. */

	/**
	 * Get params from storage
	 */
	function getStoredParams(key) {
		if (!config.hasAttributionConsent) return [];

		try {
			const stored = sessionStorage.getItem(key);
			const parsed = stored ? JSON.parse(stored) : [];
			// STORED-STATE INVARIANT: A formerly permitted value must not outlive a
			// changed allowlist and reappear in a later link or lead projection.
			return Array.isArray(parsed)
				? parsed.filter(
						(item) =>
							Array.isArray(item) &&
							item.length === 2 &&
							typeof item[0] === 'string' &&
							typeof item[1] === 'string' &&
							(!config.limitParameters || config.allowedParameters.includes(item[0]))
				  )
				: [];
		} catch (e) {
			return [];
		}
	}

	/**
	 * Save params to storage
	 */
	function setStoredParams(key, params) {
		if (!config.hasAttributionConsent) return;

		try {
			sessionStorage.setItem(key, JSON.stringify(params));
		} catch (e) {}
	}

	/**
	 * Convert array → map
	 */
	function paramsToMap(params = []) {
		const map = new Map();
		params.forEach(([k, v]) => map.set(k, v));
		return map;
	}

	/**
	 * Convert map → array
	 */
	function mapToParams(map) {
		return Array.from(map.entries());
	}

	/**
	 * Handle attribution models
	 *
	 * Modes:
	 * - first   → keep first value
	 * - last    → always overwrite
	 * - hybrid  → first + last combined
	 */
	function processTracking(urlParams) {
		const first = paramsToMap(getStoredParams(STORAGE_FIRST));
		const last = paramsToMap(getStoredParams(STORAGE_LAST));

		const mode = config.attributionMode;

		/* Preserve the first observed value for each parameter. */
		if (mode === 'first') {
			urlParams.forEach(([key, value]) => {
				if (!first.has(key)) {
					first.set(key, value);
				}
			});

			setStoredParams(STORAGE_FIRST, mapToParams(first));

			return mapToParams(first);
		}

		/* Always retain the most recently observed values. */
		if (mode === 'last') {
			urlParams.forEach(([key, value]) => {
				last.set(key, value);
			});

			setStoredParams(STORAGE_LAST, mapToParams(last));

			return mapToParams(last);
		}

		/*
		 * Hybrid attribution.
		 *
		 * - first touch preserved
		 * - last touch updated
		 * - return merged result
		 */
		if (mode === 'hybrid') {
			urlParams.forEach(([key, value]) => {
				// first touch only if not set
				if (!first.has(key)) {
					first.set(key, value);
				}

				// last touch always updated
				last.set(key, value);
			});

			setStoredParams(STORAGE_FIRST, mapToParams(first));
			setStoredParams(STORAGE_LAST, mapToParams(last));

			/**
			 * Merge:
			 * last overrides first if conflict
			 */
			const merged = new Map(first);

			last.forEach((value, key) => {
				merged.set(key, value);
			});

			return mapToParams(merged);
		}

		return [];
	}

	/* External-link handling. */

	function applyExternalBehavior(link, url) {
		if (!config.externalLinks) return false;

		if (!isExternal(url)) return false;

		let changed = false;

		if (link.getAttribute('target') !== '_blank') {
			link.setAttribute('target', '_blank');
			changed = true;
		}

		// Security: rel
		const rel = link.getAttribute('rel') || '';
		const relParts = rel.split(' ').filter(Boolean);

		if (!relParts.includes('noopener')) relParts.push('noopener');
		if (!relParts.includes('noreferrer')) relParts.push('noreferrer');

		const nextRel = relParts.join(' ');

		if (nextRel !== rel) {
			link.setAttribute('rel', nextRel);
			changed = true;
		}

		return changed;
	}

	/* Main link processor. */

	function processLink(link, currentParams) {
		if (!(link instanceof HTMLAnchorElement)) return;

		if (link.dataset.wphaveProcessed === 'true') return;

		if (link.hasAttribute('onclick')) return;

		if (link.hasAttribute('data-no-process')) return;

		const rawHref = link.getAttribute('href');

		if (shouldSkipHref(rawHref)) return;

		const url = getUrlObject(rawHref);

		// NAVIGATION INVARIANT: A host match is not sufficient for internal
		// authority, and non-HTTP schemes must never enter link rewriting.
		if (!url || !['http:', 'https:'].includes(url.protocol) || url.username || url.password) {
			return;
		}

		let changed = false;

		/**
		 * Apply parameter feature
		 */
		if (config.parameterMode !== 'disabled' && shouldApplyParameters(url)) {
			// CROSS-ORIGIN INVARIANT: Query strings on the current page can contain
			// password-reset tokens, nonces and private form data. Only site-approved
			// parameter names may cross to another origin, even when the internal-link
			// setting permits unrestricted propagation within this site.
			const forwardedParams = isExternal(url)
				? currentParams.filter(([key]) => isExternalParameterAllowed(key))
				: currentParams;
			changed = applyParameters(url, forwardedParams) || changed;
		}

		/**
		 * Apply external link feature
		 */
		changed = applyExternalBehavior(link, url) || changed;

		/**
		 * Update href only if needed
		 */
		if (changed) {
			const isRelative = rawHref.startsWith('/') || rawHref.startsWith('?');

			if (isRelative && url.origin === window.location.origin) {
				link.setAttribute('href', url.pathname + url.search + url.hash);
			} else {
				link.setAttribute('href', url.toString());
			}
		}

		link.dataset.wphaveProcessed = 'true';
	}

	function processAll(root = document) {
		const currentParams = getCurrentParameters();

		const links = root.querySelectorAll('a[href]');
		links.forEach((link) => processLink(link, currentParams));
	}

	/* Initialization and observation of dynamically inserted links. */

	document.addEventListener('DOMContentLoaded', () => {
		processAll();
		warmLeadProofFor(document);

		const observer = new MutationObserver((mutations) => {
			const currentParams = getCurrentParameters();

			mutations.forEach((mutation) => {
				mutation.addedNodes.forEach((node) => {
					if (!(node instanceof HTMLElement)) return;
					warmLeadProofFor(node);

					if (node.matches && node.matches('a[href]')) {
						processLink(node, currentParams);
					}

					const nested = node.querySelectorAll ? node.querySelectorAll('a[href]') : [];

					nested.forEach((link) => processLink(link, currentParams));
				});
			});
		});

		observer.observe(document.body, {
			childList: true,
			subtree: true
		});
	});

	/* Lead tracking. */

	const LEAD_ENDPOINT = '/wp-json/wphave/v1/audience/leads';
	let leadProof = '';
	let leadProofExpiresAt = 0;
	let leadProofPromise = null;

	function getLeadProof() {
		if (typeof fetch !== 'function') {
			return Promise.resolve('');
		}

		if (leadProof && Date.now() < leadProofExpiresAt) {
			return Promise.resolve(leadProof);
		}

		if (!leadProofPromise) {
			leadProofPromise = fetch(config.audienceLeadProofUrl, {
				credentials: 'same-origin',
				headers: { Accept: 'application/json' },
				cache: 'no-store'
			})
				.then((response) => {
					if (!response.ok) {
						throw new Error('Lead proof request failed.');
					}

					return response.json();
				})
				.then((data) => {
					leadProof = data.proof || '';
					leadProofExpiresAt =
						Date.now() + Math.max(0, (Number(data.expiresIn) || 0) * 1000 - 60000);

					return leadProof;
				})
				.catch(() => '')
				.finally(() => {
					leadProofPromise = null;
				});
		}

		return leadProofPromise;
	}

	function warmLeadProofFor(root) {
		if (!config.hasAttributionConsent || !root) return;

		const hasTrackedElement =
			root.matches?.('[data-wphave-audience="1"]') ||
			root.querySelector?.('[data-wphave-audience="1"]');

		if (hasTrackedElement) {
			getLeadProof();
		}
	}

	/*
	 * PERFORMANCE INVARIANT: A public proof is warmed only when the document
	 * contains a trackable element. This keeps unrelated page views free of the
	 * REST request while ensuring navigation clicks do not wait for verification.
	 */

	/**
	 * Prevent duplicate spam (client-side)
	 */
	let lastLeadHash = null;
	let lastLeadTime = 0;

	/**
	 * Simple throttle (per session)
	 */
	let leadCounter = 0;
	const MAX_LEADS_PER_MINUTE = 30;

	setInterval(() => {
		leadCounter = 0;
	}, 60000);

	/**
	 * Generate hash for dedupe
	 */
	function hashLead(payload) {
		try {
			return btoa(JSON.stringify(payload)).substr(0, 50);
		} catch (e) {
			return null;
		}
	}

	/**
	 * Safe sendLead function
	 */
	async function sendLead(type, data = {}) {
		/* Validate the event before constructing its payload. */

		if (!type || typeof type !== 'string') return;

		const allowedTypes = ['form', 'click', 'download', 'outbound', 'signup', 'system'];

		if (!allowedTypes.includes(type)) return;

		/* Throttle excessive submissions in the current browser context. */

		if (leadCounter >= MAX_LEADS_PER_MINUTE) {
			return;
		}

		leadCounter++;

		/* Build the normalized tracking payload. */

		const proof = await getLeadProof();

		if (!proof) return;

		const payload = {
			_wphave_audience_proof: proof,
			type,
			event: typeof data.event === 'string' ? data.event : '',
			object_type: data.object_type || type,
			object_id: data.object_id || 0,
			object_key: data.object_key || '',
			object_label: data.object_label || data.event || '',
			object_url: data.object_url || window.location.href,
			object_subtype: data.object_subtype || '',
			data: {
				...data,

				/* The server expects the honeypot field to stay empty. */
				honeypot: ''
			},
			tracking: getCurrentParameters(),
			tracking_first: getStoredParams(STORAGE_FIRST),
			tracking_last: getStoredParams(STORAGE_LAST),
			url: window.location.href,
			referrer: document.referrer
		};

		/* Prevent duplicate client-side submissions. */

		const hash = hashLead(payload);

		if (hash && hash === lastLeadHash && Date.now() - lastLeadTime < 2000) {
			return;
		}

		lastLeadHash = hash;
		lastLeadTime = Date.now();

		/* Enforce the payload size limit before transport. */

		const json = JSON.stringify(payload);

		if (json.length > 8000) {
			return;
		}

		/* Prefer Beacon during navigation and fall back to fetch. */

		try {
			/* Beacon can complete while the document is unloading. */
			if (navigator.sendBeacon) {
				const blob = new Blob([json], {
					type: 'application/json'
				});

				navigator.sendBeacon(LEAD_ENDPOINT, blob);
				return;
			}

			/* Keep the fetch request alive during navigation where supported. */
			fetch(LEAD_ENDPOINT, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json'
				},
				body: json,
				keepalive: true
			}).catch(() => {
				// silent fail
			});
		} catch (e) {
			// never break frontend
		}
	}

	/**
	 * Global Click Tracking
	 */

	document.addEventListener('click', (e) => {
		if (!config.hasAttributionConsent) return;

		const el = e.target.closest('[data-wphave-audience="1"]');

		if (!el) return;
		const href = el.getAttribute('href') || window.location.href;
		let url;

		try {
			url = new URL(href, window.location.href);
		} catch (error) {
			url = new URL(window.location.href);
		}

		const pathname = url.pathname || '';
		const extensionMatch = pathname.match(/\.([a-z0-9]{2,8})$/i);
		const extension = extensionMatch ? extensionMatch[1].toLowerCase() : '';
		const explicitType = (el.dataset.wphaveTrackType || '').toLowerCase();
		const type = ['click', 'download', 'outbound'].includes(explicitType)
			? explicitType
			: 'click';
		const label = el.dataset.wphaveTrackLabel || (el.textContent || '').trim() || url.hostname;

		sendLead(type, {
			event: label,
			object_type: type,
			object_key: el.dataset.wphaveGoalId || el.dataset.wphaveTrackLabel || url.href,
			object_label: label,
			object_url: el.dataset.wphaveTrackUrl || url.href,
			object_subtype:
				type === 'download'
					? extension || 'file'
					: type === 'outbound'
					? url.hostname
					: el.dataset.wphaveGoalId || 'link',
			goal_id: el.dataset.wphaveGoalId || '',
			value: el.dataset.wphaveValue || ''
		});
	});

	window.addEventListener('wphave:consent-changed', (event) => {
		const consent = event?.detail?.consent || {};
		config.hasAttributionConsent = !!(consent.analytics || consent.__all);

		if (config.hasAttributionConsent) {
			warmLeadProofFor(document);
			return;
		}

		try {
			sessionStorage.removeItem(STORAGE_KEY);
			sessionStorage.removeItem(STORAGE_FIRST);
			sessionStorage.removeItem(STORAGE_LAST);
		} catch (e) {
			// Ignore storage failures in restricted browser modes.
		}
	});
})();
