<?php

/**
 * Function to prevent loading specific wphave features in special contexts.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Function to prevent loading specific wphave features in special contexts.
 */

if ( ! function_exists( 'wphave_should_not_load_features' ) ) :

	function wphave_should_not_load_features() {

		// Maintenance Mode
		// The maintenance document replaces the regular site and add-on output.
		if( WPHAVE_Maintenance_Mode::is_active() ) {
			return true;
		}

		// Coming Soon Mode
		// In this case we use a separate template to view the coming soon page
		if( WPHAVE_Coming_Soon::is_active() ) {
			return true;
		}

		// Recipe - Print Card
		// In this case we use a separate template to provide a print view
		if( isset( $_GET['print-recipe-card'] ) ) {
			return true;
		}

		return false;

	}

endif;
