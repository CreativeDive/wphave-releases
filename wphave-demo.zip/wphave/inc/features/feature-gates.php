<?php

/**
 * Helpers for feature toggles controlled by the wphave experience settings.
 */

if (!defined('ABSPATH')) {
	exit();
}

/**
 * Helpers for feature toggles controlled by the wphave experience settings.
 */

function wphave_experience_feature_enabled($feature, $default = true) {
	if (!function_exists('wphave_data_get')) {
		return (bool) $default;
	}

	$feature = preg_replace('/[^A-Za-z0-9_\-]/', '', (string) $feature);

	return (bool) wphave_data_get('site_settings', 'advanced.ui.features.' . $feature, $default);
}

/**
 * Resolve a canonical product feature gate.
 */

function wphave_feature_enabled(string $feature): bool {
	$features = [
		'activity' => ['setting' => 'activityLog', 'default' => true],
		'backups' => ['setting' => 'backups', 'default' => true],
		'notes' => ['setting' => 'notes', 'default' => true, 'release' => 'notes'],
		'developer-tools' => ['developer_tools' => true, 'release' => 'developerTools'],
		'external-browser-connections' => [
			'developer_tool' => 'externalBrowserConnections',
			'release' => 'externalBrowserConnections',
		],
		'performance-monitor' => [
			'developer_tool' => 'performanceMonitor',
			'release' => 'performanceMonitor',
		],
		'presence' => ['setting' => 'presence', 'default' => true, 'release' => 'presence'],
		'request-inspector' => [
			'developer_tool' => 'requestInspector',
			'release' => 'requestInspector',
		],
		'request-profiler' => [
			'developer_tool' => 'requestProfiler',
			'release' => 'requestProfiler',
		],
		'commerce' => ['release' => 'commerce'],
		'commerce-reporting' => ['release' => 'commerceReporting'],
		'campaigns' => ['release' => 'campaigns'],
		'documents' => ['release' => 'documents'],
	];

	$definition = $features[$feature] ?? null;
	if (!is_array($definition)) {
		return true;
	}

	if (isset($definition['release']) && !wphave_release_feature_ready($definition['release'])) {
		return false;
	}

	// RELEASE INVARIANT: Reporting cannot outlive its owning Commerce workspace.
	if ('commerce-reporting' === $feature && !wphave_feature_enabled('commerce')) {
		return false;
	}

	if (!empty($definition['developer_tools'])) {
		return wphave_developer_tools_enabled();
	}

	if (isset($definition['developer_tool'])) {
		return wphave_developer_tool_enabled($definition['developer_tool']);
	}

	if (!isset($definition['setting'])) {
		return true;
	}

	return wphave_experience_feature_enabled(
		$definition['setting'],
		$definition['default'] ?? true,
	);
}

/**
 * Check whether a prepared feature should be exposed in the current release.
 *
 * This is a temporary release gate, not a permission or license check. Keep it
 * aligned with src/_FEATURE_READY.js for features that also expose PHP runtime
 * data or server-side AI action contracts.
 */

function wphave_release_feature_ready($feature) {
	static $features = null;

	if (null === $features) {
		$path = __DIR__ . '/release-flags.json';
		$decoded = is_readable($path) ? json_decode((string) file_get_contents($path), true) : null;
		$features = is_array($decoded) ? $decoded : [];
	}

	$feature = preg_replace('/[^A-Za-z0-9_\-]/', '', (string) $feature);

	// RELEASE INVARIANT: A misspelled or unclassified flag must never expose an
	// unfinished server surface. Every release flag is declared in the shared
	// manifest consumed by both PHP and JavaScript.
	return array_key_exists($feature, $features) && true === $features[$feature];
}

function wphave_ai_feature_enabled(): bool {
	return wphave_release_feature_ready('ai');
}

function wphave_planner_feature_enabled(): bool {
	return wphave_release_feature_ready('websitePlanner');
}

/** Check whether the Campaigns platform module is available. */
function wphave_campaigns_feature_enabled(): bool {
	return wphave_feature_enabled('campaigns');
}

/**
 * Check whether the Documents platform module is available.
 */

function wphave_documents_feature_enabled(): bool {
	return wphave_feature_enabled('documents');
}

/** Shared release boundary for the experimental static publishing workflow. */
function wphave_static_publishing_feature_enabled(): bool {
	return wphave_release_feature_ready('staticPublishing');
}

/** Check the shared PHP/JavaScript release gate for Content Models. */
function wphave_content_models_feature_enabled(): bool {
	return wphave_release_feature_ready('contentModels');
}

/**
 * Check the workspace-wide Developer Tools gate.
 *
 * Disabled is the fail-closed default: release readiness alone must never
 * activate diagnostic collectors, routes, storage or browser assets.
 */

function wphave_developer_tools_enabled(): bool {
	if (!function_exists('wphave_data_get')) {
		return false;
	}

	return (bool) wphave_data_get(
		'site_settings',
		'advanced.ui.features.developerTools.enabled',
		false,
	);
}

/** Resolve one tool below the workspace-wide Developer Tools gate. */

function wphave_developer_tool_enabled(string $tool): bool {
	$tools = [
		'requestInspector',
		'performanceMonitor',
		'requestProfiler',
		'externalBrowserConnections',
	];
	if (!in_array($tool, $tools, true) || !wphave_developer_tools_enabled()) {
		return false;
	}

	$stored_value = wphave_data_get(
		'site_settings',
		'advanced.ui.features.developerTools.tools.' . $tool,
		null,
	);

	if (null !== $stored_value) {
		return (bool) $stored_value;
	}

	if ('externalBrowserConnections' === $tool) {
		return (bool) wphave_data_get(
			'site_settings',
			'advanced.ui.features.externalBrowserConnections',
			false,
		);
	}

	return false;
}

/**
 * Check whether Query Monitor is active for this site or network.
 *
 * Runtime constants cover custom plugin locations while the canonical plugin
 * file check also works before Query Monitor has exposed its public classes.
 *
 * @return bool Whether Query Monitor is active.
 */

function wphave_query_monitor_active() {
	if (defined('QM_VERSION') || defined('QUERY_MONITOR_VERSION') || class_exists('QueryMonitor')) {
		return true;
	}

	if (!function_exists('is_plugin_active')) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}

	return is_plugin_active('query-monitor/query-monitor.php') ||
		(is_multisite() && is_plugin_active_for_network('query-monitor/query-monitor.php'));
}

/**
 * Check whether the request inspector runtime may expose its entry points.
 *
 * User activation remains a separate, capability-protected decision so the
 * RELEASE INVARIANT: The release gate never turns request instrumentation on by itself.
 *
 * @return bool Whether the request inspector is available in this release.
 */

function wphave_request_inspector_feature_enabled() {
	return wphave_feature_enabled('request-inspector');
}

/**
 * Check whether Presence routes, storage and scheduled cleanup may be active.
 */

function wphave_presence_feature_enabled() {
	return wphave_feature_enabled('presence');
}

/**
 * Check whether the internal notes feature may be loaded.
 */

function wphave_notes_feature_enabled() {
	return wphave_feature_enabled('notes');
}

/**
 * Whether WordPress-native block review notes are available in WPHAVE.
 *
 * This release gate is intentionally separate from the Workspace Notes
 * feature. Review notes use the Core comment entity and are scoped to an
 * editable post; Workspace Notes remain independent private posts.
 */
function wphave_review_notes_feature_enabled(): bool {
	return wphave_release_feature_ready('reviewNotes') &&
		version_compare(get_bloginfo('version'), '6.9', '>=');
}

/**
 * Performance monitor feature enabled.
 */

function wphave_performance_monitor_feature_enabled() {
	return wphave_feature_enabled('performance-monitor');
}

/** Request profiler screen and explicit capture runtime enabled. */

function wphave_request_profiler_feature_enabled(): bool {
	return wphave_feature_enabled('request-profiler');
}

/**
 * Check whether backup routes, jobs and scheduled events may be active.
 */

function wphave_backup_feature_enabled() {
	return wphave_feature_enabled('backups');
}

/**
 * Check whether the Activity Log runtime, routes and interface may be active.
 *
 * Disabling this extension intentionally preserves existing activity rows.
 */

function wphave_activity_feature_enabled() {
	return wphave_feature_enabled('activity');
}
