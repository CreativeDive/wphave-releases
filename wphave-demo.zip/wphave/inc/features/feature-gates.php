<?php

/**
 * Helpers for feature toggles controlled by the wphave experience settings.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Helpers for feature toggles controlled by the wphave experience settings.
 */

if ( ! function_exists( 'wphave_experience_feature_enabled' ) ) :

	function wphave_experience_feature_enabled( $feature, $default = true ) {

		if( ! function_exists( 'wphave_data_get' ) ) {
			return (bool) $default;
		}

		$feature = preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $feature );

		return (bool) wphave_data_get( 'site_settings', 'advanced.ui.features.' . $feature, $default );

	}

endif;

if ( ! function_exists( 'wphave_feature_enabled' ) ) :

	/**
	 * Resolve a canonical product feature gate.
	 */

	function wphave_feature_enabled( string $feature ): bool {
		$features = array(
			'activity'            => array( 'setting' => 'activityLog', 'default' => true ),
			'backups'             => array( 'setting' => 'backups', 'default' => true ),
			'notes'               => array( 'setting' => 'notes', 'default' => true, 'release' => 'notes' ),
			'developer-tools'     => array( 'developer_tools' => true, 'release' => 'developerTools' ),
			'external-browser-connections' => array( 'developer_tool' => 'externalBrowserConnections', 'release' => 'externalBrowserConnections' ),
			'performance-monitor' => array( 'developer_tool' => 'performanceMonitor', 'release' => 'performanceMonitor' ),
			'presence'            => array( 'setting' => 'presence', 'default' => true, 'release' => 'presence' ),
			'request-inspector'   => array( 'developer_tool' => 'requestInspector', 'release' => 'requestInspector' ),
			'request-profiler'    => array( 'developer_tool' => 'requestProfiler', 'release' => 'requestProfiler' ),
			'commerce-reporting'  => array( 'release' => 'commerceReporting' ),
			'campaigns'           => array( 'release' => 'campaigns' ),
			'documents'           => array( 'release' => 'documents' ),
		);

		$definition = $features[ $feature ] ?? null;
		if ( ! is_array( $definition ) ) {
			return true;
		}

		if ( isset( $definition['release'] ) && ! wphave_release_feature_ready( $definition['release'] ) ) {
			return false;
		}

		if ( ! empty( $definition['developer_tools'] ) ) {
			return wphave_developer_tools_enabled();
		}

		if ( isset( $definition['developer_tool'] ) ) {
			return wphave_developer_tool_enabled( $definition['developer_tool'] );
		}

		if ( ! isset( $definition['setting'] ) ) {
			return true;
		}

		return wphave_experience_feature_enabled( $definition['setting'], $definition['default'] ?? true );
	}

endif;


if ( ! function_exists( 'wphave_release_feature_ready' ) ) :

	/**
	 * Check whether a prepared feature should be exposed in the current release.
	 *
	 * This is a temporary release gate, not a permission or license check. Keep it
	 * aligned with src/_FEATURE_READY.js for features that also expose PHP runtime
	 * data or server-side AI action contracts.
	 */

	function wphave_release_feature_ready( $feature ) {
		static $features = null;

		if ( null === $features ) {
			$path = __DIR__ . '/release-flags.json';
			$decoded = is_readable( $path ) ? json_decode( (string) file_get_contents( $path ), true ) : null;
			$features = is_array( $decoded ) ? $decoded : array();
		}

		$feature = preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $feature );

		// RELEASE INVARIANT: A misspelled or unclassified flag must never expose an
		// unfinished server surface. Every release flag is declared in the shared
		// manifest consumed by both PHP and JavaScript.
		return array_key_exists( $feature, $features ) && true === $features[$feature];

	}

endif;

if ( ! function_exists( 'wphave_ai_feature_enabled' ) ) :

	function wphave_ai_feature_enabled(): bool {
		return wphave_release_feature_ready( 'ai' );
	}

endif;

if ( ! function_exists( 'wphave_planner_feature_enabled' ) ) :

	function wphave_planner_feature_enabled(): bool {
		return wphave_release_feature_ready( 'websitePlanner' );
	}

endif;

if ( ! function_exists( 'wphave_campaigns_feature_enabled' ) ) :

	/** Check whether the Campaigns platform module is available. */
	function wphave_campaigns_feature_enabled(): bool {
		return wphave_feature_enabled( 'campaigns' );
	}

endif;

if ( ! function_exists( 'wphave_documents_feature_enabled' ) ) :

	/**
	 * Check whether the Documents platform module is available.
	 */

	function wphave_documents_feature_enabled(): bool {
		return wphave_feature_enabled( 'documents' );
	}

endif;

if ( ! function_exists( 'wphave_static_publishing_feature_enabled' ) ) :

	/** Shared release boundary for the experimental static publishing workflow. */
	function wphave_static_publishing_feature_enabled(): bool {
		return wphave_release_feature_ready( 'staticPublishing' );
	}

endif;

if ( ! function_exists( 'wphave_content_models_feature_enabled' ) ) :

	/** Check the shared PHP/JavaScript release gate for Content Models. */
	function wphave_content_models_feature_enabled(): bool {
		return wphave_release_feature_ready( 'contentModels' );
	}

endif;


if ( ! function_exists( 'wphave_developer_tools_enabled' ) ) :

	/**
	 * Check the workspace-wide Developer Tools gate.
	 *
	 * Disabled is the fail-closed default: release readiness alone must never
	 * activate diagnostic collectors, routes, storage or browser assets.
	 */

	function wphave_developer_tools_enabled(): bool {

		if( ! function_exists( 'wphave_data_get' ) ) {
			return false;
		}

		return (bool) wphave_data_get(
			'site_settings',
			'advanced.ui.features.developerTools.enabled',
			false
		);

	}

endif;


if ( ! function_exists( 'wphave_developer_tool_enabled' ) ) :

	/** Resolve one tool below the workspace-wide Developer Tools gate. */

	function wphave_developer_tool_enabled( string $tool ): bool {

		$tools = [ 'requestInspector', 'performanceMonitor', 'requestProfiler', 'externalBrowserConnections' ];
		if( ! in_array( $tool, $tools, true ) || ! wphave_developer_tools_enabled() ) {
			return false;
		}

		$stored_value = wphave_data_get(
			'site_settings',
			'advanced.ui.features.developerTools.tools.' . $tool,
			null
		);

		if( null !== $stored_value ) {
			return (bool) $stored_value;
		}

		if( 'externalBrowserConnections' === $tool ) {
			return (bool) wphave_data_get(
				'site_settings',
				'advanced.ui.features.externalBrowserConnections',
				false
			);
		}

		return false;

	}

endif;


if ( ! function_exists( 'wphave_query_monitor_active' ) ) :

	/**
	 * Check whether Query Monitor is active for this site or network.
	 *
	 * Runtime constants cover custom plugin locations while the canonical plugin
	 * file check also works before Query Monitor has exposed its public classes.
	 *
	 * @return bool Whether Query Monitor is active.
	 */

	function wphave_query_monitor_active() {

		if( defined( 'QM_VERSION' ) || defined( 'QUERY_MONITOR_VERSION' ) || class_exists( 'QueryMonitor' ) ) {
			return true;
		}

		if( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		return is_plugin_active( 'query-monitor/query-monitor.php' )
			|| ( is_multisite() && is_plugin_active_for_network( 'query-monitor/query-monitor.php' ) );

	}

endif;


if ( ! function_exists( 'wphave_request_inspector_feature_enabled' ) ) :

	/**
	 * Check whether the request inspector runtime may expose its entry points.
	 *
	 * User activation remains a separate, capability-protected decision so the
	 * RELEASE INVARIANT: The release gate never turns request instrumentation on by itself.
	 *
	 * @return bool Whether the request inspector is available in this release.
	 */

	function wphave_request_inspector_feature_enabled() {

		return wphave_feature_enabled( 'request-inspector' );

	}

endif;


if ( ! function_exists( 'wphave_presence_feature_enabled' ) ) :

	/**
	 * Check whether Presence routes, storage and scheduled cleanup may be active.
	 */

	function wphave_presence_feature_enabled() {

		return wphave_feature_enabled( 'presence' );

	}

endif;


if ( ! function_exists( 'wphave_notes_feature_enabled' ) ) :

	/**
	 * Check whether the internal notes feature may be loaded.
	 */

	function wphave_notes_feature_enabled() {

		return wphave_feature_enabled( 'notes' );

	}

endif;

if ( ! function_exists( 'wphave_review_notes_feature_enabled' ) ) :

	/**
	 * Whether WordPress-native block review notes are available in WPHAVE.
	 *
	 * This release gate is intentionally separate from the Workspace Notes
	 * feature. Review notes use the Core comment entity and are scoped to an
	 * editable post; Workspace Notes remain independent private posts.
	 */
	function wphave_review_notes_feature_enabled(): bool {
		return wphave_release_feature_ready( 'reviewNotes' ) && version_compare( get_bloginfo( 'version' ), '6.9', '>=' );
	}

endif;


if ( ! function_exists( 'wphave_performance_monitor_feature_enabled' ) ) :

	/**
	 * Performance monitor feature enabled.
	 */

	function wphave_performance_monitor_feature_enabled() {

		return wphave_feature_enabled( 'performance-monitor' );

	}

endif;


if ( ! function_exists( 'wphave_request_profiler_feature_enabled' ) ) :

	/** Request profiler screen and explicit capture runtime enabled. */

	function wphave_request_profiler_feature_enabled(): bool {

		return wphave_feature_enabled( 'request-profiler' );

	}

endif;


if ( ! function_exists( 'wphave_backup_feature_enabled' ) ) :

	/**
	 * Check whether backup routes, jobs and scheduled events may be active.
	 */

	function wphave_backup_feature_enabled() {

		return wphave_feature_enabled( 'backups' );

	}

endif;


if ( ! function_exists( 'wphave_activity_feature_enabled' ) ) :

	/**
	 * Check whether the Activity Log runtime, routes and interface may be active.
	 *
	 * Disabling this extension intentionally preserves existing activity rows.
	 */

	function wphave_activity_feature_enabled() {

		return wphave_feature_enabled( 'activity' );

	}

endif;
