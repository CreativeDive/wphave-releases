/**
 * Frontend live search.
 */

(() => {
	const settings = window.wphaveLiveSearch || {};
	const minChars = Number(settings.minChars || 2);
	const limit = Number(settings.limit || 8);
	const labels = settings.labels || {};
	const states = new WeakMap();
	let resultsId = 0;

	if (!settings.endpoint) {
		return;
	}

	const debounce = (callback, delay = 220) => {
		let timer = null;

		return (...args) => {
			window.clearTimeout(timer);
			timer = window.setTimeout(() => callback(...args), delay);
		};
	};

	const getState = (form) => {
		if (!states.has(form)) {
			states.set(form, {
				controller: null,
				requestId: 0,
				results: null
			});
		}

		return states.get(form);
	};

	const ensureResults = (form) => {
		const state = getState(form);
		let results = state.results;

		if (!results) {
			results = document.createElement('div');
			results.className = 'wphave-popover-layer wphave-live-search';
			results.dataset.popoverPortal = 'true';
			results.dataset.popoverMatchWidth = 'true';
			results.dataset.popoverPreserveFocus = 'true';
			results.id = `wphave-live-search-${++resultsId}`;
			results.dataset.popoverId = results.id;
			results.setAttribute('role', 'status');
			results.setAttribute('aria-live', 'polite');
			results.setAttribute('aria-atomic', 'true');
			results.setAttribute('aria-label', labels.noResults);
			results.hidden = true;
			// Search results sit flush below the input; an arrow overlaps the first row.
			results.appendChild(document.createElement('ul'));
			// Keep suggestions outside form clipping and stacking contexts, even while closed.
			document.body.appendChild(results);
			state.results = results;
		}

		return results;
	};

	const clearResults = (form) => {
		const results = ensureResults(form);
		window.dispatchEvent(
			new CustomEvent('closePopover', { detail: { target: results.id, restoreFocus: false } })
		);
		results.setAttribute('aria-busy', 'false');
		results.querySelector('ul').replaceChildren();
	};

	const cancelSearch = (form) => {
		const state = getState(form);
		state.requestId += 1;

		if (state.controller) {
			state.controller.abort();
			state.controller = null;
		}

		clearResults(form);
	};

	const createFallbackThumb = (item) => {
		const thumb = document.createElement('div');
		thumb.className = 'thumb';

		const letter = document.createElement('div');
		letter.className = 'letter';

		const span = document.createElement('span');
		span.textContent = item.initial || '#';

		letter.appendChild(span);
		thumb.appendChild(letter);

		return thumb;
	};

	const createResultItem = (item) => {
		const li = document.createElement('li');
		li.className = 'wphave-live-search-item';

		const thumbnailLink = document.createElement('a');
		thumbnailLink.className = 'wphave-live-search-thumbnail';
		thumbnailLink.href = item.url || '#';
		thumbnailLink.tabIndex = -1;
		thumbnailLink.setAttribute('aria-hidden', 'true');

		if (item.thumbnail) {
			const img = document.createElement('img');
			img.src = item.thumbnail;
			img.alt = '';
			img.loading = 'lazy';
			thumbnailLink.appendChild(img);
		} else {
			thumbnailLink.appendChild(createFallbackThumb(item));
		}

		const titleLink = document.createElement('a');
		titleLink.className = 'search-title wphave-text-link';
		titleLink.href = item.url || '#';
		titleLink.textContent = item.title || '';

		li.append(thumbnailLink, titleLink);

		return li;
	};

	const createMessageItem = (message, className = 'no-match') => {
		const li = document.createElement('li');
		li.className = className;
		li.textContent = message;

		return li;
	};

	const createViewAllItem = (data) => {
		if (!data?.hasMore || !data?.searchUrl) {
			return null;
		}

		const li = document.createElement('li');
		li.className = 'wphave-live-search-view-all';

		const link = document.createElement('a');
		link.className = 'wphave-text-link';
		link.href = data.searchUrl;
		link.textContent = labels.viewAll;

		li.appendChild(link);

		return li;
	};

	const renderResults = (form, data) => {
		const results = ensureResults(form);
		const list = results.querySelector('ul');
		const fragment = document.createDocumentFragment();
		const items = Array.isArray(data?.items) ? data.items : [];

		if (items.length) {
			items.forEach((item) => fragment.appendChild(createResultItem(item)));

			const viewAll = createViewAllItem(data);

			if (viewAll) {
				fragment.appendChild(viewAll);
			}
		} else {
			fragment.appendChild(createMessageItem(labels.noResults));
		}

		list.replaceChildren(fragment);
		results.setAttribute('aria-busy', 'false');
		results.setAttribute('aria-label', items.length ? labels.results : labels.noResults);
		openResults(form, results);
	};

	const openResults = (form, results) => {
		const input = form.querySelector('input[type="search"]');

		// A completed request must not reopen suggestions after focus moves away.
		const activeElement = input.ownerDocument.activeElement;
		if (activeElement !== input && !results.contains(activeElement)) {
			return;
		}

		window.dispatchEvent(
			new CustomEvent('openPopover', {
				detail: { target: results.id, trigger: input }
			})
		);
	};

	const renderError = (form) => {
		const results = ensureResults(form);
		const list = results.querySelector('ul');
		list.replaceChildren(createMessageItem(labels.error, 'no-match is-error'));
		results.setAttribute('aria-busy', 'false');
		results.setAttribute('aria-label', labels.error);
		openResults(form, results);
	};

	const getPostTypes = (form, input) => {
		// SEARCH SCOPE INVARIANT: Suggestions use the same form fields as a full
		// search, including every selected type in a multi-select search block.
		const fields = form.querySelectorAll('input[name="post_type[]"], input[name="post_type"]');
		const postTypes = [...fields]
			.filter((field) => !field.disabled && field.value)
			.map((field) => field.value);

		return postTypes.length
			? postTypes.join(',')
			: form.dataset.postType || input.dataset.postType || '';
	};

	const search = async (form, input) => {
		const term = input.value.trim();

		if (term.length < minChars) {
			cancelSearch(form);
			return;
		}

		const state = getState(form);
		state.requestId += 1;
		const requestId = state.requestId;

		if (state.controller) {
			state.controller.abort();
		}

		state.controller = new AbortController();
		const results = ensureResults(form);
		results.setAttribute('aria-busy', 'true');
		results.setAttribute('aria-label', labels.loading);

		const params = new URLSearchParams({
			term,
			limit: String(limit)
		});
		const postType = getPostTypes(form, input);

		if (postType) {
			params.set('postType', postType);
		}

		try {
			const response = await fetch(`${settings.endpoint}?${params.toString()}`, {
				method: 'GET',
				credentials: 'same-origin',
				signal: state.controller.signal
			});
			const data = await response.json().catch(() => null);

			if (!response.ok) {
				throw new Error(data?.message || labels.error);
			}

			if (requestId === state.requestId) {
				state.controller = null;
				renderResults(form, data);
			}
		} catch (error) {
			if (error.name !== 'AbortError' && requestId === state.requestId) {
				state.controller = null;
				renderError(form);
			}
		}
	};

	const initForm = (form) => {
		if (form.dataset.wphaveLiveSearchReady === '1') {
			return;
		}

		const input = form.querySelector('input[type="search"]');

		if (!input) {
			return;
		}

		form.dataset.wphaveLiveSearchReady = '1';
		input.setAttribute('autocomplete', 'off');
		const results = ensureResults(form);
		input.setAttribute('aria-controls', results.id);
		input.setAttribute('aria-expanded', 'false');
		input.dataset.popoverControlled = 'true';
		input.dataset.popoverPlacement = 'bottom-start';
		results.addEventListener('popoverIsClosing', () => {
			const state = getState(form);
			state.requestId += 1;
			state.controller?.abort();
			state.controller = null;
		});

		const debouncedSearch = debounce(() => search(form, input));

		input.addEventListener('input', debouncedSearch);
		input.addEventListener('focus', () => {
			if (input.value.trim().length >= minChars) {
				search(form, input);
			}
		});
		input.addEventListener('keydown', (event) => {
			if (event.key === 'Escape') {
				cancelSearch(form);
			} else if (event.key === 'ArrowDown' && !results.hidden) {
				event.preventDefault();
				results.querySelector('a:not([tabindex="-1"])')?.focus();
			}
		});
		results.addEventListener('keydown', (event) => {
			const links = [...results.querySelectorAll('a:not([tabindex="-1"])')];
			const index = links.indexOf(results.ownerDocument.activeElement);

			if (event.key === 'Escape') {
				event.preventDefault();
				cancelSearch(form);
				input.focus();
			} else if (event.key === 'ArrowDown' && index !== -1) {
				event.preventDefault();
				links[(index + 1) % links.length]?.focus();
			} else if (event.key === 'ArrowUp' && index !== -1) {
				event.preventDefault();
				(index === 0 ? input : links[index - 1])?.focus();
			}
		});
	};

	const init = () => {
		document.querySelectorAll('form[role="search"]').forEach(initForm);
	};

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
})();
