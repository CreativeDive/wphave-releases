<?php

if (!defined('ABSPATH')) {
	exit();
}

if (!class_exists('WPHAVE_Live_Search')):
	/**
	 * Frontend live search powered by a public REST endpoint.
	 *
	 * The endpoint only returns published, publicly readable content and keeps
	 * expensive search requests bounded by minimum term length, result limits,
	 * short-lived caching and request-signature throttling.
	 */

	final class WPHAVE_Live_Search {
		const REST_NAMESPACE = 'wphave/v1';
		const REST_ROUTE = '/search';
		const SCRIPT_HANDLE = 'wphave-live-search';
		const MIN_TERM_LENGTH = 2;
		const MAX_TERM_LENGTH = 100;
		const MAX_POST_TYPE_FILTER_BYTES = 512;
		const DEFAULT_LIMIT = 8;
		const MAX_LIMIT = 10;
		const CACHE_TTL = 2 * MINUTE_IN_SECONDS;
		const RATE_LIMIT_MAX = 300;
		const RATE_LIMIT_WINDOW = HOUR_IN_SECONDS;

		/**
		 * Register frontend assets and REST routes.
		 *
		 * @return void
		 */

		public static function init(): void {
			add_action('wp_enqueue_scripts', [__CLASS__, 'enqueue_assets']);
			add_action('rest_api_init', [__CLASS__, 'register_rest_routes']);
		}

		/**
		 * Enqueue live search assets only when a supported search block exists.
		 *
		 * @return void
		 */

		public static function enqueue_assets(bool $force = false): void {
			static $assets_enqueued = false;

			if (
				function_exists('wphave_should_not_load_features') &&
				wphave_should_not_load_features()
			) {
				return;
			}

			if (!$force && !self::should_enqueue_assets()) {
				return;
			}

			if ($assets_enqueued) {
				return;
			}

			$assets_enqueued = true;

			$version = defined('WPHAVE_VERSION') ? WPHAVE_VERSION : null;

			wp_enqueue_style(
				self::SCRIPT_HANDLE,
				wphave_asset_url('inc/features/live-search/style.css'),
				[],
				$version,
				'all',
			);

			wp_enqueue_script(
				self::SCRIPT_HANDLE,
				wphave_asset_url('inc/features/live-search/script.js'),
				[],
				$version,
				true,
			);

			wp_localize_script(self::SCRIPT_HANDLE, 'wphaveLiveSearch', [
				'endpoint' => esc_url_raw(rest_url(self::REST_NAMESPACE . self::REST_ROUTE)),
				'minChars' => self::MIN_TERM_LENGTH,
				'limit' => self::DEFAULT_LIMIT,
				'labels' => [
					'loading' => __('Loading search results…', 'wphave'),
					'results' => __('Search results', 'wphave'),
					'noResults' => __('No matches were found', 'wphave'),
					'error' => __('Search results could not be loaded.', 'wphave'),
					'viewAll' => __('View all results', 'wphave'),
				],
			]);
		}

		/**
		 * Register the public live search REST endpoint.
		 *
		 * @return void
		 */

		public static function register_rest_routes(): void {
			register_rest_route(self::REST_NAMESPACE, self::REST_ROUTE, [
				'methods' => WP_REST_Server::READABLE,
				'callback' => [__CLASS__, 'rest_search'],
				'permission_callback' => '__return_true',
				'args' => [
					'term' => [
						'required' => true,
						'type' => 'string',
						'sanitize_callback' => 'sanitize_text_field',
						'validate_callback' => [__CLASS__, 'validate_search_term'],
					],
					'postType' => [
						'type' => 'string',
						'default' => 'any',
						'sanitize_callback' => 'sanitize_text_field',
						'validate_callback' => [__CLASS__, 'validate_post_type_filter'],
					],
					'limit' => [
						'type' => 'integer',
						'default' => self::DEFAULT_LIMIT,
						'minimum' => 1,
						'maximum' => self::MAX_LIMIT,
						'sanitize_callback' => 'absint',
					],
				],
			]);
		}

		/**
		 * Validate the public search term before it reaches WP_Query.
		 *
		 * @param mixed $term Search term.
		 * @return bool True when the term length is bounded.
		 */

		public static function validate_search_term($term): bool {
			return is_string($term) && self::string_length(trim($term)) <= self::MAX_TERM_LENGTH;
		}

		/** Validate the public post-type selector before list expansion. */

		public static function validate_post_type_filter($post_types): bool {
			return is_string($post_types) &&
				strlen($post_types) <= self::MAX_POST_TYPE_FILTER_BYTES;
		}

		/**
		 * Handle one live search request.
		 *
		 * @param WP_REST_Request $request REST request.
		 * @return WP_REST_Response|WP_Error Search response or rate-limit error.
		 */

		public static function rest_search(WP_REST_Request $request): WP_REST_Response|WP_Error {
			// PRIVACY INVARIANT: This route is deliberately public, so its query may
			// select only allowlisted public post types and published objects. It must
			// never reuse an authenticated/admin query that can reveal private state.
			$raw_term = $request->get_param('term');

			// AVAILABILITY INVARIANT: REST argument validation is only an early
			// transport boundary. The final public callback repeats type and byte-safe
			// character bounds before cache-key construction or WP_Query execution.
			if (!self::validate_search_term($raw_term)) {
				return new WP_Error(
					'wphave_live_search_invalid_term',
					__('The search term is invalid or too long.', 'wphave'),
					['status' => 400],
				);
			}

			$raw_post_types = $request->get_param('postType');
			$raw_post_types = null === $raw_post_types ? 'any' : $raw_post_types;

			// AVAILABILITY INVARIANT: The public type selector is bounded again at
			// the final callback before comma expansion, cache-key work or WP_Query.
			// Duplicate valid types never multiply downstream query dimensions.
			if (!self::validate_post_type_filter($raw_post_types)) {
				return new WP_Error(
					'wphave_live_search_invalid_post_types',
					__('The post-type filter is invalid or too long.', 'wphave'),
					['status' => 400],
				);
			}

			$term = trim(sanitize_text_field($raw_term));
			$limit = min(
				self::MAX_LIMIT,
				max(1, absint($request->get_param('limit') ?: self::DEFAULT_LIMIT)),
			);

			if (self::string_length($term) < self::MIN_TERM_LENGTH) {
				return rest_ensure_response(self::empty_response($term));
			}

			$post_types = self::allowed_post_types($raw_post_types);

			if (empty($post_types)) {
				return rest_ensure_response(self::empty_response($term));
			}

			$cache_key = self::cache_key($term, $post_types, $limit);
			$cached = get_transient($cache_key);

			if (is_array($cached)) {
				// DISCLOSURE INVARIANT: A cached search is not publication authority.
				// Reproject current objects so revocation, password changes and old
				// titles/thumbnails cannot survive in an anonymous response.
				$previous_count = count($cached['items'] ?? []);
				$cached['items'] = array_values(
					array_filter(
						array_map(
							static fn($item) => self::prepare_post_item((int) ($item['id'] ?? 0)),
							$cached['items'] ?? [],
						),
					),
				);
				if (count($cached['items']) !== $previous_count) {
					$cached['hasMore'] = false;
				}
				return rest_ensure_response($cached);
			}

			$rate_limit = self::check_rate_limit();

			if (is_wp_error($rate_limit)) {
				return $rate_limit;
			}

			$query = new WP_Query([
				'post_type' => $post_types,
				'post_status' => 'publish',
				'has_password' => false,
				's' => $term,
				'posts_per_page' => $limit + 1,
				'orderby' => 'relevance',
				'order' => 'DESC',
				'ignore_sticky_posts' => true,
				'no_found_rows' => true,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
			]);

			$posts = array_slice($query->posts, 0, $limit);
			$response = [
				'term' => $term,
				'items' => array_values(
					array_filter(array_map([__CLASS__, 'prepare_post_item'], $posts)),
				),
				'hasMore' => count($query->posts) > $limit,
				'searchUrl' => esc_url_raw(add_query_arg('s', $term, home_url('/'))),
			];

			set_transient($cache_key, $response, self::CACHE_TTL);

			return rest_ensure_response($response);
		}

		/**
		 * Check whether the current rendered content needs live search assets.
		 *
		 * @return bool True when supported search markup is present.
		 */

		private static function should_enqueue_assets(): bool {
			// Compatibility mode has no WPHAVE render engine that can discover late block and template output.
			if (function_exists('wphave_use_fse') && wphave_use_fse()) {
				return true;
			}

			if (
				class_exists('WPHAVE_Block_Inspector') &&
				(WPHAVE_Block_Inspector::rendered_content_contains('action-search') ||
					WPHAVE_Block_Inspector::rendered_content_contains(
						'wp-block-wphave-search-form',
					) ||
					WPHAVE_Block_Inspector::rendered_content_contains('wp-block-search'))
			) {
				return true;
			}

			return false;
		}

		/**
		 * Return sanitized public post types allowed for the search request.
		 *
		 * @param string $requested Requested post type list or any.
		 * @return array Allowed post type names.
		 */

		private static function allowed_post_types(string $requested): array {
			$public_post_types = get_post_types(
				[
					'public' => true,
					'exclude_from_search' => false,
				],
				'names',
			);

			unset($public_post_types['attachment']);

			if ($requested === '' || $requested === 'any') {
				return array_values($public_post_types);
			}

			$requested_types = array_values(
				array_unique(array_filter(array_map('sanitize_key', explode(',', $requested)))),
			);

			return array_values(array_intersect($requested_types, $public_post_types));
		}

		/**
		 * Convert a found post into the compact frontend result payload.
		 *
		 * @param WP_Post|int|null $post Post object or id.
		 * @return array|null Search result item or null when not public.
		 */

		private static function prepare_post_item($post): ?array {
			$post = $post instanceof WP_Post ? $post : get_post($post);

			// DISCLOSURE INVARIANT: This public projection never inherits a caller's password access.
			if (
				!$post ||
				!is_post_publicly_viewable($post) ||
				'' !== (string) $post->post_password
			) {
				return null;
			}

			$post_type_object = get_post_type_object($post->post_type);
			$title = get_the_title($post);
			$thumbnail = get_the_post_thumbnail_url($post, 'thumbnail');

			return [
				'id' => (int) $post->ID,
				'title' => $title ? $title : __('(no title)', 'wphave'),
				'url' => get_permalink($post),
				'type' => $post->post_type,
				'typeLabel' => $post_type_object
					? $post_type_object->labels->singular_name
					: $post->post_type,
				'thumbnail' => $thumbnail ? esc_url_raw($thumbnail) : '',
				'initial' => self::initial($title),
			];
		}

		/**
		 * Return the fallback initial used when a result has no thumbnail.
		 *
		 * @param string $title Result title.
		 * @return string Uppercase initial or placeholder.
		 */

		private static function initial(string $title): string {
			$title = trim(wp_strip_all_tags($title));

			if ($title === '') {
				return '#';
			}

			return self::string_upper(self::string_substr($title, 0, 1));
		}

		/**
		 * Build an empty response with the matching full search URL.
		 *
		 * @param string $term Search term.
		 * @return array Empty response payload.
		 */

		private static function empty_response(string $term): array {
			return [
				'term' => $term,
				'items' => [],
				'hasMore' => false,
				'searchUrl' => esc_url_raw(add_query_arg('s', $term, home_url('/'))),
			];
		}

		/**
		 * Build a short-lived cache key for one normalized search request.
		 *
		 * @param string $term Search term.
		 * @param array $post_types Allowed post types.
		 * @param int $limit Result limit.
		 * @return string Transient cache key.
		 */

		private static function cache_key(string $term, array $post_types, int $limit): string {
			sort($post_types);

			return 'wphave_live_search_' .
				md5(self::string_lower($term) . '|' . implode(',', $post_types) . '|' . $limit);
		}

		/**
		 * Return multibyte-safe string length with fallbacks.
		 *
		 * @param string $value Input string.
		 * @return int String length.
		 */

		private static function string_length(string $value): int {
			if (function_exists('wphave_strlen')) {
				return wphave_strlen($value);
			}

			return function_exists('mb_strlen') ? mb_strlen($value) : strlen($value);
		}

		/**
		 * Return a multibyte-safe substring with fallbacks.
		 *
		 * @param string $value Input string.
		 * @param int $start Start offset.
		 * @param int|null $length Optional length.
		 * @return string Substring.
		 */

		private static function string_substr(
			string $value,
			int $start,
			?int $length = null,
		): string {
			if (function_exists('wphave_substr')) {
				return wphave_substr($value, $start, $length);
			}

			return function_exists('mb_substr')
				? mb_substr($value, $start, $length)
				: substr($value, $start, $length);
		}

		/**
		 * Return a lowercase string with multibyte support when available.
		 *
		 * @param string $value Input string.
		 * @return string Lowercase string.
		 */

		private static function string_lower(string $value): string {
			return function_exists('mb_strtolower') ? mb_strtolower($value) : strtolower($value);
		}

		/**
		 * Return an uppercase string with multibyte support when available.
		 *
		 * @param string $value Input string.
		 * @return string Uppercase string.
		 */

		private static function string_upper(string $value): string {
			return function_exists('mb_strtoupper') ? mb_strtoupper($value) : strtoupper($value);
		}

		/**
		 * Apply a transient-backed rate limit for public search requests.
		 *
		 * @return true|WP_Error True when allowed, otherwise rate-limit error.
		 */

		private static function check_rate_limit() {
			$key = 'wphave_live_search_rate_' . md5(self::request_signature());

			$count = WPHAVE_Rate_Limiter::increment($key, self::RATE_LIMIT_WINDOW);

			if ($count > self::RATE_LIMIT_MAX) {
				return new WP_Error(
					'wphave_live_search_rate_limited',
					__('Too many search requests. Please try again later.', 'wphave'),
					['status' => 429],
				);
			}

			return true;
		}

		/**
		 * Build an HMAC request signature for throttling only.
		 *
		 * @return string Request signature.
		 */

		private static function request_signature(): string {
			// ABUSE INVARIANT: Every public caller shares its network budget,
			// regardless of login state, User-Agent or disposable visitor identity.
			$signature = WPHAVE_Rate_Limiter::client_key('live-search');
			// Trusted PHP integrations retain their existing extension contract.
			$signature = (string) apply_filters(
				'wphave_live_search_rate_limit_signature',
				$signature,
				WPHAVE_Client_IP::resolve(),
				sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'] ?? '')),
				get_current_user_id(),
			);
			return hash_hmac('sha256', $signature, wp_salt('nonce'));
		}
	}

	WPHAVE_Live_Search::init();
endif;
