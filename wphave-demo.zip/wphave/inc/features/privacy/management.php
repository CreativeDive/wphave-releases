<?php

/**
 * Register Privacy management routes without loading workflow implementations.
 *
 * Consent processing remains owned by the frontend bootstrap. Privacy requests
 * and scanner internals cross this synchronous boundary only while WordPress
 * registers the feature's REST routes.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function wphave_privacy_register_management_routes(): void {
	require_once __DIR__ . '/core/request-manager.php';
	require_once __DIR__ . '/scanner/bootstrap.php';

	WPHAVE_Privacy_Request_Manager::register_routes();
	WPHAVE_Privacy_Scanner::register_rest_routes();
}

add_action( 'rest_api_init', 'wphave_privacy_register_management_routes' );
