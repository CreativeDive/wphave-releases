<?php

/** Public information derived from the registered WPHAVE processing inventory. */
class WPHAVE_Privacy_Consent_Disclosures {
	public static function get(array $processings): array {
		$operator = wphave_data_get('privacy_settings', 'consent.disclosure', []);
		$operator = is_array($operator) ? $operator : [];
		$common = ['privacyUrl' => get_privacy_policy_url()];
		foreach (['provider', 'recipients', 'transfers'] as $field) {
			$common[$field] = is_string($operator[$field] ?? null)
				? sanitize_textarea_field($operator[$field])
				: '';
		}

		$services = [
			[
				'id' => 'wphave-consent',
				'label' => __('Privacy preferences', 'wphave'),
				'category' => 'necessary',
				'disclosure' => array_merge($common, [
					'purpose' => __('Remember your consent choices for this website.', 'wphave'),
					'data' => __('Your selected consent categories.', 'wphave'),
					'retention' => __(
						'No separate server-side consent history is created by this preference cookie.',
						'wphave',
					),
					'storageMode' => 'listed',
					'storage' => [
						[
							'type' => 'cookie',
							'name' => 'wphave_consent',
							'purpose' => __('Remember your consent choices.', 'wphave'),
							'duration' => __(
								'365 days from the last saved choice, or until you delete the cookie.',
								'wphave',
							),
						],
					],
				]),
			],
		];
		if (!(bool) wphave_data_get('site_settings', 'advanced.analytics.enabled', false)) {
			return $services;
		}
		foreach (['analytics_aggregate', 'analytics_sessions', 'analytics_attribution'] as $id) {
			$processing = $processings[$id] ?? null;
			if (!$processing) {
				continue;
			}
			$storage = [];
			foreach ($processing['storage'] as $location) {
				[$type, $name] = array_pad(explode(':', $location, 2), 2, '');
				if (!in_array($type, ['localStorage', 'sessionStorage'], true)) {
					continue;
				}
				if (
					strpos($name, 'wphave_params') === 0 &&
					wphave_data_get('site_settings', 'advanced.parameter.state', 'disabled') ===
						'disabled'
				) {
					continue;
				}
				$is_visitor_storage =
					$type === 'localStorage' &&
					in_array($name, ['wphave_visitor_id', 'wphave_visitor_expires_at'], true);
				$storage[] = [
					'type' => $type,
					'name' => $name,
					'purpose' => $processing['description'],
					'duration' => $is_visitor_storage
						? __(
							'Valid for 90 days from creation, without renewal on visits. Expired values are discarded on the next access. Removed earlier when Analytics consent is withdrawn or website data is cleared.',
							'wphave',
						)
						: ($type === 'localStorage'
							? __(
								'No automatic expiry. Removed when Analytics consent is withdrawn or website data is cleared.',
								'wphave',
							)
							: __(
								'For the browser tab session, or until Analytics consent is withdrawn. Session restoration by the browser may extend this lifetime.',
								'wphave',
							)),
				];
			}
			$retention = '';
			if (isset($processing['retention_days'])) {
				$retention = sprintf(
					__('%d days; expired records are removed by scheduled cleanup.', 'wphave'),
					$processing['retention_days'],
				);
			} elseif (isset($processing['retention_months'])) {
				$retention = sprintf(
					__('%d months; expired records are removed by scheduled cleanup.', 'wphave'),
					$processing['retention_months'],
				);
			}

			$services[] = [
				'id' => 'wphave-' . $id,
				'label' => $processing['label'],
				'category' => $id === 'analytics_aggregate' ? '' : 'analytics',
				'blockingEnabled' => $id !== 'analytics_aggregate',
				'disclosure' => array_merge($common, [
					'purpose' => $processing['description'],
					'data' =>
						$id === 'analytics_aggregate'
							? __(
								'Anonymous aggregated page and traffic counts without visitor or session identifiers.',
								'wphave',
							)
							: ($id === 'analytics_sessions'
								? __(
									'Pseudonymous visitor and session identifiers, page views and interactions, device and browser categories, browser language including region, and viewport dimensions in CSS pixels.',
									'wphave',
								)
								: __(
									'Campaign parameters, referrer information and conversion assignments to a pseudonymous session.',
									'wphave',
								)),
					'retention' => $retention,
					'storageMode' => $storage ? 'listed' : 'none',
					'storage' => $storage,
				]),
			];
		}
		return $services;
	}
}
