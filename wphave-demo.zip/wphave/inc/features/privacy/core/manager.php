<?php

/**
 * Central privacy processing registry and authorization gateway.
 *
 * Features must register persistent processing here and ask this manager before
 * creating visitor identifiers, storing attribution or linking journeys. The
 * registry is intentionally runtime-only: it documents and coordinates the
 * product's processing behavior without creating another source of customer
 * data in WordPress options.
 *
 * @package wphave
 */

if (!defined('ABSPATH')) {
	exit();
}

class WPHAVE_Privacy_Manager {
	const PURPOSE_ESSENTIAL = 'essential';
	const PURPOSE_ANALYTICS_AGGREGATE = 'analytics_aggregate';
	const PURPOSE_ANALYTICS_SESSIONS = 'analytics_sessions';
	const PURPOSE_ANALYTICS_ATTRIBUTION = 'analytics_attribution';
	const PURPOSE_AUDIENCE_LEADS = 'audience_leads';
	const PURPOSE_MARKETING_SUBSCRIPTIONS = 'marketing_subscriptions';
	const PURPOSE_EXTERNAL_SERVICES = 'external_services';

	private static $processings = [];
	private static $identities = [];
	private static $retention_policies = [];
	private static $exporters = [];
	private static $erasers = [];
	private static $booted = false;

	/**
	 * Initializes WordPress privacy integration and the built-in registry.
	 *
	 * @return void
	 */

	public static function boot(): void {
		if (self::$booted) {
			return;
		}

		self::$booted = true;
		self::register_default_processings();
		add_filter('wphave_consent_services', [__CLASS__, 'register_consent_services']);
		add_filter('wp_privacy_personal_data_exporters', [
			__CLASS__,
			'register_wordpress_exporters',
		]);
		add_filter('wp_privacy_personal_data_erasers', [__CLASS__, 'register_wordpress_erasers']);
	}

	/**
	 * Returns the canonical purpose definitions used by all WPHAVE modules.
	 *
	 * @return array
	 */

	public static function get_purposes(): array {
		return [
			self::PURPOSE_ESSENTIAL => [
				'label' => __('Essential functionality', 'wphave'),
				'consent_category' => 'necessary',
				'requires_consent' => false,
			],
			self::PURPOSE_ANALYTICS_AGGREGATE => [
				'label' => __('Anonymous analytics', 'wphave'),
				'consent_category' => 'necessary',
				'requires_consent' => false,
			],
			self::PURPOSE_ANALYTICS_SESSIONS => [
				'label' => __('Analytics sessions', 'wphave'),
				'consent_category' => 'analytics',
				'requires_consent' => true,
			],
			self::PURPOSE_ANALYTICS_ATTRIBUTION => [
				'label' => __('Analytics attribution', 'wphave'),
				'consent_category' => 'analytics',
				'requires_consent' => true,
			],
			self::PURPOSE_AUDIENCE_LEADS => [
				'label' => __('Audience leads', 'wphave'),
				'consent_category' => 'analytics',
				'requires_consent' => true,
			],
			self::PURPOSE_MARKETING_SUBSCRIPTIONS => [
				'label' => __('Marketing subscriptions', 'wphave'),
				'consent_category' => 'marketing',
				'requires_consent' => true,
			],
			self::PURPOSE_EXTERNAL_SERVICES => [
				'label' => __('External services', 'wphave'),
				'consent_category' => '',
				'requires_consent' => true,
			],
		];
	}

	/**
	 * Registers one product processing activity.
	 *
	 * Required fields: id and purpose. Storage is a list of technical storage
	 * locations, for example "database:wphave_analytics_events" or
	 * "localStorage:wphave_visitor_id".
	 *
	 * @param array $processing Processing definition.
	 * @return bool Whether the definition was accepted.
	 */

	public static function register_processing(array $processing): bool {
		$id = sanitize_key($processing['id'] ?? '');
		$purpose = sanitize_key($processing['purpose'] ?? '');

		if (!$id || !isset(self::get_purposes()[$purpose])) {
			return false;
		}

		self::$processings[$id] = [
			'id' => $id,
			'label' => sanitize_text_field($processing['label'] ?? $id),
			'purpose' => $purpose,
			'storage' => array_values(
				array_filter(
					array_map('sanitize_text_field', (array) ($processing['storage'] ?? [])),
				),
			),
			'retention_days' => isset($processing['retention_days'])
				? max(0, absint($processing['retention_days']))
				: null,
			'retention_months' => isset($processing['retention_months'])
				? max(0, absint($processing['retention_months']))
				: null,
			'erasable' => !empty($processing['erasable']),
			'description' => sanitize_text_field($processing['description'] ?? ''),
		];

		return true;
	}

	/**
	 * Returns the product's registered processing activities.
	 *
	 * @return array
	 */

	public static function get_processings(): array {
		return self::$processings;
	}

	/**
	 * Adds WPHAVE's own data processing to the consent preferences UI.
	 *
	 * @param array $services Configured external and product services.
	 * @return array
	 */

	public static function register_consent_services(array $services): array {
		if (!(bool) wphave_data_get('site_settings', 'advanced.analytics.enabled', false)) {
			return $services;
		}

		$services[] = [
			'id' => 'wphave-analytics',
			'label' => __('Website analytics', 'wphave'),
			'category' => 'analytics',
			'description' => __(
				'Anonymous daily page totals are recorded without a visitor identifier. With Analytics consent, pseudonymous sessions and detailed interactions are also recorded.',
				'wphave',
			),
		];
		$services[] = [
			'id' => 'wphave-analytics-attribution',
			'label' => __('Campaign and conversion measurement', 'wphave'),
			'category' => 'analytics',
			'description' => __(
				'With Analytics consent, campaign parameters, referrer information and conversions can be assigned to a pseudonymous session.',
				'wphave',
			),
		];

		return $services;
	}

	/**
	 * Checks whether a processing purpose may run for the current request.
	 *
	 * Consent-dependent purposes fail closed when the WPHAVE consent manager is
	 * unavailable or disabled. Integrations with an external CMP can explicitly
	 * allow a purpose through the wphave_privacy_can_process filter.
	 *
	 * @param string $purpose Purpose id.
	 * @param array $context Optional processing context.
	 * @return bool
	 */

	public static function can_process(string $purpose, array $context = []): bool {
		$purpose = sanitize_key($purpose);
		$definition = self::get_purposes()[$purpose] ?? null;

		if (!$definition) {
			return false;
		}

		if (empty($definition['requires_consent'])) {
			$allowed = true;
		} elseif (class_exists('WPHAVE_Consent_Manager')) {
			$consent = WPHAVE_Consent_Manager::instance();
			$category = sanitize_key(
				$context['consent_category'] ?? $definition['consent_category'],
			);
			$allowed = $category && $consent->is_enabled() && $consent->has_consent($category);
		} else {
			$allowed = false;
		}

		return (bool) apply_filters(
			'wphave_privacy_can_process',
			$allowed,
			$purpose,
			$context,
			$definition,
		);
	}

	/**
	 * Registers a browser-side identifier and the purpose that authorizes it.
	 *
	 * @param array $identity Identifier definition.
	 * @return bool Whether the definition was accepted.
	 */

	public static function register_identity(array $identity): bool {
		$id = sanitize_key($identity['id'] ?? '');
		$purpose = sanitize_key($identity['purpose'] ?? '');
		$storage = sanitize_text_field($identity['storage'] ?? '');

		if (!$id || !$storage || !isset(self::get_purposes()[$purpose])) {
			return false;
		}

		self::$identities[$id] = [
			'id' => $id,
			'purpose' => $purpose,
			'storage' => $storage,
			'retention_days' => isset($identity['retention_days'])
				? max(0, absint($identity['retention_days']))
				: null,
			'description' => sanitize_text_field($identity['description'] ?? ''),
		];

		return true;
	}

	/**
	 * Returns registered browser-side identifiers.
	 *
	 * @return array
	 */

	public static function get_identities(): array {
		return self::$identities;
	}

	/**
	 * Registers an automatic data-retention policy.
	 *
	 * A feature owns the actual cleanup callback. This class provides the
	 * central inventory and later cron orchestration point.
	 *
	 * @param array $policy Retention policy definition.
	 * @return bool Whether the definition was accepted.
	 */

	public static function register_retention_policy(array $policy): bool {
		$id = sanitize_key($policy['id'] ?? '');
		$days = absint($policy['retention_days'] ?? 0);

		if (!$id || !$days || empty($policy['callback']) || !is_callable($policy['callback'])) {
			return false;
		}

		self::$retention_policies[$id] = [
			'id' => $id,
			'label' => sanitize_text_field($policy['label'] ?? $id),
			'retention_days' => $days,
			'callback' => $policy['callback'],
		];

		return true;
	}

	/**
	 * Returns retention metadata without exposing callbacks to UI consumers.
	 *
	 * @return array
	 */

	public static function get_retention_policies(): array {
		return array_map(static function (array $policy): array {
			unset($policy['callback']);
			return $policy;
		}, self::$retention_policies);
	}

	/**
	 * Registers a WordPress privacy exporter owned by a WPHAVE feature.
	 *
	 * @param string $id Stable exporter id.
	 * @param string $name Human-readable name.
	 * @param callable $callback WordPress exporter callback.
	 * @return void
	 */

	public static function register_exporter(string $id, string $name, callable $callback): void {
		self::$exporters[sanitize_key($id)] = [
			'exporter_friendly_name' => $name,
			'callback' => $callback,
		];
	}

	/**
	 * Registers a WordPress privacy eraser owned by a WPHAVE feature.
	 *
	 * @param string $id Stable eraser id.
	 * @param string $name Human-readable name.
	 * @param callable $callback WordPress eraser callback.
	 * @return void
	 */

	public static function register_eraser(string $id, string $name, callable $callback): void {
		self::$erasers[sanitize_key($id)] = [
			'eraser_friendly_name' => $name,
			'callback' => $callback,
		];
	}

	/**
	 * Adds feature exporters to WordPress's registered exporter list.
	 *
	 * @param array $exporters Registered exporters.
	 * @return array
	 */

	public static function register_wordpress_exporters(array $exporters): array {
		return array_merge($exporters, self::$exporters);
	}

	/**
	 * Adds feature erasers to WordPress's registered eraser list.
	 *
	 * @param array $erasers Registered erasers.
	 * @return array
	 */

	public static function register_wordpress_erasers(array $erasers): array {
		return array_merge($erasers, self::$erasers);
	}

	/**
	 * Registers the known product processing activities without changing how
	 * existing features behave. Individual feature migrations will wire their
	 * runtime calls to can_process() in follow-up changes.
	 *
	 * @return void
	 */

	private static function register_default_processings(): void {
		self::register_processing([
			'id' => 'analytics_aggregate',
			'label' => __('Anonymous analytics totals', 'wphave'),
			'purpose' => self::PURPOSE_ANALYTICS_AGGREGATE,
			'storage' => ['database:wphave_analytics_daily'],
			'retention_months' => class_exists('WPHAVE_Analytics_Retention_Policy')
				? WPHAVE_Analytics_Retention_Policy::aggregate_months()
				: 25,
			'erasable' => false,
			'description' => __(
				'Daily aggregated page and traffic totals without visitor or session identifiers.',
				'wphave',
			),
		]);
		self::register_processing([
			'id' => 'analytics_sessions',
			'label' => __('Analytics sessions and journeys', 'wphave'),
			'purpose' => self::PURPOSE_ANALYTICS_SESSIONS,
			'storage' => [
				'localStorage:wphave_visitor_id',
				'sessionStorage:wphave_session_id',
				'database:wphave_analytics_events',
			],
			'retention_days' => class_exists('WPHAVE_Analytics_Retention_Policy')
				? WPHAVE_Analytics_Retention_Policy::raw_days()
				: 30,
			'erasable' => true,
			'description' => __('Pseudonymous events, sessions and journeys.', 'wphave'),
		]);
		self::register_processing([
			'id' => 'analytics_attribution',
			'label' => __('Campaign and referrer attribution', 'wphave'),
			'purpose' => self::PURPOSE_ANALYTICS_ATTRIBUTION,
			'storage' => [
				'sessionStorage:wphave_attribution',
				'sessionStorage:wphave_params',
				'database:wphave_analytics_events',
			],
			'retention_days' => class_exists('WPHAVE_Analytics_Retention_Policy')
				? WPHAVE_Analytics_Retention_Policy::raw_days()
				: 30,
			'erasable' => true,
			'description' => __(
				'Campaign parameters, referrer and conversion attribution.',
				'wphave',
			),
		]);
		self::register_processing([
			'id' => 'audience_leads',
			'label' => __('Audience leads', 'wphave'),
			'purpose' => self::PURPOSE_AUDIENCE_LEADS,
			'storage' => [
				'database:wphave_audience_contacts',
				'database:wphave_audience_identities',
				'database:wphave_audience_interactions',
				'database:wphave_audience_leads',
				'database:wphave_audience_activities',
				'database:wphave_audience_consent_events',
				'database:wphave_audience_consent_evidence',
				'database:wphave_audience_entity_tags',
				'database:wphave_audience_field_values',
			],
			'erasable' => true,
			'description' => __('Form contact data and optional attribution.', 'wphave'),
		]);
		self::register_processing([
			'id' => 'marketing_subscribers',
			'label' => __('Marketing subscribers', 'wphave'),
			'purpose' => self::PURPOSE_MARKETING_SUBSCRIPTIONS,
			'storage' => [
				'database:wphave_audience_contacts',
				'database:wphave_audience_identities',
				'database:wphave_audience_subscribers',
				'database:wphave_audience_consent_events',
				'database:wphave_audience_consent_evidence',
			],
			'erasable' => true,
			'description' => __('Subscription status, consent record and contact data.', 'wphave'),
		]);
		self::register_identity([
			'id' => 'analytics_visitor',
			'purpose' => self::PURPOSE_ANALYTICS_SESSIONS,
			'storage' => 'localStorage:wphave_visitor_id',
			'description' => __('Pseudonymous persistent analytics visitor identifier.', 'wphave'),
		]);
		self::register_processing([
			'id' => 'marketing_suppression_proof',
			'label' => __('Marketing unsubscribe proof', 'wphave'),
			'purpose' => self::PURPOSE_MARKETING_SUBSCRIPTIONS,
			'storage' => ['database:wphave_audience_subscribers.email_hash'],
			'retention_days' => 1095,
			'erasable' => true,
			'description' => __(
				'Minimal hashed email, purpose and withdrawal timestamp retained after an unsubscribe.',
				'wphave',
			),
		]);
		self::register_identity([
			'id' => 'analytics_session',
			'purpose' => self::PURPOSE_ANALYTICS_SESSIONS,
			'storage' => 'sessionStorage:wphave_session_id',
			'description' => __('Pseudonymous analytics session identifier.', 'wphave'),
		]);
	}
}

add_action('init', ['WPHAVE_Privacy_Manager', 'boot']);

/**
 * Checks whether a WPHAVE processing purpose is authorized right now.
 *
 * @param string $purpose Purpose id.
 * @param array $context Optional processing context.
 * @return bool
 */

function wphave_privacy_can_process(string $purpose, array $context = []): bool {
	return WPHAVE_Privacy_Manager::can_process($purpose, $context);
}
