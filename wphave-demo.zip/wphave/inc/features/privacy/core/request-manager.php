<?php

/**
 * Privacy request preview and WordPress request bridge.
 *
 * @package wphave
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once wphave_dir() . 'inc/background-jobs/functions.php';
require_once wphave_dir() . 'inc/features/security/file-identity.php';
require_once wphave_dir() . 'inc/features/security/atomic-file.php';
require_once wphave_dir() . 'inc/features/security/rate-limiter.php';
require_once wphave_dir() . 'inc/features/security/client-ip.php';

class WPHAVE_Privacy_Request_Manager {

    const REST_NAMESPACE = 'wphave/v1';
	const EXPORT_CLEANUP_HOOK = 'wphave_privacy_export_cleanup';
	const EXPORT_CLEANUP_SCHEDULE_OPTION = 'wphave_privacy_export_cleanup_schedule';
	const EXPORT_CLEANUP_RETRY_META = '_wphave_privacy_export_cleanup_retry_at';
	const EXPORT_TOKEN_LENGTH = 48;
	const EXPORT_LOOKUP_ATTEMPT_LIMIT = 120;
	const MAX_ENCRYPTED_EXPORT_BYTES = 16 * MB_IN_BYTES;
	const MAX_EXPORT_ITEMS = 2000;
	const MAX_EXPORT_FIELD_BYTES = 65536;
	const MAX_EXPORT_PLAINTEXT_BYTES = 8 * MB_IN_BYTES;
	private static bool $routes_registered = false;

    /**
     * Initialize the request feature.
     *
     * @return void
     */

    public static function init(): void {
		// RUNTIME INVARIANT: privacy/management.php exclusively owns REST route
		// discovery. This engine is also loaded by Cron for export retention and
		// must not register an unreachable interactive surface there.
		add_action( 'init', [ __CLASS__, 'schedule_export_cleanup' ] );
		add_action( self::EXPORT_CLEANUP_HOOK, [ __CLASS__, 'cleanup_expired_exports' ] );
		add_action( 'before_delete_post', [ __CLASS__, 'cleanup_deleted_request_export' ], 10, 2 );
    }

    /**
     * Register the request REST routes.
     *
     * @return void
     */

    public static function register_routes(): void {
		if ( self::$routes_registered ) {
			return;
		}

		self::$routes_registered = true;

        register_rest_route( self::REST_NAMESPACE, '/privacy/requests/preview', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [ __CLASS__, 'preview' ],
            'permission_callback' => [ __CLASS__, 'can_manage' ],
            'args' => [ 'email' => [ 'required' => true, 'type' => 'string', 'maxLength' => 254 ] ],
        ] );
        register_rest_route( self::REST_NAMESPACE, '/privacy/requests', [
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [ __CLASS__, 'list_requests' ],
                'permission_callback' => [ __CLASS__, 'can_manage' ],
            ],
            [
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => [ __CLASS__, 'create_request' ],
                'permission_callback' => [ __CLASS__, 'can_manage' ],
                'args' => [
                    'email' => [ 'required' => true, 'type' => 'string', 'maxLength' => 254 ],
                    'type' => [ 'required' => true, 'sanitize_callback' => 'sanitize_key' ],
                ],
            ],
        ] );
        register_rest_route( self::REST_NAMESPACE, '/privacy/requests/(?P<id>\d+)/process', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [ __CLASS__, 'process_request' ],
            'permission_callback' => [ __CLASS__, 'can_manage' ],
			'args' => [
				'id' => [ 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ],
			],
        ] );
        register_rest_route( self::REST_NAMESPACE, '/privacy/exports/(?P<id>\d+)', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [ __CLASS__, 'download_export' ],
            'permission_callback' => '__return_true',
            'args' => [ 'token' => [ 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ] ],
        ] );
    }

    /**
     * Determine whether the current user can manage request.
     *
     * @return bool Determine whether the current user can manage request.
     */

    public static function can_manage(): bool {
		$can_manage = current_user_can( 'manage_options' ) || current_user_can( 'wphave_manage_settings_privacy' );

		return $can_manage && function_exists( 'wphave_privacy_has_pro_access' ) && wphave_privacy_has_pro_access();
    }

    /**
     * Preview.
     *
     * @param WP_REST_Request $request REST request.
     */

    public static function preview( WP_REST_Request $request ) {
		$authorization = self::require_manage_access();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$raw_email = $request->get_param( 'email' );
		// PRIVACY-IDENTITY INVARIANT: Preview and creation accept one bounded
		// mailbox identity before sanitizers, exporters or Core request lookups.
		if ( ! is_string( $raw_email ) || strlen( $raw_email ) > 254 ) {
			return new WP_Error( 'wphave_privacy_invalid_email', __( 'Enter a valid email address.', 'wphave' ), [ 'status' => 400 ] );
		}
		$email = sanitize_email( $raw_email );
		// IDENTITY INVARIANT: Preview counts belong to the exact mailbox the
		// operator named. Sanitization must not silently select another person.
		if ( $email !== $raw_email ) {
			return new WP_Error( 'wphave_privacy_invalid_email', __( 'Enter a valid email address.', 'wphave' ), [ 'status' => 400 ] );
		}

        if ( ! is_email( $email ) ) {
            return new WP_Error( 'wphave_privacy_invalid_email', __( 'Enter a valid email address.', 'wphave' ), [ 'status' => 400 ] );
        }

        $summaries = [];
        $exporters = apply_filters( 'wp_privacy_personal_data_exporters', [] );

        foreach ( $exporters as $id => $exporter ) {
            if ( ! str_starts_with( $id, 'wphave-' ) || empty( $exporter['callback'] ) || ! is_callable( $exporter['callback'] ) ) {
                continue;
            }

            $result = call_user_func( $exporter['callback'], $email, 1 );
            $summaries[] = [
                'id' => $id,
                'label' => sanitize_text_field( $exporter['exporter_friendly_name'] ?? $id ),
                'items' => is_array( $result['data'] ?? null ) ? count( $result['data'] ) : 0,
                'hasMore' => empty( $result['done'] ),
            ];
        }

		// AUTHORIZATION/PRIVACY-REQUEST-PREVIEW-RESPONSE INVARIANT: Exporter
		// registration and execution are extension boundaries that can expose
		// data-subject presence and counts. Revalidate capability and Pro entitlement
		// after every summary is projected and immediately before disclosure.
		$authorization = self::require_manage_access();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

        return rest_ensure_response( [ 'email' => $email, 'sources' => $summaries ] );
    }

    /**
     * Create request.
     *
     * @param WP_REST_Request $request REST request.
     */

    public static function create_request( WP_REST_Request $request ) {
		$authorization = self::require_manage_access();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$raw_email = $request->get_param( 'email' );
		if ( ! is_string( $raw_email ) || strlen( $raw_email ) > 254 ) {
			return new WP_Error( 'wphave_privacy_invalid_request', __( 'Choose a valid email address and request type.', 'wphave' ), [ 'status' => 400 ] );
		}
		$email = sanitize_email( $raw_email );
		// IDENTITY INVARIANT: A privacy request and its confirmation mail must
		// target exactly the submitted mailbox, never a sanitizer-derived one.
		if ( $email !== $raw_email ) {
			return new WP_Error( 'wphave_privacy_invalid_request', __( 'Choose a valid email address and request type.', 'wphave' ), [ 'status' => 400 ] );
		}
        $type = sanitize_key( $request->get_param( 'type' ) );
        $action_name = [ 'export' => 'export_personal_data', 'erase' => 'remove_personal_data' ][ $type ] ?? '';

        if ( ! is_email( $email ) || ! $action_name ) {
            return new WP_Error( 'wphave_privacy_invalid_request', __( 'Choose a valid email address and request type.', 'wphave' ), [ 'status' => 400 ] );
        }

		// AUTHORIZATION/PRIVACY-REQUEST-CREATE-COMMIT INVARIANT: Request
		// sanitizers and validation execute extension code after callback admission.
		// Revalidate capability and Pro entitlement immediately before Core may
		// create a durable request that can trigger external confirmation mail.
		$authorization = self::require_manage_access();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

        require_once ABSPATH . 'wp-admin/includes/user.php';
        $request_id = wp_create_user_request( $email, $action_name );

        if ( is_wp_error( $request_id ) ) {
            return $request_id;
        }
		$created_request = get_post( $request_id );
		$created_request = $created_request instanceof WP_Post ? clone $created_request : null;

		// OWNERSHIP/COMMIT INVARIANT: A Core user request is not owned by WPHAVE
		// until its exact marker is durable. External confirmation must never make
		// an unmarked request actionable by the data subject but invisible to the
		// WPHAVE list and processor.
		update_post_meta( $request_id, '_wphave_privacy_request', '1' );
		if (
			! metadata_exists( 'post', $request_id, '_wphave_privacy_request' )
			|| '1' !== get_post_meta( $request_id, '_wphave_privacy_request', true )
		) {
			self::rollback_unmarked_request( (int) $request_id, $created_request, $email, $action_name );

			return new WP_Error(
				'wphave_privacy_request_marker_failed',
				__( 'The privacy request could not be saved safely.', 'wphave' ),
				[ 'status' => 500 ]
			);
		}

        $sent = wp_send_user_request( $request_id );

        if ( is_wp_error( $sent ) ) {
            return $sent;
        }

        return rest_ensure_response( [
            'requestId' => (int) $request_id,
            'status' => 'confirmation_sent',
            'message' => __( 'WordPress sent a confirmation email to the data subject. The request can be processed after confirmation.', 'wphave' ),
        ] );
    }

	/** Core created the request; remove it only while its initial state remains intact. */
	private static function rollback_unmarked_request( int $request_id, ?WP_Post $created, string $email, string $action_name ): void {
		$current = get_post( $request_id );
		// ROLLBACK INVARIANT: A failed WPHAVE marker is not permission to delete
		// a Core privacy request changed by a metadata hook or administrator.
		if (
			! $created instanceof WP_Post
			|| ! $current instanceof WP_Post
			|| 'user_request' !== $current->post_type
			|| 'request-pending' !== $current->post_status
			|| $email !== $current->post_title
			|| $action_name !== $current->post_name
			|| $created->post_author !== $current->post_author
			|| $created->post_content !== $current->post_content
			|| $created->post_status !== $current->post_status
		) {
			return;
		}
		wp_delete_post( $request_id, true );
	}

    /**
     * List requests.
     */

    public static function list_requests() {
		$authorization = self::require_manage_access();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

        $posts = get_posts( [
            'post_type' => 'user_request',
            'post_status' => 'any',
            'posts_per_page' => 50,
            'meta_key' => '_wphave_privacy_request',
            'meta_value' => '1',
            'orderby' => 'date',
            'order' => 'DESC',
        ] );
        $requests = [];

        foreach ( $posts as $post ) {
            $request = wp_get_user_request( $post->ID );

            if ( ! $request ) {
                continue;
            }

            $requests[] = [
                'id' => (int) $request->ID,
                'email' => sanitize_email( $request->email ),
                'type' => $request->action_name === 'remove_personal_data' ? 'erase' : 'export',
                'status' => sanitize_key( $request->status ),
                'createdAt' => ! empty( $request->created_timestamp ) ? gmdate( 'c', (int) $request->created_timestamp ) : '',
                'canProcess' => $request->status === 'request-confirmed',
            ];
        }

		// AUTHORIZATION/PRIVACY-REQUEST-LIST-RESPONSE INVARIANT: Core request
		// hydration and data-subject normalization cross post, metadata and sanitizer
		// extension boundaries. Revalidate capability and Pro entitlement after the
		// complete private projection and immediately before releasing identities.
		$authorization = self::require_manage_access();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

        return rest_ensure_response( [ 'requests' => $requests ] );
    }

    /**
     * Process request.
     *
     * @param WP_REST_Request $request REST request.
     */

    public static function process_request( WP_REST_Request $request ) {
		$authorization = self::require_manage_access();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

        $id = absint( $request->get_param( 'id' ) );
        $data_request = wp_get_user_request( $id );

        if ( ! $data_request || get_post_meta( $id, '_wphave_privacy_request', true ) !== '1' ) {
            return new WP_Error( 'wphave_privacy_request_missing', __( 'This WPHAVE privacy request could not be found.', 'wphave' ), [ 'status' => 404 ] );
        }

        if ( $data_request->status !== 'request-confirmed' ) {
            return new WP_Error( 'wphave_privacy_request_unconfirmed', __( 'The person must confirm this request by email before it can be processed.', 'wphave' ), [ 'status' => 409 ] );
        }

		// AUTHORIZATION/PRIVACY-REQUEST-DISPATCH INVARIANT: Core request hydration
		// and ownership metadata are filterable boundaries. Revalidate capability
		// and Pro entitlement after them and immediately before dispatching any
		// exporter, filesystem, mail or erasure workflow.
		$authorization = self::require_manage_access();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

        if ( $data_request->action_name === 'export_personal_data' ) {
            return self::send_export( $id, $data_request->email );
        }

        if ( $data_request->action_name === 'remove_personal_data' ) {
            return self::erase_data( $id, $data_request->email );
        }

        return new WP_Error( 'wphave_privacy_request_invalid', __( 'This request type is not supported.', 'wphave' ), [ 'status' => 400 ] );
    }

	private static function require_manage_access() {
		// AUTHORIZATION INVARIANT: REST route permission is only an early gate.
		// Every management callback must repeat capability and Pro entitlement
		// before identity disclosure, request creation, mail, export, or erasure.
		if ( self::can_manage() ) {
			return true;
		}

		return new WP_Error(
			'wphave_privacy_request_forbidden',
			__( 'You are not allowed to manage privacy requests.', 'wphave' ),
			[ 'status' => 403 ]
		);
	}

    /**
     * Send export.
     *
     * @param int $id Id.
     * @param string $email Email.
     */

    private static function send_export( int $id, string $email ) {
		$authorization = self::require_manage_access();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

        $items = self::collect_export_items( $email );
		if ( is_wp_error( $items ) ) {
			return $items;
		}

		// AUTHORIZATION/PRIVACY-EXPORT-FILE INVARIANT: Exporter registration and
		// callbacks are extension boundaries. Their completion cannot carry stale
		// authority into creation of an encrypted export or its bearer grant.
		$authorization = self::require_manage_access();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

        $token = wp_generate_password( self::EXPORT_TOKEN_LENGTH, false, false );
        $uploads = wp_upload_dir();
        $directory = trailingslashit( $uploads['basedir'] ) . 'wphave-privacy-exports';

        if ( ! wp_mkdir_p( $directory ) ) {
            return new WP_Error( 'wphave_privacy_export_directory', __( 'The export file could not be created.', 'wphave' ), [ 'status' => 500 ] );
        }

		$filename = 'wphave-personal-data-' . $id . '-' . wp_generate_password( 20, false, false ) . '.wphave';
        $path = trailingslashit( $directory ) . $filename;
        $html = self::build_export_html( $email, $items );
		if ( is_wp_error( $html ) ) {
			return $html;
		}
		$encrypted = WPHAVE_Crypto::encrypt( $html, 'privacy_export' );
		// EXPORT SIZE INVARIANT: A generated link must never point at an
		// encrypted blob too large for the public bounded download path.
		if ( ! is_string( $encrypted ) || strlen( $encrypted ) > self::MAX_ENCRYPTED_EXPORT_BYTES ) {
			return new WP_Error( 'wphave_privacy_export_too_large', __( 'The privacy export exceeds the safe download size.', 'wphave' ), [ 'status' => 413 ] );
		}
		$authorization = self::require_manage_access();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		try {
			// EXPORT PUBLICATION INVARIANT: Private ciphertext is published only
			// after a complete create-only write with owner-only permissions. A
			// partial write or concurrent node cannot acquire a bearer grant.
			WPHAVE_Security_Atomic_File::write_new(
				$path,
				$encrypted,
				__( 'The export file could not be written.', 'wphave' ),
				0600
			);
		} catch (RuntimeException $error) {
			return new WP_Error( 'wphave_privacy_export_write', __( 'The export file could not be written.', 'wphave' ), [ 'status' => 500 ] );
		}

		// SECURITY AND RECOVERY INVARIANT: Encrypted bytes plus filename, bearer
		// hash and expiry form one access grant. A partial metadata write must remove
		// the exact newly created file and every fragment before mail delivery; an
		// incomplete grant is never reported as a completed export.
		$metadata_written = array(
			update_post_meta( $id, '_wphave_privacy_export_file', $filename ),
			update_post_meta( $id, '_wphave_privacy_export_sha256', hash( 'sha256', $encrypted ) ),
			update_post_meta( $id, '_wphave_privacy_export_token', wp_hash( $token ) ),
			update_post_meta( $id, '_wphave_privacy_export_expires', time() + 3 * DAY_IN_SECONDS ),
		);

		if ( in_array( false, $metadata_written, true ) ) {
			try {
				// ROLLBACK INVARIANT: A rejected bearer grant may remove only the
				// ciphertext revision this request created, never a later file at
				// the same path after metadata hooks or concurrent activity.
				WPHAVE_Security_Conditional_File::remove_if_matches(
					$path,
					hash( 'sha256', $encrypted ),
					__( 'Privacy export bytes changed before rollback.', 'wphave' )
				);
			} catch ( RuntimeException $cleanup_error ) {
				// Preserve unproven bytes; the bearer metadata is revoked below.
			}

			delete_post_meta( $id, '_wphave_privacy_export_file' );
			delete_post_meta( $id, '_wphave_privacy_export_sha256' );
			delete_post_meta( $id, '_wphave_privacy_export_token' );
			delete_post_meta( $id, '_wphave_privacy_export_expires' );

			return new WP_Error(
				'wphave_privacy_export_metadata',
				__( 'The export access grant could not be saved. No export was retained.', 'wphave' ),
				[ 'status' => 500 ]
			);
		}

		// AUTHORIZATION/PRIVACY-EXPORT-MAIL INVARIANT: Bearer metadata writes and
		// their hooks cannot authorize an external email. Revocation removes the
		// complete newly-created grant before any download link leaves the site.
		$authorization = self::require_manage_access();
		if ( is_wp_error( $authorization ) ) {
			self::delete_export( $id );

			return $authorization;
		}

        $url = add_query_arg( [ 'token' => rawurlencode( $token ) ], rest_url( self::REST_NAMESPACE . '/privacy/exports/' . $id ) );
        $sent = wp_mail( $email, sprintf( /* translators: %s: contextual value. */
        __( 'Your personal data export from %s', 'wphave' ), wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) ), sprintf( __( "Your export is ready. Download it here:\n%s\n\nThis link expires in three days.", 'wphave' ), $url ) );

		if ( ! $sent ) {
			// SECURITY/DATA-LIFECYCLE INVARIANT: Archive bytes and their bearer grant
			// become durable only when delivery succeeds. A failed notification must
			// roll back both together so retries cannot accumulate undisclosed links.
			self::delete_export( $id );
            return new WP_Error( 'wphave_privacy_export_email', __( 'The export was created, but the email could not be sent.', 'wphave' ), [ 'status' => 500 ] );
		}

		$authorization = self::require_manage_access();
		if ( is_wp_error( $authorization ) ) {
			self::delete_export( $id );

			return $authorization;
		}

		$completed = self::complete_request( $id );
		if( is_wp_error( $completed ) ) {
			// The emailed bearer must not survive a completion state the server could
			// not commit. A retry creates a new bounded grant and the old link stays inert.
			self::delete_export( $id );
			return $completed;
		}

        return rest_ensure_response( [ 'status' => 'completed', 'message' => __( 'The data export was created and sent to the person.', 'wphave' ) ] );
    }

    /**
     * Erase data.
     *
     * @param int $id Id.
     * @param string $email Email.
     */

    private static function erase_data( int $id, string $email ) {
		$authorization = self::require_manage_access();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

        $removed = false;
		$erasers = apply_filters( 'wp_privacy_personal_data_erasers', [] );

		// AUTHORIZATION/PRIVACY-ERASURE-CALLBACK INVARIANT: The eraser registry is
		// filterable and every callback is independently irreversible. Revalidate
		// the live management policy after registry projection and immediately
		// before each page callback; stale dispatch authority is never inherited.
		$authorization = self::require_manage_access();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		foreach ( $erasers as $eraser_id => $eraser ) {
            if ( ! str_starts_with( $eraser_id, 'wphave-' ) || empty( $eraser['callback'] ) || ! is_callable( $eraser['callback'] ) ) {
                continue;
            }

            for ( $page = 1; $page <= 100; $page++ ) {
				$authorization = self::require_manage_access();
				if ( is_wp_error( $authorization ) ) {
					return $authorization;
				}

                $result = call_user_func( $eraser['callback'], $email, $page );
                $removed = $removed || ! empty( $result['items_removed'] );

				$authorization = self::require_manage_access();
				if ( is_wp_error( $authorization ) ) {
					return $authorization;
				}

                if ( ! empty( $result['done'] ) ) {
                    break;
                }
            }
		}

		$authorization = self::require_manage_access();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$completed = self::complete_request( $id );
		if( is_wp_error( $completed ) ) {
			return $completed;
		}

        return rest_ensure_response( [ 'status' => 'completed', 'itemsRemoved' => $removed, 'message' => __( 'The WPHAVE data for this person was erased.', 'wphave' ) ] );
    }

    /**
     * Collect export items.
     *
     * @param string $email Email.
     * @return array Collect export items.
     */

    private static function collect_export_items( string $email ): array|WP_Error {
        $items = [];
		$bytes = 0;

        foreach ( apply_filters( 'wp_privacy_personal_data_exporters', [] ) as $exporter_id => $exporter ) {
            if ( ! str_starts_with( $exporter_id, 'wphave-' ) || empty( $exporter['callback'] ) || ! is_callable( $exporter['callback'] ) ) {
                continue;
            }

            for ( $page = 1; $page <= 100; $page++ ) {
                $result = call_user_func( $exporter['callback'], $email, $page );
				$page_items = is_array( $result['data'] ?? null ) ? $result['data'] : [];
				// EXPORT-COLLECTION INVARIANT: One extension callback cannot amplify a
				// privacy request into unbounded array copies, fields or plaintext.
				if ( count( $page_items ) > self::MAX_EXPORT_ITEMS - count( $items ) ) {
					return self::export_too_large();
				}
				foreach ( $page_items as $item ) {
					if ( ! is_array( $item ) || ! is_array( $item['data'] ?? null ) || count( $item['data'] ) > 100 ) {
						return self::export_too_large();
					}
					$label = $item['group_label'] ?? '';
					if ( ! is_string( $label ) || strlen( $label ) > self::MAX_EXPORT_FIELD_BYTES ) {
						return self::export_too_large();
					}
					$bytes += strlen( $label );
					foreach ( $item['data'] as $field ) {
						if ( ! is_array( $field ) ) {
							return self::export_too_large();
						}
						foreach ( [ 'name', 'value' ] as $key ) {
							$value = $field[$key] ?? '';
							if ( ! is_scalar( $value ) || strlen( (string) $value ) > self::MAX_EXPORT_FIELD_BYTES ) {
								return self::export_too_large();
							}
							$bytes += strlen( (string) $value );
						}
					}
					if ( $bytes > self::MAX_EXPORT_PLAINTEXT_BYTES ) {
						return self::export_too_large();
					}
					$items[] = $item;
				}

                if ( ! empty( $result['done'] ) ) {
                    break;
                }
            }
        }

        return $items;
    }

    /**
     * Build export HTML.
     *
     * @param string $email Email.
     * @param array $items Items.
     * @return string Build export HTML.
     */

    private static function build_export_html( string $email, array $items ): string|WP_Error {
        $content = '<!doctype html><html><head><meta charset="utf-8"><title>' . esc_html__( 'Personal data export', 'wphave' ) . '</title></head><body><h1>' . esc_html__( 'Personal data export', 'wphave' ) . '</h1><p>' . esc_html( $email ) . '</p>';

        foreach ( $items as $item ) {
            $content .= '<h2>' . esc_html( $item['group_label'] ?? '' ) . '</h2><table>';

            foreach ( $item['data'] ?? [] as $field ) {
                $content .= '<tr><th>' . esc_html( $field['name'] ?? '' ) . '</th><td>' . esc_html( $field['value'] ?? '' ) . '</td></tr>';
				// Each escaped field is bounded before another one can amplify it.
				if ( strlen( $content ) > self::MAX_EXPORT_PLAINTEXT_BYTES ) {
					return self::export_too_large();
				}
            }

            $content .= '</table>';
			// EXPORT-OUTPUT INVARIANT: Escaping expands data. Bound the actual HTML
			// before encryption rather than trusting the input-byte estimate alone.
			if ( strlen( $content ) > self::MAX_EXPORT_PLAINTEXT_BYTES ) {
				return self::export_too_large();
			}
        }

		$content .= '</body></html>';
		return strlen( $content ) <= self::MAX_EXPORT_PLAINTEXT_BYTES
			? $content
			: self::export_too_large();
    }

	private static function export_too_large(): WP_Error {
		return new WP_Error(
			'wphave_privacy_export_too_large',
			__( 'The privacy export exceeds the safe size limit.', 'wphave' ),
			[ 'status' => 413 ]
		);
	}

    /**
     * Complete request.
     *
     * @param int $id Id.
     * @return true|WP_Error
     */

    private static function complete_request( int $id ) {
		$previous_status = get_post_status( $id );
		$processed_meta_existed = metadata_exists( 'post', $id, '_wphave_privacy_processed_at' );
		$previous_processed_at = get_post_meta( $id, '_wphave_privacy_processed_at', true );

		// PRIVACY/COMMIT INVARIANT: A completed response requires the exact Core
		// request status and processing marker to be durable as one projection. An
		// irreversible erasure or an emailed export must never be described as
		// completed while the canonical request remains retryable.
		$updated = wp_update_post(
			[ 'ID' => $id, 'post_status' => 'request-completed' ],
			true
		);
		if( is_wp_error( $updated ) || 'request-completed' !== get_post_status( $id ) ) {
			return new WP_Error(
				'wphave_privacy_request_completion_failed',
				__( 'The privacy request completion state could not be saved.', 'wphave' ),
				[ 'status' => 500 ]
			);
		}

		$processed_at = time();
		update_post_meta( $id, '_wphave_privacy_processed_at', $processed_at );
		if( $processed_at !== (int) get_post_meta( $id, '_wphave_privacy_processed_at', true ) ) {
			wp_update_post( [ 'ID' => $id, 'post_status' => $previous_status ] );
			if( $processed_meta_existed ) {
				update_post_meta( $id, '_wphave_privacy_processed_at', $previous_processed_at );
			} else {
				delete_post_meta( $id, '_wphave_privacy_processed_at' );
			}

			return new WP_Error(
				'wphave_privacy_request_completion_failed',
				__( 'The privacy request completion state could not be saved.', 'wphave' ),
				[ 'status' => 500 ]
			);
		}

		return true;
    }

	/**
	 * Schedules daily cleanup for expired encrypted exports.
	 *
	 * @return void
	 */

	public static function schedule_export_cleanup(): void {
		// DATA-MINIMIZATION INVARIANT: Export retention must have exactly one
		// fixed-duration daily owner. Reconcile drift and duplicate legacy events
		// instead of accepting a schedule that may silently stop deleting archives.
		WPHAVE_Background_Job_Scheduler::sync_recurring(
			self::EXPORT_CLEANUP_HOOK,
			self::EXPORT_CLEANUP_SCHEDULE_OPTION,
			true,
			'daily',
			time() + HOUR_IN_SECONDS,
			'privacy-export-cleanup-v1'
		);
	}

	/**
	 * Deletes expired export files and their access metadata.
	 *
	 * @return void
	 */

	public static function cleanup_expired_exports(): void {
		$request_ids = get_posts( [
			'post_type' => 'user_request',
			// RETENTION INVARIANT: WordPress `any` excludes Trash. Moving a
			// request there must not suspend expiry of its encrypted export.
			'post_status' => [
				'request-pending',
				'request-confirmed',
				'request-failed',
				'request-completed',
				'trash',
			],
			'posts_per_page' => 100,
			'fields' => 'ids',
			'meta_query' => [
				'relation' => 'AND',
				[
					'key' => '_wphave_privacy_export_expires',
					'value' => time(),
					'compare' => '<=',
					'type' => 'NUMERIC',
				],
				[
					'relation' => 'OR',
					[ 'key' => self::EXPORT_CLEANUP_RETRY_META, 'compare' => 'NOT EXISTS' ],
					[
						'key' => self::EXPORT_CLEANUP_RETRY_META,
						'value' => time(),
						'compare' => '<=',
						'type' => 'NUMERIC',
					],
				],
			],
		] );

		foreach( $request_ids as $request_id ) {
			self::delete_export( (int) $request_id );
		}

		// RETENTION INVARIANT: The bounded 100-request batch is a work limit,
		// not a daily deletion quota. A full batch schedules a distinct near-term
		// continuation until the expired backlog has drained.
		if ( count( $request_ids ) === 100 ) {
			WPHAVE_Background_Job_Scheduler::ensure_continuation(
				self::EXPORT_CLEANUP_HOOK,
				['continue'],
				MINUTE_IN_SECONDS
			);
		}
	}

	/**
	 * Revoke and remove an export while its request metadata is still available.
	 *
	 * @param int     $id Request id.
	 * @param WP_Post $post Post being permanently deleted.
	 * @return void
	 */
	public static function cleanup_deleted_request_export( int $id, WP_Post $post ): void {
		// RETENTION INVARIANT: A deleted request cannot be found by the daily
		// expiry query. Remove its bound ciphertext before WordPress erases the
		// metadata needed to locate and authenticate that file.
		if ( 'user_request' === $post->post_type ) {
			self::delete_export( $id );
		}
	}

	/**
	 * Deletes one export file and its private access metadata.
	 *
	 * @param int $id Request id.
	 * @return void
	 */

	private static function delete_export( int $id ): void {
		$filename = sanitize_file_name( get_post_meta( $id, '_wphave_privacy_export_file', true ) );
		$checksum = (string) get_post_meta( $id, '_wphave_privacy_export_sha256', true );
		$removed = ! $filename;

		if( $filename && preg_match( '/^[a-f0-9]{64}$/D', $checksum ) ) {
			$uploads = wp_upload_dir();
			$path = trailingslashit( $uploads['basedir'] ) . 'wphave-privacy-exports/' . $filename;

			try {
				// RETENTION INVARIANT: Revoke the bearer below regardless of file
				// state, but delete only the ciphertext bound to this exact grant.
				WPHAVE_Security_Conditional_File::remove_if_matches(
					$path,
					$checksum,
					__( 'Privacy export bytes changed before deletion.', 'wphave' )
				);
				$removed = true;
			} catch ( Throwable $error ) {
				// Preserve unproven bytes for explicit operator reconciliation.
			}
		}

		// RETENTION/RECOVERY INVARIANT: A failed conditional removal revokes the
		// bearer immediately, but its filename and expected digest remain available
		// for a later authenticated retry. Postpone it so one stubborn file cannot
		// monopolize the bounded expiry batch.
		delete_post_meta( $id, '_wphave_privacy_export_token' );
		if ( ! $removed ) {
			if ( ! get_post_meta( $id, '_wphave_privacy_export_expires', true ) ) {
				update_post_meta( $id, '_wphave_privacy_export_expires', time() );
			}
			update_post_meta( $id, self::EXPORT_CLEANUP_RETRY_META, time() + HOUR_IN_SECONDS );
			return;
		}

		delete_post_meta( $id, '_wphave_privacy_export_file' );
		delete_post_meta( $id, '_wphave_privacy_export_sha256' );
		delete_post_meta( $id, '_wphave_privacy_export_expires' );
		delete_post_meta( $id, self::EXPORT_CLEANUP_RETRY_META );
	}

    /**
     * Download export.
     *
     * @param WP_REST_Request $request REST request.
     */

    public static function download_export( WP_REST_Request $request ) {
        $id = absint( $request->get_param( 'id' ) );
		$raw_token = $request->get_param( 'token' );

		// BEARER/AVAILABILITY INVARIANT: Export authority has one exact generated
		// token shape. Reject malformed grants before their object ID can cause any
		// metadata lookup or their attacker-controlled bytes can enter password hashing.
		if (
			! $id
			|| ! is_string( $raw_token )
			|| 1 !== preg_match( '/^[A-Za-z0-9]{' . self::EXPORT_TOKEN_LENGTH . '}$/D', $raw_token )
		) {
			return new WP_Error( 'wphave_privacy_export_unavailable', __( 'This export link is no longer available.', 'wphave' ), [ 'status' => 404 ] );
		}

		$token = $raw_token;
		// PUBLIC-LOOKUP INVARIANT: Syntactically valid bearer guesses must spend
		// a network-bound budget before attacker-chosen IDs reach private metadata.
		// The ID and token are claims and may not create fresh rate-limit buckets.
		if (
			WPHAVE_Rate_Limiter::increment(
				WPHAVE_Rate_Limiter::client_key( 'privacy-export' ),
				HOUR_IN_SECONDS
			) > self::EXPORT_LOOKUP_ATTEMPT_LIMIT
		) {
			return new WP_Error( 'wphave_privacy_export_rate_limited', __( 'Too many export link attempts. Please try again later.', 'wphave' ), [ 'status' => 429 ] );
		}
        $hash = get_post_meta( $id, '_wphave_privacy_export_token', true );
        $expires = (int) get_post_meta( $id, '_wphave_privacy_export_expires', true );
        $stored_filename = (string) get_post_meta( $id, '_wphave_privacy_export_file', true );
        $stored_checksum = (string) get_post_meta( $id, '_wphave_privacy_export_sha256', true );
        $filename = sanitize_file_name( $stored_filename );

		// SECURITY/BEARER INVARIANT: No request-specific metadata or bytes may be
		// deleted before the bearer token proves authority over this exact export.
		// Expiry is retention state, not anonymous mutation authority.
		// Read-time sanitization must also not repair mutated path metadata into a
		// filename that is then accepted at the filesystem boundary.
		if ( ! $hash || ! hash_equals( $hash, wp_hash( $token ) ) || ! $filename || $stored_filename !== $filename || ! preg_match( '/^[a-f0-9]{64}$/D', $stored_checksum ) ) {
            return new WP_Error( 'wphave_privacy_export_unavailable', __( 'This export link is no longer available.', 'wphave' ), [ 'status' => 404 ] );
        }

		// SECURITY INVARIANT: Token, future expiry, and canonical filename are one
		// access grant. Missing metadata must never widen a time-limited grant.
		if ( $expires <= time() ) {
			self::delete_export( $id );
			return new WP_Error( 'wphave_privacy_export_unavailable', __( 'This export link is no longer available.', 'wphave' ), [ 'status' => 404 ] );
		}

        $uploads = wp_upload_dir();
        $path = trailingslashit( $uploads['basedir'] ) . 'wphave-privacy-exports/' . $filename;

        if ( ! is_readable( $path ) ) {
            return new WP_Error( 'wphave_privacy_export_missing', __( 'The export file could not be found.', 'wphave' ), [ 'status' => 404 ] );
        }

		try {
			// PUBLIC EXPORT MEMORY INVARIANT: A valid bearer does not authorize
			// loading arbitrary-sized, replaced or linked bytes into a PHP worker.
			$observation = WPHAVE_Security_File_Identity::read_bounded(
				$path,
				self::MAX_ENCRYPTED_EXPORT_BYTES + 1,
				false,
				__( 'The export file could not be read safely.', 'wphave' )
			);
		} catch ( RuntimeException $error ) {
			return new WP_Error( 'wphave_privacy_export_invalid', __( 'The export file could not be read safely.', 'wphave' ), [ 'status' => 500 ] );
		}
		if ( $observation['truncated'] || $observation['sizeBytes'] > self::MAX_ENCRYPTED_EXPORT_BYTES ) {
			return new WP_Error( 'wphave_privacy_export_too_large', __( 'The export file is too large to download safely.', 'wphave' ), [ 'status' => 413 ] );
		}
		// BEARER-BINDING INVARIANT: A valid token authorizes the ciphertext
		// created for this request, not any other encrypted file swapped into
		// the same filename after grant publication.
		if ( ! hash_equals( $stored_checksum, hash( 'sha256', $observation['content'] ) ) ) {
			return new WP_Error( 'wphave_privacy_export_invalid', __( 'The export file changed after the link was created.', 'wphave' ), [ 'status' => 500 ] );
		}
		$html = WPHAVE_Crypto::decrypt( $observation['content'], 'privacy_export' );

		// SECURITY INVARIANT: A valid bearer grant authorizes only an encrypted
		// WPHAVE export. A plaintext or corrupted file must never become downloadable,
		// even when its metadata and token are otherwise valid.
		if( ! is_string( $html ) ) {
			return new WP_Error( 'wphave_privacy_export_invalid', __( 'The export file could not be decrypted.', 'wphave' ), [ 'status' => 500 ] );
		}

		$response = new WP_REST_Response( $html );
        $response->header( 'Content-Type', 'text/html; charset=utf-8' );
        $response->header( 'Content-Disposition', 'attachment; filename="personal-data-export.html"' );
		$response->header( 'Cache-Control', 'private, no-store, max-age=0' );
		$response->header( 'Pragma', 'no-cache' );
		$response->header( 'X-Content-Type-Options', 'nosniff' );
        return $response;
    }
}

WPHAVE_Privacy_Request_Manager::init();
