<?php

require_once wphave_dir() . 'inc/features/security/email-identity.php';

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Privacy_Scanner_Workflow {
	/**
	 * Start scan job.
	 *
	 * @param int $limit Limit.
	 * @param bool $scheduled Scheduled.
	 * @param callable|null $commit_guard Optional request-context authorization guard.
	 * @return array|WP_Error Start scan job.
	 */

	protected static function start_scan_job(
		int $limit = self::DEFAULT_LIMIT,
		bool $scheduled = false,
		?callable $commit_guard = null,
	) {
		$lock = self::acquire_scan_lock();

		if (!$lock) {
			return self::get_status();
		}

		try {
			return self::start_scan_job_unlocked($limit, $scheduled, $commit_guard);
		} finally {
			self::release_scan_lock($lock);
		}
	}

	/**
	 * Start a scan while holding the shared job-state lock.
	 *
	 * @param int $limit Limit.
	 * @param bool $scheduled Scheduled.
	 * @param callable|null $commit_guard Optional request-context authorization guard.
	 * @return array|WP_Error Start scan job.
	 */

	protected static function start_scan_job_unlocked(
		int $limit,
		bool $scheduled,
		?callable $commit_guard = null,
	) {
		if (get_option(self::JOB_OPTION, [])) {
			return self::get_status();
		}

		$limit = max(1, min(self::MAX_LIMIT, $limit ?: self::DEFAULT_LIMIT));
		$started_at = current_time('mysql');
		$urls = self::discover_urls($limit);

		if ($commit_guard) {
			// AUTHORIZATION/PRIVACY-SCAN-START-COMMIT INVARIANT: URL discovery
			// crosses query, permalink and normalization extension boundaries. A REST
			// caller must retain the canonical Privacy policy after the complete
			// candidate projection and immediately before the first durable job write.
			// Cron omits this request-only guard and retains its separate ownership.
			$authorization = call_user_func($commit_guard);

			if (is_wp_error($authorization)) {
				return $authorization;
			}
		}

		$job = [
			'startedAt' => $started_at,
			'scheduled' => $scheduled,
			'urls' => $urls,
			'processed' => 0,
			'services' => [],
			'errors' => [],
		];

		update_option(self::JOB_OPTION, $job, false);
		update_option(
			self::RESULTS_OPTION,
			[
				'startedAt' => $started_at,
				'finishedAt' => '',
				'scheduled' => $scheduled,
				'processed' => 0,
				'total' => count($urls),
				'servicesFound' => 0,
				'services' => [],
				'errors' => [],
			],
			false,
		);

		$status = [
			'state' => 'running',
			'startedAt' => $started_at,
			'finishedAt' => '',
			'scheduled' => $scheduled,
			'processed' => 0,
			'total' => count($urls),
			'servicesFound' => 0,
			'errors' => [],
		];

		self::set_status($status);
		if (class_exists('WPHAVE_Activity_Log')) {
			WPHAVE_Activity_Log::record('privacy_scan.started', [
				'category' => 'system',
				'action' => 'started',
				'actor_type' => $scheduled ? 'cron' : null,
				'object_type' => 'scan',
				'object_label' => 'Privacy scan',
				'context' => ['total' => count($urls), 'scheduled' => $scheduled],
			]);
		}

		return $status;
	}

	/**
	 * Return scan settings.
	 *
	 * @return array Return scan settings.
	 */

	protected static function get_scan_settings(): array {
		$settings = function_exists('wphave_data_get')
			? wphave_data_get('privacy_settings', 'consent.scan', [])
			: [];
		$settings = is_array($settings) ? $settings : [];
		$frequency = sanitize_key($settings['frequency'] ?? 'weekly');

		if (!in_array($frequency, ['daily', 'weekly', 'monthly'], true)) {
			$frequency = 'weekly';
		}

		$time_window = sanitize_key($settings['time_window'] ?? 'night');

		if (!in_array($time_window, ['night', 'morning', 'afternoon', 'evening'], true)) {
			$time_window = 'night';
		}

		// SCAN-NOTIFICATION INVARIANT: Public-page findings leave the site only
		// for an exact configured or WordPress admin mailbox.
		$email = WPHAVE_Email_Identity::exact($settings['email'] ?? '');

		return [
			'auto_enabled' => !empty($settings['auto_enabled']),
			'frequency' => $frequency,
			'time_window' => $time_window,
			'email' => $email ?: WPHAVE_Email_Identity::exact(get_option('admin_email')),
		];
	}

	/**
	 * Return status.
	 *
	 * @return array Return status.
	 */

	public static function get_status(): array {
		$status = get_option(self::STATUS_OPTION, []);

		if (!is_array($status)) {
			$status = [];
		}

		$status = wp_parse_args($status, [
			'state' => 'idle',
			'startedAt' => '',
			'finishedAt' => '',
			'scheduled' => false,
			'processed' => 0,
			'total' => 0,
			'servicesFound' => 0,
			'errors' => [],
		]);

		$status = self::normalize_status($status);
		$status['automation'] = self::get_automation_status();

		return $status;
	}

	/**
	 * Return results.
	 *
	 * @return array Return results.
	 */

	public static function get_results(): array {
		$results = get_option(self::RESULTS_OPTION, []);

		if (!is_array($results)) {
			$results = [];
		}

		$results = wp_parse_args($results, [
			'startedAt' => '',
			'finishedAt' => '',
			'scheduled' => false,
			'processed' => 0,
			'total' => 0,
			'servicesFound' => 0,
			'services' => [],
			'errors' => [],
		]);

		$results['services'] = array_values(
			array_filter(is_array($results['services']) ? $results['services'] : [], function (
				$service,
			) {
				$domain = is_array($service)
					? self::normalize_domain($service['domain'] ?? '')
					: '';
				return $domain && !self::is_ignored_domain($domain);
			}),
		);

		$results['servicesFound'] = count($results['services']);

		return $results;
	}

	/**
	 * Set status.
	 *
	 * @param array $status Status.
	 * @return void
	 */

	protected static function set_status(array $status): void {
		update_option(self::STATUS_OPTION, self::normalize_status($status), false);
	}

	/**
	 * Normalize status.
	 *
	 * @param array $status Status.
	 * @return array Normalize status.
	 */

	protected static function normalize_status(array $status): array {
		$processed = absint($status['processed'] ?? 0);
		$total = absint($status['total'] ?? 0);
		$state = sanitize_key($status['state'] ?? 'idle');

		if ($state === 'complete' && $total > 0 && $processed < $total) {
			$status['state'] = 'partial';
		}

		if ($state === 'running' && !get_option(self::JOB_OPTION, [])) {
			$status['state'] = $total > 0 && $processed >= $total ? 'complete' : 'partial';
		}

		return $status;
	}

	/**
	 * Process scan batch.
	 *
	 * @param callable|null $commit_guard Optional request-context authorization guard.
	 * @return array|WP_Error Process scan batch.
	 */

	protected static function process_scan_batch(?callable $commit_guard = null) {
		$lock = self::acquire_scan_lock();

		if (!$lock) {
			return self::get_status();
		}

		try {
			return self::process_scan_batch_unlocked($commit_guard);
		} finally {
			self::release_scan_lock($lock);
		}
	}

	/**
	 * Process one scan batch while holding the scan lock.
	 *
	 * @param callable|null $commit_guard Optional request-context authorization guard.
	 * @return array|WP_Error Process scan batch.
	 */

	protected static function process_scan_batch_unlocked(?callable $commit_guard = null) {
		$job = get_option(self::JOB_OPTION, []);

		if (!is_array($job) || empty($job['urls']) || !isset($job['processed'])) {
			return self::get_status();
		}

		$urls = array_values($job['urls']);
		$services = is_array($job['services'] ?? null) ? $job['services'] : [];
		$errors = self::normalize_privacy_scan_errors(
			is_array($job['errors'] ?? null) ? $job['errors'] : [],
		);
		$processed = absint($job['processed']);
		$started_at = sanitize_text_field($job['startedAt'] ?? current_time('mysql'));
		$scheduled = !empty($job['scheduled']);
		$total = count($urls);
		$batch_end = min($total, $processed + self::BATCH_SIZE);

		if ($commit_guard) {
			// AUTHORIZATION/PRIVACY-SCAN-PROCESS INVARIANT: A stored manual job is
			// data, not continuing request authority. Revalidate the REST caller after
			// complete job projection and before any server-side request can execute.
			// Scheduled workers omit this guard and retain their Cron ownership checks.
			$authorization = call_user_func($commit_guard);

			if (is_wp_error($authorization)) {
				return $authorization;
			}
		}

		for ($index = $processed; $index < $batch_end; $index++) {
			$url = $urls[$index];

			if (!self::is_same_site_scan_url($url)) {
				$processed++;
				$errors[] = [
					'url' => WPHAVE_Security_Normalizer::diagnostic_url($url),
					'message' => __('Skipped a scan URL outside the current site.', 'wphave'),
				];
				continue;
			}

			// TRANSPORT INVARIANT: Scanner classification receives only a complete,
			// bounded response from the already validated site URL. The extra byte is
			// an overflow sentinel and must never reach service detection.
			if ($commit_guard) {
				$authorization = call_user_func($commit_guard);

				if (is_wp_error($authorization)) {
					return $authorization;
				}
			}

			$response = wp_safe_remote_get(WPHAVE_Privacy_Public_Scan::request_url($url), [
				'cookies' => [],
				'timeout' => 8,
				'redirection' => 0,
				'sslverify' => true,
				'limit_response_size' => self::MAX_RESPONSE_BYTES + 1,
				'user-agent' =>
					'WPHAVE Privacy Scanner/' .
					(defined('WPHAVE_VERSION') ? WPHAVE_VERSION : '1.0') .
					'; ' .
					home_url('/'),
				'headers' => [
					'Accept' => 'text/html,application/xhtml+xml',
					'Cookie' => '',
					'Authorization' => '',
				],
			]);

			$processed++;

			if (is_wp_error($response)) {
				$errors[] = [
					'url' => WPHAVE_Security_Normalizer::diagnostic_url($url),
					'message' => WPHAVE_Security_Redactor::error_text(
						$response->get_error_message(),
					),
				];
				continue;
			}

			$code = (int) wp_remote_retrieve_response_code($response);

			if ($code < 200 || $code >= 400) {
				$errors[] = [
					'url' => $url,
					'message' => sprintf('HTTP %d', $code),
				];
				continue;
			}

			$content_type = (string) wp_remote_retrieve_header($response, 'content-type');

			if (
				$content_type &&
				stripos($content_type, 'text/html') === false &&
				stripos($content_type, 'application/xhtml+xml') === false
			) {
				continue;
			}

			$html = wp_remote_retrieve_body($response);

			if (!is_string($html) || $html === '' || strlen($html) > self::MAX_RESPONSE_BYTES) {
				if (is_string($html) && strlen($html) > self::MAX_RESPONSE_BYTES) {
					$errors[] = [
						'url' => WPHAVE_Security_Normalizer::diagnostic_url($url),
						'message' => __(
							'The page exceeded the Privacy Scanner response limit and was not analyzed.',
							'wphave',
						),
					];
				}
				continue;
			}

			if (!WPHAVE_Privacy_Public_Scan::is_public_response($response, $html)) {
				$errors[] = [
					'url' => WPHAVE_Security_Normalizer::diagnostic_url($url),
					'message' => __(
						'The page did not confirm an anonymous scan response and was not analyzed.',
						'wphave',
					),
				];
				continue;
			}
			self::scan_html($html, $url, $services);
		}

		// SECURITY INVARIANT: Operational scan URLs may contain credentials or
		// personal data in their query string. Every error projection must cross
		// the diagnostic normalization boundary before any option is persisted.
		$errors = self::normalize_privacy_scan_errors($errors);

		$is_complete = $processed >= $total;
		$results = [
			'startedAt' => $started_at,
			'finishedAt' => $is_complete ? current_time('mysql') : '',
			'scheduled' => $scheduled,
			'processed' => $processed,
			'total' => $total,
			'servicesFound' => count($services),
			'services' => array_values($services),
			'errors' => $errors,
		];

		if ($commit_guard) {
			// AUTHORIZATION/PRIVACY-SCAN-PROCESS-COMMIT INVARIANT: HTTP transports,
			// response parsers and service classifiers execute extension code. A manual
			// request must retain Privacy authority immediately before publishing the
			// first result, job-progress or status mutation.
			$authorization = call_user_func($commit_guard);

			if (is_wp_error($authorization)) {
				return $authorization;
			}
		}

		update_option(self::RESULTS_OPTION, $results, false);

		if ($is_complete) {
			delete_option(self::JOB_OPTION);
			if (class_exists('WPHAVE_Activity_Log')) {
				WPHAVE_Activity_Log::record('privacy_scan.completed', [
					'category' => 'system',
					'action' => 'completed',
					'actor_type' => $scheduled ? 'cron' : null,
					'object_type' => 'scan',
					'object_label' => 'Privacy scan',
					'context' => [
						'processed' => $processed,
						'services_found' => count($services),
						'errors' => count($errors),
						'scheduled' => $scheduled,
					],
				]);
			}
		} else {
			$job['processed'] = $processed;
			$job['services'] = $services;
			$job['errors'] = $errors;
			update_option(self::JOB_OPTION, $job, false);
		}

		$status = [
			'state' => $is_complete ? 'complete' : 'running',
			'startedAt' => $started_at,
			'finishedAt' => $results['finishedAt'],
			'scheduled' => $scheduled,
			'processed' => $processed,
			'total' => $total,
			'servicesFound' => count($services),
			'errors' => $errors,
		];

		self::set_status($status);

		return $status;
	}

	/**
	 * Normalize persisted scanner failures without changing operational scan URLs.
	 */
	private static function normalize_privacy_scan_errors(array $errors): array {
		$normalized = [];

		foreach (array_slice($errors, 0, 100) as $error) {
			if (!is_array($error)) {
				continue;
			}

			$normalized[] = [
				'url' => WPHAVE_Security_Normalizer::diagnostic_url($error['url'] ?? ''),
				'message' => WPHAVE_Security_Redactor::error_text($error['message'] ?? ''),
			];
		}

		return $normalized;
	}

	/**
	 * Acquire an atomic, short-lived lock for scanner batch processing.
	 *
	 * @return string|false Lock token or false when another worker owns it.
	 */

	protected static function acquire_scan_lock() {
		return WPHAVE_Background_Job_Lock::acquire(self::LOCK_OPTION, MINUTE_IN_SECONDS);
	}

	/**
	 * Release a scanner lock only when it is still owned by this worker.
	 *
	 * @param string $token Lock token.
	 * @return void
	 */

	protected static function release_scan_lock(string $token): void {
		// SECURITY INVARIANT: A timed-out scanner may resume after another worker
		// has acquired the lease; stale cleanup therefore removes only its own token.
		WPHAVE_Background_Job_Lock::release(self::LOCK_OPTION, $token);
	}

	/**
	 * Determine whether a discovered URL belongs to the current site origin.
	 *
	 * @param string $url Scan URL.
	 * @return bool Whether the URL may be requested.
	 */

	protected static function is_same_site_scan_url(string $url): bool {
		$target = wp_parse_url($url);
		$site = wp_parse_url(home_url('/'));

		if (
			!is_array($target) ||
			!is_array($site) ||
			empty($target['host']) ||
			empty($site['host'])
		) {
			return false;
		}

		$target_scheme = strtolower((string) ($target['scheme'] ?? ''));
		$site_scheme = strtolower((string) ($site['scheme'] ?? ''));
		$target_port = absint($target['port'] ?? ($target_scheme === 'https' ? 443 : 80));
		$site_port = absint($site['port'] ?? ($site_scheme === 'https' ? 443 : 80));

		// SECURITY INVARIANT: Discovered links are request candidates, not SSRF
		// authority. They must not carry URL credentials, and scheme, host and
		// effective port must match the configured site origin before the scanner
		// may fetch a URL.
		return in_array($target_scheme, ['http', 'https'], true) &&
			empty($target['user']) &&
			empty($target['pass']) &&
			$target_scheme === $site_scheme &&
			strtolower($target['host']) === strtolower($site['host']) &&
			$target_port === $site_port;
	}

	/**
	 * Maybe send scan notification.
	 *
	 * @param array $results Results.
	 * @param array $settings Feature settings.
	 * @return void
	 */

	protected static function maybe_send_scan_notification(array $results, array $settings): void {
		$findings = self::get_actionable_findings($results);
		$hashes = self::get_finding_hashes($findings);
		$previous_hashes = get_option(self::NOTIFIED_OPTION, []);
		$previous_hashes = is_array($previous_hashes) ? $previous_hashes : [];
		$new_hashes = array_diff($hashes, $previous_hashes);

		if (empty($new_hashes)) {
			update_option(self::NOTIFIED_OPTION, $hashes, false);
			return;
		}

		if (empty($findings) || empty($settings['email'])) {
			return;
		}

		$new_findings = array_values(
			array_filter($findings, function ($finding) use ($new_hashes) {
				return in_array(self::get_finding_hash($finding), $new_hashes, true);
			}),
		);

		if (empty($new_findings)) {
			return;
		}

		$subject = sprintf(
			/* translators: %s: site name. */
			__('[%s] Privacy scan found services to review', 'wphave'),
			wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES),
		);

		$content =
			'<p><strong>' .
			esc_html(
				sprintf(
					/* translators: %d: number of new findings. */
					__('New findings: %d', 'wphave'),
					count($new_findings),
				),
			) .
			'</strong><br>' .
			esc_html(
				sprintf(
					/* translators: 1: processed pages, 2: total pages. */
					__('Pages scanned: %1$d/%2$d', 'wphave'),
					absint($results['processed'] ?? 0),
					absint($results['total'] ?? 0),
				),
			) .
			'</p><ul style="margin: 0; padding-left: 20px;">';

		foreach ($new_findings as $finding) {
			$type =
				$finding['resourceType'] === 'sensitive'
					? __('privacy-relevant service', 'wphave')
					: __('unassigned consent service', 'wphave');
			$content .=
				'<li><strong>' .
				esc_html($finding['domain']) .
				'</strong> (' .
				esc_html($type) .
				')</li>';
		}

		$content .= '</ul>';
		$content .=
			'<p>' .
			esc_html__(
				'Open the WPHAVE Privacy settings to assign consent categories or review sensitive services.',
				'wphave',
			) .
			'</p>';

		$message = wphave_build_email_template([
			'title' => __('Privacy scan findings', 'wphave'),
			'description' => sprintf(
				/* translators: %s: site URL. */
				__(
					'The automatic privacy scan for %s found services that should be reviewed.',
					'wphave',
				),
				esc_html(home_url('/')),
			),
			'content' => $content,
			'footer_content' => esc_html__(
				'This notification was generated automatically by WPHAVE Privacy.',
				'wphave',
			),
		]);

		if (wp_mail($settings['email'], $subject, $message, wphave_email_template_headers())) {
			update_option(self::NOTIFIED_OPTION, $hashes, false);
		}
	}

	/**
	 * Return actionable findings.
	 *
	 * @param array $results Results.
	 * @return array Return actionable findings.
	 */

	protected static function get_actionable_findings(array $results): array {
		$services = is_array($results['services'] ?? null) ? $results['services'] : [];

		return array_values(
			array_filter($services, function ($service) {
				$resource_type = sanitize_key($service['resourceType'] ?? 'consent');
				$category = sanitize_key($service['category'] ?? '');

				return $resource_type === 'sensitive' ||
					($resource_type === 'consent' && empty($category));
			}),
		);
	}

	/**
	 * Return finding hashes.
	 *
	 * @param array $findings Findings.
	 * @return array Return finding hashes.
	 */

	protected static function get_finding_hashes(array $findings): array {
		return array_values(array_unique(array_map([__CLASS__, 'get_finding_hash'], $findings)));
	}

	/**
	 * Return finding hash.
	 *
	 * @param array $finding Finding.
	 * @return string Return finding hash.
	 */

	protected static function get_finding_hash(array $finding): string {
		return md5(
			self::normalize_domain($finding['domain'] ?? '') .
				'|' .
				sanitize_key($finding['resourceType'] ?? 'consent'),
		);
	}

	/**
	 * Discover urls.
	 *
	 * @param int $limit Limit.
	 * @return array Discover urls.
	 */

	protected static function discover_urls(int $limit): array {
		$urls = [home_url('/')];

		$post_types = get_post_types(['public' => true], 'names');
		$post_types = array_values(
			array_filter($post_types, function ($post_type) {
				return !in_array($post_type, ['attachment'], true);
			}),
		);

		if ($post_types) {
			$posts = get_posts([
				'post_type' => $post_types,
				'post_status' => 'publish',
				'posts_per_page' => max(0, $limit - 1),
				'orderby' => 'modified',
				'order' => 'DESC',
				'fields' => 'ids',
				'no_found_rows' => true,
			]);

			foreach ($posts as $post_id) {
				$permalink = get_permalink($post_id);

				if ($permalink) {
					$urls[] = $permalink;
				}
			}
		}

		$urls = array_values(
			array_unique(array_filter(array_map([__CLASS__, 'normalize_url'], $urls))),
		);

		return array_slice($urls, 0, $limit);
	}

	/**
	 * Add service entry.
	 *
	 * @param array $services Services.
	 * @param string $domain Domain.
	 * @param string $url Resource URL.
	 * @param string $source Source.
	 * @param string $source_page Source page.
	 * @param array $classification Classification.
	 * @return void
	 */

	protected static function add_service_entry(
		array &$services,
		string $domain,
		string $url,
		string $source,
		string $source_page,
		array $classification,
	): void {
		$saved_category = self::get_saved_category($domain);
		$key = $domain;

		if (!isset($services[$key])) {
			$services[$key] = [
				'domain' => $domain,
				'category' => $saved_category,
				'suggested' => $classification['suggested'] ?? null,
				'confidence' => $classification['confidence'] ?? 'low',
				'active' => true,
				'sources' => [],
				'urls' => [],
				'pages' => [],
				'resourceType' => $classification['resourceType'] ?? 'consent',
				'detectedBy' => 'scan',
			];
		}

		if ($saved_category && empty($services[$key]['category'])) {
			$services[$key]['category'] = $saved_category;
		}

		if (!in_array($source, $services[$key]['sources'], true)) {
			$services[$key]['sources'][] = $source;
		}

		if (
			$url &&
			count($services[$key]['urls']) < 25 &&
			!in_array($url, $services[$key]['urls'], true)
		) {
			$services[$key]['urls'][] = $url;
		}

		if (
			count($services[$key]['pages']) < 25 &&
			!in_array($source_page, $services[$key]['pages'], true)
		) {
			$services[$key]['pages'][] = $source_page;
		}
	}
}
