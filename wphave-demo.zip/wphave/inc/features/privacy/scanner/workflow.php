<?php

require_once wphave_dir() . 'inc/features/security/email-identity.php';

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Privacy_Scanner_Workflow {
	/**
	 * Start scan job.
	 *
	 * @param int $limit Limit.
	 * @param bool $scheduled Scheduled.
	 * @param callable|null $commit_guard Optional request-context authorization guard.
	 * @return array|WP_Error Start scan job.
	 */

	protected static function start_scan_job(
		int $limit = self::DEFAULT_LIMIT,
		bool $scheduled = false,
		?callable $commit_guard = null,
	) {
		$lock = self::acquire_scan_lock();

		if (!$lock) {
			return self::get_status();
		}

		try {
			return self::start_scan_job_unlocked($limit, $scheduled, $commit_guard);
		} finally {
			self::release_scan_lock($lock);
		}
	}

	/**
	 * Start a scan while holding the shared job-state lock.
	 *
	 * @param int $limit Limit.
	 * @param bool $scheduled Scheduled.
	 * @param callable|null $commit_guard Optional request-context authorization guard.
	 * @return array|WP_Error Start scan job.
	 */

	protected static function start_scan_job_unlocked(
		int $limit,
		bool $scheduled,
		?callable $commit_guard = null,
	) {
		if (!self::restore_start_checkpoint_unlocked()) {
			return new WP_Error(
				'wphave_privacy_scan_recovery_failed',
				__('The Privacy scan could not restore its previous state.', 'wphave'),
				['status' => 503],
			);
		}
		$existing_job = self::get_resumable_scan_job();
		$replace_invalid_manual_job =
			!$scheduled &&
			$existing_job !== [] &&
			false === ($existing_job['scheduled'] ?? null) &&
			!self::is_valid_scan_job($existing_job);
		if ($existing_job && !$replace_invalid_manual_job) {
			return self::get_status();
		}

		$limit = max(1, min(self::MAX_LIMIT, $limit ?: self::DEFAULT_LIMIT));
		$started_at = current_time('mysql');
		$urls = self::discover_urls($limit);

		if ($commit_guard) {
			// AUTHORIZATION/PRIVACY-SCAN-START-COMMIT INVARIANT: URL discovery
			// crosses query, permalink and normalization extension boundaries. A REST
			// caller must retain the canonical Privacy policy after the complete
			// candidate projection and immediately before the first durable job write.
			// Cron omits this request-only guard and retains its separate ownership.
			$authorization = call_user_func($commit_guard);

			if (is_wp_error($authorization)) {
				return $authorization;
			}
		}
		if (!$urls) {
			return new WP_Error(
				'wphave_privacy_scan_empty_queue',
				__('The Privacy scan could not find a page to scan.', 'wphave'),
				['status' => 503],
			);
		}
		if (
			$existing_job === [] &&
			false !== get_option(self::JOB_CHECKPOINT_OPTION, false)
		) {
			// RECOVERY INVARIANT: A terminal orphan checkpoint may be ignored by
			// readers, but must be removed before a new queue becomes durable.
			delete_option(self::JOB_CHECKPOINT_OPTION);
			if (false !== get_option(self::JOB_CHECKPOINT_OPTION, false)) {
				return new WP_Error(
					'wphave_privacy_scan_recovery_failed',
					__('The Privacy scan could not clear its old recovery state.', 'wphave'),
					['status' => 503],
				);
			}
		}
		if ($replace_invalid_manual_job) {
			// RECOVERY INVARIANT: Only a newly authorized manual start may retire
			// a malformed manual job. A scheduled or valid job keeps its ownership.
			// Remove both queue records before publishing the replacement.
			delete_option(self::JOB_OPTION);
			delete_option(self::JOB_CHECKPOINT_OPTION);
			if (
				false !== get_option(self::JOB_OPTION, false) ||
				false !== get_option(self::JOB_CHECKPOINT_OPTION, false)
			) {
				return new WP_Error(
					'wphave_privacy_scan_recovery_failed',
					__('The Privacy scan could not replace its invalid job.', 'wphave'),
					['status' => 503],
				);
			}
		}

		$job = [
			'scanId' => wp_generate_uuid4(),
			'startedAt' => $started_at,
			'scheduled' => $scheduled,
			'urls' => $urls,
			'processed' => 0,
			'services' => [],
			'errors' => [],
		];
		$previous_results = get_option(self::RESULTS_OPTION, null);
		$previous_status = get_option(self::STATUS_OPTION, null);
		$start_checkpoint = [
			'scanId' => $job['scanId'],
			'resultsPresent' => $previous_results !== null,
			'results' => is_array($previous_results)
				? self::canonical_scan_results($previous_results, true)
				: [],
			'statusPresent' => $previous_status !== null,
			'status' => self::canonical_scan_status($previous_status),
		];
		$rollback_start = static function (): void {
			self::restore_start_checkpoint_unlocked();
		};
		$write_error = static fn() => new WP_Error(
			'wphave_privacy_scan_start_write_failed',
			__('The Privacy scan could not save its starting state.', 'wphave'),
			['status' => 503],
		);

		// PERSISTENCE INVARIANT: A filterable WordPress write is authoritative
		// only after exact readback. Never publish a running scan with a different
		// task queue, result projection or status than the one just constructed.
		if (!self::persist_scan_option(self::START_CHECKPOINT_OPTION, $start_checkpoint)) {
			delete_option(self::START_CHECKPOINT_OPTION);
			return $write_error();
		}
		if (!self::persist_scan_option(self::JOB_OPTION, $job)) {
			$rollback_start();
			return $write_error();
		}
		$initial_results = [
			'storageVersion' => self::RESULTS_STORAGE_VERSION,
			'scanId' => $job['scanId'],
			'startedAt' => $started_at,
			'finishedAt' => '',
			'scheduled' => $scheduled,
			'processed' => 0,
			'total' => count($urls),
			'servicesFound' => 0,
			'services' => [],
			'errors' => [],
		];
		if (!self::persist_scan_option(self::RESULTS_OPTION, $initial_results)) {
			$rollback_start();
			return $write_error();
		}

		$status = [
			'scanId' => $job['scanId'],
			'state' => 'running',
			'startedAt' => $started_at,
			'finishedAt' => '',
			'scheduled' => $scheduled,
			'processed' => 0,
			'total' => count($urls),
			'servicesFound' => 0,
			'errors' => [],
		];

		if (!self::persist_scan_option(self::STATUS_OPTION, $status)) {
			$rollback_start();
			return $write_error();
		}
		delete_option(self::START_CHECKPOINT_OPTION);
		if (false !== get_option(self::START_CHECKPOINT_OPTION, false)) {
			$rollback_start();
			return $write_error();
		}
		if (class_exists('WPHAVE_Activity_Log')) {
			WPHAVE_Activity_Log::record('privacy_scan.started', [
				'category' => 'system',
				'action' => 'started',
				'actor_type' => $scheduled ? 'cron' : null,
				'object_type' => 'scan',
				'object_label' => 'Privacy scan',
				'context' => ['total' => count($urls), 'scheduled' => $scheduled],
			]);
		}

		return $status;
	}

	/** Retry an interrupted start rollback before scheduled work can resume. */
	public static function recover_failed_start(): bool {
		if (false === get_option(self::START_CHECKPOINT_OPTION, false)) {
			return true;
		}
		$lock = self::acquire_scan_lock();
		if (!$lock) {
			return false;
		}
		try {
			return self::restore_start_checkpoint_unlocked();
		} finally {
			self::release_scan_lock($lock);
		}
	}

	/** Keep the prior snapshot until every rollback write is acknowledged. */
	private static function restore_start_checkpoint_unlocked(): bool {
		$checkpoint = get_option(self::START_CHECKPOINT_OPTION, false);
		if ($checkpoint === false) {
			return true;
		}
		if (!self::is_valid_start_checkpoint($checkpoint)) {
			return false;
		}
		$current_job = get_option(self::JOB_OPTION, []);
		if (self::is_valid_scan_job($current_job)) {
			$checkpoint_scan_id = $checkpoint['scanId'] ?? null;
			$current_scan_id = $current_job['scanId'] ?? null;
			if (!is_string($checkpoint_scan_id) || !is_string($current_scan_id)) {
				// An older checkpoint has no identity proof for a valid job.
				return false;
			}
			if ($current_scan_id !== $checkpoint_scan_id) {
				// ROLLBACK IDENTITY INVARIANT: A stale start checkpoint cannot
				// erase a newer confirmed queue or its published projections.
				delete_option(self::START_CHECKPOINT_OPTION);
				return false === get_option(self::START_CHECKPOINT_OPTION, false);
			}
		}
		// ROLLBACK INVARIANT: A filtered restore leaves the old snapshot durable
		// and suppresses the incomplete job until a later request can retry.
		delete_option(self::JOB_OPTION);
		delete_option(self::JOB_CHECKPOINT_OPTION);
		if (
			false !== get_option(self::JOB_OPTION, false) ||
			false !== get_option(self::JOB_CHECKPOINT_OPTION, false)
		) {
			return false;
		}
		foreach ([
			self::RESULTS_OPTION => ['resultsPresent', 'results'],
			self::STATUS_OPTION => ['statusPresent', 'status'],
		] as $option => [$present_key, $value_key]) {
			if ($checkpoint[$present_key]) {
				if (!self::persist_scan_option($option, $checkpoint[$value_key])) {
					return false;
				}
			} else {
				delete_option($option);
				if (false !== get_option($option, false)) {
					return false;
				}
			}
		}
		delete_option(self::START_CHECKPOINT_OPTION);
		return false === get_option(self::START_CHECKPOINT_OPTION, false);
	}

	/** Validate the complete previous-state snapshot before reading or restoring it. */
	private static function is_valid_start_checkpoint($checkpoint): bool {
		return is_array($checkpoint) &&
			array_diff(
				array_keys($checkpoint),
				['scanId', 'resultsPresent', 'results', 'statusPresent', 'status'],
			) === [] &&
			(!isset($checkpoint['scanId']) || is_string($checkpoint['scanId'])) &&
			is_bool($checkpoint['resultsPresent'] ?? null) &&
			is_array($checkpoint['results'] ?? null) &&
			is_bool($checkpoint['statusPresent'] ?? null) &&
			is_array($checkpoint['status'] ?? null) &&
			($checkpoint['resultsPresent']
				? self::canonical_scan_results($checkpoint['results'], true) === $checkpoint['results']
				: $checkpoint['results'] === []) &&
			($checkpoint['statusPresent']
				? self::canonical_scan_status($checkpoint['status']) === $checkpoint['status']
				: $checkpoint['status'] === self::canonical_scan_status([]));
	}

	/**
	 * Return scan settings.
	 *
	 * @return array Return scan settings.
	 */

	protected static function get_scan_settings(): array {
		$settings = function_exists('wphave_data_get')
			? wphave_data_get('privacy_settings', 'consent.scan', [])
			: [];
		$settings = is_array($settings) ? $settings : [];
		$frequency = sanitize_key($settings['frequency'] ?? 'weekly');

		if (!in_array($frequency, ['daily', 'weekly', 'monthly'], true)) {
			$frequency = 'weekly';
		}

		$time_window = sanitize_key($settings['time_window'] ?? 'night');

		if (!in_array($time_window, ['night', 'morning', 'afternoon', 'evening'], true)) {
			$time_window = 'night';
		}

		// SCAN-NOTIFICATION INVARIANT: Public-page findings leave the site only
		// for an exact configured or WordPress admin mailbox.
		$email = WPHAVE_Email_Identity::exact($settings['email'] ?? '');

		return [
			'auto_enabled' => !empty($settings['auto_enabled']),
			'frequency' => $frequency,
			'time_window' => $time_window,
			'email' => $email ?: WPHAVE_Email_Identity::exact(get_option('admin_email')),
		];
	}

	/**
	 * Return status.
	 *
	 * @return array Return status.
	 */

	public static function get_status(): array {
		$start_checkpoint = get_option(self::START_CHECKPOINT_OPTION, false);
		$status = self::canonical_scan_status(
			self::start_checkpoint_blocks_job($start_checkpoint)
				? (self::is_valid_start_checkpoint($start_checkpoint)
					? $start_checkpoint['status']
					: [])
				: get_option(self::STATUS_OPTION, []),
		);
		$status = self::normalize_status($status);
		$job = self::get_resumable_scan_job();
		if (self::is_valid_scan_job($job) && false === $job['scheduled']) {
			// RECOVERY INVARIANT: A filtered or interrupted manual status write
			// cannot hide a valid queue from the UI. Read projection is derived
			// without mutating the durable status or granting processing authority.
			$status = self::canonical_scan_status(
				array_merge($status, self::status_from_scan_job($job)),
			);
		}
		$status['automation'] = self::get_automation_status();

		return $status;
	}

	/** Apply the same disclosure contract to stored and immediate scan status. */
	private static function canonical_scan_status($stored): array {
		$status = is_array($stored) ? $stored : [];
		// DISCLOSURE INVARIANT: Status is stored through filterable options.
		// Jobs and immediate REST responses must follow the same allowlist.
		$stored_status = $status;
		$status = [
			'state' => in_array(
				$status['state'] ?? null,
				['idle', 'running', 'partial', 'complete', 'cancelled'],
				true,
			)
				? $status['state']
				: 'idle',
			'startedAt' => is_string($status['startedAt'] ?? null)
				? sanitize_text_field($status['startedAt'])
				: '',
			'finishedAt' => is_string($status['finishedAt'] ?? null)
				? sanitize_text_field($status['finishedAt'])
				: '',
			'scheduled' => is_bool($status['scheduled'] ?? null) ? $status['scheduled'] : false,
			'processed' => is_int($status['processed'] ?? null) ? max(0, $status['processed']) : 0,
			'total' => is_int($status['total'] ?? null) ? max(0, $status['total']) : 0,
			'servicesFound' => is_int($status['servicesFound'] ?? null)
				? max(0, $status['servicesFound'])
				: 0,
			'errors' => self::normalize_privacy_scan_errors(
				is_array($status['errors'] ?? null) ? $status['errors'] : [],
			),
		];
		if (is_string($stored_status['scanId'] ?? null) && $stored_status['scanId'] !== '') {
			$status['scanId'] = WPHAVE_Security_Redactor::diagnostic_text(
				$stored_status['scanId'],
				64,
			);
		}

		return $status;
	}

	/**
	 * Return results.
	 *
	 * @return array Return results.
	 */

	public static function get_results(): array {
		$start_checkpoint = get_option(self::START_CHECKPOINT_OPTION, false);
		return self::canonical_scan_results(
			self::start_checkpoint_blocks_job($start_checkpoint)
				? (self::is_valid_start_checkpoint($start_checkpoint)
					? $start_checkpoint['results']
					: [])
				: get_option(self::RESULTS_OPTION, []),
			false,
		);
	}

	/** Build the same allowlisted result shape for storage and API disclosure. */
	private static function canonical_scan_results($stored, bool $durable): array {
		$stored = is_array($stored) ? $stored : [];
		$services = self::sanitize_result_services($stored['services'] ?? []);
		$started_at = is_string($stored['startedAt'] ?? null)
			? sanitize_text_field($stored['startedAt'])
			: '';
		$finished_at = is_string($stored['finishedAt'] ?? null)
			? sanitize_text_field($stored['finishedAt'])
			: '';

		// DATA MINIMIZATION INVARIANT: Neither a legacy option nor a filtered
		// write may smuggle extra top-level keys into the durable result or REST.
		$results = [
			'startedAt' => $started_at,
			'finishedAt' => $finished_at,
			'scheduled' => is_bool($stored['scheduled'] ?? null)
				? $stored['scheduled']
				: false,
			'processed' => is_int($stored['processed'] ?? null)
				? max(0, $stored['processed'])
				: 0,
			'total' => is_int($stored['total'] ?? null) ? max(0, $stored['total']) : 0,
			'servicesFound' => count($services),
			'services' => $services,
			'errors' => self::normalize_privacy_scan_errors(
				is_array($stored['errors'] ?? null) ? $stored['errors'] : [],
			),
		];
		if (is_string($stored['scanId'] ?? null) && $stored['scanId'] !== '') {
			$results['scanId'] = WPHAVE_Security_Redactor::diagnostic_text(
				$stored['scanId'],
				64,
			);
		}
		if ($durable) {
			$results['storageVersion'] = self::RESULTS_STORAGE_VERSION;
		}

		return $results;
	}

	/** Limit and redact the durable and public service projection identically. */
	private static function sanitize_result_services($services): array {
		if (!is_array($services)) {
			return [];
		}
		$bounded = [];
		// RESOURCE BUDGET INVARIANT: Invalid entries consume inspection budget
		// too; a filtered option must not force an unbounded read or migration.
		foreach (array_slice($services, 0, self::MAX_SERVICES) as $service) {
			$service = self::sanitize_scan_service($service);
			if ($service === null) {
				continue;
			}
			$bounded[] = $service;
			// RESOURCE BUDGET INVARIANT: Migration and reads must stop at the
			// durable cap instead of copying an unbounded legacy array first.
			if (count($bounded) >= self::MAX_SERVICES) {
				break;
			}
		}

		return $bounded;
	}

	/** Admit only fields produced and consumed by the Privacy Scanner. */
	private static function sanitize_scan_service($service): ?array {
		if (!is_array($service) || !is_string($service['domain'] ?? null)) {
			return null;
		}
		$domain = substr(sanitize_text_field($service['domain']), 0, 253);
		$normalized_domain = self::normalize_domain($domain);
		if (
			!$normalized_domain ||
			!filter_var($normalized_domain, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME) ||
			self::is_ignored_domain($normalized_domain)
		) {
			return null;
		}
		$references = [];
		foreach (['urls', 'pages'] as $field) {
			$values = is_array($service[$field] ?? null) ? $service[$field] : [];
			$references[$field] = array_values(array_map(
				static fn($value) => WPHAVE_Security_Redactor::diagnostic_text(
					is_string($value) ? $value : '',
					self::MAX_DIAGNOSTIC_URL_LENGTH,
				),
				array_slice($values, 0, self::MAX_SERVICE_REFERENCES),
			));
		}
		$sources = is_array($service['sources'] ?? null) ? $service['sources'] : [];
		$sources = array_values(array_unique(array_map(
			static fn($value) => is_string($value) ? sanitize_key($value) : '',
			array_slice($sources, 0, self::MAX_SERVICE_REFERENCES),
		)));
		$sources = array_values(array_filter($sources));
		$category = is_string($service['category'] ?? null)
			? sanitize_key($service['category'])
			: null;
		$suggested = is_string($service['suggested'] ?? null)
			? sanitize_key($service['suggested'])
			: null;
		$confidence = is_string($service['confidence'] ?? null)
			? sanitize_key($service['confidence'])
			: 'low';
		$resource_type = is_string($service['resourceType'] ?? null)
			? sanitize_key($service['resourceType'])
			: 'consent';

		// DATA MINIMIZATION INVARIANT: Unknown legacy or filtered keys are not
		// part of a finding. They must never survive a read, migration or batch.
		return [
			'domain' => $domain,
			'category' => $category,
			'suggested' => $suggested,
			'confidence' => in_array($confidence, ['low', 'medium', 'high'], true)
				? $confidence
				: 'low',
			'active' => true,
			'sources' => $sources,
			'urls' => $references['urls'],
			'pages' => $references['pages'],
			'resourceType' => in_array($resource_type, ['consent', 'sensitive'], true)
				? $resource_type
				: 'consent',
			'detectedBy' => 'scan',
		];
	}

	/** Upgrade older stored findings without tying data minimization to a read. */
	public static function migrate_legacy_scan_results(): bool {
		if (false !== get_option(self::START_CHECKPOINT_OPTION, false)) {
			return false;
		}
		$stored = get_option(self::RESULTS_OPTION, []);
		$pending = get_option(self::RESULTS_MIGRATION_OPTION, []);
		if (
			((!is_array($stored) || !$stored) && !$pending) ||
			(is_array($stored) &&
				($stored['storageVersion'] ?? null) === self::RESULTS_STORAGE_VERSION &&
				self::canonical_scan_results($stored, true) === $stored &&
				!$pending)
		) {
			return true;
		}
		$lock = self::acquire_scan_lock();
		if (!$lock) {
			return false;
		}

		try {
			$results = get_option(self::RESULTS_OPTION, []);
			$target = get_option(self::RESULTS_MIGRATION_OPTION, []);
			if (
				$target &&
				(!is_array($target) ||
					!in_array($target['storageVersion'] ?? null, [2, self::RESULTS_STORAGE_VERSION], true) ||
					!is_array($target['services'] ?? null) ||
					!is_array($target['errors'] ?? null))
			) {
				// RECOVERY INVARIANT: A malformed pending option cannot be promoted
				// over a current result or treated as a sanitized migration target.
				delete_option(self::RESULTS_MIGRATION_OPTION);
				return false === get_option(self::RESULTS_MIGRATION_OPTION, false);
			}
			if (is_array($target) && $target) {
				$target = self::canonical_scan_results($target, true);
				if (!self::persist_scan_option(self::RESULTS_MIGRATION_OPTION, $target)) {
					return false;
				}
				if (
					!is_array($results) ||
					($results['storageVersion'] ?? null) !== self::RESULTS_STORAGE_VERSION ||
					($results['scanId'] ?? null) === ($target['scanId'] ?? null) &&
					(int) ($results['processed'] ?? 0) <= $target['processed']
				) {
					// RECOVERY INVARIANT: The pending target contains redacted data.
					// Retry it after a filtered result write, but never replace a newer
					// scan identified by a different run ID.
					if (!self::persist_scan_option(self::RESULTS_OPTION, $target)) {
						return false;
					}
				}
				delete_option(self::RESULTS_MIGRATION_OPTION);
				return false === get_option(self::RESULTS_MIGRATION_OPTION, false);
			}
			if (!is_array($results) || !$results) {
				return true;
			}
			if (
				($results['storageVersion'] ?? null) === self::RESULTS_STORAGE_VERSION &&
				self::canonical_scan_results($results, true) === $results
			) {
				return true;
			}

			// PRIVACY/MIGRATION INVARIANT: Keep only the redacted target as a
			// checkpoint. A filtered result write may fail, but the next run can
			// retry without duplicating legacy query secrets in another option.
			$target = self::canonical_scan_results($results, true);
			if (!self::persist_scan_option(self::RESULTS_MIGRATION_OPTION, $target)) {
				delete_option(self::RESULTS_MIGRATION_OPTION);
				return false;
			}
			if (!self::persist_scan_option(self::RESULTS_OPTION, $target)) {
				return false;
			}
			delete_option(self::RESULTS_MIGRATION_OPTION);

			return false === get_option(self::RESULTS_MIGRATION_OPTION, false);
		} finally {
			self::release_scan_lock($lock);
		}
	}

	/**
	 * Set status.
	 *
	 * @param array $status Status.
	 * @return void
	 */

	protected static function set_status(array $status): void {
		update_option(self::STATUS_OPTION, self::normalize_status($status), false);
	}

	/** Store one scan projection only when its exact value can be read back. */

	protected static function persist_scan_option(string $option, array $value): bool {
		update_option($option, $value, false);

		return get_option($option, null) === $value;
	}

	/** Read the last verified queue while a filtered progress write is unresolved. */
	protected static function get_resumable_scan_job(): array {
		if (self::start_checkpoint_blocks_job(get_option(self::START_CHECKPOINT_OPTION, false))) {
			return [];
		}
		$checkpoint = get_option(self::JOB_CHECKPOINT_OPTION, []);
		if (self::is_valid_scan_checkpoint($checkpoint)) {
			$job = get_option(self::JOB_OPTION, []);
			if (
				self::is_valid_scan_job($job) &&
				is_string($job['scanId'] ?? null) &&
				$job['scanId'] !== '' &&
				$job['scanId'] !== ($checkpoint['before']['scanId'] ?? null)
			) {
				// RECOVERY IDENTITY INVARIANT: A checkpoint from an older run cannot
				// replace a valid newer queue, even when its cleanup was interrupted.
				return $job;
			}
			if (!$job && self::is_terminal_scan_checkpoint($checkpoint)) {
				// COMPLETION INVARIANT: A leftover checkpoint cannot revive a job
				// whose matching terminal status and results were committed.
				return [];
			}
			// RECOVERY INVARIANT: A crash after the job write but before checkpoint
			// removal must keep acknowledged progress. A different durable job value
			// is unverified, so replay the predecessor instead of trusting it.
			return $job === $checkpoint['after']
				? $checkpoint['after']
				: $checkpoint['before'];
		}

		$job = get_option(self::JOB_OPTION, []);

		return is_array($job) ? $job : [];
	}

	/** A newer valid run remains visible while an old start checkpoint is retired. */
	private static function start_checkpoint_blocks_job($checkpoint): bool {
		if ($checkpoint === false) {
			return false;
		}
		$job = get_option(self::JOB_OPTION, []);
		// RECOVERY VISIBILITY INVARIANT: Only a different, valid scan identity
		// can outrank a pending rollback; malformed or legacy identities fail closed.
		return !(
			self::is_valid_start_checkpoint($checkpoint) &&
			is_string($checkpoint['scanId'] ?? null) &&
			self::is_valid_scan_job($job) &&
			is_string($job['scanId'] ?? null) &&
			$job['scanId'] !== $checkpoint['scanId']
		);
	}

	/** Accept only one bounded, forward-only transition of the same scan queue. */
	private static function is_valid_scan_checkpoint($checkpoint): bool {
		if (
			!is_array($checkpoint) ||
			!self::is_valid_scan_job($checkpoint['before'] ?? null) ||
			!self::is_valid_scan_job($checkpoint['after'] ?? null)
		) {
			return false;
		}

		$before = $checkpoint['before'];
		$after = $checkpoint['after'];

		// RECOVERY TRANSITION INVARIANT: A checkpoint is evidence of progress
		// only within one immutable queue and at most one scanner batch.
		return ($before['scanId'] ?? null) === ($after['scanId'] ?? null) &&
			($before['startedAt'] ?? null) === ($after['startedAt'] ?? null) &&
			$before['scheduled'] === $after['scheduled'] &&
			$before['urls'] === $after['urls'] &&
			$after['processed'] > $before['processed'] &&
			$after['processed'] <= $before['processed'] + self::BATCH_SIZE;
	}

	/** Identify a checkpoint left after its job reached a durable terminal state. */
	private static function is_terminal_scan_checkpoint(array $checkpoint): bool {
		$before = $checkpoint['before'];
		$status = get_option(self::STATUS_OPTION, []);
		if (
			!is_array($status) ||
			($status['startedAt'] ?? null) !== ($before['startedAt'] ?? null) ||
			($status['scheduled'] ?? null) !== ($before['scheduled'] ?? null)
		) {
			return false;
		}
		if (
			isset($before['scanId']) &&
			($status['scanId'] ?? null) !== $before['scanId']
		) {
			// IDENTITY INVARIANT: Seconds-resolution timestamps can collide.
			// New jobs require their unique run identity at terminal recovery.
			return false;
		}
		if ('cancelled' === ($status['state'] ?? null) && true === $before['scheduled']) {
			return true;
		}
		if (
			'complete' !== ($status['state'] ?? null) ||
			($status['processed'] ?? null) !== count($before['urls']) ||
			($status['total'] ?? null) !== count($before['urls'])
		) {
			return false;
		}
		$results = get_option(self::RESULTS_OPTION, []);

		return is_array($results) &&
			(!isset($before['scanId']) ||
				($results['scanId'] ?? null) === $before['scanId']) &&
			($results['startedAt'] ?? null) === ($before['startedAt'] ?? null) &&
			($results['scheduled'] ?? null) === ($before['scheduled'] ?? null) &&
			($results['processed'] ?? null) === count($before['urls']) &&
			($results['total'] ?? null) === count($before['urls']);
	}

	/** Validate the durable queue identity and cursor shared by REST and Cron. */
	protected static function is_valid_scan_job($job): bool {
		// QUEUE BUDGET INVARIANT: A resumed or filtered option must obey the same
		// page limit as a newly discovered scan before any network request runs.
		return is_array($job) &&
			is_bool($job['scheduled'] ?? null) &&
			is_array($job['urls'] ?? null) &&
			!empty($job['urls']) &&
			count($job['urls']) <= self::MAX_LIMIT &&
			is_int($job['processed'] ?? null) &&
			$job['processed'] >= 0 &&
			$job['processed'] <= count($job['urls']);
	}

	/** Derive the running status projection from one structurally valid job. */
	protected static function status_from_scan_job(array $job): array {
		$services = self::normalize_privacy_scan_services($job['services'] ?? []);

		$status = [
			'state' => 'running',
			'startedAt' => sanitize_text_field($job['startedAt'] ?? ''),
			'finishedAt' => '',
			'scheduled' => $job['scheduled'],
			'processed' => $job['processed'],
			'total' => count($job['urls']),
			'servicesFound' => count($services),
			'errors' => self::normalize_privacy_scan_errors(
				is_array($job['errors'] ?? null) ? $job['errors'] : [],
			),
		];
		if (is_string($job['scanId'] ?? null) && $job['scanId'] !== '') {
			$status['scanId'] = $job['scanId'];
		}

		return $status;
	}

	/**
	 * Normalize status.
	 *
	 * @param array $status Status.
	 * @return array Normalize status.
	 */

	protected static function normalize_status(array $status): array {
		$processed = absint($status['processed'] ?? 0);
		$total = absint($status['total'] ?? 0);
		$state = sanitize_key($status['state'] ?? 'idle');

		if ($state === 'complete' && $total > 0 && $processed < $total) {
			$status['state'] = 'partial';
		}

		if ($state === 'running' && !self::get_resumable_scan_job()) {
			$status['state'] = $total > 0 && $processed >= $total ? 'complete' : 'partial';
		}

		return $status;
	}

	/**
	 * Process scan batch.
	 *
	 * @param callable|null $commit_guard Optional request-context authorization guard.
	 * @return array|WP_Error Process scan batch.
	 */

	protected static function process_scan_batch(?callable $commit_guard = null) {
		$lock = self::acquire_scan_lock();

		if (!$lock) {
			return self::get_status();
		}

		try {
			return self::process_scan_batch_unlocked($commit_guard);
		} finally {
			self::release_scan_lock($lock);
		}
	}

	/**
	 * Process one scan batch while holding the scan lock.
	 *
	 * @param callable|null $commit_guard Optional request-context authorization guard.
	 * @return array|WP_Error Process scan batch.
	 */

	protected static function process_scan_batch_unlocked(?callable $commit_guard = null) {
		$job = self::get_resumable_scan_job();

		if ($job === []) {
			return self::get_status();
		}
		if (!self::is_valid_scan_job($job)) {
			// DATA INTEGRITY INVARIANT: A malformed cursor cannot be coerced into
			// progress, skip pages, or publish a falsely completed scan.
			return new WP_Error(
				'wphave_privacy_scan_invalid_job',
				__('The Privacy scan job has invalid progress data.', 'wphave'),
				['status' => 409],
			);
		}

		$urls = array_values($job['urls']);
		$services = self::normalize_privacy_scan_services($job['services'] ?? []);
		$errors = self::normalize_privacy_scan_errors(
			is_array($job['errors'] ?? null) ? $job['errors'] : [],
		);
		$processed = absint($job['processed']);
		$started_at = sanitize_text_field($job['startedAt'] ?? current_time('mysql'));
		$scheduled = !empty($job['scheduled']);
		$total = count($urls);
		$batch_end = min($total, $processed + self::BATCH_SIZE);

		if ($commit_guard) {
			// AUTHORIZATION/PRIVACY-SCAN-PROCESS INVARIANT: A stored manual job is
			// data, not continuing request authority. Revalidate the REST caller after
			// complete job projection and before any server-side request can execute.
			// Scheduled workers omit this guard and retain their Cron ownership checks.
			$authorization = call_user_func($commit_guard);

			if (is_wp_error($authorization)) {
				return $authorization;
			}
		}

		for ($index = $processed; $index < $batch_end; $index++) {
			$url = $urls[$index];
			if (!is_string($url) || $url === '') {
				// INPUT INVARIANT: Stored job URLs can cross option filters or old
				// schema boundaries. A malformed entry is consumed without transport
				// or diagnostic interpolation; it must not crash the worker.
				$processed++;
				$errors[] = [
					'url' => '',
					'message' => __('Skipped an invalid scan URL.', 'wphave'),
				];
				continue;
			}

			if (!self::is_same_site_scan_url($url)) {
				$processed++;
				$errors[] = [
					'url' => WPHAVE_Security_Normalizer::diagnostic_url($url),
					'message' => __('Skipped a scan URL outside the current site.', 'wphave'),
				];
				continue;
			}

			// TRANSPORT INVARIANT: Scanner classification receives only a complete,
			// bounded response from the already validated site URL. The extra byte is
			// an overflow sentinel and must never reach service detection.
			if ($commit_guard) {
				$authorization = call_user_func($commit_guard);

				if (is_wp_error($authorization)) {
					return $authorization;
				}
			}

			$response = wp_safe_remote_get(WPHAVE_Privacy_Public_Scan::request_url($url), [
				'cookies' => [],
				'timeout' => 8,
				'redirection' => 0,
				'sslverify' => true,
				'limit_response_size' => self::MAX_RESPONSE_BYTES + 1,
				'user-agent' =>
					'WPHAVE Privacy Scanner/' .
					(defined('WPHAVE_VERSION') ? WPHAVE_VERSION : '1.0') .
					'; ' .
					home_url('/'),
				'headers' => [
					'Accept' => 'text/html,application/xhtml+xml',
					'Cookie' => '',
					'Authorization' => '',
				],
			]);

			$processed++;

			if (is_wp_error($response)) {
				$errors[] = [
					'url' => WPHAVE_Security_Normalizer::diagnostic_url($url),
					'message' => WPHAVE_Security_Redactor::error_text(
						$response->get_error_message(),
					),
				];
				continue;
			}

			$code = (int) wp_remote_retrieve_response_code($response);

			if ($code < 200 || $code >= 400) {
				$errors[] = [
					'url' => $url,
					'message' => sprintf('HTTP %d', $code),
				];
				continue;
			}

			$content_type = (string) wp_remote_retrieve_header($response, 'content-type');

			if (
				$content_type &&
				stripos($content_type, 'text/html') === false &&
				stripos($content_type, 'application/xhtml+xml') === false
			) {
				continue;
			}

			$html = wp_remote_retrieve_body($response);

			if (!is_string($html) || $html === '' || strlen($html) > self::MAX_RESPONSE_BYTES) {
				if (is_string($html) && strlen($html) > self::MAX_RESPONSE_BYTES) {
					$errors[] = [
						'url' => WPHAVE_Security_Normalizer::diagnostic_url($url),
						'message' => __(
							'The page exceeded the Privacy Scanner response limit and was not analyzed.',
							'wphave',
						),
					];
				}
				continue;
			}

			if (!WPHAVE_Privacy_Public_Scan::is_public_response($response, $html)) {
				$errors[] = [
					'url' => WPHAVE_Security_Normalizer::diagnostic_url($url),
					'message' => __(
						'The page did not confirm an anonymous scan response and was not analyzed.',
						'wphave',
					),
				];
				continue;
			}
			self::scan_html($html, $url, $services);
		}

		// SECURITY INVARIANT: Operational scan URLs may contain credentials or
		// personal data in their query string. Every error projection must cross
		// the diagnostic normalization boundary before any option is persisted.
		$errors = self::normalize_privacy_scan_errors($errors);

		$is_complete = $processed >= $total;
		$results = [
			'storageVersion' => self::RESULTS_STORAGE_VERSION,
			'startedAt' => $started_at,
			'finishedAt' => $is_complete ? current_time('mysql') : '',
			'scheduled' => $scheduled,
			'processed' => $processed,
			'total' => $total,
			'servicesFound' => count($services),
			'services' => array_values($services),
			'errors' => $errors,
		];
		if (is_string($job['scanId'] ?? null) && $job['scanId'] !== '') {
			$results['scanId'] = $job['scanId'];
		}

		if ($commit_guard) {
			// AUTHORIZATION/PRIVACY-SCAN-PROCESS-COMMIT INVARIANT: HTTP transports,
			// response parsers and service classifiers execute extension code. A manual
			// request must retain Privacy authority immediately before publishing the
			// first result, job-progress or status mutation.
			$authorization = call_user_func($commit_guard);

			if (is_wp_error($authorization)) {
				return $authorization;
			}
		}

		// PERSISTENCE INVARIANT: A filtered result cannot authorize job removal
		// or a completed status. Keep the job retryable until exact readback.
		if (!self::persist_scan_option(self::RESULTS_OPTION, $results)) {
			return new WP_Error(
				'wphave_privacy_scan_results_write_failed',
				__('The Privacy scan could not save its results.', 'wphave'),
				['status' => 503],
			);
		}

		if ($commit_guard) {
			$authorization = call_user_func($commit_guard);
			if (is_wp_error($authorization)) {
				return $authorization;
			}
		}

		if (!$is_complete) {
			$next_job = $job;
			$next_job['processed'] = $processed;
			$next_job['services'] = $services;
			$next_job['errors'] = $errors;
			// RECOVERY INVARIANT: Checkpoint the verified queue before a filterable
			// progress write. The expected successor distinguishes an acknowledged
			// write from a filtered write or an interruption before that write.
			if (
				!self::persist_scan_option(self::JOB_CHECKPOINT_OPTION, [
					'before' => $job,
					'after' => $next_job,
				])
			) {
				// A rejected checkpoint must never become a recovery source.
				delete_option(self::JOB_CHECKPOINT_OPTION);
				return new WP_Error(
					'wphave_privacy_scan_checkpoint_write_failed',
					__('The Privacy scan could not save its recovery state.', 'wphave'),
					['status' => 503],
				);
			}
			if (!self::persist_scan_option(self::JOB_OPTION, $next_job)) {
				return new WP_Error(
					'wphave_privacy_scan_job_write_failed',
					__('The Privacy scan could not save its progress.', 'wphave'),
					['status' => 503],
				);
			}
			delete_option(self::JOB_CHECKPOINT_OPTION);
		}

		$status = [
			'state' => $is_complete ? 'complete' : 'running',
			'startedAt' => $started_at,
			'finishedAt' => $results['finishedAt'],
			'scheduled' => $scheduled,
			'processed' => $processed,
			'total' => $total,
			'servicesFound' => count($services),
			'errors' => $errors,
		];
		if (is_string($job['scanId'] ?? null) && $job['scanId'] !== '') {
			$status['scanId'] = $job['scanId'];
		}

		$status = self::normalize_status($status);
		if (!self::persist_scan_option(self::STATUS_OPTION, $status)) {
			return new WP_Error(
				'wphave_privacy_scan_status_write_failed',
				__('The Privacy scan could not save its status.', 'wphave'),
				['status' => 503],
			);
		}

		if ($is_complete) {
			// COMPLETION INVARIANT: The resumable job is removed only after the
			// result and terminal status have both been acknowledged.
			delete_option(self::JOB_OPTION);
			delete_option(self::JOB_CHECKPOINT_OPTION);
			if (class_exists('WPHAVE_Activity_Log')) {
				WPHAVE_Activity_Log::record('privacy_scan.completed', [
					'category' => 'system',
					'action' => 'completed',
					'actor_type' => $scheduled ? 'cron' : null,
					'object_type' => 'scan',
					'object_label' => 'Privacy scan',
					'context' => [
						'processed' => $processed,
						'services_found' => count($services),
						'errors' => count($errors),
						'scheduled' => $scheduled,
					],
				]);
			}
		}

		return $status;
	}

	/**
	 * Keep only persisted findings that satisfy the shape used by the scanner.
	 * A corrupt service must not become an array mutation target on the next page.
	 */
	private static function normalize_privacy_scan_services($stored): array {
		if (!is_array($stored)) {
			return [];
		}

		$services = [];
		// A corrupt stored job cannot make one batch inspect unlimited findings.
		foreach (array_slice($stored, 0, self::MAX_SERVICES, true) as $key => $service) {
			if (
				!is_string($key) ||
				!is_array($service) ||
				!is_string($service['domain'] ?? null) ||
				self::normalize_domain($service['domain']) !== $key
			) {
				continue;
			}
			$valid = true;
			foreach (['sources', 'urls', 'pages'] as $field) {
				if (!is_array($service[$field] ?? null)) {
					$valid = false;
					break;
				}
				foreach (array_slice($service[$field], 0, self::MAX_SERVICE_REFERENCES) as $value) {
					if (!is_string($value)) {
						$valid = false;
						break;
					}
				}
			}
			if (!$valid) {
				continue;
			}
			foreach (['category', 'suggested', 'confidence', 'resourceType', 'detectedBy'] as $field) {
				if (isset($service[$field]) && !is_string($service[$field])) {
					$valid = false;
					break;
				}
			}
			if (!$valid || !is_bool($service['active'] ?? null)) {
				continue;
			}
			$sanitized = self::sanitize_scan_service($service);
			if ($sanitized === null) {
				continue;
			}
			$services[$key] = $sanitized;
			if (count($services) >= self::MAX_SERVICES) {
				break;
			}
		}

		return $services;
	}

	/**
	 * Normalize persisted scanner failures without changing operational scan URLs.
	 */
	private static function normalize_privacy_scan_errors(array $errors): array {
		$normalized = [];

		foreach (array_slice($errors, 0, 100) as $error) {
			if (!is_array($error)) {
				continue;
			}
			$url = $error['url'] ?? '';
			$message = $error['message'] ?? '';

			$normalized[] = [
				'url' => WPHAVE_Security_Normalizer::diagnostic_url(
					is_string($url) ? $url : '',
				),
				'message' => WPHAVE_Security_Redactor::error_text(
					is_string($message) ? $message : '',
				),
			];
		}

		return $normalized;
	}

	/**
	 * Acquire an atomic, short-lived lock for scanner batch processing.
	 *
	 * @return string|false Lock token or false when another worker owns it.
	 */

	protected static function acquire_scan_lock() {
		return WPHAVE_Background_Job_Lock::acquire(self::LOCK_OPTION, MINUTE_IN_SECONDS);
	}

	/**
	 * Release a scanner lock only when it is still owned by this worker.
	 *
	 * @param string $token Lock token.
	 * @return void
	 */

	protected static function release_scan_lock(string $token): void {
		// SECURITY INVARIANT: A timed-out scanner may resume after another worker
		// has acquired the lease; stale cleanup therefore removes only its own token.
		WPHAVE_Background_Job_Lock::release(self::LOCK_OPTION, $token);
	}

	/**
	 * Determine whether a discovered URL belongs to the current site origin.
	 *
	 * @param string $url Scan URL.
	 * @return bool Whether the URL may be requested.
	 */

	protected static function is_same_site_scan_url(string $url): bool {
		$target = wp_parse_url($url);
		$site = wp_parse_url(home_url('/'));

		if (
			!is_array($target) ||
			!is_array($site) ||
			empty($target['host']) ||
			empty($site['host'])
		) {
			return false;
		}

		$target_scheme = strtolower((string) ($target['scheme'] ?? ''));
		$site_scheme = strtolower((string) ($site['scheme'] ?? ''));
		$target_port = absint($target['port'] ?? ($target_scheme === 'https' ? 443 : 80));
		$site_port = absint($site['port'] ?? ($site_scheme === 'https' ? 443 : 80));
		$site_path = rtrim((string) ($site['path'] ?? '/'), '/') . '/';
		$target_path = (string) ($target['path'] ?? '/');
		$path_is_safe =
			str_starts_with($target_path, $site_path) &&
			!str_contains($target_path, '\\') &&
			!preg_match('#(?:^|/)\.{1,2}(?:/|$)#', $target_path) &&
			!preg_match('/%(?:2e|2f|5c|25)/i', $target_path);

		// SECURITY INVARIANT: Discovered links are request candidates, not SSRF
		// authority. They must remain inside this site's Home path, including
		// on hosts shared by subdirectory sites; encoded traversal is rejected.
		return in_array($target_scheme, ['http', 'https'], true) &&
			empty($target['user']) &&
			empty($target['pass']) &&
			$target_scheme === $site_scheme &&
			strtolower($target['host']) === strtolower($site['host']) &&
			$target_port === $site_port &&
			$path_is_safe;
	}

	/**
	 * Maybe send scan notification.
	 *
	 * @param array $results Results.
	 * @param array $settings Feature settings.
	 * @return void
	 */

	protected static function maybe_send_scan_notification(array $results, array $settings): void {
		$findings = self::get_actionable_findings($results);
		$hashes = self::get_finding_hashes($findings);
		$previous_hashes = get_option(self::NOTIFIED_OPTION, []);
		$previous_hashes = is_array($previous_hashes) ? $previous_hashes : [];
		$new_hashes = array_diff($hashes, $previous_hashes);

		if (empty($new_hashes)) {
			update_option(self::NOTIFIED_OPTION, $hashes, false);
			return;
		}

		if (empty($findings) || empty($settings['email'])) {
			return;
		}

		$new_findings = array_values(
			array_filter($findings, function ($finding) use ($new_hashes) {
				return in_array(self::get_finding_hash($finding), $new_hashes, true);
			}),
		);

		if (empty($new_findings)) {
			return;
		}

		$subject = sprintf(
			/* translators: %s: site name. */
			__('[%s] Privacy scan found services to review', 'wphave'),
			wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES),
		);

		$content =
			'<p><strong>' .
			esc_html(
				sprintf(
					/* translators: %d: number of new findings. */
					__('New findings: %d', 'wphave'),
					count($new_findings),
				),
			) .
			'</strong><br>' .
			esc_html(
				sprintf(
					/* translators: 1: processed pages, 2: total pages. */
					__('Pages scanned: %1$d/%2$d', 'wphave'),
					absint($results['processed'] ?? 0),
					absint($results['total'] ?? 0),
				),
			) .
			'</p><ul style="margin: 0; padding-left: 20px;">';

		foreach ($new_findings as $finding) {
			$type =
				$finding['resourceType'] === 'sensitive'
					? __('privacy-relevant service', 'wphave')
					: __('unassigned consent service', 'wphave');
			$content .=
				'<li><strong>' .
				esc_html($finding['domain']) .
				'</strong> (' .
				esc_html($type) .
				')</li>';
		}

		$content .= '</ul>';
		$content .=
			'<p>' .
			esc_html__(
				'Open the WPHAVE Privacy settings to assign consent categories or review sensitive services.',
				'wphave',
			) .
			'</p>';

		$message = wphave_build_email_template([
			'title' => __('Privacy scan findings', 'wphave'),
			'description' => sprintf(
				/* translators: %s: site URL. */
				__(
					'The automatic privacy scan for %s found services that should be reviewed.',
					'wphave',
				),
				esc_html(home_url('/')),
			),
			'content' => $content,
			'footer_content' => esc_html__(
				'This notification was generated automatically by WPHAVE Privacy.',
				'wphave',
			),
		]);

		if (wp_mail($settings['email'], $subject, $message, wphave_email_template_headers())) {
			update_option(self::NOTIFIED_OPTION, $hashes, false);
		}
	}

	/**
	 * Return actionable findings.
	 *
	 * @param array $results Results.
	 * @return array Return actionable findings.
	 */

	protected static function get_actionable_findings(array $results): array {
		$services = is_array($results['services'] ?? null) ? $results['services'] : [];

		return array_values(
			array_filter($services, function ($service) {
				$resource_type = sanitize_key($service['resourceType'] ?? 'consent');
				$category = sanitize_key($service['category'] ?? '');

				return $resource_type === 'sensitive' ||
					($resource_type === 'consent' && empty($category));
			}),
		);
	}

	/**
	 * Return finding hashes.
	 *
	 * @param array $findings Findings.
	 * @return array Return finding hashes.
	 */

	protected static function get_finding_hashes(array $findings): array {
		return array_values(array_unique(array_map([__CLASS__, 'get_finding_hash'], $findings)));
	}

	/**
	 * Return finding hash.
	 *
	 * @param array $finding Finding.
	 * @return string Return finding hash.
	 */

	protected static function get_finding_hash(array $finding): string {
		return md5(
			self::normalize_domain($finding['domain'] ?? '') .
				'|' .
				sanitize_key($finding['resourceType'] ?? 'consent'),
		);
	}

	/**
	 * Discover urls.
	 *
	 * @param int $limit Limit.
	 * @return array Discover urls.
	 */

	protected static function discover_urls(int $limit): array {
		$urls = [home_url('/')];

		$post_types = get_post_types(['public' => true], 'names');
		$post_types = array_values(
			array_filter($post_types, function ($post_type) {
				return !in_array($post_type, ['attachment'], true);
			}),
		);

		if ($post_types) {
			$posts = get_posts([
				'post_type' => $post_types,
				'post_status' => 'publish',
				'posts_per_page' => max(0, $limit - 1),
				'orderby' => 'modified',
				'order' => 'DESC',
				'fields' => 'ids',
				'no_found_rows' => true,
			]);

			foreach ($posts as $post_id) {
				$permalink = get_permalink($post_id);

				if ($permalink) {
					$urls[] = $permalink;
				}
			}
		}

		$urls = array_values(
			array_unique(array_filter(array_map([__CLASS__, 'normalize_url'], $urls))),
		);

		return array_slice($urls, 0, $limit);
	}

	/**
	 * Add service entry.
	 *
	 * @param array $services Services.
	 * @param string $domain Domain.
	 * @param string $url Resource URL.
	 * @param string $source Source.
	 * @param string $source_page Source page.
	 * @param array $classification Classification.
	 * @return void
	 */

	protected static function add_service_entry(
		array &$services,
		string $domain,
		string $url,
		string $source,
		string $source_page,
		array $classification,
	): void {
		$saved_category = self::get_saved_category($domain);
		$key = $domain;

		if (!isset($services[$key])) {
			// RESOURCE BUDGET INVARIANT: One bounded HTML page may still contain
			// thousands of distinct domains. Cap durable findings across all pages.
			if (count($services) >= self::MAX_SERVICES) {
				return;
			}
			$services[$key] = [
				'domain' => $domain,
				'category' => $saved_category,
				'suggested' => $classification['suggested'] ?? null,
				'confidence' => $classification['confidence'] ?? 'low',
				'active' => true,
				'sources' => [],
				'urls' => [],
				'pages' => [],
				'resourceType' => $classification['resourceType'] ?? 'consent',
				'detectedBy' => 'scan',
			];
		}

		if ($saved_category && empty($services[$key]['category'])) {
			$services[$key]['category'] = $saved_category;
		}

		if (!in_array($source, $services[$key]['sources'], true)) {
			$services[$key]['sources'][] = $source;
		}

		$diagnostic_url = $url
			? WPHAVE_Security_Redactor::diagnostic_text(
				$url,
				self::MAX_DIAGNOSTIC_URL_LENGTH,
			)
			: '';
		if (
			$diagnostic_url &&
			count($services[$key]['urls']) < self::MAX_SERVICE_REFERENCES &&
			!in_array($diagnostic_url, $services[$key]['urls'], true)
		) {
			$services[$key]['urls'][] = $diagnostic_url;
		}

		$diagnostic_page = WPHAVE_Security_Redactor::diagnostic_text(
			$source_page,
			self::MAX_DIAGNOSTIC_URL_LENGTH,
		);
		if (
			count($services[$key]['pages']) < self::MAX_SERVICE_REFERENCES &&
			!in_array($diagnostic_page, $services[$key]['pages'], true)
		) {
			$services[$key]['pages'][] = $diagnostic_page;
		}
	}
}
