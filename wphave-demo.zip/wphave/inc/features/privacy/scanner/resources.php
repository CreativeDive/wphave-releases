<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Privacy_Scanner_Resources {

/**
     * Scan HTML.
     *
     * @param string $html HTML markup to process.
     * @param string $source_page Source page.
     * @param array $services Services.
     * @return void
     */

	protected static function scan_html( string $html, string $source_page, array &$services ): void {
		self::scan_external_scripts( $html, $source_page, $services );
		self::scan_inline_scripts( $html, $source_page, $services );
		self::scan_iframes( $html, $source_page, $services );
		self::scan_images( $html, $source_page, $services );
		self::scan_links( $html, $source_page, $services );
        self::scan_embeds_and_objects( $html, $source_page, $services );
	}

/**
     * Scan external images as manual-review resources.
     *
     * @param string $html HTML markup to process.
     * @param string $source_page Source page.
     * @param array $services Services.
     * @return void
     */

    protected static function scan_images( string $html, string $source_page, array &$services ): void {
        if ( ! preg_match_all( '/<img\b[^>]*\bsrc\s*=\s*(["\'])(.*?)\1[^>]*>/is', $html, $matches ) ) {
            return;
        }

		foreach ( $matches[2] as $src ) {
			self::add_resource( $services, $src, 'image', $source_page );
		}
	}

/**
     * Scan external scripts.
     *
     * @param string $html HTML markup to process.
     * @param string $source_page Source page.
     * @param array $services Services.
     * @return void
     */

    protected static function scan_external_scripts( string $html, string $source_page, array &$services ): void {
        if ( ! preg_match_all( '/<script\b[^>]*\bsrc\s*=\s*(["\'])(.*?)\1[^>]*>/is', $html, $matches ) ) {
            return;
        }

        foreach ( $matches[2] as $src ) {
            self::add_resource( $services, $src, 'script', $source_page );
        }
    }

/**
     * Scan inline scripts.
     *
     * @param string $html HTML markup to process.
     * @param string $source_page Source page.
     * @param array $services Services.
     * @return void
     */

    protected static function scan_inline_scripts( string $html, string $source_page, array &$services ): void {
        if ( ! preg_match_all( '/<script\b(?![^>]*\bsrc\s*=)(?![^>]*type=["\'](?:application\/ld\+json|application\/json|text\/template)["\'])([^>]*)>(.*?)<\/script>/is', $html, $matches ) ) {
            return;
        }

        foreach ( $matches[2] as $content ) {
            if ( ! is_string( $content ) || trim( $content ) === '' ) {
                continue;
            }

            preg_match_all( '/https?:\/\/[^\s"\'<>]+/i', $content, $url_matches );

            foreach ( $url_matches[0] ?? [] as $url ) {
                self::add_resource( $services, rtrim( $url, ');,\'"' ), 'inline-script', $source_page );
            }

            $keyword = self::detect_inline_keyword( $content );

            if ( $keyword ) {
                self::add_virtual_resource( $services, $keyword['domain'], 'inline-script', $source_page, $keyword['category'], $keyword['confidence'] );
            }
        }
    }

/**
     * Scan iframes.
     *
     * @param string $html HTML markup to process.
     * @param string $source_page Source page.
     * @param array $services Services.
     * @return void
     */

    protected static function scan_iframes( string $html, string $source_page, array &$services ): void {
        if ( ! preg_match_all( '/<iframe\b[^>]*\bsrc\s*=\s*(["\'])(.*?)\1[^>]*>/is', $html, $matches ) ) {
            return;
        }

        foreach ( $matches[2] as $src ) {
            self::add_resource( $services, $src, 'iframe', $source_page );
        }
    }

/**
     * Scan links.
     *
     * @param string $html HTML markup to process.
     * @param string $source_page Source page.
     * @param array $services Services.
     * @return void
     */

    protected static function scan_links( string $html, string $source_page, array &$services ): void {
        if ( ! preg_match_all( '/<link\b([^>]*)\bhref\s*=\s*(["\'])(.*?)\2([^>]*)>/is', $html, $matches, PREG_SET_ORDER ) ) {
            return;
        }

        $tracked_rels = [ 'stylesheet', 'preload', 'modulepreload', 'preconnect', 'dns-prefetch' ];

        foreach ( $matches as $match ) {
            $attrs = strtolower( $match[1] . ' ' . $match[4] );
            $href  = $match[3];
            $rel   = '';

            if ( preg_match( '/\brel\s*=\s*(["\'])(.*?)\1/i', $attrs, $rel_match ) ) {
                $rel = strtolower( trim( $rel_match[2] ) );
            }

            $rel_values = preg_split( '/\s+/', $rel );

            if ( ! array_intersect( $tracked_rels, $rel_values ?: [] ) ) {
                continue;
            }

            self::add_resource( $services, $href, in_array( 'stylesheet', $rel_values ?: [], true ) ? 'stylesheet' : 'resource-hint', $source_page );
        }
    }

/**
     * Scan embeds and objects.
     *
     * @param string $html HTML markup to process.
     * @param string $source_page Source page.
     * @param array $services Services.
     * @return void
     */

    protected static function scan_embeds_and_objects( string $html, string $source_page, array &$services ): void {
        if ( preg_match_all( '/<(embed|source)\b[^>]*\bsrc\s*=\s*(["\'])(.*?)\2[^>]*>/is', $html, $matches ) ) {
            foreach ( $matches[3] as $src ) {
                self::add_resource( $services, $src, 'embed', $source_page );
            }
        }

        if ( preg_match_all( '/<object\b[^>]*\bdata\s*=\s*(["\'])(.*?)\1[^>]*>/is', $html, $matches ) ) {
            foreach ( $matches[2] as $src ) {
                self::add_resource( $services, $src, 'object', $source_page );
            }
        }
    }

/**
     * Add resource.
     *
     * @param array $services Services.
     * @param string $raw_url Raw URL.
     * @param string $source Source.
     * @param string $source_page Source page.
     * @return void
     */

    protected static function add_resource( array &$services, string $raw_url, string $source, string $source_page ): void {
        $url = self::normalize_resource_url( $raw_url, $source_page );

        if ( ! $url || ! self::is_external_url( $url ) ) {
            return;
        }

        $domain = self::domain_from_url( $url );

        if ( ! $domain || self::is_ignored_domain( $domain ) ) {
            return;
        }

        $classification = self::classify_domain( $domain, $source, $url );
        self::add_service_entry( $services, $domain, $url, $source, $source_page, $classification );
    }

/**
     * Add virtual resource.
     *
     * @param array $services Services.
     * @param string $domain Domain.
     * @param string $source Source.
     * @param string $source_page Source page.
     * @param string $suggested Suggested.
     * @param string $confidence Confidence.
     * @return void
     */

    protected static function add_virtual_resource( array &$services, string $domain, string $source, string $source_page, string $suggested, string $confidence ): void {
        $domain = self::normalize_domain( $domain );

        if ( ! $domain || self::is_ignored_domain( $domain ) ) {
            return;
        }

        self::add_service_entry( $services, $domain, '', $source, $source_page, [
            'suggested'    => $suggested,
            'confidence'   => $confidence,
            'resourceType' => 'consent',
        ] );
    }

/**
     * Normalize resource url.
     *
     * @param string $raw_url Raw URL.
     * @param string $base_url Base URL.
     * @return string Normalize resource url.
     */

    protected static function normalize_resource_url( string $raw_url, string $base_url ): string {
        $raw_url = html_entity_decode( trim( $raw_url ), ENT_QUOTES );

        if ( $raw_url === '' || str_starts_with( $raw_url, 'data:' ) || str_starts_with( $raw_url, 'mailto:' ) || str_starts_with( $raw_url, 'tel:' ) || str_starts_with( $raw_url, '#' ) ) {
            return '';
        }

        if ( str_starts_with( $raw_url, '//' ) ) {
            return ( is_ssl() ? 'https:' : 'http:' ) . $raw_url;
        }

        if ( preg_match( '/^https?:\/\//i', $raw_url ) ) {
            return esc_url_raw( $raw_url );
        }

        return esc_url_raw( wp_make_link_relative( $raw_url ) === $raw_url ? self::absolute_url( $raw_url, $base_url ) : $raw_url );
    }

/**
     * Absolute url.
     *
     * @param string $path Path.
     * @param string $base_url Base URL.
     * @return string Absolute url.
     */

    protected static function absolute_url( string $path, string $base_url ): string {
        $base = wp_parse_url( $base_url );

        if ( ! is_array( $base ) || empty( $base['scheme'] ) || empty( $base['host'] ) ) {
            return '';
        }

        if ( str_starts_with( $path, '/' ) ) {
            return $base['scheme'] . '://' . $base['host'] . $path;
        }

        $dir = isset( $base['path'] ) ? trailingslashit( dirname( $base['path'] ) ) : '/';
        return $base['scheme'] . '://' . $base['host'] . $dir . $path;
    }

/**
     * Determine whether external url.
     *
     * @param string $url Resource URL.
     * @return bool Determine whether external url.
     */

    protected static function is_external_url( string $url ): bool {
        $host = wp_parse_url( $url, PHP_URL_HOST );

        if ( ! $host ) {
            return false;
        }

        $host = self::normalize_domain( $host );
        $site = self::normalize_domain( wp_parse_url( home_url(), PHP_URL_HOST ) );

        if ( ! $host || $host === $site || self::is_ignored_domain( $host ) ) {
            return false;
        }

        return ! str_contains( $host, 'localhost' ) && ! str_ends_with( $host, '.local' );
    }

/**
     * Determine whether a hostname belongs to technical web standards metadata.
     *
     * These URLs commonly occur in SVG/XML namespaces and schema declarations.
     * They identify a vocabulary and do not cause a browser request by themselves.
     *
     * @param string $domain Domain.
     * @return bool Whether the domain must be excluded from service findings.
     */

    protected static function is_ignored_domain( string $domain ): bool {
        $domain = self::normalize_domain( $domain );

        foreach ( [ 'w3.org' ] as $ignored_domain ) {
            if ( $domain === $ignored_domain || str_ends_with( $domain, '.' . $ignored_domain ) ) {
                return true;
            }
        }

        return false;
    }

}
