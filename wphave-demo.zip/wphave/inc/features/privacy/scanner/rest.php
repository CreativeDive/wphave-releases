<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Privacy_Scanner_REST {

/**
     * Register the privacy scanner REST routes.
     *
     * @return void
     */

    public static function register_rest_routes(): void {
		if ( self::$routes_registered ) {
			return;
		}

		self::$routes_registered = true;

        register_rest_route( 'wphave/v1', '/privacy-scan/start', [
            'methods'             => 'POST',
            'callback'            => [ __CLASS__, 'rest_start_scan' ],
            'permission_callback' => [ __CLASS__, 'can_manage' ],
            'args'                => [
                'limit' => [
                    'sanitize_callback' => 'absint',
                    'default'           => self::DEFAULT_LIMIT,
                ],
            ],
        ] );

        register_rest_route( 'wphave/v1', '/privacy-scan/status', [
            'methods'             => 'GET',
            'callback'            => [ __CLASS__, 'rest_get_status' ],
			'permission_callback' => [ __CLASS__, 'can_view' ],
        ] );

        register_rest_route( 'wphave/v1', '/privacy-scan/process', [
            'methods'             => 'POST',
            'callback'            => [ __CLASS__, 'rest_process_scan' ],
            'permission_callback' => [ __CLASS__, 'can_manage' ],
        ] );

        register_rest_route( 'wphave/v1', '/privacy-scan/results', [
            'methods'             => 'GET',
            'callback'            => [ __CLASS__, 'rest_get_results' ],
			'permission_callback' => [ __CLASS__, 'can_view' ],
        ] );

        register_rest_route( 'wphave/v1', '/privacy-scan/overview', [
            'methods'             => 'GET',
            'callback'            => [ __CLASS__, 'rest_get_overview' ],
			'permission_callback' => [ __CLASS__, 'can_view' ],
        ] );
    }

/**
     * Determine whether the current user can manage privacy scanner.
     *
     * @return bool Determine whether the current user can manage privacy scanner.
     */

    public static function can_manage(): bool {
		return self::can_view();
    }

/**
     * Determine whether the current user may inspect existing scan state.
     *
     * @return bool Whether privacy management capabilities are available.
     */

	public static function can_view(): bool {
		// PRIVACY INVARIANT: Scan status and results describe installed services and
		// visited site URLs. They are administrative diagnostics and never become
		// public merely because the scanner itself fetches public frontend pages.
		return current_user_can( 'manage_options' ) || current_user_can( 'wphave_manage_settings_privacy' );
    }

	private static function require_scan_access() {
		// AUTHORIZATION INVARIANT: Scanner callbacks expose visited URLs, detected
		// services and background-job state or can schedule privileged HTTP work.
		// Every public callback repeats the Privacy policy beyond REST dispatch.
		if ( ! self::can_view() ) {
			return new WP_Error(
				'wphave_privacy_scan_forbidden',
				__( 'You are not allowed to access Privacy Scanner data.', 'wphave' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

/**
     * Handle the start scan REST request.
     *
     * @param WP_REST_Request $request REST request.
     */

    public static function rest_start_scan( WP_REST_Request $request ) {
		$authorization = self::require_scan_access();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

        $limit = absint( $request->get_param( 'limit' ) );
        $status = self::start_scan_job(
			$limit,
			false,
			static function() {
				return self::require_scan_access();
			}
		);

		if ( is_wp_error( $status ) ) {
			return $status;
		}

        return rest_ensure_response( $status );
    }

/**
     * Handle the get status REST request.
     */

    public static function rest_get_status() {
		$authorization = self::require_scan_access();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

        $synchronized = self::sync_cron_schedule(
			static function() {
				return self::require_scan_access();
			}
		);

		if ( is_wp_error( $synchronized ) ) {
			return $synchronized;
		}

        $status = self::get_status();

		// AUTHORIZATION/PRIVACY-SCAN-STATUS-RESPONSE INVARIANT: Schedule
		// reconciliation and status/automation projection cross option, Cron and
		// entitlement boundaries. Revalidate Privacy authority immediately before
		// releasing operational state, configured notification identity or timing.
		$authorization = self::require_scan_access();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

        return rest_ensure_response( $status );
    }

/**
     * Handle the process scan REST request.
     */

    public static function rest_process_scan() {
		$authorization = self::require_scan_access();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

        $status = self::process_scan_batch(
			static function() {
				return self::require_scan_access();
			}
		);

		if ( is_wp_error( $status ) ) {
			return $status;
		}

		$authorization = self::require_scan_access();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

        return rest_ensure_response( $status );
    }

/**
     * Handle the get results REST request.
     */

    public static function rest_get_results() {
		$authorization = self::require_scan_access();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$results = self::get_results();
		$has_pro_access = function_exists( 'wphave_privacy_has_pro_access' ) && wphave_privacy_has_pro_access();

		if( ! $has_pro_access ) {
			$total = count( $results['services'] );
			$results['services'] = array_slice( $results['services'], 0, 1 );
			$results['access'] = [
				'limited' => true,
				'totalFindings' => $total,
				'hiddenFindings' => max( 0, $total - 1 ),
			];
		}

		// AUTHORIZATION/PRIVACY-SCAN-RESULT-RESPONSE INVARIANT: Stored findings,
		// domain normalization and entitlement shaping cross option and extension
		// boundaries after callback admission. Revalidate the canonical Privacy
		// policy after the complete projection and immediately before disclosure.
		$authorization = self::require_scan_access();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

        return rest_ensure_response( $results );
    }

/**
     * Return the complete read snapshot required when the Privacy workspace mounts.
     *
     * Each projection keeps its canonical callback so access shaping and status
     * recovery cannot drift between the composed and legacy routes.
     */

    public static function rest_get_overview() {
		$authorization = self::require_scan_access();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

        $projections = array();
        $errors = array();

        foreach( array( 'results' => 'rest_get_results', 'status' => 'rest_get_status' ) as $projection => $callback ) {
            $response = call_user_func( array( __CLASS__, $callback ) );

            if( is_wp_error( $response ) ) {
                $error_data = $response->get_error_data();
                $errors[$projection] = array(
                    'code' => $response->get_error_code(),
                    'message' => $response->get_error_message(),
                    'status' => is_array( $error_data ) ? (int) ( $error_data['status'] ?? 500 ) : 500,
                );
                continue;
            }

            $projections[$projection] = $response instanceof WP_REST_Response
                ? $response->get_data()
                : $response;
        }

		// AUTHORIZATION/PRIVACY-SCAN-OVERVIEW-RESPONSE INVARIANT: Successful
		// sub-projections remain private even if a later projection observes revoked
		// authority. Revalidate the shared Privacy policy after composition and
		// before releasing either retained data or internal error structure.
		$authorization = self::require_scan_access();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

        return rest_ensure_response( array(
            'projections' => $projections,
            'errors' => $errors,
        ) );
    }

}
