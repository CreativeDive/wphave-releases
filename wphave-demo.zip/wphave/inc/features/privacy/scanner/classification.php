<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Privacy_Scanner_Classification {

/**
     * Return saved category.
     *
     * @param string $domain Domain.
     * @return ?string Return saved category.
     */

    protected static function get_saved_category( string $domain ): ?string {
        if ( ! class_exists( 'WPHAVE_Consent_Config' ) ) {
            return null;
        }

        $config = new WPHAVE_Consent_Config();

        foreach ( $config->get_services() as $service ) {
            if ( empty( $service['domain'] ) || empty( $service['category'] ) ) {
                continue;
            }

            $service_domain = self::normalize_domain( $service['domain'] );

            if ( $domain === $service_domain || str_ends_with( $domain, '.' . $service_domain ) ) {
                return sanitize_key( $service['category'] );
            }
        }

        return null;
    }

/**
     * Classify domain.
     *
     * @param string $domain Domain.
     * @param string $source Source.
     * @param string $url Resource URL.
     * @return array Classify domain.
     */

	protected static function classify_domain( string $domain, string $source, string $url ): array {
		$domain = strtolower( $domain );
		$url    = strtolower( $url );

		if ( in_array( $source, [ 'stylesheet', 'resource-hint', 'embed', 'object', 'image' ], true ) ) {
			return [
				'suggested'    => null,
				'confidence'   => 'medium',
				'resourceType' => 'sensitive',
			];
		}

        $analytics = [
            'googletagmanager.com',
            'google-analytics.com',
            'analytics.google.com',
            'stats.g.doubleclick.net',
            'matomo',
            'plausible.io',
            'plausible',
            'fathom',
            'hotjar.com',
            'clarity.ms',
        ];

        $marketing = [
            'facebook.net',
            'facebook.com',
            'connect.facebook.net',
            'doubleclick.net',
            'googleadservices.com',
            'googlesyndication.com',
            'ads.linkedin.com',
            'snap.licdn.com',
            'pinterest.com',
            'tiktok.com',
            'twitter.com',
            'x.com',
            't.co',
            'youtube.com',
            'youtu.be',
            'vimeo.com',
            'instagram.com',
            'spotify.com',
        ];

        $sensitive = [
            'googleapis.com',
            'gstatic.com',
            'fonts.googleapis.com',
            'fonts.gstatic.com',
            'jsdelivr.net',
            'unpkg.com',
            'cdnjs.cloudflare.com',
        ];

        foreach ( $analytics as $needle ) {
            if ( str_contains( $domain, $needle ) || str_contains( $url, $needle ) ) {
                return [
                    'suggested'    => 'analytics',
                    'confidence'   => 'high',
                    'resourceType' => 'consent',
                ];
            }
        }

        foreach ( $marketing as $needle ) {
            if ( str_contains( $domain, $needle ) || str_contains( $url, $needle ) ) {
                return [
                    'suggested'    => 'marketing',
                    'confidence'   => 'high',
                    'resourceType' => 'consent',
                ];
            }
        }

        foreach ( $sensitive as $needle ) {
            if ( str_contains( $domain, $needle ) || str_contains( $url, $needle ) ) {
                return [
                    'suggested'    => null,
                    'confidence'   => 'medium',
                    'resourceType' => 'sensitive',
                ];
            }
        }

        return [
            'suggested'    => null,
            'confidence'   => $source === 'script' || $source === 'inline-script' || $source === 'iframe' ? 'medium' : 'low',
            'resourceType' => 'consent',
        ];
    }

/**
     * Detect inline keyword.
     *
     * @param string $content Content to process.
     * @return ?array Detect inline keyword.
     */

    protected static function detect_inline_keyword( string $content ): ?array {
        if ( preg_match( '/\bgtag\s*\(|\bdataLayer\s*\.\s*push\s*\(/i', $content ) ) {
            return [
                'domain'     => 'googletagmanager.com',
                'category'   => 'analytics',
                'confidence' => 'medium',
            ];
        }

        if ( preg_match( '/\bfbq\s*\(/i', $content ) ) {
            return [
                'domain'     => 'facebook.net',
                'category'   => 'marketing',
                'confidence' => 'medium',
            ];
        }

        if ( preg_match( '/\b_paq\s*\.\s*push\s*\(/i', $content ) ) {
            return [
                'domain'     => 'matomo',
                'category'   => 'analytics',
                'confidence' => 'medium',
            ];
        }

        if ( preg_match( '/\bhj\s*\(/i', $content ) ) {
            return [
                'domain'     => 'hotjar.com',
                'category'   => 'analytics',
                'confidence' => 'medium',
            ];
        }

        if ( preg_match( '/\bclarity\s*\(/i', $content ) ) {
            return [
                'domain'     => 'clarity.ms',
                'category'   => 'analytics',
                'confidence' => 'medium',
            ];
        }

        return null;
    }

/**
     * Domain from url.
     *
     * @param string $url Resource URL.
     * @return string Domain from url.
     */

    protected static function domain_from_url( string $url ): string {
        return self::normalize_domain( wp_parse_url( $url, PHP_URL_HOST ) );
    }

/**
     * Normalize domain.
     *
     * @param string $domain Domain.
     * @return string Normalize domain.
     */

    protected static function normalize_domain( $domain ): string {
        $domain = strtolower( trim( (string) $domain ) );
        $domain = preg_replace( '/^www\./', '', $domain );
        $domain = preg_replace( '/:\d+$/', '', $domain );

        return $domain;
    }

/**
     * Normalize url.
     *
     * @param string $url Resource URL.
     * @return string Normalize url.
     */

    protected static function normalize_url( $url ): string {
        $url = esc_url_raw( (string) $url );

        if ( ! $url ) {
            return '';
        }

        return strtok( $url, '#' );
    }

}
