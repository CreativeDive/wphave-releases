<?php

require_once __DIR__ . '/../public-scan-context.php';

require_once wphave_dir() . 'inc/features/security/boundaries/index.php';
require_once wphave_dir() . 'inc/background-jobs/lock.php';
require_once __DIR__ . '/rest.php';
require_once __DIR__ . '/workflow.php';
require_once __DIR__ . '/scheduler.php';
require_once __DIR__ . '/resources.php';
require_once __DIR__ . '/classification.php';

/**
 * WPHAVE Privacy Scanner
 *
 * Scans public site URLs for external scripts, embeds and privacy-relevant
 * resources so admins can map services to consent categories.
 */

if (!defined('ABSPATH')) {
	exit();
}

class WPHAVE_Privacy_Scanner {
	use WPHAVE_Privacy_Scanner_REST,
		WPHAVE_Privacy_Scanner_Workflow,
		WPHAVE_Privacy_Scanner_Scheduler,
		WPHAVE_Privacy_Scanner_Resources,
		WPHAVE_Privacy_Scanner_Classification;

	const RESULTS_OPTION = 'wphave_privacy_scan_results';
	const STATUS_OPTION = 'wphave_privacy_scan_status';
	const JOB_OPTION = 'wphave_privacy_scan_job';
	const CRON_HOOK = 'wphave_privacy_scan_cron';
	const SCHEDULE_OPTION = 'wphave_privacy_scan_schedule';
	const NOTIFIED_OPTION = 'wphave_privacy_scan_notified_findings';
	const LOCK_OPTION = 'wphave_privacy_scan_lock';
	const AUTOMATION_LOCK_OPTION = 'wphave_privacy_scan_automation_lock';
	const DEFAULT_LIMIT = 200;
	const MAX_LIMIT = 200;
	const MAX_SCAN_TIME = 25;
	const BATCH_SIZE = 5;
	const MAX_RESPONSE_BYTES = 2 * MB_IN_BYTES;
	private static bool $routes_registered = false;

	/**
	 * Initialize the privacy scanner feature.
	 *
	 * @return void
	 */

	public static function init(): void {
		// RUNTIME INVARIANT: privacy/management.php exclusively owns scanner REST
		// discovery. The scanner engine itself is shared with Cron automation.
		if (
			is_admin() ||
			wp_doing_cron() ||
			(defined('REST_REQUEST') && REST_REQUEST) ||
			(defined('WP_CLI') && WP_CLI)
		) {
			add_action('init', [__CLASS__, 'sync_cron_schedule']);
			add_action('init', [__CLASS__, 'recover_interrupted_scan'], 20);
		}
		add_action(self::CRON_HOOK, [__CLASS__, 'run_scheduled_scan'], 10, 1);
	}
}

WPHAVE_Privacy_Scanner::init();
