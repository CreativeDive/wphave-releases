<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Privacy_Scanner_Scheduler {
	/**
	 * Sync cron schedule.
	 *
	 * @param callable|null $commit_guard Optional request-context authorization guard.
	 * @return true|WP_Error
	 */

	public static function sync_cron_schedule($commit_guard = null) {
		// LIFECYCLE INVARIANT: WordPress action dispatch may supply an empty hook
		// argument. Only an explicit callable from the REST adapter is a commit guard;
		// incidental hook payloads never alter lifecycle reconciliation semantics.
		$commit_guard = is_callable($commit_guard) ? $commit_guard : null;
		$settings = self::get_scan_settings();
		$schedule = self::cron_schedule_from_frequency($settings['frequency']);
		$has_pro_access =
			function_exists('wphave_privacy_has_pro_access') && wphave_privacy_has_pro_access();

		if ($commit_guard) {
			// AUTHORIZATION/PRIVACY-SCAN-SCHEDULE-COMMIT INVARIANT: A status request
			// may reconcile executable Cron state only while it retains the canonical
			// Privacy policy after complete settings, entitlement and time projection.
			// Init and Cron callers omit this request-only guard and retain lifecycle
			// ownership independent of an interactive user session.
			$authorization = call_user_func($commit_guard);

			if (is_wp_error($authorization)) {
				return $authorization;
			}
		}

		WPHAVE_Background_Job_Scheduler::sync_recurring(
			self::CRON_HOOK,
			self::SCHEDULE_OPTION,
			$has_pro_access && !empty($settings['auto_enabled']),
			$schedule,
			self::next_time_window_timestamp($settings['time_window']),
			$settings['time_window'],
			true,
		);

		if (!$has_pro_access || empty($settings['auto_enabled'])) {
			if ($commit_guard) {
				$authorization = call_user_func($commit_guard);

				if (is_wp_error($authorization)) {
					return $authorization;
				}
			}

			$automation_lock = self::acquire_automation_lock();

			if ($automation_lock) {
				try {
					self::cancel_scheduled_job();
				} finally {
					self::release_automation_lock($automation_lock);
				}
			}
		}

		return true;
	}

	/**
	 * Run scheduled scan.
	 *
	 * @param mixed $mode Mode.
	 * @return void
	 */

	public static function run_scheduled_scan($mode = 'start'): void {
		$automation_lock = self::acquire_automation_lock();

		if (!$automation_lock) {
			return;
		}

		try {
			self::run_scheduled_scan_unlocked($mode);
		} finally {
			self::release_automation_lock($automation_lock);
		}
	}

	/** Run the scheduled workflow while this worker owns automation. */

	private static function run_scheduled_scan_unlocked($mode): void {
		if (
			false !== get_option(self::START_CHECKPOINT_OPTION, false) &&
			!self::recover_failed_start()
		) {
			// RECOVERY INVARIANT: Cron cannot run or announce a new scan while
			// the previous confirmed result still awaits rollback.
			return;
		}
		if (!function_exists('wphave_privacy_has_pro_access') || !wphave_privacy_has_pro_access()) {
			self::cancel_scheduled_job();
			return;
		}

		$settings = self::get_scan_settings();

		if (empty($settings['auto_enabled'])) {
			self::cancel_scheduled_job();
			return;
		}

		$job = self::get_resumable_scan_job();
		if (is_array($job) && !empty($job['scheduled']) && !self::is_recoverable_scheduled_job($job)) {
			// RECOVERY INVARIANT: A Cron-owned job without a usable cursor or
			// queue cannot advance. Cancel it instead of scheduling an endless
			// no-progress continuation; retry cancellation if its status write fails.
			if (!self::cancel_scheduled_job()) {
				WPHAVE_Background_Job_Scheduler::ensure_continuation(
					self::CRON_HOOK,
					['continue'],
					MINUTE_IN_SECONDS,
				);
			}
			return;
		}
		if (!self::continuation_can_run($mode, $job)) {
			wp_clear_scheduled_hook(self::CRON_HOOK, ['continue']);
			return;
		}

		$status = self::get_status();

		if (self::is_recoverable_scheduled_job($job)) {
			$expected_status = self::status_from_scan_job($job);
			$needs_reconciliation = false;
			foreach ($expected_status as $key => $value) {
				if (($status[$key] ?? null) !== $value) {
					$needs_reconciliation = true;
					break;
				}
			}
			if ($needs_reconciliation) {
				// RECOVERY INVARIANT: A verified Cron-owned job outlives a filtered
				// status write. Reconstruct only its status projection and acknowledge
				// that write before running another batch or sending a notification.
				if (!self::persist_scan_option(self::STATUS_OPTION, $expected_status)) {
					self::recover_scheduled_job();
					return;
				}
				$status = $expected_status;
			}
		} else {
			if ($status['state'] === 'running' && empty($status['scheduled'])) {
				return;
			}

			if ($status['state'] !== 'running') {
				$status = self::start_scan_job(self::MAX_LIMIT, true);
				if (is_wp_error($status)) {
					// RECOVERY INVARIANT: A rejected start write cannot become a runner
					// state or authorize notification. A retained Cron job may retry later.
					self::recover_scheduled_job();
					return;
				}
			}
		}

		$status = WPHAVE_Background_Job_Runner::run(
			static fn() => self::process_scan_batch(),
			static fn($state) => is_array($state) && 'running' === ($state['state'] ?? ''),
			static fn($state) => absint($state['processed'] ?? 0),
			self::MAX_SCAN_TIME,
			$status,
		);
		if (is_wp_error($status)) {
			// RECOVERY INVARIANT: A failed batch keeps its job or checkpoint.
			// Schedule another worker before inspecting array-only status fields.
			self::recover_scheduled_job();
			return;
		}

		if ($status['state'] === 'running') {
			WPHAVE_Background_Job_Scheduler::ensure_continuation(
				self::CRON_HOOK,
				['continue'],
				2 * MINUTE_IN_SECONDS,
			);

			return;
		}

		if ($status['state'] === 'complete') {
			self::maybe_send_scan_notification(self::get_results(), $settings);
		}
	}

	/** Restore the continuation of a valid Cron-owned scan after a lost request. */

	public static function recover_interrupted_scan(): void {
		$settings = self::get_scan_settings();
		$has_pro_access =
			function_exists('wphave_privacy_has_pro_access') && wphave_privacy_has_pro_access();

		if (!$has_pro_access || empty($settings['auto_enabled'])) {
			return;
		}

		self::recover_scheduled_job();
	}

	/** Reconcile one future continuation for a structurally valid scheduled job. */

	private static function recover_scheduled_job(): bool {
		$job = self::get_resumable_scan_job();

		if (!self::is_recoverable_scheduled_job($job)) {
			return false;
		}

		// AVAILABILITY INVARIANT: Persisted scheduled work is authoritative even
		// when its transient Cron wake-up was lost. Reconciliation must remain
		// argument-scoped so the independent recurring start event is untouched.
		return WPHAVE_Background_Job_Scheduler::ensure_continuation(
			self::CRON_HOOK,
			['continue'],
			MINUTE_IN_SECONDS,
		);
	}

	/** Decide whether an event has authority to start or resume scanner work. */

	private static function continuation_can_run($mode, $job): bool {
		if ('continue' !== $mode) {
			return true;
		}

		// OWNERSHIP INVARIANT: A continuation carries no authority to create a
		// replacement scan. It may resume only the structurally valid Cron-owned
		// job for which it was scheduled; stale events otherwise terminate safely.
		return self::is_recoverable_scheduled_job($job);
	}

	/** Validate the minimum persisted identity needed by scheduled recovery. */

	private static function is_recoverable_scheduled_job($job): bool {
		return self::is_valid_scan_job($job) && true === $job['scheduled'];
	}

	/** Acquire one owner for scheduled start, continuation and notification work. */

	private static function acquire_automation_lock() {
		return WPHAVE_Background_Job_Lock::acquire(
			self::AUTOMATION_LOCK_OPTION,
			self::MAX_SCAN_TIME + MINUTE_IN_SECONDS,
		);
	}

	/** Cancel persisted automatic work without affecting a manual scan. */

	private static function cancel_scheduled_job(): bool {
		wp_clear_scheduled_hook(self::CRON_HOOK, ['continue']);
		$lock = self::acquire_scan_lock();

		if (!$lock) {
			return false;
		}

		try {
			$job = self::get_resumable_scan_job();

			if (!is_array($job) || empty($job['scheduled'])) {
				return true;
			}

			// OWNERSHIP INVARIANT: Disabling automation revokes only Cron-owned
			// work. A manual scan remains user-owned and must never be discarded by
			// an unrelated scheduler reconciliation.
			// DATA MINIMIZATION INVARIANT: Cancellation may not re-persist unknown
			// fields or raw diagnostics from a filtered legacy status option.
			$status = self::get_status();
			unset($status['automation'], $status['scanId']);
			$status['state'] = 'cancelled';
			$status['startedAt'] = sanitize_text_field($job['startedAt'] ?? '');
			$status['scheduled'] = true;
			$status['finishedAt'] = current_time('mysql');
			if (is_string($job['scanId'] ?? null) && $job['scanId'] !== '') {
				$status['scanId'] = $job['scanId'];
			}
			$status = self::normalize_status($status);

			// RECOVERY INVARIANT: A filtered or failed terminal write cannot erase
			// the Cron-owned job. The next scheduler sync can retry cancellation.
			if (!self::persist_scan_option(self::STATUS_OPTION, $status)) {
				return false;
			}

			delete_option(self::JOB_OPTION);
			delete_option(self::JOB_CHECKPOINT_OPTION);

			return true;
		} finally {
			self::release_scan_lock($lock);
		}
	}

	/** Release scheduled ownership only when this request still owns it. */

	private static function release_automation_lock(string $token): void {
		WPHAVE_Background_Job_Lock::release(self::AUTOMATION_LOCK_OPTION, $token);
	}

	/**
	 * Cron schedule from frequency.
	 *
	 * @param string $frequency Frequency.
	 * @return string Cron schedule from frequency.
	 */

	protected static function cron_schedule_from_frequency(string $frequency): string {
		return WPHAVE_Background_Job_Scheduler::schedule_for_frequency($frequency);
	}

	/**
	 * Return the next preferred scan time in the configured site timezone.
	 *
	 * @param string $time_window Time window.
	 * @return int UTC timestamp.
	 */

	protected static function next_time_window_timestamp(string $time_window): int {
		return WPHAVE_Background_Job_Scheduler::next_time_window($time_window);
	}

	/**
	 * Return automation status.
	 *
	 * @return array Return automation status.
	 */

	protected static function get_automation_status(): array {
		$settings = self::get_scan_settings();
		$next = wp_next_scheduled(self::CRON_HOOK);
		$has_pro_access =
			function_exists('wphave_privacy_has_pro_access') && wphave_privacy_has_pro_access();

		return [
			'enabled' => $has_pro_access && $settings['auto_enabled'],
			'frequency' => $settings['frequency'],
			'timeWindow' => $settings['time_window'],
			'email' => $settings['email'],
			'nextRun' => $has_pro_access && $next ? wp_date('Y-m-d H:i:s', $next) : '',
			'timing' =>
				$has_pro_access && $settings['auto_enabled']
					? WPHAVE_Background_Job_Scheduler::display_timing(self::CRON_HOOK)
					: null,
		];
	}
}
