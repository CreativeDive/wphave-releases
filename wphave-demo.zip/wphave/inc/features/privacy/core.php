<?php

/** Register public scan isolation before frontend or management features load. */
if (!defined('ABSPATH')) {
	exit();
}

require_once __DIR__ . '/public-scan-context.php';
