<?php
/** A short-lived request marker lowers scan requests to anonymous public access. */
if (!defined('ABSPATH')) {
	exit();
}
final class WPHAVE_Privacy_Public_Scan {
	public const QUERY_KEY = 'wphave_public_privacy_scan';
	public const RESPONSE_HEADER = 'X-WPHAVE-Privacy-Scan-Context';
	private const MAX_AGE = 120;

	public static function token(?int $now = null): string {
		$timestamp = (string) ($now ?? time());
		return $timestamp .
			'.' .
			hash_hmac('sha256', 'privacy-public-scan:' . $timestamp, wp_salt('auth'));
	}

	public static function valid_token($value, ?int $now = null): bool {
		if (
			!is_string($value) ||
			!preg_match('/^([0-9]{10})\\.([a-f0-9]{64})$/D', $value, $matches)
		) {
			return false;
		}
		$age = ($now ?? time()) - (int) $matches[1];
		return $age >= 0 &&
			$age <= self::MAX_AGE &&
			hash_equals(self::token((int) $matches[1]), $value);
	}

	public static function request_url(string $url): string {
		return add_query_arg(self::QUERY_KEY, self::token(), $url);
	}

	public static function boot(): void {
		if (
			($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET' ||
			is_admin() ||
			!self::valid_token($_GET[self::QUERY_KEY] ?? null)
		) {
			return;
		}
		// No persistent login/session changes: only this child HTTP request is anonymous.
		$_COOKIE = [];
		unset(
			$_SERVER['HTTP_COOKIE'],
			$_SERVER['HTTP_AUTHORIZATION'],
			$_SERVER['REDIRECT_HTTP_AUTHORIZATION'],
			$_SERVER['PHP_AUTH_USER'],
			$_SERVER['PHP_AUTH_PW'],
		);
		add_filter('determine_current_user', '__return_zero', PHP_INT_MAX);
		wp_set_current_user(0);
		add_filter('show_admin_bar', '__return_false', PHP_INT_MAX);
		add_action(
			'send_headers',
			static function () {
				nocache_headers();
				header(
					self::RESPONSE_HEADER .
						': ' .
						(get_current_user_id() === 0 ? 'anonymous' : 'invalid'),
				);
			},
			PHP_INT_MAX,
		);
	}

	public static function is_public_response($response, string $html): bool {
		if (wp_remote_retrieve_header($response, self::RESPONSE_HEADER) !== 'anonymous') {
			return false;
		}
		$processor = new WP_HTML_Tag_Processor($html);
		while ($processor->next_tag()) {
			if (
				$processor->get_attribute('id') === 'wpadminbar' ||
				($processor->get_tag() === 'BODY' && $processor->has_class('logged-in'))
			) {
				return false;
			}
		}
		return true;
	}
}
add_action('plugins_loaded', [WPHAVE_Privacy_Public_Scan::class, 'boot'], -PHP_INT_MAX);
