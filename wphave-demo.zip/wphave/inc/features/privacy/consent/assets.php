<?php

/**
 * Registration and localization of consent frontend assets.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPHAVE_Consent_Assets {

    protected $config;
    protected $domains;
    protected $detectors;

    /**
     * Initialize the consent assets service.
     *
     * @param WPHAVE_Consent_Config $config Config.
     * @param WPHAVE_Consent_Domain_Resolver $domains Domains.
     * @param WPHAVE_Consent_Detector_Registry $detectors Detectors.
     */

    public function __construct( WPHAVE_Consent_Config $config, WPHAVE_Consent_Domain_Resolver $domains, WPHAVE_Consent_Detector_Registry $detectors ) {
        $this->config    = $config;
        $this->domains   = $domains;
        $this->detectors = $detectors;
    }

    /**
     * Registers and enqueues frontend assets.
     *
     * @return void
     */

    public function enqueue() {
        $privacy = $this->config->get_privacy_root();

        $this->enqueue_cookie_status_assets( $privacy );
        $this->enqueue_consent_assets();
    }

    /**
     * Enqueue cookie status assets.
     *
     * @param mixed $privacy Privacy.
     */

    protected function enqueue_cookie_status_assets( $privacy ) {
        $is_enabled = $privacy['advanced']['cookie_status_enabled'] ?? false;

        $js_path  = 'inc/features/privacy/consent/assets/cookie-status.js';
        $css_path = 'inc/features/privacy/consent/assets/cookie-status.css';

        wp_register_script( 'wphave-cookie-status', wphave_asset_url( $js_path ), [], WPHAVE_Asset_Registry::version( $js_path ), true );
        wp_register_style( 'wphave-cookie-status', wphave_asset_url( $css_path ), [], WPHAVE_Asset_Registry::version( $css_path ), 'all' );

        if ( ! $is_enabled ) {
            return;
        }

        wp_enqueue_script( 'wphave-cookie-status' );
        wp_enqueue_style( 'wphave-cookie-status' );
		wp_enqueue_script( 'wphave-tooltip' );
		wp_enqueue_style( 'wphave-tooltip' );

        $notice = $privacy['advanced']['cookie_status_notice'] ?? '';

        if ( empty( $notice ) ) {
            $notice = esc_html__( 'Your browser has cookies disabled. Some features on this website may not work properly. Please enable cookies in your browser settings.', 'wphave' );
        }

        wp_localize_script( 'wphave-cookie-status', 'WPHAVE_COOKIE_STATUS_DATA', [
            'notice' => wphave_replace( [ "\r", "\n" ], '', $notice ),
			'closeLabel' => __( 'Close cookie warning', 'wphave' ),
        ] );
    }

    /**
     * Enqueue consent assets.
     */

    protected function enqueue_consent_assets() {
        // Consent has to execute early in the head, but it still belongs to the
        // production build. Serving the readable source files here bypasses
        // minification for every visitor and makes release output inconsistent.
        $consent_js = 'build/privacy-consent/bundle.js';
        $embed_css  = 'inc/features/privacy/consent/assets/embed.css';
        $ui_css     = 'inc/features/privacy/consent/assets/ui.css';
        $ui_js      = 'build/privacy-consent-ui/bundle.js';

        wp_register_script( 'wphave-consent', wphave_asset_url( $consent_js ), [], WPHAVE_Asset_Registry::version( $consent_js ), false );
        wp_register_style( 'wphave-consent-embed', wphave_asset_url( $embed_css ), [], WPHAVE_Asset_Registry::version( $embed_css ), 'all' );
        wp_register_style( 'wphave-consent-ui', wphave_asset_url( $ui_css ), [], WPHAVE_Asset_Registry::version( $ui_css ), 'all' );
        wp_register_script( 'wphave-consent-ui', wphave_asset_url( $ui_js ), [], WPHAVE_Asset_Registry::version( $ui_js ), true );

        wp_enqueue_script( 'wphave-consent' );
        wp_enqueue_style( 'wphave-consent-embed' );
        wp_enqueue_style( 'wphave-consent-ui' );
        wp_enqueue_script( 'wphave-consent-ui' );

        wp_localize_script( 'wphave-consent', 'WPHAVE_CONSENT_DATA', [
            'categories' => $this->config->get_categories(),
            'services'   => $this->config->get_services(),
            'serviceMap' => $this->build_service_map(),
            'allowedServiceDomains' => $this->build_allowed_service_domains(),
			'embedBlocking' => $this->config->is_embed_blocking_enabled(),
            'detectors'  => $this->detectors->all(),
        ] );
    }

    /**
     * Build service map.
     */

    protected function build_service_map() {
        $map = [];

        foreach ( $this->config->get_services() as $service ) {
            if ( empty( $service['domain'] ) || empty( $service['category'] ) || ( isset( $service['blockingEnabled'] ) && ! $service['blockingEnabled'] ) ) {
                continue;
            }

            $map[ $this->domains->normalize( $service['domain'] ) ] = $service['category'];
        }

        return $map;
    }

    /**
     * Build domains explicitly allowed to load without consent.
     */

    protected function build_allowed_service_domains() {
        $domains = [];

        foreach ( $this->config->get_services() as $service ) {
            if ( empty( $service['domain'] ) || ! isset( $service['blockingEnabled'] ) || $service['blockingEnabled'] ) {
                continue;
            }

            $domains[] = $this->domains->normalize( $service['domain'] );
        }

        return array_values( array_unique( $domains ) );
    }
}
