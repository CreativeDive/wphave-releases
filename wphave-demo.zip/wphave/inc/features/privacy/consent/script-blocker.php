<?php

/**
 * Consent-aware external and inline script blocking.
 */

if (!defined('ABSPATH')) {
    exit();
}

class WPHAVE_Consent_Script_Blocker {
    protected $config;
    protected $domains;

    /**
     * Initialize the consent script blocker service.
     *
     * @param WPHAVE_Consent_Config $config Config.
     * @param WPHAVE_Consent_Domain_Resolver $domains Domains.
     */

    public function __construct(
        WPHAVE_Consent_Config $config,
        WPHAVE_Consent_Domain_Resolver $domains,
    ) {
        $this->config = $config;
        $this->domains = $domains;
    }

    /**
     * Intercepts WordPress-enqueued scripts before output.
     *
     * @param string $tag Full script tag.
     * @param string $handle Script handle.
     * @param string $src Script source URL.
     * @return string
     */

    public function filter_wp_script_tag($tag, $handle, $src) {
        if (empty($src)) {
            return $tag;
        }

        $domain = $this->domains->get_domain_from_url($src);

        if ($this->domains->is_internal($domain)) {
            return $tag;
        }

        if ($this->domains->is_sensitive($domain)) {
            return $tag;
        }

        // Preserve script metadata through the same parser used for final HTML.
        return $this->process_external_scripts($tag);
    }

    /**
     * Processes static external scripts in final HTML.
     *
     * @param string $html HTML.
     * @return string
     */

    public function process_external_scripts($html) {
        $processor = new WP_HTML_Tag_Processor($html);

        /*
         * Script attributes may contain quoted characters that are unsafe to
         * parse with regular expressions. The HTML processor updates the actual
         * element while retaining harmless attributes such as async or defer.
         */

        while ($processor->next_tag('script')) {
            $src = $processor->get_attribute('src');

            if (!is_string($src) || !$src || $processor->get_attribute('data-wphave-processed')) {
                continue;
            }

            $domain = $this->domains->get_domain_from_url($src);

            if (!$domain || $this->domains->is_internal($domain)) {
                continue;
            }

            if ($this->domains->is_sensitive($domain)) {
                continue;
            }

            $category = $this->domains->resolve_category($domain);

            // CONSENT INVARIANT: Blocking must not turn approved modules into classic scripts.
            $original_type = $processor->get_attribute('type');
            if (is_string($original_type) && $original_type !== '') {
                $processor->set_attribute('data-wphave-script-type', $original_type);
            }
            $processor->set_attribute('type', 'text/plain');
            $processor->set_attribute('data-consent', $category ?: 'unknown');
            $processor->set_attribute('data-wphave-processed', '1');
            $processor->set_attribute('data-src', esc_url_raw($src));
            $processor->remove_attribute('src');
        }

        return $processor->get_updated_html();
    }

    /**
     * Processes inline scripts that contain tracking or dynamic external calls.
     *
     * @param string $html HTML.
     * @return string
     */

    public function process_inline_scripts($html) {
        return preg_replace_callback(
            '/<script\b(?![^>]*type=["\']text\/plain["\'])([^>]*)>(.*?)<\/script>/is',
            function ($matches) {
                $full_tag = $matches[0];
                $attrs = $matches[1];
                $content = $matches[2];

                if (preg_match('/\bsrc\s*=/i', $attrs)) {
                    return $full_tag;
                }

                if ($this->is_processed_html($full_tag)) {
                    return $full_tag;
                }

                $processor = new WP_HTML_Tag_Processor($full_tag);
                $processor->next_tag('script');
                $original_type = $processor->get_attribute('type');
                // CONSENT INVARIANT: Inert JSON/data blocks must never become executable scripts.
                if (
                    is_string($original_type) &&
                    !in_array(
                        strtolower(trim($original_type)),
                        ['', 'module', 'text/javascript', 'application/javascript'],
                        true,
                    )
                ) {
                    return $full_tag;
                }

                $category = $this->detect_inline_category($content);

                if (!$category) {
                    return $full_tag;
                }

                return $this->build_blocked_script_tag([
                    'category' => $category,
                    'inline' => $content,
                    'type' => is_string($original_type) ? $original_type : '',
                ]);
            },
            $html,
        );
    }

    /**
     * Builds a blocked non-executable script placeholder.
     *
     * @param array $script Script config.
     * @return string
     */

    protected function build_blocked_script_tag($script) {
        $category = $script['category'] ?? 'unknown';

        $attrs =
            ' type="text/plain" data-consent="' .
            esc_attr($category) .
            '" data-wphave-processed="1"';

        if (!empty($script['type'])) {
            $attrs .= ' data-wphave-script-type="' . esc_attr($script['type']) . '"';
        }

        if (!empty($script['src'])) {
            return '<script' . $attrs . ' data-src="' . esc_url($script['src']) . '"></script>';
        }

        if (!empty($script['inline'])) {
            /*
             * Even text/plain script elements follow HTML's raw-text parsing
             * rules. Neutralize every case variant so inline source cannot end
             * the placeholder and append arbitrary markup.
             */

            $inline = preg_replace('/<\/script/i', '<\/script', (string) $script['inline']);

            return '<script' . $attrs . '>' . $inline . '</script>';
        }

        return '';
    }

    /**
     * Detects whether inline script content should be blocked and which category.
     *
     * @param string $content Inline JS.
     * @return string|null
     */

    protected function detect_inline_category($content) {
        $has_gtag = preg_match('/gtag\s*\(/i', $content);
        $has_fbq = preg_match('/fbq\s*\(/i', $content);
        $has_fetch = preg_match('/fetch\s*\(/i', $content);
        $has_image =
            preg_match('/new\s+image\s*\(/i', $content) && preg_match('/\.src\s*=\s*/i', $content);
        $has_script = preg_match('/createelement\s*\(\s*[\'\"]script[\'\"]\s*\)/i', $content);
        $has_url = preg_match('/https?:\/\//i', $content);

        if ($has_gtag) {
            return $this->domains->resolve_category('googletagmanager.com') ?: 'unknown';
        }

        if ($has_fbq) {
            return $this->domains->resolve_category('facebook.net') ?: 'unknown';
        }

        if (!(($has_fetch || $has_image || $has_script) && $has_url)) {
            return null;
        }

        preg_match_all('/https?:\/\/[^\s"\']+/i', $content, $url_matches);
        $urls = $url_matches[0] ?? [];

        foreach ($urls as $url) {
            $url = rtrim($url, ');,"\'');
            $domain = $this->domains->get_domain_from_url($url);

            if (!$domain || $this->domains->is_internal($domain)) {
                continue;
            }

            if ($this->domains->is_sensitive($domain)) {
                continue;
            }

            $category = $this->domains->resolve_category($domain);

            if ($category) {
                return $category;
            }
        }

        return 'unknown';
    }

    /**
     * Checks whether an HTML snippet has already been processed.
     *
     * @param string $html HTML.
     * @return bool
     */

    protected function is_processed_html($html) {
        return strpos($html, 'data-wphave-processed') !== false;
    }
}
