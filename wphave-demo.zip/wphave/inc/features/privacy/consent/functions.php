<?php
/**
 * Bootstrap the modular WPHAVE consent system.
 *
 * Keep the dependency order explicit: lower-level configuration and detection
 * services must exist before the manager composes and registers them.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/domain-resolver.php';
require_once __DIR__ . '/detector-registry.php';
require_once __DIR__ . '/script-blocker.php';
require_once __DIR__ . '/embed-blocker.php';
require_once __DIR__ . '/html-processor.php';
require_once __DIR__ . '/assets.php';
require_once __DIR__ . '/renderer.php';
require_once __DIR__ . '/custom-scripts.php';
require_once __DIR__ . '/manager.php';

WPHAVE_Consent_Manager::instance();

/**
 * Register the detector rules shipped with WPHAVE.
 *
 * The init hook lets third-party code extend or replace detector state before
 * rendered output enters the consent processing pipeline.
 *
 * @return void
 */

function wphave_register_default_consent_detectors() {
    $manager = WPHAVE_Consent_Manager::instance();

    if ( ! $manager->is_enabled() ) {
        return;
    }

    $manager->register_detector( [ 'type' => 'domain',  'value' => 'googletagmanager.com', 'category' => 'analytics' ] );
    $manager->register_detector( [ 'type' => 'keyword', 'value' => 'gtag',                 'category' => 'analytics' ] );
    $manager->register_detector( [ 'type' => 'keyword', 'value' => 'fbq',                  'category' => 'marketing' ] );
    $manager->register_detector( [ 'type' => 'keyword', 'value' => 'facebook.net',         'category' => 'marketing' ] );
    $manager->register_detector( [ 'type' => 'keyword', 'value' => 'youtube.com',          'category' => 'marketing' ] );
    $manager->register_detector( [ 'type' => 'domain',  'value' => 'platform.twitter.com', 'category' => 'marketing' ] );
    $manager->register_detector( [ 'type' => 'domain',  'value' => 'twitter.com',          'category' => 'marketing' ] );
    $manager->register_detector( [ 'type' => 'domain',  'value' => 't.co',                 'category' => 'marketing' ] );
    $manager->register_detector( [ 'type' => 'domain',  'value' => 'tiktok.com',           'category' => 'marketing' ] );
    $manager->register_detector( [ 'type' => 'domain',  'value' => 'instagram.com',        'category' => 'marketing' ] );
}

add_action( 'init', 'wphave_register_default_consent_detectors' );

/**
 * Determine whether consent handling is enabled for the current runtime.
 *
 * @return bool Whether the consent manager is active.
 */

function wphave_consent_is_enabled() {
    return WPHAVE_Consent_Manager::instance()->is_enabled();
}

/**
 * Register the external embed providers shipped with WPHAVE.
 *
 * @return void
 */

function wphave_register_default_consent_embeds() {
    $manager = WPHAVE_Consent_Manager::instance();

    if ( ! $manager->is_enabled() ) {
        return;
    }

    $manager->register_embed( [
        'tag'            => 'blockquote',
        'class'          => 'tiktok-embed',
        'domain'         => 'tiktok.com',
        'category'       => 'marketing',
        'script_domains' => [ 'tiktok.com', 'www.tiktok.com' ],
    ] );

    $manager->register_embed( [
        'tag'            => 'blockquote',
        'class'          => 'instagram-media',
        'domain'         => 'instagram.com',
        'category'       => 'marketing',
        'script_domains' => [ 'instagram.com', 'www.instagram.com' ],
    ] );

    $manager->register_embed( [
        'tag'            => 'blockquote',
        'class'          => 'twitter-tweet',
        'domain'         => 'twitter.com',
        'category'       => 'marketing',
        'script_domains' => [ 'twitter.com', 'platform.twitter.com' ],
    ] );
}

add_action( 'init', 'wphave_register_default_consent_embeds' );
