<?php

/**
 * Registry for consent script detectors.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPHAVE_Consent_Detector_Registry {

    protected $detectors = [];

    /**
     * Registers a detection rule.
     *
     * @param array $args Detector config.
     * @return void
     */

    public function register( $args = [] ) {
        $detector = wp_parse_args( $args, [
            'type'     => 'domain',
            'value'    => '',
            'category' => 'marketing',
        ] );

        if ( empty( $detector['value'] ) ) {
            return;
        }

        $this->detectors[] = $detector;
    }

    /**
     * Returns all detector definitions.
     *
     * @return array
     */

    public function all() {
        return $this->detectors;
    }
}
