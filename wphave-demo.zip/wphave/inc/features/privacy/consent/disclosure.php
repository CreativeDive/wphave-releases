<?php

/**
 * Shared visitor information contract. Disclosure never grants runtime consent.
 */
require_once __DIR__ . '/domain-resolver.php';

class WPHAVE_Consent_Disclosure {
    public const TEXT_FIELDS = [
        'provider',
        'purpose',
        'data',
        'recipients',
        'transfers',
        'retention',
    ];
    public const STORAGE_TYPES = ['cookie', 'localStorage', 'sessionStorage', 'other'];

    /** Validate authored metadata without requiring legacy configurations to be complete. */
    public static function validate($entry) {
        if (!is_array($entry)) {
            return self::error();
        }
        foreach (['label', 'description'] as $field) {
            if (
                isset($entry[$field]) &&
                (!is_string($entry[$field]) || strlen($entry[$field]) > 5000)
            ) {
                return self::error();
            }
        }
        if (!isset($entry['disclosure'])) {
            return true;
        }
        $data = $entry['disclosure'];
        if (!is_array($data)) {
            return self::error();
        }
        foreach (array_merge(self::TEXT_FIELDS, ['privacyUrl', 'storageMode']) as $field) {
            if (
                isset($data[$field]) &&
                (!is_string($data[$field]) || strlen($data[$field]) > 5000)
            ) {
                return self::error();
            }
        }
        $url = $data['privacyUrl'] ?? '';
        if (
            $url !== '' &&
            (!filter_var($url, FILTER_VALIDATE_URL) ||
                !in_array(
                    strtolower(wp_parse_url($url, PHP_URL_SCHEME) ?? ''),
                    ['http', 'https'],
                    true,
                ))
        ) {
            return self::error();
        }
        if (!in_array($data['storageMode'] ?? 'unknown', ['unknown', 'none', 'listed'], true)) {
            return self::error();
        }
        $storage = $data['storage'] ?? [];
        if (!is_array($storage) || count($storage) > 50) {
            return self::error();
        }
        foreach ($storage as $item) {
            if (!is_array($item) || !in_array($item['type'] ?? '', self::STORAGE_TYPES, true)) {
                return self::error();
            }
            foreach (['name', 'purpose', 'duration'] as $field) {
                if (
                    isset($item[$field]) &&
                    (!is_string($item[$field]) || strlen($item[$field]) > 2000)
                ) {
                    return self::error();
                }
            }
        }
        return true;
    }

    private static function error() {
        return new WP_Error(
            'wphave_invalid_consent_disclosure',
            __(
                'Service information contains invalid text, storage entries or a privacy URL. Use an HTTP or HTTPS URL.',
                'wphave',
            ),
            ['status' => 400],
        );
    }

    /** Allowlist the public read model: executable script source is never included. */
    public static function normalize(array $entry): array {
        $data = is_array($entry['disclosure'] ?? null) ? $entry['disclosure'] : [];
        $text = static function ($value): string {
            return is_string($value) ? sanitize_textarea_field($value) : '';
        };
        $result = [];
        foreach (self::TEXT_FIELDS as $field) {
            $result[$field] = $text($data[$field] ?? '');
        }
        $result['purpose'] = $result['purpose'] ?: $text($entry['description'] ?? '');
        $url = is_string($data['privacyUrl'] ?? null) ? $data['privacyUrl'] : '';
        $result['privacyUrl'] = preg_match('#^https?://#i', $url)
            ? esc_url_raw($url, ['http', 'https'])
            : '';
        $result['storageMode'] = in_array($data['storageMode'] ?? '', ['none', 'listed'], true)
            ? $data['storageMode']
            : 'unknown';
        $result['storage'] = [];
        foreach (
            is_array($data['storage'] ?? null) ? array_slice($data['storage'], 0, 50) : []
            as $item
        ) {
            if (!is_array($item)) {
                continue;
            }
            $result['storage'][] = [
                'type' => in_array($item['type'] ?? '', self::STORAGE_TYPES, true)
                    ? $item['type']
                    : 'other',
                'name' => $text($item['name'] ?? ''),
                'purpose' => $text($item['purpose'] ?? ''),
                'duration' => $text($item['duration'] ?? ''),
            ];
        }
        return [
            'label' => $text($entry['label'] ?? ($entry['name'] ?? ($entry['domain'] ?? ''))),
            'domain' => $text($entry['domain'] ?? ''),
            'category' => $text($entry['category'] ?? ''),
            'blockingEnabled' =>
                ($entry['resourceType'] ?? '') !== 'sensitive' &&
                ($entry['blockingEnabled'] ?? true) !== false,
            'disclosure' => $result,
        ];
    }

    /** Hide only bare own-host inventory rows; never change saved mappings or enforcement. */
    private static function is_generic_site_entry(
        array $entry,
        WPHAVE_Consent_Domain_Resolver $domains,
        string $site_host,
    ): bool {
        $service = self::normalize($entry);
        $domain = $domains->normalize($service['domain']);
        if (!$site_host || !$domain || $domain !== $site_host || $service['category'] !== '') {
            return false;
        }
        // Explicit names distinguish concrete first-party services from a host-only row.
        foreach (['label', 'name'] as $field) {
            if (
                is_string($entry[$field] ?? null) &&
                trim($entry[$field]) !== '' &&
                $domains->normalize($entry[$field]) !== $domain
            ) {
                return false;
            }
        }
        $data = $service['disclosure'];
        foreach (array_merge(self::TEXT_FIELDS, ['privacyUrl']) as $field) {
            if ($data[$field] !== '') {
                return false;
            }
        }
        return $data['storageMode'] === 'unknown' && !$data['storage'];
    }

    public static function collect(WPHAVE_Consent_Config $config): array {
        $domains = new WPHAVE_Consent_Domain_Resolver($config);
        $site_host = $domains->get_domain_from_url(home_url());
        $services = array_values(
            array_filter($config->get_services(), static function ($service) use (
                $domains,
                $site_host,
            ) {
                return is_array($service) &&
                    !self::is_generic_site_entry($service, $domains, $site_host);
            }),
        );
        foreach ($config->get_scripts() as $script) {
            if (
                !is_array($script) ||
                ($script['enabled'] ?? true) === false ||
                empty($script['category']) ||
                empty($script['name'])
            ) {
                continue;
            }
            $source = $script['inline'] ?? ($script['code'] ?? '');
            if (!is_string($source) || trim($source) === '') {
                continue;
            }
            $services[] = $script;
        }
        return array_map([self::class, 'normalize'], $services);
    }
}
