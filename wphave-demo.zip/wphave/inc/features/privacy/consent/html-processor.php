<?php

/**
 * Ordered final-HTML consent processing pipeline.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPHAVE_Consent_Html_Processor {

    protected $script_blocker;
    protected $embed_blocker;

    /**
     * Initialize the consent HTML processor service.
     *
     * @param WPHAVE_Consent_Script_Blocker $script_blocker Script blocker.
     * @param WPHAVE_Consent_Embed_Blocker $embed_blocker Embed blocker.
     */

    public function __construct( WPHAVE_Consent_Script_Blocker $script_blocker, WPHAVE_Consent_Embed_Blocker $embed_blocker ) {
        $this->script_blocker = $script_blocker;
        $this->embed_blocker  = $embed_blocker;
    }

    /**
     * Runs the final HTML processing pipeline.
     *
     * Order matters:
     * 1. Embeds first, so provider packages can collect related scripts.
     * 2. External scripts second, for all remaining script tags.
     * 3. Inline scripts last.
     *
     * @param string $html HTML.
     * @return string
     */

    public function process( $html ) {
        // SECURITY INVARIANT: Final HTML is classified in this order: embeds first,
        // then remaining external scripts, then inline code; later stages must not
        // reintroduce executable content skipped by an earlier consent boundary.
        $html = $this->embed_blocker->process( $html );
        $html = $this->outside_templates( $html, [ $this->script_blocker, 'process_external_scripts' ] );
        $html = $this->outside_templates( $html, [ $this->script_blocker, 'process_inline_scripts' ] );

        return $html;
    }

    /**
     * Temporarily removes templates before regex processing.
     *
     * @param string $html HTML.
     * @param callable $callback Callback.
     * @return string
     */

    protected function outside_templates( $html, callable $callback ) {
        if ( strpos( $html, '<template' ) === false ) {
            return call_user_func( $callback, $html );
        }

        $templates = [];

        $html = preg_replace_callback(
            '/<template\b[^>]*>.*?<\/template>/is',
            function( $matches ) use ( &$templates ) {
                $key = '###WPHAVE_TEMPLATE_' . count( $templates ) . '###';
                $templates[ $key ] = $matches[0];
                return $key;
            },
            $html
        );

        $html = call_user_func( $callback, $html );

        return strtr( $html, $templates );
    }
}
