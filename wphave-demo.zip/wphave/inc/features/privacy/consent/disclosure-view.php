<?php

/** Accessible public rendering of the normalized disclosure read model. */
class WPHAVE_Consent_Disclosure_View {
    public static function render_summary(array $service, string $panel_id): void {
        $data = $service['disclosure']; ?>
        <button type="button" class="wphave-consent-service-summary" data-consent-details aria-controls="<?php echo esc_attr(
            $panel_id,
        ); ?>">
            <span class="wphave-consent-service-summary-text">
                <strong><?php echo esc_html($service['label']); ?></strong>
                <span><?php echo esc_html(
                    $data['purpose'] ?:
                    __('Purpose not yet provided by the website operator.', 'wphave'),
                ); ?></span>
                <small class="wphave-consent-badges"><?php self::render_storage_summary(
                    $data,
                ); ?></small>
            </span>
            <span class="wphave-consent-service-summary-link"><?php esc_html_e(
                'Details',
                'wphave',
            ); ?> <span aria-hidden="true">→</span></span>
        </button>
        <?php
    }

    public static function render(array $service): void {
        $data = $service['disclosure'];
        $missing = __('Not yet provided by the website operator.', 'wphave');
        ?>
        <article class="wphave-consent-service">
            <header class="wphave-consent-service-header">
                <h3><?php echo esc_html($service['label']); ?></h3>
                <?php if (
                    $service['domain'] &&
                    preg_match(
                        '/(?<![\pL\pN_.-])' .
                            preg_quote(trim($service['domain']), '/') .
                            '(?![\pL\pN_.-])/iu',
                        $service['label'],
                    ) !== 1
                ): ?>
                    <p><?php echo esc_html($service['domain']); ?></p>
                <?php endif; ?>
            </header>
            <?php
            self::render_section(
                __('Purpose and data', 'wphave'),
                [
                    'purpose' => __('Purpose', 'wphave'),
                    'data' => __('Data processed', 'wphave'),
                ],
                $data,
            );
            self::render_section(
                __('Provider and sharing', 'wphave'),
                [
                    'provider' => __('Provider', 'wphave'),
                    'recipients' => __('Recipients / third-party access', 'wphave'),
                    'transfers' => __('International transfers', 'wphave'),
                    'privacyUrl' => __('Privacy policy', 'wphave'),
                ],
                $data,
            );
            ?>
            <section class="wphave-consent-storage-section">
                <h4><?php esc_html_e('Storage and retention', 'wphave'); ?></h4>
                <dl class="wphave-consent-service-facts">
                    <?php self::render_row(
                        __('Server-side retention', 'wphave'),
                        $data['retention'],
                    ); ?>
                </dl>
                <h5><?php esc_html_e('Cookies and browser storage', 'wphave'); ?></h5>
                <?php if ($data['storageMode'] === 'none'): ?>
                    <?php self::render_notice(
                        __('This service does not store information in your browser.', 'wphave'),
                        'storage',
                    ); ?>
                <?php elseif ($data['storageMode'] === 'listed' && $data['storage']): ?>
                    <?php foreach ($data['storage'] as $storage): ?>
                        <dl class="wphave-consent-storage-facts">
                            <?php
                            self::render_row(
                                __('Name / technology', 'wphave'),
                                $storage['name'],
                                '',
                                $storage['type'],
                            );
                            self::render_row(__('Purpose', 'wphave'), $storage['purpose']);
                            self::render_row(
                                __('Browser storage duration', 'wphave'),
                                $storage['duration'],
                            );
                            ?>
                        </dl>
                    <?php endforeach; ?>
                <?php else: ?>
                    <?php self::render_notice($missing, 'incomplete'); ?>
                <?php endif; ?>
            </section>
        </article>
        <?php
    }

    /** List missing fields once per section without implying that processing is absent. */
    private static function render_section(string $title, array $fields, array $data): void {
        $missing = [];
        echo '<section class="wphave-consent-service-section"><h4>' .
            esc_html($title) .
            '</h4><dl class="wphave-consent-service-facts">';
        foreach ($fields as $key => $label) {
            if (!$data[$key]) {
                $missing[] = $label;
                continue;
            }
            self::render_row(
                $label,
                $key === 'privacyUrl' ? __('Read privacy policy', 'wphave') : $data[$key],
                $key === 'privacyUrl' ? $data[$key] : '',
            );
        }
        echo '</dl>';
        if ($missing) {
            self::render_notice(
                sprintf(
                    /* translators: %s: comma-separated labels of missing disclosure fields. */
                    __('Not yet provided by the website operator: %s.', 'wphave'),
                    implode(', ', $missing),
                ),
                'incomplete',
            );
        }
        echo '</section>';
    }

    /** Shared, non-interactive notice; color supplements the explicit message. */
    public static function render_notice(string $message, string $variant = 'info'): void {
        $variant = in_array($variant, ['info', 'incomplete', 'storage'], true) ? $variant : 'info';
        $class = 'wphave-consent-service-notice is-' . $variant;
        echo '<p class="' . esc_attr($class) . '"><span>' . esc_html($message) . '</span>';
        echo '<span class="wphave-consent-notice-icon" aria-hidden="true">' .
            wphave_svg_ui_icon('info', ['inline' => true]) .
            '</span></p>';
    }

    /** Badges describe known facts; incomplete storage information remains explicit text. */
    private static function render_storage_summary(array $data): void {
        if ($data['storageMode'] === 'none') {
            self::render_badge(__('No browser storage', 'wphave'));
        } elseif ($data['storageMode'] === 'listed' && $data['storage']) {
            foreach (array_unique(array_column($data['storage'], 'type')) as $type) {
                self::render_badge($type);
            }
        } else {
            echo esc_html(__('Browser storage information not yet provided.', 'wphave'));
        }
    }

    private static function render_badge(string $label): void {
        echo '<span class="wphave-consent-badge">' . esc_html($label) . '</span>';
    }

    private static function render_row(
        string $label,
        string $value,
        string $url = '',
        string $badge = '',
    ): void {
        echo '<div class="wphave-consent-fact-row"><dt>' . esc_html($label) . '</dt><dd>';
        if ($url) {
            echo '<a href="' . esc_url($url, ['http', 'https']) . '">' . esc_html($value) . '</a>';
        } elseif ($value === '') {
            echo '<span class="wphave-consent-missing-value">' .
                esc_html(__('Not yet provided by the website operator.', 'wphave')) .
                '</span>';
        } else {
            echo esc_html($value);
        }
        if ($badge !== '') {
            echo ' ';
            self::render_badge($badge);
        }
        echo '</dd></div>';
    }
}
