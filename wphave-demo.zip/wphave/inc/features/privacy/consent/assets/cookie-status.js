/**
 * Detect cookie availability and expose the result to the frontend UI.
 */

(function () {
	'use strict';

	function cookiesEnabled() {
		try {
			const key = 'cookie_status_test';
			const expires = new Date(Date.now() + 60000).toUTCString();

			document.cookie = `${key}=1; expires=${expires}; path=/`;

			const enabled = document.cookie.includes(`${key}=`);

			// Cleanup (optional)
			document.cookie = `${key}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/`;

			return enabled;
		} catch (e) {
			return false;
		}
	}

	function createNotice() {
		if (document.querySelector('.cookie-status')) return;

		const wrapper = document.createElement('div');
		const content = document.createElement('div');
		const message = document.createElement('p');
		const closeBtn = document.createElement('button');

		wrapper.className = 'cookie-status';
		content.className = 'cookie-status-content';
		message.textContent = window.WPHAVE_COOKIE_STATUS_DATA?.notice || '';
		closeBtn.className = 'cookie-status-close';
		closeBtn.type = 'button';
		closeBtn.setAttribute('aria-label', window.WPHAVE_COOKIE_STATUS_DATA?.closeLabel || '');
		closeBtn.textContent = '×';
		content.appendChild(message);
		wrapper.append(content, closeBtn);

		document.body.appendChild(wrapper);

		closeBtn.addEventListener('click', () => {
			wrapper.remove();
		});
	}

	function removeNotice() {
		document.querySelectorAll('.cookie-status').forEach((el) => el.remove());
	}

	function init() {
		const enabled = cookiesEnabled();

		if (enabled) {
			removeNotice();
		} else {
			createNotice();
		}
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
})();
