﻿/**
 * Enforce consent decisions for static and runtime-created frontend resources.
 *
 * Architecture:
 *
 * 1. PHP layer
 *    - Rewrites static external scripts to:
 *      <script type="text/plain" data-consent="..." data-src="..."></script>
 *
 *    - Rewrites static embeds / iframes to:
 *      <div data-consent-placeholder data-consent-category="...">
 *          <template class="wphave-consent-template">Original HTML</template>
 *      </div>
 *
 * 2. JavaScript runtime layer
 *    - Reads and writes consent cookie.
 *    - Blocks runtime-created scripts, iframes and requests.
 *    - Activates PHP-created blocked nodes only after valid consent.
 *    - Allows one-off placeholder restore via "Load content".
 *
 * Core rules:
 *
 * - Blocking layer never activates.
 * - Activation layer never decides blindly.
 * - Every script activation goes through canExecuteScript().
 * - Placeholder restore only bypasses consent when explicitly forced by
 *   "Load content".
 * - Trusted context only prevents self-blocking while restoring approved content.
 */

(function () {
	'use strict';

	/* Configuration. */

	const CONSENT_KEY = 'wphave_consent';
	const DATA = window.WPHAVE_CONSENT_DATA || {};
	const SERVICE_MAP = DATA.serviceMap || {};
	const EMBED_BLOCKING_ENABLED = DATA.embedBlocking !== false;
	const ALLOWED_SERVICE_DOMAINS = new Set(
		(DATA.allowedServiceDomains || []).map(normalizeDomain)
	);

	const ATTR_ALLOWED = 'data-wphave-consent-allowed';
	const ATTR_EXECUTED = 'data-wphave-consent-executed';
	const ATTR_BOUND = 'data-wphave-consent-bound';

	const DEFAULT_CATEGORIES = ['necessary', 'analytics', 'marketing', 'preferences'];

	const PROVIDERS = [
		{
			name: 'tiktok',
			match: (fragment) => fragment.querySelector('[class*="tiktok"], [src*="tiktok"]'),
			allowDomains: ['tiktok.com', 'tiktokcdn.com', 'ttwstatic.com']
		},
		{
			name: 'twitter',
			match: (fragment) =>
				fragment.querySelector('.twitter-tweet, [src*="twitter"], [src*="x.com"]'),
			allowDomains: ['twitter.com', 'x.com', 't.co', 'twimg.com']
		},
		{
			name: 'instagram',
			match: (fragment) => fragment.querySelector('.instagram-media, [src*="instagram"]'),
			allowDomains: ['instagram.com', 'cdninstagram.com']
		}
	];

	/* Runtime state. */

	let consentCache = null;
	let trustedContextDepth = 0;

	const oneOffAllowedDomains = new Set();

	/* Trusted context. */

	/**
	 * Run approved activation work without allowing unrelated resources.
	 *
	 * @param {Function} callback Activation callback.
	 * @return {*} Callback result.
	 */
	function runInTrustedContext(callback) {
		trustedContextDepth++;

		try {
			return callback();
		} finally {
			trustedContextDepth--;
		}
	}

	function isTrustedContext() {
		return trustedContextDepth > 0;
	}

	/* URL and domain helpers. */

	function normalizeDomain(domain) {
		if (!domain) return '';

		return String(domain)
			.toLowerCase()
			.replace(/^www\./, '')
			.replace(/:\d+$/, '');
	}

	function domainMatches(domain, configuredDomain) {
		const current = normalizeDomain(domain);
		const configured = normalizeDomain(configuredDomain);

		return (
			!!current &&
			!!configured &&
			(current === configured || current.endsWith('.' + configured))
		);
	}

	function cleanUrl(raw) {
		if (!raw) return null;

		try {
			let url = String(raw)
				.replace(/\\u0026/g, '&')
				.replace(/&amp;/g, '&')
				.replace(/\\n/g, '')
				.replace(/\\r/g, '')
				.replace(/\\t/g, '')
				.trim();

			url = url.split('<')[0].split('"')[0].split("'")[0];

			const parsed = new URL(url, window.location.origin);
			let clean = parsed.origin + parsed.pathname + parsed.search;

			clean = clean.replace(/\/+$/, '');

			return clean;
		} catch (error) {
			return null;
		}
	}

	function getDomain(url) {
		try {
			return normalizeDomain(new URL(url, window.location.origin).hostname);
		} catch (error) {
			return null;
		}
	}

	function isExternalUrl(url) {
		try {
			const parsed = new URL(url, window.location.origin);

			if (!/^https?:$/.test(parsed.protocol)) return false;
			if (parsed.origin === window.location.origin) return false;
			if (parsed.hostname === 'localhost') return false;
			if (parsed.hostname.endsWith('.local')) return false;

			return true;
		} catch (error) {
			return false;
		}
	}

	function isInternalWPHAVERequest(url) {
		if (!url) return false;

		try {
			const parsed = new URL(url, window.location.origin);
			// SECURITY INVARIANT: A WPHAVE-looking path is internal only on this exact
			// origin; external hosts cannot bypass consent by copying the REST prefix.
			return (
				parsed.origin === window.location.origin &&
				parsed.pathname.includes('/wp-json/wphave/')
			);
		} catch (error) {
			return false;
		}
	}

	/* Category and resource helpers. */

	function getCategoryFromUrl(url) {
		try {
			const hostname = new URL(url, window.location.origin).hostname;
			const match = Object.entries(SERVICE_MAP)
				.sort(([firstDomain], [secondDomain]) => secondDomain.length - firstDomain.length)
				.find(([domain]) => domainMatches(hostname, domain));

			return match ? match[1] : null;
		} catch (error) {
			return null;
		}
	}

	function isExplicitlyAllowedDomain(domain) {
		return Array.from(ALLOWED_SERVICE_DOMAINS).some((allowedDomain) =>
			domainMatches(domain, allowedDomain)
		);
	}

	function isOneOffAllowedDomain(domain) {
		return Array.from(oneOffAllowedDomains).some((allowedDomain) =>
			domainMatches(domain, allowedDomain)
		);
	}

	function getResourceType(domain) {
		if (!domain) return 'ignore';

		if (
			domain.includes('w3.org') ||
			domain.includes('localhost') ||
			domain.endsWith('.local') ||
			domain === normalizeDomain(window.location.hostname)
		) {
			return 'ignore';
		}

		if (
			domain.includes('googleapis.com') ||
			domain.includes('gstatic.com') ||
			domain.includes('jsdelivr.net') ||
			domain.includes('unpkg.com') ||
			domain.includes('cdnjs.cloudflare.com')
		) {
			return 'sensitive';
		}

		return 'consent';
	}

	/* Consent state. */

	function readConsentFromCookie() {
		try {
			const cookie = document.cookie
				.split('; ')
				.find((row) => row.startsWith(CONSENT_KEY + '='));

			if (!cookie) return {};

			return JSON.parse(decodeURIComponent(cookie.split('=')[1])) || {};
		} catch (error) {
			return {};
		}
	}

	function getConsent() {
		if (consentCache !== null) {
			return consentCache;
		}

		consentCache = readConsentFromCookie();
		return consentCache;
	}

	function writeConsent(consent) {
		consentCache = { ...consent };

		// SECURITY INVARIANT: The consent state is site-scoped, SameSite=Lax and gains
		// the Secure attribute whenever transport security is available.
		const secure = window.location.protocol === 'https:' ? ';Secure' : '';

		document.cookie =
			CONSENT_KEY +
			'=' +
			encodeURIComponent(JSON.stringify(consentCache)) +
			';path=/;max-age=' +
			60 * 60 * 24 * 365 +
			';SameSite=Lax' +
			secure;
	}

	function hasFullConsent() {
		return getConsent().__all === true;
	}

	function hasConsent(category) {
		if (!category || category === 'necessary') return true;

		if (category === 'unknown') {
			return false;
		}

		if (hasFullConsent()) return true;

		return getConsent()[category] === true;
	}

	function getCategoryConsentObject(value) {
		const consent = {};

		DEFAULT_CATEGORIES.forEach((category) => {
			consent[category] = category === 'necessary' ? true : value;
		});

		return consent;
	}

	/* Decision engine: the single source of truth for blocking decisions. */

	/**
	 * Resolve the single authoritative blocking decision for a resource URL.
	 *
	 * @param {string} url Resource URL.
	 * @return {Object} Decision containing the resource category and allow state.
	 */
	function getBlockingDecision(url) {
		const clean = cleanUrl(url);

		if (!clean || !isExternalUrl(clean)) {
			return {
				shouldBlock: false,
				category: null,
				resourceType: 'ignore',
				url: clean
			};
		}

		const domain = getDomain(clean);

		if (isExplicitlyAllowedDomain(domain)) {
			return {
				shouldBlock: false,
				category: null,
				resourceType: 'consent',
				url: clean
			};
		}

		const mappedCategory = getCategoryFromUrl(clean);
		const category = mappedCategory || 'unknown';
		const resourceType = getResourceType(domain);

		if (resourceType === 'ignore') {
			return {
				shouldBlock: false,
				category: null,
				resourceType,
				url: clean
			};
		}

		if (resourceType === 'sensitive') {
			return {
				shouldBlock: false,
				category: 'sensitive',
				resourceType,
				url: clean
			};
		}

		if (isOneOffAllowedDomain(domain)) {
			return {
				shouldBlock: false,
				category,
				resourceType,
				url: clean
			};
		}

		return {
			shouldBlock: !hasConsent(category),
			category: category,
			resourceType,
			url: clean
		};
	}

	/**
	 * Determine whether a blocked script may execute in the current context.
	 *
	 * @param {string} src Script source URL.
	 * @param {string} category Assigned consent category.
	 * @param {Object} options Activation options.
	 * @return {boolean} Whether execution is allowed.
	 */
	function canExecuteScript(src, category, options = {}) {
		if (options.force === true) {
			return true;
		}

		if (src) {
			const domain = getDomain(src);

			if (domain && isOneOffAllowedDomain(domain)) {
				return true;
			}
		}

		const decision = src ? getBlockingDecision(src) : null;

		const finalCategory = category || (decision ? decision.category : null) || 'unknown';

		return hasConsent(finalCategory);
	}

	/**
	 * Determine whether placeholder content may be restored.
	 *
	 * @param {string} category Assigned consent category.
	 * @param {Object} options Activation options.
	 * @return {boolean} Whether restoration is allowed.
	 */
	function canRestorePlaceholder(category, options = {}) {
		if (options.force === true) {
			return true;
		}

		return hasConsent(category || 'unknown');
	}

	/* Node helpers. */

	function isBlockedScript(node) {
		return (
			node &&
			node.nodeType === 1 &&
			node.tagName === 'SCRIPT' &&
			node.getAttribute('type') === 'text/plain' &&
			node.hasAttribute('data-consent')
		);
	}

	function isConsentPlaceholder(node) {
		return (
			node &&
			node.nodeType === 1 &&
			node.hasAttribute('data-consent-placeholder') &&
			node.hasAttribute('data-consent-category') &&
			!!node.querySelector('template.wphave-consent-template')
		);
	}

	function isAllowedNode(node) {
		return (
			node &&
			node.nodeType === 1 &&
			node.hasAttribute &&
			(node.hasAttribute(ATTR_ALLOWED) || node.closest?.('[' + ATTR_ALLOWED + ']'))
		);
	}

	function markAllowed(node) {
		if (node && node.setAttribute) {
			node.setAttribute(ATTR_ALLOWED, '1');
		}
	}

	function getScriptCandidateSrc(node) {
		if (!node) return '';
		return node.getAttribute('data-src') || node.getAttribute('src') || node.src || '';
	}

	function collectExternalDomains(container) {
		const domains = new Set();

		if (!container || !container.querySelectorAll) {
			return domains;
		}

		container
			.querySelectorAll('script, iframe, img, source, embed, object, link')
			.forEach((node) => {
				const url =
					node.getAttribute('data-src') ||
					node.getAttribute('src') ||
					node.getAttribute('href') ||
					node.getAttribute('data');

				if (!url || !isExternalUrl(url)) return;

				const domain = getDomain(url);

				if (domain) {
					domains.add(domain);
				}
			});

		return domains;
	}

	/*
	 * Blocking layer.
	 *
	 * This layer never activates anything. It only blocks or lets pass.
	 */

	/**
	 * Convert a script into an inert placeholder while preserving its metadata.
	 *
	 * @param {HTMLScriptElement} script Script to block.
	 * @param {string} src Original source URL.
	 * @param {string} category Assigned consent category.
	 * @return {void}
	 */
	function convertScriptToBlockedPlaceholder(script, src, category) {
		if (!script || !src) return false;

		script.type = 'text/plain';
		script.removeAttribute('src');
		script.setAttribute('data-src', src);
		script.setAttribute('data-consent', category || 'unknown');

		return true;
	}

	function convertIframeToBlockedNode(iframe, src, category) {
		if (!iframe || !src) return false;

		iframe.removeAttribute('src');
		iframe.setAttribute('data-blocked-src', src);
		iframe.setAttribute('data-consent', category || 'unknown');

		return true;
	}

	function interceptScriptNode(node) {
		if (!node || node.nodeType !== 1 || node.tagName !== 'SCRIPT') {
			return node;
		}

		if (isBlockedScript(node)) {
			return node;
		}

		if (isTrustedContext() || isAllowedNode(node)) {
			return node;
		}

		const src = node.src || node.getAttribute('src');

		if (!src || !isExternalUrl(src)) {
			return node;
		}

		const decision = getBlockingDecision(src);

		if (decision.shouldBlock) {
			convertScriptToBlockedPlaceholder(
				node,
				decision.url || src,
				decision.category || 'unknown'
			);
		}

		return node;
	}

	function interceptIframeNode(node) {
		if (!node || node.nodeType !== 1 || node.tagName !== 'IFRAME') {
			return node;
		}

		if (!EMBED_BLOCKING_ENABLED) {
			return node;
		}

		if (isTrustedContext() || isAllowedNode(node)) {
			return node;
		}

		const src = node.src || node.getAttribute('src');

		if (!src || !isExternalUrl(src)) {
			return node;
		}

		const decision = getBlockingDecision(src);

		if (decision.shouldBlock) {
			convertIframeToBlockedNode(node, decision.url || src, decision.category || 'unknown');
		}

		return node;
	}

	function interceptNode(node) {
		if (!node || node.nodeType !== 1) return node;

		if (isTrustedContext() || isAllowedNode(node)) {
			return node;
		}

		if (node.tagName === 'SCRIPT') {
			return interceptScriptNode(node);
		}

		if (node.tagName === 'IFRAME') {
			return interceptIframeNode(node);
		}

		if (node.querySelectorAll) {
			node.querySelectorAll('script[src]').forEach(interceptScriptNode);
			node.querySelectorAll('iframe[src]').forEach(interceptIframeNode);
		}

		return node;
	}

	function blockExistingRuntimeNodes(root = document) {
		if (!root.querySelectorAll) return;

		root.querySelectorAll('script[src]').forEach(interceptScriptNode);
		root.querySelectorAll('iframe[src]').forEach(interceptIframeNode);
	}

	/*
	 * Activation layer.
	 *
	 * This layer never blindly executes scripts. Every script goes through
	 * canExecuteScript(), except when explicitly forced by one-off loading.
	 */

	function createExecutableScriptFromPlaceholder(node) {
		const script = document.createElement('script');

		markAllowed(script);

		[...node.attributes].forEach((attr) => {
			const name = attr.name;

			if (
				name === 'type' ||
				name === 'data-consent' ||
				name === 'data-src' ||
				name === 'data-wphave-processed' ||
				name === ATTR_EXECUTED
			) {
				return;
			}

			script.setAttribute(name, attr.value);
		});

		const dataSrc = node.getAttribute('data-src');

		if (dataSrc) {
			script.src = dataSrc;
		} else if (node.textContent) {
			script.textContent = node.textContent;
		}

		return script;
	}

	function createExecutableScriptFromScriptTag(oldScript) {
		const script = document.createElement('script');

		markAllowed(script);

		[...oldScript.attributes].forEach((attr) => {
			const name = attr.name;

			if (
				name === 'type' ||
				name === 'data-consent' ||
				name === 'data-src' ||
				name === 'data-wphave-processed' ||
				name === ATTR_EXECUTED
			) {
				return;
			}

			script.setAttribute(name, attr.value);
		});

		const dataSrc = oldScript.getAttribute('data-src');

		if (dataSrc) {
			script.src = dataSrc;
		} else if (oldScript.src) {
			script.src = oldScript.src;
		} else if (oldScript.textContent) {
			script.textContent = oldScript.textContent;
		}

		return script;
	}

	function activateBlockedScript(node, options = {}) {
		if (!isBlockedScript(node)) return false;
		if (!node.isConnected) return false;
		if (node.getAttribute(ATTR_EXECUTED) === '1') return false;

		const src = node.getAttribute('data-src');
		const category = node.getAttribute('data-consent');

		if (!canExecuteScript(src, category, options)) {
			return false;
		}

		node.setAttribute(ATTR_EXECUTED, '1');

		const executable = createExecutableScriptFromPlaceholder(node);

		runInTrustedContext(() => {
			node.parentNode.replaceChild(executable, node);
		});

		return true;
	}

	function activateBlockedScripts(root = document, options = {}) {
		if (!root.querySelectorAll) return;

		root.querySelectorAll('script[type="text/plain"][data-consent]').forEach((node) => {
			activateBlockedScript(node, options);
		});
	}

	function safeActivateScripts(container, options = {}) {
		if (!container || !container.querySelectorAll) return;

		container.querySelectorAll('script').forEach((oldScript) => {
			const src = getScriptCandidateSrc(oldScript);
			const category = oldScript.getAttribute('data-consent');
			if (!canExecuteScript(src, category, options)) {
				if (src && isExternalUrl(src)) {
					const decision = getBlockingDecision(src);
					convertScriptToBlockedPlaceholder(
						oldScript,
						decision.url || src,
						decision.category || category || 'unknown'
					);
				}

				return;
			}

			const script = createExecutableScriptFromScriptTag(oldScript);
			oldScript.replaceWith(script);
		});
	}

	function restorePlaceholder(node, options = {}) {
		if (!isConsentPlaceholder(node)) return false;
		if (!node.parentNode) return false;
		if (node.getAttribute(ATTR_EXECUTED) === '1') return false;

		const category = node.getAttribute('data-consent-category');
		const domainAttr = node.getAttribute('data-consent-domain');

		if (!canRestorePlaceholder(category, options)) {
			return false;
		}

		const template = node.querySelector('template.wphave-consent-template');
		if (!template) return false;

		const parent = node.parentNode;
		const fragment = template.content.cloneNode(true);

		if (options.force === true) {
			if (domainAttr) {
				oneOffAllowedDomains.add(normalizeDomain(domainAttr));
			}

			collectExternalDomains(fragment).forEach((domain) => {
				oneOffAllowedDomains.add(domain);
			});

			PROVIDERS.forEach((provider) => {
				if (provider.match(fragment)) {
					provider.allowDomains.forEach((domain) => {
						oneOffAllowedDomains.add(normalizeDomain(domain));
					});
				}
			});
		}

		node.setAttribute(ATTR_EXECUTED, '1');

		runInTrustedContext(() => {
			safeActivateScripts(fragment, options);
			parent.insertBefore(fragment, node);
			parent.removeChild(node);
		});

		return true;
	}

	function activatePlaceholders(root = document, options = {}) {
		if (!root.querySelectorAll) return;

		root.querySelectorAll('[data-consent-placeholder][data-consent-category]').forEach(
			(node) => {
				restorePlaceholder(node, options);
			}
		);
	}

	function activateSinglePlaceholder(node) {
		restorePlaceholder(node, { force: true });
	}

	/**
	 * Activate every eligible blocked resource below a root node.
	 *
	 * @param {Document|HTMLElement} root Root containing blocked resources.
	 * @param {Object} options Activation options.
	 * @return {void}
	 */
	function runActivation(root = document, options = {}) {
		activateBlockedScripts(root, options);
		activatePlaceholders(root, options);
	}

	/* UI actions. */

	function openConsentSettings() {
		window.dispatchEvent(
			new CustomEvent('openModal', {
				detail: { target: 'wphave-consent-preferences' }
			})
		);
	}

	function closeConsentUI() {
		const banner = document.getElementById('wph-cons');
		const reopen = document.getElementById('wph-cons-reopen');

		if (banner) {
			banner.classList.add('is-hidden');
			banner.setAttribute('aria-hidden', 'true');
			banner.hidden = true;
		}
		window.dispatchEvent(
			new CustomEvent('closeModal', {
				detail: { target: 'wphave-consent-preferences' }
			})
		);
		if (reopen) {
			reopen.classList.remove('is-hidden');
			reopen.setAttribute('aria-hidden', 'false');
			reopen.hidden = false;
		}
	}

	function syncInputsFromConsent() {
		const consent = getConsent();

		document.querySelectorAll('[data-category]').forEach((input) => {
			const category = input.getAttribute('data-category');

			if (!category) return;

			input.checked =
				category === 'necessary' || hasConsent(category) || consent[category] === true;
		});
	}

	function collectInputsConsent() {
		const consent = {
			__all: false,
			necessary: true
		};

		document.querySelectorAll('[data-category]').forEach((input) => {
			const category = input.getAttribute('data-category');

			if (!category) return;

			consent[category] = category === 'necessary' ? true : input.checked === true;
		});

		return consent;
	}

	function bindConsentActions(root = document) {
		if (!root.querySelectorAll) return;

		root.querySelectorAll('[data-action]').forEach((button) => {
			if (button.getAttribute(ATTR_BOUND) === '1') return;

			button.setAttribute(ATTR_BOUND, '1');

			button.addEventListener('click', (event) => {
				const action = button.getAttribute('data-action');

				if (action === 'open-settings') {
					event.preventDefault();
					openConsentSettings();
					return;
				}

				if (action === 'accept-single') {
					event.preventDefault();

					const placeholder = button.closest('[data-consent-placeholder]');
					if (placeholder) {
						activateSinglePlaceholder(placeholder);
					}

					return;
				}

				if (action === 'accept-all') {
					event.preventDefault();
					window.WPHAVE_CONSENT.acceptAll();
					closeConsentUI();
					return;
				}

				if (action === 'reject-all') {
					event.preventDefault();
					window.WPHAVE_CONSENT.rejectAll();
					closeConsentUI();
					return;
				}

				if (action === 'save-settings') {
					event.preventDefault();
					window.WPHAVE_CONSENT.setAll(collectInputsConsent());
					closeConsentUI();
					return;
				}
			});
		});
	}

	/* Public API. */

	/**
	 * Persist a consent decision and activate newly approved resources.
	 *
	 * @param {Object} nextConsent Category consent state.
	 * @return {void}
	 */
	function setConsentAndActivate(nextConsent) {
		writeConsent(nextConsent);
		syncInputsFromConsent();
		runActivation(document);
		window.dispatchEvent(
			new CustomEvent('wphave:consent-changed', {
				detail: { consent: getConsent() }
			})
		);
	}

	window.WPHAVE_CONSENT = {
		get() {
			return getConsent();
		},

		has(category) {
			return hasConsent(category);
		},

		set(category, value) {
			const next = {
				...getConsent(),
				[category]: value
			};

			if (category !== '__all') {
				delete next.__all;
			}

			setConsentAndActivate(next);
		},

		setAll(consent) {
			const next = {
				...getConsent(),
				...consent
			};

			if (!('__all' in consent)) {
				delete next.__all;
			}

			setConsentAndActivate(next);
		},

		acceptAll() {
			setConsentAndActivate({
				__all: true,
				...getCategoryConsentObject(true)
			});
		},

		rejectAll() {
			setConsentAndActivate({
				__all: false,
				...getCategoryConsentObject(false)
			});
		},

		run() {
			runActivation(document);
		},

		openSettings() {
			openConsentSettings();
		},

		reset() {
			consentCache = {};
			document.cookie = CONSENT_KEY + '=;path=/;max-age=0;SameSite=Lax';
			window.dispatchEvent(
				new CustomEvent('wphave:consent-changed', {
					detail: { consent: {} }
				})
			);
		}
	};

	/* Runtime hooks. */

	function hookDynamicNodes() {
		const appendChild = Node.prototype.appendChild;
		const insertBefore = Node.prototype.insertBefore;
		const replaceChild = Node.prototype.replaceChild;

		Node.prototype.appendChild = function (node) {
			return appendChild.call(this, interceptNode(node));
		};

		Node.prototype.insertBefore = function (node, referenceNode) {
			return insertBefore.call(this, interceptNode(node), referenceNode);
		};

		Node.prototype.replaceChild = function (node, oldNode) {
			return replaceChild.call(this, interceptNode(node), oldNode);
		};
	}

	function hookSetAttribute() {
		const originalSetAttribute = Element.prototype.setAttribute;

		Element.prototype.setAttribute = function (name, value) {
			const attrName = String(name).toLowerCase();

			if (isTrustedContext() || isAllowedNode(this)) {
				return originalSetAttribute.call(this, name, value);
			}

			if (this.tagName === 'SCRIPT' && attrName === 'src' && isExternalUrl(value)) {
				const decision = getBlockingDecision(value);

				if (decision.shouldBlock) {
					this.type = 'text/plain';
					originalSetAttribute.call(this, 'data-src', decision.url || value);
					originalSetAttribute.call(this, 'data-consent', decision.category || 'unknown');
					return;
				}
			}

			if (
				EMBED_BLOCKING_ENABLED &&
				this.tagName === 'IFRAME' &&
				attrName === 'src' &&
				isExternalUrl(value)
			) {
				const decision = getBlockingDecision(value);

				if (decision.shouldBlock) {
					originalSetAttribute.call(this, 'data-blocked-src', decision.url || value);
					originalSetAttribute.call(this, 'data-consent', decision.category || 'unknown');
					return;
				}
			}

			return originalSetAttribute.call(this, name, value);
		};
	}

	function hookScriptSrcProperty() {
		const descriptor = Object.getOwnPropertyDescriptor(HTMLScriptElement.prototype, 'src');

		if (!descriptor || !descriptor.configurable) return;

		Object.defineProperty(HTMLScriptElement.prototype, 'src', {
			get() {
				return descriptor.get.call(this);
			},
			set(value) {
				if (isTrustedContext() || isAllowedNode(this)) {
					return descriptor.set.call(this, value);
				}

				if (isExternalUrl(value)) {
					const decision = getBlockingDecision(value);

					if (decision.shouldBlock) {
						this.type = 'text/plain';
						this.setAttribute('data-src', decision.url || value);
						this.setAttribute('data-consent', decision.category || 'unknown');
						return value;
					}
				}

				return descriptor.set.call(this, value);
			}
		});
	}

	function hookIframeSrcProperty() {
		const descriptor = Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype, 'src');

		if (!descriptor || !descriptor.configurable) return;

		Object.defineProperty(HTMLIFrameElement.prototype, 'src', {
			get() {
				return descriptor.get.call(this);
			},
			set(value) {
				if (isTrustedContext() || isAllowedNode(this)) {
					return descriptor.set.call(this, value);
				}

				if (isExternalUrl(value)) {
					if (!EMBED_BLOCKING_ENABLED) {
						return descriptor.set.call(this, value);
					}

					const decision = getBlockingDecision(value);

					if (decision.shouldBlock) {
						this.setAttribute('data-blocked-src', decision.url || value);
						this.setAttribute('data-consent', decision.category || 'unknown');
						return value;
					}
				}

				return descriptor.set.call(this, value);
			}
		});
	}

	function getFetchUrl(args) {
		const input = args[0];

		if (typeof input === 'string') return input;
		if (input instanceof Request) return input.url;

		return null;
	}

	function hookFetch() {
		const originalFetch = window.fetch;

		if (typeof originalFetch !== 'function') return;

		window.fetch = function (...args) {
			const url = getFetchUrl(args);

			if (!url || isInternalWPHAVERequest(url) || !isExternalUrl(url)) {
				return originalFetch.apply(this, args);
			}

			const decision = getBlockingDecision(url);

			if (decision.shouldBlock) {
				return Promise.reject(new Error('Blocked by WPHAVE consent manager'));
			}

			return originalFetch.apply(this, args);
		};
	}

	function hookXHR() {
		if (typeof window.XMLHttpRequest !== 'function') return;

		const originalOpen = window.XMLHttpRequest.prototype.open;
		const originalSend = window.XMLHttpRequest.prototype.send;

		window.XMLHttpRequest.prototype.open = function (method, url, async, user, password) {
			this._wphaveUrl = typeof url === 'string' ? url : null;
			return originalOpen.call(this, method, url, async, user, password);
		};

		window.XMLHttpRequest.prototype.send = function (body) {
			const url = this._wphaveUrl;

			if (!url || isInternalWPHAVERequest(url) || !isExternalUrl(url)) {
				return originalSend.call(this, body);
			}

			const decision = getBlockingDecision(url);

			if (decision.shouldBlock) {
				setTimeout(() => {
					try {
						this.dispatchEvent(new Event('error'));
						this.dispatchEvent(new Event('loadend'));
					} catch (error) {}
				}, 0);

				return;
			}

			return originalSend.call(this, body);
		};
	}

	function hookBeacon() {
		if (!window.navigator || typeof window.navigator.sendBeacon !== 'function') return;

		const originalSendBeacon = window.navigator.sendBeacon.bind(window.navigator);

		window.navigator.sendBeacon = function (url, data) {
			if (!url || typeof url !== 'string') {
				return originalSendBeacon(url, data);
			}

			if (isInternalWPHAVERequest(url) || !isExternalUrl(url)) {
				return originalSendBeacon(url, data);
			}

			const decision = getBlockingDecision(url);

			if (decision.shouldBlock) {
				return false;
			}

			return originalSendBeacon(url, data);
		};
	}

	function hookDocumentWrite() {
		const originalWrite = document.write.bind(document);
		const originalWriteln = document.writeln.bind(document);

		function sanitize(html) {
			if (typeof html !== 'string') return html;

			return html.replace(
				/<script\b([^>]*?)\bsrc=(["'])(.*?)\2([^>]*)><\/script>/gi,
				(match, before, quote, src) => {
					if (!isExternalUrl(src)) return match;

					const decision = getBlockingDecision(src);

					if (!decision.shouldBlock) return match;

					return `<script type="text/plain" data-consent="${
						decision.category || 'unknown'
					}" data-src="${decision.url || src}"></script>`;
				}
			);
		}

		document.write = function (html) {
			return originalWrite(sanitize(html));
		};

		document.writeln = function (html) {
			return originalWriteln(sanitize(html));
		};
	}

	/**
	 * Install resource interception hooks exactly once.
	 *
	 * These hooks protect resources created after the initial PHP output pass.
	 *
	 * @return {void}
	 */
	function installRuntimeHooks() {
		hookSetAttribute();
		hookScriptSrcProperty();
		hookIframeSrcProperty();
		hookDynamicNodes();
		hookFetch();
		hookXHR();
		hookBeacon();
		hookDocumentWrite();
	}

	/* DOM observer. */

	/**
	 * Observe inserted nodes and apply the same blocking rules as initial HTML.
	 *
	 * @return {void}
	 */
	function observeDomChanges() {
		const observer = new MutationObserver((mutations) => {
			mutations.forEach((mutation) => {
				mutation.addedNodes.forEach((node) => {
					if (!node || node.nodeType !== 1) return;

					interceptNode(node);
					bindConsentActions(node);
					runActivation(node);
				});
			});
		});

		observer.observe(document.documentElement, {
			childList: true,
			subtree: true
		});
	}

	/* Initialization. */

	function init() {
		installRuntimeHooks();

		blockExistingRuntimeNodes(document);

		syncInputsFromConsent();
		bindConsentActions(document);

		runActivation(document);

		observeDomChanges();
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init, { once: true });
	} else {
		init();
	}
})();
