/**
 * Synchronize the consent banner, preferences dialog and reopen control.
 */

(function () {
	'use strict';

	const DATA = window.WPHAVE_CONSENT_DATA || { categories: [] };

	function getBanner() {
		return document.getElementById('wph-cons');
	}

	function getReopen() {
		return document.getElementById('wph-cons-reopen');
	}

	function setVisibility(element, visible) {
		if (!element) {
			return;
		}

		element.hidden = !visible;
		element.setAttribute('aria-hidden', visible ? 'false' : 'true');
		element.classList.toggle('is-hidden', !visible);
	}

	function showBanner() {
		setVisibility(getBanner(), true);
		setVisibility(getReopen(), false);
	}

	function hideBanner() {
		setVisibility(getBanner(), false);
		setVisibility(getReopen(), true);
	}

	function syncInputsFromConsent(consent = {}) {
		document.querySelectorAll('[data-category]').forEach((input) => {
			const key = input.dataset.category;
			if (!key) {
				return;
			}

			const category = DATA.categories.find((cat) => cat.key === key);
			const isRequired = !!category?.required;

			input.checked = isRequired ? true : !!consent[key];
		});
	}

	/** Navigate informational panels without touching the unsaved category inputs. */
	function bindServiceNavigation() {
		const modal = document.getElementById('wphave-consent-preferences');
		const overview = modal?.querySelector('#wphave-consent-overview');
		const views = modal?.querySelector('.wphave-consent-views');
		const scroller = modal?.querySelector('.wphave-consent-modal-content');
		if (!overview || !views || !scroller) {
			return;
		}
		const title = modal.querySelector('#wphave-consent-preferences-title');
		const overviewTitle = title?.textContent;
		const overviewDescription = modal.getAttribute('aria-describedby');
		if (title) {
			views.querySelectorAll('.wphave-consent-service-header').forEach((header) => {
				const heading = header.querySelector('h3');
				if (heading) {
					heading.hidden = true;
					header.hidden = !header.querySelector('p');
				}
			});
		}
		let active = overview;
		let trigger = null;
		let overviewScroll = 0;
		let finishTransition = null;

		function navigate(next, backwards = false, animate = true) {
			finishTransition?.();
			if (next === active) {
				return;
			}
			const previous = active;
			const oldHeight = views.offsetHeight;
			previous.inert = true;
			next.hidden = false;
			next.inert = false;
			active = next;
			if (title) {
				title.textContent =
					next === overview
						? overviewTitle
						: next.querySelector('.wphave-consent-service-header h3')?.textContent ||
						  overviewTitle;
			}
			if (next === overview && overviewDescription) {
				modal.setAttribute('aria-describedby', overviewDescription);
			} else {
				modal.removeAttribute('aria-describedby');
			}
			const focusTarget = backwards ? trigger : next.querySelector('[data-consent-back]');
			const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
			const canAnimate = animate && !reducedMotion && typeof next.animate === 'function';
			previous.hidden = true;
			const newHeight = views.offsetHeight;
			scroller.scrollTop = backwards ? overviewScroll : 0;
			if (animate) {
				focusTarget?.focus({ preventScroll: true });
			}
			if (!canAnimate) {
				return;
			}
			previous.hidden = false;
			previous.classList.add('is-leaving');
			previous.setAttribute('aria-hidden', 'true');
			const direction = backwards ? -1 : 1;
			const timing = { duration: 240, easing: 'cubic-bezier(0.2, 0.7, 0.2, 1)' };
			const animations = [
				previous.animate(
					[
						{ transform: 'translateX(0)' },
						{ transform: `translateX(${-direction * 100}%)` }
					],
					timing
				),
				next.animate(
					[
						{ transform: `translateX(${direction * 100}%)` },
						{ transform: 'translateX(0)' }
					],
					timing
				),
				views.animate([{ height: `${oldHeight}px` }, { height: `${newHeight}px` }], timing)
			];
			const finish = () => {
				previous.hidden = true;
				previous.classList.remove('is-leaving');
				previous.removeAttribute('aria-hidden');
				animations.forEach((animation) => animation.cancel());
				if (finishTransition === finish) {
					finishTransition = null;
				}
				scroller.scrollTop = backwards ? overviewScroll : 0;
			};
			finishTransition = finish;
			Promise.allSettled(animations.map((animation) => animation.finished)).then(() => {
				if (finishTransition === finish) {
					finish();
				}
			});
		}

		modal.addEventListener('click', (event) => {
			const categoryButton = event.target.closest('[data-consent-category-expand]');
			if (categoryButton && overview.contains(categoryButton)) {
				const content = document.getElementById(
					categoryButton.getAttribute('aria-controls')
				);
				if (content && overview.contains(content)) {
					const expanded = categoryButton.getAttribute('aria-expanded') !== 'true';
					categoryButton.setAttribute('aria-expanded', String(expanded));
					content.hidden = !expanded;
				}
				return;
			}

			const button = event.target.closest('[data-consent-details], [data-consent-back]');
			if (!button || !modal.contains(button)) {
				return;
			}
			if (button.hasAttribute('data-consent-back')) {
				navigate(overview, true);
				return;
			}
			const next = document.getElementById(button.getAttribute('aria-controls'));
			if (!next || next.parentElement !== views) {
				return;
			}
			overviewScroll = scroller.scrollTop;
			trigger = button;
			navigate(next);
		});
		modal.addEventListener('modalIsClosing', () => {
			navigate(overview, true, false);
		});
		modal.addEventListener('modalWillOpen', () => {
			navigate(overview, true, false);
		});
	}

	function bindEvents() {
		window.addEventListener('wphave:consent-changed', () => {
			syncInputsFromConsent(window.WPHAVE_CONSENT.get());
			hideBanner();
		});
	}

	function init() {
		bindEvents();
		bindServiceNavigation();

		const consent = window.WPHAVE_CONSENT.get();

		if (!consent || Object.keys(consent).length === 0) {
			showBanner();
			return;
		}

		syncInputsFromConsent(consent);
		hideBanner();
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
})();
