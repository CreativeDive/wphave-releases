﻿/**
 * Synchronize the consent banner, preferences dialog and reopen control.
 */

(function () {
	'use strict';

	const DATA = window.WPHAVE_CONSENT_DATA || { categories: [] };

	function getBanner() {
		return document.getElementById('wph-cons');
	}

	function getReopen() {
		return document.getElementById('wph-cons-reopen');
	}

	function setVisibility(element, visible) {
		if (!element) return;

		element.hidden = !visible;
		element.setAttribute('aria-hidden', visible ? 'false' : 'true');
		element.classList.toggle('is-hidden', !visible);
	}

	function showBanner() {
		setVisibility(getBanner(), true);
		setVisibility(getReopen(), false);
	}

	function hideBanner() {
		setVisibility(getBanner(), false);
		setVisibility(getReopen(), true);
	}

	function syncInputsFromConsent(consent = {}) {
		document.querySelectorAll('[data-category]').forEach((input) => {
			const key = input.dataset.category;
			if (!key) return;

			const category = DATA.categories.find((cat) => cat.key === key);
			const isRequired = !!category?.required;

			input.checked = isRequired ? true : !!consent[key];
		});
	}

	function bindCategoryToggles() {
		document.querySelectorAll('.wphave-consent-category').forEach((category) => {
			const header = category.querySelector('.wphave-consent-category-top');
			const toggle = category.querySelector('.wphave-consent-category-info');
			const services = category.querySelector('.wphave-consent-category-services-wrap');
			if (!header || !toggle || !services) return;

			const toggleCategory = () => {
				const isOpen = toggle.getAttribute('aria-expanded') !== 'true';
				toggle.setAttribute('aria-expanded', String(isOpen));
				services.hidden = !isOpen;
				category.classList.toggle('is-open', isOpen);
			};

			toggle.addEventListener('click', toggleCategory);
			header.addEventListener('click', (event) => {
				if (
					event.target.closest(
						'.wphave-consent-category-toggle, .wphave-consent-category-info'
					)
				)
					return;
				toggleCategory();
			});
		});
	}

	function bindEvents() {
		window.addEventListener('wphave:consent-changed', () => {
			syncInputsFromConsent(window.WPHAVE_CONSENT.get());
			hideBanner();
		});
	}

	function init() {
		bindEvents();
		bindCategoryToggles();

		const consent = window.WPHAVE_CONSENT.get();

		if (!consent || Object.keys(consent).length === 0) {
			showBanner();
			return;
		}

		syncInputsFromConsent(consent);
		hideBanner();
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
})();
