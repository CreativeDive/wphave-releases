<?php

/**
 * Consent-aware output for administrator-provided custom scripts.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPHAVE_Consent_Custom_Scripts {

    protected $config;

    /**
     * Initialize the custom script renderer.
     *
     * @param WPHAVE_Consent_Config $config Config.
     */

    public function __construct( WPHAVE_Consent_Config $config ) {
        $this->config = $config;
    }

    /**
     * Render scripts assigned to the document head.
     *
     * @return void
     */

    public function render_head() {
        $this->render_location( 'head' );
    }

    /**
     * Render scripts assigned to the opening body hook.
     *
     * @return void
     */

    public function render_body() {
        $this->render_location( 'body' );
    }

    /**
     * Render scripts assigned to the document footer.
     *
     * @return void
     */

    public function render_footer() {
        $this->render_location( 'footer' );
    }

    /**
     * Render inert script placeholders for one location.
     *
     * The source is trusted administrator input, but it must remain inert until
     * the visitor grants consent. Closing script tags are neutralized so stored
     * source cannot terminate the placeholder and append executable markup.
     *
     * @param string $location Output location.
     * @return void
     */

    public function render_location( $location ) {
        $allowed_categories = $this->get_allowed_categories();

        foreach ( $this->config->get_scripts() as $index => $script ) {
            if ( ! is_array( $script ) || ( isset( $script['enabled'] ) && ! $script['enabled'] ) || $this->normalize_location( $script['location'] ?? '' ) !== $location ) {
                continue;
            }

            $category = sanitize_key( $script['category'] ?? '' );
            $source   = $this->get_script_source( $script );

            if ( ! isset( $allowed_categories[ $category ] ) || $source === '' ) {
                continue;
            }

            // SECURITY INVARIANT: Consent-gated source remains text until activation;
            // stored closing tags cannot terminate this inert placeholder early.
            $source = preg_replace( '/<\/script/i', '<\/script', $source );

            echo '<script type="text/plain" data-consent="' . esc_attr( $category ) . '" data-wphave-custom-script="' . esc_attr( (string) $index ) . '" data-wphave-processed="1">' . $source . '</script>';
        }
    }

    /**
     * Return configured consent category keys.
     *
     * @return array<string,bool>
     */

    protected function get_allowed_categories() {
        $allowed = [];

        foreach ( $this->config->get_categories() as $category ) {
            $key = sanitize_key( $category['key'] ?? '' );

            if ( $key ) {
                $allowed[ $key ] = true;
            }
        }

        return $allowed;
    }

    /**
     * Normalize supported output locations.
     *
     * @param string $location Stored location.
     * @return string
     */

    protected function normalize_location( $location ) {
        $location = sanitize_key( $location );

        if ( $location === '' ) {
            return 'footer';
        }

        if ( $location === 'body_open' ) {
            return 'body';
        }

        return in_array( $location, [ 'head', 'body', 'footer' ], true ) ? $location : '';
    }

    /**
     * Return JavaScript source from current and legacy field names.
     *
     * A single complete script wrapper is accepted for convenience and removed
     * because the consent system creates the executable element after approval.
     *
     * @param array $script Script config.
     * @return string
     */

    protected function get_script_source( $script ) {
        $source = isset( $script['inline'] ) ? $script['inline'] : ( $script['code'] ?? '' );
        $source = is_string( $source ) ? trim( $source ) : '';

        if ( preg_match( '/^<script\b[^>]*>(.*?)<\/script>$/is', $source, $matches ) ) {
            $source = trim( $matches[1] );
        }

        return $source;
    }
}
