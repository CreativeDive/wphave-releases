<?php

/**
 * Consent configuration and visitor consent state.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPHAVE_Consent_Config {

    /**
     * Returns the privacy root config.
     *
     * @return array
     */

    public function get_privacy_root() {
		/*
		 * Runtime enforcement deliberately reads the stored configuration without
		 * checking Pro access. A downgrade makes Pro controls read-only; it must
		 * never disable consent protection that is already active.
		 */

		$data = wphave_data_get( 'privacy_settings' );

		return is_array( $data ) ? $data : [];
    }

    /**
     * Returns the normalized consent config.
     *
     * @return array
     */

    public function get_consent() {
        $privacy = $this->get_privacy_root();
        $consent = $privacy['consent'] ?? [];

        if ( ! is_array( $consent ) ) {
            $consent = [];
        }

        return wp_parse_args( $consent, [
            'mode'           => 'manual',
            'scripts'        => [],
            'services'       => [],
            'categories'     => [],
            'embed_blocking' => true,
            'banner'         => [],
            'preferences'    => [],
        ] );
    }

    /**
     * Checks whether the consent feature is enabled.
     *
     * @return bool
     */

    public function is_enabled() {
        $consent = $this->get_consent();

        /*
        * Consent output and automatic embed transformation require the
        * controlled WPHAVE theme output pipeline. WPHAVE does not enable this
        * compliance-sensitive feature for arbitrary third-party theme markup.
        */

        return ! empty( $consent['banner']['isEnabled'] ) && ! wphave_use_fse();
    }

    /**
     * Returns whether automatic embed blocking is enabled.
     *
     * @return bool
     */

    public function is_embed_blocking_enabled() {
        $consent = $this->get_consent();
        return isset( $consent['embed_blocking'] ) ? (bool) $consent['embed_blocking'] : true;
    }

    /**
     * Returns stored service mappings.
     *
     * @return array
     */

    public function get_services() {
        $consent = $this->get_consent();
        $services = is_array( $consent['services'] ?? null ) ? $consent['services'] : [];

        return array_values( apply_filters( 'wphave_consent_services', $services ) );
    }

    /**
     * Returns user-defined script config.
     *
     * @return array
     */

    public function get_scripts() {
        $consent = $this->get_consent();
        return is_array( $consent['scripts'] ?? null ) ? $consent['scripts'] : [];
    }

    /**
     * Returns default consent categories.
     *
     * @return array[]
     */

    public function get_categories() {
        return [
            [
                'key'         => 'necessary',
                'label'       => __( 'Necessary', 'wphave' ),
                'required'    => true,
                'description' => __( 'These services are essential for the proper functioning of the website and cannot be disabled.', 'wphave' ),
            ],
            [
                'key'         => 'analytics',
                'label'       => __( 'Analytics', 'wphave' ),
                'description' => __( 'These services help us understand how visitors interact with the website in order to improve performance and usability.', 'wphave' ),
            ],
            [
                'key'         => 'marketing',
                'label'       => __( 'Marketing', 'wphave' ),
                'description' => __( 'These services are used to display personalized content and advertisements, and to measure the effectiveness of marketing campaigns.', 'wphave' ),
            ],
            [
                'key'         => 'preferences',
                'label'       => __( 'Preferences', 'wphave' ),
                'description' => __( 'These services allow the website to remember choices you make, such as language or region, to provide a more personalized experience.', 'wphave' ),
            ],
        ];
    }

    /**
     * Checks whether the current visitor has consent for a category.
     *
     * @param string $category Consent category.
     * @return bool
     */

    public function has_consent( $category ) {
        if ( $category === 'necessary' ) {
            return true;
        }

        if ( empty( $_COOKIE['wphave_consent'] ) ) {
            return false;
        }

        $consent = json_decode( stripslashes( $_COOKIE['wphave_consent'] ), true );

        return is_array( $consent ) && ! empty( $consent[ $category ] );
    }
}
