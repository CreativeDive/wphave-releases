<?php

/**
 * Accessible consent banner, preferences modal and reopen control output.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPHAVE_Consent_Renderer {

    protected $config;

    /**
     * Initialize the consent renderer service.
     *
     * @param WPHAVE_Consent_Config $config Config.
     */

    public function __construct( WPHAVE_Consent_Config $config ) {
        $this->config = $config;
    }

    /**
     * Renders the consent banner, preferences modal and reopen button.
     * Keep your existing full HTML here if you want the exact same UI.
     *
     * @return void
     */

    public function render() {
        $consent = $this->config->get_consent();
        $banner = $consent['banner'] ?? [];
        $preferences = $consent['preferences'] ?? [];

        $categories = $this->config->get_categories();
        $services = array_filter( $this->config->get_services(), function( $service ) {
            return ! isset( $service['blockingEnabled'] ) || $service['blockingEnabled'];
        } );
        $services = array_merge( $services, $this->get_custom_script_services() );

        $position = $banner['position'] ?? 'bottom';

        $title             = ! empty( $banner['title'] ) ? $banner['title'] : __( 'Cookie Consent', 'wphave' );
        $description       = ! empty( $banner['description'] ) ? $banner['description'] : __( 'We use cookies to help you navigate efficiently and perform certain functions. You will find detailed information about all cookies under each consent category below.', 'wphave' );
        $accept_all_label  = ! empty( $banner['accept_button'] ) ? $banner['accept_button'] : __( 'Accept all', 'wphave' );
        $reject_all_label  = ! empty( $banner['reject_button'] ) ? $banner['reject_button'] : __( 'Reject all', 'wphave' );

        $preferences_label = ! empty( $banner['preferences_button'] ) ? $banner['preferences_button'] : __( 'Preferences', 'wphave' );
        $preferences_desc  = ! empty( $preferences['description'] ) ? $preferences['description'] : __( 'Choose which categories may load optional services. Necessary services are always enabled.', 'wphave' );
        $save_label        = ! empty( $banner['save_button'] ) ? $banner['save_button'] : __( 'Save preferences', 'wphave' );

        ?>
        <aside class="wphave-consent wphave-consent-banner is-hidden position-<?php echo esc_attr( $position ); ?>" id="wph-cons" aria-labelledby="wph-cons-title" aria-describedby="wph-cons-description" aria-hidden="true" hidden>
            <div class="wphave-consent-content">
                <div class="wphave-consent-title" id="wph-cons-title"><?php echo esc_html( $title ); ?></div>
                <p id="wph-cons-description"><?php echo esc_html( $description ); ?></p>

                <div class="wphave-consent-actions">
                    <button class="wphave-consent-btn secondary" type="button" data-modal="#wphave-consent-preferences" aria-haspopup="dialog" aria-controls="wphave-consent-preferences" aria-expanded="false">
                        <?php echo esc_html( $preferences_label ); ?>
                    </button>
                    <div>
                        <button class="wphave-consent-btn" type="button" data-action="accept-all"><?php echo esc_html( $accept_all_label ); ?></button>
                        <button class="wphave-consent-btn" type="button" data-action="reject-all"><?php echo esc_html( $reject_all_label ); ?></button>
                    </div>
                </div>
            </div>
        </aside>

        <?php echo wphave_render_modal( [
            'id' => 'wphave-consent-preferences',
            'labelledby' => 'wphave-consent-preferences-title',
            'describedby' => 'wphave-consent-preferences-description',
            'class' => 'wphave-consent wphave-consent-modal',
            'wrapper_class' => 'wphave-consent-modal-box',
            'variant' => 'bare',
        ], function() use ( $preferences_desc, $categories, $services, $reject_all_label, $accept_all_label, $save_label ) {
            ?>
            <div class="wphave-consent-modal-header">
                <div class="wphave-consent-title" id="wphave-consent-preferences-title"><?php echo esc_html__( 'Privacy Preferences', 'wphave' ); ?></div>
            </div>

            <div class="wphave-consent-modal-content">
                <p id="wphave-consent-preferences-description"><?php echo esc_html( $preferences_desc ); ?></p>

                <form class="wphave-consent-modal-categories">
                    <?php $this->render_category_rows( $categories, $services ); ?>
                </form>
            </div>

            <div class="wphave-consent-modal-actions">
                <div>
                    <button class="wphave-consent-btn secondary" type="button" data-action="reject-all"><?php echo esc_html( $reject_all_label ); ?></button>
                    <button class="wphave-consent-btn secondary" type="button" data-action="accept-all"><?php echo esc_html( $accept_all_label ); ?></button>
                </div>
                <button class="wphave-consent-btn" type="button" data-action="save-settings"><?php echo esc_html( $save_label ); ?></button>
            </div>
            <?php
        } ); ?>

        <button class="wphave-consent wphave-consent-reopen is-hidden" data-modal="#wphave-consent-preferences" data-tooltip="<?php echo esc_attr__( 'Consent Preferences', 'wphave' ); ?>" data-placement="top" id="wph-cons-reopen" type="button" aria-label="<?php echo esc_attr__( 'Consent Preferences', 'wphave' ); ?>" aria-haspopup="dialog" aria-controls="wphave-consent-preferences" aria-expanded="false" aria-hidden="true" hidden>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                <path d="m14.58,12.35c-.04.51-.07.91-.1,1.32-.02.25-.22.43-.43.42-.23-.02-.37-.24-.36-.52.03-.54.07-1.08.07-1.61,0-.75-.49-1.4-1.2-1.64-.74-.24-1.52,0-1.97.61-.25.33-.35.71-.35,1.13,0,1.48-.15,2.95-.5,4.39-.24.99-.58,1.95-1.08,2.84-.06.11-.14.23-.21.33-.14.2-.3.24-.5.13-.17-.1-.24-.3-.17-.5.01-.03.03-.06.05-.1.76-1.28,1.16-2.68,1.41-4.13.18-1.03.24-2.07.25-3.11.01-1.24.96-2.31,2.23-2.45,1.41-.15,2.61.81,2.82,2.11.05.29.03.58.04.78Z"/>
                <path d="m12.05,3.25c3.65.18,6.33,1.86,7.94,5.18.36.74.57,1.53.67,2.35.03.27-.11.47-.36.5-.22.03-.39-.13-.43-.41-.39-2.53-1.7-4.44-3.89-5.75-1.03-.62-2.16-.95-3.36-1.04-.8-.06-1.58,0-2.35.17-.18.04-.37.03-.47-.13-.06-.1-.1-.27-.06-.38.04-.11.18-.22.29-.25.66-.16,1.33-.25,2.02-.25Z"/>
                <path d="m12.03,5.31c1.16,0,2.25.28,3.26.85.06.03.13.07.18.12.14.14.15.36.04.51-.12.16-.32.19-.52.1-.41-.18-.81-.4-1.23-.52-3.2-.97-6.58.81-7.41,4.12-.12.48-.14.98-.19,1.47-.03.24-.15.39-.35.41-.26.03-.43-.14-.43-.43,0-.61.07-1.22.25-1.81.78-2.55,2.49-4.1,5.07-4.69.16-.04.33-.06.5-.08.28-.03.56-.04.84-.06Z"/>
                <path d="m18.67,12.42c-.07,2.12-.42,4.18-1.29,6.14-.08.17-.16.34-.25.51-.12.23-.31.3-.52.2-.21-.1-.26-.34-.16-.57.22-.5.45-.99.62-1.5.37-1.08.6-2.19.7-3.32.06-.64.09-1.28.1-1.92.01-1.02-.25-1.97-.74-2.87-.03-.05-.06-.09-.08-.14-.1-.21-.02-.42.17-.52.2-.1.41-.04.52.16.34.58.58,1.19.73,1.84.15.66.2,1.32.17,2Z"/>
                <path d="m11.99,7.38c2.02-.02,3.84,1.31,4.42,3.25.08.28,0,.47-.24.55-.22.07-.43-.06-.52-.32-.5-1.51-1.54-2.42-3.11-2.65-1.24-.18-2.35.15-3.26,1.04-.06.06-.13.12-.21.16-.16.07-.37,0-.46-.15-.09-.14-.07-.35.07-.49.39-.41.84-.73,1.35-.96.61-.28,1.26-.42,1.95-.43Z"/>
                <path d="m16.59,12.96c-.14,2.43-.65,4.77-1.86,6.91-.07.12-.15.25-.23.36-.14.18-.33.22-.52.11-.17-.1-.23-.3-.16-.5.02-.04.03-.08.06-.11.85-1.38,1.35-2.88,1.64-4.46.14-.77.2-1.56.29-2.35.03-.26.17-.42.4-.41.23,0,.39.2.39.45Z"/>
                <path d="m8.28,11.12c-.06,1-.09,2-.18,2.99-.13,1.38-.43,2.73-1,4.01-.05.11-.1.22-.16.32-.12.21-.33.28-.52.18-.19-.1-.27-.32-.17-.54.11-.25.23-.5.33-.75.36-.96.6-1.95.7-2.97.08-.83.1-1.66.15-2.49.02-.29.05-.57.1-.85.04-.22.23-.34.43-.31.21.03.34.2.32.42Z"/>
                <path d="m13.82,15.07c.26,0,.45.22.39.47-.39,1.76-.97,3.45-1.92,4.99-.1.16-.22.25-.41.22-.16-.02-.29-.11-.32-.27-.02-.1-.01-.22.04-.3.89-1.49,1.46-3.1,1.84-4.78.05-.21.19-.33.39-.33Z"/>
                <path d="m12.46,12.67c-.06,1.4-.22,2.79-.65,4.13-.06.2-.14.39-.23.58-.1.21-.32.28-.53.18-.18-.08-.26-.3-.17-.5.39-.95.59-1.95.68-2.98.06-.69.08-1.39.11-2.08.01-.25.17-.42.39-.43.23,0,.39.17.39.44,0,.22,0,.43,0,.65Z"/>
                <path d="m3.34,11.99c-.02-1.03.15-2.03.5-3,.06-.15.13-.28.31-.32.33-.07.55.2.45.55-.15.55-.31,1.09-.42,1.64-.12.65-.11,1.31-.05,1.97.02.17.04.34.05.52.01.22-.1.4-.25.42-.23.03-.45-.1-.5-.31-.05-.24-.08-.48-.1-.73-.02-.24,0-.49,0-.74Z"/>
                <path d="m6.03,14.28c-.1.81-.2,1.59-.52,2.33-.07.15-.14.31-.33.35-.15.03-.27-.01-.37-.13-.11-.13-.12-.27-.07-.44.12-.36.24-.71.33-1.08.08-.35.11-.72.16-1.08.03-.22.15-.38.35-.4.19-.03.35.06.41.24.02.07.03.14.04.2Z"/>
                <path d="m5.94,6.76c-.2-.03-.32-.1-.39-.26-.07-.16-.03-.31.09-.43.45-.41.91-.81,1.37-1.2.14-.12.3-.21.46-.31.2-.12.41-.07.53.12.12.19.08.41-.12.53-.62.4-1.2.85-1.7,1.39-.07.08-.19.11-.25.15Z"/>
                <path d="m20.28,12.68c.23,0,.42.18.38.42-.08.48-.19.95-.3,1.42-.05.2-.29.3-.48.24-.21-.06-.32-.25-.27-.47.09-.42.18-.84.27-1.26.05-.22.19-.34.4-.34Z"/>
                <path d="m10.88,19.11s-.02.1-.06.17c-.16.32-.33.64-.5.95-.11.2-.33.25-.52.15-.19-.11-.25-.33-.15-.53.17-.32.33-.64.5-.95.1-.18.27-.26.45-.22.19.05.3.19.3.43Z"/>
            </svg>
        </button>
        <?php
    }

    /**
     * Represent custom scripts as disclosure-only service entries.
     *
     * Script source is intentionally never exposed in the preferences modal.
     *
     * @return array[]
     */

    protected function get_custom_script_services() {
        $services = [];

        foreach ( $this->config->get_scripts() as $script ) {
            if ( ! is_array( $script ) || ( isset( $script['enabled'] ) && ! $script['enabled'] ) || empty( $script['category'] ) ) {
                continue;
            }

            $name   = isset( $script['name'] ) && is_string( $script['name'] ) ? trim( $script['name'] ) : '';
            $source = isset( $script['inline'] ) ? $script['inline'] : ( $script['code'] ?? '' );
            $source = is_string( $source ) ? trim( $source ) : '';

            if ( $name === '' || $source === '' ) {
                continue;
            }

            $services[] = [
                'category'    => sanitize_key( $script['category'] ),
                'label'       => $name,
                'description' => __( 'Custom script', 'wphave' ),
            ];
        }

        return $services;
    }

    /**
     * Render category rows.
     *
     * @param mixed $categories Categories.
     * @param mixed $services Services.
     */

    protected function render_category_rows( $categories, $services ) {
        $has_any = false;

        foreach ( $categories as $category ) {
            $key = $category['key'] ?? '';

            foreach ( $services as $service ) {
                if ( ! empty( $service['category'] ) && $service['category'] === $key ) {
                    $has_any = true;
                    break 2;
                }
            }
        }

        foreach ( $categories as $category ) {
            $key      = $category['key'] ?? '';
            $label    = $category['label'] ?? $key;
            $required = ! empty( $category['required'] );
            $desc     = $category['description'] ?? '';

            $category_services = array_filter( $services, function( $service ) use ( $key ) {
                return ! empty( $service['category'] ) && $service['category'] === $key;
            } );

            if ( empty( $category_services ) ) {
                continue;
            }

            $checked = $required || $this->config->has_consent( $key );
            ?>
            <?php
            $category_id = 'wphave-consent-category-' . sanitize_html_class( $key );
            $services_id = $category_id . '-services';
            $switch_id = $category_id . '-switch';
            $label_id = $category_id . '-label';
            ?>
            <div class="wphave-consent-category" data-category-row="<?php echo esc_attr( $key ); ?>">
                <div class="wphave-consent-category-top">
                    <button class="wphave-consent-category-info" type="button" aria-expanded="false" aria-controls="<?php echo esc_attr( $services_id ); ?>">
                        <strong id="<?php echo esc_attr( $label_id ); ?>"><?php echo esc_html( $label ); ?></strong>
                        <?php if ( $required ) : ?>
                            <span class="wphave-consent-badge"><?php echo esc_html__( 'Required', 'wphave' ); ?></span>
                        <?php endif; ?>
                    </button>

                    <div class="wphave-consent-category-toggle">
                        <input id="<?php echo esc_attr( $switch_id ); ?>" type="checkbox" data-category="<?php echo esc_attr( $key ); ?>" aria-labelledby="<?php echo esc_attr( $label_id ); ?>" <?php checked( $checked ); ?> <?php disabled( $required ); ?> role="switch" />
                    </div>
                </div>

                <div class="wphave-consent-category-services-wrap" id="<?php echo esc_attr( $services_id ); ?>" hidden>
                    <div class="wphave-consent-category-services">
                        <?php if ( $desc ) : ?>
                            <p><?php echo esc_html( $desc ); ?></p>
                        <?php endif; ?>

                        <small><?php echo esc_html__( 'Assigned services', 'wphave' ); ?></small>
                        <ul>
                            <?php foreach ( $category_services as $service ) : ?>
                                <li>
                                    <strong><?php echo esc_html( $service['label'] ?? $service['domain'] ?? '' ); ?></strong>
                                    <?php if ( ! empty( $service['description'] ) ) : ?>
                                        <span><?php echo esc_html( $service['description'] ); ?></span>
                                    <?php endif; ?>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div>
            <?php
        }

        if ( ! $has_any ) {
            echo esc_html__( 'No services were found that matched a category!', 'wphave' );
        }
    }
}
