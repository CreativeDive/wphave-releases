<?php

/**
 * Consent-aware domain normalization and category resolution.
 */

if (!defined('ABSPATH')) {
    exit();
}

class WPHAVE_Consent_Domain_Resolver {
    protected $config;

    /**
     * Initialize the consent domain resolver service.
     *
     * @param WPHAVE_Consent_Config $config Config.
     */

    public function __construct(WPHAVE_Consent_Config $config) {
        $this->config = $config;
    }

    /**
     * Normalizes a domain for matching.
     *
     * @param string $domain Domain or host.
     * @return string
     */

    public function normalize($domain) {
        $domain = strtolower(trim((string) $domain));
        $domain = preg_replace('/^www\./', '', $domain);
        $domain = preg_replace('/:\d+$/', '', $domain);

        return $domain;
    }

    /**
     * Extracts and normalizes host from a URL.
     *
     * @param string $url URL.
     * @return string
     */

    public function get_domain_from_url($url) {
        $host = parse_url($url, PHP_URL_HOST);
        return $host ? $this->normalize($host) : '';
    }

    /**
     * Checks whether a domain belongs to the current site or local dev.
     *
     * @param string $domain Domain.
     * @return bool
     */

    public function is_internal($domain) {
        if (empty($domain)) {
            return true;
        }

        $domain = $this->normalize($domain);
        $site = $this->normalize(parse_url(home_url(), PHP_URL_HOST));

        // CONSENT INVARIANT: Similar-looking external hosts are never local exemptions.
        return $domain === $site || $domain === 'localhost' || str_ends_with($domain, '.local');
    }

    /**
     * Checks whether a domain is privacy-relevant but not consent-controlled.
     *
     * @param string $domain Domain.
     * @return bool
     */

    public function is_sensitive($domain) {
        $domain = $this->normalize($domain);

        foreach (
            ['googleapis.com', 'gstatic.com', 'jsdelivr.net', 'unpkg.com', 'cdnjs.cloudflare.com']
            as $sensitive_domain
        ) {
            if ($domain === $sensitive_domain || str_ends_with($domain, '.' . $sensitive_domain)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Resolves a category from saved service mappings.
     *
     * @param string $domain Domain.
     * @return string|false
     */

    public function get_saved_category($domain) {
        $domain = $this->normalize($domain);

        $services = $this->config->get_services();
        // CONSENT INVARIANT: A specific subdomain rule wins over its parent rule.
        usort(
            $services,
            fn($a, $b) => strlen($this->normalize($b['domain'] ?? '')) <=>
                strlen($this->normalize($a['domain'] ?? '')),
        );
        foreach ($services as $service) {
            if (empty($service['domain'])) {
                continue;
            }

            $service_domain = $this->normalize($service['domain']);

            if ($domain === $service_domain || str_ends_with($domain, '.' . $service_domain)) {
                if (isset($service['blockingEnabled']) && !$service['blockingEnabled']) {
                    return 'necessary';
                }

                if (empty($service['category'])) {
                    continue;
                }

                return $service['category'];
            }
        }

        return false;
    }

    /**
     * Resolves a category exclusively from an explicit saved mapping.
     *
     * @param string $domain Domain.
     * @return string|null
     */

    public function resolve_category($domain) {
        $saved = $this->get_saved_category($domain);

        return $saved ?: null;
    }
}
