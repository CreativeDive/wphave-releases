<?php

/**
 * Consent-aware domain normalization and category resolution.
 */

if (!defined('ABSPATH')) {
    exit();
}

class WPHAVE_Consent_Domain_Resolver {
    protected $config;

    /**
     * Initialize the consent domain resolver service.
     *
     * @param WPHAVE_Consent_Config $config Config.
     */

    public function __construct(WPHAVE_Consent_Config $config) {
        $this->config = $config;
    }

    /**
     * Normalizes a domain for matching.
     *
     * @param string $domain Domain or host.
     * @return string
     */

    public function normalize($domain) {
        $domain = strtolower(trim((string) $domain));
        $domain = preg_replace('/^www\./', '', $domain);
        $domain = preg_replace('/:\d+$/', '', $domain);

        return $domain;
    }

    /**
     * Extracts and normalizes host from a URL.
     *
     * @param string $url URL.
     * @return string
     */

    public function get_domain_from_url($url) {
        $host = parse_url($url, PHP_URL_HOST);
        return $host ? $this->normalize($host) : '';
    }

    /**
     * Checks whether a domain belongs to the current site or local dev.
     *
     * @param string $domain Domain.
     * @return bool
     */

    public function is_internal($domain) {
        if (empty($domain)) {
            return true;
        }

        $domain = $this->normalize($domain);
        $site = $this->normalize(wp_parse_url(home_url(), PHP_URL_HOST));

        // CONSENT INVARIANT: "Local" means this site's host family. A public
        // page may otherwise bypass consent for localhost or another .local
        // service on the visitor's own network, not the WordPress origin.
        return $domain === $site;
    }

    /** Whether a browser resource URL belongs to the exact site origin. */
    public function is_internal_url($url): bool {
        $candidate = wp_parse_url((string) $url);
        $site = wp_parse_url(home_url('/'));
        if (!is_array($candidate) || !is_array($site)) {
            return false;
        }

        if (empty($candidate['host']) && empty($candidate['scheme'])) {
            return true;
        }

        if (empty($candidate['host']) || empty($site['host']) || empty($site['scheme'])) {
            return false;
        }

        $scheme = strtolower((string) ($candidate['scheme'] ?? $site['scheme']));
        $site_scheme = strtolower((string) $site['scheme']);
        $default_port = static fn(string $value): int => 'https' === $value ? 443 : 80;
        $candidate_port = (int) ($candidate['port'] ?? $default_port($scheme));
        $site_port = (int) ($site['port'] ?? $default_port($site_scheme));

        // CONSENT INVARIANT: Hostname alone is insufficient authority. Another
        // port or scheme on that host may be a distinct third-party service.
        return in_array($scheme, ['http', 'https'], true) &&
            $scheme === $site_scheme &&
            strtolower(rtrim((string) $candidate['host'], '.')) ===
                strtolower(rtrim((string) $site['host'], '.')) &&
            $candidate_port === $site_port &&
            empty($candidate['user']) &&
            empty($candidate['pass']);
    }

    /**
     * Checks whether a domain is privacy-relevant but not consent-controlled.
     *
     * @param string $domain Domain.
     * @return bool
     */

    public function is_sensitive($domain) {
        $domain = $this->normalize($domain);

        foreach (
            ['googleapis.com', 'gstatic.com', 'jsdelivr.net', 'unpkg.com', 'cdnjs.cloudflare.com']
            as $sensitive_domain
        ) {
            if ($domain === $sensitive_domain || str_ends_with($domain, '.' . $sensitive_domain)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Resolves a category from saved service mappings.
     *
     * @param string $domain Domain.
     * @return string|false
     */

    public function get_saved_category($domain) {
        $domain = $this->normalize($domain);

        $services = $this->config->get_services();
        // CONSENT INVARIANT: A specific subdomain rule wins over its parent rule.
        usort(
            $services,
            fn($a, $b) => strlen($this->normalize($b['domain'] ?? '')) <=>
                strlen($this->normalize($a['domain'] ?? '')),
        );
        foreach ($services as $service) {
            if (empty($service['domain'])) {
                continue;
            }

            $service_domain = $this->normalize($service['domain']);

            if ($domain === $service_domain || str_ends_with($domain, '.' . $service_domain)) {
                if (isset($service['blockingEnabled']) && !$service['blockingEnabled']) {
                    return 'necessary';
                }

                if (empty($service['category'])) {
                    continue;
                }

                return $service['category'];
            }
        }

        return false;
    }

    /**
     * Resolves a category exclusively from an explicit saved mapping.
     *
     * @param string $domain Domain.
     * @return string|null
     */

    public function resolve_category($domain) {
        $saved = $this->get_saved_category($domain);

        return $saved ?: null;
    }
}
