<?php

/**
 * Central consent service composition and WordPress hook registration.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPHAVE_Consent_Manager {

    protected static $instance = null;

    protected $config;
    protected $domains;
    protected $detectors;
    protected $script_blocker;
    protected $embed_blocker;
    protected $html_processor;
    protected $assets;
    protected $renderer;
    protected $custom_scripts;

    protected $buffer_started = false;
    protected $buffer_level   = 0;

    /**
     * Returns singleton instance.
     *
     * @return static
     */

    public static function instance() {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Constructor.
     */

    public function __construct() {
        $this->config    = new WPHAVE_Consent_Config();
        $this->domains   = new WPHAVE_Consent_Domain_Resolver( $this->config );
        $this->detectors = new WPHAVE_Consent_Detector_Registry();

        $this->script_blocker = new WPHAVE_Consent_Script_Blocker( $this->config, $this->domains );
        $this->embed_blocker  = new WPHAVE_Consent_Embed_Blocker( $this->config, $this->domains );
        $this->html_processor = new WPHAVE_Consent_Html_Processor( $this->script_blocker, $this->embed_blocker );
        $this->assets         = new WPHAVE_Consent_Assets( $this->config, $this->domains, $this->detectors );
        $this->renderer       = new WPHAVE_Consent_Renderer( $this->config );
        $this->custom_scripts = new WPHAVE_Consent_Custom_Scripts( $this->config );

        if ( ! $this->config->is_enabled() ) {
            return;
        }

        $this->register_hooks();
    }

    /**
     * Registers WordPress hooks.
     *
     * @return void
     */

    protected function register_hooks() {
        add_action( 'wp_enqueue_scripts', [ $this->assets, 'enqueue' ] );
        add_action( 'wp_head', [ $this->custom_scripts, 'render_head' ], 100 );
        add_action( 'wp_body_open', [ $this->custom_scripts, 'render_body' ] );
        add_action( 'wp_footer', [ $this->custom_scripts, 'render_footer' ], 4 );
        add_action( 'wp_footer', [ $this->renderer, 'render' ], 5 );

        add_filter( 'script_loader_tag', [ $this->script_blocker, 'filter_wp_script_tag' ], 10, 3 );

        /*
        * Register consent HTML processor in global output pipeline.
        * Runs EARLY so scripts, embeds and inline tracking code are blocked
        * before any further processing (e.g. caching).
        *
        * Important:
        * - Must run before cache to ensure only safe HTML is stored
        * - Works independently from cache (always executed)
        *
        * This guarantees GDPR-compliant output in all scenarios.
        */

        WPHAVE_Output_Buffer::instance()->register(
            [ $this->html_processor, 'process' ],
            20 // <-- Priority must be lower than wphave static cache buffer priority !
        );
    }

    /**
     * Public proxy for registering detector rules.
     *
     * @param array $args Detector config.
     * @return void
     */

    public function register_detector( $args = [] ) {
        $this->detectors->register( $args );
    }

    /**
     * Public proxy for registering embed providers.
     *
     * @param array $args Embed config.
     * @return void
     */

    public function register_embed( $args = [] ) {
        $this->embed_blocker->register_embed( $args );
    }

    /**
     * Returns registered detectors.
     *
     * @return array
     */

    public function get_detectors() {
        return $this->detectors->all();
    }

    /**
     * Determine whether consent management is enabled.
     */

    public function is_enabled() {
        return $this->config->is_enabled();
    }

    /**
     * Returns whether the current visitor consented to a category.
     *
     * @param string $category Consent category.
     * @return bool
     */

    public function has_consent( $category ) {
        return $this->config->has_consent( $category );
    }
}
