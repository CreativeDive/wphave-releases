<?php

/**
 * Consent placeholders and restoration metadata for external embeds.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPHAVE_Consent_Embed_Blocker {

    protected $config;
    protected $domains;
    protected $registry = [];
    protected $style_text = [];

    /**
     * Initialize the consent embed blocker service.
     *
     * @param WPHAVE_Consent_Config $config Config.
     * @param WPHAVE_Consent_Domain_Resolver $domains Domains.
     */

    public function __construct( WPHAVE_Consent_Config $config, WPHAVE_Consent_Domain_Resolver $domains ) {
        $this->config  = $config;
        $this->domains = $domains;
    }

    /**
     * Registers an embed provider definition.
     *
     * @param array $args Embed config.
     * @return void
     */

    public function register_embed( $args = [] ) {
        $embed = wp_parse_args( $args, [
            'tag'            => 'blockquote',
            'class'          => '',
            'domain'         => '',
            'category'       => null,
            'script_domains' => [],
        ] );

        if ( ! is_array( $embed['script_domains'] ) ) {
            $embed['script_domains'] = [];
        }

        $this->registry[] = $embed;
    }

    /**
     * Processes all DOM-based embeds and iframes.
     *
     * @param string $html HTML.
     * @return string
     */

    public function process( $html ) {
        if ( ! $this->config->is_embed_blocking_enabled() ) {
            return $html;
        }

        if (
            strpos( $html, '<iframe' ) === false &&
            strpos( $html, '<blockquote' ) === false &&
            strpos( $html, 'wp-block-embed' ) === false
        ) {
            return $html;
        }

        // DOMDocument's HTML4 parser drops SVG closing tags inside CSS raw text.
        // Tokenize only STYLE contents; scripts and embeds must remain inspectable.
        $this->style_text = [];
        $processor = new WP_HTML_Tag_Processor( $html );
        $prefix = 'WPHAVE_STYLE_' . bin2hex( random_bytes( 16 ) ) . '_';

        while ( $processor->next_tag( 'STYLE' ) ) {
            $token = $prefix . count( $this->style_text );
            $this->style_text[ $token ] = $processor->get_modifiable_text();
            $processor->set_modifiable_text( $token );
        }

        $dom = new DOMDocument( '1.0', 'UTF-8' );
        $this->load_html_utf8( $dom, $processor->get_updated_html() );

        $xpath = new DOMXPath( $dom );

        $this->process_registered_embeds( $dom, $xpath );
        $this->process_iframes( $dom );

        $output = strtr( $dom->saveHTML(), $this->style_text );
        $this->style_text = [];

        return $output;
    }

    /**
     * Loads HTML into DOMDocument as UTF-8.
     *
     * @param DOMDocument $dom DOM document.
     * @param string $html HTML.
     * @return void
     */

    protected function load_html_utf8( DOMDocument $dom, $html ) {
        libxml_use_internal_errors( true );

        $dom->loadHTML(
            '<?xml encoding="UTF-8">' . $html,
            LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD
        );

        foreach ( $dom->childNodes as $node ) {
            if ( $node->nodeType === XML_PI_NODE ) {
                $dom->removeChild( $node );
                break;
            }
        }

        $dom->encoding = 'UTF-8';
    }

    /**
     * Processes registered embed provider nodes.
     *
     * @param DOMDocument $dom DOM document.
     * @param DOMXPath $xpath XPath instance.
     * @return void
     */

    protected function process_registered_embeds( DOMDocument $dom, DOMXPath $xpath ) {
        foreach ( $this->registry as $embed ) {
            $tag   = $embed['tag'] ?? '';
            $class = $embed['class'] ?? '';

            if ( ! $tag || ! $class ) {
                continue;
            }

            $query = '//' . $tag . '[contains(concat(" ", normalize-space(@class), " "), " ' . $class . ' ")]';
            $nodes = $xpath->query( $query );

            foreach ( $nodes as $node ) {
                if ( ! $node instanceof DOMElement ) {
                    continue;
                }

                if ( $this->node_is_inside_template( $node ) || $this->node_is_processed( $node ) ) {
                    continue;
                }

                $target = $this->find_embed_container( $node );

                if ( ! $target instanceof DOMElement || $this->node_is_processed( $target ) ) {
                    continue;
                }

                $original = $this->collect_embed_package_html( $dom, $target, $embed );
                $domain   = $this->extract_domain_from_html( $original ) ?: ( $embed['domain'] ?? '' );
                $domain   = $this->domains->normalize( $domain );

				if ( ! $domain || $this->domains->is_internal( $domain ) ) {
					continue;
				}

				if ( $this->domains->is_sensitive( $domain ) ) {
					continue;
				}

				$category = $this->domains->resolve_category( $domain );

                $this->replace_node_with_placeholder( $dom, $target, [
                    'category' => $category ?: 'unknown',
                    'domain'   => $domain,
                    'original' => $original,
                ] );
            }
        }
    }

    /**
     * Processes remaining iframe nodes.
     *
     * @param DOMDocument $dom DOM document.
     * @return void
     */

    protected function process_iframes( DOMDocument $dom ) {
        $iframes = iterator_to_array( $dom->getElementsByTagName( 'iframe' ) );

        foreach ( $iframes as $iframe ) {
            if ( ! $iframe instanceof DOMElement ) {
                continue;
            }

            if ( $this->node_is_inside_template( $iframe ) || $this->node_is_processed( $iframe ) ) {
                continue;
            }

            $src = $iframe->getAttribute( 'src' );

            if ( empty( $src ) ) {
                continue;
            }

            $domain = $this->domains->get_domain_from_url( $src );

			if ( ! $domain || $this->domains->is_internal( $domain ) ) {
				continue;
			}

			if ( $this->domains->is_sensitive( $domain ) ) {
				continue;
			}

			$category = $this->domains->resolve_category( $domain );

            $target = $this->find_embed_container( $iframe );

            if ( ! $target instanceof DOMElement ) {
                $target = $iframe;
            }

            if ( $this->node_is_processed( $target ) ) {
                continue;
            }

            $this->replace_node_with_placeholder( $dom, $target, [
                'category' => $category ?: 'unknown',
                'domain'   => $domain,
                'original' => $dom->saveHTML( $target ),
            ] );
        }
    }

    /**
     * Finds a meaningful wrapper node for an iframe/embed.
     *
     * @param DOMElement $node Starting node.
     * @return DOMElement
     */

    protected function find_embed_container( DOMElement $node ) {
        $current    = $node;
        $max_levels = 6;
        $level      = 0;

        while ( $current && $current->parentNode && $level < $max_levels ) {
            $parent = $current->parentNode;

            if ( ! $parent instanceof DOMElement ) {
                break;
            }

            $tag   = strtolower( $parent->tagName );
            $class = $parent->getAttribute( 'class' );

            if ( $tag === 'figure' && ( str_contains( $class, 'wp-block-embed' ) || str_contains( $class, 'wp-embed-aspect' ) ) ) {
                return $parent;
            }

            if ( $tag === 'blockquote' && ( str_contains( $class, 'tiktok-embed' ) || str_contains( $class, 'instagram-media' ) || str_contains( $class, 'twitter-tweet' ) ) ) {
                return $parent;
            }

            $current = $parent;
            $level++;
        }

        return $node;
    }

    /**
     * Collects an embed node plus directly following related loader scripts.
     *
     * @param DOMDocument $dom DOM document.
     * @param DOMElement $node Embed node.
     * @param array $embed Embed provider config.
     * @return string
     */

    protected function collect_embed_package_html( DOMDocument $dom, DOMElement $node, array $embed = [] ) {
        $html = $dom->saveHTML( $node );

        $allowed_script_domains = array_filter( array_map( [ $this->domains, 'normalize' ], $embed['script_domains'] ?? [] ) );
        $embed_domain           = ! empty( $embed['domain'] ) ? $this->domains->normalize( $embed['domain'] ) : '';
        $sibling                = $node->nextSibling;

        while ( $sibling ) {
            if ( $sibling instanceof DOMText ) {
                if ( trim( $sibling->textContent ) === '' ) {
                    $html   .= $dom->saveHTML( $sibling );
                    $sibling = $sibling->nextSibling;
                    continue;
                }
                break;
            }

            if ( ! $sibling instanceof DOMElement || strtolower( $sibling->tagName ) !== 'script' ) {
                break;
            }

            $src = $sibling->hasAttribute( 'data-src' )
                ? $sibling->getAttribute( 'data-src' )
                : $sibling->getAttribute( 'src' );

            if ( empty( $src ) ) {
                break;
            }

            $script_domain = $this->domains->get_domain_from_url( $src );

            $is_related = in_array( $script_domain, $allowed_script_domains, true );

            if ( ! $is_related && $embed_domain ) {
                $is_related = ( $script_domain === $embed_domain );
            }

            if ( ! $is_related ) {
                break;
            }

            $html .= $dom->saveHTML( $sibling );

            $next = $sibling->nextSibling;
            $sibling->parentNode->removeChild( $sibling );
            $sibling = $next;
        }

        return $html;
    }

    /**
     * Builds a blocked embed placeholder.
     *
     * @param array $args Placeholder args.
     * @return string
     */

    protected function build_blocked_node( $args = [] ) {
        $args = wp_parse_args( $args, [
            'category' => 'unknown',
            'domain'   => '',
            'original' => '',
        ] );

        $category = esc_attr( $args['category'] );
        $domain   = esc_attr( $args['domain'] );
        $original = $args['original'];

        $title          = esc_html__( 'External content blocked', 'wphave' );
        $message        = esc_html__( 'This external content requires your consent.', 'wphave' );
        $settings_label = esc_html__( 'Privacy settings', 'wphave' );
        $accept_label   = esc_html__( 'Load content', 'wphave' );

        $domain_html = $domain
            ? '<small>' . esc_html__( 'Source', 'wphave' ) . ': ' . esc_html( $domain ) . '</small>'
            : '';

        return <<<HTML
<div class="wphave-consent wphave-consent-embed"
    data-wphave-processed="1"
    data-consent-placeholder="1"
    data-consent-category="{$category}"
    data-consent-domain="{$domain}">

    <div class="wphave-consent-content">
        <strong>{$title}</strong>
        <p>{$message}</p>
        {$domain_html}
    </div>

    <div class="wphave-consent-actions">
        <button type="button" class="wphave-consent-btn secondary" data-modal="#wphave-consent-preferences" aria-haspopup="dialog" aria-controls="wphave-consent-preferences" aria-expanded="false">
            {$settings_label}
        </button>

        <button type="button" class="wphave-consent-btn" data-action="accept-single">
            {$accept_label}
        </button>
    </div>

    <template class="wphave-consent-template">{$original}</template>
</div>
HTML;
    }

    /**
     * Replaces a DOM node with a placeholder fragment.
     *
     * @param DOMDocument $dom DOM document.
     * @param DOMElement $node Node to replace.
     * @param array $args Placeholder args.
     * @return void
     */

    protected function replace_node_with_placeholder( DOMDocument $dom, DOMElement $node, array $args ) {
        if ( ! $node->parentNode ) {
            return;
        }

        $placeholder = $this->build_blocked_node( $args );

        $tmp = new DOMDocument( '1.0', 'UTF-8' );
        $this->load_html_utf8( $tmp, $placeholder );

        $fragment = $dom->createDocumentFragment();

        foreach ( iterator_to_array( $tmp->childNodes ) as $child ) {
            $fragment->appendChild( $dom->importNode( $child, true ) );
        }

        $node->parentNode->replaceChild( $fragment, $node );
    }

    /**
     * Checks whether a node or any parent is already processed.
     *
     * @param DOMElement $node Node.
     * @return bool
     */

    protected function node_is_processed( DOMElement $node ) {
        while ( $node ) {
            if ( $node instanceof DOMElement && $node->hasAttribute( 'data-wphave-processed' ) ) {
                return true;
            }

            $node = $node->parentNode;
        }

        return false;
    }

    /**
     * Checks whether a node is inside a template placeholder.
     *
     * @param DOMNode $node Node.
     * @return bool
     */

    protected function node_is_inside_template( DOMNode $node ) {
        $parent = $node->parentNode;

        while ( $parent ) {
            if ( $parent instanceof DOMElement && strtolower( $parent->nodeName ) === 'template' ) {
                return true;
            }

            $parent = $parent->parentNode;
        }

        return false;
    }

    /**
     * Extracts first external-looking domain from an HTML snippet.
     *
     * @param string $html HTML.
     * @return string
     */

    protected function extract_domain_from_html( $html ) {
        if ( ! preg_match( '/https?:\/\/([^\/"\']+)/i', $html, $m ) ) {
            return '';
        }

        return $this->domains->normalize( $m[1] ?? '' );
    }
}
