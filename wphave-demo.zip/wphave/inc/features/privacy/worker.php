<?php

/** Bootstrap Privacy cleanup, scanner automation and continuation workers. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * WORKER INVARIANT: Cleanup and scanner callbacks require the processing
 * registry and entitlement boundary, but never the browser consent UI. Loading
 * bootstrap.php here would couple Cron to the public output-buffer pipeline.
 */
require_once __DIR__ . '/access.php';
require_once __DIR__ . '/core/manager.php';
require_once __DIR__ . '/core/request-manager.php';
require_once __DIR__ . '/scanner/bootstrap.php';
