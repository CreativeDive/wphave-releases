<?php

/** Privacy entitlement boundary shared by request and worker compositions. */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

if( ! function_exists( 'wphave_privacy_has_pro_access' ) ) {

	/**
	 * Determine whether Privacy Pro settings and management tools are available.
	 *
	 * Stored consent rules deliberately remain active when access expires. This
	 * avoids silently weakening an existing privacy configuration while its
	 * settings become read-only.
	 *
	 * @return bool Whether a valid Pro entitlement is available.
	 */

	function wphave_privacy_has_pro_access() {
		return function_exists( 'wphave_has_pro_access' ) && wphave_has_pro_access();
	}
}
