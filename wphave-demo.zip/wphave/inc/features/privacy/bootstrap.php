<?php

/**
 * Bootstrap privacy processing and consent services.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/access.php';
require_once __DIR__ . '/core/manager.php';
require_once __DIR__ . '/consent/functions.php';
