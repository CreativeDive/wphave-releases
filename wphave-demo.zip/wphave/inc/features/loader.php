<?php

/**
 * Load registered product features for explicit runtime contexts.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WPHAVE_Feature_Loader {

	/** @var array<string, array<string, mixed>> */
	private $features;

	/** @var array<string, bool> */
	private $loaded = array();

	/** @var array<string, bool> */
	private $loading = array();

	public function __construct( array $features ) {
		$this->features = $features;
		$this->validate();
	}

	public function load( string $context ): void {
		foreach ( array_keys( $this->features ) as $feature ) {
			$this->load_feature( $feature, $context );
		}
	}

	public function registered(): array {
		return $this->features;
	}

	private function load_feature( string $feature, string $context ): void {
		$key = $feature . ':' . $context;
		if ( isset( $this->loaded[ $key ] ) || isset( $this->loading[ $key ] ) ) {
			return;
		}

		$definition = $this->features[ $feature ] ?? null;
		$entrypoint = $definition['entrypoints'][ $context ] ?? null;
		if ( ! is_array( $definition ) || ! is_string( $entrypoint ) ) {
			return;
		}

		$this->loading[ $key ] = true;
		$gate = $definition['gate'] ?? null;
		$gated_contexts = $definition['gated_contexts'] ?? array_keys( $definition['entrypoints'] );
		if ( in_array( $context, $gated_contexts, true ) && is_callable( $gate ) && ! $gate() ) {
			unset( $this->loading[ $key ] );
			$this->loaded[ $key ] = true;
			return;
		}

		// A disabled composition root must not activate its dependencies as a side
		// effect. Shared dependencies still load normally when another enabled root
		// requests them in the same runtime context.
		foreach ( $definition['dependencies'] ?? array() as $dependency ) {
			$this->load_feature( $dependency, $context );
		}

		require_once $entrypoint;
		unset( $this->loading[ $key ] );
		$this->loaded[ $key ] = true;
	}

	private function validate(): void {
		$contexts = array( 'core', 'frontend', 'management', 'worker' );
		foreach ( $this->features as $feature => $definition ) {
			if ( ! is_string( $feature ) || '' === $feature || ! is_array( $definition ) ) {
				throw new InvalidArgumentException( 'Invalid WPHAVE feature definition.' );
			}

			foreach ( $definition['entrypoints'] ?? array() as $context => $entrypoint ) {
				if ( ! in_array( $context, $contexts, true ) || ! is_string( $entrypoint ) || ! is_file( $entrypoint ) ) {
					throw new InvalidArgumentException( 'Invalid WPHAVE feature entrypoint: ' . $feature . ':' . $context );
				}
			}

			foreach ( $definition['dependencies'] ?? array() as $dependency ) {
				if ( ! isset( $this->features[ $dependency ] ) ) {
					throw new InvalidArgumentException( 'Unknown WPHAVE feature dependency: ' . $dependency );
				}
			}
		}

		$visited = array();
		$visiting = array();
		foreach ( array_keys( $this->features ) as $feature ) {
			$this->validate_dependencies( $feature, $visited, $visiting );
		}
	}

	private function validate_dependencies( string $feature, array &$visited, array &$visiting ): void {
		if ( isset( $visited[ $feature ] ) ) {
			return;
		}

		if ( isset( $visiting[ $feature ] ) ) {
			throw new InvalidArgumentException( 'Cyclic WPHAVE feature dependency: ' . $feature );
		}

		$visiting[ $feature ] = true;
		foreach ( $this->features[ $feature ]['dependencies'] ?? array() as $dependency ) {
			$this->validate_dependencies( $dependency, $visited, $visiting );
		}

		unset( $visiting[ $feature ] );
		$visited[ $feature ] = true;
	}
}
