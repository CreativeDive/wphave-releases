<?php

/** Register the commercial write boundary in the shared core runtime. */

if (!defined('ABSPATH')) {
	exit();
}

require_once __DIR__ . '/commercial-access.php';
