<?php

/**
 * Productive WPHAVE write access for the single licensed distribution.
 *
 * Public rendering, visitor input, recovery and license administration are
 * deliberately outside this management boundary. WordPress capabilities and
 * each route's own authorization still apply after this check succeeds.
 */

if (!defined('ABSPATH')) {
	exit();
}

final class WPHAVE_Commercial_Access {
	/**
	 * Routes that maintain an existing website or its license without creating
	 * new WPHAVE-managed production content. Keep this list narrow and explicit.
	 */
	private const CONTINUITY_ROUTES = [
		'#^/wphave/v1/data/license_settings$#',
		'#^/wphave/v1/license/verify-token$#',
		'#^/wphave/v1/(?:update-status|check-updates|run-update)$#',
		'#^/wphave/v1/database/schema(?:/(?:update|network))?$#',
		'#^/wphave/v1/backups(?:/|$)#',
		'#^/wphave/v1/security/action-authorization$#',
		'#^/wphave/v1/form-(?:submit|nonce)$#',
		'#^/wphave/v1/audience/(?:public-proof|subscribers$|subscribers/confirm|unsubscribe|subscribers/[^/]+/unsubscribe)(?:/|$)#',
		'#^/wphave/v1/audience/leads$#',
		'#^/wphave/v1/campaigns/(?:unsubscribe|provider-events)(?:/|$)#',
		'#^/wphave/v1/analytics/track$#',
		'#^/wphave/v1/privacy/requests(?:/|$)#',
		'#^/wphave/v1/privacy/exports(?:/|$)#',
		'#^/wphave/v1/activity/observe$#',
		'#^/wphave/v1/user/(?:change-password|change-email)(?:/|$)#',
		'#^/wphave/v1/user-preferences$#',
	];

	public static function init(): void {
		add_filter('rest_pre_dispatch', [self::class, 'guard_rest_write'], 11, 3);
	}

	/** Return whether a request would create or change productive WPHAVE state. */
	public static function requires_license(string $route, string $method): bool {
		if (in_array(strtoupper($method), ['GET', 'HEAD', 'OPTIONS'], true)) {
			return false;
		}

		if (
			!str_starts_with($route, '/wphave/v1/') &&
			!preg_match('#^/wp/v2/wphave-[a-z0-9-]+(?:/|$)#', $route)
		) {
			return false;
		}

		foreach (self::CONTINUITY_ROUTES as $pattern) {
			if (preg_match($pattern, $route)) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Deny management writes before their callbacks can start side effects.
	 * A verified Playground demo token uses the same existing Pro authority.
	 */
	public static function guard_rest_write($result, $server, $request) {
		if (is_wp_error($result) || !$request instanceof WP_REST_Request) {
			return $result;
		}

		if (!self::requires_license((string) $request->get_route(), (string) $request->get_method())) {
			return $result;
		}

		if (function_exists('wphave_has_pro_access') && wphave_has_pro_access()) {
			return $result;
		}

		return new WP_Error(
			'wphave_license_required',
			__('An active WPHAVE license is required to change this workspace data.', 'wphave'),
			['status' => 403],
		);
	}
}

WPHAVE_Commercial_Access::init();
