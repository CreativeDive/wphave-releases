<?php

/**
 * WPHAVE Schema Validator responsibilities.
 *
 * Internal methods are protected so the schema facade can compose providers
 * through the inheritance chain without exposing implementation APIs.
 */

if( ! defined( 'ABSPATH' ) ) {
    exit;
}

abstract class WPHAVE_Schema_Validator {

    /**
     * Validate graph structure and high-value required properties.
     *
     * This is an internal quality check rather than a replacement for Google
     * Rich Results Test or the Schema.org validator.
     *
     * @param array<string,mixed> $payload JSON-LD payload.
     * @return array{errors:array<int,array<string,string>>,warnings:array<int,array<string,string>>}
     */

    public function validate_schema_payload( array $payload ): array {
        $errors = array();
        $warnings = array();
        $graph = isset( $payload['@graph'] ) && is_array( $payload['@graph'] ) ? $payload['@graph'] : array();

        if( ( $payload['@context'] ?? '' ) !== 'https://schema.org' ) {
            $errors[] = $this->validation_issue( 'context', __( 'The Schema.org context is missing or invalid.', 'wphave' ) );
        }

        if( empty( $graph ) ) {
            $errors[] = $this->validation_issue( 'graph', __( 'The JSON-LD graph contains no nodes.', 'wphave' ) );
            return compact( 'errors', 'warnings' );
        }

        $ids = array();
        foreach( $graph as $node ) {
            if( ! is_array( $node ) ) {
                $errors[] = $this->validation_issue( 'node', __( 'The graph contains an invalid node.', 'wphave' ) );
                continue;
            }

            $type = $node['@type'] ?? '';
            $id = $node['@id'] ?? '';
            if( $type === '' ) {
                $errors[] = $this->validation_issue( 'type', __( 'A graph node is missing @type.', 'wphave' ), $id );
            }

            if( $id === '' ) {
                $warnings[] = $this->validation_issue( 'id', __( 'A graph node has no stable @id.', 'wphave' ), $type );
            } elseif( isset( $ids[ $id ] ) ) {
                $errors[] = $this->validation_issue( 'duplicate_id', __( 'The graph contains a duplicate @id.', 'wphave' ), $id );
            } else {
                $ids[ $id ] = true;
            }

            $this->validate_schema_node( $node, $errors, $warnings );
        }

        return compact( 'errors', 'warnings' );
    }

    /**
     * Validate properties required or strongly recommended for one node type.
     *
     * @param array<string,mixed> $node Graph node.
     * @param array<int,array<string,string>> &$errors Collected errors.
     * @param array<int,array<string,string>> &$warnings Collected warnings.
     */

    protected function validate_schema_node( array $node, array &$errors, array &$warnings ): void {
        $type = $node['@type'] ?? '';
        $id = $node['@id'] ?? $type;

        if( in_array( $type, array( 'Organization', 'Person', 'WebSite', 'WebPage', 'CollectionPage', 'Product', 'ProductGroup', 'SoftwareApplication', 'Service', 'Event', 'VideoObject' ), true ) && empty( $node['name'] ) ) {
            $errors[] = $this->validation_issue( 'name', sprintf( /* translators: %s or %d: contextual value; 1, 2, or 3: ordered contextual values. */
            __( '%s is missing a name.', 'wphave' ), $type ), $id );
        }

        if( $type === 'Organization' && ! empty( $node['hasMerchantReturnPolicy'] ) ) {
            $this->validate_merchant_return_policy( $node['hasMerchantReturnPolicy'], $errors, $warnings );
        }

        if( $type === 'Organization' && ! empty( $node['hasShippingService'] ) ) {
            $this->validate_shipping_service( $node['hasShippingService'], $errors, $warnings );
        }

        if( $type === 'Organization' ) {
            $this->validate_organization_node( $node, $errors, $warnings );
        }

        $local_business_types = array( 'LocalBusiness', 'Store', 'Restaurant', 'ProfessionalService', 'MedicalBusiness', 'RealEstateAgent', 'AutomotiveBusiness', 'LodgingBusiness' );
        if( in_array( $type, $local_business_types, true ) ) {
            $this->validate_local_business_node( $node, $errors, $warnings );
        }

        if( $type === 'Product' ) {
            $this->validate_product_node( $node, $errors, $warnings );
        }

        if( $type === 'ProductGroup' ) {
            if( empty( $node['productGroupID'] ) || empty( $node['variesBy'] ) || empty( $node['hasVariant'] ) ) {
                $errors[] = $this->validation_issue( 'product_group_required', __( 'ProductGroup requires a group ID, variant properties and variants.', 'wphave' ), $id );
            }

            foreach( is_array( $node['hasVariant'] ?? null ) ? $node['hasVariant'] : array() as $variant ) {
                if( is_array( $variant ) ) {
                    $this->validate_product_node( $variant, $errors, $warnings );
                }
            }
        }

        if( $type === 'SoftwareApplication' ) {
            $offer_price = $node['offers']['price'] ?? null;
            if( $offer_price === null || $offer_price === '' ) {
                $errors[] = $this->validation_issue( 'software_price', __( 'SoftwareApplication requires an offer price for Google rich results.', 'wphave' ), $id );
            }

            if( empty( $node['aggregateRating'] ) && empty( $node['review'] ) ) {
                $errors[] = $this->validation_issue( 'software_rating', __( 'SoftwareApplication requires an aggregate rating or review for Google rich results.', 'wphave' ), $id );
            }

            if( ! empty( $node['aggregateRating'] ) ) {
                $rating_value = (float) ( $node['aggregateRating']['ratingValue'] ?? 0 );
                $rating_count = absint( $node['aggregateRating']['ratingCount'] ?? 0 );
                if( $rating_value < 1 || $rating_value > 5 || $rating_count < 1 ) {
                    $errors[] = $this->validation_issue( 'software_rating_invalid', __( 'SoftwareApplication aggregate rating requires a value from 1 to 5 and a positive rating count.', 'wphave' ), $id );
                }
            }

            if( empty( $node['applicationCategory'] ) ) {
                $warnings[] = $this->validation_issue( 'software_category', __( 'SoftwareApplication should specify an application category.', 'wphave' ), $id );
            }
        }

        if( $type === 'Service' ) {
            if( empty( $node['serviceType'] ) || empty( $node['provider'] ) ) {
                $errors[] = $this->validation_issue( 'service_required', __( 'Service requires a service type and provider.', 'wphave' ), $id );
            }

            if( empty( $node['areaServed'] ) ) {
                $warnings[] = $this->validation_issue( 'service_area', __( 'Service should specify the area it serves.', 'wphave' ), $id );
            }
        }

        if( $type === 'Event' ) {
            foreach( array( 'startDate', 'location', 'eventStatus', 'eventAttendanceMode', 'organizer' ) as $property ) {
                if( empty( $node[ $property ] ) ) {
                    $errors[] = $this->validation_issue( 'event_' . $property, sprintf( /* translators: %s or %d: contextual value; 1, 2, or 3: ordered contextual values. */
                    __( 'Event is missing %s.', 'wphave' ), $property ), $id );
                }
            }

            if( ! empty( $node['startDate'] ) && strtotime( $node['startDate'] ) === false ) {
                $errors[] = $this->validation_issue( 'event_start_date', __( 'Event start date is not a valid ISO date or date-time.', 'wphave' ), $id );
            }

            if( ! empty( $node['endDate'] ) && strtotime( $node['endDate'] ) < strtotime( $node['startDate'] ?? '' ) ) {
                $errors[] = $this->validation_issue( 'event_dates', __( 'Event end date must not be earlier than its start date.', 'wphave' ), $id );
            }

            if( empty( $node['image'] ) ) {
                $warnings[] = $this->validation_issue( 'event_image', __( 'Event should provide a representative image.', 'wphave' ), $id );
            }

            $locations = isset( $node['location']['@type'] ) ? array( $node['location'] ) : ( is_array( $node['location'] ?? null ) ? $node['location'] : array() );
            foreach( $locations as $location ) {
                if( ( $location['@type'] ?? '' ) === 'VirtualLocation' && empty( $location['url'] ) ) {
                    $errors[] = $this->validation_issue( 'event_virtual_location', __( 'Online event requires a public event URL.', 'wphave' ), $id );
                }

                if( ( $location['@type'] ?? '' ) === 'Place' ) {
                    foreach( array( 'streetAddress', 'postalCode', 'addressLocality', 'addressCountry' ) as $property ) {
                        if( empty( $location['address'][ $property ] ) ) {
                            $errors[] = $this->validation_issue( 'event_location_' . $property, sprintf( /* translators: %s or %d: contextual value; 1, 2, or 3: ordered contextual values. */
                            __( 'Event venue address is missing %s.', 'wphave' ), $property ), $id );
                        }
                    }
                }
            }
        }

        if( $type === 'VideoObject' ) {
            foreach( array( 'description', 'thumbnailUrl', 'uploadDate' ) as $property ) {
                if( empty( $node[ $property ] ) ) {
                    $errors[] = $this->validation_issue( 'video_' . $property, sprintf( /* translators: %s or %d: contextual value; 1, 2, or 3: ordered contextual values. */
                    __( 'VideoObject is missing %s.', 'wphave' ), $property ), $id );
                }
            }

            if( empty( $node['contentUrl'] ) && empty( $node['embedUrl'] ) ) {
                $errors[] = $this->validation_issue( 'video_url', __( 'VideoObject requires a content or embed URL.', 'wphave' ), $id );
            }

            if( ! empty( $node['uploadDate'] ) && strtotime( $node['uploadDate'] ) === false ) {
                $errors[] = $this->validation_issue( 'video_upload_date', __( 'VideoObject upload date is not a valid ISO date or date-time.', 'wphave' ), $id );
            }

            if( ! empty( $node['duration'] ) && ! preg_match( '/^P(?=\d|T\d)(?:\d+Y)?(?:\d+M)?(?:\d+D)?(?:T(?=\d)(?:\d+H)?(?:\d+M)?(?:\d+(?:\.\d+)?S)?)?$/', $node['duration'] ) ) {
                $errors[] = $this->validation_issue( 'video_duration', __( 'VideoObject duration must use ISO 8601 format such as PT1M30S.', 'wphave' ), $id );
            }
        }

        if( in_array( $type, array( 'Article', 'BlogPosting' ), true ) ) {
            foreach( array( 'headline', 'datePublished', 'author' ) as $property ) {
                if( empty( $node[ $property ] ) ) {
                    $errors[] = $this->validation_issue( 'article_' . $property, sprintf( /* translators: %s or %d: contextual value; 1, 2, or 3: ordered contextual values. */
                    __( 'Article is missing %s.', 'wphave' ), $property ), $id );
                }
            }

            if( empty( $node['image'] ) ) {
                $warnings[] = $this->validation_issue( 'article_image', __( 'Article should provide a representative image.', 'wphave' ), $id );
            }
        }

        if( $type === 'FAQPage' && empty( $node['mainEntity'] ) ) {
            $errors[] = $this->validation_issue( 'faq_questions', __( 'FAQPage contains no complete questions and answers.', 'wphave' ), $id );
        }
    }

    /**
     * Validate merchant data shared by simple, grouped and variable products.
     *
     * WooCommerce may return one Offer, an AggregateOffer or an array wrapping
     * either shape. Normalizing that variation here keeps preview diagnostics
     * accurate without changing WooCommerce's authoritative product payload.
     *
     * @param array<string,mixed> $node Product node.
     * @param array<int,array<string,string>> &$errors Collected errors.
     * @param array<int,array<string,string>> &$warnings Collected warnings.
     */

    protected function validate_product_node( array $node, array &$errors, array &$warnings ): void {
        $id = $node['@id'] ?? 'Product';
        $offers = $node['offers'] ?? array();
        $offers = isset( $offers['@type'] ) ? array( $offers ) : ( is_array( $offers ) ? $offers : array() );

        if( empty( $offers ) && empty( $node['review'] ) && empty( $node['aggregateRating'] ) ) {
            $errors[] = $this->validation_issue( 'product_offer', __( 'Product requires offers, a review or an aggregate rating for Google product results.', 'wphave' ), $id );
        }

        foreach( $offers as $offer ) {
            if( ! is_array( $offer ) ) {
                $errors[] = $this->validation_issue( 'product_offer_shape', __( 'Product contains an invalid offer.', 'wphave' ), $id );
                continue;
            }

            $offer_type = $offer['@type'] ?? '';
            $price = $offer['price'] ?? ( $offer['priceSpecification'][0]['price'] ?? '' );
            if( $offer_type === 'Offer' && $price === '' ) {
                $errors[] = $this->validation_issue( 'product_price', __( 'Product offer is missing a price.', 'wphave' ), $id );
            }

            if( $offer_type === 'AggregateOffer' && ( ! isset( $offer['lowPrice'] ) || ! isset( $offer['highPrice'] ) ) ) {
                $errors[] = $this->validation_issue( 'product_price_range', __( 'Variable or grouped product offer is missing its price range.', 'wphave' ), $id );
            }

            if( ! in_array( $offer_type, array( 'Offer', 'AggregateOffer' ), true ) ) {
                $warnings[] = $this->validation_issue( 'product_offer_type', __( 'Product offer uses an unexpected Schema.org type.', 'wphave' ), $id );
            }

            if( empty( $offer['priceCurrency'] ) ) {
                $warnings[] = $this->validation_issue( 'product_currency', __( 'Product offer should specify its currency.', 'wphave' ), $id );
            }

            if( empty( $offer['availability'] ) ) {
                $warnings[] = $this->validation_issue( 'product_availability', __( 'Product offer should specify its availability.', 'wphave' ), $id );
            }
        }

        $identifier_properties = array( 'sku', 'gtin', 'gtin8', 'gtin12', 'gtin13', 'gtin14', 'mpn' );
        $has_identifier = count( array_filter( $identifier_properties, function( $property ) use ( $node ) {
            return ! empty( $node[ $property ] );
        } ) ) > 0;
        if( ! $has_identifier ) {
            $warnings[] = $this->validation_issue( 'product_identifier', __( 'Product should provide an SKU, GTIN or MPN.', 'wphave' ), $id );
        }

        if( ! empty( $node['aggregateRating'] ) ) {
            $rating = $node['aggregateRating'];
            if( ! is_array( $rating ) || empty( $rating['ratingValue'] ) || empty( $rating['reviewCount'] ) ) {
                $errors[] = $this->validation_issue( 'product_rating', __( 'Product aggregate rating is incomplete.', 'wphave' ), $id );
            }
        }
    }

    /**
     * Validate a standard Organization-level merchant return policy.
     *
     * @param mixed $policy Return policy node.
     * @param array<int,array<string,string>> &$errors Collected errors.
     * @param array<int,array<string,string>> &$warnings Collected warnings.
     */

    protected function validate_merchant_return_policy( $policy, array &$errors, array &$warnings ): void {
        if( ! is_array( $policy ) ) {
            $errors[] = $this->validation_issue( 'return_policy_shape', __( 'Merchant return policy is invalid.', 'wphave' ) );
            return;
        }

        $id = $policy['@id'] ?? 'MerchantReturnPolicy';
        if( empty( $policy['applicableCountry'] ) || empty( $policy['returnPolicyCategory'] ) ) {
            $errors[] = $this->validation_issue( 'return_policy_required', __( 'Merchant return policy requires an applicable country and policy category.', 'wphave' ), $id );
        }

        if( ( $policy['returnPolicyCategory'] ?? '' ) === 'https://schema.org/MerchantReturnFiniteReturnWindow' && empty( $policy['merchantReturnDays'] ) ) {
            $errors[] = $this->validation_issue( 'return_policy_days', __( 'A finite merchant return window requires the number of return days.', 'wphave' ), $id );
        }

        if( empty( $policy['merchantReturnLink'] ) ) {
            $warnings[] = $this->validation_issue( 'return_policy_url', __( 'Merchant return policy should link to the public policy page.', 'wphave' ), $id );
        }
    }

    /**
     * Validate an Organization-level merchant shipping service.
     *
     * @param mixed $service Shipping service node.
     * @param array<int,array<string,string>> &$errors Collected errors.
     * @param array<int,array<string,string>> &$warnings Collected warnings.
     */

    protected function validate_shipping_service( $service, array &$errors, array &$warnings ): void {
        if( ! is_array( $service ) ) {
            $errors[] = $this->validation_issue( 'shipping_service_shape', __( 'Merchant shipping service is invalid.', 'wphave' ) );
            return;
        }

        $id = $service['@id'] ?? 'ShippingService';
        $conditions = $service['shippingConditions'] ?? array();
        $rate = $conditions['shippingRate'] ?? array();
        if( empty( $conditions['shippingDestination'] ) || ! isset( $rate['value'] ) || empty( $rate['currency'] ) ) {
            $errors[] = $this->validation_issue( 'shipping_service_required', __( 'Merchant shipping service requires a destination, rate and currency.', 'wphave' ), $id );
        }

        foreach( array( 'handlingTime' => $service['handlingTime'] ?? array(), 'transitTime' => $conditions['transitTime'] ?? array() ) as $period_name => $period ) {
            $duration = is_array( $period ) ? ( $period['duration'] ?? array() ) : array();
            if( ! isset( $duration['minValue'], $duration['maxValue'] ) || $duration['minValue'] > $duration['maxValue'] || ( $duration['unitCode'] ?? '' ) !== 'DAY' ) {
                $errors[] = $this->validation_issue( 'shipping_' . $period_name, sprintf( /* translators: %s or %d: contextual value; 1, 2, or 3: ordered contextual values. */
                __( 'Merchant shipping %s is invalid.', 'wphave' ), $period_name ), $id );
            }
        }

        if( empty( $service['name'] ) ) {
            $warnings[] = $this->validation_issue( 'shipping_service_name', __( 'Merchant shipping service should have a name.', 'wphave' ), $id );
        }
    }

    /**
     * Validate optional organization address and contact details.
     *
     * @param array<string,mixed> $node Organization node.
     * @param array<int,array<string,string>> &$errors Collected errors.
     * @param array<int,array<string,string>> &$warnings Collected warnings.
     */

    protected function validate_organization_node( array $node, array &$errors, array &$warnings ): void {
        $id = $node['@id'] ?? 'Organization';
        if( ! empty( $node['address'] ) ) {
            foreach( array( 'streetAddress', 'postalCode', 'addressLocality', 'addressCountry' ) as $property ) {
                if( empty( $node['address'][ $property ] ) ) {
                    $errors[] = $this->validation_issue( 'organization_address_' . $property, sprintf( /* translators: %s or %d: contextual value; 1, 2, or 3: ordered contextual values. */
                    __( 'Organization address is missing %s.', 'wphave' ), $property ), $id );
                }
            }

            if( ! empty( $node['address']['addressCountry'] ) && ! preg_match( '/^[A-Z]{2}$/', $node['address']['addressCountry'] ) ) {
                $errors[] = $this->validation_issue( 'organization_address_country', __( 'Organization address requires a two-letter country code.', 'wphave' ), $id );
            }
        }

        if( ! empty( $node['contactPoint'] ) && empty( $node['contactPoint']['contactType'] ) ) {
            $warnings[] = $this->validation_issue( 'organization_contact_type', __( 'Organization contact point should specify its purpose.', 'wphave' ), $id );
        }
    }

    /**
     * Validate required location data and optional geographic coordinates.
     *
     * @param array<string,mixed> $node Local business node.
     * @param array<int,array<string,string>> &$errors Collected errors.
     * @param array<int,array<string,string>> &$warnings Collected warnings.
     */

    protected function validate_local_business_node( array $node, array &$errors, array &$warnings ): void {
        $id = $node['@id'] ?? 'LocalBusiness';
        if( empty( $node['name'] ) || empty( $node['address'] ) ) {
            $errors[] = $this->validation_issue( 'local_business_required', __( 'LocalBusiness requires a name and complete physical address.', 'wphave' ), $id );
        }

        if( ! empty( $node['address'] ) ) {
            foreach( array( 'streetAddress', 'postalCode', 'addressLocality', 'addressCountry' ) as $property ) {
                if( empty( $node['address'][ $property ] ) ) {
                    $errors[] = $this->validation_issue( 'local_business_address_' . $property, sprintf( /* translators: %s or %d: contextual value; 1, 2, or 3: ordered contextual values. */
                    __( 'LocalBusiness address is missing %s.', 'wphave' ), $property ), $id );
                }
            }
        }

        if( isset( $node['geo'] ) ) {
            $latitude = $node['geo']['latitude'] ?? 91;
            $longitude = $node['geo']['longitude'] ?? 181;
            if( $latitude < -90 || $latitude > 90 || $longitude < -180 || $longitude > 180 ) {
                $errors[] = $this->validation_issue( 'local_business_geo', __( 'LocalBusiness coordinates are outside the valid latitude or longitude range.', 'wphave' ), $id );
            }
        } elseif( $type === 'Event' ) {
            $warnings[] = $this->validation_issue( 'local_business_geo', __( 'LocalBusiness should provide geographic coordinates.', 'wphave' ), $id );
        }

        if( empty( $node['telephone'] ) ) {
            $warnings[] = $this->validation_issue( 'local_business_telephone', __( 'LocalBusiness should provide a public telephone number.', 'wphave' ), $id );
        }
    }

    /**
     * Create one normalized validation result.
     *
     * @param string $code Stable issue code.
     * @param string $message Human-readable message.
     * @param string $node Optional node identifier.
     * @return array<string,string>
     */

    protected function validation_issue( string $code, string $message, string $node = '' ): array {
        return array(
            'code' => $code,
            'message' => $message,
            'node' => $node,
        );
    }
}
