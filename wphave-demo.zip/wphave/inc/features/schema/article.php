<?php

/**
 * WPHAVE Schema Article responsibilities.
 *
 * Builds Article/BlogPosting and author entities from canonical post data.\n *
 * Internal methods remain protected so extensions use the documented filters
 * instead of coupling to provider implementation APIs.
 */

if( ! defined( 'ABSPATH' ) ) {
    exit;
}

abstract class WPHAVE_Schema_Article extends WPHAVE_Schema_Content {

    /**
     * Build the Article or BlogPosting node for an eligible singular post.
     *
     * Article data is derived from the canonical WordPress post rather than
     * duplicated in schema settings. This keeps publication dates, author and
     * featured image synchronized with the visible content.
     *
     * @return array<string,mixed>
     */

    protected function get_article_node(): array {
        if( ! $this->is_article_request() ) {
            return array();
        }

        $post = get_post();
        if( ! $post ) {
            return array();
        }

        $url = get_permalink( $post );
        $description = get_post_meta( $post->ID, 'wphave_seo_description', true ) ?: get_the_excerpt( $post );
        $settings = $this->get_settings();
        $article_settings = isset( $settings['articles'] ) && is_array( $settings['articles'] ) ? $settings['articles'] : array();
        $post_type = get_post_meta( $post->ID, 'wphave_schema_article_type', true );
        $type = in_array( $post_type, array( 'Article', 'BlogPosting' ), true ) ? $post_type : ( ( $article_settings['type'] ?? 'BlogPosting' ) === 'Article' ? 'Article' : 'BlogPosting' );
        $node = array(
            '@type' => $type,
            '@id' => $url . '#article',
            'url' => $url,
            'headline' => wp_strip_all_tags( get_the_title( $post ) ),
            'description' => wp_strip_all_tags( $description ),
            'datePublished' => get_the_date( DATE_W3C, $post ),
            'dateModified' => get_the_modified_date( DATE_W3C, $post ),
            'inLanguage' => get_bloginfo( 'language' ),
            'mainEntityOfPage' => array(
                '@id' => $url . '#webpage',
            ),
            'author' => array(
                '@id' => $this->get_author_id( (int) $post->post_author ),
            ),
            'publisher' => array(
                '@id' => $this->get_id( 'identity' ),
            ),
        );

        $image = $this->get_post_image_node( $post->ID );
        $image_urls = array_values( array_filter( array(
            esc_url_raw( get_post_meta( $post->ID, 'wphave_schema_article_image_1x1', true ) ),
            esc_url_raw( get_post_meta( $post->ID, 'wphave_schema_article_image_4x3', true ) ),
            esc_url_raw( get_post_meta( $post->ID, 'wphave_schema_article_image_16x9', true ) ),
        ) ) );
        if( ! empty( $image_urls ) ) {
            $node['image'] = $image_urls;
        } elseif( ! empty( $image ) ) {
            $node['image'] = $image;
        }

        return apply_filters( 'wphave_schema_article_node', $node, $post );
    }

    /**
     * Build the Person node for the author of the current article.
     *
     * @return array<string,mixed>
     */

    protected function get_author_node(): array {
        $post = get_post();
        $author_id = $post ? (int) $post->post_author : 0;
        $author_url = $author_id ? get_author_posts_url( $author_id ) : '';

        return apply_filters( 'wphave_schema_author_node', array(
            '@type' => 'Person',
            '@id' => $this->get_author_id( $author_id ),
            'name' => get_the_author_meta( 'display_name', $author_id ),
            'url' => $author_url,
        ), $author_id );
    }

    /**
     * Check whether the current request should receive article markup.
     *
     * @return bool
     */

    protected function is_article_request(): bool {
        if( ! is_singular( 'post' ) || $this->get_primary_entity_type() !== '' || $this->post_schema_node_excluded( 'article' ) ) {
            return false;
        }

        $settings = $this->get_settings();

        return isset( $settings['articles']['isEnabled'] ) ? (bool) $settings['articles']['isEnabled'] : false;
    }
    /**
     * Build a stable identifier for a public WordPress author.
     *
     * @param int $author_id WordPress user ID.
     * @return string
     */

    protected function get_author_id( int $author_id ): string {
        $url = $author_id ? get_author_posts_url( $author_id ) : home_url( '/' );

        return $url . '#person';
    }
}
