<?php

/**
 * WPHAVE Schema Commerce responsibilities.
 *
 * Internal methods are protected so the schema facade can compose providers
 * through the inheritance chain without exposing implementation APIs.
 */

if( ! defined( 'ABSPATH' ) ) {
    exit;
}

abstract class WPHAVE_Schema_Commerce extends WPHAVE_Schema_Discovery {

    /**
     * Request-local WooCommerce node cache keyed by product ID.
     *
     * The native-output filter and graph builder must make the same ownership
     * decision. Caching prevents WooCommerce data from being generated twice
     * and lets native JSON-LD remain active when wphave cannot build a usable
     * replacement node.
     *
     * @var array<int,array<string,mixed>>
     */

    protected array $woocommerce_product_nodes = array();

    /**
     * Remove native WooCommerce page schema only when wphave explicitly owns it.
     *
     * Order and email schema remain untouched. On product pages wphave already
     * supplies the website, webpage, breadcrumb and product graph nodes, so the
     * corresponding native types would otherwise describe the same entities a
     * second time.
     *
     * @param array<int,string> $types WooCommerce structured data types.
     * @return array<int,string>
     */

    public function filter_woocommerce_structured_data_types( array $types ): array {
        if( ! $this->woocommerce_takeover_enabled() || ! function_exists( 'is_product' ) || ! is_product() || $this->post_schema_disabled() ) {
            return $types;
        }

        $post_id = get_queried_object_id();
        if( $post_id <= 0 || ! $this->woocommerce_product_node_is_usable( $this->get_woocommerce_product_node( $post_id ) ) ) {
            return $types;
        }

        $owned_types = array( 'product', 'review', 'breadcrumblist', 'website' );

        return array_values( array_diff( $types, $owned_types ) );
    }

    /**
     * Build a Product node with WooCommerce's own normalized product data.
     *
     * Reusing the native generator preserves compatibility with product types,
     * tax display settings, sales, stock states, reviews, extensions and the
     * WooCommerce Brands feature. wphave only reconnects the generated product
     * to its stable page graph identifier.
     *
     * @param int $post_id WooCommerce product post ID.
     * @return array<string,mixed>
     */

    protected function get_woocommerce_product_node( int $post_id ): array {
        if( isset( $this->woocommerce_product_nodes[ $post_id ] ) ) {
            return $this->woocommerce_product_nodes[ $post_id ];
        }

        $this->woocommerce_product_nodes[ $post_id ] = array();
        if( ! function_exists( 'wc_get_product' ) || ! function_exists( 'WC' ) ) {
            return array();
        }

        $product = wc_get_product( $post_id );
        $woocommerce = WC();
        $structured_data = $woocommerce && isset( $woocommerce->structured_data ) ? $woocommerce->structured_data : null;

        if( ! $product || ! $structured_data || ! method_exists( $structured_data, 'generate_product_data' ) || ! method_exists( $structured_data, 'get_structured_data' ) ) {
            return array();
        }

        $structured_data->generate_product_data( $product );
        $data = $structured_data->get_structured_data( array( 'product' ) );

        if( isset( $data['@graph'][0] ) && is_array( $data['@graph'][0] ) ) {
            $data = $data['@graph'][0];
        }

        if( ! is_array( $data ) || ( $data['@type'] ?? '' ) !== 'Product' ) {
            return array();
        }

        $url = get_permalink( $post_id );
        unset( $data['@context'] );
        $data['@id'] = $url . '#primary-entity';
        $data['mainEntityOfPage'] = array(
            '@id' => $url . '#webpage',
        );

        if( $product->is_type( 'variable' ) && $this->woocommerce_product_groups_enabled() ) {
            $product_group = $this->get_woocommerce_product_group_node( $data, $product );
            if( ! empty( $product_group ) ) {
                $data = $product_group;
            }
        }

        /**
         * Filter additional product identifiers before they enter the graph.
         *
         * Integrations may return supported Schema.org identifier properties
         * such as `mpn`, `gtin8`, `gtin12`, `gtin13` or `gtin14`. WooCommerce's
         * native `sku` and normalized `gtin` values are never overwritten.
         *
         * @param array<string,string> $identifiers Additional identifiers.
         * @param WC_Product $product WooCommerce product.
         */

        $identifiers = apply_filters( 'wphave_schema_woocommerce_product_identifiers', array(), $product );
        $supported_identifiers = array( 'mpn', 'gtin8', 'gtin12', 'gtin13', 'gtin14' );
        foreach( is_array( $identifiers ) ? $identifiers : array() as $key => $value ) {
            if( ! in_array( $key, $supported_identifiers, true ) || ! is_scalar( $value ) || ! empty( $data[ $key ] ) ) {
                continue;
            }

            if( $key === 'mpn' ) {
                $mpn = trim( sanitize_text_field( $value ) );
                if( $mpn !== '' ) {
                    $data[ $key ] = $mpn;
                }
                continue;
            }

            $gtin = $this->normalize_gtin( $value, (int) substr( $key, 4 ) );
            if( $gtin !== '' ) {
                $data[ $key ] = $gtin;
            }
        }

        $data = apply_filters( 'wphave_schema_woocommerce_product_node', $data, $product );

        foreach( array( 'gtin', 'gtin8', 'gtin12', 'gtin13', 'gtin14' ) as $gtin_key ) {
            if( ! empty( $data[ $gtin_key ] ) ) {
                $expected_length = $gtin_key === 'gtin' ? 0 : (int) substr( $gtin_key, 4 );
                $gtin = $this->normalize_gtin( $data[ $gtin_key ], $expected_length );
                if( $gtin === '' ) {
                    unset( $data[ $gtin_key ] );
                } else {
                    $data[ $gtin_key ] = $gtin;
                }
            }
        }

        $data = apply_filters( 'wphave_schema_primary_entity_node', $data, $data['@type'] ?? 'Product', get_post( $post_id ) );
        $this->woocommerce_product_nodes[ $post_id ] = is_array( $data ) ? $data : array();

        return $this->woocommerce_product_nodes[ $post_id ];
    }

    /**
     * Convert a native variable Product into a compact ProductGroup graph node.
     *
     * Only visible variations with a current price and recognized variant
     * properties are emitted. Unsupported attribute models retain the native
     * WooCommerce Product/AggregateOffer representation as a safe fallback.
     *
     * @param array<string,mixed> $data Native WooCommerce product data.
     * @param WC_Product_Variable $product Variable product.
     * @return array<string,mixed>
     */

    protected function get_woocommerce_product_group_node( array $data, $product ): array {
        $property_map = array(
            'color' => 'color',
            'colour' => 'color',
            'farbe' => 'color',
            'size' => 'size',
            'groesse' => 'size',
            'material' => 'material',
            'pattern' => 'pattern',
            'muster' => 'pattern',
        );
        $variants = array();
        $varies_by = array();

        $children = $product->get_children();
        if( count( $children ) > 100 ) {
            return array();
        }

        foreach( $children as $variation_id ) {
            $variation = wc_get_product( $variation_id );
            if( ! $variation || ! $variation->is_visible() || $variation->get_price() === '' ) {
                continue;
            }

            $properties = array();
            $query = array();
            foreach( $variation->get_variation_attributes() as $attribute_name => $attribute_value ) {
                $attribute_slug = sanitize_title( str_replace( array( 'attribute_', 'pa_' ), '', $attribute_name ) );
                $property = $property_map[ $attribute_slug ] ?? '';
                if( $property === '' || $attribute_value === '' ) {
                    return array();
                }

                $value = taxonomy_exists( 'pa_' . $attribute_slug ) ? get_term_by( 'slug', $attribute_value, 'pa_' . $attribute_slug ) : false;
                $properties[ $property ] = $value && ! is_wp_error( $value ) ? $value->name : $attribute_value;
                $varies_by[] = 'https://schema.org/' . $property;
                $query[ $attribute_name ] = $attribute_value;
            }

            if( empty( $properties ) ) {
                continue;
            }

            $variant_url = add_query_arg( $query, get_permalink( $product->get_id() ) );
            $stock_status = $variation->is_in_stock() ? ( $variation->is_on_backorder() ? 'BackOrder' : 'InStock' ) : 'OutOfStock';
            $variant = array_merge( array(
                '@type' => 'Product',
                '@id' => get_permalink( $product->get_id() ) . '#variation-' . $variation->get_id(),
                'name' => $variation->get_name(),
                'image' => wp_get_attachment_url( $variation->get_image_id() ),
                'offers' => array(
                    '@type' => 'Offer',
                    'url' => $variant_url,
                    'price' => wc_format_decimal( wc_get_price_to_display( $variation ), wc_get_price_decimals() ),
                    'priceCurrency' => get_woocommerce_currency(),
                    'availability' => 'https://schema.org/' . $stock_status,
                    'itemCondition' => 'https://schema.org/NewCondition',
                ),
            ), $properties );

            $variation_sku = $variation->get_sku( 'edit' );
            if( $variation_sku !== '' ) {
                $variant['sku'] = $variation_sku;
            }

            if( method_exists( $variation, 'get_global_unique_id' ) ) {
                $gtin = $this->normalize_gtin( $variation->get_global_unique_id() );
                if( $gtin !== '' ) {
                    $variant['gtin'] = $gtin;
                }
            }

            $variants[] = $variant;
        }

        if( empty( $variants ) || empty( $varies_by ) ) {
            return array();
        }

        unset( $data['offers'], $data['sku'], $data['gtin'] );
        $data['@type'] = 'ProductGroup';
        $data['productGroupID'] = $product->get_sku() ?: (string) $product->get_id();
        $data['variesBy'] = array_values( array_unique( $varies_by ) );
        $data['hasVariant'] = $variants;

        return apply_filters( 'wphave_schema_woocommerce_product_group_node', $data, $product );
    }

    /**
     * Check whether variable WooCommerce products use ProductGroup markup.
     *
     * @return bool
     */

    protected function woocommerce_product_groups_enabled(): bool {
        $settings = $this->get_settings();

        return isset( $settings['woocommerce']['useProductGroups'] ) ? (bool) $settings['woocommerce']['useProductGroups'] : false;
    }

    /**
     * Check whether the current request is a product owned by wphave schema.
     *
     * @return bool
     */

    protected function is_woocommerce_product_request(): bool {
        return $this->woocommerce_takeover_enabled() && function_exists( 'is_product' ) && is_product() && function_exists( 'wc_get_product' );
    }

    /**
     * Check whether wphave should replace native WooCommerce product schema.
     *
     * @return bool
     */

    protected function woocommerce_takeover_enabled(): bool {
        if( ! $this->is_enabled() || ! class_exists( 'WooCommerce' ) ) {
            return false;
        }

        $settings = $this->get_settings();

        return isset( $settings['woocommerce']['takeOverProductSchema'] ) ? (bool) $settings['woocommerce']['takeOverProductSchema'] : false;
    }

    /**
     * Determine whether a generated node can safely replace native output.
     *
     * @param array<string,mixed> $node Generated WooCommerce node.
     * @return bool
     */

    protected function woocommerce_product_node_is_usable( array $node ): bool {
        $type = $node['@type'] ?? '';

        if( $type === 'Product' ) {
            return ! empty( $node['name'] ) && $this->woocommerce_offers_are_usable( $node['offers'] ?? array() );
        }

        if( $type !== 'ProductGroup' || empty( $node['name'] ) || empty( $node['productGroupID'] ) || empty( $node['variesBy'] ) || empty( $node['hasVariant'] ) || ! is_array( $node['hasVariant'] ) ) {
            return false;
        }

        foreach( $node['hasVariant'] as $variant ) {
            if( ! is_array( $variant ) || ( $variant['@type'] ?? '' ) !== 'Product' || empty( $variant['name'] ) || ! $this->woocommerce_offers_are_usable( $variant['offers'] ?? array() ) ) {
                return false;
            }
        }

        return true;
    }

    /**
     * Validate offer values before wphave assumes ownership of native output.
     *
     * @param mixed $offers One Offer, AggregateOffer or an offer list.
     * @return bool
     */

    protected function woocommerce_offers_are_usable( $offers ): bool {
        if( ! is_array( $offers ) ) {
            return false;
        }

        $offers = isset( $offers['@type'] ) ? array( $offers ) : $offers;
        if( empty( $offers ) ) {
            return false;
        }

        foreach( $offers as $offer ) {
            if( ! is_array( $offer ) || ! preg_match( '/^[A-Z]{3}$/', (string) ( $offer['priceCurrency'] ?? '' ) ) ) {
                return false;
            }

            $type = $offer['@type'] ?? '';
            if( $type === 'Offer' ) {
                $price = $offer['price'] ?? ( $offer['priceSpecification'][0]['price'] ?? null );
                if( ! is_numeric( $price ) || (float) $price < 0 ) {
                    return false;
                }
            } elseif( $type === 'AggregateOffer' ) {
                if( ! is_numeric( $offer['lowPrice'] ?? null ) || ! is_numeric( $offer['highPrice'] ?? null ) || (float) $offer['lowPrice'] < 0 || (float) $offer['highPrice'] < (float) $offer['lowPrice'] ) {
                    return false;
                }
            } else {
                return false;
            }
        }

        return true;
    }

    /**
     * Normalize and validate a GTIN including its GS1 check digit.
     *
     * Separators are removed for compatibility with formatted merchant input.
     * Only GTIN-8, GTIN-12, GTIN-13 and GTIN-14 values are accepted.
     *
     * @param mixed $value Raw identifier.
     * @param int $expected_length Required length, or zero for any GTIN.
     * @return string
     */

    protected function normalize_gtin( $value, int $expected_length = 0 ): string {
        $gtin = preg_replace( '/[^0-9]/', '', (string) $value );
        $length = strlen( $gtin );
        if( ! in_array( $length, array( 8, 12, 13, 14 ), true ) || ( $expected_length > 0 && $length !== $expected_length ) ) {
            return '';
        }

        $sum = 0;
        $weight = 3;
        for( $index = $length - 2; $index >= 0; $index-- ) {
            $sum += (int) $gtin[ $index ] * $weight;
            $weight = $weight === 3 ? 1 : 3;
        }

        $check_digit = ( 10 - ( $sum % 10 ) ) % 10;

        return $check_digit === (int) $gtin[ $length - 1 ] ? $gtin : '';
    }

    /**
     * Normalize a localized decimal price for Schema.org output.
     *
     * @param mixed $price Raw post meta value.
     * @return string
     */

    protected function normalize_price( $price ): string {
        $price = trim( (string) $price );
        $price = str_replace( array( ' ', ',' ), array( '', '.' ), $price );

        return is_numeric( $price ) ? number_format( (float) $price, 2, '.', '' ) : '';
    }
}
