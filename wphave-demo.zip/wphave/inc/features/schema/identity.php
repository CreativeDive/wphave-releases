<?php

/**
 * WPHAVE Schema Identity responsibilities.
 *
 * Internal methods are protected so the schema facade can compose providers
 * through the inheritance chain without exposing implementation APIs.
 */

if( ! defined( 'ABSPATH' ) ) {
    exit;
}

abstract class WPHAVE_Schema_Identity extends WPHAVE_Schema_Validator {

    /**
     * Build the Organization or Person node representing the website owner.
     *
     * @return array<string,mixed>
     */

    protected function get_identity_node(): array {
        $settings = $this->get_settings();
        $identity = isset( $settings['identity'] ) && is_array( $settings['identity'] ) ? $settings['identity'] : array();
        $type = ( $identity['type'] ?? 'Organization' ) === 'Person' ? 'Person' : 'Organization';
        $brand = wphave_data_get( 'site_settings', 'brand', array() );
        $brand = is_array( $brand ) ? $brand : array();
        $name = trim( (string) ( $identity['name'] ?? '' ) );
        $name = $name !== '' ? $name : wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
        $logo_id = absint( $identity['logo'] ?? ( $brand['logo'] ?? 0 ) );
        $logo_url = $logo_id ? wp_get_attachment_image_url( $logo_id, 'full' ) : '';
        $social_profiles = WPHAVE_Social_Profiles::get_profiles();
        $same_as = array();

        foreach( $social_profiles as $profile ) {
            $url = $profile['url'] ?? '';
            if( $url !== '' ) {
                $same_as[] = $url;
            }
        }

        $node = array(
            '@type' => $type,
            '@id' => $this->get_id( 'identity' ),
            'name' => $name,
            'legalName' => $type === 'Organization' ? sanitize_text_field( $identity['legalName'] ?? '' ) : '',
            'url' => home_url( '/' ),
            'description' => trim( (string) ( $identity['description'] ?? get_bloginfo( 'description' ) ) ),
            'email' => sanitize_email( $identity['email'] ?? '' ),
            'telephone' => sanitize_text_field( $identity['telephone'] ?? '' ),
            'foundingDate' => $type === 'Organization' ? $this->sanitize_schema_date( $identity['foundingDate'] ?? '' ) : '',
            'taxID' => $type === 'Organization' ? sanitize_text_field( $identity['taxID'] ?? '' ) : '',
            'vatID' => $type === 'Organization' ? sanitize_text_field( $identity['vatID'] ?? '' ) : '',
            'sameAs' => array_values( array_unique( $same_as ) ),
        );

        if( $type === 'Organization' ) {
            $address = $this->get_identity_address_node( $identity );
            if( ! empty( $address ) ) {
                $node['address'] = $address;
            }

            $contact_point = $this->get_identity_contact_point_node( $identity );
            if( ! empty( $contact_point ) ) {
                $node['contactPoint'] = $contact_point;
            }

            $registration_id = sanitize_text_field( $identity['registrationId'] ?? '' );
            if( $registration_id !== '' ) {
                $node['identifier'] = array(
                    '@type' => 'PropertyValue',
                    'propertyID' => sanitize_text_field( $identity['registrationType'] ?? __( 'Company registration', 'wphave' ) ),
                    'value' => $registration_id,
                );
            }
        }

        if( $logo_url ) {
            $node['logo'] = array(
                '@type' => 'ImageObject',
                '@id' => $this->get_id( 'logo' ),
                'url' => $logo_url,
                'contentUrl' => $logo_url,
            );
        }

        $return_policy = $this->get_merchant_return_policy_node();
        if( $type === 'Organization' && ! empty( $return_policy ) ) {
            $node['hasMerchantReturnPolicy'] = $return_policy;
        }

        $shipping_service = $this->get_shipping_service_node();
        if( $type === 'Organization' && ! empty( $shipping_service ) ) {
            $node['hasShippingService'] = $shipping_service;
        }

        return apply_filters( 'wphave_schema_identity_node', $node, $identity );
    }

    /**
     * Build the public postal address of the organization.
     *
     * Partial addresses are retained for preview validation, but no address is
     * emitted when all address fields are empty.
     *
     * @param array<string,mixed> $identity Identity settings.
     * @return array<string,mixed>
     */

    protected function get_identity_address_node( array $identity ): array {
        $address = isset( $identity['address'] ) && is_array( $identity['address'] ) ? $identity['address'] : array();
        $node = array(
            '@type' => 'PostalAddress',
            'streetAddress' => sanitize_text_field( $address['street'] ?? '' ),
            'postalCode' => sanitize_text_field( $address['postalCode'] ?? '' ),
            'addressLocality' => sanitize_text_field( $address['locality'] ?? '' ),
            'addressRegion' => sanitize_text_field( $address['region'] ?? '' ),
            'addressCountry' => strtoupper( sanitize_text_field( $address['country'] ?? '' ) ),
        );

        return count( array_filter( array_slice( $node, 1 ) ) ) > 0 ? $node : array();
    }

    /**
     * Build one public contact point for the organization.
     *
     * @param array<string,mixed> $identity Identity settings.
     * @return array<string,mixed>
     */

    protected function get_identity_contact_point_node( array $identity ): array {
        $contact = isset( $identity['contact'] ) && is_array( $identity['contact'] ) ? $identity['contact'] : array();
        $telephone = sanitize_text_field( $contact['telephone'] ?? '' );
        $email = sanitize_email( $contact['email'] ?? '' );
        if( $telephone === '' && $email === '' ) {
            return array();
        }

        $languages = array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'trim', explode( ',', (string) ( $contact['languages'] ?? '' ) ) ) ) ) );

        return array(
            '@type' => 'ContactPoint',
            'contactType' => sanitize_text_field( $contact['type'] ?? 'customer service' ),
            'telephone' => $telephone,
            'email' => $email,
            'availableLanguage' => $languages,
        );
    }

    /**
     * Sanitize an ISO calendar date without accepting ambiguous local formats.
     *
     * @param mixed $date Raw date.
     * @return string
     */

    protected function sanitize_schema_date( $date ): string {
        $date = sanitize_text_field( $date );

        return preg_match( '/^\d{4}(?:-\d{2}(?:-\d{2})?)?$/', $date ) ? $date : '';
    }

    /**
     * Build one physical business location operated by the site organization.
     *
     * The Organization remains the publisher and legal identity. LocalBusiness
     * receives its own stable ID and references that operator, avoiding two
     * competing site identity nodes in the connected graph.
     *
     * @return array<string,mixed>
     */

    protected function get_local_business_node(): array {
        $settings = $this->get_settings();
        $identity = isset( $settings['identity'] ) && is_array( $settings['identity'] ) ? $settings['identity'] : array();
        $business = isset( $settings['localBusiness'] ) && is_array( $settings['localBusiness'] ) ? $settings['localBusiness'] : array();
        if( empty( $business['isEnabled'] ) || ( $identity['type'] ?? 'Organization' ) !== 'Organization' ) {
            return array();
        }

        $types = array( 'LocalBusiness', 'Store', 'Restaurant', 'ProfessionalService', 'MedicalBusiness', 'RealEstateAgent', 'AutomotiveBusiness', 'LodgingBusiness' );
        $type = in_array( $business['type'] ?? '', $types, true ) ? $business['type'] : 'LocalBusiness';
        $latitude = filter_var( $business['latitude'] ?? null, FILTER_VALIDATE_FLOAT );
        $longitude = filter_var( $business['longitude'] ?? null, FILTER_VALIDATE_FLOAT );
        $node = array(
            '@type' => $type,
            '@id' => home_url( '/' ) . '#local-business',
            'name' => sanitize_text_field( $business['name'] ?? ( $identity['name'] ?? get_bloginfo( 'name' ) ) ),
            'url' => esc_url_raw( $business['url'] ?? home_url( '/' ) ),
            'telephone' => sanitize_text_field( $business['telephone'] ?? ( $identity['telephone'] ?? '' ) ),
            'priceRange' => sanitize_text_field( $business['priceRange'] ?? '' ),
            'address' => $this->get_identity_address_node( $identity ),
            'parentOrganization' => array(
                '@id' => $this->get_id( 'identity' ),
            ),
            'areaServed' => array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'trim', explode( ',', (string) ( $business['areaServed'] ?? '' ) ) ) ) ) ),
        );

        if( $latitude !== false && $longitude !== false ) {
            $node['geo'] = array(
                '@type' => 'GeoCoordinates',
                'latitude' => (float) $latitude,
                'longitude' => (float) $longitude,
            );
        }

        $hours = array();
        foreach( array(
            'weekdays' => array( 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday' ),
            'weekend' => array( 'Saturday', 'Sunday' ),
        ) as $period => $days ) {
            $opens = sanitize_text_field( $business[ $period . 'Opens' ] ?? '' );
            $closes = sanitize_text_field( $business[ $period . 'Closes' ] ?? '' );
            if( preg_match( '/^(?:[01]\d|2[0-3]):[0-5]\d$/', $opens ) && preg_match( '/^(?:[01]\d|2[0-3]):[0-5]\d$/', $closes ) ) {
                $hours[] = array(
                    '@type' => 'OpeningHoursSpecification',
                    'dayOfWeek' => $days,
                    'opens' => $opens,
                    'closes' => $closes,
                );
            }
        }
        $node['openingHoursSpecification'] = $hours;

        return apply_filters( 'wphave_schema_local_business_node', $node, $business );
    }

    /**
     * Build the standard merchant return policy configured for the business.
     *
     * Values are emitted only when the required country and policy category
     * are explicit. This avoids deriving legal terms from WooCommerce pages or
     * free-form shop copy that may not represent the actual return conditions.
     *
     * @return array<string,mixed>
     */

    protected function get_merchant_return_policy_node(): array {
        $settings = $this->get_settings();
        $policy = isset( $settings['woocommerce']['returns'] ) && is_array( $settings['woocommerce']['returns'] ) ? $settings['woocommerce']['returns'] : array();
        if( empty( $policy['isEnabled'] ) ) {
            return array();
        }

        $countries = array_slice( array_values( array_unique( array_filter( array_map( function( $country ) {
            $country = strtoupper( trim( $country ) );
            return preg_match( '/^[A-Z]{2}$/', $country ) ? $country : '';
        }, explode( ',', (string) ( $policy['countries'] ?? '' ) ) ) ) ) ), 0, 50 );
        $category = $policy['category'] ?? 'MerchantReturnFiniteReturnWindow';
        $categories = array( 'MerchantReturnFiniteReturnWindow', 'MerchantReturnNotPermitted', 'MerchantReturnUnlimitedWindow' );
        if( empty( $countries ) || ! in_array( $category, $categories, true ) ) {
            return array();
        }

        $node = array(
            '@type' => 'MerchantReturnPolicy',
            '@id' => home_url( '/' ) . '#merchant-return-policy',
            'applicableCountry' => $countries,
            'returnPolicyCategory' => 'https://schema.org/' . $category,
            'merchantReturnLink' => esc_url_raw( $policy['url'] ?? '' ),
        );

        if( $category === 'MerchantReturnFiniteReturnWindow' ) {
            $node['merchantReturnDays'] = absint( $policy['days'] ?? 0 );
        }

        if( $category !== 'MerchantReturnNotPermitted' ) {
            $methods = array( 'ReturnByMail', 'ReturnInStore', 'ReturnAtKiosk' );
            $fees = array( 'FreeReturn', 'ReturnFeesCustomerResponsibility' );
            $method = $policy['method'] ?? 'ReturnByMail';
            $return_fees = $policy['fees'] ?? 'FreeReturn';
            $node['returnMethod'] = 'https://schema.org/' . ( in_array( $method, $methods, true ) ? $method : 'ReturnByMail' );
            $node['returnFees'] = 'https://schema.org/' . ( in_array( $return_fees, $fees, true ) ? $return_fees : 'FreeReturn' );
        }

        return apply_filters( 'wphave_schema_merchant_return_policy_node', $node, $policy );
    }

    /**
     * Build one standard delivery service for the merchant organization.
     *
     * The service intentionally uses explicit settings instead of attempting
     * to flatten WooCommerce zones, conditional rates or shipping extensions.
     * Incomplete policies are omitted rather than published with invented data.
     *
     * @return array<string,mixed>
     */

    protected function get_shipping_service_node(): array {
        $settings = $this->get_settings();
        $shipping = isset( $settings['woocommerce']['shipping'] ) && is_array( $settings['woocommerce']['shipping'] ) ? $settings['woocommerce']['shipping'] : array();
        if( empty( $shipping['isEnabled'] ) ) {
            return array();
        }

        $countries = array_slice( array_values( array_unique( array_filter( array_map( function( $country ) {
            $country = strtoupper( trim( $country ) );
            return preg_match( '/^[A-Z]{2}$/', $country ) ? $country : '';
        }, explode( ',', (string) ( $shipping['countries'] ?? '' ) ) ) ) ) ), 0, 50 );
        $rate = $this->normalize_price( $shipping['rate'] ?? '' );
        $currency = strtoupper( trim( (string) ( $shipping['currency'] ?? '' ) ) );
        $handling_min = absint( $shipping['handlingMin'] ?? 0 );
        $handling_max = absint( $shipping['handlingMax'] ?? 0 );
        $transit_min = absint( $shipping['transitMin'] ?? 0 );
        $transit_max = absint( $shipping['transitMax'] ?? 0 );
        if( empty( $countries ) || $rate === '' || ! preg_match( '/^[A-Z]{3}$/', $currency ) || $handling_min > $handling_max || $transit_min > $transit_max ) {
            return array();
        }

        $destinations = array_map( function( $country ) {
            return array(
                '@type' => 'DefinedRegion',
                'addressCountry' => $country,
            );
        }, $countries );

        $node = array(
            '@type' => 'ShippingService',
            '@id' => home_url( '/' ) . '#merchant-shipping-service',
            'name' => sanitize_text_field( $shipping['name'] ?? __( 'Standard shipping', 'wphave' ) ),
            'fulfillmentType' => 'https://schema.org/FulfillmentTypeDelivery',
            'handlingTime' => $this->get_shipping_service_period( $handling_min, $handling_max ),
            'shippingConditions' => array(
                '@type' => 'ShippingConditions',
                'shippingDestination' => $destinations,
                'shippingRate' => array(
                    '@type' => 'MonetaryAmount',
                    'value' => $rate,
                    'currency' => $currency,
                ),
                'transitTime' => $this->get_shipping_service_period( $transit_min, $transit_max ),
            ),
        );

        return apply_filters( 'wphave_schema_shipping_service_node', $node, $shipping );
    }

    /**
     * Build a day-based ServicePeriod used for handling and transit times.
     *
     * @param int $minimum Minimum number of days.
     * @param int $maximum Maximum number of days.
     * @return array<string,mixed>
     */

    protected function get_shipping_service_period( int $minimum, int $maximum ): array {
        return array(
            '@type' => 'ServicePeriod',
            'duration' => array(
                '@type' => 'QuantitativeValue',
                'minValue' => $minimum,
                'maxValue' => $maximum,
                'unitCode' => 'DAY',
            ),
        );
    }
}
