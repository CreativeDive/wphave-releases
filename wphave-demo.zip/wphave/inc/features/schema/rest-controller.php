<?php

/**
 * Registers protected REST endpoints for Schema.org diagnostics.
 *
 * The controller owns capability checks, public-page retrieval, JSON-LD
 * extraction and response creation. Graph construction and validation remain
 * delegated to the schema service injected through the constructor.
 */

if( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPHAVE_Schema_REST_Controller {

    /**
     * Maximum public HTML size accepted by the preview endpoint.
     */

    private const MAX_PREVIEW_BYTES = 2097152;

    /**
     * Initialize the component.
     *
     * @var WPHAVE_Schema
     */

    private WPHAVE_Schema $schema;

    /**
     * Initialize the component.
     *
     * @param WPHAVE_Schema $schema Schema facade.
     */

    public function __construct( WPHAVE_Schema $schema ) {
        $this->schema = $schema;
    }

    /**
     * Register the protected public-output preview route.
     */

    public function register_routes(): void {
        register_rest_route( 'wphave/v1', '/schema/preview/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array( $this, 'preview' ),
            'permission_callback' => array( $this, 'can_manage_schema_settings' ),
            'args' => array(
                'id' => array(
                    'required' => true,
                    'type' => 'integer',
                    'minimum' => 1,
                    'sanitize_callback' => 'absint',
                ),
            ),
        ) );
    }

    /**
     * Check whether the current user may inspect schema output.
     *
     * @return bool
     */

    public function can_manage_schema_settings(): bool {
        return current_user_can( 'manage_options' ) || current_user_can( 'wphave_manage_settings_schema' );
    }

    /**
     * Fetch and validate the real public JSON-LD output for one local post.
     *
     * The URL is resolved exclusively from a published local post, preventing
     * the endpoint from becoming a general-purpose server-side request proxy.
     * A cache-busting query parameter bypasses stale full-page cache entries.
     *
     * @param WP_REST_Request $request REST request.
     * @return WP_REST_Response|WP_Error
     */

    public function preview( WP_REST_Request $request ) {
		// AUTHORIZATION INVARIANT: The HTTP preview callback may trigger a
		// server-side request and expose the complete generated graph. Repeat the
		// Schema settings capability before resolving even the requested post ID.
		if( ! $this->can_manage_schema_settings() ) {
			return new WP_Error(
				'wphave_schema_preview_forbidden',
				__( 'You are not allowed to inspect Schema previews.', 'wphave' ),
				array( 'status' => 403 )
			);
		}

        $result = $this->inspect_post( absint( $request['id'] ) );
		// DISCLOSURE INVARIANT: Permalink, HTTP and Schema validation hooks may
		// change the caller's authority while preparing a complete graph. Do
		// not release even a diagnostic result under the stale entry decision.
		if( ! $this->can_manage_schema_settings() ) {
			return new WP_Error(
				'wphave_schema_preview_forbidden',
				__( 'You are not allowed to inspect Schema previews.', 'wphave' ),
				array( 'status' => 403 )
			);
		}

        return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
    }

    /**
     * Inspect the real public Schema.org output for a published local post.
     *
     * This service method is shared by the Schema screen and Content Audit so
     * both surfaces use the same origin checks, parser and validator.
     *
     * @param int $post_id Published post ID.
     * @return array<string,mixed>|WP_Error
     */

    public function inspect_post( int $post_id ) {
        $post = get_post( $post_id );

        if( ! $post || $post->post_status !== 'publish' ) {
            return new WP_Error( 'wphave_schema_preview_post_unavailable', __( 'Select a published public post for schema preview.', 'wphave' ), array( 'status' => 404 ) );
        }

        $post_type = get_post_type_object( $post->post_type );
        if( ! $post_type || empty( $post_type->public ) || ! empty( $post->post_password ) ) {
            return new WP_Error( 'wphave_schema_preview_post_private', __( 'The selected post is not publicly accessible.', 'wphave' ), array( 'status' => 403 ) );
        }

        $url = get_permalink( $post );
        if( ! $url ) {
            return new WP_Error( 'wphave_schema_preview_url_missing', __( 'The public URL could not be resolved.', 'wphave' ), array( 'status' => 404 ) );
        }

		if( ! $this->is_same_origin_url( $url ) ) {
			return new WP_Error( 'wphave_schema_preview_url_unsafe', __( 'The public URL must use the same origin as this WordPress installation.', 'wphave' ), array( 'status' => 403 ) );
		}

		// SECURITY INVARIANT: Preview fetching is restricted to a published,
		// non-password-protected same-origin permalink, without redirects and within
		// a fixed response limit. Same-origin validation is an authorization boundary;
		// wp_safe_remote_get() remains mandatory as the transport boundary so DNS
		// resolution cannot turn the approved URL into a private-network request. The
		// extra byte is an overflow sentinel: truncated public HTML must never be
		// treated as a complete Schema preview document.
		$response = wp_safe_remote_get( add_query_arg( '_wphave_schema_preview', time(), $url ), array(
            'timeout' => 15,
            'redirection' => 0,
			'sslverify' => true,
            'limit_response_size' => self::MAX_PREVIEW_BYTES + 1,
            'headers' => array(
                'Cache-Control' => 'no-cache',
            ),
            'user-agent' => 'wphave-schema-preview/' . ( defined( 'WPHAVE_VERSION' ) ? WPHAVE_VERSION : '1.0' ),
        ) );

        if( is_wp_error( $response ) ) {
            // SECURITY INVARIANT: HTTP transport diagnostics may contain private
            // hosts, socket paths, query credentials or personal identifiers. The
            // REST boundary exposes only the central redacted representation.
            return new WP_Error(
                'wphave_schema_preview_request_failed',
                WPHAVE_Security_Redactor::error_text( $response->get_error_message() ),
                array( 'status' => 502 )
            );
        }

        $status = (int) wp_remote_retrieve_response_code( $response );
        if( $status < 200 || $status >= 300 ) {
            return new WP_Error( 'wphave_schema_preview_http_error', sprintf( /* translators: %s or %d: contextual value; 1, 2, or 3: ordered contextual values. */
            __( 'The public page returned HTTP status %d.', 'wphave' ), $status ), array( 'status' => 502 ) );
        }

		$body = (string) wp_remote_retrieve_body( $response );
		if( strlen( $body ) > self::MAX_PREVIEW_BYTES ) {
			return new WP_Error( 'wphave_schema_preview_too_large', __( 'The public page exceeded the Schema preview response limit.', 'wphave' ), array( 'status' => 413 ) );
		}

		$payload = $this->extract_schema_payload( $body );
        if( empty( $payload ) ) {
            return new WP_Error( 'wphave_schema_preview_missing', __( 'No wphave JSON-LD graph was found. Save and enable Schema before loading the preview.', 'wphave' ), array( 'status' => 409 ) );
        }

        $validation = $this->schema->validate_schema_payload( $payload );

        return array(
            'postId' => $post_id,
            'url' => $url,
            'payload' => $payload,
            'nodes' => count( $payload['@graph'] ?? array() ),
            'errors' => $validation['errors'],
            'warnings' => $validation['warnings'],
        );
    }

    /**
     * Ensure preview requests cannot be redirected to an arbitrary host.
     *
     * Permalinks are normally local, but WordPress filters can replace them.
     * Comparing scheme, host and effective port keeps the HTTP client scoped to
     * the configured site without blocking legitimate local development URLs.
     *
     * @param string $url Candidate permalink.
     * @return bool
     */

    protected function is_same_origin_url( string $url ): bool {
        $candidate = wp_parse_url( $url );
        $site = wp_parse_url( home_url( '/' ) );
        if ( ! is_array( $candidate ) || ! is_array( $site ) || empty( $candidate['scheme'] ) || empty( $candidate['host'] ) || empty( $site['scheme'] ) || empty( $site['host'] ) ) {
            return false;
        }

        $candidate_port = (int) ( $candidate['port'] ?? ( $candidate['scheme'] === 'https' ? 443 : 80 ) );
        $site_port = (int) ( $site['port'] ?? ( $site['scheme'] === 'https' ? 443 : 80 ) );

        // SECURITY INVARIANT: A local preview URL conveys location only. It may
        // never inject URL credentials into a privileged server-side request.
        return empty( $candidate['user'] )
            && empty( $candidate['pass'] )
            && strtolower( $candidate['scheme'] ) === strtolower( $site['scheme'] )
            && strtolower( $candidate['host'] ) === strtolower( $site['host'] )
            && $candidate_port === $site_port;
    }

    /**
     * Extract the wphave JSON-LD script from a complete HTML document.
     *
     * Only the script carrying the plugin-specific class is accepted, so JSON-LD
     * emitted by SEO plugins or WooCommerce cannot be mistaken for the preview.
     *
     * @param string $html Public page HTML.
     * @return array<string,mixed>
     */

    protected function extract_schema_payload( string $html ): array {
        if( ! preg_match( '/<script\b(?=[^>]*\btype=["\']application\/ld\+json["\'])(?=[^>]*\bclass=["\'][^"\']*\bwphave-schema\b[^"\']*["\'])[^>]*>(.*?)<\/script>/is', $html, $matches ) ) {
            return array();
        }

        $payload = json_decode( trim( $matches[1] ), true );

        return is_array( $payload ) ? $payload : array();
    }
}
