<?php

/**
 * WPHAVE Schema Content foundation responsibilities.
 *
 * Builds the site and page nodes plus reusable media references.\n *
 * Internal methods remain protected so extensions use the documented filters
 * instead of coupling to provider implementation APIs.
 */

if( ! defined( 'ABSPATH' ) ) {
    exit;
}

abstract class WPHAVE_Schema_Content extends WPHAVE_Schema_Identity {

    /**
     * Build the WebSite node shared by all public pages.
     *
     * @return array<string,mixed>
     */

    protected function get_website_node(): array {
        return apply_filters( 'wphave_schema_website_node', array(
            '@type' => 'WebSite',
            '@id' => $this->get_id( 'website' ),
            'url' => home_url( '/' ),
            'name' => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
            'description' => wp_specialchars_decode( get_bloginfo( 'description' ), ENT_QUOTES ),
            'inLanguage' => get_bloginfo( 'language' ),
            'publisher' => array(
                '@id' => $this->get_id( 'identity' ),
            ),
        ) );
    }

    /**
     * Build the WebPage node for a singular page, archive or homepage.
     *
     * @return array<string,mixed>
     */

    protected function get_webpage_node(): array {
        $url = $this->get_current_url();
        $title = wp_get_document_title();
        $description = '';
        $type = 'WebPage';

        if( is_singular() ) {
            $post_id = get_queried_object_id();
            $post = get_post( $post_id );
            $description = $post_id ? get_post_meta( $post_id, 'wphave_seo_description', true ) : '';

            if( ! $description && $post instanceof WP_Post ) {
                $description = get_the_excerpt( $post );
            }
        } elseif( is_archive() ) {
            $type = 'CollectionPage';
            $description = get_the_archive_description();
        }

        if( is_front_page() ) {
            $type = 'WebPage';
        }

        $node = array(
            '@type' => $type,
            '@id' => $url . '#webpage',
            'url' => $url,
            'name' => wp_strip_all_tags( $title ),
            'description' => wp_strip_all_tags( $description ),
            'inLanguage' => get_bloginfo( 'language' ),
            'isPartOf' => array(
                '@id' => $this->get_id( 'website' ),
            ),
            'about' => array(
                '@id' => $this->get_id( 'identity' ),
            ),
        );

        if( ! is_front_page() && $this->breadcrumbs_enabled() && ! $this->post_schema_node_excluded( 'breadcrumb' ) ) {
            $node['breadcrumb'] = array(
                '@id' => $url . '#breadcrumb',
            );
        }

        if( $this->is_article_request() ) {
            $node['mainEntity'] = array(
                '@id' => $url . '#article',
            );
        } elseif( $this->get_primary_entity_type() !== '' ) {
            $node['mainEntity'] = array(
                '@id' => $url . '#primary-entity',
            );
        } elseif( ! empty( $this->get_faq_node() ) ) {
            $node['mainEntity'] = array(
                '@id' => $url . '#faq',
            );
        }

        return apply_filters( 'wphave_schema_webpage_node', $node );
    }

    /**
     * Build an ImageObject reference from the featured image of a post.
     *
     * @param int $post_id WordPress post ID.
     * @return array<string,mixed>
     */

    protected function get_post_image_node( int $post_id ): array {
        $image_id = get_post_thumbnail_id( $post_id );
        $image = $image_id ? wp_get_attachment_image_src( $image_id, 'full' ) : false;

        if( ! $image ) {
            return array();
        }

        return array(
            '@type' => 'ImageObject',
            '@id' => get_permalink( $post_id ) . '#primaryimage',
            'url' => $image[0],
            'contentUrl' => $image[0],
            'width' => (int) $image[1],
            'height' => (int) $image[2],
            'caption' => wp_get_attachment_caption( $image_id ),
        );
    }
}
