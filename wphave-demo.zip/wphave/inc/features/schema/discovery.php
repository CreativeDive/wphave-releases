<?php

/**
 * WPHAVE Schema Discovery responsibilities.
 *
 * Builds FAQPage and BreadcrumbList nodes that help clients understand\n * visible page structure and navigation.\n *
 * Internal methods remain protected so extensions use the documented filters
 * instead of coupling to provider implementation APIs.
 */

if (!defined('ABSPATH')) {
	exit();
}

require_once dirname(__DIR__, 2) . '/blocks/conditions/projection.php';

abstract class WPHAVE_Schema_Discovery extends WPHAVE_Schema_Primary_Entity {
	/**
	 * Build one FAQPage node from explicitly marked wphave Accordion blocks.
	 *
	 * Questions and answers are derived from the same blocks rendered on the
	 * page. Empty entries are discarded so JSON-LD never invents content that
	 * visitors cannot access in the document.
	 *
	 * @return array<string,mixed>
	 */

	protected function get_faq_node(): array {
		if ($this->faq_node !== null) {
			return $this->faq_node;
		}

		$this->faq_node = [];
		if (!is_singular() || !$this->faq_enabled() || $this->post_schema_node_excluded('faq')) {
			return $this->faq_node;
		}

		$post = get_post();
		if (!$post || !has_blocks($post->post_content)) {
			return $this->faq_node;
		}

		$questions = $this->extract_faq_questions(parse_blocks($post->post_content));
		if (empty($questions)) {
			return $this->faq_node;
		}

		$this->faq_node = apply_filters(
			'wphave_schema_faq_node',
			[
				'@type' => 'FAQPage',
				'@id' => get_permalink($post) . '#faq',
				'url' => get_permalink($post),
				'isPartOf' => [
					'@id' => get_permalink($post) . '#webpage',
				],
				'mainEntity' => $questions,
			],
			$post,
		);

		return $this->faq_node;
	}

	/**
	 * Recursively collect FAQ questions from parsed block trees.
	 *
	 * @param array<int,array<string,mixed>> $blocks Parsed WordPress blocks.
	 * @return array<int,array<string,mixed>>
	 */

	protected function extract_faq_questions(array $blocks): array {
		$questions = [];

		foreach ($blocks as $block) {
			// Invariant: a denied ancestor excludes its entire subtree from public JSON-LD.
			if (!$this->faq_block_is_public($block)) {
				continue;
			}

			if (
				($block['blockName'] ?? '') === 'wphave/accordion' &&
				$this->is_faq_accordion($block)
			) {
				foreach ($block['innerBlocks'] ?? [] as $item) {
					$question = $this->get_faq_question_from_item($item);
					if (!empty($question)) {
						$questions[] = $question;
					}
				}
			}

			if (!empty($block['innerBlocks'])) {
				$questions = array_merge(
					$questions,
					$this->extract_faq_questions($block['innerBlocks']),
				);
			}
		}

		return $questions;
	}

	/**
	 * Check whether a parsed accordion explicitly opts into FAQ semantics.
	 *
	 * @param array<string,mixed> $block Parsed accordion block.
	 * @return bool
	 */

	protected function is_faq_accordion(array $block): bool {
		$wphave =
			isset($block['attrs']['wphave']) && is_array($block['attrs']['wphave'])
				? $block['attrs']['wphave']
				: [];
		$content_type = $wphave['settings']['contentType'] ?? 'default';

		return $content_type === 'faq' && $this->block_is_publicly_visible($wphave);
	}

	/**
	 * Convert one Accordion Item into a Question with acceptedAnswer.
	 *
	 * @param array<string,mixed> $item Parsed Accordion Item block.
	 * @return array<string,mixed>
	 */

	protected function get_faq_question_from_item(array $item): array {
		if (($item['blockName'] ?? '') !== 'wphave/accordion-item') {
			return [];
		}

		if (!$this->faq_block_is_public($item)) {
			return [];
		}

		$question = '';
		$answer = '';

		foreach ($item['innerBlocks'] ?? [] as $child) {
			// Titles and answer wrappers carry their own publication restrictions too.
			if (!$this->faq_block_is_public($child)) {
				continue;
			}

			if (($child['blockName'] ?? '') === 'wphave/accordion-title') {
				$question = $this->normalize_visible_text($child['attrs']['content'] ?? '');
			}

			if (($child['blockName'] ?? '') === 'wphave/accordion-content') {
				$answer_html = $this->render_public_faq_answer($child['innerBlocks'] ?? []);
				$answer = $this->normalize_visible_text($answer_html);
			}
		}

		if ($question === '' || $answer === '') {
			return [];
		}

		return [
			'@type' => 'Question',
			'name' => $question,
			'acceptedAnswer' => [
				'@type' => 'Answer',
				'text' => $answer,
			],
		];
	}

	/** Check parsed block attributes through the shared anonymous publication policy. */
	protected function faq_block_is_public(array $block): bool {
		$settings = $block['attrs']['wphave'] ?? [];
		return $this->block_is_publicly_visible(is_array($settings) ? $settings : []);
	}

	/** Render answer descendants without granting the current visitor's extra access. */
	protected function render_public_faq_answer(array $blocks): string {
		return WPHAVE_Block_Projection::render_public($blocks);
	}

	/**
	 * Check base visibility and dynamic access rules for a wphave block.
	 *
	 * Responsive-only hiding does not exclude a block because it remains
	 * visible on other supported devices.
	 *
	 * @param array<string,mixed> $wphave Block settings.
	 * @return bool
	 */

	protected function block_is_publicly_visible(array $wphave): bool {
		return WPHAVE_Block_Projection::visible($wphave);
	}

	/**
	 * Convert rendered block markup into normalized visible plain text.
	 *
	 * @param mixed $value Raw rich text or rendered HTML.
	 * @return string
	 */

	protected function normalize_visible_text($value): string {
		$value = preg_replace(
			'/<(?:script|style|noscript)\b[^>]*>.*?<\/(?:script|style|noscript)>/is',
			' ',
			(string) $value,
		);
		$value = preg_replace('/<\/(?:p|div|li|h[1-6]|blockquote)>/i', ' ', (string) $value);
		$value = html_entity_decode(
			wp_strip_all_tags($value, true),
			ENT_QUOTES,
			get_bloginfo('charset'),
		);

		return trim(preg_replace('/\s+/u', ' ', $value));
	}

	/**
	 * Check whether FAQ extraction is enabled globally.
	 *
	 * @return bool
	 */

	protected function faq_enabled(): bool {
		$settings = $this->get_settings();

		return !isset($settings['faq']['isEnabled']) || (bool) $settings['faq']['isEnabled'];
	}

	/**
	 * Build a minimal breadcrumb trail from the current WordPress hierarchy.
	 *
	 * @return array<string,mixed>
	 */

	protected function get_breadcrumb_node(): array {
		if (
			is_front_page() ||
			!$this->breadcrumbs_enabled() ||
			$this->post_schema_node_excluded('breadcrumb')
		) {
			return [];
		}

		$items = [
			[
				'@type' => 'ListItem',
				'position' => 1,
				'name' => wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES),
				'item' => home_url('/'),
			],
		];

		if (is_singular()) {
			$post = get_post();
			$ancestors = $post ? array_reverse(get_post_ancestors($post)) : [];

			foreach ($ancestors as $ancestor_id) {
				$items[] = [
					'@type' => 'ListItem',
					'position' => count($items) + 1,
					'name' => get_the_title($ancestor_id),
					'item' => get_permalink($ancestor_id),
				];
			}

			$items[] = [
				'@type' => 'ListItem',
				'position' => count($items) + 1,
				'name' => get_the_title($post),
			];
		} else {
			$items[] = [
				'@type' => 'ListItem',
				'position' => 2,
				'name' => wp_strip_all_tags(wp_get_document_title()),
			];
		}

		return apply_filters('wphave_schema_breadcrumb_node', [
			'@type' => 'BreadcrumbList',
			'@id' => $this->get_current_url() . '#breadcrumb',
			'itemListElement' => $items,
		]);
	}

	/**
	 * Check whether automatic breadcrumb schema is enabled.
	 *
	 * @return bool
	 */

	protected function breadcrumbs_enabled(): bool {
		$settings = $this->get_settings();

		return !isset($settings['breadcrumbs']['isEnabled']) ||
			(bool) $settings['breadcrumbs']['isEnabled'];
	}
}
