<?php

/**
 * WPHAVE Schema Primary Entity responsibilities.
 *
 * Builds manually configured Product, SoftwareApplication, Service, Event
 * and VideoObject entities. WooCommerce-specific product generation remains in
 * the commerce provider.
 *
 * Internal methods remain protected so extensions use the documented filters
 * instead of coupling to provider implementation APIs.
 */

if( ! defined( 'ABSPATH' ) ) {
    exit;
}

abstract class WPHAVE_Schema_Primary_Entity extends WPHAVE_Schema_Article {

    /**
     * Build the configured SoftwareApplication or Product node.
     *
     * Both types share offer and identity fields. Type-specific properties are
     * added only when they apply, keeping the public JSON-LD concise and valid.
     *
     * @return array<string,mixed>
     */

    protected function get_primary_entity_node(): array {
        $type = $this->get_primary_entity_type();
        $post = get_post();

        if( $type === '' || ! $post ) {
            return array();
        }

        if( $this->is_woocommerce_product_request() ) {
            return $this->get_woocommerce_product_node( $post->ID );
        }

        $url = get_permalink( $post );
        $name = trim( (string) get_post_meta( $post->ID, 'wphave_schema_name', true ) );
        $description = trim( (string) get_post_meta( $post->ID, 'wphave_schema_description', true ) );
        $price = $this->normalize_price( get_post_meta( $post->ID, 'wphave_schema_price', true ) );
        $currency = strtoupper( sanitize_key( get_post_meta( $post->ID, 'wphave_schema_currency', true ) ?: 'EUR' ) );
        $availability = sanitize_key( get_post_meta( $post->ID, 'wphave_schema_availability', true ) ?: 'InStock' );
        $availability_options = array( 'InStock', 'OutOfStock', 'PreOrder', 'BackOrder', 'Discontinued' );
        $availability = in_array( $availability, $availability_options, true ) ? $availability : 'InStock';
        $node = array(
            '@type' => $type,
            '@id' => $url . '#primary-entity',
            'url' => $url,
            'name' => $name !== '' ? $name : get_the_title( $post ),
            'description' => $description !== '' ? $description : ( get_post_meta( $post->ID, 'wphave_seo_description', true ) ?: get_the_excerpt( $post ) ),
            'mainEntityOfPage' => array(
                '@id' => $url . '#webpage',
            ),
        );

        if( $price !== '' && in_array( $type, array( 'Product', 'SoftwareApplication', 'Event' ), true ) ) {
            $node['offers'] = array(
                '@type' => 'Offer',
                'url' => $url,
                'price' => $price,
                'priceCurrency' => $currency,
                'availability' => 'https://schema.org/' . $availability,
            );
        }

        $image = $this->get_post_image_node( $post->ID );
        if( ! empty( $image ) ) {
            $node['image'] = $image;
        }

        if( $type === 'Product' ) {
            $node['sku'] = get_post_meta( $post->ID, 'wphave_schema_sku', true );
            $node['mpn'] = get_post_meta( $post->ID, 'wphave_schema_mpn', true );
            $gtin = $this->normalize_gtin( get_post_meta( $post->ID, 'wphave_schema_gtin', true ) );
            if( $gtin !== '' ) {
                $node[ 'gtin' . strlen( $gtin ) ] = $gtin;
            }
            $brand = trim( (string) get_post_meta( $post->ID, 'wphave_schema_brand', true ) );
            if( $brand !== '' ) {
                $node['brand'] = array(
                    '@type' => 'Brand',
                    'name' => $brand,
                );
            }
        } elseif( $type === 'SoftwareApplication' ) {
            $node['applicationCategory'] = get_post_meta( $post->ID, 'wphave_schema_application_category', true );
            $node['operatingSystem'] = get_post_meta( $post->ID, 'wphave_schema_operating_system', true );
            $node['softwareVersion'] = get_post_meta( $post->ID, 'wphave_schema_software_version', true );
            $rating_value = (float) str_replace( ',', '.', get_post_meta( $post->ID, 'wphave_schema_rating_value', true ) );
            $rating_count = absint( get_post_meta( $post->ID, 'wphave_schema_rating_count', true ) );
            if( $rating_value >= 1 && $rating_value <= 5 && $rating_count > 0 ) {
                $node['aggregateRating'] = array(
                    '@type' => 'AggregateRating',
                    'ratingValue' => number_format( $rating_value, 1, '.', '' ),
                    'ratingCount' => $rating_count,
                    'bestRating' => '5',
                    'worstRating' => '1',
                );
            }
            $node['publisher'] = array(
                '@id' => $this->get_id( 'identity' ),
            );
        } elseif( $type === 'Service' ) {
            $node['serviceType'] = get_post_meta( $post->ID, 'wphave_schema_service_type', true );
            $node['areaServed'] = array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'trim', explode( ',', (string) get_post_meta( $post->ID, 'wphave_schema_service_area', true ) ) ) ) ) );
            $node['provider'] = array(
                '@id' => $this->get_id( 'identity' ),
            );
        } elseif( $type === 'Event' ) {
            $status = get_post_meta( $post->ID, 'wphave_schema_event_status', true ) ?: 'EventScheduled';
            $attendance = get_post_meta( $post->ID, 'wphave_schema_event_attendance', true ) ?: 'OfflineEventAttendanceMode';
            $statuses = array( 'EventScheduled', 'EventCancelled', 'EventPostponed', 'EventRescheduled', 'EventMovedOnline' );
            $attendance_modes = array( 'OfflineEventAttendanceMode', 'OnlineEventAttendanceMode', 'MixedEventAttendanceMode' );
            $status = in_array( $status, $statuses, true ) ? $status : 'EventScheduled';
            $attendance = in_array( $attendance, $attendance_modes, true ) ? $attendance : 'OfflineEventAttendanceMode';
            $node['startDate'] = get_post_meta( $post->ID, 'wphave_schema_event_start', true );
            $node['endDate'] = get_post_meta( $post->ID, 'wphave_schema_event_end', true );
            $node['previousStartDate'] = get_post_meta( $post->ID, 'wphave_schema_event_previous_start', true );
            $node['eventStatus'] = 'https://schema.org/' . $status;
            $node['eventAttendanceMode'] = 'https://schema.org/' . $attendance;
            $node['organizer'] = array(
                '@id' => $this->get_id( 'identity' ),
            );
            $performer = trim( (string) get_post_meta( $post->ID, 'wphave_schema_event_performer', true ) );
            if( $performer !== '' ) {
                $node['performer'] = array(
                    '@type' => 'Person',
                    'name' => $performer,
                );
            }
            $node['location'] = $this->get_event_location( $post->ID, $attendance );
        } else {
            $thumbnail_url = esc_url_raw( get_post_meta( $post->ID, 'wphave_schema_video_thumbnail_url', true ) );
            if( $thumbnail_url === '' ) {
                $thumbnail_url = get_the_post_thumbnail_url( $post, 'full' ) ?: '';
            }

            $node['contentUrl'] = esc_url_raw( get_post_meta( $post->ID, 'wphave_schema_video_content_url', true ) );
            $node['embedUrl'] = esc_url_raw( get_post_meta( $post->ID, 'wphave_schema_video_embed_url', true ) );
            $node['thumbnailUrl'] = $thumbnail_url;
            $node['uploadDate'] = get_post_meta( $post->ID, 'wphave_schema_video_upload_date', true );
            $node['duration'] = strtoupper( get_post_meta( $post->ID, 'wphave_schema_video_duration', true ) );
            $node['expires'] = get_post_meta( $post->ID, 'wphave_schema_video_expires', true );
            $node['regionsAllowed'] = array_values( array_filter( array_map( 'strtoupper', array_map( 'trim', explode( ',', (string) get_post_meta( $post->ID, 'wphave_schema_video_regions', true ) ) ) ) ) );
            $live_start = get_post_meta( $post->ID, 'wphave_schema_video_live_start', true );
            $live_end = get_post_meta( $post->ID, 'wphave_schema_video_live_end', true );
            if( $live_start !== '' && $live_end !== '' ) {
                $node['publication'] = array(
                    '@type' => 'BroadcastEvent',
                    'isLiveBroadcast' => true,
                    'startDate' => $live_start,
                    'endDate' => $live_end,
                );
            }
            $node['publisher'] = array(
                '@id' => $this->get_id( 'identity' ),
            );
        }

        if( in_array( $type, array( 'Product', 'SoftwareApplication' ), true ) ) {
            $review_author = trim( (string) get_post_meta( $post->ID, 'wphave_schema_review_author', true ) );
            $review_body = trim( (string) get_post_meta( $post->ID, 'wphave_schema_review_body', true ) );
            $review_rating = (float) str_replace( ',', '.', get_post_meta( $post->ID, 'wphave_schema_review_rating', true ) );
            if( $review_author !== '' && $review_body !== '' && $review_rating >= 1 && $review_rating <= 5 ) {
                $node['review'] = array(
                    '@type' => 'Review',
                    'author' => array(
                        '@type' => 'Person',
                        'name' => $review_author,
                    ),
                    'reviewBody' => $review_body,
                    'reviewRating' => array(
                        '@type' => 'Rating',
                        'ratingValue' => number_format( $review_rating, 1, '.', '' ),
                        'bestRating' => '5',
                        'worstRating' => '1',
                    ),
                );
            }
        }

        return apply_filters( 'wphave_schema_primary_entity_node', $node, $type, $post );
    }

    /**
     * Return the supported primary schema type assigned to the current post.
     *
     * @return string
     */

    protected function get_primary_entity_type(): string {
        if( ! is_singular() || $this->post_schema_node_excluded( 'primary_entity' ) ) {
            return '';
        }

        if( $this->is_woocommerce_product_request() ) {
            return 'Product';
        }

        $type = get_post_meta( get_queried_object_id(), 'wphave_schema_type', true );

        return in_array( $type, array( 'SoftwareApplication', 'Product', 'Service', 'Event', 'VideoObject' ), true ) ? $type : '';
    }

    /**
     * Build the physical and/or virtual location for an Event entity.
     *
     * @param int $post_id Event post ID.
     * @param string $attendance Supported Schema.org attendance mode.
     * @return array<string,mixed>
     */

    protected function get_event_location( int $post_id, string $attendance ): array {
        $locations = array();
        if( $attendance !== 'OnlineEventAttendanceMode' ) {
            $locations[] = array(
                '@type' => 'Place',
                'name' => get_post_meta( $post_id, 'wphave_schema_event_location_name', true ),
                'address' => array(
                    '@type' => 'PostalAddress',
                    'streetAddress' => get_post_meta( $post_id, 'wphave_schema_event_street', true ),
                    'postalCode' => get_post_meta( $post_id, 'wphave_schema_event_postal_code', true ),
                    'addressLocality' => get_post_meta( $post_id, 'wphave_schema_event_locality', true ),
                    'addressRegion' => get_post_meta( $post_id, 'wphave_schema_event_region', true ),
                    'addressCountry' => strtoupper( get_post_meta( $post_id, 'wphave_schema_event_country', true ) ),
                ),
            );
        }

        if( $attendance !== 'OfflineEventAttendanceMode' ) {
            $locations[] = array(
                '@type' => 'VirtualLocation',
                'url' => esc_url_raw( get_post_meta( $post_id, 'wphave_schema_event_location_url', true ) ),
            );
        }

        return count( $locations ) === 1 ? $locations[0] : $locations;
    }

}
