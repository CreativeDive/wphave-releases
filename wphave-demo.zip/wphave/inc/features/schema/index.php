<?php

/**
 * Builds and renders the public Schema.org JSON-LD graph.
 *
 * The graph uses stable fragment identifiers so providers added later can
 * reference the site identity, website and current page without duplicating
 * entities. Empty values are removed before the graph reaches the frontend.
 */

if( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPHAVE_Schema extends WPHAVE_Schema_Commerce {
    /**
     * Shared schema instance.
     *
     * @var WPHAVE_Schema|null
     */

    private static ?WPHAVE_Schema $instance = null;

    /**
     * REST-enabled post meta used by page-specific schema providers.
     *
     * Values are stored as strings so an empty editor field remains distinct
     * from a real numeric zero. Providers normalize prices and URLs at output.
     *
     * @var array<string,string>
     */

    protected array $post_meta = array(
        'wphave_schema_disabled' => 'boolean_string',
        'wphave_schema_exclude_article' => 'boolean_string',
        'wphave_schema_exclude_primary_entity' => 'boolean_string',
        'wphave_schema_exclude_faq' => 'boolean_string',
        'wphave_schema_exclude_breadcrumb' => 'boolean_string',
        'wphave_schema_article_type' => 'key',
        'wphave_schema_article_image_1x1' => 'url',
        'wphave_schema_article_image_4x3' => 'url',
        'wphave_schema_article_image_16x9' => 'url',
        'wphave_schema_type' => 'key',
        'wphave_schema_name' => 'text',
        'wphave_schema_description' => 'textarea',
        'wphave_schema_sku' => 'text',
        'wphave_schema_brand' => 'text',
        'wphave_schema_mpn' => 'text',
        'wphave_schema_gtin' => 'text',
        'wphave_schema_price' => 'text',
        'wphave_schema_currency' => 'key',
        'wphave_schema_availability' => 'key',
        'wphave_schema_application_category' => 'text',
        'wphave_schema_operating_system' => 'text',
        'wphave_schema_software_version' => 'text',
        'wphave_schema_rating_value' => 'text',
        'wphave_schema_rating_count' => 'nonnegative_int',
        'wphave_schema_review_author' => 'text',
        'wphave_schema_review_body' => 'textarea',
        'wphave_schema_review_rating' => 'text',
        'wphave_schema_service_type' => 'text',
        'wphave_schema_service_area' => 'text',
        'wphave_schema_event_start' => 'text',
        'wphave_schema_event_end' => 'text',
        'wphave_schema_event_previous_start' => 'text',
        'wphave_schema_event_performer' => 'text',
        'wphave_schema_event_status' => 'key',
        'wphave_schema_event_attendance' => 'key',
        'wphave_schema_event_location_name' => 'text',
        'wphave_schema_event_location_url' => 'url',
        'wphave_schema_event_street' => 'text',
        'wphave_schema_event_postal_code' => 'text',
        'wphave_schema_event_locality' => 'text',
        'wphave_schema_event_region' => 'text',
        'wphave_schema_event_country' => 'key',
        'wphave_schema_video_content_url' => 'url',
        'wphave_schema_video_embed_url' => 'url',
        'wphave_schema_video_thumbnail_url' => 'url',
        'wphave_schema_video_upload_date' => 'text',
        'wphave_schema_video_duration' => 'text',
        'wphave_schema_video_expires' => 'text',
        'wphave_schema_video_regions' => 'text',
        'wphave_schema_video_live_start' => 'text',
        'wphave_schema_video_live_end' => 'text',
    );

    /**
     * Request-local FAQ node cache.
     *
     * Parsing and rendering nested blocks can be relatively expensive. The
     * cache ensures the page relationship and graph output share one result.
     *
     * @var array<string,mixed>|null
     */

    protected ?array $faq_node = null;

    /**
     * Request-local normalized schema settings.
     */

    protected ?array $settings_cache = null;

    /**
     * Get the shared schema instance.
     *
     * @return WPHAVE_Schema
     */

    public static function instance(): WPHAVE_Schema {
        if( self::$instance === null ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Register the frontend structured-data output.
     */

    public function __construct() {
        add_action( 'init', array( $this, 'register_post_meta' ) );
        add_action( 'wp_head', array( $this, 'render' ), 20 );
        add_filter( 'woocommerce_structured_data_type_for_page', array( $this, 'filter_woocommerce_structured_data_types' ), 100 );
    }

    /**
     * Register a read-only Schema status box in the classic product editor.
     *
     * WooCommerce remains the canonical source for product values. The box
     * explains ownership without duplicating editable price, stock or identifier
     * fields that could diverge from the actual product data.
     */

    public function register_product_schema_meta_box(): void {
        add_meta_box(
            'wphave-product-schema-status',
            __( 'Schema', 'wphave' ),
            array( $this, 'render_product_schema_meta_box' ),
            'product',
            'side',
            'default'
        );
    }

    /**
     * Render the WooCommerce product Schema ownership explanation.
     *
     * @param WP_Post $post Current WooCommerce product.
     */

    public function render_product_schema_meta_box( WP_Post $post ): void {
        if( $post->post_type !== 'product' ) {
            return;
        }

        $settings = $this->get_settings();
        $takeover_enabled = $this->is_enabled() && ! empty( $settings['woocommerce']['takeOverProductSchema'] );

        if( $takeover_enabled ) {
            echo '<p><strong>' . esc_html__( 'Managed by wphave', 'wphave' ) . '</strong></p>';
            echo '<p>' . esc_html__( 'Product name, description, images, price, stock, SKU, ratings and supported identifiers are read directly from WooCommerce. Edit those values in the regular product fields.', 'wphave' ) . '</p>';
        } else {
            echo '<p><strong>' . esc_html__( 'wphave product integration is disabled', 'wphave' ) . '</strong></p>';
            echo '<p>' . esc_html__( 'WooCommerce continues to manage its native product structured data.', 'wphave' ) . '</p>';
        }

        echo '<p><a href="' . esc_url( admin_url( 'admin.php?page=workspace&screen=settings' ) ) . '">' . esc_html__( 'Open wphave settings', 'wphave' ) . '</a></p>';
        echo '<p class="description">' . esc_html__( 'Then choose Schema and open the Commerce tab.', 'wphave' ) . '</p>';
    }

    /**
     * Register page-specific schema fields for every public post type.
     */

    public function register_post_meta(): void {
        $post_types = get_post_types( array(
            'public' => true,
        ), 'names' );

        foreach( $post_types as $post_type ) {
            if( $post_type === 'attachment' ) {
                continue;
            }

            foreach( $this->post_meta as $meta_key => $sanitize_type ) {
                register_post_meta( $post_type, $meta_key, array(
                    'single' => true,
                    'type' => 'string',
                    'show_in_rest' => true,
                    'auth_callback' => array( $this, 'can_edit_post_meta' ),
                    'sanitize_callback' => function( $value ) use ( $sanitize_type ) {
                        return $this->sanitize_post_meta_value( $value, $sanitize_type );
                    },
                ) );
            }
        }
    }

    /**
     * Check whether the current user may update schema post metadata.
     *
     * @return bool
     */

    public function can_edit_post_meta(): bool {
        return current_user_can( 'edit_posts' );
    }

    /**
     * Check whether structured data is enabled in site settings.
     *
     * Schema is disabled by default until a site administrator deliberately
     * reviews and enables its public identity data.
     *
     * @return bool
     */

    public function is_enabled(): bool {
        $settings = $this->get_settings();

        return isset( $settings['isEnabled'] ) ? (bool) $settings['isEnabled'] : false;
    }

    /**
     * Render one JSON-LD script containing the complete graph for the request.
     */

    public function render(): void {
        if( ! $this->should_render() ) {
            return;
        }

        $graph = $this->get_graph();

        if( empty( $graph ) ) {
            return;
        }

        $payload = array(
            '@context' => 'https://schema.org',
            '@graph' => $graph,
        );

        // SECURITY INVARIANT: Structured data is embedded in an HTML script context.
        // Tag and ampersand hex encoding prevents schema values from terminating the
        // JSON-LD element and becoming executable markup.
        echo '<script type="application/ld+json" class="wphave-schema">' . wp_json_encode( $payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP ) . '</script>' . "\n";
    }

    /**
     * Build the graph for the current public request.
     *
     * @return array<int,array<string,mixed>>
     */

    public function get_graph(): array {
        if( ! $this->should_render() ) {
            return array();
        }

        $graph = array(
            $this->get_identity_node(),
            $this->get_local_business_node(),
            $this->get_website_node(),
            $this->get_webpage_node(),
        );

        $breadcrumb = $this->get_breadcrumb_node();
        if( ! empty( $breadcrumb ) ) {
            $graph[] = $breadcrumb;
        }

        $article = $this->get_article_node();
        if( ! empty( $article ) ) {
            $graph[] = $this->get_author_node();
            $graph[] = $article;
        }

        $primary_entity = $this->get_primary_entity_node();
        if( ! empty( $primary_entity ) ) {
            $graph[] = $primary_entity;
        }

        $faq = $this->get_faq_node();
        if( ! empty( $faq ) ) {
            $graph[] = $faq;
        }

        $graph = array_values( array_filter( array_map( array( $this, 'remove_empty_values' ), $graph ) ) );

        /**
         * Filter the complete Schema.org graph before it is serialized.
         *
         * @param array<int,array<string,mixed>> $graph Schema graph nodes.
         */

        return apply_filters( 'wphave_schema_graph', $graph );
    }

    /**
     * Determine whether schema output is appropriate for the current request.
     *
     * @return bool
     */

    protected function should_render(): bool {
        if( ! $this->is_enabled() || is_admin() || is_feed() || is_robots() || is_trackback() || is_404() || is_search() ) {
            return false;
        }

        if( is_singular() ) {
            $post = get_post();
            if( ! $post || ! empty( $post->post_password ) ) {
                return false;
            }

            if( $this->post_schema_disabled( $post->ID ) ) {
                return false;
            }

            if( class_exists( 'WPHAVE_SEO' ) && WPHAVE_SEO::instance()->post_is_noindex( $post->ID ) ) {
                return false;
            }
        }

        /**
         * Filter whether JSON-LD should be rendered for the current request.
         *
         * @param bool $should_render Whether schema output is enabled.
         */

        return (bool) apply_filters( 'wphave_schema_should_render', true );
    }

    /**
     * Sanitize one schema post meta value according to its field purpose.
     *
     * @param mixed $value Raw REST value.
     * @param string $sanitize_type Sanitization strategy.
     * @return string
     */

    protected function sanitize_post_meta_value( $value, string $sanitize_type ): string {
        if( $sanitize_type === 'boolean_string' ) {
            return rest_sanitize_boolean( $value ) ? '1' : '0';
        }

        if( $sanitize_type === 'key' ) {
            return sanitize_text_field( $value );
        }

        if( $sanitize_type === 'textarea' ) {
            return sanitize_textarea_field( $value );
        }

        if( $sanitize_type === 'url' ) {
            return esc_url_raw( $value );
        }

        if( $sanitize_type === 'nonnegative_int' ) {
            return (string) max( 0, absint( $value ) );
        }

        return sanitize_text_field( $value );
    }

    /**
     * Check whether wphave schema is disabled for the current singular post.
     *
     * @param int $post_id Optional post ID. Defaults to the queried object.
     * @return bool
     */

    protected function post_schema_disabled( int $post_id = 0 ): bool {
        $post_id = $post_id ?: get_queried_object_id();

        return $post_id > 0 && get_post_meta( $post_id, 'wphave_schema_disabled', true ) === '1';
    }

    /**
     * Check whether one automatically generated node is excluded locally.
     *
     * @param string $node Supported node identifier.
     * @return bool
     */

    protected function post_schema_node_excluded( string $node ): bool {
        if( ! is_singular() ) {
            return false;
        }

        $supported_nodes = array( 'article', 'primary_entity', 'faq', 'breadcrumb' );
        if( ! in_array( $node, $supported_nodes, true ) ) {
            return false;
        }

        return get_post_meta( get_queried_object_id(), 'wphave_schema_exclude_' . $node, true ) === '1';
    }

    /**
     * Return normalized schema settings.
     *
     * @return array<string,mixed>
     */

    protected function get_settings(): array {
        if( $this->settings_cache !== null ) {
            return $this->settings_cache;
        }

        /*
         * Runtime rendering deliberately uses the stored configuration without
         * LIFECYCLE INVARIANT: A downgrade locks editing but must not remove an
         * already published Schema.org graph.
         */

        $settings = wphave_data_get( 'site_settings', 'schema', array() );

        $this->settings_cache = is_array( $settings ) ? $settings : array();

        return $this->settings_cache;
    }

    /**
     * Build a stable site-level node identifier.
     *
     * @param string $fragment Identifier fragment without a hash.
     * @return string
     */

    protected function get_id( string $fragment ): string {
        return home_url( '/' ) . '#' . sanitize_title( $fragment );
    }

    /**
     * Resolve the canonical public URL for the current request.
     *
     * @return string
     */

    protected function get_current_url(): string {
        if( is_singular() ) {
            $url = get_permalink( get_queried_object_id() );
            return $url ?: home_url( '/' );
        }

        if( is_front_page() ) {
            return home_url( '/' );
        }

        $url = get_pagenum_link( max( 1, get_query_var( 'paged' ) ) );
        return $url ?: home_url( '/' );
    }

    /**
     * Recursively remove empty properties without discarding boolean false or zero.
     *
     * @param mixed $value Graph value.
     * @return mixed
     */

    protected function remove_empty_values( $value ) {
        if( ! is_array( $value ) ) {
            return $value;
        }

        $clean = array();
        foreach( $value as $key => $item ) {
            $item = $this->remove_empty_values( $item );
            if( $item === '' || $item === null || $item === array() ) {
                continue;
            }

            $clean[ $key ] = $item;
        }

        return $clean;
    }
}

WPHAVE_Schema::instance();
