<?php

/** Bootstrap Schema.org diagnostics and editor integrations. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/rest-controller.php';

( static function (): void {
	$schema = WPHAVE_Schema::instance();
	$rest_controller = new WPHAVE_Schema_REST_Controller( $schema );

	add_action( 'add_meta_boxes_product', array( $schema, 'register_product_schema_meta_box' ) );
	add_action( 'rest_api_init', array( $rest_controller, 'register_routes' ) );
} )();
