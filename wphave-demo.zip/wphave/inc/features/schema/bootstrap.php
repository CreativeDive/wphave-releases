<?php

/**
 * Bootstrap the Schema.org provider hierarchy and public facade.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Determine whether Schema settings may be changed.
 *
 * Existing Schema.org output deliberately remains active after a downgrade.
 * Pro access controls configuration changes, not public runtime rendering.
 *
 * @return bool Whether a valid Pro entitlement is available.
 */

function wphave_schema_has_pro_access() {
	return function_exists( 'wphave_has_pro_access' ) && wphave_has_pro_access();
}

/**
 * Preserve the complete stored Schema configuration without Pro access.
 *
 * Disabled UI controls are not a security boundary. Keeping this protection on
 * the shared write path prevents direct or unrelated site-settings saves from
 * replacing a former Pro user's active Schema graph with client defaults.
 *
 * @param array $data Prepared site settings.
 * @param array $config Site-settings resource configuration.
 * @return array Entitlement-safe site settings.
 */

function wphave_preserve_schema_pro_settings( array $data, array $config ): array {
	if( wphave_schema_has_pro_access() || ! class_exists( 'WPHAVE_Data_Resources' ) ) return $data;

	$current = WPHAVE_Data_Resources::get( 'site_settings', false );

	if( array_key_exists( 'schema', $current ) ) {
		$data['schema'] = $current['schema'];
	} else {
		unset( $data['schema'] );
	}

	return $data;
}

add_filter( 'wphave_prepare_site_settings_for_write', 'wphave_preserve_schema_pro_settings', 20, 2 );

require_once __DIR__ . '/validator.php';
require_once __DIR__ . '/identity.php';
require_once __DIR__ . '/content.php';
require_once __DIR__ . '/article.php';
require_once __DIR__ . '/primary-entity.php';
require_once __DIR__ . '/discovery.php';
require_once __DIR__ . '/commerce.php';
require_once __DIR__ . '/index.php';
