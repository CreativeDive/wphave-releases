<?php

/** Appointment-type ownership and policy validation. */

final class WPHAVE_Booking_Services {
	public const POST_TYPE = 'wphave_booking_type';
	private const META_KEY = '_wphave_booking_policy';

	/**
	 * Register the appointment type with delegated booking capabilities.
	 * @return void
	 */

	public static function register(): void {
		register_post_type(self::POST_TYPE, [
			'label' => __('Services', 'wphave'),
			'public' => false,
			'publicly_queryable' => false,
			'show_ui' => true,
			'show_in_menu' => true,
			'show_in_rest' => false,
			'supports' => ['title'],
			'capabilities' => [
				// Object capabilities must remain distinct from primitive capabilities.
				// The access preload excludes object capabilities from its cap list.
				'edit_post' => 'edit_wphave_booking_type',
				'read_post' => 'read_wphave_booking_type',
				'delete_post' => 'delete_wphave_booking_type',
				'edit_posts' => 'wphave_manage_bookings',
				'edit_others_posts' => 'wphave_manage_bookings',
				'edit_published_posts' => 'wphave_manage_bookings',
				'edit_private_posts' => 'wphave_manage_bookings',
				'publish_posts' => 'wphave_manage_bookings',
				'read_private_posts' => 'wphave_manage_bookings',
				'delete_posts' => 'wphave_manage_bookings',
				'delete_others_posts' => 'wphave_manage_bookings',
				'delete_published_posts' => 'wphave_manage_bookings',
				'delete_private_posts' => 'wphave_manage_bookings',
				'create_posts' => 'wphave_manage_bookings',
			],
			'map_meta_cap' => true,
		]);
	}

	/**
	 * Return a published appointment type’s validated availability policy.
	 *
	 * @param int $id Internal record ID.
	 * @return array<string, mixed>|null
	 */

	public static function get(int $id): ?array {
		$post = get_post($id);

		if (!$post || self::POST_TYPE !== $post->post_type || 'publish' !== $post->post_status) {
			return null;
		}

		$policy = get_post_meta($id, self::META_KEY, true);

		if (!is_array($policy)) {
			return null;
		}

		try {
			return self::validate($policy);
		} catch (InvalidArgumentException $error) {
			return null;
		}
	}

	/**
	 * Normalize a policy and reject invalid timezone or availability rules.
	 *
	 * @param array $input Untrusted appointment policy input.
	 * @return array<string, mixed>
	 */

	public static function validate(array $input): array {
		if (!is_string($input['timezone'] ?? null)) {
			throw new InvalidArgumentException('A valid timezone is required.');
		}
		$timezone = (string) ($input['timezone'] ?? '');
		$daily_limit_input = $input['max_bookings_per_day'] ?? 0;
		// A cast must never turn an array, boolean, float or malformed number into
		// a different publishable policy. Both REST JSON and native JSON editors
		// enter this validation boundary before availability is calculated.
		foreach ([
			'duration_minutes',
			'buffer_minutes',
			'notice_minutes',
			'horizon_days',
			'slot_step_minutes',
			'max_bookings_per_day',
		] as $field) {
			$value = $input[$field] ?? 0;
			if (!is_int($value) && !(is_string($value) && preg_match('/^\d{1,5}$/D', $value))) {
				throw new InvalidArgumentException('Invalid numeric appointment policy.');
			}
		}
		if ((!is_int($daily_limit_input) &&
			!(is_string($daily_limit_input) && preg_match('/^\d{1,3}$/D', $daily_limit_input))) ||
			!is_string($input['meeting_mode'] ?? 'online') ||
			!is_string($input['meeting_details'] ?? '') ||
			!is_string($input['attendee_email_note'] ?? '')) {
			throw new InvalidArgumentException('Invalid appointment details or daily limit.');
		}
		$fixed_offset = preg_match('/^[+-](?:(?:0[0-9]|1[0-3]):[0-5][0-9]|14:00)$/', $timezone);

		if (!in_array($timezone, timezone_identifiers_list(), true) && !$fixed_offset) {
			throw new InvalidArgumentException('A valid timezone is required.');
		}

		$policy = [
			'timezone' => $timezone,
			'duration_minutes' => (int) ($input['duration_minutes'] ?? 0),
			'buffer_minutes' => (int) ($input['buffer_minutes'] ?? 0),
			'notice_minutes' => (int) ($input['notice_minutes'] ?? 0),
			'horizon_days' => (int) ($input['horizon_days'] ?? 0),
			'slot_step_minutes' => (int) ($input['slot_step_minutes'] ?? 0),
			'max_bookings_per_day' => (int) ($input['max_bookings_per_day'] ?? 0),
			'provider_ids' => [],
			'provider_weekly_windows' => [],
			'provider_date_windows' => [],
			'weekly_windows' => [],
			'closed_dates' => [],
			'date_windows' => [],
			'intake_fields' => WPHAVE_Booking_Intake::validate_fields($input['intake_fields'] ?? []),
			'meeting_mode' => (string) ($input['meeting_mode'] ?? 'online'),
			'meeting_details' => trim((string) ($input['meeting_details'] ?? '')),
			'attendee_email_note' => trim((string) ($input['attendee_email_note'] ?? '')),
		];

		$provider_ids = $input['provider_ids'] ?? [];
		if (!is_array($provider_ids) || count($provider_ids) > 20) {
			throw new InvalidArgumentException('Invalid booking providers.');
		}
		foreach ($provider_ids as $provider_id) {
			if (!is_int($provider_id) && !(is_string($provider_id) && preg_match('/^[1-9][0-9]*$/D', $provider_id))) {
				throw new InvalidArgumentException('Invalid booking provider ID.');
			}
			$provider_id = (int) $provider_id;
			if (!$provider_id || !get_userdata($provider_id) || in_array($provider_id, $policy['provider_ids'], true)) {
				throw new InvalidArgumentException('Booking provider is unavailable or duplicated.');
			}
			$policy['provider_ids'][] = $provider_id;
		}
		$provider_windows = $input['provider_weekly_windows'] ?? [];
		if (!is_array($provider_windows) || count($provider_windows) > 20) {
			throw new InvalidArgumentException('Invalid provider availability.');
		}
		foreach ($provider_windows as $provider_id => $windows) {
			if (!preg_match('/^[1-9][0-9]*$/D', (string) $provider_id) ||
				!in_array((int) $provider_id, $policy['provider_ids'], true)) {
				throw new InvalidArgumentException('Provider availability must belong to this service.');
			}
			// An empty override means this provider offers no hours; absence inherits service hours.
			$policy['provider_weekly_windows'][(int) $provider_id] = self::normalize_weekly_windows($windows);
		}

		if (!in_array($policy['meeting_mode'], ['online', 'phone', 'in_person'], true) ||
			$policy['max_bookings_per_day'] < 0 || $policy['max_bookings_per_day'] > 100 ||
			strlen($policy['meeting_details']) > 1000 ||
			strlen($policy['attendee_email_note']) > 1000 ||
			!is_array($input['date_windows'] ?? [])) {
			throw new InvalidArgumentException('Invalid appointment details or date exceptions.');
		}

		if (
			!is_array($input['weekly_windows'] ?? []) ||
			!is_array($input['closed_dates'] ?? []) ||
			count($input['weekly_windows'] ?? []) > 7
		) {
			throw new InvalidArgumentException('Invalid booking calendar.');
		}

		$policy['weekly_windows'] = self::normalize_weekly_windows($input['weekly_windows'] ?? []);

		if (count($input['closed_dates'] ?? []) > 366) {
			throw new InvalidArgumentException('Too many closed dates.');
		}

		foreach (($input['closed_dates'] ?? []) as $date) {
			if (
				!is_string($date) ||
				!preg_match('/^\d{4}-\d{2}-\d{2}$/D', $date) ||
				DateTimeImmutable::createFromFormat('!Y-m-d', $date) === false ||
				DateTimeImmutable::createFromFormat('!Y-m-d', $date)->format('Y-m-d') !== $date
			) {
				throw new InvalidArgumentException('Invalid closed date.');
			}
			$policy['closed_dates'][] = $date;
		}

		$policy['date_windows'] = self::normalize_date_windows($input['date_windows'] ?? [], $policy['closed_dates']);
		$provider_dates = $input['provider_date_windows'] ?? [];
		if (!is_array($provider_dates) || count($provider_dates) > 20) {
			throw new InvalidArgumentException('Invalid provider date exceptions.');
		}
		foreach ($provider_dates as $provider_id => $dates) {
			if (!preg_match('/^[1-9][0-9]*$/D', (string) $provider_id) ||
				!in_array((int) $provider_id, $policy['provider_ids'], true)) {
				throw new InvalidArgumentException('Provider date exceptions must belong to this service.');
			}
			$policy['provider_date_windows'][(int) $provider_id] = self::normalize_date_windows($dates, $policy['closed_dates']);
		}

		// The calculator owns numeric and wall-time invariants.
		WPHAVE_Booking_Availability::slots(
			$policy,
			[],
			new DateTimeImmutable('now', new DateTimeZone('UTC')),
		);

		return $policy;
	}

	/**
	 * Validate one map of local date exceptions for a service or provider.
	 * @param mixed $input Date-to-window map.
	 * @param array<int, string> $closed Shared closed dates that cannot be reopened.
	 * @return array<string, array<int, array{start: string, end: string}>>
	 */
	private static function normalize_date_windows($input, array $closed): array {
		if (!is_array($input) || count($input) > 366) {
			throw new InvalidArgumentException('Too many date exceptions.');
		}
		$result = [];
		foreach ($input as $date => $windows) {
			$parsed = DateTimeImmutable::createFromFormat('!Y-m-d', (string) $date);
			if (!$parsed || $parsed->format('Y-m-d') !== (string) $date ||
				!is_array($windows) || count($windows) > 4 || in_array($date, $closed, true)) {
				throw new InvalidArgumentException('Invalid date exception.');
			}

			$previous_end = '';
			foreach ($windows as $window) {
				if (!is_array($window) || !is_string($window['start'] ?? null) ||
					!is_string($window['end'] ?? null) ||
					!preg_match('/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D', $window['start']) ||
					!preg_match('/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D', $window['end']) ||
					$window['start'] >= $window['end'] || $window['start'] < $previous_end) {
					throw new InvalidArgumentException('Invalid date exception window.');
				}
				$result[$date][] = [
					'start' => $window['start'],
					'end' => $window['end'],
				];
				$previous_end = $window['end'];
			}
			$result[$date] ??= [];
		}
		return $result;
	}

	/**
	 * Validate recurring windows for a service or one assigned provider.
	 * Both paths must enforce identical wall-time and overlap invariants.
	 *
	 * @param mixed $input Weekday-to-window map.
	 * @return array<int, array<int, array{start: string, end: string}>>
	 */
	private static function normalize_weekly_windows($input): array {
		if (!is_array($input) || count($input) > 7) {
			throw new InvalidArgumentException('Invalid weekly booking windows.');
		}
		$result = [];
		foreach ($input as $weekday => $windows) {
			if (!preg_match('/^[1-7]$/D', (string) $weekday) || !is_array($windows) || count($windows) > 4) {
				throw new InvalidArgumentException('Invalid weekly booking windows.');
			}
			$previous_end = '';
			foreach ($windows as $window) {
				if (!is_array($window) || !is_string($window['start'] ?? null) ||
					!is_string($window['end'] ?? null) ||
					!preg_match('/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D', $window['start']) ||
					!preg_match('/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D', $window['end']) ||
					$window['start'] >= $window['end'] || $window['start'] < $previous_end) {
					throw new InvalidArgumentException('Invalid booking window.');
				}
				$result[(int) $weekday][] = ['start' => $window['start'], 'end' => $window['end']];
				$previous_end = $window['end'];
			}
			$result[(int) $weekday] ??= [];
		}
		return $result;
	}

	/**
	 * Persist a nonce-authorized policy from the native post editor.
	 *
	 * @param int $post_id Appointment type post ID.
	 * @return void
	 */

	public static function save(int $post_id): void {
		if (
			self::POST_TYPE !== get_post_type($post_id) ||
			!current_user_can('wphave_manage_bookings') ||
			!isset($_POST['wphave_booking_nonce']) ||
			!wp_verify_nonce(
				sanitize_text_field(wp_unslash($_POST['wphave_booking_nonce'])),
				'wphave_booking_policy',
			)
		) {
			return;
		}

		$raw = isset($_POST['wphave_booking_policy'])
			? wp_unslash($_POST['wphave_booking_policy'])
			: '';

		if (!is_string($raw) || strlen($raw) > 32768) {
			return;
		}

		$decoded = json_decode($raw, true);

		try {
			$policy = self::validate(is_array($decoded) ? $decoded : []);
			update_post_meta($post_id, self::META_KEY, $policy);
		} catch (InvalidArgumentException $error) {
			delete_post_meta($post_id, self::META_KEY);
		}
	}

	/**
	 * Register the native appointment-policy fallback editor.
	 * @return void
	 */

	public static function meta_box(): void {
		add_meta_box(
			'wphave-booking-policy',
			__('Booking availability', 'wphave'),
			[__CLASS__, 'render_meta_box'],
			self::POST_TYPE,
		);
	}

	/**
	 * Render a policy JSON editor and embeddable shortcode.
	 *
	 * @param WP_Post $post Appointment type post.
	 * @return void
	 */

	public static function render_meta_box(WP_Post $post): void {
		$policy = get_post_meta($post->ID, self::META_KEY, true);

		if (!is_array($policy)) {
			$policy = [
				'timezone' => wp_timezone_string() ?: 'UTC',
				'duration_minutes' => 30,
				'buffer_minutes' => 0,
				'notice_minutes' => 60,
				'horizon_days' => 30,
				'slot_step_minutes' => 30,
				'max_bookings_per_day' => 0,
				'weekly_windows' => [
					1 => [['start' => '09:00', 'end' => '17:00']],
					2 => [['start' => '09:00', 'end' => '17:00']],
					3 => [['start' => '09:00', 'end' => '17:00']],
					4 => [['start' => '09:00', 'end' => '17:00']],
					5 => [['start' => '09:00', 'end' => '17:00']],
				],
				'closed_dates' => [],
				'date_windows' => [],
				'intake_fields' => [],
				'meeting_mode' => 'online',
				'meeting_details' => '',
			];
		}

		wp_nonce_field('wphave_booking_policy', 'wphave_booking_nonce');

		echo '<p>' . esc_html__('Edit the appointment policy as JSON. Use weekday numbers 1 (Monday) through 7 (Sunday). Invalid policies disable public booking.', 'wphave') . '</p>';
		echo '<textarea name="wphave_booking_policy" rows="18" style="width:100%;font-family:monospace">';
		echo esc_textarea(wp_json_encode($policy, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
		echo '</textarea>';
		echo '<p><code>[wphave_booking id="' . esc_html((string) $post->ID) . '"]</code></p>';
	}
}
