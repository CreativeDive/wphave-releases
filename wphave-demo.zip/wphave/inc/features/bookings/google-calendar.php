<?php

/** Read one connected Google calendar's busy intervals without importing event details. */
final class WPHAVE_Booking_Google_Calendar {
	private const OPTION = 'wphave_booking_google_calendar';
	private const KEY_CONTEXT = 'booking_google_calendar';
	private const SCOPE = 'https://www.googleapis.com/auth/calendar.events.freebusy';

	/**
	 * Whether this installation has the OAuth credentials needed to connect.
	 * @return bool
	 */
	public static function configured(): bool {
		return defined('WPHAVE_BOOKING_GOOGLE_CLIENT_ID') && defined('WPHAVE_BOOKING_GOOGLE_CLIENT_SECRET') &&
			is_string(WPHAVE_BOOKING_GOOGLE_CLIENT_ID) && '' !== WPHAVE_BOOKING_GOOGLE_CLIENT_ID &&
			is_string(WPHAVE_BOOKING_GOOGLE_CLIENT_SECRET) && '' !== WPHAVE_BOOKING_GOOGLE_CLIENT_SECRET;
	}

	/**
	 * Whether connection storage exists, including malformed values that must fail closed.
	 * @return bool
	 */
	public static function connected(int $provider_id = 0): bool {
		return false !== get_option(self::option_name($provider_id), false);
	}

	/**
	 * Public status contains no credential or provider event detail.
	 * @return array<string, bool|string>
	 */
	public static function status(int $provider_id = 0): array {
		$query = $provider_id > 0 ? '&provider_id=' . $provider_id : '';
		return [
			'configured' => self::configured(),
			'connected' => self::connected($provider_id),
			'connectUrl' => self::configured()
				? wp_nonce_url(admin_url('admin-post.php?action=wphave_booking_google_connect' . $query), 'wphave_booking_google_connect')
				: '',
			'disconnectUrl' => self::connected($provider_id)
				? wp_nonce_url(admin_url('admin-post.php?action=wphave_booking_google_disconnect' . $query), 'wphave_booking_google_disconnect')
				: '',
			'callbackUrl' => self::callback_url(),
		];
	}

	/**
	 * Begin the server-side OAuth authorization-code flow.
	 * @return void
	 */
	public static function connect(): void {
		self::authorize('wphave_booking_google_connect');
		$provider_id = self::requested_provider_id();
		if (!self::configured()) {
			wp_die(esc_html__('Google Calendar credentials are not configured.', 'wphave'), '', ['response' => 503]);
		}
		$state = bin2hex(random_bytes(24));
		$verifier = bin2hex(random_bytes(32));
		set_transient('wphave_booking_google_oauth_' . $state, [
			'user' => get_current_user_id(),
			'provider_id' => $provider_id,
			'verifier' => $verifier,
			'return' => wp_validate_redirect(wp_get_referer(), admin_url()),
		], 10 * MINUTE_IN_SECONDS);
		$url = add_query_arg([
			'client_id' => WPHAVE_BOOKING_GOOGLE_CLIENT_ID,
			'redirect_uri' => self::callback_url(),
			'response_type' => 'code',
			'scope' => self::SCOPE,
			'access_type' => 'offline',
			'prompt' => 'consent',
			'state' => $state,
			'code_challenge' => rtrim(strtr(base64_encode(hash('sha256', $verifier, true)), '+/', '-_'), '='),
			'code_challenge_method' => 'S256',
		], 'https://accounts.google.com/o/oauth2/v2/auth');
		wp_redirect($url, 302, 'WPHAVE');
		exit;
	}

	/**
	 * Complete OAuth only for the initiating Booking manager and one-time state.
	 * @return void
	 */
	public static function callback(): void {
		if (!current_user_can('wphave_manage_bookings')) {
			wp_die(esc_html__('Booking access required.', 'wphave'), '', ['response' => 403]);
		}
		$state = sanitize_text_field(wp_unslash($_GET['state'] ?? ''));
		if (!preg_match('/^[a-f0-9]{48}$/D', $state)) {
			wp_die(esc_html__('Calendar connection expired.', 'wphave'), '', ['response' => 400]);
		}
		$key = 'wphave_booking_google_oauth_' . $state;
		$pending = get_transient($key);
		delete_transient($key);
		if (!is_array($pending) || (int) ($pending['user'] ?? 0) !== get_current_user_id() ||
			!is_string($pending['verifier'] ?? null) || !self::configured()) {
			wp_die(esc_html__('Calendar connection expired.', 'wphave'), '', ['response' => 400]);
		}
		$code = wp_unslash($_GET['code'] ?? '');
		if (!is_string($code) || '' === $code || strlen($code) > 2048) {
			wp_die(esc_html__('Google did not authorize the calendar.', 'wphave'), '', ['response' => 400]);
		}
		try {
			$tokens = self::token_request([
				'code' => $code,
				'grant_type' => 'authorization_code',
				'redirect_uri' => self::callback_url(),
				'code_verifier' => $pending['verifier'],
			]);
		} catch (RuntimeException $error) {
			wp_die(esc_html__('Google Calendar could not be connected. Please try again.', 'wphave'), '', ['response' => 503]);
		}
		$refresh = $tokens['refresh_token'] ?? null;
		if (!is_string($refresh) || '' === $refresh) {
			wp_die(esc_html__('Google did not provide ongoing calendar access.', 'wphave'), '', ['response' => 503]);
		}
		$provider_id = (int) ($pending['provider_id'] ?? 0);
		if ($provider_id < 0 || ($provider_id > 0 && !get_userdata($provider_id))) {
			wp_die(esc_html__('Booking provider is unavailable.', 'wphave'), '', ['response' => 400]);
		}
		$cipher = WPHAVE_Crypto::encrypt($refresh, self::key_context($provider_id));
		if (!is_string($cipher) || '' === $cipher || !update_option(self::option_name($provider_id), ['refresh' => $cipher], false)) {
			wp_die(esc_html__('Calendar connection could not be saved.', 'wphave'), '', ['response' => 503]);
		}
		wp_safe_redirect(wp_validate_redirect($pending['return'] ?? '', admin_url()));
		exit;
	}

	/**
	 * Disconnect the provider without changing existing WPHAVE appointments.
	 * @return void
	 */
	public static function disconnect(): void {
		self::authorize('wphave_booking_google_disconnect');
		delete_option(self::option_name(self::requested_provider_id()));
		wp_safe_redirect(wp_validate_redirect(wp_get_referer(), admin_url()));
		exit;
	}

	/** Remove an orphaned provider credential when its WordPress user is deleted. */
	public static function remove_user(int $user_id): void {
		if ($user_id > 0) {
			delete_option(self::option_name($user_id));
		}
	}

	/**
	 * Return validated UTC intervals; an active connection always fails closed.
	 * @param DateTimeImmutable $from Requested interval start.
	 * @param DateTimeImmutable $until Requested interval end.
	 * @param int $provider_id Selected provider, or zero for site-wide checks.
	 * @return array<int, array{start: string, end: string, external: bool}>
	 * @throws RuntimeException When authorization, transport or data is invalid.
	 */
	public static function busy(DateTimeImmutable $from, DateTimeImmutable $until, int $provider_id = 0): array {
		$busy = self::read_connection($from, $until, 0);
		if ($provider_id > 0) {
			$busy = array_merge($busy, self::read_connection($from, $until, $provider_id));
		}
		return $busy;
	}

	/**
	 * Read one encrypted site or provider connection; malformed active storage fails closed.
	 * @param DateTimeImmutable $from UTC interval start.
	 * @param DateTimeImmutable $until UTC interval end.
	 * @param int $provider_id Zero for the shared calendar.
	 * @return array<int, array{start: string, end: string, external: bool}>
	 */
	private static function read_connection(DateTimeImmutable $from, DateTimeImmutable $until, int $provider_id): array {
		if (!self::connected($provider_id)) {
			return [];
		}
		if (!self::configured()) {
			throw new RuntimeException('Google Calendar credentials are unavailable.');
		}
		$connection = get_option(self::option_name($provider_id), false);
		if (!is_array($connection) || !is_string($connection['refresh'] ?? null) || '' === $connection['refresh']) {
			throw new RuntimeException('Google Calendar connection storage is invalid.');
		}
		$refresh = WPHAVE_Crypto::decrypt($connection['refresh'], self::key_context($provider_id));
		if (!is_string($refresh) || '' === $refresh) {
			throw new RuntimeException('Google Calendar connection cannot be decrypted.');
		}
		$tokens = self::token_request(['refresh_token' => $refresh, 'grant_type' => 'refresh_token']);
		$access = $tokens['access_token'] ?? null;
		if (!is_string($access) || '' === $access) {
			throw new RuntimeException('Google Calendar access could not be renewed.');
		}
		$response = wp_remote_post('https://www.googleapis.com/calendar/v3/freeBusy', [
			'timeout' => 5,
			'limit_response_size' => 262144,
			'headers' => ['Authorization' => 'Bearer ' . $access, 'Content-Type' => 'application/json'],
			'body' => wp_json_encode([
				'timeMin' => $from->setTimezone(new DateTimeZone('UTC'))->format(DATE_RFC3339),
				'timeMax' => $until->setTimezone(new DateTimeZone('UTC'))->format(DATE_RFC3339),
				'items' => [['id' => 'primary']],
			]),
		]);
		if (is_wp_error($response) || 200 !== wp_remote_retrieve_response_code($response)) {
			throw new RuntimeException('Google Calendar availability is unavailable.');
		}
		return self::parse_busy(wp_remote_retrieve_body($response), $from, $until);
	}

	/**
	 * Parse only bounded primary-calendar free/busy data; never expose event details.
	 * @param string $body Google response JSON.
	 * @param DateTimeImmutable $from Requested interval start.
	 * @param DateTimeImmutable $until Requested interval end.
	 * @return array<int, array{start: string, end: string, external: bool}>
	 * @throws RuntimeException When the response is malformed.
	 */
	public static function parse_busy(string $body, DateTimeImmutable $from, DateTimeImmutable $until): array {
		$data = json_decode($body, true);
		$calendars = $data['calendars'] ?? null;
		if (!is_array($calendars) || 1 !== count($calendars)) {
			throw new RuntimeException('Invalid Google Calendar availability response.');
		}
		// Google may resolve the requested `primary` alias to the calendar's ID.
		$calendar = reset($calendars);
		if (!is_array($calendar) || !empty($calendar['errors']) || !is_array($calendar['busy'] ?? null) || count($calendar['busy']) > 2000) {
			throw new RuntimeException('Invalid Google Calendar availability response.');
		}
		$busy = [];
		foreach ($calendar['busy'] as $interval) {
			if (!is_array($interval) || !is_string($interval['start'] ?? null) || !is_string($interval['end'] ?? null) ||
				!preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/D', $interval['start']) ||
				!preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/D', $interval['end'])) {
				throw new RuntimeException('Invalid Google Calendar interval.');
			}
			try {
				$start = new DateTimeImmutable($interval['start']);
				$end = new DateTimeImmutable($interval['end']);
			} catch (Throwable $error) {
				throw new RuntimeException('Invalid Google Calendar interval.', 0, $error);
			}
			if ($start >= $end) {
				throw new RuntimeException('Invalid Google Calendar interval.');
			}
			// Providers may return a whole event that straddles the query boundary.
			if ($end <= $from || $start >= $until) {
				continue;
			}
			$busy[] = [
				'start' => ($start < $from ? $from : $start)->format(DATE_RFC3339),
				'end' => ($end > $until ? $until : $end)->format(DATE_RFC3339),
				'external' => true,
			];
		}
		return $busy;
	}

	/**
	 * Exchange a code or refresh credential only with Google's fixed token endpoint.
	 * @param array<string, string> $grant OAuth grant fields.
	 * @return array<string, mixed> Token response.
	 * @throws RuntimeException When the provider does not authorize access.
	 */
	private static function token_request(array $grant): array {
		$response = wp_remote_post('https://oauth2.googleapis.com/token', [
			'timeout' => 5,
			'limit_response_size' => 8192,
			'body' => array_merge($grant, [
				'client_id' => WPHAVE_BOOKING_GOOGLE_CLIENT_ID,
				'client_secret' => WPHAVE_BOOKING_GOOGLE_CLIENT_SECRET,
			]),
		]);
		if (is_wp_error($response) || 200 !== wp_remote_retrieve_response_code($response)) {
			throw new RuntimeException('Google Calendar authorization failed.');
		}
		$data = json_decode(wp_remote_retrieve_body($response), true);
		if (!is_array($data)) {
			throw new RuntimeException('Invalid Google Calendar authorization response.');
		}
		return $data;
	}

	/**
	 * Check the Booking capability and action nonce before changing a connection.
	 * @param string $action Expected WordPress nonce action.
	 * @return void
	 */
	private static function authorize(string $action): void {
		if (!current_user_can('wphave_manage_bookings') || !check_admin_referer($action)) {
			wp_die(esc_html__('Booking access required.', 'wphave'), '', ['response' => 403]);
		}
	}

	/** Resolve a bounded WordPress user ID from an authorized management action. */
	private static function requested_provider_id(): int {
		$raw = wp_unslash($_GET['provider_id'] ?? '0');
		if (!is_string($raw) || !preg_match('/^(?:0|[1-9][0-9]{0,9})$/D', $raw)) {
			wp_die(esc_html__('Booking provider is unavailable.', 'wphave'), '', ['response' => 400]);
		}
		$id = (int) $raw;
		if ($id > 0 && !get_userdata($id)) {
			wp_die(esc_html__('Booking provider is unavailable.', 'wphave'), '', ['response' => 400]);
		}
		return $id;
	}

	/** Keep each provider's credential in a separate encrypted option. */
	private static function option_name(int $provider_id): string {
		return $provider_id > 0 ? self::OPTION . '_provider_' . $provider_id : self::OPTION;
	}

	/** Prevent a provider credential from decrypting under another provider ID. */
	private static function key_context(int $provider_id): string {
		return $provider_id > 0 ? self::KEY_CONTEXT . '_provider_' . $provider_id : self::KEY_CONTEXT;
	}

	/**
	 * Exact redirect URI registered in Google Cloud.
	 * @return string
	 */
	private static function callback_url(): string {
		return admin_url('admin-post.php?action=wphave_booking_google_callback');
	}
}
