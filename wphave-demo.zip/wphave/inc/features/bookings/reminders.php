<?php

require_once wphave_dir() . 'inc/features/forms/submission/mail-template.php';

/** Schedule and deliver one transactional reminder for a confirmed interval. */
final class WPHAVE_Booking_Reminders {
	/**
	 * Queue a one-time reminder; the hourly recovery pass covers missed cron jobs.
	 *
	 * @param int $booking_id Booking ID.
	 * @return void
	 */
	public static function schedule(int $booking_id): void {
		$booking = (new WPHAVE_Booking_Repository())->get($booking_id);
		if (!$booking || 'confirmed' !== $booking['status'] || 'pending' !== $booking['reminder_status']) {
			return;
		}

		$start = strtotime($booking['starts_at'] . ' UTC');
		if (!$start || $start <= time() + HOUR_IN_SECONDS) {
			return;
		}

		$hours = WPHAVE_Booking_Settings::notifications()['reminderHoursBefore'];
		$args = [$booking_id, $booking['starts_at']];
		if (!wp_next_scheduled('wphave_booking_reminder', $args)) {
			wp_schedule_single_event(max(time() + MINUTE_IN_SECONDS, $start - $hours * HOUR_IN_SECONDS), 'wphave_booking_reminder', $args);
		}
	}

	/**
	 * Recover due reminders when single-event scheduling or low traffic delayed a run.
	 * Each send still needs an atomic repository claim.
	 *
	 * @return void
	 */
	public static function reconcile(): void {
		$hours = WPHAVE_Booking_Settings::notifications()['reminderHoursBefore'];
		foreach ((new WPHAVE_Booking_Repository())->due_reminders($hours) as $booking) {
			self::send((int) $booking['id'], $booking['starts_at']);
		}
	}

	/**
	 * Claim and send at most once for the exact current interval. A throwing mail
	 * transport is ambiguous and remains unknown instead of being retried.
	 *
	 * @param int $booking_id Booking ID.
	 * @param string $start Expected UTC start.
	 * @return void
	 */
	public static function send(int $booking_id, string $start): void {
		$repository = new WPHAVE_Booking_Repository();
		$hours = WPHAVE_Booking_Settings::notifications()['reminderHoursBefore'];
		$booking = $repository->claim_reminder($booking_id, $start, $hours);
		if (!$booking) {
			return;
		}

		$service = WPHAVE_Booking_Services::get((int) $booking['service_id']);
		$timezone = new DateTimeZone($service['timezone'] ?? 'UTC');
		$when = (new DateTimeImmutable($start . ' UTC'))->setTimezone($timezone)->format('d.m.Y H:i T');
		$subject = __('Appointment reminder', 'wphave');
		$copy = sprintf(
			/* translators: 1: appointment type, 2: local date and time */
			__('Your appointment for %1$s is on %2$s.', 'wphave'),
			get_the_title((int) $booking['service_id']),
			$when,
		);
		if ('' !== ($service['meeting_details'] ?? '')) {
			$copy .= "\n\n" . __('Meeting details:', 'wphave') . "\n" . $service['meeting_details'];
		}

		$html = wphave_build_email_template([
			'title' => $subject,
			'content' => '<p>' . nl2br(esc_html($copy)) . '</p>',
			'footer_content' => esc_html__('This appointment message was sent automatically by this website.', 'wphave'),
		]);
		try {
			$accepted = wp_mail($booking['attendee_email'], $subject, $html, wphave_email_template_headers());
			$repository->finish_reminder($booking_id, $start, (bool) $accepted);
		} catch (Throwable $error) {
			$repository->finish_reminder($booking_id, $start, false);
		}
	}
}
