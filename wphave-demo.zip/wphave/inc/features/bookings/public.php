<?php

/** Server-rendered public appointment selection and submission. */

final class WPHAVE_Booking_Public {
	/**
	 * Render one block's explicitly allowed services and provider choices.
	 * Each option retains its own server-rendered form and canonical slot fallback.
	 *
	 * @param array<int, int|float|string> $service_ids IDs from block or REST attributes.
	 * @return string
	 */
	public static function render_selection(array $service_ids): string {
		$result = self::confirmation_result();
		if (null !== $result) {
			return $result;
		}

		$review = self::review();
		if (null !== $review) {
			return $review;
		}
		$services = [];
		$ids = self::normalize_service_ids($service_ids);
		foreach (array_slice(array_unique($ids), 0, 8) as $id) {
			$policy = WPHAVE_Booking_Services::get($id);
			if ($policy) {
				$services[$id] = $policy;
			}
		}
		if (!$services) {
			return self::receipt_notice() . '<p>' . esc_html__('The selected service is currently unavailable.', 'wphave') . '</p>';
		}

		$html = self::receipt_notice() . '<div class="wphave-booking-choices">';
		if (count($services) > 1) {
			$html .= '<p><label>' . esc_html__('Service', 'wphave') . ' <select class="wphave-booking-choices__service">';
			foreach ($services as $id => $policy) {
				$html .= '<option value="' . esc_attr((string) $id) . '">' . esc_html(get_the_title($id)) . '</option>';
			}
			$html .= '</select></label></p>';
		}
		foreach ($services as $id => $policy) {
			$provider_ids = $policy['provider_ids'] ?: [0];
			if (0 !== $provider_ids[0]) {
				$html .= '<fieldset class="wphave-booking-choices__providers" data-service="' .
					esc_attr((string) $id) . '"><legend>' . esc_html__('Provider', 'wphave') . '</legend>';
				foreach ($provider_ids as $index => $provider_id) {
					$user = get_userdata($provider_id);
					if (!$user) {
						continue;
					}
					$html .= '<label class="wphave-booking-choices__provider">';
					$html .= '<input type="radio" name="wphave-provider-' . esc_attr((string) $id) .
						'" value="' . esc_attr((string) $provider_id) . '"' .
						(0 === $index ? ' checked' : '') . '>';
					$html .= get_avatar($provider_id, 40, '', '', ['class' => 'wphave-booking-choices__avatar']);
					$html .= '<span>' . esc_html($user->display_name) . '</span></label>';
				}
				$html .= '</fieldset>';
			}
			foreach ($provider_ids as $provider_id) {
				$html .= '<div class="wphave-booking-choices__option" data-service="' .
					esc_attr((string) $id) . '" data-provider="' .
					esc_attr((string) $provider_id) . '">';
				$provider = $provider_id ? get_userdata($provider_id) : false;
				$label = get_the_title($id) . ($provider ? ' — ' . $provider->display_name : '');
				$html .= '<h3 class="wphave-booking-choices__fallback-label">' . esc_html($label) . '</h3>';
				$html .= self::render(['id' => $id, 'provider_id' => $provider_id, 'skip_receipt' => true]);
				$html .= '</div>';
			}
		}
		return $html . '</div>';
	}

	/**
	 * Normalize block IDs across frontend parsing and REST block rendering.
	 * WordPress coerces a block attribute declared as "number" to float in the
	 * block-renderer REST controller, even when the original ID was an integer.
	 *
	 * @param array<int, mixed> $values Untrusted service ID candidates.
	 * @return array<int, int> Unique positive post IDs, bounded to eight.
	 */
	private static function normalize_service_ids(array $values): array {
		$ids = [];
		foreach (array_slice($values, 0, 8) as $value) {
			$valid = (is_int($value) && $value > 0) ||
				(is_string($value) && preg_match('/^[1-9][0-9]*$/D', $value)) ||
				(is_float($value) && is_finite($value) && $value > 0 &&
					$value <= 9007199254740991 && floor($value) === $value);

			if ($valid && (float) $value <= 9007199254740991) {
				$ids[] = (int) $value;
			}
		}

		return array_values(array_unique($ids));
	}

	/**
	 * Load booking assets only when the queried page contains a booking entry point.
	 * @return void
	 */

	public static function enqueue_assets(): void {
		$post = get_queried_object();

		if (
			!$post instanceof WP_Post ||
			(!has_shortcode($post->post_content, 'wphave_booking') && !has_block('wphave/appointment-booking', $post))
		) {
			return;
		}

		self::enqueue_form_assets();
	}

	/**
	 * Enqueue the shared public calendar and global-form styling assets.
	 * @return void
	 */

	private static function enqueue_form_assets(): void {
		$style_path = 'inc/features/bookings/public.css';
		$script_path = 'inc/features/bookings/public.js';
		wp_enqueue_style(
			'wphave-booking',
			wphave_asset_url($style_path),
			[],
			WPHAVE_Asset_Registry::version($style_path),
		);
		wp_enqueue_script(
			'wphave-booking',
			wphave_asset_url($script_path),
			[],
			WPHAVE_Asset_Registry::version($script_path),
			true,
		);
	}

	/**
	 * Render a booking form or a token review inside the current page.
	 *
	 * @param array $attributes Shortcode or block attributes selecting an appointment type.
	 * @return string
	 */

	public static function render(array $attributes = []): string {
		if (empty($attributes['skip_receipt'])) {
			$result = self::confirmation_result();
			if (null !== $result) {
				return $result;
			}
		}

		$review = empty($attributes['skip_receipt']) ? self::review() : null;

		if (null !== $review) {
			return $review;
		}

		$id = absint($attributes['id'] ?? 0);
		$service = WPHAVE_Booking_Services::get($id);

		if (!$service) {
			return self::receipt_notice();
		}
		if (!array_key_exists('provider_id', $attributes) && count($service['provider_ids'] ?? []) > 1) {
			return self::render_selection([$id]);
		}
		$provider_id = array_key_exists('provider_id', $attributes)
			? absint($attributes['provider_id'])
			: (int) ($service['provider_ids'][0] ?? 0);
		if (($service['provider_ids'] ?? []) ? !in_array($provider_id, $service['provider_ids'], true) : 0 !== $provider_id) {
			return '';
		}

		self::enqueue_form_assets();
		$repository = new WPHAVE_Booking_Repository();

		try {
			$now = new DateTimeImmutable('now', new DateTimeZone('UTC'));
			$busy = $repository->busy(
				$id,
				$now->format('Y-m-d H:i:s'),
				$now->modify('+' . $service['horizon_days'] . ' days')->format('Y-m-d H:i:s'),
				0,
				$provider_id,
			);
			$slots = WPHAVE_Booking_Busy_Source::slots($service, $busy, $now, $provider_id);
		} catch (Throwable $error) {
			return '<p>' . esc_html__('Appointments are temporarily unavailable.', 'wphave') . '</p>';
		}

		if (!$slots) {
			return (empty($attributes['skip_receipt']) ? self::receipt_notice() : '') .
				'<p>' . esc_html__('No appointments are currently available.', 'wphave') . '</p>';
		}

		$timezone = new DateTimeZone($service['timezone']);
		$action = esc_url(admin_url('admin-post.php'));
		$request_id = wp_generate_uuid4();
		$opened_at = time();
		$nonce = wp_create_nonce('wphave_book_' . $id);
		$html = '<form class="wphave-booking wphave-booking--reservation" method="post" action="' . $action . '">';
		$html .= '<div class="wphave-booking__layout">';
		$html .= '<div class="wphave-booking__details">';
		if ('' !== $service['meeting_details']) {
			$html .= '<p class="wphave-booking__meeting">' . nl2br(esc_html($service['meeting_details'])) . '</p>';
		}
		$html .= '<input type="hidden" name="action" value="wphave_book">';
		$html .= '<input type="hidden" name="service_id" value="' . esc_attr((string) $id) . '">';
		$html .= '<input type="hidden" name="provider_id" value="' . esc_attr((string) $provider_id) . '">';
		$html .= '<input type="hidden" name="request_id" value="' . esc_attr($request_id) . '">';
		$html .= '<input type="hidden" name="opened_at" value="' . esc_attr((string) $opened_at) . '">';
		$html .= '<input type="hidden" name="booking_nonce" value="' . esc_attr($nonce) . '">';
		$html .= '<input type="hidden" name="return_url" value="' . esc_url(get_permalink()) . '">';
		$html .= '<p class="wphave-booking-trap" aria-hidden="true">';
		$html .= '<label>' . esc_html__('Leave this field empty', 'wphave');
		$html .= '<input type="text" name="company_website" tabindex="-1" autocomplete="off"></label></p>';
		$html .= '<p><label>' . esc_html__('Name', 'wphave');
		$html .= ' <input type="text" name="attendee_name" maxlength="190" required autocomplete="name"></label></p>';
		$html .= '<p><label>' . esc_html__('Email', 'wphave');
		$html .= ' <input type="email" name="attendee_email" maxlength="190" required autocomplete="email"></label></p>';
		foreach ($service['intake_fields'] as $field) {
			$common = ' name="intake[' . esc_attr($field['key']) . ']" maxlength="' .
				('textarea' === $field['type'] ? '2000' : '500') . '"' .
				($field['required'] ? ' required' : '');
			$html .= '<p><label>' . esc_html($field['label']);
			if ('textarea' === $field['type']) {
				$html .= ' <textarea' . $common . ' rows="4"></textarea>';
			} else {
				$html .= ' <input type="text"' . $common . '>';
			}
			$html .= '</label></p>';
		}
		$html .= '<button type="submit">' . esc_html__('Book appointment', 'wphave') . '</button>';
		$html .= '</div><div class="wphave-booking__schedule">';
		$html .= self::calendar_controls();
		$html .= '<div class="wphave-booking__time">';
		$html .= self::time_controls($slots, $timezone);
		$html .= '<p class="wphave-booking__timezone">' . esc_html(sprintf(
			/* translators: %s: IANA timezone */
			__('Times shown in %s.', 'wphave'),
			$service['timezone'],
		)) . '</p>';
		$html .= '</div></div></div></form>';
		return (empty($attributes['skip_receipt']) ? self::receipt_notice() : '') . $html;
	}

	/**
	 * Render a generic POST/Redirect/GET outcome without attendee details.
	 * @return string
	 */

	private static function receipt_notice(): string {
		$receipt = isset($_GET['wphave_booking']) ? sanitize_key(wp_unslash($_GET['wphave_booking'])) : '';

		$messages = [
			'pending' => __('Check your email and confirm this appointment within one hour.', 'wphave'),
			'confirmed' => __('Your appointment is booked. Please keep the time you selected.', 'wphave'),
			'cancelled' => __('Your appointment was cancelled.', 'wphave'),
			'unavailable' => __('This appointment could not be booked. Please choose another time.', 'wphave'),
		];

		if (!isset($messages[$receipt])) {
			return '';
		}

		$error = 'unavailable' === $receipt;

		return '<p class="wphave-booking-notice ' . ($error ? 'is-error' : 'is-success') . '" role="' .
			($error ? 'alert' : 'status') . '">' . esc_html($messages[$receipt]) . '</p>';
	}

	/** Render final appointment states through the same customizable system template. */
	private static function confirmation_result(): ?string {
		$receipt = isset($_GET['wphave_booking'])
			? sanitize_key(wp_unslash($_GET['wphave_booking']))
			: '';

		if (!in_array($receipt, ['confirmed', 'cancelled'], true)) {
			return null;
		}

		self::enqueue_form_assets();
		return '<div class="wphave-booking-confirmation" role="status">' .
			WPHAVE_Booking_Confirmation_Template::render($receipt) .
			'</div>';
	}


	/**
	 * Render the shared progressive calendar and grouped time fallback.
	 *
	 * @param array $slots Value supplied by the caller.
	 * @param DateTimeZone $timezone Appointment type timezone.
	 * @return string
	 */

	private static function slot_controls(array $slots, DateTimeZone $timezone): string {
		return self::calendar_controls() . self::time_controls($slots, $timezone);
	}

	/**
	 * Render the optional calendar enhancement without changing the native slot select fallback.
	 * @return string
	 */
	private static function calendar_controls(): string {
		$html = '<div class="wphave-booking__calendar" hidden aria-label="' . esc_attr__('Available appointment dates', 'wphave') . '"';
		$html .= ' data-previous-label="' . esc_attr__('Previous month', 'wphave') . '"';
		$html .= ' data-next-label="' . esc_attr__('Next month', 'wphave') . '"></div>';
		$html .= '<p class="wphave-booking__date-field" hidden><label>' . esc_html__('Date', 'wphave');
		$html .= ' <select class="wphave-booking__date" aria-label="' . esc_attr__('Date', 'wphave') . '"></select></label></p>';
		return $html;
	}

	/**
	 * Render the canonical slot select used with and without JavaScript.
	 * @param array $slots Available UTC intervals.
	 * @param DateTimeZone $timezone Appointment type timezone.
	 * @return string
	 */
	private static function time_controls(array $slots, DateTimeZone $timezone): string {
		$html = '<p><label>' . esc_html__('Time', 'wphave') . ' <select name="starts_at" required>';

		$current_date = null;
		foreach (array_slice($slots, 0, 1000) as $slot) {
			$local = (new DateTimeImmutable($slot['start']))->setTimezone($timezone);
			$date = $local->format('Y-m-d');

			if ($date !== $current_date) {
				if (null !== $current_date) {
					$html .= '</optgroup>';
				}

				$html .= '<optgroup label="' . esc_attr($local->format('d.m.Y')) . '">';
				$current_date = $date;
			}

			$html .= '<option value="' . esc_attr($slot['start']) . '" data-date="' . esc_attr($date) . '" data-time="' . esc_attr($local->format('H:i T')) . '">';
			$html .= esc_html($local->format('d.m.Y H:i T')) . '</option>';
		}

		if (null !== $current_date) {
			$html .= '</optgroup>';
		}

		return $html . '</select></label></p>';
	}

	/**
	 * Validate and hold a public request, then send its confirmation link.
	 * @return void
	 */

	public static function submit(): void {
		if ((int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > 16384) {
			self::redirect('unavailable');
		}

		$id = absint($_POST['service_id'] ?? 0);
		$raw_provider = self::post_string('provider_id');
		if (isset($_POST['provider_id']) && !preg_match('/^(?:0|[1-9][0-9]*)$/D', $raw_provider)) {
			self::redirect('unavailable');
		}
		$provider_id = '' === $raw_provider ? 0 : (int) $raw_provider;
		$nonce = sanitize_text_field(self::post_string('booking_nonce'));
		$service = WPHAVE_Booking_Services::get($id);

		if (!$service || !wp_verify_nonce($nonce, 'wphave_book_' . $id)) {
			self::redirect('unavailable');
		}

		$client_key = WPHAVE_Rate_Limiter::client_key('booking-submit');

		if (WPHAVE_Rate_Limiter::increment($client_key, MINUTE_IN_SECONDS) > 10) {
			self::redirect('unavailable');
		}

		$opened_at = absint($_POST['opened_at'] ?? 0);

		if (
			isset($_POST['company_website']) &&
			(!is_string($_POST['company_website']) || strlen($_POST['company_website']) > 1024)
		) {
			self::redirect('pending');
		}

		if (
			$opened_at < time() - DAY_IN_SECONDS ||
			$opened_at > time()
		) {
			self::redirect('unavailable');
		}

		$start = sanitize_text_field(self::post_string('starts_at'));
		$name = sanitize_text_field(self::post_string('attendee_name'));
		$email = trim(self::post_string('attendee_email'));
		$request_id = sanitize_text_field(self::post_string('request_id'));

		if (
			!preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/D', $start) ||
			'' === $name || strlen($name) > 190 ||
			!is_email($email) || sanitize_email($email) !== $email || strlen($email) > 190 ||
			!wp_is_uuid($request_id)
		) {
			self::redirect('unavailable');
		}

		$submitted = [
			'attendee_name' => $name,
			'attendee_email' => $email,
			'starts_at' => $start,
		];
		$intake = isset($_POST['intake']) ? wp_unslash($_POST['intake']) : [];
		if (!is_array($intake)) {
			self::redirect('unavailable');
		}
		try {
			$answers = json_decode(WPHAVE_Booking_Intake::capture($service, $intake), true);
		} catch (RuntimeException $error) {
			self::redirect('unavailable');
		}
		foreach ($answers as $answer) {
			$submitted['intake_' . $answer['key']] = $answer['value'];
		}

		$spam_params = array_merge($submitted, [
			'_wphave_hp_name' => 'company_website',
			'company_website' => sanitize_text_field(self::post_string('company_website')),
			'_wphave_form_time' => $opened_at,
		]);

		if (WPHAVE_Form_Spam_Policy::is_spam(
			array_fill_keys(array_keys($submitted), true),
			$submitted,
			$spam_params,
			(string) ($_SERVER['HTTP_USER_AGENT'] ?? ''),
		)) {
			self::redirect('pending');
		}

		try {
			$repository = new WPHAVE_Booking_Repository();
			$token = bin2hex(random_bytes(32));
			$created = false;
			$booking_id = $repository->reserve(
				$id,
				(new DateTimeImmutable($start))->format('Y-m-d H:i:s'),
				$name,
				$email,
				$request_id,
				'pending_confirmation',
				hash('sha256', $token),
				gmdate('Y-m-d H:i:s', time() + HOUR_IN_SECONDS),
				'public',
				'requested_by_attendee',
				true,
				self::return_url(),
				$created,
				$intake,
				$provider_id,
			);

			// A replay retains the original reservation and its original token.
			// Sending this request's fresh token would strand the attendee.
			if (!$created) {
				self::redirect('pending');
			}

			if (!WPHAVE_Booking_Notifications::latest($booking_id, $token, self::return_url())) {
				$repository->cancel($booking_id);
				self::redirect('unavailable');
			}

			self::redirect('pending');
		} catch (Throwable $error) {
			self::redirect('unavailable');
		}
	}

	/**
	 * Render a GET-only confirmation, proposal, or management review.
	 * @return string|null
	 */

	private static function review(): ?string {
		$action = isset($_GET['wphave_booking_action']) ? sanitize_key(wp_unslash($_GET['wphave_booking_action'])) : '';
		$token = isset($_GET['token']) ? sanitize_text_field(wp_unslash($_GET['token'])) : '';

		if (!in_array($action, ['confirm', 'proposal', 'manage'], true) || !preg_match('/^[a-f0-9]{64}$/D', $token)) {
			return null;
		}

		if ('manage' === $action) {
			return self::manage_review($token);
		}

		$label = 'confirm' === $action ? __('Confirm appointment', 'wphave') : __('Accept new appointment time', 'wphave');
		$content = WPHAVE_Booking_Confirmation_Template::render($action);
		$html = '<form class="wphave-booking" method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
		$html .= '<input type="hidden" name="action" value="wphave_booking_review">';
		$html .= '<input type="hidden" name="review_action" value="' . esc_attr($action) . '">';
		$html .= '<input type="hidden" name="token" value="' . esc_attr($token) . '">';
		$html .= '<input type="hidden" name="return_url" value="' . esc_url(get_permalink()) . '">';
		$html .= '<button type="submit">' . esc_html($label) . '</button></form>';

		return '<div class="wphave-booking-confirmation">' . $content . $html . '</div>';
	}

	/**
	 * Render attendee time-change and cancellation controls for a valid bearer link.
	 *
	 * @param string $token Value supplied by the caller.
	 * @return string
	 */

	private static function manage_review(string $token): string {
		$repository = new WPHAVE_Booking_Repository();
		$booking = $repository->by_manage_token(hash('sha256', $token));

		if (!$booking) {
			return '<p class="wphave-booking-notice is-error">' . esc_html__('This appointment link is no longer valid.', 'wphave') . '</p>';
		}

		$service = WPHAVE_Booking_Services::get((int) $booking['service_id']);
		self::enqueue_form_assets();
		// Existing attendee cancellation survives an unpublished or removed type.
		// Only offering a new slot requires a currently published policy.
		$timezone = $service ? new DateTimeZone($service['timezone']) : wp_timezone();
		$current = (new DateTimeImmutable($booking['starts_at'] . ' UTC'))->setTimezone($timezone);
		$title = get_the_title((int) $booking['service_id']);
		$html = '<div class="wphave-booking"><h3 class="wphave-booking__title">' . esc_html($title ?: __('Appointment', 'wphave')) . '</h3>';
		$html .= '<p>' . esc_html(sprintf(__('Current appointment: %s', 'wphave'), $current->format('d.m.Y H:i T'))) . '</p></div>';

		$slots = [];
		if ($service) {
			try {
				$now = new DateTimeImmutable('now', new DateTimeZone('UTC'));
				$busy = $repository->busy(
					(int) $booking['service_id'],
					$now->format('Y-m-d H:i:s'),
					$now->modify('+' . $service['horizon_days'] . ' days')->format('Y-m-d H:i:s'),
					(int) $booking['id'],
					(int) $booking['provider_id'],
				);
				$slots = WPHAVE_Booking_Busy_Source::slots($service, $busy, $now, (int) $booking['provider_id']);
				$slots = array_values(array_filter($slots, static fn(array $slot): bool =>
					(new DateTimeImmutable($slot['start']))->format('Y-m-d H:i:s') !== $booking['starts_at']));
			} catch (Throwable $error) {
				$slots = [];
			}
		}

		if ($slots) {
			$html .= '<form class="wphave-booking" method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
			$html .= '<h4>' . esc_html__('Choose a new time', 'wphave') . '</h4>';
			$html .= '<input type="hidden" name="action" value="wphave_booking_review">';
			$html .= '<input type="hidden" name="review_action" value="manage">';
			$html .= '<input type="hidden" name="operation" value="move">';
			$html .= '<input type="hidden" name="token" value="' . esc_attr($token) . '">';
			$html .= '<input type="hidden" name="return_url" value="' . esc_url(get_permalink()) . '">';
			$html .= self::slot_controls($slots, $timezone);
			$html .= '<button type="submit">' . esc_html__('Move appointment', 'wphave') . '</button></form>';
		}

		$html .= '<form class="wphave-booking" method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
		$html .= '<input type="hidden" name="action" value="wphave_booking_review">';
		$html .= '<input type="hidden" name="review_action" value="manage">';
		$html .= '<input type="hidden" name="operation" value="cancel">';
		$html .= '<input type="hidden" name="token" value="' . esc_attr($token) . '">';
		$html .= '<input type="hidden" name="return_url" value="' . esc_url(get_permalink()) . '">';
		$html .= '<p><label><input type="checkbox" name="confirm_cancel" value="1" required> ' . esc_html__('I want to cancel this appointment.', 'wphave') . '</label></p>';
		$html .= '<button type="submit">' . esc_html__('Cancel appointment', 'wphave') . '</button></form>';

		return $html;
	}

	/**
	 * Render a review through the theme when no booking block owns the page.
	 * @return void
	 */

	public static function review_page(): void {
		if (!isset($_GET['wphave_booking_action']) && !isset($_GET['wphave_booking'])) {
			return;
		}

		$review = self::confirmation_result() ?? self::review();

		if (null === $review) {
			return;
		}

		nocache_headers();
		header('Referrer-Policy: no-referrer');
		$post = get_queried_object();

		if ($post instanceof WP_Post &&
			(has_shortcode($post->post_content, 'wphave_booking') || has_block('wphave/appointment-booking', $post))) {
			return;
		}

		self::enqueue_form_assets();
		status_header(200);
		get_header();

		echo '<main class="wphave-booking-review">';
		echo $review; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Review markup escapes dynamic values at construction.
		echo '</main>';

		get_footer();

		exit();
	}

	/**
	 * Apply a token-authorized state change only after a POST.
	 * @return void
	 */

	public static function submit_review(): void {
		$client_key = WPHAVE_Rate_Limiter::client_key('booking-review');

		if (WPHAVE_Rate_Limiter::increment($client_key, MINUTE_IN_SECONDS) > 20) {
			self::redirect('unavailable');
		}

		$action = sanitize_key(self::post_string('review_action'));
		$token = self::post_string('token');

		if (!in_array($action, ['confirm', 'proposal', 'manage'], true) || !preg_match('/^[a-f0-9]{64}$/D', $token)) {
			self::redirect('unavailable');
		}

		try {
			$repository = new WPHAVE_Booking_Repository();

			if ('manage' === $action) {
				$booking = $repository->by_manage_token(hash('sha256', $token));
				$operation = sanitize_key(self::post_string('operation'));

				if (!$booking) {
					throw new RuntimeException('Invalid appointment link.');
				}

				if ('cancel' === $operation && isset($_POST['confirm_cancel']) && $repository->cancel((int) $booking['id'], hash('sha256', $token))) {
					WPHAVE_Booking_Notifications::latest((int) $booking['id']);
					self::redirect('cancelled');
				}

				if ('move' === $operation) {
					$start = self::post_string('starts_at');
					if (preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/D', $start) &&
						$repository->reschedule((int) $booking['id'], (new DateTimeImmutable($start))->format('Y-m-d H:i:s'), (int) $booking['revision'], hash('sha256', $token))) {
						WPHAVE_Booking_Notifications::latest((int) $booking['id']);
						self::redirect('confirmed');
					}
				}

				throw new RuntimeException('Appointment change failed.');
			}

			$id = 'confirm' === $action
				? $repository->confirm(hash('sha256', $token))
				: $repository->accept_proposal(hash('sha256', $token));

			WPHAVE_Booking_Notifications::latest($id);
			self::redirect('confirmed');
		} catch (Throwable $error) {
			self::redirect('unavailable');
		}
	}

	/**
	 * Validate the local page URL used for review links and redirects.
	 * @return string
	 */

	private static function return_url(): string {
		return self::safe_return_url(self::post_string('return_url'));
	}

	/**
	 * Keep bearer links on the exact site origin, including scheme and port.
	 * WordPress's redirect check permits a same-host HTTP downgrade on HTTPS
	 * sites, so it cannot be the only validation for emailed token links.
	 *
	 * @param string $candidate Untrusted URL from a form or stored booking.
	 * @return string Safe site URL.
	 */

	public static function safe_return_url(string $candidate): string {
		$fallback = home_url('/');
		$url = esc_url_raw($candidate);
		$origin = wp_parse_url($fallback);
		$target = wp_parse_url($url);

		if (
			!is_array($origin) || !is_array($target) ||
			!isset($target['scheme'], $target['host']) ||
			strtolower($target['scheme']) !== strtolower($origin['scheme'] ?? '') ||
			strtolower($target['host']) !== strtolower($origin['host'] ?? '') ||
			($target['port'] ?? null) !== ($origin['port'] ?? null) ||
			isset($target['user']) || isset($target['pass']) || isset($target['fragment'])
		) {
			return $fallback;
		}

		return wp_validate_redirect($url, $fallback);
	}

	/**
	 * Finish a public POST with a safe local receipt redirect.
	 *
	 * @param string $result Public receipt code.
	 * @return void
	 */

	private static function redirect(string $result): void {
		$url = remove_query_arg(['wphave_booking', 'wphave_booking_action', 'token'], self::return_url());
		wp_safe_redirect(add_query_arg('wphave_booking', $result, $url), 303);
		exit();
	}

	/**
	 * Read one bounded unslashed scalar from the public POST body.
	 *
	 * @param string $key POST field name.
	 * @return string
	 */

	private static function post_string(string $key): string {
		$value = $_POST[$key] ?? '';

		if (!is_string($value) || strlen($value) > 1024) {
			return '';
		}

		return wp_unslash($value);
	}
}
