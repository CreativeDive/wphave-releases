<?php

/** Resolve one provider's effective appointment hours without mutating the service policy. */
final class WPHAVE_Booking_Provider_Policy {
	/**
	 * Apply bounded, already validated provider overrides to a service policy.
	 * An absent weekly override inherits service hours; an empty override closes
	 * that provider. Shared closed dates are retained by the slot calculator.
	 *
	 * @param array<string, mixed> $service Validated appointment policy.
	 * @param int $provider_id WordPress user ID, or zero for an unassigned service.
	 * @return array<string, mixed> Effective policy for this calculation only.
	 */
	public static function for_provider(array $service, int $provider_id): array {
		if ($provider_id <= 0) {
			return $service;
		}

		if (array_key_exists($provider_id, $service['provider_weekly_windows'] ?? [])) {
			$service['weekly_windows'] = $service['provider_weekly_windows'][$provider_id];
		}

		if (!empty($service['provider_date_windows'][$provider_id])) {
			// Personal date windows replace the shared exception for the same day.
			$service['date_windows'] = array_replace(
				$service['date_windows'] ?? [],
				$service['provider_date_windows'][$provider_id],
			);
		}

		return $service;
	}
}
