<?php

require_once wphave_dir() . 'inc/features/forms/submission/mail-template.php';

/** Transactional appointment mail, claimed once per durable booking event. */

final class WPHAVE_Booking_Notifications {

	/**
	 * Claim and send the newest booking event notification at most once.
	 * A true result means WordPress accepted the message or an earlier claim was
	 * accepted; it cannot prove delivery to the recipient's mailbox.
	 *
	 * @param int $booking_id Booking ID.
	 * @param string $token Plain bearer token for confirmation or proposal links.
	 * @param string $return_url Validated local review page URL.
	 * @return bool Whether WordPress accepted this event's message.
	 */

	public static function latest(int $booking_id, string $token = '', string $return_url = ''): bool {
		$attendee_accepted = self::attendee_latest($booking_id, $token, $return_url);
		self::host_latest($booking_id);
		WPHAVE_Booking_Reminders::schedule($booking_id);
		return $attendee_accepted;
	}

	/**
	 * Send the attendee's newest revisioned event without reusing its claim for
	 * the independent host notice.
	 *
	 * @param int $booking_id Booking ID.
	 * @param string $token Plain bearer token when required.
	 * @param string $return_url Local review page URL.
	 * @return bool Whether WordPress accepted attendee mail.
	 */
	private static function attendee_latest(int $booking_id, string $token, string $return_url): bool {
		$events = new WPHAVE_Booking_Events();
		$history = $events->latest($booking_id);

		if (!$history || 'pending' !== $history[0]['mail_status']) {
			return !empty($history) && 'accepted' === $history[0]['mail_status'];
		}

		$event = $events->claim((int) $history[0]['id']);

		if (!$event) {
			return false;
		}

		$booking = (new WPHAVE_Booking_Repository())->get($booking_id);

		// A superseded event must not send stale details or rotate the current
		// attendee link. Erasure clears the snapshot, so it fails closed here.
		if (!$booking || (int) $booking['revision'] !== (int) $event['revision'] ||
			!is_email($event['email_snapshot'])) {
			$events->finish((int) $event['id'], false);
			return false;
		}

		// A caller-supplied token may be mailed only when its digest matches the
		// live hold. This also prevents an idempotent retry from mailing a new,
		// unusable token for an existing reservation.
		if ((
			'confirmation_requested' === $event['kind'] &&
			('pending_confirmation' !== $booking['status'] ||
				$booking['confirm_expires_at'] <= gmdate('Y-m-d H:i:s') ||
				!hash_equals($booking['confirm_token_hash'], hash('sha256', $token)))
		) || (
			'proposal_sent' === $event['kind'] &&
			('confirmed' !== $booking['status'] ||
				$booking['proposal_expires_at'] <= gmdate('Y-m-d H:i:s') ||
				!hash_equals($booking['proposal_token_hash'], hash('sha256', $token)))
		)) {
			$events->finish((int) $event['id'], false);
			return false;
		}

		$title = get_the_title((int) $booking['service_id']);
		$service = WPHAVE_Booking_Services::get((int) $booking['service_id']);
		$timezone = new DateTimeZone($service['timezone'] ?? 'UTC');

		$format = static function (?string $date) use ($timezone): string {
			return $date ? (new DateTimeImmutable($date . ' UTC'))->setTimezone($timezone)->format('d.m.Y H:i T') : '';
		};

		$old = $format($event['old_start']);
		$new = $format($event['new_start']);
		$base_url = WPHAVE_Booking_Public::safe_return_url($booking['return_url'] ?: $return_url);
		$subject = __('Appointment update', 'wphave');
		$message = '';

		switch ($event['kind']) {
			case 'confirmation_requested':
				$subject = __('Confirm your appointment request', 'wphave');
				$link = add_query_arg(['wphave_booking_action' => 'confirm', 'token' => $token], $base_url);
				$message = sprintf(__('Please confirm your request for %1$s on %2$s within one hour:', 'wphave'), $title, $new) . "\n" . $link;
				break;
			case 'created':
			case 'confirmed':
			case 'proposal_accepted':
				$subject = __('Appointment confirmed', 'wphave');
				$message = sprintf(__('Your appointment for %1$s is confirmed on %2$s.', 'wphave'), $title, $new);
				break;
			case 'rescheduled':
				$subject = __('Appointment time changed', 'wphave');
				$message = sprintf(__('Your appointment for %1$s moved from %2$s to %3$s.', 'wphave'), $title, $old, $new);
				break;
			case 'proposal_sent':
				$subject = __('Proposed appointment time', 'wphave');
				$link = add_query_arg(['wphave_booking_action' => 'proposal', 'token' => $token], $base_url);
				$message = sprintf(
					__('A new time for %1$s was proposed: %2$s instead of %3$s. Accept within seven days:', 'wphave'),
					$title,
					$new,
					$old,
				) . "\n" . $link;
				break;
			case 'cancelled':
				$subject = __('Appointment cancelled', 'wphave');
				$message = sprintf(__('Your appointment for %1$s on %2$s was cancelled.', 'wphave'), $title, $old);
				break;
		}

		if ('' === $message || (in_array($event['kind'], ['confirmation_requested', 'proposal_sent'], true) && '' === $token)) {
			$events->finish((int) $event['id'], false);
			return false;
		}
		if ((int) ($booking['provider_id'] ?? 0) > 0) {
			$provider = get_userdata((int) $booking['provider_id']);
			if ($provider) {
				$message .= "\n" . sprintf(__('Provider: %s', 'wphave'), $provider->display_name);
			}
		}

		if (in_array($event['kind'], ['created', 'confirmed', 'rescheduled', 'proposal_accepted'], true) &&
			'' !== ($service['meeting_details'] ?? '')) {
			$message .= "\n\n" . __('Meeting details:', 'wphave') . "\n" . $service['meeting_details'];
		}
		if ('' !== ($service['attendee_email_note'] ?? '')) {
			$message .= "\n\n" . $service['attendee_email_note'];
		}

		$repository = new WPHAVE_Booking_Repository();
		$previous_manage_hash = (string) $booking['manage_token_hash'];
		$issued_manage_hash = '';
		$mail_attempted = false;
		$invite_path = null;

		try {
			if (in_array($event['kind'], ['created', 'confirmed', 'rescheduled', 'proposal_accepted'], true)) {
				$manage_token = $repository->issue_manage_token($booking_id, (int) $event['revision']);
				$issued_manage_hash = hash('sha256', $manage_token);
				$manage_url = add_query_arg(['wphave_booking_action' => 'manage', 'token' => $manage_token], $base_url);
				$message .= "\n\n" . __('Manage or cancel your appointment:', 'wphave') . "\n" . $manage_url;
			}
			// All booking transitions share the site-wide branded HTML template.
			// Escape the plain event copy and each bearer URL before insertion.
			$html_message = wphave_build_email_template([
				'title' => $subject,
				'content' => self::html_content($message),
				'footer_content' => esc_html__('This appointment message was sent automatically by this website.', 'wphave'),
			]);
			$invite_path = WPHAVE_Booking_Calendar_Invite::attachment($booking, $event);
			$mail_attempted = true;
			$accepted = wp_mail(
				$event['email_snapshot'],
				$subject,
				$html_message,
				wphave_email_template_headers(),
				$invite_path ? [$invite_path] : [],
			);
			if (!$accepted && '' !== $issued_manage_hash) {
				$repository->restore_manage_token($booking_id, $issued_manage_hash, $previous_manage_hash,
					(int) $event['revision']);
			}
			$events->finish((int) $event['id'], (bool) $accepted);
			return (bool) $accepted;
		} catch (Throwable $error) {
			// A throwing transport has an ambiguous outcome. Preserve the issued
			// token if it may already have been delivered; never retry this event.
			if ('' !== $issued_manage_hash && !$mail_attempted) {
				$repository->restore_manage_token($booking_id, $issued_manage_hash, $previous_manage_hash,
					(int) $event['revision']);
			}
			$events->finish((int) $event['id'], false);
			return false;
		} finally {
			if ($invite_path && is_file($invite_path)) {
				unlink($invite_path);
			}
		}
	}

	/**
	 * Tell the site operator about a current confirmed or cancelled transition.
	 * The event owns a separate at-most-once claim so an attendee mail failure
	 * cannot suppress or duplicate the operational notice.
	 *
	 * @param int $booking_id Booking ID.
	 * @return bool Whether the host transport accepted this event.
	 */
	public static function host_latest(int $booking_id): bool {
		$events = new WPHAVE_Booking_Events();
		$history = $events->latest($booking_id);
		if (!$history || 'pending' !== $history[0]['host_mail_status']) {
			return !empty($history) && 'accepted' === $history[0]['host_mail_status'];
		}

		$event = $events->claim_host((int) $history[0]['id']);
		if (!$event) {
			return false;
		}

		$booking = (new WPHAVE_Booking_Repository())->get($booking_id);
		$email = WPHAVE_Booking_Settings::recipient();
		if (!$booking || (int) $booking['revision'] !== (int) $event['revision'] ||
			!is_email($email) || '' === $booking['attendee_email']) {
			$events->finish_host((int) $event['id'], false);
			return false;
		}

		$service = WPHAVE_Booking_Services::get((int) $booking['service_id']);
		$timezone = new DateTimeZone($service['timezone'] ?? 'UTC');
		$start = 'cancelled' === $event['kind'] ? $event['old_start'] : $event['new_start'];
		$when = $start
			? (new DateTimeImmutable($start . ' UTC'))->setTimezone($timezone)->format('d.m.Y H:i T')
			: '';
		$subject = __('Appointment update for your website', 'wphave');
		$kind_labels = [
			'created' => __('created', 'wphave'),
			'confirmed' => __('confirmed', 'wphave'),
			'rescheduled' => __('rescheduled', 'wphave'),
			'proposal_accepted' => __('rescheduled', 'wphave'),
			'cancelled' => __('cancelled', 'wphave'),
		];
		$copy = sprintf(
			/* translators: 1: appointment type, 2: attendee name, 3: local time, 4: transition */
			__('Appointment %4$s: %1$s, %2$s, %3$s.', 'wphave'),
			get_the_title((int) $booking['service_id']),
			$booking['attendee_name'],
			$when,
			$kind_labels[$event['kind']] ?? $event['kind'],
		);
		if ((int) ($booking['provider_id'] ?? 0) > 0) {
			$provider = get_userdata((int) $booking['provider_id']);
			if ($provider) {
				$copy .= "\n" . sprintf(__('Provider: %s', 'wphave'), $provider->display_name);
			}
		}
		$answers = json_decode((string) ($booking['intake_json'] ?? '[]'), true);
		if (is_array($answers)) {
			foreach ($answers as $answer) {
				if (is_array($answer) && is_string($answer['label'] ?? null) && is_string($answer['value'] ?? null) &&
					'' !== $answer['value']) {
					$copy .= "\n" . $answer['label'] . ': ' . $answer['value'];
				}
			}
		}
		$html = wphave_build_email_template([
			'title' => $subject,
			'content' => self::html_content($copy),
			'footer_content' => esc_html__('Manage this appointment in your workspace.', 'wphave'),
		]);

		try {
			$accepted = wp_mail($email, $subject, $html, wphave_email_template_headers());
			$events->finish_host((int) $event['id'], (bool) $accepted);
			return (bool) $accepted;
		} catch (Throwable $error) {
			// A throwing transport may have sent the mail. Never retry automatically.
			$events->finish_host((int) $event['id'], false);
			return false;
		}
	}

	/**
	 * Read the latest host transport state for a Workspace mutation response.
	 *
	 * @param int $booking_id Booking ID.
	 * @return bool|null Accepted, not accepted, or no host notice required.
	 */
	public static function host_status(int $booking_id): ?bool {
		$history = (new WPHAVE_Booking_Events())->latest($booking_id);
		$status = $history[0]['host_mail_status'] ?? 'skipped';
		return 'skipped' === $status ? null : 'accepted' === $status;
	}

	/**
	 * Render translated plain event copy and generated links as safe email HTML.
	 *
	 * @param string $message Plain notification text with optional URL lines.
	 * @return string Escaped paragraphs for the shared email template.
	 */
	private static function html_content(string $message): string {
		$paragraphs = preg_split('/\n{2,}/', trim($message));
		$html = [];
		foreach ($paragraphs as $paragraph) {
			$lines = [];
			foreach (explode("\n", $paragraph) as $line) {
				if (preg_match('~^https?://\S+$~D', $line)) {
					$lines[] = '<a href="' . esc_url($line) . '">' . esc_html($line) . '</a>';
				} else {
					$lines[] = esc_html($line);
				}
			}
			$html[] = '<p>' . implode('<br>', $lines) . '</p>';
		}
		return implode('', $html);
	}

	/**
	 * Send the latest cancellation event through the shared notification path.
	 *
	 * @param int $id Internal record ID.
	 * @return void
	 */

	public static function cancellation(int $id): void {
		self::latest($id);
	}
}
