<?php

/** Own booking persistence and the exclusive reservation boundary. */

final class WPHAVE_Booking_Repository {
	private string $table;

	/**
	 * Resolve the booking table from WordPress's database prefix.
	 * The shared $wpdb connection is supplied by WordPress.
	 */

	public function __construct() {
		global $wpdb;
		$this->table = $wpdb->prefix . 'wphave_bookings';
	}

	/**
	 * Install booking and event tables before accepting writes.
	 * @return bool
	 */

	public function install(): bool {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();
		$sql = "CREATE TABLE {$this->table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			service_id bigint(20) unsigned NOT NULL,
			provider_id bigint(20) unsigned NOT NULL DEFAULT 0,
			request_hash char(64) NOT NULL,
			starts_at datetime NOT NULL,
			ends_at datetime NOT NULL,
			attendee_name varchar(190) NOT NULL,
			attendee_email varchar(190) NOT NULL,
			intake_json text NOT NULL,
			admin_note text NOT NULL,
			status varchar(20) NOT NULL DEFAULT 'confirmed',
			source varchar(20) NOT NULL DEFAULT 'public',
			contact_basis varchar(32) NOT NULL DEFAULT '',
			reminder_status varchar(20) NOT NULL DEFAULT 'pending',
			return_url varchar(512) NOT NULL DEFAULT '',
			revision bigint(20) unsigned NOT NULL DEFAULT 1,
			confirm_token_hash char(64) NOT NULL DEFAULT '',
			manage_token_hash char(64) NOT NULL DEFAULT '',
			confirm_expires_at datetime NULL,
			confirmed_at datetime NULL,
			proposal_starts_at datetime NULL,
			proposal_ends_at datetime NULL,
			proposal_token_hash char(64) NOT NULL DEFAULT '',
			proposal_expires_at datetime NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY request_hash (request_hash),
			KEY service_time (service_id,starts_at,ends_at),
			KEY provider_time (provider_id,starts_at,ends_at),
			KEY confirm_token_hash (confirm_token_hash),
			KEY manage_token_hash (manage_token_hash),
			KEY proposal_token_hash (proposal_token_hash),
			KEY attendee_email (attendee_email)
		) ENGINE=InnoDB {$charset};";
		dbDelta($sql);
		(new WPHAVE_Booking_Events())->install();
		return $this->ready();
	}

	/**
	 * Confirm the required InnoDB tables and transition columns exist.
	 * @return bool
	 */

	public function ready(): bool {
		global $wpdb;
		$engine = $wpdb->get_var(
			$wpdb->prepare(
				'SELECT ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s',
				$this->table,
			),
		);

		if ('InnoDB' !== $engine) {
			return false;
		}

		$columns = $wpdb->get_col(
			$wpdb->prepare(
				'SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND COLUMN_NAME IN (%s, %s, %s, %s, %s, %s, %s, %s, %s)',
				$this->table,
				'confirm_token_hash',
				'proposal_token_hash',
				'revision',
				'return_url',
				'manage_token_hash',
				'reminder_status',
				'intake_json',
				'provider_id',
				'admin_note',
			),
		);

		return count($columns) === 9 && (new WPHAVE_Booking_Events())->ready();
	}

	/**
	 * Claim a due reminder only while its confirmed interval still matches the
	 * scheduled UTC start. A changed, cancelled or erased booking fails closed.
	 *
	 * @param int $id Booking ID.
	 * @param string $start Expected UTC SQL datetime.
	 * @param int $hours Reminder lead time, bounded to seven days.
	 * @return array<string, mixed>|null Claimed booking snapshot.
	 */
	public function claim_reminder(int $id, string $start, int $hours = 24): ?array {
		global $wpdb;
		if (!$this->ready() || $hours < 2 || $hours > 168 || !preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/D', $start)) {
			return null;
		}

		$claimed = $wpdb->query($wpdb->prepare(
			"UPDATE {$this->table} SET reminder_status = 'sending'
			 WHERE id = %d AND starts_at = %s AND status = 'confirmed'
			 AND reminder_status = 'pending' AND attendee_email <> ''
			 AND starts_at > DATE_ADD(UTC_TIMESTAMP(), INTERVAL 1 HOUR)
			 AND starts_at <= DATE_ADD(UTC_TIMESTAMP(), INTERVAL %d HOUR)",
			$id,
			$start,
			$hours,
		));
		return 1 === $claimed ? $this->get($id) : null;
	}

	/**
	 * Record transport acceptance for the claimed appointment interval.
	 *
	 * @param int $id Booking ID.
	 * @param string $start Claimed UTC start.
	 * @param bool $accepted Whether WordPress accepted the message.
	 * @return void
	 */
	public function finish_reminder(int $id, string $start, bool $accepted): void {
		global $wpdb;
		$wpdb->update(
			$this->table,
			['reminder_status' => $accepted ? 'accepted' : 'unknown'],
			['id' => $id, 'starts_at' => $start, 'reminder_status' => 'sending'],
			['%s'],
			['%d', '%s', '%s'],
		);
	}

	/**
	 * Read a bounded due batch for cron recovery after a missed single event.
	 *
	 * @param int $hours Reminder lead time, bounded to seven days.
	 * @return array<int, array<string, mixed>> Due booking snapshots.
	 */
	public function due_reminders(int $hours = 24): array {
		global $wpdb;
		if (!$this->ready() || $hours < 2 || $hours > 168) {
			return [];
		}

		$rows = $wpdb->get_results(
			$wpdb->prepare("SELECT id, starts_at FROM {$this->table}
			 WHERE status = 'confirmed' AND reminder_status = 'pending'
			 AND attendee_email <> ''
			 AND starts_at > DATE_ADD(UTC_TIMESTAMP(), INTERVAL 1 HOUR)
			 AND starts_at <= DATE_ADD(UTC_TIMESTAMP(), INTERVAL %d HOUR)
			 ORDER BY starts_at ASC LIMIT 100", $hours),
			ARRAY_A,
		);
		return is_array($rows) && !$wpdb->last_error ? $rows : [];
	}

	/**
	 * Read intervals that currently block canonical service availability.
	 *
	 * @param int $service_id Appointment type ID.
	 * @param string $from Inclusive UTC range start.
	 * @param string $until Exclusive UTC range end.
	 * @param int $exclude_id Booking ID omitted from conflict checks.
	 * @param int $provider_id Selected WordPress user, or zero for an unassigned service.
	 * @return array<int, array{start: string, end: string, booking_id: int|string, other_service: bool, cap_only: bool}>
	 */

	public function busy(int $service_id, string $from, string $until, int $exclude_id = 0, int $provider_id = 0): array {
		global $wpdb;
		if (!$this->ready()) {
			throw new RuntimeException('Booking storage is unavailable.');
		}

		$service = WPHAVE_Booking_Services::get($service_id);
		if ($service && ($service['max_bookings_per_day'] ?? 0) > 0) {
			// Daily limits include appointments earlier today, even though those
			// intervals can no longer conflict with a future candidate slot.
			$local_start = (new DateTimeImmutable($from . ' UTC'))
				->setTimezone(new DateTimeZone($service['timezone']))
				->setTime(0, 0);
			$day_start = $local_start->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
			if ($day_start < $from) {
				$from = $day_start;
			}
		}

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, service_id, provider_id, starts_at, ends_at, proposal_starts_at, proposal_ends_at,
				 status, confirm_expires_at, proposal_expires_at FROM {$this->table}
				 WHERE (service_id = %d OR (provider_id = %d AND provider_id <> 0))
				 AND id <> %d AND (
				 (starts_at < %s AND ends_at > %s AND
				  (status = 'confirmed' OR (status = 'pending_confirmation' AND confirm_expires_at > UTC_TIMESTAMP())))
				 OR (status = 'confirmed' AND proposal_expires_at > UTC_TIMESTAMP()
				  AND proposal_starts_at < %s AND proposal_ends_at > %s))",
				$service_id,
				$provider_id,
				$exclude_id,
				$until,
				$from,
				$until,
				$from,
			),
			ARRAY_A,
		);

		if (!is_array($rows) || $wpdb->last_error) {
			throw new RuntimeException('Booking availability could not be read.');
		}

		$busy = [];
		foreach ($rows as $row) {
			$other_service = (int) $row['service_id'] !== $service_id;
			$cap_only = !$other_service && $provider_id > 0 && (int) $row['provider_id'] > 0 &&
				(int) $row['provider_id'] !== $provider_id;
			if (
				'confirmed' === $row['status'] ||
				('pending_confirmation' === $row['status'] && $row['confirm_expires_at'] > gmdate('Y-m-d H:i:s'))
			) {
				$busy[] = [
					'start' => $row['starts_at'] . ' UTC',
					'end' => $row['ends_at'] . ' UTC',
					'booking_id' => $row['id'],
					'other_service' => $other_service,
					'cap_only' => $cap_only,
				];
			}

			if ($row['proposal_starts_at'] && $row['proposal_expires_at'] > gmdate('Y-m-d H:i:s')) {
				$busy[] = [
					'start' => $row['proposal_starts_at'] . ' UTC',
					'end' => $row['proposal_ends_at'] . ' UTC',
					'booking_id' => $row['id'],
					'other_service' => $other_service,
					'cap_only' => $cap_only,
				];
			}
		}

		return $busy;
	}

	/**
	 * Reserve a canonical slot under the booking-wide lock and transaction.
	 *
	 * @param int $service_id Appointment type ID.
	 * @param string $start Requested UTC start.
	 * @param string $name Attendee name.
	 * @param string $email Attendee email address.
	 * @param string $request_id Per-form UUID used for retry identity.
	 * @param string $mode Initial booking state.
	 * @param string $token_hash SHA-256 digest of a bearer token.
	 * @param string|null $expires_at UTC token expiry.
	 * @param string $source Origin of the appointment.
	 * @param string $contact_basis Recorded basis for operational contact.
	 * @param bool $notify Whether to attempt a transactional notice.
	 * @param string $return_url Validated local review page URL.
	 * @param bool|null $created Set true only after a new reservation commits; retries leave it false.
	 * @param array<string, mixed> $intake Raw public answers; admin appointments omit them.
	 * @param int $provider_id Chosen WordPress user ID, or zero for an unassigned service.
	 * @return int
	 * @throws RuntimeException When storage, identity, locking, or availability checks fail.
	 */

	public function reserve(
		int $service_id,
		string $start,
		string $name,
		string $email,
		string $request_id,
		string $mode = 'confirmed',
		string $token_hash = '',
		?string $expires_at = null,
		string $source = 'admin',
		string $contact_basis = '',
		bool $notify = true,
		string $return_url = '',
		?bool &$created = null,
		array $intake = [],
		int $provider_id = 0,
	): int {
		global $wpdb;
		$created = false;

		if (
			!$this->ready() ||
			!wp_is_uuid($request_id) ||
			!in_array($mode, ['confirmed', 'pending_confirmation'], true) ||
			('pending_confirmation' === $mode && (!preg_match('/^[a-f0-9]{64}$/', $token_hash) || !$expires_at))
		) {
			throw new RuntimeException('Booking storage or request identity is unavailable.');
		}

		// A single advisory lock serializes all writers while provider conflicts can
		// span services. It must be shared by every transition below.
		$lock = 'wphave_booking_' . md5($wpdb->prefix);

		if (1 !== (int) $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 3)', $lock))) {
			throw new RuntimeException('Booking reservation lock is unavailable.');
		}

		try {
			if (false === $wpdb->query('START TRANSACTION')) {
				throw new RuntimeException('Booking transaction could not start.');
			}

			$request_hash = hash('sha256', $service_id . ':' . $request_id);

			$current_service = WPHAVE_Booking_Services::get($service_id);
			if (!$current_service) {
				throw new RuntimeException('Appointment type is no longer available.');
			}
			if (!self::provider_matches($current_service, $provider_id)) {
				throw new RuntimeException('Booking provider is no longer available.');
			}
			$intake_json = 'public' === $source
				? WPHAVE_Booking_Intake::capture($current_service, $intake)
				: '[]';

			$existing = $wpdb->get_row(
				$wpdb->prepare(
				"SELECT id, provider_id, starts_at, attendee_name, attendee_email, intake_json, status FROM {$this->table} WHERE request_hash = %s FOR UPDATE",
					$request_hash,
				),
				ARRAY_A,
			);

			if ($existing) {
				if (
					$mode !== $existing['status'] ||
					$provider_id !== (int) $existing['provider_id'] ||
					$existing['starts_at'] !== $start ||
					!hash_equals($existing['attendee_name'], $name) ||
					!hash_equals($existing['attendee_email'], $email) ||
					!hash_equals($existing['intake_json'] ?: '[]', $intake_json)
				) {
					throw new RuntimeException('Booking request identity was reused.');
				}

				if (false === $wpdb->query('COMMIT')) {
					throw new RuntimeException('Booking transaction could not commit.');
				}

				return (int) $existing['id'];
			}

			// Never trust a caller's policy snapshot for the final slot decision.
			// A draft, unpublished, or changed type must fail at the write boundary.
			$start_time = new DateTimeImmutable($start . ' UTC');
			$now = new DateTimeImmutable('now', new DateTimeZone('UTC'));
			$from = $now->format('Y-m-d H:i:s');
			$until = $now->modify('+' . (int) $current_service['horizon_days'] . ' days')->format('Y-m-d H:i:s');
			$busy = $this->busy($service_id, $from, $until, 0, $provider_id);
			$slots = WPHAVE_Booking_Busy_Source::slots($current_service, $busy, $now, $provider_id);
			$match = null;

			foreach ($slots as $slot) {
				if ($slot['start'] === $start_time->format('Y-m-d\TH:i:s\Z')) {
					$match = $slot;
					break;
				}
			}

			if (null === $match) {
				throw new RuntimeException('The selected booking time is no longer available.');
			}

			$inserted = $wpdb->insert(
				$this->table,
				[
					'service_id' => $service_id,
					'provider_id' => $provider_id,
					'request_hash' => $request_hash,
					'starts_at' => $start_time->format('Y-m-d H:i:s'),
					'ends_at' => (new DateTimeImmutable($match['end']))->format('Y-m-d H:i:s'),
					'attendee_name' => $name,
					'attendee_email' => $email,
					'intake_json' => $intake_json,
					'admin_note' => '',
					'status' => $mode,
					'source' => $source,
					'contact_basis' => $contact_basis,
					'reminder_status' => $notify ? 'pending' : 'skipped',
					'return_url' => $return_url,
					'revision' => 1,
					'confirm_token_hash' => $token_hash,
					'confirm_expires_at' => $expires_at,
					'confirmed_at' => 'confirmed' === $mode ? $now->format('Y-m-d H:i:s') : null,
					'created_at' => $now->format('Y-m-d H:i:s'),
					'updated_at' => $now->format('Y-m-d H:i:s'),
				],
				['%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s'],
			);

			if (1 !== $inserted) {
				throw new RuntimeException('Booking could not be saved.');
			}

			$booking_id = (int) $wpdb->insert_id;
			(new WPHAVE_Booking_Events())->record(
				$booking_id,
				1,
				'pending_confirmation' === $mode ? 'confirmation_requested' : 'created',
				null,
				$start_time->format('Y-m-d H:i:s'),
				$email,
				$notify,
			);

			if (false === $wpdb->query('COMMIT')) {
				throw new RuntimeException('Booking could not be committed.');
			}

			$created = true;
			return $booking_id;
		} catch (Throwable $error) {
			$wpdb->query('ROLLBACK');
			throw $error;
		} finally {
			$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lock));
		}
	}

	/**
	 * Read a bounded list for the administration fallback and overview.
	 *
	 * @param int $limit Maximum number of rows.
	 * @return array<int, array<string, mixed>>
	 */

	public function list_recent(int $limit = 100): array {
		global $wpdb;

		if (!$this->ready()) {
			throw new RuntimeException('Booking storage is unavailable.');
		}

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				// Workspace rows contain attendee details, but never bearer digests,
				// request identities or redirect URLs from the persistence record.
				"SELECT id, service_id, provider_id, starts_at, ends_at, attendee_name,
				 attendee_email, intake_json, admin_note, status, revision
				 FROM {$this->table} ORDER BY starts_at DESC LIMIT %d",
				min(100, max(1, $limit)),
			),
			ARRAY_A,
		);

		if (!is_array($rows) || $wpdb->last_error) {
			throw new RuntimeException('Booking list could not be read.');
		}

		return $rows;
	}

	/**
	 * Count current appointment states without using the bounded Workspace list.
	 *
	 * @return array{upcoming: int, awaiting_confirmation: int}
	 */
	public function summary(): array {
		global $wpdb;

		if (!$this->ready()) {
			throw new RuntimeException('Booking storage is unavailable.');
		}

		// The recent-list limit is a transport bound, never a statistics bound.
		// Expired confirmation holds must not appear as awaiting action before cleanup.
		$row = $wpdb->get_row(
			"SELECT
				COUNT(CASE WHEN status = 'confirmed' AND starts_at >= UTC_TIMESTAMP() THEN 1 END) AS upcoming,
				COUNT(CASE WHEN status = 'pending_confirmation' AND starts_at >= UTC_TIMESTAMP()
					AND confirm_expires_at > UTC_TIMESTAMP() THEN 1 END) AS awaiting_confirmation
			 FROM {$this->table}",
			ARRAY_A,
		);

		if (!is_array($row) || $wpdb->last_error) {
			throw new RuntimeException('Booking summary could not be read.');
		}

		return [
			'upcoming' => (int) $row['upcoming'],
			'awaiting_confirmation' => (int) $row['awaiting_confirmation'],
		];
	}

	/**
	 * Read one bounded UTC calendar range without silent truncation.
	 *
	 * @param string $from Inclusive UTC range start.
	 * @param string $until Exclusive UTC range end.
	 * @return array<int, array<string, mixed>>
	 */
	public function list_for_range(string $from, string $until): array {
		global $wpdb;

		if (!$this->ready()) {
			throw new RuntimeException('Booking storage is unavailable.');
		}

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				// Calendar transport has the same projection as the overview; SELECT *
				// would expose credential hashes and other internal state to the browser.
				"SELECT id, service_id, provider_id, starts_at, ends_at, attendee_name,
				 attendee_email, intake_json, admin_note, status, revision FROM {$this->table}
				 WHERE starts_at >= %s AND starts_at < %s
				 ORDER BY starts_at ASC, id ASC LIMIT 1001",
				$from . ' 00:00:00',
				$until . ' 00:00:00',
			),
			ARRAY_A,
		);

		if (!is_array($rows) || $wpdb->last_error) {
			throw new RuntimeException('Booking calendar could not be read.');
		}

		if (count($rows) > 1000) {
			throw new OverflowException('Booking calendar range contains too many appointments.');
		}

		return $rows;
	}

	/**
	 * Project appointments belonging to an existing email identity.
	 *
	 * @param string $email Attendee email address.
	 * @return array<int, array<string, mixed>>|null
	 */

	public function for_email(string $email): ?array {
		global $wpdb;

		if (!$this->ready() || !is_email($email)) {
			return null;
		}

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, service_id, starts_at, ends_at, status FROM {$this->table}
				 WHERE attendee_email = %s ORDER BY starts_at DESC LIMIT 100",
				$email,
			),
			ARRAY_A,
		);

		return is_array($rows) && !$wpdb->last_error ? $rows : null;
	}

	/**
	 * Read one booking by its internal ID.
	 *
	 * @param int $id Internal record ID.
	 * @return array<string, mixed>|null
	 */

	public function get(int $id): ?array {
		global $wpdb;

		if (!$this->ready()) {
			return null;
		}

		$row = $wpdb->get_row(
			$wpdb->prepare("SELECT * FROM {$this->table} WHERE id = %d", $id),
			ARRAY_A,
		);

		return is_array($row) ? $row : null;
	}

	/**
	 * Save a private operator note with an exact previous-value precondition.
	 * Erased bookings cannot regain personal details through a stale editor.
	 *
	 * @param int $id Booking ID.
	 * @param string $note Sanitized note.
	 * @param string $previous Note last shown to the editor.
	 * @return bool Whether the precondition still matched.
	 */
	public function update_note(int $id, string $note, string $previous): bool {
		global $wpdb;
		if (!$this->ready() || $id < 1 || strlen($note) > 4000) {
			return false;
		}
		$changed = $wpdb->query($wpdb->prepare(
			"UPDATE {$this->table} SET admin_note = %s, updated_at = %s
			 WHERE id = %d AND admin_note = %s AND attendee_email <> ''",
			$note,
			gmdate('Y-m-d H:i:s'),
			$id,
			$previous,
		));
		if (false === $changed) {
			return false;
		}
		if ($changed > 0) {
			return true;
		}
		$row = $this->get($id);
		return $row && '' !== $row['attendee_email'] && $row['admin_note'] === $note;
	}

	/**
	 * Resolve a confirmed booking from a hashed attendee bearer link.
	 *
	 * @param string $token_hash SHA-256 digest of a bearer token.
	 * @return array<string, mixed>|null
	 */

	public function by_manage_token(string $token_hash): ?array {
		global $wpdb;

		if (!preg_match('/^[a-f0-9]{64}$/D', $token_hash) || !$this->ready()) {
			return null;
		}

		$row = $wpdb->get_row(
			$wpdb->prepare("SELECT * FROM {$this->table} WHERE manage_token_hash = %s AND status = 'confirmed'", $token_hash),
			ARRAY_A,
		);

		return is_array($row) ? $row : null;
	}

	/**
	 * Rotate the attendee bearer token before a confirmed-state notice.
	 * A notification passes its event revision so a stale event cannot replace
	 * a newer link. The token is never stored in plaintext.
	 *
	 * @param int $id Internal record ID.
	 * @param int|null $expected_revision Event revision, when issuing for a notice.
	 * @return string
	 */

	public function issue_manage_token(int $id, ?int $expected_revision = null): string {
		global $wpdb;
		$token = bin2hex(random_bytes(32));
		$where = ['id' => $id, 'status' => 'confirmed'];

		if (null !== $expected_revision) {
			$where['revision'] = $expected_revision;
		}

		$updated = $wpdb->update(
			$this->table,
			['manage_token_hash' => hash('sha256', $token)],
			$where,
		);

		if (1 !== $updated) {
			throw new RuntimeException('Appointment access link could not be issued.');
		}

		return $token;
	}

	/**
	 * Restore the previous bearer hash only if a rejected mail still owns it.
	 * A concurrent rotation or privacy erasure must never be overwritten.
	 *
	 * @param int $id Booking ID.
	 * @param string $issued_hash Hash installed for the rejected message.
	 * @param string $previous_hash Hash valid before this mail attempt.
	 * @param int $expected_revision Revision that issued the rejected message.
	 * @return void
	 */

	public function restore_manage_token(
		int $id,
		string $issued_hash,
		string $previous_hash,
		int $expected_revision,
	): void {
		global $wpdb;
		$wpdb->update(
			$this->table,
			['manage_token_hash' => $previous_hash],
			[
				'id' => $id,
				'status' => 'confirmed',
				'manage_token_hash' => $issued_hash,
				'revision' => $expected_revision,
			],
			['%s'],
			['%d', '%s', '%s', '%d'],
		);
	}

	/**
	 * Activate a live public hold with a single-use confirmation token.
	 *
	 * @param string $token_hash SHA-256 digest of a bearer token.
	 * @return int
	 * @throws RuntimeException When storage, identity, locking, or availability checks fail.
	 */

	public function confirm(string $token_hash): int {
		global $wpdb;

		if (!preg_match('/^[a-f0-9]{64}$/', $token_hash) || !$this->ready()) {
			throw new RuntimeException('Invalid confirmation request.');
		}

		$candidate = $wpdb->get_row(
			$wpdb->prepare("SELECT id, service_id FROM {$this->table} WHERE confirm_token_hash = %s", $token_hash),
			ARRAY_A,
		);

		if (!$candidate) {
			throw new RuntimeException('Confirmation request expired or was already used.');
		}

		return $this->transaction((int) $candidate['service_id'], function () use ($wpdb, $candidate, $token_hash): int {
			$row = $wpdb->get_row(
				$wpdb->prepare("SELECT * FROM {$this->table} WHERE id = %d FOR UPDATE", $candidate['id']),
				ARRAY_A,
			);

			if (
				!$row ||
				'pending_confirmation' !== $row['status'] ||
				!hash_equals($row['confirm_token_hash'], $token_hash) ||
				$row['confirm_expires_at'] <= gmdate('Y-m-d H:i:s')
			) {
				throw new RuntimeException('Confirmation request expired or was already used.');
			}

			$service = WPHAVE_Booking_Services::get((int) $row['service_id']);
			if (!$service) {
				throw new RuntimeException('Appointment type is no longer available.');
			}
			// A hold owns the WPHAVE interval, but an external calendar may have
			// changed during the one-hour confirmation window.
			WPHAVE_Booking_Busy_Source::assert_external_clear($service, $row['starts_at'], $row['ends_at'], (int) $row['provider_id']);

			$revision = (int) $row['revision'] + 1;
			$updated = $wpdb->update(
				$this->table,
				[
					'status' => 'confirmed',
					'confirm_token_hash' => '',
					'manage_token_hash' => '',
					'confirm_expires_at' => null,
					'confirmed_at' => gmdate('Y-m-d H:i:s'),
					'revision' => $revision,
					'updated_at' => gmdate('Y-m-d H:i:s'),
				],
				['id' => $candidate['id'], 'revision' => $row['revision']],
			);

			if (1 !== $updated) {
				throw new RuntimeException('Confirmation could not be saved.');
			}

			(new WPHAVE_Booking_Events())->record(
				(int) $row['id'],
				$revision,
				'confirmed',
				null,
				$row['starts_at'],
				$row['attendee_email'],
				true,
			);

			return (int) $row['id'];
		});
	}

	/**
	 * Move an agreed confirmed booking after revision and slot checks.
	 *
	 * @param int $id Internal record ID.
	 * @param string $start Requested UTC start.
	 * @param int $expected_revision Revision observed by the caller.
	 * @param string $manage_token_hash Attendee token hash, or empty for an authorized administrator.
	 * @return bool
	 */

	public function reschedule(int $id, string $start, int $expected_revision, string $manage_token_hash = ''): bool {
		$row = $this->get($id);

		if (!$row || 'confirmed' !== $row['status']) {
			return false;
		}

		try {
			return $this->transaction((int) $row['service_id'], function () use ($id, $start, $expected_revision, $manage_token_hash): bool {
				global $wpdb;
				$current = $wpdb->get_row(
					$wpdb->prepare("SELECT * FROM {$this->table} WHERE id = %d FOR UPDATE", $id),
					ARRAY_A,
				);

				// The bearer token is checked again under the row lock; a lookup before
				// this transaction cannot authorize a change after token rotation.
				if (!$current || 'confirmed' !== $current['status'] || (int) $current['revision'] !== $expected_revision ||
					('' !== $manage_token_hash && !hash_equals($current['manage_token_hash'], $manage_token_hash)) ||
					$current['starts_at'] === $start) {
					throw new RuntimeException('Appointment changed before rescheduling.');
				}

				$slot = $this->available_slot((int) $current['service_id'], $start, $id, (int) $current['provider_id']);
				$revision = $expected_revision + 1;
				$updated = $wpdb->update(
					$this->table,
					[
						'starts_at' => $start,
						'ends_at' => $slot['end'],
						'reminder_status' => 'skipped' === $current['reminder_status'] ? 'skipped' : 'pending',
						'proposal_starts_at' => null,
						'proposal_ends_at' => null,
						'proposal_token_hash' => '',
						'proposal_expires_at' => null,
						'revision' => $revision,
						'updated_at' => gmdate('Y-m-d H:i:s'),
					],
					['id' => $id, 'revision' => $expected_revision],
				);

				if (1 !== $updated) {
					throw new RuntimeException('Appointment could not be moved.');
				}

				(new WPHAVE_Booking_Events())->record(
					$id,
					$revision,
					'rescheduled',
					$current['starts_at'],
					$start,
					$current['attendee_email'],
					true,
				);

				return true;
			});
		} catch (RuntimeException $error) {
			return false;
		}
	}

	/**
	 * Hold an alternate time while preserving the confirmed time.
	 *
	 * @param int $id Internal record ID.
	 * @param string $start Requested UTC start.
	 * @param int $expected_revision Revision observed by the caller.
	 * @param string $token_hash SHA-256 digest of a bearer token.
	 * @param string $expires_at UTC token expiry.
	 * @return bool
	 */

	public function propose_reschedule(int $id, string $start, int $expected_revision, string $token_hash, string $expires_at): bool {
		$row = $this->get($id);

		if (!$row || 'confirmed' !== $row['status'] || !preg_match('/^[a-f0-9]{64}$/', $token_hash)) {
			return false;
		}

		try {
			return $this->transaction((int) $row['service_id'], function () use ($id, $start, $expected_revision, $token_hash, $expires_at): bool {
				global $wpdb;
				$current = $wpdb->get_row(
					$wpdb->prepare("SELECT * FROM {$this->table} WHERE id = %d FOR UPDATE", $id),
					ARRAY_A,
				);

				if (!$current || 'confirmed' !== $current['status'] || (int) $current['revision'] !== $expected_revision ||
					$current['starts_at'] === $start) {
					throw new RuntimeException('Appointment changed before proposal.');
				}

				$slot = $this->available_slot((int) $current['service_id'], $start, $id, (int) $current['provider_id']);
				$revision = $expected_revision + 1;
				$updated = $wpdb->update(
					$this->table,
					[
						'proposal_starts_at' => $start,
						'proposal_ends_at' => $slot['end'],
						'proposal_token_hash' => $token_hash,
						'proposal_expires_at' => $expires_at,
						'revision' => $revision,
						'updated_at' => gmdate('Y-m-d H:i:s'),
					],
					['id' => $id, 'revision' => $expected_revision],
				);

				if (1 !== $updated) {
					throw new RuntimeException('Proposal could not be saved.');
				}

				(new WPHAVE_Booking_Events())->record(
					$id,
					$revision,
					'proposal_sent',
					$current['starts_at'],
					$start,
					$current['attendee_email'],
					true,
				);

				return true;
			});
		} catch (RuntimeException $error) {
			return false;
		}
	}

	/**
	 * Move to a live proposed time using its single-use bearer token.
	 *
	 * @param string $token_hash SHA-256 digest of a bearer token.
	 * @return int
	 * @throws RuntimeException When storage, identity, locking, or availability checks fail.
	 */

	public function accept_proposal(string $token_hash): int {
		global $wpdb;
		// Reject malformed bearer digests before querying an index that also
		// contains the empty default value for non-proposal bookings.
		if (!preg_match('/^[a-f0-9]{64}$/D', $token_hash) || !$this->ready()) {
			throw new RuntimeException('Proposal is unavailable.');
		}
		$candidate = $wpdb->get_row(
			$wpdb->prepare("SELECT id, service_id FROM {$this->table} WHERE proposal_token_hash = %s", $token_hash),
			ARRAY_A,
		);

		if (!$candidate) {
			throw new RuntimeException('Proposal is unavailable.');
		}

		return $this->transaction((int) $candidate['service_id'], function () use ($candidate, $token_hash, $wpdb): int {
			$row = $wpdb->get_row(
				$wpdb->prepare("SELECT * FROM {$this->table} WHERE id = %d FOR UPDATE", $candidate['id']),
				ARRAY_A,
			);

			if (!$row || 'confirmed' !== $row['status'] ||
				!hash_equals($row['proposal_token_hash'], $token_hash) ||
				$row['proposal_expires_at'] <= gmdate('Y-m-d H:i:s')) {
				throw new RuntimeException('Proposal expired or was already used.');
			}

			$service = WPHAVE_Booking_Services::get((int) $row['service_id']);
			if (!$service) {
				throw new RuntimeException('Appointment type is no longer available.');
			}
			// The proposal hold protects against local bookings, not provider-side
			// events created after the proposal email was sent.
			WPHAVE_Booking_Busy_Source::assert_external_clear(
				$service,
				$row['proposal_starts_at'],
				$row['proposal_ends_at'],
				(int) $row['provider_id'],
			);

			$revision = (int) $row['revision'] + 1;
			$updated = $wpdb->update($this->table, [
				'starts_at' => $row['proposal_starts_at'],
				'ends_at' => $row['proposal_ends_at'],
				'reminder_status' => 'skipped' === $row['reminder_status'] ? 'skipped' : 'pending',
				'proposal_starts_at' => null,
				'proposal_ends_at' => null,
				'proposal_token_hash' => '',
				'proposal_expires_at' => null,
				'revision' => $revision,
				'updated_at' => gmdate('Y-m-d H:i:s'),
			], ['id' => $candidate['id'], 'revision' => $row['revision']]);

			if (1 !== $updated) {
				throw new RuntimeException('Proposal could not be accepted.');
			}

			(new WPHAVE_Booking_Events())->record((int) $row['id'], $revision, 'proposal_accepted',
				$row['starts_at'], $row['proposal_starts_at'], $row['attendee_email'], true);
			return (int) $row['id'];
		});
	}

	/**
	 * Release a proposal whose transport rejected its notice.
	 *
	 * @param int $id Internal record ID.
	 * @param int $expected_revision Revision observed by the caller.
	 * @return bool
	 */

	public function revoke_proposal(int $id, int $expected_revision): bool {
		$row = $this->get($id);

		if (!$row || 'confirmed' !== $row['status']) {
			return false;
		}

		try {
			return $this->transaction((int) $row['service_id'], function () use ($id, $expected_revision): bool {
				global $wpdb;
				$current = $wpdb->get_row(
					$wpdb->prepare("SELECT * FROM {$this->table} WHERE id = %d FOR UPDATE", $id), ARRAY_A,
				);

				if (!$current || (int) $current['revision'] !== $expected_revision || !$current['proposal_starts_at']) {
					throw new RuntimeException('Proposal changed before release.');
				}

				$revision = $expected_revision + 1;
				$updated = $wpdb->update($this->table, [
					'proposal_starts_at' => null,
					'proposal_ends_at' => null,
					'proposal_token_hash' => '',
					'proposal_expires_at' => null,
					'revision' => $revision,
					'updated_at' => gmdate('Y-m-d H:i:s'),
				], ['id' => $id, 'revision' => $expected_revision]);

				if (1 !== $updated) {
					throw new RuntimeException('Proposal could not be released.');
				}

				(new WPHAVE_Booking_Events())->record($id, $revision, 'proposal_delivery_failed',
					$current['proposal_starts_at'], null, $current['attendee_email'], false);

				return true;
			});
		} catch (RuntimeException $error) {
			return false;
		}
	}

	/**
	 * Cancel a live booking, release its holds, and record the transition.
	 *
	 * @param int $id Internal record ID.
	 * @param string $manage_token_hash Attendee token hash, or empty for an authorized administrator.
	 * @return bool
	 */

	public function cancel(int $id, string $manage_token_hash = ''): bool {
		$row = $this->get($id);

		if (!$row || !in_array($row['status'], ['confirmed', 'pending_confirmation'], true)) {
			return false;
		}

		try {
			return $this->transaction((int) $row['service_id'], function () use ($id, $manage_token_hash): bool {
				global $wpdb;
				$current = $wpdb->get_row(
					$wpdb->prepare("SELECT * FROM {$this->table} WHERE id = %d FOR UPDATE", $id),
					ARRAY_A,
				);

				// Public cancellation must still own the current bearer token at the
				// mutation boundary, even if it was valid during the earlier lookup.
				if (!$current || !in_array($current['status'], ['confirmed', 'pending_confirmation'], true) ||
					('' !== $manage_token_hash && !hash_equals($current['manage_token_hash'], $manage_token_hash))) {
					throw new RuntimeException('Appointment has already changed.');
				}

				$revision = (int) $current['revision'] + 1;
				$updated = $wpdb->update($this->table, [
					'status' => 'cancelled',
					'confirm_token_hash' => '',
					'manage_token_hash' => '',
					'confirm_expires_at' => null,
					'proposal_token_hash' => '',
					'proposal_expires_at' => null,
					'proposal_starts_at' => null,
					'proposal_ends_at' => null,
					'revision' => $revision,
					'updated_at' => gmdate('Y-m-d H:i:s'),
				], ['id' => $id, 'revision' => $current['revision']]);

				if (1 !== $updated) {
					throw new RuntimeException('Appointment could not be cancelled.');
				}

				(new WPHAVE_Booking_Events())->record($id, $revision, 'cancelled',
					$current['starts_at'], null, $current['attendee_email'], 'confirmed' === $current['status']);

				return true;
			});
		} catch (RuntimeException $error) {
			return false;
		}
	}

	/**
	 * Mark expired confirmation holds and proposals in bounded batches.
	 * @return int
	 */

	public function expire(): int {
		global $wpdb;

		if (!$this->ready()) {
			return 0;
		}

		$candidates = $wpdb->get_results(
			"SELECT id, service_id FROM {$this->table} WHERE
				(status = 'pending_confirmation' AND confirm_expires_at <= UTC_TIMESTAMP()) OR
				(status = 'confirmed' AND proposal_expires_at <= UTC_TIMESTAMP() AND proposal_starts_at IS NOT NULL)
				ORDER BY id ASC LIMIT 100",
			ARRAY_A,
		);

		$count = 0;
		foreach ($candidates ?: [] as $candidate) {
			try {
				$this->transaction((int) $candidate['service_id'], function () use ($candidate, $wpdb, &$count): void {
					$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table} WHERE id = %d FOR UPDATE", $candidate['id']), ARRAY_A);

					if (!$row) {
						return;
					}

					$now = gmdate('Y-m-d H:i:s');
					$pending = 'pending_confirmation' === $row['status'] && $row['confirm_expires_at'] <= $now;
					$proposal = 'confirmed' === $row['status'] && $row['proposal_starts_at'] && $row['proposal_expires_at'] <= $now;

					if (!$pending && !$proposal) {
						return;
					}

					$revision = (int) $row['revision'] + 1;
					$changes = $pending ? [
						'status' => 'expired',
						'confirm_token_hash' => '',
						'confirm_expires_at' => null,
					] : [
						'proposal_starts_at' => null,
						'proposal_ends_at' => null,
						'proposal_token_hash' => '',
						'proposal_expires_at' => null,
					];

					$changes['revision'] = $revision;
					$changes['updated_at'] = $now;

					if (1 !== $wpdb->update($this->table, $changes, ['id' => $candidate['id'], 'revision' => $row['revision']])) {
						throw new RuntimeException('Expired appointment could not be updated.');
					}

					(new WPHAVE_Booking_Events())->record((int) $candidate['id'], $revision,
						$pending ? 'confirmation_expired' : 'proposal_expired',
						$pending ? $row['starts_at'] : $row['proposal_starts_at'], null,
						$row['attendee_email'], false);
					++$count;
				});
			} catch (Throwable $error) {
				// A later cron run can retry; availability already ignores the expired hold.
			}
		}

		return $count;
	}

	/**
	 * Resolve a requested UTC start through canonical availability.
	 *
	 * @param int $service_id Appointment type ID.
	 * @param string $start Requested UTC start.
	 * @param int $exclude_id Booking ID omitted from conflict checks.
	 * @param int $provider_id Assigned provider, or zero for an unassigned service.
	 * @return array{end: string}
	 * @throws RuntimeException When storage, identity, locking, or availability checks fail.
	 */

	private function available_slot(int $service_id, string $start, int $exclude_id, int $provider_id = 0): array {
		$service = WPHAVE_Booking_Services::get($service_id);
		$existing = $exclude_id > 0 ? $this->get($exclude_id) : null;
		// A booked provider remains valid for editing that appointment even if the
		// service's current provider list changed after the original reservation.
		$stored_assignment = $existing && (int) $existing['service_id'] === $service_id &&
			(int) $existing['provider_id'] === $provider_id;

		if (!$service || (!self::provider_matches($service, $provider_id) && !$stored_assignment) ||
			!preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/D', $start)) {
			throw new RuntimeException('Invalid appointment time.');
		}

		$now = new DateTimeImmutable('now', new DateTimeZone('UTC'));
		$until = $now->modify('+' . (int) $service['horizon_days'] . ' days');
		$busy = $this->busy(
			$service_id,
			$now->format('Y-m-d H:i:s'),
			$until->format('Y-m-d H:i:s'),
			$exclude_id,
			$provider_id,
		);

		foreach (WPHAVE_Booking_Busy_Source::slots($service, $busy, $now, $provider_id) as $slot) {
			if ($slot['start'] === (new DateTimeImmutable($start . ' UTC'))->format('Y-m-d\TH:i:s\Z')) {
				return ['end' => (new DateTimeImmutable($slot['end']))->format('Y-m-d H:i:s')];
			}
		}

		throw new RuntimeException('The selected booking time is no longer available.');
	}

	/**
	 * Allow an unassigned service, but require an assigned user once configured.
	 * IDs are revalidated at the write boundary.
	 *
	 * @param array<string, mixed> $service Current validated service policy.
	 * @param int $provider_id Chosen WordPress user ID, or zero for unassigned services.
	 * @return bool
	 */
	private static function provider_matches(array $service, int $provider_id): bool {
		$providers = $service['provider_ids'] ?? [];
		return $providers
			? in_array($provider_id, $providers, true) && (bool) get_userdata($provider_id)
			: 0 === $provider_id;
	}

	/**
	 * Run a booking-wide locked transaction with rollback and lock release.
	 *
	 * @param int $service_id Appointment type ID retained for transition call contracts.
	 * @param callable $operation Transition callback executed inside the transaction.
	 * @return mixed
	 * @throws RuntimeException When storage, identity, locking, or availability checks fail.
	 */

	private function transaction(int $service_id, callable $operation) {
		global $wpdb;

		if (!$this->ready()) {
			throw new RuntimeException('Booking storage is unavailable.');
		}

		$lock = 'wphave_booking_' . md5($wpdb->prefix);
		if (1 !== (int) $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 3)', $lock))) {
			throw new RuntimeException('Booking lock is unavailable.');
		}

		try {
			if (false === $wpdb->query('START TRANSACTION')) {
				throw new RuntimeException('Booking transaction could not start.');
			}

			$result = $operation();

			if (false === $wpdb->query('COMMIT')) {
				throw new RuntimeException('Booking transaction could not commit.');
			}

			return $result;
		} catch (Throwable $error) {
			$wpdb->query('ROLLBACK');
			throw $error;
		} finally {
			$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lock));
		}
	}

}
