<?php

/**
 * Calculate candidate appointment slots without mutating booking state.
 *
 * Weekly windows and exceptions are local wall-clock times in the service's
 * IANA timezone. Busy intervals and returned slots are UTC instants.
 */

final class WPHAVE_Booking_Availability {

	/**
	 * Calculate valid UTC slots from a local weekly policy and occupied intervals.
	 *
	 * @param array $service Validated policy with timezone, duration, buffers, weekly windows, and exceptions.
	 * @param array<int, array{start: string, end: string, booking_id?: int|string}> $busy Occupied UTC intervals.
	 * @param DateTimeImmutable $now Current UTC instant.
	 * @return array<int, array{start: string, end: string}> Available UTC intervals.
	 * @throws InvalidArgumentException When the policy or a local window is invalid.
	 */

	public static function slots(array $service, array $busy, DateTimeImmutable $now): array {
		$timezone = new DateTimeZone((string) ($service['timezone'] ?? 'UTC'));
		$duration = (int) ($service['duration_minutes'] ?? 0);
		$buffer = (int) ($service['buffer_minutes'] ?? 0);
		$notice = (int) ($service['notice_minutes'] ?? 0);
		$horizon = (int) ($service['horizon_days'] ?? 0);
		$step = (int) ($service['slot_step_minutes'] ?? 15);

		if (
			$duration < 5 || $duration > 480 ||
			$buffer < 0 || $buffer > 240 ||
			$notice < 0 || $notice > 10080 ||
			$horizon < 1 || $horizon > 90 ||
			$step < 15 || $step > 120
		) {
			throw new InvalidArgumentException('Invalid booking availability policy.');
		}

		$now = $now->setTimezone(new DateTimeZone('UTC'));
		$earliest = $now->modify('+' . $notice . ' minutes');
		$latest = $now->modify('+' . $horizon . ' days');
		$local_day = $now->setTimezone($timezone)->setTime(0, 0);
		$last_day = $latest->setTimezone($timezone)->setTime(0, 0);
		$closed = array_fill_keys($service['closed_dates'] ?? [], true);
		$windows = $service['weekly_windows'] ?? [];
		$daily_limit = (int) ($service['max_bookings_per_day'] ?? 0);
		if ($daily_limit < 0 || $daily_limit > 100) {
			throw new InvalidArgumentException('Invalid daily booking limit.');
		}
		$day_occupants = [];
		if ($daily_limit > 0) {
			foreach ($busy as $index => $interval) {
				// External and other-service holds block time, but only this service's
				// bookings consume its daily cap across all assigned providers.
				if (!empty($interval['external']) || !empty($interval['other_service'])) {
					continue;
				}
				$busy_date = (new DateTimeImmutable($interval['start']))->setTimezone($timezone)->format('Y-m-d');
				$occupant = (string) ($interval['booking_id'] ?? $index);
				$day_occupants[$busy_date][$occupant] = true;
			}
		}
		$result = [];

		for ($day = $local_day; $day <= $last_day; $day = $day->modify('+1 day')) {
			$date = $day->format('Y-m-d');

			if (isset($closed[$date]) ||
				($daily_limit > 0 && count($day_occupants[$date] ?? []) >= $daily_limit)) {
				continue;
			}

			// An explicit date override replaces weekly hours; an empty list closes
			// only that day without changing the recurring schedule.
			$day_windows = array_key_exists($date, $service['date_windows'] ?? [])
				? $service['date_windows'][$date]
				: ($windows[(int) $day->format('N')] ?? []);
			foreach ($day_windows as $window) {
				$start_minute = self::wall_minutes($window['start'] ?? '');
				$end_minute = self::wall_minutes($window['end'] ?? '');

				if ($start_minute >= $end_minute) {
					throw new InvalidArgumentException('Invalid booking window.');
				}

				for ($minute = $start_minute; $minute + $duration <= $end_minute; $minute += $step) {
					$start = $day->setTime(intdiv($minute, 60), $minute % 60);
					$end = $start->modify('+' . $duration . ' minutes');

					// DST gaps normalize to another wall time; reject rather than silently move.
					if ($start->format('H:i') !== sprintf('%02d:%02d', intdiv($minute, 60), $minute % 60)) {
						continue;
					}

					if ($end->format('Y-m-d') !== $date || self::local_minutes($end) > $end_minute) {
						continue;
					}

					$start_utc = $start->setTimezone(new DateTimeZone('UTC'));
					$end_utc = $end->setTimezone(new DateTimeZone('UTC'));
					if ($end_utc->getTimestamp() - $start_utc->getTimestamp() !== $duration * 60) {
						continue;
					}

					if ($start_utc < $earliest || $end_utc > $latest) {
						continue;
					}

					if (self::conflicts($start_utc, $end_utc, $buffer, $busy)) {
						continue;
					}

					$result[] = [
						'start' => $start_utc->format('Y-m-d\TH:i:s\Z'),
						'end' => $end_utc->format('Y-m-d\TH:i:s\Z'),
					];
				}
			}
		}

		return $result;
	}

	/**
	 * Parse a validated local HH:MM wall time into minutes.
	 *
	 * @param mixed $value Wall time to parse.
	 * @return int
	 */

	private static function wall_minutes($value): int {
		if (!is_string($value) || !preg_match('/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D', $value)) {
			throw new InvalidArgumentException('Invalid booking wall time.');
		}

		return ((int) substr($value, 0, 2) * 60) + (int) substr($value, 3, 2);
	}

	/**
	 * Read the local hour and minute of a date-time value.
	 *
	 * @param DateTimeImmutable $time Local date-time value.
	 * @return int
	 */

	private static function local_minutes(DateTimeImmutable $time): int {
		return ((int) $time->format('H') * 60) + (int) $time->format('i');
	}

	/**
	 * Detect overlap including the configured buffer on both intervals.
	 *
	 * @param DateTimeImmutable $start Requested UTC start.
	 * @param DateTimeImmutable $end Interval end.
	 * @param int $buffer Buffer in minutes.
	 * @param array $busy Occupied UTC intervals.
	 * @return bool
	 */

	public static function conflicts(
		DateTimeImmutable $start,
		DateTimeImmutable $end,
		int $buffer,
		array $busy,
	): bool {
		foreach ($busy as $interval) {
			// Another provider on the same service consumes a daily place but
			// cannot occupy this selected provider's interval.
			if (!empty($interval['cap_only'])) {
				continue;
			}
			$busy_start = new DateTimeImmutable($interval['start']);
			$busy_end = new DateTimeImmutable($interval['end']);

			if (
			$start < $busy_end->modify('+' . $buffer . ' minutes') &&
			$end->modify('+' . $buffer . ' minutes') > $busy_start
			) {
				return true;
			}
		}

		return false;
	}
}
