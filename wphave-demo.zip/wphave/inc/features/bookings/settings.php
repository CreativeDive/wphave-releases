<?php

/** Read and validate site-wide appointment notification and calendar settings. */
final class WPHAVE_Booking_Settings {
	/**
	 * Read current settings without trusting persisted values.
	 *
	 * @return array{operatorEmail: string, reminderHoursBefore: int}
	 */
	public static function notifications(): array {
		$settings = wphave_data_get('site_settings', 'bookings', []);
		$notifications = is_array($settings) ? ($settings['notifications'] ?? []) : [];
		if (!is_array($notifications)) {
			$notifications = [];
		}

		$email = $notifications['operatorEmail'] ?? '';
		$hours = $notifications['reminderHoursBefore'] ?? 24;
		return [
			// An invalid stored recipient must fail closed in recipient(), not redirect mail.
			'operatorEmail' => is_string($email) ? trim($email) : '__invalid__',
			'reminderHoursBefore' => is_int($hours) && $hours >= 2 && $hours <= 168 ? $hours : 24,
		];
	}

	/**
	 * Resolve the operational recipient; empty means the WordPress site address.
	 *
	 * @return string Empty when neither address is valid.
	 */
	public static function recipient(): string {
		$settings = self::notifications();
		$email = '' !== $settings['operatorEmail'] ? $settings['operatorEmail'] : get_option('admin_email');
		return is_string($email) && is_email($email) ? $email : '';
	}

	/**
	 * Validate the Booking subtree before the shared site-settings resource writes.
	 *
	 * @param mixed $settings Submitted subtree.
	 * @return true|WP_Error Validation result.
	 */
	public static function validate($settings) {
		if (!is_array($settings)) {
			return new WP_Error('wphave_invalid_booking_settings', __('Booking settings must be an object.', 'wphave'), ['status' => 400]);
		}
		$notifications = $settings['notifications'] ?? [];
		if (!is_array($notifications)) {
			return new WP_Error('wphave_invalid_booking_notifications', __('Booking notifications must be an object.', 'wphave'), ['status' => 400]);
		}
		if (array_key_exists('operatorEmail', $notifications)) {
			$email = $notifications['operatorEmail'];
			if (!is_string($email) || strlen($email) > 254 || ('' !== trim($email) && !is_email(trim($email)))) {
				return new WP_Error('wphave_invalid_booking_email', __('Enter a valid appointment notification address.', 'wphave'), ['status' => 400]);
			}
		}
		if (array_key_exists('reminderHoursBefore', $notifications)) {
			$hours = $notifications['reminderHoursBefore'];
			if (!is_int($hours) || $hours < 2 || $hours > 168) {
				return new WP_Error('wphave_invalid_booking_reminder', __('Appointment reminders must be between 2 and 168 hours before the appointment.', 'wphave'), ['status' => 400]);
			}
		}
		$calendar = $settings['calendar'] ?? [];
		if (!is_array($calendar)) {
			return new WP_Error('wphave_invalid_booking_calendar', __('Booking calendar settings must be an object.', 'wphave'), ['status' => 400]);
		}
		$start = $calendar['startHour'] ?? 8;
		$end = $calendar['endHour'] ?? 18;
		if (!is_int($start) || !is_int($end) || $start < 0 || $end > 24 || $start >= $end) {
			return new WP_Error('wphave_invalid_booking_calendar_hours', __('Choose a calendar range between 00:00 and 24:00 with an end after the start.', 'wphave'), ['status' => 400]);
		}
		if (array_key_exists('showFullDay', $calendar) && !is_bool($calendar['showFullDay'])) {
			return new WP_Error('wphave_invalid_booking_calendar_mode', __('Choose whether the booking calendar shows all 24 hours.', 'wphave'), ['status' => 400]);
		}
		return true;
	}
}
