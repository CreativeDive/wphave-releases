<?php

/**
 * Compose the booking domain only while its release gate is open.
 *
 * This file owns WordPress hook wiring. Domain rules stay in the service,
 * repository, public flow, event and notification classes below.
 */

if (!defined('ABSPATH')) {
	exit();
}

require_once __DIR__ . '/availability.php';
require_once wphave_dir() . 'inc/features/security/crypto.php';
require_once __DIR__ . '/google-calendar.php';
require_once __DIR__ . '/provider-policy.php';
require_once __DIR__ . '/busy-source.php';
require_once __DIR__ . '/settings.php';
require_once wphave_dir() . 'inc/features/forms/spam-policy.php';
require_once __DIR__ . '/intake.php';
require_once __DIR__ . '/services.php';
require_once __DIR__ . '/events.php';
require_once __DIR__ . '/repository.php';
require_once __DIR__ . '/calendar-invite.php';
require_once __DIR__ . '/confirmation-template.php';
require_once __DIR__ . '/public.php';
require_once __DIR__ . '/management.php';
require_once __DIR__ . '/privacy.php';
require_once __DIR__ . '/notifications.php';
require_once __DIR__ . '/reminders.php';
require_once __DIR__ . '/audience.php';
require_once __DIR__ . '/rest-controller.php';

add_action('init', ['WPHAVE_Booking_Services', 'register']);
add_filter('wphave_dynamic_data_fields', ['WPHAVE_Booking_Confirmation_Template', 'fields']);
add_filter('wphave_dynamic_data_public_tokens', ['WPHAVE_Booking_Confirmation_Template', 'public_tokens']);

/** Schedule bounded audit cleanup; slot correctness never depends on cron timing. */

add_action('init', static function (): void {
	if (!wp_next_scheduled('wphave_booking_expire')) {
		wp_schedule_event(time() + HOUR_IN_SECONDS, 'hourly', 'wphave_booking_expire');
	}
});

/** Expire old holds and proposals using repository-owned transactions. */

add_action('wphave_booking_expire', static function (): void {
	(new WPHAVE_Booking_Repository())->expire();
	WPHAVE_Booking_Reminders::reconcile();
});

/** Deliver the exact scheduled interval only if it is still current. */
add_action('wphave_booking_reminder', ['WPHAVE_Booking_Reminders', 'send'], 10, 2);

/** Register the public shortcode after the appointment post type. */

add_action('init', static function (): void {
	add_shortcode('wphave_booking', ['WPHAVE_Booking_Public', 'render']);
});

/** Keep booking assets scoped to pages that render the public entry point. */

add_action('wp_enqueue_scripts', ['WPHAVE_Booking_Public', 'enqueue_assets']);

/** Render token review in the active theme when no booking block owns the page. */

add_action('template_redirect', ['WPHAVE_Booking_Public', 'review_page']);
add_action('add_meta_boxes', ['WPHAVE_Booking_Services', 'meta_box']);
add_action('save_post_' . WPHAVE_Booking_Services::POST_TYPE, ['WPHAVE_Booking_Services', 'save']);
add_action('admin_init', ['WPHAVE_Booking_Management', 'ensure_schema']);
add_action('admin_menu', ['WPHAVE_Booking_Management', 'register_page']);
add_action('admin_post_wphave_book', ['WPHAVE_Booking_Public', 'submit']);
add_action('admin_post_nopriv_wphave_book', ['WPHAVE_Booking_Public', 'submit']);
add_action('admin_post_wphave_booking_review', ['WPHAVE_Booking_Public', 'submit_review']);
add_action('admin_post_nopriv_wphave_booking_review', ['WPHAVE_Booking_Public', 'submit_review']);
add_action('admin_post_wphave_cancel_booking', ['WPHAVE_Booking_Management', 'cancel']);
add_action('admin_post_wphave_booking_google_connect', ['WPHAVE_Booking_Google_Calendar', 'connect']);
add_action('admin_post_wphave_booking_google_callback', ['WPHAVE_Booking_Google_Calendar', 'callback']);
add_action('admin_post_wphave_booking_google_disconnect', ['WPHAVE_Booking_Google_Calendar', 'disconnect']);
add_action('deleted_user', ['WPHAVE_Booking_Google_Calendar', 'remove_user']);
add_action('init', ['WPHAVE_Booking_Privacy', 'register'], 20);
add_action('rest_api_init', ['WPHAVE_Booking_REST_Controller', 'register']);
add_filter('wphave_audience_contact_detail', ['WPHAVE_Booking_Audience', 'enrich_contact'], 10, 3);
