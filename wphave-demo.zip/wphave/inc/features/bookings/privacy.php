<?php

/** WordPress personal-data export and erasure for booking attendees. */

final class WPHAVE_Booking_Privacy {

	/**
	 * Register WordPress personal-data export and erasure callbacks.
	 * @return void
	 */

	public static function register(): void {
		if (!class_exists('WPHAVE_Privacy_Manager')) {
			return;
		}

		WPHAVE_Privacy_Manager::register_exporter(
			'wphave-bookings',
			__('WPHAVE Appointments', 'wphave'),
			[__CLASS__, 'export'],
		);

		WPHAVE_Privacy_Manager::register_eraser(
			'wphave-bookings',
			__('WPHAVE Appointments', 'wphave'),
			[__CLASS__, 'erase'],
		);
	}

	/**
	 * Export an attendee’s bookings and their revisioned history.
	 *
	 * @param string $email_address Data-subject email address.
	 * @param int $page One-based export or erasure page.
	 * @return array<string, mixed>
	 */

	public static function export(string $email_address, int $page = 1): array {
		global $wpdb;
		$repository = new WPHAVE_Booking_Repository();

		if (!is_email($email_address)) {
			return ['data' => [], 'done' => true];
		}

		if (!$repository->ready()) {
			return ['data' => [], 'done' => false];
		}

		$table = $wpdb->prefix . 'wphave_bookings';
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, service_id, provider_id, starts_at, ends_at, attendee_name, attendee_email, intake_json, admin_note, status, contact_basis
				 FROM {$table} WHERE attendee_email = %s ORDER BY id ASC LIMIT 100 OFFSET %d",
				$email_address,
				max(0, $page - 1) * 100,
			),
			ARRAY_A,
		);

		if (!is_array($rows) || $wpdb->last_error) {
			return ['data' => [], 'done' => false];
		}

		$data = [];
		$events = $wpdb->prefix . 'wphave_booking_events';
		foreach ($rows as $row) {
			$provider = (int) $row['provider_id'] > 0 ? get_userdata((int) $row['provider_id']) : false;
			$history = $wpdb->get_results(
				$wpdb->prepare("SELECT kind, old_start, new_start, created_at, mail_status FROM {$events} WHERE booking_id = %d ORDER BY id ASC", $row['id']),
				ARRAY_A,
			);

			if (!is_array($history) || $wpdb->last_error) {
				return ['data' => [], 'done' => false];
			}

			$data[] = [
				'group_id' => 'wphave-bookings',
				'group_label' => __('WPHAVE Appointments', 'wphave'),
				'item_id' => 'appointment-' . (int) $row['id'],
				'data' => [
					['name' => __('Appointment type', 'wphave'), 'value' => get_the_title((int) $row['service_id'])],
					['name' => __('Provider', 'wphave'), 'value' => $provider ? $provider->display_name : ''],
					['name' => __('Start (UTC)', 'wphave'), 'value' => $row['starts_at']],
					['name' => __('End (UTC)', 'wphave'), 'value' => $row['ends_at']],
					['name' => __('Name', 'wphave'), 'value' => $row['attendee_name']],
					['name' => __('Email', 'wphave'), 'value' => $row['attendee_email']],
					['name' => __('Status', 'wphave'), 'value' => $row['status']],
					['name' => __('Contact basis', 'wphave'), 'value' => $row['contact_basis']],
					['name' => __('Appointment answers', 'wphave'), 'value' => $row['intake_json']],
					['name' => __('Internal appointment note', 'wphave'), 'value' => $row['admin_note']],
					['name' => __('Appointment history (UTC)', 'wphave'), 'value' => wp_json_encode($history)],
				],
			];
		}

		return ['data' => $data, 'done' => count($rows) < 100];
	}

	/**
	 * Remove attendee identity and event email snapshots without freeing booked time.
	 *
	 * @param string $email_address Data-subject email address.
	 * @param int $page One-based export or erasure page.
	 * @return array<string, mixed>
	 */

	public static function erase(string $email_address, int $page = 1): array {
		global $wpdb;
		$repository = new WPHAVE_Booking_Repository();

		if (!is_email($email_address)) {
			return [
				'items_removed' => false,
				'items_retained' => false,
				'messages' => [],
				'done' => true,
			];
		}

		if (!$repository->ready()) {
			return [
				'items_removed' => false,
				'items_retained' => true,
				'messages' => [__('Booking storage is unavailable; attendee data was not erased.', 'wphave')],
				'done' => true,
			];
		}

		$table = $wpdb->prefix . 'wphave_bookings';
		$events = $wpdb->prefix . 'wphave_booking_events';

		// Keep the occupied interval so erasure cannot create a double booking.
		// Revoke every bearer credential and unsent event recipient atomically;
		// otherwise an old email link could restore access after erasure.
		if (false === $wpdb->query('START TRANSACTION')) {
			return [
				'items_removed' => false,
				'items_retained' => true,
				'messages' => [__('Booking data could not be erased.', 'wphave')],
				'done' => true,
			];
		}

		$event_removed = $wpdb->query(
			$wpdb->prepare("UPDATE {$events} SET email_snapshot = '', mail_status = 'skipped', updated_at = %s WHERE email_snapshot = %s",
				gmdate('Y-m-d H:i:s'), $email_address),
		);

		$removed = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET attendee_name = '', attendee_email = '', intake_json = '[]', admin_note = '', return_url = '',
				 confirm_token_hash = '', confirm_expires_at = NULL, manage_token_hash = '',
				 proposal_token_hash = '', proposal_starts_at = NULL,
				 proposal_ends_at = NULL, proposal_expires_at = NULL, updated_at = %s
				 WHERE attendee_email = %s",
				gmdate('Y-m-d H:i:s'),
				$email_address,
			),
		);

		$committed = false;

		if (false === $removed || false === $event_removed) {
			$wpdb->query('ROLLBACK');
		} else {
			$committed = false !== $wpdb->query('COMMIT');
			if (!$committed) {
				$wpdb->query('ROLLBACK');
			}
		}

		return [
			'items_removed' => $committed && ($removed > 0 || $event_removed > 0),
			'items_retained' => !$committed,
			'messages' => !$committed
				? [__('Booking data could not be erased.', 'wphave')]
				: [],
			'done' => true,
		];
	}
}
