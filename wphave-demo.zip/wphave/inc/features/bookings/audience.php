<?php

/** Read-only bridge from existing Audience identities to appointments. */

final class WPHAVE_Booking_Audience {

	/**
	 * Add a read-only appointment projection to an authorized Audience contact detail.
	 *
	 * @param array $detail Authorized Audience contact detail payload.
	 * @param int $contact_id Audience contact ID.
	 * @param string $email Attendee email address.
	 * @return array<string, mixed>
	 */

	public static function enrich_contact(array $detail, int $contact_id, string $email): array {
		// Audience access alone never grants appointment visibility. This bridge
		// must honor the same Booking capability as the calendar and REST API.
		if (!current_user_can('wphave_manage_bookings') || !$contact_id || !is_email($email)) {
			return $detail;
		}
		$repository = new WPHAVE_Booking_Repository();
		if (!$repository->ready()) {
			return $detail;
		}
		$bookings = $repository->for_email($email);
		if (null === $bookings) {
			return $detail;
		}
		$detail['bookings'] = array_map(
			static fn(array $booking): array => array_merge($booking, [
				'title' => get_the_title((int) $booking['service_id']),
			]),
			$bookings,
		);
		return $detail;
	}
}
