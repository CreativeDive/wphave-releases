<?php

require_once wphave_dir() . 'inc/features/forms/submission/validator.php';

/** Bounded booking questions validated by the shared Forms field validator. */
final class WPHAVE_Booking_Intake {
	/**
	 * Normalize appointment-type questions; reject duplicate or unsafe keys.
	 *
	 * @param mixed $fields Untrusted policy field list.
	 * @return array<int, array{key: string, label: string, type: string, required: bool}>
	 */
	public static function validate_fields($fields): array {
		if (!is_array($fields) || count($fields) > 5) {
			throw new InvalidArgumentException('Invalid appointment questions.');
		}

		$normalized = [];
		$seen = [];
		foreach ($fields as $field) {
			if (!is_array($field) || !is_string($field['key'] ?? null) ||
				!is_string($field['label'] ?? null) || !is_string($field['type'] ?? null) ||
				!is_bool($field['required'] ?? null)) {
				throw new InvalidArgumentException('Invalid appointment question.');
			}
			$key = (string) ($field['key'] ?? '');
			$label = trim((string) ($field['label'] ?? ''));
			$type = (string) ($field['type'] ?? 'text');
			if (!preg_match('/^[a-z][a-z0-9_]{0,31}$/D', $key) || isset($seen[$key]) ||
				'' === $label || strlen($label) > 120 ||
				!in_array($type, ['text', 'textarea'], true)) {
				throw new InvalidArgumentException('Invalid appointment question.');
			}
			$seen[$key] = true;
			$normalized[] = [
				'key' => $key,
				'label' => $label,
				'type' => $type,
				'required' => !empty($field['required']),
			];
		}
		return $normalized;
	}

	/**
	 * Validate public answers with Forms and snapshot their labels for later
	 * export and operator mail even if the appointment policy changes.
	 *
	 * @param array<string, mixed> $policy Current validated service policy.
	 * @param array<string, mixed> $raw Untrusted submitted answers.
	 * @return string Bounded JSON snapshot.
	 */
	public static function capture(array $policy, array $raw): string {
		$fields = $policy['intake_fields'] ?? [];
		$schema = [];
		foreach ($fields as $field) {
			$schema[$field['key']] = [
				'type' => $field['type'],
				'required' => $field['required'],
				'attrs' => ['maxlength' => 'textarea' === $field['type'] ? 2000 : 500],
			];
		}
		if (array_diff_key($raw, $schema)) {
			throw new RuntimeException('Unknown appointment answers.');
		}
		$validated = WPHAVE_Form_Validator::validate($schema, $raw);
		if (!$validated['is_valid']) {
			throw new RuntimeException('Invalid appointment answers.');
		}

		$snapshot = [];
		foreach ($fields as $field) {
			$snapshot[] = [
				'key' => $field['key'],
				'label' => $field['label'],
				'value' => (string) ($validated['values'][$field['key']] ?? ''),
			];
		}
		$json = wp_json_encode($snapshot);
		if (!is_string($json) || strlen($json) > 8192) {
			throw new RuntimeException('Appointment answers are too large.');
		}
		return $json;
	}
}
