<?php

/** Build a minimal standards-compatible calendar attachment for booked intervals. */
final class WPHAVE_Booking_Calendar_Invite {
	/**
	 * Write a short-lived private ICS attachment. The caller must unlink it in a
	 * finally block immediately after wp_mail returns or throws.
	 *
	 * @param array<string, mixed> $booking Current booking row.
	 * @param array<string, mixed> $event Revisioned event row.
	 * @return string|null Temporary file path or null on filesystem failure.
	 */
	public static function attachment(array $booking, array $event): ?string {
		if (!in_array($event['kind'], ['created', 'confirmed', 'rescheduled', 'proposal_accepted', 'cancelled'], true)) {
			return null;
		}

		$path = tempnam(sys_get_temp_dir(), 'wphave-booking-');
		if (false === $path) {
			return null;
		}

		$calendar_path = $path . '.ics';
		if (!rename($path, $calendar_path)) {
			unlink($path);
			return null;
		}

		try {
			$content = self::contents($booking, $event);
			if (false === file_put_contents($calendar_path, $content, LOCK_EX)) {
				unlink($calendar_path);
				return null;
			}
			return $calendar_path;
		} catch (Throwable $error) {
			unlink($calendar_path);
			return null;
		}
	}

	/**
	 * Produce the same UID on create, move and cancel, with an increasing sequence.
	 *
	 * @param array<string, mixed> $booking Current booking row.
	 * @param array<string, mixed> $event Revisioned event row.
	 * @return string CRLF-delimited iCalendar data.
	 */
	public static function contents(array $booking, array $event): string {
		$host = wp_parse_url(home_url('/'), PHP_URL_HOST) ?: 'localhost';
		$start = new DateTimeImmutable($booking['starts_at'] . ' UTC');
		$end = new DateTimeImmutable($booking['ends_at'] . ' UTC');
		$service = WPHAVE_Booking_Services::get((int) $booking['service_id']);
		$provider = !empty($booking['provider_id']) ? get_userdata((int) $booking['provider_id']) : false;
		$description = (string) ($service['meeting_details'] ?? '');
		if ($provider) {
			$description .= ($description ? "\n" : '') . sprintf(__('Provider: %s', 'wphave'), $provider->display_name);
		}
		$lines = [
			'BEGIN:VCALENDAR',
			'VERSION:2.0',
			'PRODID:-//WPHAVE//Booking//EN',
			'CALSCALE:GREGORIAN',
			'METHOD:' . ('cancelled' === $event['kind'] ? 'CANCEL' : 'REQUEST'),
			'BEGIN:VEVENT',
			'UID:wphave-booking-' . (int) $booking['id'] . '-' . substr(hash('sha256', home_url('/')), 0, 12) .
				'@' . preg_replace('/[^a-z0-9.-]/i', '', $host),
			'DTSTAMP:' . gmdate('Ymd\THis\Z'),
			'DTSTART:' . $start->format('Ymd\THis\Z'),
			'DTEND:' . $end->format('Ymd\THis\Z'),
			'SEQUENCE:' . (int) $event['revision'],
			'STATUS:' . ('cancelled' === $event['kind'] ? 'CANCELLED' : 'CONFIRMED'),
			'SUMMARY:' . self::escape_text(wp_strip_all_tags(get_the_title((int) $booking['service_id']))),
			'DESCRIPTION:' . self::escape_text($description),
			'END:VEVENT',
			'END:VCALENDAR',
	];
		return implode("\r\n", array_map([__CLASS__, 'fold_line'], $lines)) . "\r\n";
	}

	/**
	 * Escape user-controlled content as iCalendar TEXT, never as a new property.
	 *
	 * @param string $value Plain text.
	 * @return string Escaped value.
	 */
	private static function escape_text(string $value): string {
		$value = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $value);
		return str_replace(
			["\\", ";", ",", "\r\n", "\r", "\n"],
			["\\\\", "\\;", "\\,", "\\n", "\\n", "\\n"],
			$value,
		);
	}

	/**
	 * Fold at a safe UTF-8 character boundary before the 75-octet line limit.
	 *
	 * @param string $line Unfolded content line.
	 * @return string CRLF-folded line.
	 */
	private static function fold_line(string $line): string {
		$characters = preg_split('//u', $line, -1, PREG_SPLIT_NO_EMPTY);
		if (false === $characters) {
			return '';
		}
		$folded = '';
		$bytes = 0;
		foreach ($characters as $character) {
			$length = strlen($character);
			if ($bytes + $length > 74) {
				$folded .= "\r\n ";
				$bytes = 1;
			}
			$folded .= $character;
			$bytes += $length;
		}
		return $folded;
	}
}
