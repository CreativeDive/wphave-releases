<?php

/** Combine stored reservations with optional external busy time before slot calculation. */
final class WPHAVE_Booking_Busy_Source {
	/**
	 * Recheck an already-held interval before a delayed attendee confirmation.
	 * The database hold prevents another WPHAVE booking; only external events
	 * can have appeared since the initial slot calculation. Provider failure
	 * must reject the transition rather than silently accepting stale free time.
	 *
	 * @param array $service Current validated appointment policy.
	 * @param string $start Stored UTC SQL start.
	 * @param string $end Stored UTC SQL end.
	 * @param int $provider_id Assigned provider, or zero for an unassigned service.
	 * @return void
	 */
	public static function assert_external_clear(array $service, string $start, string $end, int $provider_id = 0): void {
		$start_time = new DateTimeImmutable($start . ' UTC');
		$end_time = new DateTimeImmutable($end . ' UTC');
		$buffer = (int) $service['buffer_minutes'];
		$external = WPHAVE_Booking_Google_Calendar::busy(
			$start_time->modify('-' . $buffer . ' minutes'),
			$end_time->modify('+' . $buffer . ' minutes'),
			$provider_id,
		);

		if (WPHAVE_Booking_Availability::conflicts($start_time, $end_time, $buffer, $external)) {
			throw new RuntimeException('The external calendar now blocks this appointment.');
		}
	}

	/**
	 * Calculate slots with a fresh provider check on every read and final write.
	 * An active connection that cannot answer prevents publishing unverified free time.
	 *
	 * @param array $service Validated appointment-type policy.
	 * @param array $busy Stored occupied intervals.
	 * @param DateTimeImmutable $now Current UTC instant.
	 * @param int $provider_id Selected provider, or zero for an unassigned service.
	 * @return array Available UTC slots.
	 */
	public static function slots(array $service, array $busy, DateTimeImmutable $now, int $provider_id = 0): array {
		$service = WPHAVE_Booking_Provider_Policy::for_provider($service, $provider_id);
		$buffer = (int) ($service['buffer_minutes'] ?? 0);
		$from = $now->modify('-' . $buffer . ' minutes');
		$until = $now->modify('+' . (int) $service['horizon_days'] . ' days')->modify('+' . $buffer . ' minutes');
		$external = WPHAVE_Booking_Google_Calendar::busy($from, $until, $provider_id);
		return WPHAVE_Booking_Availability::slots($service, array_merge($busy, $external), $now);
	}
}
