/** Browser enhancement only; the server-rendered slot select remains authoritative. */
/**
 * Reveal the chosen server-rendered service/provider form without changing its
 * submitted identity or canonical slots. All forms remain usable without JS.
 * @param {Document|Element} root Search root, including editor previews.
 * @returns {void}
 */
const enhanceBookingChoices = (root = document) =>
	root.querySelectorAll('.wphave-booking-choices').forEach((choices) => {
		if (choices.dataset.choicesEnhanced === 'true') {
			return;
		}
		const serviceSelect = choices.querySelector('.wphave-booking-choices__service');
		const options = [...choices.querySelectorAll('.wphave-booking-choices__option')];
		const providers = [...choices.querySelectorAll('.wphave-booking-choices__providers')];
		if (!options.length) {
			return;
		}
		const update = () => {
			const serviceId = serviceSelect?.value || options[0].dataset.service;
			const providerGroup = providers.find((group) => group.dataset.service === serviceId);
			const providerId =
				providerGroup?.querySelector('input[type="radio"]:checked')?.value ||
				options.find((option) => option.dataset.service === serviceId)?.dataset.provider;
			providers.forEach((group) => {
				group.hidden = group.dataset.service !== serviceId;
			});
			options.forEach((option) => {
				option.hidden =
					option.dataset.service !== serviceId || option.dataset.provider !== providerId;
			});
		};
		serviceSelect?.addEventListener('change', update);
		providers.forEach((group) => group.addEventListener('change', update));
		update();
		choices.dataset.choicesEnhanced = 'true';
	});

/**
 * Enhance each server-rendered slot select with a small month calendar.
 * @param {Document|Element} root Search root, including editor previews.
 * @returns {void}
 */
const enhanceBookingForms = (root = document) =>
	root.querySelectorAll('.wphave-booking').forEach((form) => {
		if (form.dataset.bookingEnhanced === 'true') {
			return;
		}
		const dateField = form.querySelector('.wphave-booking__date-field');
		const dateSelect = form.querySelector('.wphave-booking__date');
		const calendar = form.querySelector('.wphave-booking__calendar');
		const slotSelect = form.querySelector('select[name="starts_at"]');
		if (!dateField || !dateSelect || !calendar || !slotSelect) {
			return;
		}

		const days = new Map();
		slotSelect.querySelectorAll('option[data-date]').forEach((option) => {
			const date = option.dataset.date;
			if (!days.has(date)) {
				days.set(date, {
					label: option.parentElement?.label || date,
					slots: []
				});
			}
			days.get(date).slots.push({
				value: option.value,
				label: option.dataset.time || option.textContent
			});
		});
		if (!days.size) {
			return;
		}

		for (const [date, day] of days) {
			const option = document.createElement('option');
			option.value = date;
			option.textContent = day.label;
			dateSelect.append(option);
		}

		/**
		 * Replace visible time options when the selected local date changes.
		 * @returns {void}
		 */
		const showDay = () => {
			const previous = slotSelect.value;
			const options = days.get(dateSelect.value)?.slots || [];
			slotSelect.replaceChildren(
				...options.map((slot) => {
					const option = document.createElement('option');
					option.value = slot.value;
					option.textContent = slot.label;
					return option;
				})
			);
			if (options.some((slot) => slot.value === previous)) {
				slotSelect.value = previous;
			}
		};

		dateSelect.addEventListener('change', showDay);
		showDay();

		const locale = document.documentElement.lang || undefined;
		const months = [...new Set([...days.keys()].map((date) => date.slice(0, 7)))];
		const monthFormatter = new Intl.DateTimeFormat(locale, {
			month: 'long',
			year: 'numeric',
			timeZone: 'UTC'
		});
		const dayFormatter = new Intl.DateTimeFormat(locale, {
			weekday: 'short',
			timeZone: 'UTC'
		});
		/**
		 * Build a stable UTC date for calendar labels and weekday alignment.
		 * @param {string} date Local calendar key in YYYY-MM-DD form.
		 * @returns {Date}
		 */
		const dateValue = (date) => new Date(`${date}T12:00:00Z`);
		let monthIndex = months.indexOf(dateSelect.value.slice(0, 7));

		/**
		 * Render the selected month with disabled days that have no slots.
		 * @returns {void}
		 */
		const renderCalendar = () => {
			const month = months[monthIndex];
			const first = dateValue(`${month}-01`);
			const numberOfDays = new Date(
				Date.UTC(first.getUTCFullYear(), first.getUTCMonth() + 1, 0)
			).getUTCDate();
			const offset = (first.getUTCDay() + 6) % 7;
			const header = document.createElement('div');
			header.className = 'wphave-booking__calendar-header';

			const previous = document.createElement('button');
			previous.type = 'button';
			previous.textContent = '‹';
			previous.disabled = monthIndex === 0;
			previous.setAttribute('aria-label', calendar.dataset.previousLabel || 'Previous month');
			previous.addEventListener('click', () => {
				monthIndex -= 1;
				renderCalendar();
			});

			const heading = document.createElement('strong');
			heading.textContent = monthFormatter.format(first);

			const next = document.createElement('button');
			next.type = 'button';
			next.textContent = '›';
			next.disabled = monthIndex === months.length - 1;
			next.setAttribute('aria-label', calendar.dataset.nextLabel || 'Next month');
			next.addEventListener('click', () => {
				monthIndex += 1;
				renderCalendar();
			});
			header.append(previous, heading, next);

			const grid = document.createElement('div');
			grid.className = 'wphave-booking__calendar-grid';
			for (let weekday = 0; weekday < 7; weekday += 1) {
				const label = document.createElement('span');
				label.className = 'wphave-booking__weekday';
				label.textContent = dayFormatter.format(new Date(Date.UTC(2026, 0, 5 + weekday)));
				grid.append(label);
			}
			for (let gap = 0; gap < offset; gap += 1) {
				grid.append(document.createElement('span'));
			}
			for (let day = 1; day <= numberOfDays; day += 1) {
				const date = `${month}-${String(day).padStart(2, '0')}`;
				const button = document.createElement('button');
				button.type = 'button';
				button.textContent = String(day);
				button.disabled = !days.has(date);
				button.setAttribute('aria-label', days.get(date)?.label || date);
				button.setAttribute('aria-pressed', String(date === dateSelect.value));
				button.addEventListener('click', () => {
					dateSelect.value = date;
					showDay();
					renderCalendar();
				});
				grid.append(button);
			}
			calendar.replaceChildren(header, grid);
		};

		renderCalendar();
		calendar.hidden = false;
		form.dataset.bookingEnhanced = 'true';
	});

window.wphaveEnhanceBookingForms = enhanceBookingForms;
window.wphaveEnhanceBookingChoices = enhanceBookingChoices;
enhanceBookingChoices();
enhanceBookingForms();
