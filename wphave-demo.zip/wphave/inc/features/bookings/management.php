<?php

/** Native management boundary for appointment types and reservations. */

final class WPHAVE_Booking_Management {

	/**
	 * Install missing booking storage for an authorized administrator.
	 * @return void
	 */

	public static function ensure_schema(): void {
		if (!current_user_can('manage_options')) {
			return;
		}

		$repository = new WPHAVE_Booking_Repository();

		if (!$repository->ready()) {
			$repository->install();
		}
	}

	/**
	 * Register the native WordPress appointment fallback page.
	 * @return void
	 */

	public static function register_page(): void {
		add_submenu_page(
			'edit.php?post_type=' . WPHAVE_Booking_Services::POST_TYPE,
			__('Appointments', 'wphave'),
			__('Appointments', 'wphave'),
			'wphave_manage_bookings',
			'wphave-bookings',
			[__CLASS__, 'render'],
		);
	}

	/**
	 * Render recent appointments and their latest notification states.
	 * @return void
	 */

	public static function render(): void {
		if (!current_user_can('wphave_manage_bookings')) {
			wp_die(esc_html__('You cannot manage appointments.', 'wphave'));
		}

		$repository = new WPHAVE_Booking_Repository();

		echo '<div class="wrap"><h1>' . esc_html__('Appointments', 'wphave') . '</h1>';

		if (!$repository->ready()) {
			echo '<p>' . esc_html__('Booking storage is unavailable. No appointments can be accepted.', 'wphave') . '</p></div>';
			return;
		}

		echo '<table class="widefat striped"><thead><tr>';

		foreach ([
			__('Type', 'wphave'),
			__('Start (UTC)', 'wphave'),
			__('Name', 'wphave'),
			__('Email', 'wphave'),
			__('Status', 'wphave'),
			__('Notification', 'wphave'),
			__('Operator notification', 'wphave'),
			__('Action', 'wphave'),
		] as $heading) {
			echo '<th scope="col">' . esc_html($heading) . '</th>';
		}
		echo '</tr></thead><tbody>';

		try {
			$bookings = $repository->list_recent();
		} catch (RuntimeException $error) {
			echo '<tr><td colspan="8">' . esc_html__('Appointments could not be loaded.', 'wphave') . '</td></tr>';
			$bookings = [];
		}

		foreach ($bookings as $booking) {
			$history = (new WPHAVE_Booking_Events())->latest((int) $booking['id']);
			echo '<tr><td>' . esc_html(get_the_title((int) $booking['service_id'])) . '</td>';
			echo '<td>' . esc_html($booking['starts_at']) . '</td>';
			echo '<td>' . esc_html($booking['attendee_name']) . '</td>';
			echo '<td>' . esc_html($booking['attendee_email']) . '</td>';
			echo '<td>' . esc_html($booking['status']) . '</td>';
			echo '<td>' . esc_html($history[0]['mail_status'] ?? 'none') . '</td>';
			echo '<td>' . esc_html($history[0]['host_mail_status'] ?? 'none') . '</td><td>';
			if ('confirmed' === $booking['status']) {
				echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
				echo '<input type="hidden" name="action" value="wphave_cancel_booking">';
				echo '<input type="hidden" name="id" value="' . esc_attr((string) $booking['id']) . '">';
				wp_nonce_field('wphave_cancel_booking_' . (int) $booking['id']);
				echo '<button type="submit" class="button-link">' . esc_html__('Cancel', 'wphave') . '</button></form>';
			}
			echo '</td></tr>';
		}
		echo '</tbody></table></div>';
	}

	/**
	 * Authorize and perform a native-admin cancellation before redirecting.
	 * @return void
	 */

	public static function cancel(): void {
		$id = absint($_POST['id'] ?? 0);

		if (
			'POST' !== ($_SERVER['REQUEST_METHOD'] ?? '') ||
			!current_user_can('wphave_manage_bookings') ||
			!check_admin_referer('wphave_cancel_booking_' . $id)
		) {
			wp_die(esc_html__('Appointment cancellation was not authorized.', 'wphave'));
		}

		if ((new WPHAVE_Booking_Repository())->cancel($id)) {
			WPHAVE_Booking_Notifications::cancellation($id);
		}

		wp_safe_redirect(admin_url('edit.php?post_type=' . WPHAVE_Booking_Services::POST_TYPE . '&page=wphave-bookings'));

		exit();
	}
}
