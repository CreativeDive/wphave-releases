<?php

/** Authenticated workspace API for appointment setup and management. */

final class WPHAVE_Booking_REST_Controller {

	/**
	 * Register capability-protected appointment management endpoints.
	 * @return void
	 */

	public static function register(): void {
		$permission = static fn(): bool => current_user_can('wphave_manage_bookings');
		$id_args = [
			'id' => ['type' => 'integer', 'minimum' => 1, 'required' => true],
		];
		$service_args = [
			'title' => ['type' => 'string', 'required' => true],
			'status' => ['type' => 'string', 'enum' => ['draft', 'publish'], 'required' => true],
			'policy' => ['type' => 'object', 'required' => true],
		];
		$time_args = [
			'starts_at' => ['type' => 'string', 'required' => true],
			'revision' => ['type' => 'integer', 'minimum' => 1, 'required' => true],
		];

		register_rest_route('wphave/v1', '/bookings/published-types', [
			'methods' => WP_REST_Server::READABLE,
			'callback' => [__CLASS__, 'published_types'],
			'permission_callback' => static fn(): bool => current_user_can('edit_posts'),
		]);

		register_rest_route('wphave/v1', '/bookings/overview', [
			'methods' => WP_REST_Server::READABLE,
			'callback' => [__CLASS__, 'overview'],
			'permission_callback' => $permission,
		]);

		register_rest_route('wphave/v1', '/bookings/providers', [
			'methods' => WP_REST_Server::READABLE,
			'callback' => [__CLASS__, 'providers'],
			'permission_callback' => $permission,
		]);

		register_rest_route('wphave/v1', '/bookings/calendar', [
			'methods' => WP_REST_Server::READABLE,
			'callback' => [__CLASS__, 'calendar'],
			'permission_callback' => $permission,
		]);

		register_rest_route('wphave/v1', '/bookings/availability', [
			'methods' => WP_REST_Server::READABLE,
			'callback' => [__CLASS__, 'availability'],
			'permission_callback' => $permission,
		]);

		register_rest_route('wphave/v1', '/bookings/calendar-connection', [
			'methods' => WP_REST_Server::READABLE,
			'callback' => [__CLASS__, 'calendar_connection'],
			'permission_callback' => $permission,
		]);

		register_rest_route('wphave/v1', '/bookings/services', [
			'methods' => WP_REST_Server::CREATABLE,
			'callback' => [__CLASS__, 'create_service'],
			'permission_callback' => $permission,
			'args' => $service_args,
		]);

		register_rest_route('wphave/v1', '/bookings/services/(?P<id>\d+)', [
			'methods' => WP_REST_Server::EDITABLE,
			'callback' => [__CLASS__, 'update_service'],
			'permission_callback' => $permission,
			'args' => array_merge($id_args, $service_args),
		]);

		register_rest_route('wphave/v1', '/bookings/(?P<id>\d+)/cancel', [
			'methods' => WP_REST_Server::CREATABLE,
			'callback' => [__CLASS__, 'cancel'],
			'permission_callback' => $permission,
			'args' => $id_args,
		]);

		register_rest_route('wphave/v1', '/bookings/appointments', [
			'methods' => WP_REST_Server::CREATABLE,
			'callback' => [__CLASS__, 'create_appointment'],
			'permission_callback' => $permission,
			'args' => [
				'service_id' => ['type' => 'integer', 'minimum' => 1, 'required' => true],
				'provider_id' => ['type' => 'integer', 'minimum' => 0, 'default' => 0],
				'starts_at' => ['type' => 'string', 'required' => true],
				'attendee_name' => ['type' => 'string', 'required' => true],
				'attendee_email' => ['type' => 'string', 'format' => 'email', 'required' => true],
				'contact_basis' => [
					'type' => 'string',
					'enum' => ['requested_by_attendee', 'agreed_elsewhere'],
					'required' => true,
				],
				'notify' => ['type' => 'boolean', 'default' => false],
			],
		]);

		register_rest_route('wphave/v1', '/bookings/(?P<id>\d+)/note', [
			'methods' => WP_REST_Server::EDITABLE,
			'callback' => [__CLASS__, 'update_note'],
			'permission_callback' => $permission,
			'args' => array_merge($id_args, [
				'note' => ['type' => 'string', 'required' => true],
				'previous' => ['type' => 'string', 'required' => true],
			]),
		]);

		register_rest_route('wphave/v1', '/bookings/(?P<id>\d+)/reschedule', [
			'methods' => WP_REST_Server::CREATABLE,
			'callback' => [__CLASS__, 'reschedule'],
			'permission_callback' => $permission,
			'args' => array_merge($id_args, $time_args, [
				'agreed' => ['type' => 'boolean', 'required' => true],
			]),
		]);

		register_rest_route('wphave/v1', '/bookings/(?P<id>\d+)/propose', [
			'methods' => WP_REST_Server::CREATABLE,
			'callback' => [__CLASS__, 'propose'],
			'permission_callback' => $permission,
			'args' => array_merge($id_args, $time_args),
		]);
	}

	/**
	 * List published type IDs and titles for the block editor.
	 * @return array
	 */

	public static function published_types(): array {
		$posts = get_posts([
			'post_type' => WPHAVE_Booking_Services::POST_TYPE,
			'post_status' => 'publish',
			'numberposts' => 100,
		]);

		$types = [];
		foreach ($posts as $post) {
			if (WPHAVE_Booking_Services::get((int) $post->ID)) {
				$types[] = [
					'id' => (int) $post->ID,
					'title' => $post->post_title,
				];
			}
		}

		return ['services' => $types];
	}

	/**
	 * Search users for service assignment without exposing account emails.
	 *
	 * @param WP_REST_Request $request Authenticated search and selected IDs.
	 * @return array<string, array<int, array<string, int|string>>>
	 */
	public static function providers(WP_REST_Request $request): array {
		$search = sanitize_text_field((string) $request->get_param('search'));
		$args = ['number' => 50, 'orderby' => 'display_name', 'order' => 'ASC'];
		if ('' !== $search) {
			$args['search'] = '*' . substr($search, 0, 50) . '*';
			$args['search_columns'] = ['display_name', 'user_login'];
		}
		$users = get_users($args);
		$included = array_slice(
			array_unique(array_filter(array_map('absint', explode(',', (string) $request->get_param('include'))))),
			0,
			20,
		);
		foreach ($included as $id) {
			$user = get_userdata($id);
			if ($user) {
				$users[] = $user;
			}
		}
		$providers = [];
		foreach ($users as $user) {
			$providers[$user->ID] = [
				'id' => (int) $user->ID,
				'name' => $user->display_name,
				'avatar' => (string) get_avatar_url($user->ID, ['size' => 40]),
			];
		}
		return ['providers' => array_values($providers)];
	}

	/**
	 * Return canonical free slots for one appointment type.
	 *
	 * @param WP_REST_Request $request Authenticated REST request.
	 * @return array|WP_Error
	 */

	public static function availability(WP_REST_Request $request) {
		$id = absint($request->get_param('service_id'));
		$provider_id = absint($request->get_param('provider_id'));
		$service = WPHAVE_Booking_Services::get($id);
		$exclude_id = absint($request->get_param('exclude_id'));
		$existing = $exclude_id ? (new WPHAVE_Booking_Repository())->get($exclude_id) : null;
		// Existing reservations retain their provider assignment if a service's
		// provider list changes; only a new reservation needs current membership.
		$stored_assignment = $existing && (int) $existing['service_id'] === $id &&
			(int) $existing['provider_id'] === $provider_id;

		if (!$service || (($service['provider_ids'] ?? [])
			? !in_array($provider_id, $service['provider_ids'], true) && !$stored_assignment
			: 0 !== $provider_id)) {
			return new WP_Error('wphave_booking_type_missing', __('Appointment type not found.', 'wphave'), ['status' => 404]);
		}

		try {
			$now = new DateTimeImmutable('now', new DateTimeZone('UTC'));
			$busy = (new WPHAVE_Booking_Repository())->busy($id, $now->format('Y-m-d H:i:s'),
				$now->modify('+' . $service['horizon_days'] . ' days')->format('Y-m-d H:i:s'), $exclude_id, $provider_id);
			return ['slots' => WPHAVE_Booking_Busy_Source::slots($service, $busy, $now, $provider_id), 'timezone' => $service['timezone']];
		} catch (Throwable $error) {
			return new WP_Error('wphave_booking_availability_failed', __('Available times could not be loaded.', 'wphave'), ['status' => 503]);
		}
	}

	/**
	 * Return connection state without exposing OAuth credentials.
	 * @return array<string, bool|string>
	 */
	public static function calendar_connection(?WP_REST_Request $request = null): array {
		$provider_id = $request ? absint($request->get_param('provider_id')) : 0;
		return WPHAVE_Booking_Google_Calendar::status($provider_id);
	}

	/**
	 * Read a validated and bounded booking calendar range.
	 *
	 * @param WP_REST_Request $request Authenticated REST request.
	 * @return array|WP_Error
	 */

	public static function calendar(WP_REST_Request $request) {
		$from = (string) $request->get_param('from');
		$until = (string) $request->get_param('until');
		$zone = new DateTimeZone('UTC');
		$start = DateTimeImmutable::createFromFormat('!Y-m-d', $from, $zone);
		$end = DateTimeImmutable::createFromFormat('!Y-m-d', $until, $zone);

		if (
			!$start || !$end ||
			$start->format('Y-m-d') !== $from ||
			$end->format('Y-m-d') !== $until ||
			$end <= $start ||
			(int) $start->diff($end)->days > 45
		) {
			return new WP_Error(
				'wphave_booking_calendar_range_invalid',
				__('Select a valid calendar range of at most 45 days.', 'wphave'),
				['status' => 400],
			);
		}

		try {
			return ['bookings' => self::with_provider_names((new WPHAVE_Booking_Repository())->list_for_range($from, $until))];
		} catch (OverflowException $error) {
			return new WP_Error(
				'wphave_booking_calendar_range_too_large',
				__('This calendar range contains too many appointments. Choose a shorter view.', 'wphave'),
				['status' => 413],
			);
		} catch (RuntimeException $error) {
			return new WP_Error(
				'wphave_booking_calendar_read_failed',
				__('Appointments could not be loaded.', 'wphave'),
				['status' => 503],
			);
		}
	}

	/**
	 * Return appointment types and recent bookings to the Workspace.
	 * @return array|WP_Error
	 */

	public static function overview() {
		$repository = new WPHAVE_Booking_Repository();

		// Schema writes stay with the administrator installation boundary.
		if (!$repository->ready() && current_user_can('manage_options')) {
			$repository->install();
		}

		if (!$repository->ready()) {
			return new WP_Error('wphave_booking_storage_unavailable', __('Booking storage is unavailable.', 'wphave'), ['status' => 503]);
		}

		$posts = get_posts([
			'post_type' => WPHAVE_Booking_Services::POST_TYPE,
			'post_status' => ['publish', 'draft'],
			'numberposts' => 100,
		]);

		$services = [];
		foreach ($posts as $post) {
			$services[] = [
				'id' => $post->ID,
				'title' => $post->post_title,
				'status' => $post->post_status,
				'policy' => get_post_meta($post->ID, '_wphave_booking_policy', true) ?: null,
				'shortcode' => '[wphave_booking id="' . $post->ID . '"]',
			];
		}

		try {
			$bookings = $repository->list_recent();
			$summary = $repository->summary();
		} catch (RuntimeException $error) {
			return new WP_Error('wphave_booking_read_failed', __('Appointments could not be loaded.', 'wphave'), ['status' => 503]);
		}
		$service_counts = wp_count_posts(WPHAVE_Booking_Services::POST_TYPE);
		$summary['published_services'] = (int) ($service_counts->publish ?? 0);

		return [
			'ready' => $repository->ready(),
			'timezone' => wp_timezone_string() ?: 'UTC',
			'services' => $services,
			'bookings' => self::with_provider_names($bookings),
			'summary' => $summary,
		];
	}

	/**
	 * Add only the public display name of an assigned user to Workspace rows.
	 * Booking transport must never include user emails or internal token columns.
	 *
	 * @param array<int, array<string, mixed>> $bookings Safe repository projection.
	 * @return array<int, array<string, mixed>>
	 */
	private static function with_provider_names(array $bookings): array {
		foreach ($bookings as &$booking) {
			$provider = !empty($booking['provider_id']) ? get_userdata((int) $booking['provider_id']) : false;
			$booking['provider_name'] = $provider ? $provider->display_name : '';
		}
		unset($booking);
		return $bookings;
	}

	/**
	 * Create a validated appointment type and policy.
	 *
	 * @param WP_REST_Request $request Authenticated REST request.
	 * @return array|WP_Error
	 */

	public static function create_service(WP_REST_Request $request) {
		$validated = self::validate_request($request);

		if (is_wp_error($validated)) {
			return $validated;
		}

		$post_id = wp_insert_post([
			'post_type' => WPHAVE_Booking_Services::POST_TYPE,
			'post_status' => $validated['status'],
			'post_title' => $validated['title'],
		], true);

		if (is_wp_error($post_id) || !$post_id) {
			return new WP_Error('wphave_booking_create_failed', __('Appointment type could not be created.', 'wphave'), ['status' => 500]);
		}

		if (!update_post_meta($post_id, '_wphave_booking_policy', $validated['policy'])) {
			wp_delete_post($post_id, true);
			return new WP_Error('wphave_booking_policy_failed', __('Appointment policy could not be saved.', 'wphave'), ['status' => 500]);
		}

		return ['id' => $post_id];
	}

	/**
	 * Update a type while preserving its previous policy on failure.
	 *
	 * @param WP_REST_Request $request Authenticated REST request.
	 * @return array|WP_Error
	 */

	public static function update_service(WP_REST_Request $request) {
		$id = absint($request['id']);
		$post = get_post($id);

		if (!$post || WPHAVE_Booking_Services::POST_TYPE !== $post->post_type) {
			return new WP_Error('wphave_booking_type_missing', __('Appointment type not found.', 'wphave'), ['status' => 404]);
		}

		$validated = self::validate_request($request);

		if (is_wp_error($validated)) {
			return $validated;
		}

		$old_policy = get_post_meta($id, '_wphave_booking_policy', true);
		$stored = update_post_meta($id, '_wphave_booking_policy', $validated['policy']);

		if (!$stored && $old_policy !== $validated['policy']) {
			return new WP_Error('wphave_booking_policy_failed', __('Appointment policy could not be saved.', 'wphave'), ['status' => 500]);
		}

		$result = wp_update_post([
			'ID' => $id,
			'post_title' => $validated['title'],
			'post_status' => $validated['status'],
		], true);

		if (is_wp_error($result)) {
			update_post_meta($id, '_wphave_booking_policy', $old_policy);
			return $result;
		}

		return ['id' => $id];
	}

	/**
	 * Save an internal note after checking the editor's previous value.
	 *
	 * @param WP_REST_Request $request Authenticated REST request.
	 * @return array|WP_Error
	 */

	public static function update_note(WP_REST_Request $request) {
		$note = sanitize_textarea_field((string) $request['note']);
		$previous = (string) $request['previous'];
		if (strlen($note) > 4000 || strlen($previous) > 4000) {
			return new WP_Error('wphave_booking_note_too_long', __('The note is too long.', 'wphave'), ['status' => 400]);
		}
		if (!(new WPHAVE_Booking_Repository())->update_note(absint($request['id']), $note, $previous)) {
			return new WP_Error('wphave_booking_note_conflict', __('The note changed or this appointment is no longer available. Reload the calendar.', 'wphave'), ['status' => 409]);
		}
		return ['note' => $note];
	}

	/**
	 * Cancel one appointment and report independent notice acceptance.
	 * @param WP_REST_Request $request Authorized booking ID.
	 * @return array|WP_Error Cancellation result.
	 */
	public static function cancel(WP_REST_Request $request) {
		$id = absint($request['id']);

		if (!(new WPHAVE_Booking_Repository())->cancel($id)) {
			return new WP_Error('wphave_booking_cancel_failed', __('Appointment could not be cancelled.', 'wphave'), ['status' => 409]);
		}

		$notified = WPHAVE_Booking_Notifications::latest($id);

		return [
			'cancelled' => true,
			'notification_accepted' => $notified,
			'host_notification_accepted' => WPHAVE_Booking_Notifications::host_status($id),
		];
	}

	/**
	 * Create an agreed administrator booking and optional notice.
	 *
	 * @param WP_REST_Request $request Authenticated REST request.
	 * @return array|WP_Error
	 */

	public static function create_appointment(WP_REST_Request $request) {
		$service_id = absint($request->get_param('service_id'));
		$provider_id = absint($request->get_param('provider_id'));
		$service = WPHAVE_Booking_Services::get($service_id);
		$start = self::start($request);
		$name = sanitize_text_field((string) $request->get_param('attendee_name'));
		$raw_email = (string) $request->get_param('attendee_email');
		$email = sanitize_email($raw_email);
		$basis = sanitize_key((string) $request->get_param('contact_basis'));

		if (!$service || !$start || '' === $name || strlen($name) > 190 ||
			!is_email($email) || $email !== $raw_email || strlen($email) > 190 ||
			!in_array($basis, ['requested_by_attendee', 'agreed_elsewhere'], true)) {
			return new WP_Error('wphave_booking_invalid', __('Invalid appointment details.', 'wphave'), ['status' => 400]);
		}

		try {
			$notify = rest_sanitize_boolean($request->get_param('notify'));
			$created = false;
			$id = (new WPHAVE_Booking_Repository())->reserve(
				$service_id, $start, $name, $email, wp_generate_uuid4(),
				'confirmed', '', null, 'admin', $basis, $notify, '', $created, [], $provider_id
			);
			$notified = $notify ? WPHAVE_Booking_Notifications::latest($id) : null;
			if (!$notify) {
				WPHAVE_Booking_Notifications::host_latest($id);
				WPHAVE_Booking_Reminders::schedule($id);
			}

			return [
				'id' => $id,
				'notification_accepted' => $notified,
				'host_notification_accepted' => WPHAVE_Booking_Notifications::host_status($id),
			];
		} catch (Throwable $error) {
			// Storage and provider exception text must not become an API response,
			// including for a delegated Booking manager.
			return new WP_Error('wphave_booking_create_failed',
				__('Appointment could not be created. Check the selected time and try again.', 'wphave'),
				['status' => 409]);
		}
	}

	/**
	 * Apply an agreed direct move with optimistic revision checking.
	 *
	 * @param WP_REST_Request $request Authenticated REST request.
	 * @return array|WP_Error
	 */

	public static function reschedule(WP_REST_Request $request) {
		$id = absint($request['id']);
		$start = self::start($request);
		$revision = absint($request->get_param('revision'));

		if (!$start || !$revision || true !== $request->get_param('agreed')) {
			return new WP_Error('wphave_booking_invalid', __('Confirm that the new time was agreed.', 'wphave'), ['status' => 400]);
		}

		if (!(new WPHAVE_Booking_Repository())->reschedule($id, $start, $revision)) {
			return new WP_Error('wphave_booking_conflict', __('Appointment changed or time is unavailable.', 'wphave'), ['status' => 409]);
		}

		$notified = WPHAVE_Booking_Notifications::latest($id);

		return [
			'id' => $id,
			'notification_accepted' => $notified,
			'host_notification_accepted' => WPHAVE_Booking_Notifications::host_status($id),
		];
	}

	/**
	 * Offer a new time and revoke its hold if mail is rejected.
	 *
	 * @param WP_REST_Request $request Authenticated REST request.
	 * @return array|WP_Error
	 */

	public static function propose(WP_REST_Request $request) {
		$id = absint($request['id']);
		$start = self::start($request);
		$revision = absint($request->get_param('revision'));

		if (!$start || !$revision) {
			return new WP_Error('wphave_booking_invalid', __('Invalid proposed time.', 'wphave'), ['status' => 400]);
		}

		$token = bin2hex(random_bytes(32));
		$expires = gmdate('Y-m-d H:i:s', time() + 7 * DAY_IN_SECONDS);

		if (!(new WPHAVE_Booking_Repository())->propose_reschedule($id, $start, $revision, hash('sha256', $token), $expires)) {
			return new WP_Error('wphave_booking_conflict', __('Appointment changed or time is unavailable.', 'wphave'), ['status' => 409]);
		}

		if (!WPHAVE_Booking_Notifications::latest($id, $token, home_url('/'))) {
			(new WPHAVE_Booking_Repository())->revoke_proposal($id, $revision + 1);
			return new WP_Error('wphave_booking_proposal_mail_failed',
				__('The proposal email could not be sent. The original appointment remains unchanged.', 'wphave'), ['status' => 502]);
		}

		return ['id' => $id];
	}

	/**
	 * Validate a strict UTC instant supplied by the Workspace.
	 *
	 * @param WP_REST_Request $request Authenticated REST request.
	 * @return string|null
	 */

	private static function start(WP_REST_Request $request): ?string {
		$value = (string) $request->get_param('starts_at');

		if (!preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/D', $value)) {
			return null;
		}

		$date = DateTimeImmutable::createFromFormat('!Y-m-d\TH:i:s\Z', $value, new DateTimeZone('UTC'));

		return $date && $date->format('Y-m-d\TH:i:s\Z') === $value ? $date->format('Y-m-d H:i:s') : null;
	}

	/**
	 * Normalize and validate an appointment type request.
	 *
	 * @param WP_REST_Request $request Authenticated REST request.
	 * @return array|WP_Error
	 */

	private static function validate_request(WP_REST_Request $request) {
		$title = sanitize_text_field((string) $request->get_param('title'));
		$status = sanitize_key((string) $request->get_param('status'));
		$policy = $request->get_param('policy');

		if ('' === $title || strlen($title) > 190 || !in_array($status, ['draft', 'publish'], true)) {
			return new WP_Error('wphave_booking_type_invalid', __('Invalid appointment type.', 'wphave'), ['status' => 400]);
		}

		try {
			$policy = WPHAVE_Booking_Services::validate(is_array($policy) ? $policy : []);
		} catch (Throwable $error) {
			return new WP_Error('wphave_booking_policy_invalid', __('Invalid appointment policy.', 'wphave'), ['status' => 400]);
		}

		return ['title' => $title, 'status' => $status, 'policy' => $policy];
	}
}
