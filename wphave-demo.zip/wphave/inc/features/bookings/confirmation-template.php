<?php

/** Public appointment review content in the shared Templates and Dynamic Data systems. */

if (!defined('ABSPATH')) {
	exit();
}

final class WPHAVE_Booking_Confirmation_Template {
	/** Add request-scoped Booking values to the shared field registry. */
	public static function fields(array $fields): array {
		foreach (['state', 'title', 'message', 'action_label', 'action_url'] as $field) {
			$fields['booking']['confirmation_' . $field] = [
				'callback' => static fn() => WPHAVE_Dynamic_Data_Runtime_Context::get(
					'booking.confirmation.' . $field,
					self::default_value($field),
				),
			];
		}

		return $fields;
	}

	/** Public templates may resolve only these non-sensitive review values. */
	public static function public_tokens(array $tokens): array {
		foreach (['state', 'title', 'message', 'action_label', 'action_url'] as $field) {
			$tokens['booking.confirmation.' . $field] = [
				'source' => 'booking',
				'field' => 'confirmation_' . $field,
			];
		}

		return $tokens;
	}

	/** Provide useful, non-sensitive values while editing the system template. */
	private static function default_value(string $field): string {
		return match ($field) {
			'state' => 'pending',
			'title' => __('Confirm your appointment', 'wphave'),
			'message' => __('Choose Confirm to complete your appointment booking.', 'wphave'),
			'action_label' => __('Back to website', 'wphave'),
			'action_url' => home_url('/'),
			default => '',
		};
	}

	/**
	 * Render a customizable, read-only review before the separate POST form.
	 *
	 * @param string $action Confirmation or proposal acceptance.
	 * @return string Escaped block output.
	 */
	public static function render(string $action): string {
		$title = match ($action) {
			'proposal' => __('Accept new appointment time', 'wphave'),
			'confirmed' => __('Appointment confirmed', 'wphave'),
			'cancelled' => __('Appointment cancelled', 'wphave'),
			default => __('Confirm your appointment', 'wphave'),
		};
		$message = match ($action) {
			'proposal' => __('Review the proposed time and choose Accept to complete the change.', 'wphave'),
			'confirmed' => __('Your appointment is booked. Please keep the time you selected.', 'wphave'),
			'cancelled' => __('Your appointment was cancelled.', 'wphave'),
			default => __('Choose Confirm to complete your appointment booking.', 'wphave'),
		};

		// BEARER INVARIANT: Public template tokens never include the email token or
		// attendee details. Opening the link only renders content; the form owns POST.
		WPHAVE_Dynamic_Data_Runtime_Context::set('booking.confirmation', [
			'state' => in_array($action, ['confirmed', 'cancelled'], true) ? $action : 'pending',
			'title' => $title,
			'message' => $message,
			'action_label' => __('Back to website', 'wphave'),
			'action_url' => home_url('/'),
		]);

		$template = class_exists('WPHAVE_Templates')
			? WPHAVE_Templates::custom_template('booking_confirmation')
			: false;
		$content = is_array($template) && !empty($template['template_content'])
			? $template['template_content']
			: wphave_basic_template_content('booking_confirmation');

		if (class_exists('WPHAVE_Dynamic_Data')) {
			$content = WPHAVE_Dynamic_Data::instance()->resolve_public_tokens_in_block_content($content);
		}

		return do_blocks($content);
	}
}
