<?php

/** Durable booking transitions and at-most-once notification claims. */

final class WPHAVE_Booking_Events {
	private string $table;

	/**
	 * Resolve the event table from WordPress's database prefix.
	 * The shared $wpdb connection is supplied by WordPress.
	 */

	public function __construct() {
		global $wpdb;
		$this->table = $wpdb->prefix . 'wphave_booking_events';
	}

	/**
	 * Install the durable booking event table.
	 * @return bool
	 */

	public function install(): bool {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset = $wpdb->get_charset_collate();
		$sql = "CREATE TABLE {$this->table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			booking_id bigint(20) unsigned NOT NULL,
			revision bigint(20) unsigned NOT NULL,
			kind varchar(32) NOT NULL,
			actor_id bigint(20) unsigned NOT NULL DEFAULT 0,
			old_start datetime NULL,
			new_start datetime NULL,
			email_snapshot varchar(190) NOT NULL DEFAULT '',
			mail_status varchar(20) NOT NULL DEFAULT 'pending',
			host_mail_status varchar(20) NOT NULL DEFAULT 'skipped',
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY booking_revision_kind (booking_id,revision,kind),
			KEY booking_history (booking_id,id)
		) ENGINE=InnoDB {$charset};";

		dbDelta($sql);
		return $this->ready();
	}

	/**
	 * Confirm that the event table supports transactional event and mail state.
	 * @return bool
	 */

	public function ready(): bool {
		global $wpdb;
		$engine = $wpdb->get_var(
			$wpdb->prepare(
				'SELECT ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s',
				$this->table,
			),
		);

		if ('InnoDB' !== $engine) {
			return false;
		}

		$columns = $wpdb->get_col(
			$wpdb->prepare(
				'SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND COLUMN_NAME IN (%s, %s, %s, %s)',
				$this->table,
				'revision',
				'kind',
				'mail_status',
				'host_mail_status',
			),
		);

		return count($columns) === 4;
	}

	/**
	 * Write a revisioned event inside its booking transition transaction.
	 * The caller must roll back the booking transition if this insert fails.
	 *
	 * @param int $booking_id Booking ID.
	 * @param int $revision New booking revision.
	 * @param string $kind Transition event kind.
	 * @param string|null $old_start Previous UTC start, when applicable.
	 * @param string|null $new_start New UTC start, when applicable.
	 * @param string $email Attendee email address.
	 * @param bool $notify Whether to attempt a transactional notice.
	 * @return int
	 */

	public function record(
		int $booking_id,
		int $revision,
		string $kind,
		?string $old_start,
		?string $new_start,
		string $email,
		bool $notify,
	): int {
		global $wpdb;
		$now = gmdate('Y-m-d H:i:s');
		$inserted = $wpdb->insert(
			$this->table,
			[
				'booking_id' => $booking_id,
				'revision' => $revision,
				'kind' => $kind,
				'actor_id' => get_current_user_id(),
				'old_start' => $old_start,
				'new_start' => $new_start,
				'email_snapshot' => $email,
				'mail_status' => $notify ? 'pending' : 'skipped',
				'host_mail_status' => (
					in_array($kind, ['created', 'confirmed', 'rescheduled', 'proposal_accepted'], true) ||
					('cancelled' === $kind && $notify)
				) ? 'pending' : 'skipped',
				'created_at' => $now,
				'updated_at' => $now,
			],
			['%d', '%d', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s'],
		);

		if (1 !== $inserted) {
			throw new RuntimeException('Booking event could not be recorded.');
		}

		return (int) $wpdb->insert_id;
	}

	/**
	 * Atomically claim the current host notice once, independently of attendee mail.
	 *
	 * @param int $id Event ID.
	 * @return array<string, mixed>|null Claimed event.
	 */
	public function claim_host(int $id): ?array {
		global $wpdb;
		if (1 !== $wpdb->update(
			$this->table,
			['host_mail_status' => 'sending', 'updated_at' => gmdate('Y-m-d H:i:s')],
			['id' => $id, 'host_mail_status' => 'pending'],
			['%s', '%s'],
			['%d', '%s'],
		)) {
			return null;
		}

		return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table} WHERE id = %d", $id), ARRAY_A);
	}

	/**
	 * Persist the host transport outcome without reissuing an ambiguous send.
	 *
	 * @param int $id Event ID.
	 * @param bool $accepted Whether WordPress accepted the message.
	 * @return void
	 */
	public function finish_host(int $id, bool $accepted): void {
		global $wpdb;
		$wpdb->update(
			$this->table,
			['host_mail_status' => $accepted ? 'accepted' : 'unknown', 'updated_at' => gmdate('Y-m-d H:i:s')],
			['id' => $id, 'host_mail_status' => 'sending'],
			['%s', '%s'],
			['%d', '%s'],
		);
	}

	/**
	 * Atomically claim one pending event for a single mail attempt.
	 *
	 * @param int $id Internal record ID.
	 * @return array<string, mixed>|null
	 */

	public function claim(int $id): ?array {
		global $wpdb;
		$claimed = $wpdb->update(
			$this->table,
			['mail_status' => 'sending', 'updated_at' => gmdate('Y-m-d H:i:s')],
			['id' => $id, 'mail_status' => 'pending'],
			['%s', '%s'],
			['%d', '%s'],
		);

		if (1 !== $claimed) {
			return null;
		}

		return $wpdb->get_row(
			$wpdb->prepare("SELECT * FROM {$this->table} WHERE id = %d", $id),
			ARRAY_A,
		);
	}

	/**
	 * Persist whether WordPress accepted the claimed mail attempt.
	 *
	 * @param int $id Internal record ID.
	 * @param bool $accepted Whether WordPress accepted the message.
	 * @return void
	 */

	public function finish(int $id, bool $accepted): void {
		global $wpdb;
		$wpdb->update(
			$this->table,
			['mail_status' => $accepted ? 'accepted' : 'unknown', 'updated_at' => gmdate('Y-m-d H:i:s')],
			['id' => $id, 'mail_status' => 'sending'],
			['%s', '%s'],
			['%d', '%s'],
		);
	}

	/**
	 * Read the most recent events for one booking, newest first.
	 *
	 * @param int $booking_id Booking ID.
	 * @return array<int, array<string, mixed>>
	 */

	public function latest(int $booking_id): array {
		global $wpdb;
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$this->table} WHERE booking_id = %d ORDER BY id DESC LIMIT 20",
				$booking_id,
			),
			ARRAY_A,
		);

		return is_array($rows) ? $rows : [];
	}
}
