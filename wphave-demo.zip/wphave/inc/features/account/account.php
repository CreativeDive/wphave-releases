<?php

/**
 * Centralize the frontend login, registration, password, and account flow.
 *
 * The class deliberately retains WordPress' native form-processing lifecycle so
 * authentication plugins can continue using the established core hooks.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/request-protection.php';
require_once wphave_dir() . 'inc/features/security/email-identity.php';

class WPHAVE_Account {

	private static $instance = null;
	private $login_failure_status = 'login_failed';

	/**
	 * Return the shared class instance.
	 *
	 * @return WPHAVE_Account
	 */

	public static function instance() {
		if( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Initialize the component.
	 *
	 * @return void
	 */

	private function __construct() {
		add_action( 'init', [ $this, 'handle_registration' ], 20 );
		add_action( 'init', [ $this, 'handle_lostpassword' ], 20 );
		add_filter( 'login_redirect', [ $this, 'preserve_login_redirect' ], 9999, 3 );
		add_action( 'wp_footer', [ $this, 'render_modal' ] );
	}

	/**
	 * Determine whether popup request.
	 *
	 * @return bool
	 */

	public function is_popup_request() {
		return 'popup' === wphave_request_string( $_POST, 'wphave_account_context' );
	}

	/**
	 * Return the return URL.
	 *
	 * @param string $status Optional feedback status.
	 * @param string $url Optional return URL.
	 * @param string $view Account view to display.
	 * @return string
	 */

	public function get_return_url( $status = '', $url = '', $view = 'login' ) {
		if( ! $url ) {
			$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
			$url = home_url( $request_uri );
		}

		$url = wp_validate_redirect( $url, home_url( '/' ) );
		$url = remove_query_arg( [ 'login', 'status', 'view' ], $url );
		$args = [
			'login' => 'popup',
			'view' => sanitize_key( $view ),
		];

		if( $status ) {
			$args['status'] = sanitize_key( $status );
		}

		$return_url = add_query_arg( $args, $url );
		$return_url = apply_filters( 'wphave_account_return_url', $return_url, $status, $view, $url );

		return wp_validate_redirect( $return_url, home_url( '/' ) );
	}

	/**
	 * Set the login failure status.
	 *
	 * @param string $status Public account status.
	 * @return void
	 */

	public function set_login_failure_status( $status ) {
		$allowed_statuses = [ 'login_failed', 'rate_limited' ];
		$this->login_failure_status = in_array( $status, $allowed_statuses, true ) ? $status : 'login_failed';
	}

	/**
	 * Preserve the login redirect.
	 *
	 * @param string $redirect_to Resolved login redirect URL.
	 * @param string $requested_redirect_to Originally requested redirect URL.
	 * @param WP_User|WP_Error $user Authenticated user or authentication error.
	 * @return string
	 */

	public function preserve_login_redirect( $redirect_to, $requested_redirect_to, $user ) {
		if( ! $this->is_popup_request() ) {
			return $redirect_to;
		}

		if( is_wp_error( $user ) && ! headers_sent() ) {
			$error_codes = $user->get_error_codes();
			$status = in_array( 'wphave_login_locked', $error_codes, true ) ? 'rate_limited' : $this->login_failure_status;
			nocache_headers();
			wp_safe_redirect( $this->get_return_url( $status, $requested_redirect_to ) );
			exit;
		}

		if( $requested_redirect_to ) {
			return wp_validate_redirect( $requested_redirect_to, home_url( '/' ) );
		}

		return $redirect_to;
	}

	/**
	 * Handle the registration.
	 *
	 * @return void
	 */

	public function handle_registration() {
		if( 'register' !== wphave_request_string( $_POST, 'wphave_account_action' ) ) {
			return;
		}

		$return_url = $this->posted_return_url( 'register' );

		if( ! get_option( 'users_can_register' ) ) {
			$this->redirect( $this->get_return_url( 'registration_disabled', $return_url, 'register' ) );
		}

		if( ! wp_verify_nonce( sanitize_text_field( wphave_request_string( $_POST, 'wphave_account_nonce' ) ), 'wphave_account_register' ) ) {
			$this->redirect( $this->get_return_url( 'request_failed', $return_url, 'register' ) );
		}

		if( ! WPHAVE_Account_Request_Protection::allow( 'registration' ) ) {
			$this->redirect( $this->get_return_url( 'rate_limited', $return_url, 'register' ) );
		}

		$username = sanitize_user( wphave_request_string( $_POST, 'user_login' ) );
		$raw_email = wphave_request_string( $_POST, 'user_email' );
		// REGISTRATION IDENTITY INVARIANT: Core receives only the exact mailbox
		// the visitor entered; lossy sanitization cannot register another account.
		$email = WPHAVE_Email_Identity::exact( $raw_email );
		$result = empty( $username ) || '' === $raw_email
			? new WP_Error( 'empty_fields' )
			: ( '' === $email ? new WP_Error( 'invalid_email' ) : register_new_user( $username, $email ) );
		$status = $this->get_registration_status( $result );
		$return_url = apply_filters( 'registration_redirect', $return_url, $result );

		$this->redirect( $this->get_return_url( $status, $return_url, is_wp_error( $result ) ? 'register' : 'login' ) );
	}

	/**
	 * Handle the lostpassword.
	 *
	 * @return void
	 */

	public function handle_lostpassword() {
		if( 'lostpassword' !== wphave_request_string( $_POST, 'wphave_account_action' ) ) {
			return;
		}

		$return_url = $this->posted_return_url( 'lostpassword' );

		if( ! wp_verify_nonce( sanitize_text_field( wphave_request_string( $_POST, 'wphave_account_nonce' ) ), 'wphave_account_lostpassword' ) ) {
			$this->redirect( $this->get_return_url( 'request_failed', $return_url, 'lostpassword' ) );
		}

		if( ! WPHAVE_Account_Request_Protection::allow( 'reset' ) ) {
			$this->redirect( $this->get_return_url( 'rate_limited', $return_url, 'lostpassword' ) );
		}

		$user_login = sanitize_text_field( wphave_request_string( $_POST, 'user_login' ) );
		$result = empty( $user_login ) ? new WP_Error( 'empty_fields' ) : retrieve_password( $user_login );
		$status = empty( $user_login ) ? 'empty_fields' : $this->get_lostpassword_status( $result );
		$return_url = apply_filters( 'lostpassword_redirect', $return_url );

		$this->redirect( $this->get_return_url( $status, $return_url, 'lostpassword' ) );
	}

	/**
	 * Return the account-independent public password-reset status.
	 *
	 * WordPress still decides whether a reset email can be issued and exposes
	 * operational failures to its normal hooks. The browser response deliberately
	 * does not reveal that decision.
	 *
	 * @param mixed $result WordPress password-retrieval result.
	 * @return string Public status.
	 */

	private function get_lostpassword_status( $result ) {
		// SECURITY INVARIANT: A public reset request proves neither account
		// existence nor mailbox ownership. Success and every account-specific Core
		// error therefore collapse to the same response; only local form shape may
		// produce a distinct validation status before account lookup.
		return 'lostpassword_success';
	}

	/**
	 * Return the registration status.
	 *
	 * @param int|WP_Error $result WordPress registration result.
	 * @return string
	 */

	private function get_registration_status( $result ) {
		if( ! is_wp_error( $result ) ) {
			return 'registration_success';
		}

		$error_codes = $result->get_error_codes();
		if( in_array( 'empty_fields', $error_codes, true ) || in_array( 'empty_username', $error_codes, true ) || in_array( 'empty_email', $error_codes, true ) ) {
			return 'empty_fields';
		}

		if( in_array( 'invalid_email', $error_codes, true ) ) {
			return 'invalid_email';
		}

		return 'registration_failed';
	}

	/**
	 * Return the validated account URL submitted by the form.
	 *
	 * @param string $view Account view to display.
	 * @return string
	 */

	private function posted_return_url( $view ) {
		$url = esc_url_raw( wphave_request_string( $_POST, 'wphave_account_return' ) );
		return $this->get_return_url( '', $url, $view );
	}

	/**
	 * Redirect safely to the requested account URL.
	 *
	 * @param string $url Validated redirect target.
	 * @return void
	 */

	private function redirect( $url ) {
		nocache_headers();
		wp_safe_redirect( $url );
		exit;
	}

	/**
	 * Return the state.
	 *
	 * @return array
	 */

	private function get_state() {
		if( 'popup' !== sanitize_key( wphave_request_string( $_GET, 'login' ) ) ) {
			return [ '', 'login' ];
		}

		$status = sanitize_key( wphave_request_string( $_GET, 'status' ) );
		$view = sanitize_key( wphave_request_string( $_GET, 'view', 'login' ) );
		$views = apply_filters( 'wphave_account_available_views', [ 'login', 'register', 'lostpassword' ] );
		$views = array_values( array_filter( array_map( 'sanitize_key', is_array( $views ) ? $views : [] ) ) );

		return [ $status, in_array( $view, $views, true ) ? $view : 'login' ];
	}

	/**
	 * Return the notice.
	 *
	 * @param string $status Account feedback status.
	 * @return array|null
	 */

	private function get_notice( $status ) {
		$notices = [
			'login_failed' => [ 'error', __( 'The username or password is incorrect. Please try again.', 'wphave' ) ],
			'rate_limited' => [ 'error', __( 'Too many login attempts. Please try again later.', 'wphave' ) ],
			'success' => [ 'success', __( 'You are now logged in.', 'wphave' ) ],
			'password_reset' => [ 'success', __( 'Your password has been changed. You can now log in.', 'wphave' ) ],
			'registration_success' => [ 'success', __( 'Registration complete. Please check your email before logging in.', 'wphave' ) ],
			'registration_failed' => [ 'error', __( 'Registration could not be completed. Please check your details and try again.', 'wphave' ) ],
			'registration_disabled' => [ 'error', __( 'User registration is currently disabled.', 'wphave' ) ],
			'empty_fields' => [ 'error', __( 'Please complete all required fields.', 'wphave' ) ],
			'invalid_email' => [ 'error', __( 'Please enter a valid email address.', 'wphave' ) ],
			'lostpassword_success' => [ 'success', __( 'If a matching account exists, a password reset email has been sent.', 'wphave' ) ],
			'lostpassword_failed' => [ 'error', __( 'The password reset request could not be completed. Please try again.', 'wphave' ) ],
			'request_failed' => [ 'error', __( 'The request could not be verified. Please try again.', 'wphave' ) ],
		];

		$notice = $notices[$status] ?? null;
		$notice = apply_filters( 'wphave_account_notice', $notice, $status );

		return is_array( $notice ) && count( $notice ) >= 2 ? $notice : null;
	}

	/**
	 * Render the modal.
	 *
	 * @return void
	 */

	public function render_modal() {
		if( ! function_exists( 'wphave_has_login_register_popup' ) || ! wphave_has_login_register_popup() || wphave_should_not_load_features() ) {
			return;
		}

		[ $status, $view ] = $this->get_state();
		$logged_in = is_user_logged_in();
		$user_can_register = (bool) get_option( 'users_can_register' );
		$notice = $this->get_notice( $status );
		$uses_woocommerce = $this->uses_woocommerce_account();

		$titles = [
			'login' => __( 'Login', 'wphave' ),
			'register' => __( 'Register', 'wphave' ),
			'lostpassword' => __( 'Lost Password?', 'wphave' ),
		];

		$title = $logged_in || $uses_woocommerce ? __( 'My Account', 'wphave' ) : ( $titles[$view] ?? $titles['login'] );

		echo wphave_render_modal( [
			'id' => 'login-register',
			'html_id' => 'login_register',
			'labelledby' => 'wphave-account-title',
			'wrapper_class' => $uses_woocommerce ? 'woocommerce-account-cart' : '',
			'content_class' => 'wphave-login-register-content',
		], function() use ( $title, $notice, $uses_woocommerce, $logged_in, $user_can_register, $view ) {
			?>
			<h4 class="wphave-fstyle-heading-h4" id="wphave-account-title"><?php echo esc_html( $title ); ?></h4>
			<?php if( $notice ) { ?>
				<div class="login-register-notice is-<?php echo esc_attr( $notice[0] ); ?>" role="<?php echo $notice[0] === 'error' ? 'alert' : 'status'; ?>"><?php echo esc_html( $notice[1] ); ?></div>
			<?php }

			if( $uses_woocommerce ) {
				$this->render_woocommerce_account();
			} elseif( $logged_in ) {
				$this->render_account_navigation();
			} else {
				$this->render_guest_forms( $user_can_register, $view );
			}
		} );
	}

	/**
	 * Determine whether the WooCommerce account view is active.
	 *
	 * @return bool
	 */

	private function uses_woocommerce_account() {
		$uses_woocommerce = class_exists( 'WPHAVE_WooCommerce' ) && WPHAVE_WooCommerce::is_active();
		return (bool) apply_filters( 'wphave_account_uses_woocommerce', $uses_woocommerce );
	}

	/**
	 * Render the woocommerce account.
	 *
	 * @return void
	 */

	private function render_woocommerce_account() {
		if( has_action( 'wphave_account_render_woocommerce' ) ) {
			do_action( 'wphave_account_render_woocommerce' );
			return;
		}

		echo do_shortcode( '[woocommerce_my_account show_title=0]' );
	}

	/**
	 * Render an account navigation.
	 *
	 * @return void
	 */

	private function render_account_navigation() {
		$profile_url = get_edit_user_link();
		$return_url = wp_validate_redirect( home_url( wp_unslash( $_SERVER['REQUEST_URI'] ?? '/' ) ), home_url( '/' ) );
		$return_url = remove_query_arg( [ 'login', 'status', 'view' ], $return_url );
		$links = [
			'profile' => [
				'label' => __( 'My Account', 'wphave' ),
				'url' => $profile_url ?: admin_url( 'profile.php' ),
				'class' => 'login-register-icon-account',
			],
			'logout' => [
				'label' => __( 'Logout', 'wphave' ),
				'url' => wp_logout_url( $return_url ),
				'class' => 'login-register-icon-logout',
			],
		];
		$links = apply_filters( 'wphave_account_links', $links );
		?>
		<nav aria-label="<?php echo esc_attr__( 'Account', 'wphave' ); ?>">
			<ul>
				<?php foreach( $links as $link ) {
					if( empty( $link['url'] ) || empty( $link['label'] ) ) {
						continue;
					} ?>
					<li><a class="<?php echo esc_attr( $link['class'] ?? '' ); ?>" href="<?php echo esc_url( $link['url'] ); ?>"><?php echo esc_html( $link['label'] ); ?></a></li>
				<?php } ?>
			</ul>
		</nav>
		<?php
	}

	/**
	 * Render the guest forms.
	 *
	 * @param bool $user_can_register Whether site registration is enabled.
	 * @param string $view Initially active account view.
	 * @return void
	 */

	private function render_guest_forms( $user_can_register, $view ) {
		if( $view === 'register' && $user_can_register ) {
			$this->render_registration_form();
		} elseif( $view === 'lostpassword' ) {
			$this->render_lostpassword_form();
		} else {
			$view = 'login';
			$this->render_login_form();
		}

		$this->render_guest_links( $user_can_register, $view );
	}

	/**
	 * Render the guest links.
	 *
	 * @param bool $user_can_register Whether site registration is enabled.
	 * @param string $view Currently displayed account view.
	 * @return void
	 */

	private function render_guest_links( $user_can_register, $view ) {
		$links = [];

		if( $view === 'login' ) {
			$links['lostpassword'] = __( 'Lost your password?', 'wphave' );
			if( $user_can_register ) {
				$links['register'] = __( 'Create an account', 'wphave' );
			}
		} else {
			$links['login'] = __( 'Back to login', 'wphave' );
		}

		$links = apply_filters( 'wphave_account_view_links', $links, $view, $user_can_register );
		if( ! is_array( $links ) || empty( $links ) ) {
			return;
		}
		?>
		<nav class="account-view-links" aria-label="<?php echo esc_attr__( 'Account access', 'wphave' ); ?>">
			<ul>
				<?php foreach( $links as $target_view => $label ) {
					$target_view = sanitize_key( $target_view );
					if( empty( $target_view ) || empty( $label ) ) {
						continue;
					} ?>
					<li><a href="<?php echo esc_url( $this->get_return_url( '', '', $target_view ) ); ?>"><?php echo esc_html( $label ); ?></a></li>
				<?php } ?>
			</ul>
		</nav>
		<?php
	}

	/**
	 * Render the login form.
	 *
	 * @return void
	 */

	private function render_login_form() {
		do_action( 'wphave_account_before_form', 'login' );
		$defaults = [
			'echo' => true,
			'redirect' => $this->get_return_url( 'success' ),
			'form_id' => 'wphave-account-login-form',
			'label_username' => __( 'Username or Email Address', 'wphave' ),
			'label_password' => __( 'Password', 'wphave' ),
			'label_remember' => __( 'Remember Me', 'wphave' ),
			'label_log_in' => __( 'Log In', 'wphave' ),
			'id_username' => 'wphave-account-login-username',
			'id_password' => 'wphave-account-login-password',
			'id_remember' => 'wphave-account-login-remember',
			'id_submit' => 'wphave-account-login-submit',
			'remember' => true,
			'value_username' => '',
			'value_remember' => false,
			'required_username' => true,
			'required_password' => true,
		];
		$args = wp_parse_args( [], apply_filters( 'login_form_defaults', $defaults ) );
		$login_form_top = apply_filters( 'login_form_top', '', $args );
		$login_form_middle = apply_filters( 'login_form_middle', '', $args );
		$login_form_bottom = apply_filters( 'login_form_bottom', '', $args );
		?>
		<form name="<?php echo esc_attr( $args['form_id'] ); ?>" id="<?php echo esc_attr( $args['form_id'] ); ?>" action="<?php echo esc_url( site_url( 'wp-login.php', 'login_post' ) ); ?>" method="post">
			<?php echo $login_form_top; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Official wp_login_form() extension point. ?>
			<?php $this->render_text_field( [ 'id' => $args['id_username'], 'name' => 'log', 'label' => $args['label_username'], 'autocomplete' => 'username', 'value' => $args['value_username'] ] ); ?>
			<?php $this->render_text_field( [ 'id' => $args['id_password'], 'name' => 'pwd', 'label' => $args['label_password'], 'type' => 'password', 'autocomplete' => 'current-password' ] ); ?>
			<?php echo $login_form_middle; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Official wp_login_form() extension point. ?>
			<?php if( $args['remember'] ) { ?>
				<div class="login-remember wp-block-wphave-form-checkbox" data-form-field="">
					<label class="wphave-form-field-label wphave-form-checkbox"><input class="wphave-form-checkbox-input" name="rememberme" type="checkbox" id="<?php echo esc_attr( $args['id_remember'] ); ?>" value="forever"<?php checked( $args['value_remember'] ); ?> /> <?php echo esc_html( $args['label_remember'] ); ?></label>
				</div>
			<?php } ?>
            <button type="submit" name="wp-submit" id="<?php echo esc_attr( $args['id_submit'] ); ?>" class="button button-primary"><?php echo esc_html( $args['label_log_in'] ); ?></button>
            <input type="hidden" name="redirect_to" value="<?php echo esc_attr( $args['redirect'] ); ?>" />
            <input type="hidden" name="wphave_account_context" value="popup" />
			<?php echo $login_form_bottom; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Official wp_login_form() extension point. ?>
		</form>
		<?php
		do_action( 'wphave_account_after_form', 'login' );
	}

	/**
	 * Render the text field.
	 *
	 * @param array $args Field configuration.
	 * @return void
	 */

	private function render_text_field( $args ) {
		$id = $args['id'] ?? '';
		$name = $args['name'] ?? '';
		$label = $args['label'] ?? '';
		$type = $args['type'] ?? 'text';
		$autocomplete = $args['autocomplete'] ?? '';
		$value = $args['value'] ?? '';
		?>
		<div class="wp-block-wphave-form-input" data-form-field="">
			<span><label class="wphave-form-field-label" for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label>*</span>
			<input type="<?php echo esc_attr( $type ); ?>" name="<?php echo esc_attr( $name ); ?>" id="<?php echo esc_attr( $id ); ?>" class="wphave-form-input" value="<?php echo esc_attr( $value ); ?>" autocapitalize="off" autocomplete="<?php echo esc_attr( $autocomplete ); ?>" required aria-required="true" aria-invalid="false" />
		</div>
		<?php
	}

	/**
	 * Render the registration form.
	 *
	 * @return void
	 */

	private function render_registration_form() {
		do_action( 'wphave_account_before_form', 'register' );
		$return_url = $this->get_return_url( '', '', 'register' );
		?>
		<form id="wphave-account-register-form" action="<?php echo esc_url( $return_url ); ?>" method="post">
			<?php $this->render_text_field( [ 'id' => 'wphave-account-register-username', 'name' => 'user_login', 'label' => __( 'Username', 'wphave' ), 'autocomplete' => 'username' ] ); ?>
			<?php $this->render_text_field( [ 'id' => 'wphave-account-register-email', 'name' => 'user_email', 'label' => __( 'Email Address', 'wphave' ), 'type' => 'email', 'autocomplete' => 'email' ] ); ?>
			<div class="wphave-form-field-help"><?php echo esc_html__( 'Registration confirmation will be emailed to you.', 'wphave' ); ?></div>
			<?php do_action( 'register_form' ); ?>
			<?php wp_nonce_field( 'wphave_account_register', 'wphave_account_nonce' ); ?>
			<input type="hidden" name="wphave_account_action" value="register" />
			<input type="hidden" name="wphave_account_return" value="<?php echo esc_attr( $return_url ); ?>" />
			<button type="submit" class="button button-primary"><?php echo esc_html__( 'Register', 'wphave' ); ?></button>
		</form>
		<?php
		do_action( 'wphave_account_after_form', 'register' );
	}

	/**
	 * Render the lostpassword form.
	 *
	 * @return void
	 */

	private function render_lostpassword_form() {
		do_action( 'wphave_account_before_form', 'lostpassword' );
		$return_url = $this->get_return_url( '', '', 'lostpassword' );
		?>
		<form id="wphave-account-lostpassword-form" action="<?php echo esc_url( $return_url ); ?>" method="post">
			<?php $this->render_text_field( [ 'id' => 'wphave-account-lostpassword-username', 'name' => 'user_login', 'label' => __( 'Username or Email Address', 'wphave' ), 'autocomplete' => 'username' ] ); ?>
			<?php do_action( 'lostpassword_form' ); ?>
			<?php wp_nonce_field( 'wphave_account_lostpassword', 'wphave_account_nonce' ); ?>
			<input type="hidden" name="wphave_account_action" value="lostpassword" />
			<input type="hidden" name="wphave_account_return" value="<?php echo esc_attr( $return_url ); ?>" />
			<button type="submit" class="button button-primary"><?php echo esc_html__( 'Get New Password', 'wphave' ); ?></button>
		</form>
		<?php
		do_action( 'wphave_account_after_form', 'lostpassword' );
	}
}

WPHAVE_Account::instance();
