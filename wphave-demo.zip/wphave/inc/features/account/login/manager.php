<?php

require_once __DIR__ . '/protection.php';
require_once __DIR__ . '/runtime.php';
require_once __DIR__ . '/routes.php';
require_once __DIR__ . '/passwords.php';
require_once dirname(__DIR__) . '/request-protection.php';

/**
 * Handles custom login routing and authentication hardening.
 *
 * Route contract while the custom login is enabled:
 *
 * - GET  /{custom-slug}/                               --> renders the login form.
 * - POST /wp-login.php                                 --> processes login only.
 * - POST /wp-login.php?action=postpass                 --> processes protected-post passwords.
 * - POST /wp-login.php?action=confirm_admin_email      --> processes Core's signed admin-email confirmation.
 * - GET  /{custom-slug}/?action=lostpassword           --> renders password recovery.
 * - POST /{custom-slug}/?action=lostpassword           --> requests the recovery email.
 * - GET  /{custom-slug}/?action=rp                     --> validates a recovery key.
 * - POST /{custom-slug}/?action=rp                     --> saves the new password.
 * - GET  /{custom-slug}/?action=register               --> renders registration when WordPress registration is on.
 * - POST /{custom-slug}/?action=register               --> creates the account.
 * - GET  /{custom-slug}/?action=logout                 --> verifies the nonce, logs the user out and applies the core logout_redirect contract.
 * - GET  /wp-login.php and native UI actions           --> return a neutral 404 and never disclose the custom login path.
 * - GET  /wp-login.php?action=logout                   --> accepts only a valid logout nonce issued before activation, then logs out and redirects to the custom endpoint.
 * - GET  /wp-admin/ while logged out                   --> returns the same neutral 404.
 * - GET  /wp-login.php for interim login and core      --> confirmation passes through to WordPress.
 * - GET  /{custom-slug}/?action=enter_recovery_mode    --> passes a signed recovery link to WordPress for validation.
 * - GET  /{custom-slug}/?action=entered_recovery_mode  --> renders the custom login after Recovery Mode was initialized.
 * - GET  /wp-admin/admin-ajax.php and admin-post.php   --> remain available processors.
 *
 * WordPress URL filters make the custom endpoint canonical. Native processors
 * are passed through only when WordPress or an integration needs their runtime;
 * they must never redirect a public native request to the secret custom path.
 */

if (! defined('ABSPATH')) {
    exit;
}

class WPHAVE_Login_Manager {

    use WPHAVE_Login_Protection,
        WPHAVE_Login_Runtime,
        WPHAVE_Login_Routes,
        WPHAVE_Login_Passwords;

    private $settings = [];

    const LOGIN_ATTEMPT_WINDOW = 15 * MINUTE_IN_SECONDS;
    const LOGIN_ATTEMPT_LIMIT = 5;
    const LOGIN_IP_ATTEMPT_LIMIT = 20;
    const LOGIN_LOCKOUT_TIME = 15 * MINUTE_IN_SECONDS;
    const LOGIN_DELAY_SECONDS = 0.2;

    /**
     * Initialize the component.
     *
     * @return void
     */

    public function __construct() {
        $this->settings = wphave_data_get('site_settings', 'advanced.security', []) ?? [];

        if ($this->is_custom_login_enabled()) {
            // SECURITY: An init-time login_head can expose third-party lifecycle
            // warnings and absolute server paths. Render only after plugins load.
            add_action('wp_loaded', [$this, 'handle_login_routes'], 0);

            add_filter('login_url', [$this, 'filter_login_url'], 10, 3);
            add_filter('logout_url', [$this, 'filter_logout_url'], 10, 2);
            add_filter('lostpassword_url', [$this, 'filter_lostpassword_url'], 10, 2);
            add_filter('register_url', [$this, 'filter_register_url'], 10, 1);
            add_filter('retrieve_password_message', [$this, 'filter_retrieve_password_message'], 10, 4);
            add_filter('wp_unique_post_slug_is_bad_attachment_slug', [$this, 'reserve_custom_login_post_slug'], 10, 2);
            add_filter('wp_unique_post_slug_is_bad_hierarchical_slug', [$this, 'reserve_custom_login_post_slug'], 10, 4);
            add_filter('wp_unique_post_slug_is_bad_flat_slug', [$this, 'reserve_custom_login_post_slug'], 10, 3);
        }

        $has_login_protection = $this->is_rate_limiting_enabled() || $this->is_honeypot_enabled();

        if ($this->is_custom_login_enabled() || $has_login_protection) {
            add_filter('login_redirect', [$this, 'filter_login_redirect'], 10, 3);
            add_action('wp_login_failed', [$this, 'handle_login_failed'], 9998, 2);
        }

        if ($has_login_protection) {
            add_filter('authenticate', [$this, 'limit_login_attempts'], 30, 3);

            if ($this->is_honeypot_enabled()) {
                add_filter('login_form_middle', [$this, 'add_login_form_honeypot'], 10, 2);
            }

            if ($this->is_rate_limiting_enabled()) {
                add_action('wp_login', [$this, 'reset_failed_login_attempts_on_success'], 10, 2);
            }
        }
    }
}

add_action('plugins_loaded', function () {
    new WPHAVE_Login_Manager();
});
