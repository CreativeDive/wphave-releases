<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Login_Protection {

        /**
	 * Add login form honeypot.
	 *
	 * @param string $content Content to process.
	 * @param array $args Function arguments.
	 */

	public function add_login_form_honeypot( $content, $args ) {
		return $content . '<p class="wphave-honeypot" aria-hidden="true"><label>Company<input type="text" name="company_name" tabindex="-1" autocomplete="off" /></label></p>';
	}

    /**
	 * Determine whether honeypot enabled.
	 *
	 * @return bool
	 */

	private function is_honeypot_enabled() {
		return ! empty( $this->settings['login_honeypot'] );
	}

    /**
	 * Determine whether rate limiting enabled.
	 *
	 * @return bool
	 */

	private function is_rate_limiting_enabled() {
		return ! empty( $this->settings['login_rate_limiting'] );
	}

    /**
	 * Limit the login attempts.
	 *
	 *  - Blocking requests after too many failed attempts
	 *  - Introducing a delay between login attempts
	 *
	 * @param mixed $user
	 * @param string $username
	 * @param string $password
	 * @return mixed
	 */

	public function limit_login_attempts( $user, $username, $password ) {
		if( ! $this->is_rate_limiting_enabled() && ! $this->is_honeypot_enabled() ) {
			return $user;
		}

		$request = $this->get_request_context();

		if( ! $request['is_wp_login'] || 'POST' !== $request['method'] ) {
			return $user;
		}

		$honeypot = trim( wphave_request_string( $_POST, 'company_name' ) );

		if( ! empty( $honeypot ) && $this->is_honeypot_enabled() ) {
			return new WP_Error(
				'wphave_login_failed',
				__( 'The username or password is incorrect.', 'wphave' )
			);
		}

		if( ! $this->is_rate_limiting_enabled() ) {
			return $user;
		}

		if( empty( $username ) || empty( $password ) ) {
			return new WP_Error(
				'wphave_login_empty',
				__( 'The username or password is incorrect.', 'wphave' )
			);
		}

		if( $this->is_login_locked_out( $username ) ) {
			return new WP_Error(
				'wphave_login_locked',
				__( 'Too many failed attempts. Please try again later.', 'wphave' )
			);
		}

        if( self::LOGIN_DELAY_SECONDS > 0 && $this->is_rate_limiting_enabled() ) {
            usleep( (int) round( self::LOGIN_DELAY_SECONDS * 1000000 ) );
        }

		return $user;
	}

    /**
     * Return remaining login attempts.
     *
     * @param mixed $username Username.
     */

	private function get_remaining_login_attempts( $username = '' ) {
        $key = $this->get_login_attempt_key( $username );
		$attempts = WPHAVE_Rate_Limiter::get( $key );

        $remaining = self::LOGIN_ATTEMPT_LIMIT - $attempts;

        return max( 0, $remaining );
    }

    /**
	 * Reset the failed login attempts on success.
	 *
	 * @param string $user_login
	 * @param object $user
	 * @return void
	 */

	public function reset_failed_login_attempts_on_success( $user_login, $user ) {
		if( $this->is_rate_limiting_enabled() ) {
            $this->reset_failed_login_attempts( $user_login );
        }
	}

    /**
	 * Return the login attempt key.
	 *
	 * @return string
	 */

	private function get_login_attempt_key( $username = '' ) {
        $ip = $this->get_client_ip();
        $user = strtolower( (string) $username );

        return 'wphave_login_attempts_' . md5( $ip . '|' . $user );
    }

    /**
	 * Return the login lockout key.
	 *
	 * @return string
	 */

	private function get_login_lockout_key( $username = '' ) {
		return 'wphave_login_lockout_' . md5( $this->get_client_ip() . '|' . strtolower($username) );
	}

	/**
	 * Tracks failed attempts from one client IP across usernames.
	 */

	private function get_ip_login_attempt_key() {
		return 'wphave_login_attempts_ip_' . md5( $this->get_client_ip() );
	}

	/**
	 * Return the lockout key for one client IP.
	 */

	private function get_ip_login_lockout_key() {
		return 'wphave_login_lockout_ip_' . md5( $this->get_client_ip() );
    }

    /**
	 * Determine whether login locked out.
	 *
	 * @return bool
	 */

	private function is_login_locked_out( $username = '' ) {
        if( ! $this->is_rate_limiting_enabled() ) {
            return false;
        }

        // IP + USER
        if( get_transient( $this->get_login_lockout_key( $username ) ) ) {
            return true;
        }

		// IP across usernames
        if( get_transient( $this->get_ip_login_lockout_key() ) ) {
            return true;
        }

		// SECURITY INVARIANT: The durable attempt counters remain authoritative
		// until their lockout marker has been stored and read back. This fallback
		// keeps the login boundary closed when marker persistence fails.
		if( WPHAVE_Rate_Limiter::get( $this->get_login_attempt_key( $username ) ) >= self::LOGIN_ATTEMPT_LIMIT ) {
			return true;
		}

		if( WPHAVE_Rate_Limiter::get( $this->get_ip_login_attempt_key() ) >= self::LOGIN_IP_ATTEMPT_LIMIT ) {
			return true;
		}

        return false;
    }

    /**
	 * Register the failed login attempt.
	 *
	 * @return void
	 */

	private function register_failed_login_attempt( $username = '' ) {
        if( empty( $username ) ) {
            $username = 'unknown';
        }

        $username = strtolower( (string) $username );

		// SECURITY INVARIANT: Account-targeted and IP-wide buckets remain separate:
		// one slows guessing against an identity, the other limits username spraying.
		// IP + USER
		$key = $this->get_login_attempt_key( $username );
		$attempts = WPHAVE_Rate_Limiter::increment( $key, self::LOGIN_ATTEMPT_WINDOW );

		if( $attempts >= self::LOGIN_ATTEMPT_LIMIT ) {
			if( $this->persist_login_lockout( $this->get_login_lockout_key( $username ) ) ) {
				WPHAVE_Rate_Limiter::reset( $key );
			}
		}

		// IP across usernames. This limits credential spraying without allowing an
		// attacker to lock a known account for every other client on the site.
		$ip_key = $this->get_ip_login_attempt_key();
		$ip_attempts = WPHAVE_Rate_Limiter::increment( $ip_key, self::LOGIN_ATTEMPT_WINDOW );

		if( $ip_attempts >= self::LOGIN_IP_ATTEMPT_LIMIT ) {
			if( $this->persist_login_lockout( $this->get_ip_login_lockout_key() ) ) {
				WPHAVE_Rate_Limiter::reset( $ip_key );
			}
		}
    }

	/** Store a lockout marker before releasing its authoritative attempt counter. */

	private function persist_login_lockout( string $key ): bool {
		// SECURITY INVARIANT: Counter reset is the commit step of lockout creation.
		// It may occur only after storage acknowledges the exact marker value.
		return set_transient( $key, 1, self::LOGIN_LOCKOUT_TIME )
			&& 1 === (int) get_transient( $key );
	}

    /**
	 * Reset the failed login attempts.
	 *
	 * @return void
	 */

	private function reset_failed_login_attempts( $username = '' ) {
        $username = strtolower( (string) $username );

		WPHAVE_Rate_Limiter::reset( $this->get_login_attempt_key( $username ) );
		delete_transient( $this->get_login_lockout_key( $username ) );
	}

}
