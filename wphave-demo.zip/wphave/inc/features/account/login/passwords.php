<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Login_Passwords {

    /**
	 * Filter the retrieve password message.
	 *
	 * @param string $message
	 * @param string $key
	 * @param string $user_login
	 * @param object $user_data
	 * @return string
	 */

	public function filter_retrieve_password_message( $message, $key, $user_login, $user_data ) {
		if( ! $this->is_custom_login_enabled() ) {
			return $message;
		}

		$args = [
			'action' => 'rp',
			'key' => $key,
			'login' => rawurlencode( $user_login ),
		];

		if( class_exists( 'WPHAVE_Account' ) && WPHAVE_Account::instance()->is_popup_request() ) {
			$return_url = esc_url_raw( wphave_request_string( $_POST, 'wphave_account_return' ) );
			$args['redirect_to'] = WPHAVE_Account::instance()->get_return_url( 'password_reset', $return_url );
		}

		$url = $this->get_custom_login_url( $args );

		return sprintf(
			/* translators: 1: username, 2: reset url */
			__( "Username: %1\$s\n\nTo set your password, visit the following address:\n\n%2\$s", 'wphave' ),
			$user_login,
			$url
		);
	}

    /**
	 * Handle the lostpassword page.
	 *
	 *  - Reset key
	 *  - Username
	 *
	 *  - Updates the user password
	 *  - Redirects to login with success state
	 *
	 * @param array $request
	 * @return void
	 */

	private function handle_lostpassword_page( $request ) {
		$error_msg = '';
		$info_msg  = '';

		if( 'POST' === $request['method'] ) {
            if(
				! wp_verify_nonce( sanitize_text_field( $this->get_auth_value( $_POST, 'wphave_nonce' ) ), 'wphave_auth_action' )
            ) {
                $this->do_404();
            }

			$user_login = sanitize_text_field( $this->get_auth_value( $_POST, 'user_login' ) );

			$honeypot = trim( $this->get_auth_value( $_POST, 'company_name' ) );

			if( $this->is_honeypot_enabled() && ! empty( $honeypot ) ) {
				$this->do_404();
			}

			if( empty( $user_login ) ) {
				$error_msg = __( 'Please enter a username or email address.', 'wphave' );
			} else {
				$result = retrieve_password( $user_login );

				// Keep the response identical for known and unknown identities so the
				// custom route cannot be used for public account enumeration.
				$info_msg = __( 'If the account exists, you will receive an email.', 'wphave' );
			}
		}

		$this->render_lostpassword_page( [
			'error' => $error_msg,
			'info' => $info_msg,
		] );
	}

    /**
	 * Handle the password-reset page request.
	 */

	private function handle_resetpassword_page( $request ) {
		$error_msg = '';
		$redirect_to = wp_validate_redirect( $this->get_auth_value( $request['query'], 'redirect_to' ), '' );

        $rp_cookie = 'wp-resetpass-' . COOKIEHASH;
        $rp_path   = wp_parse_url( $_SERVER['REQUEST_URI'], PHP_URL_PATH );

        // STEP 1: Key + Login aus URL in Cookie speichern (Core-Verhalten)
        if ( isset( $request['query']['key'], $request['query']['login'] ) ) {
			if( ! is_string( $request['query']['key'] ) || ! is_string( $request['query']['login'] ) ) {
				$this->do_404();
			}

            $value = sprintf(
                '%s:%s',
                wp_unslash( $request['query']['login'] ),
                wp_unslash( $request['query']['key'] )
            );

            setcookie( $rp_cookie, $value, 0, $rp_path, COOKIE_DOMAIN, is_ssl(), true );

            // URL bereinigen
            if( ! headers_sent() ) {
                wp_safe_redirect( remove_query_arg( [ 'key', 'login' ] ) );
                exit;
            }
        }

		// STEP 2: Cookie lesen (Core-Verhalten)
		if ( isset( $_COOKIE[ $rp_cookie ] ) && is_string( $_COOKIE[ $rp_cookie ] ) && strpos( $_COOKIE[ $rp_cookie ], ':' ) !== false ) {
            list( $login, $key ) = explode( ':', wp_unslash( $_COOKIE[ $rp_cookie ] ), 2 );
            $user = check_password_reset_key( $key, $login );
        } else {
            $this->do_404();
        }

        if ( is_wp_error( $user ) ) {
            // Cookie löschen wie Core
            setcookie( $rp_cookie, ' ', time() - YEAR_IN_SECONDS, $rp_path, COOKIE_DOMAIN, is_ssl(), true );

            $this->do_404();
        }


		if( 'POST' === $request['method'] ) {
			$submitted_key = $this->get_auth_value( $_POST, 'rp_key' );
			// SECURITY INVARIANT: Password replacement requires the same reset secret
			// that WordPress authenticated from the HttpOnly reset cookie. A valid
			// form nonce alone never authorizes an account credential change.
			if( ! $submitted_key || ! hash_equals( $key, $submitted_key ) ) {
                $this->do_404();
            }

            if(
				! wp_verify_nonce( sanitize_text_field( $this->get_auth_value( $_POST, 'wphave_nonce' ) ), 'wphave_auth_action' )
            ) {
                $this->do_404();
            }

			$pass1 = $this->get_auth_value( $_POST, 'pass1' );
			$pass2 = $this->get_auth_value( $_POST, 'pass2' );
			$errors = new WP_Error();

			// Match WordPress Core: surrounding whitespace is not part of a reset
			// password, while an all-whitespace value receives a dedicated error.
			if( '' !== $pass1 ) {
				$pass1 = trim( $pass1 );
			}

			if( '' === $pass1 || '' === $pass2 ) {
				$errors->add( 'password_reset_empty', __( 'Please enter both password fields.', 'wphave' ) );
			} elseif( $pass1 !== trim( $pass2 ) ) {
				$errors->add( 'password_reset_mismatch', __( 'Passwords do not match.', 'wphave' ) );
			}

			do_action( 'validate_password_reset', $errors, $user );

			if( $errors->has_errors() ) {
				$error_msg = wp_strip_all_tags( $errors->get_error_message() );
			} else {
				reset_password( $user, $pass1 );

                // Cookie löschen (Core)
                setcookie( $rp_cookie, ' ', time() - YEAR_IN_SECONDS, $rp_path, COOKIE_DOMAIN, is_ssl(), true );

				if( ! headers_sent() ) {
					$success_url = $redirect_to ?: $this->get_custom_login_url( [ 'password' => 'changed' ] );
					wp_safe_redirect( $success_url );
					exit;
				}
			}
		}

		$this->render_resetpassword_page( [
			'error' => $error_msg,
			'key' => $key,
			'redirect_to' => $redirect_to,
			'user' => $user,
		] );
	}

        /**
	 * Render the lostpassword page.
	 *
	 * @param array $args
	 * @return void
	 */

	private function render_lostpassword_page( $args = [] ) {
		$error = isset( $args['error'] ) ? (string) $args['error'] : '';
		$info = isset( $args['info'] ) ? (string) $args['info'] : '';

		$content  = '<h1>' . esc_html__( 'Reset Password', 'wphave' ) . '</h1>';
		$content .= '<form method="post" action="' . esc_url( $this->get_custom_login_url( [ 'action' => 'lostpassword' ] ) ) . '">';

        // Nonce field
        $content .= wp_nonce_field( 'wphave_auth_action', 'wphave_nonce', true, false );

		$content .= $this->render_auth_field( 'wphave-lostpassword-username', 'user_login', __( 'Email Address or Username', 'wphave' ), 'text', 'username', ! empty( $error ) );

        // Honeypot field
		if( $this->is_honeypot_enabled() ) {
		    $content .= $this->render_auth_honeypot();
		}

		ob_start();
		do_action( 'lostpassword_form' );
		$content .= ob_get_clean();

		$content .= '<p><button type="submit">' . esc_html__( 'Send Reset Link', 'wphave' ) . '</button></p>';
		$content .= '</form>';
		$content .= $this->render_auth_navigation( [ $this->get_custom_login_url() => __( 'Back to login', 'wphave' ) ] );

		$this->render_auth_shell( __( 'Reset Password', 'wphave' ), $content, $error, $info );
	}

    /**
	 * Render the resetpassword page.
	 *
	 * @param array $args
	 * @return void
	 */

	private function render_resetpassword_page( $args = [] ) {
		$error = isset( $args['error'] ) ? (string) $args['error'] : '';
		$key = isset( $args['key'] ) ? (string) $args['key'] : '';
		$redirect_to = isset( $args['redirect_to'] ) ? (string) $args['redirect_to'] : '';
		$user = $args['user'] ?? null;

		$action_url = $this->get_custom_login_url( [ 'action' => 'rp' ] );

		if( $redirect_to ) {
			$action_url = add_query_arg( 'redirect_to', $redirect_to, $action_url );
		}

		$content  = '<h1>' . __( 'Set New Password', 'wphave' ) . '</h1>';
		$content .= '<form method="post" action="' . esc_url( $action_url ) . '">';

        // Nonce field
        $content .= wp_nonce_field( 'wphave_auth_action', 'wphave_nonce', true, false );

		$content .= $this->render_auth_field( 'wphave-reset-password', 'pass1', __( 'New Password', 'wphave' ), 'password', 'new-password', ! empty( $error ) );
		$content .= $this->render_auth_field( 'wphave-reset-password-confirmation', 'pass2', __( 'Repeat Password', 'wphave' ), 'password', 'new-password', ! empty( $error ) );

		ob_start();
		do_action( 'resetpass_form', $user );
		$content .= ob_get_clean();

        $content .= '<input type="hidden" name="rp_key" value="' . esc_attr( $key ) . '">';
		$content .= '<input type="hidden" name="redirect_to" value="' . esc_attr( $redirect_to ) . '">';

		$content .= '<p><button type="submit">' . __( 'Reset Password', 'wphave' ) . '</button></p>';
		$content .= '</form>';

		$this->render_auth_shell( __( 'Set New Password', 'wphave' ), $content, $error );
	}

}
