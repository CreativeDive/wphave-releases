<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Login_Routes {

    /**
	 * Return the custom login slug.
	 *
	 * @return string
	 */

	private function get_custom_login_slug() {
		return ! empty( $this->settings['login_slug'] )
			? sanitize_title( $this->settings['login_slug'] )
			: '';
	}

	/**
	 * Reserve the active login path in WordPress' canonical post-slug allocator.
	 *
	 * WordPress invokes the same callback for attachment, hierarchical and flat
	 * post slugs with different trailing arguments. Only the existing decision
	 * and candidate slug are relevant to this cross-content route boundary.
	 *
	 * @param bool   $is_bad_slug Existing WordPress collision decision.
	 * @param string $slug Candidate post slug.
	 * @return bool
	 */

	public function reserve_custom_login_post_slug( $is_bad_slug, $slug ) {
		if( $is_bad_slug || ! $this->is_custom_login_enabled() ) {
			return (bool) $is_bad_slug;
		}

		return sanitize_title( (string) $slug ) === $this->get_custom_login_slug();
	}

	/**
	 * Determine whether a URL points back to the native login endpoint.
	 *
	 * A login endpoint cannot be a useful post-authentication destination and
	 * must never be persisted as the login form's redirect target.
	 *
	 * @param string $url URL to inspect.
	 * @return bool
	 */

	private function is_login_endpoint_url( $url ) {
		$path = wp_parse_url( (string) $url, PHP_URL_PATH );

		if( ! $path ) {
			return false;
		}

		if( basename( $path ) === 'wp-login.php' ) {
			return true;
		}

		$custom_slug = $this->get_custom_login_slug();

		if( ! $custom_slug ) {
			return false;
		}

		// SECURITY: Native and rewritten login URLs are the same trust boundary.
		// Reject both so a filtered wp_login_url() cannot become a redirect loop.
		$custom_path = wp_parse_url( home_url( '/' . $custom_slug . '/' ), PHP_URL_PATH );

		return untrailingslashit( $path ) === untrailingslashit( (string) $custom_path );
	}

    /**
	 * Handle the login routes.
	 *
	 *  - Login page rendering
	 *  - Password reset flow
	 *  - Registration flow
	 *  - Logout handling
	 *
	 * @return void
	 */

	public function handle_login_routes() {
		if( ! $this->is_custom_login_enabled() ) {
			return;
		}

		if(
			( defined( 'DOING_AJAX' ) && DOING_AJAX ) ||
			( defined( 'REST_REQUEST' ) && REST_REQUEST ) ||
			( defined( 'DOING_CRON' ) && DOING_CRON ) ||
			( defined( 'WP_CLI' ) && WP_CLI )
		) {
			return;
		}

		$request = $this->get_request_context();

		if( $request['is_wp_login'] ) {
			if( $this->is_valid_native_logout_request( $request ) ) {
				$this->handle_logout( $request );
			}

			if( $this->should_pass_native_login_request( $request ) ) {
				return;
			}

			$this->do_404();
		}

		if( $request['is_wp_admin'] ) {
			if( is_user_logged_in() || $this->is_public_admin_processor( $request ) ) {
				return;
			}

			$this->do_404();
		}

		if( ! $request['is_custom_login'] ) {
			return;
		}

		// Redirect to HTTPS login if forced to use SSL.
        if( force_ssl_admin() && ! is_ssl() ) {
            if( ! headers_sent() ) {
                wp_safe_redirect( set_url_scheme( home_url( $_SERVER['REQUEST_URI'] ), 'https' ) );
                exit;
            }
        }

		$custom_slug = $this->get_custom_login_slug();

		if( empty( $custom_slug ) ) {
			return;
		}

		if( isset( $_REQUEST['interim-login'] ) && ! defined( 'INTERIM_LOGIN' ) ) {
			define( 'INTERIM_LOGIN', true );
		}

        nocache_headers();
        $secure = ( 'https' === parse_url( wp_login_url(), PHP_URL_SCHEME ) );

        // Set a cookie now to see if they are supported by the browser.
        setcookie(
            TEST_COOKIE,
            'WP Cookie check',
            [
                'expires' => 0,
                'path' => COOKIEPATH,
                'domain' => COOKIE_DOMAIN,
                'secure' => $secure,
                'httponly' => true,
                'samesite' => 'Lax',
            ]
        );

        if( COOKIEPATH !== SITECOOKIEPATH ) {
            setcookie(
                TEST_COOKIE,
                'WP Cookie check',
                [
                    'expires' => 0,
                    'path' => SITECOOKIEPATH,
                    'domain' => COOKIE_DOMAIN,
                    'secure' => $secure,
                    'httponly' => true,
                    'samesite' => 'Lax',
                ]
            );
        }

		$wp_language = sanitize_text_field( wphave_request_string( $_GET, 'wp_lang' ) );
		if( '' !== $wp_language ) {
			setcookie(
                'wp_lang',
				$wp_language,
                0,
                COOKIEPATH,
                COOKIE_DOMAIN,
                $secure,
                true
            );
        }

		do_action( 'login_init' );

		$login_action = $request['action'] ?: 'login';
		global $action, $interim_login;
		$action = $login_action;
		$interim_login = isset( $request['query']['interim-login'] ) ? 1 : 0;

		do_action( "login_form_{$login_action}" );

		switch( $request['action'] ) {
			case '':
			case 'login':
				$this->render_login_page( $request );
				exit;

			case 'lostpassword':
			case 'retrievepassword':
				$this->handle_lostpassword_page( $request );
				exit;

			case 'rp':
			case 'resetpass':
				$this->handle_resetpassword_page( $request );
				exit;

			case 'register':
				$this->handle_register_page( $request );
				exit;

			case 'logout':
				$this->handle_logout( $request );
				exit;

			case WP_Recovery_Mode_Link_Service::LOGIN_ACTION_ENTER:
				if( ! $this->has_recovery_mode_credentials( $request ) ) {
					$this->do_404();
				}

				if( ! headers_sent() ) {
					wp_safe_redirect(
						add_query_arg(
							$request['query'],
							site_url( 'wp-login.php' )
						)
					);
					exit;
				}
				return;

			case WP_Recovery_Mode_Link_Service::LOGIN_ACTION_ENTERED:
				$this->render_login_page( $request );
				exit;

            case 'checkemail':
            case 'confirm_admin_email':
            case 'confirmaction':
                if( ! headers_sent() ) {
                    wp_safe_redirect(
                        add_query_arg(
                            $request['query'],
                            site_url( 'wp-login.php?action=' . $request['action'] )
                        )
                    );
                    exit;
                }
                return;

			default:
				$this->do_404();
		}
	}

	/**
	 * Determine whether WordPress must process a native login request.
	 *
	 * Public native login UI routes fail closed. POST authentication remains a
	 * processor because the custom form and authentication plugins rely on the
	 * native WordPress lifecycle. A narrow GET allowlist preserves core flows
	 * that cannot be rendered safely by the custom controller.
	 *
	 * @param array $request Normalized request context.
	 * @return bool
	 */

	private function should_pass_native_login_request( $request ) {
		if( 'POST' === $request['method'] ) {
			return in_array(
				$request['action'],
				[
					'',
					'login',
					'postpass',
					'confirm_admin_email',
				],
				true
			);
		}

		if( ! empty( $request['query']['interim-login'] ) ) {
			return true;
		}

		if( WP_Recovery_Mode_Link_Service::LOGIN_ACTION_ENTER === $request['action'] ) {
			return $this->has_recovery_mode_credentials( $request );
		}

		return in_array(
			$request['action'],
			[
				'checkemail',
				'confirm_admin_email',
				'confirmaction',
			],
			true
		);
	}

	/**
	 * Determine whether a Recovery Mode entry contains its signed credentials.
	 *
	 * WordPress performs the authoritative token validation. This boundary only
	 * prevents an incomplete action query from reopening the native login UI.
	 *
	 * @param array $request Normalized request context.
	 * @return bool
	 */

	private function has_recovery_mode_credentials( $request ) {
		return '' !== $this->get_auth_value( $request['query'], 'rm_token' )
			&& '' !== $this->get_auth_value( $request['query'], 'rm_key' );
	}

	/**
	 * Determine whether a native logout URL was validly issued before activation.
	 *
	 * The administration SPA can retain its localized native logout URL in the
	 * request that enables the custom login. Honoring only its valid core nonce
	 * prevents lockout without reopening the native logout UI or exposing the
	 * custom path to an unauthenticated request.
	 *
	 * @param array $request Normalized request context.
	 * @return bool
	 */

	private function is_valid_native_logout_request( $request ) {
		// AUTHORIZATION INVARIANT: The custom route may pass through Core logout only
		// for the exact action and a valid session-bound Core nonce. URL rewriting does
		// not turn a GET parameter into logout authority.
		if( 'GET' !== $request['method'] || 'logout' !== $request['action'] ) {
			return false;
		}

		$logout_nonce = $this->get_auth_value( $request['query'], '_wpnonce' );

		return $logout_nonce && wp_verify_nonce( $logout_nonce, 'log-out' );
	}

	/**
	 * Determine whether a wp-admin path is a public processor rather than UI.
	 *
	 * @param array $request Normalized request context.
	 * @return bool
	 */

	private function is_public_admin_processor( $request ) {
		return in_array(
			basename( $request['path'] ),
			[
				'admin-ajax.php',
				'admin-post.php',
			],
			true
		);
	}

	/**
	 * Filter the login URL.
	 *
	 * @param string $login_url
	 * @param string $redirect
	 * @param bool $force_reauth
	 * @return string
	 */

	public function filter_login_url( $login_url, $redirect, $force_reauth ) {
		if( ! $this->is_custom_login_enabled() ) {
			return $login_url;
		}

		$args = [];

		if( ! empty( $redirect ) ) {
			$args['redirect_to'] = $redirect;
		}

		if( $force_reauth ) {
			$args['reauth'] = '1';
		}

		return $this->get_custom_login_url( $args );
	}

    /**
	 * Filter the logout URL.
	 *
	 * @param string $logout_url
	 * @param string $redirect
	 * @return string
	 */

	public function filter_logout_url( $logout_url, $redirect ) {
		if( ! $this->is_custom_login_enabled() ) {
			return $logout_url;
		}

		$args = [
			'action' => 'logout',
		];

		if( ! empty( $redirect ) ) {
			$args['redirect_to'] = $redirect;
		}

		return wp_nonce_url( $this->get_custom_login_url( $args ), 'log-out' );
	}

    /**
	 * Filter the lostpassword URL.
	 *
	 * @param string $lostpassword_url
	 * @param string $redirect
	 * @return string
	 */

	public function filter_lostpassword_url( $lostpassword_url, $redirect ) {
		if( ! $this->is_custom_login_enabled() ) {
			return $lostpassword_url;
		}

		$args = [
			'action' => 'lostpassword',
		];

		if( ! empty( $redirect ) ) {
			$args['redirect_to'] = $redirect;
		}

		return $this->get_custom_login_url( $args );
	}

    /**
	 * Filter the register URL.
	 *
	 * @param string $register_url
	 * @return string
	 */

	public function filter_register_url( $register_url ) {
		if( ! $this->is_custom_login_enabled() ) {
			return $register_url;
		}

		if( ! get_option( 'users_can_register' ) ) {
			return '';
		}

		return $this->get_custom_login_url( [
			'action' => 'register',
		] );
	}

    /**
	 * Filter the login redirect.
	 *
	 *  - Redirects back to custom login URL
	 *  - Appends error or lockout state
	 *
	 *  - Respects requested redirect
	 *  - Falls back to admin dashboard
	 *
	 * @param string $redirect_to
	 * @param string $requested_redirect_to
	 * @param mixed $user
	 * @return string
	 */

	public function filter_login_redirect( $redirect_to, $requested_redirect_to, $user ) {
        if( isset( $_GET['interim-login'] ) ) {
            return $redirect_to;
        }

		// A login endpoint is never a useful post-authentication destination.
		// Treat self-referential redirect values as absent to prevent a
		// successful login from appearing to have failed.
		if( $this->is_login_endpoint_url( $requested_redirect_to ) ) {
			$requested_redirect_to = '';
		}

		if( $this->is_login_endpoint_url( $redirect_to ) ) {
			$redirect_to = '';
		}

        if( is_wp_error( $user ) ) {
			$request = $this->get_request_context();

			// WordPress applies login_redirect while initially rendering the
			// empty login form. Only an actual authentication POST may be
			// converted into WPHAVE's failed-login destination.
			if( 'POST' !== $request['method'] ) {
				return $redirect_to ?: admin_url();
			}

            $args = [];

            $username = sanitize_user( wphave_request_string( $_POST, 'log' ) );

            if( $this->is_login_locked_out( $username ) ) {
                $args['locked'] = '1';
            } else {
                $args['login'] = 'failed';
            }

            if( ! empty( $requested_redirect_to ) ) {
                $args['redirect_to'] = $requested_redirect_to;
            }

            return $this->get_custom_login_url( $args );
        }

        if( ! empty( $requested_redirect_to ) ) {
            return $requested_redirect_to;
        }

        return $redirect_to ?: admin_url();
	}

    /**
	 * Return the custom login URL.
	 *
	 * @param array $args
	 * @return string
	 */

	private function get_custom_login_url( $args = [] ) {
		$custom_slug = $this->get_custom_login_slug();
		$is_enabled = $this->is_custom_login_enabled();

		if( ! $is_enabled || empty( $custom_slug ) ) {
			$url = wp_login_url();
		} else {
			$url = home_url( '/' . $custom_slug . '/' );
		}

		if( ! empty( $args ) ) {
			$url = add_query_arg( $args, $url );
		}

		return $url;
	}

}
