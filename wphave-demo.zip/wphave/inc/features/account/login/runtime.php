<?php

require_once wphave_dir() . 'inc/features/security/email-identity.php';

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Login_Runtime {
	/**
	 * Determine whether custom login enabled.
	 *
	 * @return bool
	 */

	private function is_custom_login_enabled() {
		return !empty($this->settings['login_url_enabled']) &&
			WPHAVE_Data_Resources::is_valid_login_slug($this->settings['login_slug'] ?? '');
	}

	/**
	 * Return handled actions.
	 */

	private function get_handled_actions() {
		return [
			'',
			'login',
			'lostpassword',
			'retrievepassword',
			'rp',
			'resetpass',
			'register',
			'logout',
			'postpass',
			'checkemail',
			'confirm_admin_email',
			'confirmaction',
			WP_Recovery_Mode_Link_Service::LOGIN_ACTION_ENTER,
			WP_Recovery_Mode_Link_Service::LOGIN_ACTION_ENTERED,
		];
	}

	/**
	 * Return the request context.
	 *
	 *  - Path
	 *  - Query parameters
	 *  - Request method
	 *  - Login/admin detection flags
	 *
	 * @return array
	 */

	private function get_request_context() {
		$uri = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '';
		$querystring = isset($_SERVER['QUERY_STRING']) ? wp_unslash($_SERVER['QUERY_STRING']) : '';

		$uri_path = $this->normalize_login_request_path(wp_parse_url($uri, PHP_URL_PATH));
		$wp_login_path = $this->normalize_login_request_path(
			wp_parse_url(site_url('wp-login.php'), PHP_URL_PATH),
		);
		$wp_admin_path = $this->normalize_login_request_path(
			wp_parse_url(admin_url(), PHP_URL_PATH),
		);

		$query = [];
		parse_str($querystring, $query);

		$custom_slug = $this->get_custom_login_slug();
		$custom_login_path = $custom_slug
			? $this->normalize_login_request_path(
				wp_parse_url(home_url('/' . $custom_slug . '/'), PHP_URL_PATH),
			)
			: '';
		$raw_action = null;
		if (array_key_exists('action', $query)) {
			$raw_action = $query['action'];
		} elseif (
			'POST' === strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET') &&
			array_key_exists('action', $_POST)
		) {
			$raw_action = wp_unslash($_POST['action']);
		}

		$action = '';
		if (null !== $raw_action) {
			$action = is_string($raw_action) ? sanitize_key($raw_action) : 'wphave_invalid_action';
		}

		return [
			'uri' => $uri,
			'path' => trim($uri_path, '/'),
			'query' => $query,
			'action' => $action,
			'method' => strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET'),
			'is_wp_login' => $uri_path === $wp_login_path,
			'is_wp_admin' =>
				$uri_path === $wp_admin_path ||
				strpos($uri_path, trailingslashit($wp_admin_path)) === 0,
			'is_custom_login' => $custom_login_path && $uri_path === $custom_login_path,
		];
	}

	/** Normalize one URL path for exact authentication-boundary comparisons. */

	private function normalize_login_request_path($path) {
		return '/' . trim((string) $path, '/');
	}

	/**
	 * Handle a failed login attempt.
	 *
	 *  - login=failed
	 *  - locked=1 (if rate limit exceeded)
	 *
	 * @param string $username
	 * @param WP_Error $error
	 * @return void
	 */

	public function handle_login_failed($username, $error = null) {
		$request = $this->get_request_context();

		$was_locked = $this->is_login_locked_out($username);

		if ($this->is_rate_limiting_enabled() && !$was_locked) {
			$this->register_failed_login_attempt($username);
		}

		// AUTHENTICATION/FAILURE INVARIANT: Every wp_authenticate failure consumes
		// the shared budget before transport-specific presentation. XML-RPC and
		// integrations receive their own errors, never browser redirects.
		if (!$request['is_wp_login'] || 'POST' !== $request['method']) {
			return;
		}

		// AUTHENTICATION INVARIANT: Interim UI changes redirects only. Failed
		// credentials always consume the same account and IP budgets first.
		if (isset($_GET['interim-login'])) {
			return;
		}

		if (class_exists('WPHAVE_Account') && WPHAVE_Account::instance()->is_popup_request()) {
			if ($was_locked || $this->is_login_locked_out($username)) {
				WPHAVE_Account::instance()->set_login_failure_status('rate_limited');
			}
			return;
		}

		$args = [];

		if ($was_locked || $this->is_login_locked_out($username)) {
			$args['locked'] = '1';
		} else {
			$args['login'] = 'failed';
		}

		$remaining = $this->is_rate_limiting_enabled()
			? $this->get_remaining_login_attempts($username)
			: 0;

		if ($remaining > 0 && $remaining <= 2) {
			$args['remaining'] = $remaining;
		}

		$redirect_to = $this->get_auth_value($_REQUEST, 'redirect_to');
		if ('' !== $redirect_to) {
			$args['redirect_to'] = esc_url_raw(wp_unslash($redirect_to));
		}

		if (!headers_sent()) {
			wp_safe_redirect($this->get_custom_login_url($args));
			exit();
		}
	}

	/**
	 * Handle the logout.
	 *
	 *  - Custom login page
	 *  - Optional redirect target
	 *
	 * @param array $request
	 * @return void
	 */

	private function handle_logout($request) {
		$logout_nonce = $this->get_auth_value($request['query'], '_wpnonce');

		// AUTHORIZATION INVARIANT: Rewriting the login URL does not weaken Core's
		// logout CSRF boundary. Only the canonical log-out nonce for the active session
		// may terminate it; route knowledge alone carries no authority.
		if (!$logout_nonce || !wp_verify_nonce($logout_nonce, 'log-out')) {
			if (!headers_sent()) {
				wp_safe_redirect(
					$this->get_custom_login_url([
						'login' => 'expired',
					]),
				);
				exit();
			}

			// CSRF INVARIANT: Once output has committed, a redirect cannot be sent.
			// The rejected nonce must still terminate this request before wp_logout().
			$this->do_404();
		}

		$user = wp_get_current_user();

		wp_logout();
		wp_destroy_current_session();
		wp_clear_auth_cookie();

		$requested_redirect = $this->get_auth_value($request['query'], 'redirect_to');
		if ('' !== $requested_redirect) {
			$redirect_to = esc_url_raw($requested_redirect);
			$requested_redirect_to = $redirect_to;
		} else {
			$redirect_to = $this->get_custom_login_url([
				'loggedout' => '1',
			]);
			$requested_redirect_to = '';
		}

		$redirect_to = apply_filters(
			'logout_redirect',
			$redirect_to,
			$requested_redirect_to,
			$user,
		);

		if (empty($redirect_to)) {
			$redirect_to = admin_url();
		}

		$redirect_to = wp_validate_redirect($redirect_to, admin_url());

		if (!headers_sent()) {
			wp_safe_redirect($redirect_to, 302, 'wp_logout');
			exit();
		}
	}

	/**
	 * Handle the registration page request.
	 */

	private function handle_register_page($request) {
		if (!get_option('users_can_register')) {
			$this->do_404();
		}

		$error_msg = '';
		$info_msg = '';

		if ('POST' === $request['method']) {
			if (
				!wp_verify_nonce(
					sanitize_text_field($this->get_auth_value($_POST, 'wphave_nonce')),
					'wphave_auth_action',
				)
			) {
				$this->do_404();
			}

			if (!WPHAVE_Account_Request_Protection::allow('registration')) {
				$this->render_register_page([
					'error' => __(
						'Too many requests. Please try again later.',
						'wphave',
					),
				]);
				return;
			}

			$username = sanitize_user($this->get_auth_value($_POST, 'user_login'));
			$raw_email = $this->get_auth_value($_POST, 'user_email');
			// LOGIN-ROUTE IDENTITY INVARIANT: The custom registration surface
			// cannot create a user under a sanitizer-derived mailbox.
			$email = WPHAVE_Email_Identity::exact($raw_email);
			$honeypot = trim($this->get_auth_value($_POST, 'company_name'));

			if ($this->is_honeypot_enabled() && !empty($honeypot)) {
				$this->do_404();
			}

			if (empty($username) || '' === $raw_email) {
				$error_msg = __('Please enter a username and email address.', 'wphave');
			} elseif ('' === $email) {
				$error_msg = __('Please enter a valid email address.', 'wphave');
			} else {
				$result = register_new_user($username, $email);

				if (is_wp_error($result)) {
					$error_msg = $result->get_error_message();
				} else {
					$info_msg = __('Registration complete. Please check your email.', 'wphave');
				}
			}
		}

		$this->render_register_page([
			'error' => $error_msg,
			'info' => $info_msg,
		]);
	}

	/**
	 * Return the current client IP address.
	 *
	 * @return string
	 */

	private function get_client_ip() {
		return WPHAVE_Client_IP::resolve() ?: '0.0.0.0';
	}

	/**
	 * Render a 404 response.
	 *
	 * @return void
	 */

	private function do_404() {
		status_header(404);
		nocache_headers();

		$template = get_query_template('404');

		if (!empty($template) && file_exists($template)) {
			include $template;
		} else {
			wp_die(__('Page not found.', 'wphave'), __('404 Not Found', 'wphave'), [
				'response' => 404,
			]);
		}

		exit();
	}

	/**
	 * Render the login page.
	 *
	 *  - Login errors
	 *  - Logout state
	 *  - Password reset confirmation
	 *
	 * @param array $request
	 * @return void
	 */

	private function render_login_page($request) {
		$error = '';
		$info = '';
		$redirect_to =
			esc_url_raw($this->get_auth_value($request['query'], 'redirect_to')) ?: admin_url();

		// Prevent loop
		$slug = $this->get_custom_login_slug();

		if (
			empty($_GET['interim-login']) &&
			$slug &&
			wp_parse_url($redirect_to, PHP_URL_PATH) === '/' . $slug . '/'
		) {
			$redirect_to = admin_url();
		}

		if (isset($request['query']['loggedout'])) {
			$info = __('You have been logged out.', 'wphave');
		}

		if (isset($request['query']['reauth'])) {
			$info = __('Please log in again to continue.', 'wphave');
		}

		if (isset($request['query']['login']) && 'failed' === $request['query']['login']) {
			$error = __('The username or password is incorrect.', 'wphave');
		}

		if (isset($request['query']['locked'])) {
			$error = __('Too many failed attempts. Please try again later.', 'wphave');
		}

		if (isset($request['query']['password']) && 'changed' === $request['query']['password']) {
			$info = __('Your password has been changed successfully. Please log in.', 'wphave');
		}

		if (WP_Recovery_Mode_Link_Service::LOGIN_ACTION_ENTERED === $request['action']) {
			$info = __('Recovery Mode initialized. Please log in to continue.', 'wphave');
		}

		$remaining_value = $this->get_auth_value($request['query'], 'remaining');
		if ('' !== $remaining_value) {
			$remaining = (int) $remaining_value;

			if ($remaining <= 2) {
				$info = __(
					'Warning: further failed attempts may temporarily lock your account.',
					'wphave',
				);
			}
		}

		$errors = new WP_Error();

		if (!empty($error)) {
			$errors->add('custom_error', $error);
		}

		if (!empty($info)) {
			$errors->add('custom_message', $info, 'message');
		}

		$errors = apply_filters('wp_login_errors', $errors, $redirect_to);

		$error = '';
		$info = '';
		foreach ($errors->get_error_codes() as $code) {
			$severity = $errors->get_error_data($code);

			foreach ($errors->get_error_messages($code) as $msg) {
				if ($severity === 'message') {
					$info .= $msg . ' ';
				} else {
					$error .= $msg . ' ';
				}
			}
		}

		// WordPress passes rendered error markup, not WP_Error, through this
		// legacy filter. Keeping the native value contract prevents strict
		// third-party callbacks from throwing a TypeError on the custom route.
		$error = apply_filters('login_errors', trim($error));

		$this->render_custom_login_page([
			'error' => $error,
			'info' => $info,
			'redirect_to' => $redirect_to,
		]);
	}

	/**
	 * Render the register page.
	 *
	 * @param array $args
	 * @return void
	 */

	private function render_register_page($args = []) {
		$error = isset($args['error']) ? (string) $args['error'] : '';
		$info = isset($args['info']) ? (string) $args['info'] : '';

		$content = '<h1>' . __('Register', 'wphave') . '</h1>';
		$content .=
			'<form method="post" action="' .
			esc_url($this->get_custom_login_url(['action' => 'register'])) .
			'">';

		// Nonce field
		$content .= wp_nonce_field('wphave_auth_action', 'wphave_nonce', true, false);

		$content .= $this->render_auth_field(
			'wphave-register-username',
			'user_login',
			__('Username', 'wphave'),
			'text',
			'username',
			!empty($error),
		);
		$content .= $this->render_auth_field(
			'wphave-register-email',
			'user_email',
			__('Email Address', 'wphave'),
			'email',
			'email',
			!empty($error),
		);

		// Honeypot field
		if ($this->is_honeypot_enabled()) {
			$content .= $this->render_auth_honeypot();
		}

		ob_start();
		do_action('register_form');
		$content .= ob_get_clean();

		$content .= '<p><button type="submit">' . __('Create Account', 'wphave') . '</button></p>';
		$content .= '</form>';
		$content .= $this->render_auth_navigation([
			$this->get_custom_login_url() => __('Back to login', 'wphave'),
		]);

		$this->render_auth_shell(__('Register', 'wphave'), $content, $error, $info);
	}

	/**
	 * Render the custom login page.
	 *
	 *  - Error messages
	 *  - Informational messages
	 *  - Login form
	 *
	 * @param array $args
	 * @return void
	 */

	private function render_custom_login_page($args = []) {
		$error = isset($args['error']) ? (string) $args['error'] : '';
		$info = isset($args['info']) ? (string) $args['info'] : '';
		$redirect_to = isset($args['redirect_to']) ? (string) $args['redirect_to'] : admin_url();

		nocache_headers();
		header(
			'Content-Type: ' . get_bloginfo('html_type') . '; charset=' . get_bloginfo('charset'),
		);

		$is_interim = isset($_GET['interim-login']);

		if (isset($_GET['reauth']) && !is_user_logged_in()) {
			wp_clear_auth_cookie();
		}

		$action_url = site_url('wp-login.php', 'login_post');
		$form_args = [
			'echo' => false,
			'remember' => true,
			'redirect' => $redirect_to,
			'value_remember' => false,
		];
		$form_top = apply_filters('login_form_top', '', $form_args);
		$form_middle = apply_filters('login_form_middle', '', $form_args);
		$form_bottom = apply_filters('login_form_bottom', '', $form_args);
		ob_start();
		do_action('login_form');
		$login_form = ob_get_clean();

		if ($is_interim) {
			$action_url = add_query_arg('interim-login', '1', $action_url);
		}

		$content = '<h1>' . esc_html__('Log In', 'wphave') . '</h1>';
		$content .= '<form method="post" action="' . esc_url($action_url) . '">';
		$content .= $form_top;
		$content .= $this->render_auth_field(
			'wphave-login-username',
			'log',
			__('Username or Email Address', 'wphave'),
			'text',
			'username',
			!empty($error),
		);
		$content .= $this->render_auth_field(
			'wphave-login-password',
			'pwd',
			__('Password', 'wphave'),
			'password',
			'current-password',
			!empty($error),
		);
		$content .= $form_middle;

		if ($is_interim) {
			$content .= '<input type="hidden" name="interim-login" value="1">';
		}

		$content .= '<input type="hidden" name="testcookie" value="1">';
		$content .=
			'<input type="hidden" name="redirect_to" value="' . esc_attr($redirect_to) . '">';
		$content .=
			'<p class="login-remember"><label><input name="rememberme" type="checkbox" value="forever"> ' .
			__('Remember Me', 'wphave') .
			'</label></p>';
		$content .= $login_form;

		$content .= $form_bottom;
		$content .=
			'<p class="login-submit"><input type="submit" value="' .
			esc_attr__('Log In', 'wphave') .
			'"></p>';
		$content .= '</form>';

		$links = [
			$this->get_custom_login_url(['action' => 'lostpassword']) => __(
				'Forgot password?',
				'wphave',
			),
		];

		if (get_option('users_can_register')) {
			$links[$this->get_custom_login_url(['action' => 'register'])] = __(
				'Register',
				'wphave',
			);
		}

		$content .= $this->render_auth_navigation($links);

		$this->render_auth_shell(__('Log In', 'wphave'), $content, $error, $info);
	}

	/**
	 * Render an auth shell.
	 *
	 * @param string $title
	 * @param string $content
	 * @return void
	 */

	private function render_auth_shell($title, $content, $error = '', $info = '') {
		$site_title = get_bloginfo('name');
		$page_title = $title;
		$title = get_bloginfo('name');
		$site_url = site_url();

		$is_interim = isset($_GET['interim-login']);

		$error_html = '';
		if (!empty($error)) {
			$error_html =
				'<div id="wphave-login-error" class="wphave-login-message is-error" role="alert" aria-live="assertive">' .
				esc_html($error) .
				'</div>';
		}

		$info_html = '';
		if (!empty($info)) {
			$info_html =
				'<div id="wphave-login-info" class="wphave-login-message is-info" role="status" aria-live="polite">' .
				esc_html($info) .
				'</div>';
		}

		$login_header = !$is_interim
			? '<div class="wphave-login-header">
            <div class="wphave-login-header-title">
                ' .
				esc_html($title) .
				'
            </div>
            <div>
                <a href="' .
				esc_url($site_url) .
				'">' .
				__('Go to Homepage', 'wphave') .
				'</a>
            </div>
        </div>'
			: '';

		$document_title = apply_filters(
			'login_title',
			$page_title . ' - ' . $site_title,
			$page_title,
		);
		$body_classes = [
			'wphave-login',
			'login-action-' . sanitize_html_class($GLOBALS['action'] ?? 'login'),
		];
		if (is_rtl()) {
			$body_classes[] = 'rtl';
		}
		$body_classes = apply_filters(
			'login_body_class',
			$body_classes,
			$GLOBALS['action'] ?? 'login',
		);

		echo '<!doctype html>
<html ' .
			get_language_attributes() .
			'>
<head>
	<meta charset="' .
			esc_attr(get_bloginfo('charset')) .
			'">
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>' .
			esc_html($document_title) .
			'</title>
	<link rel="stylesheet" href="' .
			esc_url(wphave_asset_url('inc/features/account/login/login.css')) .
			'">';

		do_action('login_enqueue_scripts');

		// Don't index any of these forms.
		add_filter('wp_robots', 'wp_robots_sensitive_page');
		add_action('login_head', 'wp_strict_cross_origin_referrer');

		do_action('login_head');

		echo '</head>
<body class="' .
			esc_attr(implode(' ', array_map('sanitize_html_class', $body_classes))) .
			'">';

		do_action('login_header');

		echo wp_kses_post($login_header) .
			'
		<main class="wphave-login-wrap" id="main-content">
	        ' .
			wp_kses_post($error_html . $info_html) .
			'
			<div class="wphave-login-box">
				' .
			wp_kses_post($content) .
			'
			</div>
		</main>';

		do_action('login_footer');

		echo '</body></html>';
	}

	/** Return one consistently labelled authentication field. */

	private function render_auth_field(
		$id,
		$name,
		$label,
		$type = 'text',
		$autocomplete = '',
		$invalid = false,
	) {
		$describedby = $invalid ? ' aria-describedby="wphave-login-error"' : '';

		return '<p><label for="' .
			esc_attr($id) .
			'">' .
			esc_html($label) .
			'</label><input id="' .
			esc_attr($id) .
			'" type="' .
			esc_attr($type) .
			'" name="' .
			esc_attr($name) .
			'" required aria-required="true" aria-invalid="' .
			($invalid ? 'true' : 'false') .
			'" autocomplete="' .
			esc_attr($autocomplete) .
			'"' .
			$describedby .
			'></p>';
	}

	/** Keep the bot trap out of keyboard navigation and the accessibility tree. */

	private function render_auth_honeypot() {
		return '<p class="wphave-honeypot" aria-hidden="true"><label>Company<input type="text" name="company_name" tabindex="-1" autocomplete="off"></label></p>';
	}

	/** Return semantic navigation shared by authentication views. */

	private function render_auth_navigation($links) {
		$content =
			'<nav class="wphave-auth-links" aria-label="' .
			esc_attr__('Account access', 'wphave') .
			'"><ul>';
		foreach ($links as $url => $label) {
			$content .= '<li><a href="' . esc_url($url) . '">' . esc_html($label) . '</a></li>';
		}

		return $content . '</ul></nav>';
	}

	/** Read an untrusted request value only when it is scalar text. */

	private function get_auth_value($values, $key) {
		if (!is_array($values) || !isset($values[$key]) || !is_string($values[$key])) {
			return '';
		}

		return wp_unslash($values[$key]);
	}
}
