<?php

/**
 * Bootstrap account and login services.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/account.php';
require_once __DIR__ . '/login/manager.php';
