<?php

/** Shared abuse budget for public account side effects. */

if (!defined('ABSPATH')) {
	exit();
}

require_once __DIR__ . '/../security/rate-limiter.php';
if (!class_exists('WPHAVE_Client_IP')) {
	require_once __DIR__ . '/../security/client-ip.php';
}

final class WPHAVE_Account_Request_Protection {
	public const WINDOW = HOUR_IN_SECONDS;
	public const RESET_LIMIT = 5;
	public const REGISTRATION_LIMIT = 5;

	/** Consume a client budget before identity lookup, mail or account creation. */
	public static function allow(string $action): bool {
		$limits = [
			'reset' => self::RESET_LIMIT,
			'registration' => self::REGISTRATION_LIMIT,
		];

		if (!isset($limits[$action])) {
			return false;
		}

		// ABUSE INVARIANT: The popup and custom login routes share one atomic,
		// client-bound budget per side effect. Usernames and arbitrary headers cannot
		// create fresh buckets; storage failure denies the side effect.
		$key = WPHAVE_Rate_Limiter::client_key('account-' . $action);
		return WPHAVE_Rate_Limiter::increment($key, self::WINDOW) <= $limits[$action];
	}
}
