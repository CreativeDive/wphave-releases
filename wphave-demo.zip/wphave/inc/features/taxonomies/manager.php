<?php

/**
 * Provides REST-backed taxonomy and term administration for manageable
 * public taxonomies while respecting taxonomy-specific WordPress caps.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPHAVE_Taxonomy_Manager {

	const OPTION_OBJECT_TYPES = 'wphave_taxonomy_manager_object_types';
	const CORE_TAXONOMIES = [ 'category', 'post_tag', 'nav_menu', 'link_category', 'post_format' ];

	/**
	 * Return the locked object types.
	 *
	 * @param string $taxonomy
	 * @return array
	 */

	public static function get_locked_object_types( $taxonomy ) {
		$taxonomy = sanitize_key( $taxonomy );

		$locked = [
			'category' => [ 'post' ],
			'post_tag' => [ 'post' ],
			'nav_menu' => [ 'nav_menu_item' ],
			'post_format' => [ 'post' ],
		];

		return $locked[ $taxonomy ] ?? [];
	}

	/**
	 * Applies saved taxonomy object-type assignments and registers REST routes.
	 */

	public static function init() {
		add_action( 'init', [ __CLASS__, 'apply_saved_object_types' ], 100 );
		add_action( 'rest_api_init', [ __CLASS__, 'register_rest_routes' ] );
	}

	/**
	 * Re-applies persisted taxonomy-to-post-type assignments after WordPress
	 * and custom post types have registered.
	 */

	public static function apply_saved_object_types() {
		$map = get_option( self::OPTION_OBJECT_TYPES, [] );

		if ( empty( $map ) || ! is_array( $map ) ) {
			return;
		}

		foreach ( $map as $taxonomy => $post_types ) {
			$taxonomy = sanitize_key( $taxonomy );
			$taxonomy_object = get_taxonomy( $taxonomy );

			if ( ! $taxonomy || ! $taxonomy_object ) {
				continue;
			}

			$post_types = self::sanitize_post_types( $post_types, $taxonomy );
			$current_post_types = array_values( (array) $taxonomy_object->object_type );

			foreach ( array_diff( $current_post_types, $post_types ) as $post_type ) {
				if ( in_array( $post_type, self::get_locked_object_types( $taxonomy ), true ) ) {
					continue;
				}

				unregister_taxonomy_for_object_type( $taxonomy, $post_type );
			}

			foreach ( $post_types as $post_type ) {
				register_taxonomy_for_object_type( $taxonomy, $post_type );
			}
		}
	}

	/**
	 * Return the taxonomies.
	 *
	 * @return array
	 */

	public static function get_taxonomies() {
		$taxonomies = get_taxonomies( [], 'objects' );
		$items = [];

		foreach ( $taxonomies as $taxonomy ) {
			if ( ! self::is_manageable_taxonomy( $taxonomy ) ) {
				continue;
			}

			if ( ! self::can_access_taxonomy( $taxonomy ) ) {
				continue;
			}

			$items[] = self::prepare_taxonomy_item( $taxonomy );
		}

		usort( $items, function( $a, $b ) {
			return strcasecmp( $a['label'], $b['label'] );
		});

		return [
			'items' => $items,
			'postTypes' => self::get_post_types(),
			'stats' => [
				'total' => count( $items ),
				'hierarchical' => count( array_filter( $items, function( $item ) {
					return ! empty( $item['hierarchical'] );
				} ) ),
				'public' => count( array_filter( $items, function( $item ) {
					return ! empty( $item['public'] );
				} ) ),
			],
		];
	}

	/**
	 * Return the post types.
	 *
	 * @return array
	 */

	public static function get_post_types() {
		$post_types = get_post_types([
			'public' => true,
			'show_ui' => true,
		], 'objects' );
		$items = [];

		foreach ( $post_types as $post_type ) {
			if ( 'attachment' === $post_type->name ) {
				continue;
			}

			$items[] = [
				'key' => $post_type->name,
				'value' => $post_type->name,
				'label' => $post_type->labels->name ?? $post_type->name,
				'description' => $post_type->description ?? '',
				'public' => (bool) $post_type->public,
				'hierarchical' => (bool) $post_type->hierarchical,
			];
		}

		usort( $items, function( $a, $b ) {
			return strcasecmp( $a['label'], $b['label'] );
		});

		return $items;
	}

	/**
	 * Prepare the taxonomy item.
	 *
	 * @param WP_Taxonomy|string $taxonomy
	 * @return array|null
	 */

	public static function prepare_taxonomy_item( $taxonomy ) {
		$taxonomy = is_object( $taxonomy ) ? $taxonomy : get_taxonomy( $taxonomy );

		if ( ! $taxonomy ) {
			return null;
		}

		$term_count = wp_count_terms([
			'taxonomy' => $taxonomy->name,
			'hide_empty' => false,
		]);

		return [
			'key' => $taxonomy->name,
			'name' => $taxonomy->name,
			'label' => $taxonomy->labels->name ?? $taxonomy->name,
			'singularLabel' => $taxonomy->labels->singular_name ?? $taxonomy->name,
			'description' => $taxonomy->description ?? '',
			'objectTypes' => array_values( (array) $taxonomy->object_type ),
			'hierarchical' => (bool) $taxonomy->hierarchical,
			'public' => (bool) $taxonomy->public,
			'showUi' => (bool) $taxonomy->show_ui,
			'showInRest' => (bool) $taxonomy->show_in_rest,
			'restBase' => $taxonomy->rest_base ?: $taxonomy->name,
			'queryVar' => $taxonomy->query_var,
			'rewriteSlug' => is_array( $taxonomy->rewrite ) ? ( $taxonomy->rewrite['slug'] ?? '' ) : '',
			'termCount' => is_wp_error( $term_count ) ? 0 : (int) $term_count,
			'isCore' => in_array( $taxonomy->name, self::CORE_TAXONOMIES, true ),
			'lockedObjectTypes' => self::get_locked_object_types( $taxonomy->name ),
			'permissions' => [
				// Use the taxonomy's own caps because custom taxonomies can map these independently.
				'canManageTerms' => current_user_can( $taxonomy->cap->manage_terms ),
				'canEditTerms' => current_user_can( $taxonomy->cap->edit_terms ),
				'canDeleteTerms' => current_user_can( $taxonomy->cap->delete_terms ),
				'canAssignTerms' => current_user_can( $taxonomy->cap->assign_terms ),
				'canManageObjectTypes' => current_user_can( 'manage_options' ) && ! in_array( $taxonomy->name, [ 'nav_menu', 'link_category', 'post_format' ], true ),
			],
		];
	}

	/**
	 * Determine whether manageable taxonomy.
	 *
	 * @param WP_Taxonomy $taxonomy
	 * @return bool
	 */

	public static function is_manageable_taxonomy( $taxonomy ) {
		return $taxonomy && ! empty( $taxonomy->public ) && ! empty( $taxonomy->show_ui );
	}

	/**
	 * Determine whether access taxonomy.
	 *
	 * @param WP_Taxonomy|string $taxonomy
	 * @return bool
	 */

	public static function can_access_taxonomy( $taxonomy ) {
		$taxonomy = is_object( $taxonomy ) ? $taxonomy : get_taxonomy( $taxonomy );

		if ( ! $taxonomy || empty( $taxonomy->cap ) || ! is_object( $taxonomy->cap ) ) {
			return false;
		}

		foreach ( [ 'manage_terms', 'edit_terms', 'delete_terms', 'assign_terms' ] as $cap_key ) {
			if ( isset( $taxonomy->cap->$cap_key ) && current_user_can( $taxonomy->cap->$cap_key ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Determine whether read taxonomies.
	 *
	 * @return bool
	 */

	public static function can_read_taxonomies() {
		$taxonomies = get_taxonomies( [], 'objects' );

		foreach ( $taxonomies as $taxonomy ) {
			if ( self::is_manageable_taxonomy( $taxonomy ) && self::can_access_taxonomy( $taxonomy ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Sanitize and validate taxonomy post types.
	 *
	 * @param array $post_types
	 * @param string $taxonomy
	 * @return array
	 */

	public static function sanitize_post_types( $post_types, $taxonomy = '' ) {
		$post_types = array_map( 'sanitize_key', (array) $post_types );
		$post_types = array_filter( array_unique( $post_types ), [ __CLASS__, 'is_public_post_type' ] );
		$post_types = array_merge( $post_types, self::get_locked_object_types( $taxonomy ) );
		$post_types = array_filter( array_unique( $post_types ), [ __CLASS__, 'is_public_post_type' ] );

		return array_values( $post_types );
	}

	/**
	 * Determine whether public post type.
	 *
	 * @param string $post_type
	 * @return bool
	 */

	public static function is_public_post_type( $post_type ) {
		if ( 'attachment' === $post_type ) {
			return false;
		}

		$post_type_object = get_post_type_object( $post_type );

		return $post_type_object && ! empty( $post_type_object->public ) && ! empty( $post_type_object->show_ui );
	}

	/**
	 * Return the taxonomy or error.
	 *
	 * @param string $taxonomy
	 * @return WP_Taxonomy|WP_Error
	 */

	public static function get_taxonomy_or_error( $taxonomy ) {
		$taxonomy = sanitize_key( $taxonomy );
		$taxonomy_object = get_taxonomy( $taxonomy );

		if ( ! $taxonomy_object || ! self::is_manageable_taxonomy( $taxonomy_object ) ) {
			return new WP_Error( 'invalid_taxonomy', 'Invalid taxonomy.', [ 'status' => 404 ] );
		}

		return $taxonomy_object;
	}

	/**
	 * Return the terms.
	 *
	 * @param string $taxonomy
	 * @param array $args
	 * @return array|WP_Error
	 */

	public static function get_terms( $taxonomy, $args = [] ) {
		$taxonomy_object = self::get_taxonomy_or_error( $taxonomy );

		if ( is_wp_error( $taxonomy_object ) ) {
			return $taxonomy_object;
		}

		// AUTHORIZATION/TAXONOMY-READ INVARIANT: A valid public taxonomy name is
		// an object selector, not authority to enumerate its terms. Reusable domain
		// calls repeat the taxonomy's mapped capability boundary beyond REST dispatch.
		if ( ! self::can_access_taxonomy( $taxonomy_object ) ) {
			return new WP_Error(
				'rest_forbidden',
				__( 'Sorry, you are not allowed to read terms in this taxonomy.', 'wphave' ),
				array( 'status' => 403 )
			);
		}

		$defaults = [
			'number' => 100,
			'paged' => 1,
			'search' => '',
			'hide_empty' => false,
		];

		$args = wp_parse_args( $args, $defaults );
		$number = absint( $args['number'] );
		$paged = absint( $args['paged'] );

		$query_args = [
			'taxonomy' => $taxonomy_object->name,
			'hide_empty' => (bool) $args['hide_empty'],
			'number' => $number ? min( $number, 200 ) : $defaults['number'],
			'offset' => max( 0, ( ( $paged ?: $defaults['paged'] ) - 1 ) * ( $number ?: $defaults['number'] ) ),
			'search' => sanitize_text_field( $args['search'] ),
		];

		$terms = get_terms( $query_args );

		if ( is_wp_error( $terms ) ) {
			return $terms;
		}

		$total = wp_count_terms([
			'taxonomy' => $taxonomy_object->name,
			'hide_empty' => (bool) $args['hide_empty'],
			'search' => sanitize_text_field( $args['search'] ),
		]);

		$payload = [
			'items' => array_values( array_filter( array_map( [ __CLASS__, 'prepare_term_item' ], $terms ) ) ),
			'total' => is_wp_error( $total ) ? count( $terms ) : (int) $total,
		];

		// AUTHORIZATION/TAXONOMY-RESPONSE INVARIANT: Term queries, parent
		// resolution and link generation cross extension-controlled boundaries. The
		// exact taxonomy capability must still hold after complete projection and
		// immediately before its term payload leaves the domain service.
		if ( ! self::can_access_taxonomy( $taxonomy_object ) ) {
			return new WP_Error(
				'rest_forbidden',
				__( 'Sorry, you are not allowed to read terms in this taxonomy.', 'wphave' ),
				array( 'status' => 403 )
			);
		}

		return $payload;
	}

	/**
	 * Prepare the term item.
	 *
	 * @param WP_Term|int $term
	 * @return array|null
	 */

	public static function prepare_term_item( $term ) {
		$term = $term instanceof WP_Term ? $term : get_term( $term );

		if ( ! $term || is_wp_error( $term ) ) {
			return null;
		}

		$parent_name = '';

		if ( $term->parent ) {
			$parent = get_term( $term->parent, $term->taxonomy );
			$parent_name = $parent && ! is_wp_error( $parent ) ? $parent->name : '';
		}

		return [
			'id' => (int) $term->term_id,
			'termTaxonomyId' => (int) $term->term_taxonomy_id,
			'taxonomy' => $term->taxonomy,
			'name' => $term->name,
			'slug' => $term->slug,
			'description' => $term->description,
			'parent' => (int) $term->parent,
			'parentName' => $parent_name,
			'count' => (int) $term->count,
			'link' => get_term_link( $term ),
		];
	}

	/**
	 * Save an object types.
	 *
	 * @param string $taxonomy
	 * @param array $post_types
	 * @return array|WP_Error
	 */

	public static function save_object_types( $taxonomy, $post_types ) {
		$taxonomy_object = self::get_taxonomy_or_error( $taxonomy );

		if ( is_wp_error( $taxonomy_object ) ) {
			return $taxonomy_object;
		}

		// AUTHORIZATION INVARIANT: Changing a taxonomy's object-type bindings is
		// platform configuration and therefore requires manage_options at this final
		// mutation boundary. Historically the REST permission callback was assumed to
		// be the only caller, but public callbacks and domain methods are reusable.
		if ( ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'rest_forbidden', __( 'Sorry, you are not allowed to change taxonomy object types.', 'wphave' ), [ 'status' => 403 ] );
		}

		if ( in_array( $taxonomy_object->name, [ 'nav_menu', 'link_category', 'post_format' ], true ) ) {
			return new WP_Error( 'locked_taxonomy', 'This taxonomy cannot be assigned to other post types.', [ 'status' => 403 ] );
		}

		$post_types = self::sanitize_post_types( $post_types, $taxonomy_object->name );
		$current_post_types = array_values( (array) $taxonomy_object->object_type );
		sort( $current_post_types );

		$next_post_types = $post_types;
		sort( $next_post_types );

		// AUTHORIZATION/TOCTOU INVARIANT: Object-type normalization and registry
		// inspection cross filterable WordPress boundaries. Revalidate manage_options
		// immediately before the first persisted assignment, live-registry or rewrite
		// mutation so the three representations fail closed together.
		if ( ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'rest_forbidden', __( 'Sorry, you are not allowed to change taxonomy object types.', 'wphave' ), [ 'status' => 403 ] );
		}

			$map = WPHAVE_Option_Mutations::mutate( self::OPTION_OBJECT_TYPES, function( $current ) use ( $taxonomy_object, $post_types ) {
				$current[$taxonomy_object->name] = $post_types;
				return $current;
			}, true );

			if( is_wp_error( $map ) ) {
				return $map;
			}

		foreach ( array_diff( (array) $taxonomy_object->object_type, $post_types ) as $post_type ) {
			// Keep WordPress' required core bindings even if they are missing from the request.
			if ( in_array( $post_type, self::get_locked_object_types( $taxonomy_object->name ), true ) ) {
				continue;
			}

			unregister_taxonomy_for_object_type( $taxonomy_object->name, $post_type );
		}

		foreach ( $post_types as $post_type ) {
			register_taxonomy_for_object_type( $taxonomy_object->name, $post_type );
		}

		if ( $current_post_types !== $next_post_types ) {
			flush_rewrite_rules( false );
		}

		$item = self::prepare_taxonomy_item( get_taxonomy( $taxonomy_object->name ) );
		$item['rewriteFlushed'] = $current_post_types !== $next_post_types;

		return $item;
	}

	/**
	 * Creates a term in a manageable taxonomy.
	 *
	 * @param string $taxonomy
	 * @param array $data
	 * @return array|WP_Error
	 */

	/**
	 * Create the term.
	 *
	 * @param string $taxonomy
	 * @param array $data
	 * @return array|WP_Error
	 */

	public static function create_term( $taxonomy, $data ) {
		$taxonomy_object = self::get_taxonomy_or_error( $taxonomy );

		if ( is_wp_error( $taxonomy_object ) ) {
			return $taxonomy_object;
		}

		// AUTHORIZATION INVARIANT: Creating taxonomy state requires the concrete
		// taxonomy's native manage_terms capability at this final mutation boundary;
		// successful REST dispatch alone never grants reusable write authority.
		if ( ! current_user_can( $taxonomy_object->cap->manage_terms ) ) {
			return new WP_Error( 'rest_forbidden', __( 'Sorry, you are not allowed to create terms in this taxonomy.', 'wphave' ), array( 'status' => 403 ) );
		}

		$name = sanitize_text_field( $data['name'] ?? '' );

		if ( ! $name ) {
			return new WP_Error( 'missing_term_name', 'Missing term name.', [ 'status' => 400 ] );
		}

		$args = [
			'slug' => sanitize_title( $data['slug'] ?? '' ),
			'description' => sanitize_textarea_field( $data['description'] ?? '' ),
		];

		if ( ! empty( $taxonomy_object->hierarchical ) ) {
			$args['parent'] = absint( $data['parent'] ?? 0 );
		}

		// AUTHORIZATION/TOCTOU INVARIANT: Term name, slug and description
		// normalization invoke extension-controlled filters. Revalidate the concrete
		// taxonomy's native manage_terms capability after projection and immediately
		// before Core creates persistent taxonomy state.
		if ( ! current_user_can( $taxonomy_object->cap->manage_terms ) ) {
			return new WP_Error( 'rest_forbidden', __( 'Sorry, you are not allowed to create terms in this taxonomy.', 'wphave' ), array( 'status' => 403 ) );
		}

		$result = wp_insert_term( $name, $taxonomy_object->name, $args );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return self::prepare_term_item( get_term( $result['term_id'], $taxonomy_object->name ) );
	}

	/**
	 * Update the term.
	 *
	 * @param int $term_id
	 * @param string $taxonomy
	 * @param array $data
	 * @return array|WP_Error
	 */

	public static function update_term( $term_id, $taxonomy, $data ) {
		$taxonomy_object = self::get_taxonomy_or_error( $taxonomy );

		if ( is_wp_error( $taxonomy_object ) ) {
			return $taxonomy_object;
		}

		// AUTHORIZATION INVARIANT: Updating taxonomy state requires the concrete
		// taxonomy's native edit_terms capability immediately before mutation;
		// direct callback invocation cannot inherit a route's earlier decision.
		if ( ! current_user_can( $taxonomy_object->cap->edit_terms ) ) {
			return new WP_Error( 'rest_forbidden', __( 'Sorry, you are not allowed to edit terms in this taxonomy.', 'wphave' ), array( 'status' => 403 ) );
		}

		$term_id = absint( $term_id );
		$args = [];

		if ( isset( $data['name'] ) ) {
			$args['name'] = sanitize_text_field( $data['name'] );
		}

		if ( isset( $data['slug'] ) ) {
			$args['slug'] = sanitize_title( $data['slug'] );
		}

		if ( isset( $data['description'] ) ) {
			$args['description'] = sanitize_textarea_field( $data['description'] );
		}

		if ( ! empty( $taxonomy_object->hierarchical ) && isset( $data['parent'] ) ) {
			$args['parent'] = absint( $data['parent'] );
		}

		// AUTHORIZATION/TOCTOU INVARIANT: Submitted term fields cross filterable
		// WordPress sanitizers. Revalidate the concrete taxonomy's native edit_terms
		// capability after normalization and immediately before Core persistence.
		if ( ! current_user_can( $taxonomy_object->cap->edit_terms ) ) {
			return new WP_Error( 'rest_forbidden', __( 'Sorry, you are not allowed to edit terms in this taxonomy.', 'wphave' ), array( 'status' => 403 ) );
		}

		$result = wp_update_term( $term_id, $taxonomy_object->name, $args );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return self::prepare_term_item( get_term( $term_id, $taxonomy_object->name ) );
	}

	/**
	 * Delete the term.
	 *
	 * @param int $term_id
	 * @param string $taxonomy
	 * @return array|WP_Error
	 */

	public static function delete_term( $term_id, $taxonomy ) {
		$taxonomy_object = self::get_taxonomy_or_error( $taxonomy );

		if ( is_wp_error( $taxonomy_object ) ) {
			return $taxonomy_object;
		}

		// AUTHORIZATION INVARIANT: Route permission is an early dispatch gate, not
		// deletion authority. The domain mutation must enforce the concrete
		// taxonomy's native delete_terms capability at the final sink so direct
		// callbacks and changes after REST dispatch fail closed.
		if ( ! current_user_can( $taxonomy_object->cap->delete_terms ) ) {
			return new WP_Error( 'rest_forbidden', __( 'Sorry, you are not allowed to delete terms in this taxonomy.', 'wphave' ), array( 'status' => 403 ) );
		}

		$term_id = absint( $term_id );
		$deleted = wp_delete_term( $term_id, $taxonomy_object->name );

		return is_wp_error( $deleted ) ? $deleted : [
			'id' => $term_id,
			'deleted' => (bool) $deleted,
		];
	}

	/**
	 * Registers taxonomy and term manager REST endpoints.
	 */

	public static function register_rest_routes() {

		register_rest_route( 'wphave/v1', '/taxonomies', [
			'methods' => WP_REST_Server::READABLE,
			'callback' => [ __CLASS__, 'rest_get_taxonomies' ],
			'permission_callback' => [ __CLASS__, 'can_read_taxonomies' ],
		]);

		register_rest_route( 'wphave/v1', '/taxonomies/(?P<taxonomy>[\w-]+)/terms', [
			'methods' => WP_REST_Server::READABLE,
			'callback' => [ __CLASS__, 'rest_get_terms' ],
			'permission_callback' => [ __CLASS__, 'can_read_taxonomy_terms' ],
			'args' => [
				'taxonomy' => [
					'required' => true,
					'sanitize_callback' => 'sanitize_key',
				],
				'search' => [
					'sanitize_callback' => 'sanitize_text_field',
				],
				'page' => [
					'default' => 1,
					'sanitize_callback' => 'absint',
				],
				'per_page' => [
					'default' => 100,
					'sanitize_callback' => 'absint',
				],
				'hide_empty' => [
					'default' => false,
					'sanitize_callback' => 'rest_sanitize_boolean',
				],
			],
		]);

		register_rest_route( 'wphave/v1', '/taxonomies/(?P<taxonomy>[\w-]+)/terms', [
			'methods' => WP_REST_Server::CREATABLE,
			'callback' => [ __CLASS__, 'rest_create_term' ],
			'permission_callback' => [ __CLASS__, 'can_manage_taxonomy_terms' ],
			'args' => self::get_term_route_args(),
		]);

		register_rest_route( 'wphave/v1', '/taxonomies/(?P<taxonomy>[\w-]+)/object-types', [
			'methods' => WP_REST_Server::EDITABLE,
			'callback' => [ __CLASS__, 'rest_save_object_types' ],
			'permission_callback' => function() {
				return current_user_can( 'manage_options' );
			},
			'args' => [
				'taxonomy' => [
					'required' => true,
					'sanitize_callback' => 'sanitize_key',
				],
				'post_types' => [
					'required' => true,
					'type' => 'array',
					'items' => [
						'type' => 'string',
					],
					'sanitize_callback' => function( $value ) {
						return array_map( 'sanitize_key', (array) $value );
					},
				],
			],
		]);

		register_rest_route( 'wphave/v1', '/terms/(?P<id>\d+)', [
			'methods' => WP_REST_Server::EDITABLE,
			'callback' => [ __CLASS__, 'rest_update_term' ],
			'permission_callback' => [ __CLASS__, 'can_edit_term' ],
			'args' => self::get_term_route_args( false ),
		]);

		register_rest_route( 'wphave/v1', '/terms/(?P<id>\d+)', [
			'methods' => WP_REST_Server::DELETABLE,
			'callback' => [ __CLASS__, 'rest_delete_term' ],
			'permission_callback' => [ __CLASS__, 'can_delete_term' ],
			'args' => [
				'id' => [
					'required' => true,
					'sanitize_callback' => 'absint',
				],
				'taxonomy' => [
					'required' => true,
					'sanitize_callback' => 'sanitize_key',
				],
			],
		]);
	}

	/**
	 * Return the term route args.
	 *
	 * @param bool $require_name
	 * @return array
	 */

	public static function get_term_route_args( $require_name = true ) {
		return [
			'taxonomy' => [
				'required' => true,
				'sanitize_callback' => 'sanitize_key',
			],
			'name' => [
				'required' => $require_name,
				'sanitize_callback' => 'sanitize_text_field',
			],
			'slug' => [
				'sanitize_callback' => function( $value ) {
					return sanitize_title( $value );
				},
			],
			'description' => [
				'sanitize_callback' => 'sanitize_textarea_field',
			],
			'parent' => [
				'default' => 0,
				'sanitize_callback' => 'absint',
			],
		];
	}

	/**
	 * Determine whether read taxonomy terms.
	 *
	 * @param WP_REST_Request $request
	 * @return bool
	 */

	public static function can_read_taxonomy_terms( WP_REST_Request $request ) {
		$taxonomy = self::get_taxonomy_or_error( $request['taxonomy'] );

		return ! is_wp_error( $taxonomy ) && self::can_access_taxonomy( $taxonomy );
	}

	/**
	 * Determine whether manage taxonomy terms.
	 *
	 * @param WP_REST_Request $request
	 * @return bool
	 */

	public static function can_manage_taxonomy_terms( WP_REST_Request $request ) {
		$taxonomy = self::get_taxonomy_or_error( $request['taxonomy'] );

		// SECURITY INVARIANT: Taxonomy identifiers select their own native capability
		// contract. A general WPHAVE permission never substitutes for manage_terms,
		// edit_terms or delete_terms on the concrete taxonomy.
		return ! is_wp_error( $taxonomy ) && current_user_can( $taxonomy->cap->manage_terms );
	}

	/**
	 * Determine whether edit term.
	 *
	 * @param WP_REST_Request $request
	 * @return bool
	 */

	public static function can_edit_term( WP_REST_Request $request ) {
		$taxonomy = self::get_taxonomy_or_error( $request->get_param( 'taxonomy' ) );

		return ! is_wp_error( $taxonomy ) && current_user_can( $taxonomy->cap->edit_terms );
	}

	/**
	 * Determine whether delete term.
	 *
	 * @param WP_REST_Request $request
	 * @return bool
	 */

	public static function can_delete_term( WP_REST_Request $request ) {
		$taxonomy = self::get_taxonomy_or_error( $request->get_param( 'taxonomy' ) );

		return ! is_wp_error( $taxonomy ) && current_user_can( $taxonomy->cap->delete_terms );
	}

	/**
	 * Handle the get taxonomies REST request.
	 *
	 * @return WP_REST_Response
	 */

	public static function rest_get_taxonomies() {
		// AUTHORIZATION/TAXONOMY-CATALOG INVARIANT: Per-item filtering does not
		// replace collection authorization. Callers without access to any manageable
		// taxonomy receive no management schema or public post-type inventory.
		if ( ! self::can_read_taxonomies() ) {
			return new WP_Error(
				'rest_forbidden',
				__( 'Sorry, you are not allowed to access taxonomies.', 'wphave' ),
				array( 'status' => 403 )
			);
		}

		$payload = self::get_taxonomies();

		// AUTHORIZATION/TAXONOMY-CATALOG-RESPONSE INVARIANT: Registry enumeration,
		// term counts and per-taxonomy capability flags are filterable projections.
		// Revalidate collection access after materialization and before release.
		if ( ! self::can_read_taxonomies() ) {
			return new WP_Error(
				'rest_forbidden',
				__( 'Sorry, you are not allowed to access taxonomies.', 'wphave' ),
				array( 'status' => 403 )
			);
		}

		return rest_ensure_response( $payload );
	}

	/**
	 * Handle the get terms REST request.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response|WP_Error
	 */

	public static function rest_get_terms( WP_REST_Request $request ) {
		$result = self::get_terms( $request['taxonomy'], [
			'search' => $request->get_param( 'search' ),
			'paged' => $request->get_param( 'page' ),
			'number' => $request->get_param( 'per_page' ),
			'hide_empty' => $request->get_param( 'hide_empty' ),
		]);

		return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
	}

	/**
	 * Handle the create term REST request.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response|WP_Error
	 */

	public static function rest_create_term( WP_REST_Request $request ) {
		$result = self::create_term( $request['taxonomy'], $request->get_params() );

		return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
	}

	/**
	 * Handle the save object types REST request.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response|WP_Error
	 */

	public static function rest_save_object_types( WP_REST_Request $request ) {
		$result = self::save_object_types( $request['taxonomy'], $request->get_param( 'post_types' ) );

		return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
	}

	/**
	 * Handle the update term REST request.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response|WP_Error
	 */

	public static function rest_update_term( WP_REST_Request $request ) {
		$result = self::update_term( $request['id'], $request->get_param( 'taxonomy' ), $request->get_params() );

		return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
	}

	/**
	 * Handle the delete term REST request.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response|WP_Error
	 */

	public static function rest_delete_term( WP_REST_Request $request ) {
		$result = self::delete_term( $request['id'], $request->get_param( 'taxonomy' ) );

		return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
	}
}

add_action( 'init', [ 'WPHAVE_Taxonomy_Manager', 'init' ] );
