<?php

/**
 * Apply configured WordPress output maintenance measures.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPHAVE_Maintenance_Manager {

	private array $cleanup = [];

	public function __construct() {
		$this->cleanup = (array) ( wphave_data_get( 'site_settings', 'advanced.maintenance.cleanup', [] ) ?? [] );
		add_action( 'init', [ $this, 'apply_cleanup' ], 1 );
	}

	public function apply_cleanup(): void {
		if( ! empty( $this->cleanup['wp_version_tag'] ) ) remove_action( 'wp_head', 'wp_generator' );
		if( ! empty( $this->cleanup['wp_rsd_link'] ) ) remove_action( 'wp_head', 'rsd_link' );
		if( ! empty( $this->cleanup['wp_wlwmanifest'] ) ) remove_action( 'wp_head', 'wlwmanifest_link' );

		if( ! empty( $this->cleanup['wp_shortlink'] ) ) {
			remove_action( 'wp_head', 'wp_shortlink_wp_head', 10 );
			remove_action( 'wp_head', 'wp_shortlink_header', 10 );
		}

		if( ! empty( $this->cleanup['wp_oembed'] ) ) {
			remove_action( 'wp_head', 'wp_oembed_add_discovery_links', 4 );
			remove_action( 'wp_head', 'wp_oembed_add_discovery_links', 10 );
			add_action( 'wp_enqueue_scripts', [ $this, 'deregister_wp_embed_script' ] );
		}

		if( ! empty( $this->cleanup['wp_rel_link'] ) ) {
			remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0 );
			remove_action( 'wp_head', 'parent_post_rel_link', 10, 0 );
			remove_action( 'wp_head', 'start_post_rel_link', 10, 0 );
			remove_action( 'wp_head', 'index_rel_link' );
		}
	}

	public function deregister_wp_embed_script(): void {
		wp_deregister_script( 'wp-embed' );
	}
}

new WPHAVE_Maintenance_Manager();
