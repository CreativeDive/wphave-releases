<?php

/** Anonymous daily counters, independent of visitor analytics and submission storage. */
final class WPHAVE_Form_Protection_Metrics
{
	const PREFIX = 'wphave_form_protection_';
	const DAYS = 30;
	const REASONS = ['spam', 'rate_limit'];

	public static function init(): void
	{
		// Reuse WordPress daily maintenance instead of owning another scheduled job.
		add_action('wp_scheduled_delete', [__CLASS__, 'cleanup']);
		add_action('deleted_post', [__CLASS__, 'delete_for_post']);
	}

	public static function delete_for_post(int $post_id): void
	{
		global $wpdb;
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
				$wpdb->esc_like(self::PREFIX) .
					'________' .
					$wpdb->esc_like('_' . $post_id . '_') .
					'%',
			),
		);
	}

	/** Called only after public form context validation and canonical source resolution. */
	public static function record(int $post_id, string $form_id, string $reason): bool
	{
		global $wpdb;
		if ($post_id < 1 || '' === $form_id || !in_array($reason, self::REASONS, true)) {
			return false;
		}

		$key =
			self::PREFIX .
			gmdate('Ymd') .
			'_' .
			$post_id .
			'_' .
			hash('sha256', $form_id) .
			'_' .
			$reason;
		// One atomic increment prevents lost updates. These options are never autoloaded
		// or read through the option cache, and contain no submitted or visitor data.
		return false !==
			$wpdb->query(
				$wpdb->prepare(
					"INSERT INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, '1', 'no')
				ON DUPLICATE KEY UPDATE option_value = CAST(option_value AS UNSIGNED) + 1",
					$key,
				),
			);
	}

	/** UTC calendar days, including today. Null means storage could not be read. */
	public static function totals(): ?array
	{
		global $wpdb;
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT SUBSTRING(option_name, %d) AS counter_key, SUM(CAST(option_value AS UNSIGNED)) AS total
				FROM {$wpdb->options}
				WHERE option_name LIKE %s AND option_name >= %s AND option_name < %s
				GROUP BY counter_key",
				strlen(self::PREFIX) + 10,
				$wpdb->esc_like(self::PREFIX) . '%',
				self::PREFIX . gmdate('Ymd', time() - (self::DAYS - 1) * DAY_IN_SECONDS),
				self::PREFIX . gmdate('Ymd', time() + DAY_IN_SECONDS),
			),
		);
		if (!is_array($rows) || $wpdb->last_error) {
			return null;
		}
		$totals = [];
		foreach ($rows as $row) {
			if (
				preg_match('/^(\d+)_([a-f0-9]{64})_(spam|rate_limit)$/D', $row->counter_key, $match)
			) {
				$key = $match[1] . '_' . $match[2];
				$totals[$key][$match[3]] = ($totals[$key][$match[3]] ?? 0) + (int) $row->total;
			}
		}
		return $totals;
	}

	public static function cleanup(): void
	{
		global $wpdb;
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s AND option_name < %s",
				$wpdb->esc_like(self::PREFIX) . '%',
				self::PREFIX . gmdate('Ymd', time() - (self::DAYS - 1) * DAY_IN_SECONDS),
			),
		);
	}
}

WPHAVE_Form_Protection_Metrics::init();
