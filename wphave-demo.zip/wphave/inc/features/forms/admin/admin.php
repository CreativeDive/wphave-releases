<?php

/**
 * Enable management-only global form endpoints.
 */

WPHAVE_Form_Manager::init_management();
