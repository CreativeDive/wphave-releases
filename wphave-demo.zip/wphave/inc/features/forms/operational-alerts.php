<?php

require_once wphave_dir() . 'inc/features/security/email-identity.php';

/**
 * Rate-limited administrator alerts for operational Forms failures.
 */
final class WPHAVE_Form_Operational_Alerts {

	const DEFAULT_COOLDOWN_MINUTES = 60;
	const MIN_COOLDOWN_MINUTES = 15;
	const MAX_COOLDOWN_MINUTES = 1440;
	const LOCK_TTL_SECONDS = 300;
	const MAX_FORM_ID_LENGTH = 128;

	/** Operational codes eligible for administrator notification. */
	const ERROR_CODES = array(
		'missing_form_context',
		'missing_form_schema',
		'audience_storage_failed',
		'mail_delivery_failed',
	);

	/**
	 * Send the first alert immediately and aggregate repeats until the cooldown expires.
	 *
	 * No submitted values, visitor identifiers, upload names or raw error messages
	 * enter this service.
	 */
	public static function notify( string $error_code, string $form_id, int $form_post_id = 0, ?array $settings = null ): bool {
		// PRIVACY INVARIANT: Operational alerts contain bounded error taxonomy and
		// server-owned form identity only. Submitted values, visitor identifiers,
		// filenames and raw exceptions never enter mail or cooldown state.
		$error_code = sanitize_key( $error_code );
		$form_id = substr( sanitize_text_field( $form_id ), 0, self::MAX_FORM_ID_LENGTH );
		$form_post_id = absint( $form_post_id );

		if ( ! in_array( $error_code, self::ERROR_CODES, true ) ) {
			return false;
		}

		$settings = null === $settings ? self::settings() : self::normalize_settings( $settings );

		if ( empty( $settings['enabled'] ) || ! in_array( $error_code, $settings['errorCodes'], true ) ) {
			return false;
		}

		$recipient = self::recipient( $settings );

		if ( ! $recipient ) {
			return false;
		}

		$state_key = 'wphave_form_alert_' . hash( 'sha256', $form_post_id . '|' . $form_id . '|' . $error_code );
		$lock_key = $state_key . '_lock';

		$lock_token = self::acquire_lock( $lock_key );

		if ( ! $lock_token ) {
			return false;
		}

		try {
			$state = get_transient( $state_key );
			$state = is_array( $state ) ? $state : array();
			$last_sent = absint( $state['lastSent'] ?? 0 );
			$pending_count = absint( $state['pendingCount'] ?? 0 );
			$cooldown_seconds = $settings['cooldownMinutes'] * MINUTE_IN_SECONDS;

			if ( $last_sent && time() - $last_sent < $cooldown_seconds ) {
				set_transient(
					$state_key,
					array(
						'lastSent' => $last_sent,
						'pendingCount' => $pending_count + 1,
					),
					$cooldown_seconds * 2
				);

				return false;
			}

			$occurrences = $pending_count + 1;
			$sent = self::send( $recipient, $error_code, $form_id, $form_post_id, $occurrences );

			// A failed alert transport is also cooled down to prevent recursive mail storms.
			set_transient(
				$state_key,
				array(
					'lastSent' => time(),
					'pendingCount' => $sent ? 0 : $occurrences,
				),
				$cooldown_seconds * 2
			);

			return $sent;
		} finally {
			self::release_lock( $lock_key, $lock_token );
		}
	}

	/** Return the validated persisted alert policy. */
	public static function settings(): array {
		$settings = wphave_data_get( 'site_settings', 'forms.alerts', array() );

		return self::normalize_settings( is_array( $settings ) ? $settings : array() );
	}

	private static function normalize_settings( array $settings ): array {
		$error_codes = isset( $settings['errorCodes'] ) && is_array( $settings['errorCodes'] )
			? array_values( array_intersect( self::ERROR_CODES, array_map( 'sanitize_key', $settings['errorCodes'] ) ) )
			: self::ERROR_CODES;
		$cooldown = absint( $settings['cooldownMinutes'] ?? self::DEFAULT_COOLDOWN_MINUTES );

		return array(
			'enabled' => ! empty( $settings['enabled'] ),
			'recipientEmail' => WPHAVE_Email_Identity::exact( $settings['recipientEmail'] ?? '' ),
			'cooldownMinutes' => min( self::MAX_COOLDOWN_MINUTES, max( self::MIN_COOLDOWN_MINUTES, $cooldown ) ),
			'errorCodes' => $error_codes,
		);
	}

	private static function recipient( array $settings ): string {
		$candidates = array(
			$settings['recipientEmail'] ?? '',
			WPHAVE_Form_Settings::delivery_defaults()['emailTo'] ?? '',
			get_option( 'admin_email' ),
		);

		foreach ( $candidates as $candidate ) {
			// ALERT-DELIVERY INVARIANT: Invalid configured mailboxes are skipped,
			// not rewritten into new recipients for operational notices.
			$email = WPHAVE_Email_Identity::exact( $candidate );

			if ( '' !== $email ) {
				return $email;
			}
		}

		return '';
	}

	/** Acquire one atomic per-form/error mail lock with stale-lock recovery. */
	private static function acquire_lock( string $lock_key ): string {
		return WPHAVE_Form_Option_Lock::acquire( $lock_key, self::LOCK_TTL_SECONDS );
	}

	/** Release only the lock acquired by this request. */
	private static function release_lock( string $lock_key, string $token ): void {
		WPHAVE_Form_Option_Lock::release( $lock_key, $token );
	}

	private static function send( string $recipient, string $error_code, string $form_id, int $form_post_id, int $occurrences ): bool {
		$labels = array(
			'missing_form_context' => __( 'Form context is missing', 'wphave' ),
			'missing_form_schema' => __( 'Form configuration could not be loaded', 'wphave' ),
			'audience_storage_failed' => __( 'Audience storage failed', 'wphave' ),
			'mail_delivery_failed' => __( 'Form notification delivery failed', 'wphave' ),
		);
		$form_title = $form_post_id ? sanitize_text_field( get_the_title( $form_post_id ) ) : '';
		$form_title = $form_title ?: $form_id ?: __( 'Unknown form', 'wphave' );
		$site_name = sanitize_text_field( wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) );
		$admin_url = admin_url( 'admin.php?page=workspace' );
		$content = '<p>' . esc_html__( 'WPHAVE detected an operational form failure that may prevent successful submissions.', 'wphave' ) . '</p>';
		$content .= '<table role="presentation" width="100%" cellpadding="6" cellspacing="0">';
		$content .= '<tr><th align="left">' . esc_html__( 'Form', 'wphave' ) . '</th><td>' . esc_html( $form_title ) . '</td></tr>';
		$content .= '<tr><th align="left">' . esc_html__( 'Form ID', 'wphave' ) . '</th><td><code>' . esc_html( $form_id ) . '</code></td></tr>';
		$content .= '<tr><th align="left">' . esc_html__( 'Error', 'wphave' ) . '</th><td>' . esc_html( $labels[ $error_code ] ?? $error_code ) . '</td></tr>';
		$content .= '<tr><th align="left">' . esc_html__( 'Error code', 'wphave' ) . '</th><td><code>' . esc_html( $error_code ) . '</code></td></tr>';
		$content .= '<tr><th align="left">' . esc_html__( 'Occurrences', 'wphave' ) . '</th><td>' . absint( $occurrences ) . '</td></tr>';
		$content .= '<tr><th align="left">' . esc_html__( 'Detected at', 'wphave' ) . '</th><td>' . esc_html( current_time( 'mysql' ) ) . '</td></tr>';
		$content .= '</table>';
		$content .= '<p><a href="' . esc_url( $admin_url ) . '">' . esc_html__( 'Open WPHAVE', 'wphave' ) . '</a></p>';

		$delivery = WPHAVE_Form_Settings::delivery_defaults();
		$message = wphave_build_email_template(
			array(
				'title' => __( 'Operational form alert', 'wphave' ),
				'description' => sprintf( __( 'A form on %s needs attention.', 'wphave' ), $site_name ),
				'content' => $content,
				'footer_content' => esc_html__( 'No submitted field values or visitor identifiers are included in this alert.', 'wphave' ),
			)
		);
		$headers = wphave_email_template_headers(
			array(
				'from_name' => $delivery['emailFromName'] ?? '',
				'from_email' => $delivery['emailFromEmail'] ?? '',
			)
		);

		$subject = sanitize_text_field(
			sprintf( __( '[%1$s] Form alert: %2$s', 'wphave' ), $site_name, $labels[ $error_code ] ?? $error_code )
		);

		return (bool) wp_mail(
			$recipient,
			$subject,
			$message,
			$headers
		);
	}
}
