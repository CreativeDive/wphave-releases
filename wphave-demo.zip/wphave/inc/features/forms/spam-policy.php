<?php

/**
 * Own the site-wide, non-optional baseline for Forms abuse protection.
 */
final class WPHAVE_Form_Spam_Policy {
	public const NONCE_REQUEST_LIMIT = 120;
	public const CAPTCHA_MEDIA_REQUEST_LIMIT = 240;
	public const CONTEXT_REQUEST_LIMIT = 120;
	private const NONCE_REQUEST_WINDOW = MINUTE_IN_SECONDS;
	private const MODES = ['standard', 'strict'];

	/** Return normalized policy values with safe upper and lower bounds. */
	public static function settings(?array $stored = null): array {
		$stored = null === $stored ? wphave_data_get('site_settings', 'forms.spam', []) : $stored;
		$stored = is_array($stored) ? $stored : [];
		// STORED-POLICY INVARIANT: Corrupt option types cannot abort every public
		// form submission. An invalid mode restores the baseline policy.
		$mode = is_string($stored['mode'] ?? null)
			? sanitize_key($stored['mode'])
			: 'standard';
		$mode = in_array($mode, self::MODES, true) ? $mode : 'standard';
		$strict = 'strict' === $mode;
		$minimum_fill_floor = $strict ? 3 : 1;
		$request_ceiling = $strict ? 10 : 20;
		// ABUSE-BUDGET INVARIANT: absint() turns negative stored request
		// counts into larger positive grants. Only positive integers may
		// configure these limits; malformed explicit counts use the tightest
		// supported budget, while missing settings retain their defaults.
		$minimum_fill = self::positive_setting(
			$stored['minimumFillSeconds'] ?? null,
			$minimum_fill_floor,
		);
		$max_requests = self::positive_setting(
			$stored['maxRequests'] ?? null,
			array_key_exists('maxRequests', $stored) ? 5 : $request_ceiling,
		);
		$rate_window = self::positive_setting($stored['rateWindowSeconds'] ?? null, 60);

		return [
			'mode' => $mode,
			'minimumFillSeconds' => min(10, max($minimum_fill_floor, $minimum_fill)),
			'maxRequests' => min($request_ceiling, max(5, $max_requests)),
			'rateWindowSeconds' => min(900, max(60, $rate_window)),
			'scoreThreshold' => $strict ? 3 : 4,
			'extraFieldAllowance' => $strict ? 1 : 3,
		];
	}

	/** Accept only a stored positive integer as a public spam-policy setting. */
	private static function positive_setting($value, int $fallback): int {
		return is_int($value) && $value > 0 ? $value : $fallback;
	}

	/** Consume one public submission request from the shared visitor bucket. */
	public static function is_rate_limited(string $ip, string $user_agent): bool {
		$settings = self::settings();
		$count = WPHAVE_Rate_Limiter::increment(
			self::rate_limit_key($ip, $user_agent),
			$settings['rateWindowSeconds'],
		);

		return $count > $settings['maxRequests'];
	}

	public static function rate_limit_key(string $ip, string $user_agent): string {
		// ABUSE INVARIANT: The retained UA argument is compatibility-only, never budget authority.
		return WPHAVE_Rate_Limiter::client_key('forms-submit', $ip);
	}

	/** Consume one public form-proof request from its dedicated visitor bucket. */
	public static function is_nonce_rate_limited(string $ip, string $user_agent): bool {
		$count = WPHAVE_Rate_Limiter::increment(
			self::nonce_rate_limit_key($ip, $user_agent),
			self::NONCE_REQUEST_WINDOW,
		);

		return $count > self::NONCE_REQUEST_LIMIT;
	}

	/** Return the non-secret transient identity used by form-proof admission. */
	public static function nonce_rate_limit_key(string $ip, string $user_agent): string {
		// ABUSE INVARIANT: Proof issuance has its own header-independent network budget.
		return WPHAVE_Rate_Limiter::client_key('forms-nonce', $ip);
	}

	/** Require this origin when a proof request declares an Origin header. */
	public static function allows_browser_proof_request($fetch_site, $origin = ''): bool {
		// PROOF-BUDGET INVARIANT: A foreign page can embed a public GET without
		// reading its response. Reject browser cross-site and same-site requests
		// before they can drain another visitor's nonce or CAPTCHA budget.
		return is_string($fetch_site) &&
			($fetch_site === '' || in_array(strtolower($fetch_site), ['same-origin', 'none'], true)) &&
			is_string($origin) &&
			($origin === '' || self::is_same_origin_url($origin));
	}

	/** Match the site's exact scheme, host and effective port. */
	public static function is_same_origin_url(string $url): bool {
		$home = wp_parse_url(home_url());
		$target = wp_parse_url($url);
		if (!is_array($home) || !is_array($target)) {
			return false;
		}

		$home_scheme = strtolower((string) ($home['scheme'] ?? ''));
		$target_scheme = strtolower((string) ($target['scheme'] ?? ''));
		$home_host = strtolower((string) ($home['host'] ?? ''));
		$target_host = strtolower((string) ($target['host'] ?? ''));
		$default_ports = ['http' => 80, 'https' => 443];
		$home_port = (int) ($home['port'] ?? ($default_ports[$home_scheme] ?? 0));
		$target_port = (int) ($target['port'] ?? ($default_ports[$target_scheme] ?? 0));

		// ORIGIN INVARIANT: Allowed redirect hosts and URL userinfo never
		// authorize a public proof or a private result bearer destination.
		return $home_scheme !== '' &&
			$home_host !== '' &&
			$home_scheme === $target_scheme &&
			$home_host === $target_host &&
			$home_port === $target_port &&
			!isset($target['user']) &&
			!isset($target['pass']);
	}

	/** Bound repeated image/audio generation for a known CAPTCHA bearer token. */
	public static function is_captcha_media_rate_limited(string $ip): bool {
		return WPHAVE_Rate_Limiter::increment(
			self::captcha_media_rate_limit_key($ip),
			self::NONCE_REQUEST_WINDOW,
		) > self::CAPTCHA_MEDIA_REQUEST_LIMIT;
	}

	/** Use a separate bucket so normal media playback cannot exhaust proof issuance. */
	public static function captcha_media_rate_limit_key(string $ip): string {
		return WPHAVE_Rate_Limiter::client_key('forms-captcha-media', $ip);
	}

	/** Bound valid-nonce submissions before a public form definition is parsed. */
	public static function is_context_rate_limited(string $ip): bool {
		// AVAILABILITY INVARIANT: A once-issued nonce remains reusable even after
		// its form is removed. Such stale claims must not trigger unlimited block
		// parsing while bypassing the accepted-submission budget.
		return WPHAVE_Rate_Limiter::increment(
			self::context_rate_limit_key($ip),
			self::NONCE_REQUEST_WINDOW,
		) > self::CONTEXT_REQUEST_LIMIT;
	}

	public static function context_rate_limit_key(string $ip): string {
		return WPHAVE_Rate_Limiter::client_key('forms-context', $ip);
	}

	/** Evaluate submission heuristics while keeping the detection result private. */
	public static function is_spam(
		array $schema,
		array $submitted,
		array $request_params,
		string $user_agent,
		?array $policy_settings = null,
	): bool {
		$settings = self::settings($policy_settings);
		$spam_score = 0;
		$raw_honeypot_name = $request_params['_wphave_hp_name'] ?? '';
		// HONEYPOT IDENTITY INVARIANT: The renderer emits a case-sensitive
		// six-character suffix. Normalizing it changes the request key and can
		// hide a filled trap whenever the random suffix contains uppercase text.
		$valid_honeypot = is_string($raw_honeypot_name) &&
			(bool) preg_match('/^_wphave_hp_[A-Za-z0-9]{6}$/D', $raw_honeypot_name) &&
			array_key_exists($raw_honeypot_name, $request_params);
		if (!$valid_honeypot) {
			$spam_score += 5;
		}
		$honeypot_name = $valid_honeypot ? $raw_honeypot_name : '';

		if (
			$honeypot_name &&
			(
				!is_scalar($request_params[$honeypot_name]) ||
				'' !== trim((string) $request_params[$honeypot_name])
			)
		) {
			$spam_score += 5;
		}

		$raw_form_time = $request_params['_wphave_form_time'] ?? null;
		// TIME-SIGNAL INVARIANT: The renderer emits an integer Unix second. A
		// missing, malformed or implausibly future value cannot disable the
		// heuristic through PHP casts. This public value is not proof of age.
		$valid_form_time = (is_int($raw_form_time) || is_string($raw_form_time)) &&
			false !== filter_var(
				$raw_form_time,
				FILTER_VALIDATE_INT,
				['options' => ['min_range' => 1]],
			);
		$form_time = $valid_form_time ? (int) $raw_form_time : 0;
		$now = time();
		if (!$valid_form_time || $form_time > $now + 60) {
			$spam_score += 5;
		} elseif ($now - $form_time < $settings['minimumFillSeconds']) {
			$spam_score += 'strict' === $settings['mode'] ? 2 : 1;
		}

		$allowed_keys = array_merge(
			array_keys($schema),
			array_map(
				static fn($name) => $name . '_token',
				array_keys(array_filter($schema, static fn($field) => ($field['type'] ?? '') === 'captcha')),
			),
			self::system_field_keys(),
			$honeypot_name ? [$honeypot_name] : [],
		);
		$extra_fields = array_diff(array_keys($request_params), $allowed_keys);
		if (count($extra_fields) > $settings['extraFieldAllowance']) {
			$spam_score += 2;
		}

		$empty_count = 0;
		foreach ($submitted as $value) {
			if (
				(is_array($value) && empty($value)) ||
				(!is_array($value) && '' === trim((string) $value))
			) {
				++$empty_count;
			}
		}
		if (!empty($submitted) && $empty_count === count($submitted)) {
			$spam_score += 2;
		}

		if ('' === trim($user_agent)) {
			$spam_score += 2;
		}

		return $spam_score >= $settings['scoreThreshold'];
	}

	private static function system_field_keys(): array {
		return [
			'_wphave_hp_name',
			'_wphave_form_time',
			'_wp_http_referer',
			'_wphave_form_nonce',
			'_wphave_form_id',
			'_wphave_post_id',
			'_wphave_form_context_post_id',
			'_wphave_form_source_post_id',
			'_wphave_form_redirect',
			'_wphave_submission_id',
			'_wphave_visitor_id',
			'_wphave_session_id',
			'_wphave_current_url',
			'_wphave_landing_url',
			'_wphave_referrer_url',
			'_wphave_utm_source',
			'_wphave_utm_medium',
			'_wphave_utm_campaign',
			'_wphave_utm_content',
			'_wphave_utm_term',
			'_wphave_goal_id',
			'_wphave_form_event_id',
			'_wphave_language',
			'_wphave_screen_width',
			'_wphave_screen_height',
		];
	}
}
