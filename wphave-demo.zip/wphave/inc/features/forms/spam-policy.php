<?php

/**
 * Own the site-wide, non-optional baseline for Forms abuse protection.
 */
final class WPHAVE_Form_Spam_Policy {

	public const NONCE_REQUEST_LIMIT = 120;
	private const NONCE_REQUEST_WINDOW = MINUTE_IN_SECONDS;
	private const MODES = array( 'standard', 'strict' );

	/** Return normalized policy values with safe upper and lower bounds. */
	public static function settings( ?array $stored = null ): array {
		$stored = null === $stored
			? wphave_data_get( 'site_settings', 'forms.spam', array() )
			: $stored;
		$stored = is_array( $stored ) ? $stored : array();
		$mode = sanitize_key( $stored['mode'] ?? 'standard' );
		$mode = in_array( $mode, self::MODES, true ) ? $mode : 'standard';
		$strict = 'strict' === $mode;
		$minimum_fill_floor = $strict ? 3 : 1;
		$request_ceiling = $strict ? 10 : 20;

		return array(
			'mode'                => $mode,
			'minimumFillSeconds'  => min( 10, max( $minimum_fill_floor, absint( $stored['minimumFillSeconds'] ?? $minimum_fill_floor ) ) ),
			'maxRequests'         => min( $request_ceiling, max( 5, absint( $stored['maxRequests'] ?? $request_ceiling ) ) ),
			'rateWindowSeconds'   => min( 900, max( 60, absint( $stored['rateWindowSeconds'] ?? 60 ) ) ),
			'scoreThreshold'      => $strict ? 3 : 4,
			'extraFieldAllowance' => $strict ? 1 : 3,
		);
	}

	/** Consume one public submission request from the shared visitor bucket. */
	public static function is_rate_limited( string $ip, string $user_agent ): bool {
		$settings = self::settings();
		$count = WPHAVE_Rate_Limiter::increment(
			self::rate_limit_key( $ip, $user_agent ),
			$settings['rateWindowSeconds']
		);

		return $count > $settings['maxRequests'];
	}

	public static function rate_limit_key( string $ip, string $user_agent ): string {
		return 'wphave_rate_' . md5( $ip . $user_agent );
	}

	/** Consume one public form-proof request from its dedicated visitor bucket. */
	public static function is_nonce_rate_limited( string $ip, string $user_agent ): bool {
		$count = WPHAVE_Rate_Limiter::increment(
			self::nonce_rate_limit_key( $ip, $user_agent ),
			self::NONCE_REQUEST_WINDOW
		);

		return $count > self::NONCE_REQUEST_LIMIT;
	}

	/** Return the non-secret transient identity used by form-proof admission. */
	public static function nonce_rate_limit_key( string $ip, string $user_agent ): string {
		return 'wphave_form_nonce_rate_' . md5( $ip . $user_agent );
	}

	/** Evaluate submission heuristics while keeping the detection result private. */
	public static function is_spam(
		array $schema,
		array $submitted,
		array $request_params,
		string $user_agent,
		?array $policy_settings = null
	): bool {
		$settings = self::settings( $policy_settings );
		$spam_score = 0;
		$honeypot_name = sanitize_key( $request_params['_wphave_hp_name'] ?? '' );

		if (
			$honeypot_name
			&& isset( $request_params[ $honeypot_name ] )
			&& '' !== trim( (string) $request_params[ $honeypot_name ] )
		) {
			$spam_score += 5;
		}

		$form_time = isset( $request_params['_wphave_form_time'] )
			? (int) $request_params['_wphave_form_time']
			: 0;
		if ( $form_time && ( time() - $form_time ) < $settings['minimumFillSeconds'] ) {
			$spam_score += 'strict' === $settings['mode'] ? 2 : 1;
		}

		$allowed_keys = array_merge(
			array_keys( $schema ),
			self::system_field_keys(),
			$honeypot_name ? array( $honeypot_name ) : array()
		);
		$extra_fields = array_diff( array_keys( $request_params ), $allowed_keys );
		if ( count( $extra_fields ) > $settings['extraFieldAllowance'] ) {
			$spam_score += 2;
		}

		$empty_count = 0;
		foreach ( $submitted as $value ) {
			if ( ( is_array( $value ) && empty( $value ) ) || ( ! is_array( $value ) && '' === trim( (string) $value ) ) ) {
				++$empty_count;
			}
		}
		if ( ! empty( $submitted ) && $empty_count === count( $submitted ) ) {
			$spam_score += 2;
		}

		if ( '' === trim( $user_agent ) ) {
			$spam_score += 2;
		}

		return $spam_score >= $settings['scoreThreshold'];
	}

	private static function system_field_keys(): array {
		return array(
			'_wphave_hp_name',
			'_wphave_form_time',
			'_wp_http_referer',
			'_wphave_form_nonce',
			'_wphave_form_id',
			'_wphave_post_id',
			'_wphave_form_context_post_id',
			'_wphave_form_source_post_id',
			'_wphave_form_redirect',
			'_wphave_submission_id',
			'_wphave_visitor_id',
			'_wphave_session_id',
			'_wphave_current_url',
			'_wphave_landing_url',
			'_wphave_referrer_url',
			'_wphave_utm_source',
			'_wphave_utm_medium',
			'_wphave_utm_campaign',
			'_wphave_utm_content',
			'_wphave_utm_term',
			'_wphave_goal_id',
			'_wphave_form_event_id',
			'_wphave_language',
			'_wphave_screen_width',
			'_wphave_screen_height',
		);
	}
}
