<?php

/**
 * Expose safe Forms delivery diagnostics and test notifications.
 */

require_once wphave_dir() . 'inc/features/security/boundaries/index.php';
require_once wphave_dir() . 'inc/features/security/email-identity.php';

final class WPHAVE_Form_Settings_REST_Controller {

	private const LAST_TEST_OPTION = 'wphave_forms_last_delivery_test';
	private const TEST_COOLDOWN_SECONDS = 30;
	private const TEST_LOCK_TTL_SECONDS = 120;

	public static function init(): void {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	public static function register_routes(): void {
		register_rest_route(
			'wphave/v1',
			'/forms/delivery-test',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'status' ),
					'permission_callback' => array( __CLASS__, 'can_manage' ),
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( __CLASS__, 'send_test' ),
					'permission_callback' => array( __CLASS__, 'can_manage' ),
					'args'                => array(
						'delivery' => self::delivery_arg_schema(),
					),
				),
			)
		);
	}

	/** Return the closed REST schema for a delivery-test payload. */
	public static function delivery_arg_schema(): array {
		return array(
			'type'                 => 'object',
			'required'             => false,
			'additionalProperties' => false,
			'properties'           => array(
				'recipientEmail' => array(
					'type'      => 'string',
					'maxLength' => 320,
				),
				'fromName' => array(
					'type'      => 'string',
					'maxLength' => 200,
				),
				'fromEmail' => array(
					'type'      => 'string',
					'maxLength' => 320,
				),
				'subject' => array(
					'type'      => 'string',
					'maxLength' => 200,
				),
			),
		);
	}

	public static function can_manage(): bool {
		return current_user_can( 'manage_options' )
			|| current_user_can( 'wphave_manage_settings_forms' )
			|| current_user_can( 'wphave_manage_settings' );
	}

	/** Return the stable fail-closed result for unauthorized settings calls. */
	private static function forbidden(): WP_Error {
		return new WP_Error(
			'wphave_forms_settings_forbidden',
			__( 'Sorry, you are not allowed to manage Forms delivery settings.', 'wphave' ),
			array( 'status' => 403 )
		);
	}

	public static function status() {
		// SECURITY INVARIANT: Delivery diagnostics may disclose configured mail
		// identities and transport state. The callback repeats authorization so
		// direct or composed dispatch cannot bypass the REST route boundary.
		if ( ! self::can_manage() ) {
			return self::forbidden();
		}

		return rest_ensure_response( self::diagnostics() );
	}

	/** Send a real notification through the active WordPress mail transport. */
	public static function send_test( WP_REST_Request $request ) {
		// SECURITY INVARIANT: Authorization must be revalidated immediately before
		// parsing settings, reserving a rate slot, sending mail, or persisting the
		// test result. A nonce or route permission is not authorization here.
		if ( ! self::can_manage() ) {
			return self::forbidden();
		}

		$requested_delivery = $request->get_param( 'delivery' );
		if (
			is_array( $requested_delivery )
			&& ! empty( $requested_delivery['fromEmail'] )
			&& ! is_email( (string) $requested_delivery['fromEmail'] )
		) {
			return new WP_Error(
				'wphave_forms_test_sender_invalid',
				__( 'Configure a valid default sender before sending a Forms test notification.', 'wphave' ),
				array( 'status' => 400 )
			);
		}

		$delivery = self::normalize_delivery( $requested_delivery );
		$settings = WPHAVE_Form_Settings::resolve( array(), $delivery );
		// DELIVERY-TEST INVARIANT: A test sends only to the exact requested or
		// persisted address, never to an address repaired from malformed input.
		$recipient = WPHAVE_Email_Identity::exact( $settings['emailTo'] ?? '' );

		if ( ! $recipient || ! is_email( $recipient ) ) {
			return new WP_Error(
				'wphave_forms_test_recipient_required',
				__( 'Configure a valid default recipient before sending a Forms test notification.', 'wphave' ),
				array( 'status' => 400 )
			);
		}

		if ( ! self::acquire_test_slot() ) {
			return new WP_Error(
				'wphave_forms_test_rate_limited',
				__( 'Wait a moment before sending another Forms test notification.', 'wphave' ),
				array( 'status' => 429 )
			);
		}

		$settings['emailSubject'] = sanitize_text_field( $settings['emailSubject'] ?? '' )
			?: __( 'Forms delivery test', 'wphave' );
		$settings['emailTitle'] = __( 'Forms delivery test', 'wphave' );
		$settings['emailDescription'] = __( 'This notification confirms that the current Forms delivery defaults and active mail transport can accept a message.', 'wphave' );

		$mail_error = '';
		$capture_error = static function( $error ) use ( &$mail_error ): void {
			if ( is_wp_error( $error ) ) {
				$mail_error = WPHAVE_Security_Redactor::diagnostic_text(
					$error->get_error_message(),
					500,
					array( ABSPATH, WP_CONTENT_DIR, WP_PLUGIN_DIR )
				);
			}
		};

		add_action( 'wp_mail_failed', $capture_error );
		$success = WPHAVE_Form_Mailer::send(
			$settings,
			array( 'delivery_status' => __( 'The Forms notification pipeline is working.', 'wphave' ) ),
			array( 'delivery_status' => array( 'type' => 'text', 'label' => __( 'Status', 'wphave' ) ) ),
			array(),
			array()
		);
		remove_action( 'wp_mail_failed', $capture_error );

		$message = $success
			? __( 'WordPress accepted the Forms test notification. Check the recipient inbox to confirm final delivery.', 'wphave' )
			: ( $mail_error ?: __( 'The Forms test notification could not be sent.', 'wphave' ) );
		/*
		 * PRIVACY INVARIANT: Durable delivery diagnostics contain only outcome
		 * metadata. The recipient is already canonical configuration and must not
		 * be duplicated into an independently retained diagnostic option.
		 */
		$last_test = array(
			'success' => $success,
			'testedAt' => gmdate( 'c' ),
			'message' => $message,
		);

		update_option( self::LAST_TEST_OPTION, $last_test, false );

		return rest_ensure_response(
			array_merge(
				self::diagnostics( $delivery ),
				array(
					'success'  => $success,
					'message'  => $message,
					'lastTest' => $last_test,
				)
			)
		);
	}

	private static function diagnostics( ?array $delivery = null ): array {
		$settings = WPHAVE_Form_Settings::resolve( array(), $delivery );
		$transport = class_exists( 'WPHAVE_SMTP' )
			? WPHAVE_SMTP::get_public_info()
			: array( 'transport' => 'wp_mail', 'configured' => true );
		$recipient = WPHAVE_Email_Identity::exact( $settings['emailTo'] ?? '' );
		$from_email = WPHAVE_Email_Identity::exact( $settings['emailFromEmail'] ?? '' )
			?: WPHAVE_Email_Identity::exact( get_option( 'admin_email' ) );
		$from_name = sanitize_text_field( $settings['emailFromName'] ?? '' )
			?: sanitize_text_field( get_bloginfo( 'name' ) );
		$last_test = get_option( self::LAST_TEST_OPTION, array() );

		return array(
			'ready'          => (bool) ( $recipient && is_email( $recipient ) && $from_email && is_email( $from_email ) && ! empty( $transport['configured'] ) ),
			'recipient'      => $recipient,
			'fromEmail'      => $from_email,
			'fromName'       => $from_name,
			'subject'        => sanitize_text_field( $settings['emailSubject'] ?? '' ) ?: __( 'Form submission', 'wphave' ),
			'transport'      => sanitize_key( $transport['transport'] ?? 'wp_mail' ),
			'transportReady' => ! empty( $transport['configured'] ),
			'lastTest'       => is_array( $last_test ) ? $last_test : array(),
		);
	}

	private static function normalize_delivery( $delivery ): ?array {
		if ( ! is_array( $delivery ) ) {
			return null;
		}

		return array(
			'emailTo'        => WPHAVE_Email_Identity::exact( $delivery['recipientEmail'] ?? '' ),
			'emailFromName'  => sanitize_text_field( $delivery['fromName'] ?? '' ),
			'emailFromEmail' => WPHAVE_Email_Identity::exact( $delivery['fromEmail'] ?? '' ),
			'emailSubject'   => sanitize_text_field( $delivery['subject'] ?? '' ),
		);
	}

	/** Atomically reserve one short-lived delivery-test slot for the current user. */
	private static function acquire_test_slot(): bool {
		$user_id = get_current_user_id();
		$rate_key = 'wphave_forms_delivery_test_rate_' . $user_id;
		$lock_key = $rate_key . '_lock';
		$lock_token = WPHAVE_Form_Option_Lock::acquire( $lock_key, self::TEST_LOCK_TTL_SECONDS );

		if ( ! $lock_token ) {
			return false;
		}

		try {
			if ( get_transient( $rate_key ) ) {
				return false;
			}

			// DELIVERY INVARIANT: The lock serializes contenders, but only an exact
			// persisted cooldown slot authorizes the external mail side effect. Failed
			// or ambiguous transient storage must deny the test send.
			return set_transient( $rate_key, 1, self::TEST_COOLDOWN_SECONDS )
				&& 1 === (int) get_transient( $rate_key );
		} finally {
			WPHAVE_Form_Option_Lock::release( $lock_key, $lock_token );
		}
	}
}

WPHAVE_Form_Settings_REST_Controller::init();
