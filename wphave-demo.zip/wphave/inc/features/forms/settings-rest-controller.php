<?php

/**
 * Expose safe Forms delivery diagnostics and test notifications.
 */

require_once wphave_dir() . 'inc/features/security/boundaries/index.php';
require_once wphave_dir() . 'inc/features/security/email-identity.php';
require_once wphave_dir() . 'inc/features/security/rest-body-budget.php';
require_once wphave_dir() . 'inc/features/security/site-signature.php';

final class WPHAVE_Form_Settings_REST_Controller {

	private const LAST_TEST_OPTION = 'wphave_forms_last_delivery_test';
	private const TEST_COOLDOWN_SECONDS = 30;
	private const TEST_LOCK_TTL_SECONDS = 120;
	private const MAX_TEST_REQUEST_BYTES = 8192;

	public static function init(): void {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	public static function register_routes(): void {
		// BODY-ADMISSION INVARIANT: Reject oversized JSON before WordPress
		// decodes route arguments; Core also matches route casing loosely.
		WPHAVE_REST_Body_Budget::protect(
			'POST',
			'~^/wphave/v1/forms/delivery-test$~D',
			self::MAX_TEST_REQUEST_BYTES
		);
		register_rest_route(
			'wphave/v1',
			'/forms/delivery-test',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'status' ),
					'permission_callback' => array( __CLASS__, 'can_manage' ),
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( __CLASS__, 'send_test' ),
					'permission_callback' => array( __CLASS__, 'can_manage' ),
					'args'                => array(
						'delivery' => self::delivery_arg_schema(),
					),
				),
			)
		);
	}

	/** Return the closed REST schema for a delivery-test payload. */
	public static function delivery_arg_schema(): array {
		return array(
			'type'                 => 'object',
			'required'             => false,
			'additionalProperties' => false,
			'properties'           => array(
				'recipientEmail' => array(
					'type'      => 'string',
					'maxLength' => 320,
				),
				'fromName' => array(
					'type'      => 'string',
					'maxLength' => 200,
				),
				'fromEmail' => array(
					'type'      => 'string',
					'maxLength' => 320,
				),
				'subject' => array(
					'type'      => 'string',
					'maxLength' => 200,
				),
			),
		);
	}

	public static function can_manage(): bool {
		return current_user_can( 'manage_options' )
			|| current_user_can( 'wphave_manage_settings_forms' )
			|| current_user_can( 'wphave_manage_settings' );
	}

	/** Return the stable fail-closed result for unauthorized settings calls. */
	private static function forbidden(): WP_Error {
		return new WP_Error(
			'wphave_forms_settings_forbidden',
			__( 'Sorry, you are not allowed to manage Forms delivery settings.', 'wphave' ),
			array( 'status' => 403 )
		);
	}

	public static function status() {
		// SECURITY INVARIANT: Delivery diagnostics may disclose configured mail
		// identities and transport state. The callback repeats authorization so
		// direct or composed dispatch cannot bypass the REST route boundary.
		if ( ! self::can_manage() ) {
			return self::forbidden();
		}

		$diagnostics = self::diagnostics();
		// AUTHORIZATION INVARIANT: Settings and option reads may invoke filters
		// that change the current user. Never return assembled private identities
		// after authority has been lost.
		if ( ! self::can_manage() ) {
			return self::forbidden();
		}

		return self::private_response( $diagnostics );
	}

	/** Send a real notification through the active WordPress mail transport. */
	public static function send_test( WP_REST_Request $request ) {
		// SECURITY INVARIANT: Authorization must be revalidated immediately before
		// parsing settings, reserving a rate slot, sending mail, or persisting the
		// test result. A nonce or route permission is not authorization here.
		if ( ! self::can_manage() ) {
			return self::forbidden();
		}
		// BODY-ADMISSION INVARIANT: Direct callback calls bypass the REST
		// preflight and must reject an oversized raw body before parameter reads.
		$body_error = WPHAVE_REST_Body_Budget::check( $request, self::MAX_TEST_REQUEST_BYTES );
		if ( $body_error ) {
			return $body_error;
		}

		$requested_delivery = $request->get_param( 'delivery' );
		if (
			is_array( $requested_delivery )
			&& array_key_exists( 'fromEmail', $requested_delivery )
			&& '' !== $requested_delivery['fromEmail']
			&& '' === WPHAVE_Email_Identity::exact( $requested_delivery['fromEmail'] )
		) {
			// SENDER IDENTITY INVARIANT: A direct callback may bypass the REST
			// schema. An explicit malformed sender must not be cast, repaired or
			// silently replaced by the WordPress admin mailbox.
			return new WP_Error(
				'wphave_forms_test_sender_invalid',
				__( 'Configure a valid default sender before sending a Forms test notification.', 'wphave' ),
				array( 'status' => 400 )
			);
		}

		$delivery = self::normalize_delivery( $requested_delivery );
		$settings = WPHAVE_Form_Settings::resolve( array(), $delivery );
		// DELIVERY-TEST INVARIANT: A test sends only to the exact requested or
		// persisted address, never to an address repaired from malformed input.
		$recipient = WPHAVE_Email_Identity::exact( $settings['emailTo'] ?? '' );

		if ( ! $recipient || ! is_email( $recipient ) ) {
			return new WP_Error(
				'wphave_forms_test_recipient_required',
				__( 'Configure a valid default recipient before sending a Forms test notification.', 'wphave' ),
				array( 'status' => 400 )
			);
		}
		// AUTHORIZATION INVARIANT: Resolution may invoke extensible settings
		// code. Check authority before reserving a slot or sending mail.
		if ( ! self::can_manage() ) {
			return self::forbidden();
		}

		if ( ! self::acquire_test_slot() ) {
			return new WP_Error(
				'wphave_forms_test_rate_limited',
				__( 'Wait a moment before sending another Forms test notification.', 'wphave' ),
				array( 'status' => 429 )
			);
		}

		$settings['emailSubject'] = sanitize_text_field( $settings['emailSubject'] ?? '' )
			?: __( 'Forms delivery test', 'wphave' );
		$settings['emailTitle'] = __( 'Forms delivery test', 'wphave' );
		$settings['emailDescription'] = __( 'This notification confirms that the current Forms delivery defaults and active mail transport can accept a message.', 'wphave' );

		$mail_error = '';
		$capture_error = static function( $error ) use ( &$mail_error ): void {
			if ( is_wp_error( $error ) ) {
				$mail_error = WPHAVE_Security_Redactor::diagnostic_text(
					$error->get_error_message(),
					500,
					array( ABSPATH, WP_CONTENT_DIR, WP_PLUGIN_DIR )
				);
			}
		};

		add_action( 'wp_mail_failed', $capture_error );
		try {
			$success = WPHAVE_Form_Mailer::send(
				$settings,
				array( 'delivery_status' => __( 'The Forms notification pipeline is working.', 'wphave' ) ),
				array( 'delivery_status' => array( 'type' => 'text', 'label' => __( 'Status', 'wphave' ) ) ),
				array(),
				array()
			);
		} catch ( Throwable $error ) {
			// TRANSPORT-OUTCOME INVARIANT: A throwing mail hook may already
			// have sent the test. Never expose its exception or claim a
			// definite failure; keep the reserved cooldown in force.
			$success = false;
			$mail_error = __( 'The mail transport did not confirm whether the test notification was sent. Check the inbox before trying again.', 'wphave' );
		} finally {
			// HOOK-LIFETIME INVARIANT: An exception cannot retain a diagnostic
			// listener for later, unrelated mail in the same request.
			remove_action( 'wp_mail_failed', $capture_error );
		}
		// AUTHORIZATION INVARIANT: Mail hooks can change the current user. Do
		// not persist or disclose diagnostics after authority is lost.
		if ( ! self::can_manage() ) {
			return self::forbidden();
		}

		$message = $success
			? __( 'WordPress accepted the Forms test notification. Check the recipient inbox to confirm final delivery.', 'wphave' )
			: ( $mail_error ?: __( 'The Forms test notification could not be sent.', 'wphave' ) );
		/*
		 * PRIVACY INVARIANT: Durable delivery diagnostics contain only outcome
		 * metadata. The recipient is already canonical configuration and must not
		 * be duplicated into an independently retained diagnostic option.
		 */
		$last_test = array(
			'success' => $success,
			'testedAt' => gmdate( 'c' ),
			'message' => $message,
			'testId' => wp_generate_uuid4(),
		);
		// WRITE-IDENTITY INVARIANT: A private signed UUID distinguishes equal
		// results within one second without exposing it through REST.
		$signature = self::last_test_signature( $last_test );
		$persisted_last_test = array();
		if ( '' !== $signature ) {
			$last_test['signature'] = $signature;
			$stored = update_option( self::LAST_TEST_OPTION, $last_test, false );
			// PERSISTENCE INVARIANT: Report a new lastTest only when the exact
			// signed option write succeeds and survives immediate readback.
			if ( $stored && get_option( self::LAST_TEST_OPTION, array() ) === $last_test ) {
				$persisted_last_test = self::safe_last_test( $last_test );
			}
		}

		$diagnostics = self::diagnostics( $delivery );
		// AUTHORIZATION INVARIANT: Diagnostic assembly may invoke settings or
		// option filters, so recheck before returning private identities.
		if ( ! self::can_manage() ) {
			return self::forbidden();
		}

		return self::private_response(
			array_merge(
				$diagnostics,
				array(
					'success'  => $success,
					'message'  => $message,
					'lastTest' => $persisted_last_test,
				)
			)
		);
	}

	/** CACHE-PRIVACY INVARIANT: Configured mail identities are never cacheable. */
	private static function private_response( array $data ): WP_REST_Response {
		$response = rest_ensure_response( $data );
		$response->header( 'Cache-Control', 'private, no-store, max-age=0' );

		return $response;
	}

	private static function diagnostics( ?array $delivery = null ): array {
		$settings = WPHAVE_Form_Settings::resolve( array(), $delivery );
		$transport = class_exists( 'WPHAVE_SMTP' )
			? WPHAVE_SMTP::get_public_info()
			: array( 'transport' => 'wp_mail', 'configured' => true );
		$recipient = WPHAVE_Email_Identity::exact( $settings['emailTo'] ?? '' );
		$from_email = WPHAVE_Email_Identity::exact( $settings['emailFromEmail'] ?? '' )
			?: WPHAVE_Email_Identity::exact( get_option( 'admin_email' ) );
		$from_name = sanitize_text_field( $settings['emailFromName'] ?? '' )
			?: sanitize_text_field( get_bloginfo( 'name' ) );
		$last_test = get_option( self::LAST_TEST_OPTION, array() );

		return array(
			'ready'          => (bool) ( $recipient && is_email( $recipient ) && $from_email && is_email( $from_email ) && ! empty( $transport['configured'] ) ),
			'recipient'      => $recipient,
			'fromEmail'      => $from_email,
			'fromName'       => $from_name,
			'subject'        => sanitize_text_field( $settings['emailSubject'] ?? '' ) ?: __( 'Form submission', 'wphave' ),
			'transport'      => sanitize_key( $transport['transport'] ?? 'wp_mail' ),
			'transportReady' => ! empty( $transport['configured'] ),
			'lastTest'       => self::safe_last_test( $last_test ),
		);
	}

	/** Project only the result fields written by this controller. */
	private static function safe_last_test( $stored ): array {
		// INTEGRITY INVARIANT: Persisted options are not trusted REST output.
		// Project only a bounded, site-signed result with the expected shape.
		if (
			! is_array( $stored )
			|| ! is_bool( $stored['success'] ?? null )
			|| ! is_string( $stored['testedAt'] ?? null )
			|| 1 !== preg_match( '/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\+00:00$/D', $stored['testedAt'] )
			|| ! is_string( $stored['message'] ?? null )
			|| strlen( $stored['message'] ) > 2048
			|| ! is_string( $stored['signature'] ?? null )
			|| 1 !== preg_match( '/^[a-f0-9]{64}$/D', $stored['signature'] )
			|| (
				array_key_exists( 'testId', $stored )
				&& (
					! is_string( $stored['testId'] )
					|| 1 !== preg_match( '/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/D', $stored['testId'] )
				)
			)
		) {
			return array();
		}
		$expected = self::last_test_signature( $stored );
		if ( '' === $expected || ! hash_equals( $expected, $stored['signature'] ) ) {
			return array();
		}

		return array(
			'success'  => $stored['success'],
			'testedAt' => $stored['testedAt'],
			'message'  => sanitize_text_field( $stored['message'] ),
		);
	}

	/** Bind persisted test text to the site's private signing key. */
	private static function last_test_signature( array $record ): string {
		// SITE-BOUNDARY INVARIANT: Bind outcome to this module and blog while
		// accepting old site-bound records without a test UUID.
		$payload = array(
			$record['success'],
			$record['testedAt'],
			$record['message'],
		);
		if ( array_key_exists( 'testId', $record ) ) {
			$payload[] = $record['testId'];
		}

		return WPHAVE_Site_Signature::sign( 'forms-delivery-test:v2', $payload );
	}

	private static function normalize_delivery( $delivery ): ?array {
		if ( ! is_array( $delivery ) ) {
			return null;
		}

		return array(
			'emailTo'        => WPHAVE_Email_Identity::exact( $delivery['recipientEmail'] ?? '' ),
			'emailFromName'  => sanitize_text_field( is_string( $delivery['fromName'] ?? null ) ? $delivery['fromName'] : '' ),
			'emailFromEmail' => WPHAVE_Email_Identity::exact( $delivery['fromEmail'] ?? '' ),
			'emailSubject'   => sanitize_text_field( is_string( $delivery['subject'] ?? null ) ? $delivery['subject'] : '' ),
		);
	}

	/** Atomically reserve one short-lived delivery-test slot for the current user. */
	private static function acquire_test_slot(): bool {
		$user_id = get_current_user_id();
		$rate_key = 'wphave_forms_delivery_test_rate_' . $user_id;
		$lock_key = $rate_key . '_lock';
		$lock_token = WPHAVE_Form_Option_Lock::acquire( $lock_key, self::TEST_LOCK_TTL_SECONDS );

		if ( ! $lock_token ) {
			return false;
		}

		try {
			// COOLDOWN INVARIANT: Any present value reserves the slot. A corrupt
			// falsey value such as 0 or [] must not reopen mail authority.
			if ( false !== get_transient( $rate_key ) ) {
				return false;
			}

			// DELIVERY INVARIANT: The lock serializes contenders, but only an exact
			// persisted cooldown slot authorizes the external mail side effect. Failed
			// or ambiguous transient storage must deny the test send.
			if ( ! set_transient( $rate_key, 1, self::TEST_COOLDOWN_SECONDS ) ) {
				return false;
			}
			// CACHE-SHAPE INVARIANT: Core may return integer 1 from an object
			// cache or string "1" from options. Casting an array or object to 1
			// must never grant permission to send an external notification.
			return in_array( get_transient( $rate_key ), array( 1, '1' ), true );
		} finally {
			WPHAVE_Form_Option_Lock::release( $lock_key, $lock_token );
		}
	}
}

WPHAVE_Form_Settings_REST_Controller::init();
