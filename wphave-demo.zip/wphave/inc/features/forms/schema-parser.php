<?php

/**
 * Extract normalized form schemas from block content.
 *
 *  - Extract form fields from block tree
 *  - Normalize field definitions
 *  - Ensure unique field names
 *  - Sanitize all relevant data
 *
 *  - Recursive block parsing
 *  - Neutral syntax cache keyed by current source
 *  - Schema-driven processing
 *
 *  - Ordinary field names match their rendered request keys exactly
 *  - All labels sanitized (sanitize_text_field)
 *  - Option values retain their rendered identity for exact validation
 *
 *  - Access projection is recomputed on every call
 *  - Early returns for invalid states
 */

class WPHAVE_Form_Schema_Parser {
	const MAX_DEPTH = 30;
	const MAX_FIELDS = 200;
	const MAX_OPTIONS = 200;
	const MAX_SOURCE_BYTES = 2 * 1024 * 1024;
	const INVALID_SCHEMA_FIELD = '_wphave_invalid_form_schema';

	/** Parse a persisted form source only within the public request work budget. */
	public static function parse_source_blocks(string $content): array {
		// FORM SOURCE INVARIANT: Admission, settings and schema must all reject
		// oversized block sources before WordPress builds their complete tree.
		if (strlen($content) > self::MAX_SOURCE_BYTES) {
			return [];
		}

		return parse_blocks($content);
	}

	/**
	 * Parse the post.
	 *
	 *  - Uses static cache (per request)
	 *
	 * @param int $post_id
	 * @param string|null $form_id Form identifier.
	 * @return array
	 */

	public static function parse_post(
		int $post_id,
		?string $form_id = null,
		int $condition_post_id = 0,
	): array {
		static $cache = [];

		// Hard guard: invalid ID
		if ($post_id <= 0) {
			return [];
		}

		$post = get_post($post_id);
		$condition_post_id = $condition_post_id > 0 ? $condition_post_id : $post_id;

		// Guard: invalid post or empty content
		if (!$post || empty($post->post_content)) {
			return [];
		}

		// CACHE INVARIANT: cache only neutral syntax for the exact current source.
		// Visitor roles, time rules and public render scopes are re-evaluated below
		// on every call; a previous privileged schema is never an access grant.
		if (!isset($cache[$post_id]) || $cache[$post_id]['content'] !== $post->post_content) {
			$cache[$post_id] = [
				'content' => $post->post_content,
				'blocks' => self::parse_source_blocks($post->post_content),
			];
		}
		$blocks = $cache[$post_id]['blocks'];

		// Guard: unexpected parse result
		if (!is_array($blocks)) {
			return [];
		}

		if ($form_id !== null) {
			// AUTHORITY INVARIANT: A schema match is not a public-placement grant.
			// Submission and CAPTCHA callers must first prove one unique visible
			// form source through WPHAVE_Form_Public_Context; this parser only
			// extracts fields from that already authorized source.
			$form_block = self::find_form_block($blocks, $form_id, 0, $condition_post_id);

			if (!$form_block) {
				return [];
			}

			$blocks = is_array($form_block['innerBlocks'] ?? null)
				? $form_block['innerBlocks']
				: [];
		}

		return self::parse_blocks($blocks, 0, $condition_post_id);
	}

	/**
	 * Find a specific form block in a nested block tree.
	 *
	 * @param array $blocks Parsed blocks.
	 * @param string|null $form_id Form identifier; null selects the first allowed form.
	 * @return array|null
	 */

	public static function find_form_block(
		array $blocks,
		?string $form_id = null,
		int $depth = 0,
		int $post_id = 0,
	): ?array {
		$matches = [];
		self::collect_form_blocks($blocks, $form_id, $depth, 1, $matches, $post_id);
		return $matches[0] ?? null;
	}

	/** Require one complete visible match for a reusable Form Loader source. */
	public static function find_unique_form_block(array $blocks, string $form_id, int $post_id = 0): ?array {
		$matches = [];
		$complete = self::collect_form_blocks($blocks, $form_id, 0, 2, $matches, $post_id);
		// LOADER IDENTITY INVARIANT: The loader renders the whole document;
		// selecting its first matching form may omit a later CAPTCHA or consent.
		return $complete && count($matches) === 1 ? $matches[0] : null;
	}

	/** Traverse visible paths once, stopping after enough matches or unsafe depth. */
	private static function collect_form_blocks(
		array $blocks,
		?string $form_id,
		int $depth,
		int $limit,
		array &$matches,
		int $post_id,
	): bool {
		if ($depth > self::MAX_DEPTH) {
			return false;
		}
		foreach ($blocks as $block) {
			// IDENTITY INVARIANT: select only a form whose complete path is allowed.
			// Admission, settings and schema all share this selection.
			if (!WPHAVE_Block_Projection::allows($block, false, $post_id)) {
				continue;
			}
			if (self::is_reference_block($block['blockName'] ?? '')) {
				// DEFINITION INVARIANT: Reference blocks render their selected
				// document, never serialized children. An inert child form may
				// not replace the visible form's schema or delivery settings.
				continue;
			}

			if (
				($block['blockName'] ?? '') === 'wphave/form' &&
				($form_id === null || ($block['attrs']['formId'] ?? '') === $form_id)
			) {
				$matches[] = $block;
				if (count($matches) >= $limit) {
					return true;
				}
			}

			if (!empty($block['innerBlocks']) && is_array($block['innerBlocks'])) {
				if (!self::collect_form_blocks($block['innerBlocks'], $form_id, $depth + 1, $limit, $matches, $post_id)) {
					return false;
				}
				if (count($matches) >= $limit) {
					return true;
				}
			}
		}

		return true;
	}

	/**
	 * Parse the blocks.
	 *
	 *  - Prevents infinite recursion (depth limit)
	 *  - Ignores invalid block structures
	 *
	 * @param array $blocks
	 * @param int $depth
	 * @return array
	 */

	public static function parse_blocks(array $blocks, int $depth = 0, int $post_id = 0): array {
		// SCHEMA COMPLETENESS INVARIANT: A truncated tree cannot prove that
		// every rendered CAPTCHA is present in the authoritative schema.
		if ($depth > self::MAX_DEPTH) {
			return self::invalid_schema();
		}

		$fields = [];

		foreach ($blocks as $block) {
			// AUTHORIZATION INVARIANT: a denied field or ancestor contributes no
			// schema, required constraint, label, options or accepted input name.
			if (!WPHAVE_Block_Projection::allows($block, false, $post_id)) {
				continue;
			}
			if (self::is_reference_block($block['blockName'] ?? '')) {
				continue;
			}

			if (count($fields) >= self::MAX_FIELDS) {
				if (self::contains_field_block($block, $depth, $post_id)) {
					self::mark_invalid_schema($fields);
					break;
				}
				continue;
			}

			$block_name = is_string($block['blockName'] ?? null)
				? $block['blockName']
				: '';

			// Skip invalid blocks
			if (!$block_name) {
				continue;
			}

			/*
			 * - Ensures nested fields are collected
			 * - Supports deeply nested layouts
			 */

			if (!empty($block['innerBlocks'])) {
				$child_fields = self::parse_blocks($block['innerBlocks'], $depth + 1, $post_id);
				if (isset($child_fields[self::INVALID_SCHEMA_FIELD])) {
					self::mark_invalid_schema($fields);
					break;
				}

				foreach ($child_fields as $key => $value) {
					if (count($fields) >= self::MAX_FIELDS) {
						self::mark_invalid_schema($fields);
						break;
					}

					// FIELD IDENTITY INVARIANT: Every rendered field must have one
					// unique validation name. A later required or consent field
					// must never disappear behind an earlier optional field.
					if (isset($fields[$key])) {
						self::mark_invalid_schema($fields);
						break;
					}

					$fields[$key] = $value;
				}
				if (isset($fields[self::INVALID_SCHEMA_FIELD])) {
					break;
				}
			}

			/**
			 * Converts a single block into a schema field.
			 *
			 * SECURITY:
			 * - Sanitizes field name (critical!)
			 * - Rejects invalid or short names
			 *
			 * @param array $block
			 * @return array
			 */

			if (self::is_field_block($block_name)) {
				$field = self::parse_field_block($block);

				if (empty($field['name'])) {
					// FIELD COMPLETENESS INVARIANT: A rendered control with no
					// valid submission name may still be required or carry consent.
					// It cannot silently disappear from server validation.
					self::mark_invalid_schema($fields);
					break;
				}

				// FIELD IDENTITY INVARIANT: Duplicate names make required
				// validation and response ownership ambiguous. CAPTCHA keeps
				// its failing sentinel for existing security field handling.
				if (isset($fields[$field['name']])) {
					if ($block_name === 'wphave/form-captcha') {
						// SCHEMA INVARIANT: A duplicate security field must add a
						// failing sentinel, never disappear behind the first field.
						if (count($fields) >= self::MAX_FIELDS) {
							self::mark_invalid_schema($fields);
							break;
						}
						$fields['_wphave_invalid_captcha'] = [
							'name' => '_wphave_invalid_captcha',
							'type' => 'captcha',
							'required' => true,
						];
					} else {
						self::mark_invalid_schema($fields);
					}
					break;
				}

				$fields[$field['name']] = $field;
			}
		}

		foreach ($fields as $name => $field) {
			if (($field['type'] ?? '') !== 'captcha') {
				continue;
			}
			// NAME-SPACE INVARIANT: The rendered hidden proof name belongs
			// exclusively to its CAPTCHA. A real field with that name makes POST
			// parsing ambiguous and must invalidate the complete form schema.
			if (isset($fields[$name . '_token'])) {
				self::mark_invalid_schema($fields);
				break;
			}
		}

		return $fields;
	}

	/** Add a bounded, non-field marker whenever schema traversal is incomplete. */
	private static function mark_invalid_schema(array &$fields): void {
		while (count($fields) >= self::MAX_FIELDS) {
			array_pop($fields);
		}
		$fields[self::INVALID_SCHEMA_FIELD] = ['type' => 'invalid'];
	}

	private static function invalid_schema(): array {
		return [self::INVALID_SCHEMA_FIELD => ['type' => 'invalid']];
	}

	/** Check blocks beyond the field limit without accepting any of their input. */
	private static function contains_field_block(array $block, int $depth, int $post_id): bool {
		if ($depth > self::MAX_DEPTH) {
			return true;
		}
		if (!WPHAVE_Block_Projection::allows($block, false, $post_id)) {
			return false;
		}
		if (self::is_reference_block($block['blockName'] ?? '')) {
			return false;
		}
		if (is_string($block['blockName'] ?? null) && self::is_field_block($block['blockName'])) {
			return true;
		}
		foreach ($block['innerBlocks'] ?? [] as $child) {
			if (is_array($child) && self::contains_field_block($child, $depth + 1, $post_id)) {
				return true;
			}
		}
		return false;
	}

	/** Reference blocks replace their serialized children with another document. */
	private static function is_reference_block($block_name): bool {
		return is_string($block_name) &&
			in_array($block_name, ['wphave/form-loader', 'wphave/template-part'], true);
	}

	/**
	 * Parse the field block.
	 *
	 *  - Requires ordinary names to match their rendered request keys exactly
	 *  - Rejects invalid or short names
	 *
	 * @param array $block
	 * @return array
	 */

	protected static function parse_field_block(array $block): array {
		$attrs = is_array($block['attrs'] ?? null) ? $block['attrs'] : [];
		$block_name = is_string($block['blockName'] ?? null) ? $block['blockName'] : '';

		// Resolve the persisted field name before schema identity checks.
		// SHAPE INVARIANT: Persisted block JSON is parsed before WordPress block
		// attribute validation. An array-shaped name must not crash public form
		// admission or turn a malformed CAPTCHA into an optional field.
		$raw_name = is_string($attrs['name'] ?? null) ? $attrs['name'] : '';
		$name = sanitize_key($raw_name);
		if (
			str_starts_with($name, '_wphave_') ||
			str_starts_with($name, '_wp_') ||
			$name === '_wpnonce'
		) {
			// PROTOCOL NAMESPACE INVARIANT: WPHAVE and WordPress own these
			// request keys, including the classic POST referer and nonce.
			// Authored fields cannot replace protocol values in PHP's POST map.
			if ($block_name !== 'wphave/form-captcha') {
				return [];
			}
			$name = '_wphave_invalid_captcha';
		}
		if ($block_name !== 'wphave/form-captcha' && $raw_name !== $name) {
			// FIELD-WIRE INVARIANT: Ordinary renderers emit the stored name
			// verbatim. A repaired schema key would validate a different POST
			// parameter than the visible control actually submits.
			return [];
		}
		if (
			$block_name === 'wphave/form-captcha' &&
			!preg_match('/^[a-z0-9_-]{3,80}$/D', $name)
		) {
			// SCHEMA INVARIANT: Malformed authored security fields fail
			// validation instead of disabling the form's CAPTCHA requirement.
			$name = '_wphave_invalid_captcha';
		}

		// Hard validation
		if (empty($name) || strlen($name) < 3) {
			return [];
		}

		$type = self::map_block_to_type($block_name, $attrs);

		if (!$type) {
			return [];
		}
		if (in_array($type, ['select', 'radio', 'checkbox-group'], true)) {
			$attrs = self::with_registered_option_default($block_name, $attrs);
		}
		if (
			in_array($type, ['select', 'radio', 'checkbox-group'], true) &&
			is_array($attrs['options'] ?? null) &&
			count($attrs['options']) > self::MAX_OPTIONS
		) {
			// OPTION COMPLETENESS INVARIANT: The renderer exposes every stored
			// choice. A truncated schema cannot validate the same field that
			// visitors see, so reject the entire form before side effects.
			return [];
		}
		if (in_array($type, ['select', 'radio', 'checkbox-group'], true)) {
			$options = $attrs['options'] ?? [];
			if (!is_array($options)) {
				return [];
			}
			$seen_values = [];
			foreach ($options as $option) {
				// RENDER-SCHEMA INVARIANT: Every rendered choice must have a
				// scalar value and label. Skipping a malformed option would let
				// submission use a partial schema while render uses the full list.
				if (
					!is_array($option) ||
					(isset($option['value']) && !is_string($option['value'])) ||
					(isset($option['label']) && !is_string($option['label']))
				) {
					return [];
				}
				// OPTION IDENTITY INVARIANT: HTML submits only the value, not the
				// selected label. Duplicate values make distinct visible choices
				// indistinguishable and let the mailer report the first label.
				$value_key = 'value:' . ($option['value'] ?? '');
				if (isset($seen_values[$value_key])) {
					return [];
				}
				$seen_values[$value_key] = true;
			}
		}

		return [
			'name' => $name,
			'type' => $type,
			'label' => is_string($attrs['label'] ?? null) ? sanitize_text_field($attrs['label']) : '',
			'required' => $type === 'captcha' || !empty($attrs['required']),
			'options' => self::parse_options($block_name, $attrs),

			// RAW ATTRIBUTES (trusted internally only!)
			'attrs' => $attrs,
		];
	}

	/** Resolve the same omitted option default that WP_Block applies on render. */
	private static function with_registered_option_default(string $block_name, array $attrs): array {
		if (array_key_exists('options', $attrs) || !class_exists('WP_Block_Type_Registry')) {
			return $attrs;
		}

		$registered = WP_Block_Type_Registry::get_instance()->get_registered($block_name);
		$default = $registered->attributes['options']['default'] ?? null;
		// RENDER-SCHEMA INVARIANT: An omitted block attribute uses its
		// registered default in the renderer. Validation must inspect that
		// exact option set, including the same maximum-option budget.
		if (is_array($default)) {
			$attrs['options'] = $default;
		}

		return $attrs;
	}

	/**
	 * Map the block to type.
	 *
	 *  - inputType is sanitized
	 *  - only allowed types accepted
	 */

	protected static function map_block_to_type(string $block_name, array $attrs): ?string {
		switch ($block_name) {
			case 'wphave/form-input':
				$type = is_string($attrs['inputType'] ?? null)
					? strtolower($attrs['inputType'])
					: 'text';

				$allowed = [
					'tel',
					'url',
					'date',
					'time',
					'text',
					'email',
					'number',
					'password',
					'datetime-local',
				];

			// INPUT-TYPE INVARIANT: The renderer emits the authored HTML input
			// type. Treating an unknown type as text would validate a different
			// control, including submit or hidden inputs, than visitors receive.
			return in_array($type, $allowed, true) ? $type : null;

			case 'wphave/form-textarea':
				return 'textarea';

			case 'wphave/form-select':
				return 'select';

			case 'wphave/form-radio-group':
				return 'radio';

			case 'wphave/form-checkbox':
				return 'checkbox';

			case 'wphave/form-checkbox-group':
				return 'checkbox-group';

			case 'wphave/form-file-upload':
				return 'file';

			case 'wphave/form-captcha':
				return 'captcha';

			default:
				return null;
		}
	}

	/**
	 * Determine whether a block is a supported form field.
	 */

	protected static function is_field_block(string $block_name): bool {
		static $allowed = [
			'wphave/form-input',
			'wphave/form-textarea',
			'wphave/form-select',
			'wphave/form-radio-group',
			'wphave/form-checkbox',
			'wphave/form-checkbox-group',
			'wphave/form-file-upload',
			'wphave/form-captcha',
		];

		return in_array($block_name, $allowed, true);
	}

	/**
	 * Parse the options.
	 *
	 *  - Sanitizes label + value
	 *  - Prevents invalid structures
	 */

	protected static function parse_options(string $block_name, array $attrs): array {
		if (
			!in_array(
				$block_name,
				['wphave/form-select', 'wphave/form-radio-group', 'wphave/form-checkbox-group'],
				true,
			)
		) {
			return [];
		}

		$options = $attrs['options'] ?? [];

		if (!is_array($options)) {
			return [];
		}

		$parsed = [];

		foreach ($options as $opt) {
			if (count($parsed) >= self::MAX_OPTIONS) {
				break;
			}

			if (!is_array($opt)) {
				continue;
			}

			// SHAPE INVARIANT: Neighboring option fields cannot turn a CAPTCHA
			// form's public schema parse into a PHP type error.
			$label = is_string($opt['label'] ?? null) ? sanitize_text_field($opt['label']) : '';
			// OPTION IDENTITY INVARIANT: Escaped controls submit the stored value
			// verbatim. A normalized or label-derived value was never rendered and
			// must not become an accepted server-side choice.
			$value = is_string($opt['value'] ?? null) ? $opt['value'] : '';

			if ($label === '' && $value === '') {
				continue;
			}

			if ($label === '' && $value !== '') {
				$label = $value;
			}

			$parsed[] = [
				'label' => $label,
				'value' => $value,
			];
		}

		return $parsed;
	}
}
