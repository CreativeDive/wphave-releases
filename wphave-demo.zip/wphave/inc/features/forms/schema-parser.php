<?php

/**
 * Extract normalized form schemas from block content.
 *
 *  - Extract form fields from block tree
 *  - Normalize field definitions
 *  - Ensure unique field names
 *  - Sanitize all relevant data
 *
 *  - Recursive block parsing
 *  - Static request-level cache
 *  - Schema-driven processing
 *
 *  - All field names sanitized (sanitize_key)
 *  - All labels sanitized (sanitize_text_field)
 *  - Options strictly validated
 *
 *  - Static in-memory cache per request
 *  - Early returns for invalid states
 */

class WPHAVE_Form_Schema_Parser {

    const MAX_DEPTH = 30;
    const MAX_FIELDS = 200;
    const MAX_OPTIONS = 200;

    /**
     * Parse the post.
     *
     *  - Uses static cache (per request)
     *
     * @param int $post_id
     * @param string|null $form_id Form identifier.
     * @return array
     */

    public static function parse_post( int $post_id, ?string $form_id = null ): array {
        static $cache = [];

        // Hard guard: invalid ID
        if( $post_id <= 0 ) {
            return [];
        }

        // Return cached schema
        $cache_key = $post_id . '|' . ( $form_id ?? '' );

        if( isset( $cache[ $cache_key ] ) ) {
            return $cache[ $cache_key ];
        }

        $post = get_post( $post_id );

        // Guard: invalid post or empty content
        if( ! $post || empty( $post->post_content ) ) {
            return [];
        }

        $blocks = parse_blocks( $post->post_content );

        // Guard: unexpected parse result
        if( ! is_array( $blocks ) ) {
            return [];
        }

        if( $form_id !== null ) {
            $form_block = self::find_form_block( $blocks, $form_id );

            if( ! $form_block ) {
                $cache[ $cache_key ] = [];
                return [];
            }

            $blocks = is_array( $form_block['innerBlocks'] ?? null ) ? $form_block['innerBlocks'] : [];
        }

        $cache[ $cache_key ] = self::parse_blocks( $blocks );

        return $cache[ $cache_key ];
    }

    /**
     * Find a specific form block in a nested block tree.
     *
     * @param array $blocks Parsed blocks.
     * @param string $form_id Form identifier.
     * @return array|null
     */

    protected static function find_form_block( array $blocks, string $form_id, int $depth = 0 ): ?array {
        if( $depth > self::MAX_DEPTH ) {
            return null;
        }

        foreach( $blocks as $block ) {
            if( ( $block['blockName'] ?? '' ) === 'wphave/form' && ( $block['attrs']['formId'] ?? '' ) === $form_id ) {
                return $block;
            }

            if( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
                $found = self::find_form_block( $block['innerBlocks'], $form_id, $depth + 1 );

                if( $found ) {
                    return $found;
                }
            }
        }

        return null;
    }

    /**
     * Parse the blocks.
     *
     *  - Prevents infinite recursion (depth limit)
     *  - Ignores invalid block structures
     *
     * @param array $blocks
     * @param int $depth
     * @return array
     */

    public static function parse_blocks( array $blocks, int $depth = 0 ): array {
        // Prevent recursion abuse
        if( $depth > self::MAX_DEPTH ) {
            return [];
        }

        $fields = [];

        foreach( $blocks as $block ) {

            if( count( $fields ) >= self::MAX_FIELDS ) {
                break;
            }

            $block_name = $block['blockName'] ?? '';

            // Skip invalid blocks
            if( ! $block_name ) {
                continue;
            }

            /*
             * - Ensures nested fields are collected
             * - Supports deeply nested layouts
             */

            if( ! empty( $block['innerBlocks'] ) ) {
                $child_fields = self::parse_blocks(
                    $block['innerBlocks'],
                    $depth + 1
                );

                foreach( $child_fields as $key => $value ) {

                    if( count( $fields ) >= self::MAX_FIELDS ) {
                        break;
                    }

                    // Prevent override
                    if( isset( $fields[ $key ] ) ) {
                        continue;
                    }

                    $fields[ $key ] = $value;
                }
            }

            /**
             * Converts a single block into a schema field.
             *
             * SECURITY:
             * - Sanitizes field name (critical!)
             * - Rejects invalid or short names
             *
             * @param array $block
             * @return array
             */

            if( self::is_field_block( $block_name ) ) {
                $field = self::parse_field_block( $block );

                if( ! empty( $field['name'] ) ) {
                    // Prevent duplicate field names
                    if( isset( $fields[ $field['name'] ] ) ) {
                        continue;
                    }

                    $fields[ $field['name'] ] = $field;
                }
            }
        }

        return $fields;
    }

    /**
     * Parse the field block.
     *
     *  - Sanitizes field name (critical!)
     *  - Rejects invalid or short names
     *
     * @param array $block
     * @return array
     */

    protected static function parse_field_block( array $block ): array {
        $attrs = $block['attrs'] ?? [];
        $block_name = $block['blockName'] ?? '';

        // Sanitize field name
        $name = isset( $attrs['name'] ) ? sanitize_key( $attrs['name'] ) : '';

        // Hard validation
        if( empty( $name ) || strlen( $name ) < 3 ) {
            return [];
        }

        $type = self::map_block_to_type( $block_name, $attrs );

        if( ! $type ) {
            return [];
        }

        return [
            'name' => $name,
            'type' => $type,
            'label' => isset( $attrs['label'] ) ? sanitize_text_field( $attrs['label'] ) : '',
            'required' => ! empty( $attrs['required'] ),
            'options'  => self::parse_options( $block_name, $attrs ),

            // RAW ATTRIBUTES (trusted internally only!)
            'attrs'    => $attrs,
        ];
    }

    /**
     * Map the block to type.
     *
     *  - inputType is sanitized
     *  - only allowed types accepted
     */

    protected static function map_block_to_type( string $block_name, array $attrs ): ?string {
        switch( $block_name ) {
            case 'wphave/form-input':
                $type = isset( $attrs['inputType'] ) ? sanitize_key( $attrs['inputType'] ) : 'text';

                $allowed = [
                    'tel',
                    'url',
                    'date',
                    'time',
                    'text',
                    'email',
                    'number',
                    'password',
                    'datetime-local',
                ];

                return in_array( $type, $allowed, true ) ? $type : 'text';

            case 'wphave/form-textarea':
                return 'textarea';

            case 'wphave/form-select':
                return 'select';

            case 'wphave/form-radio-group':
                return 'radio';

            case 'wphave/form-checkbox':
                return 'checkbox';

            case 'wphave/form-checkbox-group':
                return 'checkbox-group';

            case 'wphave/form-file-upload':
                return 'file';

            default:
                return null;
        }
    }

    /**
     * Determine whether a block is a supported form field.
     */

    protected static function is_field_block( string $block_name ): bool {
        static $allowed = [
            'wphave/form-input',
            'wphave/form-textarea',
            'wphave/form-select',
            'wphave/form-radio-group',
            'wphave/form-checkbox',
            'wphave/form-checkbox-group',
            'wphave/form-file-upload',
        ];

        return in_array( $block_name, $allowed, true );
    }

    /**
     * Parse the options.
     *
     *  - Sanitizes label + value
     *  - Prevents invalid structures
     */

    protected static function parse_options( string $block_name, array $attrs ): array {
        if( ! in_array( $block_name, [
            'wphave/form-select',
            'wphave/form-radio-group',
            'wphave/form-checkbox-group',
        ], true ) ) {
            return [];
        }

        $options = $attrs['options'] ?? [];

        if( ! is_array( $options ) ) {
            return [];
        }

        $parsed = [];

        foreach( $options as $opt ) {
            if( count( $parsed ) >= self::MAX_OPTIONS ) break;

            if( ! is_array( $opt ) ) continue;

            $label = isset( $opt['label'] ) ? sanitize_text_field( $opt['label'] ) : '';
            $value = isset( $opt['value'] ) ? sanitize_key( $opt['value'] ) : '';

            if( $label === '' && $value === '' ) {
                continue;
            }

            // Fallbacks
            if( $value === '' && $label !== '' ) {
                $value = sanitize_title( $label );
            }

            if( $label === '' && $value !== '' ) {
                $label = $value;
            }

            $parsed[] = [
                'label' => $label,
                'value' => $value,
            ];
        }

        return $parsed;
    }

}
