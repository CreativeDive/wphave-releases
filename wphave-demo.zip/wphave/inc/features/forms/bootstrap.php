<?php

/**
 * Bootstrap the WPHAVE global form feature.
 */

require_once wphave_dir() . 'inc/background-jobs/lock.php';
require_once __DIR__ . '/manager.php';
require_once __DIR__ . '/settings.php';
require_once __DIR__ . '/option-lock.php';
require_once __DIR__ . '/spam-policy.php';
require_once __DIR__ . '/protection-metrics.php';
require_once __DIR__ . '/submission/validator.php';
require_once __DIR__ . '/upload-policy.php';
require_once __DIR__ . '/submission/mailer.php';
require_once __DIR__ . '/submission/delivery-receipt.php';
require_once __DIR__ . '/submission/mail-template.php';
require_once __DIR__ . '/operational-alerts.php';
require_once __DIR__ . '/schema-parser.php';
require_once __DIR__ . '/submission/handler.php';
require_once __DIR__ . '/settings-rest-controller.php';
