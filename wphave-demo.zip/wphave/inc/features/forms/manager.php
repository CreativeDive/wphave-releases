<?php

/**
 * WPHAVE global form manager.
 *
 * Centralizes form registration, cached form data, source resolution,
 * recursive rendering, and management REST operations.
 */

class WPHAVE_Form_Manager {

    /**
     * Global form post type slug.
     *
     * @var string
     */

    const POST_TYPE = 'wphave-forms';

    /**
     * Shared post type feature cache bucket.
     *
     * @var string
     */

    const CACHE_TRANSIENT = 'post_type_features_data';

    /**
     * Form data key inside the shared cache bucket.
     *
     * @var string
     */

    const CACHE_KEY = 'wphave_forms';

    /**
     * Aggregated global-form usage cache.
     *
     * @var string
     */

    const USAGE_CACHE_KEY = 'wphave_form_usage_v1';

    /**
     * Whether management-only hooks have been registered.
     *
     * @var bool
     */

    private static $management_initialized = false;

    /**
     * Form read model resolved during the current request.
     *
     * @var array|null
     */

    private static $request_data = null;

    /**
     * Register hooks required for form rendering and persistence.
     *
     * @return void
     */

    public static function init() {
        add_action( 'init', [ __CLASS__, 'register_post_type' ], 16 );
        add_action( 'save_post_' . self::POST_TYPE, [ __CLASS__, 'clear_cache_on_save' ] );
        add_action( 'delete_post_' . self::POST_TYPE, [ __CLASS__, 'clear_cache_on_save' ] );
        add_action( 'save_post', [ __CLASS__, 'invalidate_usage_on_content_change' ], 10, 2 );
        add_action( 'deleted_post', [ __CLASS__, 'invalidate_usage_cache' ] );
        add_action( 'trashed_post', [ __CLASS__, 'invalidate_usage_cache' ] );
        add_action( 'untrashed_post', [ __CLASS__, 'invalidate_usage_cache' ] );
    }

    /**
     * Register management-only REST hooks once.
     *
     * @return void
     */

    public static function init_management() {
        if( self::$management_initialized ) {
            return;
        }

        self::$management_initialized = true;
        add_action( 'rest_api_init', [ __CLASS__, 'register_rest_routes' ] );
    }

    /**
     * Register the reusable global form post type.
     *
     * Forms remain registered in compatibility mode because existing form
     * loader blocks must continue resolving their stored form content.
     *
     * @return void
     */

    public static function register_post_type() {
        register_post_type( self::POST_TYPE, [
            'label' => __( 'Forms', 'wphave' ),
            'description' => __( 'Manages and structure your global forms.', 'wphave' ),
            'menu_icon' => '',
            'menu_position' => 47,
            'supports' => [
                'title',
                'editor' => [
                    'notes'
                ],
                'revisions',
                'custom-fields'
            ],
            'public' => false,
            'show_ui' => true,
            'rewrite' => false,
            'show_in_menu' => false,
            'show_in_rest' => true,
			'map_meta_cap' => true,
			'capabilities' => self::post_type_capabilities(),
            'has_archive' => false,
            'exclude_from_search' => true,
            'show_in_nav_menus' => false,
            'show_in_admin_bar' => false,
            'publicly_queryable' => false,
            'query_var' => false,
        ] );
    }

	/**
	 * Return the Core post capability map for global Forms.
	 *
	 * @return array<string,string> Post type capabilities.
	 */

	private static function post_type_capabilities(): array {
		$capability = 'wphave_manage_forms';

		// AUTHORIZATION INVARIANT: show_in_rest exposes this hidden type through
		// WordPress Core independently of WPHAVE's form_save route. Both surfaces
		// must require the Forms domain capability; edit_posts is never sufficient.
		return array(
			'edit_post' => 'edit_wphave_form',
			'read_post' => 'read_wphave_form',
			'delete_post' => 'delete_wphave_form',
			'edit_posts' => $capability,
			'edit_others_posts' => $capability,
			'delete_posts' => $capability,
			'delete_others_posts' => $capability,
			'publish_posts' => $capability,
			'read_private_posts' => $capability,
			'create_posts' => $capability,
			'delete_private_posts' => $capability,
			'delete_published_posts' => $capability,
			'edit_private_posts' => $capability,
			'edit_published_posts' => $capability,
		);
	}

    /**
     * Find a form block recursively inside parsed Gutenberg blocks.
     *
     * @param array $blocks Parsed blocks.
     * @param string|null $form_id Optional form identifier to match.
     * @return array|null Matching parsed block or null.
     */

    public static function find_block( array $blocks, ?string $form_id = null, int $depth = 0 ): ?array {
        if( $depth > WPHAVE_Form_Schema_Parser::MAX_DEPTH ) {
            return null;
        }

        foreach( $blocks as $block ) {
            if(
                ( $block['blockName'] ?? '' ) === 'wphave/form' &&
                ( $form_id === null || ( $block['attrs']['formId'] ?? '' ) === $form_id )
            ) {
                return $block;
            }

            if( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
                $found = self::find_block( $block['innerBlocks'], $form_id, $depth + 1 );

                if( $found ) {
                    return $found;
                }
            }
        }

        return null;
    }

    /**
     * Determine whether a post contains a matching form block.
     *
     * @param int $post_id Post ID.
     * @param string|null $form_id Optional form identifier.
     * @return bool Whether the post contains the form block.
     */

    public static function post_contains_block( int $post_id, ?string $form_id = null ): bool {
        $post = get_post( $post_id );

        return $post ? (bool) self::find_block( parse_blocks( $post->post_content ), $form_id ) : false;
    }

    /**
     * Resolve the post that owns the currently rendered form.
     *
     * Global forms temporarily expose their source post through a request-local
     * value while rendering. Direct form blocks use the current post, followed
     * by a bounded lookup of internal form-capable post types.
     *
     * @param string $form_id Form identifier.
     * @param int|null $fallback_post_id Optional fallback post ID.
     * @return int Source post ID.
     */

    public static function get_source_post_id( string $form_id = '', ?int $fallback_post_id = null ): int {
        $source_post_id = absint( $GLOBALS['wphave_form_source_post_id'] ?? 0 );

        if( $source_post_id && ( ! $form_id || self::post_contains_block( $source_post_id, $form_id ) ) ) {
            return $source_post_id;
        }

        $fallback_post_id = absint( $fallback_post_id ?: get_the_ID() );

        if( $fallback_post_id && ( ! $form_id || self::post_contains_block( $fallback_post_id, $form_id ) ) ) {
            return $fallback_post_id;
        }

        if( ! $form_id ) {
            return $fallback_post_id;
        }

        $post_ids = get_posts( [
            'post_type' => [ self::POST_TYPE, WPHAVE_Add_On_Manager::POST_TYPE ],
            'post_status' => 'any',
            'posts_per_page' => -1,
            'fields' => 'ids',
        ] );

        foreach( $post_ids as $post_id ) {
            if( self::post_contains_block( (int) $post_id, $form_id ) ) {
                return (int) $post_id;
            }
        }

        return $fallback_post_id;
    }

    /**
     * Return cached data for all published global forms.
     *
     * @return array Form data keyed by post ID.
     */

    public static function get_data() {
        // PERFORMANCE INVARIANT: Public requests cannot populate the shared
        // internal-post-type cache. Retain even an empty read model locally so
        // repeated consumers never rerun post loading and block rendering.
        if( self::$request_data !== null ) {
            return self::$request_data;
        }

        $cached = wphave_has_cached_data( self::CACHE_TRANSIENT, [
            'key' => self::CACHE_KEY,
            'admin_cache' => true,
        ] );

        if( $cached !== false ) {
            self::$request_data = $cached;

            return self::$request_data;
        }

        wphave_events( 'CACHE', 'Forms data.' );

        $post_ids = wphave_internal_post_type_all_ids( self::POST_TYPE );

        if( empty( $post_ids ) ) {
            self::$request_data = [];

            wphave_save_query( [], self::CACHE_TRANSIENT, [
                'key' => self::CACHE_KEY,
                'admin_cache' => true,
                'frontend_write' => false,
            ] );
            return self::$request_data;
        }

        $save_data = [];

        foreach( $post_ids as $post_id ) {
            $post = get_post( $post_id );

            if( ! $post || $post->post_type !== self::POST_TYPE || $post->post_status !== 'publish' ) {
                continue;
            }

            $save_data[$post_id] = [
                'id' => $post_id,
                'title' => $post->post_title,
                'content' => $post->post_content,
                'rendered' => $post->post_content ? do_blocks( $post->post_content ) : ''
            ];
        }

        wphave_save_query( $save_data, self::CACHE_TRANSIENT, [
            'key' => self::CACHE_KEY,
            'admin_cache' => true,
            'frontend_write' => false,
        ] );

        self::$request_data = $save_data;

        return self::$request_data;
    }

    /**
     * Remove global form data from the shared post type feature cache.
     *
     * @return void
     */

    public static function clear_cache() {
        // DATA INTEGRITY INVARIANT: Saves and deletions must discard the
        // request-local pre-mutation read model before any subsequent render.
        self::$request_data = null;
        WPHAVE_Internal_Post_Type_Cache::invalidate( self::POST_TYPE );
    }

    /**
     * Clear cached form data after a valid form save or deletion.
     *
     * @param int $post_id Form post ID.
     * @return void
     */

    public static function clear_cache_on_save( $post_id ) {
        if( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
            return;
        }

        self::clear_cache();
    }

    /**
     * Invalidate the aggregate usage snapshot after a content document changes.
     *
     * The snapshot is intentionally derived in one batch. No reverse relation is
     * persisted per source post, so form usage has one canonical discovery path.
     *
     * @param int $post_id Post ID.
     * @param WP_Post|null $post Saved post.
     * @return void
     */

    public static function invalidate_usage_on_content_change( $post_id, $post = null ) {
        if( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
            return;
        }

        $post = $post instanceof WP_Post ? $post : get_post( $post_id );

        if( ! $post || $post->post_type === self::POST_TYPE || $post->post_type === 'attachment' ) {
            return;
        }

        self::invalidate_usage_cache();
    }

    /**
     * Remove the aggregated usage snapshot.
     *
     * @return void
     */

    public static function invalidate_usage_cache() {
        delete_transient( self::USAGE_CACHE_KEY );
    }

    /**
     * Collect referenced global form post IDs from a parsed block tree.
     *
     * @param array $blocks Parsed Gutenberg blocks.
     * @param int $depth Current recursion depth.
     * @return int[] Referenced form post IDs.
     */

    public static function collect_loader_form_ids( array $blocks, int $depth = 0 ): array {
        if( $depth > WPHAVE_Form_Schema_Parser::MAX_DEPTH ) {
            return [];
        }

        $ids = [];

        foreach( $blocks as $block ) {
            if( ( $block['blockName'] ?? '' ) === 'wphave/form-loader' ) {
                $form_id = absint( $block['attrs']['formId'] ?? 0 );

                if( $form_id ) {
                    $ids[$form_id] = $form_id;
                }
            }

            if( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
                foreach( self::collect_loader_form_ids( $block['innerBlocks'], $depth + 1 ) as $form_id ) {
                    $ids[$form_id] = $form_id;
                }
            }
        }

        return array_values( $ids );
    }

    /**
     * Return one cached, site-wide usage projection for all global forms.
     *
     * A cheap SQL marker narrows the candidate documents before Gutenberg parses
     * them. Every source document counts once per form even when it embeds the
     * same loader more than once.
     *
     * @return array Usage data keyed by global form post ID.
     */

    public static function get_usage(): array {
        $cached = get_transient( self::USAGE_CACHE_KEY );

        if( is_array( $cached ) ) {
            return self::add_performance_metrics( $cached );
        }

        global $wpdb;

        $marker = '%' . $wpdb->esc_like( 'wp:wphave/form-loader' ) . '%';
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT ID, post_type, post_content FROM {$wpdb->posts}
                WHERE post_content LIKE %s
                AND post_type NOT IN (%s, 'attachment', 'revision')
                AND post_status NOT IN ('trash', 'auto-draft', 'inherit')",
                $marker,
                self::POST_TYPE
            )
        );
        $usage = [];

        foreach( is_array( $rows ) ? $rows : [] as $row ) {
            $form_ids = self::collect_loader_form_ids( parse_blocks( (string) $row->post_content ) );

            foreach( $form_ids as $form_id ) {
                if( ! isset( $usage[$form_id] ) ) {
                    $usage[$form_id] = [
                        'count' => 0,
                        'postTypes' => [],
                    ];
                }

                $usage[$form_id]['count']++;
                $usage[$form_id]['postTypes'][$row->post_type] = $row->post_type;
            }
        }

        foreach( $usage as &$item ) {
            $item['postTypes'] = array_values( $item['postTypes'] );
            sort( $item['postTypes'] );
        }
        unset( $item );

        set_transient( self::USAGE_CACHE_KEY, $usage, DAY_IN_SECONDS );

        return self::add_performance_metrics( $usage );
    }

    /**
     * Add tracked form starts and successful submissions to the projection.
     *
     * Analytics records the stable inner form identifier rather than the global
     * form post ID. Resolve that mapping once, then aggregate every form through
     * the indexed event_type/object_key columns in one query.
     *
     * @param array $usage Static form usage projection.
     * @return array Usage projection decorated with submission totals.
     */

    private static function add_performance_metrics( array $usage ): array {
        global $wpdb;

        $form_rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT ID, post_content FROM {$wpdb->posts}
                WHERE post_type = %s
                AND post_status NOT IN ('trash', 'auto-draft')",
                self::POST_TYPE
            )
        );
        $form_key_to_post_id = [];

        foreach( is_array( $form_rows ) ? $form_rows : [] as $form_row ) {
            $form_post_id = absint( $form_row->ID );
            $form_block = self::find_block( parse_blocks( (string) $form_row->post_content ) );
            $form_key = sanitize_text_field( $form_block['attrs']['formId'] ?? '' );

            if( ! isset( $usage[$form_post_id] ) ) {
                $usage[$form_post_id] = [
                    'count' => 0,
                    'postTypes' => [],
                ];
            }

            $usage[$form_post_id]['submissions'] = null;
            $usage[$form_post_id]['starts'] = null;

            if( $form_key ) {
                $form_key_to_post_id[$form_key] = $form_post_id;
            }
        }

        if( empty( $form_key_to_post_id ) || ! class_exists( 'WPHAVE_Analytics' ) ) {
            return $usage;
        }

        $events_table = $wpdb->prefix . WPHAVE_Analytics::EVENT_TABLE;
        $table_exists = $wpdb->get_var(
            $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $events_table ) )
        );

        if( $table_exists !== $events_table ) {
            return $usage;
        }

        $performance_rows = $wpdb->get_results(
            "SELECT
                object_key,
                COUNT(CASE WHEN event_type = 'form_start' THEN 1 END) AS starts,
                COUNT(CASE WHEN event_type = 'form_submit' THEN 1 END) AS submissions
            FROM {$events_table}
            WHERE event_type IN ('form_start', 'form_submit')
            GROUP BY object_key"
        );

        foreach( $form_key_to_post_id as $form_post_id ) {
            $usage[$form_post_id]['submissions'] = 0;
            $usage[$form_post_id]['starts'] = 0;
        }

        foreach( is_array( $performance_rows ) ? $performance_rows : [] as $performance_row ) {
            $form_post_id = $form_key_to_post_id[$performance_row->object_key] ?? 0;

            if( $form_post_id ) {
                $usage[$form_post_id]['submissions'] = absint( $performance_row->submissions );
                $usage[$form_post_id]['starts'] = absint( $performance_row->starts );
            }
        }

        return $usage;
    }

    /**
     * Render a published global form with its source context preserved.
     *
     * @param int $post_id Global form post ID.
     * @return string Rendered global form markup.
     */

    public static function render( $post_id ) {
        static $render_stack = [];

        $post_id = absint( $post_id );

        if( ! $post_id || isset( $render_stack[$post_id] ) || count( $render_stack ) >= 20 ) {
            return '';
        }

        $post = get_post( $post_id );

        if( ! $post || $post->post_type !== self::POST_TYPE || $post->post_status !== 'publish' ) {
            return '';
        }

        $render_stack[$post_id] = true;
        $previous_source = $GLOBALS['wphave_form_source_post_id'] ?? null;
        $GLOBALS['wphave_form_source_post_id'] = (int) $post_id;

        try {
            // The Form Loader owns layout and sizing. Rendering the referenced
            // document directly prevents an inner full-width shell from
            // overriding the Loader block's configured width.
            return do_blocks( $post->post_content );
        } finally {
            unset( $render_stack[$post_id] );

            if( $previous_source === null ) {
                unset( $GLOBALS['wphave_form_source_post_id'] );
            } else {
                $GLOBALS['wphave_form_source_post_id'] = $previous_source;
            }
        }
    }

    /**
     * Recursively render blocks while injecting the submitted form state.
     *
     * Nested fields need the same values, raw input, and validation errors as
     * direct form children. Attribute assignment happens on every block before
     * its own render callback is executed.
     *
     * @param WP_Block $block Block instance.
     * @param array $form_data Submitted form state.
     * @return string Rendered block markup.
     */

    public static function render_block( $block, $form_data ) {
        $attributes = $block->attributes;
        $attributes['_wphaveFormData'] = $form_data;
        $block->attributes = $attributes;

        if( ! empty( $block->inner_blocks ) ) {
            foreach( $block->inner_blocks as $inner_block ) {
                self::render_block( $inner_block, $form_data );
            }
        }

        return $block->render();
    }

    /**
     * Register management REST routes for global forms.
     *
     * @return void
     */

    public static function register_rest_routes() {
        register_rest_route( 'wphave/v1', '/forms', [
            'methods' => 'GET',
            'callback' => [ __CLASS__, 'get_rest_data' ],
            'permission_callback' => [ __CLASS__, 'can_manage' ]
        ] );

        register_rest_route( 'wphave/v1', '/forms/usage', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [ __CLASS__, 'get_rest_usage' ],
            'permission_callback' => [ __CLASS__, 'can_manage' ]
        ] );

        register_rest_route( 'wphave/v1', '/form_save', [
            'methods' => 'POST',
            'callback' => [ __CLASS__, 'save' ],
            'permission_callback' => [ __CLASS__, 'can_manage' ]
        ] );
    }

    /**
     * Determine whether the current user may manage global forms.
     *
     * @return bool Whether form management is permitted.
     */

    public static function can_manage() {
        return current_user_can( 'manage_options' ) || current_user_can( 'wphave_manage_options' ) || current_user_can( 'wphave_manage_forms' );
    }

    /** Return the stable fail-closed result for unauthorized management calls. */
    private static function access_error() {
        return new WP_Error(
            'wphave_forms_forbidden',
            __( 'Sorry, you are not allowed to manage forms.', 'wphave' ),
            [ 'status' => 403 ]
        );
    }

    /**
     * Return global form data for REST clients.
     *
     * @return WP_REST_Response REST response.
     */

    public static function get_rest_data() {
        // SECURITY INVARIANT: REST route permission callbacks are only the first
        // trust boundary. Every callable management handler repeats the same
        // capability policy immediately before reading global form data.
        if( ! self::can_manage() ) {
            return self::access_error();
        }

        return rest_ensure_response( self::get_data() );
    }

    /**
     * Return cached global form usage for REST clients.
     *
     * @return WP_REST_Response REST response.
     */

    public static function get_rest_usage() {
        // SECURITY INVARIANT: Internal/direct dispatch must never bypass the
        // Forms management capability required by the public REST route.
        if( ! self::can_manage() ) {
            return self::access_error();
        }

        return rest_ensure_response( self::get_usage() );
    }

    /**
     * Create, update, or delete a global form through REST.
     *
     * @param WP_REST_Request $request REST request.
     * @return WP_REST_Response|WP_Error REST result.
     */

    public static function save( WP_REST_Request $request ) {
        // SECURITY INVARIANT: Authorization precedes request parsing and every
        // create, update, delete, cache-invalidation, and persistence effect.
        if( ! self::can_manage() ) {
            return self::access_error();
        }

        $data = $request->get_json_params();
        $data = is_array( $data ) ? $data : [];
        $action = $data['action'] ?? 'save';
        $post_id = absint( $data['id'] ?? 0 );
        $title = sanitize_text_field( $data['title'] ?? '' );
        $content = is_string( $data['inner_blocks'] ?? null ) ? $data['inner_blocks'] : '';

        if( ! in_array( $action, [ 'save', 'delete' ], true ) ) {
            return new WP_Error( 'wphave_invalid_form_action', __( 'Invalid form action.', 'wphave' ), [ 'status' => 400 ] );
        }

        $existing_post = $post_id ? get_post( $post_id ) : null;

        if( $post_id && ( ! $existing_post || $existing_post->post_type !== self::POST_TYPE ) ) {
            return new WP_Error( 'wphave_form_not_found', __( 'Form not found.', 'wphave' ), [ 'status' => 404 ] );
        }

        if( $action === 'delete' ) {
            if( ! $post_id ) {
                return new WP_Error( 'wphave_form_not_found', __( 'Form not found.', 'wphave' ), [ 'status' => 404 ] );
            }

            // SECURITY INVARIANT: Form feature management does not imply deletion
            // of every form object; permanent removal follows the exact post's
            // WordPress meta capability.
            if( ! current_user_can( 'delete_post', $post_id ) ) {
                return new WP_Error( 'rest_forbidden', __( 'Sorry, you are not allowed to delete this form.', 'wphave' ), [ 'status' => 403 ] );
            }

            if( ! wp_delete_post( $post_id, true ) ) {
                return new WP_Error( 'wphave_form_delete_failed', __( 'The form could not be deleted.', 'wphave' ), [ 'status' => 500 ] );
            }

            self::clear_cache();

            return rest_ensure_response( [
                'success' => true,
                'deleted' => $post_id
            ] );
        }

        if( $post_id && ! current_user_can( 'edit_post', $post_id ) ) {
            return new WP_Error( 'rest_forbidden', __( 'Sorry, you are not allowed to edit this form.', 'wphave' ), [ 'status' => 403 ] );
        }

        $post_data = [
            'post_type' => self::POST_TYPE,
            'post_status' => 'publish',
            'post_title' => wp_slash( $title ?: __( 'My Form', 'wphave' ) ),
            'post_content' => wp_slash( $content )
        ];

        if( $post_id ) {
            $post_data['ID'] = $post_id;
        }

        $post_id = wp_insert_post( $post_data, true );

        if( is_wp_error( $post_id ) ) {
            return $post_id;
        }

        self::clear_cache();

        return rest_ensure_response( [
            'success' => true,
            'id' => $post_id
        ] );
    }

}

WPHAVE_Form_Manager::init();
