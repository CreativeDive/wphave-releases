<?php

/**
 * Resolve site-wide form defaults without weakening per-form configuration.
 */
final class WPHAVE_Form_Settings {

	/** Return the validated delivery defaults used by form notifications. */
	public static function delivery_defaults(): array {
		$delivery = wphave_data_get( 'site_settings', 'forms.delivery', array() );
		$delivery = is_array( $delivery ) ? $delivery : array();

		return array(
			'emailTo'       => self::email( $delivery['recipientEmail'] ?? '' ),
			'emailFromName' => sanitize_text_field( $delivery['fromName'] ?? '' ),
			'emailFromEmail'=> self::email( $delivery['fromEmail'] ?? '' ),
			'emailSubject'  => sanitize_text_field( $delivery['subject'] ?? '' ),
		);
	}

	/**
	 * Resolve one form's delivery configuration.
	 *
	 * Non-empty form values override site defaults. Empty defaults intentionally
	 * fall through to the mailer's existing WordPress-level safety fallbacks.
	 */
	public static function resolve( array $form_settings, ?array $delivery_defaults = null ): array {
		$resolved = $form_settings;
		$delivery_defaults = null === $delivery_defaults
			? self::delivery_defaults()
			: $delivery_defaults;

		foreach ( $delivery_defaults as $key => $default ) {
			if ( '' === trim( (string) ( $resolved[ $key ] ?? '' ) ) && '' !== $default ) {
				$resolved[ $key ] = $default;
			}
		}

		return $resolved;
	}

	private static function email( $value ): string {
		$email = sanitize_email( (string) $value );

		return $email && is_email( $email ) ? $email : '';
	}
}
