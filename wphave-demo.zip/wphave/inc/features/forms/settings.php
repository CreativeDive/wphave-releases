<?php

require_once wphave_dir() . 'inc/features/security/email-identity.php';

/**
 * Resolve site-wide form defaults without weakening per-form configuration.
 */
final class WPHAVE_Form_Settings {

	/** Return the validated delivery defaults used by form notifications. */
	public static function delivery_defaults(): array {
		$delivery = wphave_data_get( 'site_settings', 'forms.delivery', array() );
		$delivery = is_array( $delivery ) ? $delivery : array();

		return array(
			'emailTo'       => self::email( $delivery['recipientEmail'] ?? '' ),
			'emailFromName' => sanitize_text_field( is_string( $delivery['fromName'] ?? null ) ? $delivery['fromName'] : '' ),
			'emailFromEmail'=> self::email( $delivery['fromEmail'] ?? '' ),
			'emailSubject'  => sanitize_text_field( is_string( $delivery['subject'] ?? null ) ? $delivery['subject'] : '' ),
		);
	}

	/**
	 * Resolve one form's delivery configuration.
	 *
	 * Non-empty form values override site defaults. Empty defaults intentionally
	 * fall through to the mailer's existing WordPress-level safety fallbacks.
	 */
	public static function resolve( array $form_settings, ?array $delivery_defaults = null ): array {
		$resolved = $form_settings;
		foreach ( array( 'emailNotificationEnabled', 'audienceLeadEnabled', 'audienceSubscriberEnabled' ) as $flag ) {
			if ( array_key_exists( $flag, $resolved ) && ! is_bool( $resolved[ $flag ] ) ) {
				// SIDE-EFFECT INVARIANT: Raw block attributes are not validated
				// here. A malformed truthy value may not enable mail or Audience.
				$resolved[ $flag ] = false;
			}
		}
		$delivery_defaults = null === $delivery_defaults
			? self::delivery_defaults()
			: $delivery_defaults;

		foreach ( $delivery_defaults as $key => $default ) {
			// DELIVERY AUTHORITY INVARIANT: null is an explicit malformed
			// override, not an absent value. The null-coalescing operator would
			// silently replace it with a different configured mailbox.
			$current = array_key_exists( $key, $resolved ) ? $resolved[ $key ] : '';
			// DELIVERY IDENTITY INVARIANT: Only an absent or blank string inherits
			// a default. A malformed explicit recipient remains invalid so mail
			// preflight cannot silently select a different mailbox.
			if (
				is_string( $current ) &&
				'' === trim( $current ) &&
				is_string( $default ) &&
				'' !== $default
			) {
				$resolved[ $key ] = $default;
			}
		}

		return $resolved;
	}

	private static function email( $value ): string {
		// DEFAULT-DELIVERY INVARIANT: A persisted default may be absent, but it
		// cannot silently select another mailbox after normalization.
		return WPHAVE_Email_Identity::exact( $value );
	}
}
