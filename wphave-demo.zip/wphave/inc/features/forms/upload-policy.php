<?php

/**
 * Enforce site-wide ceilings for every Forms file upload.
 */
final class WPHAVE_Form_Upload_Policy {
	/** Reject temporary paths inside known web-served roots; never relocate them. */
	public static function is_private_temporary_file(string $path): bool {
		clearstatcache(true, $path);
		$real = realpath($path);
		$permissions = @fileperms($path);
		if (false === $real || is_link($path) || !is_file($real) || false === $permissions) {
			return false;
		}
		// CONFIDENTIALITY INVARIANT: PHP must provision owner-only temporary
		// files outside WordPress, the server document root and public uploads.
		if ('\\' !== DIRECTORY_SEPARATOR && ($permissions & 0077) !== 0) {
			return false;
		}
		$uploads = wp_get_upload_dir();
		$roots = [ABSPATH, $_SERVER['DOCUMENT_ROOT'] ?? '', $uploads['basedir'] ?? ''];
		foreach ($roots as $root) {
			if (!is_string($root) || '' === $root) {
				continue;
			}
			$root = realpath($root);
			if (false === $root) {
				return false;
			}
			if (
				$real === $root ||
				str_starts_with($real, rtrim($root, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR)
			) {
				return false;
			}
		}
		return true;
	}

	/** Release only paths from the caller's validated, request-owned upload plan. */
	public static function release(array $files): void {
		foreach (array_unique($files) as $file) {
			// OWNERSHIP INVARIANT: Callers pass only accepted local upload paths,
			// never raw request fields. No directory traversal or link following.
			if (is_string($file) && !is_link($file) && is_file($file)) {
				unlink($file);
			}
		}
	}

	private const FILE_TYPE_GROUPS = ['images', 'pdf', 'documents', 'spreadsheets', 'text'];
	private const DEFAULT_MAX_FILE_SIZE = 10 * MB_IN_BYTES;
	private const MAX_CONFIGURABLE_FILE_SIZE = 25 * MB_IN_BYTES;

	public static function settings(?array $stored = null): array {
		$stored =
			null === $stored ? wphave_data_get('site_settings', 'forms.uploads', []) : $stored;
		$stored = is_array($stored) ? $stored : [];
		if (!array_key_exists('allowedFileTypes', $stored)) {
			$file_types = self::FILE_TYPE_GROUPS;
		} elseif (!is_array($stored['allowedFileTypes'])) {
			$file_types = [];
		} else {
			$requested_groups = array_map(
				static fn($group): string => is_string($group) ? sanitize_key($group) : '',
				$stored['allowedFileTypes'],
			);
			$file_types = array_values(array_intersect(self::FILE_TYPE_GROUPS, $requested_groups));
		}

		// UPLOAD POLICY INVARIANT: Missing configuration inherits the documented
		// defaults, but an explicitly empty or invalid stored list grants no MIME.
		// Recovering a corrupt allowlist by enabling every group fails open.

		return [
			'maxFileSizeBytes' => min(
				self::MAX_CONFIGURABLE_FILE_SIZE,
				max(
					MB_IN_BYTES,
					absint($stored['maxFileSizeBytes'] ?? self::DEFAULT_MAX_FILE_SIZE),
				),
			),
			'maxFiles' => min(10, max(1, absint($stored['maxFiles'] ?? 5))),
			'allowedFileTypes' => $file_types,
		];
	}

	/** Return the stricter of the global byte ceiling and one field override. */
	public static function max_file_size_bytes(array $field, ?array $policy_settings = null): int {
		$global_maximum = self::settings($policy_settings)['maxFileSizeBytes'];
		$field_maximum = WPHAVE_Form_Validator::max_file_size_bytes($field);

		return $field_maximum > 0 ? min($global_maximum, $field_maximum) : $global_maximum;
	}

	/** Intersect a field selection with the server-controlled global allowlist. */
	public static function allowed_file_mimes(
		array $field_groups,
		?array $policy_settings = null,
	): array {
		$settings = self::settings($policy_settings);
		$global_mimes = WPHAVE_Form_Validator::allowed_file_mimes($settings['allowedFileTypes']);
		$field_mimes = WPHAVE_Form_Validator::allowed_file_mimes($field_groups);

		return empty($field_groups)
			? $global_mimes
			: array_intersect_key($field_mimes, $global_mimes);
	}

	/** Reject a complete request batch before any attachment is delivered. */
	public static function validate_batch(
		array $schema,
		array $files,
		?array $policy_settings = null,
	) {
		$uploaded_file_count = 0;

		foreach ($schema as $name => $field) {
			if ('file' !== ($field['type'] ?? '') || !isset($files[$name])) {
				continue;
			}

			$file = $files[$name];
			if (
				is_array($file) &&
				UPLOAD_ERR_NO_FILE === (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE)
			) {
				continue;
			}

			++$uploaded_file_count;
		}

		if ($uploaded_file_count > self::settings($policy_settings)['maxFiles']) {
			return new WP_Error(
				'wphave_form_too_many_uploads',
				__('Too many files were uploaded.', 'wphave'),
			);
		}

		return true;
	}
}
