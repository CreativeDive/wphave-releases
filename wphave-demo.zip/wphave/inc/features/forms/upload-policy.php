<?php

/**
 * Enforce site-wide ceilings for every Forms file upload.
 */
final class WPHAVE_Form_Upload_Policy {

	private const FILE_TYPE_GROUPS = array( 'images', 'pdf', 'documents', 'spreadsheets', 'text' );
	private const DEFAULT_MAX_FILE_SIZE = 10 * MB_IN_BYTES;
	private const MAX_CONFIGURABLE_FILE_SIZE = 25 * MB_IN_BYTES;

	public static function settings( ?array $stored = null ): array {
		$stored = null === $stored
			? wphave_data_get( 'site_settings', 'forms.uploads', array() )
			: $stored;
		$stored = is_array( $stored ) ? $stored : array();
		$file_types = isset( $stored['allowedFileTypes'] ) && is_array( $stored['allowedFileTypes'] )
			? array_values( array_intersect( self::FILE_TYPE_GROUPS, array_map( 'sanitize_key', $stored['allowedFileTypes'] ) ) )
			: self::FILE_TYPE_GROUPS;

		// A malformed or empty stored allowlist must never widen uploads. Fall back to
		// the complete server-owned safe group set rather than all WordPress MIME types.
		if ( empty( $file_types ) ) {
			$file_types = self::FILE_TYPE_GROUPS;
		}

		return array(
			'maxFileSizeBytes' => min(
				self::MAX_CONFIGURABLE_FILE_SIZE,
				max( MB_IN_BYTES, absint( $stored['maxFileSizeBytes'] ?? self::DEFAULT_MAX_FILE_SIZE ) )
			),
			'maxFiles'         => min( 10, max( 1, absint( $stored['maxFiles'] ?? 5 ) ) ),
			'allowedFileTypes' => $file_types,
		);
	}

	/** Return the stricter of the global byte ceiling and one field override. */
	public static function max_file_size_bytes( array $field, ?array $policy_settings = null ): int {
		$global_maximum = self::settings( $policy_settings )['maxFileSizeBytes'];
		$field_maximum = WPHAVE_Form_Validator::max_file_size_bytes( $field );

		return $field_maximum > 0 ? min( $global_maximum, $field_maximum ) : $global_maximum;
	}

	/** Intersect a field selection with the server-controlled global allowlist. */
	public static function allowed_file_mimes( array $field_groups, ?array $policy_settings = null ): array {
		$settings = self::settings( $policy_settings );
		$global_mimes = WPHAVE_Form_Validator::allowed_file_mimes( $settings['allowedFileTypes'] );
		$field_mimes = WPHAVE_Form_Validator::allowed_file_mimes( $field_groups );

		return empty( $field_groups )
			? $global_mimes
			: array_intersect_key( $field_mimes, $global_mimes );
	}

	/** Reject a complete request batch before any file is moved. */
	public static function validate_batch(
		array $schema,
		array $files,
		?array $policy_settings = null
	) {
		$uploaded_file_count = 0;

		foreach ( $schema as $name => $field ) {
			if ( 'file' !== ( $field['type'] ?? '' ) || ! isset( $files[ $name ] ) ) {
				continue;
			}

			$file = $files[ $name ];
			if ( is_array( $file ) && UPLOAD_ERR_NO_FILE === (int) ( $file['error'] ?? UPLOAD_ERR_NO_FILE ) ) {
				continue;
			}

			++$uploaded_file_count;
		}

		if ( $uploaded_file_count > self::settings( $policy_settings )['maxFiles'] ) {
			return new WP_Error(
				'wphave_form_too_many_uploads',
				__( 'Too many files were uploaded.', 'wphave' )
			);
		}

		return true;
	}
}
