<?php

/**
 * Enforce site-wide ceilings for every Forms file upload.
 */
final class WPHAVE_Form_Upload_Policy {
	/** Recognize only PHP's complete empty file-control shape. */
	public static function is_empty_upload($file): bool {
		// ABSENT-UPLOAD INVARIANT: An error code alone cannot erase a claimed
		// filename, MIME, size or path, including on undeclared multipart fields.
		return is_array($file) &&
			($file['error'] ?? null) === UPLOAD_ERR_NO_FILE &&
			($file['name'] ?? null) === '' &&
			($file['type'] ?? null) === '' &&
			($file['size'] ?? null) === 0 &&
			($file['tmp_name'] ?? null) === '';
	}

	/** Reject temporary paths inside known web-served roots; never relocate them. */
	public static function is_private_temporary_file(string $path): bool {
		clearstatcache(true, $path);
		$real = realpath($path);
		$permissions = @fileperms($path);
		if (false === $real || is_link($path) || !is_file($real) || false === $permissions) {
			return false;
		}
		// CONFIDENTIALITY INVARIANT: PHP must provision owner-only temporary
		// files outside WordPress, the server document root and public uploads.
		if ('\\' !== DIRECTORY_SEPARATOR && ($permissions & 0077) !== 0) {
			return false;
		}
		$uploads = wp_get_upload_dir();
		$roots = [ABSPATH, $_SERVER['DOCUMENT_ROOT'] ?? '', $uploads['basedir'] ?? ''];
		foreach ($roots as $root) {
			if (!is_string($root) || '' === $root) {
				continue;
			}
			$root = realpath($root);
			if (false === $root) {
				return false;
			}
			if (
				$real === $root ||
				str_starts_with($real, rtrim($root, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR)
			) {
				return false;
			}
		}
		return true;
	}

	/** Release only PHP-owned uploads from the current request. */
	public static function release(array $files): void {
		$seen = [];
		foreach ($files as $file) {
			if (!is_string($file) || isset($seen[$file])) {
				continue;
			}
			$seen[$file] = true;
			// OWNERSHIP INVARIANT: The mailer is also a public PHP call site.
			// Its cleanup list cannot authorize deletion of an arbitrary local
			// file; only PHP's upload registry proves request ownership.
			if (
				is_uploaded_file($file) &&
				!is_link($file) &&
				is_file($file)
			) {
				unlink($file);
			}
		}
	}

	private const FILE_TYPE_GROUPS = ['images', 'pdf', 'documents', 'spreadsheets', 'text'];
	private const DEFAULT_MAX_FILE_SIZE = 10 * MB_IN_BYTES;
	private const MAX_CONFIGURABLE_FILE_SIZE = 25 * MB_IN_BYTES;

	public static function settings(?array $stored = null): array {
		$stored =
			null === $stored ? wphave_data_get('site_settings', 'forms.uploads', []) : $stored;
		$stored = is_array($stored) ? $stored : [];
		$raw_maximum_bytes = $stored['maxFileSizeBytes'] ?? self::DEFAULT_MAX_FILE_SIZE;
		$raw_maximum_files = $stored['maxFiles'] ?? 5;
		// GLOBAL UPLOAD LIMIT INVARIANT: absint() turns negative stored limits
		// into positive grants. Only positive integers can authorize a larger
		// upload budget; malformed settings fall to the restrictive floor.
		$maximum_bytes = is_int($raw_maximum_bytes) && $raw_maximum_bytes > 0
			? $raw_maximum_bytes
			: MB_IN_BYTES;
		$maximum_files = is_int($raw_maximum_files) && $raw_maximum_files > 0
			? $raw_maximum_files
			: 1;
		if (!array_key_exists('allowedFileTypes', $stored)) {
			$file_types = self::FILE_TYPE_GROUPS;
		} elseif (!is_array($stored['allowedFileTypes'])) {
			$file_types = [];
		} else {
			// MIME-GROUP IDENTITY INVARIANT: Policy values are identifiers, not
			// display text. Repairing "images!" into "images" silently widens
			// a malformed stored grant.
			$requested_groups = array_filter(
				$stored['allowedFileTypes'],
				static fn($group): bool => is_string($group) &&
					in_array($group, self::FILE_TYPE_GROUPS, true),
			);
			$file_types = array_values(array_intersect(self::FILE_TYPE_GROUPS, $requested_groups));
		}

		// UPLOAD POLICY INVARIANT: Missing configuration inherits the documented
		// defaults, but an explicitly empty or invalid stored list grants no MIME.
		// Recovering a corrupt allowlist by enabling every group fails open.

		return [
			'maxFileSizeBytes' => min(
				self::MAX_CONFIGURABLE_FILE_SIZE,
				max(MB_IN_BYTES, $maximum_bytes),
			),
			'maxFiles' => min(10, $maximum_files),
			'allowedFileTypes' => $file_types,
		];
	}

	/** Return the stricter of the global byte ceiling and one field override. */
	public static function max_file_size_bytes(array $field, ?array $policy_settings = null): int {
		$global_maximum = self::settings($policy_settings)['maxFileSizeBytes'];
		$limit_enabled = $field['attrs']['limitFileSize'] ?? false;
		if ($limit_enabled === false) {
			return $global_maximum;
		}
		if ($limit_enabled !== true) {
			return 0;
		}
		$field_maximum = WPHAVE_Form_Validator::max_file_size_bytes($field);

		// FIELD-LIMIT INVARIANT: Zero from an enabled malformed limit denies
		// upload; only an explicitly disabled limit inherits the global cap.
		return $field_maximum > 0 ? min($global_maximum, $field_maximum) : 0;
	}

	/**
	 * Intersect a persisted field selection with the server-controlled allowlist.
	 *
	 * @param mixed $field_groups Untrusted block attribute; only string arrays are valid.
	 */
	public static function allowed_file_mimes(
		$field_groups,
		?array $policy_settings = null,
	): array {
		// CONFIGURATION SHAPE INVARIANT: An explicitly malformed field list
		// grants no MIME types. Only an actual empty array inherits the global
		// allowlist; corrupt stored block attributes must not crash admission.
		if (
			!is_array($field_groups) ||
			array_filter(
				$field_groups,
				static fn($group) => !is_string($group) ||
					!in_array($group, self::FILE_TYPE_GROUPS, true),
			)
		) {
			return [];
		}

		$settings = self::settings($policy_settings);
		$global_mimes = WPHAVE_Form_Validator::allowed_file_mimes($settings['allowedFileTypes']);
		$field_mimes = WPHAVE_Form_Validator::allowed_file_mimes($field_groups);

		return empty($field_groups)
			? $global_mimes
			: array_intersect_key($field_mimes, $global_mimes);
	}

	/** Reject a complete request batch before any attachment is delivered. */
	public static function validate_batch(
		array $schema,
		array $files,
		?array $policy_settings = null,
	) {
		$uploaded_file_count = 0;
		foreach ($files as $name => $file) {
			if (($schema[$name]['type'] ?? '') === 'file') {
				continue;
			}
			// UPLOAD-SCHEMA INVARIANT: PHP can receive multipart files whose
			// names are absent from the visible field schema. Such bytes cannot
			// accompany a valid submission, even if mail would omit them.
			if (self::is_empty_upload($file)) {
				continue;
			}
			return new WP_Error(
				'wphave_form_unknown_upload',
				__('An unexpected file was uploaded.', 'wphave'),
			);
		}

		foreach ($schema as $name => $field) {
			if ('file' !== ($field['type'] ?? '') || !isset($files[$name])) {
				continue;
			}

			$file = $files[$name];
			if (self::is_empty_upload($file)) {
				continue;
			}

			++$uploaded_file_count;
		}

		if ($uploaded_file_count > self::settings($policy_settings)['maxFiles']) {
			return new WP_Error(
				'wphave_form_too_many_uploads',
				__('Too many files were uploaded.', 'wphave'),
			);
		}

		return true;
	}
}
