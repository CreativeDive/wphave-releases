<?php

/**
 * Durable outbound-side-effect receipts for mail and Audience-only forms.
 * Never expire an uncertain write or send into permission to retry.
 * Only hashes/state are retained; submitted values and attachment bytes stay request-scoped.
 */
final class WPHAVE_Form_Delivery_Receipt {
	public static function begin(
		int $post_id,
		string $form_id,
		string $id,
		array $schema,
		array $values,
		array $settings,
		array $attribution = [],
	): array|WP_Error {
		global $wpdb;
		// CLAIM IDENTITY INVARIANT: An empty form or retry ID collapses distinct
		// direct calls onto one claim. Post zero also creates a key that finish()
		// cannot commit. Reject them before hashing uploads or inserting state.
		if ($post_id <= 0 || $form_id === '' || $id === '') {
			return new WP_Error(
				'delivery_identity_unavailable',
				__('The submission could not be verified.', 'wphave'),
			);
		}
		$payload = $values;
		foreach ($schema as $name => $field) {
			if (($field['type'] ?? '') !== 'file') {
				continue;
			}
			$file = $values[$name] ?? [];
			// FILE IDENTITY INVARIANT: A direct receipt caller cannot authorize
			// reading an arbitrary local path. An absent upload has no name or
			// path; a named upload must be a private PHP-owned temporary file.
			$file_name = is_array($file) ? ($file['name'] ?? '') : null;
			$temporary_file = is_array($file) ? ($file['tmp_name'] ?? '') : null;
			if (
				!is_string($file_name) ||
				!is_string($temporary_file) ||
				($file_name === '') !== ($temporary_file === '') ||
				(
					$temporary_file !== '' &&
					(
						!is_uploaded_file($temporary_file) ||
						!WPHAVE_Form_Upload_Policy::is_private_temporary_file($temporary_file)
					)
				)
			) {
				return new WP_Error(
					'delivery_identity_unavailable',
					__('The uploaded file could not be verified. Please select it again.', 'wphave'),
				);
			}
			// Temporary names change on retry; identity describes the verified
			// request upload bytes and filename, never a caller-selected path.
			$hash = $temporary_file !== '' ? @hash_file('sha256', $temporary_file) : '';
			if ($hash === false) {
				return new WP_Error(
					'delivery_identity_unavailable',
					__(
						'The uploaded file could not be verified. Please select it again.',
						'wphave',
					),
				);
			}
			$payload[$name] = ['name' => $file_name, 'hash' => $hash];
		}
		$key = 'wphave_form_delivery_' . $post_id . '_' . hash('sha256', $form_id . ':' . $id);
		// RETRY ATTRIBUTION INVARIANT: A completed receipt must not authorize
		// a second conversion for a different event, visitor or session. These
		// identifiers are part of the immutable submission claim even when
		// Analytics is unavailable during the first delivery attempt.
		$claim_attribution = [
			'form_event_id' => $attribution['form_event_id'] ?? '',
			'visitor_id' => $attribution['visitor_id'] ?? '',
			'session_id' => $attribution['session_id'] ?? '',
		];
		$json = wp_json_encode([$payload, $settings, $claim_attribution]);
		if ($json === false) {
			return new WP_Error(
				'delivery_identity_unavailable',
				__('The submission could not be verified.', 'wphave'),
			);
		}
		$signature = hash_hmac('sha256', $json, wp_salt('auth'));
		$token = wp_generate_uuid4();
		// RECEIPT-SHAPE INVARIANT: A durable claim needs a valid owner token and
		// exact serialized state before any insert can authorize side effects.
		if (!is_string($token) || !self::is_owner_token($token)) {
			return new WP_Error('delivery_identity_unavailable', __('The submission could not be verified.', 'wphave'));
		}
		$record = ['signature' => $signature, 'state' => 'pending', 'token' => $token];
		$encoded = wp_json_encode($record);
		if (!is_string($encoded) || $encoded === '') {
			return new WP_Error('delivery_identity_unavailable', __('The submission could not be verified.', 'wphave'));
		}
		// INSERT IGNORE and direct reads avoid stale persistent option-cache snapshots.
		$inserted = $wpdb->query(
			$wpdb->prepare(
				"INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')",
				$key,
				$encoded,
			),
		);
		if ($inserted === 1) {
			return ['key' => $key, 'value' => $encoded, 'sent' => false];
		}
		$current = json_decode(
			(string) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT option_value FROM {$wpdb->options} WHERE option_name = %s",
					$key,
				),
			),
			true,
		);
		if (
			$inserted === false ||
			!is_array($current) ||
			($current['signature'] ?? '') !== $signature ||
			!self::is_owner_token($current['token'] ?? null)
		) {
			return new WP_Error(
				'delivery_identity_conflict',
				__(
					'This submission could not be verified. Please reload the form before sending a new submission.',
					'wphave',
				),
			);
		}
		if (($current['state'] ?? '') === 'sent') {
			return ['key' => $key, 'value' => '', 'sent' => true];
		}
		return new WP_Error(
			'delivery_unconfirmed',
			__(
				'This submission is still processing or its delivery could not be confirmed. Please contact the site owner before sending it again.',
				'wphave',
			),
		);
	}

	public static function finish(array $receipt, bool $sent): bool {
		global $wpdb;
		// RECEIPT-KEY INVARIANT: A direct caller cannot use the release path
		// to delete an unrelated option or pass a non-string CAS value to SQL.
		if (
			!is_string($receipt['key'] ?? null) ||
			preg_match('/\Awphave_form_delivery_[1-9][0-9]*_[a-f0-9]{64}\z/D', $receipt['key']) !== 1 ||
			!is_string($receipt['value'] ?? null) ||
			$receipt['value'] === ''
		) {
			return false;
		}
		// RETRY INVARIANT: Only a proven pre-delivery rejection may release
		// this claim. A false transport result or an exception can still mean
		// Audience or SMTP accepted the write and must remain pending.
		if (!$sent) {
			return $wpdb->query(
				$wpdb->prepare(
					"DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s",
					$receipt['key'],
					$receipt['value'],
				),
			) === 1;
		}
		$record = json_decode($receipt['value'] ?? '', true);
		if (
			!is_array($record) ||
			!is_string($record['signature'] ?? null) ||
			!self::is_owner_token($record['token'] ?? null) ||
			($record['state'] ?? null) !== 'pending'
		) {
			// COMMIT INVARIANT: A malformed direct receipt cannot mark an
			// unknown claim as sent or turn a storage error into success.
			return false;
		}
		$record['state'] = 'sent';
		$encoded = wp_json_encode($record);
		if (!is_string($encoded) || $encoded === '') {
			return false;
		}
		return $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$wpdb->options} SET option_value = %s WHERE option_name = %s AND option_value = %s",
				$encoded,
				$receipt['key'],
				$receipt['value'],
			),
		) === 1;
	}

	/** Accept only WordPress' UUIDv4 owner-token representation. */
	private static function is_owner_token($token): bool {
		return is_string($token) &&
			preg_match('/\A[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\z/D', $token) === 1;
	}

	public static function delete_for_post(int $post_id): void {
		global $wpdb;
		// The receipt belongs to its source document; deleted forms cannot authorize retries.
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
				$wpdb->esc_like('wphave_form_delivery_' . $post_id . '_') . '%',
			),
		);
	}
}
add_action('deleted_post', [WPHAVE_Form_Delivery_Receipt::class, 'delete_for_post']);
