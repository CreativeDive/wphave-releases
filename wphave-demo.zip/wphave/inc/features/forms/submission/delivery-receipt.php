<?php

/**
 * Durable mail-stage receipts. Never expire an uncertain send into permission to resend.
 * Only hashes/state are retained; submitted values and attachment bytes stay request-scoped.
 */
final class WPHAVE_Form_Delivery_Receipt {
	public static function begin(
		int $post_id,
		string $form_id,
		string $id,
		array $schema,
		array $values,
		array $settings,
	): array|WP_Error {
		global $wpdb;
		$payload = $values;
		foreach ($schema as $name => $field) {
			if (($field['type'] ?? '') !== 'file') {
				continue;
			}
			$file = $values[$name] ?? [];
			// Upload validation owns path safety before this method runs. Temporary names
			// change on retry; identity must describe the validated bytes and filename.
			$hash = !empty($file['tmp_name']) ? @hash_file('sha256', $file['tmp_name']) : '';
			if ($hash === false) {
				return new WP_Error(
					'delivery_identity_unavailable',
					__(
						'The uploaded file could not be verified. Please select it again.',
						'wphave',
					),
				);
			}
			$payload[$name] = ['name' => $file['name'] ?? '', 'hash' => $hash];
		}
		$key = 'wphave_form_delivery_' . $post_id . '_' . hash('sha256', $form_id . ':' . $id);
		$json = wp_json_encode([$payload, $settings]);
		if ($json === false) {
			return new WP_Error(
				'delivery_identity_unavailable',
				__('The submission could not be verified.', 'wphave'),
			);
		}
		$signature = hash_hmac('sha256', $json, wp_salt('auth'));
		$record = ['signature' => $signature, 'state' => 'pending', 'token' => wp_generate_uuid4()];
		$encoded = wp_json_encode($record);
		// INSERT IGNORE and direct reads avoid stale persistent option-cache snapshots.
		$inserted = $wpdb->query(
			$wpdb->prepare(
				"INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')",
				$key,
				$encoded,
			),
		);
		if ($inserted === 1) {
			return ['key' => $key, 'value' => $encoded, 'sent' => false];
		}
		$current = json_decode(
			(string) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT option_value FROM {$wpdb->options} WHERE option_name = %s",
					$key,
				),
			),
			true,
		);
		if (
			$inserted === false ||
			!is_array($current) ||
			($current['signature'] ?? '') !== $signature
		) {
			return new WP_Error(
				'delivery_identity_conflict',
				__(
					'This submission could not be verified. Please reload the form before sending a new submission.',
					'wphave',
				),
			);
		}
		if (($current['state'] ?? '') === 'sent') {
			return ['key' => $key, 'value' => '', 'sent' => true];
		}
		return new WP_Error(
			'delivery_unconfirmed',
			__(
				'This submission is still processing or its delivery could not be confirmed. Please contact the site owner before sending it again.',
				'wphave',
			),
		);
	}

	public static function finish(array $receipt, bool $sent): bool {
		global $wpdb;
		// A definite transport failure can be retried; crashes/exceptions leave pending
		// intact because SMTP might already have accepted the message.
		if (!$sent) {
			return $wpdb->query(
				$wpdb->prepare(
					"DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s",
					$receipt['key'],
					$receipt['value'],
				),
			) === 1;
		}
		$record = json_decode($receipt['value'], true);
		$record['state'] = 'sent';
		return $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$wpdb->options} SET option_value = %s WHERE option_name = %s AND option_value = %s",
				wp_json_encode($record),
				$receipt['key'],
				$receipt['value'],
			),
		) === 1;
	}

	public static function delete_for_post(int $post_id): void {
		global $wpdb;
		// The receipt belongs to its source document; deleted forms cannot authorize retries.
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
				$wpdb->esc_like('wphave_form_delivery_' . $post_id . '_') . '%',
			),
		);
	}
}
add_action('deleted_post', [WPHAVE_Form_Delivery_Receipt::class, 'delete_for_post']);
