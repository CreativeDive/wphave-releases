<?php

/**
 * Build and send validated form notification emails.
 *
 *  - Resolve recipient and sender settings
 *  - Build HTML mail content from schema + values
 *  - Add optional Reply-To header
 *  - Attach uploaded files
 *  - Clean up temporary uploaded files after every completed mail attempt
 *
 *  - All email addresses sanitized
 *  - Subject sanitized
 *  - Output escaped before rendering into HTML mail template
 *
 *  - Assumes values were already validated before calling send()
 *  - Returns boolean only → caller should handle user-facing errors
 */

class WPHAVE_Form_Mailer {
	/**
	 * Send a validated form notification email.
	 *
	 *  - Recipient email sanitized
	 *  - Sender email sanitized and validated
	 *  - Subject sanitized
	 *
	 *  - Uploaded files are deleted after every completed mail attempt
	 *
	 * @param array $form_settings
	 * @param array $values
	 * @param array $schema
	 * @param array $attachments
	 * @param array $uploaded_files
	 * @return bool
	 */

	public static function send(
		array $form_settings,
		array $values,
		array $schema,
		array $attachments,
		array $uploaded_files,
	): bool {
		try {
			$mail_to = sanitize_email($form_settings['emailTo'] ?? '');
			$subject = sanitize_text_field($form_settings['emailSubject'] ?? 'Form submission');

			// SECURITY INVARIANT: Public submission values may influence only the escaped
			// message and a validated Reply-To address. Delivery authority, recipient and
			// sender identity come from the server-validated stored form configuration.
			// A missing canonical recipient or sender fails closed before wp_mail().
			if (!$mail_to || !is_email($mail_to)) {
				return false;
			}

			$from_name = sanitize_text_field(
				$form_settings['emailFromName'] ?? get_bloginfo('name'),
			);

			$from_email = sanitize_email(
				$form_settings['emailFromEmail'] ??
					($form_settings['emailFrom'] ?? get_option('admin_email')),
			);

			if (!$from_email || !is_email($from_email)) {
				$from_email = sanitize_email(get_option('admin_email'));
			}

			if (!$from_email || !is_email($from_email)) {
				return false;
			}

			$headers = wphave_email_template_headers([
				'from_name' => $from_name,
				'from_email' => $from_email,
			]);

			/*
			 *  - Allows replying directly to the sender
			 *
			 *  - Prefer explicit schema-based detection over guessing by key
			 */

			foreach ($values as $key => $value) {
				$field = $schema[$key] ?? [];

				// Prefer schema type if available
				if (
					!empty($field['type']) &&
					$field['type'] === 'email' &&
					is_string($value) &&
					is_email($value)
				) {
					$headers = wphave_email_template_headers([
						'from_name' => $from_name,
						'from_email' => $from_email,
						'reply_to_email' => $value,
					]);
					break;
				}

				// Fallback: legacy key-based detection
				if (
					empty($field['type']) &&
					is_string($key) &&
					strpos($key, 'email') !== false &&
					is_string($value) &&
					is_email($value)
				) {
					$headers = wphave_email_template_headers([
						'from_name' => $from_name,
						'from_email' => $from_email,
						'reply_to_email' => $value,
					]);
					break;
				}
			}

			if (
				!empty($form_settings['emailReplyTo']) &&
				is_email($form_settings['emailReplyTo'])
			) {
				$headers = wphave_email_template_headers([
					'from_name' => $from_name,
					'from_email' => $from_email,
					'reply_to_email' => sanitize_email($form_settings['emailReplyTo']),
				]);
			}

			/**
			 * Builds HTML email body from validated values and schema.
			 *
			 * FEATURES:
			 * - Resolves option labels for selects / radios / checkbox groups
			 * - Resolves file names for uploads
			 * - Resolves checkbox values to Yes / No
			 * - Escapes all dynamic output before injecting into template
			 *
			 * SECURITY:
			 * - Labels escaped
			 * - Values escaped
			 * - Description/title sanitized before passing into template
			 *
			 * @param array $values
			 * @param array $form_settings
			 * @param array $schema
			 * @return string
			 */

			$message = self::build_message($values, $form_settings, $schema);

			/**
			 * Builds HTML email body from validated values and schema.
			 *
			 * FEATURES:
			 * - Resolves option labels for selects / radios / checkbox groups
			 * - Resolves file names for uploads
			 * - Resolves checkbox values to Yes / No
			 * - Escapes all dynamic output before injecting into template
			 *
			 * SECURITY:
			 * - Labels escaped
			 * - Values escaped
			 * - Description/title sanitized before passing into template
			 *
			 * @param array $values
			 * @param array $form_settings
			 * @param array $schema
			 * @return string
			 */

			$sent = wp_mail($mail_to, $subject, $message, $headers, $attachments);

			/**
			 * Builds HTML email body from validated values and schema.
			 *
			 * FEATURES:
			 * - Resolves option labels for selects / radios / checkbox groups
			 * - Resolves file names for uploads
			 * - Resolves checkbox values to Yes / No
			 * - Escapes all dynamic output before injecting into template
			 *
			 * SECURITY:
			 * - Labels escaped
			 * - Values escaped
			 * - Description/title sanitized before passing into template
			 *
			 * @param array $values
			 * @param array $form_settings
			 * @param array $schema
			 * @return string
			 */

			return (bool) $sent;
		} finally {
			// LIFETIME INVARIANT: Even invalid configuration and throwing mail
			// hooks release request-owned attachments; no retry archive exists.
			WPHAVE_Form_Upload_Policy::release($uploaded_files);
		}
	}

	/**
	 * Build the message.
	 *
	 *  - Resolves option labels for selects / radios / checkbox groups
	 *  - Resolves file names for uploads
	 *  - Resolves checkbox values to Yes / No
	 *  - Escapes all dynamic output before injecting into template
	 *
	 *  - Labels escaped
	 *  - Values escaped
	 *  - Description/title sanitized before passing into template
	 *
	 * @param array $values
	 * @param array $form_settings
	 * @param array $schema
	 * @return string
	 */

	protected static function build_message(
		array $values,
		array $form_settings,
		array $schema,
	): string {
		$email_title = sanitize_text_field($form_settings['emailTitle'] ?? '');

		// Allow limited formatting in description if desired; otherwise use sanitize_text_field
		$email_description = wp_kses_post($form_settings['emailDescription'] ?? '');

		$content = '';

		foreach ($values as $name => $value) {
			$field = $schema[$name] ?? [];
			$field_type = $field['type'] ?? '';
			$display_value = $value;

			if (!empty($field['options']) && is_array($field['options'])) {
				// Multi-value field (e.g. checkbox group)
				if (is_array($value)) {
					$labels = array_map(function ($v) use ($field) {
						return self::get_option_label((string) $v, $field);
					}, $value);

					$display_value = implode(', ', array_filter($labels, 'strlen'));
				} else {
					$display_value = self::get_option_label((string) $value, $field);
				}
			}

			if ($field_type === 'file' && is_array($value)) {
				$display_value = sanitize_file_name($value['name'] ?? '');
			}

			if ($field_type === 'checkbox') {
				$display_value = $value ? __('Yes', 'wphave') : __('No', 'wphave');
			}

			/**
			 * Resolves a stored option value to its display label.
			 *
			 * FALLBACK:
			 * - Returns original value if no matching option exists
			 *
			 * SECURITY:
			 * - Output sanitized before return
			 *
			 * @param string $value
			 * @param array $field
			 * @return string
			 */

			$label = $field['label'] ?? $name;
			$label = sanitize_text_field((string) $label);

			/**
			 * Resolves a stored option value to its display label.
			 *
			 * FALLBACK:
			 * - Returns original value if no matching option exists
			 *
			 * SECURITY:
			 * - Output sanitized before return
			 *
			 * @param string $value
			 * @param array $field
			 * @return string
			 */

			if ($display_value === '' || $display_value === null) {
				continue;
			}

			// Normalize arrays that may still exist unexpectedly
			if (is_array($display_value)) {
				$display_value = implode(
					', ',
					array_map(fn($item) => sanitize_text_field((string) $item), $display_value),
				);
			}

			$content .=
				"
                <p style='line-height: 20px; padding: 0;'>
                    <strong>" .
				esc_html($label) .
				":</strong>
                    <br>
                    " .
				nl2br(esc_html((string) $display_value)) .
				"
                </p>
            ";
		}

		return wphave_build_email_template([
			'title' => $email_title,
			'description' => $email_description,
			'content' => $content,
		]);
	}

	/**
	 * Return the option label.
	 *
	 *  - Returns original value if no matching option exists
	 *
	 *  - Output sanitized before return
	 *
	 * @param string $value
	 * @param array $field
	 * @return string
	 */

	protected static function get_option_label(string $value, array $field): string {
		$options = $field['options'] ?? [];

		if (!is_array($options)) {
			return sanitize_text_field($value);
		}

		foreach ($options as $opt) {
			if (!is_array($opt)) {
				continue;
			}

			$option_value = (string) ($opt['value'] ?? '');
			$option_label = (string) ($opt['label'] ?? '');

			if ($option_value === $value) {
				return sanitize_text_field($option_label !== '' ? $option_label : $value);
			}
		}

		return sanitize_text_field($value);
	}
}
