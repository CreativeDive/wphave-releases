<?php

/**
 * Validate and normalize submitted form values.
 *
 *  - Sanitize raw submitted values
 *  - Validate required fields
 *  - Run type-specific validation
 *  - Return normalized values and structured error map
 *
 *  - Schema-driven
 *  - Stateless
 *  - Field-by-field validation
 *
 *  - Sanitizes all scalar values before validation
 *  - Leaves file arrays untouched until file validation step
 *  - Never trusts raw submitted values directly
 *
 *  - Assumes schema itself is already trusted / normalized
 *  - Does not perform business logic, only validation
 */

class WPHAVE_Form_Validator {

    const MAX_VALUE_LENGTH = 100000;
    const MAX_MULTI_VALUES = 100;

    /**
     * Validate submitted values against the form schema.
     *
     *  - is_valid
     *  - errors
     *  - values
     *
     * @param array $schema
     * @param array $submitted
     * @return array
     */

    public static function validate( array $schema, array $submitted ): array {
        $errors = [];
        $values = [];

        foreach( $schema as $name => $field ) {

            $value_raw = $submitted[ $name ] ?? '';
            $value = self::sanitize( $field, $value_raw );

            $values[ $name ] = $value;

            $field_errors = self::validate_field( $field, $value, $value_raw );

            if( ! empty( $field_errors ) ) {
                $errors[ $name ] = $field_errors;
            }
        }

        return [
            'is_valid' => empty( $errors ),
            'errors' => $errors,
            'values' => $values,
        ];
    }

    /**
     * Sanitize a submitted form-field value.
     *
     *  - Files are returned unchanged (validated later)
     *  - Arrays are sanitized recursively as text
     *  - Scalars are sanitized based on field type
     *
     * @param array $field
     * @param mixed $value
     * @return mixed
     */

    protected static function sanitize( array $field, $value ) {
        $type = $field['type'] ?? 'text';

        // File uploads are validated separately.
        if( $type === 'file' ) {
            return $value;
        }

        // Array values (e.g. checkbox groups)
        if( is_array( $value ) ) {
            return array_map(
                static fn( $item ) => sanitize_text_field( (string) $item ),
                array_slice( $value, 0, self::MAX_MULTI_VALUES + 1 )
            );
        }

        $value = is_scalar( $value ) ? (string) $value : '';

        if( strlen( $value ) > self::MAX_VALUE_LENGTH ) {
            $value = mb_substr( $value, 0, self::MAX_VALUE_LENGTH );
        }

        return match ( $type ) {
            'url' => esc_url_raw( $value ),
            'email' => sanitize_email( $value ),
            'textarea' => sanitize_textarea_field( $value ),
            default => sanitize_text_field( $value ),
        };
    }

    /**
     * Validate the field.
     *
     *  - required state
     *  - type-specific rules
     *
     *  - Required validation always runs first
     *  - File validation runs early and separately
     *  - Optional empty fields skip type validation
     *
     * @param array $field
     * @param mixed $value
     * @param mixed $original
     * @return array
     */

    protected static function validate_field( array $field, $value, $original = '' ): array {

        $errors = [];
        $type = $field['type'] ?? 'text';

        if( is_scalar( $original ) && strlen( (string) $original ) > self::MAX_VALUE_LENGTH ) {
            $errors[] = __( 'Value is too long.', 'wphave' );
        }

        // Enforce the required state before running type-specific validation.

        if( ! empty( $field['required'] ) ) {
            if( is_array( $value ) ) {
                if( empty( $value ) ) {
                    $errors[] = __( 'This field is required.', 'wphave' );
                }
            } else {
                if( $value === '' || $value === null ) {
                    $errors[] = __( 'This field is required.', 'wphave' );
                }
            }
        }

        // File inputs require their original upload array for validation.

        if( $type === 'file' ) {
            return array_merge( $errors, self::validate_file( $original, $field ) );
        }

        /*
         *  - field is optional
         *  - nothing was entered
         */

        if( empty( $field['required'] ) ) {
            $is_empty = is_array( $original ) ? empty( $original ) : ( $original === '' || $original === null );

            if( $is_empty ) {
                return $errors;
            }
        }

        // Dispatch to the validator that matches the normalized field type.

        $method = 'validate_' . str_replace( '-', '_', $type );

        if( method_exists( __CLASS__, $method ) ) {
            $errors = array_merge( $errors, self::$method( $value, $field ) );
        }

        return $errors;
    }

    /**
     * Validate an email address.
     */

    protected static function validate_email( string $value ): array {
        return is_email( $value )
            ? []
            : [ __( 'Invalid email address.', 'wphave' ) ];
    }

    /**
     * Validate a telephone number.
     */

    protected static function validate_tel( string $value ): array {
        $errors = [];

        $normalized = preg_replace( '/[^\d+]/', '', $value );

        if( $value !== '' && $normalized === '' ) {
            return [ __( 'Invalid phone number.', 'wphave' ) ];
        }

        if( ! preg_match( '/^\+?[0-9]+$/', $normalized ) ) {
            return [ __( 'Invalid phone number format.', 'wphave' ) ];
        }

        $length = strlen( ltrim( $normalized, '+' ) );

        if( $length < 6 ) {
            $errors[] = __( 'Phone number is too short.', 'wphave' );
        }

        if( $length > 15 ) {
            $errors[] = __( 'Phone number is too long.', 'wphave' );
        }

        return $errors;
    }

    /**
     * Validate a numeric value and its configured range.
     */

    protected static function validate_number( $value, array $field ): array {
        if( ! is_numeric( $value ) ) {
            return [ __( 'Must be a number.', 'wphave' ) ];
        }

        $errors = [];
        $num = $value + 0;

        $min = isset( $field['attrs']['min'] ) ? (float) $field['attrs']['min'] : null;
        $max = isset( $field['attrs']['max'] ) ? (float) $field['attrs']['max'] : null;

        if( $min !== null && $num < $min ) {
            $errors[] = __( 'Number is too small.', 'wphave' );
        }

        if( $max !== null && $num > $max ) {
            $errors[] = __( 'Number is too large.', 'wphave' );
        }

        return $errors;
    }

    /**
     * Validate a URL and its hostname.
     */

    protected static function validate_url( string $value ): array {
        if( ! filter_var( $value, FILTER_VALIDATE_URL ) ) {
            return [ __( 'Invalid URL.', 'wphave' ) ];
        }

        $host = parse_url( $value, PHP_URL_HOST );

        if( ! $host ) {
            return [ __( 'Invalid URL.', 'wphave' ) ];
        }

        if( str_ends_with( $host, '.' ) ) {
            return [ __( 'Invalid domain.', 'wphave' ) ];
        }

        if( ! filter_var( $host, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME ) ) {
            return [ __( 'Invalid domain.', 'wphave' ) ];
        }

        if( ! str_contains( $host, '.' ) ) {
            return [ __( 'Invalid domain.', 'wphave' ) ];
        }

        return [];
    }

    /**
     * Validate text length constraints.
     */

    protected static function validate_text( string $value, array $field ): array {
        $errors = [];
        $length = mb_strlen( $value );

        $minlength = isset( $field['attrs']['minlength'] ) ? (int) $field['attrs']['minlength'] : null;
        $maxlength = isset( $field['attrs']['maxlength'] ) ? (int) $field['attrs']['maxlength'] : null;

        if( $minlength !== null && $length < $minlength ) {
            $errors[] = __( 'Text is too short.', 'wphave' );
        }

        if( $maxlength !== null && $length > $maxlength ) {
            $errors[] = __( 'Text is too long.', 'wphave' );
        }

        return $errors;
    }

    /**
     * Reuses text validation rules.
     */

    protected static function validate_textarea( string $value, array $field ): array {
        return self::validate_text( $value, $field );
    }

    /**
     * Validate the minimum password length.
     */

    protected static function validate_password( string $value ): array {
        if( strlen( $value ) < 8 ) {
            return [ __( 'Password must be at least 8 characters.', 'wphave' ) ];
        }

        return [];
    }

    /**
     * Validate a required checkbox.
     */

    protected static function validate_checkbox( $value, array $field ): array {
        if( empty( $field['required'] ) ) {
            return [];
        }

        return $value
            ? []
            : [ __( 'This checkbox must be checked.', 'wphave' ) ];
    }

    /**
     * Validate a select value against its configured options.
     */

    protected static function validate_select( $value, array $field ): array {
        // Optional empty select is allowed
        if( $value === '' || $value === null ) {
            return [];
        }

        $options = $field['options'] ?? [];
        $allowed = is_array( $options ) ? array_column( $options, 'value' ) : [];

        if( ! in_array( $value, $allowed, true ) ) {
            return [ __( 'Invalid selection.', 'wphave' ) ];
        }

        return [];
    }

    /**
     * Same logic as select.
     */

    protected static function validate_radio( $value, array $field ): array {
        return self::validate_select( $value, $field );
    }

    /**
     * Validate checkbox-group values against their configured options.
     */

    protected static function validate_checkbox_group( $value, array $field ): array {
        if( $value === '' || $value === null ) {
            return [];
        }

        if( ! is_array( $value ) ) {
            return [ __( 'Invalid selection.', 'wphave' ) ];
        }

        if( count( $value ) > self::MAX_MULTI_VALUES ) {
            return [ __( 'Too many selections.', 'wphave' ) ];
        }

        $options = $field['options'] ?? [];
        $allowed = is_array( $options ) ? array_column( $options, 'value' ) : [];

        foreach( $value as $item ) {
            if( ! in_array( $item, $allowed, true ) ) {
                return [ __( 'Invalid selection.', 'wphave' ) ];
            }
        }

        return [];
    }

    /**
     * Validate an ISO date value.
     */

    protected static function validate_date( string $value ): array {
        $d = \DateTime::createFromFormat( 'Y-m-d', $value );

        return ( $d && $d->format( 'Y-m-d' ) === $value )
            ? []
            : [ __( 'Invalid date.', 'wphave' ) ];
    }

    /**
     * Validate a time value.
     */

    protected static function validate_time( string $value ): array {
        $time = \DateTime::createFromFormat( '!H:i', $value );

        return ( $time && $time->format( 'H:i' ) === $value )
            ? []
            : [ __( 'Invalid time.', 'wphave' ) ];
    }

    /**
     * Validate a local date-time value.
     */

    protected static function validate_datetime_local( string $value ): array {
        $d = \DateTime::createFromFormat( 'Y-m-d\TH:i', $value );

        return ( $d && $d->format( 'Y-m-d\TH:i' ) === $value )
            ? []
            : [ __( 'Invalid date and time.', 'wphave' ) ];
    }

    /**
     * Validate the file.
     *
     *  - Required state
     *  - Upload error state
     *  - Max file size
     *
     *  - Configured MIME and extension policy
     */

    protected static function validate_file( $file, array $field ): array {

        $errors = [];

        // Structure guard first
        // SECURITY: Optional means absent, not malformed. Any non-empty value that is
        // not a PHP upload structure must fail closed before the mutation phase.
        if( ! is_array( $file ) || ! isset( $file['error'] ) ) {
            if( ! empty( $field['required'] ) || ( $file !== '' && $file !== null ) ) {
                $errors[] = __( 'Please upload a file.', 'wphave' );
            }

            return $errors;
        }

        $upload_error = (int) $file['error'];

        if( $upload_error === UPLOAD_ERR_NO_FILE ) {
            if ( ! empty( $field['required'] ) ) {
                $errors[] = __( 'Please upload a file.', 'wphave' );
            }

            return $errors;
        }

        if( $upload_error !== UPLOAD_ERR_OK ) {
            $errors[] = __( 'File upload failed.', 'wphave' );
            return $errors;
        }

        // Max file size
        $max_bytes = WPHAVE_Form_Upload_Policy::max_file_size_bytes( $field );

        if( $max_bytes > 0 ) {
            $max_mb = $max_bytes / 1024 / 1024;

            // SECURITY: This is an early user-facing check only. The mutation
            // boundary independently measures tmp_name because request metadata
            // cannot authorize the configured filesystem limit.
            $size = isset( $file['size'] ) ? (int) $file['size'] : 0;

            if( $size > $max_bytes ) {
                $errors[] = sprintf(
                    /* translators: %s: contextual value. */
                    __( 'File is too large. Maximum size is %s MB.', 'wphave' ),
                    rtrim( rtrim( number_format( $max_mb, 2, '.', '' ), '0' ), '.' )
                );
            }
        }

        $allowed = WPHAVE_Form_Upload_Policy::allowed_file_mimes(
			$field['attrs']['acceptFileTypes'] ?? []
		);

		if( empty( $allowed ) ) {
			$errors[] = __( 'File type is not allowed.', 'wphave' );
		} else {
            $name = sanitize_file_name( $file['name'] ?? '' );
            $type = sanitize_mime_type( $file['type'] ?? '' );
            $ext = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );
            $extension_allowed = false;
            $mime_allowed = false;

            // SECURITY: Requiring both signals prevents either a spoofed client MIME
            // or a renamed extension from independently widening the field policy.
            foreach( $allowed as $allowed_mime => $allowed_extensions ) {
                if( $type === $allowed_mime || ( str_ends_with( $allowed_mime, '/*' ) && str_starts_with( $type, rtrim( $allowed_mime, '*' ) ) ) ) {
                    $mime_allowed = true;
                }

                if( in_array( $ext, $allowed_extensions, true ) ) {
                    $extension_allowed = true;
			}
		}

            if( ! $extension_allowed || ! $mime_allowed ) {
                $errors[] = __( 'File type is not allowed.', 'wphave' );
            }
        }

        return $errors;
    }

    /**
     * Resolve the canonical byte limit for one file field.
     *
     * @param array $field Form field schema.
     * @return int Maximum bytes, or zero when no limit is configured.
     */

    public static function max_file_size_bytes( array $field ): int {
        if( empty( $field['attrs']['limitFileSize'] ) ) {
            return 0;
        }

        return isset( $field['attrs']['maxFileSize'] )
            ? max( 0, (int) round( (float) $field['attrs']['maxFileSize'] * MB_IN_BYTES ) )
            : max( 0, (int) ( $field['attrs']['maxFileSizeBytes'] ?? 0 ) );
    }

    /**
     * Allowed file mimes.
     *
     * @param array $groups Groups.
     * @return array Allowed file mimes.
     */

    public static function allowed_file_mimes( array $groups ): array {
        $groups = array_map( 'sanitize_key', $groups );
        $map = [
            'images' => [
                'image/jpeg' => [ 'jpg', 'jpeg' ],
                'image/png' => [ 'png' ],
                'image/gif' => [ 'gif' ],
                'image/webp' => [ 'webp' ],
            ],
            'pdf' => [
                'application/pdf' => [ 'pdf' ],
            ],
            'documents' => [
                'application/msword' => [ 'doc' ],
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => [ 'docx' ],
            ],
            'spreadsheets' => [
                'application/vnd.ms-excel' => [ 'xls' ],
                'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' => [ 'xlsx' ],
            ],
            'text' => [
                'text/plain' => [ 'txt' ],
                'text/csv' => [ 'csv' ],
            ],
        ];
        $allowed = [];

        foreach( $groups as $group ) {
            if( isset( $map[ $group ] ) ) {
                $allowed = array_merge( $allowed, $map[ $group ] );
            }
        }

        return $allowed;
    }

}
