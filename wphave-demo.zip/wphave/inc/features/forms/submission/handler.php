<?php

/**
 * Coordinate classic and REST form submissions.
 *
 *  - Classic POST submissions (with redirect)
 *  - REST API submissions (JSON response)
 *
 *  - Resolve correct form source (direct form vs. form-loader)
 *  - Normalize submitted data
 *  - Run spam detection
 *  - Validate against schema
 *  - Trigger mailer
 *  - Return structured response
 *
 *  - Form context must be resolved manually (block-based system)
 *  - Does NOT rely on global WP loop
 *  - Schema-driven → fully dynamic forms
 */

class WPHAVE_Form_Submission_Handler {

    protected static $instance = null;

    /**
     * Instance.
     */

    public static function instance() {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Process a submitted form.
     *
     *  - Verify nonce
     *  - Process form
     *  - Store result (transient)
     *  - Redirect back to page
     *
     *  - Used for non-JS fallback
     *  - Always redirects (Post/Redirect/Get pattern)
     *
     * @return void
     */

    public function handle() {

        if ( empty( $_POST['_wphave_form_id'] ) ) {
            return;
        }

		$http_referer = wphave_request_string( $_POST, '_wp_http_referer' );
        $redirect_url = '' !== $http_referer
            ? home_url( $http_referer )
            : home_url();

		$form_id = substr( sanitize_key( wphave_request_string( $_POST, '_wphave_form_id' ) ), 0, 128 );
        $nonce = wphave_request_string( $_POST, '_wphave_form_nonce' );
		$context_post_id = absint( wphave_request_string( $_POST, '_wphave_form_context_post_id' ) );
		$source_post_id = absint( wphave_request_string( $_POST, '_wphave_form_source_post_id' ) ) ?: $context_post_id;

		if ( ! wp_verify_nonce( $nonce, self::nonce_action( $form_id, $context_post_id, $source_post_id ) ) ) {
            return;
        }

		if ( ! $this->is_valid_public_nonce_context( $context_post_id, $source_post_id, $form_id ) ) {
			return;
		}

		// AUTHORIZATION INVARIANT: Once the nonce's public source has been
		// validated, it is the only form-definition authority for this request.
		// Legacy hidden post IDs must not redirect schema, mail or Audience effects
		// to a different draft/private object after authorization has completed.
		$post_id = $source_post_id;
		$_POST['_wphave_post_id'] = $source_post_id;
		$_POST['_wphave_form_source_post_id'] = $source_post_id;

        if( WPHAVE_Form_Spam_Policy::is_rate_limited( WPHAVE_Client_IP::resolve(), (string) ( $_SERVER['HTTP_USER_AGENT'] ?? '' ) ) ) {
            $this->record_protection_block( $post_id, $form_id, 'rate_limit' );
            $this->handle_spam( $form_id, $redirect_url );
        }

        $result = $this->process( $_POST, $_FILES, $form_id, $post_id );

        $result_token = $this->store_result( $form_id, $result );

        // Success redirect
        if ( ! empty( $result['success'] ) ) {
			$form_redirect = wphave_request_string( $_POST, '_wphave_form_redirect' );
            if ( '' !== $form_redirect ) {
                wp_safe_redirect( esc_url_raw( $form_redirect ) );
                exit;
            }

            wp_safe_redirect( esc_url_raw(
                add_query_arg(
                    [
                        'wphave_form' => $form_id,
                        'wphave_form_result' => $result_token,
                    ],
                    $redirect_url
                )
            ) );
            exit;
        }

        // Error redirect
        wp_safe_redirect( esc_url_raw(
            add_query_arg(
                [
                    'wphave_form' => $form_id,
                    'wphave_form_result' => $result_token,
                ],
                $redirect_url
            )
        ) );
        exit;
    }

    /**
     * Return the form source post ID.
     *
     *  - Required for REST requests (no global loop)
     *
     * @param string $form_id
     * @return int|null
     */

    protected function get_form_source_post_id( array $params, string $form_id ): ?int {
        if ( ! empty( $params['_wphave_form_source_post_id'] ) ) {
            $source_post_id = absint( $params['_wphave_form_source_post_id'] );

            if ( $source_post_id && $this->post_contains_form_block( $source_post_id, $form_id ) ) {
                return $source_post_id;
            }
        }

        return null;
    }

    /**
     * Return form post ID.
     *
     * @param string $form_id Form ID.
     * @return ?int Return form post ID.
     */

    protected function get_form_post_id( string $form_id ): ?int {
		$post_id = absint( wphave_request_string( $_POST, '_wphave_post_id' ) );
        if ( $post_id ) {
            return $post_id;
        }

        $post_id = get_the_ID();

        return $post_id ? (int) $post_id : null;
    }

    /**
     * Resolve the form post ID.
     *
     *  - Direct form blocks
     *  - Form loader blocks (cross-post references)
     *
     *  - Required for block-based architecture
     *  - Supports decoupled form rendering
     *
     * @param int $post_id
     * @param string $form_id
     * @return int|null
     */

    protected function resolve_form_post_id( int $post_id, string $form_id ): ?int {

        $post = get_post( $post_id );
        if ( ! $post ) {
            return null;
        }

        $blocks = parse_blocks( $post->post_content );

        // Direct form block in current post, including nested layout blocks.
        if ( $this->find_form_block( $blocks, $form_id ) ) {
            return $post_id;
        }

        // Form loader block referencing another post, including nested layout blocks.
        foreach ( $this->find_form_loader_post_ids( $blocks ) as $loaded_post_id ) {
            $loaded_post = get_post( $loaded_post_id );
            if ( ! $loaded_post ) {
                continue;
            }

            $loaded_blocks = parse_blocks( $loaded_post->post_content );

            if ( $this->find_form_block( $loaded_blocks, $form_id ) ) {
                return (int) $loaded_post_id;
            }
        }

        return null;
    }

    /**
     * Post contains form block.
     *
     * @param int $post_id Post ID.
     * @param string $form_id Form ID.
     * @return bool Post contains form block.
     */

    protected function post_contains_form_block( int $post_id, string $form_id ): bool {
        $post = get_post( $post_id );

        if ( ! $post ) {
            return false;
        }

        return (bool) $this->find_form_block( parse_blocks( $post->post_content ), $form_id );
    }

    /**
     * Recursively finds a form block by form ID.
     */

    protected function find_form_block( array $blocks, ?string $form_id = null, int $depth = 0 ): ?array {
        if ( $depth > WPHAVE_Form_Schema_Parser::MAX_DEPTH ) {
            return null;
        }

        foreach ( $blocks as $block ) {
            if (
                ( $block['blockName'] ?? '' ) === 'wphave/form' &&
                ( $form_id === null || ( $block['attrs']['formId'] ?? '' ) === $form_id )
            ) {
                return $block;
            }

            if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
                $found = $this->find_form_block( $block['innerBlocks'], $form_id, $depth + 1 );

                if ( $found ) {
                    return $found;
                }
            }
        }

        return null;
    }

    /**
     * Recursively collects form-loader source post ids.
     */

    protected function find_form_loader_post_ids( array $blocks, int $depth = 0 ): array {
        if ( $depth > WPHAVE_Form_Schema_Parser::MAX_DEPTH ) {
            return [];
        }

        $post_ids = [];

        foreach ( $blocks as $block ) {
            if ( ( $block['blockName'] ?? '' ) === 'wphave/form-loader' && ! empty( $block['attrs']['formId'] ) ) {
                $post_ids[] = absint( $block['attrs']['formId'] );
            }

            if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
                $post_ids = array_merge( $post_ids, $this->find_form_loader_post_ids( $block['innerBlocks'], $depth + 1 ) );
            }
        }

        return array_values( array_unique( array_filter( $post_ids ) ) );
    }

    /**
     * Process the submitted form data.
     *
     *  - Shared between POST and REST submissions
     *  - Single source of truth for submission logic
     *
     * @param array $params
     * @param array $files
     * @param string $form_id
     * @param int|null $post_id
     * @return array
     */

    public function process( array $params, array $files, string $form_id, ?int $post_id = null ): array {

        $source_post_id = $this->get_form_source_post_id( $params, $form_id );

        if ( $source_post_id ) {
            $post_id = $source_post_id;
        } elseif ( ! $post_id ) {
            $post_id = $this->get_form_post_id( $form_id );
        }

        if ( ! $post_id ) {
            return $this->form_failure_result(
                'missing_form_context',
                __( 'The form context is missing.', 'wphave' ),
                $params,
                $form_id
            );
        }

        $source_post_id = $source_post_id ?: $post_id;
        $post_id = $this->resolve_form_post_id( $post_id, $form_id );

        if ( ! $post_id ) {
            return $this->form_failure_result(
                'missing_form_context',
                __( 'The form context is missing.', 'wphave' ),
                $params,
                $form_id
            );
        }

        $schema = WPHAVE_Form_Schema_Parser::parse_post( $post_id, $form_id );

        if ( empty( $schema ) ) {
            return $this->form_failure_result(
                'missing_form_schema',
                __( 'The form configuration could not be loaded.', 'wphave' ),
                $params,
                $form_id,
                $post_id,
                $source_post_id
            );
        }

        $normalized = $this->normalize( $schema, $params, $files );

        // Spam check: keep old fake-success behavior
        if ( $this->is_spam( $schema, $normalized['raw'], $params ) ) {
            WPHAVE_Form_Protection_Metrics::record( $post_id, $form_id, 'spam' );
            return [
                'is_valid'   => true,
                'success'    => true,
                'errors'     => [],
                'values'     => [],
                'raw_values' => [],
            ];
        }

        $result = WPHAVE_Form_Validator::validate(
            $schema,
            $normalized['values']
        );

        $result['raw_values'] = $normalized['raw'];
        $result['success']    = false;
        $form_settings = $this->get_form_settings( $post_id, $form_id );
        $request_context = $this->get_request_context( $params, $form_id, $post_id, $source_post_id );
        $request_context['goal_id'] = sanitize_key( $form_settings['conversionGoalId'] ?? '' );
        $error_code = 'validation_failed';
		$operational_error_codes = array();

        // Optional fields are valid when empty; this form-level option turns an entirely empty submission into a validation error.
        if ( ! empty( $form_settings['requireAtLeastOneResponse'] ) && ! $this->has_submission_response( $schema, $result['values'] ) ) {
            $result['is_valid'] = false;
            $result['errors']['form'][] = __( 'Please fill in at least one field before submitting.', 'wphave' );
        }

        $mail_sent = false;
        $audience_lead = null;
        $audience_error = null;

        if ( ! empty( $result['is_valid'] ) ) {

            $uploaded = $this->handle_uploads( $schema, $files );

            if ( is_wp_error( $uploaded ) ) {
                $result['is_valid'] = false;
                $result['errors']['form'][] = $uploaded->get_error_message();
                $error_code = 'upload_failed';
				$operational_error_codes[] = $error_code;
            }
        }

        if ( ! empty( $result['is_valid'] ) ) {

            $email_enabled = ! isset( $form_settings['emailNotificationEnabled'] ) || (bool) $form_settings['emailNotificationEnabled'];
			$audience_enabled = ! empty( $form_settings['audienceLeadEnabled'] )
				|| ! empty( $form_settings['audienceSubscriberEnabled'] );
            $audience_result = $this->store_audience_lead(
                $form_settings,
                $result['values'],
                $schema,
                $request_context
            );

            if ( is_wp_error( $audience_result ) ) {
                $audience_error = $audience_result->get_error_message();
                $error_code = 'audience_storage_failed';
				$operational_error_codes[] = $error_code;
                if ( $audience_enabled && ! $email_enabled ) {
                    $result['errors']['form'][] = $audience_error ?: __( 'Submission could not be stored. Please try again later.', 'wphave' );
                }
            } elseif ( is_array( $audience_result ) ) {
                $audience_lead = $audience_result;
            }

            if ( $email_enabled ) {
                $mail_sent = WPHAVE_Form_Mailer::send(
                    $form_settings,
                    $result['values'],
                    $schema,
                    $uploaded['attachments'],
                    $uploaded['uploaded_files']
                );
            } else {
                $this->delete_uploaded_files( $uploaded['uploaded_files'] );
            }

            // 🔥 Mail fail → echter Fehler
            if ( $email_enabled && ! $mail_sent ) {
                $result['errors']['form'][] = __( 'Submission failed. Please try again later.', 'wphave' );
                $error_code = 'mail_delivery_failed';
				$operational_error_codes[] = $error_code;
            }
        }

        $result['success'] = ! empty($result['is_valid']) && empty($result['errors']['form']) && ( ! isset( $email_enabled ) || ! $email_enabled || $mail_sent );

        $analytics_tracked = false;
		$operational_error_codes = array_values( array_unique( $operational_error_codes ) );

		if ( ! empty( $operational_error_codes ) ) {
			$primary_operational_error = end( $operational_error_codes );
			$analytics_tracked = (bool) apply_filters(
				'wphave_form_error_analytics_tracked',
				false,
				array(
					'form_id' => $form_id,
					'form_post_id' => $post_id,
					'source_post_id' => $source_post_id,
					'context' => $request_context,
					'error_code' => $primary_operational_error,
					'error_class' => 'operational',
				)
			);

			foreach ( $operational_error_codes as $operational_error_code ) {
				$this->record_operational_form_error( $operational_error_code, $form_id, $post_id );
			}
		}

        if ( ! empty( $result['success'] ) ) {
			$submission_analytics_tracked = (bool) apply_filters( 'wphave_form_submission_analytics_tracked', false, [
                'form_id' => $form_id,
                'form_post_id' => $post_id,
                'source_post_id' => $source_post_id,
                'schema' => $schema,
                'values' => $result['values'] ?? [],
                'raw_values' => $result['raw_values'] ?? [],
                'context' => $request_context,
                'audience_lead_id' => isset( $audience_lead['id'] ) ? (int) $audience_lead['id'] : 0,
            ] );
			$analytics_tracked = $analytics_tracked || $submission_analytics_tracked;
        } elseif ( empty( $operational_error_codes ) ) {
            $analytics_tracked = (bool) apply_filters( 'wphave_form_error_analytics_tracked', false, [
                'form_id' => $form_id,
                'form_post_id' => $post_id,
                'source_post_id' => $source_post_id,
                'context' => $request_context,
                'error_code' => $error_code,
                'error_class' => 'validation_failed' === $error_code ? 'validation' : 'operational',
            ] );
        }

        $audience_lead_id = isset( $audience_lead['id'] ) ? (int) $audience_lead['id'] : 0;
        $form_event_id = sanitize_text_field( $request_context['form_event_id'] ?? '' );
        $analytics_link_proof = ! $analytics_tracked
            && class_exists( 'WPHAVE_Analytics_Audience_Linker' )
            ? WPHAVE_Analytics_Audience_Linker::create_form_link_proof( $audience_lead_id, $form_event_id )
            : '';

        // Meta Infos für Debug / UI
        $result['meta'] = [
            'mail_sent' => (bool) $mail_sent,
            'mail_skipped' => isset( $email_enabled ) && ! $email_enabled,
            'mail_error' => ( isset( $email_enabled ) && ! $email_enabled ) || $mail_sent ? null : 'Mail could not be sent',
            'audience_lead_id' => $audience_lead_id,
            'audience_error' => $audience_error,
            'goal_id' => $request_context['goal_id'] ?? '',
            'form_event_id' => $form_event_id,
            'analytics_tracked' => $analytics_tracked,
            'analytics_link_proof' => $analytics_link_proof,
            'error_code' => empty( $result['success'] ) ? $error_code : '',
            'error_class' => empty( $result['success'] ) && 'validation_failed' === $error_code ? 'validation' : ( empty( $result['success'] ) ? 'operational' : '' ),
        ];

        return [
            'is_valid'   => ! empty( $result['is_valid'] ),
            'success'    => ! empty( $result['success'] ),
            'errors'     => $result['errors'] ?? [],
            'values'     => $result['values'] ?? [],
            'raw_values' => $result['raw_values'] ?? [],
            'meta'       => $result['meta'] ?? []
        ];
    }

    /**
     * Build and optionally track a safe early form failure.
     *
     * Submitted field values and raw error messages never enter analytics.
     */
    private function form_failure_result( string $error_code, string $message, array $params, string $form_id, int $form_post_id = 0, int $source_post_id = 0 ): array {
        $context = $this->get_request_context( $params, $form_id, $form_post_id, $source_post_id ?: null );
        $analytics_tracked = (bool) apply_filters(
            'wphave_form_error_analytics_tracked',
            false,
            array(
                'form_id' => $form_id,
                'form_post_id' => $form_post_id,
                'source_post_id' => $source_post_id,
                'context' => $context,
                'error_code' => $error_code,
                'error_class' => 'operational',
            )
        );

        $this->record_operational_form_error( $error_code, $form_id, $form_post_id );

        return array(
            'is_valid' => false,
            'success' => false,
            'errors' => array( 'form' => array( $message ) ),
            'values' => array(),
            'raw_values' => array(),
            'meta' => array(
                'analytics_tracked' => $analytics_tracked,
                'form_event_id' => sanitize_text_field( $context['form_event_id'] ?? '' ),
                'goal_id' => sanitize_key( $context['goal_id'] ?? '' ),
                'error_code' => $error_code,
                'error_class' => 'operational',
            ),
        );
    }

    /**
     * Record a privacy-minimized operational failure for administrators.
     */
    private function record_operational_form_error( string $error_code, string $form_id, int $form_post_id = 0 ): void {
		if ( class_exists( 'WPHAVE_Form_Operational_Alerts' ) ) {
			WPHAVE_Form_Operational_Alerts::notify( $error_code, $form_id, $form_post_id );
		}

        if ( ! class_exists( 'WPHAVE_Activity_Log' ) ) {
            return;
        }

        WPHAVE_Activity_Log::record(
            'forms.submission_failed',
            array(
                'category' => 'system',
                'action' => 'failed',
                'status' => 'failure',
                'severity' => 'warning',
                'actor_type' => 'visitor',
                'object_type' => 'form',
                'object_id' => $form_post_id,
                'object_subtype' => 'wphave-forms',
                'object_label' => $form_post_id ? get_the_title( $form_post_id ) : $form_id,
                'context' => array(
                    'error_code' => sanitize_key( $error_code ),
                    'form_id' => sanitize_text_field( $form_id ),
                ),
                'deduplicate' => true,
            )
        );
    }

    /**
     * Determine whether submission response.
     *
     * @param array $schema Schema.
     * @param array $values Values.
     * @return bool Determine whether submission response.
     */

    protected function has_submission_response( array $schema, array $values ): bool {
        foreach ( $schema as $name => $field ) {
            $type = $field['type'] ?? 'text';
            $value = $values[ $name ] ?? null;

            if ( $type === 'file' ) {
                if ( is_array( $value ) && ! empty( $value['name'] ) && (int) ( $value['error'] ?? UPLOAD_ERR_OK ) !== UPLOAD_ERR_NO_FILE ) {
                    return true;
                }

                continue;
            }

            if ( is_bool( $value ) ) {
                if ( $value ) {
                    return true;
                }

                continue;
            }

            if ( is_array( $value ) ) {
                foreach ( $value as $item ) {
                    if ( trim( (string) $item ) !== '' ) {
                        return true;
                    }
                }

                continue;
            }

            if ( trim( (string) $value ) !== '' ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Normalize submitted form values and files.
     *
     *  - Standard input fields (text, email, etc.)
     *  - Checkbox normalization (string → boolean)
     *  - File uploads (wp_handle_upload)
     *
     *  - values: processed field values
     *  - raw: original unmodified values
     *  - attachments: uploaded file paths
     *  - uploaded_files: temp files for cleanup
     *
     *  - Decouples business logic from $_POST / $_FILES
     *  - Ensures consistent input format for validation
     *  - Required for schema-driven processing
     *
     * @param array $schema
     * @param array $params
     * @param array $files
     * @return array
     */

    protected function normalize( array $schema, array $params, array $files ): array {

        $values         = [];
        $raw            = [];
        $attachments    = [];
        $uploaded_files = [];

        foreach ( $schema as $name => $field ) {

            $type = $field['type'] ?? 'text';

            if ( $type === 'checkbox' ) {
                $value = ( $params[ $name ] ?? 'false' ) === 'true';

                $raw[ $name ]    = $value;
                $values[ $name ] = $value;

                continue;
            }

            if ( $type === 'file' ) {
                $file = $files[ $name ] ?? null;

                $raw[ $name ]    = $file;
                $values[ $name ] = $file;

                continue;
            }

            $value = $params[ $name ] ?? '';

            $raw[ $name ]    = $value;
            $values[ $name ] = $value;
        }

        return [
            'values'         => $values,
            'raw'            => $raw,
            'attachments'    => $attachments,
            'uploaded_files' => $uploaded_files,
        ];
    }

    /**
     * Moves validated upload files only after schema validation succeeded.
     */

    protected function handle_uploads( array $schema, array $files ) {
        $attachments = [];
        $uploaded_files = [];
        $upload_plans = [];
		$batch_validation = WPHAVE_Form_Upload_Policy::validate_batch( $schema, $files );

		if ( is_wp_error( $batch_validation ) ) {
			return $batch_validation;
		}

        // SECURITY INVARIANT: Validate and freeze the complete batch before the first
        // filesystem mutation. Never move files by iterating over the raw request again.
        foreach ( $schema as $name => $field ) {
            if ( ( $field['type'] ?? '' ) !== 'file' ) {
                continue;
            }

            $file = $files[ $name ] ?? null;

            if ( $file === null || $file === '' ) {
                continue;
            }

            if ( ! is_array( $file ) || ! isset( $file['error'] ) ) {
                return new WP_Error( 'wphave_form_invalid_upload', __( 'File upload failed.', 'wphave' ) );
            }

            $upload_error = (int) $file['error'];

            if ( $upload_error === UPLOAD_ERR_NO_FILE ) {
                continue;
            }

            if (
                $upload_error !== UPLOAD_ERR_OK ||
                empty( $file['name'] ) ||
                empty( $file['tmp_name'] ) ||
                ! $this->is_valid_uploaded_file( (string) $file['tmp_name'] )
            ) {
                return new WP_Error( 'wphave_form_invalid_upload', __( 'File upload failed.', 'wphave' ) );
            }

            // SECURITY INVARIANT: The field policy and the later upload move apply
            // to the same temporary bytes. Never inherit the preliminary client-size
            // interpretation from form validation at this mutation boundary.
            $upload_bytes = $this->get_uploaded_file_size( (string) $file['tmp_name'] );
            $max_bytes = WPHAVE_Form_Upload_Policy::max_file_size_bytes( $field );

            if ( $upload_bytes === false || $upload_bytes < 1 ) {
                return new WP_Error( 'wphave_form_invalid_upload', __( 'File upload failed.', 'wphave' ) );
            }

            if ( $max_bytes > 0 && $upload_bytes > $max_bytes ) {
                return new WP_Error( 'wphave_form_upload_too_large', __( 'File is too large.', 'wphave' ) );
            }

            $mimes = $this->get_upload_mimes( $field );

            // SECURITY: The browser-provided MIME value is attacker-controlled. Resolve
            // extension and MIME through WordPress using the field's server-side policy.
            $type_check = wp_check_filetype_and_ext(
                (string) $file['tmp_name'],
                sanitize_file_name( (string) $file['name'] ),
                $mimes
            );

            if ( empty( $type_check['ext'] ) || empty( $type_check['type'] ) ) {
                return new WP_Error( 'wphave_form_invalid_upload_type', __( 'File type is not allowed.', 'wphave' ) );
            }

            $upload_plans[] = [
                'file' => $file,
                'overrides' => [
                    'mimes' => $mimes,
                    'test_form' => false,
                ],
            ];
        }

        // SECURITY INVARIANT: Commit only the validated plans above. Each plan carries
        // the exact MIME policy that authorized it, preventing validation/commit drift.
        foreach ( $upload_plans as $upload_plan ) {
            $upload = $this->move_uploaded_file(
                $upload_plan['file'],
                $upload_plan['overrides']
            );

            if ( isset( $upload['error'] ) ) {
                $this->delete_uploaded_files( $uploaded_files );
                return new WP_Error( 'wphave_form_upload_failed', sanitize_text_field( $upload['error'] ) );
            }

            $attachments[] = $upload['file'];
            $uploaded_files[] = $upload['file'];
        }

        return [
            'attachments' => $attachments,
            'uploaded_files' => $uploaded_files,
        ];
    }

    /**
     * Resolve the server-controlled MIME allowlist used by validation and mutation.
     */

    protected function get_upload_mimes( array $field ): array {
        // SECURITY: Stored field configuration may select a known group, but it cannot add
        // MIME types outside this server-owned map or WordPress's global allowlist.
        $allowed = WPHAVE_Form_Upload_Policy::allowed_file_mimes(
            $field['attrs']['acceptFileTypes'] ?? []
        );

        $mimes = [];

        foreach ( $allowed as $mime => $extensions ) {
            $mimes[ implode( '|', $extensions ) ] = $mime;
        }

        return $mimes;
    }

    /**
     * Verify that a temporary path belongs to the current HTTP upload request.
     */

    protected function is_valid_uploaded_file( string $temporary_file ): bool {
        return is_uploaded_file( $temporary_file );
    }

    /**
     * Measure the temporary upload consumed by the commit phase.
     *
     * @param string $temporary_file Verified temporary upload path.
     * @return int|false Actual byte count, or false when it cannot be measured.
     */

    protected function get_uploaded_file_size( string $temporary_file ) {
        return filesize( $temporary_file );
    }

    /**
     * Move one verified upload through the WordPress upload API.
     */

    protected function move_uploaded_file( array $file, array $overrides = [] ): array {
        if ( ! function_exists( 'wp_handle_upload' ) ) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }

        // SECURITY INVARIANT: Do not discard or recompute the policy produced during
        // planning. WordPress must enforce that same allowlist while moving the file.
        return wp_handle_upload(
            $file,
            array_merge(
                [ 'test_form' => false ],
                $overrides
            )
        );
    }

    /**
     * Delete uploaded files.
     *
     * @param array $uploaded_files Uploaded files.
     * @return void
     */

    protected function delete_uploaded_files( array $uploaded_files ): void {
        foreach ( $uploaded_files as $file ) {
            if ( is_string( $file ) && $file !== '' && file_exists( $file ) && is_file( $file ) && is_writable( $file ) ) {
                unlink( $file );
            }
        }
    }

    /**
     * Store the audience lead.
     *
     *  - Lead storage is intentionally separate from email delivery.
     *  - A mail failure must not destroy a validated lead.
     */

    protected function store_audience_lead( array $form_settings, array $values, array $schema, array $context ) {
        if ( ! class_exists( 'WPHAVE_Audience_Manager' ) ) {
            return null;
        }

        $manager = new WPHAVE_Audience_Manager();

        return $manager->create_lead_from_form_submission( $form_settings, $values, $schema, $context );
    }

    /**
     * Extracts attribution and analytics data from the request.
     */

    protected function get_request_context( array $params, string $form_id, int $form_post_id, ?int $source_post_id = null ): array {
        $tracking = [
            'utm_source' => sanitize_text_field( $params['_wphave_utm_source'] ?? '' ),
            'utm_medium' => sanitize_text_field( $params['_wphave_utm_medium'] ?? '' ),
            'utm_campaign' => sanitize_text_field( $params['_wphave_utm_campaign'] ?? '' ),
            'utm_content' => sanitize_text_field( $params['_wphave_utm_content'] ?? '' ),
            'utm_term' => sanitize_text_field( $params['_wphave_utm_term'] ?? '' ),
        ];

        return [
            'form_id' => $form_id,
            'submission_id' => sanitize_text_field( $params['_wphave_submission_id'] ?? wp_generate_uuid4() ),
            'form_post_id' => $form_post_id,
            'source_post_id' => $source_post_id ?: 0,
            'visitor_id' => sanitize_text_field( $params['_wphave_visitor_id'] ?? '' ),
            'session_id' => sanitize_text_field( $params['_wphave_session_id'] ?? '' ),
            'landing_url' => esc_url_raw( $params['_wphave_landing_url'] ?? '' ),
            'current_url' => esc_url_raw( $params['_wphave_current_url'] ?? '' ),
            'referrer_url' => esc_url_raw( $params['_wphave_referrer_url'] ?? '' ),
            'source' => $tracking['utm_source'],
            'medium' => $tracking['utm_medium'],
            'campaign' => $tracking['utm_campaign'],
            'tracking' => $tracking,
            'goal_id' => sanitize_key( $params['_wphave_goal_id'] ?? '' ),
            'form_event_id' => sanitize_text_field( $params['_wphave_form_event_id'] ?? '' ),
            'language' => sanitize_text_field( $params['_wphave_language'] ?? '' ),
            'screen_width' => absint( $params['_wphave_screen_width'] ?? 0 ),
            'screen_height' => absint( $params['_wphave_screen_height'] ?? 0 ),
        ];
    }

    /**
     * Store the result.
     *
     *  - Classic POST submissions (after redirect)
     *  - Passing validation errors & values back to frontend
     *
     *  - WordPress transient (short-lived cache)
     *
     *  - Automatically expires after 60 seconds
     *  - Retrieved once via get_result()
     *
     * @param string $form_id
     * @param array $result
     * @return string One-time result token, or an empty string on storage failure.
     */

    protected function store_result( string $form_id, array $result ): string {
        $token = wp_generate_password( 32, false, false );
		$key = self::get_result_transient_key( $form_id, $token );
		$stored = set_transient(
			$key,
            $result,
            60
        );

		// SECURITY/PRIVACY INVARIANT: A bearer token is published only after its
		// exact result exists in storage. A phantom token must not imply that
		// validation values or success state can be recovered after redirect.
		return $stored && $result === get_transient( $key ) ? $token : '';
    }

    /**
     * Return the result.
     *
     *  - Returns result once
     *  - Deletes transient immediately after retrieval
     *
     *  - Rendering errors after redirect
     *  - Prefilling form values
     *
     *  - One-time read (consume pattern)
     *  - Prevents stale error states
     *
     * @param string $form_id
     * @param string $token One-time result token from the redirect URL.
     * @return array|null
     */

    public static function get_result( string $form_id, string $token ): ?array {
        if( ! preg_match( '/^[A-Za-z0-9]{32}$/', $token ) ) return null;

        $key = self::get_result_transient_key( $form_id, $token );
        $result = get_transient( $key );

		if ( ! is_array( $result ) ) {
			return null;
		}

		// SECURITY/PRIVACY INVARIANT: One-time result data is disclosed only after
		// storage confirms consumption of its bearer. An undeleted token remains
		// replayable and therefore cannot authorize even the first disclosure.
		if ( ! delete_transient( $key ) || false !== get_transient( $key ) ) {
			return null;
		}

		return $result;
    }

    private static function get_result_transient_key( string $form_id, string $token ): string {
        return 'wphave_form_result_' . md5( $form_id . '|' . $token );
    }

    /**
     * Return the form settings.
     *
     *  - Email settings (to, from, subject)
     *  - Metadata for mailer
     *
     *  - wphave/form block attributes
     *
     *  - Only reads first matching form block
     *  - Assumes one form per post context
     *
     * @param int $post_id
     * @return array
     */

    protected function get_form_settings( int $post_id, ?string $form_id = null ): array {
        $post = get_post( $post_id );

        if ( ! $post ) {
            return [];
        }

        $blocks = parse_blocks( $post->post_content );

        $form_block = $this->find_form_block( $blocks, $form_id );

        $form_settings = $form_block['attrs'] ?? [];

        return WPHAVE_Form_Settings::resolve( $form_settings );
    }

    /**
     * Determine whether a form submission is spam.
     *
     *  - Honeypot field (hidden input)
     *  - Submission speed (time threshold)
     *  - Unexpected fields (payload tampering)
     *  - Empty submission pattern
     *  - Missing user agent
     *
     *  - Each rule increases spam score
     *  - Threshold determines final result
     *
     *  - Heuristic-based (not deterministic)
     *  - Designed to block bots without affecting real users
     *
     * @param array $schema
     * @param array $submitted
     * @return bool
     */

    protected function is_spam( array $schema, array $submitted, ?array $request_params = null ): bool {
        $request_params = is_array( $request_params ) ? $request_params : $_POST;

        return WPHAVE_Form_Spam_Policy::is_spam(
			$schema,
			$submitted,
			$request_params,
			(string) ( $_SERVER['HTTP_USER_AGENT'] ?? '' )
		);
    }

    /**
     * Handle a form submission identified as spam.
     *
     *  - Returns fake success response
     *  - Stores empty result
     *  - Redirects user as if submission succeeded
     *
     *  - Prevents bots from detecting validation logic
     *  - Avoids exposing spam detection mechanisms
     *
     *  - Silent failure (no error feedback)
     *  - Mimics successful submission
     *
     * @param string $form_id
     * @param string $redirect_url
     * @return void
     */

    private function record_protection_block( int $source_post_id, string $form_id, string $reason ): void {
        $form_post_id = $this->resolve_form_post_id( $source_post_id, $form_id );
        if ( $form_post_id ) {
            WPHAVE_Form_Protection_Metrics::record( $form_post_id, $form_id, $reason );
        }
    }

    protected function handle_spam( string $form_id, string $redirect_url ): void {
        // Return fake success (important!)
        $result_token = $this->store_result( $form_id, [
            'is_valid'   => true,
            'success'    => true,
            'values'     => [],
            'errors'     => [],
            'raw_values' => [],
        ] );

        // Redirect as if successful
        wp_safe_redirect( esc_url_raw(
            add_query_arg(
                [
                    'wphave_form' => $form_id,
                    'wphave_form_result' => $result_token,
                ],
                $redirect_url
            )
        ) );

        exit;
    }

    /**
     * Handle the REST submission.
     *
     *  - Stateless → no session, no WP loop dependency
     *  - Must be self-secured (permission_callback = public)
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */

    public function handle_rest_submission( WP_REST_Request $request ) {

        /*
         *  - params → normal form fields
         *  - files  → uploaded files
         *
         *  - REST API does NOT use $_POST / $_FILES directly
         */

        $params = $request->get_params();
        $files  = $request->get_file_params();

        /*
         *  - form_id → identifies form instance
         *  - nonce   → CSRF protection
         *  - post_id → required for schema resolution (block system)
         */

		$raw_form_id = (string) ( $params['_wphave_form_id'] ?? '' );
		$form_id = substr( sanitize_key( $raw_form_id ), 0, 128 );
        $nonce = $params['_wphave_form_nonce'] ?? '';
        $post_id = ! empty( $params['_wphave_post_id'] ) ? (int) $params['_wphave_post_id'] : null;
		$context_post_id = absint( $params['_wphave_form_context_post_id'] ?? 0 );
		$source_post_id = absint( $params['_wphave_form_source_post_id'] ?? 0 ) ?: $context_post_id;

        /*
         *  - Prevents external sites from submitting forms via JS
         *  - Adds additional layer beyond nonce
         *
         *  - Origin may be empty (allowed for compatibility)
         */

        $origin = $_SERVER['HTTP_ORIGIN'] ?? '';

        if( $origin ) {
            $home_parts = wp_parse_url( home_url() );
            $origin_parts = wp_parse_url( $origin );
            $home_scheme = strtolower( (string) ( $home_parts['scheme'] ?? '' ) );
            $origin_scheme = strtolower( (string) ( $origin_parts['scheme'] ?? '' ) );
            $home_host = strtolower( (string) ( $home_parts['host'] ?? '' ) );
            $origin_host = strtolower( (string) ( $origin_parts['host'] ?? '' ) );
            $default_ports = [ 'http' => 80, 'https' => 443 ];
            $home_port = (int) ( $home_parts['port'] ?? ( $default_ports[ $home_scheme ] ?? 0 ) );
            $origin_port = (int) ( $origin_parts['port'] ?? ( $default_ports[ $origin_scheme ] ?? 0 ) );

            if( ! $origin_scheme || ! $origin_host || $origin_scheme !== $home_scheme || $origin_host !== $home_host || $origin_port !== $home_port ) {
                return new WP_REST_Response([
                    'success' => false
                ], 403);
            }
        }

        /*
         *  - Accurate rate limiting
         *  - Avoid blocking entire proxy networks
         */

        $ip = WPHAVE_Client_IP::resolve();


        /*
         *  - Based on IP + User-Agent
         *  - Prevents shared IP blocking issues
         *
         *  - Uses WP transient (temporary cache)
         */

        /*
         *  - Delay response (slows down bots)
         *  - Return error (429 Too Many Requests)
         *
         *  - Makes brute-force attacks inefficient
         *  - Prevents high-speed spam flooding
         */

        /*
         *  - Prevents forged requests from external sites
         *  - Ensures request originated from your frontend
         */

        if( empty( $nonce ) ) {
            return new WP_REST_Response([
                'success' => false,
                'errors' => [ 'form' => [ __( 'The form security token is missing. Please reload the page and try again.', 'wphave' ) ] ],
            ], 403);
        }

		if( ! $form_id || ! wp_verify_nonce( $nonce, self::nonce_action( $form_id, $context_post_id, $source_post_id ) ) ) {
            return new WP_REST_Response([
                'success' => false,
                'errors' => [ 'form' => [ __( 'The form security check failed. Please reload the page and try again.', 'wphave' ) ] ],
            ], 403);
        }

		if ( ! $this->is_valid_public_nonce_context( $context_post_id, $source_post_id, $form_id ) ) {
			return new WP_REST_Response(
				array(
					'success' => false,
					'errors' => array(
						'form' => array( __( 'The form is no longer publicly available. Please reload the page.', 'wphave' ) ),
					),
				),
				403
			);
		}

		// AUTHORIZATION INVARIANT: The public context authenticated above is the
		// only form-definition authority for the remaining workflow. A separate,
		// attacker-controlled post ID must not select draft/private schema, delivery
		// or Audience settings after nonce validation has completed.
		$post_id = $source_post_id;
		$params['_wphave_post_id'] = $source_post_id;
		$params['_wphave_form_source_post_id'] = $source_post_id;

		// Consume the visitor bucket only after the request proves a valid public form context.
		if ( WPHAVE_Form_Spam_Policy::is_rate_limited( $ip, (string) ( $_SERVER['HTTP_USER_AGENT'] ?? '' ) ) ) {
			$this->record_protection_block( $post_id, $form_id, 'rate_limit' );
			// Random delay prevents predictable attack timing.
			usleep( rand( 200000, 600000 ) );

			return new WP_REST_Response(
				array(
					'success' => false,
					'errors' => array(
						'form' => array( __( 'Too many requests. Please try again later.', 'wphave' ) ),
					),
				),
				429
			);
		}

        /*
         *  - resolve form context
         *  - normalize input
         *  - validate schema
         *  - run spam detection
         *  - send mail
         *
         *  - structured response object
         */

        $result = $this->process( $params, $files, $form_id, $post_id );

        /*
         *  - success (bool)
         *  - errors (array)
         *  - values (array)
         */

        return new WP_REST_Response( $result, 200 );

    }

    /**
     * Register public form submission and nonce REST routes.
     *
     * Both endpoints are intentionally public. Submission validation and the
     * form-specific nonce are enforced by the handler rather than WP REST auth.
     *
     * @return void
     */

    public function register_rest_routes() {
        register_rest_route( 'wphave/v1', '/form-submit', [
            'methods' => 'POST',
            'callback' => [ $this, 'handle_rest_submission' ],
            'permission_callback' => '__return_true'
        ] );

		register_rest_route( 'wphave/v1', '/form-nonce', [
            'methods' => 'GET',
            'callback' => [ $this, 'create_form_nonce' ],
            'permission_callback' => '__return_true',
            'args' => [
                'formId' => [
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_key',
                    'validate_callback' => [ $this, 'validate_form_id' ],
                ],
				'postId' => [
					'required' => true,
					'type' => 'integer',
					'minimum' => 1,
					'sanitize_callback' => 'absint',
				],
				'sourcePostId' => [
					'required' => false,
					'type' => 'integer',
					'minimum' => 1,
					'sanitize_callback' => 'absint',
				],
            ]
        ] );
    }

    /**
     * Create a nonce scoped to one public form.
     *
     * @param WP_REST_Request $request REST request.
     * @return WP_REST_Response|WP_Error Nonce response or validation error.
     */

    public function create_form_nonce( WP_REST_Request $request ) {
        $form_id = sanitize_key( (string) $request->get_param( 'formId' ) );
		$context_post_id = absint( $request->get_param( 'postId' ) );
		$source_post_id = absint( $request->get_param( 'sourcePostId' ) ) ?: $context_post_id;

        if( ! $form_id ) {
            return new WP_Error( 'wphave_form_nonce_missing_form_id', __( 'Missing form id.', 'wphave' ), [ 'status' => 400 ] );
        }

		// AVAILABILITY INVARIANT: Public proof issuance has its own request budget
		// before a caller-controlled document identity can trigger block parsing.
		// Submission throttling cannot protect this separate, earlier endpoint.
		if (
			WPHAVE_Form_Spam_Policy::is_nonce_rate_limited(
				WPHAVE_Client_IP::resolve(),
				(string) ( $_SERVER['HTTP_USER_AGENT'] ?? '' )
			)
		) {
			return new WP_Error(
				'wphave_form_nonce_rate_limited',
				__( 'Too many form security-token requests. Please try again later.', 'wphave' ),
				[ 'status' => 429 ]
			);
		}

		if ( ! $this->is_valid_public_nonce_context( $context_post_id, $source_post_id, $form_id ) ) {
			return new WP_Error(
				'wphave_form_nonce_invalid_context',
				__( 'The form context is not publicly available.', 'wphave' ),
				[ 'status' => 404 ]
			);
		}

		$response = rest_ensure_response( [
			'nonce' => wp_create_nonce( self::nonce_action( $form_id, $context_post_id, $source_post_id ) ),
		] );

		// SECURITY INVARIANT: A public form nonce is bound to one rendered form
		// context and a short time window. Shared caches must never replay it into
		// another visitor, document revision or expired submission workflow.
		$response->header( 'Cache-Control', 'private, no-store, max-age=0' );
		$response->header( 'Pragma', 'no-cache' );

		return $response;
    }

	/** Build one nonce action bound to the form, public document and verified owner. */
	public static function nonce_action( string $form_id, int $context_post_id, int $source_post_id ): string {
		$form_id = substr( sanitize_key( $form_id ), 0, 128 );

		return implode(
			'|',
			array(
				'wphave_form_submit',
				$form_id,
				absint( $context_post_id ),
				absint( $source_post_id ),
			)
		);
	}

    /**
     * Validate a REST form identifier.
     *
     * @param mixed $value Submitted form identifier.
     * @return bool Whether the identifier is valid.
     */

    public function validate_form_id( $value ) {
		$value = (string) $value;

		return '' !== $value && strlen( $value ) <= 128 && sanitize_key( $value ) === $value;
    }

	/** Verify that a nonce request points to a form rendered by a public document. */
	private function is_valid_public_nonce_context( int $context_post_id, int $source_post_id, string $form_id ): bool {
		$context_post = get_post( $context_post_id );

		if (
			! $context_post
			|| 'publish' !== $context_post->post_status
			|| ! is_post_publicly_viewable( $context_post )
			|| post_password_required( $context_post )
		) {
			return false;
		}

		if ( $source_post_id === $context_post_id ) {
			return $this->post_contains_form_block( $context_post_id, $form_id );
		}

		$source_post = get_post( $source_post_id );

		if (
			! $source_post
			|| 'publish' !== $source_post->post_status
			|| WPHAVE_Form_Manager::POST_TYPE !== $source_post->post_type
			|| ! $this->post_contains_form_block( $source_post_id, $form_id )
		) {
			return false;
		}

		return in_array(
			$source_post_id,
			$this->find_form_loader_post_ids( parse_blocks( $context_post->post_content ) ),
			true
		);
	}
}


/*
 *  - Classic POST handler via 'wp' action
 *  - REST API endpoint for async submissions
 *
 *  - 'wp' hook ensures post context is available
 *  - REST endpoint enables async submissions
 */

$handler = WPHAVE_Form_Submission_Handler::instance();
add_action( 'wp', [ $handler, 'handle' ] ); // <-- "init" action is to early to get the post_id !
add_action( 'rest_api_init', [ $handler, 'register_rest_routes' ] );
