<?php

/**
 * Coordinate classic and REST form submissions.
 *
 *  - Classic POST submissions (with redirect)
 *  - REST API submissions (JSON response)
 *
 *  - Resolve correct form source (direct form vs. form-loader)
 *  - Normalize submitted data
 *  - Run spam detection
 *  - Validate against schema
 *  - Trigger mailer
 *  - Return structured response
 *
 *  - Form context must be resolved manually (block-based system)
 *  - Does NOT rely on global WP loop
 *  - Schema-driven → fully dynamic forms
 */

class WPHAVE_Form_Submission_Handler {
	const MAX_REST_JSON_BYTES = 262144;
	const MAX_FORM_VALUE_BYTES = 262144;
	private const MAX_FORM_VALUE_NODES = 1024;
	private const MAX_FORM_VALUE_DEPTH = 8;
	protected static $instance = null;

	/**
	 * Instance.
	 */

	public static function instance() {
		if (self::$instance === null) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Process a submitted form.
	 *
	 *  - Verify nonce
	 *  - Process form
	 *  - Store result (transient)
	 *  - Redirect back to page
	 *
	 *  - Used for non-JS fallback
	 *  - Always redirects (Post/Redirect/Get pattern)
	 *
	 * @return void
	 */

	public function handle() {
		// CLASSIC INPUT INVARIANT: WordPress slashes $_POST before this hook.
		// Unslash once so validation, Audience, mail and the retry digest all
		// operate on the visitor's original values, as the REST path does.
		$params = wp_unslash($_POST);
		if (empty($params['_wphave_form_id'])) {
			return;
		}

		$form_id = WPHAVE_Form_Identity::normalize(
			wphave_request_string($params, '_wphave_form_id'),
		);
		if (!$form_id) {
			return;
		}
		if (!self::allows_submission_origin()) {
			return;
		}
		$nonce = wphave_request_string($params, '_wphave_form_nonce');
		$context_post_id = WPHAVE_Form_Identity::request_post_id(
			$params['_wphave_form_context_post_id'] ?? null,
		);
		$source_post_id = array_key_exists('_wphave_form_source_post_id', $params)
			? WPHAVE_Form_Identity::request_post_id($params['_wphave_form_source_post_id'])
			: $context_post_id;
		// CLASSIC IDENTITY INVARIANT: A nonce for post 42 does not authorize
		// values such as "42suffix", "042" or a malformed explicit source ID.
		// Match REST admission before spending the public context budget.
		if (!$context_post_id || !$source_post_id) {
			return;
		}

		if (
			!wp_verify_nonce(
				$nonce,
				self::nonce_action($form_id, $context_post_id, $source_post_id),
			)
		) {
			return;
		}

		// AVAILABILITY INVARIANT: A once-issued nonce remains reusable after its
		// form placement is removed. Bound classic context probes before traversing
		// the claimed public layout, just as the REST submission path does.
		if (WPHAVE_Form_Spam_Policy::is_context_rate_limited(WPHAVE_Client_IP::resolve())) {
			return;
		}

		if (!$this->is_valid_public_nonce_context($context_post_id, $source_post_id, $form_id)) {
			return;
		}
		// RESULT-BEARER DESTINATION INVARIANT: The one-time token can expose
		// bounded validation replay. A submitted referer must not send it to
		// an arbitrary same-site path or a route that forwards its query.
		$canonical_return = get_permalink($context_post_id);
		$redirect_url = is_string($canonical_return) && self::is_same_origin_url($canonical_return)
			? $canonical_return
			: home_url();

		// AUTHORIZATION INVARIANT: Once the nonce's public source has been
		// validated, it is the only form-definition authority for this request.
		// Legacy hidden post IDs must not redirect schema, mail or Audience effects
		// to a different draft/private object after authorization has completed.
		$post_id = $source_post_id;
		$params['_wphave_post_id'] = $source_post_id;
		$params['_wphave_form_source_post_id'] = $source_post_id;

		if (
			WPHAVE_Form_Spam_Policy::is_rate_limited(
				WPHAVE_Client_IP::resolve(),
				(string) ($_SERVER['HTTP_USER_AGENT'] ?? ''),
			)
		) {
			$this->record_protection_block($post_id, $form_id, 'rate_limit');
			$this->handle_spam($form_id, $redirect_url);
		}

		$result = $this->process($params, $_FILES, $form_id, $post_id);
		if (!empty($result['success'])) {
			// RESULT MINIMIZATION INVARIANT: Successful classic submissions only
			// need their status after redirect; never retain submitted PII in a
			// URL-addressable one-time result merely for a success message.
			$result['values'] = [];
			$result['raw_values'] = [];
			$result['meta'] = [];
		}

		$result_token = $this->store_result($form_id, $result);
		if ($result_token === '') {
			// CLASSIC CONFIRMATION INVARIANT: A failed one-time result write must
			// not redirect to a form with no result and a fresh submission ID.
			// After successful delivery that would invite an accidental resend.
			nocache_headers();
			wp_die(
				!empty($result['success'])
					? __('The form was submitted, but its confirmation could not be saved. Please do not send it again.', 'wphave')
					: __('The form result could not be saved. Please contact the site owner before trying again.', 'wphave'),
				__('Form confirmation unavailable', 'wphave'),
				['response' => !empty($result['success']) ? 200 : 503],
			);
			return;
		}

		// Success redirect
		if (!empty($result['success'])) {
			$form_redirect = $this->configured_classic_redirect_url(
				$post_id,
				$form_id,
				wphave_request_string($params, '_wphave_form_redirect'),
			);
			if ('' !== $form_redirect) {
				wp_safe_redirect(esc_url_raw($form_redirect));
				exit();
			}

			wp_safe_redirect(
				esc_url_raw(
					add_query_arg(
						[
							'wphave_form' => $form_id,
							'wphave_form_result' => $result_token,
						],
						$redirect_url,
					),
				),
			);
			exit();
		}

		// Error redirect
		wp_safe_redirect(
			esc_url_raw(
				add_query_arg(
					[
						'wphave_form' => $form_id,
						'wphave_form_result' => $result_token,
					],
					$redirect_url,
				),
			),
		);
		exit();
	}

	/**
	 * Return the form source post ID.
	 *
	 *  - Required for REST requests (no global loop)
	 *
	 * @param string $form_id
	 * @return int|null
	 */

	protected function get_form_source_post_id(array $params, string $form_id): ?int {
		if (array_key_exists('_wphave_form_source_post_id', $params)) {
			// DIRECT-SOURCE INVARIANT: The public entries use exact decimal IDs.
			// A direct processor call cannot repair a fractional or signed value
			// into a different Form document through absint().
			$source_post_id = WPHAVE_Form_Identity::request_post_id(
				$params['_wphave_form_source_post_id'],
			);

			if ($source_post_id && $this->post_contains_form_block($source_post_id, $form_id)) {
				return $source_post_id;
			}
		}

		return null;
	}

	/**
	 * Return form post ID.
	 *
	 * @param string $form_id Form ID.
	 * @return ?int Return form post ID.
	 */

	protected function get_form_post_id(string $form_id): ?int {
		$post_id = absint(wphave_request_string($_POST, '_wphave_post_id'));
		if ($post_id) {
			return $post_id;
		}

		$post_id = get_the_ID();

		return $post_id ? (int) $post_id : null;
	}

	/**
	 * Resolve the form post ID.
	 *
	 *  - Direct form blocks
	 *  - Form loader blocks (cross-post references)
	 *
	 *  - Required for block-based architecture
	 *  - Supports decoupled form rendering
	 *
	 * @param int $post_id
	 * @param string $form_id
	 * @return int|null
	 */

	protected function resolve_form_post_id(int $post_id, string $form_id): ?int {
		$post = $post_id > 0 ? get_post($post_id) : null;
		// SOURCE-PUBLICATION INVARIANT: process() is a public PHP method.
		// Direct callers cannot select a draft or password-protected schema
		// without passing the REST/classic public-context admission boundary.
		if (!$post || 'publish' !== $post->post_status || post_password_required($post)) {
			return null;
		}

		$blocks = WPHAVE_Form_Schema_Parser::parse_source_blocks($post->post_content);

		// Direct form block in current post, including nested layout blocks.
		if ($this->find_form_block($blocks, $form_id)) {
			return $post_id;
		}

		// Form loader block referencing another post, including nested layout blocks.
		foreach ($this->find_form_loader_post_ids($blocks) as $loaded_post_id) {
			$loaded_post = get_post($loaded_post_id);
			// SOURCE AUTHORITY INVARIANT: A Loader can select only the same
			// published, unprotected Form document accepted by rendering and
			// public admission. Mere post existence is not source authority.
			if (
				!$loaded_post ||
				WPHAVE_Form_Manager::POST_TYPE !== $loaded_post->post_type ||
				'publish' !== $loaded_post->post_status ||
				post_password_required($loaded_post)
			) {
				continue;
			}

			$loaded_blocks = WPHAVE_Form_Schema_Parser::parse_source_blocks($loaded_post->post_content);

			if (WPHAVE_Form_Schema_Parser::find_unique_form_block($loaded_blocks, $form_id)) {
				return (int) $loaded_post_id;
			}
		}

		return null;
	}

	/**
	 * Post contains form block.
	 *
	 * @param int $post_id Post ID.
	 * @param string $form_id Form ID.
	 * @return bool Post contains form block.
	 */

	protected function post_contains_form_block(int $post_id, string $form_id): bool {
		$post = $post_id > 0 ? get_post($post_id) : null;

		if (!$post || 'publish' !== $post->post_status || post_password_required($post)) {
			return false;
		}

		return (bool) $this->find_form_block(
			WPHAVE_Form_Schema_Parser::parse_source_blocks($post->post_content),
			$form_id,
		);
	}

	/**
	 * Recursively finds a form block by form ID.
	 */

	protected function find_form_block(
		array $blocks,
		?string $form_id = null,
		int $depth = 0,
	): ?array {
		// IDENTITY INVARIANT: admission, settings and field schema select the same
		// visible form instance through one shared traversal policy.
		return WPHAVE_Form_Schema_Parser::find_form_block($blocks, $form_id, $depth);
	}

	/**
	 * Recursively collects form-loader source post ids.
	 */

	protected function find_form_loader_post_ids(array $blocks, int $depth = 0): array {
		if ($depth > WPHAVE_Form_Schema_Parser::MAX_DEPTH) {
			return [];
		}

		$post_ids = [];

		foreach ($blocks as $block) {
			// AUTHORIZATION INVARIANT: existence is not access. Denied ancestors,
			// form blocks and loader blocks exclude the complete path for this visitor.
			if (!WPHAVE_Block_Projection::allows($block, false)) {
				continue;
			}

			if (
				($block['blockName'] ?? '') === 'wphave/form-loader' &&
				!empty($block['attrs']['formId'])
			) {
				// LOADER IDENTITY INVARIANT: The editor stores an integer post ID.
				// Never coerce fractions, signs or arrays into another form source.
				$post_ids[] = WPHAVE_Form_Identity::source_post_id(
					$block['attrs']['formId'],
				);
			}
			if (($block['blockName'] ?? '') === 'wphave/form-loader') {
				// RENDER-PATH INVARIANT: The Loader does not render serialized
				// children. They cannot supply a fallback source after an invalid
				// or inaccessible referenced Form document.
				continue;
			}

			if (!empty($block['innerBlocks']) && is_array($block['innerBlocks'])) {
				$post_ids = array_merge(
					$post_ids,
					$this->find_form_loader_post_ids($block['innerBlocks'], $depth + 1),
				);
			}
		}

		return array_values(array_unique(array_filter($post_ids)));
	}

	/**
	 * Process the submitted form data.
	 *
	 *  - Shared between POST and REST submissions
	 *  - Single source of truth for submission logic
	 *
	 * @param array $params
	 * @param array $files
	 * @param string $form_id
	 * @param int|null $post_id
	 * @return array
	 */

	public function process(
		array $params,
		array $files,
		string $form_id,
		?int $post_id = null,
	): array {
		if (!self::within_form_value_budget($params)) {
			// ADMISSION BUDGET INVARIANT: JSON, multipart and classic POST
			// share one bound for text before schema traversal or delivery.
			return $this->form_failure_result(
				'form_payload_too_large',
				__('The form contains too much data. Please shorten your response.', 'wphave'),
				$params,
				$form_id,
			);
		}

		$source_post_id = $this->get_form_source_post_id($params, $form_id);
		if (array_key_exists('_wphave_form_source_post_id', $params) && !$source_post_id) {
			// EXPLICIT-SOURCE INVARIANT: process() is public PHP API. A malformed,
			// inaccessible or mismatched source cannot fall back to a supplied
			// context post and authorize its different schema or destinations.
			return $this->form_failure_result(
				'missing_form_context',
				__('The form context is missing.', 'wphave'),
				$params,
				$form_id,
			);
		}

		if ($source_post_id) {
			$post_id = $source_post_id;
		} elseif (!$post_id) {
			$post_id = $this->get_form_post_id($form_id);
		}

		if (!$post_id) {
			return $this->form_failure_result(
				'missing_form_context',
				__('The form context is missing.', 'wphave'),
				$params,
				$form_id,
			);
		}

		$source_post_id = $source_post_id ?: $post_id;
		$post_id = $this->resolve_form_post_id($post_id, $form_id);

		if (!$post_id) {
			return $this->form_failure_result(
				'missing_form_context',
				__('The form context is missing.', 'wphave'),
				$params,
				$form_id,
			);
		}

		if (
			array_key_exists('_wphave_submission_id', $params) &&
			!self::is_valid_submission_id($params['_wphave_submission_id'])
		) {
			// RETRY DELIVERY INVARIANT: Replacing an explicitly invalid ID
			// could grant a new mail claim after an uncertain earlier send.
			return $this->form_failure_result(
				'invalid_submission_id',
				__('The submission could not be verified. Please reload the form.', 'wphave'),
				$params,
				$form_id,
				$post_id,
				$source_post_id,
			);
		}

		$schema = WPHAVE_Form_Schema_Parser::parse_post($post_id, $form_id);

		if (empty($schema)) {
			return $this->form_failure_result(
				'missing_form_schema',
				__('The form configuration could not be loaded.', 'wphave'),
				$params,
				$form_id,
				$post_id,
				$source_post_id,
			);
		}
		if (isset($schema[WPHAVE_Form_Schema_Parser::INVALID_SCHEMA_FIELD])) {
			// ADMISSION INVARIANT: A truncated field tree may hide a required
			// CAPTCHA. Never validate or deliver against a partial schema.
			return $this->form_failure_result(
				'invalid_form_schema',
				__('The form configuration could not be loaded.', 'wphave'),
				$params,
				$form_id,
				$post_id,
				$source_post_id,
			);
		}

		foreach ($schema as $field) {
			if (($field['type'] ?? '') !== 'password') {
				continue;
			}
			// CREDENTIAL CONFIDENTIALITY INVARIANT: Generic Forms has no
			// credential destination. Never replay a password into a classic
			// result or send it to mail, Audience or analytics hooks.
			return $this->form_failure_result(
				'password_field_unsupported',
				__('This form contains a password field and cannot be submitted securely. Please contact the site owner.', 'wphave'),
				$params,
				$form_id,
				$post_id,
				$source_post_id,
			);
		}

		$normalized = $this->normalize($schema, $params, $files);

		// Spam check: keep old fake-success behavior
		if ($this->is_spam($schema, $normalized['raw'], $params)) {
			WPHAVE_Form_Protection_Metrics::record($post_id, $form_id, 'spam');
			return [
				'is_valid' => true,
				'success' => true,
				'errors' => [],
				'values' => [],
				'raw_values' => [],
			];
		}

		$captcha_fields = array_filter(
			$schema,
			static fn($field) => ($field['type'] ?? '') === 'captcha',
		);
		// DATA INVARIANT: CAPTCHA is an admission proof, never a response value.
		// Keep it out of validation replay, mail, Audience and analytics data.
		foreach ($schema as $name => $field) {
			if (($field['type'] ?? '') === 'captcha') {
				unset($schema[$name], $normalized['raw'][$name], $normalized['values'][$name]);
			}
		}

		$result = WPHAVE_Form_Validator::validate($schema, $normalized['values']);

		$result['raw_values'] = $normalized['raw'];
		$result['success'] = false;
		$form_settings = $this->get_form_settings($post_id, $form_id);
		$email_enabled =
			!isset($form_settings['emailNotificationEnabled']) ||
			(bool) $form_settings['emailNotificationEnabled'];
		$audience_enabled =
			!empty($form_settings['audienceLeadEnabled']) ||
			!empty($form_settings['audienceSubscriberEnabled']);
		// DELIVERY DESTINATION INVARIANT: A form with no enabled destination
		// must not report success after discarding its response and uploads.
		// Reject it before consuming CAPTCHA proof or starting any side effect.
		if (!$email_enabled && !$audience_enabled) {
			return $this->form_failure_result(
				'missing_delivery_destination',
				__('This form has no delivery destination. Please contact the site owner.', 'wphave'),
				$params,
				$form_id,
				$post_id,
				$source_post_id,
			);
		}
		$request_context = $this->get_request_context($params, $form_id, $post_id, $source_post_id);
		if (($request_context['form_event_id'] ?? '') === '') {
			// CONVERSION RETRY INVARIANT: Analytics falls back to a short time
			// window when the browser sends no event ID. Derive a stable, scoped
			// ID from the immutable submission claim so a late confirmed retry
			// cannot create a second conversion after that window has elapsed.
			$request_context['form_event_id'] = hash_hmac(
				'sha256',
				implode("\0", ['form-submit', $post_id, $form_id, $request_context['submission_id']]),
				wp_salt('auth'),
			);
		}
		// ATTRIBUTION INVARIANT: The stored goal setting, not the submitted
		// hidden field, selects the conversion. Its malformed shape is inert.
		$request_context['goal_id'] = WPHAVE_Form_Identity::conversion_goal_id(
			$form_settings['conversionGoalId'] ?? '',
		);
		$error_code = 'validation_failed';
		$operational_error_codes = [];

		// Optional fields are valid when empty; this form-level option turns an entirely empty submission into a validation error.
		if (
			!empty($form_settings['requireAtLeastOneResponse']) &&
			!$this->has_submission_response($schema, $result['values'])
		) {
			$result['is_valid'] = false;
			$result['errors']['form'][] = __(
				'Please fill in at least one field before submitting.',
				'wphave',
			);
		}

		$mail_sent = false;
		$audience_lead = null;

		$uploaded = null;
		$receipt = null;
		$delivery_uncertain = false;
		try {
			if (!empty($result['is_valid']) && $captcha_fields) {
				// SIDE-EFFECT INVARIANT: Reject an unproven submission before
				// moving uploads, storing Audience data or starting delivery.
				$captcha_errors = WPHAVE_Form_Captcha::validate_fields(
					$captcha_fields,
					$params,
					$form_id,
					$post_id,
				);
				if ($captcha_errors) {
					$result['is_valid'] = false;
					$result['errors'] = array_merge($result['errors'], $captcha_errors);
				}
			}
			if (!empty($result['is_valid'])) {
				$uploaded = $this->handle_uploads($schema, $files);

				if (is_wp_error($uploaded)) {
					$result['is_valid'] = false;
					// PUBLIC ERROR INVARIANT: Only our known upload-policy reasons
					// may reach visitors; never forward an arbitrary WP_Error message.
					$result['errors']['form'][] = match ($uploaded->get_error_code()) {
						'wphave_form_upload_too_large' => __('File is too large.', 'wphave'),
						'wphave_form_invalid_upload_type' => __('File type is not allowed.', 'wphave'),
						'wphave_form_too_many_uploads' => __('Too many files were uploaded.', 'wphave'),
						default => __('The file could not be uploaded. Please try again.', 'wphave'),
					};
					$error_code = 'upload_failed';
					$operational_error_codes[] = $error_code;
				}
			}

			if (!empty($result['is_valid'])) {
				// Claim mail delivery before Audience effects so conflicting retry payloads
				// cannot change one stage while reusing another stage's receipt.
				// RETRY INVARIANT: Audience-only forms need the same durable
				// payload claim as mail. A reused submission ID with different
				// values must fail before the Audience adapter can return an old lead.
				$receipt = $email_enabled || $audience_enabled
					? $this->begin_delivery_receipt(
						$post_id,
						$form_id,
						$request_context['submission_id'],
						$schema,
						$result['values'],
						$form_settings,
						$request_context,
					)
					: null;
				if (is_wp_error($receipt)) {
					// PUBLIC RECEIPT INVARIANT: A receipt error code identifies a
					// recoverable category; its downstream message may contain private
					// storage details and must never become visitor-facing text.
					$receipt_error_code = $receipt->get_error_code();
					if (!in_array($receipt_error_code, ['delivery_identity_unavailable', 'delivery_identity_conflict', 'delivery_unconfirmed'], true)) {
						$receipt_error_code = 'delivery_identity_unavailable';
					}
					$failure = $this->form_failure_result(
						$receipt_error_code,
						self::public_delivery_receipt_error_message($receipt_error_code),
						$params,
						$form_id,
						$post_id,
						$source_post_id,
					);
					$failure['raw_values'] = $normalized['raw'];
					return $failure;
				}
				$delivery_uncertain = $audience_enabled;
				// COMPLETED-RETRY INVARIANT: Subscriber-only forms have no lead
				// lookup for deduplication. A sent receipt already proves that
				// Audience storage completed; do not repeat subscriber effects.
				$subscriber_only_retry =
					$audience_enabled &&
					is_array($receipt) &&
					$receipt['sent'] &&
					($form_settings['audienceLeadEnabled'] ?? false) !== true;
				// LEGACY RETRY INVARIANT: Every newly claimed Audience ID must
				// create a new lead. An older lead without a payload receipt cannot
				// prove that its values match, even when mail is also enabled.
				$request_context['_wphave_require_new_audience_submission'] =
					$audience_enabled && is_array($receipt) && !$receipt['sent'];
				// DESTINATION INVARIANT: Mail-only forms must not invoke Audience
				// storage merely because its manager happens to be installed.
				$audience_result = !$audience_enabled || $subscriber_only_retry
					? null
					: $this->store_audience_lead(
						$form_settings,
						$result['values'],
						$schema,
						$request_context,
					);
				unset($request_context['_wphave_require_new_audience_submission']);

				if (is_wp_error($audience_result)) {
					$audience_rejected_before_write = in_array(
						$audience_result->get_error_code(),
						[
								'wphave_audience_form_email_required',
								'wphave_audience_form_purposes_invalid',
								'wphave_audience_form_consent_required',
								'wphave_audience_form_subscriber_status_invalid',
								'wphave_audience_submission_identity_conflict',
						],
						true,
					);
					// RETRY INVARIANT: Only a proven pre-write rejection may release
					// the claim. An Audience error after a failed rollback or an
					// ambiguous commit may already have persisted some effects.
					$delivery_uncertain = !$audience_rejected_before_write;
					if ($audience_rejected_before_write) {
						// DELIVERY INVARIANT: Refused consent or a submission id bound
						// to another form cannot report mail success. Release the
						// unsent receipt in finally.
						$failure = $this->form_failure_result(
							$audience_result->get_error_code(),
							self::public_audience_error_message($audience_result->get_error_code()),
							$params,
							$form_id,
							$post_id,
							$source_post_id,
						);
						$failure['raw_values'] = $normalized['raw'];
						return $failure;
					}
					$error_code = 'audience_storage_failed';
					$operational_error_codes[] = $error_code;
					if ($audience_enabled) {
						// DELIVERY INVARIANT: A required Audience write must finish
						// before mail starts. Retain an uncertain payload claim so
						// a retry cannot duplicate partially committed effects.
						$failure = $this->form_failure_result(
							$error_code,
							__('Submission storage could not be confirmed. Please contact the site owner before sending again.', 'wphave'),
							$params,
							$form_id,
							$post_id,
							$source_post_id,
						);
						$failure['raw_values'] = $normalized['raw'];
						return $failure;
					}
				} elseif (
					is_array($audience_result) &&
					(
						($form_settings['audienceLeadEnabled'] ?? false) !== true ||
						self::confirmed_audience_lead_id($audience_result['id'] ?? null) > 0
					)
				) {
					$audience_lead = $audience_result;
				} elseif (($form_settings['audienceLeadEnabled'] ?? false) === true) {
				// RETRY INVARIANT: A missing or malformed lead ID is not proof
				// that storage wrote nothing. A truthy non-ID must not certify
				// success or turn into zero in analytics and response metadata.
				// An adapter may have committed before returning an incomplete
				// result; retain the pending claim and deny a retry.
				$delivery_uncertain = true;
				$failure = $this->form_failure_result(
					'delivery_unconfirmed',
					__('Submission storage could not be confirmed. Please contact the site owner before sending again.', 'wphave'),
						$params,
						$form_id,
						$post_id,
						$source_post_id,
					);
					$failure['raw_values'] = $normalized['raw'];
					return $failure;
				}

				if ($email_enabled) {
					$delivery_uncertain = !$receipt['sent'];
					// PREFLIGHT INVARIANT: Decide before invoking the mailer whether
					// configuration alone prevents transport. Rechecking afterward
					// could misclassify an attempted send if option filters change.
					$mail_configuration_failure = $receipt['sent']
						? null
						: WPHAVE_Form_Mailer::configuration_failure($form_settings);
					$mail_sent = $receipt['sent'];
					if (!$mail_sent && $mail_configuration_failure === null) {
						$mail_sent = WPHAVE_Form_Mailer::send(
							$form_settings,
							$result['values'],
							$schema,
							$uploaded['attachments'],
							$uploaded['uploaded_files'],
						);
					}
					if ($audience_enabled && !$receipt['sent'] && !$mail_sent) {
						// CROSS-DESTINATION RETRY INVARIANT: Audience has already
						// committed its values. Releasing this payload claim would let
						// the same ID mail changed values while reusing the old lead.
						// Keep it pending until a staged retry protocol can prove both
						// destinations; manual review is safer than mixed delivery.
						$failure = $this->form_failure_result(
							'delivery_unconfirmed',
							__('The form was stored, but its notification could not be confirmed. Please contact the site owner before sending it again.', 'wphave'),
							$params,
							$form_id,
							$post_id,
							$source_post_id,
						);
						$failure['raw_values'] = $normalized['raw'];
						return $failure;
					}
					if (
						!$audience_enabled &&
						!$receipt['sent'] &&
						!$mail_sent &&
						$mail_configuration_failure === null
					) {
						// MAIL RETRY INVARIANT: A false wp_mail() result is not proof
						// that a transport hook did not deliver the message. Preserve
						// the claim once mail may have been attempted; only a proven
						// preflight configuration failure may release it for retry.
						$delivery_uncertain = true;
						$failure = $this->form_failure_result(
							'delivery_unconfirmed',
							__('Mail delivery could not be confirmed. Please contact the site owner before sending again.', 'wphave'),
							$params,
							$form_id,
							$post_id,
							$source_post_id,
						);
						$failure['raw_values'] = $normalized['raw'];
						return $failure;
					}
					if (
						!$receipt['sent'] &&
						!WPHAVE_Form_Delivery_Receipt::finish($receipt, $mail_sent)
					) {
						// A failed receipt write is not permission to send again on retry.
						$failure = $this->form_failure_result(
							'delivery_unconfirmed',
							__(
								'Delivery could not be confirmed. Please contact the site owner before sending again.',
								'wphave',
							),
							$params,
							$form_id,
							$post_id,
							$source_post_id,
						);
						$failure['raw_values'] = $normalized['raw'];
						return $failure;
					}
				} else {
					if ($audience_enabled && !$receipt['sent']) {
						// A successful Audience write must be committed to its
						// payload claim before reporting submission success.
						if (!WPHAVE_Form_Delivery_Receipt::finish($receipt, true)) {
							$failure = $this->form_failure_result(
								'delivery_unconfirmed',
								__('Submission storage could not be confirmed. Please contact the site owner before sending again.', 'wphave'),
								$params,
								$form_id,
								$post_id,
								$source_post_id,
							);
							$failure['raw_values'] = $normalized['raw'];
							return $failure;
						}
					}
					$this->delete_uploaded_files($uploaded['uploaded_files']);
				}

				// PUBLIC DIAGNOSIS INVARIANT: Only proven configuration categories
				// receive specific text. A false wp_mail() result has no trustworthy
				// SMTP cause, so the transport message stays deliberately bounded.
				if ($email_enabled && !$mail_sent) {
					$result['errors']['form'][] = match ($mail_configuration_failure) {
						'recipient' => __(
							'This form has no valid notification recipient. Please contact the site owner.',
							'wphave',
						),
						'sender' => __(
							'This site has no valid notification sender. Please contact the site owner.',
							'wphave',
						),
						default => __(
							'The site mail service could not send this form. Please contact the site owner or try again later.',
							'wphave',
						),
					};
					$error_code = 'mail_delivery_failed';
					$operational_error_codes[] = $error_code;
				}
			}

			$result['success'] =
				!empty($result['is_valid']) &&
				empty($result['errors']['form']) &&
				(!isset($email_enabled) || !$email_enabled || $mail_sent);

			$analytics_tracked = false;
			$operational_error_codes = array_values(array_unique($operational_error_codes));

			if (!empty($operational_error_codes)) {
				$primary_operational_error = end($operational_error_codes);
				$analytics_tracked = (bool) apply_filters(
					'wphave_form_error_analytics_tracked',
					false,
					[
						'form_id' => $form_id,
						'form_post_id' => $post_id,
						'source_post_id' => $source_post_id,
						'context' => $request_context,
						'error_code' => $primary_operational_error,
						'error_class' => 'operational',
						'error_details' => $this->form_error_diagnostics(
							$result['errors'] ?? [],
							$schema,
						),
					],
				);

				foreach ($operational_error_codes as $operational_error_code) {
					$this->record_operational_form_error(
						$operational_error_code,
						$form_id,
						$post_id,
					);
				}
			}

			if (!empty($result['success'])) {
				// ANALYTICS DATA INVARIANT: Tracking needs identity and outcome
				// metadata, not submitted answers or private upload paths. A
				// third-party filter listener must not receive those values merely
				// because analytics is enabled.
				$submission_analytics_tracked = (bool) apply_filters(
					'wphave_form_submission_analytics_tracked',
					false,
					[
						'form_id' => $form_id,
						'form_post_id' => $post_id,
						'source_post_id' => $source_post_id,
						'context' => $request_context,
						'audience_lead_id' => self::confirmed_audience_lead_id(
							$audience_lead['id'] ?? null,
						),
					],
				);
				$analytics_tracked = $analytics_tracked || $submission_analytics_tracked;
			} elseif (empty($operational_error_codes)) {
				$analytics_tracked = (bool) apply_filters(
					'wphave_form_error_analytics_tracked',
					false,
					[
						'form_id' => $form_id,
						'form_post_id' => $post_id,
						'source_post_id' => $source_post_id,
						'context' => $request_context,
						'error_code' => $error_code,
						'error_class' =>
							'validation_failed' === $error_code ? 'validation' : 'operational',
						'error_details' => $this->form_error_diagnostics(
							$result['errors'] ?? [],
							$schema,
						),
					],
				);
			}

			$audience_lead_id = self::confirmed_audience_lead_id($audience_lead['id'] ?? null);
			$form_event_id = sanitize_text_field($request_context['form_event_id'] ?? '');
			// FALLBACK ATTRIBUTION INVARIANT: A link proof certifies a completed
			// submission, not merely an Audience lead written before another
			// destination or the delivery receipt may have failed.
			$analytics_link_proof =
				!empty($result['success']) &&
				!$analytics_tracked &&
				class_exists('WPHAVE_Analytics_Audience_Linker')
					? WPHAVE_Analytics_Audience_Linker::create_form_link_proof(
						$audience_lead_id,
						$form_event_id,
						$form_id,
						$post_id,
						$request_context['goal_id'] ?? '',
						$request_context['visitor_id'] ?? '',
						$request_context['session_id'] ?? '',
					)
					: '';

			// Meta Infos für Debug / UI
			$result['meta'] = [
				'mail_sent' => (bool) $mail_sent,
				'mail_skipped' => isset($email_enabled) && !$email_enabled,
				'mail_error' =>
					(isset($email_enabled) && !$email_enabled) || $mail_sent
						? null
						: 'Mail could not be sent',
				'audience_lead_id' => $audience_lead_id,
				'goal_id' => $request_context['goal_id'] ?? '',
				'form_event_id' => $form_event_id,
				'analytics_tracked' => $analytics_tracked,
				'analytics_link_proof' => $analytics_link_proof,
				'error_code' => empty($result['success']) ? $error_code : '',
				'error_class' =>
					empty($result['success']) && 'validation_failed' === $error_code
						? 'validation'
						: (empty($result['success'])
							? 'operational'
							: ''),
			];

			return [
				'submission_id' => $request_context['submission_id'],
				'is_valid' => !empty($result['is_valid']),
				'success' => !empty($result['success']),
				'errors' => $result['errors'] ?? [],
				'values' => $this->project_public_result_values(
					$schema,
					$result['values'] ?? [],
					$result['raw_values'] ?? [],
				),
				'raw_values' => $result['raw_values'] ?? [],
				'meta' => $result['meta'] ?? [],
			];
		} finally {
			// Known pre-delivery failures release their exact claim. An
			// exception during Audience storage or mail remains uncertain and
			// must not grant a retry against a different payload.
			if (is_array($receipt) && !$receipt['sent'] && !$delivery_uncertain) {
				WPHAVE_Form_Delivery_Receipt::finish($receipt, false);
			}
			// LIFETIME INVARIANT: Audience, mail and result exceptions cannot retain
			// attachments. PHP also removes its unmoved uploads at request shutdown.
			$this->delete_uploaded_files(
				is_array($uploaded) ? $uploaded['uploaded_files'] ?? [] : [],
			);
		}
	}

	/** Bound total text, key count and nesting without touching uploaded bytes. */
	private static function within_form_value_budget(array $params): bool {
		$bytes = 0;
		$nodes = 0;
		$stack = [[$params, 0]];

		while ($stack) {
			[$value, $depth] = array_pop($stack);
			if (!is_array($value)) {
				if ($value !== null && !is_scalar($value)) {
					return false;
				}
				$bytes += strlen((string) $value);
				if ($bytes > self::MAX_FORM_VALUE_BYTES) {
					return false;
				}
				continue;
			}

			if (
				$depth >= self::MAX_FORM_VALUE_DEPTH ||
				count($value) > self::MAX_FORM_VALUE_NODES - $nodes
			) {
				return false;
			}
			foreach ($value as $key => $item) {
				$nodes++;
				$bytes += strlen((string) $key);
				if ($bytes > self::MAX_FORM_VALUE_BYTES) {
					return false;
				}
				$stack[] = [$item, $depth + 1];
			}
		}

		return true;
	}

	/**
	 * Build and optionally track a safe early form failure.
	 *
	 * Submitted field values and raw error messages never enter analytics.
	 */
	private function form_failure_result(
		string $error_code,
		string $message,
		array $params,
		string $form_id,
		int $form_post_id = 0,
		int $source_post_id = 0,
	): array {
		$context = $this->get_request_context(
			$params,
			$form_id,
			$form_post_id,
			$source_post_id ?: null,
		);
		// EARLY-ERROR GOAL INVARIANT: Stored form settings have not been
		// resolved here. A browser-supplied hidden goal ID cannot select an
		// Analytics goal through the failure hook or public result metadata.
		$context['goal_id'] = '';
		$analytics_tracked = (bool) apply_filters('wphave_form_error_analytics_tracked', false, [
			'form_id' => $form_id,
			'form_post_id' => $form_post_id,
			'source_post_id' => $source_post_id,
			'context' => $context,
			'error_code' => $error_code,
			'error_class' => 'operational',
			'error_details' => $this->form_error_diagnostics(
				['form' => [$message]],
				[],
			),
		]);

		$this->record_operational_form_error($error_code, $form_id, $form_post_id);

		return [
			// REPLAY INVARIANT: Early failures use the same bounded identity as the
			// normal result; untrusted metadata must not escape via this alternate path.
			'submission_id' => $context['submission_id'],
			'is_valid' => false,
			'success' => false,
			'errors' => ['form' => [$message]],
			'values' => [],
			'raw_values' => [],
			'meta' => [
				'analytics_tracked' => $analytics_tracked,
				'form_event_id' => sanitize_text_field($context['form_event_id'] ?? ''),
				'goal_id' => sanitize_key($context['goal_id'] ?? ''),
				'error_code' => $error_code,
				'error_class' => 'operational',
			],
		];
	}

	/**
	 * Project server-produced errors to bounded diagnostic text and block identity.
	 * Submitted values, uploads and arbitrary field names must never be persisted.
	 */
	private function form_error_diagnostics(array $errors, array $schema): array {
		$details = [];

		foreach ($errors as $field_name => $messages) {
			if (count($details) >= 8) {
				break;
			}

			$is_form_error = 'form' === $field_name;
			if (!$is_form_error && !isset($schema[$field_name])) {
				continue;
			}

			$field = $is_form_error ? [] : $schema[$field_name];
			$clean_messages = [];
			foreach (array_slice((array) $messages, 0, 2) as $message) {
				if (is_string($message)) {
					$clean_messages[] = substr(sanitize_text_field($message), 0, 120);
				}
			}

			if (!$clean_messages) {
				continue;
			}

			$details[] = [
				'field' => $is_form_error ? 'form' : substr(sanitize_key($field_name), 0, 100),
				'block' => $is_form_error ? 'form' : sanitize_key($field['type'] ?? 'field'),
				'label' => $is_form_error
					? __('Form', 'wphave')
					: substr(sanitize_text_field($field['label'] ?? $field_name), 0, 100),
				'messages' => $clean_messages,
			];
		}

		return $details;
	}

	/**
	 * Record a privacy-minimized operational failure for administrators.
	 */
	private function record_operational_form_error(
		string $error_code,
		string $form_id,
		int $form_post_id = 0,
	): void {
		if (class_exists('WPHAVE_Form_Operational_Alerts')) {
			WPHAVE_Form_Operational_Alerts::notify($error_code, $form_id, $form_post_id);
		}

		if (!class_exists('WPHAVE_Activity_Log')) {
			return;
		}

		WPHAVE_Activity_Log::record('forms.submission_failed', [
			'category' => 'system',
			'action' => 'failed',
			'status' => 'failure',
			'severity' => 'warning',
			'actor_type' => 'visitor',
			'object_type' => 'form',
			'object_id' => $form_post_id,
			'object_subtype' => 'wphave-forms',
			'object_label' => $form_post_id ? get_the_title($form_post_id) : $form_id,
			'context' => [
				'error_code' => sanitize_key($error_code),
				'form_id' => sanitize_text_field($form_id),
			],
			'deduplicate' => true,
		]);
	}

	/**
	 * Determine whether submission response.
	 *
	 * @param array $schema Schema.
	 * @param array $values Values.
	 * @return bool Determine whether submission response.
	 */

	protected function has_submission_response(array $schema, array $values): bool {
		foreach ($schema as $name => $field) {
			$type = $field['type'] ?? 'text';
			$value = $values[$name] ?? null;

			if ($type === 'file') {
				if (
					is_array($value) &&
					!empty($value['name']) &&
					(int) ($value['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_NO_FILE
				) {
					return true;
				}

				continue;
			}

			if (is_bool($value)) {
				if ($value) {
					return true;
				}

				continue;
			}

			if (is_array($value)) {
				foreach ($value as $item) {
					// RESPONSE-SHAPE INVARIANT: Only scalar checkbox-group
					// choices can count as an answer. A forged nested value must
					// neither satisfy this form rule nor trigger array-to-string warnings.
					if (!is_scalar($item)) {
						continue;
					}
					if (trim((string) $item) !== '') {
						return true;
					}
				}

				continue;
			}

			if (trim((string) $value) !== '') {
				return true;
			}
		}

		return false;
	}

	/**
	 * Normalize submitted form values and files.
	 *
	 *  - Standard input fields (text, email, etc.)
	 *  - Checkbox wire values are validated before boolean conversion
	 *  - Private PHP-owned request uploads
	 *
	 *  - values: processed field values
	 *  - raw: original unmodified values
	 *  - attachments: uploaded file paths
	 *  - uploaded_files: temp files for cleanup
	 *
	 *  - Decouples business logic from $_POST / $_FILES
	 *  - Ensures consistent input format for validation
	 *  - Required for schema-driven processing
	 *
	 * @param array $schema
	 * @param array $params
	 * @param array $files
	 * @return array
	 */

	protected function normalize(array $schema, array $params, array $files): array {
		$values = [];
		$raw = [];
		$attachments = [];
		$uploaded_files = [];

		foreach ($schema as $name => $field) {
			$type = $field['type'] ?? 'text';

			if ($type === 'checkbox') {
				// CONSENT INVARIANT: Do not collapse arbitrary attacker-controlled
				// strings into false before the validator checks the exact renderer
				// vocabulary. A required checkbox must never accept "false" as true.
				$value = $params[$name] ?? 'false';

				// REPLAY SHAPE INVARIANT: A forged checkbox array is rejected by
				// validation, but must never reach a scalar HTML field renderer.
				$raw[$name] = is_scalar($value)
					? WPHAVE_Form_Validator::bound_replay_value($value)
					: '';
				$values[$name] = $value;

				continue;
			}

			if ($type === 'file') {
				$file = $files[$name] ?? null;

				// UPLOAD RESPONSE INVARIANT: Only the selected filename is useful
				// for re-selection guidance. PHP tmp_name, full_path and error
				// metadata must never enter public form results or re-render data.
				$raw[$name] = is_array($file) && is_string($file['name'] ?? null)
					? ['name' => substr(sanitize_file_name($file['name']), 0, 255)]
					: [];
				$values[$name] = $file;

				continue;
			}

			$value = $params[$name] ?? '';

			// FORM REPLAY INVARIANT: A rejected public submission must not
			// reflect unbounded input into REST JSON or classic HTML rendering.
			// REPLAY SHAPE INVARIANT: Only checkbox groups render arrays. A
			// malformed scalar name[] remains invalid but cannot crash classic
			// replay through esc_attr(), esc_html() or selected().
			$raw[$name] = $type === 'checkbox-group' || is_scalar($value)
				? WPHAVE_Form_Validator::bound_replay_value($value)
				: '';
			$values[$name] = $value;
		}

		return [
			'values' => $values,
			'raw' => $raw,
			'attachments' => $attachments,
			'uploaded_files' => $uploaded_files,
		];
	}

	/** Remove request-owned upload metadata from the public result projection. */
	protected function project_public_result_values(
		array $schema,
		array $values,
		array $raw_values,
	): array {
		foreach ($schema as $name => $field) {
			if (($field['type'] ?? '') !== 'file') {
				continue;
			}

			// UPLOAD RESULT INVARIANT: Mail delivery receives the private path,
			// while the REST/classic response receives only the display name.
			$values[$name] = $raw_values[$name] ?? [];
		}

		return $values;
	}

	/**
	 * Prepares private PHP-owned attachments only after schema validation succeeded.
	 */

	protected function handle_uploads(array $schema, array $files) {
		$attachments = [];
		$uploaded_files = [];
		$batch_validation = WPHAVE_Form_Upload_Policy::validate_batch($schema, $files);

		if (is_wp_error($batch_validation)) {
			return $batch_validation;
		}

		// UPLOAD INVARIANT: Validate the complete batch before any delivery.
		// PHP retains ownership and request-end cleanup even when validation fails.
		foreach ($schema as $name => $field) {
			if (($field['type'] ?? '') !== 'file') {
				continue;
			}

			$file = $files[$name] ?? null;

			if ($file === null || $file === '') {
				continue;
			}

			if (!is_array($file) || !isset($file['error'])) {
				return new WP_Error(
					'wphave_form_invalid_upload',
					__('File upload failed.', 'wphave'),
				);
			}

			$upload_error = (int) $file['error'];

			if ($upload_error === UPLOAD_ERR_NO_FILE) {
				if (WPHAVE_Form_Upload_Policy::is_empty_upload($file)) {
					continue;
				}
				return new WP_Error(
					'wphave_form_invalid_upload',
					__('File upload failed.', 'wphave'),
				);
			}

			if (
				$upload_error !== UPLOAD_ERR_OK ||
				empty($file['name']) ||
				empty($file['tmp_name']) ||
				!$this->is_valid_uploaded_file((string) $file['tmp_name'])
			) {
				return new WP_Error(
					'wphave_form_invalid_upload',
					__('File upload failed.', 'wphave'),
				);
			}

			// SECURITY INVARIANT: The field policy and synchronous delivery apply
			// to the same temporary bytes. Never inherit the preliminary client-size
			// interpretation from form validation at this delivery boundary.
			$upload_bytes = $this->get_uploaded_file_size((string) $file['tmp_name']);
			$max_bytes = WPHAVE_Form_Upload_Policy::max_file_size_bytes($field);
			if ($max_bytes <= 0) {
				return new WP_Error(
					'wphave_form_invalid_upload_limit',
					__('File upload is unavailable.', 'wphave'),
				);
			}

			if ($upload_bytes === false || $upload_bytes < 1) {
				return new WP_Error(
					'wphave_form_invalid_upload',
					__('File upload failed.', 'wphave'),
				);
			}

			if ($max_bytes > 0 && $upload_bytes > $max_bytes) {
				return new WP_Error(
					'wphave_form_upload_too_large',
					__('File is too large.', 'wphave'),
				);
			}

			$mimes = $this->get_upload_mimes($field);
			// UPLOAD COMMIT INVARIANT: WordPress treats an empty MIME map as
			// "use every globally allowed type". An empty intersection must deny
			// at the final temporary-file boundary, even if settings changed since
			// the earlier form validation.
			if (empty($mimes)) {
				return new WP_Error(
					'wphave_form_invalid_upload_type',
					__('File type is not allowed.', 'wphave'),
				);
			}

			// SECURITY: The browser-provided MIME value is attacker-controlled. Resolve
			// extension and MIME through WordPress using the field's server-side policy.
			$type_check = wp_check_filetype_and_ext(
				(string) $file['tmp_name'],
				sanitize_file_name((string) $file['name']),
				$mimes,
			);

			if (empty($type_check['ext']) || empty($type_check['type'])) {
				return new WP_Error(
					'wphave_form_invalid_upload_type',
					__('File type is not allowed.', 'wphave'),
				);
			}

			// CONFIDENTIALITY INVARIANT: Keep the PHP-owned upload in place.
			// No public upload directory, media record or persistent copy exists.
			$name = sanitize_file_name((string) $file['name']);
			$attachment_name = $name;
			$suffix = 2;
			while (isset($attachments[$attachment_name])) {
				$attachment_name = $suffix++ . '-' . $name;
			}
			$attachments[$attachment_name] = $file['tmp_name'];
			$uploaded_files[] = $file['tmp_name'];
		}

		return [
			'attachments' => $attachments,
			'uploaded_files' => $uploaded_files,
		];
	}

	/**
	 * Resolve the server-controlled MIME allowlist used before delivery.
	 */

	protected function get_upload_mimes(array $field): array {
		// SECURITY: Stored field configuration may select a known group, but it cannot add
		// MIME types outside this server-owned map or WordPress's global allowlist.
		$allowed = WPHAVE_Form_Upload_Policy::allowed_file_mimes(
			$field['attrs']['acceptFileTypes'] ?? [],
		);

		$mimes = [];

		foreach ($allowed as $mime => $extensions) {
			$mimes[implode('|', $extensions)] = $mime;
		}

		return $mimes;
	}

	/**
	 * Verify that a temporary path belongs to the current HTTP upload request.
	 */

	protected function is_valid_uploaded_file(string $temporary_file): bool {
		return is_uploaded_file($temporary_file) &&
			WPHAVE_Form_Upload_Policy::is_private_temporary_file($temporary_file);
	}

	/**
	 * Measure the temporary upload consumed by the commit phase.
	 *
	 * @param string $temporary_file Verified temporary upload path.
	 * @return int|false Actual byte count, or false when it cannot be measured.
	 */

	protected function get_uploaded_file_size(string $temporary_file) {
		return filesize($temporary_file);
	}

	/**
	 * Delete uploaded files.
	 *
	 * @param array $uploaded_files Uploaded files.
	 * @return void
	 */

	protected function delete_uploaded_files(array $uploaded_files): void {
		WPHAVE_Form_Upload_Policy::release($uploaded_files);
	}

	/** Claim the verified upload payload before any delivery side effect. */
	protected function begin_delivery_receipt(
		int $post_id,
		string $form_id,
		string $submission_id,
		array $schema,
		array $values,
		array $settings,
		array $attribution = [],
	): array|WP_Error {
		return WPHAVE_Form_Delivery_Receipt::begin(
			$post_id,
			$form_id,
			$submission_id,
			$schema,
			$values,
			$settings,
			$attribution,
		);
	}

	/**
	 * Store the audience lead.
	 *
	 *  - Lead storage is intentionally separate from email delivery.
	 *  - A mail failure must not destroy a validated lead.
	 */

	/** Accept only a confirmed database lead identity. */
	private static function confirmed_audience_lead_id($value): int {
		// LEAD IDENTITY INVARIANT: The database can return integer IDs as
		// decimal strings. Signs, fractions, booleans and overflow cannot
		// certify a persisted lead or be repaired into another lead identity.
		if (is_int($value)) {
			return $value > 0 ? $value : 0;
		}
		if (!is_string($value) || !preg_match('/^[1-9][0-9]*$/D', $value)) {
			return 0;
		}
		$id = filter_var($value, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
		return $id === false ? 0 : $id;
	}

	/** Map known Audience admission errors to fixed public text. */
	private static function public_audience_error_message(string $code): string {
		// PUBLIC ERROR INVARIANT: An allowlisted error code does not make the
		// downstream WP_Error message safe for a visitor. Never reflect it.
		return match ($code) {
			'wphave_audience_form_email_required' => __('Please enter a valid email address to subscribe.', 'wphave'),
			'wphave_audience_form_purposes_invalid' => __('This form has invalid subscription purposes. Please contact the site owner.', 'wphave'),
			'wphave_audience_form_consent_required' => __('Please confirm your subscription consent before submitting.', 'wphave'),
			'wphave_audience_form_subscriber_status_invalid' => __('This form has an invalid subscription setting. Please contact the site owner.', 'wphave'),
			'wphave_audience_submission_identity_conflict' => __('This submission could not be verified. Please reload the form.', 'wphave'),
			default => __('Submission could not be stored. Please try again later.', 'wphave'),
		};
	}

	/** Map durable-claim failures to fixed text without exposing storage diagnostics. */
	private static function public_delivery_receipt_error_message(string $code): string {
		return match ($code) {
			'delivery_identity_unavailable' => __('The submission could not be verified. Please reload the form.', 'wphave'),
			'delivery_identity_conflict' => __('This submission could not be verified. Please reload the form before sending a new submission.', 'wphave'),
			'delivery_unconfirmed' => __('This submission is still processing or its delivery could not be confirmed. Please contact the site owner before sending it again.', 'wphave'),
			default => __('The submission could not be verified. Please contact the site owner.', 'wphave'),
		};
	}

	protected function store_audience_lead(
		array $form_settings,
		array $values,
		array $schema,
		array $context,
	) {
		if (!class_exists('WPHAVE_Audience_Manager')) {
			if (
				($form_settings['audienceLeadEnabled'] ?? false) === true ||
				($form_settings['audienceSubscriberEnabled'] ?? false) === true
			) {
				// DEPENDENCY INVARIANT: An enabled Audience destination is
				// required; absent storage is a failure, not an optional skip.
				return new WP_Error(
					'wphave_audience_unavailable',
					__('Audience storage is unavailable.', 'wphave'),
					['status' => 503],
				);
			}
			return null;
		}

		$manager = new WPHAVE_Audience_Manager();

		return $manager->create_lead_from_form_submission(
			$form_settings,
			$values,
			$schema,
			$context,
		);
	}

	/**
	 * Extracts attribution and analytics data from the request.
	 */

	protected function get_request_context(
		array $params,
		string $form_id,
		int $form_post_id,
		?int $source_post_id = null,
	): array {
		$tracking = [
			'utm_source' => self::bounded_context_text($params['_wphave_utm_source'] ?? ''),
			'utm_medium' => self::bounded_context_text($params['_wphave_utm_medium'] ?? ''),
			'utm_campaign' => self::bounded_context_text($params['_wphave_utm_campaign'] ?? ''),
			'utm_content' => self::bounded_context_text($params['_wphave_utm_content'] ?? ''),
			'utm_term' => self::bounded_context_text($params['_wphave_utm_term'] ?? ''),
		];

		return [
			'form_id' => $form_id,
			'submission_id' => self::submission_id_from_params($params),
			'form_post_id' => $form_post_id,
			'source_post_id' => $source_post_id ?: 0,
			'visitor_id' => self::bounded_context_text($params['_wphave_visitor_id'] ?? '', 100),
			'session_id' => self::bounded_context_text($params['_wphave_session_id'] ?? '', 100),
			'landing_url' => self::bounded_context_url($params['_wphave_landing_url'] ?? ''),
			'current_url' => self::bounded_context_url($params['_wphave_current_url'] ?? ''),
			'referrer_url' => self::bounded_context_url($params['_wphave_referrer_url'] ?? ''),
			'source' => $tracking['utm_source'],
			'medium' => $tracking['utm_medium'],
			'campaign' => $tracking['utm_campaign'],
			'tracking' => $tracking,
			'goal_id' => sanitize_key(self::bounded_context_text($params['_wphave_goal_id'] ?? '', 100)),
			'form_event_id' => self::bounded_context_text($params['_wphave_form_event_id'] ?? '', 100),
			'language' => self::bounded_context_text($params['_wphave_language'] ?? '', 32),
			'screen_width' => self::bounded_screen_dimension($params['_wphave_screen_width'] ?? null),
			'screen_height' => self::bounded_screen_dimension($params['_wphave_screen_height'] ?? null),
		];
	}

	/** Apply the Analytics viewport bound before exposing context to form hooks. */
	private static function bounded_screen_dimension($value): int {
		// ATTRIBUTION INVARIANT: absint() repairs negative public values into
		// plausible dimensions. Hooks see this context before Analytics applies
		// its own 65535 ceiling, so reject malformed and overwide values here.
		if (!is_int($value) && !is_string($value)) {
			return 0;
		}
		$dimension = filter_var($value, FILTER_VALIDATE_INT);
		return $dimension !== false && $dimension > 0 && $dimension <= 65535
			? $dimension
			: 0;
	}

	/** Preserve only renderer-issued UUID identities for delivery retries. */
	private static function submission_id_from_params(array $params): string {
		$id = $params['_wphave_submission_id'] ?? null;
		// RETRY IDENTITY INVARIANT: An omitted ID needs fresh entropy;
		// malformed explicit IDs are rejected before any delivery side effect.
		return self::is_valid_submission_id($id)
			? $id
			: WPHAVE_Form_Identity::new_submission_id();
	}

	/** Accept only the format emitted by the PHP and browser generators. */
	private static function is_valid_submission_id($id): bool {
		return is_string($id) &&
			(bool) preg_match(
				'/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/D',
				$id,
			);
	}

	/** Bound public attribution metadata before any persistence or response. */
	private static function bounded_context_text($value, int $limit = 255): string {
		if (!is_scalar($value)) {
			return '';
		}

		// ATTRIBUTION BOUND INVARIANT: Form field caps do not cover these
		// independent public request keys; no unbounded string reaches hooks,
		// Audience storage, mail metadata or the response projection.
		$value = (string) $value;
		$value = function_exists('mb_strcut')
			? mb_strcut($value, 0, $limit, 'UTF-8')
			: substr($value, 0, $limit);
		return sanitize_text_field($value);
	}

	private static function bounded_context_url($value): string {
		if (!is_string($value) || $value === '' || strlen($value) > 2048) {
			return '';
		}
		$parts = wp_parse_url($value);
		if (
			!is_array($parts) ||
			!in_array(strtolower((string) ($parts['scheme'] ?? '')), ['http', 'https'], true) ||
			empty($parts['host']) ||
			isset($parts['user']) ||
			isset($parts['pass'])
		) {
			return '';
		}

		// ATTRIBUTION PRIVACY INVARIANT: Browser URLs can contain login tokens,
		// nonces or personal data in queries and fragments. UTM fields are
		// captured separately; durable context needs only the origin and path.
		$path_only = substr($value, 0, strcspn($value, '?#'));
		return esc_url_raw($path_only, ['http', 'https']);
	}

	/**
	 * Store the result.
	 *
	 *  - Classic POST submissions (after redirect)
	 *  - Passing validation errors & values back to frontend
	 *
	 *  - WordPress transient (short-lived cache)
	 *
	 *  - Automatically expires after 60 seconds
	 *  - Retrieved once via get_result()
	 *
	 * @param string $form_id
	 * @param array $result
	 * @return string One-time result token, or an empty string on storage failure.
	 */

	protected function store_result(string $form_id, array $result): string {
		// BEARER ENTROPY INVARIANT: Classic error results can contain private
		// field values. Use cryptographic bytes directly; wp_generate_password()
		// is filterable and could produce a predictable public URL token.
		try {
			$token = bin2hex(random_bytes(16));
		} catch (Throwable $error) {
			return '';
		}
		$key = self::get_result_transient_key($form_id, $token);
		$stored = set_transient($key, $result, 60);

		// SECURITY/PRIVACY INVARIANT: A bearer token is published only after its
		// exact result exists in storage. A phantom token must not imply that
		// validation values or success state can be recovered after redirect.
		return $stored && $result === get_transient($key) ? $token : '';
	}

	/**
	 * Return the result.
	 *
	 *  - Returns result once
	 *  - Deletes transient immediately after retrieval
	 *
	 *  - Rendering errors after redirect
	 *  - Prefilling form values
	 *
	 *  - One-time read (consume pattern)
	 *  - Prevents stale error states
	 *
	 * @param string $form_id
	 * @param string $token One-time result token from the redirect URL.
	 * @return array|null
	 */

	public static function get_result(string $form_id, string $token): ?array {
		if (!self::is_valid_result_token($token)) {
			return null;
		}

		global $wpdb;
		$key = self::get_result_transient_key($form_id, $token);
		$lock_name = 'wphave_form_result_' . md5($key);
		$acquired = (int) $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 1)', $lock_name));
		if ($acquired !== 1) {
			return null;
		}

		try {
			// ONE-TIME RESULT INVARIANT: Reading and deleting a bearer
			// must be serialized across workers and cache backends. Otherwise
			// two parallel GETs can both read the same private field values.
			$result = get_transient($key);
			if (!is_array($result)) {
				return null;
			}

			// SECURITY/PRIVACY INVARIANT: One-time result data is disclosed only after
			// storage confirms consumption of its bearer.
			if (!delete_transient($key) || false !== get_transient($key)) {
				return null;
			}

			return $result;
		} finally {
			$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lock_name));
		}
	}

	private static function get_result_transient_key(string $form_id, string $token): string {
		return 'wphave_form_result_' . md5($form_id . '|' . $token);
	}

	/** A classic result bearer has one exact wire representation. */
	private static function is_valid_result_token(string $token): bool {
		return preg_match('/\A[A-Za-z0-9]{32}\z/', $token) === 1;
	}

	/** Keep a classic result bearer out of shared caches and navigation referrers. */
	public function protect_result_url_headers(array $headers): array {
		$token = wphave_request_string($_GET, 'wphave_form_result');
		if (self::is_valid_result_token($token)) {
			// BEARER URL INVARIANT: A one-time result may contain validation
			// values. Its URL must never be cached or disclosed as a referrer.
			$headers['Cache-Control'] = 'private, no-store, max-age=0';
			$headers['Referrer-Policy'] = 'no-referrer';
		}

		return $headers;
	}

	/**
	 * Return the form settings.
	 *
	 *  - Email settings (to, from, subject)
	 *  - Metadata for mailer
	 *
	 *  - wphave/form block attributes
	 *
	 *  - Only reads first matching form block
	 *  - Assumes one form per post context
	 *
	 * @param int $post_id
	 * @return array
	 */

	protected function get_form_settings(int $post_id, ?string $form_id = null): array {
		$post = get_post($post_id);

		if (!$post) {
			return [];
		}

		$blocks = WPHAVE_Form_Schema_Parser::parse_source_blocks($post->post_content);

		$form_block = $this->find_form_block($blocks, $form_id);

		// SETTINGS SHAPE INVARIANT: Parsed post content has not passed block
		// attribute validation. Only an attribute map may select delivery policy.
		$form_settings = is_array($form_block['attrs'] ?? null)
			? $form_block['attrs']
			: [];

		return WPHAVE_Form_Settings::resolve($form_settings);
	}

	/** Accept a classic success redirect only when it matches the saved form link. */
	private function configured_classic_redirect_url(
		int $post_id,
		string $form_id,
		string $submitted_url,
	): string {
		if ($submitted_url === '' || !class_exists('WPHAVE_Block_Linking')) {
			return '';
		}

		$settings = $this->get_form_settings($post_id, $form_id);
		$link = $settings['redirectLink'] ?? null;
		if (!is_array($link)) {
			return '';
		}

		$link_data = WPHAVE_Block_Linking::instance()->get_link(['link' => $link]);
		$configured_url = is_array($link_data) && is_string($link_data['url'] ?? null)
			? $link_data['url']
			: '';
		// REDIRECT PARITY INVARIANT: The rendered hidden value already passes
		// WordPress redirect validation. Compare against that exact canonical
		// destination so AJAX and classic POST share one navigation policy.
		$configured_url = $configured_url !== ''
			? wp_validate_redirect($configured_url, '')
			: '';
		// REDIRECT AUTHORITY INVARIANT: A hidden input describes the rendered
		// success link; it cannot choose a different destination after delivery.
		// Exact matching also prevents URL normalization from retargeting it.
		return $configured_url !== '' && hash_equals($configured_url, $submitted_url)
			? $configured_url
			: '';
	}

	/**
	 * Determine whether a form submission is spam.
	 *
	 *  - Honeypot field (hidden input)
	 *  - Submission speed (time threshold)
	 *  - Unexpected fields (payload tampering)
	 *  - Empty submission pattern
	 *  - Missing user agent
	 *
	 *  - Each rule increases spam score
	 *  - Threshold determines final result
	 *
	 *  - Heuristic-based (not deterministic)
	 *  - Designed to block bots without affecting real users
	 *
	 * @param array $schema
	 * @param array $submitted
	 * @return bool
	 */

	protected function is_spam(
		array $schema,
		array $submitted,
		?array $request_params = null,
	): bool {
		$request_params = is_array($request_params) ? $request_params : $_POST;

		return WPHAVE_Form_Spam_Policy::is_spam(
			$schema,
			$submitted,
			$request_params,
			(string) ($_SERVER['HTTP_USER_AGENT'] ?? ''),
		);
	}

	/**
	 * Handle a form submission identified as spam.
	 *
	 *  - Returns fake success response
	 *  - Stores empty result
	 *  - Redirects user as if submission succeeded
	 *
	 *  - Prevents bots from detecting validation logic
	 *  - Avoids exposing spam detection mechanisms
	 *
	 *  - Silent failure (no error feedback)
	 *  - Mimics successful submission
	 *
	 * @param string $form_id
	 * @param string $redirect_url
	 * @return void
	 */

	private function record_protection_block(
		int $source_post_id,
		string $form_id,
		string $reason,
	): void {
		$form_post_id = $this->resolve_form_post_id($source_post_id, $form_id);
		if ($form_post_id) {
			WPHAVE_Form_Protection_Metrics::record($form_post_id, $form_id, $reason);
		}
	}

	protected function handle_spam(string $form_id, string $redirect_url): void {
		// Return fake success (important!)
		$result_token = $this->store_result($form_id, [
			'is_valid' => true,
			'success' => true,
			'values' => [],
			'errors' => [],
			'raw_values' => [],
		]);
		if ($result_token === '') {
			// CLASSIC RESULT INVARIANT: A blocked request still uses the same
			// confirmation-storage contract as an ordinary submission. Never
			// redirect to an empty bearer or reveal the spam decision on failure.
			nocache_headers();
			wp_die(
				__('The form was submitted, but its confirmation could not be saved. Please do not send it again.', 'wphave'),
				__('Form confirmation unavailable', 'wphave'),
				['response' => 200],
			);
			return;
		}

		// Redirect as if successful
		wp_safe_redirect(
			esc_url_raw(
				add_query_arg(
					[
						'wphave_form' => $form_id,
						'wphave_form_result' => $result_token,
					],
					$redirect_url,
				),
			),
		);

		exit();
	}

	/** Require an absolute URL on the site's exact scheme, host and port. */
	private static function is_same_origin_url(string $url): bool {
		// RESULT-BEARER ORIGIN INVARIANT: A filtered permalink and an allowed
		// redirect host are not authority to disclose a private result token.
		// Reuse the proof-issuance rule for browser REST submissions.
		return WPHAVE_Form_Spam_Policy::is_same_origin_url($url);
	}

	/** Admit browser submissions only from this origin on classic and REST paths. */
	private static function allows_submission_origin(): bool {
		$fetch_site = $_SERVER['HTTP_SEC_FETCH_SITE'] ?? '';
		$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
		// PUBLIC-NONCE INVARIANT: Anonymous WordPress nonces are obtainable by
		// visitors. A foreign browser must not use one to forge a classic POST
		// or REST submission. Missing headers retain legacy client support;
		// non-browser callers still face the normal public abuse budgets.
		return WPHAVE_Form_Spam_Policy::allows_browser_proof_request($fetch_site) &&
			($origin === '' || (is_string($origin) && self::is_same_origin_url($origin)));
	}

	/**
	 * Handle the REST submission.
	 *
	 *  - Stateless → no session, no WP loop dependency
	 *  - Must be self-secured (permission_callback = public)
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response|WP_Error
	 */

	public function handle_rest_submission(WP_REST_Request $request) {
		// DIRECT-CALL INVARIANT: The pre-dispatch JSON budget also applies when
		// another PHP caller invokes this public handler without REST admission.
		$body_error = WPHAVE_REST_Body_Budget::check($request, self::MAX_REST_JSON_BYTES);
		if ($body_error) {
			return $body_error;
		}
		/*
		 *  - params → normal form fields
		 *  - files  → uploaded files
		 *
		 *  - REST API does NOT use $_POST / $_FILES directly
		 */

		$params = $request->get_params();
		$files = $request->get_file_params();

		/*
		 *  - form_id → identifies form instance
		 *  - nonce   → CSRF protection
		 *  - post_id → required for schema resolution (block system)
		 */

		$raw_form_id = $params['_wphave_form_id'] ?? null;
		$form_id = WPHAVE_Form_Identity::normalize($raw_form_id);
		$nonce = $params['_wphave_form_nonce'] ?? '';
		$context_post_id = WPHAVE_Form_Identity::request_post_id($params['_wphave_form_context_post_id'] ?? null);
		$source_post_id = array_key_exists('_wphave_form_source_post_id', $params)
			? WPHAVE_Form_Identity::request_post_id($params['_wphave_form_source_post_id'])
			: $context_post_id;

		/*
		 *  - Prevents external sites from submitting forms via JS
		 *  - Adds additional layer beyond nonce
		 *
		 *  - Origin may be empty (allowed for compatibility)
		 */

		if (!self::allows_submission_origin()) {
			return new WP_REST_Response(
				[
					'success' => false,
				],
				403,
			);
		}
		// REQUEST IDENTITY INVARIANT: A valid nonce never licenses coercion of
		// malformed post references into a different public form placement.
		if (!$context_post_id || !$source_post_id) {
			return new WP_REST_Response(['success' => false], 403);
		}

		/*
		 *  - Accurate rate limiting
		 *  - Avoid blocking entire proxy networks
		 */

		$ip = WPHAVE_Client_IP::resolve();

		/*
		 *  - Based on IP + User-Agent
		 *  - Prevents shared IP blocking issues
		 *
		 *  - Uses WP transient (temporary cache)
		 */

		/*
		 *  - Delay response (slows down bots)
		 *  - Return error (429 Too Many Requests)
		 *
		 *  - Makes brute-force attacks inefficient
		 *  - Prevents high-speed spam flooding
		 */

		/*
		 *  - Prevents forged requests from external sites
		 *  - Ensures request originated from your frontend
		 */

		// INPUT-SHAPE INVARIANT: REST body values can be arrays or objects. Never
		// pass them into WordPress nonce casting or context admission.
		if (!is_string($nonce) || $nonce === '') {
			return new WP_REST_Response(
				[
					'success' => false,
					'errors' => [
						'form' => [
							__(
								'The form security token is missing. Please reload the page and try again.',
								'wphave',
							),
						],
					],
				],
				403,
			);
		}

		if (
			!$form_id ||
			!wp_verify_nonce(
				$nonce,
				self::nonce_action($form_id, $context_post_id, $source_post_id),
			)
		) {
			return new WP_REST_Response(
				[
					'success' => false,
					'errors' => [
						'form' => [
							__(
								'The form security check failed. Please reload the page and try again.',
								'wphave',
							),
						],
					],
				],
				403,
			);
		}

		// AVAILABILITY INVARIANT: A reusable, previously issued nonce can name a
		// now-unpublished form. Bound every authenticated context probe before
		// resolving and parsing the claimed document.
		if (WPHAVE_Form_Spam_Policy::is_context_rate_limited($ip)) {
			return new WP_REST_Response(
				[
					'success' => false,
					'errors' => [
						'form' => [__('Too many requests. Please try again later.', 'wphave')],
					],
				],
				429,
			);
		}

		if (!$this->is_valid_public_nonce_context($context_post_id, $source_post_id, $form_id)) {
			return new WP_REST_Response(
				[
					'success' => false,
					'errors' => [
						'form' => [
							__(
								'The form is no longer publicly available. Please reload the page.',
								'wphave',
							),
						],
					],
				],
				403,
			);
		}

		// AUTHORIZATION INVARIANT: The public context authenticated above is the
		// only form-definition authority for the remaining workflow. A separate,
		// attacker-controlled post ID must not select draft/private schema, delivery
		// or Audience settings after nonce validation has completed.
		$post_id = $source_post_id;
		$params['_wphave_post_id'] = $source_post_id;
		$params['_wphave_form_source_post_id'] = $source_post_id;

		// Consume the visitor bucket only after the request proves a valid public form context.
		if (
			WPHAVE_Form_Spam_Policy::is_rate_limited(
				$ip,
				(string) ($_SERVER['HTTP_USER_AGENT'] ?? ''),
			)
		) {
			$this->record_protection_block($post_id, $form_id, 'rate_limit');
			// Random delay prevents predictable attack timing.
			usleep(rand(200000, 600000));

			return new WP_REST_Response(
				[
					'success' => false,
					'errors' => [
						'form' => [__('Too many requests. Please try again later.', 'wphave')],
					],
				],
				429,
			);
		}

		/*
		 *  - resolve form context
		 *  - normalize input
		 *  - validate schema
		 *  - run spam detection
		 *  - send mail
		 *
		 *  - structured response object
		 */

		$result = $this->process($params, $files, $form_id, $post_id);
		if (!empty($result['success'])) {
			// REST RESULT MINIMIZATION INVARIANT: Success needs no field replay.
			// The same validated values have already reached their configured
			// destinations; do not copy visitor PII into a second response body.
			$result['values'] = [];
			$result['raw_values'] = [];
		}

		/*
		 *  - success (bool)
		 *  - errors (array)
		 *  - values (array)
		 */

		$response = new WP_REST_Response($result, 200);
		// RESPONSE CONFIDENTIALITY INVARIANT: Validation replay contains user
		// input. Shared or browser caches must not retain a submission response.
		$response->header('Cache-Control', 'private, no-store, max-age=0');
		$response->header('Pragma', 'no-cache');
		return $response;
	}

	/**
	 * Register public form submission and nonce REST routes.
	 *
	 * Both endpoints are intentionally public. Submission validation and the
	 * form-specific nonce are enforced by the handler rather than WP REST auth.
	 *
	 * @return void
	 */

	public function register_rest_routes() {
		// ADMISSION INVARIANT: Public JSON must be bounded before Core decodes it;
		// multipart attachments retain their separate upload policy.
		WPHAVE_REST_Body_Budget::protect(
			'POST',
			'~^/wphave/v1/form-submit$~D',
			self::MAX_REST_JSON_BYTES,
		);
		register_rest_route('wphave/v1', '/form-submit', [
			'methods' => 'POST',
			'callback' => [$this, 'handle_rest_submission'],
			'permission_callback' => '__return_true',
		]);

		register_rest_route('wphave/v1', '/form-nonce', [
			'methods' => 'GET',
			'callback' => [$this, 'create_form_nonce'],
			'permission_callback' => '__return_true',
			'args' => [
				'formId' => [
					'required' => true,
					'type' => 'string',
					'sanitize_callback' => [WPHAVE_Form_Identity::class, 'normalize'],
					'validate_callback' => [$this, 'validate_form_id'],
				],
				'postId' => [
					'required' => true,
					'type' => 'integer',
					'minimum' => 1,
					'sanitize_callback' => static fn($value): int => WPHAVE_Form_Identity::request_post_id($value),
				],
				'sourcePostId' => [
					'required' => false,
					'type' => 'integer',
					'minimum' => 1,
					'sanitize_callback' => static fn($value): int => WPHAVE_Form_Identity::request_post_id($value),
				],
			],
		]);
	}

	/**
	 * Create a nonce scoped to one public form.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @return WP_REST_Response|WP_Error Nonce response or validation error.
	 */

	public function create_form_nonce(WP_REST_Request $request) {
		// PROOF-BUDGET INVARIANT: A cross-site browser can send a public GET
		// without reading the nonce. Fetch Metadata and an explicit Origin
		// must both pass before charging the visitor's issuance bucket.
		if (!self::allows_submission_origin()) {
			return new WP_Error(
				'wphave_form_nonce_cross_site',
				__('The form is unavailable.', 'wphave'),
				['status' => 403],
			);
		}
		$form_id = WPHAVE_Form_Identity::normalize($request->get_param('formId'));
		$context_post_id = WPHAVE_Form_Identity::request_post_id($request->get_param('postId'));
		$source_parameter = $request->get_param('sourcePostId');
		$source_post_id = $source_parameter === null
			? $context_post_id
			: WPHAVE_Form_Identity::request_post_id($source_parameter);

		if (!$form_id) {
			return new WP_Error(
				'wphave_form_nonce_missing_form_id',
				__('Missing form id.', 'wphave'),
				['status' => 400],
			);
		}
		if (!$context_post_id || !$source_post_id) {
			return new WP_Error(
				'wphave_form_nonce_invalid_context',
				__('The form context is not publicly available.', 'wphave'),
				['status' => 404],
			);
		}

		// AVAILABILITY INVARIANT: Public proof issuance has its own request budget
		// before a caller-controlled document identity can trigger block parsing.
		// Submission throttling cannot protect this separate, earlier endpoint.
		if (
			WPHAVE_Form_Spam_Policy::is_nonce_rate_limited(
				WPHAVE_Client_IP::resolve(),
				(string) ($_SERVER['HTTP_USER_AGENT'] ?? ''),
			)
		) {
			return new WP_Error(
				'wphave_form_nonce_rate_limited',
				__('Too many form security-token requests. Please try again later.', 'wphave'),
				['status' => 429],
			);
		}

		if (!$this->is_valid_public_nonce_context($context_post_id, $source_post_id, $form_id)) {
			return new WP_Error(
				'wphave_form_nonce_invalid_context',
				__('The form context is not publicly available.', 'wphave'),
				['status' => 404],
			);
		}

		$response = rest_ensure_response([
			'nonce' => wp_create_nonce(
				self::nonce_action($form_id, $context_post_id, $source_post_id),
			),
		]);

		// SECURITY INVARIANT: A public form nonce is bound to one rendered form
		// context and a short time window. Shared caches must never replay it into
		// another visitor, document revision or expired submission workflow.
		$response->header('Cache-Control', 'private, no-store, max-age=0');
		$response->header('Pragma', 'no-cache');

		return $response;
	}

	/** Build one nonce action bound to the form, public document and verified owner. */
	public static function nonce_action(
		string $form_id,
		int $context_post_id,
		int $source_post_id,
	): string {
		$form_id = WPHAVE_Form_Identity::normalize($form_id);

		return implode('|', [
			'wphave_form_submit',
			$form_id,
			absint($context_post_id),
			absint($source_post_id),
		]);
	}

	/**
	 * Validate a REST form identifier.
	 *
	 * @param mixed $value Submitted form identifier.
	 * @return bool Whether the identifier is valid.
	 */

	public function validate_form_id($value) {
		return '' !== WPHAVE_Form_Identity::normalize($value);
	}

	/**
	 * AUTHORISATION INVARIANT: token issuance, classic POST and REST resolve the
	 * same currently rendered public layout and complete form/loader path. A
	 * previously issued nonce cannot restore revoked access; stored conditions
	 * apply even without an active Pro license.
	 */
	private function is_valid_public_nonce_context(
		int $context_post_id,
		int $source_post_id,
		string $form_id,
	): bool {
		return WPHAVE_Form_Public_Context::allows(
			$context_post_id,
			$source_post_id,
			$form_id,
		);
	}
}

/*
 *  - Classic POST handler via 'wp' action
 *  - REST API endpoint for async submissions
 *
 *  - 'wp' hook ensures post context is available
 *  - REST endpoint enables async submissions
 */

$handler = WPHAVE_Form_Submission_Handler::instance();
add_action('wp', [$handler, 'handle']); // <-- "init" action is to early to get the post_id !
add_action('rest_api_init', [$handler, 'register_rest_routes']);
add_filter('wp_headers', [$handler, 'protect_result_url_headers']);
