<?php

/**
 * Return the headers required for HTML form emails.
 *
 *  - Define HTML content type
 *  - Define From header
 *  - Optionally define Reply-To header
 *
 *  - Sanitizes header values
 *  - Prevents malformed email addresses
 *  - Strips line breaks from header strings (header injection protection)
 *
 *  - Returns a plain numeric array of header strings for wp_mail()
 *  - Caller must provide already trusted / sanitized values where possible
 */

 if ( ! function_exists( 'wphave_email_template_headers' ) ) :

    function wphave_email_template_headers( $args = [] ) {
		// SECURITY INVARIANT: Mail header values are single-line canonical identities.
		// Caller-controlled CR/LF bytes and malformed addresses never reach wp_mail(),
		// so template customization cannot create additional headers.

        $from_name = ! empty( $args['from_name'] )
            ? $args['from_name']
            : wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );

        $from_email = ! empty( $args['from_email'] )
            ? $args['from_email']
            : get_option( 'admin_email' );

        $reply_to_email = ! empty( $args['reply_to_email'] )
            ? $args['reply_to_email']
            : '';

        /*
         *  - remove CR/LF from header values
         */

        $from_name = sanitize_text_field( str_replace( [ "\r", "\n" ], '', (string) $from_name ) );

        $from_email = sanitize_email(
            str_replace( [ "\r", "\n" ], '', (string) $from_email )
        );

        $reply_to_email = sanitize_email(
            str_replace( [ "\r", "\n" ], '', (string) $reply_to_email )
        );

        /**
         * Builds full HTML email markup.
         *
         * Responsibilities:
         * - Render optional logo / branding
         * - Render title / description / content
         * - Render footer with site context
         *
         * SECURITY:
         * - Escapes all plain text values
         * - Allows limited HTML only where explicitly intended
         * - Uses safe URL escaping for images and site URLs
         *
         * IMPORTANT:
         * - 'description', 'content' and 'footer_content' may contain limited HTML
         * - Use trusted / sanitized inputs before passing user-generated content
         */

        if( ! $from_email || ! is_email( $from_email ) ) {
            $from_email = sanitize_email( get_option( 'admin_email' ) );
        }

        if( ! $from_email || ! is_email( $from_email ) ) {
            return [
                'Content-Type: text/html; charset=UTF-8',
            ];
        }

        /**
         * Builds full HTML email markup.
         *
         * Responsibilities:
         * - Render optional logo / branding
         * - Render title / description / content
         * - Render footer with site context
         *
         * SECURITY:
         * - Escapes all plain text values
         * - Allows limited HTML only where explicitly intended
         * - Uses safe URL escaping for images and site URLs
         *
         * IMPORTANT:
         * - 'description', 'content' and 'footer_content' may contain limited HTML
         * - Use trusted / sanitized inputs before passing user-generated content
         */

        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $from_name . ' <' . $from_email . '>',
        ];

        if( $reply_to_email && is_email( $reply_to_email ) ) {
            $headers[] = 'Reply-To: ' . $reply_to_email;
        }

        return $headers;
    }

endif;


/**
 * Build the HTML form-email template.
 *
 *  - Render optional logo / branding
 *  - Render title / description / content
 *  - Render footer with site context
 *
 *  - Escapes all plain text values
 *  - Allows limited HTML only where explicitly intended
 *  - Uses safe URL escaping for images and site URLs
 *
 *  - 'description', 'content' and 'footer_content' may contain limited HTML
 *  - Use trusted / sanitized inputs before passing user-generated content
 */

if ( ! function_exists( 'wphave_build_email_template' ) ) :

    function wphave_build_email_template( $args = [] ) {

        $defaults = [
            'title' => '',
            'description' => '',
            'content' => '',
            'footer_content' => ''
        ];

        $args = wp_parse_args( $args, $defaults );

        $site_url = home_url();
        $site_name = wp_specialchars_decode( get_bloginfo('name'), ENT_QUOTES );

        /*
         *  - title
         *
         *  - description
         *  - content
         *  - footer_content
         */

        $title = sanitize_text_field( $args['title'] ?? $site_name );
        $content = $args['content'] ?? '';
        $description = $args['description'] ?? '';
        $footer_content = $args['footer_content'] ?? '';

        $brand = wphave_data_get( 'site_settings', 'brand' );
        $brand = is_array( $brand ) ? $brand : [];

        $logo_id = $brand['logo'] ?? '';
        $slogan   = isset( $brand['slogan'] ) ? sanitize_text_field( $brand['slogan'] ) : '';
        $logo_url = wphave_image_src( $logo_id, 'medium' );

        $now = current_time('timestamp');
        $current_year = date_i18n( 'Y', $now );
        $footer_text = sprintf(/* translators: %s: contextual value. */
        __('Sent from %s', 'wphave'), $site_url);

        ob_start(); ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo esc_html( $title ); ?></title>
</head>

<body style="margin: 0; padding: 0; background-color: #f2f4f6; <?php echo esc_attr( wphave_email_template_font_style() ); ?>">
    <?php

    /*
     *  - Render as plain text only
     */

    if( $description ) : ?>
        <div style="display: none; font-size: 1px; color:#fff; line-height: 1px; max-height: 0; max-width: 0; opacity: 0; overflow:hidden;">
            <?php echo esc_html( wp_strip_all_tags( (string) $description ) ) . str_repeat( '&nbsp;&zwnj;', 10 ); ?>
        </div>
    <?php endif; ?>
    <table width="100%" cellpadding="0" cellspacing="0" style="padding: 20px; background: #f2f4f6;" role="presentation">
        <?php if( $logo_url || $site_name ) { ?>
            <tr>
                <td align="center" style="padding: 20px; text-align: center; <?php echo esc_attr( wphave_email_template_font_style() ); ?>">
                    <?php if( $logo_url ) { ?>
                        <img src="<?php echo esc_url( $logo_url ); ?>" width="180" alt="<?php echo esc_attr( $site_name ); ?>" style="display: inline-block; border: 0;">
                    <?php } else { ?>
                        <h2 style="<?php echo esc_attr( wphave_email_template_font_style( '18px' ) ); ?>">
                            <?php echo esc_html( $site_name ); ?>
                        </h2>
                    <?php } ?>
                </td>
            </tr>
        <?php }

        // Content ?>
        <tr>
            <td align="center">
                <?php
                // Container
                // To be responsive, use: "max-width: 600px; width: 100%;" on <table> ?>
                <table width="600" align="center" cellpadding="0" cellspacing="0" style="margin: 0 auto; max-width: 600px; width: 100%; background: #ffffff; border-radius: 6px">

                    <?php if( $title || $description ) { ?>
                        <tr>
                            <td style="padding: 20px; text-align: left;">
                                <?php if( $title ) { ?>
                                    <h1 style="<?php echo esc_attr( wphave_email_template_font_style( '22px' ) ); ?>">
                                        <?php echo esc_html( $title ); ?>
                                    </h1>
                                <?php }

                                if( $description ) { ?>
                                    <p style="<?php echo esc_attr( wphave_email_template_font_style() ); ?>">
                                        <?php echo wp_kses_post( $description ); ?>
                                    </p>
                                <?php } ?>
                            </td>
                        </tr>
                        <?php if( $content ) {
                            echo wphave_email_template_divider();
                        }
                    }

                    if( $content ) { ?>
                        <tr>
                            <td style="padding: 20px; text-align: left; <?php echo esc_attr( wphave_email_template_font_style() ); ?>">
                                <?php echo wp_kses_post( $content ); ?>
                            </td>
                        </tr>
                    <?php } ?>

                </table>

            </td>
        </tr>
        <?php
        // Footer
        ?>
        <tr>
            <td align="center" style="padding: 20px; text-align: center; <?php echo esc_attr( wphave_email_template_font_style('12px', '20px', '#919293') ); ?>">
                <?php echo wp_kses_post( $footer_content ); ?>
                <p style="padding: 0; <?php echo esc_attr( wphave_email_template_font_style('12px', '20px', '#919293') ); ?>">
                    &copy; <?php echo esc_html( $site_name ); ?>
                    <?php
                        if( $current_year ) {
                            echo ' - ' . esc_html( $current_year );
                        }
                    ?>
                    <?php
                        if( $slogan ) {
                            echo ' - ' . esc_html( $slogan );
                        }
                    ?>
                    <br>
                    <?php echo esc_html( $footer_text ); ?>
                </p>
            </td>
        </tr>
    </table>

</body>
</html>
        <?php
        return ob_get_clean();
    }

endif;


/**
 * Build a sanitized inline font style.
 *
 *  - Sanitizes all CSS scalar inputs
 *
 *  - Intended for internal use only
 *  - Returns a CSS declaration string, not escaped HTML
 */

if ( ! function_exists( 'wphave_email_template_font_style' ) ) :

    function wphave_email_template_font_style( $size = '14px', $line_height = '24px', $color = '#242424' ) {

        $size = preg_match( '/^[0-9.]+(px|em|rem|%)$/', (string) $size ) ? $size : '14px';
        $line_height = preg_match( '/^[0-9.]+(px|em|rem|%)$/', (string) $line_height ) ? $line_height : '24px';
        $color = preg_match( '/^#[0-9a-fA-F]{3,8}$/', (string) $color ) ? $color : '#242424';

        return "font-size: {$size}; font-weight: 400; font-family: Helvetica, Arial, sans-serif; line-height: {$line_height}; color: {$color};";

    }

endif;


/**
 * Build a sanitized email divider.
 *
 *  - Restricts color input to safe hex values
 */


if ( ! function_exists( 'wphave_email_template_divider' ) ) :

    function wphave_email_template_divider( $color = '#f0f0f0' ) {

        $color = preg_match( '/^#[0-9a-fA-F]{3,8}$/', (string) $color ) ? $color : '#f0f0f0';

        return '
<tr>
    <td style="padding: 0 20px;">
        <table width="100%" cellpadding="0" cellspacing="0">
            <tr>
                <td style="border-top: 1px solid ' . $color . '; font-size: 0; line-height: 0;">&nbsp;</td>
            </tr>
        </table>
    </td>
</tr>
        ';

    }

endif;
