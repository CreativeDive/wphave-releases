<?php

/**
 * Resolve only form placements that the WPHAVE public renderer can expose.
 */
final class WPHAVE_Form_Public_Context {
	private const MAX_DEPTH = 32;

	public static function source(int $context_post_id, string $form_id): int {
		// PUBLIC-CONTEXT INVARIANT: A client-provided page ID is never proof that
		// its stored form is reachable in a public document.
		$context = get_post($context_post_id);
		if (
			!$context ||
			'publish' !== $context->post_status ||
			!is_post_publicly_viewable($context) ||
			post_password_required($context)
		) {
			return 0;
		}

		$seen = [];
		// ACCESS-MODE INVARIANT: REST bypasses frontend redirects. Apply the
		// same document replacement rules before issuing or accepting proof.
		if (
			class_exists('WPHAVE_Maintenance_Mode') &&
			WPHAVE_Maintenance_Mode::is_active()
		) {
			return 0;
		}
		if (
			class_exists('WPHAVE_Coming_Soon') &&
			WPHAVE_Coming_Soon::is_active() &&
			!self::is_coming_soon_context($context_post_id)
		) {
			return 0;
		}
		if (self::is_coming_soon_context($context_post_id)) {
			// SOURCE INVARIANT: Coming Soon substitutes the ordinary page, Header
			// and Footer; only the active published add-on owns this path.
			$owner = absint(WPHAVE_Coming_Soon::get_post_id());
			$add_on = get_post($owner);
			if (!$add_on || 'publish' !== $add_on->post_status) {
				return 0;
			}

			return self::unique_source(self::find_in_blocks(
				WPHAVE_Form_Schema_Parser::parse_source_blocks($add_on->post_content),
				$owner,
				$form_id,
				0,
				$seen,
			));
		}

		$layout = self::assigned_custom_template($context_post_id);
		$content = $layout ?: $context;
		// RENDER-PARITY INVARIANT: Only the renderer's first content slot may
		// expose the page body, even if that first slot is hidden.
		$content_slot_seen = false;
		$sources = self::find_in_blocks(
			WPHAVE_Form_Schema_Parser::parse_source_blocks($content->post_content),
			(int) $content->ID,
			$form_id,
			0,
			$seen,
			$layout ? $context : null,
			$content_slot_seen,
		);
		foreach (['header', 'footer'] as $slot) {
			if (
				$layout &&
				self::slot_is_hidden((int) $layout->ID, $slot)
			) {
				continue;
			}

			$sources = array_merge($sources, self::find_in_slot($slot, $form_id, 0, $seen));
		}

		return self::unique_source($sources);
	}

	private static function unique_source(array $sources): int {
		$sources = array_values(array_unique(array_filter($sources)));

		// SOURCE-IDENTITY INVARIANT: One form ID must resolve to exactly one
		// owner in this document; ambiguity cannot route visitor data to mail.
		return count($sources) === 1 ? (int) $sources[0] : 0;
	}

	public static function allows(int $context_post_id, int $source_post_id, string $form_id): bool {
		return $source_post_id > 0 &&
			self::source($context_post_id, $form_id) === $source_post_id;
	}

	private static function is_coming_soon_context(int $context_post_id): bool {
		return class_exists('WPHAVE_Coming_Soon') &&
			WPHAVE_Coming_Soon::is_active() &&
			'page' === get_option('show_on_front') &&
			$context_post_id === absint(get_option('page_on_front'));
	}

	private static function assigned_custom_template(int $context_post_id): ?WP_Post {
		if (!class_exists('WPHAVE_Templates')) {
			return null;
		}

		$id = absint(get_post_meta($context_post_id, WPHAVE_Templates::META_CUSTOM_TEMPLATE, true));
		$direct_assignment = $id > 0;
		if (!$id) {
			$context = get_post($context_post_id);
			$template_context = self::template_context($context);
			$selected = $template_context
				? WPHAVE_Templates::custom_template($template_context)
				: false;
			$id = is_array($selected) ? absint($selected['post_id'] ?? 0) : 0;
		}

		$template = get_post($id);
		if (
			!$template ||
			WPHAVE_Templates::POST_TYPE !== $template->post_type ||
			'publish' !== $template->post_status ||
			($direct_assignment && 'custom' !== get_post_meta($id, WPHAVE_Templates::META_TEMPLATE_ID, true))
		) {
			return null;
		}

		return $template;
	}

	private static function template_context(?WP_Post $context): string {
		if (!$context) {
			return '';
		}

		if ($context->post_type === 'page') {
			if (
				'page' === get_option('show_on_front') &&
				(int) $context->ID === absint(get_option('page_on_front'))
			) {
				return 'homepage';
			}
			if ((int) $context->ID === absint(get_option('wp_page_for_privacy_policy'))) {
				return 'privacy_policy';
			}

			return 'post_type_page';
		}

		return 'post_type_' . sanitize_key($context->post_type);
	}

	private static function slot_is_hidden(int $template_id, string $slot): bool {
		$visibility = get_post_meta(
			$template_id,
			WPHAVE_Templates::META_LAYOUT_VISIBILITY,
			true,
		);

		return is_array($visibility) && ($visibility[$slot] ?? '') === 'hidden';
	}

	private static function find_in_slot(
		string $slot,
		string $form_id,
		int $depth,
		array &$seen,
	): array {
		$assignments = wphave_data_get('template_parts', '', []);
		$id = is_array($assignments) ? absint($assignments[$slot] ?? 0) : 0;

		return self::find_in_part($id, $form_id, $depth, $seen, $slot);
	}

	private static function find_in_part(
		int $id,
		string $form_id,
		int $depth,
		array &$seen,
		string $slot = '',
	): array {
		// PART-REFERENCE INVARIANT: Publication alone grants no authority.
		// The caller must reach this part through a bounded layout reference.
		if (
			!class_exists('WPHAVE_Template_Parts') ||
			!$id ||
			$depth > self::MAX_DEPTH ||
			isset($seen[$id])
		) {
			return [];
		}

		$part = get_post($id);
		if (
			!$part ||
			WPHAVE_Template_Parts::POST_TYPE !== $part->post_type ||
			'publish' !== $part->post_status ||
			($slot && $slot !== get_post_meta($id, WPHAVE_Template_Parts::META_PART_TYPE, true))
		) {
			return [];
		}

		$seen[$id] = true;
		return self::find_in_blocks(
			WPHAVE_Form_Schema_Parser::parse_source_blocks($part->post_content),
			$id,
			$form_id,
			$depth + 1,
			$seen,
		);
	}

	private static function find_in_blocks(
		array $blocks,
		int $owner_id,
		string $form_id,
		int $depth,
		array &$seen,
		?WP_Post $content_post = null,
		?bool &$content_slot_seen = null,
	): array {
		if ($depth > self::MAX_DEPTH) {
			return [];
		}

		$sources = [];
		foreach ($blocks as $block) {
			$name = $block['blockName'] ?? '';
			$use_content_slot = false;
			if ($name === 'wphave/content' && $content_post && !$content_slot_seen) {
				$content_slot_seen = true;
				$use_content_slot = true;
			}
			if (!WPHAVE_Block_Projection::allows($block, false)) {
				// VISIBILITY INVARIANT: A hidden ancestor cannot expose children.
				// Still consume its content slot: renderer replaces the first
				// serialized slot, regardless of visitor visibility.
				if (
					$content_post &&
					!$content_slot_seen &&
					self::contains_content_slot($block['innerBlocks'] ?? [])
				) {
					$content_slot_seen = true;
				}
				continue;
			}

			$attrs = $block['attrs'] ?? [];
			if ($name === 'wphave/form' && ($attrs['formId'] ?? '') === $form_id) {
				$sources[] = $owner_id;
			}

			if ($name === 'wphave/form-loader') {
				$id = absint($attrs['formId'] ?? 0);
				$post = get_post($id);
				if (
					$post &&
					WPHAVE_Form_Manager::POST_TYPE === $post->post_type &&
					'publish' === $post->post_status &&
					!post_password_required($post) &&
					WPHAVE_Form_Schema_Parser::find_form_block(
						WPHAVE_Form_Schema_Parser::parse_source_blocks($post->post_content),
						$form_id,
					)
				) {
					$sources[] = $id;
				}
			}

			if ($use_content_slot) {
				$sources = array_merge($sources, self::find_in_blocks(
					WPHAVE_Form_Schema_Parser::parse_source_blocks($content_post->post_content),
					(int) $content_post->ID,
					$form_id,
					$depth + 1,
					$seen,
				));
			}

			if ($name === 'wphave/template-part') {
				$id = absint($attrs['templatePartId'] ?? 0);
				$slot = (string) ($attrs['slot'] ?? '');
				$part_sources = $id
					? self::find_in_part($id, $form_id, $depth + 1, $seen)
					: (in_array($slot, ['header', 'footer'], true)
						? self::find_in_slot($slot, $form_id, $depth + 1, $seen)
						: []);
				$sources = array_merge($sources, $part_sources);
			}

			if (!empty($block['innerBlocks']) && is_array($block['innerBlocks'])) {
				$sources = array_merge($sources, self::find_in_blocks(
					$block['innerBlocks'],
					$owner_id,
					$form_id,
					$depth + 1,
					$seen,
					$content_post,
					$content_slot_seen,
				));
			}
		}

		return $sources;
	}

	private static function contains_content_slot(array $blocks, int $depth = 0): bool {
		// DEPTH INVARIANT: An overdeep hidden subtree cannot make a later
		// content slot eligible by exhausting the scanner.
		if ($depth > self::MAX_DEPTH) {
			return true;
		}

		foreach ($blocks as $block) {
			if (($block['blockName'] ?? '') === 'wphave/content') {
				return true;
			}
			if (
				!empty($block['innerBlocks']) &&
				self::contains_content_slot($block['innerBlocks'], $depth + 1)
			) {
				return true;
			}
		}

		return false;
	}
}
