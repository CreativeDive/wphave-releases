<?php

/**
 * Resolve only form placements that the WPHAVE public renderer can expose.
 */
final class WPHAVE_Form_Public_Context {
	private const MAX_DEPTH = 32;

	public static function source(int $context_post_id, string $form_id): int {
		// PUBLIC-CONTEXT INVARIANT: A client-provided page ID is never proof that
		// its stored form is reachable in a public document.
		$context = get_post($context_post_id);
		if (
			!$context ||
			'publish' !== $context->post_status ||
			!is_post_publicly_viewable($context) ||
			post_password_required($context)
		) {
			return 0;
		}

		$seen = [];
		$complete = true;
		// ACCESS-MODE INVARIANT: REST bypasses frontend redirects. Apply the
		// same document replacement rules before issuing or accepting proof.
		if (
			class_exists('WPHAVE_Maintenance_Mode') &&
			WPHAVE_Maintenance_Mode::is_active()
		) {
			return 0;
		}
		if (
			class_exists('WPHAVE_Coming_Soon') &&
			WPHAVE_Coming_Soon::is_active() &&
			!self::is_coming_soon_context($context_post_id)
		) {
			return 0;
		}
		if (self::is_coming_soon_context($context_post_id)) {
			// SOURCE INVARIANT: Coming Soon substitutes the ordinary page, Header
			// and Footer; only the active published add-on owns this path.
			$owner = absint(WPHAVE_Coming_Soon::get_post_id());
			// PUBLIC-OWNER INVARIANT: A missing add-on ID cannot fall through
			// get_post(0) to the global WordPress post.
			$add_on = $owner > 0 ? get_post($owner) : null;
			if (!$add_on || 'publish' !== $add_on->post_status) {
				return 0;
			}

			$sources = self::find_in_blocks(
				WPHAVE_Form_Schema_Parser::parse_source_blocks($add_on->post_content),
				$owner,
				$form_id,
				0,
				$seen,
				$complete,
			);
			return $complete ? self::unique_source($sources) : 0;
		}

		$layout = self::assigned_custom_template($context_post_id);
		$content = $layout ?: $context;
		// RENDER-PARITY INVARIANT: Only the renderer's first content slot may
		// expose the page body, even if that first slot is hidden.
		$content_slot_seen = false;
		$sources = self::find_in_blocks(
			WPHAVE_Form_Schema_Parser::parse_source_blocks($content->post_content),
			(int) $content->ID,
			$form_id,
			0,
			$seen,
			$complete,
			$layout ? $context : null,
			$content_slot_seen,
		);
		foreach (['header', 'footer'] as $slot) {
			if (
				$layout &&
				self::slot_is_hidden((int) $layout->ID, $slot)
			) {
				continue;
			}

			$sources = array_merge($sources, self::find_in_slot($slot, $form_id, 0, $seen, $complete));
		}

		// COMPLETENESS INVARIANT: A visible branch beyond the traversal bound
		// may contain a second form. An incomplete scan cannot authorize one.
		return $complete ? self::unique_source($sources) : 0;
	}

	private static function unique_source(array $sources): int {
		$sources = array_values(array_filter($sources));

		// SOURCE-IDENTITY INVARIANT: One form ID must have exactly one visible
		// placement, even when two placements share an owner post. Otherwise
		// the renderer can show a second schema while validation selects the first.
		return count($sources) === 1 ? (int) $sources[0] : 0;
	}

	public static function allows(int $context_post_id, int $source_post_id, string $form_id): bool {
		return $source_post_id > 0 &&
			self::source($context_post_id, $form_id) === $source_post_id;
	}

	private static function is_coming_soon_context(int $context_post_id): bool {
		return class_exists('WPHAVE_Coming_Soon') &&
			WPHAVE_Coming_Soon::is_active() &&
			'page' === get_option('show_on_front') &&
			$context_post_id === absint(get_option('page_on_front'));
	}

	private static function assigned_custom_template(int $context_post_id): ?WP_Post {
		if (!class_exists('WPHAVE_Templates')) {
			return null;
		}

		// RENDER-PARITY INVARIANT: Only the exact assigned template may grant
		// a public form; use the renderer's assignment identity contract.
		$assignment = get_post_meta($context_post_id, WPHAVE_Templates::META_CUSTOM_TEMPLATE, true);
		$id = WPHAVE_Templates::assigned_post_id($assignment);
		if (!$id && !in_array($assignment, ['', null, 0, '0'], true)) {
			// A malformed explicit assignment must not fall through to a
			// different context template and authorize its embedded form.
			return null;
		}
		$direct_assignment = $id > 0;
		if (!$id) {
			$context = get_post($context_post_id);
			$template_context = self::template_context($context);
			$selected = $template_context
				? WPHAVE_Templates::custom_template($template_context)
				: false;
			// CATALOG IDENTITY INVARIANT: A malformed catalog reference must
			// not authorize a template that the renderer cannot select.
			$id = is_array($selected)
				? WPHAVE_Templates::assigned_post_id($selected['post_id'] ?? null)
				: 0;
		}

		// TEMPLATE-ID INVARIANT: An absent assignment cannot inherit a
		// global template through WordPress' get_post(0) fallback.
		$template = $id > 0 ? get_post($id) : null;
		if (
			!$template ||
			WPHAVE_Templates::POST_TYPE !== $template->post_type ||
			'publish' !== $template->post_status ||
			post_password_required($template) ||
			($direct_assignment && 'custom' !== get_post_meta($id, WPHAVE_Templates::META_TEMPLATE_ID, true))
		) {
			return null;
		}

		return $template;
	}

	private static function template_context(?WP_Post $context): string {
		if (!$context) {
			return '';
		}

		if ($context->post_type === 'page') {
			if (
				'page' === get_option('show_on_front') &&
				(int) $context->ID === absint(get_option('page_on_front'))
			) {
				return 'homepage';
			}
			if ((int) $context->ID === absint(get_option('wp_page_for_privacy_policy'))) {
				return 'privacy_policy';
			}

			return 'post_type_page';
		}

		return 'post_type_' . sanitize_key($context->post_type);
	}

	private static function slot_is_hidden(int $template_id, string $slot): bool {
		$visibility = get_post_meta(
			$template_id,
			WPHAVE_Templates::META_LAYOUT_VISIBILITY,
			true,
		);

		return is_array($visibility) && ($visibility[$slot] ?? '') === 'hidden';
	}

	private static function find_in_slot(
		string $slot,
		string $form_id,
		int $depth,
		array &$seen,
		bool &$complete,
	): array {
		$assignments = wphave_data_get('template_parts', '', []);
		$id = is_array($assignments) && class_exists('WPHAVE_Template_Parts')
			? WPHAVE_Template_Parts::assignment_post_id($assignments[$slot] ?? null)
			: 0;

		return self::find_in_part($id, $form_id, $depth, $seen, $complete, $slot);
	}

	private static function find_in_part(
		int $id,
		string $form_id,
		int $depth,
		array &$seen,
		bool &$complete,
		string $slot = '',
	): array {
		// PART-REFERENCE INVARIANT: Publication alone grants no authority.
		// The caller must reach this part through a bounded layout reference.
		if ($depth > self::MAX_DEPTH) {
			$complete = false;
			return [];
		}
		if (
			!class_exists('WPHAVE_Template_Parts') ||
			!$id ||
			isset($seen[$id])
		) {
			return [];
		}

		$part = get_post($id);
		if (
			!$part ||
			WPHAVE_Template_Parts::POST_TYPE !== $part->post_type ||
			'publish' !== $part->post_status ||
			post_password_required($part) ||
			($slot && $slot !== get_post_meta($id, WPHAVE_Template_Parts::META_PART_TYPE, true))
		) {
			return [];
		}

		$seen[$id] = true;
		$sources = self::find_in_blocks(
			WPHAVE_Form_Schema_Parser::parse_source_blocks($part->post_content),
			$id,
			$form_id,
			$depth + 1,
			$seen,
			$complete,
		);
		// PLACEMENT INVARIANT: A part may render at multiple sibling locations.
		// Track only the active reference path, so each placement counts while
		// recursive part cycles remain bounded.
		unset($seen[$id]);
		return $sources;
	}

	private static function find_in_blocks(
		array $blocks,
		int $owner_id,
		string $form_id,
		int $depth,
		array &$seen,
		bool &$complete,
		?WP_Post $content_post = null,
		?bool &$content_slot_seen = null,
	): array {
		if ($depth > self::MAX_DEPTH) {
			$complete = false;
			return [];
		}

		$sources = [];
		foreach ($blocks as $block) {
			$name = $block['blockName'] ?? '';
			$use_content_slot = false;
			if ($name === 'wphave/content' && $content_post && !$content_slot_seen) {
				$content_slot_seen = true;
				$use_content_slot = true;
			}
			if (!WPHAVE_Block_Projection::allows($block, false)) {
				// VISIBILITY INVARIANT: A hidden ancestor cannot expose children.
				// Still consume its content slot: renderer replaces the first
				// serialized slot, regardless of visitor visibility.
				if (
					$content_post &&
					!$content_slot_seen &&
					self::contains_content_slot($block['innerBlocks'] ?? [])
				) {
					$content_slot_seen = true;
				}
				continue;
			}

			// STORED-ATTRIBUTE INVARIANT: Raw parsed block attributes need not
			// have passed the registered block schema. Only an attribute map may
			// select a public form, Loader or Template Part source.
			$attrs = is_array($block['attrs'] ?? null) ? $block['attrs'] : [];
			if ($name === 'wphave/form' && ($attrs['formId'] ?? '') === $form_id) {
				$sources[] = $owner_id;
			}

			if ($name === 'wphave/form-loader') {
				$id = WPHAVE_Form_Identity::source_post_id($attrs['formId'] ?? null);
				// LOADER IDENTITY INVARIANT: get_post(0) may resolve the global
				// post. An invalid Loader reference must never inherit that Form
				// document as public submission authority.
				$post = $id > 0 ? get_post($id) : null;
				if (
					$post &&
					WPHAVE_Form_Manager::POST_TYPE === $post->post_type &&
					'publish' === $post->post_status &&
					!post_password_required($post) &&
					WPHAVE_Form_Schema_Parser::find_unique_form_block(
						WPHAVE_Form_Schema_Parser::parse_source_blocks($post->post_content),
						$form_id,
					)
				) {
					$sources[] = $id;
				}
				// RENDER-PATH INVARIANT: The loader outputs only its referenced
				// Form document. Persisted inner blocks are not rendered and cannot
				// authorize an otherwise invisible form submission or nonce.
				continue;
			}

			if ($use_content_slot) {
				$sources = array_merge($sources, self::find_in_blocks(
					WPHAVE_Form_Schema_Parser::parse_source_blocks($content_post->post_content),
					(int) $content_post->ID,
					$form_id,
					$depth + 1,
					$seen,
					$complete,
				));
			}
			if ($name === 'wphave/content' && $content_post) {
				// RENDER-PATH INVARIANT: The render engine replaces the first
				// Content block as a whole. Its serialized children, and those
				// of later inert Content blocks, cannot authorize a form.
				continue;
			}

			if ($name === 'wphave/template-part') {
				$id = class_exists('WPHAVE_Template_Parts')
					? WPHAVE_Template_Parts::reference_post_id($attrs['templatePartId'] ?? null)
					: 0;
				// SLOT IDENTITY INVARIANT: The renderer recognizes only literal
				// strings. Coercing a stored array emits a public PHP warning and
				// must never select a global Part assignment.
				$slot = is_string($attrs['slot'] ?? null) ? $attrs['slot'] : '';
				$part_sources = $id
					? self::find_in_part($id, $form_id, $depth + 1, $seen, $complete)
					: (in_array($slot, ['header', 'footer'], true)
						? self::find_in_slot($slot, $form_id, $depth + 1, $seen, $complete)
						: []);
				$sources = array_merge($sources, $part_sources);
				// RENDER-PATH INVARIANT: A Template Part renders its selected
				// document, not serialized children of the reference block.
				continue;
			}

			if (!empty($block['innerBlocks']) && is_array($block['innerBlocks'])) {
				$sources = array_merge($sources, self::find_in_blocks(
					$block['innerBlocks'],
					$owner_id,
					$form_id,
					$depth + 1,
					$seen,
					$complete,
					$content_post,
					$content_slot_seen,
				));
			}
		}

		return $sources;
	}

	private static function contains_content_slot(array $blocks, int $depth = 0): bool {
		// DEPTH INVARIANT: An overdeep hidden subtree cannot make a later
		// content slot eligible by exhausting the scanner.
		if ($depth > self::MAX_DEPTH) {
			return true;
		}

		foreach ($blocks as $block) {
			if (($block['blockName'] ?? '') === 'wphave/content') {
				return true;
			}
			if (
				!empty($block['innerBlocks']) &&
				self::contains_content_slot($block['innerBlocks'], $depth + 1)
			) {
				return true;
			}
		}

		return false;
	}
}
