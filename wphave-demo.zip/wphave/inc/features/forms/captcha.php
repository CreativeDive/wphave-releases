<?php

/** Short-lived, form-bound visual and spoken challenge for public Forms. */
final class WPHAVE_Form_Captcha {
	private const ALPHABET = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
	private const LENGTH = 5;
	private const TTL = 600;
	// MEDIA INVARIANT: A damaged packaged clip cannot trigger an unbounded read.
	private const MAX_CLIP_BYTES = 262144;

	/** Register the public refresh endpoint and token-bound media delivery. */
	public static function init(): void {
		add_action('rest_api_init', [__CLASS__, 'register_routes']);
		add_action('template_redirect', [__CLASS__, 'serve_media'], 0);
	}

	/** Generate one unguessable handle; the answer never enters HTML or REST JSON. */
	public static function issue(string $form_id, int $source_post_id, string $field): ?array {
		// ISSUANCE INVARIANT: Both challenge formats must be available before a
		// bearer token is stored. An incomplete challenge cannot authorize mail.
		if (
			!$form_id ||
			WPHAVE_Form_Identity::normalize($form_id) !== $form_id ||
			!$source_post_id ||
			$field === '_wphave_invalid_captcha' ||
			str_starts_with($field, '_wphave_') ||
			str_starts_with($field, '_wp_') ||
			$field === '_wpnonce' ||
			!preg_match('/^[a-z0-9_-]{3,80}$/D', $field) ||
			!function_exists('imagecreatetruecolor') ||
			!function_exists('imagepng')
		) {
			return null;
		}

		$answer = '';
		for ($index = 0; $index < self::LENGTH; $index++) {
			$answer .= self::ALPHABET[random_int(0, strlen(self::ALPHABET) - 1)];
		}
		$locale = function_exists('determine_locale') ? determine_locale() : 'en_US';
		$language = str_starts_with(strtolower($locale), 'de') ? 'de' : 'en';
		if (self::wav($answer, $language) === '') {
			return null;
		}
		$token = bin2hex(random_bytes(24));
		$stored = [
			'answer' => $answer,
			'form_id' => $form_id,
			'source_post_id' => $source_post_id,
			'field' => $field,
			'language' => $language,
		];
		// STORAGE INVARIANT: Publish a bearer token only after its exact answer
		// and bindings can be read back from the transient store.
		if (!set_transient(self::key($token), $stored, self::TTL)) {
			return null;
		}
		if (get_transient(self::key($token)) !== $stored) {
			delete_transient(self::key($token));
			return null;
		}

		return [
			'token' => $token,
			'image' => self::media_url($token, 'image'),
			'audio' => self::media_url($token, 'audio'),
		];
	}

	/** Return field errors for every unanswered or invalid published CAPTCHA. */
	public static function validate_fields(
		array $fields,
		array $params,
		string $form_id,
		int $source_post_id,
	): array {
		$errors = [];
		foreach ($fields as $name => $field) {
			$answer = $params[$name] ?? null;
			$token = $params[$name . '_token'] ?? null;
			if (!self::verify($token, $answer, $form_id, $source_post_id, $name)) {
				$errors[$name] = [__('The security code is incorrect or expired. Please try a new code.', 'wphave')];
			}
		}

		return $errors;
	}

	/** Consume a challenge exactly once and compare its answer and source binding. */
	public static function verify(
		$token,
		$answer,
		string $form_id,
		int $source_post_id,
		string $field,
	): bool {
		if (
			!is_string($token) ||
			!preg_match('/^[a-f0-9]{48}$/D', $token)
		) {
			return false;
		}
		// AVAILABILITY INVARIANT: Unknown handles never allocate an ownership
		// lock. The value is read again under the lock before consumption.
		if (false === get_transient(self::key($token))) {
			return false;
		}
		// REPLAY INVARIANT: The token lock serializes concurrent attempts. A
		// wrong answer consumes the challenge just like a correct answer.
		$lock_name = 'wphave_captcha_' . $token . '_lock';
		$owner = WPHAVE_Form_Option_Lock::acquire($lock_name, 15);
		if (!$owner) {
			return false;
		}
		try {
			$challenge = get_transient(self::key($token));
			if (!self::is_stored_challenge($challenge)) {
				delete_transient(self::key($token));
				return false;
			}
			// CONSUMPTION INVARIANT: An answer is never accepted while its
			// transient may still exist. A failed cache deletion fails closed.
			if (
				!delete_transient(self::key($token)) ||
				false !== get_transient(self::key($token))
			) {
				// CONSUMPTION INVARIANT: A cache drop-in may report successful
				// deletion while still serving the bearer. Never accept an answer
				// until storage confirms the challenge is absent.
				return false;
			}
			// ATTEMPT INVARIANT: Even a malformed answer consumes a live token.
			// Only the token shape is checked before the ownership lock.
			return is_string($answer) &&
				preg_match('/^[a-zA-Z0-9]{5}$/D', $answer) === 1 &&
				hash_equals((string) ($challenge['answer'] ?? ''), strtoupper($answer)) &&
				hash_equals((string) ($challenge['form_id'] ?? ''), $form_id) &&
				(int) ($challenge['source_post_id'] ?? 0) === $source_post_id &&
				hash_equals((string) ($challenge['field'] ?? ''), $field);
		} finally {
			WPHAVE_Form_Option_Lock::release($lock_name, $owner);
		}
	}

	/** Expose refresh only through the public form context admission check. */
	public static function register_routes(): void {
		register_rest_route('wphave/v1', '/form-captcha', [
			'methods' => 'GET',
			'callback' => [__CLASS__, 'refresh'],
			'permission_callback' => '__return_true',
		]);
	}

	/** Refresh only a CAPTCHA that belongs to the public form source. */
	public static function refresh(WP_REST_Request $request) {
		// CROSS-SITE INVARIANT: A foreign page must not spend another visitor's
		// proof-issuance budget through a no-CORS GET. Missing Fetch Metadata is
		// allowed for older clients, but an explicit Origin must match the site.
		if (!self::allows_browser_refresh($_SERVER['HTTP_SEC_FETCH_SITE'] ?? '')) {
			return new WP_Error('captcha_cross_site', __('The form is unavailable.', 'wphave'), ['status' => 403]);
		}
		// AVAILABILITY INVARIANT: Bound even invalid context probes before the
		// schema parser and challenge generator can do any significant work.
		if (
			WPHAVE_Form_Spam_Policy::is_nonce_rate_limited(
				WPHAVE_Client_IP::resolve(),
				(string) ($_SERVER['HTTP_USER_AGENT'] ?? ''),
			)
		) {
			return new WP_Error('captcha_rate_limited', __('Too many requests.', 'wphave'), ['status' => 429]);
		}
		$form_id = WPHAVE_Form_Identity::normalize($request->get_param('formId'));
		$raw_field = $request->get_param('field');
		// FIELD IDENTITY INVARIANT: Sanitizing a public refresh selector can
		// turn a forged name into another CAPTCHA field's exact schema key.
		$field = is_string($raw_field) && preg_match('/^[a-z0-9_-]{3,80}$/D', $raw_field)
			? $raw_field
			: '';
		// REQUEST IDENTITY INVARIANT: Refresh must use the same exact public
		// placement IDs as nonce issuance and submission. No repaired ID may
		// obtain a new CAPTCHA challenge for another form source.
		$context_id = WPHAVE_Form_Identity::request_post_id($request->get_param('postId'));
		$source_id = WPHAVE_Form_Identity::request_post_id($request->get_param('sourcePostId'));
		// AUTHORITY INVARIANT: Client IDs identify a candidate only. The
		// published form placement and its parsed CAPTCHA field grant issuance.
		$public_source = $form_id && $field && $context_id && $source_id &&
			WPHAVE_Form_Public_Context::allows($context_id, $source_id, $form_id);
		$schema = $public_source
			? WPHAVE_Form_Schema_Parser::parse_post($source_id, $form_id)
			: [];
		if (
			!$public_source ||
			isset($schema[WPHAVE_Form_Schema_Parser::INVALID_SCHEMA_FIELD]) ||
			($schema[$field]['type'] ?? '') !== 'captcha'
		) {
			return new WP_Error(
				'captcha_invalid_context',
				__('The form is unavailable.', 'wphave'),
				['status' => 404],
			);
		}
		$challenge = self::issue($form_id, $source_id, $field);
		if (!$challenge) {
			return new WP_Error(
				'captcha_unavailable',
				__('The security code is unavailable.', 'wphave'),
				['status' => 503],
			);
		}
		$response = rest_ensure_response($challenge);
		$response->header('Cache-Control', 'private, no-store, max-age=0');
		return $response;
	}

	/** Deliver either format only to a bearer of a live, well-formed token. */
	public static function serve_media(): void {
		if (!isset($_GET['wphave_form_captcha'])) {
			return;
		}
		$raw_token = $_GET['wphave_form_captcha'];
		$token = is_string($raw_token) ? wp_unslash($raw_token) : '';
		if (!$token) {
			status_header(404);
			exit();
		}
		$raw_mode = $_GET['mode'] ?? '';
		$mode = is_string($raw_mode) ? wp_unslash($raw_mode) : '';
		$status = self::media_request_status($token, $mode, $_SERVER['HTTP_SEC_FETCH_SITE'] ?? '');
		if ($status !== 200) {
			status_header($status);
			exit();
		}
		$challenge = get_transient(self::key($token));
		if (!self::is_stored_challenge($challenge)) {
			status_header(404);
			exit();
		}
		// CACHE INVARIANT: Token-bearing media must not be reused by a shared
		// cache after expiry or after a successful or failed answer attempt.
		nocache_headers();
		header('X-Content-Type-Options: nosniff');
		if ($mode === 'image') {
			$image = self::png($challenge['answer']);
			if ($image === '') {
				status_header(503);
				exit();
			}
			header('Content-Type: image/png');
			header('Content-Length: ' . strlen($image));
			echo $image;
		} else {
			$audio = self::wav((string) $challenge['answer'], $challenge['language']);
			if (!$audio) {
				status_header(503);
				exit();
			}
			header('Content-Type: audio/wav');
			header('Content-Length: ' . strlen($audio));
			echo $audio;
		}
		exit();
	}

	/** Bound all plausible media handles before reading their transient. */
	private static function media_request_status(string $token, string $mode, $fetch_site): int {
		if (
			strlen($token) !== 48 ||
			!preg_match('/^[a-f0-9]{48}$/D', $token) ||
			!in_array($mode, ['image', 'audio'], true)
		) {
			return 404;
		}
		if (!self::allows_browser_refresh($fetch_site)) {
			return 403;
		}
		// LOOKUP BUDGET INVARIANT: A syntactically valid but unknown bearer
		// must not trigger unlimited database/cache reads. Foreign browser
		// embeds and malformed URLs are rejected before spending this bucket.
		return WPHAVE_Form_Spam_Policy::is_captcha_media_rate_limited(WPHAVE_Client_IP::resolve())
			? 429
			: 200;
	}

	/** Render the visual proof; decorative noise is never answer entropy. */
	private static function png(string $answer): string {
		$image = imagecreatetruecolor(220, 80);
		$background = imagecolorallocate($image, 241, 245, 249);
		$foreground = imagecolorallocate($image, 23, 37, 59);
		$noise = imagecolorallocate($image, 170, 184, 199);
		imagefilledrectangle($image, 0, 0, 219, 79, $background);
		for ($line = 0; $line < 8; $line++) {
			imageline(
				$image,
				mt_rand(0, 219),
				mt_rand(0, 79),
				mt_rand(0, 219),
				mt_rand(0, 79),
				$noise,
			);
		}
		for ($index = 0; $index < self::LENGTH; $index++) {
			$glyph = imagecreatetruecolor(9, 15);
			imagefilledrectangle($glyph, 0, 0, 8, 14, $background);
			imagestring($glyph, 5, 0, 0, $answer[$index], $foreground);
			imagecopyresampled(
				$image,
				$glyph,
				19 + $index * 40,
				mt_rand(12, 25),
				0,
				0,
				28,
				43,
				9,
				15,
			);
		}
		for ($dot = 0; $dot < 80; $dot++) {
			imagesetpixel($image, mt_rand(0, 219), mt_rand(0, 79), $noise);
		}
		ob_start();
		if (!imagepng($image)) {
			ob_end_clean();
			return '';
		}
		$bytes = (string) ob_get_clean();
		return str_starts_with($bytes, "\x89PNG\r\n\x1a\n") ? $bytes : '';
	}

	/** Join packaged mono PCM clips; any missing or malformed clip fails closed. */
	private static function wav(string $answer, string $language = 'en'): string {
		$pcm = '';
		foreach (str_split($answer) as $character) {
			$path = __DIR__ . '/captcha-audio/' . $language . '/' . $character . '.wav';
			$clip_size = is_file($path) ? filesize($path) : false;
			$clip = is_int($clip_size) && $clip_size <= self::MAX_CLIP_BYTES
				? file_get_contents($path)
				: false;
			if (
				!is_string($clip) ||
				strlen($clip) < 36 ||
				substr($clip, 0, 4) !== 'RIFF' ||
				substr($clip, 8, 4) !== 'WAVE' ||
				substr($clip, 12, 4) !== 'fmt '
			) {
				return '';
			}
			$format = unpack('vformat/vchannels/Vrate/Vbytes/vblock/vbits', substr($clip, 20, 16));
			if (
				$format['format'] !== 1 ||
				$format['channels'] !== 1 ||
				$format['rate'] !== 16000 ||
				$format['bits'] !== 16 ||
				$format['block'] !== 2 ||
				$format['bytes'] !== 32000
			) {
				return '';
			}
			$offset = 12;
			$data = '';
			while ($offset + 8 <= strlen($clip)) {
				$size = unpack('V', substr($clip, $offset + 4, 4))[1];
				if ($size > strlen($clip) - $offset - 8) {
					return '';
				}
				if (substr($clip, $offset, 4) === 'data') {
					if ($size % 2 !== 0) {
						return '';
					}
					$data = substr($clip, $offset + 8, $size);
					break;
				}
				$offset += 8 + $size + ($size % 2);
			}
			if ($data === '') {
				return '';
			}
			$pcm .= $data . str_repeat("\0", 6400);
		}
		$size = strlen($pcm);
		return 'RIFF' .
			pack('V', $size + 36) .
			'WAVEfmt ' .
			pack('VvvVVvv', 16, 1, 1, 16000, 32000, 2, 16) .
			'data' .
			pack('V', $size) .
			$pcm;
	}

	/** Check cache contents before using them as media input or proof. */
	private static function is_stored_challenge($challenge): bool {
		return is_array($challenge) &&
			is_string($challenge['answer'] ?? null) &&
			preg_match('/^[' . self::ALPHABET . ']{' . self::LENGTH . '}$/D', $challenge['answer']) === 1 &&
			is_string($challenge['form_id'] ?? null) &&
			$challenge['form_id'] !== '' &&
			WPHAVE_Form_Identity::normalize($challenge['form_id']) === $challenge['form_id'] &&
			is_int($challenge['source_post_id'] ?? null) &&
			$challenge['source_post_id'] > 0 &&
			is_string($challenge['field'] ?? null) &&
			// STORED-FIELD INVARIANT: Cache corruption must not restore a
			// protocol-owned field that issuance would refuse to create.
			$challenge['field'] !== '_wphave_invalid_captcha' &&
			!str_starts_with($challenge['field'], '_wphave_') &&
			!str_starts_with($challenge['field'], '_wp_') &&
			$challenge['field'] !== '_wpnonce' &&
			preg_match('/^[a-z0-9_-]{3,80}$/D', $challenge['field']) === 1 &&
			in_array($challenge['language'] ?? null, ['de', 'en'], true);
	}

	/** Permit the form's own fetch; reject browser requests from other origins. */
	private static function allows_browser_refresh($fetch_site): bool {
		// PROOF ORIGIN INVARIANT: A legacy browser may omit Fetch Metadata
		// but still send Origin. An explicit foreign origin cannot spend the
		// challenge issuance or media lookup budget.
		return WPHAVE_Form_Spam_Policy::allows_browser_proof_request(
			$fetch_site,
			$_SERVER['HTTP_ORIGIN'] ?? '',
		);
	}

	/** Build a same-origin, token-bound URL without putting the answer in it. */
	private static function media_url(string $token, string $mode): string {
		return add_query_arg(
			['wphave_form_captcha' => $token, 'mode' => $mode],
			home_url('/'),
		);
	}

	/** Keep transient keys isolated from other form proof and cache entries. */
	private static function key(string $token): string {
		return 'wphave_form_captcha_' . $token;
	}
}

WPHAVE_Form_Captcha::init();
