<?php

/**
 * Provide short-lived, ownership-safe database locks for Forms workflows.
 */
final class WPHAVE_Form_Option_Lock {

	/** Acquire a lock and recover it only when the observed stale owner still owns it. */
	public static function acquire( string $option_name, int $ttl_seconds ): string {
		$token = WPHAVE_Background_Job_Lock::acquire( $option_name, $ttl_seconds );

		return is_string( $token ) ? $token : '';
	}

	/** Release a lock only while its original token still owns the option. */
	public static function release( string $option_name, string $token ): void {
		WPHAVE_Background_Job_Lock::release( $option_name, $token );
	}
}
