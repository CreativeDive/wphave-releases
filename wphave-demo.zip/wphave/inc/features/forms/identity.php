<?php

/** Preserve persisted form identifiers exactly across rendering and admission. */
final class WPHAVE_Form_Identity {
	/** Accept an exact positive post ID from browser form data or REST JSON. */
	public static function request_post_id($value): int {
		// REQUEST IDENTITY INVARIANT: Browser form data arrives as decimal
		// text, while JSON may supply an integer. Coercion must never turn
		// arrays, signs, fractions or overflow into a different post ID.
		if (is_int($value)) {
			return $value > 0 ? $value : 0;
		}
		if (
			!is_string($value) ||
			!preg_match('/^[1-9][0-9]*$/D', $value) ||
			(string) (int) $value !== $value
		) {
			return 0;
		}

		return (int) $value;
	}

	/** Accept only the editor's exact positive integer source reference. */
	public static function source_post_id($value): int {
		// SOURCE IDENTITY INVARIANT: absint() coerces arrays and fractional
		// numbers into unrelated post IDs. A malformed Loader reference must
		// never render or authorize a different published form document.
		return is_int($value) && $value > 0 ? $value : 0;
	}

	/** Create an unguessable version-4 identity for one delivery attempt. */
	public static function new_submission_id(): string {
		// RETRY IDENTITY INVARIANT: A collision can alias another payload's
		// durable receipt. Never fall back to a non-cryptographic generator.
		$bytes = random_bytes(16);
		$bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x40);
		$bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80);
		$hex = bin2hex($bytes);

		return substr($hex, 0, 8) . '-' .
			substr($hex, 8, 4) . '-' .
			substr($hex, 12, 4) . '-' .
			substr($hex, 16, 4) . '-' .
			substr($hex, 20);
	}

	public static function normalize($value): string {
		if (
			!is_string($value) ||
			strlen($value) > 128 ||
			!preg_match('/^[A-Za-z0-9_-]+$/D', $value)
		) {
			return '';
		}

		return $value;
	}

	/** Accept only a saved conversion goal ID already canonical in Analytics. */
	public static function conversion_goal_id($value): string {
		// GOAL IDENTITY INVARIANT: Analytics stores only lowercase canonical
		// IDs. Repairing a malformed saved form value could attribute a visitor
		// event to a different goal that was never selected by the author.
		return is_string($value) &&
			strlen($value) <= 190 &&
			preg_match('/^[a-z0-9_-]+$/D', $value)
				? $value
				: '';
	}
}
