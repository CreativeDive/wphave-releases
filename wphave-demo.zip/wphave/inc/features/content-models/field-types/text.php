<?php

/** Single-line plain-text field contract. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Store single-line text after WordPress plain-text sanitization. */

final class WPHAVE_Content_Model_Text_Field_Type extends WPHAVE_Content_Model_Abstract_Placeholder_Field_Type {
    
	/** Get the stable text type name.
	 *
	 * @return string Field type name.
	 */

	public function get_name(): string {
		return 'text';
	}

	/**
	 * Sanitize a scalar as single-line plain text.
	 *
	 * @param mixed $value Untrusted field value.
	 * @param array $field Field definition; unused by plain text.
	 * @return string Sanitized text value.
	 */

	public function sanitize_value( $value, array $field ): string {
		return sanitize_text_field( $this->scalar_string( $value ) );
	}
}
