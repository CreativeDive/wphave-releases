<?php

/** Shared canonical JSON storage for bounded semantic multi-choice fields. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Preserve scalar post meta while providing one versioned multi-value contract. */

abstract class WPHAVE_Content_Model_Abstract_Multiple_Choice_Field_Type extends WPHAVE_Content_Model_Abstract_Choice_Field_Type {
	const STORAGE_ENCODING = 'json_string_v1';
	const MAX_ENCODED_BYTES = 16384;

	/** Normalize options and retain only allowlisted presentation settings. */

	public function normalize_definition( array $field ) {
		$settings = is_array( $field['settings'] ?? null ) ? $field['settings'] : array();
		$field = parent::normalize_definition( $field );
		if ( is_wp_error( $field ) ) {
			return $field;
		}
		$field['settings'] = array_merge( array( 'encoding' => self::STORAGE_ENCODING ), $this->normalize_multiple_settings( $settings ) );
		$default = $field['default'] ?? '';
		if ( '' !== $default ) {
			// DECODE-BUDGET INVARIANT: Defaults share the persisted value wire
			// format and must meet its byte ceiling before JSON decoding.
			if ( ! is_string( $default ) || strlen( $default ) > self::MAX_ENCODED_BYTES ) {
				return new WP_Error( 'wphave_content_model_choice_default_invalid', __( 'The selected default values are invalid.', 'wphave' ) );
			}
			$values = is_string( $default ) ? json_decode( $default, true ) : null;
			$allowed = wp_list_pluck( $field['options'], 'value' );
			if (
				JSON_ERROR_NONE !== json_last_error() ||
				! is_array( $values ) ||
				count( $values ) > self::MAX_OPTIONS
			) {
				return new WP_Error( 'wphave_content_model_choice_default_invalid', __( 'The selected default values are invalid.', 'wphave' ) );
			}
			foreach ( $values as $value ) {
				if ( ! is_string( $value ) || ! in_array( $value, $allowed, true ) ) {
					return new WP_Error( 'wphave_content_model_choice_default_invalid', __( 'The selected default values are invalid.', 'wphave' ) );
				}
			}
			if ( count( $values ) !== count( array_unique( $values, SORT_STRING ) ) ) {
				return new WP_Error( 'wphave_content_model_choice_default_invalid', __( 'The selected default values are invalid.', 'wphave' ) );
			}
			$field['default'] = wp_json_encode( array_values( array_filter( $allowed, static function ( $value ) use ( $values ) {
				return in_array( $value, $values, true );
			} ) ) );
		}
		return $field;
	}

	/** Allow concrete controls to add presentation-only settings. */

	protected function normalize_multiple_settings( array $settings ): array {
		return array();
	}

	/** Encode unique selections in immutable option order after allowlist filtering. */
    
	public function sanitize_value( $value, array $field ): string {
		if ( '' === $value ) {
			return '';
		}
		if ( is_string( $value ) ) {
			if ( strlen( $value ) > self::MAX_ENCODED_BYTES ) {
				return '[]';
			}
			$values = json_decode( $value, true );
			if ( JSON_ERROR_NONE !== json_last_error() ) {
				return '[]';
			}
		} elseif ( is_array( $value ) ) {
			$values = $value;
		} else {
			return '[]';
		}
		if ( ! is_array( $values ) || count( $values ) > self::MAX_OPTIONS ) {
			return '[]';
		}
		$requested = array();
		foreach ( $values as $selected ) {
			if ( ! is_string( $selected ) ) {
				return '[]';
			}
			$requested[ sanitize_text_field( $selected ) ] = true;
		}
		$canonical = array();
		foreach ( wp_list_pluck( $field['options'] ?? array(), 'value' ) as $allowed ) {
			if ( isset( $requested[ $allowed ] ) ) {
				$canonical[] = $allowed;
			}
		}
		$encoded = wp_json_encode( $canonical );
		return is_string( $encoded ) && strlen( $encoded ) <= self::MAX_ENCODED_BYTES ? $encoded : '[]';
	}

	/** Reject malformed, duplicate or unknown selections before persistence. */

	public function normalize_submitted_value( $value, array $field ) {
		if ( '' === $value ) {
			return '';
		}
		if ( ! is_string( $value ) ) {
			return new WP_Error( 'wphave_content_model_value_semantically_invalid', __( 'The selected values are invalid.', 'wphave' ) );
		}
		if ( strlen( $value ) > self::MAX_ENCODED_BYTES ) {
			return new WP_Error( 'wphave_content_model_value_semantically_invalid', __( 'The selected values are invalid.', 'wphave' ) );
		}
		$values = json_decode( $value, true );
		$allowed = wp_list_pluck( $field['options'] ?? array(), 'value' );
		if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $values ) || count( $values ) > self::MAX_OPTIONS ) {
			return new WP_Error( 'wphave_content_model_value_semantically_invalid', __( 'The selected values are invalid.', 'wphave' ) );
		}
		foreach ( $values as $selected ) {
			if ( ! is_string( $selected ) || ! in_array( $selected, $allowed, true ) ) {
				return new WP_Error( 'wphave_content_model_value_semantically_invalid', __( 'The selected values are invalid.', 'wphave' ) );
			}
		}
		if ( count( $values ) !== count( array_unique( $values, SORT_STRING ) ) ) {
			return new WP_Error( 'wphave_content_model_value_semantically_invalid', __( 'The selected values are invalid.', 'wphave' ) );
		}

		return $this->sanitize_value( $value, $field );
	}
}
