<?php

/** Bounded checkbox-group field using the shared multi-choice storage contract. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WPHAVE_Content_Model_Checkbox_Group_Field_Type extends WPHAVE_Content_Model_Abstract_Multiple_Choice_Field_Type {

	/** Get the stable checkbox-group type name. */

	public function get_name(): string {
		return 'checkbox_group';
	}

	/** Retain only the allowlisted checkbox presentation variation. */
    
	protected function normalize_multiple_settings( array $settings ): array {
		return array(
			'variation' => in_array( $settings['variation'] ?? '', array( 'default', 'boxed' ), true ) ? $settings['variation'] : 'default',
		);
	}
}
