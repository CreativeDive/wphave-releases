<?php

/** Shared scalar identity handling for WordPress object references. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Store references as positive decimal IDs after type-specific existence checks. */

abstract class WPHAVE_Content_Model_Abstract_Reference_Field_Type extends WPHAVE_Content_Model_Abstract_Field_Type {
    
	/**
	 * Normalize the shared selector placeholder used by simple references.
	 *
	 * @param array $field Base normalized field definition.
	 * @return array Definition with a safe placeholder setting.
	 */

	public function normalize_definition( array $field ) {
		$settings = is_array( $field['settings'] ?? null ) ? $field['settings'] : array();
		$field['options'] = array();
		$field['settings'] = array(
			'placeholder' => sanitize_text_field( $settings['placeholder'] ?? '' ),
		);
		return $field;
	}

	/**
	 * Normalize a candidate reference ID and verify the referenced object contract.
	 *
	 * @param mixed $value Untrusted reference value.
	 * @param array $field Complete reference field definition.
	 * @return string Positive object ID or an empty string.
	 */

	public function sanitize_value( $value, array $field ): string {
		// ID-BOUNDARY INVARIANT: Object IDs fit in a signed 64-bit decimal;
		// never scan or coerce an attacker-sized scalar before rejecting it.
		if ( ! is_scalar( $value ) || ! self::is_bounded_id( (string) $value ) ) {
			return '';
		}
		$id = absint( $value );
		return $id && $this->is_valid_reference( $id, $field ) ? (string) $id : '';
	}

	/** Evaluate object visibility only after deterministic value normalization. */

	public function can_read_value( string $value, array $field ): bool {
		if ( '' === $value ) {
			return true;
		}

		return self::is_bounded_id( $value )
			&& $this->is_readable_reference( absint( $value ), $field );
	}

	/** Reject noncanonical or overflowing IDs before WordPress integer coercion. */
	private static function is_bounded_id( string $value ): bool {
		$max = (string) PHP_INT_MAX;
		return strlen( $value ) <= strlen( $max )
			&& ( strlen( $value ) < strlen( $max ) || strcmp( $value, $max ) <= 0 )
			&& 1 === preg_match( '/^[1-9]\d*$/', $value );
	}

	/**
	 * Determine whether an object belongs to this reference contract.
	 *
	 * @param int   $id    Positive WordPress object ID.
	 * @param array $field Complete reference field definition.
	 * @return bool Whether the referenced object is valid.
	 */

	abstract protected function is_valid_reference( int $id, array $field ): bool;

	/** Determine whether a structurally valid reference is visible now. */

	protected function is_readable_reference( int $id, array $field ): bool {
		return $this->is_valid_reference( $id, $field );
	}
}
