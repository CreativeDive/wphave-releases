<?php

/** Enumerated single-choice field contract. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Validate an enumerated single-choice definition and its stored values. */

final class WPHAVE_Content_Model_Select_Field_Type extends WPHAVE_Content_Model_Abstract_Choice_Field_Type {

	/** Get the stable select type name.
	 *
	 * @return string Field type name.
	 */

	public function get_name(): string {
		return 'select';
	}

	/**
	 * Normalize choice options and the select-specific placeholder.
	 *
	 * @param array $field Base normalized field definition.
	 * @return array|WP_Error Definition with safe options and placeholder.
	 */

	public function normalize_definition( array $field ) {
		$settings = is_array( $field['settings'] ?? null ) ? $field['settings'] : array();
		$placeholder = sanitize_text_field( $settings['placeholder'] ?? '' );
		$variation = in_array( $settings['variation'] ?? '', array( 'dropdown', 'select_box' ), true ) ? $settings['variation'] : 'dropdown';
		$field = parent::normalize_definition( $field );
		if ( ! is_wp_error( $field ) ) {
			$field['settings'] = array(
				'placeholder' => $placeholder,
				'variation'   => $variation,
			);
		}
		return $field;
	}
}
