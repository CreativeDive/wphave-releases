<?php

/** WordPress image attachment reference field contract. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Reference an existing attachment whose MIME family is `image`. */

final class WPHAVE_Content_Model_Image_Reference_Field_Type extends WPHAVE_Content_Model_Abstract_Reference_Field_Type {
    
	/** Get the stable image-reference type name.
	 *
	 * @return string Field type name.
	 */

	public function get_name(): string {
		return 'image';
	}

	/**
	 * Verify that an attachment belongs to the image MIME family.
	 *
	 * @param int   $id    Attachment ID.
	 * @param array $field Complete definition; unused by image references.
	 * @return bool Whether the attachment is a referenceable image.
	 */

	protected function is_valid_reference( int $id, array $field ): bool {
		$mime_type = get_post_mime_type( $id );
		return 'attachment' === get_post_type( $id )
			&& is_string( $mime_type )
			&& 0 === strpos( $mime_type, 'image/' );
	}

	/** Respect a private parent while allowing ordinary public Media Library files. */

	protected function is_readable_reference( int $id, array $field ): bool {
		$attachment = get_post( $id );
		$parent = $attachment && $attachment->post_parent ? get_post( $attachment->post_parent ) : null;

		// PRIVACY INVARIANT: Image references follow the same parent-aware disclosure
		// boundary as files. Numeric attachment knowledge cannot reveal media belonging
		// to private content without read_post authority.
		return current_user_can( 'read_post', $id )
			|| ! $parent
			|| is_post_publicly_viewable( $parent );
	}
}
