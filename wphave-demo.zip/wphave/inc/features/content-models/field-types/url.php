<?php

/** HTTP and HTTPS URL field contract. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Accept only absolute web URLs without embedded credentials. */

final class WPHAVE_Content_Model_URL_Field_Type extends WPHAVE_Content_Model_Abstract_Placeholder_Field_Type {
    
	/** Get the stable URL type name.
	 *
	 * @return string Field type name.
	 */

	public function get_name(): string {
		return 'url';
	}

	/**
	 * Sanitize an absolute HTTP(S) URL and reject credentials or missing hosts.
	 *
	 * @param mixed $value Untrusted field value.
	 * @param array $field Field definition; unused by URLs.
	 * @return string Safe absolute URL or an empty string.
	 */

	public function sanitize_value( $value, array $field ): string {
		$value = esc_url_raw( $this->scalar_string( $value ), array( 'http', 'https' ) );
		$parts = $value ? wp_parse_url( $value ) : false;
		if ( ! is_array( $parts ) || empty( $parts['host'] ) || ! in_array( $parts['scheme'] ?? '', array( 'http', 'https' ), true ) || isset( $parts['user'] ) || isset( $parts['pass'] ) ) {
			return '';
		}
		return $value;
	}
}
