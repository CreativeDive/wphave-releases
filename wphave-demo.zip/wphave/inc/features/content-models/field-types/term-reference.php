<?php

/** WordPress taxonomy-term reference field contract. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Reference one existing term from one immutable REST-visible taxonomy. */

final class WPHAVE_Content_Model_Term_Reference_Field_Type extends WPHAVE_Content_Model_Abstract_Reference_Field_Type {
    
	/** Get the stable term-reference type name.
	 *
	 * @return string Field type name.
	 */

	public function get_name(): string {
		return 'term_reference';
	}

	/**
	 * Normalize and verify the immutable taxonomy setting.
	 *
	 * @param array $field Base normalized field definition.
	 * @return array|WP_Error Definition with a valid taxonomy or an error.
	 */

	public function normalize_definition( array $field ) {
		$settings = is_array( $field['settings'] ?? null ) ? $field['settings'] : array();
		$placeholder = sanitize_text_field( $settings['placeholder'] ?? '' );
		$taxonomy = sanitize_key( $settings['taxonomy'] ?? '' );
		$object = $taxonomy ? get_taxonomy( $taxonomy ) : null;
		if ( ! $object || ! $object->show_in_rest ) {
			return new WP_Error( 'wphave_content_model_reference_taxonomy_invalid', __( 'Term references need an available REST taxonomy.', 'wphave' ) );
		}
		$field['options'] = array();
		$field['settings'] = array(
			'taxonomy'    => $taxonomy,
			'placeholder' => $placeholder,
		);
		return $field;
	}

	/**
	 * Verify that a term exists in the configured taxonomy.
	 *
	 * @param int   $id    Term ID.
	 * @param array $field Complete term-reference definition.
	 * @return bool Whether the term is referenceable.
	 */

	protected function is_valid_reference( int $id, array $field ): bool {
		$taxonomy = $field['settings']['taxonomy'] ?? '';
		$term = $taxonomy ? get_term( $id, $taxonomy ) : null;
		return $term instanceof WP_Term;
	}

	/** Public taxonomies are readable anonymously; private taxonomies require access. */

	protected function is_readable_reference( int $id, array $field ): bool {
		$taxonomy = $field['settings']['taxonomy'] ?? '';
		$object = $taxonomy ? get_taxonomy( $taxonomy ) : null;

		// AUTHORIZATION INVARIANT: Public taxonomies permit public term projection;
		// private taxonomy identifiers require the taxonomy's native assignment
		// capability and are never made readable merely by storing their term ID.
		// REFERENCE-SCOPE INVARIANT: A stale stored ID never becomes readable
		// merely because the configured taxonomy itself is public.
		return $object
			&& $this->is_valid_reference( $id, $field )
			&& ( $object->public || current_user_can( $object->cap->assign_terms ) );
	}
}
