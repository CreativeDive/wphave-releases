<?php

/** Email-address field contract. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Store only addresses accepted by WordPress email validation. */

final class WPHAVE_Content_Model_Email_Field_Type extends WPHAVE_Content_Model_Abstract_Placeholder_Field_Type {
    
	/** Get the stable email type name.
	 *
	 * @return string Field type name.
	 */

	public function get_name(): string {
		return 'email';
	}

	/**
	 * Normalize and validate one email address.
	 *
	 * @param mixed $value Untrusted field value.
	 * @param array $field Field definition; unused by email fields.
	 * @return string Valid email address or an empty string.
	 */

	public function sanitize_value( $value, array $field ): string {
		$value = sanitize_email( $this->scalar_string( $value ) );
		return is_email( $value ) ? $value : '';
	}
}
