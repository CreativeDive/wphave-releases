<?php

/** Shared behavior for scalar Content Model field types. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Provide safe defaults shared by scalar field-type implementations. */

abstract class WPHAVE_Content_Model_Abstract_Field_Type implements WPHAVE_Content_Model_Field_Type {
    
	/** Get the default string REST representation.
	 *
	 * @return string REST schema type.
	 */

	public function get_rest_type(): string {
		return 'string';
	}

	/**
	 * Remove option collections from field types that do not support them.
	 *
	 * @param array $field Base normalized field definition.
	 * @return array Normalized definition without options.
	 */

	public function normalize_definition( array $field ) {
		$field['options'] = array();
		$field['settings'] = array();
		return $field;
	}

	/**
	 * Convert scalar input to a string and reject nested values.
	 *
	 * @param mixed $value Untrusted field value.
	 * @return string Scalar string or an empty string for non-scalars.
	 */

	protected function scalar_string( $value ): string {
		return is_scalar( $value ) ? (string) $value : '';
	}

	/**
	 * Reject non-empty values that collapse to the empty clear sentinel.
	 *
	 * @param mixed $value Untrusted explicit write value.
	 * @param array $field Immutable field definition.
	 * @return string|WP_Error Canonical value or semantic error.
	 */

	public function normalize_submitted_value( $value, array $field ) {
		$canonical = $this->sanitize_value( $value, $field );
		if ( '' !== $this->scalar_string( $value ) && '' === $canonical ) {
			return new WP_Error( 'wphave_content_model_value_semantically_invalid', __( 'A Content Field value is invalid for its field type.', 'wphave' ) );
		}

		return $canonical;
	}

	/**
	 * Allow scalar values without an additional object-level read boundary.
	 *
	 * @param string $value Canonical value; unused for ordinary scalars.
	 * @param array  $field Field definition; unused for ordinary scalars.
	 * @return bool Always true.
	 */

	public function can_read_value( string $value, array $field ): bool {
		return true;
	}
}
