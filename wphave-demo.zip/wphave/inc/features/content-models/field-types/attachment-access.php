<?php

/** Shared disclosure policy for attachment references in Content Models. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WPHAVE_Content_Model_Attachment_Access {
	public static function can_read( int $id ): bool {
		$attachment = get_post( $id );
		$parent = $attachment && $attachment->post_parent
			? get_post( $attachment->post_parent )
			: null;
		$publicly_viewable = $attachment && is_post_publicly_viewable( $attachment );

		// ATTACHMENT-DISCLOSURE INVARIANT: A missing or public parent never
		// overrides the attachment's own effective status. Core resolves an
		// inherited attachment status from its parent, or to publish when
		// unattached. Only a genuinely public object or exact read_post access
		// may contribute an ID to a Content Model response.
		// A public effective status does not remove a parent's password gate.
		return $attachment
			&& 'attachment' === $attachment->post_type
			&& (
				(
					$publicly_viewable
					&& '' === (string) $attachment->post_password
					&& ( ! $parent || '' === (string) $parent->post_password )
				)
				|| ( ! $publicly_viewable && current_user_can( 'read_post', $id ) )
				|| current_user_can( 'edit_post', $id )
			);
	}
}
