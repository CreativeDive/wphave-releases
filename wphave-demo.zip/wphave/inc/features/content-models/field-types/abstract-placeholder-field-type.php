<?php

/** Shared placeholder normalization for compatible scalar field types. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Preserve only a sanitized, non-semantic input placeholder setting. */

abstract class WPHAVE_Content_Model_Abstract_Placeholder_Field_Type extends WPHAVE_Content_Model_Abstract_Field_Type {
    
	/**
	 * Normalize a plain-text placeholder and discard unrelated settings.
	 *
	 * @param array $field Base normalized field definition.
	 * @return array Definition with a safe placeholder setting.
	 */

	public function normalize_definition( array $field ) {
		$settings = is_array( $field['settings'] ?? null ) ? $field['settings'] : array();
		$field['options'] = array();
		$field['settings'] = array(
			'placeholder' => sanitize_text_field( $settings['placeholder'] ?? '' ),
		);
		return $field;
	}
}
