<?php

/** Enumerated radio-choice field contract. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Reuse the single-choice allowlist while exposing a distinct editor control. */

final class WPHAVE_Content_Model_Radio_Field_Type extends WPHAVE_Content_Model_Abstract_Choice_Field_Type {

	/** Get the stable radio type name.
	 *
	 * @return string Field type name.
	 */

	public function get_name(): string {
		return 'radio';
	}

	/** Retain only the allowlisted radio presentation variation. */
    
	public function normalize_definition( array $field ) {
		$settings = is_array( $field['settings'] ?? null ) ? $field['settings'] : array();
		$field = parent::normalize_definition( $field );
		if ( ! is_wp_error( $field ) ) {
			$field['settings'] = array(
				'variation' => in_array( $settings['variation'] ?? '', array( 'default', 'boxed' ), true ) ? $settings['variation'] : 'default',
			);
		}
		return $field;
	}
}
