<?php

/** WordPress post reference field contract. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Reference one existing REST-visible non-attachment content item. */

final class WPHAVE_Content_Model_Post_Reference_Field_Type extends WPHAVE_Content_Model_Abstract_Reference_Field_Type {
	const MAX_POST_TYPES = 20;
	const DORMANT_INTEGRATION_POST_TYPES = array( 'product' );

	/** Get the stable post-reference type name.
	 *
	 * @return string Field type name.
	 */

	public function get_name(): string {
		return 'post_reference';
	}

	/**
	 * Normalize the explicit allowlist of referenceable post types.
	 *
	 * @param array $field Base normalized field definition.
	 * @return array|WP_Error Definition with validated post-type settings.
	 */

	public function normalize_definition( array $field ) {
		$settings = is_array( $field['settings'] ?? null ) ? $field['settings'] : array();
		$placeholder = sanitize_text_field( $settings['placeholder'] ?? '' );
		$post_types = $settings['postTypes'] ?? array();
		if ( ! is_array( $post_types ) || count( $post_types ) > self::MAX_POST_TYPES ) {
			return new WP_Error( 'wphave_content_model_reference_post_types_invalid', __( 'Post references need a bounded post-type list.', 'wphave' ) );
		}
		$post_types = array_values( array_unique( array_filter( array_map( 'sanitize_key', $post_types ) ) ) );
		foreach ( $post_types as $post_type ) {
			$object = get_post_type_object( $post_type );
			// LIFECYCLE INVARIANT: A temporarily disabled integration must not
			// invalidate or erase its persisted field contract. Only explicitly
			// owned dormant types are admitted without a live REST registration;
			// arbitrary missing types continue to fail closed.
			$dormant_integration = in_array( $post_type, self::DORMANT_INTEGRATION_POST_TYPES, true );
			if (
				( ( ! $object || ! $object->show_in_rest ) && ! $dormant_integration )
				|| 'attachment' === $post_type
			) {
				return new WP_Error( 'wphave_content_model_reference_post_type_invalid', __( 'A referenced post type is unavailable.', 'wphave' ) );
			}
		}
		if ( ! $post_types ) {
			return new WP_Error( 'wphave_content_model_reference_post_types_required', __( 'Post references need at least one post type.', 'wphave' ) );
		}
		$field['options'] = array();
		$field['settings'] = array(
			'postTypes'   => $post_types,
			'placeholder' => $placeholder,
		);
		return $field;
	}

	/**
	 * Verify that a post exists and belongs to the immutable type allowlist.
	 *
	 * @param int   $id    Post ID.
	 * @param array $field Complete post-reference definition.
	 * @return bool Whether the post is referenceable.
	 */

	protected function is_valid_reference( int $id, array $field ): bool {
		$post = get_post( $id );
		return $post
			&& in_array( $post->post_type, $field['settings']['postTypes'] ?? array(), true );
	}

	/** Public posts remain readable without a session; private posts require access. */

	protected function is_readable_reference( int $id, array $field ): bool {
		$post = get_post( $id );
		return $post
			&& ( is_post_publicly_viewable( $post ) || current_user_can( 'read_post', $id ) );
	}
}
