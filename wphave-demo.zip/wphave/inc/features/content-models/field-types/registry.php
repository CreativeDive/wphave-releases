<?php

/** Object registry for server-side Content Model field-type contracts. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/interface-field-type.php';
require_once __DIR__ . '/abstract-field-type.php';
require_once __DIR__ . '/abstract-placeholder-field-type.php';
require_once __DIR__ . '/abstract-choice-field-type.php';
require_once __DIR__ . '/abstract-multiple-choice-field-type.php';
require_once __DIR__ . '/abstract-reference-field-type.php';
require_once __DIR__ . '/attachment-access.php';
require_once __DIR__ . '/text.php';
require_once __DIR__ . '/textarea.php';
require_once __DIR__ . '/number.php';
require_once __DIR__ . '/select.php';
require_once __DIR__ . '/multi-select.php';
require_once __DIR__ . '/radio.php';
require_once __DIR__ . '/checkbox-group.php';
require_once __DIR__ . '/toggle.php';
require_once __DIR__ . '/url.php';
require_once __DIR__ . '/email.php';
require_once __DIR__ . '/date.php';
require_once __DIR__ . '/datetime.php';
require_once __DIR__ . '/post-reference.php';
require_once __DIR__ . '/term-reference.php';
require_once __DIR__ . '/user-reference.php';
require_once __DIR__ . '/image-reference.php';
require_once __DIR__ . '/gallery.php';
require_once __DIR__ . '/file-reference.php';

/** Resolve all server-side field behavior through registered type objects. */

final class WPHAVE_Content_Model_Field_Type_Registry {

	/** @var array<string,WPHAVE_Content_Model_Field_Type>|null Registered type objects. */
    
	private static $types;

	/**
	 * Build the registry once and ignore invalid or duplicate extensions.
	 *
	 * The filter is an intentional extension boundary, but every entry must satisfy
	 * the closed field-type interface before it can affect definitions or values.
	 *
	 * @return void
	 */

	public static function boot() {
		if ( null !== self::$types ) {
			return;
		}
		$types = apply_filters( 'wphave_content_model_field_types', array(
			new WPHAVE_Content_Model_Text_Field_Type(),
			new WPHAVE_Content_Model_Textarea_Field_Type(),
			new WPHAVE_Content_Model_Number_Field_Type(),
			new WPHAVE_Content_Model_Select_Field_Type(),
			new WPHAVE_Content_Model_Multi_Select_Field_Type(),
			new WPHAVE_Content_Model_Radio_Field_Type(),
			new WPHAVE_Content_Model_Checkbox_Group_Field_Type(),
			new WPHAVE_Content_Model_Toggle_Field_Type(),
			new WPHAVE_Content_Model_URL_Field_Type(),
			new WPHAVE_Content_Model_Email_Field_Type(),
			new WPHAVE_Content_Model_Date_Field_Type(),
			new WPHAVE_Content_Model_Datetime_Field_Type(),
			new WPHAVE_Content_Model_Post_Reference_Field_Type(),
			new WPHAVE_Content_Model_Term_Reference_Field_Type(),
			new WPHAVE_Content_Model_User_Reference_Field_Type(),
			new WPHAVE_Content_Model_Image_Reference_Field_Type(),
			new WPHAVE_Content_Model_Gallery_Field_Type(),
			new WPHAVE_Content_Model_File_Reference_Field_Type(),
		) );
		self::$types = array();
		foreach ( $types as $type ) {
			if ( ! $type instanceof WPHAVE_Content_Model_Field_Type ) {
				continue;
			}
			$name = sanitize_key( $type->get_name() );
			if ( $name && ! isset( self::$types[ $name ] ) ) {
				self::$types[ $name ] = $type;
			}
		}
	}

	/** Get all registered stable field-type names.
	 *
	 * @return array Registered type names.
	 */

	public static function names() {
		self::boot();
		return array_keys( self::$types );
	}

	/**
	 * Resolve a registered type object.
	 *
	 * @param string $type Candidate type name.
	 * @return WPHAVE_Content_Model_Field_Type|null Registered contract or null.
	 */

	public static function get( $type ) {
		self::boot();
		return self::$types[ sanitize_key( $type ) ] ?? null;
	}

	/**
	 * Determine whether a type contract exists.
	 *
	 * @param string $type Candidate type name.
	 * @return bool Whether the type is registered.
	 */

	public static function has( $type ) {
		return null !== self::get( $type );
	}

	/**
	 * Delegate type-specific field-definition normalization.
	 *
	 * @param string $type  Registered type name.
	 * @param array  $field Base normalized field definition.
	 * @return array|WP_Error Normalized definition or unknown-type error.
	 */

	public static function normalize_definition( $type, array $field ) {
		$contract = self::get( $type );
		return $contract ? $contract->normalize_definition( $field ) : new WP_Error( 'wphave_content_model_field_type_unknown', __( 'The field type is unavailable.', 'wphave' ) );
	}

	/**
	 * Sanitize an untrusted value through its registered type contract.
	 *
	 * @param string $type  Registered type name.
	 * @param mixed  $value Untrusted field value.
	 * @param array  $field Complete field definition.
	 * @return string Canonical value or an empty string for unavailable types.
	 */

	public static function sanitize( $type, $value, $field = array() ) {
		$contract = self::get( $type );
		return $contract ? $contract->sanitize_value( $value, (array) $field ) : '';
	}

	/**
	 * Validate one explicit write and preserve the distinction from clearing.
	 *
	 * @param string $type  Registered type name.
	 * @param mixed  $value Untrusted submitted value.
	 * @param array  $field Complete field definition.
	 * @return string|WP_Error Canonical value or semantic error.
	 */

	public static function normalize_submitted_value( $type, $value, $field = array() ) {
		$contract = self::get( $type );
		return $contract
			? $contract->normalize_submitted_value( $value, (array) $field )
			: new WP_Error( 'wphave_content_model_field_type_unknown', __( 'The field type is unavailable.', 'wphave' ) );
	}

	/**
	 * Apply contextual read authorization without changing schema normalization.
	 *
	 * @param string $type  Registered type name.
	 * @param string $value Canonical value being exposed.
	 * @param array  $field Complete field definition.
	 * @return bool Whether the current request may read the value.
	 */

	public static function can_read( $type, $value, $field = array() ) {
		$contract = self::get( $type );
		return $contract && $contract->can_read_value( (string) $value, (array) $field );
	}

	/**
	 * Resolve the WordPress REST schema type for a registered field type.
	 *
	 * @param string $type Registered type name.
	 * @return string REST schema type, defaulting safely to string.
	 */

	public static function rest_type( $type ) {
		$contract = self::get( $type );
		return $contract ? $contract->get_rest_type() : 'string';
	}
}
