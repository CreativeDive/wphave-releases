<?php

/** Boolean toggle field contract with canonical string storage. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Store boolean values as the unambiguous scalar strings `1` and `0`. */

final class WPHAVE_Content_Model_Toggle_Field_Type extends WPHAVE_Content_Model_Abstract_Field_Type {
    
	/** Get the stable toggle type name.
	 *
	 * @return string Field type name.
	 */

	public function get_name(): string {
		return 'toggle';
	}

	/**
	 * Normalize optional human-readable state labels.
	 *
	 * @param array $field Base normalized field definition.
	 * @return array Definition with safe state labels.
	 */

	public function normalize_definition( array $field ) {
		$settings = is_array( $field['settings'] ?? null ) ? $field['settings'] : array();
		$field['options'] = array();
		$field['settings'] = array(
			'onLabel'  => sanitize_text_field( $settings['onLabel'] ?? __( 'On', 'wphave' ) ),
			'offLabel' => sanitize_text_field( $settings['offLabel'] ?? __( 'Off', 'wphave' ) ),
		);
		return $field;
	}

	/**
	 * Convert known boolean representations to canonical scalar storage.
	 *
	 * Unknown values fail closed to the false representation.
	 *
	 * @param mixed $value Untrusted field value.
	 * @param array $field Field definition; unused by toggles.
	 * @return string `1` when true, otherwise `0`.
	 */

	public function sanitize_value( $value, array $field ): string {
		return in_array( $value, array( true, 1, '1', 'true', 'on', 'yes' ), true ) ? '1' : '0';
	}

	/** Accept only explicit boolean representations instead of coercing typos. */

	public function normalize_submitted_value( $value, array $field ) {
		$allowed = array( true, false, 1, 0, '1', '0', 'true', 'false', 'on', 'off', 'yes', 'no' );
		if ( ! in_array( $value, $allowed, true ) ) {
			return new WP_Error( 'wphave_content_model_value_semantically_invalid', __( 'The toggle value is invalid.', 'wphave' ) );
		}

		return $this->sanitize_value( $value, $field );
	}
}
