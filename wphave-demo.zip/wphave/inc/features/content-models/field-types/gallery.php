<?php

/** Bounded ordered collection of WordPress image attachment references. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Store a gallery as canonical versioned JSON inside one scalar post-meta value. */

final class WPHAVE_Content_Model_Gallery_Field_Type extends WPHAVE_Content_Model_Abstract_Field_Type {
	const STORAGE_ENCODING = 'json_string_v1';
	const MAX_ITEMS = 50;
	const MAX_ENCODED_BYTES = 16384;

	/** Get the stable gallery type name. */

	public function get_name(): string {
		return 'gallery';
	}

	/** Pin storage and collection limits so clients cannot weaken the contract. */

	public function normalize_definition( array $field ) {
		$field['options'] = array();
		$field['settings'] = array(
			'encoding' => self::STORAGE_ENCODING,
			'maxItems' => self::MAX_ITEMS,
		);
		return $field;
	}

	/** Canonicalize stored input while dropping unavailable references. */

	public function sanitize_value( $value, array $field ): string {
		$ids = $this->decode( $value );
		if ( null === $ids ) {
			return '[]';
		}

		$canonical = array();
		foreach ( $ids as $id ) {
			if ( $this->is_valid_image( $id ) && ! in_array( $id, $canonical, true ) ) {
				$canonical[] = $id;
			}
		}

		$encoded = wp_json_encode( $canonical );
		return is_string( $encoded ) && strlen( $encoded ) <= self::MAX_ENCODED_BYTES ? $encoded : '[]';
	}

	/** Reject malformed, duplicate, excessive, or non-image selections atomically. */

	public function normalize_submitted_value( $value, array $field ) {
		if ( '' === $value ) {
			return '';
		}

		$ids = $this->decode( $value );
		if ( null === $ids || count( $ids ) !== count( array_unique( $ids, SORT_NUMERIC ) ) ) {
			return $this->invalid_value();
		}
		foreach ( $ids as $id ) {
			if ( ! $this->is_valid_image( $id ) ) {
				return $this->invalid_value();
			}
		}

		return $this->sanitize_value( $value, $field );
	}

	/** Require read access to every selected attachment before exposing the gallery. */

	public function can_read_value( string $value, array $field ): bool {
		// PRIVACY INVARIANT: Gallery disclosure is atomic. If any referenced image is
		// bound to private content the caller cannot read, the complete gallery value
		// remains unavailable rather than leaking the remaining IDs or ordering.
		if ( '' === $value ) {
			return true;
		}

		$ids = $this->decode( $value );
		if ( null === $ids ) {
			return false;
		}
		foreach ( $ids as $id ) {
			$attachment = get_post( $id );
			$parent = $attachment && $attachment->post_parent ? get_post( $attachment->post_parent ) : null;
			if ( ! current_user_can( 'read_post', $id ) && $parent && ! is_post_publicly_viewable( $parent ) ) {
				return false;
			}
		}
		return true;
	}

	/** Decode only a bounded list of positive integer IDs. */

	private function decode( $value ): ?array {
		if ( is_string( $value ) ) {
			$ids = json_decode( $value, true );
			if ( JSON_ERROR_NONE !== json_last_error() ) {
				return null;
			}
		} elseif ( is_array( $value ) ) {
			$ids = $value;
		} else {
			return null;
		}
		if ( ! is_array( $ids ) || count( $ids ) > self::MAX_ITEMS ) {
			return null;
		}

		$normalized = array();
		foreach ( $ids as $id ) {
			$is_positive_integer = is_int( $id ) && $id > 0;
			$is_positive_integer_string = is_string( $id ) && preg_match( '/^[1-9]\d*$/', $id );
			if ( ! $is_positive_integer && ! $is_positive_integer_string ) {
				return null;
			}
			$id = absint( $id );
			if ( ! $id ) {
				return null;
			}
			$normalized[] = $id;
		}
		return $normalized;
	}

	/** Verify the referenced object and MIME family without user-dependent state. */

	private function is_valid_image( int $id ): bool {
		$mime_type = get_post_mime_type( $id );
		return 'attachment' === get_post_type( $id )
			&& is_string( $mime_type )
			&& 0 === strpos( $mime_type, 'image/' );
	}

	/** Return the shared semantic-write failure without partially accepting input. */

	private function invalid_value(): WP_Error {
		return new WP_Error( 'wphave_content_model_value_semantically_invalid', __( 'The selected gallery images are invalid.', 'wphave' ) );
	}
}
