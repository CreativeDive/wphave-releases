<?php

/** Contract implemented by every server-side Content Model field type. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Define the complete validation and storage contract for one scalar field type. */

interface WPHAVE_Content_Model_Field_Type {
    
	/** Get the stable registry name.
	 *
	 * @return string Field type name.
	 */

	public function get_name(): string;

	/** Get the WordPress REST schema type used for registered meta.
	 *
	 * @return string REST schema type.
	 */

	public function get_rest_type(): string;

	/**
	 * Validate and normalize type-specific field-definition properties.
	 *
	 * @param array $field Base normalized field definition.
	 * @return array|WP_Error Normalized definition or validation error.
	 */

	public function normalize_definition( array $field );

	/**
	 * Sanitize one untrusted value against the complete field definition.
	 *
	 * @param mixed $value Untrusted scalar value.
	 * @param array $field Immutable field definition.
	 * @return string Canonical stored value or an empty string when invalid.
	 */

	public function sanitize_value( $value, array $field ): string;

	/**
	 * Validate an explicit write without conflating invalid input with clearing.
	 *
	 * @param mixed $value Untrusted submitted value.
	 * @param array $field Immutable field definition.
	 * @return string|WP_Error Canonical value or a semantic validation error.
	 */

	public function normalize_submitted_value( $value, array $field );

	/**
	 * Decide whether a canonical value may be exposed in the current read context.
	 *
	 * Definition normalization must never depend on the current user. Contextual
	 * authorization belongs here and is evaluated only when a value is read.
	 *
	 * @param string $value Canonical stored or default value.
	 * @param array  $field Immutable field definition.
	 * @return bool Whether the value may be returned to the current request.
	 */

	public function can_read_value( string $value, array $field ): bool;
}
