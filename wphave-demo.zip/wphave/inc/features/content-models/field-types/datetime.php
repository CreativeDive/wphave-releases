<?php

/** Absolute date-and-time field contract. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Normalize explicit ISO 8601 timestamps to a stable UTC representation. */

final class WPHAVE_Content_Model_Datetime_Field_Type extends WPHAVE_Content_Model_Abstract_Field_Type {
    
	/** Get the stable date-time type name.
	 *
	 * @return string Field type name.
	 */

	public function get_name(): string {
		return 'datetime';
	}

	/**
	 * Validate an ISO 8601 timestamp with an explicit timezone and normalize UTC.
	 *
	 * @param mixed $value Untrusted field value.
	 * @param array $field Field definition; unused by date-time fields.
	 * @return string Canonical UTC timestamp or an empty string.
	 */

	public function sanitize_value( $value, array $field ): string {
		$value = $this->scalar_string( $value );
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?(?:Z|[+-]\d{2}:\d{2})$/', $value ) ) {
			return '';
		}
		$parts = date_parse( $value );
		if ( ! empty( $parts['warning_count'] ) || ! empty( $parts['error_count'] ) ) {
			return '';
		}
		try {
			$date = new DateTimeImmutable( $value );
			return $date->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d\TH:i:s\Z' );
		} catch ( Exception $exception ) {
			return '';
		}
	}
}
