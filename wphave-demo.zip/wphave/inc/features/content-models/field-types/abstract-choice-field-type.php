<?php

/** Shared allowlist validation for single-choice Content Model field types. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Normalize and sanitize bounded single-choice fields without duplicating policy. */

abstract class WPHAVE_Content_Model_Abstract_Choice_Field_Type extends WPHAVE_Content_Model_Abstract_Field_Type {
	const MAX_OPTIONS = 200;

	/**
	 * Normalize a bounded list of unique, non-empty label/value options.
	 *
	 * @param array $field Base normalized field definition.
	 * @return array|WP_Error Definition with safe options or validation error.
	 */

	public function normalize_definition( array $field ) {
		if ( isset( $field['options'] ) && ! is_array( $field['options'] ) ) {
			return new WP_Error( 'wphave_content_model_choice_options_invalid', __( 'Choice options must be provided as a list.', 'wphave' ) );
		}
		if ( count( $field['options'] ?? array() ) > self::MAX_OPTIONS ) {
			return new WP_Error( 'wphave_content_model_choice_options_limit', __( 'Choice fields can contain at most 200 options.', 'wphave' ) );
		}
		$options = array();
		$values = array();
		foreach ( $field['options'] ?? array() as $option ) {
			if ( ! is_array( $option ) || ! is_scalar( $option['value'] ?? null ) || ! is_scalar( $option['label'] ?? null ) ) {
				return new WP_Error( 'wphave_content_model_choice_option_invalid', __( 'Every choice option needs a valid label and value.', 'wphave' ) );
			}
			$value = sanitize_text_field( $option['value'] );
			$label = sanitize_text_field( $option['label'] );
			if ( '' === $value || '' === $label ) {
				return new WP_Error( 'wphave_content_model_choice_option_invalid', __( 'Every choice option needs a non-empty label and value.', 'wphave' ) );
			}
			if ( isset( $values[ $value ] ) ) {
				return new WP_Error( 'wphave_content_model_duplicate_option', __( 'Choice option values must be unique.', 'wphave' ) );
			}
			$values[ $value ] = true;
			$options[] = array( 'value' => $value, 'label' => $label );
		}
		if ( ! $options ) {
			return new WP_Error( 'wphave_content_model_choice_options_required', __( 'Choice fields need at least one option.', 'wphave' ) );
		}
		$field['options'] = $options;
		$field['settings'] = array();
		return $field;
	}

	/**
	 * Accept only a scalar value present in the immutable option allowlist.
	 *
	 * @param mixed $value Untrusted selected value.
	 * @param array $field Field definition containing normalized options.
	 * @return string Allowlisted value or an empty string.
	 */

	public function sanitize_value( $value, array $field ): string {
		$value = sanitize_text_field( $this->scalar_string( $value ) );
		return in_array( $value, wp_list_pluck( $field['options'] ?? array(), 'value' ), true ) ? $value : '';
	}
}
