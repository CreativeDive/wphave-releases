<?php

/** Locale-independent finite numeric field contract. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Store finite, locale-independent numbers in a canonical scalar form. */

final class WPHAVE_Content_Model_Number_Field_Type extends WPHAVE_Content_Model_Abstract_Placeholder_Field_Type {
    
	/** Get the stable number type name.
	 *
	 * @return string Field type name.
	 */

	public function get_name(): string {
		return 'number';
	}

	/** Get the numeric WordPress REST representation.
	 *
	 * @return string REST schema type.
	 */

	public function get_rest_type(): string {
		return 'number';
	}

	/** Normalize the input or bounded range-slider presentation contract. */
    
	public function normalize_definition( array $field ) {
		$settings = is_array( $field['settings'] ?? null ) ? $field['settings'] : array();
		$field = parent::normalize_definition( $field );
		$variation = in_array( $settings['variation'] ?? '', array( 'input', 'range' ), true ) ? $settings['variation'] : 'input';
		$min = is_numeric( $settings['min'] ?? null ) ? (float) $settings['min'] : 0.0;
		$max = is_numeric( $settings['max'] ?? null ) ? (float) $settings['max'] : 100.0;
		$step = is_numeric( $settings['step'] ?? null ) ? (float) $settings['step'] : 1.0;
		if ( ! is_finite( $min ) || ! is_finite( $max ) || ! is_finite( $step ) || $min >= $max || $step <= 0 ) {
			return new WP_Error( 'wphave_content_model_number_range_invalid', __( 'Range sliders require a finite minimum below the maximum and a positive step.', 'wphave' ) );
		}
		$field['settings'] = array(
			'placeholder' => $field['settings']['placeholder'],
			'variation'   => $variation,
			'min'         => 0 + $min,
			'max'         => 0 + $max,
			'step'        => 0 + $step,
		);
		return $field;
	}

	/**
	 * Normalize finite numeric input and reject non-numeric or infinite values.
	 *
	 * @param mixed $value Untrusted numeric value.
	 * @param array $field Field definition; unused by numbers.
	 * @return string Canonical numeric string or an empty string.
	 */

	public function sanitize_value( $value, array $field ): string {
		if ( ! is_numeric( $value ) ) {
			return '';
		}
		$number = (float) $value;
		if ( ! is_finite( $number ) ) {
			return '';
		}
		if ( 'range' === ( $field['settings']['variation'] ?? 'input' ) ) {
			$min = (float) ( $field['settings']['min'] ?? 0 );
			$max = (float) ( $field['settings']['max'] ?? 100 );
			if ( $number < $min || $number > $max ) {
				return '';
			}
		}
		return (string) ( 0 + $value );
	}
}
