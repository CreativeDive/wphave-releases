<?php

/** Calendar-date field contract. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Store real Gregorian dates in the canonical `YYYY-MM-DD` representation. */

final class WPHAVE_Content_Model_Date_Field_Type extends WPHAVE_Content_Model_Abstract_Field_Type {
    
	/** Get the stable date type name.
	 *
	 * @return string Field type name.
	 */

	public function get_name(): string {
		return 'date';
	}

	/**
	 * Accept only a strict, round-trippable Gregorian calendar date.
	 *
	 * @param mixed $value Untrusted field value.
	 * @param array $field Field definition; unused by dates.
	 * @return string Canonical date or an empty string.
	 */

	public function sanitize_value( $value, array $field ): string {
		$value = $this->scalar_string( $value );
		$date = DateTimeImmutable::createFromFormat( '!Y-m-d', $value );
		$errors = DateTimeImmutable::getLastErrors();
		return $date && false === $errors && $date->format( 'Y-m-d' ) === $value ? $value : '';
	}
}
