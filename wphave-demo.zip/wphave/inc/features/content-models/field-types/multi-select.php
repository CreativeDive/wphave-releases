<?php

/** Bounded Multi Select field using the shared multi-choice storage contract. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WPHAVE_Content_Model_Multi_Select_Field_Type extends WPHAVE_Content_Model_Abstract_Multiple_Choice_Field_Type {

	/** Get the stable Multi Select type name. */

	public function get_name(): string {
		return 'multi_select';
	}

	/** Retain a sanitized presentation-only placeholder. */
    
	protected function normalize_multiple_settings( array $settings ): array {
		return array( 'placeholder' => sanitize_text_field( $settings['placeholder'] ?? '' ) );
	}
}
