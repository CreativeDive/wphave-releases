<?php

/** Multi-line plain-text field contract. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Store bounded multi-line text without executable markup. */

final class WPHAVE_Content_Model_Textarea_Field_Type extends WPHAVE_Content_Model_Abstract_Field_Type {
	const MAX_LENGTH = 100000;

	/** Get the stable textarea type name.
	 *
	 * @return string Field type name.
	 */

	public function get_name(): string {
		return 'textarea';
	}

	/**
	 * Normalize presentation-only row and value-length settings.
	 *
	 * @param array $field Base normalized field definition.
	 * @return array Definition with bounded textarea settings.
	 */

	public function normalize_definition( array $field ) {
		$settings = is_array( $field['settings'] ?? null ) ? $field['settings'] : array();
		$field['options'] = array();
		$field['settings'] = array(
			'rows'        => min( 20, max( 2, absint( $settings['rows'] ?? 5 ) ) ),
			'maxLength'   => min( self::MAX_LENGTH, absint( $settings['maxLength'] ?? 0 ) ),
			'placeholder' => sanitize_text_field( $settings['placeholder'] ?? '' ),
		);
		return $field;
	}

	/**
	 * Sanitize multi-line text and enforce the configured character limit.
	 *
	 * @param mixed $value Untrusted field value.
	 * @param array $field Complete textarea definition.
	 * @return string Sanitized and bounded multi-line text.
	 */

	public function sanitize_value( $value, array $field ): string {
		$value = sanitize_textarea_field( $this->scalar_string( $value ) );
		$limit = absint( $field['settings']['maxLength'] ?? 0 );
		if ( $limit > 0 ) {
			$value = function_exists( 'mb_substr' ) ? mb_substr( $value, 0, $limit ) : substr( $value, 0, $limit );
		}
		return $value;
	}
}
