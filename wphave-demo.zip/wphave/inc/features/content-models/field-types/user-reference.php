<?php

/** WordPress user reference field contract. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Reference an existing user by ID without copying personal profile data. */

final class WPHAVE_Content_Model_User_Reference_Field_Type extends WPHAVE_Content_Model_Abstract_Reference_Field_Type {
    
	/** Get the stable user-reference type name.
	 *
	 * @return string Field type name.
	 */

	public function get_name(): string {
		return 'user_reference';
	}

	/**
	 * Verify that a WordPress user exists without exposing profile properties.
	 *
	 * @param int   $id    User ID.
	 * @param array $field Complete definition; unused by user references.
	 * @return bool Whether the user is referenceable.
	 */

	protected function is_valid_reference( int $id, array $field ): bool {
		return false !== get_user_by( 'id', $id );
	}

	/** User identities remain protected from anonymous Dynamic Content output. */

	protected function is_readable_reference( int $id, array $field ): bool {
		// PRIVACY INVARIANT: User-reference fields expose only the caller's identity
		// unless WordPress grants directory-level list_users authority. Existence of a
		// stored numeric user ID is never sufficient disclosure authority.
		return get_current_user_id() === $id || current_user_can( 'list_users' );
	}
}
