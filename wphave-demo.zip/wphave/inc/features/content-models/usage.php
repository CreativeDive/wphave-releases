<?php

/** Read-only usage discovery for Content Field groups. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once dirname(__DIR__) . '/security/safe-link.php';

/** Locate stored values and block bindings without mutating content. */
final class WPHAVE_Content_Model_Usage {
	const MAX_ITEMS = 500;
	const MAX_STORED_VALUE_BYTES = 16384;
	const MAX_BLOCK_CONTENT_BYTES = 262144;

	/**
	 * Collect editable content items that use fields from one validated group.
	 *
	 * Exact post-meta keys provide the primary index. Block content is narrowed by
	 * the binding-source marker and then parsed structurally, avoiding false-positive
	 * field-key substring matches.
	 *
	 * @param array $group Validated field-group definition.
	 * @return array Bounded usage response.
	 */
	public static function for_group( array $group ) {
		global $wpdb;

		$fields_by_key = array();
		foreach ( $group['fields'] as $field ) {
			$fields_by_key[ $field['key'] ] = $field;
		}
		if ( ! $fields_by_key || ! $group['postTypes'] ) {
			return array( 'items' => array(), 'total' => 0, 'truncated' => false );
		}

		$type_placeholders = implode( ',', array_fill( 0, count( $group['postTypes'] ), '%s' ) );
		$meta_keys = array_map( array( 'WPHAVE_Content_Model_Value_Repository', 'meta_key' ), array_keys( $fields_by_key ) );
		$meta_placeholders = implode( ',', array_fill( 0, count( $meta_keys ), '%s' ) );
		$meta_ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT DISTINCT pm.post_id FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE pm.meta_key IN ({$meta_placeholders}) AND p.post_type IN ({$type_placeholders}) LIMIT %d",
				array_merge( $meta_keys, $group['postTypes'], array( self::MAX_ITEMS + 1 ) )
			)
		);

		$binding_like = '%' . $wpdb->esc_like( WPHAVE_Content_Models::BINDING_SOURCE ) . '%';
		$binding_ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts} WHERE post_type IN ({$type_placeholders}) AND post_status NOT IN ('trash','auto-draft','inherit') AND post_content LIKE %s LIMIT %d",
				array_merge( $group['postTypes'], array( $binding_like, self::MAX_ITEMS + 1 ) )
			)
		);

		$candidate_ids = array_values( array_unique( array_map( 'absint', array_merge( $meta_ids, $binding_ids ) ) ) );
		$truncated = count( $candidate_ids ) > self::MAX_ITEMS;
		$candidate_ids = array_slice( $candidate_ids, 0, self::MAX_ITEMS );
		$items = array();
		foreach ( $candidate_ids as $post_id ) {
			$post = get_post( $post_id );

			// AUTHORIZATION INVARIANT: A schema-management capability does not disclose
			// every object using that schema. Usage results are projected only for exact
			// posts the current user may edit.
			if ( ! $post || ! in_array( $post->post_type, $group['postTypes'], true ) || ! current_user_can( 'edit_post', $post_id ) ) {
				continue;
			}
			$used = array();
			foreach ( $fields_by_key as $key => $field ) {
				$meta_key = WPHAVE_Content_Model_Value_Repository::meta_key( $key );
				if (
					metadata_exists( 'post', $post_id, $meta_key ) &&
					self::has_stored_value( get_post_meta( $post_id, $meta_key, true ), $field )
				) {
					$used[ $key ] = array( 'key' => $key, 'label' => $field['label'], 'storedValue' => true, 'binding' => false );
				}
			}
			// PARSER-BUDGET INVARIANT: Schema discovery must not recursively parse
			// arbitrarily large legacy post bodies. Preserve exact meta evidence,
			// and tell callers when block evidence could not be inspected.
			if ( strlen( $post->post_content ) <= self::MAX_BLOCK_CONTENT_BYTES ) {
				self::collect_bindings( parse_blocks( $post->post_content ), $fields_by_key, $used );
			} else {
				$truncated = true;
			}
			if ( ! $used ) {
				continue;
			}
			$post_type_object = get_post_type_object( $post->post_type );
			$items[] = array(
				'id'            => $post_id,
				'title'         => get_the_title( $post ) ?: __( '(no title)', 'wphave' ),
				'postType'      => $post->post_type,
				'postTypeLabel' => $post_type_object ? $post_type_object->labels->singular_name : $post->post_type,
				'status'        => $post->post_status,
				// LINK INVARIANT: Field-usage links remain safe after Core filters.
				'editUrl'       => WPHAVE_Safe_Link::http( get_edit_post_link( $post_id, 'raw' ) ),
				'fields'        => array_values( $used ),
			);
		}

		return array( 'items' => $items, 'total' => count( $items ), 'truncated' => $truncated );
	}

	/**
	 * Distinguish a meaningful stored value from an existing but empty meta row.
	 *
	 * Zero remains meaningful for numbers and toggles. Canonical collection fields
	 * additionally treat their empty JSON list as empty; arbitrary text containing
	 * `[]` is not reinterpreted as a collection.
	 *
	 * @param mixed $value Stored scalar post-meta value.
	 * @param array $field Validated field definition.
	 * @return bool Whether the field has an explicit semantic value.
	 */
	private static function has_stored_value( $value, array $field ) {
		if ( '' === $value || null === $value ) {
			return false;
		}

		if ( in_array( $field['type'], array( 'checkbox_group', 'multi_select', 'gallery' ), true ) ) {
			// A collection has a 16 KiB storage contract. Reject oversized legacy
			// values before JSON allocation even in this read-only discovery path.
			$decoded = is_string( $value ) && strlen( $value ) <= self::MAX_STORED_VALUE_BYTES
				? json_decode( $value, true )
				: null;
			return is_array( $decoded ) && ! empty( $decoded );
		}

		return true;
	}

	/** Recursively collect WPHAVE block-binding keys from parsed blocks. */
	private static function collect_bindings( array $blocks, array $fields_by_key, array &$used ) {
		foreach ( $blocks as $block ) {
			$bindings = $block['attrs']['metadata']['bindings'] ?? array();
			foreach ( is_array( $bindings ) ? $bindings : array() as $binding ) {
				$key = sanitize_key( $binding['args']['key'] ?? '' );
				if ( WPHAVE_Content_Models::BINDING_SOURCE !== ( $binding['source'] ?? '' ) || ! isset( $fields_by_key[ $key ] ) ) {
					continue;
				}
				$used[ $key ] = array(
					'key'         => $key,
					'label'       => $fields_by_key[ $key ]['label'],
					'storedValue' => ! empty( $used[ $key ]['storedValue'] ),
					'binding'     => true,
				);
			}
			if ( ! empty( $block['innerBlocks'] ) ) {
				self::collect_bindings( $block['innerBlocks'], $fields_by_key, $used );
			}
		}
	}
}
