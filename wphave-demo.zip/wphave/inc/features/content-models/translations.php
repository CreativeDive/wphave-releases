<?php

/** Runtime translation and Gettext catalog export for Content Fields. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Translate presentation copy without changing schema identity or stored values.
 *
 * Source strings remain part of the canonical field-group definition. Translation
 * happens only on delivery, using deterministic contexts derived from immutable
 * group, field, layout and option identities. Field keys and option values never
 * enter this layer and therefore remain stable across locales.
 */
final class WPHAVE_Content_Model_Translations {
	const TEXT_DOMAIN = 'wphave-content-fields';

	/** Load the optional site-owned Content Fields catalog for the active locale. */
	public static function load_textdomain() {
		$locale = determine_locale();
		$paths = array(
			WP_LANG_DIR . '/plugins/' . self::TEXT_DOMAIN . '-' . $locale . '.mo',
			wphave_dir() . 'languages/' . self::TEXT_DOMAIN . '-' . $locale . '.mo',
		);

		foreach ( $paths as $path ) {
			if ( is_readable( $path ) ) {
				load_textdomain( self::TEXT_DOMAIN, $path, $locale );
				break;
			}
		}
	}

	/**
	 * Translate every user-facing string in one validated runtime group.
	 *
	 * @param array $group Validated group including its persistent ID.
	 * @return array Localized delivery copy with all data identifiers untouched.
	 */
	public static function translate_group( array $group ) {
		$group_id = absint( $group['id'] ?? 0 );
		$translated = $group;
		$translated['title'] = self::translate( $group['title'] ?? '', self::context( $group_id, 'group', 'title' ) );
		$translated['description'] = self::translate( $group['description'] ?? '', self::context( $group_id, 'group', 'description' ) );
		$translated['fields'] = array_map(
			static fn( $field ) => self::translate_field( $field, $group_id ),
			$group['fields'] ?? array()
		);
		$translated['presentation'] = self::translate_presentation( $group['presentation'] ?? array(), $group_id );

		return $translated;
	}

	/** Translate one field's presentation copy while preserving defaults and values. */
	public static function translate_field( array $field, $group_id ) {
		$field_id = sanitize_key( $field['id'] ?? '' );
		$translated = $field;
		foreach ( array( 'label', 'description', 'caption' ) as $property ) {
			$translated[ $property ] = self::translate(
				$field[ $property ] ?? '',
				self::context( $group_id, 'field', $field_id . ':' . $property )
			);
		}

		if ( isset( $translated['settings']['placeholder'] ) ) {
			$translated['settings']['placeholder'] = self::translate(
				$translated['settings']['placeholder'],
				self::context( $group_id, 'field', $field_id . ':placeholder' )
			);
		}

		foreach ( $translated['options'] ?? array() as $index => $option ) {
			$translated['options'][ $index ]['label'] = self::translate(
				$option['label'] ?? '',
				self::context( $group_id, 'option', $field_id . ':' . rawurlencode( (string) ( $option['value'] ?? '' ) ) )
			);
		}

		return $translated;
	}

	/** Translate section copy recursively within the bounded presentation tree. */
	private static function translate_presentation( array $presentation, $group_id ) {
		$translated = $presentation;
		foreach ( $translated['items'] ?? array() as $index => $item ) {
			if ( 'section' !== ( $item['kind'] ?? '' ) ) {
				continue;
			}
			$item_id = sanitize_key( $item['id'] ?? '' );
			foreach ( array( 'label', 'description', 'caption' ) as $property ) {
				$translated['items'][ $index ][ $property ] = self::translate(
					$item[ $property ] ?? '',
					self::context( $group_id, 'section', $item_id . ':' . $property )
				);
			}
		}

		return $translated;
	}

	/** Translate a non-empty source string with an unambiguous Gettext context. */
	private static function translate( $source, $context ) {
		$source = (string) $source;
		return '' === $source
			? ''
			: translate_with_gettext_context( $source, $context, self::TEXT_DOMAIN );
	}

	/** Build the stable public context contract used by POT, PO and MO catalogs. */
	private static function context( $group_id, $kind, $identity ) {
		return sprintf( 'Content Fields / group:%d / %s:%s', absint( $group_id ), sanitize_key( $kind ), $identity );
	}

	/**
	 * Generate a complete POT template from every valid manageable field group.
	 *
	 * @return string Portable Object Template ready for standard translation tools.
	 */
	public static function generate_pot() {
		$entries = array();
		foreach ( WPHAVE_Content_Model_Repository::all_for_management() as $group ) {
			if ( empty( $group['valid'] ) ) {
				continue;
			}
			self::collect_group_entries( $group, $entries );
		}

		ksort( $entries );
		$body = 'msgid ""' . "\n" . 'msgstr ""' . "\n";
		$body .= '"Project-Id-Version: WPHAVE Content Fields\\n"' . "\n";
		$body .= '"Content-Type: text/plain; charset=UTF-8\\n"' . "\n";
		$body .= '"Content-Transfer-Encoding: 8bit\\n"' . "\n";
		$body .= '"X-Domain: ' . self::TEXT_DOMAIN . '\\n"' . "\n\n";

		foreach ( $entries as $entry ) {
			$body .= '#. ' . self::pot_escape( $entry['comment'] ) . "\n";
			$body .= 'msgctxt "' . self::pot_escape( $entry['context'] ) . '"' . "\n";
			$body .= 'msgid "' . self::pot_escape( $entry['source'] ) . '"' . "\n";
			$body .= 'msgstr ""' . "\n\n";
		}

		return $body;
	}

	/** Collect the same source/context pairs consumed by runtime translation. */
	private static function collect_group_entries( array $group, array &$entries ) {
		$group_id = absint( $group['id'] );
		self::add_entry( $entries, $group['title'] ?? '', self::context( $group_id, 'group', 'title' ), 'Field group title' );
		self::add_entry( $entries, $group['description'] ?? '', self::context( $group_id, 'group', 'description' ), 'Field group description' );

		foreach ( $group['fields'] ?? array() as $field ) {
			$field_id = sanitize_key( $field['id'] ?? '' );
			foreach ( array( 'label', 'description', 'caption' ) as $property ) {
				self::add_entry( $entries, $field[ $property ] ?? '', self::context( $group_id, 'field', $field_id . ':' . $property ), 'Content Field ' . $property );
			}
			self::add_entry( $entries, $field['settings']['placeholder'] ?? '', self::context( $group_id, 'field', $field_id . ':placeholder' ), 'Content Field placeholder' );
			foreach ( $field['options'] ?? array() as $option ) {
				self::add_entry( $entries, $option['label'] ?? '', self::context( $group_id, 'option', $field_id . ':' . rawurlencode( (string) ( $option['value'] ?? '' ) ) ), 'Content Field option label; the stored option value is intentionally not translated' );
			}
		}

		foreach ( $group['presentation']['items'] ?? array() as $item ) {
			if ( 'section' !== ( $item['kind'] ?? '' ) ) {
				continue;
			}
			$item_id = sanitize_key( $item['id'] ?? '' );
			foreach ( array( 'label', 'description', 'caption' ) as $property ) {
				self::add_entry( $entries, $item[ $property ] ?? '', self::context( $group_id, 'section', $item_id . ':' . $property ), 'Content Field section ' . $property );
			}
		}
	}

	/** Add a unique, non-empty translation unit. */
	private static function add_entry( array &$entries, $source, $context, $comment ) {
		$source = (string) $source;
		if ( '' === $source ) {
			return;
		}
		$entries[ $context . "\0" . $source ] = compact( 'source', 'context', 'comment' );
	}

	/** Escape a scalar for one-line PO syntax without producing executable PHP. */
	private static function pot_escape( $value ) {
		return addcslashes( (string) $value, "\\\"\n\r\t" );
	}
}
