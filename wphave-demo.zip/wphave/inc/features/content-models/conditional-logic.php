<?php

/** Content Fields adapter for the shared WPHAVE rules engine. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Own field-type operator policy and reject cyclic visibility dependencies. */
final class WPHAVE_Content_Model_Conditional_Logic {
	/** Normalize every field rule group after all source contracts are known. */
	public static function normalize_fields( array $fields ) {
		$sources = array_column( $fields, null, 'id' );
		foreach ( $fields as $index => $field ) {
			$available = $sources;
			unset( $available[ $field['id'] ] );
			$logic = WPHAVE_Rules_Engine::normalize(
				$field['conditionalLogic'] ?? null,
				$available,
				array( __CLASS__, 'operators_for_field' )
			);
			if ( is_wp_error( $logic ) ) {
				return $logic;
			}
			$fields[ $index ]['conditionalLogic'] = $logic;
		}

		return self::has_cycle( $fields )
			? new WP_Error( 'wphave_content_model_condition_cycle', __( 'Conditional field dependencies cannot contain a cycle.', 'wphave' ) )
			: $fields;
	}

	/** Return operators meaningful for one source field's immutable value type. */
	public static function operators_for_field( array $field ) {
		$operators = array( 'equals', 'not_equals', 'empty', 'not_empty' );
		if ( 'number' === $field['type'] ) {
			$operators[] = 'greater_than';
			$operators[] = 'less_than';
		}
		if ( in_array( $field['type'], array( 'checkbox_group', 'multi_select', 'gallery' ), true ) ) {
			$operators = array( 'empty', 'not_empty', 'contains', 'not_contains' );
		}
		return $operators;
	}

	/** Detect cycles in target-to-source dependencies using bounded depth-first search. */
	private static function has_cycle( array $fields ) {
		$graph = array();
		foreach ( $fields as $field ) {
			$graph[ $field['id'] ] = empty( $field['conditionalLogic']['enabled'] )
				? array()
				: wp_list_pluck( $field['conditionalLogic']['rules'], 'source' );
		}
		$visiting = array();
		$visited = array();
		$visit = static function ( $id ) use ( &$visit, &$graph, &$visiting, &$visited ) {
			if ( isset( $visiting[ $id ] ) ) {
				return true;
			}
			if ( isset( $visited[ $id ] ) ) {
				return false;
			}
			$visiting[ $id ] = true;
			foreach ( $graph[ $id ] ?? array() as $dependency ) {
				if ( $visit( $dependency ) ) {
					return true;
				}
			}
			unset( $visiting[ $id ] );
			$visited[ $id ] = true;
			return false;
		};
		foreach ( array_keys( $graph ) as $id ) {
			if ( $visit( $id ) ) {
				return true;
			}
		}
		return false;
	}
}
