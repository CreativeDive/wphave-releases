<?php

/** Central authorization policy for schema and value operations. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Centralize schema and value authorization without trusting REST clients. */

final class WPHAVE_Content_Model_Access_Policy {
	const VIEW_SCHEMAS = 'wphave_view_content_models';
	const EDIT_SCHEMAS = 'wphave_edit_content_models';
	const ACTIVATE_SCHEMAS = 'wphave_activate_content_models';
	const EDIT_VALUES = 'wphave_edit_content_model_values';

	/**
	 * Check an explicit Content Fields capability or full administrator access.
	 *
	 * @param string $capability Capability required by the operation.
	 * @return bool Whether the current user has the capability.
	 */

	private static function has( $capability ) {
		return current_user_can( 'manage_options' )
			|| current_user_can( $capability );
	}

	/** Determine whether the current user may inspect field-group schemas.
	 *
	 * @return bool Whether schema viewing is allowed.
	 */

	public static function can_view_schemas() {
		return self::has( self::VIEW_SCHEMAS );
	}

	/** Determine whether the current user may create or edit field-group schemas.
	 *
	 * @return bool Whether schema editing is allowed.
	 */

	public static function can_edit_schemas() {
		return self::has( self::EDIT_SCHEMAS );
	}

	/** Determine whether the current user may change runtime activation.
	 *
	 * @return bool Whether activation changes are allowed.
	 */

	public static function can_activate_schemas() {
		return self::has( self::ACTIVATE_SCHEMAS );
	}

	/**
	 * Require both Content Field access and object-level edit permission.
	 *
	 * @param int $post_id Content item whose registered values would change.
	 * @return bool Whether the current user may edit values on the item.
	 */

	public static function can_edit_values( $post_id ) {
		// AUTHORIZATION INVARIANT: Content Fields access is not object authority.
		// The attacker-controlled post ID must independently pass Core's mapped
		// edit_post capability for that exact object before metadata can change.
		return current_user_can( 'edit_post', absint( $post_id ) )
			&& self::has( self::EDIT_VALUES );
	}
}
