<?php

/** Immutable request-level index of active Content Model contracts. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Build an immutable request-level index of active, conflict-free contracts. */

final class WPHAVE_Content_Model_Registry {

	/** @var array|null Validated active field groups for the current request. */

	private static $groups;

	/** @var array|null Active fields indexed by post type and stable field key. */
    
	private static $fields_by_post_type;

	/** Get all validated active field groups.
	 *
	 * @return array Active field-group definitions.
	 */

	public static function groups() {
		if ( null === self::$groups ) {
			self::build();
		}
		return self::$groups;
	}

	/**
	 * Get conflict-free fields assigned to a post type.
	 *
	 * @param string $post_type WordPress post type name.
	 * @return array Fields keyed by stable field key.
	 */

	public static function fields_for_post_type( $post_type ) {
		if ( null === self::$fields_by_post_type ) {
			self::build();
		}
		return self::$fields_by_post_type[ sanitize_key( $post_type ) ] ?? array();
	}

	/**
	 * Resolve one registered field contract.
	 *
	 * @param string $post_type WordPress post type name.
	 * @param string $key       Stable field key.
	 * @return array|null Field contract or null when unavailable or conflicted.
	 */

	public static function field( $post_type, $key ) {
		return self::fields_for_post_type( $post_type )[ sanitize_key( $key ) ] ?? null;
	}

	/**
	 * Get active field groups assigned to a post type.
	 *
	 * @param string $post_type WordPress post type name.
	 * @return array Matching field-group definitions.
	 */

	public static function groups_for_post_type( $post_type ) {
		$post_type = sanitize_key( $post_type );
		return array_values( array_filter( self::groups(), static fn( $group ) => in_array( $post_type, $group['postTypes'], true ) ) );
	}

	/**
	 * Build request caches and fail closed by removing colliding field keys.
	 *
	 * @return void
	 */

	private static function build() {
		self::$groups = WPHAVE_Content_Model_Repository::all( array( 'publish' ) );
		self::$fields_by_post_type = array();
		$conflicts = array();

		foreach ( self::$groups as $group ) {
			foreach ( $group['postTypes'] as $post_type ) {
				foreach ( $group['fields'] as $field ) {
					$key = $field['key'];
					if ( isset( self::$fields_by_post_type[ $post_type ][ $key ] ) ) {
						$conflicts[ $post_type ][ $key ] = true;
						unset( self::$fields_by_post_type[ $post_type ][ $key ] );
						continue;
					}
					if ( isset( $conflicts[ $post_type ][ $key ] ) ) {
						continue;
					}
					self::$fields_by_post_type[ $post_type ][ $key ] = $field + array(
						'groupId'    => $group['id'],
						'groupTitle' => $group['title'],
					);
				}
			}
		}
	}

	/** Clear request-level indexes after definition mutations.
	 *
	 * @return void
	 */

	public static function reset() {
		self::$groups = null;
		self::$fields_by_post_type = null;
	}
}
