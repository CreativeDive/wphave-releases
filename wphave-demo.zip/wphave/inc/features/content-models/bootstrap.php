<?php

/**
 * WPHAVE Content Models integration facade and WordPress hooks.
 *
 * Invariants: definitions flow through Migrator, Validator, Repository and
 * Registry; values flow through an allowlisted repository; removed fields retain
 * recoverable values; runtime access revalidates the active post-type assignment;
 * and only `wphave/*` blocks may consume the binding source.
 */

if (!defined('ABSPATH')) {
	exit();
}

require_once wphave_dir() . 'inc/background-jobs/lock.php';
require_once dirname(__DIR__, 2) . '/rules/engine.php';
require_once __DIR__ . '/field-types/registry.php';
require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/presentation.php';
require_once __DIR__ . '/translations.php';
require_once __DIR__ . '/conditional-logic.php';
require_once __DIR__ . '/validator.php';
require_once __DIR__ . '/definition-codec.php';
require_once __DIR__ . '/access-policy.php';
require_once __DIR__ . '/write-lock.php';
require_once __DIR__ . '/repository.php';
require_once __DIR__ . '/registry.php';
require_once __DIR__ . '/value-repository.php';
require_once __DIR__ . '/block-bindings.php';

/**
 * Integrate Content Models with WordPress storage, meta and Block Bindings.
 *
 * This integration facade exposes only validated registry data and restricts
 * runtime binding consumption to WPHAVE blocks.
 */

final class WPHAVE_Content_Models {
	const POST_TYPE = 'wphave_field_group';
	const META_PREFIX = '_wphave_field_';
	const BINDING_SOURCE = 'wphave/content-model';

	/** Register WordPress lifecycle hooks for the complete subsystem.
	 *
	 * @return void
	 */

	public static function init() {
		add_action('init', ['WPHAVE_Content_Model_Translations', 'load_textdomain'], 5);
		add_action('init', [__CLASS__, 'register_storage'], 6);
		add_action('init', [__CLASS__, 'register_fields'], 30);
		add_action('init', [__CLASS__, 'register_binding_source'], 31);
		add_filter(
			'block_bindings_supported_attributes',
			['WPHAVE_Content_Model_Block_Bindings', 'supported_attributes'],
			10,
			2,
		);
		add_filter('wp_insert_post_data', [__CLASS__, 'sanitize_storage'], 10, 2);
		add_action('save_post_' . self::POST_TYPE, [__CLASS__, 'flush_cache']);
		add_action('trashed_post', [__CLASS__, 'flush_cache']);
		add_action('untrashed_post', [__CLASS__, 'flush_cache']);
		add_action('deleted_post', [__CLASS__, 'flush_cache'], 10, 2);
	}

	/** Register the private post type used as the field-group definition store.
	 *
	 * @return void
	 */

	public static function register_storage() {
		register_post_type(self::POST_TYPE, [
			'label' => __('Field groups', 'wphave'),
			'public' => false,
			'publicly_queryable' => false,
			'show_ui' => false,
			'show_in_rest' => false,
			'rewrite' => false,
			'query_var' => false,
			'supports' => ['title', 'editor', 'revisions'],
			'capabilities' => [
				'read' => WPHAVE_Content_Model_Access_Policy::VIEW_SCHEMAS,
				'create_posts' => WPHAVE_Content_Model_Access_Policy::EDIT_SCHEMAS,
				'edit_posts' => WPHAVE_Content_Model_Access_Policy::EDIT_SCHEMAS,
				'edit_others_posts' => WPHAVE_Content_Model_Access_Policy::EDIT_SCHEMAS,
				'edit_published_posts' => WPHAVE_Content_Model_Access_Policy::EDIT_SCHEMAS,
				'publish_posts' => WPHAVE_Content_Model_Access_Policy::ACTIVATE_SCHEMAS,
				'delete_posts' => WPHAVE_Content_Model_Access_Policy::EDIT_SCHEMAS,
				'delete_others_posts' => WPHAVE_Content_Model_Access_Policy::EDIT_SCHEMAS,
				'delete_published_posts' => WPHAVE_Content_Model_Access_Policy::EDIT_SCHEMAS,
			],
			'map_meta_cap' => true,
		]);
	}

	/**
	 * Normalize direct post writes before a field-group definition is persisted.
	 *
	 * Invalid or future schemas remain byte-for-byte untouched and are ignored by
	 * the runtime instead of being destructively downgraded.
	 *
	 * @param array $data    Slashed post data prepared by WordPress.
	 * @param array $postarr Original post data supplied to the insert operation.
	 * @return array Filtered post data.
	 */

	public static function sanitize_storage($data, $postarr) {
		if (self::POST_TYPE !== ($data['post_type'] ?? '') || !isset($data['post_content'])) {
			return $data;
		}
		$decoded = WPHAVE_Content_Model_Definition_Codec::decode($data['post_content']);
		$definition = is_wp_error($decoded)
			? $decoded
			: WPHAVE_Content_Model_Validator::sanitize_definition($decoded);
		// A downgrade preserves unknown future schemas byte-for-byte; runtime ignores them.
		if (!is_wp_error($definition)) {
			$data['post_content'] = wp_json_encode($definition);
		}
		return $data;
	}

	/**
	 * Invalidate definition and registry caches after relevant post mutations.
	 *
	 * @param int          $post_id Optional changed post ID.
	 * @param WP_Post|null $post    Optional resolved post object.
	 * @return void
	 */

	public static function flush_cache($post_id = 0, $post = null) {
		$post = $post ?: ($post_id ? get_post($post_id) : null);
		if ($post && self::POST_TYPE !== $post->post_type) {
			return;
		}
		WPHAVE_Content_Model_Repository::invalidate();
		WPHAVE_Content_Model_Registry::reset();
	}

	/** Get all active, validated field groups.
	 *
	 * @return array Validated field-group definitions.
	 */

	public static function get_groups() {
		return WPHAVE_Content_Model_Registry::groups();
	}

	/**
	 * Get the conflict-free active field registry for a content type.
	 *
	 * @param string $post_type WordPress post type name.
	 * @return array Fields keyed by their stable field key.
	 */

	public static function get_fields_for_post_type($post_type) {
		return WPHAVE_Content_Model_Registry::fields_for_post_type($post_type);
	}

	/**
	 * Return the single allowlist of public editable content types supported by fields.
	 *
	 * A REST-visible editor is not sufficient: WordPress exposes several internal
	 * entities (templates, patterns, navigation data and plugin-owned records) in
	 * the REST API and administration UI. Content Fields may target only genuinely
	 * public post types. Management choices, schema validation and runtime meta
	 * registration must all consume this same fail-closed boundary.
	 *
	 * @return array Post-type objects indexed by name.
	 */
	public static function supported_post_types() {
		return array_filter(
			get_post_types(
				[
					'public' => true,
					'show_ui' => true,
					'show_in_rest' => true,
				],
				'objects',
			),
			static function ($post_type) {
				return !in_array($post_type->name, [self::POST_TYPE, 'attachment'], true);
			},
		);
	}

	/**
	 * Determine whether a post type belongs to the shared Content Fields allowlist.
	 *
	 * @param string $post_type Candidate post-type name.
	 * @return bool Whether Content Fields may target the post type.
	 */
	public static function supports_post_type($post_type) {
		return isset(self::supported_post_types()[sanitize_key($post_type)]);
	}

	/**
	 * Register active fields as revision-aware, REST-visible WordPress post meta.
	 *
	 * REST visibility is required by the editor entity lifecycle so Content Fields
	 * participate in dirty state, autosaves and revisions. Sanitization and
	 * authorization remain delegated to the immutable field contract and central
	 * access policy; the dedicated batch endpoint adds stricter atomic semantics
	 * for callers that do not participate in the editor entity lifecycle.
	 *
	 * @return void
	 */

	public static function register_fields() {
		foreach (array_keys(self::supported_post_types()) as $post_type) {
			$fields = WPHAVE_Content_Model_Registry::fields_for_post_type($post_type);
			if ($fields && !post_type_supports($post_type, 'custom-fields')) {
				add_post_type_support($post_type, 'custom-fields');
			}
			foreach ($fields as $field) {
				register_post_meta(
					$post_type,
					WPHAVE_Content_Model_Value_Repository::meta_key($field['key']),
					[
						'type' => 'string',
						'single' => true,
						'show_in_rest' => true,
						'revisions_enabled' => true,
						'sanitize_callback' => static fn(
							$value,
						) => WPHAVE_Content_Model_Field_Type_Registry::sanitize(
							$field['type'],
							$value,
							$field,
						),
						'auth_callback' => static fn(
							$allowed,
							$meta_key,
							$object_id,
						) => WPHAVE_Content_Model_Access_Policy::can_edit_values($object_id),
					],
				);
			}
		}
	}

	/** Register the WPHAVE-only Block Bindings source when WordPress supports it.
	 *
	 * @return void
	 */

	public static function register_binding_source() {
		if (function_exists('register_block_bindings_source')) {
			register_block_bindings_source(self::BINDING_SOURCE, [
				'label' => __('WPHAVE Content Model', 'wphave'),
				'uses_context' => ['postId', 'postType'],
				'get_value_callback' => [__CLASS__, 'get_binding_value'],
			]);
		}
	}

	/**
	 * Resolve an allowlisted field value for a WPHAVE block binding.
	 *
	 * @param array    $source_args    Binding arguments containing the field key.
	 * @param WP_Block $block_instance Block requesting the bound value.
	 * @param string   $attribute_name Bound block attribute name.
	 * @return string|int|float|bool|null Typed scalar field value or null when unavailable.
	 */

	public static function get_binding_value($source_args, $block_instance, $attribute_name) {
		$block_name = $block_instance->name ?? '';
		if (0 !== strpos($block_name, 'wphave/')) {
			return null;
		}
		$post_id = absint($block_instance->context['postId'] ?? get_the_ID());
		$key = sanitize_key($source_args['key'] ?? '');
		$value = WPHAVE_Content_Model_Value_Repository::get($post_id, $key);
		$field = WPHAVE_Content_Model_Registry::field(get_post_type($post_id), $key);
		$block_type = WP_Block_Type_Registry::get_instance()->get_registered($block_name);
		return WPHAVE_Content_Model_Block_Bindings::resolve(
			$value,
			$block_type->attributes[$attribute_name] ?? [],
			$field,
		);
	}
}

WPHAVE_Content_Models::init();
