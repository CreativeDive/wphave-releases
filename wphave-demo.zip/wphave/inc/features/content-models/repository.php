<?php

/** Persistence and cache boundary for Content Model definitions. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Persist validated definitions and own layered cache invalidation. */

final class WPHAVE_Content_Model_Repository {
	const CACHE_GROUP = 'wphave_content_models';
	const GENERATION_OPTION = 'wphave_content_models_cache_generation';
    
	/** @var array Request-local definitions indexed by generated cache key. */
	private static $memory = array();

	/**
	 * Load validated definitions for an explicit set of post statuses.
	 *
	 * Invalid stored schemas are excluded from runtime results. Cache keys include
	 * a generation counter so mutations invalidate persistent and request caches.
	 *
	 * @param array $statuses Post statuses to include.
	 * @return array Validated definitions with storage metadata.
	 */

	public static function all( $statuses = array( 'publish' ) ) {
		$statuses = array_values( array_unique( array_map( 'sanitize_key', (array) $statuses ) ) );
		sort( $statuses );
		$generation = absint( get_option( self::GENERATION_OPTION, 1 ) );
		$key = 'definitions:' . $generation . ':' . md5( wp_json_encode( $statuses ) );
		if ( isset( self::$memory[ $key ] ) ) {
			return self::$memory[ $key ];
		}

		$cached = wp_cache_get( $key, self::CACHE_GROUP );
		if ( is_array( $cached ) ) {
			self::$memory[ $key ] = $cached;
			return $cached;
		}

		$definitions = array();
		$posts = get_posts( array(
			'post_type'      => WPHAVE_Content_Models::POST_TYPE,
			'post_status'    => $statuses,
			'posts_per_page' => -1,
			'orderby'        => array( 'title' => 'ASC', 'ID' => 'ASC' ),
			'no_found_rows'  => true,
		) );
		foreach ( $posts as $post ) {
			$definition = self::definition( $post );
			if ( is_wp_error( $definition ) ) {
				continue;
			}
			$definitions[] = array(
				'id'       => $post->ID,
				'title'    => $post->post_title,
				'active'   => 'publish' === $post->post_status,
				'status'   => 'trash' === $post->post_status ? 'trash' : ( 'publish' === $post->post_status ? 'active' : 'inactive' ),
				'modified' => mysql_to_rfc3339( $post->post_modified_gmt ),
			) + $definition;
		}

		self::$memory[ $key ] = $definitions;
		wp_cache_set( $key, $definitions, self::CACHE_GROUP, HOUR_IN_SECONDS );
		return $definitions;
	}

	/**
	 * Load every storage record for management, including invalid definitions.
	 *
	 * Runtime callers intentionally fail closed through all(). Management callers
	 * must never confuse a validation failure with deletion, so invalid records are
	 * returned as non-editable diagnostic shells instead of being omitted.
	 */
	public static function all_for_management( $statuses = array( 'publish', 'draft', 'trash' ) ) {
		$posts = get_posts( array(
			'post_type'      => WPHAVE_Content_Models::POST_TYPE,
			'post_status'    => array_values( array_unique( array_map( 'sanitize_key', (array) $statuses ) ) ),
			'posts_per_page' => -1,
			'orderby'        => array( 'title' => 'ASC', 'ID' => 'ASC' ),
			'no_found_rows'  => true,
		) );

		return array_map( array( __CLASS__, 'prepare_for_management' ), $posts );
	}

	/**
	 * Decode and validate one stored definition without contextual authorization.
	 *
	 * @param WP_Post $post Field-group storage post.
	 * @return array|WP_Error Deterministic definition or validation error.
	 */
	public static function definition( $post ) {
		$decoded = WPHAVE_Content_Model_Definition_Codec::decode( $post->post_content );
		return is_wp_error( $decoded ) ? $decoded : WPHAVE_Content_Model_Validator::sanitize_definition( $decoded );
	}

	/**
	 * Build a stable management representation without hiding damaged records.
	 *
	 * @param WP_Post $post Field-group storage post.
	 * @return array Valid group or a bounded non-editable diagnostic shell.
	 */
	public static function prepare_for_management( $post ) {
		$definition = self::definition( $post );
		$metadata = array(
			'id'       => $post->ID,
			'title'    => $post->post_title,
			'active'   => 'publish' === $post->post_status,
			'status'   => 'trash' === $post->post_status ? 'trash' : ( 'publish' === $post->post_status ? 'active' : 'inactive' ),
			'modified' => mysql_to_rfc3339( $post->post_modified_gmt ),
			'revision' => self::revision( $post ),
			'valid'    => ! is_wp_error( $definition ),
		);
		if ( ! is_wp_error( $definition ) ) {
			return $metadata + $definition;
		}

		return $metadata + array(
			'description'   => '',
			'editorDisplay' => 'flow',
			'postTypes'     => array(),
			'fields'        => array(),
			'retiredFields' => array(),
			'presentation'  => array( 'grid' => 'full', 'items' => array() ),
			'diagnostic'    => array(
				'code'    => $definition->get_error_code(),
				'message' => $definition->get_error_message(),
			),
		);
	}

	/**
	 * Derive an opaque optimistic-concurrency token from the stored contract.
	 *
	 * @param WP_Post $post Field-group storage post.
	 * @return string SHA-256 revision token.
	 */
	public static function revision( $post ) {
		return hash( 'sha256', $post->post_title . "\n" . $post->post_status . "\n" . $post->post_content );
	}

	/**
	 * Resolve a field-group storage post by ID.
	 *
	 * @param int $id Candidate post ID.
	 * @return WP_Post|null Matching storage post or null.
	 */

	public static function find( $id ) {
		$post = get_post( absint( $id ) );
		return $post && WPHAVE_Content_Models::POST_TYPE === $post->post_type ? $post : null;
	}

	/**
	 * Insert or update one already validated field-group definition.
	 *
	 * @param int   $id         Existing storage post ID, or zero to create.
	 * @param string $title      Sanitized field-group title.
	 * @param array  $definition Validated schema definition.
	 * @param bool   $active     Whether the group should be published.
	 * @return int|WP_Error Saved post ID or persistence error.
	 */

	public static function save( $id, $title, $definition, $active ) {
		if ( ! is_array( $definition ) ) {
			return new WP_Error( 'wphave_content_model_persistence_contract_invalid', __( 'Only a validated field-group definition can be persisted.', 'wphave' ) );
		}
		$encoded = WPHAVE_Content_Model_Definition_Codec::encode_for_wordpress( $definition );
		if ( is_wp_error( $encoded ) ) {
			return $encoded;
		}

		return wp_insert_post( array(
			'ID'           => absint( $id ),
			'post_type'    => WPHAVE_Content_Models::POST_TYPE,
			'post_title'   => $title,
			'post_content' => $encoded,
			'post_status'  => $active ? 'publish' : 'draft',
		), true );
	}

	/**
	 * Capture the complete mutable storage row before an update.
	 *
	 * @param WP_Post $post Existing field-group storage post.
	 * @return array Exact fields required for hook-independent recovery.
	 */
	public static function snapshot( $post ) {
		return array(
			'post_title'        => $post->post_title,
			'post_content'      => $post->post_content,
			'post_status'       => $post->post_status,
			'post_name'         => $post->post_name,
			'post_modified'     => $post->post_modified,
			'post_modified_gmt' => $post->post_modified_gmt,
		);
	}

	/**
	 * Verify immutable schema bytes around status-only lifecycle mutations.
	 *
	 * Trash and restore must never rewrite a definition, including one that is too
	 * damaged or too new for the current validator. Comparing raw storage keeps the
	 * recovery path usable without interpreting untrusted schema content.
	 *
	 * @param WP_Post|null $post            Re-read storage post.
	 * @param array        $snapshot        Pre-mutation snapshot.
	 * @param string       $expected_status Required post status after mutation.
	 * @return bool Whether identity and schema bytes remained unchanged.
	 */
	public static function matches_snapshot( $post, array $snapshot, $expected_status ) {
		return $post
			&& WPHAVE_Content_Models::POST_TYPE === $post->post_type
			&& $expected_status === $post->post_status
			&& $snapshot['post_title'] === $post->post_title
			&& $snapshot['post_content'] === $post->post_content
			&& $snapshot['post_name'] === $post->post_name;
	}

	/**
	 * Verify that filters and hooks did not alter the validated write contract.
	 *
	 * @param WP_Post|null $post       Re-read stored post.
	 * @param string       $title      Expected title.
	 * @param array        $definition Expected normalized definition.
	 * @param bool         $active     Expected activation state.
	 * @return bool Whether the complete persistence postcondition holds.
	 */
	public static function matches( $post, $title, array $definition, $active ) {
		$stored = $post ? self::definition( $post ) : null;
		return $post
			&& ! is_wp_error( $stored )
			&& (string) $post->post_title === (string) $title
			&& ( $active ? 'publish' : 'draft' ) === $post->post_status
			&& wp_json_encode( $stored ) === wp_json_encode( $definition );
	}

	/**
	 * Restore a previously captured row without re-entering mutation hooks.
	 *
	 * This recovery path is used only after a failed postcondition. The direct
	 * update prevents the same third-party filter from corrupting the rollback.
	 *
	 * @param int   $id       Field-group storage ID.
	 * @param array $snapshot Exact snapshot returned by snapshot().
	 * @return bool Whether the storage row was restored.
	 */
	public static function restore( $id, array $snapshot ) {
		global $wpdb;
		$restored = false !== $wpdb->update(
			$wpdb->posts,
			array(
				'post_title'        => $snapshot['post_title'],
				'post_content'      => $snapshot['post_content'],
				'post_status'       => $snapshot['post_status'],
				'post_name'         => $snapshot['post_name'],
				'post_modified'     => $snapshot['post_modified'],
				'post_modified_gmt' => $snapshot['post_modified_gmt'],
			),
			array( 'ID' => absint( $id ) ),
			array( '%s', '%s', '%s', '%s', '%s', '%s' ),
			array( '%d' )
		);
		clean_post_cache( absint( $id ) );
		self::invalidate();
		return $restored;
	}

	/**
	 * Trash a definition while deliberately retaining all content values.
	 *
	 * @param int $id Field-group storage post ID.
	 * @return WP_Post|false|null Trashed post, false on failure, or null when absent.
	 */

	public static function trash( $id ) {
		return wp_trash_post( absint( $id ) );
	}

	/**
	 * Restore a trashed definition to an explicitly inactive runtime state.
	 *
	 * @param int $id Field-group storage post ID.
	 * @return WP_Post|false|null Restored post, false on failure, or null when absent.
	 */
	public static function restore_from_trash( $id ) {
		$post = wp_untrash_post( absint( $id ) );
		if ( ! $post ) {
			return $post;
		}

		if ( 'draft' !== $post->post_status ) {
			$updated = wp_update_post(
				array(
					'ID'          => $post->ID,
					'post_status' => 'draft',
				),
				true
			);
			if ( is_wp_error( $updated ) ) {
				return false;
			}
			$post = get_post( $post->ID );
		}

		return $post;
	}

	/** Invalidate request and persistent definition caches atomically by generation.
	 *
	 * @return void
	 */

	public static function invalidate() {
		global $wpdb;
		self::$memory = array();
		if ( false === get_option( self::GENERATION_OPTION, false ) ) {
			add_option( self::GENERATION_OPTION, 1, '', false );
		}
		// CACHE INVARIANT: SQL arithmetic prevents concurrent invalidations from
		// collapsing into one read-modify-write generation and reviving stale data.
		$wpdb->query( $wpdb->prepare(
			"UPDATE {$wpdb->options} SET option_value = CAST(option_value AS UNSIGNED) + 1 WHERE option_name = %s",
			self::GENERATION_OPTION
		) );
		wp_cache_delete( self::GENERATION_OPTION, 'options' );
	}
}
