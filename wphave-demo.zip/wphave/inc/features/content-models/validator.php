<?php

/** Validates and migrates WPHAVE Content Model definitions. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Reconstruct trusted field-group definitions from untrusted stored or REST data. */

final class WPHAVE_Content_Model_Validator {
	const SCHEMA_VERSION = WPHAVE_Content_Model_Schema::CURRENT_VERSION;
	const MAX_FIELDS = 100;
	const MAX_POST_TYPES = 50;
	const MAX_RETIRED_FIELDS = 1000;

	/**
	 * Reject malformed or excessive input before any WordPress sanitizer sees it.
	 *
	 * @param mixed $definition Untrusted schema payload.
	 * @return true|WP_Error True for an acceptable outer shape, or an error.
	 */

	private static function validate_shape( $definition ) {
		if ( ! is_array( $definition ) ) {
			return new WP_Error( 'wphave_content_model_invalid', __( 'A valid field group is required.', 'wphave' ) );
		}
		// VERSION INVARIANT: only an actual JSON integer identifies a schema.
		// Coercing arbitrary strings to version zero could reinterpret malformed or
		// future data as a legacy definition and migrate it destructively.
		if ( isset( $definition['schemaVersion'] ) && ( ! is_int( $definition['schemaVersion'] ) || $definition['schemaVersion'] < 0 ) ) {
			return new WP_Error( 'wphave_content_model_schema_version_invalid', __( 'The field group schema version is invalid.', 'wphave' ) );
		}

		$scalar_properties = array( 'description', 'targetType', 'editorDisplay' );
		foreach ( $scalar_properties as $property ) {
			if ( isset( $definition[ $property ] ) && ! is_scalar( $definition[ $property ] ) ) {
				return new WP_Error( 'wphave_content_model_property_invalid', __( 'The field group contains an invalid property.', 'wphave' ) );
			}
		}

		if ( isset( $definition['fields'] ) && ! is_array( $definition['fields'] ) ) {
			return new WP_Error( 'wphave_content_model_fields_invalid', __( 'Fields must be provided as a list.', 'wphave' ) );
		}
		if ( count( $definition['fields'] ?? array() ) > self::MAX_FIELDS ) {
			return new WP_Error( 'wphave_content_model_fields_limit', __( 'A field group can contain at most 100 fields.', 'wphave' ) );
		}
		if ( isset( $definition['retiredFields'] ) && ! is_array( $definition['retiredFields'] ) ) {
			return new WP_Error( 'wphave_content_model_retired_fields_invalid', __( 'Retired field identities must be provided as a list.', 'wphave' ) );
		}
		if ( count( $definition['retiredFields'] ?? array() ) > self::MAX_RETIRED_FIELDS ) {
			return new WP_Error( 'wphave_content_model_retired_fields_limit', __( 'The field group contains too many retired field identities.', 'wphave' ) );
		}

		if ( isset( $definition['postTypes'] ) && ! is_array( $definition['postTypes'] ) ) {
			return new WP_Error( 'wphave_content_model_post_types_invalid', __( 'Content types must be provided as a list.', 'wphave' ) );
		}
		if ( count( $definition['postTypes'] ?? array() ) > self::MAX_POST_TYPES ) {
			return new WP_Error( 'wphave_content_model_post_types_limit', __( 'A field group can target at most 50 content types.', 'wphave' ) );
		}
		foreach ( $definition['postTypes'] ?? array() as $post_type ) {
			if ( ! is_string( $post_type ) ) {
				return new WP_Error( 'wphave_content_model_post_type_invalid', __( 'Every content type must be a valid identifier.', 'wphave' ) );
			}
		}

		if ( isset( $definition['presentation'] ) && ! is_array( $definition['presentation'] ) ) {
			return new WP_Error( 'wphave_content_model_presentation_invalid', __( 'The field layout is invalid.', 'wphave' ) );
		}

		return true;
	}

	/**
	 * Migrate and normalize a complete field-group definition.
	 *
	 * @param mixed $definition Untrusted schema payload.
	 * @return array|WP_Error Trusted current-version definition or an error.
	 */

	public static function sanitize_definition($definition) {
		$valid = self::validate_shape($definition);
		if (is_wp_error($valid)) {
			return $valid;
		}
		$definition = WPHAVE_Content_Model_Schema::assert_current($definition);
		if (is_wp_error($definition)) {
			return $definition;
		}

		$fields = [];
		$keys = [];
		$ids = [];
		foreach ($definition['fields'] ?? [] as $field) {
			$field = self::sanitize_field($field);
			if (is_wp_error($field)) {
				return $field;
			}
			if (isset($keys[$field['key']])) {
				return new WP_Error(
					'wphave_content_model_duplicate_field',
					__('Field keys must be unique within a field group.', 'wphave')
				);
			}
			if (isset($ids[$field['id']])) {
				return new WP_Error(
					'wphave_content_model_duplicate_field_id',
					__('Field identifiers must be unique within a field group.', 'wphave')
				);
			}
			$keys[$field['key']] = true;
			$ids[$field['id']] = true;
			$fields[] = $field;
		}
		$fields = WPHAVE_Content_Model_Conditional_Logic::normalize_fields($fields);
		if (is_wp_error($fields)) {
			return $fields;
		}

		$post_types = array_values(
			array_unique(array_filter(array_map('sanitize_key', $definition['postTypes'] ?? [])))
		);
		$retired_fields = self::sanitize_retired_fields(
			$definition['retiredFields'] ?? [],
			$ids,
			$keys
		);
		if (is_wp_error($retired_fields)) {
			return $retired_fields;
		}
		$presentation = WPHAVE_Content_Model_Presentation::normalize(
			$definition['presentation'] ?? [],
			$fields
		);
		if (is_wp_error($presentation)) {
			return $presentation;
		}

		return [
			'schemaVersion' => self::SCHEMA_VERSION,
			'targetType' => 'post_meta',
			'lifecycle' => ['removedValues' => 'retain'],
			'description' => sanitize_textarea_field($definition['description'] ?? ''),
			'editorDisplay' => in_array($definition['editorDisplay'] ?? '', ['flow', 'tab'], true)
				? $definition['editorDisplay']
				: 'flow',
			'postTypes' => $post_types,
			'fields' => $fields,
			'retiredFields' => $retired_fields,
			'presentation' => $presentation
		];
	}

	/**
	 * Normalize non-executable identities reserved by removed fields.
	 *
	 * @param array $retired_fields Submitted retired field identities.
	 * @param array $active_ids     Active field IDs used for collision checks.
	 * @param array $active_keys    Active field keys used for collision checks.
	 * @return array|WP_Error Normalized tombstones or a conflict error.
	 */

	private static function sanitize_retired_fields( array $retired_fields, array $active_ids, array $active_keys ) {
		$normalized = array();
		$ids = $active_ids;
		$keys = $active_keys;
		foreach ( $retired_fields as $field ) {
			if ( ! is_array( $field ) ) {
				return new WP_Error( 'wphave_content_model_retired_field_invalid', __( 'A retired field identity is invalid.', 'wphave' ) );
			}
			foreach ( array( 'id', 'key', 'type' ) as $property ) {
				if ( ! isset( $field[ $property ] ) || ! is_string( $field[ $property ] ) ) {
					return new WP_Error( 'wphave_content_model_retired_field_invalid', __( 'A retired field identity is invalid.', 'wphave' ) );
				}
			}
			$id = sanitize_key( $field['id'] );
			$key = sanitize_key( $field['key'] );
			$type = sanitize_key( $field['type'] );
			if ( '' === $id || ! preg_match( '/^[a-z][a-z0-9_]{1,63}$/', $key ) || '' === $type || isset( $ids[ $id ] ) || isset( $keys[ $key ] ) ) {
				return new WP_Error( 'wphave_content_model_retired_field_conflict', __( 'Retired field identities must be unique and cannot overlap active fields.', 'wphave' ) );
			}
			$ids[ $id ] = true;
			$keys[ $key ] = true;
			$normalized[] = array( 'id' => $id, 'key' => $key, 'type' => $type );
		}
		return $normalized;
	}

	/**
	 * Validate and normalize one supported scalar field definition.
	 *
	 * @param mixed $field Untrusted field definition.
	 * @return array|WP_Error Normalized field contract or validation error.
	 */

	private static function sanitize_field( $field ) {
		if ( ! is_array( $field ) ) {
			return new WP_Error( 'wphave_content_model_field_invalid', __( 'Every field must be a valid object.', 'wphave' ) );
		}
		foreach ( array( 'id', 'label', 'key', 'type', 'description', 'caption', 'default', 'required' ) as $property ) {
			if ( isset( $field[ $property ] ) && ! is_scalar( $field[ $property ] ) ) {
				return new WP_Error( 'wphave_content_model_field_invalid', __( 'Every field property must have the expected type.', 'wphave' ) );
			}
		}
		if ( isset( $field['settings'] ) && ! is_array( $field['settings'] ) ) {
			return new WP_Error( 'wphave_content_model_field_settings_invalid', __( 'Field settings must be provided as an object.', 'wphave' ) );
		}
		if ( isset( $field['conditionalLogic'] ) && ! is_array( $field['conditionalLogic'] ) ) {
			return new WP_Error( 'wphave_content_model_field_conditions_invalid', __( 'Field conditions must be provided as an object.', 'wphave' ) );
		}
		if ( isset( $field['required'] ) && ! is_bool( $field['required'] ) ) {
			return new WP_Error( 'wphave_content_model_field_required_invalid', __( 'The required field setting must be a boolean.', 'wphave' ) );
		}

		$label = sanitize_text_field( $field['label'] ?? '' );
		$key = sanitize_key( $field['key'] ?? '' );
		$type = sanitize_key( $field['type'] ?? 'text' );
		if ( '' === $label || ! preg_match( '/^[a-z][a-z0-9_]{1,63}$/', $key ) || ! WPHAVE_Content_Model_Field_Type_Registry::has( $type ) ) {
			return new WP_Error( 'wphave_content_model_field_invalid', __( 'Each field needs a label, a valid unique key and a supported type.', 'wphave' ) );
		}

		$field = array(
			'id'          => sanitize_key( $field['id'] ?? '' ) ?: wp_generate_uuid4(),
			'label'       => $label,
			'key'         => $key,
			'type'        => $type,
			'description' => sanitize_textarea_field( $field['description'] ?? '' ),
			'caption'     => sanitize_textarea_field( $field['caption'] ?? '' ),
			'required'    => ! empty( $field['required'] ),
			'default'     => $field['default'] ?? '',
			'options'     => $field['options'] ?? array(),
			'settings'    => $field['settings'] ?? array(),
			'conditionalLogic' => $field['conditionalLogic'] ?? WPHAVE_Rules_Engine::disabled(),
		);
		$field = WPHAVE_Content_Model_Field_Type_Registry::normalize_definition( $type, $field );
		if ( is_wp_error( $field ) ) {
			return $field;
		}
		// DATA INVARIANT: an invalid non-empty default is not an instruction to
		// clear the default. Definition writes reject that ambiguity completely.
		if ( '' !== $field['default'] ) {
			$default = WPHAVE_Content_Model_Field_Type_Registry::normalize_submitted_value( $type, $field['default'], $field );
			if ( is_wp_error( $default ) ) {
				return $default;
			}
			$field['default'] = $default;
		}
		return $field;
	}

}
