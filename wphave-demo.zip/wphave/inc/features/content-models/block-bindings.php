<?php
/** Scalar Content Field binding contract shared by registration and frontend resolution. */
if (!defined('ABSPATH')) {
	exit();
}

final class WPHAVE_Content_Model_Block_Bindings {
	/** Derive supported targets from block metadata; design and structured attributes stay private. */
	public static function supported_attributes($supported, $name) {
		if (!is_string($name) || strpos($name, 'wphave/') !== 0) {
			return $supported;
		}
		$block = WP_Block_Type_Registry::get_instance()->get_registered($name);
		foreach ($block->attributes ?? [] as $key => $definition) {
			if (self::is_target($definition)) {
				$supported[] = $key;
			}
		}
		return array_values(array_unique($supported));
	}

	/** Content roles are necessary but object and array shapes need dedicated adapters. */
	public static function is_target($definition) {
		return 'content' === ($definition['role'] ?? null) &&
			in_array(
				$definition['type'] ?? null,
				['string', 'rich-text', 'number', 'integer', 'boolean'],
				true,
			);
	}

	/** Adapt only validated, readable repository values; null retains WordPress fallback behavior. */
	public static function resolve($value, $definition, $field) {
		if (
			null === $value ||
			!$field ||
			!self::is_target($definition) ||
			in_array($field['type'], ['gallery', 'multi_select', 'checkbox_group'], true)
		) {
			return null;
		}
		$type = $definition['type'];
		if (in_array($type, ['string', 'rich-text'], true)) {
			return (string) $value;
		}
		if ('boolean' === $type) {
			return 'toggle' === $field['type'] ? '1' === $value : null;
		}
		$contract = WPHAVE_Content_Model_Field_Type_Registry::get($field['type']);
		if ($contract instanceof WPHAVE_Content_Model_Abstract_Reference_Field_Type) {
			return preg_match('/^[1-9]\\d*$/', (string) $value) &&
				(float) $value <= 9007199254740991
				? (int) $value
				: null;
		}
		if ('number' !== $field['type'] || !is_numeric($value) || !is_finite((float) $value)) {
			return null;
		}
		$number = 0 + $value;
		return 'integer' === $type &&
			(floor($number) !== (float) $number || abs($number) > 9007199254740991)
			? null
			: $number;
	}
}
