<?php

/** REST API for WPHAVE field groups and post field values. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/usage.php';

/**
 * Expose permission-checked field-group schemas and allowlisted content values.
 *
 * Every write is size-bounded, shape-validated and serialized through the
 * database-backed mutex before it reaches WordPress persistence.
 */

final class WPHAVE_Content_Models_REST_Controller {
	const MAX_SCHEMA_BODY_BYTES = 262144;
	const MAX_VALUES_BODY_BYTES = 65536;
	const MAX_VALUE_BYTES = 16384;

	/** Register REST route setup on the WordPress REST lifecycle.
	 *
	 * @return void
	 */

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/** Check whether the current user may list field-group schemas.
	 *
	 * @return bool Whether schema viewing is allowed.
	 */

	public static function can_view() {
		return WPHAVE_Content_Model_Access_Policy::can_view_schemas();
	}

	/** Check whether the current user may create or edit schemas.
	 *
	 * @return bool Whether schema management is allowed.
	 */

	public static function can_manage() {
		return WPHAVE_Content_Model_Access_Policy::can_edit_schemas();
	}

	private static function require_schema_view() {
		// AUTHORIZATION INVARIANT: Schema callbacks expose internal field contracts.
		// REST permission callbacks are an early gate; every public schema read
		// repeats the canonical view policy before repository or translation work.
		if ( ! self::can_view() ) {
			return new WP_Error(
				'wphave_content_models_view_forbidden',
				__( 'You are not allowed to view Content Models.', 'wphave' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	private static function require_schema_manage() {
		// AUTHORIZATION INVARIANT: Schema lifecycle callbacks repeat the canonical
		// edit policy before acquiring a lock, validating input or changing storage.
		if ( ! self::can_manage() ) {
			return new WP_Error(
				'wphave_content_models_manage_forbidden',
				__( 'You are not allowed to manage Content Models.', 'wphave' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Release projected schema data only while view authority remains current.
	 *
	 * @param mixed $data Prepared response data.
	 * @return WP_REST_Response|WP_Error
	 */
	private static function authorized_schema_response( $data ) {
		// AUTHORIZATION/SCHEMA-READ INVARIANT: Repository queries, usage discovery and translation filters cannot lease schema-view authority across private response projection.
		$authorization = self::require_schema_view();
		return is_wp_error( $authorization ) ? $authorization : rest_ensure_response( $data );
	}

	private static function require_value_access( $request ) {
		// AUTHORIZATION INVARIANT: Native edit_post authority alone cannot disclose
		// or mutate Content Field values. Recheck the feature policy and exact
		// attacker-controlled post ID immediately before reading or locking values.
		if ( ! self::can_edit_post( $request ) ) {
			return new WP_Error(
				'wphave_content_model_values_forbidden',
				__( 'You are not allowed to edit Content Fields for this item.', 'wphave' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Release projected field values only while exact-object authority is current.
	 *
	 * @param WP_REST_Request $request Current object request.
	 * @param mixed           $data    Prepared response data.
	 * @return WP_REST_Response|WP_Error
	 */
	private static function authorized_value_response( $request, $data ) {
		// AUTHORIZATION/VALUE-READ INVARIANT: Registry, metadata and translation filters cannot lease feature or mapped object authority across private value projection.
		$authorization = self::require_value_access( $request );
		return is_wp_error( $authorization ) ? $authorization : rest_ensure_response( $data );
	}

	/** Register schema and content-value REST endpoints.
	 *
	 * @return void
	 */

	public static function register_routes() {
		// ADMISSION INVARIANT: The existing schema/value callback budgets are too
		// late to protect WordPress' REST JSON decoder. Register their exact raw
		// wire limits before route argument validation can materialize payloads.
		WPHAVE_REST_Body_Budget::protect(
			'POST',
			'~^/wphave/v1/content-models$~D',
			self::MAX_SCHEMA_BODY_BYTES
		);
		foreach ( array( 'POST', 'PUT', 'PATCH' ) as $method ) {
			WPHAVE_REST_Body_Budget::protect(
				$method,
				'~^/wphave/v1/content-models/[0-9]+$~D',
				self::MAX_SCHEMA_BODY_BYTES
			);
			WPHAVE_REST_Body_Budget::protect(
				$method,
				'~^/wphave/v1/content-models/post/[0-9]+$~D',
				self::MAX_VALUES_BODY_BYTES
			);
		}
		register_rest_route( 'wphave/v1', '/content-models', array(
			array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( __CLASS__, 'index' ), 'permission_callback' => array( __CLASS__, 'can_view' ) ),
			array( 'methods' => WP_REST_Server::CREATABLE, 'callback' => array( __CLASS__, 'create' ), 'permission_callback' => array( __CLASS__, 'can_manage' ) ),
		) );
		register_rest_route( 'wphave/v1', '/content-models/translations', array(
			array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( __CLASS__, 'translations' ), 'permission_callback' => array( __CLASS__, 'can_view' ) ),
		) );
		register_rest_route( 'wphave/v1', '/content-models/(?P<id>\d+)', array(
			array( 'methods' => WP_REST_Server::EDITABLE, 'callback' => array( __CLASS__, 'update' ), 'permission_callback' => array( __CLASS__, 'can_manage' ) ),
			array( 'methods' => WP_REST_Server::DELETABLE, 'callback' => array( __CLASS__, 'delete' ), 'permission_callback' => array( __CLASS__, 'can_manage' ) ),
		) );
		register_rest_route( 'wphave/v1', '/content-models/(?P<id>\d+)/usage', array(
			array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( __CLASS__, 'usage' ), 'permission_callback' => array( __CLASS__, 'can_view' ) ),
		) );
		register_rest_route( 'wphave/v1', '/content-models/(?P<id>\d+)/restore', array(
			array( 'methods' => WP_REST_Server::CREATABLE, 'callback' => array( __CLASS__, 'restore' ), 'permission_callback' => array( __CLASS__, 'can_manage' ) ),
		) );
		register_rest_route( 'wphave/v1', '/content-models/post/(?P<id>\d+)', array(
			array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( __CLASS__, 'post_fields' ), 'permission_callback' => array( __CLASS__, 'can_edit_post' ) ),
			array( 'methods' => WP_REST_Server::EDITABLE, 'callback' => array( __CLASS__, 'save_post_fields' ), 'permission_callback' => array( __CLASS__, 'can_edit_post' ) ),
		) );
	}

	/** Return a bounded, non-executable Gettext template for field presentation copy. */
	public static function translations() {
		$authorization = self::require_schema_view();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		return self::authorized_schema_response( array(
			'filename' => 'wphave-content-fields.pot',
			'content'  => WPHAVE_Content_Model_Translations::generate_pot(),
		) );
	}

	/** Return bounded, permission-filtered value and block-binding usage. */
	public static function usage( $request ) {
		$authorization = self::require_schema_view();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$post = WPHAVE_Content_Model_Repository::find( absint( $request['id'] ) );
		if ( ! $post ) {
			return new WP_Error( 'wphave_content_model_not_found', __( 'Field group not found.', 'wphave' ), array( 'status' => 404 ) );
		}
		$group = WPHAVE_Content_Model_Repository::definition( $post );
		if ( is_wp_error( $group ) ) {
			return new WP_Error( 'wphave_content_model_usage_unavailable', __( 'Usage cannot be inspected for a damaged field group.', 'wphave' ), array( 'status' => 409 ) );
		}
		$group = WPHAVE_Content_Model_Translations::translate_group( array( 'id' => $post->ID, 'title' => $post->post_title ) + $group );
		return self::authorized_schema_response( WPHAVE_Content_Model_Usage::for_group( $group ) );
	}

	/**
	 * Authorize value access against both the feature and target content item.
	 *
	 * @param WP_REST_Request $request REST request containing the content ID.
	 * @return bool Whether the current user may edit registered values.
	 */

	public static function can_edit_post( $request ) {
		return WPHAVE_Content_Model_Access_Policy::can_edit_values( absint( $request['id'] ) );
	}

	/**
	 * Convert a storage post into a validated REST field-group representation.
	 *
	 * @param WP_Post $post Field-group storage post.
	 * @return array|null Prepared group or null when its schema is invalid.
	 */

	private static function prepare( $post ) {
		return WPHAVE_Content_Model_Repository::prepare_for_management( $post );
	}

	/** List manageable groups, eligible content types and registered field types.
	 *
	 * @return WP_REST_Response REST response for the management workspace.
	 */

	public static function index() {
		$authorization = self::require_schema_view();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$items = WPHAVE_Content_Model_Repository::all_for_management();
		$post_types = array();
		foreach ( WPHAVE_Content_Models::supported_post_types() as $post_type ) {
			$post_types[] = array( 'value' => $post_type->name, 'label' => $post_type->labels->name );
		}
		return self::authorized_schema_response( array( 'items' => array_values( $items ), 'postTypes' => $post_types, 'fieldTypes' => WPHAVE_Content_Model_Field_Type_Registry::names() ) );
	}

	/**
	 * Validate and normalize an incoming field-group write payload.
	 *
	 * Server-owned retired identities are stripped here and reconstructed during
	 * writes. Active cross-group key collisions are rejected before persistence;
	 * inactive drafts remain independently editable until activation.
	 *
	 * @param WP_REST_Request $request    Incoming schema request.
	 * @param int             $current_id Existing group ID excluded from collisions.
	 * @return array|WP_Error Normalized title, status and definition, or an error.
	 */

	private static function payload( $request, $current_id = 0 ) {
		if ( strlen( (string) $request->get_body() ) > self::MAX_SCHEMA_BODY_BYTES ) {
			return new WP_Error( 'wphave_content_model_too_large', __( 'The field group exceeds the 256 KB limit.', 'wphave' ), array( 'status' => 413 ) );
		}
		$data = $request->get_json_params();
		if ( ! is_array( $data ) ) {
			return new WP_Error( 'wphave_content_model_json_invalid', __( 'The field group request must contain a valid JSON object.', 'wphave' ), array( 'status' => 400 ) );
		}
		if ( isset( $data['title'] ) && ! is_scalar( $data['title'] ) ) {
			return new WP_Error( 'wphave_content_model_title_invalid', __( 'The field group title is invalid.', 'wphave' ), array( 'status' => 400 ) );
		}
		if ( isset( $data['active'] ) && ! is_bool( $data['active'] ) ) {
			return new WP_Error( 'wphave_content_model_status_invalid', __( 'The field group status must be a boolean.', 'wphave' ), array( 'status' => 400 ) );
		}
		$title = sanitize_text_field( $data['title'] ?? '' );
		if ( '' === $title ) {
			return new WP_Error( 'wphave_content_model_title_required', __( 'Enter a field group title.', 'wphave' ), array( 'status' => 400 ) );
		}
		// Retired identities are server-maintained history. Clients may echo the
		// response but can neither invent tombstones nor discard existing ones.
		$definition_data = $data;
		$definition_data['retiredFields'] = array();
		$definition = WPHAVE_Content_Model_Validator::sanitize_definition( $definition_data );
		if ( is_wp_error( $definition ) ) {
			$definition->add_data( array( 'status' => 400 ) );
			return $definition;
		}
		$active = ! empty( $data['active'] );
		if ( $active && ( ! $definition['postTypes'] || ! $definition['fields'] ) ) {
			return new WP_Error( 'wphave_content_model_active_schema_empty', __( 'Active field groups need at least one content type and one field.', 'wphave' ), array( 'status' => 400 ) );
		}
		foreach ( $definition['postTypes'] as $post_type ) {
			if ( ! WPHAVE_Content_Models::supports_post_type( $post_type ) ) {
				return new WP_Error( 'wphave_content_model_post_type_invalid', __( 'A selected post type is unavailable.', 'wphave' ), array( 'status' => 400 ) );
			}
		}

		// RUNTIME INVARIANT: only active groups participate in the field registry.
		// Drafts may intentionally prepare overlapping schemas, but activating one
		// must remain collision-free against every other active group. The shared
		// write lock serializes this check with persistence and closes activation races.
		if ( $active ) {
			foreach ( get_posts( array(
				'post_type' => WPHAVE_Content_Models::POST_TYPE,
				'post_status' => 'publish',
				'posts_per_page' => -1,
				'post__not_in' => $current_id ? array( $current_id ) : array(),
				'no_found_rows' => true,
			) ) as $other_post ) {
				$other = WPHAVE_Content_Model_Repository::definition( $other_post );
				if ( is_wp_error( $other ) || ! array_intersect( $definition['postTypes'], $other['postTypes'] ) ) {
					continue;
				}
				$duplicate_keys = array_values( array_intersect( wp_list_pluck( $definition['fields'], 'key' ), wp_list_pluck( $other['fields'], 'key' ) ) );
				if ( $duplicate_keys ) {
					return new WP_Error(
						'wphave_content_model_field_collision',
						sprintf(
							/* translators: 1: field key, 2: field group title. */
							__( 'The field key “%1$s” is already active in the field group “%2$s”.', 'wphave' ),
							$duplicate_keys[0],
							$other_post->post_title
						),
						array(
							'status'   => 409,
							'fieldKey' => $duplicate_keys[0],
							'groupId'  => $other_post->ID,
						)
					);
				}
			}
		}
		return array( 'title' => $title, 'active' => $active, 'definition' => $definition );
	}

	/**
	 * Serialize and persist a schema while preserving immutable field identities.
	 *
	 * Removed fields become permanent tombstones so retained meta can never be
	 * reinterpreted by a later field with the same ID or key.
	 *
	 * @param WP_REST_Request $request Incoming schema request.
	 * @param int             $id      Existing field-group ID, or zero to create.
	 * @return WP_REST_Response|WP_Error Saved group response or failure.
	 */

	private static function write( $request, $id = 0 ) {
		$lock = WPHAVE_Content_Model_Write_Lock::acquire();
		if ( is_wp_error( $lock ) ) {
			return $lock;
		}

		try {
			$payload = self::payload( $request, $id );
			if ( is_wp_error( $payload ) ) {
				return $payload;
			}
			$current = $id ? WPHAVE_Content_Model_Repository::find( $id ) : null;
			if ( $id && ! $current ) {
				return new WP_Error( 'wphave_content_model_not_found', __( 'Field group not found.', 'wphave' ), array( 'status' => 404 ) );
			}
			$snapshot = $current ? WPHAVE_Content_Model_Repository::snapshot( $current ) : null;
			if ( $id ) {
				$expected_revision = sanitize_text_field( $request->get_param( 'revision' ) ?? '' );
				if ( ! hash_equals( WPHAVE_Content_Model_Repository::revision( $current ), $expected_revision ) ) {
					return new WP_Error( 'wphave_content_model_revision_conflict', __( 'This field group changed after it was opened. Reload it before saving to avoid overwriting newer work.', 'wphave' ), array( 'status' => 409 ) );
				}
			}
			$was_active = $current && 'publish' === $current->post_status;
			$changing_activation = (bool) $payload['active'] !== (bool) $was_active;
			if ( $changing_activation && ! WPHAVE_Content_Model_Access_Policy::can_activate_schemas() ) {
				return new WP_Error( 'wphave_content_model_activation_forbidden', __( 'You cannot change field-group activation.', 'wphave' ), array( 'status' => 403 ) );
			}
			if ( $id ) {
				$current_definition = WPHAVE_Content_Model_Repository::definition( $current );
				if ( is_wp_error( $current_definition ) ) {
					return new WP_Error( 'wphave_content_model_recovery_required', __( 'This stored field group is damaged and cannot be overwritten through the regular editor.', 'wphave' ), array( 'status' => 409 ) );
				}
				if ( ! is_wp_error( $current_definition ) ) {
					$current_keys = wp_list_pluck( $current_definition['fields'], 'key', 'id' );
					$current_types = wp_list_pluck( $current_definition['fields'], 'type', 'id' );
					$current_ids_by_key = wp_list_pluck( $current_definition['fields'], 'id', 'key' );
					$retired_ids_by_key = wp_list_pluck( $current_definition['retiredFields'], 'id', 'key' );
					$retired_keys_by_id = wp_list_pluck( $current_definition['retiredFields'], 'key', 'id' );
					foreach ( $payload['definition']['fields'] as $field ) {
						if ( isset( $retired_ids_by_key[ $field['key'] ] ) || isset( $retired_keys_by_id[ $field['id'] ] ) ) {
							return new WP_Error( 'wphave_content_model_field_retired', __( 'Retired field identities cannot be reused. Create the field with a new key.', 'wphave' ), array( 'status' => 409 ) );
						}
						if ( isset( $current_keys[ $field['id'] ] ) && $current_keys[ $field['id'] ] !== $field['key'] ) {
							return new WP_Error( 'wphave_content_model_key_immutable', __( 'Saved field keys cannot be changed. Add a new field to preserve existing content and bindings.', 'wphave' ), array( 'status' => 409 ) );
						}
						if ( isset( $current_types[ $field['id'] ] ) && $current_types[ $field['id'] ] !== $field['type'] ) {
							return new WP_Error( 'wphave_content_model_type_immutable', __( 'Saved field types cannot be changed. Add a new field to preserve the existing data contract.', 'wphave' ), array( 'status' => 409 ) );
						}
						if ( isset( $current_ids_by_key[ $field['key'] ] ) && $current_ids_by_key[ $field['key'] ] !== $field['id'] ) {
							return new WP_Error( 'wphave_content_model_identity_immutable', __( 'Saved field keys remain bound to their original field identifiers. Use a new key for a new field.', 'wphave' ), array( 'status' => 409 ) );
						}
					}

					$incoming_ids = array_fill_keys( wp_list_pluck( $payload['definition']['fields'], 'id' ), true );
					$retired_by_id = array();
					foreach ( $current_definition['retiredFields'] as $retired_field ) {
						$retired_by_id[ $retired_field['id'] ] = $retired_field;
					}
					foreach ( $current_definition['fields'] as $current_field ) {
						if ( ! isset( $incoming_ids[ $current_field['id'] ] ) ) {
							$retired_by_id[ $current_field['id'] ] = array(
								'id'   => $current_field['id'],
								'key'  => $current_field['key'],
								'type' => $current_field['type'],
							);
						}
					}
					if ( count( $retired_by_id ) > WPHAVE_Content_Model_Validator::MAX_RETIRED_FIELDS ) {
						return new WP_Error( 'wphave_content_model_retired_fields_limit', __( 'No more field identities can be retired from this group.', 'wphave' ), array( 'status' => 409 ) );
					}
					$payload['definition']['retiredFields'] = array_values( $retired_by_id );
				}
			}
			// AUTHORIZATION/PERSISTENCE INVARIANT: Lock acquisition and schema validation cross extensible WordPress boundaries, so edit authority must be current immediately before the repository write.
			$authorization = self::require_schema_manage();
			if ( is_wp_error( $authorization ) ) {
				return $authorization;
			}
			$post_id = WPHAVE_Content_Model_Repository::save( $id, $payload['title'], $payload['definition'], $payload['active'] );
			if ( is_wp_error( $post_id ) ) {
				return $post_id;
			}
			$saved_post = get_post( $post_id );
			// DATA INVARIANT: a successful WordPress call is insufficient. Verify the
			// complete postcondition and roll back if a hook changed persisted data.
			if ( ! WPHAVE_Content_Model_Repository::matches( $saved_post, $payload['title'], $payload['definition'], $payload['active'] ) ) {
				// CREATE ROLLBACK INVARIANT: A mismatched return ID is not proof
				// that this request still owns the stored definition. Keep an
				// unverified new record for reconciliation instead of deleting it.
				if ( ! $snapshot ) {
					return new WP_Error( 'wphave_content_model_write_recovery_failed', __( 'The field group write could not be verified and automatic recovery failed. The stored record requires attention.', 'wphave' ), array( 'status' => 500, 'post_id' => $post_id ) );
				}
				// UPDATE RECOVERY INVARIANT: A hook may have changed the storage
				// post's type. Never write old field-group bytes into a foreign type.
				if ( ! $saved_post instanceof WP_Post || WPHAVE_Content_Models::POST_TYPE !== $saved_post->post_type ) {
					return new WP_Error( 'wphave_content_model_write_recovery_failed', __( 'The field group write could not be verified and automatic recovery failed. The stored record requires attention.', 'wphave' ), array( 'status' => 500, 'post_id' => $post_id ) );
				}
				$recovered = WPHAVE_Content_Model_Repository::restore( $post_id, $snapshot );
				if ( ! $recovered ) {
					return new WP_Error( 'wphave_content_model_write_recovery_failed', __( 'The field group write could not be verified and automatic recovery failed. The stored record requires attention.', 'wphave' ), array( 'status' => 500 ) );
				}
				return new WP_Error( 'wphave_content_model_write_verification_failed', __( 'The field group could not be verified after saving. The previous version was restored.', 'wphave' ), array( 'status' => 500 ) );
			}
			return rest_ensure_response( self::prepare( $saved_post ) );
		} finally {
			WPHAVE_Content_Model_Write_Lock::release( $lock );
		}
	}

	/**
	 * Create a field group through the shared atomic write path.
	 *
	 * @param WP_REST_Request $request Incoming create request.
	 * @return WP_REST_Response|WP_Error Saved group response or failure.
	 */

	public static function create( $request ) {
		$authorization = self::require_schema_manage();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		return self::write( $request );
	}

	/**
	 * Update a field group through the shared atomic write path.
	 *
	 * @param WP_REST_Request $request Incoming update request.
	 * @return WP_REST_Response|WP_Error Saved group response or failure.
	 */

	public static function update( $request ) {
		$authorization = self::require_schema_manage();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		return self::write( $request, absint( $request['id'] ) );
	}

	/**
	 * Trash a field group without deleting any content values.
	 *
	 * Deleting an active group additionally requires activation permission because
	 * it immediately removes fields from the runtime registry.
	 *
	 * @param WP_REST_Request $request Delete request containing the group ID.
	 * @return WP_REST_Response|WP_Error Deletion response or failure.
	 */

	public static function delete( $request ) {
		$authorization = self::require_schema_manage();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$lock = WPHAVE_Content_Model_Write_Lock::acquire();
		if ( is_wp_error( $lock ) ) {
			return $lock;
		}

		try {
			$post = WPHAVE_Content_Model_Repository::find( absint( $request['id'] ) );
			if ( ! $post ) {
				return new WP_Error( 'wphave_content_model_not_found', __( 'Field group not found.', 'wphave' ), array( 'status' => 404 ) );
			}
			if ( 'publish' === $post->post_status && ! WPHAVE_Content_Model_Access_Policy::can_activate_schemas() ) {
				return new WP_Error( 'wphave_content_model_activation_forbidden', __( 'You cannot deactivate field groups.', 'wphave' ), array( 'status' => 403 ) );
			}
			$expected_revision = sanitize_text_field( $request->get_param( 'revision' ) ?? '' );
			if ( ! hash_equals( WPHAVE_Content_Model_Repository::revision( $post ), $expected_revision ) ) {
				return new WP_Error( 'wphave_content_model_revision_conflict', __( 'This field group changed after it was loaded. Reload it before moving it to the trash.', 'wphave' ), array( 'status' => 409 ) );
			}
			$snapshot = WPHAVE_Content_Model_Repository::snapshot( $post );
			// AUTHORIZATION/LIFECYCLE INVARIANT: Lock acquisition and revision discovery cannot lease schema or activation authority across the final trash transition.
			$authorization = self::require_schema_manage();
			if ( is_wp_error( $authorization ) ) {
				return $authorization;
			}
			if ( 'publish' === $post->post_status && ! WPHAVE_Content_Model_Access_Policy::can_activate_schemas() ) {
				return new WP_Error( 'wphave_content_model_activation_forbidden', __( 'You cannot deactivate field groups.', 'wphave' ), array( 'status' => 403 ) );
			}
			$trashed = WPHAVE_Content_Model_Repository::trash( $post->ID );
			if ( ! $trashed ) {
				return new WP_Error( 'wphave_content_model_trash_failed', __( 'The field group could not be moved to the trash.', 'wphave' ), array( 'status' => 500 ) );
			}
			$stored = WPHAVE_Content_Model_Repository::find( $post->ID );
			if ( ! WPHAVE_Content_Model_Repository::matches_snapshot( $stored, $snapshot, 'trash' ) ) {
				if ( ! WPHAVE_Content_Model_Repository::restore( $post->ID, $snapshot ) ) {
					return new WP_Error( 'wphave_content_model_trash_recovery_failed', __( 'The field group deletion could not be verified and automatic recovery failed.', 'wphave' ), array( 'status' => 500 ) );
				}
				return new WP_Error( 'wphave_content_model_trash_verification_failed', __( 'The field group was not moved to the trash. Its previous state was restored.', 'wphave' ), array( 'status' => 500 ) );
			}
			return rest_ensure_response( array( 'deleted' => true, 'id' => $post->ID ) );
		} finally {
			WPHAVE_Content_Model_Write_Lock::release( $lock );
		}
	}

	/**
	 * Restore a trashed field group as inactive without interpreting its schema.
	 *
	 * Invalid and future schemas remain recoverable because lifecycle verification
	 * compares raw bytes. Restoring never republishes a group implicitly.
	 *
	 * @param WP_REST_Request $request Restore request containing ID and revision.
	 * @return WP_REST_Response|WP_Error Restored management record or failure.
	 */
	public static function restore( $request ) {
		$authorization = self::require_schema_manage();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$lock = WPHAVE_Content_Model_Write_Lock::acquire();
		if ( is_wp_error( $lock ) ) {
			return $lock;
		}

		try {
			$post = WPHAVE_Content_Model_Repository::find( absint( $request['id'] ) );
			if ( ! $post || 'trash' !== $post->post_status ) {
				return new WP_Error( 'wphave_content_model_not_trashed', __( 'Trashed field group not found.', 'wphave' ), array( 'status' => 404 ) );
			}
			$expected_revision = sanitize_text_field( $request->get_param( 'revision' ) ?? '' );
			if ( ! hash_equals( WPHAVE_Content_Model_Repository::revision( $post ), $expected_revision ) ) {
				return new WP_Error( 'wphave_content_model_revision_conflict', __( 'This field group changed after it was loaded. Reload it before restoring.', 'wphave' ), array( 'status' => 409 ) );
			}
			$snapshot = WPHAVE_Content_Model_Repository::snapshot( $post );
			// AUTHORIZATION/LIFECYCLE INVARIANT: A restore remains forbidden when schema authority expires while acquiring the lock or verifying the trashed revision.
			$authorization = self::require_schema_manage();
			if ( is_wp_error( $authorization ) ) {
				return $authorization;
			}
			$restored = WPHAVE_Content_Model_Repository::restore_from_trash( $post->ID );
			$stored = WPHAVE_Content_Model_Repository::find( $post->ID );
			if ( ! $restored || ! WPHAVE_Content_Model_Repository::matches_snapshot( $stored, $snapshot, 'draft' ) ) {
				if ( ! WPHAVE_Content_Model_Repository::restore( $post->ID, $snapshot ) ) {
					return new WP_Error( 'wphave_content_model_restore_recovery_failed', __( 'The field group restore could not be verified and automatic recovery failed.', 'wphave' ), array( 'status' => 500 ) );
				}
				return new WP_Error( 'wphave_content_model_restore_verification_failed', __( 'The field group could not be restored. Its trashed state was preserved.', 'wphave' ), array( 'status' => 500 ) );
			}

			return rest_ensure_response( self::prepare( $stored ) );
		} finally {
			WPHAVE_Content_Model_Write_Lock::release( $lock );
		}
	}

	/**
	 * Return registered field contracts and stored values for one content item.
	 *
	 * @param WP_REST_Request $request Read request containing the content ID.
	 * @return WP_REST_Response|WP_Error Field response or not-found error.
	 */

	public static function post_fields( $request ) {
		$authorization = self::require_value_access( $request );
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$post = get_post( absint( $request['id'] ) );
		if ( ! $post ) {
			return new WP_Error( 'wphave_content_model_post_not_found', __( 'Content not found.', 'wphave' ), array( 'status' => 404 ) );
		}
		$fields = WPHAVE_Content_Model_Registry::fields_for_post_type( $post->post_type );
		foreach ( $fields as $key => &$field ) {
			$field['value'] = WPHAVE_Content_Model_Value_Repository::get( $post, $key, false );
			$field = WPHAVE_Content_Model_Translations::translate_group( array(
				'id'           => $field['groupId'],
				'title'        => $field['groupTitle'],
				'description'  => '',
				'fields'       => array( $field ),
				'presentation' => array(),
			) )['fields'][0];
		}
		return self::authorized_value_response( $request, array_values( $fields ) );
	}

	/**
	 * Validate and persist an allowlisted set of Content Field values.
	 *
	 * Unknown keys, nested values and oversized requests fail before any existing
	 * value changes, preventing partial writes from malformed payloads.
	 *
	 * @param WP_REST_Request $request Value update request containing the content ID.
	 * @return WP_REST_Response|WP_Error Updated field response or failure.
	 */

	public static function save_post_fields( $request ) {
		$authorization = self::require_value_access( $request );
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}
		// LOCK INVARIANT: Even a direct callback must reject an oversized value
		// document before contending for the shared schema/value write mutex.
		if ( strlen( (string) $request->get_body() ) > self::MAX_VALUES_BODY_BYTES ) {
			return new WP_Error( 'wphave_content_model_values_too_large', __( 'The Content Fields request exceeds the 64 KB limit.', 'wphave' ), array( 'status' => 413 ) );
		}

		$lock = WPHAVE_Content_Model_Write_Lock::acquire();
		if ( is_wp_error( $lock ) ) {
			return $lock;
		}

		try {
			return self::save_post_fields_locked( $request );
		} finally {
			WPHAVE_Content_Model_Write_Lock::release( $lock );
		}
	}

	/**
	 * Validate and commit one value batch while the shared model lock is held.
	 *
	 * The schema registry and its values therefore cannot change independently
	 * between allowlist validation, snapshots, writes, and potential rollback.
	 *
	 * @param WP_REST_Request $request Value update request containing the content ID.
	 * @return WP_REST_Response|WP_Error Updated field response or failure.
	 */
	private static function save_post_fields_locked( $request ) {
		if ( strlen( (string) $request->get_body() ) > self::MAX_VALUES_BODY_BYTES ) {
			return new WP_Error( 'wphave_content_model_values_too_large', __( 'The Content Fields request exceeds the 64 KB limit.', 'wphave' ), array( 'status' => 413 ) );
		}
		$post = get_post( absint( $request['id'] ) );
		if ( ! $post ) {
			return new WP_Error( 'wphave_content_model_post_not_found', __( 'Content not found.', 'wphave' ), array( 'status' => 404 ) );
		}
		$fields = WPHAVE_Content_Model_Registry::fields_for_post_type( $post->post_type );
		$data = $request->get_json_params();
		if ( ! is_array( $data ) || ! isset( $data['values'] ) || ! is_array( $data['values'] ) ) {
			return new WP_Error( 'wphave_content_model_values_invalid', __( 'Content Field values must be provided as a JSON object.', 'wphave' ), array( 'status' => 400 ) );
		}
		$values = $data['values'];
		if ( count( $values ) > WPHAVE_Content_Model_Validator::MAX_FIELDS ) {
			return new WP_Error( 'wphave_content_model_values_limit', __( 'Too many Content Field values were submitted.', 'wphave' ), array( 'status' => 413 ) );
		}
		$normalized = array();
		foreach ( $values as $key => $value ) {
			if ( ! is_string( $key ) || ! is_scalar( $value ) ) {
				return new WP_Error( 'wphave_content_model_value_invalid', __( 'Every Content Field value must be scalar.', 'wphave' ), array( 'status' => 400 ) );
			}
			if ( strlen( (string) $value ) > self::MAX_VALUE_BYTES ) {
				return new WP_Error( 'wphave_content_model_value_too_large', __( 'A Content Field value exceeds the 16 KB limit.', 'wphave' ), array( 'status' => 413 ) );
			}
			$normalized_key = sanitize_key( $key );
			if ( $normalized_key !== $key || ! isset( $fields[ $normalized_key ] ) ) {
				return new WP_Error( 'wphave_content_model_field_unregistered', __( 'The request contains an unavailable Content Field.', 'wphave' ), array( 'status' => 400 ) );
			}
			$canonical = WPHAVE_Content_Model_Field_Type_Registry::normalize_submitted_value(
				$fields[ $normalized_key ]['type'],
				$value,
				$fields[ $normalized_key ]
			);
			if ( is_wp_error( $canonical ) ) {
				$canonical->add_data( array( 'status' => 400 ) );
				return $canonical;
			}
			$normalized[ $normalized_key ] = $canonical;
		}

		// AUTHORIZATION/VALUE-COMMIT INVARIANT: Lock acquisition and value normalization cross extensible WordPress boundaries; both feature and object authority must be current immediately before the first metadata snapshot or write.
		$authorization = self::require_value_access( $request );
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		// DATA INVARIANT: validate the complete batch before the first mutation and
		// restore every earlier value if a later WordPress meta write fails.
		$snapshots = array();
		foreach ( $normalized as $key => $value ) {
			$meta_key = WPHAVE_Content_Model_Value_Repository::meta_key( $key );
			$snapshots[ $key ] = array(
				'exists' => metadata_exists( 'post', $post->ID, $meta_key ),
				'value'  => get_post_meta( $post->ID, $meta_key, true ),
			);
		}

		// AUTHORIZATION/VALUE-SNAPSHOT-COMMIT INVARIANT: Snapshot construction
		// invokes filterable metadata reads. Materialize every rollback value before
		// mutation, then revalidate both feature and exact-object authority once more
		// immediately before the first write so no stale-authority partial batch can
		// begin.
		$authorization = self::require_value_access( $request );
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$changed = array();
		foreach ( $normalized as $key => $value ) {
			if ( (string) $snapshots[ $key ]['value'] === $value ) {
				continue;
			}
			if ( false === WPHAVE_Content_Model_Value_Repository::update( $post, $key, $value ) ) {
				if ( ! self::rollback_post_field_values( $post->ID, $changed, $snapshots ) ) {
					return new WP_Error( 'wphave_content_model_value_recovery_failed', __( 'The Content Field value write failed and automatic recovery could not be verified.', 'wphave' ), array( 'status' => 500 ) );
				}
				return new WP_Error( 'wphave_content_model_value_write_failed', __( 'The Content Field values could not be saved. Existing values were restored.', 'wphave' ), array( 'status' => 500 ) );
			}
			$changed[] = $key;
		}
		return self::post_fields( $request );
	}

	/**
	 * Restore and verify value snapshots in reverse mutation order.
	 *
	 * @param int   $post_id  Content item whose meta changed.
	 * @param array $changed  Stable field keys successfully changed earlier.
	 * @param array $snapshots Existence and value snapshots keyed by field key.
	 * @return bool Whether every changed value exactly matches its snapshot.
	 */
	private static function rollback_post_field_values( $post_id, array $changed, array $snapshots ) {
		foreach ( array_reverse( $changed ) as $key ) {
			$meta_key = WPHAVE_Content_Model_Value_Repository::meta_key( $key );
			if ( $snapshots[ $key ]['exists'] ) {
				update_post_meta( $post_id, $meta_key, $snapshots[ $key ]['value'] );
			} else {
				delete_post_meta( $post_id, $meta_key );
			}
			if (
				metadata_exists( 'post', $post_id, $meta_key ) !== $snapshots[ $key ]['exists'] ||
				( $snapshots[ $key ]['exists'] && get_post_meta( $post_id, $meta_key, true ) !== $snapshots[ $key ]['value'] )
			) {
				return false;
			}
		}

		return true;
	}
}
