<?php

/** Load Content Model management APIs. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/rest-controller.php';
WPHAVE_Content_Models_REST_Controller::init();
