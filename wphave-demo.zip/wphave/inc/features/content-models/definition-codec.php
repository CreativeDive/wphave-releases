<?php

/** Lossless JSON encoding for current field-group definitions. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Keep WordPress slashing semantics outside the schema and validation layers. */
final class WPHAVE_Content_Model_Definition_Codec {
	const MAX_ENCODED_BYTES = 262144;
	/** Encode a validated definition for WordPress's slashed insert boundary. */
	public static function encode_for_wordpress( array $definition ) {
		$encoded = wp_json_encode( $definition );
		// PERSISTENCE INVARIANT: A successful write must remain readable under
		// the same bounded runtime decoder, including direct service callers.
		if ( ! is_string( $encoded ) || strlen( $encoded ) > self::MAX_ENCODED_BYTES ) {
			return new WP_Error( 'wphave_content_model_encode_failed', __( 'The field group could not be encoded safely.', 'wphave' ) );
		}

		// PERSISTENCE INVARIANT: wp_insert_post() unslashes its input. The
		// matching slash keeps nested JSON strings byte-correct in post_content.
		return wp_slash( $encoded );
	}

	/**
	 * Decode only valid JSON from the current storage contract.
	 *
	 * FORMAT INVARIANT: Runtime reads never guess how malformed stored bytes were
	 * intended. Repairs require an explicit, separately reviewed migration.
	 */
	public static function decode( $encoded ) {
		// PARSER INVARIANT: The REST write limit also applies when a definition
		// reaches runtime through legacy storage or another WordPress writer.
		if ( ! is_string( $encoded ) || '' === $encoded || strlen( $encoded ) > self::MAX_ENCODED_BYTES ) {
			return new WP_Error( 'wphave_content_model_json_invalid', __( 'The stored field group is not valid JSON.', 'wphave' ) );
		}

		$definition = json_decode( $encoded, true );
		if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $definition ) ) {
			return new WP_Error( 'wphave_content_model_json_invalid', __( 'The stored field group is not valid JSON.', 'wphave' ) );
		}

		return $definition;
	}
}
