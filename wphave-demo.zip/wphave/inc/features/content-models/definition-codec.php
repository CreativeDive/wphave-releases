<?php

/** Lossless JSON encoding for current field-group definitions. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Keep WordPress slashing semantics outside the schema and validation layers. */
final class WPHAVE_Content_Model_Definition_Codec {
	/** Encode a validated definition for WordPress's slashed insert boundary. */
	public static function encode_for_wordpress( array $definition ) {
		$encoded = wp_json_encode( $definition );
		if ( ! is_string( $encoded ) ) {
			return new WP_Error( 'wphave_content_model_encode_failed', __( 'The field group could not be encoded safely.', 'wphave' ) );
		}

		// PERSISTENCE INVARIANT: wp_insert_post() unslashes its input. The
		// matching slash keeps nested JSON strings byte-correct in post_content.
		return wp_slash( $encoded );
	}

	/**
	 * Decode only valid JSON from the current storage contract.
	 *
	 * FORMAT INVARIANT: Runtime reads never guess how malformed stored bytes were
	 * intended. Repairs require an explicit, separately reviewed migration.
	 */
	public static function decode( $encoded ) {
		if ( ! is_string( $encoded ) || '' === $encoded ) {
			return new WP_Error( 'wphave_content_model_json_invalid', __( 'The stored field group is not valid JSON.', 'wphave' ) );
		}

		$definition = json_decode( $encoded, true );
		if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $definition ) ) {
			return new WP_Error( 'wphave_content_model_json_invalid', __( 'The stored field group is not valid JSON.', 'wphave' ) );
		}

		return $definition;
	}
}
