<?php

/** Validates the value-free, depth-limited presentation tree of a Content Model. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Validate and normalize the depth-limited, value-free presentation tree. */

final class WPHAVE_Content_Model_Presentation {
	const GRID_LAYOUTS = array( 'full', 'half-half', 'one-third-one-third-one-third' );
	const MAX_ITEMS = 200;
	const MAX_DEPTH = 1;

	/**
	 * Normalize a presentation and append any missing active field references.
	 *
	 * Root output is always single-column. Only sections retain a constrained grid.
	 * Duplicate and dangling references are removed without changing field identity.
	 *
	 * @param mixed $presentation Untrusted presentation payload.
	 * @param array $fields       Normalized active field definitions.
	 * @return array|WP_Error Normalized presentation or a structural error.
	 */

	public static function normalize( $presentation, array $fields ) {
		if ( ! is_array( $presentation ) ) {
			return new WP_Error( 'wphave_content_model_presentation_invalid', __( 'The field layout is invalid.', 'wphave' ) );
		}
		if ( isset( $presentation['items'] ) && ! is_array( $presentation['items'] ) ) {
			return new WP_Error( 'wphave_content_model_items_invalid', __( 'The field layout items must be provided as a list.', 'wphave' ) );
		}

		$field_ids = array_fill_keys( wp_list_pluck( $fields, 'id' ), true );
		$state = array(
			'referenced' => array(),
			'item_ids'   => array(),
			'count'      => 0,
		);
		$items = self::normalize_items( $presentation['items'] ?? array(), 0, $field_ids, $state );
		if ( is_wp_error( $items ) ) {
			return $items;
		}
		foreach ( array_keys( $field_ids ) as $field_id ) {
			if ( ! isset( $state['referenced'][ $field_id ] ) ) {
				if ( ++$state['count'] > self::MAX_ITEMS ) {
					return new WP_Error( 'wphave_content_model_items_limit', __( 'A field layout can contain at most 200 items.', 'wphave' ) );
				}
				$items[] = array( 'kind' => 'field', 'fieldId' => $field_id );
			}
		}

		// Root fields deliberately remain single-column. Grid choices belong to sections.
		return array( 'grid' => 'full', 'items' => $items );
	}

	/**
	 * Normalize one ordered container while enforcing the global item limit.
	 *
	 * @param array $items     Presentation nodes in the current container.
	 * @param int   $depth     Current section nesting depth.
	 * @param array $field_ids Allowlisted active field identifiers.
	 * @param array $state     Shared reference, identifier and item-count state.
	 * @return array|WP_Error Normalized nodes or a validation error.
	 */

	private static function normalize_items( array $items, $depth, array $field_ids, array &$state ) {
		$normalized = array();
		foreach ( $items as $item ) {
			if ( ++$state['count'] > self::MAX_ITEMS ) {
				return new WP_Error( 'wphave_content_model_items_limit', __( 'A field layout can contain at most 200 items.', 'wphave' ) );
			}
			$item = self::normalize_item( $item, $depth, $field_ids, $state );
			if ( is_wp_error( $item ) ) {
				return $item;
			}
			if ( $item ) {
				$normalized[] = $item;
			}
		}
		return $normalized;
	}

	/**
	 * Normalize one field reference, divider or section node.
	 *
	 * @param mixed $item      Untrusted presentation node.
	 * @param int   $depth     Current section nesting depth.
	 * @param array $field_ids Allowlisted active field identifiers.
	 * @param array $state     Shared reference and identifier state.
	 * @return array|WP_Error|null Normalized node, error, or null for a discarded reference.
	 */

	private static function normalize_item( $item, $depth, array $field_ids, array &$state ) {
		if ( ! is_array( $item ) ) {
			return new WP_Error( 'wphave_content_model_presentation_item_invalid', __( 'Every field layout item must be a valid object.', 'wphave' ) );
		}
		foreach ( array( 'kind', 'fieldId', 'id', 'label', 'description', 'caption', 'grid' ) as $property ) {
			if ( isset( $item[ $property ] ) && ! is_scalar( $item[ $property ] ) ) {
				return new WP_Error( 'wphave_content_model_presentation_item_invalid', __( 'A field layout item contains an invalid property.', 'wphave' ) );
			}
		}

		$kind = sanitize_key( $item['kind'] ?? '' );
		if ( 'field' === $kind ) {
			$field_id = sanitize_key( $item['fieldId'] ?? '' );
			if ( ! isset( $field_ids[ $field_id ] ) || isset( $state['referenced'][ $field_id ] ) ) {
				return null;
			}
			$state['referenced'][ $field_id ] = true;
			return array( 'kind' => 'field', 'fieldId' => $field_id );
		}

		if ( 'divider' === $kind ) {
			$id = self::normalize_unique_id( $item['id'] ?? '', $state );
			return is_wp_error( $id ) ? $id : array( 'kind' => 'divider', 'id' => $id );
		}

		if ( 'section' === $kind ) {
			if ( $depth >= self::MAX_DEPTH ) {
				return new WP_Error( 'wphave_content_model_section_depth', __( 'Sections cannot be nested inside other sections.', 'wphave' ) );
			}
			if ( isset( $item['children'] ) && ! is_array( $item['children'] ) ) {
				return new WP_Error( 'wphave_content_model_section_children_invalid', __( 'Section children must be provided as a list.', 'wphave' ) );
			}
			$label = sanitize_text_field( $item['label'] ?? '' );
			if ( '' === $label ) {
				return new WP_Error( 'wphave_content_model_section_required', __( 'Sections need a heading.', 'wphave' ) );
			}
			$id = self::normalize_unique_id( $item['id'] ?? '', $state );
			if ( is_wp_error( $id ) ) {
				return $id;
			}
			$grid = self::normalize_grid( $item['grid'] ?? 'full' );
			if ( is_wp_error( $grid ) ) {
				return $grid;
			}
			$children = self::normalize_items( $item['children'] ?? array(), $depth + 1, $field_ids, $state );
			if ( is_wp_error( $children ) ) {
				return $children;
			}
			return array(
				'kind'        => 'section',
				'id'          => $id,
				'label'       => $label,
				'description' => sanitize_textarea_field( $item['description'] ?? '' ),
				'caption'     => sanitize_text_field( $item['caption'] ?? '' ),
				'grid'        => $grid,
				'children'    => $children,
			);
		}

		return new WP_Error( 'wphave_content_model_presentation_kind_invalid', __( 'The field layout contains an unsupported item type.', 'wphave' ) );
	}

	/**
	 * Restrict a section grid to supported WPHAVE layout contracts.
	 *
	 * @param mixed $grid Requested grid identifier.
	 * @return string|WP_Error Supported grid or an invalid-type error.
	 */

	private static function normalize_grid( $grid ) {
		if ( ! is_scalar( $grid ) ) {
			return new WP_Error( 'wphave_content_model_grid_invalid', __( 'The field layout grid is invalid.', 'wphave' ) );
		}
		$grid = sanitize_key( $grid );
		return in_array( $grid, self::GRID_LAYOUTS, true ) ? $grid : 'full';
	}

	/**
	 * Normalize a layout-node ID and reject identity collisions.
	 *
	 * @param mixed $id    Requested node identifier.
	 * @param array $state Shared identifier state.
	 * @return string|WP_Error Unique identifier or a collision error.
	 */

	private static function normalize_unique_id( $id, array &$state ) {
		$id = sanitize_key( $id ) ?: wp_generate_uuid4();
		if ( isset( $state['item_ids'][ $id ] ) ) {
			return new WP_Error( 'wphave_content_model_duplicate_layout_id', __( 'Layout element identifiers must be unique.', 'wphave' ) );
		}
		$state['item_ids'][ $id ] = true;
		return $id;
	}
}
