<?php

/** Current Content Model schema boundary. */

if (!defined('ABSPATH')) {
	exit();
}

/** Reject non-current schemas before canonical validation can discard data. */
final class WPHAVE_Content_Model_Schema {
	const CURRENT_VERSION = 8;

	/**
	 * Admit only the current persisted contract.
	 *
	 * VERSION INVARIANT: Normal runtime code never guesses schema migrations.
	 * Older and newer schemas fail closed so validation cannot silently normalize
	 * data without an explicit sequential transformation.
	 *
	 * @param mixed $definition Untrusted stored definition.
	 * @return array|WP_Error Current definition or a fail-closed schema error.
	 */
	public static function assert_current($definition) {
		if (!is_array($definition)) {
			return new WP_Error(
				'wphave_content_model_invalid',
				__('A valid field group is required.', 'wphave')
			);
		}

		if (self::CURRENT_VERSION !== ($definition['schemaVersion'] ?? null)) {
			return new WP_Error(
				'wphave_content_model_schema_unsupported',
				__('This field group does not use the current WPHAVE schema.', 'wphave')
			);
		}

		return $definition;
	}
}
