<?php

/** Allowlist-based value persistence; removed fields remain recoverable orphans. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Read and write only values backed by the active immutable field registry. */

final class WPHAVE_Content_Model_Value_Repository {
    
	/**
	 * Build the private WordPress meta key for a stable field key.
	 *
	 * @param string $key Registered field key.
	 * @return string Namespaced post-meta key.
	 */

	public static function meta_key( $key ) {
		return WPHAVE_Content_Models::META_PREFIX . sanitize_key( $key );
	}

	/**
	 * Read and sanitize a registered value for a content item.
	 *
	 * @param WP_Post|int $post        Post object or ID.
	 * @param string      $key         Registered field key.
	 * @param bool        $use_default Whether an empty stored value uses the field default.
	 * @return string|null Sanitized value or null when the field is unavailable.
	 */

	public static function get( $post, $key, $use_default = true ) {
		$post = is_object( $post ) ? $post : get_post( absint( $post ) );
		$field = $post ? WPHAVE_Content_Model_Registry::field( $post->post_type, $key ) : null;
		if ( ! $post || ! $field ) {
			return null;
		}
		$value = get_post_meta( $post->ID, self::meta_key( $key ), true );
		$sanitized = WPHAVE_Content_Model_Field_Type_Registry::sanitize( $field['type'], $value, $field );
		$resolved = '' === $sanitized && $use_default ? $field['default'] : $sanitized;

		// SECURITY INVARIANT: schema validation is deterministic and cache-safe;
		// object visibility is evaluated only for the value being exposed now.
		return WPHAVE_Content_Model_Field_Type_Registry::can_read( $field['type'], $resolved, $field )
			? $resolved
			: null;
	}

	/**
	 * Sanitize and persist a registered value for a content item.
	 *
	 * @param WP_Post|int $post  Post object or ID.
	 * @param string      $key   Registered field key.
	 * @param mixed       $value Untrusted submitted value.
	 * @return int|bool Meta ID, true for an update, or false when unavailable.
	 */

	public static function update( $post, $key, $value ) {
		$post = is_object( $post ) ? $post : get_post( absint( $post ) );
		$field = $post ? WPHAVE_Content_Model_Registry::field( $post->post_type, $key ) : null;
		if ( ! $post || ! $field ) {
			return false;
		}
		$value = WPHAVE_Content_Model_Field_Type_Registry::sanitize( $field['type'], $value, $field );
		return update_post_meta( $post->ID, self::meta_key( $key ), $value );
	}
}
