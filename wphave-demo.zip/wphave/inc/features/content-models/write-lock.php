<?php

/** Short database-backed mutex for atomic field-registry writes. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Serialize schema mutations through a short database-backed ownership token. */

final class WPHAVE_Content_Model_Write_Lock {
	const OPTION = 'wphave_content_models_write_lock';
	const TTL = 15;

	/**
	 * Acquire the schema write lock or recover an expired lock.
	 *
	 * @return string|WP_Error Ownership token or a conflict response.
	 */

	public static function acquire() {
		$token = WPHAVE_Background_Job_Lock::acquire( self::OPTION, self::TTL );
		if ( is_string( $token ) ) {
			return $token;
		}

		return new WP_Error(
			'wphave_content_model_locked',
			__( 'Another field group is being saved. Try again.', 'wphave' ),
			array( 'status' => 409 )
		);
	}

	/**
	 * Release the lock only when the caller still owns its token.
	 *
	 * @param string $token Ownership token returned by acquire().
	 * @return void
	 */

	public static function release( $token ) {
		// SECURITY INVARIANT: Schema write authority remains bound to the token;
		// a timed-out request must never release a successor's active lease.
		WPHAVE_Background_Job_Lock::release( self::OPTION, (string) $token );
	}
}
