<?php

/**
 * Privacy-first geography reporting from independent daily country counters.
 */

trait WPHAVE_Analytics_Report_Geography {

	private const GEOGRAPHY_MIN_VISIBLE_VIEWS = 5;
	private const GEOGRAPHY_TREND_COUNTRIES = 5;

	/**
	 * Return country distribution, trend and coverage for the selected period.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @return WP_REST_Response Geography report.
	 */
	public function api_geography( WP_REST_Request $request ) {
		global $wpdb;

		$privacy_daily_table = $wpdb->prefix . WPHAVE_Analytics::PRIVACY_DAILY_TABLE;

		if ( ! $this->table_exists( $privacy_daily_table ) ) {
			return rest_ensure_response( $this->empty_geography_report() );
		}

		$params = [];
		$where = $this->query_builder->build_privacy_dimension_filters( $request, $params );
		$where .= ' AND dimension_type = %s';
		$params[] = 'country';

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT dimension_value AS country, SUM(views) AS views
				FROM {$privacy_daily_table}
				{$where}
				GROUP BY dimension_value
				ORDER BY views DESC",
				...$params
			)
		) ?: [];

		$total_params = [];
		$total_where = $this->build_filters( $request, $total_params );
		$total_views = $this->table_exists( $this->daily_table )
			? (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COALESCE(SUM(views), 0) FROM {$this->daily_table} {$total_where}",
					...$total_params
				)
			)
			: 0;
		$resolved_views = array_sum(
			array_map( static fn( $row ): int => (int) $row->views, $rows )
		);

		$visible_rows = [];
		$suppressed_views = 0;

		foreach ( $rows as $row ) {
			$views = (int) $row->views;

			if ( $views < self::GEOGRAPHY_MIN_VISIBLE_VIEWS ) {
				$suppressed_views += $views;
				continue;
			}

			$visible_rows[] = [
				'country' => strtoupper( sanitize_key( $row->country ) ),
				'views'   => $views,
			];
		}

		if ( $suppressed_views ) {
			$visible_rows[] = [
				'country' => 'OTHER',
				'views'   => $suppressed_views,
			];
		}

		foreach ( $visible_rows as &$row ) {
			$row['share'] = $resolved_views ? ( $row['views'] / $resolved_views ) * 100 : 0;
		}
		unset( $row );

		$site_country = $this->get_site_country();
		$domestic_views = 0;

		foreach ( $rows as $row ) {
			if ( $site_country && strtoupper( (string) $row->country ) === $site_country ) {
				$domestic_views += (int) $row->views;
			}
		}

		return rest_ensure_response(
			[
				'countries' => $visible_rows,
				'trend'     => $this->get_geography_trend( $request, $privacy_daily_table, $visible_rows ),
				'coverage'  => [
					'totalViews'       => $total_views,
					'resolvedViews'    => $resolved_views,
					'unresolvedViews'  => max( 0, $total_views - $resolved_views ),
					'resolvedPercent'  => $total_views ? ( $resolved_views / $total_views ) * 100 : 0,
					'countriesReached' => count( $rows ),
				],
				'siteCountry' => $site_country,
				'domestic'    => [
					'views' => $domestic_views,
					'share' => $resolved_views ? ( $domestic_views / $resolved_views ) * 100 : 0,
				],
				'international' => [
					'views' => max( 0, $resolved_views - $domestic_views ),
					'share' => $resolved_views ? ( ( $resolved_views - $domestic_views ) / $resolved_views ) * 100 : 0,
				],
			]
		);
	}

	/**
	 * Return daily series only for countries that passed disclosure control.
	 */
	private function get_geography_trend( WP_REST_Request $request, string $table, array $visible_rows ): array {
		global $wpdb;

		$country_codes = array_slice(
			array_values(
				array_filter(
					array_column( $visible_rows, 'country' ),
					static fn( string $country ): bool => 'OTHER' !== $country
				)
			),
			0,
			self::GEOGRAPHY_TREND_COUNTRIES
		);

		if ( ! $country_codes ) {
			return [];
		}

		$params = [];
		$where = $this->query_builder->build_privacy_dimension_filters( $request, $params );
		$placeholders = implode( ', ', array_fill( 0, count( $country_codes ), '%s' ) );
		$params[] = 'country';
		$params = array_merge( $params, $country_codes );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT view_date AS date, dimension_value AS country, SUM(views) AS views
				FROM {$table}
				{$where} AND dimension_type = %s AND dimension_value IN ({$placeholders})
				GROUP BY view_date, dimension_value
				ORDER BY view_date ASC",
				...$params
			)
		) ?: [];

		return array_map(
			static fn( $row ): array => [
				'date'    => (string) $row->date,
				'country' => strtoupper( (string) $row->country ),
				'views'   => (int) $row->views,
			],
			$rows
		);
	}

	/**
	 * Return the configured public organization country when available.
	 */
	private function get_site_country(): string {
		$country = strtoupper(
			trim(
				(string) wphave_data_get(
					'site_settings',
					'schema.identity.address.country',
					''
				)
			)
		);

		return preg_match( '/^[A-Z]{2}$/', $country ) ? $country : '';
	}

	private function empty_geography_report(): array {
		return [
			'countries'    => [],
			'trend'        => [],
			'coverage'     => [
				'totalViews'       => 0,
				'resolvedViews'    => 0,
				'unresolvedViews'  => 0,
				'resolvedPercent'  => 0,
				'countriesReached' => 0,
			],
			'siteCountry'  => '',
			'domestic'     => [ 'views' => 0, 'share' => 0 ],
			'international' => [ 'views' => 0, 'share' => 0 ],
		];
	}
}
