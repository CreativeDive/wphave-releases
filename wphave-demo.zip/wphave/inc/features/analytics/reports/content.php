<?php

/**
 * Build aggregate post, page, insight and content performance reports.
 */

trait WPHAVE_Analytics_Report_Content {

    public function api_stats( WP_REST_Request $request ) {
        $days = max( 1, min( 365, absint( $request->get_param( 'days' ) ?: 30 ) ) );

        if ( ! $this->table_exists( $this->daily_table ) ) {
            return rest_ensure_response( [
                'days'            => $days,
                'views'           => 0,
                'sessions'        => 0,
                'unique_visitors' => 0,
                'posts'           => 0,
            ] );
        }

        global $wpdb;
        $recent_threshold = current_datetime()->modify("-{$days} days")->format('Y-m-d');

        $row = $wpdb->get_row(
            $wpdb->prepare(
                "
                SELECT
                    COALESCE(SUM(views), 0) AS views,
                    COALESCE(SUM(unique_visitors), 0) AS unique_visitors,
                    COALESCE(SUM(sessions), 0) AS sessions,
                    COUNT(DISTINCT object_key) AS posts
                FROM {$this->daily_table}
                WHERE view_date >= %s
                ",
                $recent_threshold
            )
        );

        return rest_ensure_response( [
            'days'            => $days,
            'views'           => (int) ( $row->views ?? 0 ),
            'unique_visitors' => (int) ( $row->unique_visitors ?? 0 ),
            'sessions'        => (int) ( $row->sessions ?? 0 ),
            'posts'           => (int) ( $row->posts ?? 0 ),
        ] );
    }

/**
     * API posts.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_posts( WP_REST_Request $request ) {
        $type  = sanitize_key( $request->get_param( 'type' ) ?: 'trending' );
        $days  = max( 1, min( 365, absint( $request->get_param( 'days' ) ?: 30 ) ) );
        $limit = max( 1, min( 100, absint( $request->get_param( 'limit' ) ?: 10 ) ) );

        if ( ! $this->table_exists( $this->daily_table ) ) {
            return rest_ensure_response( [] );
        }

        global $wpdb;

        if ( $type === 'popular' ) {
            $rows = $wpdb->get_results(
                $wpdb->prepare(
                    "
                    SELECT
                        MAX(post_id) as post_id,
                        MAX(object_type) as object_type,
                        MAX(object_id) as object_id,
                        MAX(object_subtype) as object_subtype,
                        object_key,
                        MAX(object_label) as object_label,
                        MAX(object_url) as object_url,
                        SUM(views) AS value
                    FROM {$this->daily_table}
                    GROUP BY object_key
                    ORDER BY value DESC
                    LIMIT %d
                    ",
                    $limit
                )
            );
        } else {
            $boost_threshold = current_datetime()->modify('-3 days')->format('Y-m-d');
            $recent_threshold = current_datetime()->modify("-{$days} days")->format('Y-m-d');

            $rows = $wpdb->get_results(
                $wpdb->prepare(
                    "
                    SELECT
                        MAX(post_id) as post_id,
                        MAX(object_type) as object_type,
                        MAX(object_id) as object_id,
                        MAX(object_subtype) as object_subtype,
                        object_key,
                        MAX(object_label) as object_label,
                        MAX(object_url) as object_url,
                        SUM(
                            CASE
                                WHEN view_date >= %s THEN views * 2
                                WHEN view_date >= %s THEN views
                                ELSE 0
                            END
                        ) AS value
                    FROM {$this->daily_table}
                    WHERE view_date >= %s
                    GROUP BY object_key
                    ORDER BY value DESC
                    LIMIT %d
                    ",
                    $boost_threshold,
                    $recent_threshold,
                    $recent_threshold,
                    $limit
                )
            );
        }

        $items = array_map( function ( $row ) {
            $post_id = (int) $row->post_id;
            $object_type = $row->object_type ?: 'post';
            $object_id = (int)($row->object_id ?: $post_id);

            return [
                'id'    => $object_type . ':' . $object_id . ':' . $row->object_subtype,
                'post_id' => $post_id,
                'object_type' => $object_type,
                'object_id' => $object_id,
                'object_subtype' => $row->object_subtype,
                'title' => $row->object_label ?: ($post_id ? get_the_title( $post_id ) : __('Unknown content', 'wphave')),
                'url'   => $row->object_url ?: ($post_id ? get_permalink( $post_id ) : ''),
                'value' => (int) $row->value,
            ];
        }, $rows );

        return rest_ensure_response( $items );
    }

/**
     * API pages.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_pages(WP_REST_Request $request) {
        $raw_search = $request->get_param('search');
        // REPORT-QUERY INVARIANT: Analytics viewing authority does not grant
        // unbounded sanitizer, SQL LIKE or count-query work. Validate raw bytes
        // before either table probing or construction of an escaped pattern.
        if ($raw_search !== null && (!is_string($raw_search) || strlen($raw_search) > 512)) {
            return new WP_Error(
                'wphave_analytics_pages_search_invalid',
                __('The page search is too long.', 'wphave'),
                ['status' => 400],
            );
        }
        if ( ! $this->table_exists( $this->daily_table ) ) {
            return rest_ensure_response([
                'items' => [],
                'total' => 0,
                'page' => 1,
                'perPage' => 20,
            ]);
        }

        global $wpdb;

        $page = max(1, absint($request->get_param('page') ?: 1));
        // QUERY INVARIANT: An editor cannot force an unbounded sorted OFFSET
        // scan over aggregated page rows with a very large page number.
        if ($page > 1000) {
            return new WP_Error(
                'wphave_analytics_page_too_deep',
                __('The requested page is too deep.', 'wphave'),
                ['status' => 400],
            );
        }
        $per_page = max(1, min(100, absint($request->get_param('per_page') ?: 20)));
        $offset = ($page - 1) * $per_page;
        $search = sanitize_text_field($raw_search ?? '');
        $orderby = sanitize_key($request->get_param('orderby') ?: 'views');
        $order = strtoupper(sanitize_key($request->get_param('order') ?: 'desc')) === 'ASC' ? 'ASC' : 'DESC';
        $allowed_orderby = [
            'title' => 'title',
            'views' => 'views',
            'unique_visitors' => 'unique_visitors',
            'sessions' => 'sessions',
        ];
        $orderby_sql = $allowed_orderby[$orderby] ?? 'views';

        $params = [];
        $where = $this->build_filters($request, $params);
        $range = $this->get_date_range($request);
        $previous_params = [];
        $previous_where = $this->build_filters($request, $previous_params, $this->get_previous_date_range($range));

        $search_join = '';
        $search_where = '';
        $search_params = [];

        if ($search) {
            $search_join = "";
            $search_where = " AND COALESCE(NULLIF(d.object_label, ''), p.post_title) LIKE %s";
            $search_params[] = '%' . $wpdb->esc_like($search) . '%';
        }

        $aliased_where = $this->prefix_where_columns($where, 'd');
        $previous_aliased_where = $this->prefix_where_columns($previous_where, 'd');

        $total = (int) $wpdb->get_var(
            $wpdb->prepare(
                "
                SELECT COUNT(*) FROM (
                    SELECT d.object_key
                    FROM {$this->daily_table} d
                    LEFT JOIN {$wpdb->posts} p ON p.ID = d.post_id
                    $search_join
                    $aliased_where
                    $search_where
                    GROUP BY d.object_key
                ) counted
                ",
                ...array_merge($params, $search_params)
            )
        );

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "
                SELECT
                    MAX(d.post_id) as post_id,
                    MAX(d.object_type) as object_type,
                    MAX(d.object_id) as object_id,
                    MAX(d.object_subtype) as object_subtype,
                    d.object_key,
                    MAX(COALESCE(NULLIF(d.object_label, ''), p.post_title, '')) as title,
                    MAX(COALESCE(NULLIF(d.object_url, ''), '')) as url,
                    SUM(d.views) as views,
                    SUM(d.unique_visitors) as unique_visitors,
                    SUM(d.sessions) as sessions
                FROM {$this->daily_table} d
                LEFT JOIN {$wpdb->posts} p ON p.ID = d.post_id
                $aliased_where
                $search_where
                GROUP BY d.object_key
                ORDER BY {$orderby_sql} {$order}
                LIMIT %d OFFSET %d
                ",
                ...array_merge($params, $search_params, [$per_page, $offset])
            )
        );
        $object_keys = array_map(fn($row) => $row->object_key, $rows);
        $previous_page_map = [];

        if ($object_keys) {
            $object_conditions = [];
            $object_params = [];

            foreach ($rows as $row) {
                $object_conditions[] = "d.object_key = %s";
                $object_params[] = $row->object_key;
            }

            $previous_rows = $wpdb->get_results(
                $wpdb->prepare(
                    "
                    SELECT
                        MAX(d.object_type) as object_type,
                        MAX(d.object_id) as object_id,
                        MAX(d.object_subtype) as object_subtype,
                        d.object_key,
                        SUM(d.views) as views,
                        SUM(d.unique_visitors) as unique_visitors,
                        SUM(d.sessions) as sessions
                    FROM {$this->daily_table} d
                    LEFT JOIN {$wpdb->posts} p ON p.ID = d.post_id
                    $previous_aliased_where
                    $search_where
                    AND (" . implode(' OR ', $object_conditions) . ")
                    GROUP BY d.object_key
                    ",
                    ...array_merge($previous_params, $search_params, $object_params)
                )
            );
            $previous_page_map = $this->map_rows_by_key($previous_rows, ['object_key']);
        }

        return rest_ensure_response([
            'items' => array_map(function($row) use ($previous_page_map) {
                $post_id = (int) $row->post_id;
                $previous = $previous_page_map[$this->get_row_key($row, ['object_key'])] ?? null;
                $object_type = $row->object_type ?: 'post';
                $object_id = (int)($row->object_id ?: $post_id);
                $object_subtype = $row->object_subtype ?: ($post_id ? get_post_type($post_id) : '');

                return [
                    'id' => $object_type . ':' . $object_id . ':' . $object_subtype,
                    'post_id' => $post_id,
                    'object_type' => $object_type,
                    'object_id' => $object_id,
                    'object_subtype' => $object_subtype,
                    'title' => $row->title ?: ($post_id ? get_the_title($post_id) : __('Unknown content', 'wphave')),
                    'url' => $row->url ?: ($post_id ? get_permalink($post_id) : ''),
                    'value' => (int) $row->views,
                    'views' => (int) $row->views,
                    'unique_visitors' => (int) $row->unique_visitors,
                    'sessions' => (int) $row->sessions,
                    'compare' => [
                        'views' => [
                            'previous' => (int)($previous->views ?? 0),
                            'change' => $this->get_change((float)$row->views, (float)($previous->views ?? 0)),
                        ],
                        'unique_visitors' => [
                            'previous' => (int)($previous->unique_visitors ?? 0),
                            'change' => $this->get_change((float)$row->unique_visitors, (float)($previous->unique_visitors ?? 0)),
                        ],
                        'sessions' => [
                            'previous' => (int)($previous->sessions ?? 0),
                            'change' => $this->get_change((float)$row->sessions, (float)($previous->sessions ?? 0)),
                        ],
                    ],
                ];
            }, $rows),
            'total' => $total,
            'page' => $page,
            'perPage' => $per_page,
        ]);
    }

/**
     * API insights.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_insights(WP_REST_Request $request) {
        if ( ! $this->table_exists( $this->daily_table ) ) {
            return rest_ensure_response([
                'errors' => [],
                'searches' => [],
                'archives' => [],
                'forms' => [],
                'goals' => [],
                'goalDaily' => [],
                'campaignConversions' => [],
                'microConversions' => [],
                'recommendations' => [],
                'downloads' => [],
                'outbound' => [],
                'lowEngagement' => [],
                'dataQuality' => [],
            ]);
        }

        global $wpdb;

        $params = [];
        $where = $this->build_filters($request, $params);
        $daily_where = $this->prefix_where_columns($where, 'd');
        $format_object = function($row) {
            $post_id = (int)($row->post_id ?? 0);
            $object_type = $row->object_type ?: 'post';
            $object_id = (int)($row->object_id ?: $post_id);
            $object_subtype = $row->object_subtype ?: ($post_id ? get_post_type($post_id) : '');

            return [
                'id' => $object_type . ':' . $object_id . ':' . $object_subtype,
                'post_id' => $post_id,
                'object_type' => $object_type,
                'object_id' => $object_id,
                'object_subtype' => $object_subtype,
                'title' => $row->title ?: ($post_id ? get_the_title($post_id) : __('Unknown content', 'wphave')),
                'url' => $row->url ?: ($post_id ? get_permalink($post_id) : ''),
                'value' => (int)($row->views ?? $row->value ?? 0),
                'views' => (int)($row->views ?? $row->value ?? 0),
                'unique_visitors' => (int)($row->unique_visitors ?? 0),
                'sessions' => (int)($row->sessions ?? 0),
            ];
        };

        $errors = $wpdb->get_results(
            $wpdb->prepare(
                "
                SELECT
                    MAX(d.post_id) as post_id,
                    MAX(d.object_type) as object_type,
                    MAX(d.object_id) as object_id,
                    MAX(d.object_subtype) as object_subtype,
                    d.object_key,
                    MAX(COALESCE(NULLIF(d.object_url, ''), NULLIF(d.object_label, ''), '404')) as title,
                    MAX(COALESCE(NULLIF(d.object_url, ''), '')) as url,
                    SUM(d.views) as views,
                    SUM(d.unique_visitors) as unique_visitors,
                    SUM(d.sessions) as sessions,
                    MAX(NULLIF(d.referrer_domain, '')) as referrer_domain
                FROM {$this->daily_table} d
                $daily_where
                AND (
                    (d.object_type = 'error' AND d.object_subtype = '404')
                    OR d.object_type = '404'
                )
                GROUP BY d.object_key
                ORDER BY views DESC
                LIMIT 20
                ",
                ...$params
            )
        );

        $search_params = [];
        $search_where = $this->build_event_filters($request, $search_params, 'e');
        $searches = $this->table_exists($this->events_table)
            ? $wpdb->get_results(
                $wpdb->prepare(
                    "
                    SELECT
                        MAX(e.post_id) as post_id,
                        MAX(e.object_type) as object_type,
                        MAX(e.object_id) as object_id,
                        MAX(e.object_subtype) as object_subtype,
                        e.object_key,
                        MAX(COALESCE(NULLIF(e.object_label, ''), 'Search')) as title,
                        MAX(COALESCE(NULLIF(e.object_url, ''), '')) as url,
                        COUNT(*) as views,
                        COUNT(DISTINCT e.visitor_id) as unique_visitors,
                        COUNT(DISTINCT e.session_id) as sessions
                    FROM {$this->events_table} e
                    $search_where
                    AND e.event_type = 'search'
                    GROUP BY e.object_key
                    ORDER BY views DESC
                    LIMIT 20
                    ",
                    ...$search_params
                )
            )
            : [];

        $archives = $wpdb->get_results(
            $wpdb->prepare(
                "
                SELECT
                    MAX(d.post_id) as post_id,
                    MAX(d.object_type) as object_type,
                    MAX(d.object_id) as object_id,
                    MAX(d.object_subtype) as object_subtype,
                    d.object_key,
                    MAX(COALESCE(NULLIF(d.object_label, ''), d.object_type)) as title,
                    MAX(COALESCE(NULLIF(d.object_url, ''), '')) as url,
                    SUM(d.views) as views,
                    SUM(d.unique_visitors) as unique_visitors,
                    SUM(d.sessions) as sessions
                FROM {$this->daily_table} d
                $daily_where
                AND d.object_type IN ('home', 'post_type_archive', 'taxonomy_archive', 'author_archive', 'date_archive')
                GROUP BY d.object_key
                ORDER BY views DESC
                LIMIT 20
                ",
                ...$params
            )
        );

        $quality_row = $wpdb->get_row(
            $wpdb->prepare(
                "
                SELECT
                    COALESCE(SUM(d.views), 0) as total_views,
                    COALESCE(SUM(CASE WHEN d.source = 'direct' THEN d.views ELSE 0 END), 0) as direct_views,
                    COALESCE(SUM(CASE WHEN NOT (d.source = 'anonymous' AND d.medium = 'aggregate') THEN d.views ELSE 0 END), 0) as technology_views,
                    COALESCE(SUM(CASE WHEN NOT (d.source = 'anonymous' AND d.medium = 'aggregate') AND (d.device_type = '' OR d.device_type = 'unknown') THEN d.views ELSE 0 END), 0) as unknown_device_views,
                    COALESCE(SUM(CASE WHEN NOT (d.source = 'anonymous' AND d.medium = 'aggregate') AND (d.browser = '' OR d.browser = 'unknown') THEN d.views ELSE 0 END), 0) as unknown_browser_views,
                    COALESCE(SUM(CASE WHEN NOT (d.source = 'anonymous' AND d.medium = 'aggregate') AND (d.os = '' OR d.os = 'unknown') THEN d.views ELSE 0 END), 0) as unknown_os_views,
                    COUNT(DISTINCT CASE WHEN d.object_label = '' THEN d.object_key END) as missing_labels,
                    COUNT(DISTINCT CASE WHEN d.object_url IS NULL OR d.object_url = '' THEN d.object_key END) as missing_urls
                FROM {$this->daily_table} d
                $daily_where
                ",
                ...$params
            )
        );

        $low_engagement = [];
        $forms = [];
        $goals = [];
        $downloads = [];
        $outbound = [];
        $micro_conversions = [];

        if ( $this->table_exists( $this->events_table ) ) {
            $event_params = [];
            $event_where = $this->build_event_filters($request, $event_params, 'e');
            $low_engagement_rows = $wpdb->get_results(
                $wpdb->prepare(
                    "
                    SELECT
                        MAX(e.post_id) as post_id,
                        MAX(e.object_type) as object_type,
                        MAX(e.object_id) as object_id,
                        MAX(e.object_subtype) as object_subtype,
                        e.object_key,
                        MAX(COALESCE(NULLIF(e.object_label, ''), '')) as title,
                        MAX(COALESCE(NULLIF(e.object_url, ''), '')) as url,
                        COUNT(CASE WHEN e.event_type = 'pageview' THEN 1 END) as views,
                        COUNT(DISTINCT e.visitor_id) as unique_visitors,
                        COUNT(DISTINCT e.session_id) as sessions,
                        COUNT(CASE WHEN e.event_type = 'engagement' THEN 1 END) as engagements
                    FROM {$this->events_table} e
                    $event_where
                    AND e.object_type NOT IN ('error', '404')
                    GROUP BY e.object_key
                    HAVING views >= 3 AND sessions > 0 AND engagements = 0
                    ORDER BY views DESC
                    LIMIT 20
                    ",
                    ...$event_params
                )
            );
            $low_engagement = array_map(function($row) use ($format_object) {
                $item = $format_object($row);
                $item['engagements'] = (int)($row->engagements ?? 0);
                $item['views_per_session'] = $item['sessions'] ? $item['views'] / $item['sessions'] : 0;

                return $item;
            }, $low_engagement_rows);

            $interaction_rows = $wpdb->get_results(
                $wpdb->prepare(
                    "
                    SELECT
                        MAX(e.post_id) as post_id,
                        MAX(e.object_type) as object_type,
                        MAX(e.object_id) as object_id,
                        MAX(e.object_subtype) as object_subtype,
                        e.object_key,
                        MAX(COALESCE(NULLIF(e.object_label, ''), NULLIF(e.object_url, ''), '')) as title,
                        MAX(COALESCE(NULLIF(e.object_url, ''), '')) as url,
                        COUNT(*) as value,
                        COUNT(*) as views,
                        COUNT(DISTINCT e.visitor_id) as unique_visitors,
                        COUNT(DISTINCT e.session_id) as sessions,
                        MAX(NULLIF(e.referrer_domain, '')) as referrer_domain
                    FROM {$this->events_table} e
                    $event_where
                    AND e.event_type IN ('download', 'outbound')
                    GROUP BY e.object_key
                    ORDER BY value DESC
                    LIMIT 50
                    ",
                    ...$event_params
                )
            );

            foreach ($interaction_rows as $row) {
                $item = $format_object($row);
                $item['referrer_domain'] = $row->referrer_domain ?? '';

                if ($row->object_type === 'download') {
                    $downloads[] = $item;
                } elseif ($row->object_type === 'outbound') {
                    $outbound[] = $item;
                }
            }

            $micro_rows = $wpdb->get_results(
                $wpdb->prepare(
                    "
                    SELECT
                        MAX(e.post_id) as post_id,
                        MAX(e.object_type) as object_type,
                        MAX(e.object_id) as object_id,
                        MAX(e.object_subtype) as object_subtype,
                        e.object_key,
                        e.event_type,
                        MAX(COALESCE(NULLIF(e.object_label, ''), e.object_key, e.event_type)) as title,
                        MAX(COALESCE(NULLIF(e.object_url, ''), '')) as url,
                        COUNT(*) as value,
                        COUNT(*) as views,
                        COUNT(DISTINCT e.visitor_id) as unique_visitors,
                        COUNT(DISTINCT e.session_id) as sessions
                    FROM {$this->events_table} e
                    $event_where
                    AND e.event_type IN ('subscribe', 'register', 'login', 'search', 'scroll', 'time_on_page', 'play', 'custom_event')
                    GROUP BY e.event_type, e.object_key
                    ORDER BY value DESC
                    LIMIT 50
                    ",
                    ...$event_params
                )
            );

            $micro_conversions = array_map(function($row) use ($format_object) {
                $item = $format_object($row);
                $item['event_type'] = $row->event_type ?? '';

                return $item;
            }, $micro_rows);

            $form_rows = $wpdb->get_results(
                $wpdb->prepare(
                    "
                    SELECT
                        MAX(e.post_id) as post_id,
                        MAX(e.object_type) as object_type,
                        MAX(e.object_id) as object_id,
                        MAX(e.object_subtype) as object_subtype,
                        e.object_key,
                        MAX(COALESCE(NULLIF(e.object_label, ''), e.object_key, 'Form')) as title,
                        MAX(COALESCE(NULLIF(e.object_url, ''), '')) as url,
                        COUNT(CASE WHEN e.event_type = 'form_start' THEN 1 END) as starts,
                        COUNT(CASE WHEN e.event_type = 'form_submit' THEN 1 END) as submits,
                        COUNT(CASE WHEN e.event_type = 'form_error' THEN 1 END) as errors,
                        COUNT(DISTINCT e.visitor_id) as unique_visitors,
                        COUNT(DISTINCT e.session_id) as sessions
                    FROM {$this->events_table} e
                    $event_where
                    AND e.event_type IN ('form_start', 'form_submit', 'form_error')
                    GROUP BY e.object_key
                    ORDER BY submits DESC, starts DESC
                    LIMIT 50
                    ",
                    ...$event_params
                )
            );

            $forms = array_map(function($row) use ($format_object) {
                $item = $format_object($row);
                $item['starts'] = (int)($row->starts ?? 0);
                $item['submits'] = (int)($row->submits ?? 0);
                $item['errors'] = (int)($row->errors ?? 0);
                $item['value'] = $item['submits'];
                $item['conversion_rate'] = $item['starts'] ? ( $item['submits'] / $item['starts'] ) * 100 : null;

                return $item;
            }, $form_rows);

            $goals = $this->get_goal_performance($request, $event_where, $event_params);
        }

        $total_views = max(1, (int)($quality_row->total_views ?? 0));
		$technology_views = max( 1, (int) ( $quality_row->technology_views ?? 0 ) );
        $data_quality = [
            [
                'key' => 'direct',
                'label' => __('Direct traffic', 'wphave'),
                'value' => (int)($quality_row->direct_views ?? 0),
                'percent' => ((int)($quality_row->direct_views ?? 0) / $total_views) * 100,
            ],
            [
                'key' => 'unknown_device',
                'label' => __('Unrecognized devices', 'wphave'),
                'value' => (int)($quality_row->unknown_device_views ?? 0),
                'percent' => ((int)($quality_row->unknown_device_views ?? 0) / $technology_views) * 100,
            ],
            [
                'key' => 'unknown_browser',
                'label' => __('Unrecognized browsers', 'wphave'),
                'value' => (int)($quality_row->unknown_browser_views ?? 0),
                'percent' => ((int)($quality_row->unknown_browser_views ?? 0) / $technology_views) * 100,
            ],
            [
                'key' => 'unknown_os',
                'label' => __('Unrecognized operating systems', 'wphave'),
                'value' => (int)($quality_row->unknown_os_views ?? 0),
                'percent' => ((int)($quality_row->unknown_os_views ?? 0) / $technology_views) * 100,
            ],
            [
                'key' => 'missing_labels',
                'label' => __('Targets without label', 'wphave'),
                'value' => (int)($quality_row->missing_labels ?? 0),
                'percent' => 0,
            ],
            [
                'key' => 'missing_urls',
                'label' => __('Targets without URL', 'wphave'),
                'value' => (int)($quality_row->missing_urls ?? 0),
                'percent' => 0,
            ],
        ];

        return rest_ensure_response([
            'errors' => array_map(function($row) use ($format_object) {
                $item = $format_object($row);
                $item['referrer_domain'] = $row->referrer_domain ?? '';

                return $item;
            }, $errors),
            'searches' => array_map($format_object, $searches),
            'archives' => array_map($format_object, $archives),
            'forms' => $forms,
            'goals' => $goals,
            'goalDaily' => $this->get_goal_daily_performance($request),
            'campaignConversions' => $this->get_campaign_conversion_performance($request),
            'microConversions' => $micro_conversions,
            'recommendations' => $this->get_recommendations([
                'errors' => $errors,
                'low_engagement' => $low_engagement,
                'forms' => $forms,
                'goals' => $goals,
                'downloads' => $downloads,
                'outbound' => $outbound,
                'micro_conversions' => $micro_conversions,
                'data_quality' => $data_quality,
            ]),
            'downloads' => $downloads,
            'outbound' => $outbound,
            'lowEngagement' => $low_engagement,
            'dataQuality' => $data_quality,
        ]);
    }

/**
     * Return recommendations.
     *
     * @param array $data Data.
     * @return array Return recommendations.
     */

    private function get_recommendations(array $data): array {
        $items             = [];
        $errors            = $data['errors'] ?? [];
        $low_engagement    = $data['low_engagement'] ?? [];
        $forms             = $data['forms'] ?? [];
        $goals             = $data['goals'] ?? [];
        $downloads         = $data['downloads'] ?? [];
        $outbound          = $data['outbound'] ?? [];
        $micro_conversions = $data['micro_conversions'] ?? [];
        $data_quality      = $data['data_quality'] ?? [];
        $quality_by_key    = [];

        foreach ( $data_quality as $quality_item ) {
            $quality_by_key[ $quality_item['key'] ?? '' ] = $quality_item;
        }

        $error_views = array_sum(
            array_map(
                fn( $item ) => (int) ( $item->value ?? $item->views ?? 0 ),
                $errors
            )
        );

        if ( $error_views > 0 ) {
            $top_error = $errors[0] ?? null;
            $items[]   = $this->build_recommendation(
                'redirect',
                'warning',
                95,
                __('Fix URLs that currently end in a 404', 'wphave'),
                sprintf(
                    /* translators: 1: total 404 views, 2: number of affected URLs. */
                    _n(
                        '%1$d visit ended on %2$d missing URL in the selected period.',
                        '%1$d visits ended on %2$d missing URLs in the selected period.',
                        $error_views,
                        'wphave'
                    ),
                    $error_views,
                    count( $errors )
                ),
                $error_views,
                [ 'analytics', 'conversions' ],
                [
                    'metric' => '404_views',
                    'count'  => $error_views,
                    'items'  => count( $errors ),
                    'target' => (string) ( $top_error->url ?? $top_error->object_url ?? '' ),
                ],
                [ 'screen' => 'analytics', 'section' => 'insights' ]
            );
        }

        foreach ( $forms as $form ) {
            $starts          = (int) ( $form['starts'] ?? 0 );
            $submits         = (int) ( $form['submits'] ?? 0 );
            $errors_count    = (int) ( $form['errors'] ?? 0 );
            $conversion_rate = (float) ( $form['conversion_rate'] ?? 0 );
            $title           = $form['title'] ?? __('Unknown form', 'wphave');

            if ( $starts >= 3 && $submits === 0 ) {
                $items[] = $this->build_recommendation(
                    'form_no_submits',
                    'warning',
                    92,
                    sprintf(
                        /* translators: %s: form title. */
                        __('Check form: %s', 'wphave'),
                        $title
                    ),
                    sprintf(
                        /* translators: %d: number of form starts. */
                        _n(
                            'The form was started %d time but produced no submit.',
                            'The form was started %d times but produced no submits.',
                            $starts,
                            'wphave'
                        ),
                        $starts
                    ),
                    $starts,
                    [ 'analytics', 'conversions' ],
                    [
                        'metric'  => 'form_starts_without_submit',
                        'starts'  => $starts,
                        'submits' => $submits,
                        'errors'  => $errors_count,
                        'target'  => $title,
                    ],
                    [ 'screen' => 'conversions', 'section' => 'forms' ]
                );

                continue;
            }

            if ( $starts >= 5 && $errors_count >= 2 && ( $errors_count / $starts ) >= 0.25 ) {
                $items[] = $this->build_recommendation(
                    'form_errors',
                    'warning',
                    88,
                    sprintf(
                        /* translators: %s: form title. */
                        __('Reduce errors in form: %s', 'wphave'),
                        $title
                    ),
                    sprintf(
                        /* translators: 1: error count, 2: start count. */
                        __('%1$d errors were recorded across %2$d form starts.', 'wphave'),
                        $errors_count,
                        $starts
                    ),
                    $errors_count,
                    [ 'analytics', 'conversions' ],
                    [
                        'metric' => 'form_errors',
                        'starts' => $starts,
                        'errors' => $errors_count,
                        'target' => $title,
                    ],
                    [ 'screen' => 'conversions', 'section' => 'forms' ]
                );
            } elseif ( $starts >= 5 && $conversion_rate < 20 ) {
                $items[] = $this->build_recommendation(
                    'form_conversion',
                    'warning',
                    84,
                    sprintf(
                        /* translators: %s: form title. */
                        __('Improve form conversion: %s', 'wphave'),
                        $title
                    ),
                    sprintf(
                        /* translators: 1: conversion rate, 2: start count. */
                        __('Only %1$s%% of %2$d starts produced a submit.', 'wphave'),
                        number_format_i18n( $conversion_rate, 1 ),
                        $starts
                    ),
                    round( $conversion_rate, 1 ),
                    [ 'analytics', 'conversions' ],
                    [
                        'metric'          => 'form_conversion_rate',
                        'starts'          => $starts,
                        'submits'         => $submits,
                        'conversion_rate' => round( $conversion_rate, 1 ),
                        'target'          => $title,
                    ],
                    [ 'screen' => 'conversions', 'section' => 'forms' ]
                );
            }
        }

        $low_engagement_views = array_sum(
            array_map(fn( $item ) => (int) ( $item['views'] ?? $item['value'] ?? 0 ), $low_engagement)
        );

        if ( $low_engagement_views > 0 ) {
            $items[] = $this->build_recommendation(
                'content',
                'warning',
                78,
                __('Add a clear next step to low-engagement content', 'wphave'),
                sprintf(
                    /* translators: 1: view count, 2: number of affected targets. */
                    _n(
                        '%1$d view across %2$d target produced no engagement signal.',
                        '%1$d views across %2$d targets produced no engagement signal.',
                        $low_engagement_views,
                        'wphave'
                    ),
                    $low_engagement_views,
                    count( $low_engagement )
                ),
                $low_engagement_views,
                [ 'analytics', 'conversions' ],
                [
                    'metric' => 'views_without_engagement',
                    'count'  => $low_engagement_views,
                    'items'  => count( $low_engagement ),
                ],
                [ 'screen' => 'analytics', 'section' => 'insights' ]
            );
        }

        $download_count = array_sum(array_map(fn( $item ) => (int) ( $item['value'] ?? 0 ), $downloads));

        if ( $download_count >= 3 ) {
            $top_download = $downloads[0] ?? [];
            $items[]      = $this->build_recommendation(
                'download',
                'info',
                58,
                __('Use proven download interest as a conversion signal', 'wphave'),
                sprintf(
                    /* translators: 1: download count, 2: most downloaded file. */
                    _n(
                        '%1$d download was tracked. The leading file is “%2$s”.',
                        '%1$d downloads were tracked. The leading file is “%2$s”.',
                        $download_count,
                        'wphave'
                    ),
                    $download_count,
                    $top_download['title'] ?? __('Unknown file', 'wphave')
                ),
                $download_count,
                [ 'conversions' ],
                [
                    'metric' => 'downloads',
                    'count'  => $download_count,
                    'target' => $top_download['title'] ?? '',
                ],
                [ 'screen' => 'analytics', 'section' => 'insights' ]
            );
        }

        $outbound_count = array_sum(array_map(fn( $item ) => (int) ( $item['value'] ?? 0 ), $outbound));

        if ( $outbound_count >= 3 ) {
            $items[] = $this->build_recommendation(
                'outbound',
                'info',
                52,
                __('Review high-intent outbound clicks', 'wphave'),
                sprintf(
                    /* translators: %d: outbound click count. */
                    _n(
                        '%d outbound click may represent intent that is not yet measured as a goal.',
                        '%d outbound clicks may represent intent that is not yet measured as a goal.',
                        $outbound_count,
                        'wphave'
                    ),
                    $outbound_count
                ),
                $outbound_count,
                [ 'conversions' ],
                [ 'metric' => 'outbound_clicks', 'count' => $outbound_count ],
                [ 'screen' => 'analytics', 'section' => 'insights' ]
            );
        }

        $micro_conversion_count = array_sum(
            array_map(fn( $item ) => (int) ( $item['value'] ?? 0 ), $micro_conversions)
        );

        if ( $micro_conversion_count >= 5 ) {
            $items[] = $this->build_recommendation(
                'micro_conversion',
                'info',
                48,
                __('Review recurring micro-conversions', 'wphave'),
                sprintf(
                    /* translators: %d: micro-conversion count. */
                    _n(
                        '%d intent signal was tracked and may qualify as an explicit goal.',
                        '%d intent signals were tracked and may qualify as explicit goals.',
                        $micro_conversion_count,
                        'wphave'
                    ),
                    $micro_conversion_count
                ),
                $micro_conversion_count,
                [ 'conversions' ],
                [ 'metric' => 'micro_conversions', 'count' => $micro_conversion_count ],
                [ 'screen' => 'analytics', 'section' => 'insights' ]
            );
        }

        $direct = $quality_by_key['direct'] ?? null;

        if ( $direct && (float) ( $direct['percent'] ?? 0 ) > 70 ) {
            $direct_percent = round((float) $direct['percent'], 1);
            $items[]        = $this->build_recommendation(
                'attribution',
                'info',
                64,
                __('Improve campaign attribution', 'wphave'),
                sprintf(
                    /* translators: %s: direct traffic percentage. */
                    __('%s%% of tracked traffic is classified as direct in this period.', 'wphave'),
                    number_format_i18n($direct_percent, 1)
                ),
                $direct_percent,
                [ 'analytics', 'conversions' ],
                [
                    'metric'  => 'direct_traffic_share',
                    'percent' => $direct_percent,
                    'count'   => (int) ( $direct['value'] ?? 0 ),
                ],
                [ 'screen' => 'conversions', 'section' => 'attribution' ]
            );
        }

        $total_goal_conversions = array_sum(
            array_map(fn( $goal ) => (int) ( $goal['conversions'] ?? 0 ), $goals)
        );

        if ( $goals && $total_goal_conversions === 0 ) {
            $items[] = $this->build_recommendation(
                'goals_no_conversions',
                'warning',
                90,
                __('Active goals produced no conversions', 'wphave'),
                sprintf(
                    /* translators: %d: active goal count. */
                    _n(
                        '%d active goal matched no event in the selected period.',
                        '%d active goals matched no events in the selected period.',
                        count( $goals ),
                        'wphave'
                    ),
                    count( $goals )
                ),
                count( $goals ),
                [ 'analytics', 'conversions' ],
                [
                    'metric'      => 'active_goals_without_conversions',
                    'active_goals' => count( $goals ),
                    'conversions' => 0,
                ],
                [ 'screen' => 'conversions', 'section' => 'goals' ]
            );
        } elseif ( $total_goal_conversions > 0 ) {
            $unvalued_conversions = array_sum(
                array_map(
                    fn( $goal ) => (float) ( $goal['value'] ?? 0 ) <= 0
                        ? (int) ( $goal['conversions'] ?? 0 )
                        : 0,
                    $goals
                )
            );

            if ( $unvalued_conversions > 0 ) {
                $items[] = $this->build_recommendation(
                    'goal_value',
                    'info',
                    70,
                    __('Assign a value to converting goals', 'wphave'),
                    sprintf(
                        /* translators: %d: conversion count without an assigned goal value. */
                        _n(
                            '%d conversion came from a goal without an assigned value.',
                            '%d conversions came from goals without an assigned value.',
                            $unvalued_conversions,
                            'wphave'
                        ),
                        $unvalued_conversions
                    ),
                    $unvalued_conversions,
                    [ 'conversions' ],
                    [
                        'metric'      => 'conversions_without_goal_value',
                        'conversions' => $unvalued_conversions,
                    ],
                    [ 'screen' => 'conversions', 'section' => 'goals' ]
                );
            }
        }

        foreach ( [ 'missing_labels', 'missing_urls' ] as $quality_key ) {
            $quality_item = $quality_by_key[ $quality_key ] ?? null;
            $count        = (int) ( $quality_item['value'] ?? 0 );

            if ( $count <= 0 ) {
                continue;
            }

            $items[] = $this->build_recommendation(
                'data_quality',
                'warning',
                72,
                $quality_item['label'] ?? __('Incomplete tracking data', 'wphave'),
                sprintf(
                    /* translators: 1: affected target count, 2: data quality label. */
                    _n(
                        '%1$d tracked target is classified as “%2$s”.',
                        '%1$d tracked targets are classified as “%2$s”.',
                        $count,
                        'wphave'
                    ),
                    $count,
                    $quality_item['label'] ?? __('incomplete', 'wphave')
                ),
                $count,
                [ 'analytics', 'conversions' ],
                [ 'metric' => $quality_key, 'count' => $count ],
                [ 'screen' => 'analytics', 'section' => 'insights' ]
            );
        }

        usort(
            $items,
            fn( $left, $right ) => ( $right['priority'] ?? 0 ) <=> ( $left['priority'] ?? 0 )
        );

        $selected       = [];
        $surface_counts = [];

        foreach ( $items as $item ) {
            $available_surfaces = array_filter(
                $item['surfaces'] ?? [],
                fn( $surface ) => ( $surface_counts[ $surface ] ?? 0 ) < 8
            );

            if ( ! $available_surfaces ) {
                continue;
            }

            $item['surfaces'] = array_values($available_surfaces);
            $selected[] = $item;

            foreach ( $item['surfaces'] as $surface ) {
                $surface_counts[ $surface ] = ( $surface_counts[ $surface ] ?? 0 ) + 1;
            }
        }

        return $selected;
    }

    /**
     * Build a recommendation using the shared analytics and conversion contract.
     *
     * @param string $type Recommendation type.
     * @param string $severity Recommendation severity.
     * @param int    $priority Sort priority between 0 and 100.
     * @param string $title Recommendation title.
     * @param string $message Evidence-based recommendation message.
     * @param float  $impact Numeric impact used by visual summaries.
     * @param array  $surfaces Screens where the recommendation is relevant.
     * @param array  $evidence Machine-readable evidence for the recommendation.
     * @param array  $destination Suggested destination for further investigation.
     * @return array Recommendation.
     */

    private function build_recommendation(
        string $type,
        string $severity,
        int $priority,
        string $title,
        string $message,
        float $impact,
        array $surfaces,
        array $evidence,
        array $destination
    ): array {
        return [
            'type'        => $type,
            'status'      => $severity,
            'severity'    => $severity,
            'confidence'  => 'measured',
            'priority'    => max(0, min(100, $priority)),
            'impact'      => $impact,
            'value'       => $impact,
            'title'       => $title,
            'message'     => $message,
            'surfaces'    => array_values(array_unique($surfaces)),
            'evidence'    => $evidence,
            'destination' => $destination,
        ];
    }

/**
     * API timeseries.
     *
     * @param WP_REST_Request $request REST request.
     */


}
