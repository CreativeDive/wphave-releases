<?php

require_once wphave_dir() . 'inc/features/security/boundaries/index.php';

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Analytics_Report_Conversions {

/**
     * API goals.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_goals(WP_REST_Request $request) {
        if ( ! $this->table_exists( $this->events_table ) ) {
            return rest_ensure_response([
                'items' => $this->goals->get_items(),
                'performance' => [],
                'daily' => [],
                'campaigns' => [],
            ]);
        }

        $params = [];
        $where = $this->build_event_filters($request, $params, 'e');

        return rest_ensure_response([
            'items' => $this->goals->get_items(),
            'performance' => $this->get_goal_performance($request, $where, $params),
            'daily' => $this->get_goal_daily_performance($request),
            'campaigns' => $this->get_campaign_conversion_performance($request),
        ]);
    }

/**
     * API conversion events.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_conversion_events(WP_REST_Request $request, bool $for_export = false) {
        if ( ! $this->table_exists( $this->events_table ) ) {
            return rest_ensure_response([
                'items' => [],
                'total' => 0,
                'page' => 1,
                'perPage' => 20,
            ]);
        }

        global $wpdb;

        $page = max(1, absint($request->get_param('page') ?: 1));
        // QUERY INVARIANT: Deep OFFSET scans are not a bounded reporting read.
        if ($page > 1000) {
            return new WP_Error(
                'wphave_analytics_page_too_deep',
                __('The requested page is too deep.', 'wphave'),
                ['status' => 400],
            );
        }
        // EXPORT INVARIANT: A query parameter cannot opt an ordinary report into
        // the much larger export batch; only the server-owned export path may.
        $max_per_page = $for_export ? 10000 : 100;
        $per_page = max(1, min($max_per_page, absint($request->get_param('per_page') ?: 20)));
        $offset = ($page - 1) * $per_page;
        $params = [];
        $where = $this->build_event_filters($request, $params, 'e');
        $where .= " AND e.event_type IN ('" . implode("', '", array_map('esc_sql', WPHAVE_Analytics_Event_Types::CONVERSION)) . "')";
        $raw_goal_id = $request->get_param('goal_id');
        $raw_event_type = $request->get_param('event_type');
        // FILTER INVARIANT: A malformed filter must never collapse into a
        // different goal or silently broaden a private event query.
        $invalid_goal_id = $raw_goal_id !== null && (
            !is_string($raw_goal_id) ||
            strlen($raw_goal_id) > 190 ||
            sanitize_key($raw_goal_id) !== $raw_goal_id
        );
        $invalid_event_type = $raw_event_type !== null && (
            !is_string($raw_event_type) ||
            strlen($raw_event_type) > 40 ||
            sanitize_key($raw_event_type) !== $raw_event_type
        );
        if ($invalid_goal_id || $invalid_event_type) {
            return new WP_Error(
                'wphave_analytics_filter_invalid',
                __('Invalid conversion event filter.', 'wphave'),
                ['status' => 400],
            );
        }
        $goal_id = $raw_goal_id ?? '';
        $event_type = $raw_event_type ?? '';
		$allowed_event_types = WPHAVE_Analytics_Event_Types::CONVERSION;
		if ($event_type !== '' && !in_array($event_type, $allowed_event_types, true)) {
			return new WP_Error(
				'wphave_analytics_filter_invalid',
				__('Invalid conversion event filter.', 'wphave'),
				['status' => 400],
			);
		}
		$sortable_columns = [ 'viewed_at', 'event_type', 'object_label', 'source', 'campaign', 'device_type', 'is_logged_in' ];
		$requested_orderby = sanitize_key( $request->get_param( 'orderby' ) ?? '' );
		$orderby = in_array( $requested_orderby, $sortable_columns, true ) ? $requested_orderby : 'viewed_at';
		$order = strtolower( sanitize_key( $request->get_param( 'order' ) ?? '' ) ) === 'asc' ? 'ASC' : 'DESC';

        if ($event_type && in_array($event_type, $allowed_event_types, true)) {
            $where .= ' AND e.event_type = %s';
            $params[] = $event_type;
        }

        if ($goal_id) {
            $goal = $this->get_goal_by_id($goal_id);

            if ( ! $goal ) {
                return rest_ensure_response([
                    'items' => [],
                    'total' => 0,
                    'page' => $page,
                    'perPage' => $per_page,
                ]);
            }

            if (!$event_type) {
                $where .= ' AND e.event_type = %s';
                $params[] = $this->goal_event_type($goal['type']);
            }
            $this->append_goal_filter($where, $params, $goal);
        } elseif (!$event_type) {
            $where .= " AND e.event_type != 'pageview'";
        }

        $total = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$this->events_table} e $where",
                ...$params
            )
        );

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "
                SELECT
                    e.id,
                    e.event_type,
                    e.goal_id,
                    e.viewed_at,
                    e.post_id,
                    e.object_type,
                    e.object_id,
                    e.object_subtype,
                    e.object_key,
                    e.object_label,
                    e.object_url,
                    e.page_url,
                    e.referrer_url,
                    e.referrer_domain,
                    e.source,
                    e.medium,
                    e.campaign,
                    e.device_type,
                    e.browser,
                    e.os,
                    e.is_logged_in
                FROM {$this->events_table} e
                $where
				ORDER BY e.{$orderby} {$order}, e.id {$order}
                LIMIT %d OFFSET %d
                ",
                ...array_merge($params, [$per_page, $offset])
            )
        );

        return rest_ensure_response([
            'items' => array_map([$this, 'format_conversion_event'], $rows),
            'total' => $total,
            'page' => $page,
            'perPage' => $per_page,
        ]);
    }

/**
     * API export goals.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_export_goals(WP_REST_Request $request) {
        $rows = array_map(function($goal) {
            return [
                'id' => $goal['id'],
                'label' => $goal['label'],
                'type' => $goal['type'],
                'match' => $goal['match'],
                'value' => $goal['value'],
                'enabled' => ! empty($goal['enabled']) ? '1' : '0',
            ];
        }, $this->goals->get_items());

        return $this->csv_response('wphave-conversion-goals.csv', ['id', 'label', 'type', 'match', 'value', 'enabled'], $rows);
    }

/**
     * API export conversion events.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_export_conversion_events(WP_REST_Request $request) {
        // EXPORT INVARIANT: A CSV export is one bounded server-owned first batch;
        // client pagination must not turn it into a deep-offset SQL scan.
        $request->set_param('page', 1);
        $request->set_param('per_page', 10000);
        $event_response = $this->api_conversion_events($request, true);
        if (is_wp_error($event_response)) {
            return $event_response;
        }
        $events = $event_response->get_data();
        $headers = [
            'id',
            'event_type',
            'goal_id',
            'viewed_at',
            'label',
            'object_type',
            'object_key',
            'object_url',
            'page_url',
            'referrer_domain',
            'source',
            'medium',
            'campaign',
            'device_type',
            'browser',
            'os',
            'is_logged_in',
        ];
        $rows = array_map(function($event) {
            return [
                'id' => $event['id'],
                'event_type' => $event['event_type'],
                'goal_id' => $event['goal_id'],
                'viewed_at' => $event['viewed_at'],
                'label' => $event['label'],
                'object_type' => $event['object_type'],
                'object_key' => $event['object_key'],
                'object_url' => $event['object_url'],
                'page_url' => $event['page_url'],
                'referrer_domain' => $event['referrer_domain'],
                'source' => $event['source'],
                'medium' => $event['medium'],
                'campaign' => $event['campaign'],
                'device_type' => $event['device_type'],
                'browser' => $event['browser'],
                'os' => $event['os'],
                'is_logged_in' => $event['is_logged_in'] ? '1' : '0',
            ];
        }, $events['items'] ?? []);

        return $this->csv_response('wphave-conversion-events.csv', $headers, $rows);
    }

/**
     * Return goal performance.
     *
     * @param WP_REST_Request $request REST request.
     * @param string $event_where Event where.
     * @param array $event_params Event params.
     * @return array Return goal performance.
     */

    private function get_goal_performance(WP_REST_Request $request, string $event_where, array $event_params): array {
        $goals = array_filter($this->goals->get_items(), fn($goal) => ! empty($goal['enabled']));

        if ( ! $goals || ! $this->table_exists( $this->events_table ) ) {
            return [];
        }

        global $wpdb;
        $items = [];

        foreach ($goals as $goal) {
            $params = $event_params;
            $where = $event_where;
            $event_type = $this->goal_event_type($goal['type']);
            $where .= ' AND e.event_type = %s';
            $params[] = $event_type;

            $this->append_goal_filter($where, $params, $goal);

            $row = $wpdb->get_row(
                $wpdb->prepare(
                    "
                    SELECT
                        COUNT(*) as conversions,
                        COUNT(DISTINCT e.visitor_id) as visitors,
                        COUNT(DISTINCT e.session_id) as sessions
                    FROM {$this->events_table} e
                    $where
                    ",
                    ...$params
                )
            );

            $conversions = (int)($row->conversions ?? 0);
            $items[] = array_merge($goal, [
                'conversions' => $conversions,
                'visitors' => (int)($row->visitors ?? 0),
                'sessions' => (int)($row->sessions ?? 0),
                'estimated_value' => $conversions * (float)$goal['value'],
            ]);
        }

        usort($items, fn($a, $b) => $b['estimated_value'] <=> $a['estimated_value']);

        return $items;
    }

/**
     * Return goal daily performance.
     *
     * @param WP_REST_Request $request REST request.
     * @return array Return goal daily performance.
     */

    private function get_goal_daily_performance(WP_REST_Request $request): array {
        $goals = array_filter($this->goals->get_items(), fn($goal) => ! empty($goal['enabled']));

        if ( ! $goals || ! $this->table_exists( $this->events_table ) ) {
            return [];
        }

        global $wpdb;

		$range = $this->get_event_date_range( $request );
        $days = [];
        $cursor = strtotime($range['from']);
        $end = strtotime($range['to']);

        while ( $cursor <= $end ) {
            $days[] = date('Y-m-d', $cursor);
            $cursor = strtotime('+1 day', $cursor);
        }

        $items = [];

        foreach ($goals as $goal) {
            $params = [];
            $where = $this->build_event_filters($request, $params, 'e');
            $event_type = $this->goal_event_type($goal['type']);
            $where .= ' AND e.event_type = %s';
            $params[] = $event_type;

            $this->append_goal_filter($where, $params, $goal);

            $rows = $wpdb->get_results(
                $wpdb->prepare(
                    "
                    SELECT
                        DATE(e.viewed_at) as date,
                        COUNT(*) as conversions,
                        COUNT(DISTINCT e.visitor_id) as visitors,
                        COUNT(DISTINCT e.session_id) as sessions
                    FROM {$this->events_table} e
                    $where
                    GROUP BY DATE(e.viewed_at)
                    ORDER BY date ASC
                    ",
                    ...$params
                )
            );
            $rows_by_date = [];

            foreach ($rows as $row) {
                $rows_by_date[$row->date] = $row;
            }

            foreach ($days as $date) {
                $row = $rows_by_date[$date] ?? null;
                $conversions = (int)($row->conversions ?? 0);

                $items[] = [
                    'date' => $date,
                    'goal_id' => $goal['id'],
                    'label' => $goal['label'],
                    'type' => $goal['type'],
                    'conversions' => $conversions,
                    'visitors' => (int)($row->visitors ?? 0),
                    'sessions' => (int)($row->sessions ?? 0),
                    'estimated_value' => $conversions * (float)$goal['value'],
                ];
            }
        }

        return $items;
    }

/**
     * Return campaign conversion performance.
     *
     * @param WP_REST_Request $request REST request.
     * @return array Return campaign conversion performance.
     */

    private function get_campaign_conversion_performance(WP_REST_Request $request): array {
        $goals = array_filter($this->goals->get_items(), fn($goal) => ! empty($goal['enabled']));

        if ( ! $goals || ! $this->table_exists( $this->events_table ) || ! $this->table_exists( $this->daily_table ) ) {
            return [];
        }

        global $wpdb;

		$traffic_params = [];
		$event_range = $this->get_event_date_range( $request );
		$traffic_where = $this->build_filters( $request, $traffic_params, $event_range );
        $traffic_rows = $wpdb->get_results(
            $wpdb->prepare(
                "
                SELECT
                    campaign,
                    source,
                    medium,
                    SUM(views) as views,
                    SUM(unique_visitors) as visitors,
                    SUM(sessions) as sessions
                FROM {$this->daily_table}
                $traffic_where
                AND campaign != ''
                GROUP BY campaign, source, medium
                ",
                ...$traffic_params
            )
        );
        $items = [];

        foreach ($traffic_rows as $row) {
            $key = implode('|', [$row->campaign, $row->source, $row->medium]);
            $items[$key] = [
                'campaign' => $row->campaign,
                'source' => $row->source,
                'medium' => $row->medium,
                'value' => (int)$row->views,
                'views' => (int)$row->views,
                'visitors' => (int)$row->visitors,
                'sessions' => (int)$row->sessions,
                'conversions' => 0,
                'conversion_sessions' => 0,
                'conversion_visitors' => 0,
                'estimated_value' => 0,
                'top_goal' => '',
                'goals' => [],
            ];
        }

        foreach ($goals as $goal) {
            $params = [];
            $where = $this->build_event_filters($request, $params, 'e');
            $event_type = $this->goal_event_type($goal['type']);
            $where .= ' AND e.event_type = %s AND e.campaign != %s';
            $params[] = $event_type;
            $params[] = '';

            $this->append_goal_filter($where, $params, $goal);

            $rows = $wpdb->get_results(
                $wpdb->prepare(
                    "
                    SELECT
                        e.campaign,
                        e.source,
                        e.medium,
                        COUNT(*) as conversions,
                        COUNT(DISTINCT e.visitor_id) as visitors,
                        COUNT(DISTINCT e.session_id) as sessions
                    FROM {$this->events_table} e
                    $where
                    GROUP BY e.campaign, e.source, e.medium
                    ",
                    ...$params
                )
            );

            foreach ($rows as $row) {
                $key = implode('|', [$row->campaign, $row->source, $row->medium]);

                if ( ! isset($items[$key]) ) {
                    $items[$key] = [
                        'campaign' => $row->campaign,
                        'source' => $row->source,
                        'medium' => $row->medium,
                        'value' => 0,
                        'views' => 0,
                        'visitors' => 0,
                        'sessions' => 0,
                        'conversions' => 0,
                        'conversion_sessions' => 0,
                        'conversion_visitors' => 0,
                        'estimated_value' => 0,
                        'top_goal' => '',
                        'goals' => [],
                    ];
                }

                $conversions = (int)($row->conversions ?? 0);
                $estimated_value = $conversions * (float)$goal['value'];
                $items[$key]['conversions'] += $conversions;
                $items[$key]['conversion_sessions'] += (int)($row->sessions ?? 0);
                $items[$key]['conversion_visitors'] += (int)($row->visitors ?? 0);
                $items[$key]['estimated_value'] += $estimated_value;
                $items[$key]['goals'][] = [
                    'id' => $goal['id'],
                    'label' => $goal['label'],
                    'type' => $goal['type'],
                    'conversions' => $conversions,
                    'estimated_value' => $estimated_value,
                ];
            }
        }

        $items = array_values(array_map(function($item) {
            usort($item['goals'], fn($a, $b) => $b['conversions'] <=> $a['conversions']);
            $item['top_goal'] = $item['goals'][0]['label'] ?? '';
            $item['conversion_rate'] = $item['sessions'] ? ($item['conversions'] / $item['sessions']) * 100 : 0;

            return $item;
        }, $items));

        usort($items, fn($a, $b) => $b['estimated_value'] <=> $a['estimated_value'] ?: $b['conversions'] <=> $a['conversions']);

        return array_slice($items, 0, 50);
    }

/**
     * Goal event type.
     *
     * @param string $type Type.
     * @return string Goal event type.
     */

    private function goal_event_type(string $type): string {
        $map = [
            'form_submit' => 'form_submit',
            'download' => 'download',
            'outbound' => 'outbound',
            'click' => 'click',
            'pageview' => 'pageview',
            'subscribe' => 'subscribe',
            'register' => 'register',
            'login' => 'login',
            'search' => 'search',
            'scroll' => 'scroll',
            'time_on_page' => 'time_on_page',
            'play' => 'play',
            'custom_event' => 'custom_event',
        ];

        return $map[$type] ?? 'form_submit';
    }

/**
     * Return goal by ID.
     *
     * @param string $goal_id Goal ID.
     * @return ?array Return goal by ID.
     */

    private function get_goal_by_id(string $goal_id): ?array {
        foreach ($this->goals->get_items() as $goal) {
            if (($goal['id'] ?? '') === $goal_id) {
                return $goal;
            }
        }

        return null;
    }

/**
     * Append goal filter.
     *
     * @param string $where Where.
     * @param array $params Params.
     * @param array $goal Goal.
     * @return void
     */

    private function append_goal_filter(string &$where, array &$params, array $goal): void {
        $goal_id = sanitize_key($goal['id'] ?? '');
        $match = trim((string)($goal['match'] ?? ''));

        if ( $match !== '' ) {
            $this->append_goal_match_filter($where, $params, $goal, $match);
            return;
        }

        if ( $match === '' && $this->goal_counts_all_events_when_unmatched( $goal ) ) {
            return;
        }

        if ( $goal_id && $match === '' ) {
            $where .= ' AND e.goal_id = %s';
            $params[] = $goal_id;
            return;
        }
    }

/**
     * Append goal match filter.
     *
     * @param string $where Where.
     * @param array $params Params.
     * @param array $goal Goal.
     * @param string $match Match.
     * @return void
     */

    private function append_goal_match_filter(string &$where, array &$params, array $goal, string $match): void {
        global $wpdb;

        if (($goal['type'] ?? '') === 'pageview') {
            $where .= ' AND (e.object_url LIKE %s OR e.object_key = %s)';
            $params[] = '%' . $wpdb->esc_like($match) . '%';
            $params[] = $match;
        } else {
            $where .= ' AND (e.object_key = %s OR e.object_label = %s OR e.object_url LIKE %s)';
            $params[] = $match;
            $params[] = $match;
            $params[] = '%' . $wpdb->esc_like($match) . '%';
        }
    }

/**
     * Goal counts all events when unmatched.
     *
     * @param array $goal Goal.
     * @return bool Goal counts all events when unmatched.
     */

    private function goal_counts_all_events_when_unmatched(array $goal): bool {
        return in_array($goal['type'] ?? '', ['form_submit', 'login'], true);
    }

/**
     * Format conversion event.
     *
     * @param mixed $row Row.
     * @return array Format conversion event.
     */

    private function format_conversion_event($row): array {
        return [
            'id' => (int)($row->id ?? 0),
            'event_type' => $row->event_type ?? '',
            'goal_id' => $row->goal_id ?? '',
            'viewed_at' => $row->viewed_at ?? '',
            'post_id' => (int)($row->post_id ?? 0),
            'object_type' => $row->object_type ?? '',
            'object_id' => (int)($row->object_id ?? 0),
            'object_subtype' => $row->object_subtype ?? '',
            'object_key' => $row->object_key ?? '',
            'label' => $row->object_label ?: $row->object_key ?: __('Unknown event', 'wphave'),
            'object_url' => $row->object_url ?? '',
            'page_url' => $row->page_url ?? '',
            'referrer_url' => $row->referrer_url ?? '',
            'referrer_domain' => $row->referrer_domain ?? '',
            'source' => $row->source ?? '',
            'medium' => $row->medium ?? '',
            'campaign' => $row->campaign ?? '',
            'device_type' => $row->device_type ?? '',
            'browser' => $row->browser ?? '',
            'os' => $row->os ?? '',
            'is_logged_in' => ! empty($row->is_logged_in),
        ];
    }

/**
     * Csv response.
     *
     * @param string $filename Filename.
     * @param array $headers Headers.
     * @param array $rows Rows.
     */

    private function csv_response(string $filename, array $headers, array $rows) {
        $handle = fopen('php://temp', 'r+');
        fputcsv($handle, $headers);

        foreach ($rows as $row) {
            fputcsv($handle, array_map(fn($key) => $this->sanitize_csv_value($row[$key] ?? ''), $headers));
        }

        rewind($handle);
        $csv = stream_get_contents($handle);
        fclose($handle);

		// AUTHORIZATION INVARIANT: CSV streaming is irreversible and bypasses the
		// facade's post-return release check. Revalidate the established Analytics
		// view policy after all extensible cell sanitization and before any header or
		// byte is disclosed, including when this repository is invoked directly.
		if (
			! current_user_can( 'manage_options' )
			&& ! current_user_can( 'view_wphave_analytics' )
		) {
			return new WP_Error(
				'wphave_analytics_forbidden',
				__( 'You are not allowed to view analytics.', 'wphave' ),
				[ 'status' => 403 ]
			);
		}

        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . sanitize_file_name($filename) . '"');
        echo $csv;
        exit;
    }

/**
     * Sanitize csv value.
     *
     * @param mixed $value Value.
     * @return string Sanitize csv value.
     */

    private function sanitize_csv_value($value): string {
        return WPHAVE_Security_CSV::cell($value);
    }

/**
     * API campaigns.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_campaigns(WP_REST_Request $request) {
        if ( ! $this->table_exists( $this->daily_table ) ) {
            return rest_ensure_response([]);
        }

        global $wpdb;

        $params = [];
        $where = $this->build_filters($request, $params);
        $range = $this->get_date_range($request);
        $previous_params = [];
        $previous_where = $this->build_filters($request, $previous_params, $this->get_previous_date_range($range));

        $rows = $wpdb->get_results(
            $wpdb->prepare("
                SELECT
                    campaign,
                    source,
                    medium,
                    SUM(views) as value,
                    SUM(unique_visitors) as visitors,
                    SUM(sessions) as sessions
                FROM {$this->daily_table}
                $where
                AND campaign != ''
                GROUP BY campaign, source, medium
                ORDER BY value DESC
                LIMIT 50
            ", ...$params)
        );
        $previous_rows = $wpdb->get_results(
            $wpdb->prepare("
                SELECT
                    campaign,
                    source,
                    medium,
                    SUM(views) as value,
                    SUM(unique_visitors) as visitors,
                    SUM(sessions) as sessions
                FROM {$this->daily_table}
                $previous_where
                AND campaign != ''
                GROUP BY campaign, source, medium
            ", ...$previous_params)
        );
        $previous_campaign_map = $this->map_rows_by_key($previous_rows, ['campaign', 'source', 'medium']);

        return rest_ensure_response(array_map(function($row) use ($previous_campaign_map) {
            $previous = $previous_campaign_map[$this->get_row_key($row, ['campaign', 'source', 'medium'])] ?? null;
            $current_engagement = $row->sessions ? (int) $row->value / (int) $row->sessions : 0;
            $previous_engagement = $previous && $previous->sessions ? (int) $previous->value / (int) $previous->sessions : 0;

            return [
                'campaign' => $row->campaign,
                'source' => $row->source,
                'medium' => $row->medium,
                'value' => (int) $row->value,
                'visitors' => (int) $row->visitors,
                'sessions' => (int) $row->sessions,
                'engagement' => $current_engagement,
                'compare' => [
                    'value' => [
                        'previous' => (int)($previous->value ?? 0),
                        'change' => $this->get_change((float)$row->value, (float)($previous->value ?? 0)),
                    ],
                    'sessions' => [
                        'previous' => (int)($previous->sessions ?? 0),
                        'change' => $this->get_change((float)$row->sessions, (float)($previous->sessions ?? 0)),
                    ],
                    'engagement' => [
                        'previous' => $previous_engagement,
                        'change' => $this->get_change((float)$current_engagement, (float)$previous_engagement),
                    ],
                ],
            ];
        }, $rows));
    }

}
