<?php

/**
 * Exact consent-based audience counts for the raw-event retention window.
 *
 * Daily rows are grouped by content and acquisition dimensions. Their distinct
 * visitor and session counts cannot be summed into a site-wide cardinality.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

trait WPHAVE_Analytics_Report_Identity {
	/** Whether every day in the requested range is still backed by raw events. */
	private function has_exact_identity_coverage( WP_REST_Request $request, ?array $range = null ): bool {
		if ( ! $this->table_exists( $this->events_table ) ) {
			return false;
		}

		$range = $range ?: $this->get_date_range( $request );
		$raw_boundary = date(
			'Y-m-d',
			strtotime(
				'-' . WPHAVE_Analytics_Retention_Policy::raw_days() . ' days',
				current_time( 'timestamp' )
			)
		);

		return $range['from'] >= $raw_boundary
			&& $range['to'] <= current_time( 'Y-m-d' );
	}

	/** Count each visitor and session once across every page in the range. */
	private function get_exact_identity_totals( WP_REST_Request $request, ?array $range = null ): ?object {
		if ( ! $this->has_exact_identity_coverage( $request, $range ) ) {
			return null;
		}

		global $wpdb;

		$params = [];
		$where = $this->build_event_filters( $request, $params, '', $range );
		$where .= " AND event_type = 'pageview'";

		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT visitor_id) AS unique_visitors,
					COUNT(DISTINCT session_id) AS sessions
				FROM {$this->events_table}
				{$where}",
				...$params
			)
		);
	}

	/** Return exact daily points; their sum is not a period-wide visitor count. */
	private function get_exact_identity_days( WP_REST_Request $request ): ?array {
		if ( ! $this->has_exact_identity_coverage( $request ) ) {
			return null;
		}

		global $wpdb;

		$params = [];
		$where = $this->build_event_filters( $request, $params );
		$where .= " AND event_type = 'pageview'";
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT DATE(viewed_at) AS date,
					COUNT(DISTINCT visitor_id) AS unique_visitors,
					COUNT(DISTINCT session_id) AS sessions
				FROM {$this->events_table}
				{$where}
				GROUP BY DATE(viewed_at)",
				...$params
			)
		);

		if ( ! is_array( $rows ) ) {
			return null;
		}

		$days = [];
		foreach ( $rows as $row ) {
			$days[ $row->date ] = $row;
		}

		return $days;
	}

	/** Return exact identities for each acquisition grouping. */
	private function get_exact_identity_sources( WP_REST_Request $request, ?array $range = null ): ?array {
		return $this->get_exact_identity_groups(
			$request,
			[ 'source', 'medium', 'campaign' ],
			$range
		);
	}

	/** Count identities per approved event dimension without summing daily cardinalities. */
	private function get_exact_identity_groups(
		WP_REST_Request $request,
		array $dimensions,
		?array $range = null,
		string $event_type = 'pageview'
	): ?array {
		if ( ! $this->has_exact_identity_coverage( $request, $range ) ) {
			return null;
		}

		$allowed = [
			'object_key',
			'source',
			'medium',
			'campaign',
			'device_type',
			'browser',
			'os',
		];
		if ( ! $dimensions || array_diff( $dimensions, $allowed ) ) {
			return null;
		}
		if ( ! in_array( $event_type, [ 'pageview', 'search' ], true ) ) {
			return null;
		}

		global $wpdb;

		$params = [];
		$where = $this->build_event_filters( $request, $params, '', $range );
		$where .= " AND event_type = '{$event_type}'";
		$columns = implode( ', ', $dimensions );
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT {$columns},
					COUNT(DISTINCT visitor_id) AS visitors,
					COUNT(DISTINCT session_id) AS sessions
				FROM {$this->events_table}
				{$where}
				GROUP BY {$columns}",
				...$params
			)
		);

		if ( ! is_array( $rows ) ) {
			return null;
		}

		return $this->map_rows_by_key( $rows, $dimensions );
	}
}
