<?php

require_once __DIR__ . '/overview.php';
require_once __DIR__ . '/content.php';
require_once __DIR__ . '/timeseries.php';
require_once __DIR__ . '/journeys.php';
require_once __DIR__ . '/realtime.php';
require_once __DIR__ . '/conversions.php';
require_once __DIR__ . '/technology.php';
require_once __DIR__ . '/geography.php';


/**
 * Read-side analytics reports.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPHAVE_Analytics_Report_Repository {

	use WPHAVE_Analytics_Report_Overview,
		WPHAVE_Analytics_Report_Content,
		WPHAVE_Analytics_Report_Timeseries,
		WPHAVE_Analytics_Report_Journeys,
		WPHAVE_Analytics_Report_Realtime,
		WPHAVE_Analytics_Report_Conversions,
		WPHAVE_Analytics_Report_Technology,
		WPHAVE_Analytics_Report_Geography;

    private string $events_table;
    private string $daily_table;
    private WPHAVE_Analytics_Schema $schema;
    private WPHAVE_Analytics_Query_Builder $query_builder;
    private WPHAVE_Analytics_Goals $goals;

    /**
     * Initialize the report service.
     *
     * @param string $events_table Events table.
     * @param string $daily_table Daily table.
     * @param WPHAVE_Analytics_Schema $schema Schema.
     * @param WPHAVE_Analytics_Query_Builder $query_builder Query builder.
     */

    public function __construct( string $events_table, string $daily_table, WPHAVE_Analytics_Schema $schema, WPHAVE_Analytics_Query_Builder $query_builder ) {
        $this->events_table = $events_table;
        $this->daily_table = $daily_table;
        $this->schema = $schema;
        $this->query_builder = $query_builder;
        $this->goals = new WPHAVE_Analytics_Goals();
    }


}
