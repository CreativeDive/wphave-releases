<?php

/**
 * Build time-series analytics reports.
 */

trait WPHAVE_Analytics_Report_Timeseries {

    public function api_timeseries( WP_REST_Request $request ) {
        if ( ! $this->table_exists( $this->daily_table ) ) {
            return rest_ensure_response( [] );
        }

        global $wpdb;
        $params = [];
        $where = $this->build_filters($request, $params);

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "
                SELECT
                    view_date,
                    SUM(views) AS views,
                    NULL AS unique_visitors,
                    NULL AS sessions
                FROM {$this->daily_table}
                $where
                GROUP BY view_date
                ORDER BY view_date ASC
                ",
                ...$params
            )
        );

		$identity_days = $this->get_exact_identity_days( $request );
		foreach ( $rows as $row ) {
			$identity_day = $identity_days[ $row->view_date ] ?? null;
			$row->unique_visitors = null === $identity_days
				? null
				: (int) ( $identity_day->unique_visitors ?? 0 );
			$row->sessions = null === $identity_days
				? null
				: (int) ( $identity_day->sessions ?? 0 );
		}

        return rest_ensure_response(
            array_map( function ( $row ) {
                return [
                    'date'            => $row->view_date,
                    'views'           => (int) $row->views,
                    'unique_visitors' => null === $row->unique_visitors ? null : (int) $row->unique_visitors,
                    'sessions'        => null === $row->sessions ? null : (int) $row->sessions,
                ];
            }, $rows )
        );
    }

}
