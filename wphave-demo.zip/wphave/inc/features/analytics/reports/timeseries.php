<?php

/**
 * Build time-series analytics reports.
 */

trait WPHAVE_Analytics_Report_Timeseries {

    public function api_timeseries( WP_REST_Request $request ) {
        if ( ! $this->table_exists( $this->daily_table ) ) {
            return rest_ensure_response( [] );
        }

        global $wpdb;
        $params = [];
        $where = $this->build_filters($request, $params);

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "
                SELECT
                    view_date,
                    SUM(views) AS views,
                    SUM(unique_visitors) AS unique_visitors,
                    SUM(sessions) AS sessions
                FROM {$this->daily_table}
                $where
                GROUP BY view_date
                ORDER BY view_date ASC
                ",
                ...$params
            )
        );

        return rest_ensure_response(
            array_map( function ( $row ) {
                return [
                    'date'            => $row->view_date,
                    'views'           => (int) $row->views,
                    'unique_visitors' => (int) $row->unique_visitors,
                    'sessions'        => (int) $row->sessions,
                ];
            }, $rows )
        );
    }

}
