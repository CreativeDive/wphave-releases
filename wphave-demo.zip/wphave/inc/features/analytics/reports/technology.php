<?php

/**
 * Isolate technology reporting from the public Analytics facade.
 */
trait WPHAVE_Analytics_Report_Technology {

	/**
	 * Return classified technology dimensions and their collection coverage.
	 *
	 * Anonymous aggregate pageviews intentionally have no technology details.
	 * They are reported as not collected instead of being mixed into an
	 * "unknown" browser, device or operating-system bucket.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @return WP_REST_Response Technology report.
	 */
	public function api_technology( WP_REST_Request $request ) {
		if ( ! $this->table_exists( $this->daily_table ) ) {
			return rest_ensure_response( $this->empty_technology_report() );
		}

		global $wpdb;

		$params   = [];
		$where    = $this->build_filters( $request, $params );
		$privacy_daily_table = $wpdb->prefix . WPHAVE_Analytics::PRIVACY_DAILY_TABLE;
		$privacy_rows = [];

		if ( $this->table_exists( $privacy_daily_table ) ) {
			$privacy_params = [];
			$privacy_where  = $this->query_builder->build_privacy_dimension_filters( $request, $privacy_params );
			$privacy_rows   = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT dimension_type, dimension_value, SUM(views) AS value
					FROM {$privacy_daily_table}
					{$privacy_where}
					GROUP BY dimension_type, dimension_value
					ORDER BY value DESC",
					...$privacy_params
				)
			);
		}
		$coverage = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT
					COALESCE(SUM(views), 0) AS total_views,
					COALESCE(SUM(CASE WHEN source = 'anonymous' AND medium = 'aggregate' THEN views ELSE 0 END), 0) AS not_collected_views,
					COALESCE(SUM(CASE WHEN NOT (source = 'anonymous' AND medium = 'aggregate') THEN views ELSE 0 END), 0) AS collected_views,
					COALESCE(SUM(CASE
						WHEN NOT (source = 'anonymous' AND medium = 'aggregate')
							AND COALESCE(device_type, '') NOT IN ('', 'unknown')
							AND COALESCE(browser, '') NOT IN ('', 'unknown')
							AND COALESCE(os, '') NOT IN ('', 'unknown')
						THEN views ELSE 0 END), 0) AS classified_views
				FROM {$this->daily_table}
				{$where}",
				...$params
			)
		);

		$get_dimension_rows = function ( string $select, string $group_by, string $eligibility ) use ( $wpdb, $where, $params ) {
			$qualified_where = $where
				? $where . ' AND ' . $eligibility
				: 'WHERE ' . $eligibility;

			return $wpdb->get_results(
				$wpdb->prepare(
					"SELECT
						{$select},
						SUM(views) AS value,
						SUM(unique_visitors) AS visitors,
						SUM(sessions) AS sessions
					FROM {$this->daily_table}
					{$qualified_where}
					GROUP BY {$group_by}
					ORDER BY value DESC
					LIMIT 50",
					...$params
				)
			);
		};

		$map_rows = static function ( array $rows ): array {
			return array_map(
				static function ( $row ): array {
					return array_merge(
						(array) $row,
						[
							'value'      => (int) $row->value,
							'visitors'   => (int) $row->visitors,
							'sessions'   => (int) $row->sessions,
							'engagement' => $row->sessions ? (int) $row->value / (int) $row->sessions : 0,
						]
					);
				},
				$rows
			);
		};

		$get_privacy_rows = static function ( string $dimension_type, string $key ) use ( $privacy_rows ): array {
			return array_values(
				array_map(
					static function ( $row ) use ( $key ): object {
						return (object) [
							$key       => $row->dimension_value,
							'value'    => (int) $row->value,
							'visitors' => 0,
							'sessions' => 0,
						];
					},
					array_filter(
						$privacy_rows,
						static fn( $row ): bool => $dimension_type === $row->dimension_type
					)
				)
			);
		};

		$merge_dimension_rows = static function ( array $consented_rows, array $anonymous_rows, string $key ): array {
			$merged = [];

			foreach ( array_merge( $consented_rows, $anonymous_rows ) as $row ) {
				$value = (string) $row->{$key};

				if ( ! isset( $merged[ $value ] ) ) {
					$merged[ $value ] = (object) [
						$key       => $value,
						'value'    => 0,
						'visitors' => 0,
						'sessions' => 0,
					];
				}

				$merged[ $value ]->value += (int) $row->value;
				$merged[ $value ]->visitors += (int) $row->visitors;
				$merged[ $value ]->sessions += (int) $row->sessions;
			}

			usort(
				$merged,
				static fn( $left, $right ): int => $right->value <=> $left->value
			);

			return array_values( $merged );
		};

		$recognized_device      = "COALESCE(device_type, '') NOT IN ('', 'unknown')";
		$recognized_browser     = "COALESCE(browser, '') NOT IN ('', 'unknown')";
		$recognized_os          = "COALESCE(os, '') NOT IN ('', 'unknown')";
		$recognized_combination = implode(
			' AND ',
			[
				$recognized_device,
				$recognized_browser,
				$recognized_os,
			]
		);

		$device_rows = $merge_dimension_rows(
			$get_dimension_rows( 'device_type', 'device_type', $recognized_device ),
			$get_privacy_rows( 'device', 'device_type' ),
			'device_type'
		);
		$browser_rows = $merge_dimension_rows(
			$get_dimension_rows( 'browser', 'browser', $recognized_browser ),
			$get_privacy_rows( 'browser', 'browser' ),
			'browser'
		);
		$os_rows = $merge_dimension_rows(
			$get_dimension_rows( 'os', 'os', $recognized_os ),
			$get_privacy_rows( 'os', 'os' ),
			'os'
		);

		return rest_ensure_response(
			[
				'coverage'         => $this->format_technology_coverage( $coverage, $get_privacy_rows( 'device', 'device_type' ) ),
				'devices'          => $map_rows( $device_rows ),
				'browsers'         => $map_rows( $browser_rows ),
				'operatingSystems' => $map_rows( $os_rows ),
				'browserVersions'  => $map_rows( $get_privacy_rows( 'browser_version', 'browser' ) ),
				'osVersions'       => $map_rows( $get_privacy_rows( 'os_version', 'os' ) ),
				'languages'        => $map_rows( $get_privacy_rows( 'language', 'language' ) ),
				'screenClasses'    => $map_rows( $get_privacy_rows( 'screen', 'screen_class' ) ),
				'combinations'     => $map_rows(
					$get_dimension_rows(
						'device_type, browser, os',
						'device_type, browser, os',
						$recognized_combination
					)
				),
			]
		);
	}

	/**
	 * Normalize technology coverage values for the REST contract.
	 */
	private function format_technology_coverage( ?object $coverage, array $anonymous_device_rows = [] ): array {
		$total_views         = (int) ( $coverage->total_views ?? 0 );
		$anonymous_classified_views = array_sum(
			array_map( static fn( $row ): int => (int) $row->value, $anonymous_device_rows )
		);
		$not_collected_views = max(
			0,
			(int) ( $coverage->not_collected_views ?? 0 ) - $anonymous_classified_views
		);
		$collected_views     = (int) ( $coverage->collected_views ?? 0 );
		$consented_classified_views = (int) ( $coverage->classified_views ?? 0 );
		$classified_views = $consented_classified_views + $anonymous_classified_views;

		return [
			'totalViews'        => $total_views,
			'notCollectedViews' => $not_collected_views,
			'collectedViews'    => $collected_views,
			'unrecognizedViews' => max( 0, $collected_views - $consented_classified_views ),
			'classifiedViews'   => $classified_views,
			'classifiedPercent' => $total_views ? ( $classified_views / $total_views ) * 100 : 0,
			'collectionPercent' => $total_views ? ( $classified_views / $total_views ) * 100 : 0,
		];
	}

	/**
	 * Empty REST response contract.
	 */
	private function empty_technology_report(): array {
		return [
			'coverage'         => $this->format_technology_coverage( null ),
			'devices'          => [],
			'browsers'         => [],
			'operatingSystems' => [],
			'browserVersions'  => [],
			'osVersions'       => [],
			'languages'        => [],
			'screenClasses'    => [],
			'combinations'     => [],
		];
	}
}
