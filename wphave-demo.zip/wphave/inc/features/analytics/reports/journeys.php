<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Analytics_Report_Journeys {

/**
     * Return engagement stats.
     *
     * @param WP_REST_Request $request REST request.
     * @param ?array $range Range.
     * @return array Return engagement stats.
     */

    private function get_engagement_stats(WP_REST_Request $request, ?array $range = null): array {
        if ( ! $this->table_exists( $this->events_table ) ) {
            return [
                'bounces' => 0,
                'bounce_rate' => 0,
                'engaged_sessions' => 0,
                'engagement_rate' => 0,
            ];
        }

        global $wpdb;

        $params = [];
        $where = $this->build_event_filters($request, $params, '', $range);

        $row = $wpdb->get_row(
            $wpdb->prepare("
                SELECT
                    COUNT(*) as sessions,
                    SUM(CASE WHEN pageviews = 1 AND engagements = 0 THEN 1 ELSE 0 END) as bounces,
                    SUM(CASE WHEN engagements > 0 THEN 1 ELSE 0 END) as engaged_sessions
                FROM (
                    SELECT
                        session_id,
                        COUNT(CASE WHEN event_type = 'pageview' THEN 1 END) as pageviews,
                        COUNT(CASE WHEN event_type = 'engagement' THEN 1 END) as engagements
                    FROM {$this->events_table}
                    $where
                    GROUP BY session_id
                    HAVING pageviews > 0
                ) session_stats
            ", ...$params)
        );

        $sessions = (int) ($row->sessions ?? 0);
        $bounces = (int) ($row->bounces ?? 0);
        $engaged_sessions = (int) ($row->engaged_sessions ?? 0);

        return [
            'bounces' => $bounces,
            'bounce_rate' => $sessions ? ($bounces / $sessions) * 100 : 0,
            'engaged_sessions' => $engaged_sessions,
            'engagement_rate' => $sessions ? ($engaged_sessions / $sessions) * 100 : 0,
        ];
    }

/**
     * API entry pages.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_entry_pages(WP_REST_Request $request) {

        if ( ! $this->table_exists( $this->events_table ) ) {
            return rest_ensure_response([]);
        }

        global $wpdb;
        $params = [];
        $session_where = $this->build_event_filters($request, $params);

        $rows = $wpdb->get_results($wpdb->prepare("
            SELECT
                MAX(e.post_id) as post_id,
                MAX(e.object_type) as object_type,
                MAX(e.object_id) as object_id,
                MAX(e.object_subtype) as object_subtype,
                e.object_key,
                MAX(e.object_label) as object_label,
                MAX(e.object_url) as object_url,
                COUNT(*) as value
            FROM (
                SELECT session_id, MIN(viewed_at) as first_view
                FROM {$this->events_table}
                $session_where
                AND event_type = 'pageview'
                GROUP BY session_id
            ) s
            JOIN {$this->events_table} e
                ON e.session_id = s.session_id
                AND e.viewed_at = s.first_view
                AND e.event_type = 'pageview'
            GROUP BY e.object_key
            ORDER BY value DESC
            LIMIT 10
        ", ...$params));

        return rest_ensure_response(array_map(function($r) {
            $post_id = (int)$r->post_id;
            $object_type = $r->object_type ?: 'post';
            $object_id = (int)($r->object_id ?: $post_id);

            return [
                'id' => $object_type . ':' . $object_id . ':' . $r->object_subtype,
                'post_id' => $post_id,
                'object_type' => $object_type,
                'object_id' => $object_id,
                'object_subtype' => $r->object_subtype,
                'title' => $r->object_label ?: ($post_id ? get_the_title($post_id) : __('Unknown content', 'wphave')),
                'url' => $r->object_url ?: ($post_id ? get_permalink($post_id) : ''),
                'value' => (int)$r->value
            ];
        }, $rows));
    }

/**
     * API exit pages.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_exit_pages(WP_REST_Request $request) {

        if ( ! $this->table_exists( $this->events_table ) ) {
            return rest_ensure_response([]);
        }

        global $wpdb;
        $params = [];
        $session_where = $this->build_event_filters($request, $params);

        $rows = $wpdb->get_results($wpdb->prepare("
            SELECT
                MAX(e.post_id) as post_id,
                MAX(e.object_type) as object_type,
                MAX(e.object_id) as object_id,
                MAX(e.object_subtype) as object_subtype,
                e.object_key,
                MAX(e.object_label) as object_label,
                MAX(e.object_url) as object_url,
                COUNT(*) as value
            FROM (
                SELECT session_id, MAX(viewed_at) as last_view
                FROM {$this->events_table}
                $session_where
                AND event_type = 'pageview'
                GROUP BY session_id
            ) s
            JOIN {$this->events_table} e
                ON e.session_id = s.session_id
                AND e.viewed_at = s.last_view
                AND e.event_type = 'pageview'
            GROUP BY e.object_key
            ORDER BY value DESC
            LIMIT 10
        ", ...$params));

        return rest_ensure_response(array_map(function($r) {
            $post_id = (int)$r->post_id;
            $object_type = $r->object_type ?: 'post';
            $object_id = (int)($r->object_id ?: $post_id);

            return [
                'id' => $object_type . ':' . $object_id . ':' . $r->object_subtype,
                'post_id' => $post_id,
                'object_type' => $object_type,
                'object_id' => $object_id,
                'object_subtype' => $r->object_subtype,
                'title' => $r->object_label ?: ($post_id ? get_the_title($post_id) : __('Unknown content', 'wphave')),
                'url' => $r->object_url ?: ($post_id ? get_permalink($post_id) : ''),
                'value' => (int)$r->value
            ];
        }, $rows));
    }

/**
     * API flow.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_flow(WP_REST_Request $request) {

        if ( ! $this->table_exists( $this->events_table ) ) {
            return rest_ensure_response([
                'items'              => [],
                'totalSessions'      => 0,
                'singlePageSessions' => 0,
                'averageSteps'       => 0,
                'maxSteps'           => 4,
                'isLimited'          => false,
                'sampleJourney'      => [],
            ]);
        }

        global $wpdb;
        $params = [];
        $event_where = $this->build_event_filters($request, $params);
        $max_steps = 4;
        $event_limit = 10000;

        $sessions = $wpdb->get_results($wpdb->prepare("
            SELECT session_id, post_id, object_type, object_id, object_subtype, object_label, object_url, viewed_at
            FROM {$this->events_table}
            $event_where
            AND event_type = 'pageview'
            ORDER BY session_id, viewed_at ASC
            LIMIT %d
        ", ...array_merge($params, [$event_limit + 1])));

        $is_limited = count($sessions) > $event_limit;
        $sessions = array_slice($sessions, 0, $event_limit);

        $flows = [];
        $targets = [];

        foreach ($sessions as $row) {
            $post_id = absint($row->post_id);
            $object_type = $row->object_type ?: 'post';
            $object_id = (int)($row->object_id ?: $post_id);
            $object_subtype = $row->object_subtype ?: ($post_id ? get_post_type($post_id) : '');
            $target_key = $object_type . ':' . $object_id . ':' . $object_subtype;
            $targets[$target_key] = [
                'post_id' => $post_id,
                'object_type' => $object_type,
                'object_id' => $object_id,
                'object_subtype' => $object_subtype,
                'title' => $row->object_label ?: ($post_id ? get_the_title($post_id) : __('Unknown content', 'wphave')),
                'url' => $row->object_url ?: ($post_id ? get_permalink($post_id) : ''),
            ];

            $current_flow = $flows[$row->session_id] ?? [];
            $last_post_id = end($current_flow);

            if ($last_post_id !== $target_key) {
                $flows[$row->session_id][] = $target_key;
            }
        }

        $paths = [];
        $total_steps = 0;
        $single_page_sessions = 0;

        foreach ($flows as $flow) {
            $steps = count($flow);

            if (!$steps) {
                continue;
            }

            $total_steps += $steps;

            if ($steps === 1) {
                $single_page_sessions++;
            }

            $displayed_flow = array_slice($flow, 0, $max_steps);
            $key = implode('|', $displayed_flow);

            if (!isset($paths[$key])) {
                $paths[$key] = [
                    'value'     => 0,
                    'truncated' => false,
                ];
            }

            $paths[$key]['value']++;
            $paths[$key]['truncated'] = $paths[$key]['truncated'] || $steps > $max_steps;
        }

        uasort($paths, fn($a, $b) => $b['value'] <=> $a['value']);
        $total_sessions = count($flows);
        $path_items = array_slice($paths, 0, 50, true);

        return rest_ensure_response([
            'items' => array_map(function($k, $data) use ($total_sessions, $targets) {
                $target_keys = array_filter(explode('|', $k));
                $titles = array_map(fn($target_key) => $targets[$target_key]['title'] ?? __('Unknown content', 'wphave'), $target_keys);
                $steps = count($target_keys);
                $value = (int)$data['value'];

                return [
                    'path'      => $titles,
                    'targets'   => array_map(fn($target_key) => $targets[$target_key] ?? null, $target_keys),
                    'entry'     => $titles[0] ?? '',
                    'exit'      => $titles[$steps - 1] ?? '',
                    'steps'     => $steps,
                    'value'     => $value,
                    'percent'   => $total_sessions ? round(($value / $total_sessions) * 100, 1) : 0,
                    'truncated' => (bool)$data['truncated'],
                ];
            }, array_keys($path_items), $path_items),
            'totalSessions'      => $total_sessions,
            'singlePageSessions' => $single_page_sessions,
            'averageSteps'       => $total_sessions ? round($total_steps / $total_sessions, 1) : 0,
            'maxSteps'           => $max_steps,
            'isLimited'          => $is_limited,
            'sampleJourney'      => $this->get_sample_session_journey($request),
        ]);
    }

/**
     * Return sample session journey.
     *
     * @param WP_REST_Request $request REST request.
     * @return array Return sample session journey.
     */

    private function get_sample_session_journey(WP_REST_Request $request): array {
        if ( ! $this->table_exists( $this->events_table ) ) {
            return [];
        }

        global $wpdb;

        $params = [];
        $where = $this->build_event_filters($request, $params, 'e');
        $session_hash = $wpdb->get_var(
            $wpdb->prepare(
                "
                SELECT e.session_id
                FROM {$this->events_table} e
                $where
                GROUP BY e.session_id
                HAVING COUNT(*) > 1
                ORDER BY MAX(e.viewed_at) DESC
                LIMIT 1
                ",
                ...$params
            )
        );

        if ( ! $session_hash || ! class_exists( 'WPHAVE_Analytics_Event_Query' ) ) {
            return [];
        }

        $query = new WPHAVE_Analytics_Event_Query( $this->events_table, $this->schema );

        return $query->get_session_journey( sanitize_text_field( $session_hash ), 100 );
    }

}
