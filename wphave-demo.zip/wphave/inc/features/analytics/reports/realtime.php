<?php

require_once dirname(__DIR__, 2) . '/security/safe-link.php';

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Analytics_Report_Realtime {

/**
     * API realtime.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_realtime(WP_REST_Request $request) {

        global $wpdb;
        $window = 5;
		$since = date(
			'Y-m-d H:i:s',
			current_time( 'timestamp' ) - ( $window * MINUTE_IN_SECONDS )
		);

        if ( ! $this->table_exists( $this->events_table ) ) {
            return rest_ensure_response([
                'active'          => 0,
                'events'          => 0,
                'eventsPerMinute' => 0,
                'window'          => [
                    'minutes' => $window,
                    'label'   => sprintf(
                        /* translators: %d: number of minutes. */
                        __('Last %d minutes', 'wphave'),
                        $window
                    ),
                ],
                'lastUpdated'     => current_time('mysql'),
                'pagesTotal'      => 0,
                'topPage'         => null,
                'pages'           => [],
            ]);
        }

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "
            SELECT
                COUNT(DISTINCT session_id) as active_sessions,
                COUNT(*) as events
            FROM {$this->events_table}
            WHERE viewed_at >= %s
                ",
                $since
            )
        );

        $pages = $wpdb->get_results(
            $wpdb->prepare(
                "
            SELECT
                post_id,
                object_type,
                object_id,
                object_subtype,
                MAX(object_label) as object_label,
                MAX(object_url) as object_url,
                COUNT(*) as value
            FROM {$this->events_table}
            WHERE viewed_at >= %s
            AND event_type = 'pageview'
            GROUP BY object_key
            ORDER BY value DESC
            LIMIT 5
                ",
                $since
            )
        );

        $events = (int)($rows[0]->events ?? 0);
        $active = (int)($rows[0]->active_sessions ?? 0);
        $formatted_pages = array_map(function ($row) {
            $post_id = (int)$row->post_id;
            $object_type = $row->object_type ?: 'post';
            $object_id = (int)($row->object_id ?: $post_id);
            $title = $row->object_label ?: ($post_id ? get_the_title($post_id) : '');

            return [
                'id'    => $object_type . ':' . $object_id . ':' . $row->object_subtype,
                'post_id' => $post_id,
                'object_type' => $object_type,
                'object_id' => $object_id,
                'object_subtype' => $row->object_subtype,
                'title' => $title ?: __('Unknown page', 'wphave'),
                // STORED-LINK INVARIANT: Historic event rows are untrusted even
                // after the tracking write boundary was repaired.
                'url'   => WPHAVE_Safe_Link::same_site_http($row->object_url ?: ($post_id ? get_permalink($post_id) : '')),
                'value' => (int)$row->value,
            ];
        }, $pages);

        return rest_ensure_response([
            'active'          => $active,
            'events'          => $events,
            'eventsPerMinute' => round($events / $window, 1),
            'window'          => [
                'minutes' => $window,
                'label'   => sprintf(
                    /* translators: %d: number of minutes. */
                    __('Last %d minutes', 'wphave'),
                    $window
                ),
            ],
            'lastUpdated'     => current_time('mysql'),
            'pagesTotal'      => $events,
            'topPage'         => $formatted_pages[0] ?? null,
            'pages'           => $formatted_pages,
        ]);
    }

/**
     * API status.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_status(WP_REST_Request $request) {
        $last_event = null;
        $last_daily = null;
        $events = 0;
        $daily_rows = 0;

        global $wpdb;

        if ( $this->table_exists( $this->events_table ) ) {
            $event_row = $wpdb->get_row("
                SELECT MAX(viewed_at) as last_event, COUNT(*) as total
                FROM {$this->events_table}
            ");
            $last_event = $event_row->last_event ?? null;
            $events = (int) ($event_row->total ?? 0);
        }

        if ( $this->table_exists( $this->daily_table ) ) {
            $daily_row = $wpdb->get_row("
                SELECT MAX(view_date) as last_daily, COUNT(*) as total
                FROM {$this->daily_table}
            ");
            $last_daily = $daily_row->last_daily ?? null;
            $daily_rows = (int) ($daily_row->total ?? 0);
        }

        return rest_ensure_response([
            'enabled' => $this->is_enabled(),
			'trackingActive' => $this->is_enabled(),
            'loggedInTracking' => defined('WPHAVE_ANALYTICS_TRACK_LOGGED_IN') && WPHAVE_ANALYTICS_TRACK_LOGGED_IN,
            'botFiltering' => true,
			'retention' => WPHAVE_Analytics_Retention_Policy::get(),
			'rawRetentionDays' => WPHAVE_Analytics_Retention_Policy::raw_days(),
			'cleanupStatus' => get_option( 'wphave_analytics_cleanup_status', [] ),
            'sessionTimeoutMinutes' => WPHAVE_Analytics::SESSION_TIMEOUT_MINUTES,
            'tables' => [
                'events' => $this->table_exists($this->events_table),
                'daily' => $this->table_exists($this->daily_table),
            ],
            'lastEvent' => $last_event,
            'lastAggregation' => $last_daily,
            'events' => $events,
            'dailyRows' => $daily_rows,
            'cron' => [
                'aggregation' => wp_next_scheduled('wphave_analytics_aggregate_daily'),
                'cleanup' => wp_next_scheduled('wphave_analytics_cleanup_events'),
            ],
        ]);
    }

}
