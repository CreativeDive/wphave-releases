<?php

/**
 * Build overview and comparison reports and provide their shared query helpers.
 */

trait WPHAVE_Analytics_Report_Overview {

/**
     * Table exists.
     *
     * @param string $table Table.
     * @return bool Table exists.
     */

    private function table_exists( string $table ): bool {
        return $this->schema->table_exists( $table );
    }

/**
     * Determine whether analytics collection is enabled.
     *
     * @return bool Determine whether enabled.
     */

    private function is_enabled(): bool {
        return (bool) wphave_data_get( 'site_settings', 'advanced.analytics.enabled', false );
    }

/**
     * API overview.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_overview(WP_REST_Request $request) {

        if ( ! $this->table_exists( $this->daily_table ) ) {
            return rest_ensure_response([
                'stats' => [
                    'views' => 0,
                    'sessions' => 0,
                    'unique_visitors' => 0,
                    'returning' => [
                        'total' => 0,
                        'returning' => 0,
                        'rate' => 0,
                    ],
                ],
                'timeseries' => [],
                'sources' => [],
                'devices' => [],
                'referrers' => [],
            ]);
        }

        global $wpdb;

        $params = [];
        $where = $this->build_filters($request, $params);
        $range = $this->get_date_range($request);
        $previous_range = $this->get_previous_date_range($range);
        $previous_params = [];
        $previous_where = $this->build_filters($request, $previous_params, $previous_range);
        $days = $range['days'];

        $stats = $wpdb->get_row(
            $wpdb->prepare("
                SELECT
                    SUM(views) as views,
                    SUM(unique_visitors) as unique_visitors,
                    SUM(sessions) as sessions
                FROM {$this->daily_table}
                $where
            ", ...$params)
        );

        $timeseries = $wpdb->get_results(
            $wpdb->prepare("
                SELECT
                    view_date as date,
                    SUM(views) as views,
                    SUM(unique_visitors) as unique_visitors,
                    SUM(sessions) as sessions
                FROM {$this->daily_table}
                $where
                GROUP BY view_date
                ORDER BY view_date ASC
            ", ...$params)
        );

        $sources = $wpdb->get_results(
            $wpdb->prepare("
                SELECT
                    source,
                    medium,
                    campaign,
                    SUM(views) as value,
                    SUM(sessions) as sessions,
                    SUM(unique_visitors) as visitors
                FROM {$this->daily_table}
                $where
                GROUP BY source, medium, campaign
                ORDER BY value DESC
                LIMIT 10
            ", ...$params)
        );

        $previous_sources = $wpdb->get_results(
            $wpdb->prepare("
                SELECT
                    source,
                    medium,
                    campaign,
                    SUM(views) as value,
                    SUM(sessions) as sessions,
                    SUM(unique_visitors) as visitors
                FROM {$this->daily_table}
                $previous_where
                GROUP BY source, medium, campaign
            ", ...$previous_params)
        );
        $previous_source_map = $this->map_rows_by_key($previous_sources, ['source', 'medium', 'campaign']);

        $devices = $wpdb->get_results(
            $wpdb->prepare("
                SELECT device_type, SUM(views) as value
                FROM {$this->daily_table}
                $where
                GROUP BY device_type
            ", ...$params)
        );

        $referrers = $wpdb->get_results(
            $wpdb->prepare("
                SELECT referrer_domain, SUM(views) as value
                FROM {$this->daily_table}
                $where
                GROUP BY referrer_domain
                ORDER BY value DESC
                LIMIT 10
            ", ...$params)
        );

        $previous_referrers = $wpdb->get_results(
            $wpdb->prepare("
                SELECT referrer_domain, SUM(views) as value
                FROM {$this->daily_table}
                $previous_where
                GROUP BY referrer_domain
            ", ...$previous_params)
        );
        $previous_referrer_map = $this->map_rows_by_key($previous_referrers, ['referrer_domain']);

        $returning = (object) [
            'total' => 0,
            'returning' => 0,
        ];

        if ( $this->table_exists( $this->events_table ) ) {
            $visitor_threshold = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );
            $returning = $wpdb->get_row(
                $wpdb->prepare("
                    SELECT
                        COUNT(*) as total,
                        SUM(has_previous) as returning
                    FROM (
                        SELECT
                            recent.visitor_id,
                            EXISTS (
                                SELECT 1
                                FROM {$this->events_table} previous_events
                                WHERE previous_events.visitor_id = recent.visitor_id
                                AND previous_events.event_type = 'pageview'
                                AND previous_events.viewed_at < %s
                                LIMIT 1
                            ) as has_previous
                        FROM (
                            SELECT DISTINCT visitor_id
                            FROM {$this->events_table}
                            WHERE event_type = 'pageview'
                            AND viewed_at >= %s
                        ) recent
                    ) visitor_summary
                ", $visitor_threshold, $visitor_threshold)
            );

            if ( ! $returning ) {
                $returning = (object) [
                    'total' => 0,
                    'returning' => 0,
                ];
            }
        }

        $engagement = $this->get_engagement_stats($request);
        $previous_engagement = $this->get_engagement_stats($request, $previous_range);

        return rest_ensure_response([
            'stats' => [
                'views' => (int)($stats->views ?? 0),
                'sessions' => (int)($stats->sessions ?? 0),
                'unique_visitors' => (int)($stats->unique_visitors ?? 0),
                'bounces' => $engagement['bounces'],
                'bounce_rate' => $engagement['bounce_rate'],
                'engaged_sessions' => $engagement['engaged_sessions'],
                'engagement_rate' => $engagement['engagement_rate'],
                'compare' => [
                    'bounce_rate' => [
                        'previous' => $previous_engagement['bounce_rate'],
                        'change' => $this->get_change((float)$engagement['bounce_rate'], (float)$previous_engagement['bounce_rate']),
                    ],
                    'engagement_rate' => [
                        'previous' => $previous_engagement['engagement_rate'],
                        'change' => $this->get_change((float)$engagement['engagement_rate'], (float)$previous_engagement['engagement_rate']),
                    ],
                ],
                'returning' => [
                    'total' => (int)$returning->total,
                    'returning' => (int)$returning->returning,
                    'rate' => $returning->total
                        ? ($returning->returning / $returning->total) * 100
                        : 0
                            ],
            ],

            'timeseries' => array_map(fn($r) => [
                'date' => $r->date,
                'views' => (int)$r->views,
                'sessions' => (int)$r->sessions,
                'unique_visitors' => (int)$r->unique_visitors,
            ], $timeseries),

            'sources' => array_map(function($row) use ($previous_source_map) {
                $previous = $previous_source_map[$this->get_row_key($row, ['source', 'medium', 'campaign'])] ?? null;
                $current_engagement = $row->sessions ? $row->value / $row->sessions : 0;
                $previous_engagement = $previous && $previous->sessions ? $previous->value / $previous->sessions : 0;

                return [
                    'source' => $row->source,
                    'medium' => $row->medium,
                    'campaign' => $row->campaign,
                    'value' => (int)$row->value,
                    'sessions' => (int)$row->sessions,
                    'visitors' => (int)$row->visitors,
                    'engagement' => $current_engagement,
                    'compare' => [
                        'value' => [
                            'previous' => (int)($previous->value ?? 0),
                            'change' => $this->get_change((float)$row->value, (float)($previous->value ?? 0)),
                        ],
                        'engagement' => [
                            'previous' => $previous_engagement,
                            'change' => $this->get_change((float)$current_engagement, (float)$previous_engagement),
                        ],
                    ],
                ];
            }, $sources),
            'devices' => $devices,
            'referrers' => array_map(function($row) use ($previous_referrer_map) {
                $previous = $previous_referrer_map[$this->get_row_key($row, ['referrer_domain'])] ?? null;

                return [
                    'referrer_domain' => $row->referrer_domain,
                    'value' => (int)$row->value,
                    'compare' => [
                        'value' => [
                            'previous' => (int)($previous->value ?? 0),
                            'change' => $this->get_change((float)$row->value, (float)($previous->value ?? 0)),
                        ],
                    ],
                ];
            }, $referrers),
        ]);
    }

/**
     * API compare.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_compare(WP_REST_Request $request) {

        if ( ! $this->table_exists( $this->daily_table ) ) {
            return [
                'current' => 0,
                'previous' => 0,
                'change' => 0,
                'metrics' => [
                    'views' => [
                        'current' => 0,
                        'previous' => 0,
                        'change' => 0,
                    ],
                    'sessions' => [
                        'current' => 0,
                        'previous' => 0,
                        'change' => 0,
                    ],
                    'unique_visitors' => [
                        'current' => 0,
                        'previous' => 0,
                        'change' => 0,
                    ],
                ],
            ];
        }

        global $wpdb;

        $params = [];
        $where = $this->build_filters($request, $params);
        $range = $this->get_date_range($request);

        $current = $wpdb->get_row(
            $wpdb->prepare("
                SELECT
                    SUM(views) as views,
                    SUM(unique_visitors) as unique_visitors,
                    SUM(sessions) as sessions
                FROM {$this->daily_table}
                $where
            ", ...$params)
        );

        $previous_to = strtotime($range['from'] . ' -1 day');
        $previous_from = strtotime($range['from'] . ' -' . $range['days'] . ' days');
        $previous_where = $where;

        $previous_params = [
            date('Y-m-d', $previous_from),
            date('Y-m-d', $previous_to)
        ];

        $previous = $wpdb->get_row(
            $wpdb->prepare("
                SELECT
                    SUM(views) as views,
                    SUM(unique_visitors) as unique_visitors,
                    SUM(sessions) as sessions
                FROM {$this->daily_table}
                $previous_where
            ", ...array_merge($previous_params, array_slice($params, 2)))
        );

        $metric_compare = function( $metric ) use ( $current, $previous ) {
            $current_value = (int) ( $current->{$metric} ?? 0 );
            $previous_value = (int) ( $previous->{$metric} ?? 0 );

            return [
                'current' => $current_value,
                'previous' => $previous_value,
                'change' => $previous_value
                    ? (($current_value - $previous_value) / $previous_value) * 100
                    : 0,
            ];
        };

        $metrics = [
            'views' => $metric_compare( 'views' ),
            'sessions' => $metric_compare( 'sessions' ),
            'unique_visitors' => $metric_compare( 'unique_visitors' ),
        ];

        return [
            'current' => $metrics['views']['current'],
            'previous' => $metrics['views']['previous'],
            'change' => $metrics['views']['change'],
            'metrics' => $metrics,
        ];
    }

/**
     * Build filters.
     *
     * @param WP_REST_Request $request REST request.
     * @param mixed $params Params.
     * @param ?array $range Range.
     * @return string Build filters.
     */

    private function build_filters(WP_REST_Request $request, &$params, ?array $range = null): string {
        return $this->query_builder->build_daily_filters( $request, $params, $range );
    }

/**
     * Prefix where columns.
     *
     * @param string $where Where.
     * @param string $alias Alias.
     * @return string Prefix where columns.
     */

    private function prefix_where_columns(string $where, string $alias): string {
        foreach ([
            'post_id',
            'object_type',
            'object_id',
            'object_subtype',
            'view_date',
            'viewed_at',
            'source',
            'medium',
            'campaign',
            'referrer_domain',
            'device_type',
        ] as $column) {
            $where = preg_replace('/\b' . preg_quote($column, '/') . '\b/', "{$alias}.{$column}", $where);
        }

        return $where;
    }

/**
     * Return previous date range.
     *
     * @param array $range Range.
     * @return array Return previous date range.
     */

    private function get_previous_date_range(array $range): array {
        $to = strtotime($range['from'] . ' -1 day');
        $from = strtotime($range['from'] . ' -' . (int)$range['days'] . ' days');

        return [
            'from' => date('Y-m-d', $from),
            'to' => date('Y-m-d', $to),
            'days' => (int)$range['days'],
        ];
    }

/**
     * Return change.
     *
     * @param float $current Current.
     * @param float $previous Previous.
     * @return ?float Return change.
     */

    private function get_change(float $current, float $previous): ?float {
        if ($previous <= 0) {
            return null;
        }

        return (($current - $previous) / $previous) * 100;
    }

/**
     * Return row key.
     *
     * @param mixed $row Row.
     * @param array $keys Keys.
     * @return string Return row key.
     */

    private function get_row_key($row, array $keys): string {
        $values = [];

        foreach ($keys as $key) {
            $values[] = (string)($row->{$key} ?? '');
        }

        return implode('|', $values);
    }

/**
     * Map rows by key.
     *
     * @param array $rows Rows.
     * @param array $keys Keys.
     * @return array Map rows by key.
     */

    private function map_rows_by_key(array $rows, array $keys): array {
        $map = [];

        foreach ($rows as $row) {
            $map[$this->get_row_key($row, $keys)] = $row;
        }

        return $map;
    }

/**
     * Build event filters.
     *
     * @param WP_REST_Request $request REST request.
     * @param mixed $params Params.
     * @param string $alias Alias.
     * @param ?array $range Range.
     * @return string Build event filters.
     */

    private function build_event_filters(WP_REST_Request $request, &$params, string $alias = '', ?array $range = null): string {
        return $this->query_builder->build_event_filters( $request, $params, $alias, $range );
    }

/**
     * Return date range.
     *
     * @param WP_REST_Request $request REST request.
     * @return array Return date range.
     */

    private function get_date_range(WP_REST_Request $request): array {
        return $this->query_builder->get_date_range( $request );
    }

	/** Return the requested range bounded by raw-event retention. */

	private function get_event_date_range( WP_REST_Request $request ): array {
		return $this->query_builder->get_event_date_range( $request );
	}

/**
     * API stats.
     *
     * @param WP_REST_Request $request REST request.
     */


}
