<?php

/**
 * Handles analytics installation, scheduling, and frontend runtime assets.
 */

trait WPHAVE_Analytics_Runtime {

    /**
     * Install.
     *
     * @return void
     */

    public static function install(): void {
        WPHAVE_Analytics_Schema::install( WPHAVE_Analytics_Schema::DB_VERSION );
    }

	/**
	 * Table exists.
	 *
	 * @param string $table Table.
	 * @return bool Table exists.
	 */

	private function table_exists( string $table ): bool {
        return $this->schema->table_exists( $table );
    }

    /**
     * Schedule crons.
     *
     * @return void
     */

    public function schedule_crons(): void {
		// LIFECYCLE INVARIANT: Analytics recurring work uses the shared scheduler
		// so interval drift, duplicates and partial persistence are reconciled by
		// the same atomic contract as every other platform worker.
		WPHAVE_Background_Job_Scheduler::sync_recurring(
			'wphave_analytics_aggregate_daily',
			self::AGGREGATION_SCHEDULE_OPTION,
			true,
			'hourly',
			time() + HOUR_IN_SECONDS,
			'analytics-aggregation-v1'
		);
		WPHAVE_Background_Job_Scheduler::sync_recurring(
			'wphave_analytics_cleanup_events',
			self::CLEANUP_SCHEDULE_OPTION,
			true,
			'daily',
			time() + HOUR_IN_SECONDS,
			'analytics-retention-v1'
		);
    }

    /**
     * Determine whether analytics collection is enabled.
     *
     * @return bool Determine whether enabled.
     */

    private function is_enabled(): bool {
        return (bool) wphave_data_get( 'site_settings', 'advanced.analytics.enabled', false );
    }

    /**
     * Return tracking object context.
     *
     * @return ?array Return tracking object context.
     */

    private function get_tracking_object_context(): ?array {
        return $this->target_resolver->resolve_current_request();
    }

    /**
     * Enqueue tracking script.
     *
     * @return void
     */

	public function enqueue_tracking_script(): void {
        if ( ! $this->is_enabled() ) {
            return;
        }

		if (
			is_admin()
			|| is_feed()
			|| wp_doing_ajax()
			|| WPHAVE_Analytics_Preview_Guard::is_current_request()
		) {
            return;
        }

        $context = $this->get_tracking_object_context();

        if ( ! $context ) {
            return;
        }

        wp_enqueue_script(
            'wphave-analytics',
			wphave_asset_url( 'inc/features/analytics/analytics.js' ),
            [],
            self::VERSION,
            true
        );

		wp_add_inline_script(
			'wphave-analytics',
			'window.WPHAVE_ANALYTICS = ' . wp_json_encode( [
				'endpoint'            => esc_url_raw( rest_url( 'wphave/v1/analytics/track' ) ),
				'trackingMode'        => wphave_privacy_can_process( WPHAVE_Privacy_Manager::PURPOSE_ANALYTICS_SESSIONS ) ? 'sessions' : 'aggregate',
				'postId'              => (int) $context['post_id'],
				'objectType'          => $context['object_type'],
				'objectId'            => (int) $context['object_id'],
				'objectSubtype'       => $context['object_subtype'],
				'objectLabel'         => $context['object_label'],
				'objectUrl'           => $context['object_url'],
				'searchResultsBucket' => $this->get_search_results_bucket( $context ),
				'sessionTimeout'      => self::SESSION_TIMEOUT_MINUTES,
				'isLoggedIn'          => is_user_logged_in(),
			] ) . ';',
			'before'
		);
	}

	/**
	 * Return a coarse result-count bucket without exposing the search query.
	 *
	 * @param array $context Current analytics target.
	 * @return string Search result bucket.
	 */
	private function get_search_results_bucket( array $context ): string {
		if ( 'search' !== ( $context['object_type'] ?? '' ) ) {
			return '';
		}

		global $wp_query;

		$count = isset( $wp_query->found_posts ) ? absint( $wp_query->found_posts ) : 0;

		if ( 0 === $count ) {
			return 'none';
		}

		if ( $count <= 5 ) {
			return '1_5';
		}

		if ( $count <= 20 ) {
			return '6_20';
		}

		return '21_plus';
	}

}
