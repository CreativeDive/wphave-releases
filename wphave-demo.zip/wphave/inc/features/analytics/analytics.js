﻿/**
 * Collect privacy-aware frontend analytics events.
 *
 * Storage access deliberately falls back to memory when the browser blocks
 * AVAILABILITY INVARIANT: Analytics failures never break the frontend experience.
 */

(function () {
	if (!window.WPHAVE_ANALYTICS || !window.fetch) return;

	const config = window.WPHAVE_ANALYTICS;
	const hasSessionTracking = config.trackingMode === 'sessions';
	const now = Date.now();
	const sessionTimeout = (config.sessionTimeout || 30) * 60 * 1000;
	const memoryStorage = {};

	const getStorageItem = (storage, key) => {
		try {
			return storage.getItem(key);
		} catch {
			return memoryStorage[key] || null;
		}
	};

	const setStorageItem = (storage, key, value) => {
		try {
			storage.setItem(key, value);
		} catch {
			memoryStorage[key] = value;
		}
	};

	const removeStorageItem = (storage, key) => {
		try {
			storage.removeItem(key);
		} catch {
			delete memoryStorage[key];
		}
	};

	const clearSessionTrackingStorage = () => {
		removeStorageItem(localStorage, 'wphave_visitor_id');
		removeStorageItem(sessionStorage, 'wphave_session_id');
		removeStorageItem(sessionStorage, 'wphave_last_seen');
		removeStorageItem(sessionStorage, 'wphave_attribution');
	};

	const uuid = () => {
		if (window.crypto && crypto.randomUUID) {
			return crypto.randomUUID();
		}

		return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
			const r = (Math.random() * 16) | 0;
			const v = c === 'x' ? r : (r & 0x3) | 0x8;
			return v.toString(16);
		});
	};

	const params = new URLSearchParams(window.location.search);
	let visitorId = '';
	let sessionId = '';
	let storedAttribution = {};
	let attribution = {};

	if (hasSessionTracking) {
		visitorId = getStorageItem(localStorage, 'wphave_visitor_id');

		if (!visitorId) {
			visitorId = uuid();
			setStorageItem(localStorage, 'wphave_visitor_id', visitorId);
		}

		sessionId = getStorageItem(sessionStorage, 'wphave_session_id');
		const lastSeen = parseInt(getStorageItem(sessionStorage, 'wphave_last_seen') || '0', 10);
		let isNewSession = false;

		if (!sessionId || now - lastSeen > sessionTimeout) {
			sessionId = uuid();
			isNewSession = true;
			setStorageItem(sessionStorage, 'wphave_session_id', sessionId);
		}

		setStorageItem(sessionStorage, 'wphave_last_seen', String(now));

		const getParam = (primary, fallback = '') =>
			params.get(primary) || (fallback ? params.get(fallback) : '') || '';
		const urlAttribution = {
			utm_source: getParam('utm_source', 'wphave_source'),
			utm_medium: getParam('utm_medium', 'wphave_medium'),
			utm_campaign: getParam('utm_campaign', 'wphave_campaign'),
			utm_content: getParam('utm_content', 'wphave_content'),
			utm_term: getParam('utm_term', 'wphave_term')
		};
		const hasUrlAttribution = Object.values(urlAttribution).some(Boolean);

		try {
			storedAttribution = JSON.parse(
				getStorageItem(sessionStorage, 'wphave_attribution') || '{}'
			);
		} catch {
			storedAttribution = {};
		}

		if (isNewSession && !hasUrlAttribution) {
			storedAttribution = {};
			removeStorageItem(sessionStorage, 'wphave_attribution');
		}

		attribution = hasUrlAttribution ? urlAttribution : storedAttribution;

		if (hasUrlAttribution) {
			setStorageItem(sessionStorage, 'wphave_attribution', JSON.stringify(urlAttribution));
		}
	}

	const downloadExtensions = [
		'pdf',
		'doc',
		'docx',
		'xls',
		'xlsx',
		'ppt',
		'pptx',
		'zip',
		'rar',
		'7z',
		'csv',
		'txt',
		'mp3',
		'mp4',
		'mov',
		'webm'
	];

	const allowedCustomEventTypes = [
		'click',
		'download',
		'outbound',
		'subscribe',
		'register',
		'login',
		'search',
		'scroll',
		'time_on_page',
		'play',
		'custom_event'
	];

	const getAnonymousReferrerChannel = () => {
		if (!document.referrer) {
			return 'direct';
		}

		try {
			const referrer = new URL(document.referrer);

			if (referrer.hostname === window.location.hostname) {
				return 'internal';
			}

			const hostname = referrer.hostname.toLowerCase();

			if (
				['google.', 'bing.', 'yahoo.', 'duckduckgo.', 'ecosia.', 'baidu.', 'yandex.'].some(
					(engine) => hostname.includes(engine)
				)
			) {
				return 'search';
			}

			if (
				[
					'facebook.com',
					'instagram.com',
					'x.com',
					'twitter.com',
					'linkedin.com',
					'pinterest.com',
					'reddit.com',
					'tiktok.com',
					'youtube.com'
				].some((domain) => hostname === domain || hostname.endsWith(`.${domain}`))
			) {
				return 'social';
			}

			return 'referral';
		} catch {
			return 'direct';
		}
	};

	const basePayload = {
		post_id: config.postId,
		object_type: config.objectType || 'post',
		object_id: config.objectId || config.postId || 0,
		object_subtype: config.objectSubtype || '',
		object_label: hasSessionTracking ? config.objectLabel || '' : '',
		object_url: hasSessionTracking ? config.objectUrl || window.location.href : '',
		...(hasSessionTracking
			? {
					page_url: window.location.href,
					visitor_id: visitorId,
					session_id: sessionId,
					referrer_url: document.referrer || '',
					url: window.location.href,
					language: String(navigator.language || '')
						.toLowerCase()
						.split(/[-_]/)[0],
					utm_source: attribution.utm_source || '',
					utm_medium: attribution.utm_medium || '',
					utm_campaign: attribution.utm_campaign || '',
					utm_content: attribution.utm_content || '',
					utm_term: attribution.utm_term || '',
					is_logged_in: !!config.isLoggedIn
			  }
			: {
					referrer_channel: getAnonymousReferrerChannel(),
					search_results_bucket: config.searchResultsBucket || '',
					language_bucket: String(navigator.language || '')
						.toLowerCase()
						.split(/[-_]/)[0],
					screen_bucket: (() => {
						const width = window.screen ? Number(window.screen.width || 0) : 0;

						if (width < 768) return 'small';
						if (width < 1280) return 'medium';
						if (width < 1920) return 'large';

						return 'extra_large';
					})()
			  })
	};

	const recentEvents = {};

	const track = (eventType, payload = {}) => {
		if (!hasSessionTracking && eventType !== 'pageview') return;

		const dedupeKey = [
			eventType,
			payload.object_key || basePayload.object_key || '',
			payload.object_url || basePayload.object_url || '',
			basePayload.page_url || ''
		].join('|');

		const current = Date.now();

		if (
			[
				'download',
				'outbound',
				'click',
				'form_submit',
				'form_error',
				'subscribe',
				'register',
				'login',
				'search',
				'scroll',
				'time_on_page',
				'play',
				'custom_event'
			].includes(eventType) &&
			recentEvents[dedupeKey] &&
			current - recentEvents[dedupeKey] < 30000
		) {
			return;
		}

		recentEvents[dedupeKey] = current;

		const body = JSON.stringify({
			...basePayload,
			...payload,
			event_type: eventType,
			...(hasSessionTracking ? { event_id: payload.event_id || uuid() } : {})
		});

		if (navigator.sendBeacon) {
			navigator.sendBeacon(config.endpoint, new Blob([body], { type: 'application/json' }));
			return;
		}

		fetch(config.endpoint, {
			method: 'POST',
			credentials: 'same-origin',
			headers: {
				'Content-Type': 'application/json'
			},
			body,
			keepalive: true
		});
	};

	window.WPHAVE_ANALYTICS_CONTEXT = basePayload;
	window.WPHAVE_ANALYTICS_TRACK = track;

	track('pageview');

	window.addEventListener('wphave:consent-changed', (event) => {
		const consent = event?.detail?.consent || {};

		if (!consent.analytics && !consent.__all) {
			clearSessionTrackingStorage();
		}
	});

	if (!hasSessionTracking) return;

	const searchQuery = (params.get('s') || '').trim();

	if ((config.objectType === 'search' || searchQuery) && searchQuery) {
		track('search', {
			object_type: 'search',
			object_id: 0,
			object_key: `search:${searchQuery.toLowerCase()}`,
			object_subtype: 'query',
			object_label: searchQuery,
			object_url: window.location.href
		});
	}

	let engagementTracked = false;

	const trackEngagement = () => {
		if (engagementTracked) return;
		engagementTracked = true;
		track('engagement');
	};

	setTimeout(trackEngagement, 10000);
	window.addEventListener(
		'scroll',
		() => {
			const scrollable = document.documentElement.scrollHeight - window.innerHeight;
			if (scrollable > 0 && window.scrollY / scrollable >= 0.5) {
				trackEngagement();
			}
		},
		{ passive: true }
	);

	const trackedScrollDepths = {};
	const trackScrollDepth = () => {
		const scrollable = document.documentElement.scrollHeight - window.innerHeight;

		if (scrollable <= 0) return;

		const depth = Math.round((window.scrollY / scrollable) * 100);

		[50, 75, 90].forEach((threshold) => {
			if (depth < threshold || trackedScrollDepths[threshold]) return;

			trackedScrollDepths[threshold] = true;
			track('scroll', {
				object_type: 'scroll',
				object_id: threshold,
				object_key: `scroll:${threshold}`,
				object_subtype: String(threshold),
				object_label: `${threshold}% scroll depth`,
				object_url: window.location.href
			});
		});
	};

	window.addEventListener('scroll', trackScrollDepth, { passive: true });

	[30, 60, 120].forEach((seconds) => {
		setTimeout(() => {
			track('time_on_page', {
				object_type: 'time',
				object_id: seconds,
				object_key: `time_on_page:${seconds}`,
				object_subtype: String(seconds),
				object_label: `${seconds} seconds on page`,
				object_url: window.location.href
			});
		}, seconds * 1000);
	});

	document.addEventListener(
		'play',
		(event) => {
			const media = event.target;

			if (!media || !['AUDIO', 'VIDEO'].includes(media.tagName)) return;

			const source =
				media.currentSrc ||
				media.src ||
				media.querySelector?.('source[src]')?.getAttribute('src') ||
				'';

			track('play', {
				object_type: 'media',
				object_id: 0,
				object_key: source || media.id || media.tagName.toLowerCase(),
				object_subtype: media.tagName.toLowerCase(),
				object_label:
					media.getAttribute('aria-label') ||
					media.title ||
					source ||
					media.tagName.toLowerCase(),
				object_url: source || window.location.href
			});
		},
		true
	);

	document.addEventListener(
		'submit',
		(event) => {
			const form = event.target;

			if (!form || !form.matches || !form.matches('form')) return;

			const explicitType = (form.dataset.wphaveTrackType || '').toLowerCase();

			if (allowedCustomEventTypes.includes(explicitType)) {
				track(explicitType, {
					object_type: explicitType === 'custom_event' ? 'custom' : explicitType,
					object_id: 0,
					object_key:
						form.dataset.wphaveGoalId ||
						form.dataset.wphaveTrackLabel ||
						form.id ||
						form.name ||
						explicitType,
					object_subtype: form.dataset.wphaveTrackSubtype || form.id || form.name || '',
					object_label:
						form.dataset.wphaveTrackLabel ||
						form.getAttribute('aria-label') ||
						form.id ||
						explicitType,
					object_url: form.dataset.wphaveTrackUrl || window.location.href,
					goal_id: form.dataset.wphaveGoalId || '',
					value: form.dataset.wphaveValue || ''
				});
				return;
			}

			const formIdentity = [
				form.id || '',
				form.name || '',
				form.className || '',
				form.getAttribute('action') || ''
			]
				.join(' ')
				.toLowerCase();
			const inferredType = /login/.test(formIdentity)
				? 'login'
				: /register|registration|signup|sign-up/.test(formIdentity)
				? 'register'
				: /subscribe|newsletter|optin|opt-in/.test(formIdentity)
				? 'subscribe'
				: '';

			if (inferredType) {
				track(inferredType, {
					object_type: inferredType,
					object_id: 0,
					object_key: form.id || form.name || inferredType,
					object_subtype: form.id || form.name || '',
					object_label:
						form.getAttribute('aria-label') || form.id || form.name || inferredType,
					object_url: form.getAttribute('action') || window.location.href
				});
				return;
			}

			const searchInput = form.querySelector('input[name="s"], input[type="search"]');
			const isSearchForm =
				searchInput &&
				(form.getAttribute('role') === 'search' ||
					form.classList.contains('search-form') ||
					searchInput.name === 's');

			if (!isSearchForm) return;

			const query = (searchInput.value || '').trim();

			if (!query) return;

			track('search', {
				object_type: 'search',
				object_id: 0,
				object_key: `search:${query.toLowerCase()}`,
				object_subtype: 'query',
				object_label: query,
				object_url: window.location.href
			});
		},
		true
	);

	document.addEventListener(
		'click',
		(event) => {
			const link = event.target.closest ? event.target.closest('a[href]') : null;

			if (!link) return;

			const href = link.getAttribute('href');
			const explicitTracking = link.dataset.wphaveTrack === '1';
			if (
				!href ||
				href.startsWith('#') ||
				href.startsWith('javascript:') ||
				href.startsWith('tel:') ||
				href.startsWith('mailto:')
			) {
				return;
			}

			let url;

			try {
				url = new URL(href, window.location.href);
			} catch {
				return;
			}

			const pathname = url.pathname || '';
			const extensionMatch = pathname.match(/\.([a-z0-9]{2,8})$/i);
			const extension = extensionMatch ? extensionMatch[1].toLowerCase() : '';
			const isDownload =
				link.hasAttribute('download') || downloadExtensions.includes(extension);
			const isOutbound = url.hostname !== window.location.hostname;
			const explicitType = (link.dataset.wphaveTrackType || '').toLowerCase();

			if (explicitTracking) {
				const eventType = allowedCustomEventTypes.includes(explicitType)
					? explicitType
					: isDownload
					? 'download'
					: isOutbound
					? 'outbound'
					: 'click';
				const label =
					link.dataset.wphaveTrackLabel ||
					(link.textContent || '').trim() ||
					decodeURIComponent(pathname.split('/').filter(Boolean).pop() || '') ||
					url.hostname;
				const objectType =
					eventType === 'download' || eventType === 'outbound'
						? eventType
						: eventType === 'custom_event'
						? 'custom'
						: eventType;

				track(eventType, {
					object_type: objectType,
					object_id: 0,
					object_key:
						link.dataset.wphaveGoalId || link.dataset.wphaveTrackLabel || url.href,
					object_subtype:
						eventType === 'download'
							? extension || 'file'
							: eventType === 'outbound'
							? url.hostname
							: link.dataset.wphaveGoalId || 'link',
					object_label: label,
					object_url: link.dataset.wphaveTrackUrl || url.href,
					goal_id: link.dataset.wphaveGoalId || '',
					value: link.dataset.wphaveValue || ''
				});
				return;
			}

			if (!isDownload && !isOutbound) return;

			const eventType = isDownload ? 'download' : 'outbound';
			const label =
				(link.textContent || '').trim() ||
				decodeURIComponent(pathname.split('/').filter(Boolean).pop() || '') ||
				url.hostname;

			track(eventType, {
				object_type: eventType,
				object_id: 0,
				object_subtype: isDownload ? extension || 'file' : url.hostname,
				object_label: label,
				object_url: url.href
			});
		},
		true
	);
})();
