<?php

/**
 * Conversion goal storage and REST mutations.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPHAVE_Analytics_Goals {

    const OPTION = 'wphave_analytics_conversion_goals';
    const TYPES = WPHAVE_Analytics_Event_Types::CONVERSION;
    const MAX_REQUEST_BYTES = 8192;
    const MAX_GOALS = 100;

    /**
     * Return items.
     *
     * @return array Return items.
     */

    public function get_items(): array {
        $goals = get_option( self::OPTION, [] );

        return is_array( $goals ) ? array_values( array_filter( array_map( [ $this, 'normalize' ], $goals ) ) ) : [];
    }

    /**
     * API items.
     *
     * @return WP_REST_Response API items.
     */

    public function api_items(): WP_REST_Response {
        return rest_ensure_response( [
            'items' => $this->get_items(),
        ] );
    }

    /**
     * Save.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function save( WP_REST_Request $request ) {
		// AUTHORIZATION INVARIANT: Analytics read access does not authorize changing
		// the server-wide goal policy. Mutating callbacks repeat the management check
		// at the effect boundary even when REST permission callbacks already ran.
        if ( ! $this->can_manage() ) {
            return new WP_Error( 'wphave_analytics_forbidden', __( 'You are not allowed to manage analytics goals.', 'wphave' ), [ 'status' => 403 ] );
        }

        $budget_error = WPHAVE_REST_Body_Budget::check( $request, self::MAX_REQUEST_BYTES );
        if ( $budget_error ) {
            return $budget_error;
        }

        $data = $request->get_json_params();
        $data = is_array( $data ) ? $data : [];
        $goal = $this->sanitize( $data );

        if ( is_wp_error( $goal ) ) {
            return $goal;
        }

		// AUTHORIZATION INVARIANT: Sanitization and validation are extensible and
		// may outlive the entry check. Revalidate the same existing policy at the
		// commit boundary so stale authority cannot mutate the shared goal option.
		if ( ! $this->can_manage() ) {
			return new WP_Error( 'wphave_analytics_forbidden', __( 'You are not allowed to manage analytics goals.', 'wphave' ), [ 'status' => 403 ] );
		}

        $goals = WPHAVE_Option_Mutations::mutate( self::OPTION, function( $goals ) use ( $goal ) {
            // STORAGE INVARIANT: The bound is checked under the option lock so
            // concurrent writers cannot each append past the catalogue limit.
            if ( count( $goals ) > self::MAX_GOALS ) {
                return new WP_Error( 'wphave_analytics_goals_limit', __( 'Too many conversion goals are stored.', 'wphave' ), [ 'status' => 409 ] );
            }
            $found = false;

            foreach ( $goals as $index => $existing ) {
                if ( ($existing['id'] ?? '') === $goal['id'] ) {
                    $goals[ $index ] = $goal;
                    $found = true;
                    break;
                }
            }

            if ( ! $found ) {
                if ( count( $goals ) >= self::MAX_GOALS ) {
                    return new WP_Error( 'wphave_analytics_goals_limit', __( 'Too many conversion goals are stored.', 'wphave' ), [ 'status' => 409 ] );
                }
                $goals[] = $goal;
            }

            return array_values( $goals );
        } );

        if ( is_wp_error( $goals ) ) {
            return $goals;
        }

        return rest_ensure_response( [
            'success' => true,
            'items'   => $goals,
        ] );
    }

    /**
     * Delete.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function delete( WP_REST_Request $request ) {
		// AUTHORIZATION INVARIANT: Deletion follows the same management boundary as
		// creation and update; knowledge of a stable goal identifier is insufficient.
        if ( ! $this->can_manage() ) {
            return new WP_Error( 'wphave_analytics_forbidden', __( 'You are not allowed to manage analytics goals.', 'wphave' ), [ 'status' => 403 ] );
        }

        $id = $request->get_param( 'id' );

        // IDENTITY INVARIANT: Deletion cannot silently normalize a malformed
        // identifier into the ID of another saved goal.
        if (
            ! is_string( $id ) ||
            $id === '' ||
            strlen( $id ) > 190 ||
            ! preg_match( '/^[a-z0-9_-]+$/D', $id )
        ) {
            return new WP_Error( 'wphave_analytics_invalid_goal', __( 'Invalid conversion goal.', 'wphave' ), [ 'status' => 400 ] );
        }

        if ( sanitize_key( $id ) !== $id ) {
            return new WP_Error( 'wphave_analytics_invalid_goal', __( 'Invalid conversion goal.', 'wphave' ), [ 'status' => 400 ] );
        }

		// AUTHORIZATION INVARIANT: Identifier normalization is an extensible trust
		// boundary. Goal deletion requires fresh management authority immediately
		// before the shared option is mutated, not merely at callback entry.
		if ( ! $this->can_manage() ) {
			return new WP_Error( 'wphave_analytics_forbidden', __( 'You are not allowed to manage analytics goals.', 'wphave' ), [ 'status' => 403 ] );
		}

        $goals = WPHAVE_Option_Mutations::mutate( self::OPTION, fn( $goals ) => array_values( array_filter(
            $goals,
            fn( $goal ) => ($goal['id'] ?? '') !== $id
        ) ) );

        if ( is_wp_error( $goals ) ) {
            return $goals;
        }

        return rest_ensure_response( [
            'success' => true,
            'items'   => $goals,
        ] );
    }

    /**
     * Determine whether the current user can manage goals.
     *
     * @return bool Determine whether the current user can manage goals.
     */

    private function can_manage(): bool {
		return current_user_can( 'manage_options' )
			|| current_user_can( 'wphave_manage_settings_tracking' );
    }

    /**
     * Sanitize.
     *
     * @param array $data Data.
     */

    private function sanitize( array $data ) {
        // IDENTITY INVARIANT: A supplied ID must already be canonical. Silent
        // sanitize_key() conversion could otherwise overwrite a different goal.
        if (
            array_key_exists( 'id', $data ) &&
            (
                ! is_string( $data['id'] ) ||
                $data['id'] === '' ||
                strlen( $data['id'] ) > 190 ||
                ! preg_match( '/^[a-z0-9_-]+$/D', $data['id'] )
            )
        ) {
            return new WP_Error( 'wphave_analytics_invalid_goal', __( 'Invalid conversion goal identifier.', 'wphave' ), [ 'status' => 400 ] );
        }

        // VALUE INVARIANT: Non-finite numbers cannot be stored as a conversion
        // value because JSON and report arithmetic cannot represent them.
        if (
            isset( $data['value'] ) &&
            ( ! is_numeric( $data['value'] ) || ! is_finite( (float) $data['value'] ) )
        ) {
            return new WP_Error( 'wphave_analytics_invalid_goal', __( 'Invalid conversion goal value.', 'wphave' ), [ 'status' => 400 ] );
        }
        $goal = $this->normalize( $data );

        if ( ! $goal || ! $goal['label'] ) {
            return new WP_Error( 'wphave_analytics_invalid_goal', __( 'Conversion goal needs a label.', 'wphave' ), [ 'status' => 400 ] );
        }

        $validation = $this->validate_match_rule( $goal );

        if ( is_wp_error( $validation ) ) {
            return $validation;
        }

        return $goal;
    }

    /**
     * Validate match rule.
     *
     * @param array $goal Goal.
     */

    private function validate_match_rule( array $goal ) {
        $match = trim( (string) ( $goal['match'] ?? '' ) );
        $type = $goal['type'] ?? 'form_submit';

        if ( in_array( $type, [ 'pageview', 'subscribe', 'register', 'search', 'scroll', 'time_on_page', 'play', 'custom_event' ], true ) && $match === '' ) {
            return new WP_Error( 'wphave_analytics_goal_match_required', __( 'This goal type needs a match rule so it does not count every event of that type.', 'wphave' ), [ 'status' => 400 ] );
        }

        if ( $match !== '' ) {
            $too_broad = in_array( $match, [ '*', '/', '/*', 'http://', 'https://' ], true );

            if ( strlen( $match ) < 3 || $too_broad ) {
                return new WP_Error( 'wphave_analytics_goal_match_too_broad', __( 'The match rule is too broad. Use a specific form ID, URL fragment, file URL, outbound URL or object key.', 'wphave' ), [ 'status' => 400 ] );
            }
        }

        return true;
    }

    /**
     * Normalize.
     *
     * @param array $data Data.
     * @return ?array Normalize.
     */

    private function normalize( array $data ): ?array {
        $type = sanitize_key( $data['type'] ?? 'form_submit' );

        if ( ! in_array( $type, self::TYPES, true ) ) {
            return null;
        }

        // REPORT INVARIANT: Historical option rows pass through this reader too.
        // A malformed stored value must not reintroduce INF into JSON or totals.
        $value = $data['value'] ?? 0;
        if ( ! is_numeric( $value ) || ! is_finite( (float) $value ) ) {
            return null;
        }

        $id = sanitize_key( $data['id'] ?? '' );

        return [
            'id'      => $id ?: 'goal_' . wp_generate_uuid4(),
            'label'   => sanitize_text_field( substr( (string) ( $data['label'] ?? '' ), 0, 120 ) ),
            'type'    => $type,
            'match'   => sanitize_text_field( substr( (string) ( $data['match'] ?? '' ), 0, 255 ) ),
            'value'   => max( 0, (float) $value ),
            'enabled' => ! isset( $data['enabled'] ) || (bool) $data['enabled'],
        ];
    }
}
