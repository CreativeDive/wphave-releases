<?php

/**
 * REST route registration for WPHAVE analytics.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPHAVE_Analytics_REST_Controller {

    private WPHAVE_Analytics $analytics;

    /**
     * Initialize the REST service.
     *
     * @param WPHAVE_Analytics $analytics Analytics.
     */

    public function __construct( WPHAVE_Analytics $analytics ) {
        $this->analytics = $analytics;
    }

    /**
     * Register the REST REST routes.
     *
     * @return void
     */

    public function register_routes(): void {
        // ADMISSION INVARIANT: Goal writes are small policy documents. Reject an
        // oversized JSON body before WordPress decodes and validates route args.
        WPHAVE_REST_Body_Budget::protect(
            'POST',
            '~^/wphave/v1/analytics/goals$~D',
            WPHAVE_Analytics_Goals::MAX_REQUEST_BYTES,
        );
        WPHAVE_REST_Body_Budget::protect(
            'POST',
            '~^/wphave/v1/analytics/track$~D',
            WPHAVE_Analytics::TRACK_MAX_PAYLOAD_BYTES,
        );
        // PRIVACY INVARIANT: Anonymous clients may submit a bounded tracking event,
        // but every analytics projection remains protected by can_view_analytics.
        $this->register_route( '/analytics/track', 'POST', 'track', '__return_true' );
        $this->register_route( '/analytics/stats', 'GET', 'api_stats' );
        $this->register_route( '/analytics/posts', 'GET', 'api_posts' );
        $this->register_route( '/analytics/timeseries', 'GET', 'api_timeseries' );
        $this->register_route( '/analytics', 'GET', 'api_overview' );
        $this->register_route( '/analytics/compare', 'GET', 'api_compare' );
        $this->register_route( '/analytics/overview', 'GET', 'api_overview' );
        $this->register_route( '/analytics/overview-composition', 'GET', 'api_overview_composition' );
        $this->register_route( '/analytics/behavior-composition', 'GET', 'api_behavior_composition' );
        $this->register_route( '/analytics/acquisition-composition', 'GET', 'api_acquisition_composition' );
        $this->register_route( '/analytics/engagement-composition', 'GET', 'api_engagement_composition' );
        $this->register_route( '/analytics/entry-pages', 'GET', 'api_entry_pages' );
        $this->register_route( '/analytics/exit-pages', 'GET', 'api_exit_pages' );
        $this->register_route( '/analytics/flow', 'GET', 'api_flow' );
        $this->register_route( '/analytics/realtime', 'GET', 'api_realtime' );
        $this->register_route( '/analytics/status', 'GET', 'api_status' );
        $this->register_route(
            '/analytics/pages',
            'GET',
            'api_pages',
            null,
            ['search' => ['type' => 'string', 'maxLength' => 200]],
        );
        $this->register_route( '/analytics/campaigns', 'GET', 'api_campaigns' );
        $this->register_route( '/analytics/technology', 'GET', 'api_technology' );
        $this->register_route( '/analytics/geography', 'GET', 'api_geography' );
        $this->register_route( '/analytics/insights', 'GET', 'api_insights' );
        $this->register_route( '/analytics/goals', 'GET', 'api_goals' );
		$this->register_route(
			'/analytics/goals',
			'POST',
			'save_goal',
			[ $this->analytics, 'can_manage_analytics' ],
			$this->goal_route_args()
		);
        $this->register_route( '/analytics/conversion-events', 'GET', 'api_conversion_events' );
        $this->register_route( '/analytics/export/goals', 'GET', 'api_export_goals' );
        $this->register_route( '/analytics/export/conversion-events', 'GET', 'api_export_conversion_events' );
		$this->register_route(
			'/analytics/goals/(?P<id>[a-zA-Z0-9_\\-]+)',
			'DELETE',
			'delete_goal',
			[ $this->analytics, 'can_manage_analytics' ],
			[
				'id' => [
					'required'          => true,
					'type'              => 'string',
					'maxLength'         => 190,
					'pattern'           => '^[a-z0-9_\\-]+$',
				],
			]
		);
    }

    /**
     * Register route.
     *
     * @param string $route Route.
     * @param string $methods Methods.
     * @param string $callback Callback.
     * @param mixed $permission_callback Permission callback.
     * @param array $args Function arguments.
     * @return void
     */

    private function register_route( string $route, string $methods, string $callback, $permission_callback = null, array $args = [] ): void {
        register_rest_route( 'wphave/v1', $route, [
            'methods'             => $methods,
            'callback'            => [ $this->analytics, $callback ],
            'permission_callback' => $permission_callback ?: [ $this->analytics, 'can_view_analytics' ],
            'args'                => $args,
        ] );
    }

    /**
     * Goal route args.
     *
     * @return array Goal route args.
     */

    private function goal_route_args(): array {
        return [
            'id' => [
                'type'              => 'string',
                'maxLength'         => 190,
                'pattern'           => '^[a-z0-9_\\-]+$',
            ],
            'label' => [
                'required'          => true,
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'type' => [
                'required'          => true,
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_key',
            ],
            'match' => [
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'value' => [
                'type'              => 'number',
                'sanitize_callback' => static fn( $value ) => is_numeric( $value ) ? (float) $value : 0,
            ],
            'enabled' => [
                'type'              => 'boolean',
                'sanitize_callback' => 'rest_sanitize_boolean',
            ],
        ];
    }
}
