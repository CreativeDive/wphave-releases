<?php

/**
 * Exposes the analytics REST facade and scheduled repository operations.
 */

trait WPHAVE_Analytics_REST_API {

    /**
     * API overview.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_overview(WP_REST_Request $request) {
		return $this->dispatch_analytics_report( function() use ( $request ) {
			$response = $this->reports->api_overview( $request );
			$data = $response instanceof WP_REST_Response ? $response->get_data() : array();
			$data = is_array( $data ) ? $data : array();
			$data['providers'] = apply_filters( 'wphave_analytics_provider_projections', array(), $request );

			return rest_ensure_response( $data );
		} );
    }

    /**
     * API compare.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_compare(WP_REST_Request $request) {
        return $this->dispatch_analytics_report( fn() => $this->reports->api_compare( $request ) );
    }

    /**
     * Compose the reports required by the Analytics Overview transport.
     *
     * Report ownership remains with the existing report methods. This endpoint
     * only removes repeated HTTP and WordPress bootstrap overhead.
     *
     * @param WP_REST_Request $request REST request.
     * @return WP_REST_Response|WP_Error Composed report response.
     */

    public function api_overview_composition( WP_REST_Request $request ) {
        return $this->compose_analytics_reports(
            $request,
            [
                'overview'  => 'api_overview',
                'compare'   => 'api_compare',
                'insights'  => 'api_insights',
                'campaigns' => 'api_campaigns',
                'status'    => 'api_status',
            ]
        );
    }

    /**
     * Compose the period-bound reports required by Analytics Behavior.
     *
     * The independently paginated pages collection intentionally remains on
     * its canonical route so table interactions never reload this envelope.
     *
     * @param WP_REST_Request $request REST request.
     * @return WP_REST_Response|WP_Error Composed report response.
     */

    public function api_behavior_composition( WP_REST_Request $request ) {
        return $this->compose_analytics_reports(
            $request,
            [
                'overview'   => 'api_overview',
                'entryPages' => 'api_entry_pages',
                'exitPages'  => 'api_exit_pages',
                'insights'   => 'api_insights',
            ]
        );
    }

    /**
     * Compose the reports required by Analytics Acquisition.
     *
     * @param WP_REST_Request $request REST request.
     * @return WP_REST_Response|WP_Error Composed report response.
     */

    public function api_acquisition_composition( WP_REST_Request $request ) {
        return $this->compose_analytics_reports(
            $request,
            [
                'overview'  => 'api_overview',
                'campaigns' => 'api_campaigns',
            ]
        );
    }

    /** Compose the Analytics reports consumed by the Engagement workspace. */

    public function api_engagement_composition( WP_REST_Request $request ) {
        return $this->compose_analytics_reports(
            $request,
            [
                'overview' => 'api_overview',
                'insights' => 'api_insights',
            ]
        );
    }

    /**
     * Execute an explicitly declared Analytics report projection map.
     *
     * @param WP_REST_Request     $request REST request.
     * @param array<string,string> $report_methods Projection to report method map.
     * @return WP_REST_Response|WP_Error Composed report response.
     */

    private function compose_analytics_reports( WP_REST_Request $request, array $report_methods ) {
		return $this->dispatch_analytics_report( function() use ( $request, $report_methods ) {
			$projections = [];

			foreach ( $report_methods as $projection => $method ) {
				$response = $this->reports->{$method}( $request );

				if ( is_wp_error( $response ) ) {
					return $response;
				}

				$projection_data = rest_ensure_response( $response )->get_data();

				if ( 'overview' === $projection && is_array( $projection_data ) ) {
					$projection_data['providers'] = apply_filters( 'wphave_analytics_provider_projections', array(), $request );
				}

				$projections[ $projection ] = $projection_data;
			}

			return rest_ensure_response( $projections );
		} );
    }

	/**
	 * Execute and release one privileged Analytics report.
	 *
	 * @param callable $report Report producer.
	 * @return mixed Report response or authorization error.
	 */
	private function dispatch_analytics_report( callable $report ) {
		// AUTHORIZATION INVARIANT: REST permission callbacks are only an early
		// dispatch gate. Every public report/export callback repeats Analytics view
		// authority before work and after extensible projections before disclosure.
		if ( ! $this->can_view_analytics() ) {
			return $this->analytics_view_forbidden();
		}

		$response = $report();

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		if ( ! $this->can_view_analytics() ) {
			return $this->analytics_view_forbidden();
		}

		return $response;
	}

	/** Return the stable Analytics disclosure denial. */
	private function analytics_view_forbidden(): WP_Error {
		return new WP_Error(
			'wphave_analytics_forbidden',
			__( 'You are not allowed to view analytics.', 'wphave' ),
			[ 'status' => 403 ]
		);
	}

    /**
     * Register the functions REST routes.
     *
     * @return void
     */

    public function register_routes(): void {
        $this->rest_controller->register_routes();
    }

    /**
     * Determine whether the current user can view analytics.
     *
     * @return bool Determine whether the current user can view analytics.
     */

    public function can_view_analytics(): bool {
        return current_user_can( 'manage_options' ) || current_user_can( 'view_wphave_analytics' );
    }

    /**
     * Determine whether the current user can manage analytics.
     *
     * @return bool Determine whether the current user can manage analytics.
     */

    public function can_manage_analytics(): bool {
		return current_user_can( 'manage_options' )
			|| current_user_can( 'wphave_manage_settings_tracking' );
    }

	/**
	 * Track.
	 *
	 * @param WP_REST_Request $request REST request.
	 */

    /**
     * Aggregate daily.
     *
     * @return void
     */

    public function aggregate_daily(): void {
        if ( ! $this->is_enabled() ) {
            return;
        }

        $this->repository->aggregate_daily();
    }

    /**
     * API entry pages.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_entry_pages(WP_REST_Request $request) {
        return $this->dispatch_analytics_report( fn() => $this->reports->api_entry_pages( $request ) );
    }

    /**
     * API exit pages.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_exit_pages(WP_REST_Request $request) {
        return $this->dispatch_analytics_report( fn() => $this->reports->api_exit_pages( $request ) );
    }

    /**
     * API flow.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_flow(WP_REST_Request $request) {
        return $this->dispatch_analytics_report( fn() => $this->reports->api_flow( $request ) );
    }

    /**
     * Cleanup events.
     *
     * @return void
     */

    public function cleanup_events(): void {
		$lock_option = 'wphave_analytics_cleanup_lock';
		$lock_token = WPHAVE_Background_Job_Lock::acquire(
			$lock_option,
			15 * MINUTE_IN_SECONDS
		);
		if ( ! $lock_token ) {
			return;
		}

		try {
			// SECURITY INVARIANT: Raw expired events are deleted only after their daily
			// ORDERING INVARIANT: Retention runs only after the aggregate has committed successfully. It must not destroy
			// the sole copy of analytics data when aggregation fails.
			if ( ! $this->repository->aggregate_daily() ) {
				throw new RuntimeException(
					'Analytics retention cleanup requires a successful aggregation.'
				);
			}

			$deleted = $this->repository->cleanup_events();
			$failed = (bool) $deleted['failed'];
			unset( $deleted['failed'] );
			$has_more = ! $failed && max( $deleted ) >= 5000;
			$needs_retry = $failed || $has_more;
			$continuation_scheduled = $needs_retry
				? WPHAVE_Analytics_Retention_Policy::schedule_cleanup_continuation(
					( $failed ? 15 : 5 ) * MINUTE_IN_SECONDS
				)
				: false;
			$previous_status = get_option( 'wphave_analytics_cleanup_status', [] );
			$previous_status = is_array( $previous_status ) ? $previous_status : [];

			update_option(
				'wphave_analytics_cleanup_status',
				[
					'lastRun' => gmdate( 'c' ),
					'lastSuccess' => $failed
						? ( $previous_status['lastSuccess'] ?? null )
						: gmdate( 'c' ),
					'deleted' => $deleted,
					'error' => $failed
						? __(
							'Analytics retention cleanup could not delete every expired row.',
							'wphave'
						)
						: null,
					'continuationPending' => $needs_retry,
					'continuationScheduled' => $continuation_scheduled,
					'scheduleError' => $needs_retry && ! $continuation_scheduled
						? __( 'Analytics retention cleanup could not be scheduled.', 'wphave' )
						: null,
				],
				false
			);
		} catch ( Throwable $error ) {
			$previous_status = get_option( 'wphave_analytics_cleanup_status', [] );
			$previous_status = is_array( $previous_status ) ? $previous_status : [];
			$continuation_scheduled = WPHAVE_Analytics_Retention_Policy::schedule_cleanup_continuation(
				15 * MINUTE_IN_SECONDS
			);
			update_option(
				'wphave_analytics_cleanup_status',
				[
					'lastRun' => gmdate( 'c' ),
					'lastSuccess' => $previous_status['lastSuccess'] ?? null,
					'deleted' => [],
					'error' => __( 'Analytics retention cleanup failed.', 'wphave' ),
					'continuationPending' => true,
					'continuationScheduled' => $continuation_scheduled,
					'scheduleError' => $continuation_scheduled
						? null
						: __( 'Analytics retention cleanup could not be scheduled.', 'wphave' ),
				],
				false
			);
		} finally {
			// SECURITY INVARIANT: Cleanup authority remains bound to the atomic
			// retention lease even after timeout recovery by a successor.
			WPHAVE_Background_Job_Lock::release( $lock_option, $lock_token );
		}
    }

    /**
     * API stats.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_stats(WP_REST_Request $request) {
        return $this->dispatch_analytics_report( fn() => $this->reports->api_stats( $request ) );
    }

    /**
     * API posts.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_posts(WP_REST_Request $request) {
        return $this->dispatch_analytics_report( fn() => $this->reports->api_posts( $request ) );
    }

    /**
     * API realtime.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_realtime(WP_REST_Request $request) {
        return $this->dispatch_analytics_report( fn() => $this->reports->api_realtime( $request ) );
    }

    /**
     * API status.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_status(WP_REST_Request $request) {
        return $this->dispatch_analytics_report( fn() => $this->reports->api_status( $request ) );
    }

    /**
     * API pages.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_pages(WP_REST_Request $request) {
        return $this->dispatch_analytics_report( fn() => $this->reports->api_pages( $request ) );
    }

    /**
     * API campaigns.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_campaigns(WP_REST_Request $request) {
        return $this->dispatch_analytics_report( fn() => $this->reports->api_campaigns( $request ) );
    }

    /**
     * API technology.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_technology(WP_REST_Request $request) {
        return $this->dispatch_analytics_report( fn() => $this->reports->api_technology( $request ) );
    }

    /**
     * API geography.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_geography(WP_REST_Request $request) {
        return $this->dispatch_analytics_report( fn() => $this->reports->api_geography( $request ) );
    }

    /**
     * API insights.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_insights(WP_REST_Request $request) {
        return $this->dispatch_analytics_report( fn() => $this->reports->api_insights( $request ) );
    }

    /**
     * API goals.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_goals(WP_REST_Request $request) {
        return $this->dispatch_analytics_report( fn() => $this->reports->api_goals( $request ) );
    }

    /**
     * API conversion events.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_conversion_events(WP_REST_Request $request) {
		return $this->dispatch_analytics_report( function() use ( $request ) {
			$response = $this->reports->api_conversion_events( $request );
			$data = $response instanceof WP_REST_Response ? $response->get_data() : array();
			$data = is_array( $data ) ? $data : array();
			$data['providers'] = apply_filters( 'wphave_conversion_provider_projections', array(), $request );

			return rest_ensure_response( $data );
		} );
    }

    /**
     * API export goals.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_export_goals(WP_REST_Request $request) {
        return $this->dispatch_analytics_report( fn() => $this->reports->api_export_goals( $request ) );
    }

    /**
     * API export conversion events.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_export_conversion_events(WP_REST_Request $request) {
        return $this->dispatch_analytics_report( fn() => $this->reports->api_export_conversion_events( $request ) );
    }

    /**
     * Save goal.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function save_goal(WP_REST_Request $request) {
        return $this->goals->save( $request );
    }

    /**
     * Delete goal.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function delete_goal(WP_REST_Request $request) {
        return $this->goals->delete( $request );
    }

    /**
     * API timeseries.
     *
     * @param WP_REST_Request $request REST request.
     */

    public function api_timeseries(WP_REST_Request $request) {
        return $this->dispatch_analytics_report( fn() => $this->reports->api_timeseries( $request ) );
    }

}
