<?php

/**
 * Bootstrap the WPHAVE analytics feature.
 */

if( ! defined( 'ABSPATH' ) ) {
    exit;
}

if (
	! defined( 'WPHAVE_ANALYTICS_INTERACTIVE_RUNTIME' )
	&& ( ! defined( 'WPHAVE_ANALYTICS_WORKER_RUNTIME' ) || ! WPHAVE_ANALYTICS_WORKER_RUNTIME )
) {
	define( 'WPHAVE_ANALYTICS_INTERACTIVE_RUNTIME', true );
}

require_once wphave_dir() . 'inc/background-jobs/functions.php';
require_once __DIR__ . '/tracking/dimensions.php';
require_once __DIR__ . '/tracking/event-types.php';
require_once __DIR__ . '/tracking/user-agent-classifier.php';
require_once __DIR__ . '/tracking/preview-guard.php';
require_once __DIR__ . '/privacy/retention-policy.php';
require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/tracking/repository.php';
require_once __DIR__ . '/runtime.php';
require_once __DIR__ . '/api/rest-api.php';
require_once __DIR__ . '/tracking/tracking.php';
require_once __DIR__ . '/privacy/privacy.php';

if ( defined( 'WPHAVE_ANALYTICS_INTERACTIVE_RUNTIME' ) && WPHAVE_ANALYTICS_INTERACTIVE_RUNTIME ) {
	// INTERACTIVE INVARIANT: Reports, public tracking resolution and REST
	// controllers never belong to aggregation or retention-only Cron requests.
	require_once __DIR__ . '/privacy/country-resolver.php';
	require_once __DIR__ . '/tracking/query-builder.php';
	require_once __DIR__ . '/tracking/audience-linker.php';
	require_once __DIR__ . '/goals.php';
	require_once __DIR__ . '/tracking/event-query.php';
	require_once __DIR__ . '/reports/repository.php';
	require_once __DIR__ . '/tracking/target-resolver.php';
	require_once __DIR__ . '/api/rest-controller.php';
}

require_once __DIR__ . '/analytics.php';

if( ! defined( 'WPHAVE_ANALYTICS_TRACK_LOGGED_IN' ) ) {
    define( 'WPHAVE_ANALYTICS_TRACK_LOGGED_IN', true );
}
