<?php

/**
 * Coordinates WPHAVE analytics services and WordPress hooks.
 */

class WPHAVE_Analytics {

    use WPHAVE_Analytics_Runtime;
    use WPHAVE_Analytics_REST_API;
    use WPHAVE_Analytics_Tracking;
    use WPHAVE_Analytics_Privacy;

	const VERSION = '1.0.13';
    const EVENT_TABLE = 'wphave_analytics_events';
    const DAILY_TABLE = 'wphave_analytics_daily';
	const PRIVACY_DAILY_TABLE = 'wphave_analytics_privacy_daily';
	const AGGREGATION_SCHEDULE_OPTION = 'wphave_analytics_aggregation_schedule';
	const CLEANUP_SCHEDULE_OPTION = 'wphave_analytics_cleanup_schedule';
    const SESSION_TIMEOUT_MINUTES = 30;
    const TRACK_RATE_LIMIT_MAX = 600;
    const TRACK_RATE_LIMIT_WINDOW = HOUR_IN_SECONDS;
	const TRACK_MAX_PAYLOAD_BYTES = 32 * 1024;

    private static ?WPHAVE_Analytics $instance = null;
    private string $events_table;
    private string $daily_table;
    private WPHAVE_Analytics_Schema $schema;
    private ?WPHAVE_Analytics_Target_Resolver $target_resolver = null;
    private ?WPHAVE_Analytics_Query_Builder $query_builder = null;
    private ?WPHAVE_Analytics_REST_Controller $rest_controller = null;
    private WPHAVE_Analytics_Repository $repository;
    private ?WPHAVE_Analytics_Goals $goals = null;
    private ?WPHAVE_Analytics_Event_Query $event_query = null;
    private ?WPHAVE_Analytics_Report_Repository $reports = null;
    private ?WPHAVE_Analytics_Audience_Linker $audience_linker = null;
    private ?WPHAVE_Analytics_Country_Resolver $country_resolver = null;

    /**
     * Initialize the analytics services and hooks.
     */

    public function __construct() {
        global $wpdb;

        $this->events_table = $wpdb->prefix . self::EVENT_TABLE;
        $this->daily_table = $wpdb->prefix . self::DAILY_TABLE;
        $this->schema = new WPHAVE_Analytics_Schema( $this->events_table, $this->daily_table );
        $this->repository = new WPHAVE_Analytics_Repository( $this->events_table, $this->daily_table, $this->schema );

        // LIFECYCLE INVARIANT: Analytics is booted from inside `init`. Registering
        // another `init` callback here could miss first-request scheduling, so the
        // idempotent scheduler must run immediately once runtime compatibility is known.
        $this->schedule_crons();
		$has_worker_runtime = defined( 'WPHAVE_ANALYTICS_WORKER_RUNTIME' ) && WPHAVE_ANALYTICS_WORKER_RUNTIME;
		$has_interactive_runtime = defined( 'WPHAVE_ANALYTICS_INTERACTIVE_RUNTIME' ) && WPHAVE_ANALYTICS_INTERACTIVE_RUNTIME;
		if ( $has_interactive_runtime ) {
			$this->audience_linker = new WPHAVE_Analytics_Audience_Linker( $this->schema );
			$this->country_resolver = new WPHAVE_Analytics_Country_Resolver();
			$this->goals = new WPHAVE_Analytics_Goals();
			$this->event_query = new WPHAVE_Analytics_Event_Query( $this->events_table, $this->schema );
			$this->target_resolver = new WPHAVE_Analytics_Target_Resolver();
			$this->query_builder = new WPHAVE_Analytics_Query_Builder();
			$this->reports = new WPHAVE_Analytics_Report_Repository( $this->events_table, $this->daily_table, $this->schema, $this->query_builder );
			$this->rest_controller = new WPHAVE_Analytics_REST_Controller( $this );
		}

		// WORKER INVARIANT: Cron owns only persisted aggregation and retention
		// callbacks. Public tracking assets and REST controllers are interactive
		// request surfaces and must never be registered by a worker-only entrypoint.
		// WP-CLI deliberately composes both runtimes, so these capabilities remain
		// monotone when the worker context is added to an interactive request.
		if ( $has_worker_runtime ) {
			add_action( 'wphave_analytics_aggregate_daily', [ $this, 'aggregate_daily' ] );
			add_action( 'wphave_analytics_cleanup_events', [ $this, 'cleanup_events' ] );
			add_action( WPHAVE_Analytics_Retention_Policy::CLEANUP_CONTINUATION_HOOK, [ $this, 'cleanup_events' ] );
		}

		if ( $has_interactive_runtime ) {
			add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_tracking_script' ] );
			add_action( 'rest_api_init', [ $this, 'register_routes' ] );
			add_filter( 'wphave_form_submission_analytics_tracked', [ $this, 'track_form_submission' ], 10, 2 );
			add_filter( 'wphave_form_error_analytics_tracked', [ $this, 'track_form_error' ], 10, 2 );
		}

        if( class_exists( 'WPHAVE_Privacy_Manager' ) ) {
            WPHAVE_Privacy_Manager::register_retention_policy( [
                'id' => 'analytics-retention',
				'label' => __( 'Analytics raw-event retention', 'wphave' ),
                'retention_days' => WPHAVE_Analytics_Retention_Policy::raw_days(),
                'callback' => [ $this, 'cleanup_events' ],
            ] );
            WPHAVE_Privacy_Manager::register_exporter( 'wphave-analytics', __( 'WPHAVE Analytics', 'wphave' ), [ $this, 'privacy_export' ] );
            WPHAVE_Privacy_Manager::register_eraser( 'wphave-analytics', __( 'WPHAVE Analytics', 'wphave' ), [ $this, 'privacy_erase' ] );
        }

    }

    /**
     * Boot one analytics instance for the request.
     *
     * @return WPHAVE_Analytics Shared analytics instance.
     */

    public static function boot(): WPHAVE_Analytics {
        if( self::$instance === null ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

}

WPHAVE_Database_Schema_Manager::register( [
    'id' => 'analytics',
    'label' => 'Analytics tables',
    'version' => WPHAVE_Analytics_Schema::DB_VERSION,
    'option' => 'wphave_analytics_db_version',
	'tables' => [
		WPHAVE_Analytics::EVENT_TABLE,
		WPHAVE_Analytics::DAILY_TABLE,
		WPHAVE_Analytics::PRIVACY_DAILY_TABLE,
	],
    'callback' => [ 'WPHAVE_Analytics', 'install' ],
    'validator' => [ 'WPHAVE_Analytics_Schema', 'validate' ],
] );

add_action( 'init', static function (): void {
	if ( ! WPHAVE_Database_Schema_Manager::runtime_compatible( 'analytics' ) ) {
		return;
	}

	WPHAVE_Analytics::boot();
} );
