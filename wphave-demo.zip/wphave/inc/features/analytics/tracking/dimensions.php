<?php

/**
 * Shared analytics dimension helpers.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPHAVE_Analytics_Dimensions {

    /**
     * Stable ID.
     *
     * @param string $value Value.
     * @return int Stable ID.
     */

    public static function stable_id( string $value ): int {
        return absint( sprintf( '%u', crc32( strtolower( trim( $value ) ) ) ) );
    }

    /**
     * Object key.
     *
     * @param string $object_type Object type.
     * @param int $object_id Object ID.
     * @param string $object_subtype Object subtype.
     * @return string Object key.
     */

    public static function object_key( string $object_type, int $object_id, string $object_subtype = '' ): string {
        return substr( sanitize_key( $object_type ) . ':' . absint( $object_id ) . ':' . sanitize_key( $object_subtype ), 0, 190 );
    }

    /**
     * Dimension hash.
     *
     * @param array $dimensions Dimensions.
     * @return string Dimension hash.
     */

    public static function dimension_hash( array $dimensions ): string {
        $values = [
            $dimensions['object_key'] ?? '',
            $dimensions['view_date'] ?? '',
            $dimensions['source'] ?? '',
            $dimensions['medium'] ?? '',
            $dimensions['campaign'] ?? '',
            $dimensions['referrer_domain'] ?? '',
            $dimensions['device_type'] ?? '',
            $dimensions['browser'] ?? '',
            $dimensions['os'] ?? '',
        ];

        return hash( 'sha256', implode( '|', array_map( 'strval', $values ) ) );
    }
}
