<?php

/**
 * Focused analytics event read helpers for cross-feature integrations.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPHAVE_Analytics_Event_Query {

    private string $events_table;
    private WPHAVE_Analytics_Schema $schema;

    /**
     * Initialize the event query service.
     *
     * @param string $events_table Events table.
     * @param WPHAVE_Analytics_Schema $schema Schema.
     */

    public function __construct( string $events_table, WPHAVE_Analytics_Schema $schema ) {
        $this->events_table = $events_table;
        $this->schema = $schema;
    }

    /**
     * Return session journey.
     *
     * @param string $session_hash Session hash.
     * @param int $limit Limit.
     * @return array Return session journey.
     */

    public function get_session_journey( string $session_hash, int $limit = 50 ): array {
        if ( ! $session_hash || ! $this->schema->table_exists( $this->events_table ) ) {
            return [];
        }

        global $wpdb;

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "
                SELECT event_type, goal_id, object_type, object_key, object_subtype, object_label, object_url, page_url, referrer_domain, source, medium, campaign, device_type, browser, os, viewed_at
                FROM {$this->events_table}
                WHERE session_id = %s
				" . WPHAVE_Analytics_Preview_Guard::get_event_exclusion_sql() . "
                ORDER BY viewed_at ASC
                LIMIT %d
                ",
                sanitize_text_field( $session_hash ),
                max( 1, min( 100, $limit ) )
            ),
            ARRAY_A
        );

        return array_map( [ $this, 'format_event' ], $rows ?: [] );
    }

    /**
     * Format event.
     *
     * @param array $row Row.
     * @return array Format event.
     */

    private function format_event( array $row ): array {
        return [
            'event_type'   => sanitize_key( $row['event_type'] ?? '' ),
            'goal_id'      => sanitize_key( $row['goal_id'] ?? '' ),
            'object_type'  => sanitize_key( $row['object_type'] ?? '' ),
            'object_key'   => sanitize_text_field( $row['object_key'] ?? '' ),
            'object_subtype' => sanitize_text_field( $row['object_subtype'] ?? '' ),
            'object_label' => sanitize_text_field( $row['object_label'] ?? '' ),
            'object_url'   => esc_url_raw( $row['object_url'] ?? '' ),
            'page_url'     => esc_url_raw( $row['page_url'] ?? '' ),
            'referrer_domain' => sanitize_text_field( $row['referrer_domain'] ?? '' ),
            'source'       => sanitize_text_field( $row['source'] ?? '' ),
            'medium'       => sanitize_text_field( $row['medium'] ?? '' ),
            'campaign'     => sanitize_text_field( $row['campaign'] ?? '' ),
            'device_type'  => sanitize_text_field( $row['device_type'] ?? '' ),
            'browser'      => sanitize_text_field( $row['browser'] ?? '' ),
            'os'           => sanitize_text_field( $row['os'] ?? '' ),
            'viewed_at'    => sanitize_text_field( $row['viewed_at'] ?? '' ),
        ];
    }
}
