<?php

/**
 * Resolves the current WordPress request into an analytics target.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPHAVE_Analytics_Target_Resolver {

    /**
     * Resolve current request.
     *
     * @return ?array Resolve current request.
     */

    public function resolve_current_request(): ?array {
        if ( is_front_page() || is_home() ) {
            return [
                'post_id'        => absint( get_option( 'page_on_front' ) ),
                'object_type'    => 'home',
                'object_id'      => absint( get_option( 'page_on_front' ) ),
                'object_subtype' => is_front_page() ? 'front_page' : 'posts_page',
                'object_label'   => get_bloginfo( 'name' ),
                'object_url'     => home_url( '/' ),
            ];
        }

        if ( is_singular() ) {
            return $this->resolve_post( get_queried_object_id() );
        }

        if ( is_post_type_archive() ) {
            return $this->resolve_post_type_archive();
        }

        if ( is_category() || is_tag() || is_tax() ) {
            return $this->resolve_taxonomy_archive();
        }

        if ( is_search() ) {
            $search_query = get_search_query( false );

            return [
                'post_id'        => 0,
                'object_type'    => 'search',
                'object_id'      => WPHAVE_Analytics_Dimensions::stable_id( $search_query ),
                'object_subtype' => 'search',
                'object_label'   => $search_query ? sprintf( /* translators: %s: contextual value. */
                __( 'Search: %s', 'wphave' ), $search_query ) : __( 'Search results', 'wphave' ),
                'object_url'     => get_search_link( $search_query ),
            ];
        }

        if ( is_author() ) {
            return $this->resolve_author_archive();
        }

        if ( is_date() ) {
            return [
                'post_id'        => 0,
                'object_type'    => 'date_archive',
                'object_id'      => WPHAVE_Analytics_Dimensions::stable_id( $this->get_current_url() ),
                'object_subtype' => is_day() ? 'day' : ( is_month() ? 'month' : 'year' ),
                'object_label'   => get_the_archive_title(),
                'object_url'     => $this->get_current_url(),
            ];
        }

        if ( is_404() ) {
            return [
                'post_id'        => 0,
                'object_type'    => 'error',
                'object_id'      => WPHAVE_Analytics_Dimensions::stable_id( $this->get_current_url() ),
                'object_subtype' => '404',
                'object_label'   => __( '404 Not Found', 'wphave' ),
                'object_url'     => $this->get_current_url(),
            ];
        }

        return null;
    }

    /**
     * Resolve post.
     *
     * @param int $post_id Post ID.
     * @return ?array Resolve post.
     */

    private function resolve_post( int $post_id ): ?array {
        if ( ! $post_id || get_post_status( $post_id ) !== 'publish' ) {
            return null;
        }

        return [
            'post_id'        => (int) $post_id,
            'object_type'    => 'post',
            'object_id'      => (int) $post_id,
            'object_subtype' => get_post_type( $post_id ) ?: 'post',
            'object_label'   => get_the_title( $post_id ),
            'object_url'     => get_permalink( $post_id ),
        ];
    }

    /**
     * Resolve post type archive.
     *
     * @return array Resolve post type archive.
     */

    private function resolve_post_type_archive(): array {
        $post_type = get_query_var( 'post_type' );
        $post_type = is_array( $post_type ) ? reset( $post_type ) : $post_type;
        $post_type = sanitize_key( $post_type ?: 'post' );
        $post_type_object = get_post_type_object( $post_type );
        $archive_link = get_post_type_archive_link( $post_type );

        return [
            'post_id'        => 0,
            'object_type'    => 'post_type_archive',
            'object_id'      => 0,
            'object_subtype' => $post_type,
            'object_label'   => $post_type_object->labels->name ?? post_type_archive_title( '', false ),
            'object_url'     => $archive_link ?: '',
        ];
    }

    /**
     * Resolve taxonomy archive.
     *
     * @return ?array Resolve taxonomy archive.
     */

    private function resolve_taxonomy_archive(): ?array {
        $term = get_queried_object();

        if ( ! $term || empty( $term->term_id ) ) {
            return null;
        }

        $term_link = get_term_link( $term );

        return [
            'post_id'        => 0,
            'object_type'    => 'taxonomy_archive',
            'object_id'      => (int) $term->term_id,
            'object_subtype' => sanitize_key( $term->taxonomy ?? '' ),
            'object_label'   => $term->name ?? '',
            'object_url'     => is_wp_error( $term_link ) ? '' : $term_link,
        ];
    }

    /**
     * Resolve author archive.
     *
     * @return array Resolve author archive.
     */

    private function resolve_author_archive(): array {
        $author = get_queried_object();
        $author_id = absint( $author->ID ?? 0 );

        return [
            'post_id'        => 0,
            'object_type'    => 'author_archive',
            'object_id'      => $author_id,
            'object_subtype' => 'author',
            'object_label'   => $author_id ? get_the_author_meta( 'display_name', $author_id ) : __( 'Author archive', 'wphave' ),
            'object_url'     => $author_id ? get_author_posts_url( $author_id ) : '',
        ];
    }

    /**
     * Return current url.
     *
     * @return string Return current url.
     */

    private function get_current_url(): string {
        $request = $GLOBALS['wp']->request ?? '';

        return home_url( '/' . ltrim( $request, '/' ) );
    }

}
