<?php

/**
 * Write-side database operations for WPHAVE analytics.
 */

if (!defined('ABSPATH')) {
	exit();
}

class WPHAVE_Analytics_Repository {
	private string $events_table;
	private string $daily_table;
	private WPHAVE_Analytics_Schema $schema;

	/**
	 * Initialize the repository service.
	 *
	 * @param string $events_table Events table.
	 * @param string $daily_table Daily table.
	 * @param WPHAVE_Analytics_Schema $schema Schema.
	 */

	public function __construct(
		string $events_table,
		string $daily_table,
		WPHAVE_Analytics_Schema $schema,
	) {
		$this->events_table = $events_table;
		$this->daily_table = $daily_table;
		$this->schema = $schema;
	}

	/**
	 * Insert event.
	 *
	 * @param array $data Data.
	 * @return bool Insert event.
	 */

	public function insert_event(array $data): bool {
		return (bool) $this->insert_event_id($data);
	}

	/**
	 * Insert event ID.
	 *
	 * @param array $data Data.
	 * @return int Insert event ID.
	 */

	public function insert_event_id(array $data): int {
		if (!$this->schema->table_exists($this->events_table)) {
			return 0;
		}

		global $wpdb;

		$previous_suppress_errors = $wpdb->suppress_errors();
		$inserted = $wpdb->insert($this->events_table, $data, [
			'%d',
			'%s',
			'%d',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%d',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%d',
			'%d',
		]);
		$last_error = $wpdb->last_error;
		$wpdb->suppress_errors($previous_suppress_errors);

		if (
			false === $inserted &&
			$last_error &&
			str_contains(strtolower($last_error), 'duplicate')
		) {
			return 0;
		}

		return $inserted ? (int) $wpdb->insert_id : 0;
	}

	/**
	 * Aggregate daily.
	 *
	 * @return bool Whether every aggregate row was persisted.
	 */

	public function aggregate_daily(): bool {
		// DATA INTEGRITY INVARIANT: The aggregation watermark advances only after all
		// required daily rows and derived post counters are persisted successfully.
		// A partial batch remains retryable and must not masquerade as complete.
		if (
			!$this->schema->table_exists($this->events_table) ||
			!$this->schema->table_exists($this->daily_table)
		) {
			return false;
		}

		global $wpdb;
		$site_timestamp = current_time('timestamp');
		$raw_boundary_timestamp =
			$site_timestamp - WPHAVE_Analytics_Retention_Policy::raw_days() * DAY_IN_SECONDS;
		$last_aggregation = get_option('wphave_analytics_last_aggregation', '');
		$last_aggregation_timestamp = is_string($last_aggregation)
			? strtotime($last_aggregation)
			: false;
		$aggregate_since_timestamp =
			false !== $last_aggregation_timestamp
				? max(
					$raw_boundary_timestamp,
					min($last_aggregation_timestamp, $site_timestamp) - DAY_IN_SECONDS,
				)
				: $raw_boundary_timestamp;
		$aggregate_since = date('Y-m-d H:i:s', $aggregate_since_timestamp);

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"
            SELECT
                MAX(post_id) AS post_id,
                MAX(COALESCE(object_type, 'post')) AS object_type,
                MAX(COALESCE(object_id, post_id)) AS object_id,
                MAX(COALESCE(object_subtype, '')) AS object_subtype,
                object_key,
                MAX(COALESCE(object_label, '')) AS object_label,
                MAX(COALESCE(object_url, '')) AS object_url,
                DATE(viewed_at) AS view_date,
				COUNT(*) AS views,
				COUNT(DISTINCT visitor_id) AS unique_visitors,
				COUNT(DISTINCT session_id) AS sessions,
                COALESCE(source, '') AS source,
                COALESCE(medium, '') AS medium,
                COALESCE(campaign, '') AS campaign,
                COALESCE(referrer_domain, '') AS referrer_domain,
                COALESCE(device_type, '') AS device_type,
                COALESCE(browser, '') AS browser,
                COALESCE(os, '') AS os
            FROM {$this->events_table}
			WHERE viewed_at >= %s
				AND event_type = 'pageview'
            GROUP BY
                object_key,
                DATE(viewed_at),
                source,
                medium,
                campaign,
                referrer_domain,
                device_type,
                browser,
                os
            ",
				$aggregate_since,
			),
		);

		if (null === $rows) {
			return false;
		}

		foreach ($rows as $row) {
			$dimension_hash = WPHAVE_Analytics_Dimensions::dimension_hash([
				'object_key' => $row->object_key,
				'view_date' => $row->view_date,
				'source' => $row->source,
				'medium' => $row->medium,
				'campaign' => $row->campaign,
				'referrer_domain' => $row->referrer_domain,
				'device_type' => $row->device_type,
				'browser' => $row->browser,
				'os' => $row->os,
			]);

			$persisted = $wpdb->query(
				$wpdb->prepare(
					"
                    INSERT INTO {$this->daily_table}
                        (
                            post_id,
                            object_type,
                            object_id,
                            object_subtype,
                            object_key,
                            object_label,
                            object_url,
                            view_date,
                            dimension_hash,
                            views,
                            unique_visitors,
                            sessions,
                            source,
                            medium,
                            campaign,
                            referrer_domain,
                            device_type,
                            browser,
                            os
                        )
                    VALUES
                        (%d, %s, %d, %s, %s, %s, %s, %s, %s, %d, %d, %d, %s, %s, %s, %s, %s, %s, %s)
                    ON DUPLICATE KEY UPDATE
                        views = VALUES(views),
                        unique_visitors = VALUES(unique_visitors),
                        sessions = VALUES(sessions),
                        object_label = VALUES(object_label),
                        object_url = VALUES(object_url)
                    ",
					$row->post_id,
					$row->object_type,
					$row->object_id,
					$row->object_subtype,
					$row->object_key,
					$row->object_label,
					$row->object_url,
					$row->view_date,
					$dimension_hash,
					$row->views,
					$row->unique_visitors,
					$row->sessions,
					$row->source,
					$row->medium,
					$row->campaign,
					$row->referrer_domain,
					$row->device_type,
					$row->browser,
					$row->os,
				),
			);

			if (false === $persisted) {
				return false;
			}
		}

		$this->sync_post_view_meta();
		update_option('wphave_analytics_last_aggregation', current_time('mysql'), false);

		return true;
	}

	/**
	 * Increments a daily pageview bucket that contains no visitor-level data.
	 *
	 * The anonymous source/medium dimension keeps this bucket separate from the
	 * hourly aggregation of consented raw events, which otherwise replaces rows
	 * with an identical dimension hash.
	 *
	 * @param array $data Published post context.
	 * @return bool Whether the bucket was written.
	 */

	public function increment_anonymous_pageview(array $data): bool {
		global $wpdb;

		$privacy_daily_table = $wpdb->prefix . WPHAVE_Analytics::PRIVACY_DAILY_TABLE;

		if (
			!$this->schema->table_exists($this->daily_table) ||
			!$this->schema->table_exists($privacy_daily_table)
		) {
			return false;
		}

		$view_date = current_time('Y-m-d');
		$source = 'anonymous';
		$medium = 'aggregate';
		$dimension_hash = WPHAVE_Analytics_Dimensions::dimension_hash([
			'object_key' => sanitize_text_field($data['object_key'] ?? ''),
			'view_date' => $view_date,
			'source' => $source,
			'medium' => $medium,
		]);

		$wpdb->query('START TRANSACTION');

		$base_inserted =
			false !==
			$wpdb->query(
				$wpdb->prepare(
					"INSERT INTO {$this->daily_table}
					(post_id, object_type, object_id, object_subtype, object_key, object_label, object_url, view_date, dimension_hash, views, unique_visitors, sessions, source, medium, campaign, referrer_domain, device_type, browser, os)
					VALUES (%d, %s, %d, %s, %s, %s, %s, %s, %s, 1, 0, 0, %s, %s, '', '', '', '', '')
					ON DUPLICATE KEY UPDATE views = views + 1",
					absint($data['post_id'] ?? 0),
					sanitize_key($data['object_type'] ?? 'post'),
					absint($data['object_id'] ?? 0),
					sanitize_key($data['object_subtype'] ?? ''),
					sanitize_text_field($data['object_key'] ?? ''),
					sanitize_text_field($data['object_label'] ?? ''),
					esc_url_raw($data['object_url'] ?? ''),
					$view_date,
					$dimension_hash,
					$source,
					$medium,
				),
			);

		if (!$base_inserted) {
			$wpdb->query('ROLLBACK');

			return false;
		}

		foreach (
			(array) ($data['privacy_dimensions'] ?? [])
			as $dimension_type => $dimension_value
		) {
			$dimension_type = sanitize_key($dimension_type);
			$dimension_value = sanitize_text_field($dimension_value);

			if (!$dimension_type || !$dimension_value || 'unknown' === $dimension_value) {
				continue;
			}

			$privacy_hash = hash(
				'sha256',
				implode('|', [
					$data['object_key'] ?? '',
					$view_date,
					$dimension_type,
					$dimension_value,
				]),
			);

			$dimension_inserted =
				false !==
				$wpdb->query(
					$wpdb->prepare(
						"INSERT INTO {$privacy_daily_table}
						(post_id, object_type, object_id, object_subtype, object_key, view_date, dimension_type, dimension_value, dimension_hash, views)
						VALUES (%d, %s, %d, %s, %s, %s, %s, %s, %s, 1)
						ON DUPLICATE KEY UPDATE views = views + 1",
						absint($data['post_id'] ?? 0),
						sanitize_key($data['object_type'] ?? 'post'),
						absint($data['object_id'] ?? 0),
						sanitize_key($data['object_subtype'] ?? ''),
						sanitize_text_field($data['object_key'] ?? ''),
						$view_date,
						$dimension_type,
						$dimension_value,
						$privacy_hash,
					),
				);

			if (!$dimension_inserted) {
				$wpdb->query('ROLLBACK');

				return false;
			}
		}

		$wpdb->query('COMMIT');

		return true;
	}

	/**
	 * Increment independent, low-entropy daily dimensions for a pageview.
	 *
	 * This deliberately does not accept visitor or session identifiers. Each
	 * dimension is written to its own row and cannot be joined to another
	 * dimension through a shared event key.
	 *
	 * @param array $context Trusted WordPress object context.
	 * @param array $dimensions Dimension name/value pairs.
	 * @return bool Whether all counters were written.
	 */
	public function increment_privacy_dimensions(array $context, array $dimensions): bool {
		global $wpdb;

		$privacy_daily_table = $wpdb->prefix . WPHAVE_Analytics::PRIVACY_DAILY_TABLE;

		if (!$this->schema->table_exists($privacy_daily_table)) {
			return false;
		}

		$view_date = current_time('Y-m-d');

		foreach ($dimensions as $dimension_type => $dimension_value) {
			$dimension_type = sanitize_key($dimension_type);
			$dimension_value = sanitize_text_field($dimension_value);

			if (!$dimension_type || !$dimension_value || 'unknown' === $dimension_value) {
				continue;
			}

			$dimension_hash = hash(
				'sha256',
				implode('|', [
					$context['object_key'] ?? '',
					$view_date,
					$dimension_type,
					$dimension_value,
				]),
			);

			$inserted =
				false !==
				$wpdb->query(
					$wpdb->prepare(
						"INSERT INTO {$privacy_daily_table}
						(post_id, object_type, object_id, object_subtype, object_key, view_date, dimension_type, dimension_value, dimension_hash, views)
						VALUES (%d, %s, %d, %s, %s, %s, %s, %s, %s, 1)
						ON DUPLICATE KEY UPDATE views = views + 1",
						absint($context['post_id'] ?? 0),
						sanitize_key($context['object_type'] ?? 'post'),
						absint($context['object_id'] ?? 0),
						sanitize_key($context['object_subtype'] ?? ''),
						sanitize_text_field($context['object_key'] ?? ''),
						$view_date,
						$dimension_type,
						$dimension_value,
						$dimension_hash,
					),
				);

			if (!$inserted) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Cleanup events.
	 *
	 * @return void
	 */

	public function cleanup_events(): array {
		global $wpdb;
		$policy = WPHAVE_Analytics_Retention_Policy::get();
		$site_timestamp = current_time('timestamp');
		$raw_threshold = date(
			'Y-m-d H:i:s',
			$site_timestamp - $policy['raw_days'] * DAY_IN_SECONDS,
		);
		$daily_threshold = WPHAVE_Analytics_Retention_Policy::aggregate_boundary_date();
		$deleted = [
			'events' => 0,
			'daily' => 0,
			'privacy_daily' => 0,
			'failed' => false,
		];

		if ($this->schema->table_exists($this->events_table)) {
			$result = $wpdb->query(
				$wpdb->prepare(
					"DELETE FROM {$this->events_table} WHERE viewed_at < %s ORDER BY id ASC LIMIT 5000",
					$raw_threshold,
				),
			);
			$deleted['failed'] = false === $result;
			$deleted['events'] = max(0, (int) $result);
		}

		if ($this->schema->table_exists($this->daily_table)) {
			$result = $wpdb->query(
				$wpdb->prepare(
					"DELETE FROM {$this->daily_table} WHERE view_date < %s ORDER BY id ASC LIMIT 5000",
					$daily_threshold,
				),
			);
			$deleted['failed'] = $deleted['failed'] || false === $result;
			$deleted['daily'] = max(0, (int) $result);
		}

		$privacy_daily_table = $wpdb->prefix . WPHAVE_Analytics::PRIVACY_DAILY_TABLE;

		if ($this->schema->table_exists($privacy_daily_table)) {
			$result = $wpdb->query(
				$wpdb->prepare(
					"DELETE FROM {$privacy_daily_table} WHERE view_date < %s ORDER BY id ASC LIMIT 5000",
					$daily_threshold,
				),
			);
			$deleted['failed'] = $deleted['failed'] || false === $result;
			$deleted['privacy_daily'] = max(0, (int) $result);
		}

		$link_result = $this->clear_orphaned_conversion_links();
		$deleted['audience_links'] = max(0, (int) $link_result);
		$deleted['failed'] = $deleted['failed'] || false === $link_result;

		return $deleted;
	}

	/** Detach bounded orphan references without deleting independently retained Audience data. */
	private function clear_orphaned_conversion_links(): int|false {
		global $wpdb;
		$interactions_table = $wpdb->prefix . 'wphave_audience_interactions';
		// Missing Analytics storage is not proof that every Audience reference is orphaned.
		if (
			!$this->schema->table_exists($this->events_table) ||
			!$this->schema->table_exists($interactions_table)
		) {
			return 0;
		}
		$ids = $wpdb->get_col(
			"SELECT i.id FROM {$interactions_table} i
			LEFT JOIN {$this->events_table} e ON e.id = i.conversion_event_id
			WHERE i.conversion_event_id > 0 AND e.id IS NULL
			ORDER BY i.id ASC LIMIT 5000",
		);
		// get_col() may return [] on failure: never report a failed read as successful cleanup.
		if ($wpdb->last_error) {
			return false;
		}
		if (!$ids) {
			return 0;
		}
		$placeholders = implode(', ', array_fill(0, count($ids), '%d'));
		// REFERENCE INVARIANT: Recheck the current link during the write. A concurrent
		// form attribution may have replaced the stale link with a valid event.
		return $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$interactions_table} SET conversion_event_id = 0
			WHERE id IN ({$placeholders}) AND conversion_event_id > 0
			AND NOT EXISTS (SELECT 1 FROM {$this->events_table} e WHERE e.id = {$interactions_table}.conversion_event_id)",
				...array_map('intval', $ids),
			),
		);
	}

	/**
	 * Sync post view meta.
	 *
	 * @return void
	 */

	private function sync_post_view_meta(): void {
		if (!$this->schema->table_exists($this->daily_table)) {
			return;
		}

		global $wpdb;
		$recent_threshold = current_datetime()->modify('-30 days')->format('Y-m-d');

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"
                SELECT
                    post_id,
                    SUM(views) AS lifetime,
                    SUM(
                        CASE
                            WHEN view_date >= %s THEN views
                            ELSE 0
                        END
                    ) AS recent
                FROM {$this->daily_table}
                WHERE object_type = 'post'
                GROUP BY post_id
                ",
				$recent_threshold,
			),
		);

		foreach ($rows as $row) {
			$post_id = absint($row->post_id);

			if (!$post_id || !get_post($post_id)) {
				continue;
			}

			update_post_meta($post_id, 'wphave_views_recent', (int) ($row->recent ?? 0));
			update_post_meta($post_id, 'wphave_views_lifetime', (int) ($row->lifetime ?? 0));
		}
	}
}
