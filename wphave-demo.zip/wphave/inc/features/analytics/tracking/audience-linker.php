<?php

/**
 * Links analytics events to audience leads.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPHAVE_Analytics_Audience_Linker {

    private const FORM_LINK_CONTEXT = 'wphave_analytics_form_link_v3';

    private WPHAVE_Analytics_Schema $schema;

    /**
     * Initialize the audience linker service.
     *
     * @param WPHAVE_Analytics_Schema $schema Schema.
     */

    public function __construct( WPHAVE_Analytics_Schema $schema ) {
        $this->schema = $schema;
    }

    /**
     * Create a proof that binds a completed form conversion to its stored identity.
     *
     * The proof is returned only with the successful submission response and
     * lets the browser fallback finish attribution without trusting a bare lead
     * identifier on the public analytics endpoint.
     *
     * @param int    $lead_id Lead ID.
     * @param string $client_event_id Client-generated form event UUID.
     * @param string $form_id Validated form identity.
     * @param int    $form_post_id Validated form source post ID.
     * @param string $goal_id Stored conversion goal ID.
     * @param string $visitor_id Visitor ID submitted with the completed form.
     * @param string $session_id Session ID submitted with the completed form.
     * @return string HMAC proof, or an empty string for incomplete input.
     */
	public static function create_form_link_proof(
		int $lead_id,
		string $client_event_id,
		string $form_id,
		int $form_post_id,
		string $goal_id,
		string $visitor_id,
		string $session_id,
	): string {
		$client_event_id = sanitize_text_field($client_event_id);

		if (
			!$lead_id ||
			!$client_event_id ||
			!$form_id ||
			!$form_post_id ||
			!$visitor_id ||
			!$session_id
		) {
			return '';
		}

		// FALLBACK IDENTITY INVARIANT: Public tracking supplies form, source,
		// goal and visitor/session identifiers. Authenticate their exact values
		// from the completed submission so a proof cannot be reassigned to
		// another conversion or browser identity.
		return hash_hmac(
			'sha256',
			wp_json_encode([
				$lead_id,
				$client_event_id,
				$form_id,
				$form_post_id,
				$goal_id,
				$visitor_id,
				$session_id,
			]),
			wp_salt(self::FORM_LINK_CONTEXT),
		);
	}

    /**
     * Verify a form fallback attribution proof in constant time.
     *
     * @param int    $lead_id Lead ID.
     * @param string $client_event_id Client-generated form event UUID.
     * @param string $form_id Claimed form identity.
     * @param int    $form_post_id Claimed form source post ID.
     * @param string $goal_id Claimed conversion goal ID.
     * @param string $visitor_id Claimed visitor ID.
     * @param string $session_id Claimed session ID.
     * @param string $proof Submitted HMAC proof.
     * @return bool Whether the proof is valid.
     */
	public static function verify_form_link_proof(
		int $lead_id,
		string $client_event_id,
		string $form_id,
		int $form_post_id,
		string $goal_id,
		string $visitor_id,
		string $session_id,
		string $proof,
	): bool {
		$expected = self::create_form_link_proof(
			$lead_id,
			$client_event_id,
			$form_id,
			$form_post_id,
			$goal_id,
			$visitor_id,
			$session_id,
		);

		// SECURITY INVARIANT: Fallback attribution may join only the exact lead and
		// form conversion tuple authenticated with the installation salt; caller-
		// supplied identifiers alone never authorize cross-record linkage.
		return $expected !== '' && $proof !== '' && hash_equals($expected, $proof);
	}

    /**
     * Link lead to event.
     *
     * @param int $lead_id Lead ID.
     * @param int $event_id Event ID.
     * @return void
     */

    public function link_lead_to_event( int $lead_id, int $event_id ): void {
        if ( ! $lead_id || ! $event_id ) {
            return;
        }

        global $wpdb;

        $leads_table = $wpdb->prefix . 'wphave_audience_leads';
        $interactions_table = $wpdb->prefix . 'wphave_audience_interactions';

        if ( ! $this->schema->table_exists( $leads_table ) || ! $this->schema->table_exists( $interactions_table ) ) {
            return;
        }

        $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$interactions_table} i INNER JOIN {$leads_table} l ON l.origin_interaction_id = i.id SET i.conversion_event_id = %d WHERE l.id = %d",
                $event_id,
                $lead_id
            )
        );
    }
}
