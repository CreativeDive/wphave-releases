<?php

/**
 * Central analytics event type definitions.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPHAVE_Analytics_Event_Types {

    const TRACKABLE = [
        'pageview',
        'engagement',
        'download',
        'outbound',
        'click',
        'form_start',
        'form_submit',
        'form_error',
        'subscribe',
        'register',
        'login',
        'search',
        'scroll',
        'time_on_page',
        'play',
        'custom_event',
    ];

    const CONVERSION = [
        'form_submit',
        'download',
        'outbound',
        'click',
        'pageview',
        'subscribe',
        'register',
        'login',
        'search',
        'scroll',
        'time_on_page',
        'play',
        'custom_event',
    ];

    const DEDUPED = [
        'download',
        'outbound',
        'click',
        'form_submit',
        'form_error',
        'subscribe',
        'register',
        'login',
        'search',
        'scroll',
        'time_on_page',
        'play',
        'custom_event',
    ];

    const OBJECT_TYPES = [
        'post',
        'home',
        'post_type_archive',
        'taxonomy_archive',
        'search',
        'author_archive',
        'date_archive',
        'error',
        '404',
        'download',
        'outbound',
        'form',
        'click',
        'media',
        'scroll',
        'time',
        'custom',
        'subscribe',
        'register',
        'login',
    ];
}
