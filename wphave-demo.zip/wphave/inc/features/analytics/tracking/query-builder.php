<?php

/**
 * Shared analytics SQL filter builder.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPHAVE_Analytics_Query_Builder {

    /**
     * Build daily filters.
     *
     * @param WP_REST_Request $request REST request.
     * @param array $params Params.
     * @param ?array $range Range.
     * @return string Build daily filters.
     */

    public function build_daily_filters( WP_REST_Request $request, array &$params, ?array $range = null ): string {
        $where = 'WHERE 1=1';
        $range = $range ?: $this->get_date_range( $request );

        $where .= ' AND view_date BETWEEN %s AND %s';
        $params[] = $range['from'];
        $params[] = $range['to'];

        $where .= $this->build_target_filters( $request, $params );
        $where .= $this->build_dimension_filters( $request, $params );

        return $where;
    }

    /**
     * Build event filters.
     *
     * @param WP_REST_Request $request REST request.
     * @param array $params Params.
     * @param string $alias Alias.
     * @param ?array $range Range.
     * @return string Build event filters.
     */

    public function build_event_filters( WP_REST_Request $request, array &$params, string $alias = '', ?array $range = null ): string {
        $prefix = $alias ? "{$alias}." : '';
        $where = 'WHERE 1=1';
        $range = $this->clamp_event_range(
			$range ?: $this->get_date_range( $request )
		);

        $where .= " AND {$prefix}viewed_at BETWEEN %s AND %s";
        $params[] = $range['from'] . ' 00:00:00';
        $params[] = $range['to'] . ' 23:59:59';

        $where .= $this->build_target_filters( $request, $params, $prefix );
        $where .= $this->build_dimension_filters( $request, $params, $prefix );
		$where .= WPHAVE_Analytics_Preview_Guard::get_event_exclusion_sql( $alias );

        return $where;
    }

	/**
	 * Build filters for independent privacy-first dimension counters.
	 *
	 * Attribution filters cannot be applied because those dimensions are never
	 * combined with the anonymous technology counters.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @param array $params Query parameters.
	 * @return string Privacy-dimension filters.
	 */
	public function build_privacy_dimension_filters( WP_REST_Request $request, array &$params ): string {
		$range = $this->get_date_range( $request );
		$where = 'WHERE view_date BETWEEN %s AND %s';
		$params[] = $range['from'];
		$params[] = $range['to'];
		$where .= $this->build_target_filters( $request, $params );

		$source   = sanitize_text_field( $request->get_param( 'source' ) ?? '' );
		$campaign = sanitize_text_field( $request->get_param( 'campaign' ) ?? '' );
		$referrer = sanitize_text_field( $request->get_param( 'referrer' ) ?? '' );
		$device   = sanitize_text_field( $request->get_param( 'device' ) ?? '' );
		$channel  = sanitize_key( $request->get_param( 'channel' ) ?: $request->get_param( 'segment' ) );

		if ( ( $source && 'anonymous' !== $source ) || $campaign || $referrer || $device || $channel ) {
			$where .= ' AND 1=0';
		}

		return $where;
	}

    /**
     * Return date range.
     *
     * @param WP_REST_Request $request REST request.
     * @return array Return date range.
     */

    public function get_date_range( WP_REST_Request $request ): array {
		$has_extended_access = (bool) apply_filters(
			'wphave_analytics_has_extended_report_access',
			function_exists( 'wphave_has_pro_access' ) && wphave_has_pro_access()
		);
		$from = $has_extended_access
			? sanitize_text_field( $request->get_param( 'from' ) ?? '' )
			: '';
		$to = $has_extended_access
			? sanitize_text_field( $request->get_param( 'to' ) ?? '' )
			: '';

        if ( $from && $to ) {
            $from_ts = strtotime( $from );
            $to_ts = strtotime( $to );

            if ( $from_ts && $to_ts ) {
                if ( $from_ts > $to_ts ) {
                    [ $from_ts, $to_ts ] = [ $to_ts, $from_ts ];
                }

				$to_ts = min( $to_ts, current_time( 'timestamp' ) );

				$maximum_days = WPHAVE_Analytics_Retention_Policy::maximum_report_days();
				$days = (int) ceil( ( $to_ts - $from_ts ) / DAY_IN_SECONDS ) + 1;

				if ( $days > $maximum_days ) {
					$days = $maximum_days;
					$from_ts = strtotime( '-' . ( $days - 1 ) . ' days', $to_ts );
				}

				$earliest_ts = $this->get_aggregate_earliest_timestamp();
				$from_ts = max( $from_ts, $earliest_ts );

				if ( $from_ts > $to_ts ) {
					$from_ts = $to_ts;
				}

				$days = max(
					1,
					(int) ceil( ( $to_ts - $from_ts ) / DAY_IN_SECONDS ) + 1
				);

                return [
                    'from' => date( 'Y-m-d', $from_ts ),
                    'to'   => date( 'Y-m-d', $to_ts ),
                    'days' => $days,
                ];
            }
        }

		$maximum_days = $has_extended_access
			? WPHAVE_Analytics_Retention_Policy::maximum_report_days()
			: 7;
		$days = max(
			1,
			min(
				$maximum_days,
				absint( $request->get_param( 'days' ) ?: 30 )
			)
		);
		$to = current_time( 'timestamp' );
		$from = strtotime( '-' . ( $days - 1 ) . ' days', $to );
		$from = max( $from, $this->get_aggregate_earliest_timestamp() );
		$days = max(
			1,
			(int) ceil( ( $to - $from ) / DAY_IN_SECONDS ) + 1
		);

        return [
            'from' => date( 'Y-m-d', $from ),
            'to'   => date( 'Y-m-d', $to ),
            'days' => $days,
        ];
    }

	/** Return the requested range clamped to available raw event history. */

	public function get_event_date_range( WP_REST_Request $request ): array {
		return $this->clamp_event_range( $this->get_date_range( $request ) );
	}

	/** Clamp an explicit range to the rolling raw-event boundary. */

	private function clamp_event_range( array $range ): array {
		$to_ts = min(
			strtotime( $range['to'] ?? '' ) ?: current_time( 'timestamp' ),
			current_time( 'timestamp' )
		);
		$from_ts = strtotime( $range['from'] ?? '' ) ?: $to_ts;
		$earliest_ts = strtotime(
			'-' . WPHAVE_Analytics_Retention_Policy::raw_days() . ' days',
			current_time( 'timestamp' )
		);
		$from_ts = max( $from_ts, $earliest_ts );

		if ( $from_ts > $to_ts ) {
			$from_ts = $to_ts;
		}

		return [
			'from' => date( 'Y-m-d', $from_ts ),
			'to' => date( 'Y-m-d', $to_ts ),
			'days' => max(
				1,
				(int) ceil( ( $to_ts - $from_ts ) / DAY_IN_SECONDS ) + 1
			),
		];
	}

	/** Return the oldest calendar timestamp that aggregate reports may query. */

	private function get_aggregate_earliest_timestamp(): int {
		return strtotime(
			WPHAVE_Analytics_Retention_Policy::aggregate_boundary_date()
		);
	}

    /**
     * Build target filters.
     *
     * @param WP_REST_Request $request REST request.
     * @param array $params Params.
     * @param string $prefix Prefix.
     * @return string Build target filters.
     */

    private function build_target_filters( WP_REST_Request $request, array &$params, string $prefix = '' ): string {
        $where = '';
        $post_id = absint( $request->get_param( 'post_id' ) ?? 0 );

        if ( $post_id ) {
            $where .= " AND {$prefix}post_id = %d";
            $params[] = $post_id;
        }

        $object_type = sanitize_key( $request->get_param( 'object_type' ) ?? '' );
        if ( $object_type ) {
            $where .= " AND {$prefix}object_type = %s";
            $params[] = $object_type;
        }

        $object_id = $request->get_param( 'object_id' );
        if ( $object_id !== null && $object_id !== '' ) {
            $where .= " AND {$prefix}object_id = %d";
            $params[] = absint( $object_id );
        }

        $object_subtype = sanitize_key( $request->get_param( 'object_subtype' ) ?? '' );
        if ( $object_subtype ) {
            $where .= " AND {$prefix}object_subtype = %s";
            $params[] = $object_subtype;
        }

        return $where;
    }

    /**
     * Build dimension filters.
     *
     * @param WP_REST_Request $request REST request.
     * @param array $params Params.
     * @param string $prefix Prefix.
     * @return string Build dimension filters.
     */

    private function build_dimension_filters( WP_REST_Request $request, array &$params, string $prefix = '' ): string {
        $where = '';
        $source = sanitize_text_field( $request->get_param( 'source' ) ?? '' );

        if ( $source ) {
            $where .= " AND {$prefix}source = %s";
            $params[] = $source;
        }

        $campaign = sanitize_text_field( $request->get_param( 'campaign' ) ?? '' );
        if ( $campaign ) {
            $where .= " AND {$prefix}campaign = %s";
            $params[] = $campaign;
        }

        $device = sanitize_text_field( $request->get_param( 'device' ) ?? '' );
        if ( $device ) {
            $where .= " AND {$prefix}device_type = %s";
            $params[] = $device;
        }

        $referrer = sanitize_text_field( $request->get_param( 'referrer' ) ?? '' );
        if ( $referrer ) {
            $where .= " AND {$prefix}referrer_domain = %s";
            $params[] = $referrer;
        }

        $channel = sanitize_key( $request->get_param( 'channel' ) ?: $request->get_param( 'segment' ) );

        if ( $channel === 'organic' ) {
            $where .= " AND {$prefix}medium = 'organic'";
        } elseif ( $channel === 'social' ) {
            $where .= " AND {$prefix}medium = 'social'";
        } elseif ( $channel === 'direct' ) {
            $where .= " AND {$prefix}source = 'direct'";
        } elseif ( $channel === 'referral' ) {
            $where .= " AND {$prefix}medium = 'referral'";
        } elseif ( $channel === 'campaign' ) {
            $where .= " AND {$prefix}campaign != ''";
        }

        return $where;
    }
}
