<?php

/**
 * Classifies user agents into stable, privacy-preserving analytics dimensions.
 *
 * PRIVACY INVARIANT: The raw user agent never leaves this service. Reports consume only the
 * normalized categories returned here.
 */
class WPHAVE_Analytics_User_Agent_Classifier {

	/**
	 * Classify a user agent.
	 *
	 * @param string $user_agent Browser user agent.
	 * @return array{device_type: string, browser: string, browser_version: string, os: string, os_version: string}
	 */
	public function classify( string $user_agent ): array {
		$user_agent = strtolower( $user_agent );

		$browser = $this->classify_browser( $user_agent );
		$os      = $this->classify_os( $user_agent );

		return [
			'device_type' => $this->classify_device( $user_agent ),
			'browser'     => $browser,
			'browser_version' => $this->classify_browser_version( $user_agent, $browser ),
			'os'          => $os,
			'os_version'  => $this->classify_os_version( $user_agent, $os ),
		];
	}

	/**
	 * Return only a browser major version to avoid high-entropy build numbers.
	 */
	private function classify_browser_version( string $user_agent, string $browser ): string {
		$tokens = [
			'edge'             => 'edg(?:a|ios)?',
			'opera'            => 'opr',
			'samsung_internet' => 'samsungbrowser',
			'firefox'          => '(?:firefox|fxios)',
			'chrome'           => '(?:chrome|crios)',
			'safari'           => 'version',
		];

		if ( ! isset( $tokens[ $browser ] ) ) {
			return '';
		}

		return preg_match( '/' . $tokens[ $browser ] . '\/(\d+)/i', $user_agent, $matches )
			? $matches[1]
			: '';
	}

	/**
	 * Classify the device family.
	 */
	private function classify_device( string $user_agent ): string {
		if ( '' === $user_agent ) {
			return 'unknown';
		}

		if ( preg_match( '/ipad|tablet|kindle|silk\/|playbook|sm-t|nexus 7|nexus 9/i', $user_agent ) ) {
			return 'tablet';
		}

		if ( preg_match( '/mobile|iphone|ipod|android|iemobile|opera mini|opera mobi/i', $user_agent ) ) {
			return 'mobile';
		}

		return 'desktop';
	}

	/**
	 * Classify the browser family. More specific Chromium and iOS tokens must
	 * be checked before their generic Safari or Chrome fallbacks.
	 */
	private function classify_browser( string $user_agent ): string {
		$patterns = [
			'edge'             => '/edg(?:a|ios)?\//i',
			'opera'            => '/(?:opr|opera|opera mini|opera mobi)\//i',
			'samsung_internet' => '/samsungbrowser\//i',
			'firefox'          => '/(?:firefox|fxios)\//i',
			'chrome'           => '/(?:chrome|crios)\//i',
			'safari'           => '/safari\//i',
		];

		foreach ( $patterns as $browser => $pattern ) {
			if ( preg_match( $pattern, $user_agent ) ) {
				return $browser;
			}
		}

		return 'unknown';
	}

	/**
	 * Classify the operating-system family.
	 */
	private function classify_os( string $user_agent ): string {
		if ( preg_match( '/iphone|ipad|ipod/i', $user_agent ) ) {
			return 'ios';
		}

		if ( str_contains( $user_agent, 'android' ) ) {
			return 'android';
		}

		if ( preg_match( '/windows phone|windows mobile/i', $user_agent ) ) {
			return 'windows_phone';
		}

		if ( str_contains( $user_agent, 'windows' ) ) {
			return 'windows';
		}

		if ( preg_match( '/cros/i', $user_agent ) ) {
			return 'chromeos';
		}

		if ( preg_match( '/macintosh|mac os x/i', $user_agent ) ) {
			return 'macos';
		}

		if ( str_contains( $user_agent, 'linux' ) ) {
			return 'linux';
		}

		return 'unknown';
	}

	/**
	 * Return only an operating-system major version.
	 */
	private function classify_os_version( string $user_agent, string $os ): string {
		$patterns = [
			'ios'           => '/(?:iphone )?os (\d+)[_\s]/i',
			'android'       => '/android (\d+)/i',
			'windows_phone' => '/windows phone(?: os)? (\d+)/i',
			'windows'       => '/windows nt (\d+)/i',
			'chromeos'      => '/cros [^ )]+ (\d+)/i',
			'macos'         => '/mac os x (\d+)[_.]/i',
		];

		if ( ! isset( $patterns[ $os ] ) ) {
			return '';
		}

		return preg_match( $patterns[ $os ], $user_agent, $matches ) ? $matches[1] : '';
	}
}
