<?php

/**
 * Processes analytics events and derives request tracking dimensions.
 */

trait WPHAVE_Analytics_Tracking {
	public function track(WP_REST_Request $request) {
		if (!$this->is_enabled()) {
			return rest_ensure_response(['tracked' => false, 'reason' => 'disabled']);
		}

		if ($this->is_bot()) {
			return rest_ensure_response(['tracked' => false, 'reason' => 'bot']);
		}

		$rate_limit = $this->check_track_rate_limit();

		if (is_wp_error($rate_limit)) {
			return $rate_limit;
		}

		// AVAILABILITY INVARIANT: Every anonymous event has a fixed wire-size bound
		// before JSON fields can drive URL parsing, hashing or database persistence.
		// Rate limiting request count alone must never permit unbounded per-request work.
		if (strlen($request->get_body()) > self::TRACK_MAX_PAYLOAD_BYTES) {
			return rest_ensure_response([
				'tracked' => false,
				'reason' => 'payload_too_large',
			]);
		}

		$data = $request->get_json_params();

		if (!is_array($data)) {
			return rest_ensure_response(['tracked' => false, 'reason' => 'invalid_payload']);
		}

		// INPUT-SHAPE INVARIANT: Tracking fields are scalar browser signals.
		// Nested JSON must stop before Core URL/text sanitizers receive arrays
		// and throw from an unauthenticated request.
		foreach ($data as $value) {
			if (!is_scalar($value) && $value !== null) {
				return rest_ensure_response(['tracked' => false, 'reason' => 'invalid_payload']);
			}
		}

		if (WPHAVE_Analytics_Preview_Guard::is_tracking_payload($data)) {
			return rest_ensure_response(['tracked' => false, 'reason' => 'internal_preview']);
		}

		if (!wphave_privacy_can_process(WPHAVE_Privacy_Manager::PURPOSE_ANALYTICS_SESSIONS)) {
			return $this->track_anonymous_pageview($data);
		}

		if (!$this->table_exists($this->events_table)) {
			return rest_ensure_response(['tracked' => false, 'reason' => 'missing_table']);
		}

		if (is_user_logged_in() && !defined('WPHAVE_ANALYTICS_TRACK_LOGGED_IN')) {
			return rest_ensure_response(['tracked' => false, 'reason' => 'logged_in']);
		}

		$post_id = absint($data['post_id'] ?? 0);
		$object_type = sanitize_key($data['object_type'] ?? 'post');

		if (!in_array($object_type, WPHAVE_Analytics_Event_Types::OBJECT_TYPES, true)) {
			$object_type = 'post';
		}

		if ($object_type === 'post' && !$this->is_public_tracking_post($post_id)) {
			return rest_ensure_response(['tracked' => false, 'reason' => 'invalid_post']);
		}

		$object_id = absint($data['object_id'] ?? $post_id);
		$object_subtype = sanitize_key($data['object_subtype'] ?? '');
		$object_label = sanitize_text_field($data['object_label'] ?? '');
		$object_url = esc_url_raw($data['object_url'] ?? ($data['url'] ?? ''));
		$page_url = esc_url_raw($data['page_url'] ?? ($data['url'] ?? ''));
		$goal_id = sanitize_key($data['goal_id'] ?? '');
		$provided_object_key = sanitize_text_field($data['object_key'] ?? '');

		if ($object_type === 'post') {
			// ANALYTICS-IDENTITY INVARIANT: An anonymous pageview may report a
			// public post ID, but cannot author its report title, destination URL,
			// subtype or aggregation key. Derive all of them from that live post.
			$object_id = $post_id;
			$object_subtype = get_post_type($post_id);
			$object_label = sanitize_text_field(get_the_title($post_id));
			$object_url = esc_url_raw((string) get_permalink($post_id), ['http', 'https']);
			$provided_object_key = '';
		}

		if (in_array($object_type, ['download', 'outbound'], true) && !$object_id) {
			$object_id = WPHAVE_Analytics_Dimensions::stable_id($object_url ?: $object_label);
		}

		if ($object_type === 'form' && $provided_object_key) {
			$object_id = WPHAVE_Analytics_Dimensions::stable_id($provided_object_key);
		}

		$object_key =
			$provided_object_key ?:
			WPHAVE_Analytics_Dimensions::object_key($object_type, $object_id, $object_subtype);

		$event_type = sanitize_key($data['event_type'] ?? 'pageview');
		$event_type = in_array($event_type, WPHAVE_Analytics_Event_Types::TRACKABLE, true)
			? $event_type
			: 'pageview';
		$visitor_id = sanitize_text_field($data['visitor_id'] ?? '');
		$session_id = sanitize_text_field($data['session_id'] ?? '');

		if (!$visitor_id || !$session_id) {
			return rest_ensure_response(['tracked' => false, 'reason' => 'missing_ids']);
		}

		$referrer_url = esc_url_raw($data['referrer_url'] ?? '');
		$referrer_domain = $this->get_domain_from_url($referrer_url);

		$utm_source = sanitize_text_field($data['utm_source'] ?? '');
		$utm_medium = sanitize_text_field($data['utm_medium'] ?? '');
		$utm_campaign = sanitize_text_field($data['utm_campaign'] ?? '');
		$utm_content = sanitize_text_field($data['utm_content'] ?? '');
		$utm_term = sanitize_text_field($data['utm_term'] ?? '');

		$source_medium = $this->detect_source_medium($utm_source, $utm_medium, $referrer_domain);
		$device = $this->detect_device();
		$is_logged_in = is_user_logged_in();
		$user_id_hash = $is_logged_in
			? hash_hmac('sha256', (string) get_current_user_id(), wp_salt('auth'))
			: '';
		$lead_id = absint($data['lead_id'] ?? 0);
		$client_event_id = sanitize_text_field($data['event_id'] ?? '');
		$lead_link_proof = sanitize_text_field($data['lead_link_proof'] ?? '');
		$form_link_authorized =
			'form_submit' !== $event_type ||
			WPHAVE_Analytics_Audience_Linker::verify_form_link_proof(
				$lead_id,
				$client_event_id,
				$lead_link_proof,
			);

		if (!$form_link_authorized) {
			return rest_ensure_response([
				'tracked' => false,
				'reason' => 'invalid_form_proof',
			]);
		}

		$event_id = $this->insert_tracking_event([
			'post_id' => $post_id,
			'object_type' => $object_type,
			'object_id' => $object_id,
			'object_subtype' => $object_subtype,
			'object_key' => $object_key,
			'object_label' => $object_label,
			'object_url' => $object_url,
			'page_url' => $page_url,
			'event_type' => $event_type,
			'visitor_id' => $visitor_id,
			'session_id' => $session_id,
			'goal_id' => $goal_id,
			'client_event_id' => $client_event_id,
			'referrer_url' => $referrer_url,
			'referrer_domain' => $referrer_domain,
			'source' => $source_medium['source'],
			'medium' => $source_medium['medium'],
			'campaign' => $utm_campaign,
			'content' => $utm_content,
			'term' => $utm_term,
			'device_type' => $device['device_type'],
			'browser' => $device['browser'],
			'os' => $device['os'],
			'language' => sanitize_text_field($data['language'] ?? ''),
			'screen_width' => $this->normalize_viewport_dimension($data['screen_width'] ?? 0),
			'screen_height' => $this->normalize_viewport_dimension($data['screen_height'] ?? 0),
			'is_logged_in' => $is_logged_in,
			'user_id_hash' => $user_id_hash,
		]);

		if ($event_id && 'pageview' === $event_type) {
			$country = $this->country_resolver->resolve();

			$dimensions = array_filter([
				'country' => $country,
				'language' => $this->normalize_browser_locale($data['language'] ?? ''),
			]);
			$width = $this->normalize_viewport_dimension($data['screen_width'] ?? 0);
			if ($width > 0) {
				// Report grouping is derived from the consented measurement. Raw
				// events keep exact viewport values; anonymous requests never enter here.
				$dimensions['screen'] =
					$width < 768
						? 'small'
						: ($width < 1280
							? 'medium'
							: ($width < 1920
								? 'large'
								: 'extra_large'));
			}
			if ($dimensions) {
				$this->repository->increment_privacy_dimensions(
					[
						'post_id' => $post_id,
						'object_type' => $object_type,
						'object_id' => $object_id,
						'object_subtype' => $object_subtype,
						'object_key' => $object_key,
					],
					$dimensions,
				);
			}
		}

		if ($event_id && $event_type === 'form_submit' && $form_link_authorized) {
			$this->audience_linker->link_lead_to_event($lead_id, $event_id);
		}

		return rest_ensure_response([
			'tracked' => (bool) $event_id,
			'duplicate' => !$event_id,
		]);
	}

	/**
	 * Track form submission.
	 *
	 * @param mixed $tracked Tracked.
	 * @param mixed $submission Submission.
	 * @return bool Track form submission.
	 */

	public function track_form_submission($tracked, $submission): bool {
		return $this->track_form_result($tracked, $submission, 'form_submit');
	}

	/**
	 * Track a failed form attempt without persisting submitted field values.
	 *
	 * @param mixed $tracked Tracked.
	 * @param mixed $submission Submission context and safe error metadata.
	 * @return bool Whether the error event was stored.
	 */
	public function track_form_error($tracked, $submission): bool {
		return $this->track_form_result($tracked, $submission, 'form_error');
	}

	/**
	 * Persist one normalized Forms analytics result.
	 *
	 * @param mixed $tracked Existing tracked state.
	 * @param mixed $submission Normalized submission context.
	 * @param string $event_type Supported Forms event type.
	 * @return bool Whether the event was stored.
	 */
	private function track_form_result($tracked, $submission, string $event_type): bool {
		if ($tracked || !is_array($submission)) {
			return (bool) $tracked;
		}

		if (
			!$this->is_enabled() ||
			!wphave_privacy_can_process(WPHAVE_Privacy_Manager::PURPOSE_ANALYTICS_SESSIONS) ||
			!$this->table_exists($this->events_table) ||
			$this->is_bot()
		) {
			return false;
		}

		$context =
			isset($submission['context']) && is_array($submission['context'])
				? $submission['context']
				: [];
		$form_id = sanitize_text_field($context['form_id'] ?? ($submission['form_id'] ?? ''));
		$visitor_id = sanitize_text_field($context['visitor_id'] ?? '');
		$session_id = sanitize_text_field($context['session_id'] ?? '');

		if (!$form_id || !$visitor_id || !$session_id) {
			return false;
		}

		$form_post_id = absint($context['form_post_id'] ?? ($submission['form_post_id'] ?? 0));
		$source_post_id = absint(
			$context['source_post_id'] ?? ($submission['source_post_id'] ?? 0),
		);
		$post_id = $source_post_id ?: $form_post_id;
		$goal_id = sanitize_key($context['goal_id'] ?? '');
		$current_url = esc_url_raw($context['current_url'] ?? '');
		$referrer_url = esc_url_raw($context['referrer_url'] ?? '');
		$referrer_domain = $this->get_domain_from_url($referrer_url);
		$tracking =
			isset($context['tracking']) && is_array($context['tracking'])
				? $context['tracking']
				: [];
		$utm_source = sanitize_text_field($tracking['utm_source'] ?? ($context['source'] ?? ''));
		$utm_medium = sanitize_text_field($tracking['utm_medium'] ?? ($context['medium'] ?? ''));
		$utm_campaign = sanitize_text_field(
			$tracking['utm_campaign'] ?? ($context['campaign'] ?? ''),
		);
		$utm_content = sanitize_text_field($tracking['utm_content'] ?? '');
		$utm_term = sanitize_text_field($tracking['utm_term'] ?? '');
		$source_medium = $this->detect_source_medium($utm_source, $utm_medium, $referrer_domain);
		$device = $this->detect_device();
		$is_logged_in = is_user_logged_in();
		$user_id_hash = $is_logged_in
			? hash_hmac('sha256', (string) get_current_user_id(), wp_salt('auth'))
			: '';
		$object_key = $form_id;
		$object_url = $current_url ?: ($source_post_id ? get_permalink($source_post_id) : '');
		$object_label = $form_post_id ? get_the_title($form_post_id) : '';
		$object_label = $object_label ?: $form_id;
		$client_event_id = sanitize_text_field($context['form_event_id'] ?? '');
		$event_id = $this->insert_tracking_event([
			'post_id' => $post_id,
			'object_type' => 'form',
			'object_id' => WPHAVE_Analytics_Dimensions::stable_id($object_key),
			'object_subtype' => $form_post_id ? get_post_type($form_post_id) : 'wphave-forms',
			'object_key' => $object_key,
			'object_label' => $object_label,
			'object_url' => $object_url,
			'page_url' => $current_url,
			'event_type' => $event_type,
			'visitor_id' => $visitor_id,
			'session_id' => $session_id,
			'goal_id' => $goal_id,
			'client_event_id' => $client_event_id,
			'referrer_url' => $referrer_url,
			'referrer_domain' => $referrer_domain,
			'source' => $source_medium['source'],
			'medium' => $source_medium['medium'],
			'campaign' => $utm_campaign,
			'content' => $utm_content,
			'term' => $utm_term,
			'device_type' => $device['device_type'],
			'browser' => $device['browser'],
			'os' => $device['os'],
			'language' => sanitize_text_field($context['language'] ?? ''),
			'screen_width' => $this->normalize_viewport_dimension($context['screen_width'] ?? 0),
			'screen_height' => $this->normalize_viewport_dimension($context['screen_height'] ?? 0),
			'is_logged_in' => $is_logged_in,
			'user_id_hash' => $user_id_hash,
		]);

		if ($event_id && 'form_submit' === $event_type) {
			$this->audience_linker->link_lead_to_event(
				absint($submission['audience_lead_id'] ?? 0),
				$event_id,
			);
		}

		return (bool) $event_id;
	}
	/**
	 * Records one anonymous pageview in the daily aggregate table.
	 *
	 * The endpoint accepts only pageviews for public WordPress request targets.
	 * Search queries, error URLs, identifiers, campaign data and interaction
	 * behavior are never persisted in this mode.
	 *
	 * @param array $data Tracking payload.
	 * @return WP_REST_Response Tracking result.
	 */

	private function track_anonymous_pageview(array $data): WP_REST_Response {
		if (!wphave_privacy_can_process(WPHAVE_Privacy_Manager::PURPOSE_ANALYTICS_AGGREGATE)) {
			return rest_ensure_response(['tracked' => false, 'reason' => 'privacy_denied']);
		}

		if (!$this->table_exists($this->daily_table)) {
			return rest_ensure_response(['tracked' => false, 'reason' => 'missing_daily_table']);
		}

		$event_type = sanitize_key($data['event_type'] ?? 'pageview');

		if ('pageview' !== $event_type) {
			return rest_ensure_response([
				'tracked' => false,
				'reason' => 'aggregate_event_not_supported',
			]);
		}

		$context = $this->get_anonymous_object_context($data);

		if (!$context) {
			return rest_ensure_response([
				'tracked' => false,
				'reason' => 'invalid_aggregate_target',
			]);
		}

		$data['object_type'] = $context['object_type'];
		$context['privacy_dimensions'] = $this->get_anonymous_privacy_dimensions($data);
		$inserted = $this->repository->increment_anonymous_pageview($context);

		return rest_ensure_response([
			'tracked' => $inserted,
			'mode' => 'aggregate',
		]);
	}

	/**
	 * A published status alone does not make a post public: private post types and
	 * password-protected posts must never become anonymous report dimensions.
	 */
	private function is_public_tracking_post(int $post_id): bool {
		$post = $post_id > 0 ? get_post($post_id) : null;

		// TRACKING TARGET INVARIANT: Both tracking modes use the same public-object
		// boundary before accepting a post ID or deriving its title and permalink.
		return $post instanceof WP_Post &&
			'publish' === $post->post_status &&
			'' === $post->post_password &&
			is_post_publicly_viewable($post);
	}

	/**
	 * Resolve a public aggregate target from trusted WordPress objects.
	 *
	 * Search terms and requested 404 paths are deliberately collapsed into one
	 * site-wide bucket instead of accepting labels or URLs from the client.
	 *
	 * @param array $data Tracking payload.
	 * @return ?array<string, int|string> Anonymous object context.
	 */
	private function get_anonymous_object_context(array $data): ?array {
		$object_type = sanitize_key($data['object_type'] ?? 'post');
		$object_id = absint($data['object_id'] ?? ($data['post_id'] ?? 0));
		$object_subtype = sanitize_key($data['object_subtype'] ?? '');
		$post_id = absint($data['post_id'] ?? 0);
		$object_label = '';
		$object_url = '';

		switch ($object_type) {
			case 'post':
				if (!$this->is_public_tracking_post($post_id)) {
					return null;
				}

				$object_id = $post_id;
				$object_subtype = get_post_type($post_id) ?: 'post';
				$object_label = get_the_title($post_id);
				$object_url = get_permalink($post_id);
				break;

			case 'home':
				$object_id = absint(get_option('page_on_front'));
				$object_subtype = in_array($object_subtype, ['front_page', 'posts_page'], true)
					? $object_subtype
					: 'front_page';
				$object_label = get_bloginfo('name');
				$object_url = home_url('/');
				break;

			case 'post_type_archive':
				$post_type = post_type_exists($object_subtype) ? $object_subtype : 'post';
				$post_type_object = get_post_type_object($post_type);
				// AGGREGATE TARGET INVARIANT: Anonymous reports only describe archives
				// that a visitor can actually open; private type labels stay private.
				if (
					!$post_type_object ||
					!$post_type_object->publicly_queryable ||
					('post' !== $post_type && !$post_type_object->has_archive)
				) {
					return null;
				}
				$object_id = 0;
				$object_subtype = $post_type;
				$object_label = $post_type_object->labels->name ?? $post_type;
				$object_url = get_post_type_archive_link($post_type) ?: '';
				break;

			case 'taxonomy_archive':
				$term = $object_id ? get_term($object_id) : null;

				if (!$term || is_wp_error($term) || !is_taxonomy_viewable($term->taxonomy)) {
					return null;
				}

				$term_link = get_term_link($term);
				$object_subtype = sanitize_key($term->taxonomy);
				$object_label = $term->name;
				$object_url = is_wp_error($term_link) ? '' : $term_link;
				break;

			case 'author_archive':
				if (!$object_id || !get_user_by('id', $object_id)) {
					return null;
				}

				// AUTHOR REPORT INVARIANT: An arbitrary user ID is not a public
				// author. A public, unprotected publication must exist before an
				// anonymous request can persist that user's name and author URL.
				$public_types = get_post_types(['publicly_queryable' => true], 'names');
				if (!$public_types) {
					return null;
				}
				$author_posts = new WP_Query([
					'author' => $object_id,
					'post_type' => array_values($public_types),
					'post_status' => 'publish',
					'has_password' => false,
					'posts_per_page' => 1,
					'fields' => 'ids',
					'no_found_rows' => true,
					'ignore_sticky_posts' => true,
				]);
				if (!$author_posts->posts) {
					return null;
				}

				$object_subtype = 'author';
				$object_label = get_the_author_meta('display_name', $object_id);
				$object_url = get_author_posts_url($object_id);
				break;

			case 'date_archive':
				$object_id = 0;
				$object_subtype = in_array($object_subtype, ['day', 'month', 'year'], true)
					? $object_subtype
					: 'date';
				$object_label = __('Date archive', 'wphave');
				break;

			case 'search':
				$object_id = 0;
				$object_subtype = 'search';
				$object_label = __('Search results', 'wphave');
				break;

			case 'error':
			case '404':
				$object_type = 'error';
				$object_id = 0;
				$object_subtype = '404';
				$object_label = __('404 Not Found', 'wphave');
				break;

			default:
				return null;
		}

		return [
			'post_id' => 'post' === $object_type ? $post_id : 0,
			'object_type' => $object_type,
			'object_id' => $object_id,
			'object_subtype' => $object_subtype,
			'object_key' => WPHAVE_Analytics_Dimensions::object_key(
				$object_type,
				$object_id,
				$object_subtype,
			),
			'object_label' => $object_label,
			'object_url' => $object_url,
		];
	}

	/**
	 * Derive low-entropy dimensions for independent aggregate counters.
	 *
	 * No raw value, identifier or cross-dimension combination is persisted.
	 *
	 * @param array $data Tracking payload.
	 * @return array<string, string> Privacy-safe dimensions.
	 */
	private function get_anonymous_privacy_dimensions(array $data): array {
		$technology = $this->detect_device();
		$local_time = current_datetime();
		$dimensions = [
			'page_type' => sanitize_key($data['object_type'] ?? 'post'),
			'hour' => $local_time->format('H'),
			'weekday' => strtolower($local_time->format('D')),
			'device' => $technology['device_type'],
			'browser' => $technology['browser'],
			'os' => $technology['os'],
		];
		$country = $this->country_resolver->resolve();

		if ($country) {
			$dimensions['country'] = $country;
		}

		$search_results_bucket = sanitize_key($data['search_results_bucket'] ?? '');

		if (
			'search' === ($data['object_type'] ?? '') &&
			in_array($search_results_bucket, ['none', '1_5', '6_20', '21_plus'], true)
		) {
			$dimensions['search_results'] = $search_results_bucket;
		}

		if ($technology['browser_version']) {
			$dimensions['browser_version'] =
				$technology['browser'] . ' ' . $technology['browser_version'];
		}

		if ($technology['os_version']) {
			$dimensions['os_version'] = $technology['os'] . ' ' . $technology['os_version'];
		}

		// CONSENT INVARIANT: Ignore browser-derived fields even from stale clients.
		// Language, viewport and referrer belong exclusively to consented events.

		return array_filter(
			$dimensions,
			static fn(string $value): bool => '' !== $value && 'unknown' !== $value,
		);
	}

	/**
	 * Insert tracking event.
	 *
	 * @param array $data Data.
	 * @return int Insert tracking event.
	 */

	private function insert_tracking_event(array $data): int {
		$visitor_id = sanitize_text_field($data['visitor_id'] ?? '');
		$session_id = sanitize_text_field($data['session_id'] ?? '');
		$event_type = sanitize_key($data['event_type'] ?? 'pageview');
		$object_key = sanitize_text_field($data['object_key'] ?? '');
		$object_url = esc_url_raw($data['object_url'] ?? '');
		$page_url = esc_url_raw($data['page_url'] ?? '');
		$dedupe_hash = $this->event_dedupe_hash([
			'event_type' => $event_type,
			'visitor_id' => $visitor_id,
			'session_id' => $session_id,
			'object_key' => $object_key,
			'object_url' => $object_url,
			'page_url' => $page_url,
			'goal_id' => sanitize_key($data['goal_id'] ?? ''),
			'client_event_id' => sanitize_text_field($data['client_event_id'] ?? ''),
		]);

		return $this->repository->insert_event_id([
			'post_id' => absint($data['post_id'] ?? 0),
			'object_type' => sanitize_key($data['object_type'] ?? 'post'),
			'object_id' => absint($data['object_id'] ?? 0),
			'object_subtype' => sanitize_key($data['object_subtype'] ?? ''),
			'object_key' => $object_key,
			'object_label' => sanitize_text_field($data['object_label'] ?? ''),
			'object_url' => $object_url,
			'page_url' => $page_url,
			'event_type' => $event_type,
			'goal_id' => sanitize_key($data['goal_id'] ?? ''),
			'viewed_at' => sanitize_text_field($data['viewed_at'] ?? current_time('mysql')),
			'visitor_id' => hash('sha256', $visitor_id),
			'session_id' => hash('sha256', $session_id),
			'dedupe_hash' => $dedupe_hash,
			// Normalized technology fields are sufficient for reporting. Raw request
			// fingerprints deliberately remain empty and cannot be queried later.
			'ip_hash' => '',
			'user_agent' => '',
			'is_logged_in' => !empty($data['is_logged_in']) ? 1 : 0,
			'user_id_hash' => sanitize_text_field($data['user_id_hash'] ?? ''),
			'referrer_url' => $this->minimize_referrer_url($data['referrer_url'] ?? ''),
			'referrer_domain' => sanitize_text_field($data['referrer_domain'] ?? ''),
			'source' => sanitize_text_field($data['source'] ?? ''),
			'medium' => sanitize_text_field($data['medium'] ?? ''),
			'campaign' => sanitize_text_field($data['campaign'] ?? ''),
			'content' => sanitize_text_field($data['content'] ?? ''),
			'term' => sanitize_text_field($data['term'] ?? ''),
			'device_type' => sanitize_text_field($data['device_type'] ?? ''),
			'browser' => sanitize_text_field($data['browser'] ?? ''),
			'os' => sanitize_text_field($data['os'] ?? ''),
			'language' => $this->normalize_browser_locale($data['language'] ?? ''),
			// Legacy column names now carry viewport dimensions in CSS pixels.
			'screen_width' => $this->normalize_viewport_dimension($data['screen_width'] ?? 0),
			'screen_height' => $this->normalize_viewport_dimension($data['screen_height'] ?? 0),
		]);
	}

	/**
	 * Keep only referrer scheme, host and path.
	 *
	 * Query parameters and fragments frequently contain search terms, campaign
	 * identifiers or personal values and are not required by current reports.
	 *
	 * @param mixed $value Referrer URL.
	 * @return string Minimized referrer URL.
	 */
	private function minimize_referrer_url($value): string {
		$url = esc_url_raw((string) $value);

		if (!$url) {
			return '';
		}

		$parts = wp_parse_url($url);

		if (!is_array($parts) || empty($parts['host'])) {
			return '';
		}

		if (!in_array($parts['scheme'] ?? '', ['http', 'https'], true)) {
			return '';
		}
		$scheme = $parts['scheme'];
		$path = isset($parts['path']) ? '/' . ltrim($parts['path'], '/') : '';

		return esc_url_raw($scheme . '://' . strtolower($parts['host']) . $path);
	}

	/** Preserve regional/script subtags within the existing 20-character column. */
	private function normalize_browser_locale($value): string {
		$locale = str_replace('_', '-', sanitize_text_field((string) $value));
		if (strlen($locale) > 20 || !preg_match('/^[a-z]{2,8}(?:-[a-z0-9]{1,8})*$/iD', $locale)) {
			return '';
		}
		$parts = explode('-', $locale);
		$parts[0] = strtolower($parts[0]);
		foreach ($parts as $index => $part) {
			if ($index === 0) {
				continue;
			}
			$parts[$index] =
				strlen($part) === 2
					? strtoupper($part)
					: (strlen($part) === 4
						? ucfirst(strtolower($part))
						: strtolower($part));
		}
		return implode('-', $parts);
	}

	/** Reject malformed dimensions; zero denotes unavailable, not a tiny viewport. */
	private function normalize_viewport_dimension($value): int {
		$value = filter_var($value, FILTER_VALIDATE_INT);
		return $value !== false && $value > 0 && $value <= 65535 ? $value : 0;
	}
	/**
	 * Determine whether the current request appears to come from a bot.
	 *
	 * @return bool Determine whether bot.
	 */

	private function is_bot(): bool {
		$ua = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');

		if (!$ua) {
			return true;
		}

		if (
			isset($_SERVER['HTTP_X_PURPOSE']) &&
			stripos($_SERVER['HTTP_X_PURPOSE'], 'preview') !== false
		) {
			return true;
		}

		return (bool) preg_match(
			'/bot|crawl|spider|slurp|bingpreview|facebookexternalhit|linkedinbot|whatsapp|telegrambot|discordbot|preview|crawler|monitoring|headless|phantom|selenium|pagespeed|lighthouse|gtmetrix|pingdom|uptimerobot/i',
			$ua,
		);
	}

	/**
	 * Event dedupe hash.
	 *
	 * @param array $data Data.
	 * @return ?string Event dedupe hash.
	 */

	private function event_dedupe_hash(array $data): ?string {
		$event_type = sanitize_key($data['event_type'] ?? '');

		if (!in_array($event_type, WPHAVE_Analytics_Event_Types::DEDUPED, true)) {
			return null;
		}

		$client_event_id = sanitize_text_field($data['client_event_id'] ?? '');

		if ($client_event_id) {
			return hash('sha256', implode('|', ['client', $event_type, $client_event_id]));
		}

		$bucket = (int) floor(time() / 30);

		return hash(
			'sha256',
			implode('|', [
				$event_type,
				$data['visitor_id'] ?? '',
				$data['session_id'] ?? '',
				$data['object_key'] ?? '',
				$data['object_url'] ?? '',
				$data['page_url'] ?? '',
				$bucket,
			]),
		);
	}

	/**
	 * Apply a transient-backed rate limit for the public analytics tracking endpoint.
	 *
	 * @return true|WP_Error True when tracking may continue, otherwise rate-limit error.
	 */

	private function check_track_rate_limit() {
		$key = 'wphave_analytics_track_rate_' . md5($this->request_signature());
		$count = WPHAVE_Rate_Limiter::increment($key, self::TRACK_RATE_LIMIT_WINDOW);

		if ($count > self::TRACK_RATE_LIMIT_MAX) {
			return new WP_Error(
				'wphave_analytics_rate_limited',
				__('Too many analytics requests. Please try again later.', 'wphave'),
				['status' => 429],
			);
		}

		return true;
	}

	/**
	 * Build a privacy-safe request signature for rate limiting.
	 *
	 * @return string Hashed request signature.
	 */

	private function request_signature(): string {
		// ABUSE INVARIANT: Rotating browser headers never renews tracking admission.
		return WPHAVE_Rate_Limiter::client_key('analytics-track');
	}

	/**
	 * Return domain from url.
	 *
	 * @param string $url Resource URL.
	 * @return string Return domain from url.
	 */

	private function get_domain_from_url(string $url): string {
		if (!$url) {
			return '';
		}

		$host = wp_parse_url($url, PHP_URL_HOST);

		return $host ? strtolower(preg_replace('/^www\./', '', $host)) : '';
	}

	/**
	 * Detect source medium.
	 *
	 * @param string $utm_source Utm source.
	 * @param string $utm_medium Utm medium.
	 * @param string $referrer_domain Referrer domain.
	 * @return array Detect source medium.
	 */

	private function detect_source_medium(
		string $utm_source,
		string $utm_medium,
		string $referrer_domain,
	): array {
		if ($utm_source) {
			return [
				'source' => strtolower($utm_source),
				'medium' => strtolower($utm_medium ?: 'campaign'),
			];
		}

		if (!$referrer_domain) {
			return [
				'source' => 'direct',
				'medium' => 'none',
			];
		}

		foreach (
			['google.', 'bing.', 'yahoo.', 'duckduckgo.', 'ecosia.', 'baidu.', 'yandex.']
			as $engine
		) {
			if (str_contains($referrer_domain, $engine)) {
				return [
					'source' => $referrer_domain,
					'medium' => 'organic',
				];
			}
		}

		foreach (
			[
				'facebook.com',
				'instagram.com',
				'x.com',
				'twitter.com',
				'linkedin.com',
				'pinterest.com',
				'reddit.com',
				'tiktok.com',
				'youtube.com',
			]
			as $domain
		) {
			if (str_contains($referrer_domain, $domain)) {
				return [
					'source' => $referrer_domain,
					'medium' => 'social',
				];
			}
		}

		return [
			'source' => $referrer_domain,
			'medium' => 'referral',
		];
	}

	/**
	 * Detect device.
	 *
	 * @return array Detect device.
	 */

	private function detect_device(): array {
		$classifier = new WPHAVE_Analytics_User_Agent_Classifier();

		return $classifier->classify($_SERVER['HTTP_USER_AGENT'] ?? '');
	}
}
