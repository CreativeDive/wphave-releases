<?php

/**
 * Keeps internal WPHAVE previews out of visitor analytics.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPHAVE_Analytics_Preview_Guard {

	/**
	 * Determine whether the current frontend request renders an internal preview.
	 *
	 * @return bool Whether the current request is an internal preview.
	 */
	public static function is_current_request(): bool {
		return WPHAVE_Site_Preview_Context::is_current_request();
	}

	/**
	 * Determine whether an analytics payload points to an internal preview URL.
	 *
	 * @param array $data Analytics payload.
	 * @return bool Whether the payload belongs to an internal preview.
	 */
	public static function is_tracking_payload( array $data ): bool {
		foreach ( [ 'page_url', 'url', 'object_url', 'referrer_url' ] as $key ) {
			if ( WPHAVE_Site_Preview_Context::is_url( $data[ $key ] ?? '' ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Return a SQL fragment that excludes legacy internal-preview events.
	 *
	 * The column name is assembled only from a trusted query alias.
	 *
	 * @param string $alias Optional trusted table alias.
	 * @return string SQL condition.
	 */
	public static function get_event_exclusion_sql( string $alias = '' ): string {
		$column = $alias ? "{$alias}.page_url" : 'page_url';

		return " AND {$column} NOT LIKE '%?mode=preview%'"
			. " AND {$column} NOT LIKE '%&mode=preview%'"
			. " AND {$column} NOT LIKE '%wphave-global-styles-preview=%'";
	}

}
