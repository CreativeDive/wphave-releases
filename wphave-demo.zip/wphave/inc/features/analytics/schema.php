<?php

/**
 * WPHAVE Analytics schema and migration handling.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPHAVE_Analytics_Schema {

	const DB_VERSION = '1.0.14';

    private string $events_table;
    private string $daily_table;

    /**
     * Initialize the schema service.
     *
     * @param string $events_table Events table.
     * @param string $daily_table Daily table.
     */

    public function __construct( string $events_table, string $daily_table ) {
        $this->events_table = $events_table;
        $this->daily_table  = $daily_table;
    }

    /**
     * Table exists.
     *
     * @param string $table Table.
     * @return bool Table exists.
     */

    public function table_exists( string $table ): bool {
        return WPHAVE_Database_Metadata::table_exists( $table );
    }

    /**
     * Install.
     *
     * @param string $version Version.
     * @return void
     */

    public static function install( string $version ): void {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset = $wpdb->get_charset_collate();

        $events = $wpdb->prefix . WPHAVE_Analytics::EVENT_TABLE;
        $daily  = $wpdb->prefix . WPHAVE_Analytics::DAILY_TABLE;
		$privacy_daily = $wpdb->prefix . WPHAVE_Analytics::PRIVACY_DAILY_TABLE;

        $sql_events = "CREATE TABLE {$events} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            post_id bigint(20) unsigned NOT NULL DEFAULT 0,
            object_type varchar(40) NOT NULL DEFAULT 'post',
            object_id bigint(20) unsigned NOT NULL DEFAULT 0,
            object_subtype varchar(100) NOT NULL DEFAULT '',
            object_key varchar(190) NOT NULL DEFAULT '',
            object_label varchar(255) NOT NULL DEFAULT '',
            object_url text DEFAULT NULL,
            page_url text DEFAULT NULL,
            event_type varchar(40) NOT NULL DEFAULT 'pageview',
            goal_id varchar(190) DEFAULT NULL,
            viewed_at datetime NOT NULL,
            visitor_id varchar(64) NOT NULL,
            session_id varchar(64) NOT NULL,
            dedupe_hash char(64) DEFAULT NULL,
            ip_hash varchar(64) DEFAULT NULL,
            user_agent varchar(255) DEFAULT NULL,
            is_logged_in tinyint(1) unsigned NOT NULL DEFAULT 0,
            user_id_hash varchar(64) DEFAULT NULL,
            referrer_url text DEFAULT NULL,
            referrer_domain varchar(190) DEFAULT NULL,
            source varchar(100) DEFAULT NULL,
            medium varchar(100) DEFAULT NULL,
            campaign varchar(150) DEFAULT NULL,
            content varchar(150) DEFAULT NULL,
            term varchar(150) DEFAULT NULL,
            device_type varchar(30) DEFAULT NULL,
            browser varchar(80) DEFAULT NULL,
            os varchar(80) DEFAULT NULL,
            language varchar(20) DEFAULT NULL,
            screen_width int(10) unsigned DEFAULT NULL,
            screen_height int(10) unsigned DEFAULT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY dedupe_hash (dedupe_hash),
            KEY post_id (post_id),
            KEY object_date (object_type, object_id, viewed_at),
            KEY event_type (event_type),
            KEY event_type_date (event_type, viewed_at),
            KEY event_object (event_type, object_key),
            KEY goal_id (goal_id),
            KEY goal_date (goal_id, viewed_at),
            KEY viewed_at (viewed_at),
            KEY post_date (post_id, viewed_at),
            KEY visitor_id (visitor_id),
            KEY session_id (session_id),
            KEY source (source),
            KEY referrer_domain (referrer_domain),
            KEY source_date (source, viewed_at),
            KEY campaign_date (campaign, viewed_at),
            KEY device_date (device_type, viewed_at),
            KEY session_date (session_id, viewed_at)
        ) {$charset};";

        $sql_daily = "CREATE TABLE {$daily} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            post_id bigint(20) unsigned NOT NULL DEFAULT 0,
            object_type varchar(40) NOT NULL DEFAULT 'post',
            object_id bigint(20) unsigned NOT NULL DEFAULT 0,
            object_subtype varchar(100) NOT NULL DEFAULT '',
            object_key varchar(190) NOT NULL DEFAULT '',
            object_label varchar(255) NOT NULL DEFAULT '',
            object_url text DEFAULT NULL,
            view_date date NOT NULL,
            dimension_hash char(64) NOT NULL DEFAULT '',
            views int(10) unsigned NOT NULL DEFAULT 0,
            unique_visitors int(10) unsigned NOT NULL DEFAULT 0,
            sessions int(10) unsigned NOT NULL DEFAULT 0,
            source varchar(100) NOT NULL DEFAULT '',
            medium varchar(100) NOT NULL DEFAULT '',
            campaign varchar(150) NOT NULL DEFAULT '',
            referrer_domain varchar(190) NOT NULL DEFAULT '',
            device_type varchar(30) NOT NULL DEFAULT '',
            browser varchar(80) NOT NULL DEFAULT '',
            os varchar(80) NOT NULL DEFAULT '',
            PRIMARY KEY (id),
            UNIQUE KEY dimension_hash (dimension_hash),
            KEY date (view_date),
            KEY object (object_key),
            KEY source (source),
            KEY campaign_date (campaign, view_date),
            KEY device (device_type),
            KEY post (post_id)
        ) {$charset};";

        $sql_privacy_daily = "CREATE TABLE {$privacy_daily} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			post_id bigint(20) unsigned NOT NULL DEFAULT 0,
			object_type varchar(40) NOT NULL DEFAULT 'post',
			object_id bigint(20) unsigned NOT NULL DEFAULT 0,
			object_subtype varchar(100) NOT NULL DEFAULT '',
			object_key varchar(190) NOT NULL DEFAULT '',
			view_date date NOT NULL,
			dimension_type varchar(40) NOT NULL,
			dimension_value varchar(100) NOT NULL,
			dimension_hash char(64) NOT NULL,
			views int(10) unsigned NOT NULL DEFAULT 0,
			PRIMARY KEY (id),
			UNIQUE KEY dimension_hash (dimension_hash),
			KEY date_type (view_date, dimension_type),
			KEY type_value (dimension_type, dimension_value),
			KEY post (post_id)
		) {$charset};";

        self::prepare_daily_dimension_hash_index( $daily );
        dbDelta( $sql_events );
        dbDelta( $sql_daily );
		dbDelta( $sql_privacy_daily );
        self::ensure_events_table_columns( $events );
        self::ensure_events_table_indexes( $events );

        // The central schema manager owns the version marker and writes it only
        // after every table and validator in the batch has succeeded.
    }

    /**
     * Repair aggregates created while the daily identity index was absent.
     *
     * Release 1.0.64 removed a completed rollout migration without restoring
     * the unique index to the declarative table definition. Fresh installations
     * could therefore create duplicate aggregate identities and could never pass
     * the schema validator. IDEMPOTENCY INVARIANT: The repair is bounded so affected
     * installations can safely converge before dbDelta restores the index.
     *
     * @param string $table Daily aggregate table.
     * @return void
     */

    private static function prepare_daily_dimension_hash_index( string $table ): void {
        global $wpdb;

        if ( ! WPHAVE_Database_Metadata::table_exists( $table, true ) ) {
            return;
        }

        $indexes = array_unique( (array) $wpdb->get_col( "SHOW INDEX FROM {$table}", 2 ) );
        if ( in_array( 'dimension_hash', $indexes, true ) ) {
            return;
        }

        self::repair_blank_daily_dimension_hashes( $table );
        self::merge_duplicate_daily_dimensions( $table );
    }

    /**
     * Rebuild blank identities in bounded batches.
     *
     * @param string $table Daily aggregate table.
     * @return void
     */

    private static function repair_blank_daily_dimension_hashes( string $table ): void {
        global $wpdb;

        do {
            $rows = $wpdb->get_results(
                "SELECT id, object_key, view_date, source, medium, campaign, referrer_domain, device_type, browser, os FROM {$table} WHERE dimension_hash = '' ORDER BY id ASC LIMIT 250",
                ARRAY_A
            );

            if ( ! is_array( $rows ) ) {
                throw new RuntimeException( 'Analytics daily identities could not be read: ' . $wpdb->last_error );
            }

            foreach ( $rows as $row ) {
                $updated = $wpdb->update(
                    $table,
                    array( 'dimension_hash' => WPHAVE_Analytics_Dimensions::dimension_hash( $row ) ),
                    array( 'id' => absint( $row['id'] ?? 0 ) ),
                    array( '%s' ),
                    array( '%d' )
                );

                if ( false === $updated ) {
                    throw new RuntimeException( 'Analytics daily identity could not be repaired: ' . $wpdb->last_error );
                }
            }
        } while ( count( $rows ) === 250 );
    }

    /**
     * Merge duplicate aggregate identities before restoring uniqueness.
     *
     * Each group is committed independently. An interrupted migration can be
     * retried without double-counting because the retained row receives the
     * complete group totals immediately before the redundant rows are removed.
     *
     * @param string $table Daily aggregate table.
     * @return void
     */

    private static function merge_duplicate_daily_dimensions( string $table ): void {
        global $wpdb;

        do {
            $hashes = $wpdb->get_col(
                "SELECT dimension_hash FROM {$table} GROUP BY dimension_hash HAVING COUNT(*) > 1 LIMIT 100"
            );

            if ( ! is_array( $hashes ) ) {
                throw new RuntimeException( 'Duplicate analytics dimensions could not be read: ' . $wpdb->last_error );
            }

            foreach ( $hashes as $dimension_hash ) {
                $wpdb->query( 'START TRANSACTION' );

                try {
                    $aggregate = $wpdb->get_row(
                        $wpdb->prepare(
                            "SELECT MIN(id) AS keeper_id, SUM(views) AS views, SUM(unique_visitors) AS unique_visitors, SUM(sessions) AS sessions FROM {$table} WHERE dimension_hash = %s",
                            $dimension_hash
                        ),
                        ARRAY_A
                    );

                    $keeper_id = absint( $aggregate['keeper_id'] ?? 0 );
                    if ( ! $keeper_id ) {
                        throw new RuntimeException( 'Duplicate analytics dimensions could not be aggregated.' );
                    }

                    $updated = $wpdb->update(
                        $table,
                        array(
                            'views' => absint( $aggregate['views'] ?? 0 ),
                            'unique_visitors' => absint( $aggregate['unique_visitors'] ?? 0 ),
                            'sessions' => absint( $aggregate['sessions'] ?? 0 ),
                        ),
                        array( 'id' => $keeper_id ),
                        array( '%d', '%d', '%d' ),
                        array( '%d' )
                    );
                    $deleted = $wpdb->query(
                        $wpdb->prepare(
                            "DELETE FROM {$table} WHERE dimension_hash = %s AND id <> %d",
                            $dimension_hash,
                            $keeper_id
                        )
                    );

                    if ( false === $updated || false === $deleted || false === $wpdb->query( 'COMMIT' ) ) {
                        throw new RuntimeException( 'Duplicate analytics dimensions could not be merged: ' . $wpdb->last_error );
                    }
                } catch ( Throwable $error ) {
                    $wpdb->query( 'ROLLBACK' );
                    throw $error;
                }
            }
        } while ( count( $hashes ) === 100 );
    }

    /**
     * Validate.
     *
     * @return bool Validate.
     */

    public static function validate(): bool {
        global $wpdb;

        $events = $wpdb->prefix . WPHAVE_Analytics::EVENT_TABLE;
        $daily = $wpdb->prefix . WPHAVE_Analytics::DAILY_TABLE;
		$privacy_daily = $wpdb->prefix . WPHAVE_Analytics::PRIVACY_DAILY_TABLE;
        $schema = new self( $events, $daily );

		if (
			! $schema->table_exists( $events ) ||
			! $schema->table_exists( $daily ) ||
			! $schema->table_exists( $privacy_daily )
		) {
            return false;
        }

        $event_columns = $wpdb->get_col( "SHOW COLUMNS FROM {$events}", 0 );

        if ( ! is_array( $event_columns ) ) {
            return false;
        }

        foreach ( [ 'goal_id', 'page_url', 'dedupe_hash', 'is_logged_in', 'user_id_hash' ] as $column ) {
            if ( ! in_array( $column, $event_columns, true ) ) {
                return false;
            }
        }

        $daily_columns = $wpdb->get_col( "SHOW COLUMNS FROM {$daily}", 0 );

        if ( ! is_array( $daily_columns ) ) {
            return false;
        }

        foreach ( [ 'view_date', 'dimension_hash', 'views', 'unique_visitors', 'sessions', 'source', 'medium', 'campaign', 'device_type' ] as $column ) {
            if ( ! in_array( $column, $daily_columns, true ) ) {
                return false;
            }
        }

        $event_indexes = array_unique( (array) $wpdb->get_col( "SHOW INDEX FROM {$events}", 2 ) );
        $daily_indexes = array_unique( (array) $wpdb->get_col( "SHOW INDEX FROM {$daily}", 2 ) );
		$privacy_daily_indexes = array_unique( (array) $wpdb->get_col( "SHOW INDEX FROM {$privacy_daily}", 2 ) );
		foreach ( [ 'PRIMARY', 'goal_id', 'goal_date', 'dedupe_hash', 'viewed_at' ] as $index ) {
			if ( ! in_array( $index, $event_indexes, true ) ) {
				return false;
			}
		}

		foreach ( [ 'PRIMARY', 'dimension_hash', 'date' ] as $index ) {
			if ( ! in_array( $index, $daily_indexes, true ) ) {
				return false;
			}
		}
		foreach ( [ 'PRIMARY', 'dimension_hash', 'date_type' ] as $index ) {
			if ( ! in_array( $index, $privacy_daily_indexes, true ) ) {
				return false;
			}
		}

        return true;
    }

    /**
     * Ensure events table columns.
     *
     * @param string $table Table.
     * @return void
     */

    private static function ensure_events_table_columns( string $table ): void {
        global $wpdb;

        $columns = $wpdb->get_col( "SHOW COLUMNS FROM {$table}", 0 );

        if ( ! is_array( $columns ) ) {
            return;
        }

        $alter = [];

        if ( ! in_array( 'goal_id', $columns, true ) ) {
            $alter[] = "ADD goal_id varchar(190) DEFAULT NULL AFTER event_type";
        }

        if ( ! in_array( 'page_url', $columns, true ) ) {
            $alter[] = "ADD page_url text DEFAULT NULL AFTER object_url";
        }

        if ( ! in_array( 'dedupe_hash', $columns, true ) ) {
            $alter[] = "ADD dedupe_hash char(64) DEFAULT NULL AFTER session_id";
        }

        if ( ! in_array( 'is_logged_in', $columns, true ) ) {
            $alter[] = "ADD is_logged_in tinyint(1) unsigned NOT NULL DEFAULT 0 AFTER user_agent";
        }

        if ( ! in_array( 'user_id_hash', $columns, true ) ) {
            $alter[] = "ADD user_id_hash varchar(64) DEFAULT NULL AFTER is_logged_in";
        }

        if ( $alter ) {
            if( $wpdb->query( "ALTER TABLE {$table} " . implode( ', ', $alter ) ) === false ) throw new RuntimeException( 'Analytics event columns could not be updated: ' . $wpdb->last_error );
        }
    }

    /**
     * Ensure events table indexes.
     *
     * @param string $table Table.
     * @return void
     */

    private static function ensure_events_table_indexes( string $table ): void {
        global $wpdb;

        $indexes = $wpdb->get_col( "SHOW INDEX FROM {$table}", 2 );

        if ( ! is_array( $indexes ) ) {
            return;
        }

        $indexes = array_unique( $indexes );

        if ( ! in_array( 'object', $indexes, true ) ) {
            if ( false === $wpdb->query( "ALTER TABLE {$table} ADD KEY object (object_type, object_id)" ) ) {
                throw new RuntimeException( 'Analytics object index could not be created: ' . $wpdb->last_error );
            }
        }

        if ( ! in_array( 'goal_id', $indexes, true ) ) {
            if( $wpdb->query( "ALTER TABLE {$table} ADD KEY goal_id (goal_id)" ) === false ) throw new RuntimeException( 'Analytics goal index could not be created: ' . $wpdb->last_error );
        }

        if ( ! in_array( 'goal_date', $indexes, true ) ) {
            if( $wpdb->query( "ALTER TABLE {$table} ADD KEY goal_date (goal_id, viewed_at)" ) === false ) throw new RuntimeException( 'Analytics goal-date index could not be created: ' . $wpdb->last_error );
        }

        if ( ! in_array( 'dedupe_hash', $indexes, true ) ) {
            if( $wpdb->query( "ALTER TABLE {$table} ADD UNIQUE KEY dedupe_hash (dedupe_hash)" ) === false ) throw new RuntimeException( 'Analytics deduplication index could not be created: ' . $wpdb->last_error );
        }
    }
}
