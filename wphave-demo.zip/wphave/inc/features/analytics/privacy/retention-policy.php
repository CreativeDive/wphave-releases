<?php

/**
 * Canonical configuration contract for Analytics data retention.
 *
 * Raw pseudonymous events and identifier-free daily statistics intentionally
 * have separate lifetimes. Consumers read this policy so cleanup, privacy
 * disclosures and UI cannot drift apart.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPHAVE_Analytics_Retention_Policy {

	const SETTINGS_PATH = 'advanced.analytics.retention';
	const CLEANUP_CONTINUATION_HOOK = 'wphave_analytics_cleanup_continuation';
	const LEGACY_RAW_DAYS = 30;
	const DEFAULT_RAW_DAYS = 90;
	const DEFAULT_AGGREGATE_MONTHS = 25;
	const RAW_DAY_CHOICES = [ 30, 60, 90, 180, 426 ];
	const AGGREGATE_MONTH_CHOICES = [ 13, 25, 37, 61 ];

	private static bool $settings_changed = false;

	/** Return the effective, backward-compatible policy. */

	public static function get(): array {
		$stored = wphave_data_get( 'site_settings', self::SETTINGS_PATH, null );
		$stored = is_array( $stored ) ? $stored : [];

		return [
			'raw_days' => self::normalize_raw_days(
				$stored['rawDays'] ?? self::LEGACY_RAW_DAYS
			),
			'aggregate_months' => self::normalize_aggregate_months(
				$stored['aggregateMonths'] ?? self::DEFAULT_AGGREGATE_MONTHS
			),
		];
	}

	/** Normalize Analytics settings before persistence. */

	public static function prepare_site_settings( array $data ): array {
		$retention = $data['advanced']['analytics']['retention'] ?? null;

		if ( null === $retention ) {
			return $data;
		}

		$retention = is_array( $retention ) ? $retention : [];
		$normalized = [
			'rawDays' => self::normalize_raw_days(
				$retention['rawDays'] ?? self::DEFAULT_RAW_DAYS
			),
			'aggregateMonths' => self::normalize_aggregate_months(
				$retention['aggregateMonths'] ?? self::DEFAULT_AGGREGATE_MONTHS
			),
		];
		$current = self::get();
		self::$settings_changed = (
			[
				'raw_days' => $normalized['rawDays'],
				'aggregate_months' => $normalized['aggregateMonths'],
			] !== $current
		);
		$data['advanced']['analytics']['retention'] = $normalized;

		return $data;
	}

	/**
	 * Preserve paid retention configuration when entitlement is unavailable.
	 *
	 * Disabled controls are not a security boundary. This runs on the shared
	 * settings write path so direct REST payloads and unrelated settings saves
	 * cannot create or replace a Pro-only policy.
	 */

	public static function preserve_without_pro( array $data ): array {
		if (
			( function_exists( 'wphave_has_pro_access' ) && wphave_has_pro_access() )
			|| ! class_exists( 'WPHAVE_Data_Resources' )
		) {
			return $data;
		}

		$current = WPHAVE_Data_Resources::get( 'site_settings', false );
		$current_retention = $current['advanced']['analytics']['retention'] ?? null;

		if ( is_array( $current_retention ) ) {
			$data['advanced']['analytics']['retention'] = $current_retention;
		} else {
			unset( $data['advanced']['analytics']['retention'] );
		}

		self::$settings_changed = false;

		return $data;
	}

	/** Queue prompt enforcement after a retention setting changes. */

	public static function settings_saved( array $data ): void {
		$settings_changed = self::$settings_changed;
		self::$settings_changed = false;

		if (
			! $settings_changed
			|| ! isset( $data['advanced']['analytics']['retention'] )
		) {
			return;
		}

		$scheduled = self::schedule_cleanup_continuation( MINUTE_IN_SECONDS );
		$status = get_option( 'wphave_analytics_cleanup_status', [] );
		$status = is_array( $status ) ? $status : [];
		$status['continuationPending'] = true;
		$status['continuationScheduled'] = $scheduled;
		$status['scheduleError'] = $scheduled
			? null
			: __( 'Analytics retention cleanup could not be scheduled.', 'wphave' );
		update_option( 'wphave_analytics_cleanup_status', $status, false );
	}

	/** Schedule or confirm one pending retention continuation. */

	public static function schedule_cleanup_continuation( int $delay ): bool {
		// DATA-RETENTION INVARIANT: A stale retry must never count as future
		// cleanup coverage. The platform scheduler repairs missed events and
		// collapses duplicates without disturbing the recurring daily owner.
		return WPHAVE_Background_Job_Scheduler::ensure_continuation(
			self::CLEANUP_CONTINUATION_HOOK,
			array(),
			max( MINUTE_IN_SECONDS, $delay )
		);
	}

	/** Maximum bounded report range supported by the aggregate policy. */

	public static function maximum_report_days(): int {
		return self::aggregate_months() * 31;
	}

	public static function raw_days(): int {
		return self::get()['raw_days'];
	}

	public static function aggregate_months(): int {
		return self::get()['aggregate_months'];
	}

	/**
	 * Return a calendar-safe aggregate boundary in the WordPress site timezone.
	 *
	 * PHP's relative "minus N months" arithmetic can overflow at month end
	 * (for example, March 31 may remain in March). Clamp the original day to
	 * the last valid day of the target month so cleanup and reports agree.
	 */

	public static function aggregate_boundary_timestamp( ?int $reference = null ): int {
		$reference = $reference ?? current_time( 'timestamp', true );
		$current = ( new DateTimeImmutable( '@' . $reference ) )->setTimezone(
			wp_timezone()
		);
		$target_month = $current
			->modify( 'first day of this month' )
			->modify( '-' . self::aggregate_months() . ' months' );
		$target_day = min(
			(int) $current->format( 'j' ),
			(int) $target_month->format( 't' )
		);

		return $target_month
			->setDate(
				(int) $target_month->format( 'Y' ),
				(int) $target_month->format( 'n' ),
				$target_day
			)
			->setTime(
				(int) $current->format( 'H' ),
				(int) $current->format( 'i' ),
				(int) $current->format( 's' )
			)
			->getTimestamp();
	}

	/** Return the aggregate boundary as the canonical site-local SQL date. */

	public static function aggregate_boundary_date( ?int $reference = null ): string {
		return wp_date(
			'Y-m-d',
			self::aggregate_boundary_timestamp( $reference ),
			wp_timezone()
		);
	}

	private static function normalize_raw_days( $value ): int {
		$value = absint( $value );

		return in_array( $value, self::RAW_DAY_CHOICES, true )
			? $value
			: self::DEFAULT_RAW_DAYS;
	}

	private static function normalize_aggregate_months( $value ): int {
		$value = absint( $value );

		return in_array( $value, self::AGGREGATE_MONTH_CHOICES, true )
			? $value
			: self::DEFAULT_AGGREGATE_MONTHS;
	}
}

add_filter(
	'wphave_prepare_site_settings_for_write',
	[ 'WPHAVE_Analytics_Retention_Policy', 'prepare_site_settings' ]
);
add_filter(
	'wphave_prepare_site_settings_for_write',
	[ 'WPHAVE_Analytics_Retention_Policy', 'preserve_without_pro' ],
	20
);
add_action(
	'wphave_site_settings_saved',
	[ 'WPHAVE_Analytics_Retention_Policy', 'settings_saved' ]
);
