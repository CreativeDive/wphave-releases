<?php

/**
 * Handles analytics personal-data export and erasure.
 */

trait WPHAVE_Analytics_Privacy {

	/**
	 * Privacy export.
	 *
	 * @param string $email_address Email address.
	 * @param int $page Page.
	 * @return array Privacy export.
	 */

	public function privacy_export( string $email_address, int $page = 1 ): array {
		if ( ! $this->table_exists( $this->events_table ) ) {
			return [ 'data' => [], 'done' => true ];
		}

		global $wpdb;
		$hashes = $this->privacy_event_hashes( $email_address );

		if ( ! $hashes ) {
			return [ 'data' => [], 'done' => true ];
		}

		$placeholders = implode( ',', array_fill( 0, count( $hashes ), '%s' ) );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT event_type, object_label, object_url, page_url, referrer_url, viewed_at FROM {$this->events_table} WHERE session_id IN ({$placeholders}) OR user_id_hash IN ({$placeholders}) ORDER BY id ASC", ...array_merge( $hashes, $hashes ) ), ARRAY_A ) ?: [];
		$data = array_map( static function( array $row, int $index ): array {
			return [ 'group_id' => 'wphave-analytics', 'group_label' => __( 'WPHAVE Analytics', 'wphave' ), 'item_id' => 'event-' . $index, 'data' => array_map( static fn( $key, $value ) => [ 'name' => ucwords( str_replace( '_', ' ', $key ) ), 'value' => (string) $value ], array_keys( $row ), array_values( $row ) ) ];
		}, $rows, array_keys( $rows ) );

		return [ 'data' => $data, 'done' => true ];
	}

	/**
	 * Privacy erase.
	 *
	 * @param string $email_address Email address.
	 * @param int $page Page.
	 * @return array Privacy erase.
	 */

	public function privacy_erase( string $email_address, int $page = 1 ): array {
		if ( ! $this->table_exists( $this->events_table ) ) {
			return [ 'items_removed' => false, 'items_retained' => false, 'messages' => [], 'done' => true ];
		}

		global $wpdb;
		$hashes = $this->privacy_event_hashes( $email_address );
		$removed = false;

		if ( $hashes ) {
			$placeholders = implode( ',', array_fill( 0, count( $hashes ), '%s' ) );
			$removed = false !== $wpdb->query( $wpdb->prepare( "DELETE FROM {$this->events_table} WHERE session_id IN ({$placeholders}) OR user_id_hash IN ({$placeholders})", ...array_merge( $hashes, $hashes ) ) );
		}

		return [ 'items_removed' => $removed, 'items_retained' => false, 'messages' => [], 'done' => true ];
	}

	/**
	 * Privacy event hashes.
	 *
	 * @param string $email_address Email address.
	 * @return array Privacy event hashes.
	 */

	private function privacy_event_hashes( string $email_address ): array {
		global $wpdb;
		$email = sanitize_email( strtolower( $email_address ) );
		$hashes = [];
		$user = get_user_by( 'email', $email );

		if ( $user ) {
			$hashes[] = hash_hmac( 'sha256', (string) $user->ID, wp_salt( 'auth' ) );
		}

		$identities_table = $wpdb->prefix . 'wphave_audience_identities';
		$interactions_table = $wpdb->prefix . 'wphave_audience_interactions';
		if (
			WPHAVE_Database_Metadata::table_exists( $identities_table ) &&
			WPHAVE_Database_Metadata::table_exists( $interactions_table )
		) {
			$email_hash = hash_hmac( 'sha256', $email, wp_salt( 'auth' ) );
			$hashes = array_merge(
				$hashes,
				$wpdb->get_col(
					$wpdb->prepare(
						"SELECT DISTINCT i.session_hash FROM {$interactions_table} i INNER JOIN {$identities_table} identity ON identity.contact_id = i.contact_id WHERE identity.type = 'email' AND identity.value_hash = %s AND i.session_hash != ''",
						$email_hash
					)
				) ?: []
			);
		}

		return array_values( array_unique( array_filter( $hashes ) ) );
	}

}
