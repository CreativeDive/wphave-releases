<?php

/**
 * Resolves a coarse country code without persisting or exporting an IP address.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WPHAVE_Analytics_Country_Resolver {

	/**
	 * Resolve the current request country from a trusted local source.
	 *
	 * Integrations can provide an ISO 3166-1 alpha-2 code through the
	 * `wphave_analytics_country_code` filter. Hosting GeoIP modules commonly
	 * expose GEOIP_COUNTRY_CODE or MM_COUNTRY_CODE as server variables. HTTP
	 * headers are ignored unless an administrator explicitly allowlists one
	 * through WPHAVE_ANALYTICS_COUNTRY_HEADER.
	 *
	 * @return string Valid country code or an empty string.
	 */
	public function resolve(): string {
		$filtered = apply_filters( 'wphave_analytics_country_code', '' );
		$country = $this->normalize( $filtered );

		if ( $country ) {
			return $country;
		}

		foreach ( [ 'GEOIP_COUNTRY_CODE', 'MM_COUNTRY_CODE' ] as $server_key ) {
			$country = $this->normalize( $_SERVER[ $server_key ] ?? '' );

			if ( $country ) {
				return $country;
			}
		}

		if ( defined( 'WPHAVE_ANALYTICS_COUNTRY_HEADER' ) ) {
			// SECURITY INVARIANT: Client-controlled HTTP geography participates only
			// through an explicitly configured header name and a valid coarse country code.
			$header = strtoupper(
				str_replace( '-', '_', sanitize_text_field( WPHAVE_ANALYTICS_COUNTRY_HEADER ) )
			);
			$server_key = str_starts_with( $header, 'HTTP_' ) ? $header : 'HTTP_' . $header;

			return $this->normalize( $_SERVER[ $server_key ] ?? '' );
		}

		return '';
	}

	/**
	 * Normalize an ISO country code and reject non-country GeoIP buckets.
	 *
	 * @param mixed $value Candidate value.
	 * @return string Normalized country code or an empty string.
	 */
	private function normalize( $value ): string {
		$country = strtoupper( trim( sanitize_text_field( (string) $value ) ) );

		if ( ! preg_match( '/^[A-Z]{2}$/', $country ) ) {
			return '';
		}

		if ( in_array( $country, [ 'A1', 'A2', 'EU', 'O1', 'T1', 'XX' ], true ) ) {
			return '';
		}

		return $country;
	}
}
