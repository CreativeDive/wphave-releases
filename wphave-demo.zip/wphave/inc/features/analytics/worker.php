<?php

/** Bootstrap Analytics aggregation, retention and continuation callbacks. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'WPHAVE_ANALYTICS_WORKER_RUNTIME' ) ) {
	define( 'WPHAVE_ANALYTICS_WORKER_RUNTIME', true );
}

require_once __DIR__ . '/bootstrap.php';
