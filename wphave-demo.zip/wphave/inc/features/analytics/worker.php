<?php

/** Bootstrap Analytics aggregation, retention and continuation callbacks. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'WPHAVE_ANALYTICS_WORKER_RUNTIME' ) ) {
	define( 'WPHAVE_ANALYTICS_WORKER_RUNTIME', true );
}

// The aggregation callback refreshes existing post caches. Compose its narrow
// cache dependencies without loading the complete public optimization runtime.
require_once wphave_dir() . 'inc/optimize/access.php';
require_once wphave_dir() . 'inc/optimize/transients/query-cache.php';
require_once wphave_dir() . 'inc/optimize/post-cache.php';

require_once __DIR__ . '/bootstrap.php';
