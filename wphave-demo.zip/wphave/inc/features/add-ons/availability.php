<?php

/**
 * Resolve server-side availability conditions for conditional add-ons.
 */

class WPHAVE_Add_On_Availability {

	/**
	 * Determine whether an add-on is available in the current frontend request.
	 *
	 * Availability is evaluated before markup is emitted. Interaction triggers
	 * therefore never point to conditionally unavailable markup.
	 *
	 * @param array $conditions Add-on availability settings.
	 * @return bool Whether the add-on may render.
	 */

	public static function is_available( $conditions ) {
		$conditions = is_array( $conditions ) ? $conditions : array();
		$type = sanitize_key( $conditions['type'] ?? 'site' );

		switch( $type ) {
			case 'front-page':
				return is_front_page();
			case 'singular':
				return is_singular();
			case 'post-types':
				return is_singular( self::sanitize_slugs( $conditions['postTypes'] ?? '' ) );
			case 'posts':
				$selected_posts = is_array( $conditions['posts'] ?? null ) ? $conditions['posts'] : array();
				$selected_post_ids = array_values( array_filter( array_map(
					static function( $post ) {
						return absint( is_array( $post ) ? ( $post['id'] ?? 0 ) : $post );
					},
					$selected_posts
				) ) );

				// Accept the former single picker value and ID list defensively.
				if( ! $selected_post_ids ) {
					$selected_post = is_array( $conditions['post'] ?? null ) ? $conditions['post'] : array();
					$selected_post_ids = self::sanitize_ids( array_merge(
						array( $selected_post['id'] ?? 0 ),
						self::sanitize_ids( $conditions['postIds'] ?? '' )
					) );
				}

				return is_singular() && in_array( get_queried_object_id(), $selected_post_ids, true );
			case 'archives':
				return is_archive();
			case 'search':
				return is_search();
			case '404':
				return is_404();
			case 'site':
			default:
				return true;
		}
	}

	/**
	 * Normalize a comma-separated list of post type slugs.
	 *
	 * @param string|array $value Post type values.
	 * @return array Sanitized slugs.
	 */

	private static function sanitize_slugs( $value ) {
		$values = is_array( $value ) ? $value : explode( ',', (string) $value );

		return array_values( array_filter( array_map( 'sanitize_key', $values ) ) );
	}

	/**
	 * Normalize a comma-separated list of post IDs.
	 *
	 * @param string|array $value Post ID values.
	 * @return array Positive post IDs.
	 */

	private static function sanitize_ids( $value ) {
		$values = is_array( $value ) ? $value : explode( ',', (string) $value );

		return array_values( array_filter( array_map( 'absint', $values ) ) );
	}
}
