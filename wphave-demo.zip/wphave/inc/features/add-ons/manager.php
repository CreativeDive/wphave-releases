<?php

/**
 * WPHAVE add-on manager.
 *
 * Centralizes add-on registration, cached content access, frontend rendering,
 * editor context checks, and management REST endpoints.
 */

if( ! class_exists( 'WPHAVE_Add_On_REST_Controller' ) ) {

	class WPHAVE_Add_On_REST_Controller extends WP_REST_Posts_Controller {

		/**
		 * Restrict add-on collections to the feature management boundary.
		 *
		 * @param WP_REST_Request $request Request object.
		 * @return true|WP_Error
		 */

		public function get_items_permissions_check( $request ) {
			if( ! WPHAVE_Add_On_Manager::can_manage() ) {
				return new WP_Error( 'rest_forbidden', __( 'Sorry, you are not allowed to manage add-ons.', 'wphave' ), [ 'status' => rest_authorization_required_code() ] );
			}

			return parent::get_items_permissions_check( $request );
		}

		/**
		 * Restrict direct add-on reads to the feature management boundary.
		 *
		 * @param WP_REST_Request $request Request object.
		 * @return true|WP_Error
		 */

		public function get_item_permissions_check( $request ) {
			if( ! WPHAVE_Add_On_Manager::can_manage() ) {
				return new WP_Error( 'rest_forbidden', __( 'Sorry, you are not allowed to manage add-ons.', 'wphave' ), [ 'status' => rest_authorization_required_code() ] );
			}

			return parent::get_item_permissions_check( $request );
		}

	}

}

class WPHAVE_Add_On_Manager {

	/**
	 * Add-on post type slug.
	 *
	 * @var string
	 */

	const POST_TYPE = 'wphave-add-ons';

	/**
	 * Shared transient group used by the post type feature cache.
	 *
	 * @var string
	 */

	const CACHE_TRANSIENT = 'post_type_features_data';

	/**
	 * Add-on cache key inside the shared transient.
	 *
	 * @var string
	 */

	const CACHE_KEY = 'wphave_add_ons';

	/**
	 * Whether management-only hooks have already been registered.
	 *
	 * @var bool
	 */

	private static $management_initialized = false;

	/**
	 * Prevent recursive status changes while exclusive access modes are synchronized.
	 *
	 * @var bool
	 */

	private static $syncing_access_modes = false;

	/**
	 * Add-on data resolved during the current request.
	 *
	 * @var array|null
	 */

	private static $request_data = null;

	/**
	 * Register hooks required in every request context.
	 *
	 * @return void
	 */

	public static function init() {
		add_action( 'init', [ __CLASS__, 'register_post_type' ], 16 );
		add_action( 'init', [ __CLASS__, 'register_post_meta' ] );
		add_action( 'transition_post_status', [ __CLASS__, 'synchronize_access_modes' ], 10, 3 );
		add_action( 'save_post_' . self::POST_TYPE, [ __CLASS__, 'clear_cache' ] );
		add_action( 'delete_post', [ __CLASS__, 'clear_cache_on_delete' ], 10, 2 );
		add_action( 'added_post_meta', [ __CLASS__, 'handle_identifier_meta_change' ], 10, 3 );
		add_action( 'updated_post_meta', [ __CLASS__, 'handle_identifier_meta_change' ], 10, 3 );
		add_action( 'deleted_post_meta', [ __CLASS__, 'handle_identifier_meta_change' ], 10, 3 );
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue_indirect_add_on_assets' ] );
		add_action( 'wphave_template_content_extend', [ __CLASS__, 'render_before' ], 10, 2 );
		add_action( 'wphave_render_after_footer_section', [ __CLASS__, 'render_after' ], 18 );
	}

	/**
	 * Enqueue assets for add-ons that enter the document outside regular content.
	 *
	 * The announcement bar is composed before the header and the pin button is
	 * injected by the shared image renderer. Neither block is reliably present
	 * when WordPress inspects regular page content for assets. Reading registered
	 * handles keeps block.json as the source of truth while loading styles early.
	 *
	 * @return void
	 */

	public static function enqueue_indirect_add_on_assets() {
		if( wphave_use_fse() ) {
			return;
		}

		foreach( array( 'announcement-bar', 'pin-button' ) as $add_on_id ) {
			if( ! self::has( $add_on_id ) ) {
				continue;
			}

			$block_type = WP_Block_Type_Registry::get_instance()->get_registered( 'wphave/' . $add_on_id );
			if( ! $block_type ) {
				continue;
			}

			foreach( $block_type->style_handles as $style_handle ) {
				wp_enqueue_style( $style_handle );
			}

			foreach( $block_type->view_script_handles as $script_handle ) {
				wp_enqueue_script( $script_handle );
			}
		}
	}

	/**
	 * Register hooks used only by management request contexts.
	 *
	 * @return void
	 */

	public static function init_management() {
		if( self::$management_initialized ) {
			return;
		}

		self::$management_initialized = true;
		add_action( 'rest_api_init', [ __CLASS__, 'register_rest_routes' ] );
	}

	/**
	 * Return all available add-on definitions.
	 *
	 * @return array Add-on definitions keyed by add-on ID.
	 */

	public static function get_definitions() {
		return [
			'announcement-bar' => [
				'id' => 'announcement-bar',
				'title' => __( 'Announcement Bar', 'wphave' ),
				'description' => __( 'Create a site-wide announcement bar with its own content and visibility rules.', 'wphave' ),
				'icon' => 'megaphone',
				'keywords' => [ 'elements', 'cta', 'all' ],
				'isMultiple' => true,
			],
			'cta-slide-in' => [
				'id' => 'cta-slide-in',
				'title' => __( 'CTA Slide-In', 'wphave' ),
				'description' => __( 'Show a timed call-to-action panel that slides in from a selected screen edge.', 'wphave' ),
				'icon' => 'megaphone',
				'keywords' => [ 'elements', 'cta', 'all' ],
				'isMultiple' => true,
			],
			'popup' => [
				'id' => 'popup',
				'title' => __( 'Popup', 'wphave' ),
				'description' => __( 'Create accessible popups with configurable triggers, display conditions, and frequency limits.', 'wphave' ),
				'icon' => 'window',
				'keywords' => [ 'elements', 'cta', 'all' ],
				'isMultiple' => true,
			],
			'scroll-to-top' => [
				'id' => 'scroll-to-top',
				'title' => __( 'Scroll to Top', 'wphave' ),
				'description' => __( 'Show an accessible button after scrolling that returns visitors to the top of the page.', 'wphave' ),
				'icon' => 'arrow-up',
				'keywords' => [ 'elements', 'all' ],
				'isMultiple' => false,
			],
			'social-bar' => [
				'id' => 'social-bar',
				'title' => __( 'Social Bar', 'wphave' ),
				'description' => __( 'Keep links to your social profiles visible in a customizable bar fixed to either side of the site.', 'wphave' ),
				'icon' => 'social',
				'keywords' => [ 'elements', 'social', 'all' ],
				'isMultiple' => false,
			],
			'open-graph' => [
				'id' => 'open-graph',
				'title' => __( 'Open Graph', 'wphave' ),
				'description' => __( 'Configure Open Graph metadata and a fallback image for rich link previews on social platforms.', 'wphave' ),
				'icon' => 'facebook',
				'keywords' => [ 'social', 'all' ],
				'isMultiple' => false,
			],
			'x-card' => [
				'id' => 'x-card',
				'title' => __( 'X Card', 'wphave' ),
				'description' => __( 'Configure X Card metadata, card type, account attribution, and a fallback image for shared content.', 'wphave' ),
				'icon' => 'x',
				'action' => '',
				'keywords' => [ 'social', 'all' ],
				'isMultiple' => false,
			],
			'pin-button' => [
				'id' => 'pin-button',
				'title' => __( 'Pinterest Button', 'wphave' ),
				'description' => __( 'Add a Pinterest save button to supported images for pointer and touch interactions.', 'wphave' ),
				'icon' => 'pinterest',
				'keywords' => [ 'social', 'all' ],
				'isMultiple' => false,
			],
			'coming-soon' => [
				'id' => 'coming-soon',
				'title' => __( 'Coming Soon', 'wphave' ),
				'description' => __( 'Replace the public site with a customizable coming-soon page while logged-in editors continue working.', 'wphave' ),
				'icon' => 'stop-hand',
				'keywords' => [ 'privacy', 'all' ],
				'isMultiple' => false,
			],
			'maintenance' => [
				'id' => 'maintenance',
				'title' => __( 'Maintenance Mode', 'wphave' ),
				'description' => __( 'Temporarily replace the public website with a customizable maintenance page and a standards-compliant service-unavailable response.', 'wphave' ),
				'icon' => 'tools',
				'keywords' => [ 'privacy', 'maintenance', 'all' ],
				'isMultiple' => false,
			],
		];
	}

	/**
	 * Keep Coming Soon and Maintenance mutually exclusive when one is published.
	 *
	 * Runtime priority still protects imported or externally modified data, but
	 * synchronizing post statuses keeps the editor and stored state unambiguous.
	 *
	 * @param string  $new_status New post status.
	 * @param string  $old_status Previous post status.
	 * @param WP_Post $post Changed post.
	 * @return void
	 */

	public static function synchronize_access_modes( $new_status, $old_status, $post ) {
		if( self::$syncing_access_modes || 'publish' !== $new_status || 'publish' === $old_status || self::POST_TYPE !== $post->post_type ) {
			return;
		}

		self::synchronize_access_mode_counterpart( $post );
	}

	/**
	 * Keep access-mode exclusivity after a direct add-on identifier mutation.
	 *
	 * @param int    $meta_id Metadata row ID.
	 * @param int    $post_id Add-on post ID.
	 * @param string $meta_key Metadata key.
	 * @return void
	 */

	public static function handle_identifier_meta_change( $meta_id, $post_id, $meta_key ) {
		if( 'wphave_add_on_id' !== $meta_key || self::POST_TYPE !== get_post_type( $post_id ) ) {
			return;
		}

		// DATA INTEGRITY INVARIANT: The canonical identifier may change without
		// a status transition. Both the read model and exclusive access mode must
		// reflect that mutation within the same request.
		self::clear_cache();
		self::synchronize_access_mode_counterpart( get_post( $post_id ) );
	}

	/**
	 * Deactivate published access-mode counterparts for one add-on.
	 *
	 * @param WP_Post|null $post Add-on post.
	 * @return void
	 */

	private static function synchronize_access_mode_counterpart( $post ) {
		if( self::$syncing_access_modes || ! $post instanceof WP_Post || self::POST_TYPE !== $post->post_type || 'publish' !== $post->post_status ) {
			return;
		}

		$add_on_id = get_post_meta( $post->ID, 'wphave_add_on_id', true );
		$counterpart = 'maintenance' === $add_on_id ? 'coming-soon' : ( 'coming-soon' === $add_on_id ? 'maintenance' : '' );

		if( ! $counterpart ) {
			return;
		}

		$counterpart_ids = get_posts( array(
			'post_type' => self::POST_TYPE,
			'post_status' => 'publish',
			'fields' => 'ids',
			'posts_per_page' => -1,
			'post__not_in' => array( $post->ID ),
			'meta_key' => 'wphave_add_on_id',
			'meta_value' => $counterpart,
			'no_found_rows' => true,
		) );

		self::$syncing_access_modes = true;

		foreach( $counterpart_ids as $counterpart_id ) {
			wp_update_post( array( 'ID' => $counterpart_id, 'post_status' => 'draft' ) );
		}

		self::$syncing_access_modes = false;
		self::clear_cache();
	}

	/**
	 * Register the reusable add-on custom post type.
	 *
	 * @return void
	 */

	public static function register_post_type() {
		if( wphave_use_fse() ) {
			return;
		}

		register_post_type( self::POST_TYPE, [
			'label' => __( 'Add-Ons', 'wphave' ),
			'description' => __( 'Extend your website with useful and build-in Add-Ons.', 'wphave' ),
			'menu_icon' => 'data:image/svg+xml;base64,' . base64_encode( wphave_svg_ui_icon( 'items' ) ),
			'menu_position' => 48,
			'supports' => [
				'title',
				'editor' => [
					'notes'
				],
				'revisions',
				'custom-fields'
			],
			'public' => false,
			'show_ui' => true,
			'rewrite' => false,
			'show_in_menu' => false,
			'show_in_rest' => true,
			'rest_controller_class' => 'WPHAVE_Add_On_REST_Controller',
			'map_meta_cap' => true,
			'capabilities' => self::get_post_type_capabilities(),
			'has_archive' => false,
			'exclude_from_search' => true,
			'show_in_nav_menus' => false,
			'show_in_admin_bar' => false,
			'publicly_queryable' => false,
			'query_var' => false,
		] );
	}

	/**
	 * Return WordPress post type capabilities mapped to add-on feature access.
	 *
	 * @return array Post type capability mapping.
	 */

	private static function get_post_type_capabilities() {
		$capability = 'wphave_manage_addons';

		return [
			'edit_post' => 'edit_wphave_addon',
			'read_post' => 'read_wphave_addon',
			'delete_post' => 'delete_wphave_addon',
			'edit_posts' => $capability,
			'edit_others_posts' => $capability,
			'delete_posts' => $capability,
			'publish_posts' => $capability,
			'read_private_posts' => $capability,
			'create_posts' => $capability,
			'delete_private_posts' => $capability,
			'delete_published_posts' => $capability,
			'delete_others_posts' => $capability,
			'edit_private_posts' => $capability,
			'edit_published_posts' => $capability,
		];
	}

	/**
	 * Register the add-on identifier exposed through the block editor REST API.
	 *
	 * @return void
	 */

	public static function register_post_meta() {
		register_post_meta( self::POST_TYPE, 'wphave_add_on_id', [
			'single' => true,
			'type' => 'string',
			'show_in_rest' => [
				'schema' => [
					'type' => 'string',
					'enum' => array_keys( self::get_definitions() ),
				],
			],
			'auth_callback' => [ __CLASS__, 'can_manage' ]
		] );
	}

	/**
	 * Determine whether the current user may manage add-ons.
	 *
	 * @return bool Whether add-on management is permitted.
	 */

	public static function can_manage() {
		return current_user_can( 'wphave_manage_addons' ) || current_user_can( 'wphave_manage_options' ) || current_user_can( 'manage_options' );
	}

	/**
	 * Return cached data for all saved add-ons.
	 *
	 * @return array Add-on data keyed by post ID.
	 */

	public static function get_data() {
		// PERFORMANCE INVARIANT: Frontend requests may not populate the shared
		// internal-post-type cache. Retain even an empty result for this request so
		// multiple render and asset decisions do not repeat the same database work.
		if( self::$request_data !== null ) {
			return self::$request_data;
		}

		$cached = wphave_has_cached_data( self::CACHE_TRANSIENT, [
			'key' => self::CACHE_KEY,
			'admin_cache' => true,
		] );

		if( $cached !== false ) {
			self::$request_data = $cached;

			return self::$request_data;
		}

		$post_ids = wphave_internal_post_type_all_ids( self::POST_TYPE );

		if( ! $post_ids ) {
			self::$request_data = [];

			wphave_save_query( [], self::CACHE_TRANSIENT, [
				'key' => self::CACHE_KEY,
				'admin_cache' => true,
				'frontend_write' => false,
			] );

			return self::$request_data;
		}

		wphave_events( 'CACHE', 'Add ons data.' );

		$save_data = [];

		foreach( $post_ids as $post_id ) {
			$add_on_id = get_post_meta( $post_id, 'wphave_add_on_id', true );

			if( ! isset( self::get_definitions()[$add_on_id] ) ) {
				continue;
			}

			$post = get_post( $post_id );

			if( ! $post || $post->post_type !== self::POST_TYPE || $post->post_status !== 'publish' ) {
				continue;
			}

			$save_data[$post_id] = [
				'post_id' => $post_id,
				'add_on_id' => $add_on_id,
				'add_on_content' => $post->post_content,
			];
		}

		wphave_save_query( $save_data, self::CACHE_TRANSIENT, [
			'key' => self::CACHE_KEY,
			'admin_cache' => true,
			'frontend_write' => false,
		] );

		self::$request_data = $save_data;

		return self::$request_data;
	}

	/**
	 * Remove add-on data from the shared post-type feature cache.
	 *
	 * @return void
	 */

	public static function clear_cache() {
		// DATA INTEGRITY INVARIANT: A mutation in this request must never leave
		// subsequent render decisions on the request-local pre-mutation snapshot.
		self::$request_data = null;
		WPHAVE_Internal_Post_Type_Cache::invalidate( self::POST_TYPE );
	}

	/**
	 * Clear add-on state when an add-on is permanently deleted.
	 *
	 * @param int     $post_id Deleted post ID.
	 * @param WP_Post $post Deleted post object.
	 * @return void
	 */

	public static function clear_cache_on_delete( $post_id, $post ) {
		if( ! $post instanceof WP_Post || self::POST_TYPE !== $post->post_type ) {
			return;
		}

		self::clear_cache();
	}

	/**
	 * Determine whether an add-on has a saved instance.
	 *
	 * @param string $name Add-on ID.
	 * @return bool Whether the add-on is active.
	 */

	public static function has( $name ) {
		foreach( self::get_data() as $data ) {
			if( ( $data['add_on_id'] ?? '' ) === $name ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Return the post ID for an active add-on.
	 *
	 * @param string $name Add-on ID.
	 * @return int|false Add-on post ID, or false when not found.
	 */

	public static function get_post_id( $name ) {
		foreach( self::get_data() as $post_id => $data ) {
			if( ( $data['add_on_id'] ?? '' ) === $name ) {
				return $post_id;
			}
		}

		return false;
	}

	/**
	 * Return stored block content for selected add-ons.
	 *
	 * @param array $add_ons Allowed add-on IDs.
	 * @return string Add-on block content.
	 */

	public static function get_content( $add_ons ) {
		$allowed = array_flip( $add_ons );
		$output = '';

		foreach( self::get_data() as $data ) {
			$add_on_id = $data['add_on_id'] ?? '';

			if( isset( $allowed[$add_on_id] ) ) {
				$output .= $data['add_on_content'] ?? '';
			}
		}

		return $output;
	}

	/**
	 * Return one field from an add-on block pattern.
	 *
	 * @param string $name Add-on ID.
	 * @param string $field Pattern field name.
	 * @param string $content Optional preloaded add-on content.
	 * @return mixed Pattern field value.
	 */

	public static function get_field( $name, $field, $content = '' ) {
		if( ! $content ) {
			$content = self::get_content( [ $name ] );
		}

		return WPHAVE_Block_Patterns::data( 'wphave/' . $name, $field, $content );
	}

	/**
	 * Determine whether add-on content may render in the current request.
	 *
	 * @return bool Whether frontend add-ons should render.
	 */

	public static function should_render() {
		if( ! wphave_is_internal_post_type( self::POST_TYPE ) ) {
			return false;
		}

		return ! wphave_should_not_load_features();
	}

	/**
	 * Prepend add-ons that must appear before the template content.
	 *
	 * @param string $block_content Rendered template content.
	 * @param mixed $custom_template Current custom template value.
	 * @return string Extended template content.
	 */

	public static function render_before( $block_content, $custom_template ) {
		if( ! self::should_render() ) {
			return $block_content;
		}

		$add_on_content = self::get_content( [ 'loading-screen' ] );

		return $add_on_content ? $add_on_content . $block_content : $block_content;
	}

	/**
	 * Append renderable add-ons after the footer section.
	 *
	 * Add-ons with dedicated output hooks are excluded here. The pin-button
	 * placeholder remains included so WordPress can discover its block assets.
	 *
	 * @param string $block_content Rendered template content.
	 * @return string Extended template content.
	 */

	public static function render_after( $block_content ) {
		if( ! self::should_render() ) {
			return $block_content;
		}

		$excluded = [ 'announcement-bar', 'coming-soon', 'maintenance', 'x-card', 'open-graph' ];
		$allowed = array_diff( array_keys( self::get_definitions() ), $excluded );
		$add_on_content = self::get_content( $allowed );

		return $add_on_content ? $block_content . $add_on_content : $block_content;
	}

	/**
	 * Determine whether the editor is handling a specific add-on.
	 *
	 * @param string $name Add-on ID.
	 * @return bool Whether the requested add-on is being edited or created.
	 */

	public static function is_current( $name ) {
		$post_id = absint( wphave_request_string( $_GET, 'post' ) );
		$add_on = $post_id ? get_post_meta( $post_id, 'wphave_add_on_id', true ) : '';
		$post_type = sanitize_key( wphave_request_string( $_GET, 'post_type' ) );
		$new_add_on = sanitize_key( wphave_request_string( $_GET, 'new' ) );

		return $add_on === $name || ( $post_type === self::POST_TYPE && $new_add_on === $name );
	}

	/**
	 * Register management REST routes for add-ons.
	 *
	 * @return void
	 */

	public static function register_rest_routes() {
		register_rest_route( 'wphave/v1', '/addons', [
			'methods' => 'GET',
			'callback' => [ __CLASS__, 'collect_rest_data' ],
			'permission_callback' => [ __CLASS__, 'can_manage' ]
		] );
	}

	/**
	 * Collect add-on definitions and current activation data for REST clients.
	 *
	 * @return WP_REST_Response Add-on management data.
	 */

	public static function collect_rest_data() {
		// AUTHORIZATION INVARIANT: The management catalog contains internal post
		// identities and activation state. Its public callback repeats the route's
		// Add-ons capability before consulting definitions or cached state.
		if ( ! self::can_manage() ) {
			return new WP_Error(
				'wphave_addons_forbidden',
				__( 'You are not allowed to manage add-ons.', 'wphave' ),
				array( 'status' => 403 )
			);
		}

		$definitions = self::get_definitions();
		$current = self::get_data();
		$current_indexed = [];

		foreach( $current as $post_id => $item ) {
			$add_on_id = $item['add_on_id'] ?? '';

			if( $add_on_id ) {
				$current_indexed[$add_on_id] = $post_id;
			}
		}

		foreach( $definitions as $add_on_id => $definition ) {
			$definitions[$add_on_id]['active_post_id'] = $current_indexed[$add_on_id] ?? false;
		}

		return rest_ensure_response( [
			'base' => $definitions,
			'current' => $current,
		] );
	}

}

WPHAVE_Add_On_Manager::init();
