<?php

/**
 * Bootstrap the WPHAVE add-on feature.
 */

require_once __DIR__ . '/manager.php';

// Add-on-specific integrations remain isolated in their owning block modules.
wphave_include_file( wphave_dir() . 'build/block-types/blocks-add-ons/x-card/functions.php' );
wphave_include_file( wphave_dir() . 'build/block-types/blocks-add-ons/open-graph/functions.php' );
wphave_include_file( wphave_dir() . 'build/block-types/blocks-add-ons/pin-button/functions.php' );
wphave_include_file( wphave_dir() . 'build/block-types/blocks-add-ons/coming-soon/functions.php' );
wphave_include_file( wphave_dir() . 'build/block-types/blocks-add-ons/maintenance/functions.php' );
require_once __DIR__ . '/availability.php';
