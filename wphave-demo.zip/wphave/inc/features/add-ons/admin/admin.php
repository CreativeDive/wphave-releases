<?php

/**
 * Enable management-only add-on endpoints.
 */

WPHAVE_Add_On_Manager::init_management();
