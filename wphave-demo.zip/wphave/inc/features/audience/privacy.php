<?php

/**
 * WordPress personal-data export and erasure integration for Audience.
 *
 * Email lookups use the same normalized, salted identity hash as the domain layer.
 * Exports omit internal tokens and anti-abuse fingerprints. Erasure removes the
 * complete contact-owned graph so no orphaned identity or behavioral rows remain.
 *
 * @package wphave
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Implements the WordPress privacy exporter and eraser contracts.
 */
trait WPHAVE_Audience_Privacy_Trait {

    /**
     * Export all Audience data attributable to a normalized email identity.
     *
     * Operational secrets, internal identifiers and anti-abuse hashes are excluded.
     * Results follow WordPress' paged exporter shape.
     *
     * @param string $email_address Email address.
     * @param int    $page          One-based exporter page.
     * @return array{data: array<int, array<string, mixed>>, done: bool} Privacy export.
     */

    public function privacy_export( string $email_address, int $page = 1 ): array {
        global $wpdb;

        $email = $this->normalize_privacy_email( $email_address );

        if ( '' === $email ) {
            return [
                'data' => [],
                'done' => true,
            ];
        }

        $hash = hash_hmac( 'sha256', $email, wp_salt( 'auth' ) );
        $limit = 100;
        $offset = max( 0, $page - 1 ) * $limit;
        $items = [];
        $contact_ids = $this->contact_ids_for_identity_hash( $hash );
        $leads = [];
        $interactions = [];
        $identities = [];

        if ( $contact_ids ) {
            $placeholders = implode( ',', array_fill( 0, count( $contact_ids ), '%d' ) );
            $leads = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->leads_table} WHERE contact_id IN ({$placeholders}) ORDER BY id ASC LIMIT %d OFFSET %d", ...array_merge( $contact_ids, [ $limit, $offset ] ) ), ARRAY_A ) ?: [];
            $interactions = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->interactions_table} WHERE contact_id IN ({$placeholders}) ORDER BY id ASC LIMIT %d OFFSET %d", ...array_merge( $contact_ids, [ $limit, $offset ] ) ), ARRAY_A ) ?: [];
            $identities = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->identities_table} WHERE contact_id IN ({$placeholders}) ORDER BY id ASC LIMIT %d OFFSET %d", ...array_merge( $contact_ids, [ $limit, $offset ] ) ), ARRAY_A ) ?: [];
        }
        $subscriber_query = "SELECT * FROM {$this->subscribers_table} WHERE email = %s";
        $subscriber_args = [ $email ];

        if ( $this->column_exists( $this->subscribers_table, 'email_hash' ) ) {
            $subscriber_query .= ' OR email_hash = %s';
            $subscriber_args[] = $hash;
        }

        $subscriber_query .= ' ORDER BY id ASC LIMIT %d OFFSET %d';
        $subscriber_args[] = $limit;
        $subscriber_args[] = $offset;
        $subscribers = $wpdb->get_results( $wpdb->prepare( $subscriber_query, ...$subscriber_args ), ARRAY_A ) ?: [];
		$evidence = $this->table_exists( $this->consent_evidence_table )
			? $wpdb->get_results(
				$wpdb->prepare(
					"SELECT * FROM {$this->consent_evidence_table} WHERE recipient_email = %s ORDER BY id ASC LIMIT %d OFFSET %d",
					$email,
					$limit,
					$offset
				),
				ARRAY_A
			) ?: []
			: [];

        foreach ( $leads as $lead ) {
            $items[] = [
                'group_id' => 'wphave-audience',
                'group_label' => __( 'WPHAVE Audience', 'wphave' ),
                'item_id' => 'lead-' . absint( $lead['id'] ),
                'data' => $this->privacy_data( $lead, [ 'id', 'fingerprint' ] ),
            ];
        }

        foreach ( $interactions as $interaction ) {
            $items[] = [
                'group_id' => 'wphave-audience',
                'group_label' => __( 'WPHAVE Audience', 'wphave' ),
                'item_id' => 'interaction-' . absint( $interaction['id'] ),
                'data' => $this->privacy_data( $interaction, [ 'id', 'public_id', 'fingerprint', 'ip_hash', 'user_agent_hash' ] ),
            ];
        }

        foreach ( $identities as $identity ) {
            $items[] = [
                'group_id' => 'wphave-audience',
                'group_label' => __( 'WPHAVE Audience', 'wphave' ),
                'item_id' => 'identity-' . absint( $identity['id'] ),
                'data' => $this->privacy_data( $identity, [ 'id', 'contact_id', 'value_hash' ] ),
            ];
        }

        foreach ( $subscribers as $subscriber ) {
            $items[] = [
                'group_id' => 'wphave-audience',
                'group_label' => __( 'WPHAVE Audience', 'wphave' ),
                'item_id' => 'subscriber-' . absint( $subscriber['id'] ),
                'data' => $this->privacy_data( $subscriber, [ 'id', 'confirm_token_hash', 'confirm_expires_at', 'email_hash' ] ),
            ];
        }

		foreach ( $evidence as $artifact ) {
			$items[] = [
				'group_id' => 'wphave-audience-consent-evidence',
				'group_label' => __( 'WPHAVE Audience consent evidence', 'wphave' ),
				'item_id' => 'consent-evidence-' . sanitize_text_field( $artifact['public_id'] ?? '' ),
				'data' => $this->privacy_data(
					$artifact,
					[ 'id', 'subscriber_id', 'contact_id', 'confirmation_url_hash' ]
				),
			];
		}

        if ( 1 === $page ) {
            foreach ( $contact_ids as $contact_id ) {
                $contact = $this->get_row( $this->contacts_table, $contact_id );

                if ( $contact ) {
                    $items[] = [
                        'group_id' => 'wphave-audience',
                        'group_label' => __( 'WPHAVE Audience', 'wphave' ),
                        'item_id' => 'contact-' . $contact_id,
                        'data' => $this->privacy_data( $contact, [ 'id', 'public_id' ] ),
                    ];
                }
            }
        }

        return [
            'data' => $items,
            'done' => count( $leads ) < $limit && count( $interactions ) < $limit && count( $identities ) < $limit && count( $subscribers ) < $limit && count( $evidence ) < $limit,
        ];
    }

    /**
     * Erase the subscriber rows and complete contact graph for an email identity.
     *
     * This delegates contact-owned data to the canonical transactional deletion
     * workflow, then removes standalone or minimized subscriber proof rows by hash.
     *
     * @param string $email_address Email address.
     * @param int    $page          WordPress exporter page; erasure completes in one pass.
     * @return array{items_removed: bool, items_retained: bool, messages: array, done: bool} Eraser result.
     */

    public function privacy_erase( string $email_address, int $page = 1 ): array {
        global $wpdb;

        $email = $this->normalize_privacy_email( $email_address );

        if ( '' === $email ) {
            return [
                'items_removed' => false,
                'items_retained' => false,
                'messages' => [],
                'done' => true,
            ];
        }

        $hash = hash_hmac( 'sha256', $email, wp_salt( 'auth' ) );
        $contact_ids = $this->contact_ids_for_identity_hash( $hash );
        $domain_removed = false;
        $messages = [];
        $items_retained = false;
        $evidence_removed = 0;

        foreach ( $contact_ids as $contact_id ) {
            $result = $this->delete_contact( $contact_id );

            if ( is_wp_error( $result ) ) {
                $items_retained = true;
                $messages[] = $result->get_error_message();
                continue;
            }

            $domain_removed = true;
        }

        $subscriber_query = "DELETE FROM {$this->subscribers_table} WHERE contact_id = 0 AND (email = %s";
        $subscriber_args = [ $email ];

        if ( $this->column_exists( $this->subscribers_table, 'email_hash' ) ) {
            $subscriber_query .= ' OR email_hash = %s';
            $subscriber_args[] = $hash;
        }

        $subscriber_query .= ')';

        /*
         * PRIVACY INVARIANT: Standalone evidence and its mutable subscriber
         * projection form one erasure unit. Never report either as removed unless
         * the verified transaction boundary committed the complete unit.
         */
        $transaction_started = $this->begin_audience_transaction();
        $evidence_removed = $transaction_started && $this->table_exists( $this->consent_evidence_table )
            ? $wpdb->query(
                $wpdb->prepare(
                    "DELETE FROM {$this->consent_evidence_table} WHERE contact_id = 0 AND recipient_email = %s",
                    $email
                )
            )
            : ( $transaction_started ? 0 : false );
        $subscribers = false !== $evidence_removed
            ? $wpdb->query( $wpdb->prepare( $subscriber_query, ...$subscriber_args ) )
            : false;
        $committed = false !== $evidence_removed
            && false !== $subscribers
            && $this->commit_audience_transaction();

        if ( ! $committed ) {
            if ( $transaction_started ) {
                $this->rollback_audience_transaction();
            }

            $evidence_removed = 0;
            $subscribers = 0;
            $items_retained = true;
            $messages[] = __( 'Subscriber data could not be erased.', 'wphave' );
        }

        return [
            'items_removed' => (bool) $subscribers || $domain_removed || (bool) $evidence_removed,
            'items_retained' => $items_retained,
            'messages' => $messages,
            'done' => true,
        ];
    }

    /**
     * PRIVACY INVARIANT: Resolve one losslessly normalized, structurally valid
     * privacy identity.
     *
     * Empty or malformed input must never reach a query because minimized
     * subscriber rows intentionally share an empty direct-email projection.
     *
     * @param string $email_address Requested privacy identity.
     * @return string Canonical email address, or an empty string when invalid.
     */
    private function normalize_privacy_email( string $email_address ): string {
        $email = $this->normalize_email( $email_address );

        return is_email( $email ) ? $email : '';
    }

    /**
     * Resolve contact IDs by the canonical email hash without loading its raw value.
     *
     * @param string $hash Salted SHA-256 identity hash.
     * @return array<int, int> Contact IDs, or an empty list before schema installation.
     */
    private function contact_ids_for_identity_hash( string $hash ): array {
        global $wpdb;

        if ( ! $this->table_exists( $this->identities_table ) ) {
            return [];
        }

        return array_map(
            'absint',
            $wpdb->get_col( $wpdb->prepare( "SELECT contact_id FROM {$this->identities_table} WHERE type = 'email' AND value_hash = %s", $hash ) ) ?: []
        );
    }

    /**
     * Convert a database row into WordPress privacy name/value entries.
     *
     * Empty values and explicitly excluded operational fields are omitted.
     *
     * @param array<string, mixed> $row     Database row.
     * @param array<int, string>   $exclude Column names that must not be disclosed.
     * @return array<int, array{name: string, value: string}> Privacy data entries.
     */

    private function privacy_data( array $row, array $exclude ): array {
        $data = [];

        foreach ( $row as $key => $value ) {
            if ( in_array( $key, $exclude, true ) || $value === '' || $value === null ) {
                continue;
            }

            $data[] = [
                'name' => ucwords( str_replace( '_', ' ', $key ) ),
                'value' => is_scalar( $value ) ? (string) $value : wp_json_encode( $value ),
            ];
        }

        return $data;
    }
}
