<?php

/**
 * Capability checks for Audience administration.
 *
 * @package wphave
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Capability checks for Audience administration.
 */

trait WPHAVE_Audience_Permissions_Trait {

    /**
     * Returns the stable denial used by final Audience callback guards.
     *
     * AUTHORIZATION INVARIANT: Route permission callbacks are early dispatch
     * gates only. Every public administrative callback must repeat its exact
     * read, manage, subscription or delete policy before its first data access
     * or side effect; callers outside REST receive this same fail-closed result.
     *
     * @return WP_Error Stable access denial.
     */
    private function audience_access_error(): WP_Error {
        return new WP_Error(
            'wphave_audience_forbidden',
            __( 'You are not allowed to access Audience data.', 'wphave' ),
            [ 'status' => 403 ]
        );
    }

    /**
     * Checks whether the current user may view Audience data.
     *
     * @return bool True when the user can access Audience data.
     */

    public function permission_check(): bool {
		// AUTHORIZATION INVARIANT: Audience read, subscriber management, export and
		// deletion are separate authorities. A broad workspace entry capability must
		// never be reused as permission for a more privileged downstream effect.
        return is_user_logged_in() && ( current_user_can( 'manage_options' ) || current_user_can( 'wphave_view_audience' ) );
    }

    /**
     * Allows authenticated Audience access or same-origin public subscription requests.
     *
     * @return bool True when the request is allowed.
     */

    public function permission_or_public_subscribe_check(): bool {
		// SECURITY INVARIANT: Same-origin permits entry only to the narrow public
		// subscription workflow. Its callback still applies proof, rate, consent and
		// field-projection checks; same-origin is not general Audience authorization.
        return $this->permission_check() || $this->is_same_origin_request();
    }

    /**
     * Checks whether the current user may delete Audience records.
     *
     * @return bool True when deletion is allowed.
     */

    private function can_delete(): bool {
        return current_user_can( 'manage_options' ) || current_user_can( 'wphave_delete_audience' );
    }

    /**
     * Checks whether the current user may manage Audience records.
     *
     * @return bool True when management is allowed.
     */

    private function can_manage(): bool {
        return current_user_can( 'manage_options' ) || current_user_can( 'wphave_manage_audience' );
    }

    /**
     * Checks whether the current user may manage subscriber records.
     *
     * @return bool True when subscriber management is allowed.
     */

    private function can_manage_subscribers(): bool {
        return current_user_can( 'manage_options' ) || current_user_can( 'wphave_manage_subscriptions' );
    }

    /**
     * Checks whether the current user may export Audience data.
     *
     * @return bool True when export is allowed.
     */

    private function can_export(): bool {
        return current_user_can( 'manage_options' ) || current_user_can( 'wphave_export_audience' );
    }

    /**
     * REST permission callback for Audience management operations.
     *
     * @return bool True for an authenticated Audience manager.
     */
    public function manage_permission_check(): bool {
        return is_user_logged_in() && $this->can_manage();
    }

    /**
     * REST permission callback for administrative subscription operations.
     *
     * @return bool True for an authenticated subscription manager.
     */
    public function subscription_permission_check(): bool {
        return is_user_logged_in() && $this->can_manage_subscribers();
    }

    /**
     * REST permission callback for destructive Audience operations.
     *
     * @return bool True for an authenticated user with delete capability.
     */
    public function delete_permission_check(): bool {
        return is_user_logged_in() && $this->can_delete();
    }
}
