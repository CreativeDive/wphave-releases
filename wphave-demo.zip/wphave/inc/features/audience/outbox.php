<?php

/**
 * Audience transactional outbox integration.
 *
 * Domain producers enqueue immutable versioned events inside their aggregate
 * transaction. This module owns payload validation, scheduling, delivery
 * claims, retries and terminal recovery.
 *
 * @package wphave
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait WPHAVE_Audience_Outbox_Trait {

    /**
     * Stores a versioned domain event in the transactional outbox.
     *
     * Callers enqueue before commit so aggregate state and integration intent
     * succeed or roll back together where the database supports transactions.
     *
     * @param string $event_name Versioned event name.
     * @param string $aggregate_type Aggregate type key.
     * @param string $aggregate_id Stable public aggregate id.
     * @param array $payload Bounded event payload.
     * @return bool Whether the event was queued successfully.
     */
    private function enqueue_domain_event( string $event_name, string $aggregate_type, string $aggregate_id, array $payload ): bool {
        global $wpdb;

        // DATA INTEGRITY INVARIANT: Outbox routing and aggregate identities are
        // validated exactly because consumers act on these immutable values.
        $event_name_is_valid = strlen( $event_name ) <= 190
            && preg_match( '/^audience\.[a-z0-9_]+(?:\.[a-z0-9_]+)*\.v[1-9][0-9]*$/D', $event_name );
        $aggregate_type = $this->normalize_closed_key(
            $aggregate_type,
            [ 'contact', 'lead', 'interaction' ]
        );
        $aggregate_id = $this->normalize_uuid( $aggregate_id );
        $normalized_payload = $this->normalize_outbox_payload( $payload );
        $encoded_payload = is_wp_error( $normalized_payload )
            ? false
            : wp_json_encode( $normalized_payload );

        if (
            ! $event_name_is_valid
            || '' === $aggregate_type
            || '' === $aggregate_id
            || false === $encoded_payload
            || strlen( $encoded_payload ) > 60000
        ) {
            return false;
        }

        return (bool) $wpdb->insert(
            $this->outbox_table,
            [
                'event_id' => wp_generate_uuid4(),
                'event_name' => $event_name,
                'aggregate_type' => $aggregate_type,
                'aggregate_id' => $aggregate_id,
                'payload' => $encoded_payload,
                'status' => 'pending',
                'attempts' => 0,
                'available_at' => current_time( 'mysql' ),
                'created_at' => current_time( 'mysql' ),
            ]
        );
    }

    /**
     * Validate an immutable event payload without rewriting its public contract.
     *
     * @param array $payload Event payload at the current depth.
     * @param int $depth Current nesting depth.
     * @return array|WP_Error Canonical payload or a validation error.
     */
    private function normalize_outbox_payload( array $payload, int $depth = 0 ) {
        if ( $depth > 3 || count( $payload ) > 50 ) {
            return new WP_Error( 'wphave_audience_outbox_payload_invalid' );
        }

        $normalized = [];
        $is_list = [] === $payload || array_keys( $payload ) === range( 0, count( $payload ) - 1 );

        foreach ( $payload as $key => $value ) {
            if ( ! $is_list ) {
                if (
                    ! is_string( $key )
                    || '' === $key
                    || strlen( $key ) > 100
                    || sanitize_key( $key ) !== $key
                ) {
                    return new WP_Error( 'wphave_audience_outbox_payload_invalid' );
                }
            }

            if ( is_array( $value ) ) {
                $normalized_value = $this->normalize_outbox_payload( $value, $depth + 1 );

                if ( is_wp_error( $normalized_value ) ) {
                    return $normalized_value;
                }
            } elseif ( is_string( $value ) ) {
                if ( strlen( $value ) > 500 || sanitize_text_field( $value ) !== $value ) {
                    return new WP_Error( 'wphave_audience_outbox_payload_invalid' );
                }

                $normalized_value = $value;
            } elseif ( is_int( $value ) || is_bool( $value ) || null === $value ) {
                $normalized_value = $value;
            } elseif ( is_float( $value ) && is_finite( $value ) ) {
                $normalized_value = $value;
            } else {
                return new WP_Error( 'wphave_audience_outbox_payload_invalid' );
            }

            $normalized[ $key ] = $normalized_value;
        }

        // DATA INTEGRITY INVARIANT: A versioned event is rejected rather than
        // sanitized, truncated or type-coerced. Consumers must observe exactly
        // the canonical contract accepted from its producer.
        return $normalized;
    }

    /**
     * Schedules reliable asynchronous domain-event delivery once per site.
     *
     * @return void
     */
    public function schedule_outbox(): void {
        $hook = 'wphave_audience_process_outbox';

		// DELIVERY INVARIANT: Outbox recovery owns exactly one argument-free,
		// five-minute recurring start event. The shared signature reconciler removes
		// slower or duplicate legacy events without touching argument-bearing work.
		WPHAVE_Background_Job_Scheduler::sync_recurring(
			$hook,
			'wphave_audience_outbox_schedule_signature',
			true,
			'wphave_five_minutes',
			time() + MINUTE_IN_SECONDS,
			'audience-outbox-v1'
		);
    }

    /**
     * Atomically acquire or recover one outbox delivery lease.
     *
     * @param int $event_id Internal outbox row id.
     * @param string $claim_token Unique worker ownership token.
     * @param string $now Current site-local database time.
     * @param string $expired_claim Oldest live lease timestamp.
     * @return bool Whether this worker owns the event.
     */
    private function claim_outbox_event(
        int $event_id,
        string $claim_token,
        string $now,
        string $expired_claim
    ): bool {
        global $wpdb;

        if ( $event_id <= 0 || '' === $this->normalize_uuid( $claim_token ) ) {
            return false;
        }

        return 1 === $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$this->outbox_table}
                SET status = 'processing', attempts = attempts + 1, claim_token = %s, claimed_at = %s
                WHERE id = %d AND attempts < 8
                    AND (
                        ( status = 'pending' AND available_at <= %s )
                        OR ( status = 'processing' AND claimed_at <= %s )
                    )",
                $claim_token,
                $now,
                $event_id,
                $now,
                $expired_claim
            )
        );
    }

    /**
     * Terminalize expired final-attempt claims without dispatching again.
     *
     * @param string $expired_claim Oldest live lease timestamp.
     * @return bool Whether terminal recovery could be persisted.
     */
    private function recover_terminal_outbox_claims( string $expired_claim ): bool {
        global $wpdb;

        $result = $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$this->outbox_table}
                SET status = 'failed', claim_token = '', claimed_at = NULL,
                    last_error = CASE
                        WHEN last_error IS NULL OR last_error = '' THEN %s
                        ELSE last_error
                    END
                WHERE status = 'processing' AND attempts >= 8 AND claimed_at <= %s",
                'Audience outbox worker stopped during its final delivery attempt.',
                $expired_claim
            )
        );

        return false !== $result;
    }

    /**
     * Refresh one active delivery lease without changing its owner.
     *
     * @param int $event_id Internal outbox row id.
     * @param string $claim_token Worker ownership token.
     * @return bool Whether the current worker still owns and refreshed the row.
     */
    private function refresh_outbox_claim( int $event_id, string $claim_token ): bool {
        global $wpdb;

        if ( $event_id <= 0 || '' === $this->normalize_uuid( $claim_token ) ) {
            return false;
        }

        $claimed_at = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT claimed_at FROM {$this->outbox_table}
                WHERE id = %d AND status = 'processing' AND claim_token = %s",
                $event_id,
                $claim_token
            )
        );

        if ( ! is_string( $claimed_at ) || '' === $claimed_at ) {
            return false;
        }

        $claimed_at_time = DateTimeImmutable::createFromFormat(
            'Y-m-d H:i:s',
            $claimed_at,
            wp_timezone()
        );

        if ( false === $claimed_at_time ) {
            return false;
        }

        $now = current_datetime();
        $minimum_refresh = $now->modify( '+1 second' );
        $refreshed_at = $claimed_at_time >= $minimum_refresh
            ? $claimed_at_time->modify( '+1 second' )
            : $minimum_refresh;

        // DELIVERY INVARIANT: Lease timestamps advance monotonically and the
        // compare-and-swap keeps ownership checks atomic. Computing the next
        // timestamp in PHP avoids database-specific date arithmetic, which is
        // unavailable in the SQLite-backed WordPress Playground runtime.
        return 1 === $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$this->outbox_table}
                SET claimed_at = %s
                WHERE id = %d AND status = 'processing' AND claim_token = %s AND claimed_at = %s",
                $refreshed_at->format( 'Y-m-d H:i:s' ),
                $event_id,
                $claim_token,
                $claimed_at
            )
        );
    }

    /**
     * Decode one persisted outbox payload without repairing corrupt state.
     *
     * @param string $encoded_payload Persisted JSON payload.
     * @return array Decoded event payload.
     * @throws UnexpectedValueException When storage is corrupt or not an array.
     */
    private function decode_outbox_payload( string $encoded_payload ): array {
        try {
            $payload = json_decode(
                $encoded_payload,
                true,
                32,
                JSON_THROW_ON_ERROR
            );
        } catch ( JsonException $error ) {
            // DATA INTEGRITY INVARIANT: Corrupt persisted integration data must
            // never be rewritten into an apparently valid empty event. Keep the
            // exception generic so logs cannot expose the original payload.
            throw new UnexpectedValueException( 'Invalid Audience outbox payload.' );
        }

        if ( ! is_array( $payload ) ) {
            throw new UnexpectedValueException( 'Invalid Audience outbox payload type.' );
        }

        return $payload;
    }

    /**
     * Complete a delivered event only while this worker still owns its claim.
     *
     * @param int $event_id Internal outbox row id.
     * @param string $claim_token Worker ownership token.
     * @return bool Whether exactly one owned event was completed.
     */
    private function complete_outbox_event( int $event_id, string $claim_token ): bool {
        global $wpdb;

        return 1 === $wpdb->update(
            $this->outbox_table,
            [
                'status' => 'delivered',
                'claim_token' => '',
                'claimed_at' => null,
                'delivered_at' => current_time( 'mysql' ),
                'last_error' => null,
            ],
            [
                'id' => $event_id,
                'status' => 'processing',
                'claim_token' => $claim_token,
            ]
        );
    }

    /**
     * Persist retry or terminal state only for the current claim owner.
     *
     * @param int $event_id Internal outbox row id.
     * @param string $claim_token Worker ownership token.
     * @param int $attempts Attempt count including the current claim.
     * @param Throwable $error Consumer or payload failure.
     * @return bool Whether exactly one owned event was transitioned.
     */
    private function fail_outbox_event(
        int $event_id,
        string $claim_token,
        int $attempts,
        Throwable $error
    ): bool {
        global $wpdb;

        // SECURITY INVARIANT: Consumer exceptions are an extension boundary and
        // may contain arbitrary personal data or unknown credential formats.
        // Durable outbox state stores only a controlled classification, never
        // the third-party exception message itself.
        $failure_message = $error instanceof UnexpectedValueException
            ? 'Audience outbox payload is invalid.'
            : 'Audience outbox consumer failed.';

        return 1 === $wpdb->update(
            $this->outbox_table,
            [
                'status' => $attempts >= 8 ? 'failed' : 'pending',
                'attempts' => $attempts,
                'claim_token' => '',
                'claimed_at' => null,
                'last_error' => $failure_message,
                'available_at' => current_datetime()
                    ->modify( '+' . min( 360, 2 ** $attempts ) . ' minutes' )
                    ->format( 'Y-m-d H:i:s' ),
            ],
            [
                'id' => $event_id,
                'status' => 'processing',
                'claim_token' => $claim_token,
            ]
        );
    }

    /**
     * Dispatches pending outbox events with bounded retry metadata.
     *
     * Consumers receive event name, decoded payload and unique event id and
     * must deduplicate by event id. Failures use exponential minute backoff
     * capped at 360 minutes and become terminal after eight attempts. The
     * five-minute worker cadence is the maximum normal scheduling granularity.
     *
     * @return void
     */
    public function process_outbox(): void {
        global $wpdb;

        if ( ! $this->table_exists( $this->outbox_table ) ) {
            return;
        }

        $selection_now = current_time( 'mysql' );
        $selection_expiry = current_datetime()
            ->modify( '-15 minutes' )
            ->format( 'Y-m-d H:i:s' );

        // DELIVERY INVARIANT: A crashed eighth attempt becomes terminal after
        // its lease expires. Recovery must never create a ninth consumer call.
        if ( ! $this->recover_terminal_outbox_claims( $selection_expiry ) ) {
            throw new RuntimeException( 'Audience outbox terminal recovery could not be persisted.' );
        }

        $events = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$this->outbox_table}
                WHERE attempts < 8
                    AND (
                        ( status = 'pending' AND available_at <= %s )
                        OR ( status = 'processing' AND claimed_at <= %s )
                    )
                ORDER BY id ASC
                LIMIT 50",
                $selection_now,
                $selection_expiry
            ),
            ARRAY_A
        ) ?: [];

        foreach ( $events as $event ) {
            $event_id = absint( $event['id'] );
            $claim_token = wp_generate_uuid4();
            $claim_now = current_time( 'mysql' );
            $claim_expiry = current_datetime()
                ->modify( '-15 minutes' )
                ->format( 'Y-m-d H:i:s' );

            // DELIVERY INVARIANT: A worker must own an atomic, expiring claim
            // before invoking consumers. This prevents concurrent cron/request
            // workers from dispatching the same event at the same time, while
            // allowing recovery after a worker terminates unexpectedly.
            $claimed = $this->claim_outbox_event(
                $event_id,
                $claim_token,
                $claim_now,
                $claim_expiry
            );

            if ( ! $claimed ) {
                continue;
            }

            try {
                $payload = $this->decode_outbox_payload( (string) $event['payload'] );
                do_action(
                    'wphave_audience_domain_event',
                    $event['event_name'],
                    $payload,
                    $event['event_id']
                );

                // DELIVERY INVARIANT: The generic consumer boundary may run
                // long enough for another worker to recover the lease. Confirm
                // ownership again before invoking the event-specific boundary.
                if ( ! $this->refresh_outbox_claim( $event_id, $claim_token ) ) {
                    throw new RuntimeException( 'Audience outbox delivery claim was lost.' );
                }

                do_action(
                    'wphave_audience_domain_event_' . sanitize_key( str_replace( '.', '_', $event['event_name'] ) ),
                    $payload,
                    $event['event_id']
                );
            } catch ( Throwable $error ) {
                $attempts = absint( $event['attempts'] ) + 1;

                if ( ! $this->fail_outbox_event( $event_id, $claim_token, $attempts, $error ) ) {
                    // DELIVERY INVARIANT: Losing ownership or failing to persist
                    // retry state is an operational failure, never a successful
                    // dispatch. The surviving/next worker owns recovery.
                    throw new RuntimeException( 'Audience outbox retry state could not be persisted.' );
                }

                continue;
            }

            if ( ! $this->complete_outbox_event( $event_id, $claim_token ) ) {
                throw new RuntimeException( 'Audience outbox delivery state could not be persisted.' );
            }
        }
    }
}
