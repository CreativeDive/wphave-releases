<?php

/**
 * Audience Domain V2 application services.
 *
 * Contacts are durable identities, interactions are immutable facts, and
 * leads are mutable work items. This separation is the central Audience V2
 * invariant.
 *
 * Data ownership rules:
 * - contacts own mutable person and organization profile data;
 * - identities own normalized addresses and external identifiers;
 * - interactions own immutable submission and attribution facts;
 * - leads own mutable pipeline state only;
 * - consent events and activities are append-only audit facts;
 * - the outbox is the only asynchronous integration boundary.
 *
 * Methods that mutate more than one aggregate use a database transaction.
 * Runtime readiness rejects non-transactional Audience table engines so these
 * cross-aggregate contracts cannot silently degrade to partial writes.
 *
 * @package wphave
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once wphave_dir() . 'inc/features/security/boundaries/index.php';

trait WPHAVE_Audience_Domain_V2_Trait {

    /**
     * Seeds stable default pipelines, stages and purpose registries.
     *
     * Every statement is an idempotent upsert. Keys are durable contracts;
     * labels and ordering may evolve without creating duplicate definitions.
     *
     * @return void
     */
    private function seed_audience_domain_defaults(): void {
        global $wpdb;

        $now = current_time( 'mysql' );
        $wpdb->query(
            $wpdb->prepare(
                "INSERT INTO {$this->pipelines_table} (pipeline_key, label, is_default, is_active, created_at, updated_at) VALUES ('default', %s, 1, 1, %s, %s) ON DUPLICATE KEY UPDATE label = VALUES(label), is_default = 1, is_active = 1, updated_at = VALUES(updated_at)",
                __( 'Default pipeline', 'wphave' ),
                $now,
                $now
            )
        );
        $pipeline_id = (int) $wpdb->get_var( "SELECT id FROM {$this->pipelines_table} WHERE pipeline_key = 'default' LIMIT 1" );
        $stages = [
            [ 'new', __( 'New', 'wphave' ), 10, 'open' ],
            [ 'qualified', __( 'Qualified', 'wphave' ), 20, 'open' ],
            [ 'won', __( 'Won', 'wphave' ), 30, 'won' ],
            [ 'lost', __( 'Lost', 'wphave' ), 40, 'lost' ],
        ];

        foreach ( $stages as [ $key, $label, $position, $outcome ] ) {
            $wpdb->query(
                $wpdb->prepare(
                    "INSERT INTO {$this->stages_table} (pipeline_id, stage_key, label, position, outcome, created_at, updated_at) VALUES (%d, %s, %s, %d, %s, %s, %s) ON DUPLICATE KEY UPDATE label = VALUES(label), position = VALUES(position), outcome = VALUES(outcome), updated_at = VALUES(updated_at)",
                    $pipeline_id,
                    $key,
                    $label,
                    $position,
                    $outcome,
                    $now,
                    $now
                )
            );
        }

        foreach ( [
            'general' => __( 'General audience', 'wphave' ),
            'newsletter' => __( 'Newsletter', 'wphave' ),
            'demo_request' => __( 'Demo request', 'wphave' ),
            'product_updates' => __( 'Product updates', 'wphave' ),
            'waitlist' => __( 'Waitlist', 'wphave' ),
            'webinar' => __( 'Webinar', 'wphave' ),
            'download_follow_up' => __( 'Download follow-up', 'wphave' ),
        ] as $key => $label ) {
            $wpdb->query(
                $wpdb->prepare(
                    "INSERT INTO {$this->purposes_table} (purpose_key, label, channel, requires_double_opt_in, is_active, created_at, updated_at) VALUES (%s, %s, 'email', 1, 1, %s, %s) ON DUPLICATE KEY UPDATE label = VALUES(label), updated_at = VALUES(updated_at)",
                    $key,
                    $label,
                    $now,
                    $now
                )
            );
        }

        $wpdb->query(
            $wpdb->prepare(
                "INSERT INTO {$this->purposes_table} (purpose_key, label, channel, requires_double_opt_in, is_active, created_at, updated_at) VALUES ('lead_capture', %s, 'none', 0, 1, %s, %s) ON DUPLICATE KEY UPDATE label = VALUES(label), updated_at = VALUES(updated_at)",
                __( 'Lead capture', 'wphave' ),
                $now,
                $now
            )
        );
    }

    /**
     * Resolves or creates a contact by an exact normalized email identity.
     *
     * PRIVACY INVARIANT: Names, IP addresses and browser data never trigger an automatic identity merge.
     * Invalid or absent email returns null so anonymous interactions remain
     * valid. Identity insertion failure removes the newly created contact.
     *
     * @param string $email Candidate email identity.
     * @param array{first_name?: string, last_name?: string} $profile Optional profile hints.
     * @return int|null|WP_Error Contact id, null for anonymous data, or persistence error.
     */
    private function resolve_contact( string $email, array $profile = [] ) {
        global $wpdb;

        $email = $this->normalize_email( $email );

        if ( ! is_email( $email ) ) {
            return null;
        }

        $normalized_profile = $this->normalize_contact_profile( $profile );

        if ( is_wp_error( $normalized_profile ) ) {
            return $normalized_profile;
        }

        $normalized = strtolower( $email );
        $hash = hash_hmac( 'sha256', $normalized, wp_salt( 'auth' ) );
        $contact_id = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT contact_id FROM {$this->identities_table} WHERE type = 'email' AND value_hash = %s LIMIT 1",
                $hash
            )
        );

        if ( $wpdb->last_error ) {
            return new WP_Error( 'wphave_audience_identity_lookup_failed', __( 'Contact identity could not be resolved.', 'wphave' ), [ 'status' => 500 ] );
        }

        if ( $contact_id ) {
            $profile_updated = $this->update_contact_profile( $contact_id, $normalized_profile );

            if ( is_wp_error( $profile_updated ) ) {
                return $profile_updated;
            }

            return $contact_id;
        }

        $now = current_time( 'mysql' );
        $public_id = wp_generate_uuid4();
        $inserted = $wpdb->insert(
            $this->contacts_table,
            [
                'public_id' => $public_id,
                'display_name' => trim( $normalized_profile['first_name'] . ' ' . $normalized_profile['last_name'] ),
                'first_name' => $normalized_profile['first_name'],
                'last_name' => $normalized_profile['last_name'],
                'status' => 'active',
                'created_at' => $now,
                'updated_at' => $now,
            ]
        );

        if ( ! $inserted ) {
            return new WP_Error( 'wphave_audience_contact_insert_failed', __( 'Contact could not be stored.', 'wphave' ), [ 'status' => 500 ] );
        }

        $contact_id = (int) $wpdb->insert_id;
        $identity = $wpdb->insert(
            $this->identities_table,
            [
                'contact_id' => $contact_id,
                'type' => 'email',
                'provider' => 'wphave',
                'value' => $normalized,
                'normalized_value' => $normalized,
                'value_hash' => $hash,
                'verification_status' => 'unverified',
                'is_primary' => 1,
                'created_at' => $now,
                'updated_at' => $now,
            ]
        );

        if ( ! $identity ) {
            $wpdb->delete( $this->contacts_table, [ 'id' => $contact_id ], [ '%d' ] );
            return new WP_Error( 'wphave_audience_identity_insert_failed', __( 'Contact identity could not be stored.', 'wphave' ), [ 'status' => 500 ] );
        }

        if ( ! $this->enqueue_domain_event( 'audience.contact.created.v1', 'contact', $public_id, [ 'contact_id' => $contact_id ] ) ) {
            return new WP_Error( 'wphave_audience_contact_event_failed', __( 'Contact event could not be queued.', 'wphave' ), [ 'status' => 500 ] );
        }

        return $contact_id;
    }

    /**
     * Fills missing contact names without overwriting established profile data.
     *
     * @param int $contact_id Contact database id.
     * @param array{first_name?: string, last_name?: string} $profile Profile hints.
     * @return true|WP_Error Whether missing profile values were synchronized.
     */
    private function update_contact_profile( int $contact_id, array $profile ) {
        global $wpdb;

        $current = $wpdb->get_row(
            $wpdb->prepare( "SELECT first_name, last_name FROM {$this->contacts_table} WHERE id = %d", $contact_id ),
            ARRAY_A
        );

        if ( ! $current ) {
            return new WP_Error( 'wphave_audience_contact_profile_failed', __( 'Contact profile could not be loaded.', 'wphave' ), [ 'status' => 500 ] );
        }

        $first_name = $current['first_name'] ?: $profile['first_name'];
        $last_name = $current['last_name'] ?: $profile['last_name'];

        if ( $first_name === $current['first_name'] && $last_name === $current['last_name'] ) {
            return true;
        }

        $updated = $wpdb->update(
            $this->contacts_table,
            [
                'first_name' => $first_name,
                'last_name' => $last_name,
                'display_name' => trim( $first_name . ' ' . $last_name ),
                'updated_at' => current_time( 'mysql' ),
            ],
            [ 'id' => $contact_id ]
        );

        return false === $updated
            ? new WP_Error( 'wphave_audience_contact_profile_failed', __( 'Contact profile could not be updated.', 'wphave' ), [ 'status' => 500 ] )
            : true;
    }

    /**
     * Persists one immutable interaction using submission idempotency.
     *
     * Raw visitor and session ids are hashed before storage. Reusing a submission
     * id returns the original interaction unchanged.
     *
     * @param array $data Sanitized interaction source data and optional payload.
     * @return array|WP_Error Stored interaction or persistence error.
     */
    private function record_interaction( array $data ) {
        global $wpdb;

        $submission_id = sanitize_text_field( $data['submission_id'] ?? '' );

        if ( $submission_id ) {
            $existing = $wpdb->get_row(
                $wpdb->prepare( "SELECT * FROM {$this->interactions_table} WHERE submission_id = %s LIMIT 1", $submission_id ),
                ARRAY_A
            );

            if ( $existing ) {
                return $this->format_row( $existing );
            }
        }

        $now = current_time( 'mysql' );
        $occurred_at = sanitize_text_field( $data['occurred_at'] ?? '' );

        if ( ! preg_match( '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $occurred_at ) ) {
            $occurred_at = $now;
        }
        $row = [
            'public_id' => wp_generate_uuid4(),
            'submission_id' => $submission_id ?: wp_generate_uuid4(),
            'contact_id' => absint( $data['contact_id'] ?? 0 ),
            'type' => sanitize_key( $data['type'] ?? 'form_submission' ),
            'event' => sanitize_text_field( $data['event'] ?? '' ),
            'source' => sanitize_text_field( $data['source'] ?? '' ),
            'medium' => sanitize_text_field( $data['medium'] ?? '' ),
            'campaign' => sanitize_text_field( $data['campaign'] ?? '' ),
            'content' => sanitize_text_field( $data['content'] ?? '' ),
            'term' => sanitize_text_field( $data['term'] ?? '' ),
            'object_type' => sanitize_key( $data['object_type'] ?? '' ),
            'object_id' => absint( $data['object_id'] ?? 0 ),
            'object_subtype' => sanitize_key( $data['object_subtype'] ?? '' ),
            'object_key' => sanitize_text_field( $data['object_key'] ?? '' ),
            'object_label' => sanitize_text_field( $data['object_label'] ?? '' ),
            'object_url' => esc_url_raw( $data['object_url'] ?? '' ),
            'goal_id' => sanitize_key( $data['goal_id'] ?? '' ),
            'conversion_event_id' => absint( $data['conversion_event_id'] ?? 0 ),
            'landing_url' => esc_url_raw( $data['landing_url'] ?? '' ),
            'current_url' => esc_url_raw( $data['current_url'] ?? '' ),
            'referrer_url' => esc_url_raw( $data['referrer_url'] ?? '' ),
            'session_hash' => $this->hash_value( $data['session_id'] ?? '' ),
            'visitor_hash' => $this->hash_value( $data['visitor_id'] ?? '' ),
            'ip_hash' => $this->get_ip_hash(),
            'user_agent_hash' => $this->get_user_agent_hash(),
            'fingerprint' => sanitize_text_field( $data['fingerprint'] ?? '' ),
            'payload' => wp_json_encode( $this->sanitize_payload( $data['payload'] ?? [] ) ),
            'occurred_at' => $occurred_at,
            'created_at' => $now,
        ];

        if ( ! $wpdb->insert( $this->interactions_table, $row ) ) {
            return new WP_Error( 'wphave_audience_interaction_insert_failed', __( 'Interaction could not be stored.', 'wphave' ), [ 'status' => 500 ] );
        }

        $row['id'] = (int) $wpdb->insert_id;
        if ( ! $this->enqueue_domain_event( 'audience.interaction.recorded.v1', 'interaction', $row['public_id'], [ 'interaction_id' => $row['id'], 'contact_id' => $row['contact_id'] ] ) ) {
            return new WP_Error( 'wphave_audience_interaction_event_failed', __( 'Interaction event could not be queued.', 'wphave' ), [ 'status' => 500 ] );
        }

        return $this->format_row( $row );
    }

    /**
     * Creates a mutable operational lead in the default pipeline.
     *
     * The lead references, but never duplicates, its contact and immutable
     * origin interaction. Creation also appends an activity and outbox event.
     *
     * @param int $contact_id Contact id, or zero for an anonymous lead.
     * @param int $interaction_id Required origin interaction id.
     * @param array $data Lead title and optional original creation time.
     * @return array|WP_Error Lead row or a fail-closed configuration/storage error.
     */
    private function create_operational_lead( int $contact_id, int $interaction_id, array $data ) {
        global $wpdb;

        $stage = $wpdb->get_row(
            "SELECT s.id, s.pipeline_id FROM {$this->stages_table} s INNER JOIN {$this->pipelines_table} p ON p.id = s.pipeline_id WHERE p.is_default = 1 ORDER BY s.position ASC LIMIT 1",
            ARRAY_A
        );

        if ( ! $stage ) {
            $code = $wpdb->last_error
                ? 'wphave_audience_pipeline_read_failed'
                : 'wphave_audience_default_stage_missing';
            $message = $wpdb->last_error
                ? __( 'The default lead pipeline could not be loaded.', 'wphave' )
                : __( 'Configure a default lead pipeline stage before accepting leads.', 'wphave' );

            return new WP_Error( $code, $message, [ 'status' => 500 ] );
        }

        $now = current_time( 'mysql' );
		$created_at = sanitize_text_field( $data['created_at'] ?? '' );

		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $created_at ) ) {
			$created_at = $now;
		}
        $public_id = wp_generate_uuid4();
        $inserted = $wpdb->insert(
            $this->leads_table,
            [
                'public_id' => $public_id,
                'contact_id' => $contact_id,
                'origin_interaction_id' => $interaction_id,
                'pipeline_id' => absint( $stage['pipeline_id'] ),
                'stage_id' => absint( $stage['id'] ),
                'status' => 'open',
                'title' => sanitize_text_field( $data['title'] ?? __( 'New website lead', 'wphave' ) ),
                'priority' => 'normal',
                'created_at' => $created_at,
                'updated_at' => $now,
            ]
        );

        if ( ! $inserted ) {
            return new WP_Error( 'wphave_audience_lead_insert_failed', __( 'Lead could not be stored.', 'wphave' ), [ 'status' => 500 ] );
        }

        $lead_id = (int) $wpdb->insert_id;
        $activity_recorded = $this->record_activity(
            $contact_id,
            $lead_id,
            $interaction_id,
            'lead_created',
            [ 'stage_id' => absint( $stage['id'] ) ],
            $created_at
        );

        if ( ! $activity_recorded || ! $this->enqueue_domain_event( 'audience.lead.created.v1', 'lead', $public_id, [ 'lead_id' => $lead_id, 'contact_id' => $contact_id ] ) ) {
            return new WP_Error( 'wphave_audience_lead_graph_failed', __( 'Lead activity and event records could not be stored.', 'wphave' ), [ 'status' => 500 ] );
        }

        return $this->get_row( $this->leads_table, $lead_id );
    }

    /**
     * Appends an immutable internal activity to the contact/lead timeline.
     *
     * @param int $contact_id Related contact id.
     * @param int $lead_id Related lead id, or zero.
     * @param int $interaction_id Related interaction id, or zero.
     * @param string $type Stable activity type key.
     * @param array $payload Bounded structured activity data.
     * @return bool Whether the immutable activity was stored successfully.
     */
    private function record_activity( int $contact_id, int $lead_id, int $interaction_id, string $type, array $payload = [], string $occurred_at = '' ): bool {
        global $wpdb;

        // DATA INTEGRITY INVARIANT: Timeline types and explicit timestamps are
        // exact append-only identities and are never repaired before storage.
        $type = $this->normalize_closed_key(
            $type,
            [ 'lead_created', 'lead_updated', 'contact_merged', 'note' ]
        );
        $occurred_at = '' === $occurred_at
            ? current_time( 'mysql' )
            : $this->normalize_mysql_datetime( $occurred_at );
        $encoded_payload = $this->encode_activity_payload( $type, $payload );

        if ( '' === $type || '' === $occurred_at || false === $encoded_payload ) {
            return false;
        }

        return (bool) $wpdb->insert(
            $this->activities_table,
            [
                'contact_id' => $contact_id,
                'lead_id' => $lead_id,
                'interaction_id' => $interaction_id,
                'actor_user_id' => get_current_user_id(),
                'type' => $type,
                'visibility' => 'internal',
                'payload' => $encoded_payload,
                'occurred_at' => $occurred_at,
            ]
        );
    }

    /**
     * Encodes one activity payload without applying lossy generic truncation.
     *
     * DATA INTEGRITY INVARIANT: Lead notes are bounded multiline documents.
     * Generic activity payloads remain defensive telemetry maps, but note text
     * must never be silently shortened or have its line structure collapsed.
     *
     * @param string $type Validated activity type.
     * @param array  $payload Candidate activity payload.
     * @return string|false Encoded payload, or false for an invalid contract.
     */
    private function encode_activity_payload( string $type, array $payload ) {
        if ( 'note' === $type ) {
            if (
                [ 'note' ] !== array_keys( $payload )
                || ! is_string( $payload['note'] )
                || '' === $payload['note']
                || strlen( $payload['note'] ) > 20000
            ) {
                return false;
            }

            $normalized_payload = [ 'note' => $payload['note'] ];
        } else {
            $normalized_payload = $this->sanitize_payload( $payload );
        }

        $encoded_payload = wp_json_encode( $normalized_payload );

        return false !== $encoded_payload && strlen( $encoded_payload ) <= 60000
            ? $encoded_payload
            : false;
    }

    /**
     * Appends an immutable consent fact.
     *
     * Consent events are evidence; subscriber status is only the current
     * DATA INTEGRITY INVARIANT: Existing evidence is immutable and never updated in place.
     *
     * @param array $data Purpose, action, legal basis, statement and relations.
     * @return bool Whether the immutable fact was stored successfully.
     */
    private function record_consent_event( array $data ): bool {
        global $wpdb;

        // DATA INTEGRITY INVARIANT: Immutable consent facts retain exact purpose,
        // vocabulary, statement, evidence-reference and timestamp identities;
        // malformed audit input is never repaired into a different fact.
        $purpose = $this->normalize_purpose_key( $data['purpose_key'] ?? $data['purpose'] ?? '' );
        $action = $this->normalize_closed_key(
            $data['action'] ?? 'granted',
            [
                'requested',
                'granted',
                'granted_manually',
                'confirmed',
                'withdrawn',
                'confirmation_sent',
                'confirmation_failed',
            ]
        );
        $legal_basis = $this->normalize_closed_key(
            $data['legal_basis'] ?? 'consent',
            [
                'consent',
                'contract',
                'legal_obligation',
                'vital_interests',
                'public_task',
                'legitimate_interests',
            ]
        );
        $channel = $this->normalize_closed_key(
            $data['channel'] ?? 'email',
            [ 'email' ]
        );
        $raw_statement_key = $data['statement_key'] ?? '';
        $statement_key = '' === $raw_statement_key
            ? ''
            : $this->normalize_purpose_key( $raw_statement_key );
        $raw_statement_version = $data['statement_version'] ?? '1';
        $statement_version = is_scalar( $raw_statement_version )
            ? sanitize_text_field( (string) $raw_statement_version )
            : '';
        $raw_evidence_public_id = $data['evidence_public_id'] ?? '';
        $evidence_public_id = $this->normalize_uuid( $raw_evidence_public_id );
        $has_evidence_reference = '' !== $raw_evidence_public_id;
        $has_explicit_occurred_at = array_key_exists( 'occurred_at', $data );
        $occurred_at = $has_explicit_occurred_at
            ? $this->normalize_mysql_datetime( $data['occurred_at'] )
            : current_time( 'mysql' );
        $raw_source = $data['source'] ?? '';
        $source = is_scalar( $raw_source )
            ? sanitize_text_field( (string) $raw_source )
            : '';
        $source_length = function_exists( 'mb_strlen' ) ? mb_strlen( $source ) : strlen( $source );
        $raw_statement_snapshot = $data['statement_snapshot'] ?? '';
        $statement_snapshot = is_scalar( $raw_statement_snapshot )
            ? sanitize_textarea_field( (string) $raw_statement_snapshot )
            : '';

        if (
            '' === $purpose
            || '' === $action
            || '' === $legal_basis
            || '' === $channel
            || ( '' !== $raw_statement_key && '' === $statement_key )
            || '' === $statement_version
            || strlen( $statement_version ) > 50
            || (string) $raw_statement_version !== $statement_version
            || ( $has_evidence_reference && '' === $evidence_public_id )
            || '' === $occurred_at
            || ! is_scalar( $raw_source )
            || $source_length > 190
            || ! is_scalar( $raw_statement_snapshot )
            || strlen( $statement_snapshot ) > 60000
        ) {
            return false;
        }

        return (bool) $wpdb->insert(
            $this->consent_events_table,
            [
                'public_id' => wp_generate_uuid4(),
                'contact_id' => absint( $data['contact_id'] ?? 0 ),
                'subscriber_id' => absint( $data['subscriber_id'] ?? 0 ),
                'purpose_key' => $purpose,
                'action' => $action,
                'legal_basis' => $legal_basis,
                'channel' => $channel,
                'source' => $source,
                'statement_key' => $statement_key,
                'statement_version' => $statement_version,
                'statement_snapshot' => $statement_snapshot,
                'evidence_public_id' => $evidence_public_id,
                'occurred_at' => $occurred_at,
            ]
        );
    }

}
