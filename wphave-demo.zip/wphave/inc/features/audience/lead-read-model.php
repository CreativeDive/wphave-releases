<?php

/**
 * Audience lead read models.
 *
 * This module owns filtered lead queries and composition of immutable
 * interaction, contact identity and mutable workflow projections. It performs
 * no domain writes.
 *
 * @package wphave
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait WPHAVE_Audience_Lead_Read_Model_Trait {

    /**
     * Builds the paginated lead read model used by the administration UI.
     *
     * Workflow fields come from leads; submission and attribution fields come
     * from interactions; names and email identities come from contacts. Only
     * explicitly allowlisted filters and sort keys may reach SQL identifiers.
     *
     * @param WP_REST_Request $request List filters, search, sorting and paging.
     * @return array{items: array<int, array>, total: int, page: int, per_page: int, pages: int}
     */
    private function query_leads( WP_REST_Request $request ): array {
        global $wpdb;

        $page = max( 1, absint( $request->get_param( 'page' ) ?: 1 ) );
        $per_page = max( 1, min( 100, absint( $request->get_param( 'per_page' ) ?: 20 ) ) );
        $where = 'WHERE 1=1';
        $params = [];
        $filters = [
            'status' => 'l.status',
            'type' => 'i.type',
            'source' => 'i.source',
            'campaign' => 'i.campaign',
            'goal_id' => 'i.goal_id',
        ];

        foreach ( $filters as $parameter => $column ) {
            $value = sanitize_text_field( $request->get_param( $parameter ) ?? '' );

            if ( $value ) {
                $where .= " AND {$column} = %s";
                $params[] = $value;
            }
        }

        $search = sanitize_text_field( $request->get_param( 'search' ) ?? '' );

        if ( $search ) {
            $like = '%' . $wpdb->esc_like( $search ) . '%';
            $where .= ' AND (l.title LIKE %s OR i.event LIKE %s OR i.source LIKE %s OR i.object_label LIKE %s OR identity.value LIKE %s OR c.display_name LIKE %s)';
            $params = array_merge( $params, array_fill( 0, 6, $like ) );
        }

        $sorts = [
            'title' => 'l.title',
            'status' => 'l.status',
            'priority' => 'l.priority',
            'owner_user_id' => 'l.owner_user_id',
            'type' => 'i.type',
            'event' => 'i.event',
            'email' => 'identity.value',
            'source' => 'i.source',
            'goal_id' => 'i.goal_id',
            'object_label' => 'i.object_label',
            'created_at' => 'l.created_at',
            'updated_at' => 'l.updated_at',
        ];
        $orderby = $sorts[ sanitize_key( $request->get_param( 'orderby' ) ?? '' ) ] ?? 'l.created_at';
        $order = strtolower( sanitize_key( $request->get_param( 'order' ) ?? '' ) ) === 'asc' ? 'ASC' : 'DESC';
        $joins = "FROM {$this->leads_table} l LEFT JOIN {$this->interactions_table} i ON i.id = l.origin_interaction_id LEFT JOIN {$this->contacts_table} c ON c.id = l.contact_id LEFT JOIN {$this->identities_table} identity ON identity.contact_id = l.contact_id AND identity.type = 'email' AND identity.is_primary = 1";
        $count_query = "SELECT COUNT(DISTINCT l.id) {$joins} {$where}";
        $total = (int) $wpdb->get_var( $params ? $wpdb->prepare( $count_query, ...$params ) : $count_query );
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT l.* {$joins} {$where} GROUP BY l.id ORDER BY {$orderby} {$order}, l.id {$order} LIMIT %d OFFSET %d",
                ...array_merge( $params, [ $per_page, ( $page - 1 ) * $per_page ] )
            ),
            ARRAY_A
        ) ?: [];

        return [
            'items' => $this->decorate_lead_collection( $rows ),
            'total' => $total,
            'page' => $page,
            'per_page' => $per_page,
            'pages' => max( 1, (int) ceil( $total / $per_page ) ),
        ];
    }

    /**
     * Returns unfiltered lead totals grouped by canonical interaction type.
     *
     * @return array<string, int|string> Type keys mapped to database counts.
     */
    private function get_lead_type_counts(): array {
        global $wpdb;

        $rows = $wpdb->get_results(
            "SELECT i.type category, COUNT(*) total FROM {$this->leads_table} l INNER JOIN {$this->interactions_table} i ON i.id = l.origin_interaction_id GROUP BY i.type ORDER BY total DESC, i.type ASC",
            ARRAY_A
        ) ?: [];

        return array_column( $rows, 'total', 'category' );
    }

    /**
     * Returns the previously accepted lead for a retried submission.
     *
     * Submission identity belongs to the immutable interaction. Returning its
     * IDEMPOTENCY INVARIANT: The associated lead makes public and form retries converge.
     *
     * @param string $submission_id Stable client or server submission id.
     * @return array|WP_Error|null Decorated lead, read error, or null when absent.
     */
    private function find_lead_by_submission_id( string $submission_id ) {
        global $wpdb;

        $submission_id = sanitize_text_field( $submission_id );

        if ( ! $submission_id ) {
            return null;
        }

        if ( ! $this->table_exists( $this->interactions_table ) || ! $this->table_exists( $this->leads_table ) ) {
            return new WP_Error( 'wphave_audience_submission_lookup_unavailable', __( 'Submission state could not be verified.', 'wphave' ), [ 'status' => 503 ] );
        }

        $wpdb->last_error = '';
        $lead_id = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT l.id FROM {$this->leads_table} l INNER JOIN {$this->interactions_table} i ON i.id = l.origin_interaction_id WHERE i.submission_id = %s LIMIT 1",
                $submission_id
            )
        );

        // DATA INTEGRITY INVARIANT: An idempotency lookup that cannot read its
        // canonical stores is unknown, not absent. Every write boundary must stop
        // rather than risk duplicating an immutable submission graph.
        if ( $wpdb->last_error ) {
            return new WP_Error( 'wphave_audience_submission_lookup_unavailable', __( 'Submission state could not be verified.', 'wphave' ), [ 'status' => 503 ] );
        }

        if ( ! $lead_id ) {
            return null;
        }

        $lead = $this->get_row( $this->leads_table, absint( $lead_id ) );

        return $lead
            ? $this->decorate_lead( $lead )
            : new WP_Error( 'wphave_audience_submission_lookup_unavailable', __( 'Submission state could not be loaded consistently.', 'wphave' ), [ 'status' => 503 ] );
    }

    /**
     * Composes a stable lead read model from its canonical aggregates.
     *
     * This integration projection provides the fields consumed by Forms,
     * Analytics and the Audience UI without duplicating those fields in the
     * operational leads table.
     *
     * @param array|null $lead Raw operational lead row.
     * @return array|null Decorated lead or null for a missing input row.
     */
    private function decorate_lead( ?array $lead ): ?array {
        global $wpdb;

        if ( ! $lead ) {
            return null;
        }

        $interaction = absint( $lead['origin_interaction_id'] ?? 0 )
            ? $this->get_row( $this->interactions_table, absint( $lead['origin_interaction_id'] ) )
            : null;
        $contact = absint( $lead['contact_id'] ?? 0 )
            ? $this->get_row( $this->contacts_table, absint( $lead['contact_id'] ) )
            : null;
        $email = absint( $lead['contact_id'] ?? 0 )
            ? (string) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT value FROM {$this->identities_table} WHERE contact_id = %d AND type = 'email' ORDER BY is_primary DESC, id ASC LIMIT 1",
                    absint( $lead['contact_id'] )
                )
            )
            : '';

        return $this->compose_lead( $lead, $interaction, $contact, $email );
    }

    /**
     * Decorates a lead collection with three bounded relation lookups.
     *
     * @param array<int, array> $rows Raw lead rows.
     * @return array<int, array> Decorated lead read models.
     */
    private function decorate_lead_collection( array $rows ): array {
        if ( ! $rows ) {
            return [];
        }

        global $wpdb;

        $leads = array_map( [ $this, 'format_row' ], $rows );
        $interaction_ids = array_column( $leads, 'origin_interaction_id' );
        $contact_ids = array_values(
            array_unique( array_filter( array_map( 'absint', array_column( $leads, 'contact_id' ) ) ) )
        );
        $interactions = $this->get_rows_by_ids( $this->interactions_table, $interaction_ids );
        $contacts = $this->get_rows_by_ids( $this->contacts_table, $contact_ids );
        $emails = [];

        if ( $contact_ids ) {
            $placeholders = implode( ', ', array_fill( 0, count( $contact_ids ), '%d' ) );
            $identity_rows = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT contact_id, value FROM {$this->identities_table} WHERE contact_id IN ({$placeholders}) AND type = 'email' ORDER BY contact_id ASC, is_primary DESC, id ASC",
                    ...$contact_ids
                ),
                ARRAY_A
            ) ?: [];

            foreach ( $identity_rows as $identity ) {
                $contact_id = absint( $identity['contact_id'] ?? 0 );
                if ( $contact_id && ! isset( $emails[ $contact_id ] ) ) {
                    $emails[ $contact_id ] = (string) ( $identity['value'] ?? '' );
                }
            }
        }

        return array_values(
            array_map(
                function ( array $lead ) use ( $interactions, $contacts, $emails ): array {
                    $interaction_id = absint( $lead['origin_interaction_id'] ?? 0 );
                    $contact_id = absint( $lead['contact_id'] ?? 0 );

                    return $this->compose_lead(
                        $lead,
                        $interactions[ $interaction_id ] ?? null,
                        $contacts[ $contact_id ] ?? null,
                        $emails[ $contact_id ] ?? ''
                    );
                },
                $leads
            )
        );
    }

    /**
     * Composes one stable lead read model from preloaded relation rows.
     *
     * @param array      $lead Operational lead row.
     * @param array|null $interaction Origin interaction row.
     * @param array|null $contact Contact row.
     * @param string     $email Primary email identity.
     * @return array Decorated lead read model.
     */
    private function compose_lead(
        array $lead,
        ?array $interaction,
        ?array $contact,
        string $email
    ): array {
        return array_merge(
            $interaction ?: [],
            $lead,
            [
                'email' => $email,
                'avatar_url' => $email ? wphave_get_avatar_url( $email, [ 'size' => 48 ] ) : '',
                'first_name' => $contact['first_name'] ?? '',
                'last_name' => $contact['last_name'] ?? '',
                'object_label' => $interaction['object_label'] ?? $lead['title'],
            ]
        );
    }

}
