<?php

/**
 * Audience lead workflow application service.
 *
 * This module owns trusted fixture maintenance and administrative mutations of
 * mutable lead workflow state. Canonical contact, interaction and audit writes
 * remain in the domain service; aggregate deletion remains in contact lifecycle.
 *
 * DATA INTEGRITY INVARIANT: Workflow projection, immutable activity and outbox
 * intent commit as one unit whenever a workflow transition emits an event.
 *
 * @package wphave
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait WPHAVE_Audience_Lead_Workflow_Trait {

    /**
     * Removes a trusted synthetic campaign and contacts orphaned by that removal.
     *
     * This maintenance API is intentionally limited to server-owned fixtures.
     * It must never be exposed as a public campaign deletion endpoint.
     *
     * @param string $campaign Exact sanitized campaign identifier.
     * @return true|WP_Error True after an atomic cleanup or a fail-closed error.
     */
    public function delete_internal_campaign( string $campaign ) {
        global $wpdb;

        $normalized_campaign = sanitize_text_field( $campaign );

        /*
         * SECURITY INVARIANT: Destructive fixture cleanup accepts only one
         * exact, non-empty campaign identity. Markup or other lossy variants
         * must never collapse onto a different campaign and delete its graph.
         */
        if ( '' === $normalized_campaign || $campaign !== $normalized_campaign ) {
            return new WP_Error(
                'wphave_audience_internal_campaign_invalid',
                __( 'Synthetic campaign identity is invalid.', 'wphave' )
            );
        }

        $campaign = $normalized_campaign;
        if ( ! $this->begin_audience_transaction() ) {
            return new WP_Error(
                'wphave_audience_internal_campaign_delete_failed',
                __( 'Synthetic campaign could not be deleted atomically.', 'wphave' )
            );
        }

        try {
            $contact_ids = $this->internal_campaign_contact_ids( $campaign );
            $subscriber_ids = $this->internal_campaign_subscriber_ids( $campaign );

            foreach ( $subscriber_ids as $subscriber_id ) {
                $this->delete_subscriber_graph_rows( $subscriber_id );
            }

            $interactions = $this->internal_campaign_interactions( $campaign );

            foreach ( $interactions as $interaction ) {
                $interaction_id = absint( $interaction['id'] );
                $contact_ids[] = absint( $interaction['contact_id'] );
                $lead_ids = $this->interaction_lead_ids( $interaction_id );

                $this->delete_interaction_activity_rows( $interaction_id );

                foreach ( $lead_ids as $lead_id ) {
                    $this->delete_lead_graph_rows( $lead_id );
                }

                if ( 1 !== $wpdb->delete( $this->interactions_table, [ 'id' => $interaction_id ], [ '%d' ] ) ) {
                    throw new RuntimeException( 'Synthetic interaction deletion failed.' );
                }
            }

            foreach ( array_unique( array_filter( $contact_ids ) ) as $contact_id ) {
                if ( 0 === $this->contact_audience_reference_count( $contact_id ) ) {
                    $contact = $this->get_row( $this->contacts_table, $contact_id );

                    if ( ! $contact || 'merged' === $contact['status'] ) {
                        throw new RuntimeException( 'Synthetic contact ownership could not be verified.' );
                    }

                    $this->delete_contact_graph_rows( $contact );
                }
            }

            if ( ! $this->commit_audience_transaction() ) {
                throw new RuntimeException( 'Synthetic campaign transaction could not be committed.' );
            }
        } catch ( Throwable $error ) {
            $this->rollback_audience_transaction();

            return new WP_Error(
                'wphave_audience_internal_campaign_delete_failed',
                __( 'Synthetic campaign could not be deleted atomically.', 'wphave' )
            );
        }

        return true;
    }

    /** @return array<int, int> Contact ids referenced by campaign subscribers. */
    private function internal_campaign_contact_ids( string $campaign ): array {
        global $wpdb;

        $wpdb->last_error = '';
        $ids = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT DISTINCT contact_id FROM {$this->subscribers_table} WHERE campaign = %s",
                $campaign
            )
        );

        if ( null === $ids || $wpdb->last_error ) {
            throw new RuntimeException( 'Synthetic contact references could not be read.' );
        }

        return array_map( 'absint', $ids );
    }

    /** @return array<int, int> Subscriber ids owned by one synthetic campaign. */
    private function internal_campaign_subscriber_ids( string $campaign ): array {
        global $wpdb;

        $wpdb->last_error = '';
        $ids = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT id FROM {$this->subscribers_table} WHERE campaign = %s",
                $campaign
            )
        );

        if ( null === $ids || $wpdb->last_error ) {
            throw new RuntimeException( 'Synthetic subscribers could not be read.' );
        }

        return array_map( 'absint', $ids );
    }

    /** @return array<int, array{id: string, contact_id: string}> Campaign interactions. */
    private function internal_campaign_interactions( string $campaign ): array {
        global $wpdb;

        $wpdb->last_error = '';
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, contact_id FROM {$this->interactions_table} WHERE campaign = %s",
                $campaign
            ),
            ARRAY_A
        );

        if ( null === $rows || $wpdb->last_error ) {
            throw new RuntimeException( 'Synthetic interactions could not be read.' );
        }

        return $rows;
    }

    /** @return array<int, int> Lead ids owned by one origin interaction. */
    private function interaction_lead_ids( int $interaction_id ): array {
        global $wpdb;

        $wpdb->last_error = '';
        $ids = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT id FROM {$this->leads_table} WHERE origin_interaction_id = %d",
                $interaction_id
            )
        );

        if ( null === $ids || $wpdb->last_error ) {
            throw new RuntimeException( 'Synthetic leads could not be read.' );
        }

        return array_map( 'absint', $ids );
    }

    /** Returns remaining contact references that block orphan cleanup. */
    private function contact_audience_reference_count( int $contact_id ): int {
        global $wpdb;

        $wpdb->last_error = '';
        $references = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT (SELECT COUNT(*) FROM {$this->interactions_table} WHERE contact_id = %d) + (SELECT COUNT(*) FROM {$this->subscribers_table} WHERE contact_id = %d)",
                $contact_id,
                $contact_id
            )
        );

        if ( null === $references || $wpdb->last_error ) {
            throw new RuntimeException( 'Synthetic contact references could not be counted.' );
        }

        return (int) $references;
    }

    /**
     * Configure workflow fields for a trusted synthetic lead.
     *
     * The campaign guard prevents this internal fixture API from mutating
     * unrelated Audience records.
     *
     * @param int                  $lead_id Lead database id.
     * @param string               $campaign Exact owning campaign.
     * @param array<string, mixed> $data Workflow fields and event time.
     * @return bool|WP_Error Whether the workflow was updated.
     */
    public function configure_internal_lead( int $lead_id, string $campaign, array $data ) {
        global $wpdb;

        $lead = $this->get_row( $this->leads_table, $lead_id );
        $stored_campaign = $lead
            ? (string) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT campaign FROM {$this->interactions_table} WHERE id = %d",
                    absint( $lead['origin_interaction_id'] ?? 0 )
                )
            )
            : '';

        if ( ! $lead || ! $campaign || $stored_campaign !== $campaign ) {
            return new WP_Error( 'wphave_audience_internal_lead_invalid', __( 'Synthetic lead ownership could not be verified.', 'wphave' ) );
        }

        $status = $this->normalize_closed_key(
            $data['status'] ?? 'open',
            [ 'open', 'qualified', 'won', 'lost', 'archived' ]
        );
        $priority = $this->normalize_closed_key(
            $data['priority'] ?? 'normal',
            [ 'low', 'normal', 'high' ]
        );
        $stage_key = $this->normalize_purpose_key( $data['stage'] ?? 'new' );
        $stage = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT s.id, s.outcome FROM {$this->stages_table} s INNER JOIN {$this->pipelines_table} p ON p.id = s.pipeline_id WHERE p.is_default = 1 AND s.pipeline_id = %d AND s.stage_key = %s LIMIT 1",
                absint( $lead['pipeline_id'] ),
                $stage_key
            ),
            ARRAY_A
        );
        $stage_id = absint( $stage['id'] ?? 0 );
        $stage_outcome = (string) ( $stage['outcome'] ?? '' );
        $occurred_at = array_key_exists( 'occurred_at', $data )
            ? $this->normalize_mysql_datetime( $data['occurred_at'] )
            : current_time( 'mysql' );
        $raw_lost_reason = $data['lost_reason'] ?? '';
        $lost_reason = is_scalar( $raw_lost_reason )
            ? sanitize_text_field( (string) $raw_lost_reason )
            : '';
        $lost_reason_length = function_exists( 'mb_strlen' )
            ? mb_strlen( $lost_reason )
            : strlen( $lost_reason );

        if (
            '' === $status
            || '' === $priority
            || '' === $stage_key
            || 0 === $stage_id
            || ! $this->workflow_stage_accepts_status( $stage_outcome, $status )
            || '' === $occurred_at
            || ! is_scalar( $raw_lost_reason )
            || $lost_reason_length > 255
            || ( 'lost' !== $status && '' !== $lost_reason )
        ) {
            return new WP_Error( 'wphave_audience_internal_lead_workflow_invalid', __( 'Synthetic lead workflow values are invalid.', 'wphave' ) );
        }

        $row = array_merge(
            [
                'stage_id' => $stage_id,
                'status' => $status,
                'priority' => $priority,
                'updated_at' => $occurred_at,
            ],
            $this->workflow_milestone_fields(
                $lead,
                $status,
                $lost_reason,
                $occurred_at
            )
        );

        $changed_fields = $this->workflow_changed_fields( $lead, $row );

        if ( ! $changed_fields ) {
            return true;
        }

        $event_name = $this->workflow_event_name( $changed_fields );

        // DATA INTEGRITY INVARIANT: Trusted workflow configuration uses the same
        // projection/activity/outbox commit unit as the administrative endpoint.
        if ( ! $this->begin_audience_transaction() ) {
            return new WP_Error(
                'wphave_audience_internal_lead_update_failed',
                __( 'Synthetic lead workflow could not be updated atomically.', 'wphave' )
            );
        }

        $updated = $wpdb->update( $this->leads_table, $row, [ 'id' => $lead_id ] );
        $activity_recorded = false !== $updated && $this->record_activity(
            absint( $lead['contact_id'] ),
            $lead_id,
            0,
            'lead_updated',
            $row,
            $occurred_at
        );
        $event_recorded = $activity_recorded && $this->enqueue_domain_event(
            $event_name,
            'lead',
            $lead['public_id'],
            [
                'lead_id' => $lead_id,
                'status' => $status,
                'stage_id' => $row['stage_id'] ?? absint( $lead['stage_id'] ),
                'changed_fields' => $changed_fields,
            ]
        );

        if ( false === $updated || ! $activity_recorded || ! $event_recorded ) {
            $this->rollback_audience_transaction();

            return new WP_Error(
                'wphave_audience_internal_lead_update_failed',
                __( 'Synthetic lead workflow could not be updated atomically.', 'wphave' )
            );
        }

        if ( ! $this->commit_audience_transaction() ) {
            $this->rollback_audience_transaction();

            return new WP_Error(
                'wphave_audience_internal_lead_update_failed',
                __( 'Synthetic lead workflow could not be updated atomically.', 'wphave' )
            );
        }

        return true;
    }

    /**
     * Updates mutable workflow state without changing submission evidence.
     *
     * Every accepted change appends an activity and enqueues a domain event.
     * Status values are allowlisted; invalid values retain the current state.
     *
     * @param WP_REST_Request $request Lead id and workflow fields.
     * @return WP_REST_Response|WP_Error Updated lead projection or missing error.
     */
    public function update_lead_workflow_endpoint( WP_REST_Request $request ) {
        global $wpdb;

        if ( ! $this->manage_permission_check() ) {
            return $this->audience_access_error();
        }

        $lead_id = absint( $request['id'] );
        $lead = $this->get_row( $this->leads_table, $lead_id );

        if ( ! $lead ) {
            return new WP_Error( 'wphave_audience_lead_missing', __( 'Lead was not found.', 'wphave' ), [ 'status' => 404 ] );
        }

        $data = $request->get_json_params();
        $data = is_array( $data ) ? $data : [];
        // DATA INTEGRITY INVARIANT: Workflow state is validated completely before
        // mutable state, immutable activity and outbox intent are written together.
        $status = $this->normalize_closed_key(
            $data['status'] ?? $lead['status'],
            [ 'open', 'qualified', 'won', 'lost', 'archived' ]
        );
        $priority = $this->normalize_closed_key(
            $data['priority'] ?? $lead['priority'],
            [ 'low', 'normal', 'high' ]
        );
        $stage_id = $this->normalize_non_negative_integer( $data['stage_id'] ?? $lead['stage_id'] );
        $owner_user_id = $this->normalize_non_negative_integer( $data['owner_user_id'] ?? $lead['owner_user_id'] );
        $raw_next_action_at = $data['next_action_at'] ?? $lead['next_action_at'];
        $next_action_at = null === $raw_next_action_at || '' === $raw_next_action_at
            ? null
            : $this->normalize_mysql_datetime( $raw_next_action_at );
        $has_lost_reason = array_key_exists( 'lost_reason', $data );
        $raw_lost_reason = $has_lost_reason
            ? $data['lost_reason']
            : ( 'lost' === $status ? $lead['lost_reason'] : '' );
        $lost_reason = is_scalar( $raw_lost_reason )
            ? sanitize_text_field( (string) $raw_lost_reason )
            : '';
        $lost_reason_length = function_exists( 'mb_strlen' ) ? mb_strlen( $lost_reason ) : strlen( $lost_reason );
        // DATA INTEGRITY INVARIANT: A stage is meaningful only inside the
        // pipeline owned by the lead. Cross-pipeline stage references would
        // create a contradictory workflow projection for every downstream read.
        $stage_outcome = null !== $stage_id && $stage_id > 0
            ? $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT outcome FROM {$this->stages_table} WHERE id = %d AND pipeline_id = %d LIMIT 1",
                    $stage_id,
                    absint( $lead['pipeline_id'] )
                )
            )
            : null;

        if (
            '' === $status
            || '' === $priority
            || ! is_string( $stage_outcome )
            || ! $this->workflow_stage_accepts_status( $stage_outcome, $status )
            || null === $owner_user_id
            || ! $this->lead_owner_exists( $owner_user_id )
            || ( null !== $raw_next_action_at && '' !== $raw_next_action_at && '' === $next_action_at )
            || ! is_scalar( $raw_lost_reason )
            || $lost_reason_length > 255
            || ( $has_lost_reason && 'lost' !== $status && '' !== $lost_reason )
        ) {
            return new WP_Error( 'wphave_audience_workflow_invalid', __( 'One or more workflow values are invalid.', 'wphave' ), [ 'status' => 400 ] );
        }

        $updated_at = current_time( 'mysql' );
        $row = array_merge(
            [
                'stage_id' => $stage_id,
                'owner_user_id' => $owner_user_id,
                'status' => $status,
                'priority' => $priority,
                'next_action_at' => $next_action_at,
                'updated_at' => $updated_at,
            ],
            $this->workflow_milestone_fields(
                $lead,
                $status,
                $lost_reason,
                $updated_at
            )
        );

        $changed_fields = $this->workflow_changed_fields( $lead, $row );

        if ( ! $changed_fields ) {
            return rest_ensure_response( [ 'item' => $this->decorate_lead( $lead ) ] );
        }

        $event_name = $this->workflow_event_name( $changed_fields );

        /*
         * DATA INTEGRITY INVARIANT: A workflow revision consists of the mutable
         * lead projection, one immutable activity and one reliable domain event.
         * No caller may observe success before all three commit together.
         */
        if ( ! $this->begin_audience_transaction() ) {
            return new WP_Error(
                'wphave_audience_lead_update_failed',
                __( 'Lead workflow could not be updated atomically.', 'wphave' ),
                [ 'status' => 500 ]
            );
        }

        $updated = $wpdb->update( $this->leads_table, $row, [ 'id' => $lead_id ] );
        $activity_recorded = false !== $updated && $this->record_activity( absint( $lead['contact_id'] ), $lead_id, 0, 'lead_updated', $row );
        $event_recorded = $activity_recorded && $this->enqueue_domain_event(
            $event_name,
            'lead',
            $lead['public_id'],
            [
                'lead_id' => $lead_id,
                'status' => $status,
                'stage_id' => $row['stage_id'],
                'changed_fields' => $changed_fields,
            ]
        );

        if ( false === $updated || ! $activity_recorded || ! $event_recorded ) {
            $this->rollback_audience_transaction();

            return new WP_Error(
                'wphave_audience_lead_update_failed',
                __( 'Lead workflow could not be updated atomically.', 'wphave' ),
                [ 'status' => 500 ]
            );
        }

        if ( ! $this->commit_audience_transaction() ) {
            $this->rollback_audience_transaction();

            return new WP_Error(
                'wphave_audience_lead_update_failed',
                __( 'Lead workflow could not be updated atomically.', 'wphave' ),
                [ 'status' => 500 ]
            );
        }

        return rest_ensure_response( [ 'item' => $this->decorate_lead( $this->get_row( $this->leads_table, $lead_id ) ) ] );
    }

    /**
     * Verifies the semantic contract between a stage outcome and lead status.
     *
     * Open stages may represent open or qualified work. Terminal stages must
     * match their terminal status. Archived leads retain their last stage so
     * archiving remains an orthogonal lifecycle operation.
     *
     * @param string $stage_outcome Stored stage outcome.
     * @param string $status Candidate lead status.
     * @return bool Whether the workflow projection is internally consistent.
     */
    private function workflow_stage_accepts_status( string $stage_outcome, string $status ): bool {
        if ( 'archived' === $status ) {
            return in_array( $stage_outcome, [ 'open', 'won', 'lost' ], true );
        }

        if ( 'open' === $stage_outcome ) {
            return in_array( $status, [ 'open', 'qualified' ], true );
        }

        return in_array( $stage_outcome, [ 'won', 'lost' ], true )
            && $stage_outcome === $status;
    }

    /**
     * Derives the mutable workflow projection from one accepted transition.
     *
     * DATA INTEGRITY INVARIANT: Qualification is a durable milestone. Closure
     * and loss metadata describe the current terminal state and are cleared on
     * reopening. Archiving preserves the final state without fabricating one.
     *
     * @param array  $lead Existing lead projection.
     * @param string $status Accepted target status.
     * @param string $lost_reason Validated loss reason.
     * @param string $occurred_at Canonical transition time.
     * @return array{qualified_at: ?string, closed_at: ?string, lost_reason: string}
     */
    private function workflow_milestone_fields(
        array $lead,
        string $status,
        string $lost_reason,
        string $occurred_at
    ): array {
        $qualified_at = $lead['qualified_at'] ?: null;

        if ( 'qualified' === $status && null === $qualified_at ) {
            $qualified_at = $occurred_at;
        }

        $closed_at = null;

        if ( in_array( $status, [ 'won', 'lost' ], true ) ) {
            $closed_at = in_array( $lead['status'], [ 'won', 'lost' ], true ) && $lead['closed_at']
                ? $lead['closed_at']
                : $occurred_at;
        } elseif ( 'archived' === $status ) {
            $closed_at = $lead['closed_at'] ?: null;
            $lost_reason = $lead['lost_reason'];
        } else {
            $lost_reason = '';
        }

        return [
            'qualified_at' => $qualified_at,
            'closed_at' => $closed_at,
            'lost_reason' => 'lost' === $status || 'archived' === $status
                ? $lost_reason
                : '',
        ];
    }

    /**
     * Detects a material workflow projection change before opening a transaction.
     *
     * IDEMPOTENCY INVARIANT: Repeating an accepted representation must not
     * fabricate an activity, advance updated_at or enqueue a domain event.
     * Database null and empty nullable timestamps represent the same state.
     *
     * @param array $lead Existing lead projection.
     * @param array $candidate Validated candidate projection.
     * @return array<int, string> Materially changed projection fields.
     */
    private function workflow_changed_fields( array $lead, array $candidate ): array {
        $changed_fields = [];

        foreach ( $candidate as $field => $candidate_value ) {
            if ( 'updated_at' === $field ) {
                continue;
            }

            $current_value = $lead[ $field ] ?? null;

            if ( in_array( $field, [ 'stage_id', 'owner_user_id' ], true ) ) {
                $current_value = absint( $current_value );
                $candidate_value = absint( $candidate_value );
            } elseif ( in_array( $field, [ 'next_action_at', 'qualified_at', 'closed_at' ], true ) ) {
                $current_value = $current_value ?: null;
                $candidate_value = $candidate_value ?: null;
            } else {
                $current_value = (string) $current_value;
                $candidate_value = (string) $candidate_value;
            }

            if ( $current_value !== $candidate_value ) {
                $changed_fields[] = $field;
            }
        }

        return $changed_fields;
    }

    /**
     * Selects the narrowest versioned event contract for one workflow revision.
     *
     * EVENT INVARIANT: Stage-change consumers are notified only when stage or
     * status changed. Other mutable fields use the generic workflow event so
     * automations never infer a transition that did not occur.
     *
     * @param array<int, string> $changed_fields Material projection changes.
     * @return string Versioned Audience domain event name.
     */
    private function workflow_event_name( array $changed_fields ): string {
        return array_intersect( [ 'stage_id', 'status' ], $changed_fields )
            ? 'audience.lead.stage_changed.v1'
            : 'audience.lead.workflow_updated.v1';
    }

    /**
     * Verifies that a lead owner belongs to the current WordPress workspace.
     *
     * DATA INTEGRITY INVARIANT: Zero represents an unassigned lead. Every
     * persisted owner id must resolve to a live user and, in multisite, to a
     * member of the current site so filters and notifications never target a
     * phantom or cross-workspace identity.
     *
     * @param int $owner_user_id Candidate owner id, or zero.
     * @return bool Whether the owner identity may be persisted.
     */
    private function lead_owner_exists( int $owner_user_id ): bool {
        if ( 0 === $owner_user_id ) {
            return true;
        }

        if ( false === get_userdata( $owner_user_id ) ) {
            return false;
        }

        return ! is_multisite()
            || is_user_member_of_blog( $owner_user_id, get_current_blog_id() );
    }

    /**
     * Appends an immutable internal note to a lead timeline.
     *
     * @param WP_REST_Request $request Lead id and non-empty note.
     * @return WP_REST_Response|WP_Error Success or validation error.
     */
    public function add_lead_note_endpoint( WP_REST_Request $request ) {
        if ( ! $this->manage_permission_check() ) {
            return $this->audience_access_error();
        }

        $lead = $this->get_row( $this->leads_table, absint( $request['id'] ) );

        if ( ! $lead ) {
            return new WP_Error( 'wphave_audience_lead_missing', __( 'Lead was not found.', 'wphave' ), [ 'status' => 404 ] );
        }

        $raw_note = $request->get_param( 'note' );
        $note = is_scalar( $raw_note )
            ? sanitize_textarea_field( (string) $raw_note )
            : '';
        $note_length = function_exists( 'mb_strlen' )
            ? mb_strlen( $note )
            : strlen( $note );

        if ( ! is_scalar( $raw_note ) || '' === $note || $note_length > 5000 ) {
            return new WP_Error(
                'wphave_audience_note_invalid',
                __( 'A note between 1 and 5000 characters is required.', 'wphave' ),
                [ 'status' => 400 ]
            );
        }

        if ( ! $this->record_activity( absint( $lead['contact_id'] ), absint( $lead['id'] ), 0, 'note', [ 'note' => $note ] ) ) {
            return new WP_Error( 'wphave_audience_note_failed', __( 'The lead note could not be stored.', 'wphave' ), [ 'status' => 500 ] );
        }

        return rest_ensure_response( [ 'success' => true ] );
    }

}
