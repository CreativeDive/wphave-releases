<?php

/**
 * Schema helpers for the canonical Audience domain.
 *
 * @package wphave
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Owns schema installation and readiness checks.
 */

trait WPHAVE_Audience_Schema_Trait {

    /**
     * Create or update all canonical Audience tables and seed reference data.
     *
     * @return void
     */

    public function install(): void {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset = $wpdb->get_charset_collate();

        $leads = "CREATE TABLE {$this->leads_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            public_id char(36) NOT NULL,
            contact_id bigint(20) unsigned NOT NULL DEFAULT 0,
            origin_interaction_id bigint(20) unsigned NOT NULL DEFAULT 0,
            pipeline_id bigint(20) unsigned NOT NULL DEFAULT 0,
            stage_id bigint(20) unsigned NOT NULL DEFAULT 0,
            status varchar(20) NOT NULL DEFAULT 'open',
            owner_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            title varchar(255) NOT NULL DEFAULT '',
            value decimal(18,2) DEFAULT NULL,
            currency char(3) NOT NULL DEFAULT '',
            score decimal(8,2) DEFAULT NULL,
            priority varchar(20) NOT NULL DEFAULT 'normal',
            next_action_at datetime DEFAULT NULL,
            qualified_at datetime DEFAULT NULL,
            closed_at datetime DEFAULT NULL,
            lost_reason varchar(255) NOT NULL DEFAULT '',
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY public_id (public_id),
            KEY contact_created (contact_id,created_at),
            KEY pipeline_stage (pipeline_id,stage_id),
            KEY status_updated (status,updated_at),
            KEY status_created (status,created_at),
            KEY owner_status (owner_user_id,status),
            KEY origin_interaction (origin_interaction_id)
        ) ENGINE=InnoDB {$charset};";

        $subscribers = "CREATE TABLE {$this->subscribers_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            email varchar(190) NOT NULL,
            email_hash char(64) NOT NULL DEFAULT '',
            first_name varchar(100) NOT NULL DEFAULT '',
            last_name varchar(100) NOT NULL DEFAULT '',
            status varchar(20) NOT NULL DEFAULT 'subscribed',
            purpose varchar(100) NOT NULL DEFAULT '',
            source varchar(100) NOT NULL DEFAULT '',
            medium varchar(100) NOT NULL DEFAULT '',
            campaign varchar(150) NOT NULL DEFAULT '',
            lead_id bigint(20) unsigned NOT NULL DEFAULT 0,
            consent tinyint(1) unsigned NOT NULL DEFAULT 0,
            consent_label varchar(255) NOT NULL DEFAULT '',
            consent_at datetime DEFAULT NULL,
            confirm_token_hash char(64) NOT NULL DEFAULT '',
            confirm_expires_at datetime DEFAULT NULL,
            contact_id bigint(20) unsigned NOT NULL DEFAULT 0,
            confirmed_at datetime DEFAULT NULL,
            unsubscribed_at datetime DEFAULT NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY email_hash_purpose (email_hash,purpose),
            KEY email (email),
            KEY email_hash (email_hash),
            KEY status (status),
            KEY status_created (status,created_at),
            KEY status_unsubscribed (status,unsubscribed_at),
            KEY purpose (purpose),
            KEY source (source),
            KEY lead_id (lead_id),
            KEY contact_id (contact_id),
            KEY confirm_token_hash (confirm_token_hash)
        ) ENGINE=InnoDB {$charset};";

        $contacts = "CREATE TABLE {$this->contacts_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            public_id char(36) NOT NULL,
            display_name varchar(255) NOT NULL DEFAULT '',
            first_name varchar(100) NOT NULL DEFAULT '',
            last_name varchar(100) NOT NULL DEFAULT '',
            organization varchar(190) NOT NULL DEFAULT '',
            job_title varchar(190) NOT NULL DEFAULT '',
            locale varchar(20) NOT NULL DEFAULT '',
            timezone varchar(100) NOT NULL DEFAULT '',
            status varchar(20) NOT NULL DEFAULT 'active',
            merged_into_contact_id bigint(20) unsigned NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY public_id (public_id),
            KEY status (status),
            KEY merged_into (merged_into_contact_id)
        ) ENGINE=InnoDB {$charset};";

        $identities = "CREATE TABLE {$this->identities_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            contact_id bigint(20) unsigned NOT NULL,
            type varchar(40) NOT NULL,
            provider varchar(100) NOT NULL DEFAULT '',
            value varchar(255) NOT NULL DEFAULT '',
            normalized_value varchar(255) NOT NULL DEFAULT '',
            value_hash char(64) NOT NULL,
            verification_status varchar(20) NOT NULL DEFAULT 'unverified',
            verified_at datetime DEFAULT NULL,
            is_primary tinyint(1) unsigned NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY type_hash (type,value_hash),
            KEY contact_type (contact_id,type)
        ) ENGINE=InnoDB {$charset};";

        $interactions = "CREATE TABLE {$this->interactions_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            public_id char(36) NOT NULL,
            submission_id varchar(100) NOT NULL,
            contact_id bigint(20) unsigned NOT NULL DEFAULT 0,
            type varchar(50) NOT NULL,
            event varchar(100) NOT NULL DEFAULT '',
            source varchar(100) NOT NULL DEFAULT '',
            medium varchar(100) NOT NULL DEFAULT '',
            campaign varchar(150) NOT NULL DEFAULT '',
            content varchar(150) NOT NULL DEFAULT '',
            term varchar(150) NOT NULL DEFAULT '',
            object_type varchar(40) NOT NULL DEFAULT '',
            object_id bigint(20) unsigned NOT NULL DEFAULT 0,
            object_subtype varchar(100) NOT NULL DEFAULT '',
            object_key varchar(190) NOT NULL DEFAULT '',
            object_label varchar(255) NOT NULL DEFAULT '',
            object_url text DEFAULT NULL,
            goal_id varchar(190) NOT NULL DEFAULT '',
            conversion_event_id bigint(20) unsigned NOT NULL DEFAULT 0,
            landing_url text DEFAULT NULL,
            current_url text DEFAULT NULL,
            referrer_url text DEFAULT NULL,
            visitor_hash char(64) NOT NULL DEFAULT '',
            session_hash char(64) NOT NULL DEFAULT '',
            ip_hash char(64) NOT NULL DEFAULT '',
            user_agent_hash char(64) NOT NULL DEFAULT '',
            fingerprint char(64) NOT NULL DEFAULT '',
            payload longtext DEFAULT NULL,
            occurred_at datetime NOT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY public_id (public_id),
            UNIQUE KEY submission_id (submission_id),
            KEY contact_created (contact_id,created_at),
            KEY contact_occurred (contact_id,occurred_at),
            KEY type_created (type,created_at),
            KEY session_created (session_hash,created_at),
            KEY campaign_created (campaign,created_at),
            KEY goal_id (goal_id),
            KEY conversion_event_id (conversion_event_id),
            KEY fingerprint (fingerprint)
        ) ENGINE=InnoDB {$charset};";

        $pipelines = "CREATE TABLE {$this->pipelines_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            pipeline_key varchar(100) NOT NULL,
            label varchar(190) NOT NULL,
            is_default tinyint(1) unsigned NOT NULL DEFAULT 0,
            is_active tinyint(1) unsigned NOT NULL DEFAULT 1,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY pipeline_key (pipeline_key)
        ) ENGINE=InnoDB {$charset};";

        $stages = "CREATE TABLE {$this->stages_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            pipeline_id bigint(20) unsigned NOT NULL,
            stage_key varchar(100) NOT NULL,
            label varchar(190) NOT NULL,
            position int unsigned NOT NULL DEFAULT 0,
            outcome varchar(20) NOT NULL DEFAULT 'open',
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY pipeline_stage (pipeline_id,stage_key),
            KEY pipeline_position (pipeline_id,position)
        ) ENGINE=InnoDB {$charset};";

        $activities = "CREATE TABLE {$this->activities_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            contact_id bigint(20) unsigned NOT NULL DEFAULT 0,
            lead_id bigint(20) unsigned NOT NULL DEFAULT 0,
            interaction_id bigint(20) unsigned NOT NULL DEFAULT 0,
            actor_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            type varchar(50) NOT NULL,
            visibility varchar(20) NOT NULL DEFAULT 'internal',
            payload longtext DEFAULT NULL,
            occurred_at datetime NOT NULL,
            PRIMARY KEY (id),
            KEY contact_occurred (contact_id,occurred_at),
            KEY lead_occurred (lead_id,occurred_at),
            KEY interaction_occurred (interaction_id,occurred_at)
        ) ENGINE=InnoDB {$charset};";

        $purposes = "CREATE TABLE {$this->purposes_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            purpose_key varchar(100) NOT NULL,
            label varchar(190) NOT NULL,
            description text DEFAULT NULL,
            channel varchar(40) NOT NULL DEFAULT 'email',
            requires_double_opt_in tinyint(1) unsigned NOT NULL DEFAULT 1,
            retention_days int unsigned NOT NULL DEFAULT 0,
            is_active tinyint(1) unsigned NOT NULL DEFAULT 1,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY purpose_key (purpose_key)
        ) ENGINE=InnoDB {$charset};";

        $consent_events = "CREATE TABLE {$this->consent_events_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            public_id char(36) NOT NULL,
            contact_id bigint(20) unsigned NOT NULL DEFAULT 0,
            subscriber_id bigint(20) unsigned NOT NULL DEFAULT 0,
            purpose_key varchar(100) NOT NULL DEFAULT '',
            action varchar(30) NOT NULL,
            legal_basis varchar(50) NOT NULL DEFAULT 'consent',
            channel varchar(40) NOT NULL DEFAULT 'email',
            source varchar(190) NOT NULL DEFAULT '',
            statement_key varchar(100) NOT NULL DEFAULT '',
            statement_version varchar(50) NOT NULL DEFAULT '',
            statement_snapshot text DEFAULT NULL,
            evidence_public_id char(36) NOT NULL DEFAULT '',
            occurred_at datetime NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY public_id (public_id),
            KEY contact_occurred (contact_id,occurred_at),
            KEY subscriber_occurred (subscriber_id,occurred_at)
        ) ENGINE=InnoDB {$charset};";

        $consent_evidence = "CREATE TABLE {$this->consent_evidence_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            public_id char(36) NOT NULL,
            subscriber_id bigint(20) unsigned NOT NULL DEFAULT 0,
            contact_id bigint(20) unsigned NOT NULL DEFAULT 0,
            recipient_email varchar(190) NOT NULL,
            purpose_key varchar(100) NOT NULL DEFAULT '',
            legal_basis varchar(50) NOT NULL DEFAULT 'consent',
            statement_key varchar(100) NOT NULL DEFAULT '',
            statement_version varchar(50) NOT NULL DEFAULT '',
            statement_snapshot text NOT NULL,
            template_key varchar(100) NOT NULL DEFAULT '',
            template_version varchar(50) NOT NULL DEFAULT '',
            locale varchar(20) NOT NULL DEFAULT '',
            subject text NOT NULL,
            sender_snapshot text DEFAULT NULL,
            message_snapshot longtext NOT NULL,
            message_hash char(64) NOT NULL,
            confirmation_url_hash char(64) NOT NULL,
            delivery_status varchar(20) NOT NULL DEFAULT 'unknown',
            sent_at datetime NOT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY public_id (public_id),
            KEY subscriber_sent (subscriber_id,sent_at),
            KEY contact_sent (contact_id,sent_at)
        ) ENGINE=InnoDB {$charset};";

        $outbox = "CREATE TABLE {$this->outbox_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            event_id char(36) NOT NULL,
            event_name varchar(190) NOT NULL,
            aggregate_type varchar(50) NOT NULL,
            aggregate_id varchar(100) NOT NULL,
            payload longtext DEFAULT NULL,
            status varchar(20) NOT NULL DEFAULT 'pending',
            attempts int unsigned NOT NULL DEFAULT 0,
            available_at datetime NOT NULL,
            claim_token char(36) NOT NULL DEFAULT '',
            claimed_at datetime DEFAULT NULL,
            delivered_at datetime DEFAULT NULL,
            last_error text DEFAULT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY event_id (event_id),
            KEY delivery (status,available_at),
            KEY claim_lease (status,claimed_at)
        ) ENGINE=InnoDB {$charset};";

        $tags = "CREATE TABLE {$this->tags_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            tag_key varchar(100) NOT NULL,
            label varchar(190) NOT NULL,
            color varchar(20) NOT NULL DEFAULT '',
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY tag_key (tag_key)
        ) ENGINE=InnoDB {$charset};";

        $entity_tags = "CREATE TABLE {$this->entity_tags_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            tag_id bigint(20) unsigned NOT NULL,
            entity_type varchar(30) NOT NULL,
            entity_id bigint(20) unsigned NOT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY tag_entity (tag_id,entity_type,entity_id),
            KEY entity (entity_type,entity_id)
        ) ENGINE=InnoDB {$charset};";

        $field_definitions = "CREATE TABLE {$this->field_definitions_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            field_key varchar(100) NOT NULL,
            label varchar(190) NOT NULL,
            scope varchar(30) NOT NULL,
            field_type varchar(30) NOT NULL DEFAULT 'text',
            privacy_class varchar(30) NOT NULL DEFAULT 'personal',
            validation longtext DEFAULT NULL,
            is_active tinyint(1) unsigned NOT NULL DEFAULT 1,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY scope_key (scope,field_key),
            KEY scope_active (scope,is_active)
        ) ENGINE=InnoDB {$charset};";

        $field_values = "CREATE TABLE {$this->field_values_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            definition_id bigint(20) unsigned NOT NULL,
            entity_type varchar(30) NOT NULL,
            entity_id bigint(20) unsigned NOT NULL,
            value longtext DEFAULT NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY definition_entity (definition_id,entity_type,entity_id),
            KEY entity (entity_type,entity_id)
        ) ENGINE=InnoDB {$charset};";

        dbDelta( $leads );
        dbDelta( $subscribers );
        dbDelta( $contacts );
        dbDelta( $identities );
        dbDelta( $interactions );
        dbDelta( $pipelines );
        dbDelta( $stages );
        dbDelta( $activities );
        dbDelta( $purposes );
        dbDelta( $consent_events );
        dbDelta( $consent_evidence );
        dbDelta( $outbox );
        dbDelta( $tags );
        dbDelta( $entity_tags );
        dbDelta( $field_definitions );
        dbDelta( $field_values );
        $this->ensure_audience_transactional_tables();
        $this->schema_column_cache = [];
        $this->transactional_schema_ready = null;
        $this->audience_schema_ready = null;
        $this->seed_audience_domain_defaults();
        // Version markers are committed centrally after schema validation.
    }

    /**
     * Return every table participating in an Audience aggregate transaction.
     *
     * @return array<int, string> Fully qualified internal table names.
     */
    private function audience_transactional_tables(): array {
        return [
            $this->leads_table,
            $this->subscribers_table,
            $this->contacts_table,
            $this->identities_table,
            $this->interactions_table,
            $this->pipelines_table,
            $this->stages_table,
            $this->activities_table,
            $this->purposes_table,
            $this->consent_events_table,
            $this->consent_evidence_table,
            $this->outbox_table,
            $this->tags_table,
            $this->entity_tags_table,
            $this->field_definitions_table,
            $this->field_values_table,
        ];
    }

    /**
     * Read all Audience table engines through one bounded metadata query.
     *
     * @return array<string, string>|null Engine map, or null when metadata could
     *                                    not be read safely.
     */
    private function audience_table_engines(): ?array {
        global $wpdb;

        $tables = $this->audience_transactional_tables();
        $placeholders = implode( ',', array_fill( 0, count( $tables ), '%s' ) );
        $wpdb->last_error = '';
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT TABLE_NAME, ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ({$placeholders})",
                ...$tables
            ),
            ARRAY_A
        );

        if ( '' !== $wpdb->last_error || ! is_array( $rows ) ) {
            return null;
        }

        $engines = [];

        foreach ( $rows as $row ) {
            $table = (string) ( $row['TABLE_NAME'] ?? '' );
            $engine = (string) ( $row['ENGINE'] ?? '' );

            if ( '' !== $table && '' !== $engine ) {
                $engines[ $table ] = $engine;
            }
        }

        return $engines;
    }

    /**
     * Migrate pre-existing Audience tables to the required transactional engine.
     */
    private function ensure_audience_transactional_tables(): void {
        global $wpdb;

        $engines = $this->audience_table_engines();

        if ( null === $engines ) {
            return;
        }

        foreach ( $this->audience_transactional_tables() as $table ) {
            $engine = $engines[ $table ] ?? '';

            if ( ! is_string( $engine ) || '' === $engine ) {
                continue;
            }

            if ( 0 === strcasecmp( $engine, 'InnoDB' ) ) {
                continue;
            }

            // DATA INTEGRITY INVARIANT: Every table in a cross-table Audience
            // aggregate must support rollback before schema readiness can pass.
            $wpdb->query( "ALTER TABLE {$table} ENGINE=InnoDB" );
        }

        $this->transactional_schema_ready = null;
    }

    /**
     * Verify the transactional storage contract once per request.
     */
    private function audience_tables_are_transactional(): bool {
        if ( null !== $this->transactional_schema_ready ) {
            return $this->transactional_schema_ready;
        }

        $engines = $this->audience_table_engines();

        if ( null === $engines ) {
            $this->transactional_schema_ready = false;

            return false;
        }

        foreach ( $this->audience_transactional_tables() as $table ) {
            $engine = $engines[ $table ] ?? '';

            if ( ! is_string( $engine ) || 0 !== strcasecmp( $engine, 'InnoDB' ) ) {
                $this->transactional_schema_ready = false;

                return false;
            }
        }

        $this->transactional_schema_ready = true;

        return true;
    }

    /**
     * Checks whether the current database schema has required Audience columns.
     *
     * @return bool True when the schema is complete.
     */

    private function has_required_schema(): bool {
        /*
         * PERFORMANCE INVARIANT: Schema metadata is immutable during ordinary
         * Audience requests. Repeated guards reuse one complete fail-closed result;
         * install() invalidates it whenever schema state may have changed.
         */
        if ( null !== $this->audience_schema_ready ) {
            return $this->audience_schema_ready;
        }

        // Readiness validates the required canonical columns. Unrelated extra
        // columns do not weaken that contract or make the schema unusable.
        $columns_ready = $this->table_exists( $this->leads_table )
            && $this->table_exists( $this->subscribers_table )
            && $this->column_exists( $this->leads_table, 'origin_interaction_id' )
            && $this->column_exists( $this->interactions_table, 'object_key' )
            && $this->column_exists( $this->interactions_table, 'goal_id' )
            && $this->column_exists( $this->interactions_table, 'conversion_event_id' )
            && $this->column_exists( $this->subscribers_table, 'consent_at' )
            && $this->column_exists( $this->subscribers_table, 'email_hash' )
            && $this->column_exists( $this->subscribers_table, 'confirm_token_hash' )
            && $this->column_exists( $this->subscribers_table, 'confirm_expires_at' )
            && $this->column_exists( $this->subscribers_table, 'purpose' );
        $columns_ready = $columns_ready
            && $this->table_exists( $this->contacts_table )
            && $this->table_exists( $this->identities_table )
            && $this->table_exists( $this->interactions_table )
            && $this->table_exists( $this->pipelines_table )
            && $this->table_exists( $this->stages_table )
            && $this->table_exists( $this->activities_table )
            && $this->table_exists( $this->purposes_table )
            && $this->table_exists( $this->consent_events_table )
            && $this->table_exists( $this->consent_evidence_table )
            && $this->column_exists( $this->consent_events_table, 'evidence_public_id' )
            && $this->table_exists( $this->outbox_table )
            && $this->column_exists( $this->outbox_table, 'claim_token' )
            && $this->column_exists( $this->outbox_table, 'claimed_at' )
            && $this->table_exists( $this->tags_table )
            && $this->table_exists( $this->entity_tags_table )
            && $this->table_exists( $this->field_definitions_table )
            && $this->table_exists( $this->field_values_table )
            && $this->column_exists( $this->leads_table, 'contact_id' )
            && $this->column_exists( $this->subscribers_table, 'contact_id' );
        if ( ! $columns_ready ) {
            $this->audience_schema_ready = false;

            return false;
        }

        if ( ! $this->audience_tables_are_transactional() ) {
            $this->audience_schema_ready = false;

            return false;
        }

        global $wpdb;
        $lead_indexes = array_unique( (array) $wpdb->get_col( "SHOW INDEX FROM {$this->leads_table}", 2 ) );
        $subscriber_indexes = array_unique( (array) $wpdb->get_col( "SHOW INDEX FROM {$this->subscribers_table}", 2 ) );
        $interaction_indexes = array_unique( (array) $wpdb->get_col( "SHOW INDEX FROM {$this->interactions_table}", 2 ) );
        $activity_indexes = array_unique( (array) $wpdb->get_col( "SHOW INDEX FROM {$this->activities_table}", 2 ) );
        $this->audience_schema_ready = in_array( 'PRIMARY', $lead_indexes, true )
            && in_array( 'origin_interaction', $lead_indexes, true )
            && in_array( 'status_created', $lead_indexes, true )
            && in_array( 'PRIMARY', $subscriber_indexes, true )
            && in_array( 'email_hash_purpose', $subscriber_indexes, true )
            && in_array( 'confirm_token_hash', $subscriber_indexes, true )
            && in_array( 'contact_id', $subscriber_indexes, true )
            && in_array( 'status_created', $subscriber_indexes, true )
            && in_array( 'status_unsubscribed', $subscriber_indexes, true )
            && in_array( 'contact_occurred', $interaction_indexes, true )
            && in_array( 'interaction_occurred', $activity_indexes, true );

        return $this->audience_schema_ready;
    }

    /**
     * Public schema validator used by the central database schema manager.
     *
     * @return bool True when all required Audience tables and columns exist.
     */

    public function schema_ready(): bool {
        return $this->has_required_schema();
    }

    /**
     * Return a consistent error for Audience requests while schema updates are pending.
     *
     * @return WP_Error Schema unavailable error.
     */

    private function schema_unavailable_error(): WP_Error {
        return new WP_Error(
            'wphave_audience_schema_update_required',
            __( 'Audience database tables need to be updated before this feature can be used.', 'wphave' ),
            [ 'status' => 503 ]
        );
    }

    /**
     * Checks whether a database table contains a column.
     *
     * @param string $table Fully qualified table name.
     * @param string $column Column name.
     * @return bool True when the column exists.
     */

    private function column_exists( string $table, string $column ): bool {
        if ( ! isset( $this->schema_column_cache[ $table ] ) ) {
            $this->schema_column_cache[ $table ] = WPHAVE_Database_Metadata::column_names( $table );
        }

        return in_array( $column, $this->schema_column_cache[ $table ], true );
    }

    /**
     * Checks whether a database table exists.
     *
     * @param string $table Fully qualified table name.
     * @return bool True when the table exists.
     */

    private function table_exists( string $table ): bool {
        return WPHAVE_Database_Metadata::table_exists( $table );
    }

}
