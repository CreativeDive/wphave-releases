<?php

/**
 * Audience Manager entry class.
 *
 * The class composes focused traits for schema, REST, public flows,
 * persistence, permissions and shared utilities. Its public class name is the
 * canonical integration boundary used by other WPHAVE modules.
 *
 * @package wphave
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Coordinates Audience hooks and delegates behavior to focused traits.
 */

class WPHAVE_Audience_Manager {

    use WPHAVE_Audience_Schema_Trait;
    use WPHAVE_Audience_REST_Controller_Trait;
    use WPHAVE_Audience_Public_Flows_Trait;
    use WPHAVE_Audience_Repository_Trait;
    use WPHAVE_Audience_Consent_Evidence_Trait;
    use WPHAVE_Audience_Permissions_Trait;
    use WPHAVE_Audience_Utilities_Trait;
    use WPHAVE_Audience_Retention_Trait;
    use WPHAVE_Audience_Privacy_Trait;
    use WPHAVE_Audience_Domain_V2_Trait;
    use WPHAVE_Audience_Lead_Workflow_Trait;
    use WPHAVE_Audience_Contact_Lifecycle_Trait;
    use WPHAVE_Audience_Lead_Read_Model_Trait;
    use WPHAVE_Audience_Registries_Trait;
    use WPHAVE_Audience_Outbox_Trait;

    /** Public Audience module version. */
    const VERSION = '2.3.0';

    /** Installed schema contract version. */
    const DB_VERSION = '2.4.4';

    /** Unprefixed table names. The constructor resolves the active site prefix. */
    const LEADS_TABLE = 'wphave_audience_leads';
    const SUBSCRIBERS_TABLE = 'wphave_audience_subscribers';
    const CONTACTS_TABLE = 'wphave_audience_contacts';
    const IDENTITIES_TABLE = 'wphave_audience_identities';
    const INTERACTIONS_TABLE = 'wphave_audience_interactions';
    const PIPELINES_TABLE = 'wphave_audience_pipelines';
    const STAGES_TABLE = 'wphave_audience_pipeline_stages';
    const ACTIVITIES_TABLE = 'wphave_audience_activities';
    const PURPOSES_TABLE = 'wphave_audience_purposes';
    const CONSENT_EVENTS_TABLE = 'wphave_audience_consent_events';
    const CONSENT_EVIDENCE_TABLE = 'wphave_audience_consent_evidence';
    const OUTBOX_TABLE = 'wphave_audience_outbox';
    const TAGS_TABLE = 'wphave_audience_tags';
    const ENTITY_TAGS_TABLE = 'wphave_audience_entity_tags';
    const FIELD_DEFINITIONS_TABLE = 'wphave_audience_field_definitions';
    const FIELD_VALUES_TABLE = 'wphave_audience_field_values';
    /** Default retention periods and scheduled maintenance hook. */
    const LEAD_RETENTION_DAYS = 180;
    const PENDING_SUBSCRIBER_RETENTION_DAYS = 30;
    const UNSUBSCRIBED_PROOF_RETENTION_YEARS = 3;
    /** Default lifetime for one-time subscriber confirmation credentials. */
    const CONFIRMATION_TOKEN_TTL = 2 * DAY_IN_SECONDS;
    /** Lifetime and accepted clock skew for stateless public write proofs. */
    const PUBLIC_REQUEST_PROOF_TTL = 10 * MINUTE_IN_SECONDS;
    const PUBLIC_REQUEST_PROOF_CLOCK_SKEW = MINUTE_IN_SECONDS;
    /** Versioned rewrite contract for public Audience routes. */
    const PUBLIC_ROUTE_VERSION = '1';
    /** Option recording the public route contract installed in WordPress. */
    const PUBLIC_ROUTE_VERSION_OPTION = 'wphave_audience_public_route_version';
    const RETENTION_CRON_HOOK = 'wphave_audience_cleanup_retention';
	const RETENTION_SCHEDULE_OPTION = 'wphave_audience_retention_schedule';

    /** Supported configurable retention bounds. */
    const MIN_RETENTION_DAYS = 1;
    const MAX_RETENTION_DAYS = 3650;
    const MAX_PUBLIC_JSON_BYTES = 65536;

    /** Per-user high-water mark used for non-blocking new-lead notifications. */
    const LAST_SEEN_LEAD_META = '_wphave_audience_last_seen_lead_id';

    /**
     * Fully qualified leads table name.
     *
     * @var string
     */

    private string $leads_table;

    /**
     * Fully qualified subscribers table name.
     *
     * @var string
     */

    private string $subscribers_table;

    /** Fully qualified canonical contact profile table name. */
    private string $contacts_table;

    /** Fully qualified normalized contact identity table name. */
    private string $identities_table;

    /** Fully qualified immutable interaction fact table name. */
    private string $interactions_table;

    /** Fully qualified pipeline definition table name. */
    private string $pipelines_table;

    /** Fully qualified pipeline stage definition table name. */
    private string $stages_table;

    /** Fully qualified append-only activity timeline table name. */
    private string $activities_table;

    /** Fully qualified consent purpose registry table name. */
    private string $purposes_table;

    /** Fully qualified append-only consent evidence table name. */
    private string $consent_events_table;

    /** Fully qualified immutable consent evidence artifact table name. */
    private string $consent_evidence_table;

    /** Fully qualified transactional domain-event outbox table name. */
    private string $outbox_table;

    /** Fully qualified tag definition table name. */
    private string $tags_table;

    /** Fully qualified polymorphic entity-to-tag relation table name. */
    private string $entity_tags_table;

    /** Fully qualified custom-field definition table name. */
    private string $field_definitions_table;

    /** Fully qualified polymorphic custom-field value table name. */
    private string $field_values_table;

    /** Request-local cache of table columns used by schema readiness checks. */
    private array $schema_column_cache = [];

    /** Cached transactional-engine readiness for the current request. */
    private ?bool $transactional_schema_ready = null;

    /** Cached complete Audience schema readiness for the current request. */
    private ?bool $audience_schema_ready = null;

    /**
     * Confirmation mails queued until the surrounding database transaction commits.
     *
     * This prevents an email from referring to subscriber state that was rolled back.
     * Each queued item may contain the raw one-time `confirmation_token`; that value
     * is never persisted or returned by a read model and the queue is cleared before
     * delivery begins.
     *
     * @var array<int, array<string, mixed>>
     */
    private array $pending_confirmation_subscribers = [];

    /**
     * Returns the effective retention period owned by Audience.
     *
     * Forms and other producers may display this value, but must not implement
     * their own deletion policy for Audience-owned records.
     *
     * @param string $record_type Supported Audience record type.
     * @return int Retention period in days.
     */
    public static function retention_days( string $record_type ): int {
        $defaults = array(
            'lead' => self::LEAD_RETENTION_DAYS,
            'interaction' => 180,
            'pendingSubscriber' => self::PENDING_SUBSCRIBER_RETENTION_DAYS,
        );
        $setting_keys = array(
            'lead' => 'leadDays',
            'interaction' => 'interactionDays',
            'pendingSubscriber' => 'pendingSubscriberDays',
        );

        if ( ! isset( $defaults[ $record_type ] ) ) {
            return 0;
        }

        $configured = function_exists( 'wphave_data_get' )
            ? wphave_data_get( 'site_settings', 'audience.retention.' . $setting_keys[ $record_type ], $defaults[ $record_type ] )
            : $defaults[ $record_type ];
        $days = min( self::MAX_RETENTION_DAYS, max( self::MIN_RETENTION_DAYS, absint( $configured ) ) );

        return min(
            self::MAX_RETENTION_DAYS,
            max(
                self::MIN_RETENTION_DAYS,
                absint( apply_filters( 'wphave_audience_retention_days', $days, $record_type ) )
            )
        );
    }

    /**
     * Initializes fully qualified Audience table names.
     *
     * No schema writes or hooks run in the constructor so the manager remains safe
     * to instantiate during bootstrap and tests.
     */

    public function __construct() {
        global $wpdb;

        $this->leads_table = $wpdb->prefix . self::LEADS_TABLE;
        $this->subscribers_table = $wpdb->prefix . self::SUBSCRIBERS_TABLE;
        $this->contacts_table = $wpdb->prefix . self::CONTACTS_TABLE;
        $this->identities_table = $wpdb->prefix . self::IDENTITIES_TABLE;
        $this->interactions_table = $wpdb->prefix . self::INTERACTIONS_TABLE;
        $this->pipelines_table = $wpdb->prefix . self::PIPELINES_TABLE;
        $this->stages_table = $wpdb->prefix . self::STAGES_TABLE;
        $this->activities_table = $wpdb->prefix . self::ACTIVITIES_TABLE;
        $this->purposes_table = $wpdb->prefix . self::PURPOSES_TABLE;
        $this->consent_events_table = $wpdb->prefix . self::CONSENT_EVENTS_TABLE;
        $this->consent_evidence_table = $wpdb->prefix . self::CONSENT_EVIDENCE_TABLE;
        $this->outbox_table = $wpdb->prefix . self::OUTBOX_TABLE;
        $this->tags_table = $wpdb->prefix . self::TAGS_TABLE;
        $this->entity_tags_table = $wpdb->prefix . self::ENTITY_TAGS_TABLE;
        $this->field_definitions_table = $wpdb->prefix . self::FIELD_DEFINITIONS_TABLE;
        $this->field_values_table = $wpdb->prefix . self::FIELD_VALUES_TABLE;
    }

    /**
     * Registers Audience hooks for schema setup, REST routes, public flows and exports.
     *
     * Privacy integration is conditional so Audience remains usable when the shared
     * privacy manager has not been loaded yet.
     *
     * @return void
     */

    public function init(): void {
		$has_worker_runtime = defined( 'WPHAVE_AUDIENCE_WORKER_RUNTIME' ) && WPHAVE_AUDIENCE_WORKER_RUNTIME;
		$has_interactive_runtime = defined( 'WPHAVE_AUDIENCE_INTERACTIVE_RUNTIME' ) && WPHAVE_AUDIENCE_INTERACTIVE_RUNTIME;

		// WORKER INVARIANT: Cron owns only persisted retention and outbox
		// callbacks. Public confirmation, REST and admin-export surfaces belong to
		// interactive requests and must not become part of worker-only composition.
		// WP-CLI deliberately composes both runtimes, so adding worker callbacks
		// must never remove already-loaded interactive capabilities.
		if ( $has_interactive_runtime ) {
			// This manager is initialized on WordPress' init hook, so route setup
			// must run now instead of registering another already-passed init hook.
			$this->register_public_confirmation_route();
			$this->maybe_refresh_public_routes();
			add_filter( 'query_vars', [ $this, 'register_public_query_vars' ] );
			add_action( 'parse_request', [ $this, 'resolve_public_confirmation_request' ], 0 );
			add_action( 'template_redirect', [ $this, 'handle_public_unsubscribe_confirmation' ], 0 );
			add_action( 'template_redirect', [ $this, 'render_public_subscriber_confirmation' ], 1 );
			add_action( 'rest_api_init', [ $this, 'register_routes' ] );
			add_action( 'admin_post_wphave_export_audience_leads', [ $this, 'export_leads' ] );
			add_action( 'admin_post_wphave_export_audience_contacts', [ $this, 'export_contacts' ] );
			add_action( 'admin_post_wphave_export_audience_subscribers', [ $this, 'export_subscribers' ] );
		}

		// LIFECYCLE INVARIANT: The Audience manager itself is booted on `init`.
		// Registering another `init` callback here would miss the current lifecycle
		// boundary and leave a fresh installation without retention or outbox jobs.
		// Both synchronizers are idempotent and therefore execute immediately.
		$this->schedule_retention_cleanup();
		$this->schedule_outbox();

		if ( $has_worker_runtime ) {
			add_action( self::RETENTION_CRON_HOOK, [ $this, 'cleanup_retention' ] );
			add_action( 'wphave_audience_process_outbox', [ $this, 'process_outbox' ] );
		}

        if ( class_exists( 'WPHAVE_Privacy_Manager' ) ) {
            WPHAVE_Privacy_Manager::register_retention_policy( [
                'id' => 'audience-retention',
                'label' => __( 'Audience retention', 'wphave' ),
                'retention_days' => self::retention_days( 'lead' ),
                'callback' => [ $this, 'cleanup_retention' ],
            ] );
            WPHAVE_Privacy_Manager::register_exporter( 'wphave-audience', __( 'WPHAVE Audience', 'wphave' ), [ $this, 'privacy_export' ] );
            WPHAVE_Privacy_Manager::register_eraser( 'wphave-audience', __( 'WPHAVE Audience', 'wphave' ), [ $this, 'privacy_erase' ] );
        }
    }
}
