<?php

/** Bootstrap Audience outbox delivery and retention callbacks. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'WPHAVE_AUDIENCE_WORKER_RUNTIME' ) ) {
	define( 'WPHAVE_AUDIENCE_WORKER_RUNTIME', true );
}

require_once __DIR__ . '/bootstrap.php';
