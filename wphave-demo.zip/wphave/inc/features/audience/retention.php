<?php

/**
 * Automatic retention and minimization for Audience records.
 *
 * @package wphave
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait WPHAVE_Audience_Retention_Trait {

    /**
     * Schedules the daily retention cleanup.
     *
     * @return void
     */

    public function schedule_retention_cleanup(): void {
		// PRIVACY LIFECYCLE INVARIANT: Contact-data retention owns exactly one
		// fixed-duration daily event. The shared scheduler repairs duplicates and
		// interval drift without treating timezone changes as policy changes.
		WPHAVE_Background_Job_Scheduler::sync_recurring(
			self::RETENTION_CRON_HOOK,
			self::RETENTION_SCHEDULE_OPTION,
			true,
			'daily',
			time() + HOUR_IN_SECONDS,
			'audience-retention-v1'
		);
    }

    /**
     * Deletes expired data and minimizes unsubscribe proof records.
     *
     * @return bool Whether every retention phase completed successfully.
     */

    public function cleanup_retention(): bool {
        if ( ! $this->has_required_schema() ) {
            return false;
        }

        global $wpdb;
        $lead_days = self::retention_days( 'lead' );
        $interaction_days = self::retention_days( 'interaction' );
        $lead_threshold = current_datetime()->modify('-' . $lead_days . ' days')->format('Y-m-d H:i:s');
        $interaction_threshold = current_datetime()->modify('-' . $interaction_days . ' days')->format('Y-m-d H:i:s');
        $pending_threshold = current_datetime()->modify('-' . self::retention_days( 'pendingSubscriber' ) . ' days')->format('Y-m-d H:i:s');
        $proof_threshold = current_datetime()->modify('-' . self::UNSUBSCRIBED_PROOF_RETENTION_YEARS . ' years')->format('Y-m-d H:i:s');

        $expired_lead_ids = $this->retention_ids(
            $wpdb->prepare(
                "SELECT id FROM {$this->leads_table} WHERE created_at < %s AND status IN ('lost', 'archived') LIMIT 500",
                $lead_threshold
            )
        );

        if ( null === $expired_lead_ids ) {
            return false;
        }

        foreach ( $expired_lead_ids as $lead_id ) {
            if ( true !== $this->delete_expired_operational_lead( absint( $lead_id ), $lead_threshold ) ) {
                return false;
            }
        }
        $expired_interaction_ids = $this->retention_ids(
            $wpdb->prepare(
                "SELECT interaction.id FROM {$this->interactions_table} interaction LEFT JOIN {$this->leads_table} lead ON lead.origin_interaction_id = interaction.id WHERE interaction.occurred_at < %s AND interaction.contact_id = 0 AND lead.id IS NULL LIMIT 500",
                $interaction_threshold
            )
        );

        if ( null === $expired_interaction_ids ) {
            return false;
        }

        foreach ( $expired_interaction_ids as $interaction_id ) {
            if ( ! $this->delete_expired_interaction( absint( $interaction_id ), $interaction_threshold ) ) {
                return false;
            }
        }

        if ( ! $this->delete_expired_subscribers( 'pending', 'created_at', $pending_threshold ) ) {
            return false;
        }

        if ( ! $this->minimize_unsubscribed_subscribers() ) {
            return false;
        }

        return $this->delete_expired_subscribers( 'unsubscribed', 'unsubscribed_at', $proof_threshold );
    }

    /**
     * Reads one bounded retention candidate set without confusing SQL failure with emptiness.
     *
     * RESILIENCE INVARIANT: A failed candidate read aborts the current cron run.
     * Later destructive phases retry on the next run instead of advancing from
     * an unknown partial database state.
     *
     * @param string $query Prepared bounded candidate query.
     * @return array<int, int>|null Candidate ids or null after a database error.
     */
    private function retention_ids( string $query ): ?array {
        global $wpdb;

        $wpdb->last_error = '';
        $ids = $wpdb->get_col( $query );

        if ( null === $ids || $wpdb->last_error ) {
            return null;
        }

        return array_map( 'absint', $ids );
    }

    /**
     * Atomically remove one unowned interaction and its dependent activities.
     *
     * @param int $interaction_id Expired interaction id.
     * @param string $threshold MySQL date-time expiry threshold.
     * @return bool Whether the complete graph was removed.
     */
    private function delete_expired_interaction( int $interaction_id, string $threshold ): bool {
        global $wpdb;

        if ( ! $interaction_id || '' === $threshold ) {
            return false;
        }

        if ( ! $this->begin_audience_transaction() ) {
            return false;
        }

        $activities_deleted = $wpdb->delete(
            $this->activities_table,
            [ 'interaction_id' => $interaction_id ],
            [ '%d' ]
        );
        /*
         * OWNERSHIP INVARIANT: Retention may delete only an expired interaction
         * that is still pseudonymous and unclaimed by a lead at delete time. If
         * ownership changed after candidate selection, the transaction rolls back
         * the dependent activity deletion instead of erasing the new graph.
         */
        $interaction_deleted = false !== $activities_deleted
            ? $wpdb->query(
                $wpdb->prepare(
                    "DELETE FROM {$this->interactions_table} WHERE id = %d AND occurred_at < %s AND contact_id = 0 AND NOT EXISTS (SELECT 1 FROM {$this->leads_table} WHERE origin_interaction_id = {$this->interactions_table}.id)",
                    $interaction_id,
                    $threshold
                )
            )
            : false;

        if ( false === $activities_deleted || 1 !== $interaction_deleted ) {
            $this->rollback_audience_transaction();

            return false;
        }

        if ( ! $this->commit_audience_transaction() ) {
            $this->rollback_audience_transaction();

            return false;
        }

        return true;
    }

    /**
     * Removes a bounded subscriber batch while retaining unlinkable consent facts.
     *
     * Consent events remain as legal audit evidence, but their subscriber link is
     * cleared before the mutable subscription row expires. The date column is a
     * DATA INTEGRITY INVARIANT: Retention SQL identifiers come only from the closed internal allowlist.
     *
     * @param string $status Subscriber status selected for expiry.
     * @param string $date_column Canonical created_at or unsubscribed_at column.
     * @param string $threshold MySQL date-time expiry threshold.
     * @return bool Whether the complete candidate batch was processed.
     */
    private function delete_expired_subscribers( string $status, string $date_column, string $threshold ): bool {
        global $wpdb;

        if ( ! in_array( $date_column, [ 'created_at', 'unsubscribed_at' ], true ) ) {
            return false;
        }

        $subscriber_ids = $this->retention_ids(
            $wpdb->prepare(
                "SELECT id FROM {$this->subscribers_table} WHERE status = %s AND {$date_column} IS NOT NULL AND {$date_column} < %s LIMIT 500",
                $status,
                $threshold
            )
        );

        if ( null === $subscriber_ids ) {
            return false;
        }

        foreach ( $subscriber_ids as $subscriber_id ) {
            if ( ! $this->delete_expired_subscriber( $subscriber_id, $status, $date_column, $threshold ) ) {
                return false;
            }
        }

        return true;
    }

    /**
     * Atomically expire one subscriber while retaining unlinkable consent facts.
     *
     * @param int $subscriber_id Expired subscriber id.
     * @param string $status Status observed by the candidate query.
     * @param string $date_column Canonical retention date column.
     * @param string $threshold MySQL date-time expiry threshold.
     * @return bool Whether the complete mutable graph was removed.
     */
    private function delete_expired_subscriber(
        int $subscriber_id,
        string $status,
        string $date_column,
        string $threshold
    ): bool {
        global $wpdb;

        if (
            ! $subscriber_id
            || ! in_array( $status, [ 'pending', 'unsubscribed' ], true )
            || ! in_array( $date_column, [ 'created_at', 'unsubscribed_at' ], true )
            || '' === $threshold
        ) {
            return false;
        }

        if ( ! $this->begin_audience_transaction() ) {
            return false;
        }

        $events_unlinked = $wpdb->update(
            $this->consent_events_table,
            [ 'subscriber_id' => 0 ],
            [ 'subscriber_id' => $subscriber_id ],
            [ '%d' ],
            [ '%d' ]
        );
        $evidence_deleted = false !== $events_unlinked
            ? $wpdb->delete( $this->consent_evidence_table, [ 'subscriber_id' => $subscriber_id ], [ '%d' ] )
            : false;
        /*
         * CONCURRENCY INVARIANT: Destructive retention repeats the complete
         * candidate predicate at delete time. A reactivated or refreshed row
         * makes the delete affect zero rows, which rolls back the evidence changes.
         */
        $subscriber_deleted = false !== $evidence_deleted
            ? $wpdb->query(
                $wpdb->prepare(
                    "DELETE FROM {$this->subscribers_table} WHERE id = %d AND status = %s AND {$date_column} IS NOT NULL AND {$date_column} < %s",
                    $subscriber_id,
                    $status,
                    $threshold
                )
            )
            : false;

        if ( false === $events_unlinked || false === $evidence_deleted || 1 !== $subscriber_deleted ) {
            $this->rollback_audience_transaction();

            return false;
        }

        if ( ! $this->commit_audience_transaction() ) {
            $this->rollback_audience_transaction();

            return false;
        }

        return true;
    }

    /**
     * Replaces an unsubscribed contact profile with a minimal suppression proof.
     *
     * The email HMAC was assigned before insertion and is retained with the purpose
     * as the collision-free suppression identity. Direct identifiers, attribution
     * values and any unused confirmation credential are removed in bounded batches.
     * Contact/identity retention is governed separately because another Audience
     * aggregate may still provide a valid ownership or retention basis.
     *
     * @return bool Whether the bounded minimization batch completed.
     */

    public function minimize_unsubscribed_subscribers(): bool {
        if ( ! $this->has_required_schema() || ! $this->column_exists( $this->subscribers_table, 'email_hash' ) ) {
            return false;
        }

        global $wpdb;

        $wpdb->last_error = '';
        $rows = $wpdb->get_results(
            "SELECT id, email, email_hash FROM {$this->subscribers_table} WHERE status = 'unsubscribed' AND email != '' LIMIT 500",
            ARRAY_A
        );

        if ( null === $rows || $wpdb->last_error ) {
            return false;
        }

        foreach ( $rows as $row ) {
            if ( ! $this->minimize_unsubscribed_subscriber_row( $row ) ) {
                return false;
            }
        }

        return true;
    }

    /**
     * Minimizes one unsubscribed subscriber inside its owning write transaction.
     *
     * @param int $subscriber_id Subscriber database id.
     * @return bool Whether the subscriber was found and minimized safely.
     */
    private function minimize_unsubscribed_subscriber( int $subscriber_id ): bool {
        global $wpdb;

        if ( ! $subscriber_id ) {
            return false;
        }

        $wpdb->last_error = '';
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT id, email, email_hash FROM {$this->subscribers_table} WHERE id = %d AND status = 'unsubscribed' LIMIT 1",
                $subscriber_id
            ),
            ARRAY_A
        );

        if ( ! is_array( $row ) || $wpdb->last_error ) {
            return false;
        }

        return $this->minimize_unsubscribed_subscriber_row( $row );
    }

    /**
     * Removes direct identifiers while preserving one canonical suppression key.
     *
     * @param array<string, mixed> $row Subscriber identity projection.
     * @return bool Whether the row was minimized safely.
     */
    private function minimize_unsubscribed_subscriber_row( array $row ): bool {
        global $wpdb;

        $subscriber_id = absint( $row['id'] ?? 0 );
        $email = $this->normalize_email( $row['email'] ?? '' );
        $stored_email_hash = strtolower( (string) ( $row['email_hash'] ?? '' ) );
        $email_hash = $email
            ? $this->subscriber_email_hash( $email )
            : ( preg_match( '/^[a-f0-9]{64}$/', $stored_email_hash ) ? $stored_email_hash : '' );

        /*
         * PRIVACY INVARIANT: An unsubscribe and its data minimization form one
         * atomic state transition. Malformed direct identifiers must never make
         * minimization report success while retaining personal data. A previously
         * persisted canonical suppression HMAC remains sufficient to erase the
         * profile without weakening future opt-out matching.
         */
        if ( ! $subscriber_id || '' === $email_hash ) {
            return false;
        }

        /*
         * CONCURRENCY INVARIANT: The status predicate is repeated at write time.
         * A stale retention read must never erase a subscriber that was reactivated
         * before this update acquired its row lock.
         */
        return 1 === $wpdb->update(
            $this->subscribers_table,
            [
                'email' => '',
                'email_hash' => $email_hash,
                'first_name' => '',
                'last_name' => '',
                'source' => '',
                'medium' => '',
                'campaign' => '',
                'lead_id' => 0,
                'confirm_token_hash' => '',
                'confirm_expires_at' => null,
                'updated_at' => current_time( 'mysql' ),
            ],
            [
                'id' => $subscriber_id,
                'status' => 'unsubscribed',
            ],
            [ '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s' ],
            [ '%d', '%s' ]
        );
    }
}
