<?php

/**
 * Lead, subscriber and query persistence for the Audience Manager.
 *
 * All write entry points converge on the V2 domain owners: contact resolution,
 * immutable interaction recording and operational lead creation. Form lead and
 * subscriber writes share a transaction.
 *
 * ORDERING INVARIANT: Confirmation mail and other external side effects run
 * after commit and never advertise rolled-back state.
 *
 * @package wphave
 */

if (!defined('ABSPATH')) {
	exit();
}

/**
 * Lead, subscriber and query persistence for the Audience Manager.
 */

trait WPHAVE_Audience_Repository_Trait {
	/**
	 * Record a trusted server-side lead through the canonical V2 pipeline.
	 *
	 * Callers must already have authorized and validated their internal event.
	 * Input is still sanitized by create_lead() before persistence.
	 *
	 * @param array<string, mixed> $data Normalized lead and interaction input.
	 * @return array<string, mixed>|WP_Error Stored lead read model or domain error.
	 */
	public function record_internal_lead(array $data) {
		global $wpdb;

		if (!$this->begin_audience_transaction()) {
			return new WP_Error(
				'wphave_audience_transaction_unavailable',
				__('Audience storage transaction could not be started.', 'wphave'),
				['status' => 503],
			);
		}

		$lead = $this->create_lead($data);

		if (is_wp_error($lead)) {
			$this->rollback_audience_transaction();

			return $lead;
		}

		if (!$this->commit_audience_transaction()) {
			$this->rollback_audience_transaction();

			return new WP_Error(
				'wphave_audience_transaction_commit_failed',
				__('Audience storage transaction could not be committed.', 'wphave'),
				['status' => 503],
			);
		}

		return $lead;
	}

	/**
	 * Record a trusted server-side subscriber through the canonical repository.
	 *
	 * This boundary is reserved for installation-owned fixtures and migrations.
	 * Public requests must continue to use the REST and public-flow validation.
	 * Internal imports never enqueue a confirmation email for later unrelated
	 * requests; subscriber state and consent evidence still commit atomically.
	 *
	 * @param array<string, mixed> $data Normalized subscriber input.
	 * @return array<string, mixed>|WP_Error Stored subscriber or domain error.
	 */
	public function record_internal_subscriber(array $data) {
		global $wpdb;

		$pending_confirmation_before = $this->pending_confirmation_subscribers;
		if (!$this->begin_audience_transaction()) {
			return new WP_Error(
				'wphave_audience_transaction_unavailable',
				__('Audience storage transaction could not be started.', 'wphave'),
				['status' => 503],
			);
		}

		$subscriber = $this->save_subscriber($data);

		if (is_wp_error($subscriber)) {
			$this->rollback_audience_transaction();
			$this->pending_confirmation_subscribers = $pending_confirmation_before;

			return $subscriber;
		}

		if (!$this->commit_audience_transaction()) {
			$this->rollback_audience_transaction();
			$this->pending_confirmation_subscribers = $pending_confirmation_before;

			return new WP_Error(
				'wphave_audience_transaction_commit_failed',
				__('Audience storage transaction could not be committed.', 'wphave'),
				['status' => 503],
			);
		}

		$this->pending_confirmation_subscribers = $pending_confirmation_before;

		return $subscriber;
	}

	/**
	 * Stores validated form values as an Audience lead and optional subscribers.
	 *
	 * @param array $form_settings Form block attributes.
	 * @param array $values Validated form values.
	 * @param array $schema Parsed form schema.
	 * @param array $context Request and post context.
	 * @return array|WP_Error|null Stored lead, error or null when disabled.
	 */

	public function create_lead_from_form_submission(
		array $form_settings,
		array $values,
		array $schema,
		array $context = [],
	) {
		global $wpdb;

		$pending_confirmation_before = $this->pending_confirmation_subscribers;

		$existing = $this->find_lead_by_submission_id(
			sanitize_text_field($context['submission_id'] ?? ''),
		);

		if (is_wp_error($existing)) {
			return $existing;
		}

		if ($existing) {
			return $existing;
		}

		$mapped = $this->map_form_values($values, $schema);
		$form_id = sanitize_text_field($context['form_id'] ?? ($form_settings['formId'] ?? ''));
		$form_post_id = absint($context['form_post_id'] ?? 0);
		$source_post_id = absint($context['source_post_id'] ?? 0);
		$source_post = $source_post_id ? get_post($source_post_id) : null;
		$form_post = $form_post_id ? get_post($form_post_id) : null;
		$lead_enabled = !empty($form_settings['audienceLeadEnabled']);
		$lead = null;

		if (!$this->begin_audience_transaction()) {
			return new WP_Error(
				'wphave_audience_transaction_unavailable',
				__('Audience storage transaction could not be started.', 'wphave'),
				['status' => 503],
			);
		}

		if ($lead_enabled) {
			$lead = $this->create_lead([
				'type' => 'form',
				'event' => $form_id ? 'form_submit:' . $form_id : 'form_submit',
				'email' => $mapped['email'],
				'first_name' => $mapped['first_name'],
				'last_name' => $mapped['last_name'],
				'source' => sanitize_text_field($context['source'] ?? ''),
				'medium' => sanitize_text_field($context['medium'] ?? ''),
				'campaign' => sanitize_text_field($context['campaign'] ?? ''),
				'tracking' => $context['tracking'] ?? [],
				'consent' => $mapped['consent'],
				'consent_label' => $mapped['consent_label'],
				'landing_url' => esc_url_raw($context['landing_url'] ?? ''),
				'current_url' => esc_url_raw($context['current_url'] ?? ''),
				'referrer' => esc_url_raw($context['referrer_url'] ?? ''),
				'object_type' => 'form',
				'object_id' => $form_post_id,
				'object_subtype' => $form_post ? $form_post->post_type : '',
				'object_key' => $form_id ?: ($form_post_id ? 'form:' . $form_post_id : ''),
				'object_label' => sanitize_text_field(
					$form_post
						? $form_post->post_title
						: $form_settings['emailTitle'] ?? __('Form submission', 'wphave'),
				),
				'object_url' => $source_post_id ? get_permalink($source_post_id) : '',
				'goal_id' => sanitize_key($context['goal_id'] ?? ''),
				'visitor_id' => sanitize_text_field($context['visitor_id'] ?? ''),
				'session_id' => sanitize_text_field($context['session_id'] ?? ''),
				'submission_id' => sanitize_text_field($context['submission_id'] ?? ''),
				'data' => array_merge($mapped['payload'], [
					'form_id' => $form_id,
					'form_post_id' => $form_post_id,
					'source_post_id' => $source_post_id,
					'source_post_title' => $source_post ? $source_post->post_title : '',
				]),
			]);

			if (is_wp_error($lead)) {
				$this->rollback_audience_transaction();
				$this->pending_confirmation_subscribers = $pending_confirmation_before;

				return $lead;
			}
		}

		if (!empty($form_settings['audienceSubscriberEnabled']) && is_email($mapped['email'])) {
			foreach ($this->normalize_subscription_purposes($form_settings) as $purpose) {
				$subscriber = $this->save_subscriber(
					[
						'email' => $mapped['email'],
						'first_name' => $mapped['first_name'],
						'last_name' => $mapped['last_name'],
						'purpose' => $purpose,
						'source' => is_array($lead)
							? $lead['source'] ?? ''
							: sanitize_text_field($context['source'] ?? ''),
						'medium' => is_array($lead)
							? $lead['medium'] ?? ''
							: sanitize_text_field($context['medium'] ?? ''),
						'campaign' => is_array($lead)
							? $lead['campaign'] ?? ''
							: sanitize_text_field($context['campaign'] ?? ''),
						'lead_id' => is_array($lead) ? absint($lead['id'] ?? 0) : 0,
						'status' => sanitize_key(
							$form_settings['audienceSubscriberStatus'] ?? 'pending',
						),
						'consent' => $mapped['consent'],
						'consent_label' => $mapped['consent_label'],
					],
					true,
				);

				if (is_wp_error($subscriber)) {
					$this->rollback_audience_transaction();
					$this->pending_confirmation_subscribers = $pending_confirmation_before;

					return $subscriber;
				}
			}
		}

		if (is_wp_error($lead) || ($lead_enabled && empty($lead['id']))) {
			$this->rollback_audience_transaction();
			$this->pending_confirmation_subscribers = $pending_confirmation_before;

			return $lead;
		}

		if (!$this->commit_audience_transaction()) {
			$this->rollback_audience_transaction();
			$this->pending_confirmation_subscribers = $pending_confirmation_before;

			return new WP_Error(
				'wphave_audience_transaction_commit_failed',
				__('Audience storage transaction could not be committed.', 'wphave'),
				['status' => 503],
			);
		}

		$this->flush_confirmation_emails_since($pending_confirmation_before);

		return $lead;
	}

	/**
	 * Creates a sanitized Audience lead record.
	 *
	 * @param array $data Lead data.
	 * @return array|WP_Error Stored lead row or error.
	 */

	private function create_lead(array $data) {
		if (!$this->has_required_schema()) {
			return $this->schema_unavailable_error();
		}

		if (!empty($data['honeypot']) || !empty($data['data']['honeypot'])) {
			return new WP_Error('wphave_audience_bot', __('Bot submission detected.', 'wphave'), [
				'status' => 400,
			]);
		}

		$raw_submission_id = $data['submission_id'] ?? '';

		if (!is_scalar($raw_submission_id)) {
			return new WP_Error(
				'wphave_audience_submission_id_invalid',
				__('Submission ID must be a text value.', 'wphave'),
				['status' => 400],
			);
		}

		$submitted_submission_id = (string) $raw_submission_id;
		$submission_id = trim($submitted_submission_id);
		$sanitized_submission_id = sanitize_text_field($submission_id);
		$submission_id_length = function_exists('mb_strlen')
			? mb_strlen($submission_id)
			: strlen($submission_id);

		// DATA INTEGRITY INVARIANT: Submission ids are external idempotency
		// identities. Sanitization must never rewrite one caller identity into
		// another identity that may already own an immutable interaction.
		if (
			$submitted_submission_id !== $submission_id ||
			$submission_id !== $sanitized_submission_id ||
			$submission_id_length > 100
		) {
			return new WP_Error(
				'wphave_audience_submission_id_invalid',
				__(
					'Submission ID must be unchanged by sanitization and must not exceed 100 characters.',
					'wphave',
				),
				['status' => 400],
			);
		}

		$existing = $this->find_lead_by_submission_id($submission_id);

		if (is_wp_error($existing)) {
			return $existing;
		}

		if ($existing) {
			return $existing;
		}

		$has_explicit_occurred_at = array_key_exists('occurred_at', $data);
		$occurred_at = $has_explicit_occurred_at
			? $this->normalize_mysql_datetime($data['occurred_at'])
			: current_time('mysql');

		// DATA INTEGRITY INVARIANT: Explicit event time is audit evidence and
		// must never be silently rewritten to the ingestion time. Only omitted
		// timestamps receive the server-owned current time.
		if ('' === $occurred_at) {
			return new WP_Error(
				'wphave_audience_interaction_timestamp_invalid',
				__('Interaction timestamp must be a valid MySQL datetime.', 'wphave'),
				['status' => 400],
			);
		}

		$type = $this->normalize_closed_key(
			$data['type'] ?? 'form',
			$this->registered_lead_types(),
		);

		// DATA INTEGRITY INVARIANT: Lead types are routing identities shared by
		// timelines, analytics and event consumers. Unknown or lossily rewritten
		// values must never fall back to another semantic category.
		if ('' === $type) {
			return new WP_Error(
				'wphave_audience_lead_type_invalid',
				__('Select a registered lead type.', 'wphave'),
				['status' => 400],
			);
		}

		$raw_event = $data['event'] ?? '';

		if (!is_scalar($raw_event)) {
			return new WP_Error(
				'wphave_audience_event_invalid',
				__('Event name must be a text value.', 'wphave'),
				['status' => 400],
			);
		}

		$submitted_event = (string) $raw_event;
		$event = trim($submitted_event);
		$sanitized_event = sanitize_text_field($event);
		$event_length = function_exists('mb_strlen') ? mb_strlen($event) : strlen($event);

		// DATA INTEGRITY INVARIANT: Event names participate in duplicate
		// fingerprints and immutable interaction history. They must not collide
		// through sanitization, outer-whitespace removal or database truncation.
		if ($submitted_event !== $event || $event !== $sanitized_event || $event_length > 100) {
			return new WP_Error(
				'wphave_audience_event_invalid',
				__(
					'Event name must be unchanged by sanitization and must not exceed 100 characters.',
					'wphave',
				),
				['status' => 400],
			);
		}

		$raw_object_key = $data['object_key'] ?? '';

		if (!is_scalar($raw_object_key)) {
			return new WP_Error(
				'wphave_audience_object_key_invalid',
				__('Object key must be a text value.', 'wphave'),
				['status' => 400],
			);
		}

		$submitted_object_key = (string) $raw_object_key;
		$object_key = trim($submitted_object_key);
		$sanitized_object_key = sanitize_text_field($object_key);
		$object_key_length = function_exists('mb_strlen')
			? mb_strlen($object_key)
			: strlen($object_key);

		// DATA INTEGRITY INVARIANT: The fingerprint and persisted interaction
		// must reference the exact same object identity. Sanitization or schema
		// truncation must never make those two representations diverge.
		if (
			$submitted_object_key !== $object_key ||
			$object_key !== $sanitized_object_key ||
			$object_key_length > 190
		) {
			return new WP_Error(
				'wphave_audience_object_key_invalid',
				__(
					'Object key must be unchanged by sanitization and must not exceed 190 characters.',
					'wphave',
				),
				['status' => 400],
			);
		}

		$raw_email = $data['email'] ?? ($data['data']['email'] ?? '');
		$email = $this->normalize_email($raw_email);

		if (!is_scalar($raw_email) || ('' !== trim((string) $raw_email) && !is_email($email))) {
			return new WP_Error(
				'wphave_audience_invalid_email',
				__('Invalid email address.', 'wphave'),
				['status' => 400],
			);
		}

		$payload = $this->normalize_lead_payload($data['data'] ?? []);

		if (is_wp_error($payload)) {
			return $payload;
		}

		$tracking = $this->sanitize_tracking($data['tracking'] ?? []);

		if (is_wp_error($tracking)) {
			return $tracking;
		}

		$direct_tracking = [];
		$direct_tracking_fields = [
			'source' => 'utm_source',
			'medium' => 'utm_medium',
			'campaign' => 'utm_campaign',
			'content' => 'utm_content',
			'term' => 'utm_term',
		];

		foreach ($direct_tracking_fields as $field => $tracking_key) {
			if (array_key_exists($field, $data)) {
				$direct_tracking[$tracking_key] = $data[$field];
			}
		}

		$direct_tracking = $this->sanitize_tracking($direct_tracking);

		if (is_wp_error($direct_tracking)) {
			return $direct_tracking;
		}

		// INTEGRATION INVARIANT: Direct server-side attribution and public UTM
		// input share one schema contract. Explicit tracking retains precedence
		// when an integration supplies both representations.
		$tracking = array_merge($direct_tracking, $tracking);

		$urls = $this->normalize_interaction_urls([
			'landing_url' => $data['landing_url'] ?? '',
			'current_url' => $data['url'] ?? ($data['current_url'] ?? ''),
			'referrer_url' => $data['referrer'] ?? ($data['referrer_url'] ?? ''),
			'object_url' => $data['object_url'] ?? '',
		]);

		if (is_wp_error($urls)) {
			return $urls;
		}

		$object_id = $this->normalize_non_negative_integer($data['object_id'] ?? 0);
		$conversion_event_id = $this->normalize_non_negative_integer(
			$data['conversion_event_id'] ?? 0,
		);

		// DATA INTEGRITY INVARIANT: External references must remain exact.
		// Negative, fractional or structured values must never be coerced into a
		// different valid object or conversion-event identity.
		if (null === $object_id || null === $conversion_event_id) {
			return new WP_Error(
				'wphave_audience_interaction_reference_invalid',
				__('Interaction references must be non-negative integers.', 'wphave'),
				['status' => 400],
			);
		}

		$routing_keys = $this->normalize_interaction_routing_keys([
			'object_type' => $data['object_type'] ?? '',
			'object_subtype' => $data['object_subtype'] ?? '',
			'goal_id' => $data['goal_id'] ?? '',
		]);

		if (is_wp_error($routing_keys)) {
			return $routing_keys;
		}

		$raw_object_label = $data['object_label'] ?? '';

		if (!is_scalar($raw_object_label)) {
			return new WP_Error(
				'wphave_audience_object_label_invalid',
				__('Object label must be a text value.', 'wphave'),
				['status' => 400],
			);
		}

		$object_label = sanitize_text_field((string) $raw_object_label);
		$object_label_length = function_exists('mb_strlen')
			? mb_strlen($object_label)
			: strlen($object_label);

		// DATA INTEGRITY INVARIANT: Interaction labels and derived lead titles
		// share one bounded representation so database truncation cannot make
		// the immutable origin disagree with the operational projection.
		if ($object_label_length > 255) {
			return new WP_Error(
				'wphave_audience_object_label_invalid',
				__('Object label must not exceed 255 characters.', 'wphave'),
				['status' => 400],
			);
		}

		$journey_ids = $this->normalize_interaction_journey_ids([
			'visitor_id' => $data['visitor_id'] ?? '',
			'session_id' => $data['session_id'] ?? '',
		]);

		if (is_wp_error($journey_ids)) {
			return $journey_ids;
		}

		$fingerprint = hash(
			'sha256',
			wp_json_encode([$type, $event, $email, $payload, $this->get_ip_hash(), $object_key]),
		);

		$duplicate = $this->is_duplicate_lead($fingerprint);

		if (is_wp_error($duplicate)) {
			return $duplicate;
		}

		if ($duplicate) {
			return new WP_Error(
				'wphave_audience_duplicate',
				__('Duplicate lead blocked.', 'wphave'),
				['status' => 409],
			);
		}

		$contact_id = $this->resolve_contact($email, [
			'first_name' => $data['first_name'] ?? '',
			'last_name' => $data['last_name'] ?? '',
		]);

		if (is_wp_error($contact_id)) {
			return $contact_id;
		}

		$interaction = $this->record_interaction([
			'submission_id' => $submission_id,
			'contact_id' => absint($contact_id),
			'type' => $type,
			'event' => $event,
			'source' => $tracking['utm_source'] ?? '',
			'medium' => $tracking['utm_medium'] ?? '',
			'campaign' => $tracking['utm_campaign'] ?? '',
			'content' => $tracking['utm_content'] ?? '',
			'term' => $tracking['utm_term'] ?? '',
			'landing_url' => $urls['landing_url'],
			'current_url' => $urls['current_url'],
			'referrer_url' => $urls['referrer_url'],
			'object_type' => $routing_keys['object_type'],
			'object_id' => $object_id,
			'object_subtype' => $routing_keys['object_subtype'],
			'object_key' => $object_key,
			'object_label' => $object_label,
			'object_url' => $urls['object_url'],
			'goal_id' => $routing_keys['goal_id'],
			'conversion_event_id' => $conversion_event_id,
			'visitor_id' => $journey_ids['visitor_id'],
			'session_id' => $journey_ids['session_id'],
			'fingerprint' => $fingerprint,
			'payload' => $payload,
			'occurred_at' => $occurred_at,
		]);

		if (is_wp_error($interaction)) {
			return $interaction;
		}

		$lead = $this->create_operational_lead(
			absint($contact_id),
			absint($interaction['id'] ?? 0),
			[
				'title' => $object_label ?: $event ?: __('Website lead', 'wphave'),
				'created_at' => $occurred_at,
			],
		);

		return is_wp_error($lead) ? $lead : $this->decorate_lead($lead);
	}

	/**
	 * Creates or updates a subscriber record for one purpose.
	 *
	 * The site-scoped email HMAC and purpose form the stable subscription identity,
	 * including after personal fields are minimized. Pending writes rotate an
	 * expiring one-time credential when they originate without a resource id.
	 * Consent evidence is appended only for a real status transition or a renewed
	 * confirmation request; ordinary profile edits cannot fabricate another grant.
	 * The canonical relationship is contact_id. A direct identity relation is
	 * intentionally omitted because it would duplicate contact identity ownership.
	 *
	 * @param array<string, mixed> $data Subscriber profile, purpose and transition data.
	 * @return array<string, mixed>|WP_Error Sanitized subscriber read model or error.
	 */

	private function save_subscriber(array $data, bool $public = false) {
		if (!$this->has_required_schema()) {
			return $this->schema_unavailable_error();
		}

		global $wpdb;

		$email = $this->normalize_email($data['email'] ?? '');

		if (!is_email($email)) {
			return new WP_Error(
				'wphave_audience_invalid_email',
				__('Invalid email address.', 'wphave'),
				['status' => 400],
			);
		}

		$requested_id = absint($data['id'] ?? 0);
		$previous = $requested_id ? $this->get_row($this->subscribers_table, $requested_id) : null;

		if ($requested_id && !$previous) {
			return new WP_Error(
				'wphave_audience_subscriber_missing',
				__('Subscriber was not found.', 'wphave'),
				['status' => 404],
			);
		}

		$profile = $this->normalize_contact_profile([
			'first_name' => $data['first_name'] ?? ($previous['first_name'] ?? ''),
			'last_name' => $data['last_name'] ?? ($previous['last_name'] ?? ''),
		]);

		if (is_wp_error($profile)) {
			return $profile;
		}

		$raw_purpose = $data['purpose'] ?? ($previous['purpose'] ?? '');

		$purpose = $this->normalize_purpose_key($raw_purpose);

		if (!$purpose) {
			return new WP_Error(
				'wphave_audience_purpose_invalid',
				__('Select a valid subscription purpose.', 'wphave'),
				['status' => 400],
			);
		}

		$active_purpose = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT purpose_key FROM {$this->purposes_table} WHERE purpose_key = %s AND channel = 'email' AND is_active = 1 LIMIT 1",
				$purpose,
			),
		);

		if ($wpdb->last_error) {
			return new WP_Error(
				'wphave_audience_purpose_read_failed',
				__('Subscription purposes could not be validated.', 'wphave'),
				['status' => 500],
			);
		}

		$retains_existing_purpose = $previous && $purpose === ($previous['purpose'] ?? '');

		if (!$active_purpose && !$retains_existing_purpose) {
			return new WP_Error(
				'wphave_audience_purpose_invalid',
				__('Select an active email subscription purpose.', 'wphave'),
				['status' => 400],
			);
		}

		$metadata_limits = [
			'source' => 100,
			'medium' => 100,
			'campaign' => 150,
			'consent_label' => 255,
		];
		$metadata = [];

		foreach ($metadata_limits as $field => $limit) {
			$raw_value = $data[$field] ?? ($previous[$field] ?? '');

			if (!is_scalar($raw_value)) {
				return new WP_Error(
					'wphave_audience_subscriber_metadata_invalid',
					__('Subscriber metadata fields must be text values.', 'wphave'),
					['status' => 400, 'field' => $field],
				);
			}

			$value = sanitize_text_field((string) $raw_value);
			$length = function_exists('mb_strlen') ? mb_strlen($value) : strlen($value);

			if ($length > $limit) {
				return new WP_Error(
					'wphave_audience_subscriber_metadata_too_long',
					__(
						'One or more subscriber metadata fields exceed their supported length.',
						'wphave',
					),
					['status' => 400, 'field' => $field, 'max_length' => $limit],
				);
			}

			$metadata[$field] = $value;
		}

		$now = current_time('mysql');
		$has_explicit_occurred_at = array_key_exists('occurred_at', $data);
		$occurred_at = $has_explicit_occurred_at
			? $this->normalize_mysql_datetime($data['occurred_at'])
			: $now;

		// DATA INTEGRITY INVARIANT: Explicit consent transition time is audit
		// evidence. Invalid caller input fails before subscriber or consent state
		// can be persisted under a fabricated server timestamp.
		if ('' === $occurred_at) {
			return new WP_Error(
				'wphave_audience_subscriber_timestamp_invalid',
				__('Subscriber timestamp must be a valid MySQL datetime.', 'wphave'),
				['status' => 400],
			);
		}
		$raw_status = $data['status'] ?? ($previous['status'] ?? 'subscribed');

		if (!is_scalar($raw_status)) {
			return new WP_Error(
				'wphave_audience_subscriber_status_invalid',
				__('Subscriber status must be a text value.', 'wphave'),
				['status' => 400],
			);
		}

		$canonical_status_input = strtolower(trim((string) $raw_status));
		$status = sanitize_key($canonical_status_input);

		if (
			$status !== $canonical_status_input ||
			!in_array($status, ['subscribed', 'pending', 'unsubscribed'], true)
		) {
			return new WP_Error(
				'wphave_audience_subscriber_status_invalid',
				__('Select a valid subscriber status.', 'wphave'),
				['status' => 400],
			);
		}

		$email_hash = $this->subscriber_email_hash($email);
		$id =
			$requested_id ?:
			absint(
				$wpdb->get_var(
					$wpdb->prepare(
						"SELECT id FROM {$this->subscribers_table} WHERE email_hash = %s AND purpose = %s LIMIT 1 FOR UPDATE",
						$email_hash,
						$purpose,
					),
				),
			);
		$previous = $previous ?: ($id ? $this->get_row($this->subscribers_table, $id) : null);
		$public_existing = $public && $previous;
		if ($public_existing) {
			// OWNERSHIP INVARIANT: Knowing an address never authorizes editing
			// its existing subscription. Preserve status, consent and profile.
			// A live DOI grant also remains valid; retries must not rotate it.
			$grant = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT confirm_token_hash, confirm_expires_at FROM {$this->subscribers_table} WHERE id = %d",
					$id,
				),
				ARRAY_A,
			);
			if (!$grant || $wpdb->last_error) {
				return new WP_Error(
					'wphave_audience_grant_read_failed',
					__('Subscription could not be processed.', 'wphave'),
					['status' => 503],
				);
			}
			if (
				$previous['status'] === 'subscribed' ||
				(!empty($grant['confirm_token_hash']) &&
					($grant['confirm_expires_at'] ?? '') >= current_time('mysql'))
			) {
				return $previous;
			}
			// RE-SUBSCRIPTION INVARIANT: Even without default DOI, an existing
			// withdrawn subscription stays withdrawn until its owner confirms.
			$status = $previous['status'];
		}
		$previous_status = sanitize_key($previous['status'] ?? '');
		$status_changed = !$previous || $previous_status !== $status;
		$confirmation_token = '';
		$rotate_confirmation =
			$public_existing || ($status === 'pending' && ($status_changed || !$requested_id));

		$row = [
			'email' => $email,
			'email_hash' => $email_hash,
			'first_name' => $profile['first_name'],
			'last_name' => $profile['last_name'],
			'status' => $status,
			'purpose' => $purpose,
			'source' => $metadata['source'],
			'medium' => $metadata['medium'],
			'campaign' => $metadata['campaign'],
			'lead_id' => absint($data['lead_id'] ?? 0),
			'consent' => $status === 'subscribed' ? 1 : 0,
			'consent_label' => $metadata['consent_label'],
			'consent_at' =>
				$status === 'subscribed'
					? ($previous['consent_at'] ?? null ?:
					$occurred_at)
					: $previous['consent_at'] ?? null,
			'confirmed_at' =>
				$status === 'subscribed'
					? ($previous['confirmed_at'] ?? null ?:
					$occurred_at)
					: null,
			'unsubscribed_at' =>
				$status === 'unsubscribed'
					? ($previous['unsubscribed_at'] ?? null ?:
					$occurred_at)
					: null,
			'updated_at' => $occurred_at,
		];

		if ($public_existing) {
			$row = []; // Only the new ownership grant may change before proof.
		}
		if ($rotate_confirmation) {
			$confirmation_token = $this->generate_token();
			$token_ttl = max(
				HOUR_IN_SECONDS,
				absint(
					apply_filters(
						'wphave_audience_confirmation_token_ttl',
						self::CONFIRMATION_TOKEN_TTL,
						$purpose,
					),
				),
			);
			$row['confirm_token_hash'] = $this->confirmation_token_hash($confirmation_token);
			$row['confirm_expires_at'] = current_datetime()
				->modify('+' . $token_ttl . ' seconds')
				->format('Y-m-d H:i:s');
		} elseif ($status !== 'pending') {
			$row['confirm_token_hash'] = '';
			$row['confirm_expires_at'] = null;
		}

		$contact_id = $public_existing
			? $previous['contact_id']
			: $this->resolve_contact($email, [
				'first_name' => $row['first_name'],
				'last_name' => $row['last_name'],
			]);

		if (is_wp_error($contact_id)) {
			return $contact_id;
		}

		$row['contact_id'] = absint($contact_id);

		if ($previous) {
			$updated = $wpdb->update($this->subscribers_table, $row, ['id' => $id]);

			if ($updated === false) {
				return new WP_Error(
					'wphave_audience_subscriber_update_failed',
					__('Subscriber could not be updated.', 'wphave'),
					['status' => 500],
				);
			}
		} else {
			$row['created_at'] = $occurred_at;
			$inserted = $wpdb->insert($this->subscribers_table, $row);

			if (!$inserted) {
				return new WP_Error(
					'wphave_audience_subscriber_insert_failed',
					__('Subscriber could not be stored.', 'wphave'),
					['status' => 500],
				);
			}

			$id = (int) $wpdb->insert_id;
		}

		$subscriber = $this->get_row($this->subscribers_table, $id);

		if (!$subscriber) {
			return new WP_Error(
				'wphave_audience_subscriber_missing',
				__('Subscriber could not be loaded after saving.', 'wphave'),
				['status' => 500],
			);
		}

		if ($confirmation_token) {
			$this->pending_confirmation_subscribers[absint($subscriber['id'])] = array_merge(
				$subscriber,
				['confirmation_token' => $confirmation_token],
			);
		}

		if ($status_changed || $confirmation_token) {
			$consent_action = $this->normalize_closed_key($data['consent_action'] ?? '', [
				'granted',
				'granted_manually',
			]);

			if (!in_array($consent_action, ['granted', 'granted_manually'], true)) {
				$consent_action = !empty($data['consent']) ? 'granted' : 'granted_manually';
			}

			$consent_recorded = $this->record_consent_event([
				'contact_id' => absint($subscriber['contact_id'] ?? 0),
				'subscriber_id' => absint($subscriber['id'] ?? 0),
				'purpose' => $subscriber['purpose'] ?? '',
				'action' =>
					$confirmation_token !== ''
						? 'requested'
						: ($status === 'unsubscribed'
							? 'withdrawn'
							: $consent_action),
				'source' => sanitize_text_field(
					$data['consent_source'] ?? ($subscriber['source'] ?? ''),
				),
				'statement_snapshot' => $subscriber['consent_label'] ?? '',
				'occurred_at' => $occurred_at,
			]);

			if (!$consent_recorded) {
				unset($this->pending_confirmation_subscribers[absint($subscriber['id'] ?? 0)]);

				return new WP_Error(
					'wphave_audience_consent_event_failed',
					__('Subscriber consent evidence could not be stored.', 'wphave'),
					['status' => 500],
				);
			}
		}

		return $subscriber;
	}

	/**
	 * Build the stable, site-scoped subscriber identity hash.
	 *
	 * @param string $email Normalized subscriber email.
	 * @return string HMAC used for uniqueness, suppression and privacy lookup.
	 */
	private function subscriber_email_hash(string $email): string {
		return hash_hmac('sha256', $email, wp_salt('auth'));
	}

	/**
	 * Hash a high-entropy confirmation token before persistence.
	 *
	 * @param string $token Raw one-time token delivered only by email.
	 * @return string Irreversible lookup hash.
	 */
	private function confirmation_token_hash(string $token): string {
		return hash('sha256', $token);
	}

	/**
	 * Deliver only confirmation mail queued by the current transaction scope.
	 *
	 * A caller may run inside a longer-lived process that already owns pending
	 * deliveries. Those entries remain queued for their owning workflow and must
	 * neither be discarded on rollback nor flushed by an unrelated commit.
	 *
	 * @param array<int, array<string, mixed>> $preserved Queue state before the transaction.
	 * @return void
	 */
	private function flush_confirmation_emails_since(array $preserved): void {
		$current = $this->pending_confirmation_subscribers;
		$this->pending_confirmation_subscribers = $preserved;

		foreach ($current as $subscriber_id => $subscriber) {
			if (isset($preserved[$subscriber_id]) && $preserved[$subscriber_id] === $subscriber) {
				continue;
			}

			$this->send_confirmation_email($subscriber);
		}
	}

	/**
	 * Read the registered double-opt-in policy for a subscription purpose.
	 *
	 * Unknown purposes fail closed and require confirmation.
	 *
	 * @param mixed $purpose Subscription purpose key.
	 * @return bool Whether confirmation is required.
	 */
	private function purpose_requires_double_opt_in($purpose): bool {
		global $wpdb;

		// SECURITY INVARIANT: Purpose identities are matched losslessly; malformed
		// input must remain unknown and therefore retain the fail-closed DOI policy.
		$purpose = $this->normalize_purpose_key($purpose);

		if ('' === $purpose) {
			return true;
		}

		$requires = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT requires_double_opt_in FROM {$this->purposes_table} WHERE purpose_key = %s AND is_active = 1",
				$purpose,
			),
		);

		return $requires === null ? true : (bool) $requires;
	}

	/**
	 * Maps validated form values to Audience fields and payload data.
	 *
	 * @param array $values Validated form values.
	 * @param array $schema Parsed form schema.
	 * @return array Normalized Audience form values.
	 */

	private function map_form_values(array $values, array $schema): array {
		$mapped = [
			'email' => '',
			'first_name' => '',
			'last_name' => '',
			'consent' => false,
			'consent_label' => '',
			'payload' => [],
		];

		foreach ($values as $name => $value) {
			$field = $schema[$name] ?? [];
			$label = sanitize_text_field($field['label'] ?? $name);
			$role = sanitize_key($field['attrs']['audienceRole'] ?? '');
			$type = sanitize_key($field['type'] ?? '');
			if ($type === 'file' && is_array($value)) {
				$flat_value = sanitize_file_name($value['name'] ?? '');
			} else {
				$flat_value = is_array($value)
					? implode(', ', array_map('sanitize_text_field', array_map('strval', $value)))
					: sanitize_text_field((string) $value);
			}

			if ($flat_value === '') {
				continue;
			}

			$mapped['payload'][sanitize_key($name)] = [
				'label' => $label,
				'value' => $flat_value,
			];

			$lookup = strtolower($role . ' ' . $name . ' ' . $label);

			if (
				!$mapped['email'] &&
				($type === 'email' || $role === 'email') &&
				is_email($flat_value)
			) {
				$mapped['email'] = strtolower(sanitize_email($flat_value));
				continue;
			}

			if (
				!$mapped['first_name'] &&
				preg_match('/(^|[_\\s-])(first|firstname|first_name|vorname)([_\\s-]|$)/', $lookup)
			) {
				$mapped['first_name'] = $flat_value;
				continue;
			}

			if (!$mapped['consent'] && $role === 'consent') {
				$mapped['consent'] = !in_array(
					strtolower($flat_value),
					['', '0', 'false', 'no', 'off'],
					true,
				);
				$mapped['consent_label'] = $label;
				continue;
			}

			if (
				!$mapped['last_name'] &&
				preg_match(
					'/(^|[_\\s-])(last|lastname|last_name|surname|nachname)([_\\s-]|$)/',
					$lookup,
				)
			) {
				$mapped['last_name'] = $flat_value;
			}
		}

		if (!$mapped['first_name'] && !$mapped['last_name']) {
			foreach ($values as $name => $value) {
				$field = $schema[$name] ?? [];
				$type = sanitize_key($field['type'] ?? '');
				$label = strtolower((string) ($field['label'] ?? $name));

				if ($type === 'text' && str_contains($label, 'name') && is_scalar($value)) {
					$parts = preg_split('/\s+/', trim(sanitize_text_field((string) $value)));
					$mapped['first_name'] = $parts[0] ?? '';
					$mapped['last_name'] =
						count($parts) > 1 ? implode(' ', array_slice($parts, 1)) : '';
					break;
				}
			}
		}

		return $mapped;
	}

	/**
	 * Formats a subscriber purpose key for display.
	 *
	 * @param string $purpose Purpose key.
	 * @return string Human-readable purpose label.
	 */

	private function format_purpose_label(string $purpose): string {
		global $wpdb;

		$key = $this->normalize_purpose_key($purpose);

		if ('' === $key) {
			return __('Unknown purpose', 'wphave');
		}

		$label = $this->table_exists($this->purposes_table)
			? $wpdb->get_var(
				$wpdb->prepare(
					"SELECT label FROM {$this->purposes_table} WHERE purpose_key = %s",
					$key,
				),
			)
			: '';

		return $label ?: ucwords(str_replace('_', ' ', $key));
	}

	/**
	 * Return the extensible allowlist for lead and interaction types.
	 *
	 * Extension values must already be exact storage-safe keys. Malformed filter
	 * output is ignored rather than repaired into a different registered type.
	 *
	 * @return array<int, string> Exact registered type keys.
	 */
	private function registered_lead_types(): array {
		$types = ['form', 'click', 'download', 'outbound', 'signup', 'system'];
		$registered = [];

		foreach ((array) apply_filters('wphave_audience_lead_types', $types) as $type) {
			if (!is_string($type)) {
				continue;
			}

			$canonical = strtolower(trim($type));

			// EXTENSION INVARIANT: Filter-provided routing identities must be
			// canonical already; sanitization may validate but never rewrite them.
			if (
				$type !== $canonical ||
				'' === $canonical ||
				strlen($canonical) > 100 ||
				sanitize_key($canonical) !== $canonical
			) {
				continue;
			}

			$registered[] = $canonical;
		}

		return array_values(array_unique($registered));
	}

	/**
	 * Queries an Audience table with paging, filters and search.
	 *
	 * @param string $table Fully qualified table name.
	 * @param WP_REST_Request $request REST request with query parameters.
	 * @param array $search_columns Columns used for search.
	 * @param string $date_column Column used for sorting.
	 * @param array $sortable_columns Explicit allowlist of sortable columns.
	 * @param array $default_excluded_statuses Statuses hidden without an explicit status filter.
	 * @return array Paginated query result.
	 */

	private function query_table(
		string $table,
		WP_REST_Request $request,
		array $search_columns,
		string $date_column = 'created_at',
		array $sortable_columns = [],
		array $default_excluded_statuses = [],
	): array {
		if (!$this->table_exists($table)) {
			return [
				'items' => [],
				'total' => 0,
				'page' => 1,
				'per_page' => max(1, min(100, absint($request->get_param('per_page') ?: 20))),
				'pages' => 1,
			];
		}

		global $wpdb;

		$page = max(1, absint($request->get_param('page') ?: 1));
		$per_page = max(1, min(100, absint($request->get_param('per_page') ?: 20)));
		$offset = ($page - 1) * $per_page;
		$search = sanitize_text_field($request->get_param('search') ?? '');
		$requested_orderby = sanitize_key($request->get_param('orderby') ?? '');
		$orderby = in_array($requested_orderby, $sortable_columns, true)
			? $requested_orderby
			: $date_column;
		$order =
			strtolower(sanitize_key($request->get_param('order') ?? '')) === 'asc' ? 'ASC' : 'DESC';
		$where = 'WHERE 1=1';
		$params = [];
		$requested_status = sanitize_text_field($request->get_param('status') ?? '');

		if (
			!$requested_status &&
			$default_excluded_statuses &&
			$this->column_exists($table, 'status')
		) {
			$excluded_statuses = array_values(
				array_filter(array_unique(array_map('sanitize_key', $default_excluded_statuses))),
			);

			if ($excluded_statuses) {
				$placeholders = implode(', ', array_fill(0, count($excluded_statuses), '%s'));
				$where .= " AND status NOT IN ({$placeholders})";
				$params = array_merge($params, $excluded_statuses);
			}
		}

		foreach (['status', 'type', 'purpose', 'source', 'campaign', 'goal_id'] as $filter) {
			$value = sanitize_text_field($request->get_param($filter) ?? '');

			if ($value && $this->column_exists($table, $filter)) {
				$where .= " AND {$filter} = %s";
				$params[] = $value;
			}
		}

		if ($search) {
			$like = '%' . $wpdb->esc_like($search) . '%';
			$clauses = array_map(fn($column) => "{$column} LIKE %s", $search_columns);
			$where .= ' AND (' . implode(' OR ', $clauses) . ')';
			$params = array_merge($params, array_fill(0, count($search_columns), $like));
		}

		$count_query = "SELECT COUNT(*) FROM {$table} {$where}";
		$total = (int) $wpdb->get_var(
			$params ? $wpdb->prepare($count_query, ...$params) : $count_query,
		);
		$items = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} {$where} ORDER BY {$orderby} {$order}, id {$order} LIMIT %d OFFSET %d",
				...array_merge($params, [$per_page, $offset]),
			),
			ARRAY_A,
		);

		return [
			'items' => array_map([$this, 'format_row'], $items ?: []),
			'total' => $total,
			'page' => $page,
			'per_page' => $per_page,
			'pages' => $per_page ? (int) ceil($total / $per_page) : 1,
		];
	}

	/**
	 * Return unfiltered counts for one categorical table column.
	 *
	 * Summary bars describe the complete collection and must not change with
	 * pagination, search or active table filters.
	 *
	 * @param string $table Fully qualified table name.
	 * @param string $column Grouping column.
	 * @return array<string, int> Counts keyed by normalized category.
	 */
	private function get_grouped_counts(string $table, string $column): array {
		if (
			!$this->table_exists($table) ||
			!in_array($column, ['type', 'status'], true) ||
			!$this->column_exists($table, $column)
		) {
			return [];
		}

		global $wpdb;

		$rows =
			$wpdb->get_results(
				"SELECT {$column} category, COUNT(*) total FROM {$table} GROUP BY {$column} ORDER BY total DESC, {$column} ASC",
				ARRAY_A,
			) ?:
			[];
		$counts = [];

		foreach ($rows as $row) {
			$category = sanitize_key($row['category'] ?? '');

			if (!$category) {
				$category = 'unknown';
			}

			$counts[$category] = absint($row['total'] ?? 0);
		}

		return $counts;
	}

	/**
	 * Loads one Audience table row by id.
	 *
	 * @param string $table Fully qualified table name.
	 * @param int $id Row id.
	 * @return array|null Formatted row or null.
	 */

	private function get_row(string $table, int $id): ?array {
		if (!$this->table_exists($table)) {
			return null;
		}

		global $wpdb;

		$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $id), ARRAY_A);

		return $row ? $this->format_row($row) : null;
	}

	/**
	 * Loads Audience rows by their integer identifiers.
	 *
	 * @param string $table Fully qualified table name.
	 * @param int[]  $ids Row identifiers.
	 * @return array<int, array> Formatted rows keyed by identifier.
	 */

	private function get_rows_by_ids(string $table, array $ids): array {
		if (!$this->table_exists($table)) {
			return [];
		}

		$ids = array_values(array_unique(array_filter(array_map('absint', $ids))));
		if (!$ids) {
			return [];
		}

		global $wpdb;

		$placeholders = implode(', ', array_fill(0, count($ids), '%d'));
		$rows =
			$wpdb->get_results(
				$wpdb->prepare("SELECT * FROM {$table} WHERE id IN ({$placeholders})", ...$ids),
				ARRAY_A,
			) ?:
			[];
		$indexed = [];

		foreach ($rows as $row) {
			$formatted = $this->format_row($row);
			$indexed[absint($formatted['id'] ?? 0)] = $formatted;
		}

		return $indexed;
	}

	/**
	 * Loads analytics journey events connected to a lead session.
	 *
	 * @param array $lead Lead row data.
	 * @return array Journey rows.
	 */

	private function get_lead_journey(array $lead): array {
		global $wpdb;

		$session_hash = sanitize_text_field($lead['session_hash'] ?? '');
		$events_table = $wpdb->prefix . 'wphave_analytics_events';

		if (
			!$session_hash ||
			!class_exists('WPHAVE_Analytics_Schema') ||
			!class_exists('WPHAVE_Analytics_Event_Query')
		) {
			return [];
		}

		$schema = new WPHAVE_Analytics_Schema(
			$events_table,
			$wpdb->prefix . 'wphave_analytics_daily',
		);
		$query = new WPHAVE_Analytics_Event_Query($events_table, $schema);

		return $query->get_session_journey($session_hash);
	}

	/**
	 * Deletes one Audience row by id.
	 *
	 * @param string $table Fully qualified table name.
	 * @param int $id Row id.
	 * @return bool True when a row was deleted.
	 */

	private function delete_row(string $table, int $id): bool {
		if (!$this->table_exists($table)) {
			return false;
		}

		global $wpdb;

		return $id ? (bool) $wpdb->delete($table, ['id' => $id], ['%d']) : false;
	}

	/**
	 * Normalizes database row values for REST responses.
	 *
	 * @param array $row Raw database row.
	 * @return array Formatted row.
	 */

	private function format_row(array $row): array {
		unset($row['email_hash'], $row['confirm_token_hash'], $row['confirm_expires_at']);

		foreach (
			[
				'id',
				'object_id',
				'lead_id',
				'contact_id',
				'origin_interaction_id',
				'pipeline_id',
				'stage_id',
				'owner_user_id',
				'interaction_id',
				'actor_user_id',
			]
			as $key
		) {
			if (isset($row[$key])) {
				$row[$key] = (int) $row[$key];
			}
		}

		if (isset($row['payload']) && is_string($row['payload'])) {
			$decoded = json_decode($row['payload'], true);
			$row['payload'] = is_array($decoded) ? $decoded : [];
		}

		$email = sanitize_email($row['email'] ?? '');
		$row['avatar_url'] = $email ? wphave_get_avatar_url($email, ['size' => 48]) : '';

		return $row;
	}

	/**
	 * Sanitizes UTM tracking data.
	 *
	 * @param mixed $tracking Raw tracking input.
	 * @return array<string, string>|WP_Error Sanitized tracking values or contract error.
	 */

	private function sanitize_tracking($tracking) {
		$result = [];
		$limits = [
			'utm_source' => 100,
			'utm_medium' => 100,
			'utm_campaign' => 150,
			'utm_content' => 150,
			'utm_term' => 150,
		];

		if (!is_array($tracking)) {
			return $result;
		}

		foreach ($tracking as $key => $value) {
			if (!is_string($key) || sanitize_key($key) !== $key || !isset($limits[$key])) {
				continue;
			}

			if (!is_scalar($value)) {
				return new WP_Error(
					'wphave_audience_tracking_invalid',
					__('Tracking dimensions must be text values.', 'wphave'),
					['status' => 400, 'field' => $key],
				);
			}

			$sanitized_value = sanitize_text_field((string) $value);
			$value_length = function_exists('mb_strlen')
				? mb_strlen($sanitized_value)
				: strlen($sanitized_value);

			// DATA INTEGRITY INVARIANT: Tracking dimensions may be sanitized as
			// descriptive marketing data, but must never be truncated by storage
			// or interpreted through an undocumented alternate input shape.
			if ($value_length > $limits[$key]) {
				return new WP_Error(
					'wphave_audience_tracking_invalid',
					__('One or more tracking dimensions exceed their supported length.', 'wphave'),
					['status' => 400, 'field' => $key, 'max_length' => $limits[$key]],
				);
			}

			$result[$key] = $sanitized_value;
		}

		return $result;
	}

	/**
	 * Validate bounded interaction URLs before they enter immutable history.
	 *
	 * @param array<string, mixed> $urls URL fields keyed by storage column.
	 * @return array<string, string>|WP_Error Canonical URLs or contract error.
	 */
	private function normalize_interaction_urls(array $urls) {
		$normalized = [];

		foreach ($urls as $field => $value) {
			if (!is_scalar($value)) {
				return new WP_Error(
					'wphave_audience_interaction_url_invalid',
					__('Interaction URLs must be text values.', 'wphave'),
					['status' => 400, 'field' => $field],
				);
			}

			$submitted_url = (string) $value;
			$url = trim($submitted_url);
			$safe_url = esc_url_raw($url, ['http', 'https']);

			// SECURITY INVARIANT: Immutable interaction URLs must never retain
			// executable schemes or be silently rewritten into a different
			// navigation target. The bound also limits durable untrusted input.
			if (
				$submitted_url !== $url ||
				strlen($url) > 2048 ||
				('' !== $url && $safe_url !== $url)
			) {
				return new WP_Error(
					'wphave_audience_interaction_url_invalid',
					__(
						'Interaction URLs must be unchanged safe HTTP(S) or relative URLs up to 2048 characters.',
						'wphave',
					),
					['status' => 400, 'field' => $field],
				);
			}

			$normalized[$field] = $safe_url;
		}

		return $normalized;
	}

	/**
	 * Validate optional routing keys against their storage capacities.
	 *
	 * @param array<string, mixed> $keys Routing keys by storage column.
	 * @return array<string, string>|WP_Error Canonical keys or contract error.
	 */
	private function normalize_interaction_routing_keys(array $keys) {
		$limits = [
			'object_type' => 40,
			'object_subtype' => 100,
			'goal_id' => 190,
		];
		$normalized = [];

		foreach ($limits as $field => $limit) {
			$value = $keys[$field] ?? '';

			if (!is_scalar($value)) {
				return new WP_Error(
					'wphave_audience_interaction_routing_invalid',
					__('Interaction routing keys must be text values.', 'wphave'),
					['status' => 400, 'field' => $field],
				);
			}

			$canonical = strtolower(trim((string) $value));

			// DATA INTEGRITY INVARIANT: Routing keys connect Audience and
			// Analytics dimensions. Key sanitization or database truncation must
			// never redirect an interaction into a different reporting bucket.
			if (strlen($canonical) > $limit || sanitize_key($canonical) !== $canonical) {
				return new WP_Error(
					'wphave_audience_interaction_routing_invalid',
					__(
						'Interaction routing keys must be canonical and within their supported length.',
						'wphave',
					),
					['status' => 400, 'field' => $field, 'max_length' => $limit],
				);
			}

			$normalized[$field] = $canonical;
		}

		return $normalized;
	}

	/**
	 * Validate pseudonymous journey identities before hashing.
	 *
	 * @param array<string, mixed> $ids Visitor and session identifiers.
	 * @return array<string, string>|WP_Error Exact identifiers or contract error.
	 */
	private function normalize_interaction_journey_ids(array $ids) {
		$normalized = [];

		foreach (['visitor_id', 'session_id'] as $field) {
			$value = $ids[$field] ?? '';

			if (!is_scalar($value)) {
				return new WP_Error(
					'wphave_audience_journey_identity_invalid',
					__('Journey identities must be text values.', 'wphave'),
					['status' => 400, 'field' => $field],
				);
			}

			$submitted_value = (string) $value;
			$canonical = trim($submitted_value);
			$sanitized = sanitize_text_field($canonical);
			$length = function_exists('mb_strlen') ? mb_strlen($canonical) : strlen($canonical);

			// PRIVACY INVARIANT: Pseudonymous journey hashes must represent the
			// exact supplied identity. Sanitization, trimming or unbounded input
			// must never collapse distinct visitors or sessions into one hash.
			if ($submitted_value !== $canonical || $canonical !== $sanitized || $length > 190) {
				return new WP_Error(
					'wphave_audience_journey_identity_invalid',
					__(
						'Journey identities must be unchanged by sanitization and must not exceed 190 characters.',
						'wphave',
					),
					['status' => 400, 'field' => $field],
				);
			}

			$normalized[$field] = $canonical;
		}

		return $normalized;
	}

	/**
	 * Validate and sanitize a lead payload without silent structural loss.
	 *
	 * @param mixed $payload Submitted lead payload.
	 * @return array<string|int, mixed>|WP_Error Bounded payload or contract error.
	 */
	private function normalize_lead_payload($payload) {
		$normalized = $this->normalize_lead_payload_node($payload);

		if (is_wp_error($normalized)) {
			return $normalized;
		}

		$encoded = wp_json_encode($normalized);

		if (false === $encoded || strlen($encoded) > 65535) {
			return new WP_Error(
				'wphave_audience_payload_invalid',
				__('Lead payload exceeds the supported total size.', 'wphave'),
				['status' => 400],
			);
		}

		return $normalized;
	}

	/**
	 * Recursively normalize one bounded lead payload node.
	 *
	 * @param mixed $payload Current payload node.
	 * @param int $depth Current nesting depth.
	 * @return array<string, mixed>|WP_Error Normalized node or contract error.
	 */
	private function normalize_lead_payload_node($payload, int $depth = 0) {
		if (!is_array($payload) || $depth > 3 || count($payload) > 50) {
			return new WP_Error(
				'wphave_audience_payload_invalid',
				__(
					'Lead payload must be an array with at most 50 entries per level and four levels of nesting.',
					'wphave',
				),
				['status' => 400],
			);
		}

		$normalized = [];

		foreach ($payload as $key => $value) {
			$canonical_key = is_string($key) ? sanitize_key($key) : 'item_' . $key;

			// DATA INTEGRITY INVARIANT: Payload normalization must never merge
			// distinct submitted fields or silently discard overflow. Such loss
			// would make the immutable interaction differ from accepted input.
			if (
				'' === $canonical_key ||
				(is_string($key) && $canonical_key !== $key) ||
				array_key_exists($canonical_key, $normalized)
			) {
				return new WP_Error(
					'wphave_audience_payload_invalid',
					__('Lead payload keys must be unique canonical storage keys.', 'wphave'),
					['status' => 400],
				);
			}

			if (is_array($value)) {
				$normalized_value = $this->normalize_lead_payload_node($value, $depth + 1);

				if (is_wp_error($normalized_value)) {
					return $normalized_value;
				}
			} elseif (is_scalar($value) || null === $value) {
				$normalized_value = sanitize_text_field((string) ($value ?? ''));
				$value_length = function_exists('mb_strlen')
					? mb_strlen($normalized_value)
					: strlen($normalized_value);

				if ($value_length > 500) {
					return new WP_Error(
						'wphave_audience_payload_invalid',
						__('Lead payload values must not exceed 500 characters.', 'wphave'),
						['status' => 400, 'field' => $canonical_key],
					);
				}
			} else {
				return new WP_Error(
					'wphave_audience_payload_invalid',
					__('Lead payload values must be text values or nested arrays.', 'wphave'),
					['status' => 400, 'field' => $canonical_key],
				);
			}

			$normalized[$canonical_key] = $normalized_value;
		}

		return $normalized;
	}

	/**
	 * Sanitizes arbitrary submitted payload data with depth and size limits.
	 *
	 * @param mixed $data Raw payload data.
	 * @param int $depth Current recursion depth.
	 * @return array Sanitized payload.
	 */

	private function sanitize_payload($data, int $depth = 0) {
		if ($depth > 3 || !is_array($data)) {
			return [];
		}

		$result = [];
		$count = 0;

		foreach ($data as $key => $value) {
			if ($count >= 50) {
				break;
			}

			$safe_key = sanitize_key(is_string($key) ? $key : 'item_' . $count);
			$result[$safe_key] = is_array($value)
				? $this->sanitize_payload($value, $depth + 1)
				: sanitize_text_field(substr((string) $value, 0, 500));
			$count++;
		}

		return $result;
	}

	/**
	 * Checks whether a lead fingerprint was stored recently.
	 *
	 * @param string $fingerprint Lead fingerprint.
	 * @return bool|WP_Error Whether the fingerprint is a recent duplicate, or a read error.
	 */

	private function is_duplicate_lead(string $fingerprint) {
		if (!$this->table_exists($this->interactions_table)) {
			return new WP_Error(
				'wphave_audience_duplicate_check_unavailable',
				__('Lead duplication state could not be verified.', 'wphave'),
				['status' => 503],
			);
		}

		global $wpdb;
		$duplicate_threshold = current_datetime()->modify('-30 seconds')->format('Y-m-d H:i:s');
		$wpdb->last_error = '';
		$duplicate_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$this->interactions_table} WHERE fingerprint = %s AND created_at >= %s LIMIT 1",
				$fingerprint,
				$duplicate_threshold,
			),
		);

		// DATA INTEGRITY INVARIANT: Failure to read duplicate state is unknown,
		// never proof that no matching immutable interaction exists. Writes fail
		// closed until the canonical interaction store is readable again.
		if ($wpdb->last_error) {
			return new WP_Error(
				'wphave_audience_duplicate_check_unavailable',
				__('Lead duplication state could not be verified.', 'wphave'),
				['status' => 503],
			);
		}

		return (bool) $duplicate_id;
	}

	/**
	 * Exports recent lead records as CSV.
	 *
	 * Capability and nonce checks run before output starts.
	 *
	 * @return void This method terminates the request after streaming CSV.
	 */

	public function export_leads(): void {
		if (!$this->can_export()) {
			wp_die(esc_html__('Unauthorized', 'wphave'));
		}

		$this->verify_export_nonce('leads');
		$this->export_lead_work_items();
	}

	/**
	 * Exports the canonical contact profile and primary identities as CSV.
	 *
	 * Consent and subscription state are intentionally excluded because they have
	 * their own purpose-specific export. Capability and nonce checks run before
	 * output starts.
	 *
	 * @return void This method terminates the request after streaming CSV.
	 */
	public function export_contacts(): void {
		if (!$this->can_export()) {
			wp_die(esc_html__('Unauthorized', 'wphave'));
		}

		$this->verify_export_nonce('contacts');
		$this->export_contact_profiles();
	}

	/**
	 * Exports the confirmed, deliverable subscriber projection as CSV.
	 *
	 * Capability and nonce checks run before output starts. Pending, withdrawn and
	 * minimized rows are deliberately excluded so this file is safe to hand to an
	 * external newsletter sender without additional status filtering.
	 *
	 * @return void This method terminates the request after streaming CSV.
	 */

	public function export_subscribers(): void {
		if (!$this->can_export()) {
			wp_die(esc_html__('Unauthorized', 'wphave'));
		}

		$this->verify_export_nonce('subscribers');
		$this->export_table(
			$this->subscribers_table,
			'subscribers.csv',
			[
				'email',
				'first_name',
				'last_name',
				'status',
				'purpose',
				'source',
				'medium',
				'campaign',
				'consent_at',
				'confirmed_at',
				'created_at',
			],
			['status' => 'subscribed'],
			true,
		);
	}

	/**
	 * Stream an allowlisted table projection as CSV.
	 *
	 * The caller owns authorization and supplies fixed table/column values; request
	 * parameters must never be forwarded into these SQL identifiers.
	 *
	 * @param string             $table    Fully qualified, trusted table name.
	 * @param string             $filename Download filename.
	 * @param array<int, string> $columns  Ordered allowlist of exported columns.
	 * @param array<string, string> $filters Exact-match filters from a closed allowlist.
	 * @param bool $require_email Whether rows without a deliverable email are excluded.
	 * @return void This method terminates the request after streaming CSV.
	 */

	private function export_table(
		string $table,
		string $filename,
		array $columns,
		array $filters = [],
		bool $require_email = false,
	): void {
		if (!$this->table_exists($table)) {
			wp_die(
				esc_html__('Audience database tables need to be updated before export.', 'wphave'),
			);
		}

		global $wpdb;

		$this->require_export_stream_authority();
		nocache_headers();
		header('Content-Type: text/csv; charset=utf-8');
		header('Content-Disposition: attachment; filename=' . $filename);

		$out = fopen('php://output', 'w');
		fputcsv($out, $columns, ',', '"', '');

		$where = 'WHERE 1=1';
		$params = [];

		foreach ($filters as $column => $value) {
			if (
				!in_array($column, ['status', 'purpose'], true) ||
				!$this->column_exists($table, $column)
			) {
				continue;
			}

			$where .= " AND {$column} = %s";
			$params[] = sanitize_text_field($value);
		}

		if ($require_email && $this->column_exists($table, 'email')) {
			$where .= " AND email != ''";
		}

		$query = "SELECT * FROM {$table} {$where} ORDER BY id DESC LIMIT 5000";
		$rows = $wpdb->get_results($params ? $wpdb->prepare($query, ...$params) : $query, ARRAY_A);

		foreach ($rows ?: [] as $row) {
			if ($require_email && !$this->is_deliverable_export_email($row['email'] ?? '')) {
				continue;
			}

			fputcsv(
				$out,
				array_map(fn($column) => $this->sanitize_csv_value($row[$column] ?? ''), $columns),
				',',
				'"',
				'',
			);
		}

		fclose($out);
		exit();
	}

	/**
	 * SECURITY INVARIANT: Validate a losslessly normalized recipient before
	 * external CSV handoff.
	 *
	 * Database filters remove empty projections efficiently; this domain check
	 * also excludes malformed or historically corrupted non-empty addresses.
	 *
	 * @param mixed $email Stored recipient value.
	 * @return bool Whether the value is safe to hand to an email sender.
	 */
	private function is_deliverable_export_email($email): bool {
		$normalized = $this->normalize_email($email);

		return '' !== $normalized && (bool) is_email($normalized);
	}

	/**
	 * Stream canonical contact profiles with their primary email and phone.
	 *
	 * Identity values are joined into the export without copying them into the
	 * contacts table. The result is bounded consistently with other Audience CSV
	 * exports and ordered newest-first.
	 *
	 * @return void This method terminates the request after streaming CSV.
	 */
	private function export_contact_profiles(): void {
		if (!$this->has_required_schema()) {
			wp_die(
				esc_html__('Audience database tables need to be updated before export.', 'wphave'),
			);
		}

		global $wpdb;

		$this->require_export_stream_authority();
		nocache_headers();
		header('Content-Type: text/csv; charset=utf-8');
		header('Content-Disposition: attachment; filename=contacts.csv');

		$columns = [
			'public_id',
			'display_name',
			'first_name',
			'last_name',
			'email',
			'phone',
			'organization',
			'job_title',
			'status',
			'created_at',
			'updated_at',
		];
		$out = fopen('php://output', 'w');
		fputcsv($out, $columns, ',', '"', '');
		$rows =
			$wpdb->get_results(
				"SELECT c.*, (SELECT i.value FROM {$this->identities_table} i WHERE i.contact_id = c.id AND i.type = 'email' ORDER BY i.is_primary DESC, i.id ASC LIMIT 1) email, (SELECT i.value FROM {$this->identities_table} i WHERE i.contact_id = c.id AND i.type = 'phone' ORDER BY i.is_primary DESC, i.id ASC LIMIT 1) phone FROM {$this->contacts_table} c ORDER BY c.id DESC LIMIT 5000",
				ARRAY_A,
			) ?:
			[];

		foreach ($rows as $row) {
			fputcsv(
				$out,
				array_map(fn($column) => $this->sanitize_csv_value($row[$column] ?? ''), $columns),
				',',
				'"',
				'',
			);
		}

		fclose($out);
		exit();
	}

	/**
	 * Export the canonical composed lead read model.
	 *
	 * Each operational lead is decorated from its contact and origin interaction,
	 * keeping CSV output aligned with the REST read model.
	 *
	 * @return void This method terminates the request after streaming CSV.
	 */
	private function export_lead_work_items(): void {
		global $wpdb;

		$this->require_export_stream_authority();
		nocache_headers();
		header('Content-Type: text/csv; charset=utf-8');
		header('Content-Disposition: attachment; filename=leads.csv');
		$columns = [
			'public_id',
			'title',
			'status',
			'priority',
			'email',
			'type',
			'event',
			'source',
			'medium',
			'campaign',
			'goal_id',
			'current_url',
			'created_at',
			'updated_at',
		];
		$out = fopen('php://output', 'w');
		fputcsv($out, $columns, ',', '"', '');
		$rows =
			$wpdb->get_results(
				"SELECT * FROM {$this->leads_table} ORDER BY id DESC LIMIT 5000",
				ARRAY_A,
			) ?:
			[];

		foreach ($rows as $row) {
			$lead = $this->decorate_lead($this->format_row($row)) ?: [];
			fputcsv(
				$out,
				array_map(fn($column) => $this->sanitize_csv_value($lead[$column] ?? ''), $columns),
				',',
				'"',
				'',
			);
		}

		fclose($out);
		exit();
	}

	/** Enforce live export authority at the shared response-commit boundary. */
	private function require_export_stream_authority(): void {
		// AUTHORIZATION/STREAM INVARIANT: Nonce, schema and table inspection may
		// cross filterable boundaries. Every private CSV sink repeats the canonical
		// Audience export policy before committing headers or personal-data rows.
		if (!$this->can_export()) {
			wp_die(esc_html__('Unauthorized', 'wphave'), '', ['response' => 403]);
		}
	}

	/**
	 * SECURITY INVARIANT: Prevent spreadsheet formula execution when exported
	 * CSV is opened.
	 *
	 * @param mixed $value Exported scalar value.
	 * @return string Formula-safe CSV cell value.
	 */
	private function sanitize_csv_value($value): string {
		return WPHAVE_Security_CSV::cell($value);
	}
}
