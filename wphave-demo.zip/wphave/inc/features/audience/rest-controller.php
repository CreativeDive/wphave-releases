<?php

/**
 * REST endpoints for Audience administration and public actions.
 *
 * Administrative routes delegate to explicit capability checks. Public writes
 * use narrow input projections, same-origin validation, rate limits, consent
 * gates where applicable and domain-level sanitization. Route callbacks return
 * stable read models rather than exposing physical table ownership to clients.
 *
 * @package wphave
 */

if (!defined('ABSPATH')) {
	exit();
}

/**
 * Defines the HTTP boundary for the Audience domain.
 */

trait WPHAVE_Audience_REST_Controller_Trait {
	/**
	 * Register Audience REST routes for overview, contacts, leads and consent flows.
	 *
	 * Permission callbacks are declared per operation. Public callbacks still run
	 * their request validation internally because WordPress' public route callback
	 * intentionally returns true at registration time.
	 *
	 * @return void
	 */

	public function register_routes(): void {
		// PUBLIC ADMISSION INVARIANT: Proof and per-action throttles run inside
		// callbacks. JSON decoding must have a separate byte budget before Core
		// materializes attacker-controlled public request bodies.
		foreach (
			[
				'~^/wphave/v1/audience/leads$~D',
				'~^/wphave/v1/audience/subscribers$~D',
				'~^/wphave/v1/audience/subscribers/confirm$~D',
				'~^/wphave/v1/audience/unsubscribe/(?:request|options|confirm)$~D',
			] as $route_expression
		) {
			WPHAVE_REST_Body_Budget::protect('POST', $route_expression, self::MAX_PUBLIC_JSON_BYTES);
		}
		register_rest_route('wphave/v1', '/audience/public-proof/(?P<action>[a-z_]+)', [
			'methods' => 'GET',
			'callback' => [$this, 'public_request_proof_endpoint'],
			'permission_callback' => '__return_true',
			'args' => [
				'action' => [
					'type' => 'string',
					'enum' => ['lead', 'subscribe', 'unsubscribe', 'unsubscribe_options'],
					'required' => true,
				],
			],
		]);

		register_rest_route('wphave/v1', '/audience/overview', [
			'methods' => 'GET',
			'callback' => [$this, 'overview_endpoint'],
			'permission_callback' => [$this, 'permission_check'],
		]);

		register_rest_route('wphave/v1', '/audience/notifications', [
			'methods' => WP_REST_Server::READABLE,
			'callback' => [$this, 'notification_count_endpoint'],
			'permission_callback' => [$this, 'permission_check'],
		]);

		register_rest_route('wphave/v1', '/audience/notifications/read', [
			'methods' => WP_REST_Server::CREATABLE,
			'callback' => [$this, 'mark_leads_seen_endpoint'],
			'permission_callback' => [$this, 'permission_check'],
		]);

		register_rest_route('wphave/v1', '/audience/leads', [
			[
				'methods' => 'GET',
				'callback' => [$this, 'leads_endpoint'],
				'permission_callback' => [$this, 'permission_check'],
			],
			[
				'methods' => 'POST',
				'callback' => [$this, 'create_lead_endpoint'],
				'permission_callback' => '__return_true',
			],
		]);

		register_rest_route('wphave/v1', '/audience/leads/(?P<id>\d+)', [
			[
				'methods' => 'GET',
				'callback' => [$this, 'lead_detail_endpoint'],
				'permission_callback' => [$this, 'permission_check'],
			],
			[
				'methods' => 'DELETE',
				'callback' => [$this, 'delete_lead_endpoint'],
				'permission_callback' => [$this, 'delete_permission_check'],
			],
		]);

		register_rest_route('wphave/v1', '/audience/subscribers', [
			[
				'methods' => 'GET',
				'callback' => [$this, 'subscribers_endpoint'],
				'permission_callback' => [$this, 'permission_check'],
			],
			[
				'methods' => 'POST',
				'callback' => [$this, 'save_subscriber_endpoint'],
				'permission_callback' => [$this, 'permission_or_public_subscribe_check'],
			],
		]);

		register_rest_route('wphave/v1', '/audience/subscribers/confirm', [
			'methods' => ['GET', 'POST'],
			'callback' => [$this, 'confirm_subscriber_endpoint'],
			'permission_callback' => '__return_true',
		]);

		register_rest_route('wphave/v1', '/audience/unsubscribe/request', [
			'methods' => 'POST',
			'callback' => [$this, 'request_unsubscribe_link_endpoint'],
			'permission_callback' => '__return_true',
		]);

		register_rest_route('wphave/v1', '/audience/unsubscribe/options', [
			'methods' => 'POST',
			'callback' => [$this, 'unsubscribe_options_endpoint'],
			'permission_callback' => '__return_true',
		]);

		register_rest_route('wphave/v1', '/audience/unsubscribe/confirm', [
			'methods' => 'POST',
			'callback' => [$this, 'confirm_unsubscribe_endpoint'],
			'permission_callback' => '__return_true',
		]);

		register_rest_route('wphave/v1', '/audience/subscribers/(?P<id>\d+)', [
			[
				'methods' => 'POST',
				'callback' => [$this, 'save_subscriber_endpoint'],
				'permission_callback' => [$this, 'subscription_permission_check'],
			],
			[
				'methods' => 'DELETE',
				'callback' => [$this, 'delete_subscriber_endpoint'],
				'permission_callback' => [$this, 'delete_permission_check'],
			],
		]);

		register_rest_route('wphave/v1', '/audience/subscribers/(?P<id>\d+)/unsubscribe', [
			'methods' => 'POST',
			'callback' => [$this, 'unsubscribe_subscriber_endpoint'],
			'permission_callback' => [$this, 'subscription_permission_check'],
		]);

		register_rest_route('wphave/v1', '/audience/subscribers/(?P<id>\d+)/consent-evidence', [
			'methods' => WP_REST_Server::READABLE,
			'callback' => [$this, 'subscriber_consent_evidence_endpoint'],
			'permission_callback' => [$this, 'subscription_permission_check'],
		]);

		register_rest_route('wphave/v1', '/audience/contacts', [
			[
				'methods' => 'GET',
				'callback' => [$this, 'contacts_endpoint'],
				'permission_callback' => [$this, 'permission_check'],
			],
			[
				'methods' => 'POST',
				'callback' => [$this, 'create_contact_endpoint'],
				'permission_callback' => [$this, 'manage_permission_check'],
			],
		]);

		register_rest_route('wphave/v1', '/audience/contacts/(?P<id>\d+)', [
			'methods' => ['GET', 'POST', 'DELETE'],
			'callback' => [$this, 'contact_detail_endpoint'],
			'permission_callback' => [$this, 'contact_route_permission'],
		]);

		register_rest_route('wphave/v1', '/audience/contacts/(?P<id>\d+)/merge', [
			'methods' => 'POST',
			'callback' => [$this, 'merge_contact_endpoint'],
			'permission_callback' => [$this, 'manage_permission_check'],
		]);

		register_rest_route('wphave/v1', '/audience/leads/(?P<id>\d+)/workflow', [
			'methods' => 'POST',
			'callback' => [$this, 'update_lead_workflow_endpoint'],
			'permission_callback' => [$this, 'manage_permission_check'],
		]);

		register_rest_route('wphave/v1', '/audience/leads/(?P<id>\d+)/notes', [
			'methods' => 'POST',
			'callback' => [$this, 'add_lead_note_endpoint'],
			'permission_callback' => [$this, 'manage_permission_check'],
		]);

		register_rest_route('wphave/v1', '/audience/pipelines', [
			'methods' => 'GET',
			'callback' => [$this, 'pipelines_endpoint'],
			'permission_callback' => [$this, 'permission_check'],
		]);

		register_rest_route('wphave/v1', '/audience/purposes', [
			'methods' => 'GET',
			'callback' => [$this, 'purposes_endpoint'],
			'permission_callback' => [$this, 'permission_check'],
		]);

		register_rest_route('wphave/v1', '/audience/tags', [
			[
				'methods' => 'GET',
				'callback' => [$this, 'tags_endpoint'],
				'permission_callback' => [$this, 'permission_check'],
			],
			[
				'methods' => 'POST',
				'callback' => [$this, 'tags_endpoint'],
				'permission_callback' => [$this, 'manage_permission_check'],
			],
		]);

		register_rest_route('wphave/v1', '/audience/custom-fields', [
			[
				'methods' => 'GET',
				'callback' => [$this, 'custom_fields_endpoint'],
				'permission_callback' => [$this, 'permission_check'],
			],
			[
				'methods' => 'POST',
				'callback' => [$this, 'custom_fields_endpoint'],
				'permission_callback' => [$this, 'manage_permission_check'],
			],
		]);
	}

	/**
	 * Issues one uncached, action-scoped proof to an exact same-origin client.
	 *
	 * @param WP_REST_Request $request REST request containing the action key.
	 * @return WP_REST_Response|WP_Error Proof response or access error.
	 */
	public function public_request_proof_endpoint(WP_REST_Request $request) {
		$raw_action = $request->get_param('action');
		// AVAILABILITY INVARIANT: Only the closed action vocabulary may allocate a
		// per-action rate bucket. Unknown URL slugs must not create unbounded
		// transient keys before the proof issuer rejects them.
		if (
			!is_string($raw_action) ||
			strlen($raw_action) > 32 ||
			!in_array($raw_action, $this->public_request_proof_actions(), true)
		) {
			return new WP_Error(
				'wphave_audience_proof_action_invalid',
				__('Public request action is invalid.', 'wphave'),
				['status' => 400],
			);
		}

		$action = $raw_action;

		if (!$this->is_same_origin_request()) {
			return new WP_Error(
				'wphave_audience_proof_forbidden',
				__('Public request proof is not available.', 'wphave'),
				['status' => 403],
			);
		}

		if (!$this->check_rate_limit('public_proof_' . $action, 60)) {
			return new WP_Error(
				'wphave_audience_rate_limited',
				__('Too many public requests. Please try again later.', 'wphave'),
				['status' => 429],
			);
		}

		$proof = $this->create_public_request_proof($action);

		if ('' === $proof) {
			return new WP_Error(
				'wphave_audience_proof_action_invalid',
				__('Public request action is invalid.', 'wphave'),
				['status' => 400],
			);
		}

		$response = rest_ensure_response([
			'proof' => $proof,
			'expiresIn' => self::PUBLIC_REQUEST_PROOF_TTL,
		]);
		$response->header('Cache-Control', 'private, no-store, max-age=0');

		return $response;
	}

	/**
	 * Returns lightweight, indexed Audience navigation notification counts.
	 *
	 * New leads are user-specific and use an auto-increment high-water mark;
	 * pending subscribers remain visible until their workflow state changes.
	 * This endpoint intentionally avoids loading any Audience read model.
	 *
	 * @return WP_REST_Response|WP_Error Navigation notification counts or access error.
	 */
	public function notification_count_endpoint(): WP_REST_Response|WP_Error {
		global $wpdb;

		// AUTHORIZATION INVARIANT: A REST permission callback is only an early
		// dispatch gate. This public callback must repeat the canonical Audience
		// read policy before disclosing aggregate workflow state, including when
		// invoked directly by PHP, a hook, a test or a future internal caller.
		if (!$this->permission_check()) {
			return new WP_Error(
				'wphave_audience_forbidden',
				__('You are not allowed to access Audience data.', 'wphave'),
				['status' => 403],
			);
		}

		if (!$this->has_required_schema()) {
			return rest_ensure_response([
				'count' => 0,
				'new_leads' => 0,
				'pending_subscribers' => 0,
			]);
		}

		$last_seen_lead_id = absint(
			get_user_meta(get_current_user_id(), self::LAST_SEEN_LEAD_META, true),
		);
		$new_leads = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$this->leads_table} WHERE id > %d AND status IN ('open', 'qualified')",
				$last_seen_lead_id,
			),
		);
		$pending_subscribers = (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM {$this->subscribers_table} WHERE status = 'pending'",
		);

		return rest_ensure_response([
			'count' => $new_leads + $pending_subscribers,
			'new_leads' => $new_leads,
			'pending_subscribers' => $pending_subscribers,
		]);
	}

	/**
	 * Advances the current user's lead notification high-water mark.
	 *
	 * Opening the Leads section acknowledges every lead that existed at that
	 * instant. Later inserts receive a greater primary key and become visible on
	 * the next deferred notification refresh without changing shared lead state.
	 *
	 * @return WP_REST_Response|WP_Error Remaining actionable Audience count or access error.
	 */
	public function mark_leads_seen_endpoint(): WP_REST_Response|WP_Error {
		global $wpdb;

		// AUTHORIZATION INVARIANT: Acknowledgement is a privileged per-user
		// state transition. Revalidate the canonical Audience read policy at the
		// mutation sink; a nonce or successful REST dispatch is not authority.
		if (!$this->permission_check()) {
			return new WP_Error(
				'wphave_audience_forbidden',
				__('You are not allowed to access Audience data.', 'wphave'),
				['status' => 403],
			);
		}

		$latest_lead_id = $this->has_required_schema()
			? (int) $wpdb->get_var("SELECT COALESCE(MAX(id), 0) FROM {$this->leads_table}")
			: 0;

		update_user_meta(get_current_user_id(), self::LAST_SEEN_LEAD_META, $latest_lead_id);

		return $this->notification_count_endpoint();
	}

	/**
	 * Returns overview metrics for leads, subscribers, sources, content and goals.
	 *
	 * @param WP_REST_Request $request REST request with date range parameters.
	 * @return WP_REST_Response|WP_Error Overview response or access error.
	 */

	public function overview_endpoint(WP_REST_Request $request): WP_REST_Response|WP_Error {
		if (!$this->permission_check()) {
			return $this->audience_access_error();
		}

		if (!$this->has_required_schema()) {
			return rest_ensure_response([
				'range' => $this->get_range($request),
				'leads' => [
					'total' => 0,
					'contacts' => 0,
				],
				'subscribers' => [],
				'sources' => [],
				'content' => [],
				'dailyLeads' => [],
				'dailySubscribers' => [],
				'goals' => [],
				'schemaUpdateRequired' => true,
			]);
		}

		global $wpdb;

		$range = $this->get_range($request);
		$lead_stats = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT COUNT(*) total, COUNT(DISTINCT contact_id) contacts FROM {$this->leads_table} WHERE created_at BETWEEN %s AND %s",
				$range['from'] . ' 00:00:00',
				$range['to'] . ' 23:59:59',
			),
			ARRAY_A,
		);
		$subscriber_stats = $wpdb->get_results(
			"SELECT status, COUNT(*) total FROM {$this->subscribers_table} GROUP BY status",
			ARRAY_A,
		);
		$sources = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT i.source, i.medium, COUNT(*) value FROM {$this->leads_table} l INNER JOIN {$this->interactions_table} i ON i.id = l.origin_interaction_id WHERE l.created_at BETWEEN %s AND %s GROUP BY i.source, i.medium ORDER BY value DESC LIMIT 10",
				$range['from'] . ' 00:00:00',
				$range['to'] . ' 23:59:59',
			),
			ARRAY_A,
		);
		$content = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT i.object_label, i.object_url, i.object_type, COUNT(*) value FROM {$this->leads_table} l INNER JOIN {$this->interactions_table} i ON i.id = l.origin_interaction_id WHERE l.created_at BETWEEN %s AND %s GROUP BY i.object_key, i.object_label, i.object_url, i.object_type ORDER BY value DESC LIMIT 10",
				$range['from'] . ' 00:00:00',
				$range['to'] . ' 23:59:59',
			),
			ARRAY_A,
		);
		$daily_leads = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT DATE(created_at) label, COUNT(*) value, COUNT(DISTINCT contact_id) contacts FROM {$this->leads_table} WHERE created_at BETWEEN %s AND %s GROUP BY DATE(created_at) ORDER BY label ASC",
				$range['from'] . ' 00:00:00',
				$range['to'] . ' 23:59:59',
			),
			ARRAY_A,
		);
		$daily_subscribers = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT DATE(created_at) label, COUNT(*) value FROM {$this->subscribers_table} WHERE created_at BETWEEN %s AND %s GROUP BY DATE(created_at) ORDER BY label ASC",
				$range['from'] . ' 00:00:00',
				$range['to'] . ' 23:59:59',
			),
			ARRAY_A,
		);
		$goals = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT i.goal_id, COUNT(*) value FROM {$this->leads_table} l INNER JOIN {$this->interactions_table} i ON i.id = l.origin_interaction_id WHERE l.created_at BETWEEN %s AND %s AND i.goal_id != '' GROUP BY i.goal_id ORDER BY value DESC LIMIT 10",
				$range['from'] . ' 00:00:00',
				$range['to'] . ' 23:59:59',
			),
			ARRAY_A,
		);

		return rest_ensure_response([
			'range' => $range,
			'leads' => [
				'total' => (int) ($lead_stats['total'] ?? 0),
				'contacts' => (int) ($lead_stats['contacts'] ?? 0),
			],
			'subscribers' => $this->map_status_counts($subscriber_stats),
			'sources' => array_map([$this, 'format_metric_row'], $sources ?: []),
			'content' => array_map([$this, 'format_metric_row'], $content ?: []),
			'dailyLeads' => array_map([$this, 'format_metric_row'], $daily_leads ?: []),
			'dailySubscribers' => array_map([$this, 'format_metric_row'], $daily_subscribers ?: []),
			'goals' => array_map([$this, 'format_metric_row'], $goals ?: []),
		]);
	}

	/**
	 * Returns a paginated lead list.
	 *
	 * @param WP_REST_Request $request REST request with table query parameters.
	 * @return WP_REST_Response|WP_Error Lead list response or access error.
	 */

	public function leads_endpoint(WP_REST_Request $request): WP_REST_Response|WP_Error {
		if (!$this->permission_check()) {
			return $this->audience_access_error();
		}

		$response = $this->query_leads($request);
		$response['summary'] = $this->get_lead_type_counts();

		return rest_ensure_response($response);
	}

	/**
	 * Returns a paginated subscriber list.
	 *
	 * @param WP_REST_Request $request REST request with table query parameters.
	 * @return WP_REST_Response|WP_Error Subscriber list response or access error.
	 */

	public function subscribers_endpoint(WP_REST_Request $request): WP_REST_Response|WP_Error {
		if (!$this->permission_check()) {
			return $this->audience_access_error();
		}

		$response = $this->query_table(
			$this->subscribers_table,
			$request,
			['email', 'first_name', 'last_name', 'purpose', 'source', 'campaign'],
			'updated_at',
			['email', 'status', 'purpose', 'source', 'updated_at'],
		);
		$response['summary'] = $this->get_grouped_counts($this->subscribers_table, 'status');

		return rest_ensure_response($response);
	}

	/**
	 * Returns one lead and its analytics journey.
	 *
	 * @param WP_REST_Request $request REST request containing the lead id.
	 * @return WP_REST_Response Lead detail response.
	 */

	public function lead_detail_endpoint(WP_REST_Request $request) {
		if (!$this->permission_check()) {
			return $this->audience_access_error();
		}

		$lead = $this->decorate_lead($this->get_row($this->leads_table, absint($request['id'])));

		if (!$lead) {
			return new WP_Error(
				'wphave_audience_lead_missing',
				__('Lead was not found.', 'wphave'),
				['status' => 404],
			);
		}

		global $wpdb;
		$activities =
			$wpdb->get_results(
				$wpdb->prepare(
					"SELECT * FROM {$this->activities_table} WHERE lead_id = %d ORDER BY occurred_at DESC LIMIT 100",
					absint($lead['id']),
				),
				ARRAY_A,
			) ?:
			[];
		$contact = absint($lead['contact_id'] ?? 0)
			? $this->get_row($this->contacts_table, absint($lead['contact_id']))
			: null;

		return rest_ensure_response([
			'item' => $lead,
			'contact' => $contact,
			'activities' => array_map([$this, 'format_row'], $activities),
			'journey' => $this->get_lead_journey($lead),
		]);
	}

	/**
	 * Create an idempotent public lead and optional subscriber records.
	 *
	 * Attribution-only events require analytics consent. Same-origin and rate-limit
	 * checks execute before persistence, and a submission ID replays the existing
	 * result instead of generating another interaction and lead.
	 *
	 * @param WP_REST_Request $request REST request containing lead data.
	 * @return WP_REST_Response|WP_Error Creation response or error.
	 */

	public function create_lead_endpoint(WP_REST_Request $request) {
		$body_error = WPHAVE_REST_Body_Budget::check($request, self::MAX_PUBLIC_JSON_BYTES);
		if ($body_error) {
			return $body_error;
		}
		$data = $request->get_json_params();
		$data = is_array($data) ? $data : [];
		$type = sanitize_key($data['type'] ?? '');

		if (
			in_array($type, ['click', 'download', 'outbound'], true) &&
			!wphave_privacy_can_process(WPHAVE_Privacy_Manager::PURPOSE_ANALYTICS_ATTRIBUTION)
		) {
			return new WP_Error(
				'wphave_audience_privacy_denied',
				__('Analytics consent is required for attribution events.', 'wphave'),
				['status' => 403],
			);
		}

		if (
			!$this->is_valid_public_request($request, 'lead') ||
			!$this->check_rate_limit('lead', 20)
		) {
			return new WP_Error(
				'wphave_audience_forbidden',
				__('Lead request is not allowed.', 'wphave'),
				['status' => 403],
			);
		}

		if (
			!$this->has_bounded_public_purposes($data['purposes'] ?? []) ||
			!$this->has_bounded_public_purposes($data['audienceSubscriberPurposes'] ?? [])
		) {
			return new WP_Error(
				'wphave_audience_purposes_invalid',
				__('Subscription purposes are invalid.', 'wphave'),
				['status' => 400],
			);
		}

		$submission_id = $this->normalize_submission_id($data['submission_id'] ?? '');
		if (is_wp_error($submission_id)) {
			return $submission_id;
		}

		$existing = $this->find_lead_by_submission_id($submission_id);

		if (is_wp_error($existing)) {
			return $existing;
		}

		if ($existing) {
			return rest_ensure_response($this->public_lead_receipt());
		}

		global $wpdb;
		$pending_confirmation_before = $this->pending_confirmation_subscribers;
		if (!$this->begin_audience_transaction()) {
			return new WP_Error(
				'wphave_audience_transaction_unavailable',
				__('Audience storage transaction could not be started.', 'wphave'),
				['status' => 503],
			);
		}

		$lead = $this->create_lead($data);

		if (is_wp_error($lead)) {
			$this->rollback_audience_transaction();
			$this->pending_confirmation_subscribers = $pending_confirmation_before;
			return $lead;
		}

		if (!empty($data['subscribe']) && !empty($lead['email'])) {
			foreach ($this->normalize_subscription_purposes($data) as $purpose) {
				$requires_confirmation = $this->purpose_requires_double_opt_in($purpose);
				$subscriber = $this->save_subscriber(
					[
						'email' => $lead['email'],
						'first_name' => $lead['first_name'],
						'last_name' => $lead['last_name'],
						'purpose' => $purpose,
						'source' => $lead['source'],
						'medium' => $lead['medium'],
						'campaign' => $lead['campaign'],
						'lead_id' => $lead['id'],
						'status' => $requires_confirmation ? 'pending' : 'subscribed',
						'consent_action' => 'granted',
						'consent_source' => 'public_lead_subscription',
					],
					true,
				);

				if (is_wp_error($subscriber)) {
					$this->rollback_audience_transaction();
					$this->pending_confirmation_subscribers = $pending_confirmation_before;
					return $subscriber;
				}
			}
		}

		if (!$this->commit_audience_transaction()) {
			$this->rollback_audience_transaction();
			$this->pending_confirmation_subscribers = $pending_confirmation_before;

			return new WP_Error(
				'wphave_audience_transaction_commit_failed',
				__('Audience storage transaction could not be committed.', 'wphave'),
				['status' => 503],
			);
		}

		$this->flush_confirmation_emails_since($pending_confirmation_before);

		return rest_ensure_response($this->public_lead_receipt());
	}

	/**
	 * Build the intentionally minimal response for an anonymous lead write.
	 *
	 * SECURITY AND PRIVACY INVARIANT: a public proof authorizes one bounded write;
	 * it never grants read access to the resulting lead, contact, interaction or
	 * submitted personal data. Idempotent retries therefore expose the same narrow
	 * receipt as first-time writes instead of turning submission IDs into read or
	 * existence-oracle keys.
	 *
	 * @return array<string, bool> Public write receipt.
	 */
	private function public_lead_receipt(): array {
		return [
			'success' => true,
		];
	}

	/**
	 * Create or update subscriber records from REST data.
	 *
	 * Public requests are projected onto the supported self-service fields so they
	 * cannot set administrative status or ownership data. Purpose policy determines
	 * whether new public subscriptions enter pending or subscribed state.
	 *
	 * @param WP_REST_Request $request REST request containing subscriber data.
	 * @return WP_REST_Response|WP_Error Save response or error.
	 */

	public function save_subscriber_endpoint(WP_REST_Request $request) {
		$body_error = WPHAVE_REST_Body_Budget::check($request, self::MAX_PUBLIC_JSON_BYTES);
		if ($body_error) {
			return $body_error;
		}
		$data = $request->get_json_params();
		$data = is_array($data) ? $data : $request->get_params();
		$data['id'] = absint($request->get_param('id') ?: $data['id'] ?? 0);

		if ($data['id'] && !$this->can_manage_subscribers()) {
			return new WP_Error(
				'wphave_audience_forbidden',
				__('You are not allowed to edit subscribers.', 'wphave'),
				['status' => 403],
			);
		}

		$is_public = !$this->can_manage_subscribers();

		if (!$is_public) {
			$data['consent_action'] = 'granted_manually';
			$data['consent_source'] = 'admin';
		}

		if ($is_public) {
			if (!$this->is_valid_public_request($request, 'subscribe')) {
				return new WP_Error(
					'wphave_audience_forbidden',
					__('Subscription request is not allowed.', 'wphave'),
					['status' => 403],
				);
			}

			if (!$this->has_bounded_public_purposes($data['purposes'] ?? [])) {
				return new WP_Error(
					'wphave_audience_purposes_invalid',
					__('Subscription purposes are invalid.', 'wphave'),
					['status' => 400],
				);
			}

			if (!$this->check_rate_limit('subscribe', 20)) {
				return new WP_Error(
					'wphave_audience_rate_limited',
					__('Too many subscription requests. Please try again later.', 'wphave'),
					['status' => 429],
				);
			}

			$data = [
				'email' => $data['email'] ?? '',
				'first_name' => $data['first_name'] ?? '',
				'last_name' => $data['last_name'] ?? '',
				'purpose' => $data['purpose'] ?? '',
				'purposes' => $data['purposes'] ?? [],
				'source' => $data['source'] ?? '',
				'medium' => $data['medium'] ?? '',
				'campaign' => $data['campaign'] ?? '',
			];
		}

		$pending_confirmation_before = $this->pending_confirmation_subscribers;

		/*
		 * DATA INTEGRITY INVARIANT: Subscriber projections, consent facts and
		 * queued DOI deliveries are one REST write unit. A response may report
		 * success, and mail may flush, only after its transaction commits.
		 */
		if (!$this->begin_audience_transaction()) {
			return new WP_Error(
				'wphave_audience_subscriber_transaction_unavailable',
				__('Subscriber changes could not be started safely.', 'wphave'),
				['status' => 500],
			);
		}

		if (!empty($data['purposes']) && is_array($data['purposes'])) {
			$subscribers = [];
			$primary_id = absint($data['id'] ?? 0);

			foreach ($this->normalize_subscription_purposes($data) as $index => $purpose) {
				$subscriber_data = array_merge($data, [
					'id' => $index === 0 ? $primary_id : 0,
					'purpose' => $purpose,
				]);

				if ($is_public) {
					$subscriber_data['status'] = $this->purpose_requires_double_opt_in($purpose)
						? 'pending'
						: 'subscribed';
					$subscriber_data['consent_action'] = 'granted';
					$subscriber_data['consent_source'] = 'public_subscribe';
				}
				$subscriber = $this->save_subscriber($subscriber_data, $is_public);

				if (is_wp_error($subscriber)) {
					$this->rollback_audience_transaction();
					$this->pending_confirmation_subscribers = $pending_confirmation_before;
					return $subscriber;
				}

				$subscribers[] = $subscriber;
			}

			if (!$this->commit_audience_transaction()) {
				$this->rollback_audience_transaction();
				$this->pending_confirmation_subscribers = $pending_confirmation_before;

				return new WP_Error(
					'wphave_audience_subscriber_commit_failed',
					__('Subscriber changes could not be committed safely.', 'wphave'),
					['status' => 500],
				);
			}

			$this->flush_confirmation_emails_since($pending_confirmation_before);

			if ($is_public) {
				return rest_ensure_response(['success' => true]);
			}
			return rest_ensure_response([
				'success' => true,
				'items' => $subscribers,
			]);
		}

		if ($is_public) {
			$data['status'] = $this->purpose_requires_double_opt_in($data['purpose'] ?? '')
				? 'pending'
				: 'subscribed';
			$data['consent_action'] = 'granted';
			$data['consent_source'] = 'public_subscribe';
		}

		$subscriber = $this->save_subscriber($data, $is_public);

		if (is_wp_error($subscriber)) {
			$this->rollback_audience_transaction();
			$this->pending_confirmation_subscribers = $pending_confirmation_before;
			return $subscriber;
		}

		if (!$this->commit_audience_transaction()) {
			$this->rollback_audience_transaction();
			$this->pending_confirmation_subscribers = $pending_confirmation_before;

			return new WP_Error(
				'wphave_audience_subscriber_commit_failed',
				__('Subscriber changes could not be committed safely.', 'wphave'),
				['status' => 500],
			);
		}

		$this->flush_confirmation_emails_since($pending_confirmation_before);

		// PRIVACY INVARIANT: Public receipts never disclose existing identity,
		// status, consent timestamps or whether this was a repeat submission.
		if ($is_public) {
			return rest_ensure_response(['success' => true]);
		}
		return rest_ensure_response([
			'success' => true,
			'item' => $subscriber,
		]);
	}

	/**
	 * Delete one operational lead after the dedicated delete capability check.
	 *
	 * The contact and immutable origin interaction remain available for other leads.
	 *
	 * @param WP_REST_Request $request REST request containing the lead id.
	 * @return WP_REST_Response|WP_Error Delete response or error.
	 */

	public function delete_lead_endpoint(WP_REST_Request $request) {
		if (!$this->can_delete()) {
			return new WP_Error(
				'wphave_audience_forbidden',
				__('You are not allowed to delete audience data.', 'wphave'),
				['status' => 403],
			);
		}

		$deleted = $this->delete_operational_lead(absint($request['id']));

		return is_wp_error($deleted) ? $deleted : rest_ensure_response(['success' => true]);
	}

	/**
	 * Delete one purpose-specific subscriber row after capability validation.
	 *
	 * @param WP_REST_Request $request REST request containing the subscriber id.
	 * @return WP_REST_Response|WP_Error Delete response or error.
	 */

	public function delete_subscriber_endpoint(WP_REST_Request $request) {
		if (!$this->can_delete()) {
			return new WP_Error(
				'wphave_audience_forbidden',
				__('You are not allowed to delete audience data.', 'wphave'),
				['status' => 403],
			);
		}

		$subscriber_id = absint($request['id']);

		if (!$subscriber_id || !$this->get_row($this->subscribers_table, $subscriber_id)) {
			return new WP_Error(
				'wphave_audience_subscriber_missing',
				__('Subscriber was not found.', 'wphave'),
				['status' => 404],
			);
		}

		if (!$this->begin_audience_transaction()) {
			return new WP_Error(
				'wphave_audience_subscriber_delete_failed',
				__('Subscriber and consent evidence could not be deleted atomically.', 'wphave'),
				['status' => 500],
			);
		}

		try {
			$this->delete_subscriber_graph_rows($subscriber_id);
		} catch (Throwable $error) {
			$this->rollback_audience_transaction();

			return new WP_Error(
				'wphave_audience_subscriber_delete_failed',
				__('Subscriber and consent evidence could not be deleted atomically.', 'wphave'),
				['status' => 500],
			);
		}

		if (!$this->commit_audience_transaction()) {
			$this->rollback_audience_transaction();

			return new WP_Error(
				'wphave_audience_subscriber_delete_failed',
				__('Subscriber and consent evidence could not be deleted atomically.', 'wphave'),
				['status' => 500],
			);
		}

		return rest_ensure_response(['success' => true]);
	}

	/**
	 * Mark a subscriber as unsubscribed from the administrative API.
	 *
	 * Withdrawal evidence is appended before the subscriber record is minimized to
	 * its suppression hash, retaining proof without retaining the contact profile.
	 *
	 * @param WP_REST_Request $request REST request containing the subscriber id.
	 * @return WP_REST_Response|WP_Error Update response or error.
	 */

	public function unsubscribe_subscriber_endpoint(WP_REST_Request $request) {
		global $wpdb;

		if (!$this->can_manage_subscribers()) {
			return new WP_Error(
				'wphave_audience_forbidden',
				__('You are not allowed to edit subscribers.', 'wphave'),
				['status' => 403],
			);
		}

		$id = absint($request['id']);
		$subscriber = $this->get_row($this->subscribers_table, $id);

		if (!$subscriber) {
			return new WP_Error(
				'wphave_audience_subscriber_missing',
				__('Subscriber was not found.', 'wphave'),
				['status' => 404],
			);
		}

		if (!$this->begin_audience_transaction()) {
			return new WP_Error(
				'wphave_audience_unsubscribe_failed',
				__('Subscriber could not be unsubscribed atomically.', 'wphave'),
				['status' => 500],
			);
		}

		$updated = $wpdb->update(
			$this->subscribers_table,
			[
				'status' => 'unsubscribed',
				'consent' => 0,
				'confirm_token_hash' => '',
				'confirm_expires_at' => null,
				'unsubscribed_at' => current_time('mysql'),
				'updated_at' => current_time('mysql'),
			],
			['id' => $id],
			['%s', '%d', '%s', '%s', '%s', '%s'],
			['%d'],
		);

		$consent_recorded = $this->record_consent_event([
			'contact_id' => absint($subscriber['contact_id'] ?? 0),
			'subscriber_id' => $id,
			'purpose' => $subscriber['purpose'] ?? '',
			'action' => 'withdrawn',
			'source' => 'admin',
		]);
		$subscriber_minimized = $consent_recorded
			? $this->minimize_unsubscribed_subscriber($id)
			: false;

		if (false === $updated || !$consent_recorded || !$subscriber_minimized) {
			$this->rollback_audience_transaction();

			return new WP_Error(
				'wphave_audience_unsubscribe_failed',
				__('Subscriber could not be unsubscribed atomically.', 'wphave'),
				['status' => 500],
			);
		}

		if (!$this->commit_audience_transaction()) {
			$this->rollback_audience_transaction();

			return new WP_Error(
				'wphave_audience_unsubscribe_failed',
				__('Subscriber could not be unsubscribed atomically.', 'wphave'),
				['status' => 500],
			);
		}

		return rest_ensure_response([
			'success' => true,
			'item' => $this->get_row($this->subscribers_table, $id),
		]);
	}
}
