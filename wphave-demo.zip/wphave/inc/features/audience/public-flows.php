<?php

/**
 * Public subscription confirmation and unsubscribe flows.
 *
 * @package wphave
 */

if (!defined('ABSPATH')) {
    exit();
}

/**
 * Public subscription confirmation and unsubscribe flows.
 */

trait WPHAVE_Audience_Public_Flows_Trait {
    private static array $unsubscribe_claims = [];
    /**
     * Registers the public rewrite route for subscription confirmation.
     */

    public function register_public_confirmation_route(): void {
        add_rewrite_rule(
            '^wphave/confirm-subscription/?$',
            'index.php?wphave_audience_action=confirm_subscription',
            'top',
        );
    }

    /**
     * Refreshes persisted rewrite rules once when the public route contract changes.
     *
     * The version check prevents expensive rewrite flushing during normal requests.
     * The request resolver below remains the fail-safe for stale external caches or
     * installations where persisted rewrite rules could not be refreshed.
     */

    public function maybe_refresh_public_routes(): void {
        if (get_option(self::PUBLIC_ROUTE_VERSION_OPTION) === self::PUBLIC_ROUTE_VERSION) {
            return;
        }

        flush_rewrite_rules(false);
        update_option(self::PUBLIC_ROUTE_VERSION_OPTION, self::PUBLIC_ROUTE_VERSION, false);
    }

    /**
     * Resolves the exact confirmation path independently of persisted rewrites.
     *
     * Existing links must remain usable even when a deployment, cache layer or
     * permalink change leaves WordPress' rewrite option temporarily stale.
     * Restricting this fallback to the one canonical path avoids claiming any
     * unrelated frontend URL.
     *
     * @param WP $wp Current WordPress request parser.
     */

    public function resolve_public_confirmation_request($wp): void {
        $request_path = trim((string) ($wp->request ?? ''), '/');

        if ('wphave/confirm-subscription' !== $request_path) {
            return;
        }

        $wp->query_vars['wphave_audience_action'] = 'confirm_subscription';
    }

    /**
     * Adds Audience query variables used by public confirmation routes.
     *
     * @param array $vars Existing public query variables.
     * @return array Updated query variables.
     */

    public function register_public_query_vars(array $vars): array {
        $vars[] = 'wphave_audience_action';

        return $vars;
    }

    /**
     * Handles REST-based subscriber confirmation by token.
     *
     * @param WP_REST_Request $request REST request containing the confirmation token.
     * @return WP_REST_Response|WP_Error Confirmation response or error.
     */

    public function confirm_subscriber_endpoint(WP_REST_Request $request) {
        $token = $this->normalize_public_token($request->get_param('token'));

        // CONSENT INVARIANT: GET is safe to prefetch. Mail scanners must not
        // convert possession of a DOI link into an affirmative opt-in.
        if ($request->get_method() === 'GET') {
            if (!wp_is_json_request()) {
                wp_safe_redirect($this->subscriber_confirmation_url($token));
                exit();
            }

            $response = rest_ensure_response([
                'confirmationRequired' => true,
                'url' => $this->subscriber_confirmation_url($token),
            ]);
            $response->header('Cache-Control', 'private, no-store, max-age=0');

            return $response;
        }

        $result = $this->confirm_subscriber_token($token);

        if (!empty($result['success'])) {
            return rest_ensure_response($result);
        }

        return new WP_Error(
            $result['code'] ?? 'wphave_audience_invalid_token',
            $result['message'] ?? __('Invalid subscription token.', 'wphave'),
            ['status' => $result['status'] ?? 400],
        );
    }

    /**
     * Sends an unsubscribe confirmation link for selected active purposes.
     *
     * @param WP_REST_Request $request REST request containing email and selected purposes.
     * @return WP_REST_Response|WP_Error Request response or error.
     */

    public function request_unsubscribe_link_endpoint(WP_REST_Request $request) {
        if (!$this->is_valid_public_request($request, 'unsubscribe')) {
            return new WP_Error(
                'wphave_audience_forbidden',
                __('Unsubscribe request is not allowed.', 'wphave'),
                ['status' => 403],
            );
        }

        $email = $this->normalize_email($request->get_param('email') ?? '');
        $raw_purposes = $request->get_param('purposes');
        $purposes = is_array($raw_purposes) ? $raw_purposes : [];
        if (!$this->has_bounded_public_purposes($purposes)) {
            return new WP_Error(
                'wphave_audience_purposes_invalid',
                __('Subscription purposes are invalid.', 'wphave'),
                ['status' => 400],
            );
        }
        // SECURITY INVARIANT: Destructive scope flags require explicit boolean
        // normalization; PHP truthiness must never turn "false" into "all".
        $all = $this->normalize_public_boolean($request->get_param('all'));
        $current_url = $this->normalize_public_return_url(
            $request->get_param('current_url') ?? home_url('/'),
        );
        $this->send_unsubscribe_email($email, $current_url, $purposes, $all);

        // PRIVACY INVARIANT: Public receipts never reveal address presence, purpose
        // membership or delivery success. The mail result stays internal.

        return rest_ensure_response([
            'success' => true,
            'message' => __(
                'If this email address has active subscriptions, we have sent a confirmation link.',
                'wphave',
            ),
        ]);
    }

    /**
     * Returns the site's public subscription-purpose catalog.
     *
     * The response deliberately does not disclose whether the submitted email
     * exists or which purposes it uses. The subsequent email request intersects
     * submitted purposes with the address' real subscriptions server-side.
     *
     * @param WP_REST_Request $request REST request containing the email address.
     * @return WP_REST_Response|WP_Error Available options response or error.
     */

    public function unsubscribe_options_endpoint(WP_REST_Request $request) {
        if (!$this->is_valid_public_request($request, 'unsubscribe_options')) {
            return new WP_Error(
                'wphave_audience_forbidden',
                __('Unsubscribe request is not allowed.', 'wphave'),
                ['status' => 403],
            );
        }

        if (!$this->check_rate_limit('unsubscribe_options', 20)) {
            return new WP_Error(
                'wphave_audience_rate_limited',
                __('Too many subscription requests. Please try again later.', 'wphave'),
                ['status' => 429],
            );
        }

        global $wpdb;
        $purposes =
            $wpdb->get_results(
                "SELECT purpose_key purpose, label FROM {$this->purposes_table} WHERE is_active = 1 AND channel = 'email' ORDER BY label ASC",
                ARRAY_A,
            ) ?:
            [];

        return rest_ensure_response([
            'success' => true,
            'items' => array_map([$this, 'format_row'], $purposes),
        ]);
    }

    /**
     * Confirms a pending unsubscribe request by token.
     *
     * @param WP_REST_Request $request REST request containing the pending unsubscribe token.
     * @return WP_REST_Response|WP_Error Confirmation response or error.
     */

    public function confirm_unsubscribe_endpoint(WP_REST_Request $request) {
        $token = $this->normalize_public_token($request->get_param('token'));
        $result = $this->confirm_pending_unsubscribe_request($token);

        if (!empty($result['success'])) {
            return rest_ensure_response($result);
        }

        return new WP_Error(
            $result['code'] ?? 'wphave_audience_unsubscribe_failed',
            $result['message'] ?? __('The unsubscribe request could not be completed.', 'wphave'),
            ['status' => $result['status'] ?? 400],
        );
    }

    /**
     * Confirms unsubscribe tokens from public email links before page rendering.
     */

    public function handle_public_unsubscribe_confirmation(): void {
        if (
            !headers_sent() &&
            $this->normalize_public_token(wphave_request_string($_GET, 'confirm_token'))
        ) {
            header('Referrer-Policy: no-referrer');
        }

        // WITHDRAWAL INVARIANT: Prefetching an email link is a read. The
        // subscriber must explicitly submit the confirmation form before a
        // pending withdrawal grant can be consumed.
        if ('POST' !== ($_SERVER['REQUEST_METHOD'] ?? 'GET')) {
            return;
        }

        $token = $this->normalize_public_token(wphave_request_string($_POST, 'confirm_token'));

        if (!$token) {
            return;
        }

        $result = $this->confirm_pending_unsubscribe_request($token);
        $redirect_url = remove_query_arg(['confirm_token', 'token', 'unsubscribe_status']);
        $redirect_url = add_query_arg(
            'unsubscribe_status',
            !empty($result['success']) ? 'confirmed' : 'failed',
            $redirect_url,
        );

        wp_safe_redirect($redirect_url);
        exit();
    }

    /**
     * Renders the public unsubscribe block markup.
     *
     * @param array $attributes Block attributes.
     * @return string Rendered unsubscribe form markup.
     */

    public function render_unsubscribe_block(array $attributes = []): string {
        $confirm_token = $this->normalize_public_token(
            wphave_request_string($_GET, 'confirm_token'),
        );
        $unsubscribe_status = sanitize_key(wphave_request_string($_GET, 'unsubscribe_status'));
        $initial_message = '';
        $initial_message_type = 'info';
        $classes = 'wphave-unsubscribe';

        if ($unsubscribe_status === 'confirmed') {
            $initial_message = __('Your subscription preferences have been updated.', 'wphave');
            $initial_message_type = 'success';
        } elseif ($unsubscribe_status === 'failed') {
            $initial_message = __(
                'This unsubscribe confirmation link is invalid or no longer available.',
                'wphave',
            );
            $initial_message_type = 'error';
        }

        ob_start();
        ?>
        <div
            class="<?php echo esc_attr($classes); ?>"
            data-confirm-token="<?php echo esc_attr($confirm_token); ?>"
            data-request-url="<?php echo esc_url(
                rest_url('wphave/v1/audience/unsubscribe/request'),
            ); ?>"
            data-options-url="<?php echo esc_url(
                rest_url('wphave/v1/audience/unsubscribe/options'),
            ); ?>"
            data-confirm-url="<?php echo esc_url(
                rest_url('wphave/v1/audience/unsubscribe/confirm'),
            ); ?>"
			data-options-proof-url="<?php echo esc_url(
       rest_url('wphave/v1/audience/public-proof/unsubscribe_options'),
   ); ?>"
			data-unsubscribe-proof-url="<?php echo esc_url(
       rest_url('wphave/v1/audience/public-proof/unsubscribe'),
   ); ?>"
            data-message-loading="<?php esc_attr_e(
                'Loading subscription preferences...',
                'wphave',
            ); ?>"
            data-message-requested="<?php esc_attr_e(
                'If this email address has active subscriptions, we have sent a confirmation link.',
                'wphave',
            ); ?>"
            data-message-updated="<?php esc_attr_e(
                'Your subscription preferences have been updated.',
                'wphave',
            ); ?>"
            data-label-general="<?php esc_attr_e('General audience', 'wphave'); ?>">

            <p class="wphave-unsubscribe-message" role="status" aria-live="polite" aria-atomic="true" data-type="<?php echo esc_attr(
                $initial_message_type,
            ); ?>" <?php echo $initial_message ? '' : 'hidden'; ?>>
                <?php echo esc_html($initial_message); ?>
            </p>

            <?php if ($confirm_token) : ?>
                <form method="post" action="<?php echo esc_url(remove_query_arg(['confirm_token', 'token'])); ?>" class="wphave-unsubscribe-confirmation-form">
                    <input type="hidden" name="confirm_token" value="<?php echo esc_attr($confirm_token); ?>">
                    <button type="submit" class="wph-b wp-block-wphave-form-submit-button btn primary">
                        <?php esc_html_e('Confirm unsubscribe', 'wphave'); ?>
                    </button>
                </form>
            <?php endif; ?>

            <form class="wphave-unsubscribe-form wph-b wp-block-wphave-form ly" data-view="request">
                <div class="ly-con">
                    <div class="wph-b wp-block-wphave-form-input">
                        <span>
                            <span class="wphave-form-field-label">
                                <?php esc_html_e('Email address', 'wphave'); ?>
                            </span>
                        </span>
                        <input type="email" class="wphave-form-input" name="email" autocomplete="email" required>
                    </div>
                    <button type="submit" class="wph-b wp-block-wphave-form-submit-button btn primary">
                        <?php esc_html_e('Continue', 'wphave'); ?>
                    </button>
                </div>
            </form>

            <form class="wphave-unsubscribe-form wph-b wp-block-wphave-form ly" data-view="confirm" hidden style="display: none;">
                <div class="ly-con">
                    <div class="wph-b wp-block-wphave-form-checkbox-group">
                        <span>
                            <span class="wphave-form-field-label">
                                <?php esc_html_e(
                                    'Choose what you want to unsubscribe from',
                                    'wphave',
                                ); ?>
                            </span>
                        </span>
                        <div class="wphave-form-checkbox-group" role="group">
                            <label for="wphave_unsubscribe_form_all">
                                <input type="checkbox" class="wphave-form-checkbox-group-input" name="all" id="wphave_unsubscribe_form_all" value="1" />
                                <?php esc_html_e(
                                    'Unsubscribe from all email communication',
                                    'wphave',
                                ); ?>
                            </label>
                            <div class="wphave-unsubscribe-purpose-options"></div>
                        </div>
                    </div>
                    <button type="submit" class="wph-b wp-block-wphave-form-submit-button btn primary">
                        <?php esc_html_e('Send confirmation link', 'wphave'); ?>
                    </button>
                </div>
            </form>
        </div>
        <?php return (string) ob_get_clean();
    }

    /**
     * Renders the public subscriber confirmation template when the route is active.
     */

    public function render_public_subscriber_confirmation(): void {
        if (get_query_var('wphave_audience_action') !== 'confirm_subscription') {
            return;
        }

        global $wp_query;

        if ($wp_query instanceof WP_Query) {
            $wp_query->is_404 = false;
        }

        status_header(200);
        nocache_headers();
        header('Referrer-Policy: no-referrer');

        $is_confirmation = 'POST' === ($_SERVER['REQUEST_METHOD'] ?? 'GET');
        $token = $this->normalize_public_token(
            $is_confirmation
                ? wphave_request_string($_POST, 'token')
                : wphave_request_string($_GET, 'token'),
        );

        // CONSENT INVARIANT: Only the explicit form submission commits a
        // subscription. Rendering or prefetching the email URL is read-only.
        if ($is_confirmation) {
            $result = $this->confirm_subscriber_token($token);
        } elseif ($token) {
            $result = [
                'state' => 'pending',
                'title' => __('Confirm your subscription', 'wphave'),
                'message' => __('Choose Confirm to complete your subscription.', 'wphave'),
            ];
        } else {
            $result = $this->subscriber_confirmation_error();
        }
        $content = $this->get_subscriber_confirmation_template_content($result);

        if (!$is_confirmation && $token) {
            $content .= sprintf(
                '<!-- wp:html --><form method="post" action="%s" referrerpolicy="no-referrer"><input type="hidden" name="token" value="%s"><button type="submit">%s</button></form><!-- /wp:html -->',
                esc_url(home_url('/wphave/confirm-subscription/')),
                esc_attr($token),
                esc_html__('Confirm subscription', 'wphave'),
            );
        }

        add_filter('wphave_template_content', fn() => $content, 99);
    }

    /**
     * Loads active subscription records for an email address.
     *
     * @param string $email Email address to search.
     * @return array Active subscription rows.
     */

    private function get_active_subscriptions_by_email(string $email): array {
        global $wpdb;

        if (!is_email($email)) {
            return [];
        }

        $email = $this->normalize_email($email);
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, contact_id, email, purpose, status FROM {$this->subscribers_table} WHERE email = %s AND status != 'unsubscribed' ORDER BY purpose ASC",
                $email,
            ),
            ARRAY_A,
        );

        return array_map([$this, 'format_row'], $rows ?: []);
    }

    /**
     * Creates a pending unsubscribe token and sends the confirmation email.
     *
     * @param string $email Subscriber email address.
     * @param string $base_url URL where the confirmation token should return.
     * @param array $purposes Selected subscription purposes.
     * @param bool $all Whether to unsubscribe from all purposes.
     * @return bool True when the email was sent.
     */

    private function send_unsubscribe_email(
        string $email,
        string $base_url,
        array $purposes = [],
        bool $all = false,
    ): bool {
        $email = $this->normalize_email($email);

        if (!is_email($email) || !$this->check_rate_limit('unsubscribe_email', 10)) {
            return false;
        }

        $subscriptions = $this->get_active_subscriptions_by_email($email);

        if (!$subscriptions) {
            return false;
        }

        $allowed_purposes = array_values(
            array_filter(
                array_map(
                    fn($row) => $this->normalize_purpose_key($row['purpose'] ?? ''),
                    $subscriptions,
                ),
            ),
        );
        $requested_purposes = array_values(
            array_filter(
                array_map(
                    [$this, 'normalize_purpose_key'],
                    $this->normalize_subscription_purposes(['purposes' => $purposes]),
                ),
            ),
        );

        // SECURITY INVARIANT: A public request can withdraw only purposes that are
        // currently active for the submitted address; client selections are candidates.
        $purposes = array_values(array_intersect($requested_purposes, $allowed_purposes));

        if (!$all && !$purposes) {
            return false;
        }

        if (
            !function_exists('wphave_build_email_template') ||
            !function_exists('wphave_email_template_headers')
        ) {
            return false;
        }

        $token = $this->create_pending_unsubscribe_token($email, $purposes, $all);

        if ('' === $token) {
            return false;
        }

        $url = add_query_arg(
            'confirm_token',
            rawurlencode($token),
            remove_query_arg(['confirm_token', 'token'], $base_url),
        );
        $site_name = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);
        $unsubscribe_url = esc_url($url);
        $content =
            '
            <p style="line-height: 24px; padding: 0; margin: 0 0 16px;">
                ' .
            esc_html__('Use the secure link below to confirm your unsubscribe request.', 'wphave') .
            '
            </p>
            <p style="padding: 0; margin: 0 0 20px;">
                <a href="' .
            $unsubscribe_url .
            '" style="display: inline-block; padding: 12px 18px; border-radius: 6px; background: #2563eb; color: #ffffff; text-decoration: none; font-weight: 600;">
                    ' .
            esc_html__('Confirm unsubscribe', 'wphave') .
            '
                </a>
            </p>
            <p style="line-height: 22px; padding: 0; margin: 0; color: #667085;">
                ' .
            esc_html__('If the button does not work, copy this link into your browser:', 'wphave') .
            '<br>
                <a href="' .
            $unsubscribe_url .
            '">' .
            esc_html(esc_url_raw($url)) .
            '</a>
            </p>
        ';

        $message = wphave_build_email_template([
            'title' => __('Confirm your unsubscribe request', 'wphave'),
            'description' => sprintf(
                /* translators: %s: site name. */
                __('Confirm which emails you no longer want to receive from %s.', 'wphave'),
                $site_name,
            ),
            'content' => $content,
            'footer_content' => sprintf(
                /* translators: %s: subscriber email. */
                __('This unsubscribe confirmation was requested for %s.', 'wphave'),
                esc_html($email),
            ),
        ]);

        $sent = (bool) wp_mail(
            $email,
            __('Confirm your unsubscribe request', 'wphave'),
            $message,
            wphave_email_template_headers(),
        );

        if (!$sent) {
            $this->discard_pending_unsubscribe_token($token);
        }

        return $sent;
    }

    /**
     * Stores a pending unsubscribe request in a transient and returns its token.
     *
     * @param string $email Subscriber email address.
     * @param array $purposes Selected subscription purposes.
     * @param bool $all Whether all purposes were selected.
     * @return string Pending unsubscribe token, or an empty string on storage failure.
     */

    private function create_pending_unsubscribe_token(
        string $email,
        array $purposes,
        bool $all,
    ): string {
        $token = $this->generate_token();
        $stored = set_transient(
            $this->pending_unsubscribe_transient_key($token),
            [
                'email' => $email,
                'purposes' => array_values(array_unique(array_map('sanitize_key', $purposes))),
                'all' => $all,
                'expires_at' => time() + DAY_IN_SECONDS,
            ],
            DAY_IN_SECONDS,
        );

        return $stored ? $token : '';
    }

    /** Revoke one pending request whose delivery did not complete. */
    private function discard_pending_unsubscribe_token(string $token): void {
        // SECURITY/DATA-LIFECYCLE INVARIANT: A bearer request becomes durable only
        // when its raw credential is delivered. Failed mail delivery must revoke the
        // server-side authority before the public endpoint acknowledges the attempt.
        $key = $this->pending_unsubscribe_transient_key($token);

        if ('' !== $key) {
            delete_transient($key);
        }
    }

    /**
     * Loads a pending unsubscribe request by token.
     *
     * @param string $token Pending unsubscribe token.
     * @return array Pending request data.
     */

    private function get_pending_unsubscribe_request(string $token): array {
        $token = $this->normalize_public_token($token);

        if (!$token) {
            return [];
        }

        $data = get_transient($this->pending_unsubscribe_transient_key($token));

        return is_array($data) ? $data : [];
    }

    /**
     * Confirms and deletes a pending unsubscribe request when valid.
     *
     * @param string $token Pending unsubscribe token.
     * @return array Confirmation result.
     */

    private function confirm_pending_unsubscribe_request(string $token): array {
        // AVAILABILITY INVARIANT: Anonymous token guesses consume the shared
        // request budget before they acquire a database lock or read a grant.
        // A valid grant remains untouched when the client is rate limited.
        if (!$this->check_rate_limit('unsubscribe_confirm', 20)) {
            return [
                'success' => false,
                'code' => 'wphave_audience_rate_limited',
                'status' => 429,
                'message' => __('Too many requests. Please try again later.', 'wphave'),
            ];
        }

        $key = $this->pending_unsubscribe_transient_key($token);
        if ('' === $key) {
            return $this->confirm_unsubscribe_invalid_grant();
        }

        // CLAIM INVARIANT: One database lock spans fresh read, consumption, consent
        // commit and recovery, even when grants live in an external object cache.
        // Option mutations allow nesting; bearer consumption explicitly must not.
        if (isset(self::$unsubscribe_claims[$key])) {
            return $this->unsubscribe_claim_failure(409);
        }
        self::$unsubscribe_claims[$key] = true;
        try {
            $result = WPHAVE_Option_Mutations::with_lock($key, function () use ($token, $key) {
                if (!wp_using_ext_object_cache()) {
                    WPHAVE_Option_Mutations::clear_read_cache('_transient_' . $key);
                    WPHAVE_Option_Mutations::clear_read_cache('_transient_timeout_' . $key);
                }
                return $this->confirm_claimed_unsubscribe_request($token, $key);
            });
            return is_wp_error($result) ? $this->unsubscribe_claim_failure(409) : $result;
        } finally {
            unset(self::$unsubscribe_claims[$key]);
        }
    }

    /** Return a non-disclosing invalid or consumed grant result. */
    private function confirm_unsubscribe_invalid_grant(): array {
        return [
            'success' => false,
            'message' => __(
                'This unsubscribe confirmation link is invalid or no longer available.',
                'wphave',
            ),
        ];
    }

    /** Report operational failure without recreating authority. */
    private function unsubscribe_claim_failure(int $status): array {
        return [
            'success' => false,
            'code' => 'wphave_audience_unsubscribe_failed',
            'status' => $status,
            'message' => __(
                'Your subscription preferences could not be updated. Please try again.',
                'wphave',
            ),
        ];
    }

    /** Consume and recover only while the caller holds the exclusive grant lock. */
    private function confirm_claimed_unsubscribe_request(string $token, string $key): array {
        $data = $this->get_pending_unsubscribe_request($token);

        if (!$data) {
            return $this->confirm_unsubscribe_invalid_grant();
        }

        // EXPIRY INVARIANT: Recovery preserves the original absolute deadline.
        // Legacy database grants retain their known timeout; legacy external-cache
        // grants without a verifiable deadline fail closed and need a fresh link.
        $expires =
            (int) ($data['expires_at'] ??
                (wp_using_ext_object_cache() ? 0 : get_option('_transient_timeout_' . $key, 0)));
        if ($expires <= time()) {
            return $this->confirm_unsubscribe_invalid_grant();
        }

        // SECURITY/CONSENT INVARIANT: The public bearer is consumed before any
        // subscription or consent mutation begins. An uncommitted deletion leaves
        // reusable authority and therefore must fail without changing live state.
        // A failed consume never grants recovery authority from an old snapshot.
        if (!delete_transient($key) || false !== get_transient($key)) {
            return $this->unsubscribe_claim_failure(500);
        }

        // SECURITY INVARIANT: The token identifies the complete server-owned request;
        // email, purpose scope and all-purpose intent never come from confirmation input.
        $stored_purposes = $data['purposes'] ?? [];
        $result = $this->confirm_unsubscribe_request(
            $this->normalize_email($data['email'] ?? ''),
            is_array($stored_purposes) ? $stored_purposes : [],
            // SECURITY INVARIANT: Persisted scope remains untrusted input; ambiguous
            // values must fail closed instead of expanding withdrawal to all purposes.
            $this->normalize_public_boolean($data['all'] ?? false),
        );

        if (
            empty($result['success']) &&
            in_array((int) ($result['status'] ?? 400), [429, 500], true)
        ) {
            $this->restore_pending_unsubscribe_request($key, $data, $expires);
        }

        return $result;
    }

    /**
     * Restores a consumed request after an operational failure.
     *
     * @param string $key HMAC-derived transient key.
     * @param array  $data Complete server-owned request state.
     */
    private function restore_pending_unsubscribe_request(
        string $key,
        array $data,
        int $expires,
    ): bool {
        $remaining = $expires - time();
        if ('' === $key || !$data || $remaining <= 0) {
            return false;
        }

        /*
         * CONSENT/RECOVERY INVARIANT: Consuming the bearer and committing the
         * withdrawal form one recoverable workflow. Rate-limit or storage failure
         * after consumption must restore the exact server-owned request; malformed
         * or unauthorized requests remain consumed and cannot gain retry authority.
         */
        return set_transient($key, $data, $remaining) && $data === get_transient($key);
    }

    /**
     * SECURITY INVARIANT: Build a site-scoped transient key without persisting
     * the bearer token.
     *
     * WordPress stores transient names in the options table when no persistent
     * object cache is active, so the raw one-time credential must never be used
     * as part of that name.
     *
     * @param string $token Valid public unsubscribe token.
     * @return string HMAC-derived transient key, or an empty string when invalid.
     */
    private function pending_unsubscribe_transient_key(string $token): string {
        $token = $this->normalize_public_token($token);

        if ('' === $token) {
            return '';
        }

        return 'wphave_unsubscribe_request_' . hash_hmac('sha256', $token, wp_salt('auth'));
    }

    /**
     * Marks selected active subscriptions as unsubscribed.
     *
     * @param string $email Subscriber email address.
     * @param array $purposes Selected subscription purposes.
     * @param bool $all Whether to unsubscribe from all purposes.
     * @return array Unsubscribe result.
     */

    private function confirm_unsubscribe_request(string $email, array $purposes, bool $all): array {
        global $wpdb;

        $email = $this->normalize_email($email);
        $subscriptions = $this->get_active_subscriptions_by_email($email);

        if (!is_email($email) || !$subscriptions) {
            return [
                'success' => false,
                'message' => __(
                    'This unsubscribe confirmation link is invalid or no longer available.',
                    'wphave',
                ),
            ];
        }

        $now = current_time('mysql');
        $purposes = array_values(
            array_filter(array_map([$this, 'normalize_purpose_key'], $purposes)),
        );
        $withdrawn = $all
            ? $subscriptions
            : array_values(
                array_filter(
                    $subscriptions,
                    fn($row) => in_array(
                        $this->normalize_purpose_key($row['purpose'] ?? ''),
                        $purposes,
                        true,
                    ),
                ),
            );

        if (!$all) {
            $allowed_purposes = array_values(
                array_filter(
                    array_map(
                        fn($row) => $this->normalize_purpose_key($row['purpose'] ?? ''),
                        $subscriptions,
                    ),
                ),
            );
            $purposes = array_values(array_intersect($purposes, $allowed_purposes));

            if (!$purposes) {
                return [
                    'success' => false,
                    'message' => __(
                        'Choose at least one subscription to unsubscribe from.',
                        'wphave',
                    ),
                ];
            }
        }

        /*
         * DATA INTEGRITY INVARIANT: Every selected subscription transition and
         * its immutable withdrawal facts form one public unsubscribe unit.
         */
        if (!$this->begin_audience_transaction()) {
            return [
                'success' => false,
                'code' => 'wphave_audience_unsubscribe_failed',
                'status' => 500,
                'message' => __(
                    'Your subscription preferences could not be updated. Please try again.',
                    'wphave',
                ),
            ];
        }

        $write_succeeded = true;

        if ($all) {
            $write_succeeded =
                false !==
                $wpdb->update(
                    $this->subscribers_table,
                    [
                        'status' => 'unsubscribed',
                        'consent' => 0,
                        'confirm_token_hash' => '',
                        'confirm_expires_at' => null,
                        'unsubscribed_at' => $now,
                        'updated_at' => $now,
                    ],
                    ['email' => $email],
                    ['%s', '%d', '%s', '%s', '%s', '%s'],
                    ['%s'],
                );
        } else {
            foreach ($purposes as $purpose) {
                if (
                    false ===
                    $wpdb->update(
                        $this->subscribers_table,
                        [
                            'status' => 'unsubscribed',
                            'consent' => 0,
                            'confirm_token_hash' => '',
                            'confirm_expires_at' => null,
                            'unsubscribed_at' => $now,
                            'updated_at' => $now,
                        ],
                        ['email' => $email, 'purpose' => $purpose],
                        ['%s', '%d', '%s', '%s', '%s', '%s'],
                        ['%s', '%s'],
                    )
                ) {
                    $write_succeeded = false;
                    break;
                }
            }
        }

        foreach ($write_succeeded ? $withdrawn : [] as $subscriber) {
            if (
                !$this->record_consent_event([
                    'contact_id' => absint($subscriber['contact_id'] ?? 0),
                    'subscriber_id' => absint($subscriber['id'] ?? 0),
                    'purpose' => $subscriber['purpose'] ?? '',
                    'action' => 'withdrawn',
                    'source' => 'public_unsubscribe',
                ])
            ) {
                $write_succeeded = false;
                break;
            }

            if (!$this->minimize_unsubscribed_subscriber(absint($subscriber['id'] ?? 0))) {
                $write_succeeded = false;
                break;
            }
        }

        if (!$write_succeeded) {
            $this->rollback_audience_transaction();

            return [
                'success' => false,
                'code' => 'wphave_audience_unsubscribe_failed',
                'status' => 500,
                'message' => __(
                    'Your subscription preferences could not be updated. Please try again.',
                    'wphave',
                ),
            ];
        }

        if (!$this->commit_audience_transaction()) {
            $this->rollback_audience_transaction();

            return [
                'success' => false,
                'code' => 'wphave_audience_unsubscribe_failed',
                'status' => 500,
                'message' => __(
                    'Your subscription preferences could not be updated. Please try again.',
                    'wphave',
                ),
            ];
        }

        return [
            'success' => true,
            'message' => __('Your subscription preferences have been updated.', 'wphave'),
        ];
    }

    /**
     * Confirms a pending subscriber using a confirmation token.
     *
     * Only the token hash is queried and the expiry predicate fails closed. A
     * successful transition grants the current projection, timestamps the grant,
     * consumes the credential in the same update and appends immutable evidence.
     * Replays therefore resolve to the same generic invalid-token response as an
     * unknown or expired credential.
     *
     * @param string $token Raw token received from the subscriber's email link.
     * @return array Confirmation result.
     */

    private function confirm_subscriber_token(string $token): array {
        global $wpdb;

        if (!$this->check_rate_limit('confirm_subscriber', 30)) {
            return [
                'success' => false,
                'code' => 'wphave_audience_rate_limited',
                'status' => 429,
                'state' => 'error',
                'title' => __('Too many requests', 'wphave'),
                'message' => __('Please try again in a moment.', 'wphave'),
            ];
        }

        $token = $this->normalize_public_token($token);

        if (!$token || !$this->column_exists($this->subscribers_table, 'confirm_token_hash')) {
            return $this->subscriber_confirmation_error();
        }

        $token_hash = $this->confirmation_token_hash($token);

        /*
         * OBJECT-BINDING INVARIANT: A DOI bearer token grants one exact pending
         * subscriber transition. Imported, restored or corrupted duplicate hashes
         * must fail closed; selecting an arbitrary LIMIT 1 row would turn token
         * authenticity into authority over an indeterminate object.
         */
        $matching_subscribers = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$this->subscribers_table} WHERE confirm_token_hash = %s AND confirm_expires_at >= %s LIMIT 2",
                $token_hash,
                current_time('mysql'),
            ),
            ARRAY_A,
        );

        if (!is_array($matching_subscribers) || 1 !== count($matching_subscribers)) {
            return $this->subscriber_confirmation_error();
        }

        $subscriber = $matching_subscribers[0];

        $updated_at = current_time('mysql');

        /*
         * SECURITY INVARIANT: The one-time DOI credential is consumed only in
         * the same verified commit that grants consent and appends its immutable
         * confirmation event. Any commit uncertainty must fail closed and must
         * never be reported to the public caller as a successful confirmation.
         */
        if (!$this->begin_audience_transaction()) {
            return [
                'success' => false,
                'code' => 'wphave_audience_confirmation_failed',
                'status' => 500,
                'state' => 'error',
                'title' => __('Confirmation failed', 'wphave'),
                'message' => __(
                    'Your subscription could not be confirmed. Please try again.',
                    'wphave',
                ),
            ];
        }

        $updated = $wpdb->update(
            $this->subscribers_table,
            [
                'status' => 'subscribed',
                'consent' => 1,
                'consent_at' => $updated_at,
                'confirmed_at' => $updated_at,
                'unsubscribed_at' => null,
                'confirm_token_hash' => '',
                'confirm_expires_at' => null,
                'updated_at' => $updated_at,
            ],
            [
                'id' => absint($subscriber['id']),
                'confirm_token_hash' => $token_hash,
            ],
            ['%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s'],
            ['%d', '%s'],
        );

        $consent_recorded =
            1 === $updated &&
            $this->record_consent_event([
                'contact_id' => absint($subscriber['contact_id'] ?? 0),
                'subscriber_id' => absint($subscriber['id'] ?? 0),
                'purpose' => $subscriber['purpose'] ?? '',
                'action' => 'confirmed',
                'source' => 'double_opt_in',
                'evidence_public_id' =>
                    $this->latest_consent_evidence(absint($subscriber['id'] ?? 0))['public_id'] ??
                    '',
            ]);

        if (1 !== $updated || !$consent_recorded) {
            $this->rollback_audience_transaction();

            return [
                'success' => false,
                'code' => 'wphave_audience_confirmation_failed',
                'status' => 500,
                'state' => 'error',
                'title' => __('Confirmation failed', 'wphave'),
                'message' => __(
                    'Your subscription could not be confirmed. Please try again.',
                    'wphave',
                ),
            ];
        }

        if (!$this->commit_audience_transaction()) {
            $this->rollback_audience_transaction();

            return [
                'success' => false,
                'code' => 'wphave_audience_confirmation_failed',
                'status' => 500,
                'state' => 'error',
                'title' => __('Confirmation failed', 'wphave'),
                'message' => __(
                    'Your subscription could not be confirmed. Please try again.',
                    'wphave',
                ),
            ];
        }

        return [
            'success' => true,
            'state' => 'confirmed',
            'title' => __('Subscription confirmed', 'wphave'),
            'message' => __(
                'Thank you. Your email address has been confirmed successfully.',
                'wphave',
            ),
            // PRIVACY INVARIANT: The bearer link authorizes a one-time consent
            // transition, not disclosure of the subscriber's stored profile.
            // The public page and REST caller need only a generic receipt.
        ];
    }

    /**
     * Builds a normalized invalid confirmation response.
     *
     * @return array Error response data.
     */

    private function subscriber_confirmation_error(): array {
        return [
            'success' => false,
            'code' => 'wphave_audience_invalid_token',
            'status' => 404,
            'state' => 'invalid',
            'title' => __('Confirmation link invalid', 'wphave'),
            'message' => __('This confirmation link is invalid or no longer available.', 'wphave'),
        ];
    }

    /**
     * Builds the public subscription confirmation URL.
     *
     * @param string $token Confirmation token.
     * @return string Confirmation URL.
     */

    private function subscriber_confirmation_url(string $token): string {
        return add_query_arg(
            'token',
            rawurlencode($token),
            home_url('/wphave/confirm-subscription/'),
        );
    }

    /**
     * Loads the configured subscriber confirmation template content.
     *
     * @param array $result Confirmation result data.
     * @return string Template content with placeholders replaced.
     */

    private function get_subscriber_confirmation_template_content(array $result): string {
        if (class_exists('WPHAVE_Dynamic_Data_Runtime_Context')) {
            WPHAVE_Dynamic_Data_Runtime_Context::set('audience.subscriber.confirmation', [
                'state' => sanitize_key($result['state'] ?? 'invalid'),
                'title' => sanitize_text_field($result['title'] ?? ''),
                'message' => sanitize_text_field($result['message'] ?? ''),
                'action_label' => __('Back to website', 'wphave'),
                'action_url' => home_url('/'),
            ]);
        }

        $template = class_exists('WPHAVE_Templates')
            ? WPHAVE_Templates::custom_template('subscriber_confirmation')
            : false;
        $content =
            is_array($template) && !empty($template['template_content'])
                ? $template['template_content']
                : '';

        if (!$content) {
            $content = wphave_basic_template_content('subscriber_confirmation');
        }

        $content = $this->replace_subscriber_confirmation_placeholders($content, $result);

        if (class_exists('WPHAVE_Dynamic_Data')) {
            $content = WPHAVE_Dynamic_Data::instance()->resolve_public_tokens_in_block_content(
                $content,
            );
        }

        return $content;
    }

    /**
     * Replaces subscriber confirmation placeholders in template content.
     *
     * @param string $content Template content.
     * @param array $result Confirmation result data.
     * @return string Template content with rendered values.
     */

    private function replace_subscriber_confirmation_placeholders(
        string $content,
        array $result,
    ): string {
        $site_name = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);
        $state = sanitize_key($result['state'] ?? 'invalid');
        $title = sanitize_text_field($result['title'] ?? '');
        $message = sanitize_text_field($result['message'] ?? '');

        return str_replace(
            [
                '{{wphave_subscriber_confirmation_state}}',
                '{{wphave_subscriber_confirmation_title}}',
                '{{wphave_subscriber_confirmation_message}}',
                '{{wphave_subscriber_confirmation_site_name}}',
                '{{wphave_subscriber_confirmation_back_label}}',
                '{{wphave_site_url}}',
            ],
            [
                esc_attr($state),
                esc_html($title),
                esc_html($message),
                esc_html($site_name),
                esc_html__('Back to website', 'wphave'),
                esc_url(home_url('/')),
            ],
            $content,
        );
    }

    /**
     * Sends the subscriber opt-in confirmation email.
     *
     * @param array $subscriber Subscriber row data.
     */

    private function send_confirmation_email(array $subscriber): void {
        if (empty($subscriber['email']) || empty($subscriber['confirmation_token'])) {
            return;
        }

        if (
            !function_exists('wphave_build_email_template') ||
            !function_exists('wphave_email_template_headers')
        ) {
            return;
        }

        $url = $this->subscriber_confirmation_url($subscriber['confirmation_token']);

        $site_name = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);
        $email = sanitize_email($subscriber['email']);
        $first_name = sanitize_text_field($subscriber['first_name'] ?? '');
        $name = $first_name ?: $email;
        $confirm_url = esc_url($url);
        $content =
            '
            <p style="line-height: 24px; padding: 0; margin: 0 0 16px;">
                ' .
            sprintf(
                /* translators: %s: subscriber name or email. */
                esc_html__('Hi %s,', 'wphave'),
                esc_html($name),
            ) .
            '
            </p>
            <p style="line-height: 24px; padding: 0; margin: 0 0 20px;">
                ' .
            sprintf(
                /* translators: %s: site name. */
                esc_html__('Please confirm that you want to receive updates from %s.', 'wphave'),
                esc_html($site_name),
            ) .
            '
            </p>
            <p style="padding: 0; margin: 0 0 20px;">
                <a href="' .
            $confirm_url .
            '" style="display: inline-block; padding: 12px 18px; border-radius: 6px; background: #2563eb; color: #ffffff; text-decoration: none; font-weight: 600;">
                    ' .
            esc_html__('Confirm subscription', 'wphave') .
            '
                </a>
            </p>
            <p style="line-height: 22px; padding: 0; margin: 0; color: #667085;">
                ' .
            esc_html__('If the button does not work, copy this link into your browser:', 'wphave') .
            '<br>
                <a href="' .
            $confirm_url .
            '">' .
            esc_html(esc_url_raw($url)) .
            '</a>
            </p>
        ';

        $message = wphave_build_email_template([
            'title' => __('Confirm your subscription', 'wphave'),
            'description' => sprintf(
                /* translators: %s: site name. */
                __('Confirm your email address to receive updates from %s.', 'wphave'),
                $site_name,
            ),
            'content' => $content,
            'footer_content' => sprintf(
                /* translators: %s: subscriber email. */
                __('This confirmation was requested for %s.', 'wphave'),
                esc_html($email),
            ),
        ]);

        $subject = __('Confirm your subscription', 'wphave');
        $headers = (array) wphave_email_template_headers();
        $delivered = wp_mail($email, $subject, $message, $headers);

        $this->record_confirmation_evidence(
            $subscriber,
            $subject,
            $message,
            $headers,
            $url,
            (bool) $delivered,
        );
    }
}
