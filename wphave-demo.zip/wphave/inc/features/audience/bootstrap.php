<?php

/**
 * Audience Manager bootstrap helpers.
 *
 * @package wphave
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once wphave_dir() . 'inc/background-jobs/functions.php';

if (
	! defined( 'WPHAVE_AUDIENCE_INTERACTIVE_RUNTIME' )
	&& ( ! defined( 'WPHAVE_AUDIENCE_WORKER_RUNTIME' ) || ! WPHAVE_AUDIENCE_WORKER_RUNTIME )
) {
	define( 'WPHAVE_AUDIENCE_INTERACTIVE_RUNTIME', true );
}

require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/rest-controller.php';
require_once __DIR__ . '/public-flows.php';
require_once __DIR__ . '/repository.php';
require_once __DIR__ . '/consent-evidence.php';
require_once __DIR__ . '/permissions.php';
require_once __DIR__ . '/utilities.php';
require_once __DIR__ . '/retention.php';
require_once __DIR__ . '/privacy.php';
require_once __DIR__ . '/domain-v2.php';
require_once __DIR__ . '/lead-workflow.php';
require_once __DIR__ . '/contact-lifecycle.php';
require_once __DIR__ . '/lead-read-model.php';
require_once __DIR__ . '/registries.php';
require_once __DIR__ . '/outbox.php';
require_once __DIR__ . '/manager.php';

/**
 * Initializes the shared Audience Manager instance and registers hooks.
 */

if ( ! function_exists( 'wphave_audience_manager_init' ) ) :

    function wphave_audience_manager_init() {
		if ( ! WPHAVE_Database_Schema_Manager::runtime_compatible( 'audience' ) ) {
			return;
		}

        $manager = wphave_audience_manager();
        $manager->init();
    }

endif;

/**
 * Hierarchical Audience release gates. Constants support deployments, while
 * filters allow product policy to provide stored settings without coupling
 * the domain to the settings repository.
 */
function wphave_audience_feature_enabled( string $feature = 'domain_v2' ): bool {
    $constant = 'WPHAVE_AUDIENCE_' . strtoupper( $feature );
    $default = defined( $constant ) ? (bool) constant( $constant ) : true;

    if ( $feature !== 'domain_v2' && ! wphave_audience_feature_enabled( 'domain_v2' ) ) {
        return false;
    }

    return (bool) apply_filters( 'wphave_audience_feature_enabled', $default, $feature );
}

/**
 * Returns the shared Audience Manager instance.
 *
 * @return WPHAVE_Audience_Manager Audience manager instance.
 */

if ( ! function_exists( 'wphave_audience_manager' ) ) :

    function wphave_audience_manager() {
		static $managers = [];
		$blog_id = get_current_blog_id();

		if ( ! isset( $managers[$blog_id] ) ) {
			$managers[$blog_id] = new WPHAVE_Audience_Manager();
		}

		return $managers[$blog_id];
    }

endif;

WPHAVE_Database_Schema_Manager::register( [
    'id' => 'audience',
    'label' => 'Audience tables',
    'version' => WPHAVE_Audience_Manager::DB_VERSION,
    'option' => 'wphave_audience_db_version',
    'tables' => [
        WPHAVE_Audience_Manager::LEADS_TABLE,
        WPHAVE_Audience_Manager::SUBSCRIBERS_TABLE,
        WPHAVE_Audience_Manager::CONTACTS_TABLE,
        WPHAVE_Audience_Manager::IDENTITIES_TABLE,
        WPHAVE_Audience_Manager::INTERACTIONS_TABLE,
        WPHAVE_Audience_Manager::PIPELINES_TABLE,
        WPHAVE_Audience_Manager::STAGES_TABLE,
        WPHAVE_Audience_Manager::ACTIVITIES_TABLE,
        WPHAVE_Audience_Manager::PURPOSES_TABLE,
        WPHAVE_Audience_Manager::CONSENT_EVENTS_TABLE,
        WPHAVE_Audience_Manager::CONSENT_EVIDENCE_TABLE,
        WPHAVE_Audience_Manager::OUTBOX_TABLE,
        WPHAVE_Audience_Manager::TAGS_TABLE,
        WPHAVE_Audience_Manager::ENTITY_TAGS_TABLE,
        WPHAVE_Audience_Manager::FIELD_DEFINITIONS_TABLE,
        WPHAVE_Audience_Manager::FIELD_VALUES_TABLE,
    ],
    'callback' => function() {
        wphave_audience_manager()->install();
    },
    'validator' => function() {
        return wphave_audience_manager()->schema_ready();
    },
] );

add_action( 'init', 'wphave_audience_manager_init' );
