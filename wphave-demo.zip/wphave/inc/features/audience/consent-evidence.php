<?php

/**
 * Immutable consent evidence artifacts and administrative read models.
 *
 * @package wphave
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

trait WPHAVE_Audience_Consent_Evidence_Trait {

	/** Stable contract version for newly archived DOI evidence. */
	private const CONSENT_EVIDENCE_VERSION = '1';

	/**
	 * Archives the exact DOI communication contract without retaining a usable token.
	 *
	 * The rendered message hash covers the message that was handed to wp_mail. The
	 * stored snapshot replaces the one-time URL so administrators can inspect the
	 * communication without creating a replayable credential.
	 *
	 * @param array  $subscriber Subscriber projection used for delivery.
	 * @param string $subject Final localized subject.
	 * @param string $message Final rendered HTML message.
	 * @param array  $headers Final mail headers.
	 * @param string $confirmation_url Raw one-time confirmation URL.
	 * @param bool   $delivered Whether WordPress accepted the message for delivery.
	 * @return string Evidence public id, or an empty string when persistence failed.
	 */
	private function record_confirmation_evidence(
		array $subscriber,
		string $subject,
		string $message,
		array $headers,
		string $confirmation_url,
		bool $delivered
	): string {
		global $wpdb;

		if ( ! $this->table_exists( $this->consent_evidence_table ) ) {
			return '';
		}

		$public_id = wp_generate_uuid4();
		// DATA INTEGRITY INVARIANT: Evidence must retain the exact consent-purpose
		// and recipient identities and must never repair malformed stored input.
		$purpose = $this->normalize_purpose_key( $subscriber['purpose'] ?? '' );
		$recipient_email = $this->normalize_email( $subscriber['email'] ?? '' );
		$raw_consent_label = $subscriber['consent_label'] ?? '';

		if ( '' === $purpose || ! is_email( $recipient_email ) || ! is_scalar( $raw_consent_label ) ) {
			return '';
		}

		$site_name = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		$statement = sanitize_textarea_field(
			(string) $raw_consent_label
		) ?: sprintf(
			/* translators: 1: subscription purpose, 2: website name. */
			__( 'I consent to receive email updates for the purpose "%1$s" from %2$s.', 'wphave' ),
			$purpose,
			$site_name
		);
		$redacted_message = str_replace(
			[
				$confirmation_url,
				esc_url( $confirmation_url ),
				esc_url_raw( $confirmation_url ),
			],
			'{{wphave_confirmation_url_redacted}}',
			$message
		);
		$now = current_time( 'mysql' );

		/*
		 * DATA INTEGRITY INVARIANT: The immutable communication artifact and the
		 * consent event referencing its public id are one evidence unit. Never
		 * persist or return that identity outside a verified transaction boundary.
		 */
		if ( ! $this->begin_audience_transaction() ) {
			return '';
		}

		$inserted = $wpdb->insert(
			$this->consent_evidence_table,
			[
				'public_id' => $public_id,
				'subscriber_id' => absint( $subscriber['id'] ?? 0 ),
				'contact_id' => absint( $subscriber['contact_id'] ?? 0 ),
				'recipient_email' => $recipient_email,
				'purpose_key' => $purpose,
				'legal_basis' => 'consent',
				'statement_key' => 'audience_email_subscription',
				'statement_version' => self::CONSENT_EVIDENCE_VERSION,
				'statement_snapshot' => $statement,
				'template_key' => 'audience_double_opt_in',
				'template_version' => self::CONSENT_EVIDENCE_VERSION,
				'locale' => sanitize_text_field( determine_locale() ),
				'subject' => sanitize_text_field( $subject ),
				'sender_snapshot' => implode( "\n", array_map( 'sanitize_text_field', $headers ) ),
				'message_snapshot' => wp_kses_post( $redacted_message ),
				'message_hash' => hash( 'sha256', $message ),
				'confirmation_url_hash' => hash( 'sha256', $confirmation_url ),
				'delivery_status' => $delivered ? 'accepted' : 'failed',
				'sent_at' => $now,
				'created_at' => $now,
			]
		);

		if ( ! $inserted ) {
			$this->rollback_audience_transaction();

			return '';
		}

		$event_recorded = $this->record_consent_event(
			[
				'contact_id' => absint( $subscriber['contact_id'] ?? 0 ),
				'subscriber_id' => absint( $subscriber['id'] ?? 0 ),
				'purpose' => $purpose,
				'action' => $delivered ? 'confirmation_sent' : 'confirmation_failed',
				'source' => 'double_opt_in',
				'statement_key' => 'audience_email_subscription',
				'statement_version' => self::CONSENT_EVIDENCE_VERSION,
				'statement_snapshot' => $statement,
				'evidence_public_id' => $public_id,
				'occurred_at' => $now,
			]
		);

		if ( ! $event_recorded ) {
			$this->rollback_audience_transaction();

			return '';
		}

		if ( ! $this->commit_audience_transaction() ) {
			$this->rollback_audience_transaction();

			return '';
		}

		return $public_id;
	}

	/**
	 * Returns the newest archived DOI artifact for a subscriber.
	 *
	 * @param int $subscriber_id Subscriber database id.
	 * @return array<string, mixed>|null Evidence row or null.
	 */
	private function latest_consent_evidence( int $subscriber_id ): ?array {
		global $wpdb;

		if ( ! $subscriber_id || ! $this->table_exists( $this->consent_evidence_table ) ) {
			return null;
		}

		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$this->consent_evidence_table} WHERE subscriber_id = %d ORDER BY sent_at DESC, id DESC LIMIT 1",
				$subscriber_id
			),
			ARRAY_A
		);

		return $row ? $this->format_row( $row ) : null;
	}

	/**
	 * Exposes a bounded, administrator-only consent proof read model.
	 *
	 * @param WP_REST_Request $request Request containing the subscriber id.
	 * @return WP_REST_Response|WP_Error Consent proof response.
	 */
	public function subscriber_consent_evidence_endpoint( WP_REST_Request $request ) {
		if ( ! $this->subscription_permission_check() ) {
			return $this->audience_access_error();
		}

		$subscriber_id = absint( $request['id'] );
		$subscriber = $this->get_row( $this->subscribers_table, $subscriber_id );

		if ( ! $subscriber ) {
			return new WP_Error(
				'wphave_audience_subscriber_missing',
				__( 'Subscriber was not found.', 'wphave' ),
				[ 'status' => 404 ]
			);
		}

		$evidence = $this->latest_consent_evidence( $subscriber_id );

		if ( ! $evidence ) {
			return rest_ensure_response(
				[
					'available' => false,
					'item' => null,
					'message' => __( 'No archived double-opt-in evidence is available for this subscriber.', 'wphave' ),
				]
			);
		}

		return rest_ensure_response(
			[
				'available' => true,
				'item' => $evidence,
			]
		);
	}
}
