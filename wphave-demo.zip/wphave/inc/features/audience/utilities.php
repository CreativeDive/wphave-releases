<?php

/**
 * Shared request, date, rate-limit and formatting utilities.
 *
 * @package wphave
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once __DIR__ . '/../security/client-ip.php';

/**
 * Shared request, date, rate-limit and formatting utilities.
 */

trait WPHAVE_Audience_Utilities_Trait {

    /** Whether this manager currently owns an open Audience transaction. */
    private bool $audience_transaction_active = false;

    /**
     * Builds a bounded date range from a REST request.
     *
     * @param WP_REST_Request $request REST request with range parameters.
     * @return array Date range data.
     */

    private function get_range( WP_REST_Request $request ): array {
        $days = max( 1, min( 365, absint( $request->get_param( 'days' ) ?: 30 ) ) );
        $to = current_time( 'timestamp' );
        $from = strtotime( "-{$days} days", $to );

        return [
            'from' => date( 'Y-m-d', $from ),
            'to'   => date( 'Y-m-d', $to ),
            'days' => $days,
        ];
    }

    /**
     * Maps subscriber status count rows into a stable summary shape.
     *
     * @param array $rows Database status count rows.
     * @return array Status summary.
     */

    private function map_status_counts( array $rows ): array {
        $map = [
            'total' => 0,
            'subscribed' => 0,
            'pending' => 0,
            'unsubscribed' => 0,
        ];

        foreach ( $rows as $row ) {
            $status = $row['status'] ?: 'subscribed';
            $map[ $status ] = (int) $row['total'];
            $map['total'] += (int) $row['total'];
        }

        return $map;
    }

    /**
     * Casts metric row values to numeric response values.
     *
     * @param array $row Raw metric row.
     * @return array Formatted metric row.
     */

    private function format_metric_row( array $row ): array {
        $row['value'] = (int) ( $row['value'] ?? 0 );
        if ( isset( $row['contacts'] ) ) {
            $row['contacts'] = (int) $row['contacts'];
        }
        return $row;
    }

    /**
     * Applies a transient-based rate limit for public actions.
     *
     * @param string $action Action key.
     * @param int $limit Maximum requests in the window.
     * @param int $window Window duration in seconds.
     * @param string $identity Optional custom identity value.
     * @return bool True when the action is allowed.
     */

    private function check_rate_limit( string $action = 'general', int $limit = 30, int $window = MINUTE_IN_SECONDS, string $identity = '' ): bool {
        // AVAILABILITY INVARIANT: A trusted reverse proxy is not one visitor.
        // Use the centrally validated client address for anonymous budgets;
        // untrusted forwarding headers can never create fresh identities.
        $ip = WPHAVE_Client_IP::resolve();
        $identity = $identity ? sanitize_text_field( strtolower( $identity ) ) : $ip;
        // SECURITY INVARIANT: An unresolved client shares a bounded bucket;
        // missing address metadata must never disable public rate limiting.
        $identity = '' !== $identity ? $identity : 'unresolved-client';
        $key = 'wphave_audience_rl_' . sanitize_key( $action ) . '_' . md5( $identity );
        return WPHAVE_Rate_Limiter::increment( $key, $window ) <= $limit;
    }

    /**
     * Generates a secure Audience token.
     *
     * @return string Token hash.
     */

    private function generate_token(): string {
        return hash( 'sha256', wp_generate_password( 32, false ) . microtime( true ) . wp_salt( 'nonce' ) );
    }

    /**
     * SECURITY INVARIANT: Validate an exact high-entropy public bearer token
     * without sanitizing it.
     *
     * Token input is an identity, not display text. Removing characters before
     * lookup could transform a manipulated value into a valid credential.
     *
     * @param mixed $token Raw token value from a request or URL.
     * @return string Exact lowercase hexadecimal token, or an empty string.
     */
    private function normalize_public_token( $token ): string {
        if ( ! is_string( $token ) || ! preg_match( '/^[a-f0-9]{64}$/D', $token ) ) {
            return '';
        }

        return $token;
    }

    /**
     * Normalizes a public boolean flag without relying on PHP truthiness.
     *
     * Values such as the string "false" must remain false. This is especially
     * important for destructive scope flags submitted by forms or REST clients.
     *
     * @param mixed $value Raw public flag value.
     * @return bool True only for explicit true representations.
     */

    private function normalize_public_boolean( $value ): bool {
        if ( true === $value || 1 === $value || 1.0 === $value ) {
            return true;
        }

        return is_string( $value ) && in_array( strtolower( trim( $value ) ), [ '1', 'true' ], true );
    }

    /**
     * SECURITY INVARIANT: Public writes require the exact configured browser
     * origin tuple rather than a loosely matching host.
     *
     * @return bool True for same-origin requests.
     */

    private function is_same_origin_request(): bool {
        $origin_header = isset( $_SERVER['HTTP_ORIGIN'] ) ? wp_unslash( $_SERVER['HTTP_ORIGIN'] ) : '';
        $referer_header = isset( $_SERVER['HTTP_REFERER'] ) ? wp_unslash( $_SERVER['HTTP_REFERER'] ) : '';
        $candidate = '' !== trim( $origin_header ) ? $origin_header : $referer_header;
        $home_origin = $this->normalize_origin( home_url() );
        $request_origin = $this->normalize_origin( $candidate );

        return '' !== $request_origin && hash_equals( $home_origin, $request_origin );
    }

    /**
     * Returns the public actions that require a client-bound write proof.
     *
     * @return array<string>
     */

    private function public_request_proof_actions(): array {
        return [
            'lead',
            'subscribe',
            'unsubscribe',
            'unsubscribe_options',
        ];
    }

    /**
     * Creates a short-lived proof bound to one action and client context.
     *
     * The proof is stateless so page caching cannot create server-side sessions.
     * Binding it to the remote address and user agent prevents a token collected
     * by a different client from authorizing a victim browser request.
     *
     * @param string $action Public action key.
     * @return string Empty when the action is not part of the public contract.
     */

    public function create_public_request_proof( string $action ): string {
        $action = sanitize_key( $action );

        if ( ! in_array( $action, $this->public_request_proof_actions(), true ) ) {
            return '';
        }

        $issued_at = time();
        $signature = hash_hmac(
            'sha256',
            $this->public_request_proof_message( $action, $issued_at ),
            wp_salt( 'wphave-audience-public-request' )
        );

        return $issued_at . '.' . $signature;
    }

    /**
     * Verifies an exact, action-scoped public request proof.
     *
     * @param mixed  $proof Raw proof supplied by the client.
     * @param string $action Public action key.
     * @return bool Whether the proof is structurally valid, current and authentic.
     */

    private function verify_public_request_proof( $proof, string $action ): bool {
        if ( ! is_string( $proof ) || ! preg_match( '/^(\d{10})\.([a-f0-9]{64})$/D', $proof, $matches ) ) {
            return false;
        }

        $issued_at = (int) $matches[1];
        $now = time();

        if (
            $issued_at > $now + self::PUBLIC_REQUEST_PROOF_CLOCK_SKEW ||
            $issued_at < $now - self::PUBLIC_REQUEST_PROOF_TTL
        ) {
            return false;
        }

        $expected = hash_hmac(
            'sha256',
            $this->public_request_proof_message( $action, $issued_at ),
            wp_salt( 'wphave-audience-public-request' )
        );

        return hash_equals( $expected, $matches[2] );
    }

    /** Build the canonical HMAC message without exposing client identifiers. */

    private function public_request_proof_message( string $action, int $issued_at ): string {
        $client_context = implode( '|', [
            $this->get_ip() ?: 'unresolved-client',
            substr( (string) ( $_SERVER['HTTP_USER_AGENT'] ?? '' ), 0, 512 ),
        ] );

        return implode( '|', [
            sanitize_key( $action ),
            (string) $issued_at,
            hash_hmac( 'sha256', $client_context, wp_salt( 'nonce' ) ),
        ] );
    }

    /**
     * Validates a public Audience request using exact origin and client proof.
     *
     * @param WP_REST_Request $request REST request.
     * @param string $action Public action key.
     * @return bool True when the request is valid.
     */

    private function is_valid_public_request( WP_REST_Request $request, string $action = 'public' ): bool {
        if ( ! $this->is_same_origin_request() ) {
            return false;
        }

        // SECURITY INVARIANT: Public pages may be served from a cache after a
        // WordPress REST nonce expires. A nonce supplied by a custom client is
        // still validated fail-closed, but browser flows authorize exclusively
        // with a fresh, client-bound and action-scoped proof.
        $raw_nonce = $request->get_header( 'x_wp_nonce' ) ?: $request->get_param( '_wpnonce' ) ?: $request->get_param( 'nonce' ) ?: '';

        // AVAILABILITY INVARIANT: Public auth metadata is bounded before text
        // sanitization. A forged, oversized nonce cannot force a full scan on
        // every otherwise rejected anonymous request.
        if ( ! is_string( $raw_nonce ) || strlen( $raw_nonce ) > 128 ) {
            return false;
        }

        $nonce = sanitize_text_field( $raw_nonce );

        if ( $nonce && ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
            return false;
        }

        $proof = $request->get_header( 'x_wphave_audience_proof' ) ?: $request->get_param( '_wphave_audience_proof' );

        return $this->verify_public_request_proof( $proof, $action );
    }

    /**
     * Returns the current remote IP address when valid.
     *
     * @return string Remote IP address or empty string.
     */

    private function get_ip(): string {
        $ip = trim( (string) ( $_SERVER['REMOTE_ADDR'] ?? '' ) );

        return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '';
    }

    /**
     * Returns a salted hash of the current remote IP address.
     *
     * @return string IP hash or empty string.
     */

    private function get_ip_hash(): string {
        $ip = $this->get_ip();

        return $ip ? hash_hmac( 'sha256', $ip, wp_salt( 'auth' ) ) : '';
    }

    /**
     * Returns a salted hash of the current user agent.
     *
     * @return string User agent hash or empty string.
     */

    private function get_user_agent_hash(): string {
        $ua = substr( (string) ( $_SERVER['HTTP_USER_AGENT'] ?? '' ), 0, 500 );

        return $ua ? hash_hmac( 'sha256', $ua, wp_salt( 'auth' ) ) : '';
    }

    /**
     * Returns a SHA-256 hash for a sanitized value.
     *
     * @param string $value Raw value.
     * @return string Hashed value or empty string.
     */

    private function hash_value( string $value ): string {
        return $value ? hash( 'sha256', sanitize_text_field( $value ) ) : '';
    }

    /**
     * Normalize an HTTP URL to the browser origin tuple.
     *
     * Paths are intentionally ignored, while scheme, exact host and effective
     * port remain distinct. Credentials and non-HTTP schemes fail closed.
     *
     * @param mixed $url Candidate home, Origin or Referer URL.
     * @return string Canonical origin tuple, or an empty string when invalid.
     */
    private function normalize_origin( $url ): string {
        if ( ! is_scalar( $url ) ) {
            return '';
        }

        $parts = wp_parse_url( trim( (string) $url ) );

        if ( ! is_array( $parts ) || isset( $parts['user'] ) || isset( $parts['pass'] ) ) {
            return '';
        }

        $scheme = strtolower( (string) ( $parts['scheme'] ?? '' ) );
        $host = strtolower( rtrim( (string) ( $parts['host'] ?? '' ), '.' ) );

        if ( ! in_array( $scheme, [ 'http', 'https' ], true ) || '' === $host ) {
            return '';
        }

        $port = isset( $parts['port'] )
            ? absint( $parts['port'] )
            : ( 'https' === $scheme ? 443 : 80 );

        if ( $port < 1 || $port > 65535 ) {
            return '';
        }

        return $scheme . '://' . $host . ':' . $port;
    }

    /**
     * SECURITY INVARIANT: Keep public email return URLs on the configured
     * website origin.
     *
     * Bearer tokens must never be appended to a request-controlled external URL.
     * Invalid or cross-origin candidates fall back to the canonical site root.
     *
     * @param mixed $url Requested return URL.
     * @return string Safe same-origin URL.
     */
    private function normalize_public_return_url( $url ): string {
        if ( ! is_scalar( $url ) ) {
            return home_url( '/' );
        }

        // AVAILABILITY INVARIANT: This URL is copied into a bearer email.
        // Refuse oversized input before escaping, parsing and mail assembly.
        if ( strlen( (string) $url ) > 2048 ) {
            return home_url( '/' );
        }

        $candidate = esc_url_raw( trim( (string) $url ) );

        if ( '' === $candidate || ! hash_equals( $this->normalize_origin( home_url() ), $this->normalize_origin( $candidate ) ) ) {
            return home_url( '/' );
        }

        return $candidate;
    }

    /**
     * Trims and lowercases a structurally unchanged email address.
     *
     * WordPress sanitization may remove invalid characters. Identity values must
     * never become valid only because lossy sanitization changed the submitted
     * address, otherwise two distinct inputs could resolve to the same contact.
     *
     * @param mixed $email Raw email value.
     * @return string Normalized email address, or an empty string when invalid.
     */

    private function normalize_email( $email ): string {
        if ( ! is_scalar( $email ) ) {
            return '';
        }

        // IDENTITY/AVAILABILITY INVARIANT: Subscriber.email is varchar(190).
        // Reject overlong bytes before sanitization so database truncation
        // cannot turn two distinct addresses into one subscriber identity.
        $submitted_email = (string) $email;
        if ( strlen( $submitted_email ) > 190 ) {
            return '';
        }

        $raw_email = trim( $submitted_email );

        if ( '' === $raw_email ) {
            return '';
        }

        $sanitized_email = sanitize_email( $raw_email );

        if ( 0 !== strcasecmp( $raw_email, $sanitized_email ) ) {
            return '';
        }

        return strtolower( $sanitized_email );
    }

    /** Validate an idempotency identity before any lookup or text processing. */
    private function normalize_submission_id( $raw_submission_id ) {
        if ( ! is_scalar( $raw_submission_id ) ) {
            return new WP_Error(
                'wphave_audience_submission_id_invalid',
                __( 'Submission ID must be a text value.', 'wphave' ),
                [ 'status' => 400 ],
            );
        }

        $submission_id = (string) $raw_submission_id;

        // AVAILABILITY/DATA INTEGRITY INVARIANT: Bound bytes before WordPress
        // sanitization and database lookup, then preserve the exact identity.
        // A lossy or overlong ID must never replay a different lead receipt.
        if ( strlen( $submission_id ) > 400 || trim( $submission_id ) !== $submission_id ) {
            return new WP_Error(
                'wphave_audience_submission_id_invalid',
                __( 'Submission ID is invalid or too long.', 'wphave' ),
                [ 'status' => 400 ],
            );
        }

        $length = function_exists( 'mb_strlen' ) ? mb_strlen( $submission_id ) : strlen( $submission_id );
        if ( $length > 100 || sanitize_text_field( $submission_id ) !== $submission_id ) {
            return new WP_Error(
                'wphave_audience_submission_id_invalid',
                __( 'Submission ID is invalid or too long.', 'wphave' ),
                [ 'status' => 400 ],
            );
        }

        return $submission_id;
    }

    /**
     * Normalize purpose candidates without making invalid identities valid.
     *
     * Purpose registry validation remains at the domain write boundary. This
     * helper only preserves candidate structure across form, REST and public
     * unsubscribe workflows.
     *
     * @param array $data Form, subscriber or unsubscribe data.
     * @return array<int, string> Unique, structurally preserved candidates.
     */
    private function normalize_subscription_purposes( array $data ): array {
        $purposes = $data['audienceSubscriberPurposes'] ?? $data['purposes'] ?? null;

        if ( ! is_array( $purposes ) || empty( $purposes ) ) {
            $purposes = [ $data['audienceSubscriberPurpose'] ?? $data['purpose'] ?? '' ];
        }

        $purposes = array_map(
            static function( $purpose ): string {
                return is_scalar( $purpose )
                    ? strtolower( trim( (string) $purpose ) )
                    : '';
            },
            $purposes
        );

        return array_values( array_unique( $purposes ) ) ?: [ '' ];
    }

    /** Guard public purpose arrays before normalization or transaction work. */
    private function has_bounded_public_purposes( $purposes ): bool {
        if ( ! is_array( $purposes ) || count( $purposes ) > 20 ) {
            return false;
        }

        // AVAILABILITY INVARIANT: A public purpose candidate is a short
        // registry identity. No unbounded array or element reaches array_map,
        // sorting, database lookup or a consent transaction.
        foreach ( $purposes as $purpose ) {
            if ( ! is_string( $purpose ) || strlen( $purpose ) > 100 ) {
                return false;
            }
        }

        return true;
    }

    /**
     * Resolve one exact storage-safe purpose key without lossy sanitization.
     *
     * @param mixed $purpose Raw or stored purpose candidate.
     * @return string Canonical purpose key, or an empty string when invalid.
     */
    private function normalize_purpose_key( $purpose ): string {
        if ( ! is_scalar( $purpose ) ) {
            return '';
        }

        $canonical = strtolower( trim( (string) $purpose ) );

        if ( '' === $canonical || strlen( $canonical ) > 100 || sanitize_key( $canonical ) !== $canonical ) {
            return '';
        }

        return $canonical;
    }

    /**
     * Resolve an exact member of a closed storage-key vocabulary.
     *
     * @param mixed $value Raw key candidate.
     * @param array $allowed Canonical allowed values.
     * @return string Exact allowed key, or an empty string when invalid.
     */

    private function normalize_closed_key( $value, array $allowed ): string {
        if ( ! is_scalar( $value ) ) {
            return '';
        }

        $canonical = strtolower( trim( (string) $value ) );

        if ( '' === $canonical || sanitize_key( $canonical ) !== $canonical ) {
            return '';
        }

        return in_array( $canonical, $allowed, true ) ? $canonical : '';
    }

    /**
     * Validate an exact MySQL datetime without repairing invalid calendar values.
     *
     * @param mixed $value Raw datetime candidate.
     * @return string Exact valid datetime, or an empty string when invalid.
     */

    private function normalize_mysql_datetime( $value ): string {
        if ( ! is_string( $value ) || ! preg_match( '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/D', $value ) ) {
            return '';
        }

        $parsed = DateTimeImmutable::createFromFormat( '!Y-m-d H:i:s', $value );

        return $parsed && $parsed->format( 'Y-m-d H:i:s' ) === $value ? $value : '';
    }

    /**
     * Validate an exact lowercase UUID used by public aggregate references.
     *
     * @param mixed $value Raw UUID candidate.
     * @return string Exact UUID, or an empty string when invalid.
     */

    private function normalize_uuid( $value ): string {
        if ( ! is_string( $value ) || ! preg_match( '/^[a-f0-9]{8}-[a-f0-9]{4}-[1-5][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/D', $value ) ) {
            return '';
        }

        return $value;
    }

    /**
     * Normalize an exact non-negative integer without coercing structured values.
     *
     * @param mixed $value Raw integer candidate.
     * @return int|null Canonical integer, or null when invalid.
     */

    private function normalize_non_negative_integer( $value ): ?int {
        if ( is_int( $value ) ) {
            return $value >= 0 ? $value : null;
        }

        if ( ! is_string( $value ) || ! preg_match( '/^(?:0|[1-9][0-9]*)$/D', $value ) ) {
            return null;
        }

        $normalized = filter_var( $value, FILTER_VALIDATE_INT, [ 'options' => [ 'min_range' => 0 ] ] );

        return false === $normalized ? null : $normalized;
    }

    /**
     * Start a database transaction and verify that the boundary is available.
     */
    private function begin_audience_transaction(): bool {
        global $wpdb;

        /*
         * DATA INTEGRITY INVARIANT: Audience never recursively nests a transaction
         * on the shared WordPress connection. MySQL cannot nest transactions, and
         * a second START could otherwise commit the outer Audience workflow.
         */
        if ( $this->audience_transaction_active ) {
            return false;
        }

        $wpdb->last_error = '';
        $started = $wpdb->query( 'START TRANSACTION' );

        $this->audience_transaction_active = false !== $started && '' === $wpdb->last_error;

        // DATA INTEGRITY INVARIANT: Atomic workflows never continue when the
        // storage engine cannot establish their transaction boundary.
        return $this->audience_transaction_active;
    }

    /**
     * Commit a database transaction and report an uncertain durable outcome.
     */
    private function commit_audience_transaction(): bool {
        global $wpdb;

        if ( ! $this->audience_transaction_active ) {
            return false;
        }

        $wpdb->last_error = '';
        $committed = $wpdb->query( 'COMMIT' );
        $succeeded = false !== $committed && '' === $wpdb->last_error;

        if ( $succeeded ) {
            $this->audience_transaction_active = false;
        }

        return $succeeded;
    }

    /**
     * Best-effort rollback for a failed atomic workflow.
     */
    private function rollback_audience_transaction(): bool {
        global $wpdb;

        if ( ! $this->audience_transaction_active ) {
            return false;
        }

        $wpdb->last_error = '';
        $rolled_back = $wpdb->query( 'ROLLBACK' );
        $succeeded = false !== $rolled_back && '' === $wpdb->last_error;

        if ( $succeeded ) {
            $this->audience_transaction_active = false;
        }

        return $succeeded;
    }

    /**
     * Require the authenticated application REST nonce for CSV exports.
     *
     * @param string $type Export type key.
     */

    private function verify_export_nonce( string $type ): void {
        $nonce = sanitize_text_field( wphave_request_string( $_GET, '_wpnonce' ) );

        if ( $nonce && (
            wp_verify_nonce( $nonce, 'wp_rest' ) ||
            wp_verify_nonce( $nonce, 'wphave_export_audience_' . sanitize_key( $type ) )
        ) ) {
            return;
        }

        wp_die( esc_html__( 'Invalid export link.', 'wphave' ) );
    }
}
