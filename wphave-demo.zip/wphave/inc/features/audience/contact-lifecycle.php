<?php

/**
 * Audience contact aggregate lifecycle.
 *
 * This module owns contact permissions, read/write endpoints, identity and
 * metadata graph synchronization, permanent deletion and merge semantics.
 * Shared lead deletion remains here because contact erasure and merge must
 * remove or reassign the complete owned graph atomically.
 *
 * @package wphave
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait WPHAVE_Audience_Contact_Lifecycle_Trait {

    /**
     * Applies method-specific least-privilege access to one contact resource.
     *
     * @param WP_REST_Request $request Current contact request.
     * @return bool Whether the current user may perform the HTTP method.
     */
    public function contact_route_permission( WP_REST_Request $request ): bool {
        if ( $request->get_method() === 'GET' ) {
            return $this->permission_check();
        }

        return $request->get_method() === 'DELETE'
            ? $this->delete_permission_check()
            : $this->manage_permission_check();
    }

    /**
     * Returns one filtered contact page enriched with primary-email avatars.
     *
     * @param WP_REST_Request $request Contact list request.
     * @return WP_REST_Response|WP_Error Paginated contact collection or access error.
     */
    public function contacts_endpoint( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        if ( ! $this->permission_check() ) {
            return $this->audience_access_error();
        }

        $result = $this->query_table(
            $this->contacts_table,
            $request,
            [ 'display_name', 'first_name', 'last_name', 'organization' ],
            'updated_at',
            [ 'display_name', 'status', 'created_at', 'updated_at' ],
            [ 'archived' ]
        );
        $result['summary'] = $this->get_grouped_counts(
            $this->contacts_table,
            'status'
        );

        return rest_ensure_response( $this->add_contact_avatars( $result ) );
    }

    /**
     * Normalize mutable contact profile fields within their schema capacities.
     *
     * @param array<string, mixed> $data Submitted profile values.
     * @param array<string, mixed> $fallback Existing values for omitted fields.
     * @return array<string, string>|WP_Error Canonical profile or validation error.
     */
    private function normalize_contact_profile( array $data, array $fallback = [] ) {
        $limits = [
            'first_name' => 100,
            'last_name' => 100,
            'organization' => 190,
            'job_title' => 190,
            'locale' => 20,
            'timezone' => 100,
        ];
        $profile = [];

        foreach ( $limits as $field => $limit ) {
            $raw_value = $data[ $field ] ?? $fallback[ $field ] ?? '';

            if ( ! is_scalar( $raw_value ) ) {
                return new WP_Error( 'wphave_audience_contact_field_invalid', __( 'Contact profile fields must be text values.', 'wphave' ), [ 'status' => 400, 'field' => $field ] );
            }

            $value = sanitize_text_field( (string) $raw_value );
            $length = function_exists( 'mb_strlen' ) ? mb_strlen( $value ) : strlen( $value );

            if ( $length > $limit ) {
                return new WP_Error( 'wphave_audience_contact_field_too_long', __( 'One or more contact profile fields exceed their supported length.', 'wphave' ), [ 'status' => 400, 'field' => $field, 'max_length' => $limit ] );
            }

            $profile[ $field ] = $value;
        }

        return $profile;
    }

    /**
     * Creates a contact and its optional primary email and phone identities.
     *
     * Manual contacts may be identity-less when a name or organization is known.
     * Supplied identities are normalized and checked against the global identity
     * uniqueness contract before the contact graph is written atomically.
     *
     * @param WP_REST_Request $request Contact profile and identity fields.
     * @return WP_REST_Response|WP_Error Created contact graph or validation error.
     */
    public function create_contact_endpoint( WP_REST_Request $request ) {
        global $wpdb;

        if ( ! $this->manage_permission_check() ) {
            return $this->audience_access_error();
        }

        $data = $request->get_json_params();
        $data = is_array( $data ) ? $data : [];
        $profile = $this->normalize_contact_profile( $data );

        if ( is_wp_error( $profile ) ) {
            return $profile;
        }

        $first_name = $profile['first_name'];
        $last_name = $profile['last_name'];
        $organization = $profile['organization'];
        $raw_email = $data['email'] ?? '';
        $email = $this->normalize_email( $raw_email );
        $raw_phone_input = $data['phone'] ?? '';

        if ( ! is_scalar( $raw_phone_input ) ) {
            return new WP_Error( 'wphave_audience_invalid_phone', __( 'Enter a phone number as a text value.', 'wphave' ), [ 'status' => 400 ] );
        }

        $raw_phone = trim( (string) $raw_phone_input );

        if ( $raw_phone && ! preg_match( '/^\+?[\d\s().\/-]+$/u', $raw_phone ) ) {
            return new WP_Error( 'wphave_audience_invalid_phone', __( 'Enter a phone number using digits and common formatting characters only.', 'wphave' ), [ 'status' => 400 ] );
        }

        $phone = str_starts_with( $raw_phone, '+' )
            ? '+' . preg_replace( '/\D/', '', substr( $raw_phone, 1 ) )
            : preg_replace( '/\D/', '', $raw_phone );
        $phone_digit_count = strlen( preg_replace( '/\D/', '', $phone ) );
        $status = $this->normalize_closed_key(
            $data['status'] ?? 'active',
            [ 'active', 'archived' ]
        );

        if ( ! is_scalar( $raw_email ) || ( '' !== trim( (string) $raw_email ) && ! is_email( $email ) ) ) {
            return new WP_Error( 'wphave_audience_invalid_email', __( 'Enter a valid email address.', 'wphave' ), [ 'status' => 400 ] );
        }

        if ( $raw_phone && ( $phone_digit_count < 5 || $phone_digit_count > 15 ) ) {
            return new WP_Error( 'wphave_audience_invalid_phone', __( 'Enter a phone number containing between 5 and 15 digits.', 'wphave' ), [ 'status' => 400 ] );
        }

        if ( ! $first_name && ! $last_name && ! $organization && ! $email && ! $phone ) {
            return new WP_Error( 'wphave_audience_contact_empty', __( 'Add a name, organization, email address or phone number.', 'wphave' ), [ 'status' => 400 ] );
        }

        if ( '' === $status ) {
            return new WP_Error( 'wphave_audience_contact_status_invalid', __( 'Select a valid contact status.', 'wphave' ), [ 'status' => 400 ] );
        }

        $identities = array_filter( [
            'email' => $email,
            'phone' => $phone,
        ] );

        foreach ( $identities as $type => $value ) {
            $hash = hash_hmac( 'sha256', $value, wp_salt( 'auth' ) );
            $existing_contact_id = absint(
                $wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT contact_id FROM {$this->identities_table} WHERE type = %s AND value_hash = %s LIMIT 1",
                        $type,
                        $hash
                    )
                )
            );

            if ( $existing_contact_id ) {
                return new WP_Error(
                    'wphave_audience_identity_exists',
                    __( 'A contact with this email address or phone number already exists.', 'wphave' ),
                    [ 'status' => 409, 'contact_id' => $existing_contact_id ]
                );
            }
        }

        $now = current_time( 'mysql' );
        $public_id = wp_generate_uuid4();
        $display_name = trim( $first_name . ' ' . $last_name ) ?: $organization;

        /*
         * DATA INTEGRITY INVARIANT: A manually created contact, all supplied
         * primary identities and its reliable domain event form one aggregate.
         * The REST boundary must not expose that aggregate before verified commit.
         */
        if ( ! $this->begin_audience_transaction() ) {
            return new WP_Error(
                'wphave_audience_contact_insert_failed',
                __( 'Contact could not be stored.', 'wphave' ),
                [ 'status' => 500 ]
            );
        }

        try {
            if ( ! $wpdb->insert( $this->contacts_table, [
                'public_id' => $public_id,
                'display_name' => $display_name,
                'first_name' => $first_name,
                'last_name' => $last_name,
                'organization' => $organization,
                'job_title' => $profile['job_title'],
                'locale' => $profile['locale'],
                'timezone' => $profile['timezone'],
                'status' => $status,
                'created_at' => $now,
                'updated_at' => $now,
            ] ) ) {
                throw new RuntimeException( 'Contact insertion failed.' );
            }

            $contact_id = absint( $wpdb->insert_id );

            foreach ( $identities as $type => $value ) {
                if ( ! $wpdb->insert( $this->identities_table, [
                    'contact_id' => $contact_id,
                    'type' => $type,
                    'provider' => 'manual',
                    'value' => $value,
                    'normalized_value' => $value,
                    'value_hash' => hash_hmac( 'sha256', $value, wp_salt( 'auth' ) ),
                    'verification_status' => 'unverified',
                    'is_primary' => 1,
                    'created_at' => $now,
                    'updated_at' => $now,
                ] ) ) {
                    throw new RuntimeException( 'Identity insertion failed.' );
                }
            }

            if ( ! $this->enqueue_domain_event( 'audience.contact.created.v1', 'contact', $public_id, [ 'contact_id' => $contact_id, 'source' => 'manual' ] ) ) {
                throw new RuntimeException( 'Contact creation event could not be queued.' );
            }

            if ( ! $this->commit_audience_transaction() ) {
                throw new RuntimeException( 'Contact creation transaction could not be committed.' );
            }
        } catch ( Throwable $error ) {
            $this->rollback_audience_transaction();

            return new WP_Error( 'wphave_audience_contact_insert_failed', __( 'Contact could not be stored.', 'wphave' ), [ 'status' => 500 ] );
        }

        $detail_request = new WP_REST_Request( 'GET' );
        $detail_request->set_param( 'id', $contact_id );

        return $this->contact_detail_endpoint( $detail_request );
    }

    /**
     * Adds primary-email avatars to a contact page with one identity query.
     *
     * The batched query is an explicit N+1 guard. Email is used only to derive
     * the avatar URL and is not added to the contact list response.
     *
     * @param array{items?: array<int, array>} $result Paginated contact result.
     * @return array Contact result with an avatar_url on every item.
     */
    private function add_contact_avatars( array $result ): array {
        global $wpdb;

        $contact_ids = array_values( array_filter( array_map( fn( $contact ) => absint( $contact['id'] ?? 0 ), $result['items'] ?? [] ) ) );

        if ( ! $contact_ids ) {
            return $result;
        }

        $placeholders = implode( ', ', array_fill( 0, count( $contact_ids ), '%d' ) );
        $identities = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT contact_id, value FROM {$this->identities_table} WHERE type = 'email' AND contact_id IN ({$placeholders}) ORDER BY is_primary DESC, id ASC",
                ...$contact_ids
            ),
            ARRAY_A
        ) ?: [];
        $emails = [];

        foreach ( $identities as $identity ) {
            $contact_id = absint( $identity['contact_id'] ?? 0 );

            if ( $contact_id && ! isset( $emails[ $contact_id ] ) ) {
                $emails[ $contact_id ] = sanitize_email( $identity['value'] ?? '' );
            }
        }

        $result['items'] = array_map(
            function( $contact ) use ( $emails ) {
                $email = $emails[ absint( $contact['id'] ?? 0 ) ] ?? '';
                $contact['avatar_url'] = $email ? wphave_get_avatar_url( $email, [ 'size' => 48 ] ) : '';

                return $contact;
            },
            $result['items']
        );

        return $result;
    }

    /**
     * Reads, updates, archives or permanently deletes one contact aggregate.
     *
     * GET returns the contact graph used by the drawer. POST updates mutable
     * profile fields and permits only active/archived state transitions. DELETE
     * delegates to the transactional graph deletion workflow.
     *
     * @param WP_REST_Request $request Contact request containing the numeric id.
     * @return WP_REST_Response|WP_Error Contact graph, success response or error.
     */
    public function contact_detail_endpoint( WP_REST_Request $request ) {
        global $wpdb;

        if ( ! $this->contact_route_permission( $request ) ) {
            return $this->audience_access_error();
        }

        $contact_id = absint( $request['id'] );

        if ( $request->get_method() === 'DELETE' ) {
            return $this->delete_contact( $contact_id );
        }

        if ( $request->get_method() === 'POST' ) {
            $data = $request->get_json_params();
            $data = is_array( $data ) ? $data : [];
            $current = $this->get_row( $this->contacts_table, $contact_id );

            if ( ! $current ) {
                return new WP_Error( 'wphave_audience_contact_missing', __( 'Contact was not found.', 'wphave' ), [ 'status' => 404 ] );
            }

            // DATA INTEGRITY INVARIANT: Merged contacts are immutable redirect
            // markers; mutable profile and metadata writes must never revive them.
            if ( 'merged' === $current['status'] ) {
                return new WP_Error( 'wphave_audience_contact_merged', __( 'Merged contact redirects cannot be changed.', 'wphave' ), [ 'status' => 409 ] );
            }

            $profile = $this->normalize_contact_profile( $data, $current );

            if ( is_wp_error( $profile ) ) {
                return $profile;
            }

            $first_name = $profile['first_name'];
            $last_name = $profile['last_name'];
            $organization = $profile['organization'];
            $status = $this->normalize_closed_key(
                $data['status'] ?? $current['status'],
                [ 'active', 'archived' ]
            );

            if ( '' === $status ) {
                return new WP_Error( 'wphave_audience_contact_status_invalid', __( 'Select a valid contact status.', 'wphave' ), [ 'status' => 400 ] );
            }

            /*
             * DATA INTEGRITY INVARIANT: Contact profile, tags, custom fields and
             * the reliable update event form one mutable aggregate revision.
             */
            if ( ! $this->begin_audience_transaction() ) {
                return new WP_Error(
                    'wphave_audience_contact_update_failed',
                    __( 'Contact could not be updated.', 'wphave' ),
                    [ 'status' => 500 ]
                );
            }

            try {
                $updated = $wpdb->update(
                    $this->contacts_table,
                    [
                        'first_name' => $first_name,
                        'last_name' => $last_name,
                        'display_name' => trim( $first_name . ' ' . $last_name ) ?: $organization,
                        'organization' => $organization,
                        'job_title' => $profile['job_title'],
                        'locale' => $profile['locale'],
                        'timezone' => $profile['timezone'],
                        'status' => $status,
                        'updated_at' => current_time( 'mysql' ),
                    ],
                    [ 'id' => $contact_id ]
                );

                $tags_synced = $this->sync_entity_tags( 'contact', $contact_id, $data['tag_ids'] ?? null );

                if ( is_wp_error( $tags_synced ) ) {
                    $this->rollback_audience_transaction();

                    return $tags_synced;
                }

                if ( false === $updated || ! $tags_synced ) {
                    throw new RuntimeException( 'Contact graph update failed.' );
                }

                $fields_synced = $this->sync_custom_field_values( 'contact', $contact_id, $data['custom_fields'] ?? null );

                if ( is_wp_error( $fields_synced ) ) {
                    $this->rollback_audience_transaction();

                    return $fields_synced;
                }

                if ( ! $fields_synced ) {
                    throw new RuntimeException( 'Contact graph update failed.' );
                }

                if ( ! $this->enqueue_domain_event( 'audience.contact.updated.v1', 'contact', $current['public_id'], [ 'contact_id' => $contact_id ] ) ) {
                    throw new RuntimeException( 'Contact update event could not be queued.' );
                }

                if ( ! $this->commit_audience_transaction() ) {
                    throw new RuntimeException( 'Contact update transaction could not be committed.' );
                }
            } catch ( Throwable $error ) {
                $this->rollback_audience_transaction();

                return new WP_Error( 'wphave_audience_contact_update_failed', __( 'Contact could not be updated.', 'wphave' ), [ 'status' => 500 ] );
            }
        }

        $contact = $this->get_row( $this->contacts_table, $contact_id );

        if ( ! $contact ) {
            return new WP_Error( 'wphave_audience_contact_missing', __( 'Contact was not found.', 'wphave' ), [ 'status' => 404 ] );
        }

        $identities = $wpdb->get_results(
            $wpdb->prepare( "SELECT id, type, provider, value, verification_status, verified_at, is_primary FROM {$this->identities_table} WHERE contact_id = %d ORDER BY is_primary DESC, id ASC", $contact_id ),
            ARRAY_A
        ) ?: [];
        $primary_email = '';

        foreach ( $identities as $identity ) {
            if ( ( $identity['type'] ?? '' ) === 'email' ) {
                $primary_email = sanitize_email( $identity['value'] ?? '' );
                break;
            }
        }

        $contact['avatar_url'] = $primary_email ? wphave_get_avatar_url( $primary_email, [ 'size' => 48 ] ) : '';
        $interactions = $wpdb->get_results(
            $wpdb->prepare( "SELECT * FROM {$this->interactions_table} WHERE contact_id = %d ORDER BY occurred_at DESC LIMIT 100", $contact_id ),
            ARRAY_A
        ) ?: [];
        $leads = $wpdb->get_results(
            $wpdb->prepare( "SELECT * FROM {$this->leads_table} WHERE contact_id = %d ORDER BY created_at DESC", $contact_id ),
            ARRAY_A
        ) ?: [];
        $activities = $wpdb->get_results(
            $wpdb->prepare( "SELECT * FROM {$this->activities_table} WHERE contact_id = %d ORDER BY occurred_at DESC LIMIT 100", $contact_id ),
            ARRAY_A
        ) ?: [];
        $tags = $wpdb->get_results(
            $wpdb->prepare( "SELECT t.* FROM {$this->tags_table} t INNER JOIN {$this->entity_tags_table} et ON et.tag_id = t.id WHERE et.entity_type = 'contact' AND et.entity_id = %d ORDER BY t.label ASC", $contact_id ),
            ARRAY_A
        ) ?: [];
        $custom_fields = $wpdb->get_results(
            $wpdb->prepare( "SELECT d.field_key, d.label, d.field_type, d.privacy_class, v.value FROM {$this->field_values_table} v INNER JOIN {$this->field_definitions_table} d ON d.id = v.definition_id WHERE v.entity_type = 'contact' AND v.entity_id = %d ORDER BY d.label ASC", $contact_id ),
            ARRAY_A
        ) ?: [];

        return rest_ensure_response( [
            'item' => $contact,
            'identities' => array_map( [ $this, 'format_row' ], $identities ),
            'interactions' => array_map( [ $this, 'format_row' ], $interactions ),
            'leads' => array_values( array_filter( array_map( fn( $lead ) => $this->decorate_lead( $this->format_row( $lead ) ), $leads ) ) ),
            'activities' => array_map( [ $this, 'format_row' ], $activities ),
            'tags' => $tags,
            'custom_fields' => $custom_fields,
        ] );
    }

    /**
     * Permanently deletes a complete Audience contact graph atomically.
     *
     * Lead-scoped taxonomy values are removed before leads; contact activities,
     * consent facts, subscriptions, interactions and identities follow before
     * the contact root. Merged redirect contacts fail closed because deleting
     * them would break merge history. Pseudonymous Analytics events remain but
     * lose their Audience identity link when interactions are removed.
     *
     * @param int $contact_id Contact database id.
     * @return WP_REST_Response|WP_Error Success or a fail-closed domain error.
     */
    private function delete_contact( int $contact_id ) {
        global $wpdb;

        $contact = $this->get_row( $this->contacts_table, $contact_id );

        if ( ! $contact ) {
            return new WP_Error( 'wphave_audience_contact_missing', __( 'Contact was not found.', 'wphave' ), [ 'status' => 404 ] );
        }

        if ( $contact['status'] === 'merged' ) {
            return new WP_Error( 'wphave_audience_contact_merged', __( 'Merged contact redirects must be retained with their target contact.', 'wphave' ), [ 'status' => 409 ] );
        }

        /*
         * PRIVACY INVARIANT: Every contact-owned mutable projection and the
         * contact root form one erasure graph. The deletion event may be queued
         * only when this workflow deletes exactly one root and commits the graph.
         */
        if ( ! $this->begin_audience_transaction() ) {
            return new WP_Error(
                'wphave_audience_contact_delete_failed',
                __( 'Contact could not be deleted.', 'wphave' ),
                [ 'status' => 500 ]
            );
        }

        try {
            $this->delete_contact_graph_rows( $contact );

            if ( ! $this->commit_audience_transaction() ) {
                throw new RuntimeException( 'Contact deletion transaction could not be committed.' );
            }
        } catch ( Throwable $error ) {
            $this->rollback_audience_transaction();

            return new WP_Error( 'wphave_audience_contact_delete_failed', __( 'Contact could not be deleted.', 'wphave' ), [ 'status' => 500 ] );
        }

        return rest_ensure_response( [ 'success' => true ] );
    }

    /**
     * Permanently deletes one operational lead and all lead-owned extensions.
     *
     * The contact and origin interaction remain because they may be shared by
     * other work items. Lead activities, tags and custom values are removed in
     * the same transaction so no polymorphic orphan rows remain.
     *
     * @param int $lead_id Lead database id.
     * @return bool|WP_Error True after deletion or a fail-closed domain error.
     */
    private function delete_operational_lead( int $lead_id ) {
        return $this->delete_operational_lead_with_guard( $lead_id );
    }

    /**
     * Deletes one expired terminal lead through the canonical graph boundary.
     *
     * @param int $lead_id Lead database id.
     * @param string $threshold MySQL date-time expiry threshold.
     * @return bool|WP_Error True after deletion or a fail-closed domain error.
     */
    private function delete_expired_operational_lead( int $lead_id, string $threshold ) {
        if ( '' === $threshold ) {
            return new WP_Error( 'wphave_audience_lead_delete_failed', __( 'Lead could not be deleted.', 'wphave' ), [ 'status' => 500 ] );
        }

        return $this->delete_operational_lead_with_guard( $lead_id, $threshold );
    }

    /**
     * Executes the shared lead graph deletion with an optional retention guard.
     *
     * @param int $lead_id Lead database id.
     * @param string|null $retention_threshold Optional terminal-lead expiry threshold.
     * @return bool|WP_Error True after deletion or a fail-closed domain error.
     */
    private function delete_operational_lead_with_guard( int $lead_id, ?string $retention_threshold = null ) {
        global $wpdb;

        if ( ! $lead_id || ! $this->get_row( $this->leads_table, $lead_id ) ) {
            return new WP_Error( 'wphave_audience_lead_missing', __( 'Lead was not found.', 'wphave' ), [ 'status' => 404 ] );
        }

        /*
         * DATA INTEGRITY INVARIANT: Lead activities and polymorphic extensions
         * are owned by exactly one operational lead. Success requires their
         * removal and exactly one deleted lead root in one verified commit.
         */
        if ( ! $this->begin_audience_transaction() ) {
            return new WP_Error(
                'wphave_audience_lead_delete_failed',
                __( 'Lead could not be deleted.', 'wphave' ),
                [ 'status' => 500 ]
            );
        }

        try {
            $this->delete_lead_graph_rows( $lead_id, $retention_threshold );

            if ( ! $this->commit_audience_transaction() ) {
                throw new RuntimeException( 'Lead deletion transaction could not be committed.' );
            }
        } catch ( Throwable $error ) {
            $this->rollback_audience_transaction();

            return new WP_Error( 'wphave_audience_lead_delete_failed', __( 'Lead could not be deleted.', 'wphave' ), [ 'status' => 500 ] );
        }

        return true;
    }

    /**
     * Deletes one lead-owned graph inside the caller's active transaction.
     *
     * @param int $lead_id Existing operational lead id.
     * @param string|null $retention_threshold Optional terminal-lead expiry threshold.
     * @return void
     * @throws RuntimeException When any graph row cannot be deleted exactly.
     */
    private function delete_lead_graph_rows( int $lead_id, ?string $retention_threshold = null ): void {
        global $wpdb;

        /*
         * DATA INTEGRITY INVARIANT: A subscription is an independent aggregate.
         * Lead deletion preserves it but must clear its optional attribution
         * reference before the lead root disappears.
         */
        if ( false === $wpdb->update( $this->subscribers_table, [ 'lead_id' => 0 ], [ 'lead_id' => $lead_id ], [ '%d' ], [ '%d' ] ) ) {
            throw new RuntimeException( 'Subscriber lead reference cleanup failed.' );
        }

        foreach ( [
            [ $this->activities_table, [ 'lead_id' => $lead_id ], [ '%d' ] ],
            [ $this->entity_tags_table, [ 'entity_type' => 'lead', 'entity_id' => $lead_id ], [ '%s', '%d' ] ],
            [ $this->field_values_table, [ 'entity_type' => 'lead', 'entity_id' => $lead_id ], [ '%s', '%d' ] ],
        ] as [ $table, $where, $formats ] ) {
            if ( false === $wpdb->delete( $table, $where, $formats ) ) {
                throw new RuntimeException( 'Lead graph deletion failed.' );
            }
        }

        /*
         * CONCURRENCY INVARIANT: Retention repeats terminal status and age at the
         * root delete. Reopened or refreshed leads cause a zero-row delete and
         * roll back every preceding extension and attribution mutation.
         */
        $lead_deleted = null === $retention_threshold
            ? $wpdb->delete( $this->leads_table, [ 'id' => $lead_id ], [ '%d' ] )
            : $wpdb->query(
                $wpdb->prepare(
                    "DELETE FROM {$this->leads_table} WHERE id = %d AND created_at < %s AND status IN ('lost', 'archived')",
                    $lead_id,
                    $retention_threshold
                )
            );

        if ( 1 !== $lead_deleted ) {
            throw new RuntimeException( 'Lead root deletion failed.' );
        }
    }

    /**
     * Deletes timeline references owned by one interaction in the caller's transaction.
     *
     * DATA INTEGRITY INVARIANT: Activities may reference an interaction without
     * referencing its operational lead. An interaction root must therefore
     * never be removed before every such timeline reference is removed.
     *
     * @param int $interaction_id Existing immutable interaction id.
     * @return void
     * @throws RuntimeException When the timeline references cannot be deleted.
     */
    private function delete_interaction_activity_rows( int $interaction_id ): void {
        global $wpdb;

        if ( false === $wpdb->delete( $this->activities_table, [ 'interaction_id' => $interaction_id ], [ '%d' ] ) ) {
            throw new RuntimeException( 'Interaction timeline deletion failed.' );
        }
    }

    /**
     * Deletes one subscriber-owned graph inside the caller's active transaction.
     *
     * PRIVACY INVARIANT: Consent rows linked to a subscriber remain part of its
     * erasure graph even when their denormalized contact_id is zero.
     *
     * @param int $subscriber_id Existing subscriber id.
     * @return void
     * @throws RuntimeException When evidence or the subscriber cannot be deleted.
     */
    private function delete_subscriber_graph_rows( int $subscriber_id ): void {
        global $wpdb;

        foreach ( [ $this->consent_events_table, $this->consent_evidence_table ] as $table ) {
            if ( false === $wpdb->delete( $table, [ 'subscriber_id' => $subscriber_id ], [ '%d' ] ) ) {
                throw new RuntimeException( 'Subscriber evidence deletion failed.' );
            }
        }

        if ( 1 !== $wpdb->delete( $this->subscribers_table, [ 'id' => $subscriber_id ], [ '%d' ] ) ) {
            throw new RuntimeException( 'Subscriber root deletion failed.' );
        }
    }

    /**
     * Deletes one complete contact graph inside the caller's active transaction.
     *
     * PRIVACY INVARIANT: Every owned row and the reliable deletion intent are
     * part of the same outer commit. This primitive never manages transactions.
     *
     * @param array $contact Existing contact row.
     * @return void
     * @throws RuntimeException When graph deletion or event persistence fails.
     */
    private function delete_contact_graph_rows( array $contact ): void {
        global $wpdb;

        $contact_id = absint( $contact['id'] ?? 0 );
        $wpdb->last_error = '';
        $lead_ids = array_map(
            'absint',
            $wpdb->get_col(
                $wpdb->prepare(
                    "SELECT id FROM {$this->leads_table} WHERE contact_id = %d",
                    $contact_id
                )
            ) ?: []
        );

        if ( $wpdb->last_error ) {
            throw new RuntimeException( 'Contact lead graph could not be read.' );
        }

        $wpdb->last_error = '';
        $interaction_ids = array_map(
            'absint',
            $wpdb->get_col(
                $wpdb->prepare(
                    "SELECT id FROM {$this->interactions_table} WHERE contact_id = %d",
                    $contact_id
                )
            ) ?: []
        );

        if ( $wpdb->last_error ) {
            throw new RuntimeException( 'Contact interaction graph could not be read.' );
        }

        $wpdb->last_error = '';
        $subscriber_ids = array_map(
            'absint',
            $wpdb->get_col(
                $wpdb->prepare(
                    "SELECT id FROM {$this->subscribers_table} WHERE contact_id = %d",
                    $contact_id
                )
            ) ?: []
        );

        if ( $wpdb->last_error ) {
            throw new RuntimeException( 'Contact subscriber graph could not be read.' );
        }

        /*
         * DATA INTEGRITY INVARIANT: Lead ownership is established by the lead
         * root, not by denormalized contact ids on dependent rows. Reusing the
         * complete lead primitive also removes activities whose contact_id is 0.
         */
        foreach ( $lead_ids as $lead_id ) {
            $this->delete_lead_graph_rows( $lead_id );
        }

        /*
         * DATA INTEGRITY INVARIANT: Interaction ownership follows the
         * interaction root even when a timeline row carries contact_id 0.
         */
        foreach ( $interaction_ids as $interaction_id ) {
            $this->delete_interaction_activity_rows( $interaction_id );
        }

        foreach ( $subscriber_ids as $subscriber_id ) {
            $this->delete_subscriber_graph_rows( $subscriber_id );
        }

        foreach ( [
            [ $this->activities_table, [ 'contact_id' => $contact_id ], [ '%d' ] ],
            [ $this->consent_events_table, [ 'contact_id' => $contact_id ], [ '%d' ] ],
            [ $this->consent_evidence_table, [ 'contact_id' => $contact_id ], [ '%d' ] ],
            [ $this->entity_tags_table, [ 'entity_type' => 'contact', 'entity_id' => $contact_id ], [ '%s', '%d' ] ],
            [ $this->field_values_table, [ 'entity_type' => 'contact', 'entity_id' => $contact_id ], [ '%s', '%d' ] ],
            [ $this->interactions_table, [ 'contact_id' => $contact_id ], [ '%d' ] ],
            [ $this->identities_table, [ 'contact_id' => $contact_id ], [ '%d' ] ],
        ] as [ $table, $where, $formats ] ) {
            if ( false === $wpdb->delete( $table, $where, $formats ) ) {
                throw new RuntimeException( 'Contact graph deletion failed.' );
            }
        }

        /*
         * DATA INTEGRITY INVARIANT: Merge redirects are minimized dependents of
         * their active target. The flat redirect contract lets target erasure
         * remove every marker without leaving a chain to a missing root.
         */
        if ( false === $wpdb->delete(
            $this->contacts_table,
            [
                'status' => 'merged',
                'merged_into_contact_id' => $contact_id,
            ],
            [ '%s', '%d' ]
        ) ) {
            throw new RuntimeException( 'Merged contact redirect deletion failed.' );
        }

        if ( 1 !== $wpdb->delete( $this->contacts_table, [ 'id' => $contact_id ], [ '%d' ] ) ) {
            throw new RuntimeException( 'Contact deletion failed.' );
        }

        if ( ! $this->enqueue_domain_event( 'audience.contact.deleted.v1', 'contact', $contact['public_id'], [ 'contact_id' => $contact_id ] ) ) {
            throw new RuntimeException( 'Contact deletion event could not be queued.' );
        }
    }

    /**
     * Merges a source contact graph into a different active target contact.
     *
     * Duplicate identities are removed by type and value hash before remaining
     * graph references move. The source row is retained as a minimized redirect
     * marker and must not be hard-deleted independently.
     *
     * @param WP_REST_Request $request Source id and target_contact_id.
     * @return WP_REST_Response|WP_Error Merged target graph or validation error.
     */
    public function merge_contact_endpoint( WP_REST_Request $request ) {
        global $wpdb;

        if ( ! $this->manage_permission_check() ) {
            return $this->audience_access_error();
        }

        $source_id = $this->normalize_non_negative_integer( $request['id'] );
        $target_id = $this->normalize_non_negative_integer( $request->get_param( 'target_contact_id' ) );

        if ( null === $source_id || null === $target_id || 0 === $source_id || 0 === $target_id || $source_id === $target_id ) {
            return new WP_Error( 'wphave_audience_merge_invalid', __( 'Choose two different contacts to merge.', 'wphave' ), [ 'status' => 400 ] );
        }

        $source = $this->get_row( $this->contacts_table, $source_id );
        $target = $this->get_row( $this->contacts_table, $target_id );

        if ( ! $source || ! $target || 'active' !== $source['status'] || 'active' !== $target['status'] ) {
            return new WP_Error( 'wphave_audience_merge_missing', __( 'Both active contacts are required for a merge.', 'wphave' ), [ 'status' => 404 ] );
        }

        /*
         * DATA INTEGRITY INVARIANT: Every source-owned reference, identity and
         * extension moves with the merge activity and reliable domain event. The
         * minimized source redirect becomes visible only after verified commit.
         */
        if ( ! $this->begin_audience_transaction() ) {
            return new WP_Error(
                'wphave_audience_merge_failed',
                __( 'Contacts could not be merged.', 'wphave' ),
                [ 'status' => 500 ]
            );
        }

        try {
            $duplicates = $wpdb->get_col(
                $wpdb->prepare(
                    "SELECT source.id FROM {$this->identities_table} source INNER JOIN {$this->identities_table} target ON target.type = source.type AND target.value_hash = source.value_hash WHERE source.contact_id = %d AND target.contact_id = %d",
                    $source_id,
                    $target_id
                )
            ) ?: [];

            foreach ( $duplicates as $identity_id ) {
                if ( false === $wpdb->delete( $this->identities_table, [ 'id' => absint( $identity_id ) ], [ '%d' ] ) ) {
                    throw new RuntimeException( 'Duplicate identity deletion failed.' );
                }
            }

            if ( false === $wpdb->update( $this->identities_table, [ 'contact_id' => $target_id ], [ 'contact_id' => $source_id ] ) ) {
                throw new RuntimeException( 'Identity merge failed.' );
            }

            foreach ( [ $this->leads_table, $this->subscribers_table, $this->interactions_table, $this->activities_table, $this->consent_events_table, $this->consent_evidence_table ] as $table ) {
                if ( false === $wpdb->update( $table, [ 'contact_id' => $target_id ], [ 'contact_id' => $source_id ] ) ) {
                    throw new RuntimeException( 'Contact reference merge failed.' );
                }
            }

            if ( false === $wpdb->query(
                $wpdb->prepare(
                    "INSERT IGNORE INTO {$this->entity_tags_table} (tag_id, entity_type, entity_id, created_at) SELECT tag_id, 'contact', %d, created_at FROM {$this->entity_tags_table} WHERE entity_type = 'contact' AND entity_id = %d",
                    $target_id,
                    $source_id
                )
            ) ) {
                throw new RuntimeException( 'Contact tag merge failed.' );
            }

            if ( false === $wpdb->delete( $this->entity_tags_table, [ 'entity_type' => 'contact', 'entity_id' => $source_id ], [ '%s', '%d' ] ) ) {
                throw new RuntimeException( 'Source contact tag cleanup failed.' );
            }

            if ( false === $wpdb->query(
                $wpdb->prepare(
                    "INSERT IGNORE INTO {$this->field_values_table} (definition_id, entity_type, entity_id, value, created_at, updated_at) SELECT definition_id, 'contact', %d, value, created_at, updated_at FROM {$this->field_values_table} WHERE entity_type = 'contact' AND entity_id = %d",
                    $target_id,
                    $source_id
                )
            ) ) {
                throw new RuntimeException( 'Contact custom field merge failed.' );
            }

            if ( false === $wpdb->delete( $this->field_values_table, [ 'entity_type' => 'contact', 'entity_id' => $source_id ], [ '%s', '%d' ] ) ) {
                throw new RuntimeException( 'Source contact custom field cleanup failed.' );
            }

            if ( false === $wpdb->query(
                $wpdb->prepare(
                    "UPDATE {$this->identities_table} identities INNER JOIN (SELECT type, MIN(id) primary_id FROM {$this->identities_table} WHERE contact_id = %d GROUP BY type) selected ON selected.type = identities.type SET identities.is_primary = IF(identities.id = selected.primary_id, 1, 0) WHERE identities.contact_id = %d",
                    $target_id,
                    $target_id
                )
            ) ) {
                throw new RuntimeException( 'Primary identity normalization failed.' );
            }

            /*
             * DATA INTEGRITY INVARIANT: Redirects remain one hop deep. When an
             * active target becomes a merge source, all of its existing markers
             * move to the new active target in the same transaction.
             */
            if ( false === $wpdb->update(
                $this->contacts_table,
                [ 'merged_into_contact_id' => $target_id ],
                [
                    'status' => 'merged',
                    'merged_into_contact_id' => $source_id,
                ],
                [ '%d' ],
                [ '%s', '%d' ]
            ) ) {
                throw new RuntimeException( 'Merged contact redirect normalization failed.' );
            }

            if ( 1 !== $wpdb->update(
                $this->contacts_table,
                [
                    'status' => 'merged',
                    'merged_into_contact_id' => $target_id,
                    'display_name' => '',
                    'first_name' => '',
                    'last_name' => '',
                    'organization' => '',
                    'job_title' => '',
                    'locale' => '',
                    'timezone' => '',
                    'updated_at' => current_time( 'mysql' ),
                ],
                [ 'id' => $source_id ]
            ) ) {
                throw new RuntimeException( 'Source contact minimization failed.' );
            }
            if ( ! $this->record_activity( $target_id, 0, 0, 'contact_merged', [ 'source_contact_id' => $source_id ] ) ) {
                throw new RuntimeException( 'Contact merge activity could not be stored.' );
            }
            if ( ! $this->enqueue_domain_event( 'audience.contact.merged.v1', 'contact', $target['public_id'], [ 'source_contact_id' => $source_id, 'target_contact_id' => $target_id ] ) ) {
                throw new RuntimeException( 'Contact merge event could not be queued.' );
            }

            if ( ! $this->commit_audience_transaction() ) {
                throw new RuntimeException( 'Contact merge transaction could not be committed.' );
            }
        } catch ( Throwable $error ) {
            $this->rollback_audience_transaction();

            return new WP_Error( 'wphave_audience_merge_failed', __( 'Contacts could not be merged.', 'wphave' ), [ 'status' => 500 ] );
        }

        return rest_ensure_response( [ 'success' => true, 'item' => $this->get_row( $this->contacts_table, $target_id ) ] );
    }

}
