<?php

/**
 * Audience registries and extensible metadata contracts.
 *
 * This module owns reusable tags, typed custom fields, pipeline definitions
 * and consent-purpose read models. Domain workflows consume these registries
 * without owning their validation or persistence rules.
 *
 * @package wphave
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait WPHAVE_Audience_Registries_Trait {

    /**
     * Replaces the complete tag assignment for one supported entity.
     *
     * A null input means "not supplied" and leaves assignments unchanged. Every
     * supplied value must be an array; an empty array explicitly removes every
     * assignment.
     *
     * @param string $entity_type Canonical entity scope such as contact or lead.
     * @param int    $entity_id Entity database id.
     * @param mixed  $tag_ids Submitted tag ids.
     * @return bool|WP_Error Whether the assignment was synchronized successfully.
     */
    private function sync_entity_tags( string $entity_type, int $entity_id, $tag_ids ) {
        global $wpdb;

        if ( null === $tag_ids ) {
            return true;
        }

        if ( ! is_array( $tag_ids ) ) {
            return new WP_Error( 'wphave_audience_tags_invalid', __( 'Tag assignments must be provided as an array.', 'wphave' ), [ 'status' => 400 ] );
        }

        if ( count( $tag_ids ) > 100 ) {
            return new WP_Error( 'wphave_audience_tags_limit_exceeded', __( 'A resource may receive at most 100 tag assignments per update.', 'wphave' ), [ 'status' => 400 ] );
        }

        $normalized_tag_ids = [];

        foreach ( $tag_ids as $tag_id ) {
            $is_integer_string = is_string( $tag_id ) && ctype_digit( $tag_id );

            if ( ( ! is_int( $tag_id ) && ! $is_integer_string ) || (int) $tag_id < 1 ) {
                return new WP_Error( 'wphave_audience_tags_invalid', __( 'Tag assignments must contain positive integer ids.', 'wphave' ), [ 'status' => 400 ] );
            }

            $normalized_tag_ids[] = (int) $tag_id;
        }

        $tag_ids = array_values( array_unique( $normalized_tag_ids ) );

        if ( $tag_ids ) {
            $placeholders = implode( ', ', array_fill( 0, count( $tag_ids ), '%d' ) );
            $known_tag_count = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$this->tags_table} WHERE id IN ({$placeholders})",
                    ...$tag_ids
                )
            );

            if ( $wpdb->last_error ) {
                return false;
            }

            if ( count( $tag_ids ) !== $known_tag_count ) {
                return new WP_Error( 'wphave_audience_tag_unknown', __( 'One or more tags are unavailable.', 'wphave' ), [ 'status' => 400 ] );
            }
        }

        if ( false === $wpdb->delete( $this->entity_tags_table, [ 'entity_type' => $entity_type, 'entity_id' => $entity_id ], [ '%s', '%d' ] ) ) {
            return false;
        }

        foreach ( $tag_ids as $tag_id ) {
            if ( ! $wpdb->insert( $this->entity_tags_table, [ 'tag_id' => $tag_id, 'entity_type' => $entity_type, 'entity_id' => $entity_id, 'created_at' => current_time( 'mysql' ) ] ) ) {
                return false;
            }
        }

        return true;
    }

    /**
     * Upserts validated custom-field values for one entity.
     *
     * Definitions are resolved in one query before any value is changed. Unknown,
     * inactive, cross-scope or colliding keys fail the owning update so clients
     * cannot mistake silently dropped metadata for a successful save. Empty
     * scalar values remove an existing value explicitly.
     *
     * @param string $entity_type Definition scope.
     * @param int    $entity_id Entity database id.
     * @param mixed  $values Field-key/value map, or null when omitted.
     * @return bool|WP_Error Whether every supplied value was synchronized successfully.
     */
    private function sync_custom_field_values( string $entity_type, int $entity_id, $values ) {
        global $wpdb;

        if ( null === $values ) {
            return true;
        }

        if ( ! is_array( $values ) ) {
            return new WP_Error( 'wphave_audience_fields_invalid', __( 'Custom fields must be provided as a key-value map.', 'wphave' ), [ 'status' => 400 ] );
        }

        if ( count( $values ) > 100 ) {
            return new WP_Error( 'wphave_audience_fields_limit_exceeded', __( 'A resource may receive at most 100 custom fields per update.', 'wphave' ), [ 'status' => 400 ] );
        }

        if ( ! $values ) {
            return true;
        }

        $normalized_values = [];

        foreach ( $values as $field_key => $value ) {
            $normalized_key = is_string( $field_key )
                ? $this->normalize_purpose_key( $field_key )
                : '';

            if ( ! $normalized_key || array_key_exists( $normalized_key, $normalized_values ) ) {
                return new WP_Error( 'wphave_audience_field_key_invalid', __( 'Custom field keys must be valid and unique.', 'wphave' ), [ 'status' => 400 ] );
            }

            $normalized_values[ $normalized_key ] = $value;
        }

        $field_keys = array_keys( $normalized_values );
        $placeholders = implode( ', ', array_fill( 0, count( $field_keys ), '%s' ) );
        $definitions = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, field_key, field_type, validation FROM {$this->field_definitions_table} WHERE scope = %s AND field_key IN ({$placeholders}) AND is_active = 1",
                $entity_type,
                ...$field_keys
            ),
            ARRAY_A
        );

        if ( null === $definitions ) {
            return false;
        }

        $definitions_by_key = array_column( $definitions, null, 'field_key' );

        if ( count( $definitions_by_key ) !== count( $field_keys ) ) {
            return new WP_Error( 'wphave_audience_field_unknown', __( 'One or more custom fields are unavailable for this resource.', 'wphave' ), [ 'status' => 400 ] );
        }

        foreach ( $normalized_values as $field_key => $value ) {
            $definition = $definitions_by_key[ $field_key ];

            if ( is_string( $value ) && '' === trim( $value ) ) {
                if ( false === $wpdb->delete( $this->field_values_table, [ 'definition_id' => absint( $definition['id'] ), 'entity_type' => $entity_type, 'entity_id' => $entity_id ], [ '%d', '%s', '%d' ] ) ) {
                    return false;
                }

                continue;
            }

            $sanitized = $this->normalize_custom_field_value( $definition, $value );

            if ( is_wp_error( $sanitized ) ) {
                return $sanitized;
            }

            $now = current_time( 'mysql' );
            $saved = $wpdb->query(
                $wpdb->prepare(
                    "INSERT INTO {$this->field_values_table} (definition_id, entity_type, entity_id, value, created_at, updated_at) VALUES (%d, %s, %d, %s, %s, %s) ON DUPLICATE KEY UPDATE value = VALUES(value), updated_at = VALUES(updated_at)",
                    absint( $definition['id'] ),
                    $entity_type,
                    $entity_id,
                    $sanitized,
                    $now,
                    $now
                )
            );

            if ( false === $saved ) {
                return false;
            }
        }

        return true;
    }

    /**
     * Normalize one custom-field value according to its stored definition.
     *
     * @param array<string, mixed> $definition Field type and validation contract.
     * @param mixed                $value Submitted value.
     * @return string|WP_Error Canonical storage value or validation error.
     */
    private function normalize_custom_field_value( array $definition, $value ) {
        if ( ! is_scalar( $value ) ) {
            return new WP_Error( 'wphave_audience_field_value_invalid', __( 'Custom field values must be scalar.', 'wphave' ), [ 'status' => 400 ] );
        }

        // DATA INTEGRITY INVARIANT: Stored field contracts are revalidated
        // losslessly before interpreting values; corrupted types never self-repair.
        $type = $this->normalize_closed_key(
            $definition['field_type'] ?? '',
            [ 'text', 'textarea', 'number', 'date', 'boolean', 'select', 'url', 'email' ]
        );

        if ( '' === $type ) {
            return new WP_Error( 'wphave_audience_field_type_invalid', __( 'The stored custom field type is invalid.', 'wphave' ), [ 'status' => 500 ] );
        }

        if ( 'boolean' === $type && is_bool( $value ) ) {
            return $value ? '1' : '0';
        }

        $raw = trim( (string) $value );

        if ( in_array( $type, [ 'text', 'textarea' ], true ) ) {
            return sanitize_textarea_field( $raw );
        }

        if ( 'select' === $type ) {
            $validation = json_decode( (string) ( $definition['validation'] ?? '' ), true );
            $options = is_array( $validation['options'] ?? null )
                ? array_map( 'strval', $validation['options'] )
                : [];

            if ( ! $options || ! in_array( $raw, $options, true ) ) {
                return new WP_Error( 'wphave_audience_field_value_invalid', __( 'Choose a valid custom field option.', 'wphave' ), [ 'status' => 400 ] );
            }

            return $raw;
        }

        if ( 'number' === $type ) {
            return is_numeric( $raw ) && is_finite( (float) $raw )
                ? $raw
                : new WP_Error( 'wphave_audience_field_value_invalid', __( 'Enter a valid number.', 'wphave' ), [ 'status' => 400 ] );
        }

        if ( 'date' === $type ) {
            $date = DateTimeImmutable::createFromFormat( '!Y-m-d', $raw );

            return $date && $date->format( 'Y-m-d' ) === $raw
                ? $raw
                : new WP_Error( 'wphave_audience_field_value_invalid', __( 'Enter a valid date.', 'wphave' ), [ 'status' => 400 ] );
        }

        if ( 'boolean' === $type ) {
            $normalized = strtolower( $raw );

            if ( in_array( $normalized, [ '1', 'true', 'yes', 'on' ], true ) ) {
                return '1';
            }

            if ( in_array( $normalized, [ '0', 'false', 'no', 'off' ], true ) ) {
                return '0';
            }

            return new WP_Error( 'wphave_audience_field_value_invalid', __( 'Enter a valid boolean value.', 'wphave' ), [ 'status' => 400 ] );
        }

        if ( 'email' === $type ) {
            $email = $this->normalize_email( $raw );

            return is_email( $email )
                ? $email
                : new WP_Error( 'wphave_audience_field_value_invalid', __( 'Enter a valid email address.', 'wphave' ), [ 'status' => 400 ] );
        }

        if ( 'url' === $type ) {
            $url = esc_url_raw( $raw, [ 'http', 'https' ] );

            return $url && filter_var( $url, FILTER_VALIDATE_URL )
                ? $url
                : new WP_Error( 'wphave_audience_field_value_invalid', __( 'Enter a valid HTTP or HTTPS URL.', 'wphave' ), [ 'status' => 400 ] );
        }

        return new WP_Error( 'wphave_audience_field_type_invalid', __( 'The custom field type is not supported.', 'wphave' ), [ 'status' => 400 ] );
    }

    /**
     * Normalize the supported validation contract for a custom-field definition.
     *
     * Select fields require a bounded list of unique scalar options. Other field
     * types currently expose no configurable validation attributes, so accepting
     * arbitrary keys would imply behavior that the value normalizer cannot honor.
     *
     * @param string $type Field type.
     * @param mixed  $validation Submitted validation settings.
     * @return array<string, mixed>|WP_Error Canonical validation settings.
     */
    private function normalize_custom_field_validation( string $type, $validation ) {
        if ( null === $validation || '' === $validation ) {
            $validation = [];
        }

        if ( ! is_array( $validation ) ) {
            return new WP_Error( 'wphave_audience_field_validation_invalid', __( 'Custom field validation must be an object.', 'wphave' ), [ 'status' => 400 ] );
        }

        if ( 'select' !== $type ) {
            return $validation
                ? new WP_Error( 'wphave_audience_field_validation_invalid', __( 'This custom field type does not support validation settings.', 'wphave' ), [ 'status' => 400 ] )
                : [];
        }

        if ( array_diff( array_keys( $validation ), [ 'options' ] ) || ! is_array( $validation['options'] ?? null ) || ! $validation['options'] || count( $validation['options'] ) > 100 ) {
            return new WP_Error( 'wphave_audience_field_validation_invalid', __( 'Select fields require between 1 and 100 options.', 'wphave' ), [ 'status' => 400 ] );
        }

        $options = [];

        foreach ( $validation['options'] as $option ) {
            if ( ! is_scalar( $option ) ) {
                return new WP_Error( 'wphave_audience_field_validation_invalid', __( 'Select options must be scalar values.', 'wphave' ), [ 'status' => 400 ] );
            }

            $submitted_option = (string) $option;
            $raw_option = trim( $submitted_option );
            $normalized_option = sanitize_text_field( $raw_option );
            $option_length = function_exists( 'mb_strlen' ) ? mb_strlen( $normalized_option ) : strlen( $normalized_option );

            if (
                '' === $normalized_option
                || $submitted_option !== $raw_option
                || $raw_option !== $normalized_option
                || $option_length > 190
                || in_array( $normalized_option, $options, true )
            ) {
                return new WP_Error( 'wphave_audience_field_validation_invalid', __( 'Select options must be unchanged by sanitization, at most 190 characters, non-empty, and unique.', 'wphave' ), [ 'status' => 400 ] );
            }

            $options[] = $normalized_option;
        }

        return [ 'options' => $options ];
    }

    /**
     * Returns active pipelines with their ordered stage registries.
     *
     * @return WP_REST_Response|WP_Error Pipeline collection or storage error.
     */
    public function pipelines_endpoint() {
        global $wpdb;

        if ( ! $this->permission_check() ) {
            return $this->audience_access_error();
        }

        $pipelines = $wpdb->get_results( "SELECT * FROM {$this->pipelines_table} WHERE is_active = 1 ORDER BY is_default DESC, id ASC", ARRAY_A );

        if ( null === $pipelines ) {
            return new WP_Error( 'wphave_audience_pipeline_read_failed', __( 'Pipelines could not be loaded.', 'wphave' ), [ 'status' => 500 ] );
        }

        $stages = $pipelines
            ? $wpdb->get_results(
                "SELECT stages.* FROM {$this->stages_table} stages INNER JOIN {$this->pipelines_table} pipelines ON pipelines.id = stages.pipeline_id WHERE pipelines.is_active = 1 ORDER BY stages.pipeline_id ASC, stages.position ASC, stages.id ASC",
                ARRAY_A
            )
            : [];

        if ( null === $stages ) {
            return new WP_Error( 'wphave_audience_pipeline_read_failed', __( 'Pipeline stages could not be loaded.', 'wphave' ), [ 'status' => 500 ] );
        }

        $stages_by_pipeline = [];

        foreach ( $stages as $stage ) {
            $stages_by_pipeline[ absint( $stage['pipeline_id'] ) ][] = $stage;
        }

        foreach ( $pipelines as &$pipeline ) {
            $pipeline['stages'] = $stages_by_pipeline[ absint( $pipeline['id'] ) ] ?? [];
        }
        unset( $pipeline );

        return rest_ensure_response( [ 'items' => $pipelines ] );
    }

    /**
     * Returns active communication and consent purposes.
     *
     * @return WP_REST_Response|WP_Error Purpose collection or storage error.
     */
    public function purposes_endpoint() {
        global $wpdb;

        if ( ! $this->permission_check() ) {
            return $this->audience_access_error();
        }

        $items = $wpdb->get_results( "SELECT * FROM {$this->purposes_table} WHERE is_active = 1 ORDER BY label ASC", ARRAY_A );

        if ( null === $items ) {
            return new WP_Error( 'wphave_audience_purpose_read_failed', __( 'Purposes could not be loaded.', 'wphave' ), [ 'status' => 500 ] );
        }

        return rest_ensure_response( [ 'items' => $items ] );
    }

    /**
     * Lists tags or idempotently creates/updates one reusable tag definition.
     *
     * @param WP_REST_Request $request Optional POST tag definition.
     * @return WP_REST_Response|WP_Error Tag collection or validation error.
     */
    public function tags_endpoint( WP_REST_Request $request ) {
        global $wpdb;

        $is_allowed = $request->get_method() === 'POST'
            ? $this->manage_permission_check()
            : $this->permission_check();

        if ( ! $is_allowed ) {
            return $this->audience_access_error();
        }

        if ( $request->get_method() === 'POST' ) {
            $label = sanitize_text_field( $request->get_param( 'label' ) ?? '' );
            $raw_key = $request->get_param( 'key' );
            $key = null === $raw_key || '' === $raw_key
                ? sanitize_key( $label )
                : $this->normalize_purpose_key( $raw_key );
            $label_length = function_exists( 'mb_strlen' ) ? mb_strlen( $label ) : strlen( $label );

            if (
                ! $key
                || ! $label
                || strlen( $key ) > 100
                || $label_length > 190
            ) {
                return new WP_Error( 'wphave_audience_tag_invalid', __( 'A tag key of at most 100 characters and label of at most 190 characters are required.', 'wphave' ), [ 'status' => 400 ] );
            }

            $now = current_time( 'mysql' );
            $saved = $wpdb->query(
                $wpdb->prepare(
                    "INSERT INTO {$this->tags_table} (tag_key, label, color, created_at, updated_at) VALUES (%s, %s, %s, %s, %s) ON DUPLICATE KEY UPDATE label = VALUES(label), color = VALUES(color), updated_at = VALUES(updated_at)",
                    $key,
                    $label,
                    sanitize_hex_color( $request->get_param( 'color' ) ?? '' ) ?: '',
                    $now,
                    $now
                )
            );

            if ( false === $saved ) {
                return new WP_Error( 'wphave_audience_tag_save_failed', __( 'Tag could not be stored.', 'wphave' ), [ 'status' => 500 ] );
            }
        }

        $items = $wpdb->get_results( "SELECT * FROM {$this->tags_table} ORDER BY label ASC", ARRAY_A );

        if ( null === $items ) {
            return new WP_Error( 'wphave_audience_tag_read_failed', __( 'Tags could not be loaded.', 'wphave' ), [ 'status' => 500 ] );
        }

        return rest_ensure_response( [ 'items' => $items ] );
    }

    /**
     * Lists custom-field definitions or upserts one scoped definition.
     *
     * Scope and field type are closed allowlists so storage semantics remain
     * predictable for future renderers, validation and privacy processing.
     *
     * @param WP_REST_Request $request Optional POST definition.
     * @return WP_REST_Response|WP_Error Definition collection or validation error.
     */
    public function custom_fields_endpoint( WP_REST_Request $request ) {
        global $wpdb;

        $is_allowed = $request->get_method() === 'POST'
            ? $this->manage_permission_check()
            : $this->permission_check();

        if ( ! $is_allowed ) {
            return $this->audience_access_error();
        }

        if ( $request->get_method() === 'POST' ) {
            // DATA INTEGRITY INVARIANT: Registry identities are exact durable
            // contracts; supplied keys are validated and never slug-repaired.
            $scope = $this->normalize_closed_key(
                $request->get_param( 'scope' ) ?? '',
                [ 'contact', 'lead', 'interaction' ]
            );
            $key = $this->normalize_purpose_key( $request->get_param( 'key' ) ?? '' );
            $label = sanitize_text_field( $request->get_param( 'label' ) ?? '' );
            $privacy_class = $this->normalize_closed_key(
                $request->get_param( 'privacy_class' ) ?? 'personal',
                [ 'personal', 'sensitive', 'operational' ]
            );
            $label_length = function_exists( 'mb_strlen' ) ? mb_strlen( $label ) : strlen( $label );

            if (
                ! $scope
                || ! $key
                || ! $label
                || ! $privacy_class
                || strlen( $key ) > 100
                || $label_length > 190
                || strlen( $privacy_class ) > 30
            ) {
                return new WP_Error( 'wphave_audience_field_invalid', __( 'A valid scope, key, label, and privacy class within the supported lengths are required.', 'wphave' ), [ 'status' => 400 ] );
            }

            $type = $this->normalize_closed_key(
                $request->get_param( 'field_type' ) ?? 'text',
                [ 'text', 'textarea', 'number', 'date', 'boolean', 'select', 'url', 'email' ]
            );

            if ( '' === $type ) {
                return new WP_Error( 'wphave_audience_field_type_invalid', __( 'The custom field type is not supported.', 'wphave' ), [ 'status' => 400 ] );
            }

            $validation = $this->normalize_custom_field_validation( $type, $request->get_param( 'validation' ) );

            if ( is_wp_error( $validation ) ) {
                return $validation;
            }

            $validation_json = wp_json_encode( $validation );

            if ( false === $validation_json ) {
                return new WP_Error( 'wphave_audience_field_validation_invalid', __( 'Custom field validation could not be encoded.', 'wphave' ), [ 'status' => 400 ] );
            }

            $existing = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT id, field_type, validation FROM {$this->field_definitions_table} WHERE scope = %s AND field_key = %s LIMIT 1",
                    $scope,
                    $key
                ),
                ARRAY_A
            );

            if ( $wpdb->last_error ) {
                return new WP_Error( 'wphave_audience_field_read_failed', __( 'Custom field could not be inspected.', 'wphave' ), [ 'status' => 500 ] );
            }

            if ( $existing ) {
                $existing_validation = json_decode( (string) ( $existing['validation'] ?? '' ), true );
                $existing_validation_json = wp_json_encode( is_array( $existing_validation ) ? $existing_validation : [] );
                $contract_changes = $type !== $existing['field_type'] || $validation_json !== $existing_validation_json;

                if ( $contract_changes ) {
                    $stored_value_count = (int) $wpdb->get_var(
                        $wpdb->prepare(
                            "SELECT COUNT(*) FROM {$this->field_values_table} WHERE definition_id = %d",
                            absint( $existing['id'] )
                        )
                    );

                    if ( $wpdb->last_error ) {
                        return new WP_Error( 'wphave_audience_field_read_failed', __( 'Custom field usage could not be inspected.', 'wphave' ), [ 'status' => 500 ] );
                    }

                    if ( $stored_value_count > 0 ) {
                        return new WP_Error( 'wphave_audience_field_contract_in_use', __( 'Migrate existing values before changing this custom field contract.', 'wphave' ), [ 'status' => 409 ] );
                    }
                }
            }

            $now = current_time( 'mysql' );
            $saved = $wpdb->query(
                $wpdb->prepare(
                    "INSERT INTO {$this->field_definitions_table} (field_key, label, scope, field_type, privacy_class, validation, is_active, created_at, updated_at) VALUES (%s, %s, %s, %s, %s, %s, 1, %s, %s) ON DUPLICATE KEY UPDATE label = VALUES(label), field_type = VALUES(field_type), privacy_class = VALUES(privacy_class), validation = VALUES(validation), is_active = 1, updated_at = VALUES(updated_at)",
                    $key,
                    $label,
                    $scope,
                    $type,
                    $privacy_class,
                    $validation_json,
                    $now,
                    $now
                )
            );

            if ( false === $saved ) {
                return new WP_Error( 'wphave_audience_field_save_failed', __( 'Custom field could not be stored.', 'wphave' ), [ 'status' => 500 ] );
            }
        }

        $items = $wpdb->get_results( "SELECT * FROM {$this->field_definitions_table} WHERE is_active = 1 ORDER BY scope ASC, label ASC", ARRAY_A );

        if ( null === $items ) {
            return new WP_Error( 'wphave_audience_field_read_failed', __( 'Custom fields could not be loaded.', 'wphave' ), [ 'status' => 500 ] );
        }

        foreach ( $items as &$item ) {
            $stored_validation = (string) ( $item['validation'] ?? '' );
            $validation = '' === $stored_validation
                ? []
                : json_decode( $stored_validation, true );

            if ( ! is_array( $validation ) || ( '' !== $stored_validation && JSON_ERROR_NONE !== json_last_error() ) ) {
                return new WP_Error( 'wphave_audience_field_contract_invalid', __( 'A stored custom field contract is invalid.', 'wphave' ), [ 'status' => 500 ] );
            }

            $item['validation'] = $validation;
        }
        unset( $item );

        return rest_ensure_response( [ 'items' => $items ] );
    }

}
