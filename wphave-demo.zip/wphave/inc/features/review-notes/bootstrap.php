<?php

/**
 * Enable the WordPress Notes contract for post types edited by WPHAVE.
 *
 * WordPress deliberately requires an explicit `editor.notes` support value
 * before its comments REST controller accepts a note. Appending support keeps
 * every existing editor support argument intact and lets Core remain the
 * authorization and persistence authority.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Append Core Notes support without discarding existing editor arguments.
 *
 * @param string $post_type Post type name.
 */

if ( ! function_exists( 'wphave_review_notes_enable_post_type_support' ) ) {

	function wphave_review_notes_enable_post_type_support( string $post_type ): void {
		$supports = get_all_post_type_supports( $post_type );
		$editor_support = $supports['editor'] ?? null;

		if ( ! $editor_support ) {
			return;
		}

		$editor_arguments = is_array( $editor_support ) ? $editor_support : array();
		$has_notes = array_any(
			$editor_arguments,
			static fn( $argument ): bool => is_array( $argument ) && ! empty( $argument['notes'] )
		);

		if ( $has_notes ) {
			return;
		}

		$editor_arguments[] = array( 'notes' => true );
		add_post_type_support( $post_type, 'editor', ...$editor_arguments );
	}

}

add_action(
	'init',
	static function (): void {
		$post_types = get_post_types(
			array(
				'show_ui' => true,
				'show_in_rest' => true,
			),
			'objects'
		);

		foreach ( $post_types as $post_type ) {
			wphave_review_notes_enable_post_type_support( $post_type->name );
		}
	},
	20
);
