<?php

/** Bootstrap public brand assets. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/favicon.php';
