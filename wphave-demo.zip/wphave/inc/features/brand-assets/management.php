<?php

/** Bootstrap administrative brand-asset services. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/logo-generator.php';
