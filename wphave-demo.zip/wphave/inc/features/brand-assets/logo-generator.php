<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once wphave_dir() . 'inc/features/security/atomic-file.php';
require_once wphave_dir() . 'inc/features/security/file-identity.php';
require_once wphave_dir() . 'inc/features/security/conditional-file.php';

	/**
	 * Generate a controlled pair of SVG logo attachments.
	 *
	 * The endpoint accepts design tokens rather than arbitrary SVG markup. It
	 * honors the effective SVG upload policy and places the SVG sanitizer at the
	 * server-side trust boundary.
	 */

	class WPHAVE_Logo_Generator {

		const REST_NAMESPACE = 'wphave/v1';
		const REST_ROUTE = '/brand-assets/logo';
		const MAX_TEXT_LENGTH = 60;
		const COMBINED_GAP = 36;

		/**
		 * Register the REST route.
		 *
		 * @return void
		 */

		public static function init() {
			add_action( 'rest_api_init', array( __CLASS__, 'register_rest_route' ) );
		}

		/**
		 * Register the logo generation endpoint.
		 *
		 * @return void
		 */

		public static function register_rest_route() {
			register_rest_route( self::REST_NAMESPACE, self::REST_ROUTE, array(
				array(
					'methods' => WP_REST_Server::READABLE,
					'callback' => array( __CLASS__, 'get_capabilities' ),
					'permission_callback' => array( __CLASS__, 'can_manage_brand_assets' ),
				),
				array(
					'methods' => WP_REST_Server::CREATABLE,
					'callback' => array( __CLASS__, 'generate' ),
					'permission_callback' => array( __CLASS__, 'can_generate' ),
				),
			) );
		}

		/**
		 * Check capabilities shared by status and generation calls.
		 *
		 * @return bool
		 */

		public static function can_manage_brand_assets() {
			return current_user_can( 'manage_options' ) && current_user_can( 'upload_files' );
		}

		/**
		 * Require the same capabilities as managing Brand settings and media.
		 *
		 * @return bool
		 */

		public static function can_generate() {
			$has_pro_access = function_exists( 'wphave_has_pro_access' ) && wphave_has_pro_access();

			return $has_pro_access && self::can_manage_brand_assets();
		}

		/**
		 * Check WPHAVE's sanitizer switch and WordPress' filtered MIME allow-list.
		 *
		 * @return bool
		 */

		public static function svg_upload_allowed() {
			$wphave_enabled = function_exists( 'wphave_svg_upload_support_enabled' )
				&& wphave_svg_upload_support_enabled();
			$allowed_mimes = get_allowed_mime_types( get_current_user_id() );
			$mime_allowed = isset( $allowed_mimes['svg'] )
				&& $allowed_mimes['svg'] === 'image/svg+xml';
			$allowed = $wphave_enabled && $mime_allowed;

			return (bool) apply_filters( 'wphave_brand_asset_generator_svg_upload_allowed', $allowed );
		}

		/**
		 * Expose environment capabilities for proactive UI feedback.
		 *
		 * @return WP_REST_Response
		 */

		public static function get_capabilities() {
			// AUTHORIZATION INVARIANT: Brand capability discovery is an administrative
			// callback, not a public environment probe. Repeat the route policy here.
			if ( ! self::can_manage_brand_assets() ) {
				return new WP_Error(
					'wphave_brand_assets_forbidden',
					__( 'You are not allowed to manage brand assets.', 'wphave' ),
					array( 'status' => 403 )
				);
			}

			return new WP_REST_Response( array(
				'svgUploadAllowed' => self::svg_upload_allowed(),
			), 200 );
		}

		/**
		 * Generate and store standard and contrast logo attachments atomically.
		 *
		 * @param WP_REST_Request $request Request object.
		 * @return WP_REST_Response|WP_Error
		 */

		public static function generate( WP_REST_Request $request ) {
			// AUTHORIZATION INVARIANT: Generating attachments consumes Pro authority,
			// site settings authority and filesystem authority. Recheck all three at
			// the final public callback before inspecting SVG support or writing files.
			if ( ! self::can_generate() ) {
				return new WP_Error(
					'wphave_brand_generation_forbidden',
					__( 'You are not allowed to generate brand assets.', 'wphave' ),
					array( 'status' => 403 )
				);
			}

			if ( ! self::svg_upload_allowed() ) {
				return new WP_Error(
					'wphave_logo_svg_upload_disabled',
					__( 'SVG uploads are currently disabled. Enable them in Media Settings before generating a logo.', 'wphave' ),
					array( 'status' => 403 )
				);
			}

			$design = self::normalize_design( $request->get_json_params() );

			if ( is_wp_error( $design ) ) {
				return $design;
			}

			// AUTHORIZATION/TOCTOU INVARIANT: SVG policy and design sanitization are
			// filterable extension boundaries. Recheck Pro, settings and upload authority
			// after both complete and before rendering or publishing either variant.
			if ( ! self::can_generate() ) {
				return new WP_Error(
					'wphave_brand_generation_forbidden',
					__( 'You are not allowed to generate brand assets.', 'wphave' ),
					array( 'status' => 403 )
				);
			}

			$created_ids = array();
			$variants = array(
				'logo' => array(
					'color' => $design['standardColor'],
					'shapeColor' => $design['contrastColor'],
				),
				'contrastLogo' => array(
					'color' => $design['contrastColor'],
					'shapeColor' => $design['standardColor'],
				),
			);

			foreach ( $variants as $variant => $variant_colors ) {
				$svg = self::render_svg( array_merge( $design, $variant_colors ) );
				$attachment_id = self::store_svg_attachment( $svg, $design['text'], $variant );

				if ( is_wp_error( $attachment_id ) ) {
					// ROLLBACK INVARIANT: A first variant may have been edited by
					// another hook before a later variant fails. Its numeric ID is
					// insufficient authority for permanent attachment/file deletion.
					// Return the incomplete IDs for explicit reconciliation.
					if ( $created_ids ) {
						$error_data = $attachment_id->get_error_data();
						$attachment_id->add_data( array_merge( is_array( $error_data ) ? $error_data : array(), array( 'recovery_attachment_ids' => array_values( $created_ids ) ) ) );
					}

					return $attachment_id;
				}

				$created_ids[ $variant ] = $attachment_id;
			}

			return new WP_REST_Response( array(
				'logo' => array(
					'id' => $created_ids['logo'],
					'url' => wp_get_attachment_url( $created_ids['logo'] ),
				),
				'contrastLogo' => array(
					'id' => $created_ids['contrastLogo'],
					'url' => wp_get_attachment_url( $created_ids['contrastLogo'] ),
				),
			), 201 );
		}

		/**
		 * Normalize the small, explicit design grammar.
		 *
		 * @param mixed $input Request payload.
		 * @return array|WP_Error
		 */

		public static function normalize_design( $input ) {
			$input = is_array( $input ) ? $input : array();
			$text = sanitize_text_field( $input['text'] ?? '' );
			$text = function_exists( 'mb_substr' )
				? mb_substr( $text, 0, self::MAX_TEXT_LENGTH )
				: substr( $text, 0, self::MAX_TEXT_LENGTH );

			if ( ! $text ) {
				return new WP_Error(
					'wphave_logo_text_required',
					__( 'Enter logo text before generating the logo.', 'wphave' ),
					array( 'status' => 400 )
				);
			}

			$layout = self::enum_value( $input['layout'] ?? '', array( 'wordmark', 'monogram', 'combined' ), 'wordmark' );
			$metrics = $layout === 'combined'
				? self::normalize_combined_metrics( $input['metrics'] ?? array() )
				: self::normalize_metrics( $input['metrics'] ?? array() );

			if ( is_wp_error( $metrics ) ) {
				return $metrics;
			}

			return array(
				'text' => $text,
				'layout' => $layout,
				'letterCase' => self::enum_value( $input['letterCase'] ?? '', array( 'original', 'uppercase', 'lowercase' ), 'original' ),
				'fontFamily' => self::enum_value( $input['fontFamily'] ?? '', array( 'sans', 'serif', 'mono' ), 'sans' ),
				'fontWeight' => self::integer_value( $input['fontWeight'] ?? 700, 400, 900, 700 ),
				'letterSpacing' => self::integer_value( $input['letterSpacing'] ?? 0, -2, 12, 0 ),
				'shape' => self::enum_value( $input['shape'] ?? '', array( 'none', 'background', 'border' ), 'none' ),
				'shiny' => filter_var( $input['shiny'] ?? false, FILTER_VALIDATE_BOOLEAN ),
				'corners' => self::enum_value( $input['corners'] ?? '', array( 'none', 'slightly-rounded', 'rounded' ), 'slightly-rounded' ),
				'standardColor' => self::color_value( $input['standardColor'] ?? '#000000', '#000000' ),
				'contrastColor' => self::color_value( $input['contrastColor'] ?? '#ffffff', '#ffffff' ),
				'metrics' => $metrics,
			);
		}

		/**
		 * Render sanitized SVG markup from normalized design data.
		 *
		 * @param array $design Normalized design.
		 * @return string|WP_Error
		 */

		public static function render_svg( $design ) {
			if ( ! class_exists( 'WPHAVE_Safe_SVG' ) ) {
			}

			$text = self::transform_text( $design['text'], $design['letterCase'], $design['layout'] );
			$escaped_text = htmlspecialchars( $text, ENT_QUOTES | ENT_XML1, 'UTF-8' );
			$font_families = array(
				'sans' => 'Arial, Helvetica, sans-serif',
				'serif' => 'Georgia, Times, serif',
				'mono' => 'Courier, monospace',
			);
			$font_family = $font_families[ $design['fontFamily'] ];
			$color = self::color_value( $design['color'] ?? '', '#000000' );
			$shape_color = self::color_value( $design['shapeColor'] ?? '', '#ffffff' );

			$metrics = $design['metrics'];
			$shape_markup = '';
			$text_markup = '';

			if ( $design['layout'] === 'combined' ) {
				$wordmark = self::transform_text( $design['text'], $design['letterCase'], 'wordmark' );
				$monogram = self::transform_text( $design['text'], $design['letterCase'], 'monogram' );
				$escaped_text = htmlspecialchars( $wordmark, ENT_QUOTES | ENT_XML1, 'UTF-8' );
				$escaped_monogram = htmlspecialchars( $monogram, ENT_QUOTES | ENT_XML1, 'UTF-8' );
				$monogram_metrics = $metrics['monogram'];
				$wordmark_metrics = $metrics['wordmark'];
				$monogram_bounds = $design['shape'] === 'none'
					? $monogram_metrics
					: self::shape_geometry( $monogram_metrics, 'monogram' );

				if ( $design['shape'] !== 'none' ) {
					$shape_markup = self::shape_markup(
						$monogram_bounds,
						$design['shape'],
						$design['corners'],
						$shape_color,
						! empty( $design['shiny'] )
					);
				}

				$wordmark_x = $monogram_bounds['x']
					+ $monogram_bounds['width']
					+ self::COMBINED_GAP
					- $wordmark_metrics['x'];

				// Keep both text parts on one typographic baseline. Centering their
				// visible bounds makes words with descenders appear too high and does
				// not match the flex-centered browser preview.
				$wordmark_y = 0;
				$wordmark_top = $wordmark_metrics['y'] + $wordmark_y;
				$wordmark_right = $wordmark_x + $wordmark_metrics['x'] + $wordmark_metrics['width'];
				$wordmark_bottom = $wordmark_top + $wordmark_metrics['height'];
				$monogram_bottom = $monogram_bounds['y'] + $monogram_bounds['height'];
				$metrics = array(
					'x' => $monogram_bounds['x'],
					'y' => min( $monogram_bounds['y'], $wordmark_top ),
					'width' => $wordmark_right - $monogram_bounds['x'],
					'height' => max( $monogram_bottom, $wordmark_bottom ) - min( $monogram_bounds['y'], $wordmark_top ),
				);
				$text_markup = sprintf(
					'<text x="0" y="0" fill="%1$s" font-family="%2$s" font-size="112" font-weight="%3$d" letter-spacing="%4$d">%5$s</text><text x="%6$s" y="%7$s" fill="%1$s" font-family="%2$s" font-size="112" font-weight="%3$d" letter-spacing="%4$d">%8$s</text>',
					$color,
					$font_family,
					$design['fontWeight'],
					$design['letterSpacing'],
					$escaped_monogram,
					self::decimal_value( $wordmark_x ),
					self::decimal_value( $wordmark_y ),
					$escaped_text
				);
			}

			if ( $design['layout'] !== 'combined' && $design['shape'] !== 'none' ) {
				$shape_geometry = self::shape_geometry( $metrics, $design['layout'] );
				$metrics = $shape_geometry;
				$shape_markup = self::shape_markup(
					$shape_geometry,
					$design['shape'],
					$design['corners'],
					$shape_color,
					! empty( $design['shiny'] )
				);
			}

			if ( $design['layout'] !== 'combined' ) {
				$text_markup = sprintf(
					'<text x="0" y="0" fill="%1$s" font-family="%2$s" font-size="112" font-weight="%3$d" letter-spacing="%4$d">%5$s</text>',
					$color,
					$font_family,
					$design['fontWeight'],
					$design['letterSpacing'],
					$escaped_text
				);
			}

			$view_box = implode( ' ', array(
				self::decimal_value( $metrics['x'] ),
				self::decimal_value( $metrics['y'] ),
				self::decimal_value( $metrics['width'] ),
				self::decimal_value( $metrics['height'] ),
			) );

			$svg = sprintf(
				'<svg xmlns="http://www.w3.org/2000/svg" viewBox="%1$s" width="%2$s" height="%3$s" role="img" aria-label="%4$s"><title>%4$s</title>%5$s%6$s</svg>',
				$view_box,
				self::decimal_value( $metrics['width'] ),
				self::decimal_value( $metrics['height'] ),
				$escaped_text,
				$shape_markup,
				$text_markup
			);
			$sanitized = WPHAVE_Safe_SVG::sanitize_markup( $svg );

			if ( ! $sanitized ) {
				return new WP_Error(
					'wphave_logo_svg_invalid',
					__( 'The generated logo could not be sanitized.', 'wphave' ),
					array( 'status' => 500 )
				);
			}

			return $sanitized;
		}

		/**
		 * Expand visible text bounds into the selected logo shape.
		 *
		 * Wordmarks retain their natural aspect ratio. Monograms receive a square
		 * canvas centered around the visible glyphs before padding is added.
		 *
		 * @param array $metrics Visible text bounds.
		 * @param string $layout Logo layout.
		 * @return array
		 */

		private static function shape_geometry( $metrics, $layout ) {
			$padding_x = 24;
			$padding_y = 18;
			$content_x = $metrics['x'];
			$content_y = $metrics['y'];
			$content_width = $metrics['width'];
			$content_height = $metrics['height'];

			if ( $layout === 'monogram' ) {
				$content_size = max( $content_width, $content_height );
				$content_x -= ( $content_size - $content_width ) / 2;
				$content_y -= ( $content_size - $content_height ) / 2;
				$content_width = $content_size;
				$content_height = $content_size;
				$padding_y = $padding_x;
			}

			return array(
				'x' => $content_x - $padding_x,
				'y' => $content_y - $padding_y,
				'width' => $content_width + ( $padding_x * 2 ),
				'height' => $content_height + ( $padding_y * 2 ),
			);
		}

		/**
		 * Render the optional background or border around one geometry.
		 *
		 * @param array $geometry Shape bounds.
		 * @param string $shape Shape style.
		 * @param string $corners Corner style.
		 * @param string $shape_color Shape color.
		 * @param bool   $shiny Whether to render a subtle light highlight.
		 * @return string
		 */

		private static function shape_markup( $geometry, $shape, $corners, $shape_color, $shiny ) {
			$corner_radii = array(
				'none' => 0,
				'slightly-rounded' => 8,
				'rounded' => 24,
			);
			$radius = $corner_radii[ $corners ];
			$rect_x = $geometry['x'];
			$rect_y = $geometry['y'];
			$rect_width = $geometry['width'];
			$rect_height = $geometry['height'];

			if ( $shape === 'border' ) {
				$stroke_width = 4;
				$stroke_inset = $stroke_width / 2;
				$rect_x += $stroke_inset;
				$rect_y += $stroke_inset;
				$rect_width -= $stroke_width;
				$rect_height -= $stroke_width;

				$base_markup = sprintf(
					'<rect x="%1$s" y="%2$s" width="%3$s" height="%4$s" rx="%5$d" fill="none" stroke="%6$s" stroke-width="%7$d"/>',
					self::decimal_value( $rect_x ),
					self::decimal_value( $rect_y ),
					self::decimal_value( $rect_width ),
					self::decimal_value( $rect_height ),
					$radius,
					$shape_color,
					$stroke_width
				);

				return $shiny
					? $base_markup . self::shine_markup(
						$rect_x,
						$rect_y,
						$rect_width,
						$rect_height,
						$radius,
						'border',
						$stroke_width
					)
					: $base_markup;
			}

			$base_markup = sprintf(
				'<rect x="%1$s" y="%2$s" width="%3$s" height="%4$s" rx="%5$d" fill="%6$s"/>',
				self::decimal_value( $rect_x ),
				self::decimal_value( $rect_y ),
				self::decimal_value( $rect_width ),
				self::decimal_value( $rect_height ),
				$radius,
				$shape_color
			);

			return $shiny
				? $base_markup . self::shine_markup(
					$rect_x,
					$rect_y,
					$rect_width,
					$rect_height,
					$radius,
					'background'
				)
				: $base_markup;
		}

		/**
		 * Render a transparent radial highlight over one shape.
		 *
		 * @param float  $x Shape x position.
		 * @param float  $y Shape y position.
		 * @param float  $width Shape width.
		 * @param float  $height Shape height.
		 * @param int    $radius Shape corner radius.
		 * @param string $shape Shape style.
		 * @param int    $stroke_width Border width.
		 * @return string
		 */

		private static function shine_markup( $x, $y, $width, $height, $radius, $shape, $stroke_width = 0 ) {
			$gradient = '<defs><radialGradient id="wphave-logo-shine" cx="22%" cy="18%" r="70%"><stop offset="0" stop-color="#ffffff" stop-opacity="0.5"/><stop offset="0.58" stop-color="#ffffff" stop-opacity="0"/></radialGradient></defs>';

			if ( $shape === 'border' ) {
				return $gradient . sprintf(
					'<rect x="%1$s" y="%2$s" width="%3$s" height="%4$s" rx="%5$d" fill="none" stroke="url(#wphave-logo-shine)" stroke-width="%6$d"/>',
					self::decimal_value( $x ),
					self::decimal_value( $y ),
					self::decimal_value( $width ),
					self::decimal_value( $height ),
					$radius,
					$stroke_width
				);
			}

			return $gradient . sprintf(
				'<rect x="%1$s" y="%2$s" width="%3$s" height="%4$s" rx="%5$d" fill="url(#wphave-logo-shine)"/>',
				self::decimal_value( $x ),
				self::decimal_value( $y ),
				self::decimal_value( $width ),
				self::decimal_value( $height ),
				$radius
			);
		}

		/**
		 * Store one generated SVG and create its media attachment.
		 *
		 * @param string|WP_Error $svg SVG markup.
		 * @param string $text Logo text.
		 * @param string $variant Variant key.
		 * @return int|WP_Error
		 */

		private static function store_svg_attachment( $svg, $text, $variant ) {
			if ( is_wp_error( $svg ) ) {
				return $svg;
			}

			$uploads = wp_upload_dir();

			if ( ! empty( $uploads['error'] ) ) {
				return new WP_Error( 'wphave_logo_upload_directory', $uploads['error'], array( 'status' => 500 ) );
			}

			if ( ! wp_mkdir_p( $uploads['path'] ) ) {
				return new WP_Error(
					'wphave_logo_upload_directory',
					__( 'The uploads directory could not be created.', 'wphave' ),
					array( 'status' => 500 )
				);
			}

			$base_name = sanitize_file_name( $text . '-' . ( $variant === 'contrastLogo' ? 'contrast-logo' : 'logo' ) . '.svg' );
			$file_name = wp_unique_filename( $uploads['path'], $base_name );
			$file_path = trailingslashit( $uploads['path'] ) . $file_name;
			$attachment_title = sanitize_text_field( $text . ( $variant === 'contrastLogo' ? ' Contrast Logo' : ' Logo' ) );
			$alt = sanitize_text_field( $text );

			// AUTHORIZATION/TOCTOU INVARIANT: Filename and text sanitizers run
			// independently for every variant. Recheck SVG policy, Pro, settings
			// and upload authority after all of them and before publishing media.
			if ( ! self::svg_upload_allowed() ) {
				return new WP_Error(
					'wphave_logo_svg_upload_disabled',
					__( 'SVG uploads are currently disabled. Enable them in Media Settings before generating a logo.', 'wphave' ),
					array( 'status' => 403 )
				);
			}

			if ( ! self::can_generate() ) {
				return new WP_Error(
					'wphave_brand_generation_forbidden',
					__( 'You are not allowed to generate brand assets.', 'wphave' ),
					array( 'status' => 403 )
				);
			}

			try {
				// PUBLICATION INVARIANT: wp_unique_filename() is only a snapshot.
				// Concurrent logo requests must never overwrite each other's SVG bytes.
				// The attachment record is published only after the exclusive copy
				// completes; this path also works in runtimes without hard links.
				$stage = trailingslashit( $uploads['path'] ) . '.wphave-logo-' . wp_generate_uuid4();
				WPHAVE_Security_Atomic_File::write(
					$stage,
					$svg,
					__( 'The generated logo could not be staged.', 'wphave' )
				);
				WPHAVE_Security_Atomic_File::copy_verified_unpublished(
					$stage,
					$file_path,
					hash( 'sha256', $svg ),
					__( 'The generated logo could not be published.', 'wphave' ),
					WPHAVE_Security_File_Permissions::for_new_public_file( $file_path )
				);
			} catch ( RuntimeException $error ) {
				return new WP_Error(
					'wphave_logo_write_failed',
					__( 'The generated logo could not be published.', 'wphave' ),
					array( 'status' => 500 )
				);
			} finally {
				if ( isset( $stage ) ) {
					try {
						WPHAVE_Security_Conditional_File::remove_if_matches(
							$stage,
							hash( 'sha256', $svg ),
							__( 'Logo staging could not be cleaned up safely.', 'wphave' )
						);
					} catch ( RuntimeException $error ) {
						// Keep a changed staging node for explicit reconciliation.
					}
				}
			}

			// SECURITY INVARIANT: Media registration references only fully written bytes
			// atomically moved from request-local staging into the uploads directory.
			$attachment_id = wp_insert_attachment( array(
				'post_mime_type' => 'image/svg+xml',
				'post_title' => $attachment_title,
				'post_content' => '',
				'post_status' => 'inherit',
			), $file_path, 0, true );

			// INSERT INVARIANT: Core may return zero for a failed attachment
			// insert. Neither zero nor a WP_Error is a published media object.
			if ( is_wp_error( $attachment_id ) || ! is_int( $attachment_id ) || $attachment_id < 1 ) {
				try {
					// ROLLBACK INVARIANT: A failed attachment insert owns only the
					// SVG revision it published, not a later replacement at this path.
					WPHAVE_Security_Conditional_File::remove_if_matches(
						$file_path,
						hash( 'sha256', $svg ),
						__( 'Failed logo publication could not be cleaned up safely.', 'wphave' )
					);
				} catch ( RuntimeException $error ) {
					// Preserve the unproven file for explicit reconciliation.
				}
				return is_wp_error( $attachment_id )
					? $attachment_id
					: new WP_Error( 'wphave_logo_attachment_failed', __( 'The generated logo could not be registered.', 'wphave' ), array( 'status' => 500 ) );
			}
			// METADATA AUTHORIZATION INVARIANT: Attachment insertion invokes
			// WordPress hooks. A revocation there prevents the separate alt-text
			// write while retaining the new media object for reconciliation.
			if ( ! self::can_generate() ) {
				return new WP_Error( 'wphave_brand_generation_forbidden', __( 'You are not allowed to generate brand assets.', 'wphave' ), array( 'status' => 403, 'attachment_id' => $attachment_id ) );
			}

			update_post_meta( $attachment_id, '_wp_attachment_image_alt', $alt );
			// METADATA COMMIT INVARIANT: A generated logo is not complete when
			// its accessible name failed to persist. Preserve the registered
			// media object for recovery rather than deleting an unproven ID.
			if ( $alt !== get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ) ) {
				return new WP_Error( 'wphave_logo_metadata_failed', __( 'The generated logo metadata could not be saved.', 'wphave' ), array( 'status' => 500, 'attachment_id' => $attachment_id ) );
			}

			return $attachment_id;
		}

		/**
		 * Return a value from a closed enum.
		 *
		 * @param mixed $value Requested value.
		 * @param array $allowed Allowed values.
		 * @param string $fallback Fallback value.
		 * @return string
		 */

		private static function enum_value( $value, $allowed, $fallback ) {
			$value = (string) $value;

			return in_array( $value, $allowed, true ) ? $value : $fallback;
		}

		/**
		 * Clamp a numeric design value.
		 *
		 * @param mixed $value Requested value.
		 * @param int $minimum Minimum.
		 * @param int $maximum Maximum.
		 * @param int $fallback Fallback.
		 * @return int
		 */

		private static function integer_value( $value, $minimum, $maximum, $fallback ) {
			if ( ! is_numeric( $value ) ) {
				return $fallback;
			}

			return min( $maximum, max( $minimum, (int) $value ) );
		}

		/**
		 * Accept hexadecimal colors only.
		 *
		 * @param mixed $value Requested value.
		 * @param string $fallback Fallback.
		 * @return string
		 */

		private static function color_value( $value, $fallback ) {
			$value = strtolower( trim( (string) $value ) );

			return preg_match( '/^#[0-9a-f]{6}$/', $value ) ? $value : $fallback;
		}

		/**
		 * Validate browser-measured text bounds used by the SVG viewBox.
		 *
		 * @param mixed $metrics Requested bounds.
		 * @return array|WP_Error
		 */

		private static function normalize_metrics( $metrics ) {
			$metrics = is_array( $metrics ) ? $metrics : array();
			$rules = array(
				'x' => array( -1000, 1000 ),
				'y' => array( -1000, 1000 ),
				'width' => array( 1, 6000 ),
				'height' => array( 1, 1000 ),
			);
			$normalized = array();

			foreach ( $rules as $key => $range ) {
				if ( ! isset( $metrics[ $key ] ) || ! is_numeric( $metrics[ $key ] ) ) {
					return new WP_Error(
						'wphave_logo_metrics_invalid',
						__( 'The visible logo bounds could not be validated.', 'wphave' ),
						array( 'status' => 400 )
					);
				}

				$value = (float) $metrics[ $key ];

				if ( ! is_finite( $value ) || $value < $range[0] || $value > $range[1] ) {
					return new WP_Error(
						'wphave_logo_metrics_invalid',
						__( 'The visible logo bounds are outside the supported range.', 'wphave' ),
						array( 'status' => 400 )
					);
				}

				$normalized[ $key ] = round( $value, 3 );
			}

			return $normalized;
		}

		/**
		 * Validate the independently measured parts of a combined logo.
		 *
		 * @param mixed $metrics Requested combined bounds.
		 * @return array|WP_Error
		 */

		private static function normalize_combined_metrics( $metrics ) {
			$metrics = is_array( $metrics ) ? $metrics : array();
			$normalized = array();

			foreach ( array( 'monogram', 'wordmark' ) as $part ) {
				$part_metrics = self::normalize_metrics( $metrics[ $part ] ?? array() );

				if ( is_wp_error( $part_metrics ) ) {
					return $part_metrics;
				}

				$normalized[ $part ] = $part_metrics;
			}

			return $normalized;
		}

		/**
		 * Serialize a bounded decimal without locale-specific separators.
		 *
		 * @param float $value Numeric value.
		 * @return string
		 */

		private static function decimal_value( $value ) {
			$value = number_format( (float) $value, 3, '.', '' );

			return rtrim( rtrim( $value, '0' ), '.' );
		}

		/**
		 * Apply casing and monogram rules.
		 *
		 * @param string $text Logo text.
		 * @param string $letter_case Case mode.
		 * @param string $layout Layout mode.
		 * @return string
		 */
        
		private static function transform_text( $text, $letter_case, $layout ) {
			if ( $layout === 'monogram' ) {
				$words = preg_split( '/\s+/u', trim( $text ) );
				$characters = array();

				foreach ( array_slice( $words, 0, 2 ) as $word ) {
					$characters[] = function_exists( 'mb_substr' ) ? mb_substr( $word, 0, 1 ) : substr( $word, 0, 1 );
				}

				$text = implode( '', $characters );
			}

			if ( $letter_case === 'uppercase' ) {
				return function_exists( 'mb_strtoupper' ) ? mb_strtoupper( $text ) : strtoupper( $text );
			}

			if ( $letter_case === 'lowercase' ) {
				return function_exists( 'mb_strtolower' ) ? mb_strtolower( $text ) : strtolower( $text );
			}

			return $text;
		}
	}

	WPHAVE_Logo_Generator::init();
