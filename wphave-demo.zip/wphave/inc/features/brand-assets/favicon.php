<?php

/**
 * Resolve the configured site icon URL.
 *
 * WordPress' native Site Icon is the single authority. When it is not set, the
 * bundled product icon provides a stable frontend fallback.
 *
 * @return string Escaped favicon URL.
 */

if ( ! function_exists( 'wphave_get_favicon_url' ) ) :

	function wphave_get_favicon_url() {
		$wp_favicon = get_site_icon_url();

		if ( $wp_favicon ) {
			return esc_url( $wp_favicon );
		}

		if ( wphave_use_fse() ) {
			return esc_url( get_theme_file_uri( '/assets/img/favicon.ico' ) );
		}

		return esc_url( wphave_asset_url( '/assets/img/favicon.ico' ) );
	}

endif;

/**
 * Print the resolved site icon in the document head.
 *
 * @return void
 */

if ( ! function_exists( 'wphave_browser_icons' ) ) :

	function wphave_browser_icons() {
		$favicon = wphave_get_favicon_url();

		if ( ! $favicon ) {
			return;
		}
		?>
		<link rel="shortcut icon" href="<?php echo esc_url( $favicon ); ?>">
		<?php
	}

endif;

add_action( 'wp_head', 'wphave_browser_icons' );
