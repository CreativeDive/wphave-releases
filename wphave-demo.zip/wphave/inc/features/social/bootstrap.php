<?php

/** Bootstrap social profile and sharing services. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/profiles.php';
require_once __DIR__ . '/sharing.php';
