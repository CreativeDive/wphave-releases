<?php

/**
 * Build privacy-friendly social-sharing destinations.
 *
 * @package wphave
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

if( ! class_exists( 'WPHAVE_Social_Sharing' ) ) :

/**
 * Own the supported sharing services and their URL contracts.
 */

class WPHAVE_Social_Sharing {

	/**
	 * Return the supported services in their default order.
	 *
	 * PRIVACY INVARIANT: No service loads a remote SDK. A third party is contacted only after the
	 * visitor deliberately follows its generated sharing URL.
	 *
	 * @return array
	 */

	public static function services() {
		$services = array(
			'native' => array( 'label' => __( 'Share', 'wphave' ), 'color' => '#62676f', 'icon' => 'share', 'action' => 'native' ),
			'facebook' => array( 'label' => __( 'Facebook', 'wphave' ), 'color' => '#1778F2', 'icon' => 'facebook' ),
			'x' => array( 'label' => __( 'X', 'wphave' ), 'color' => '#1e3050', 'icon' => 'x' ),
			'linkedin' => array( 'label' => __( 'LinkedIn', 'wphave' ), 'color' => '#0077B5', 'icon' => 'linkedin' ),
			'bluesky' => array( 'label' => __( 'Bluesky', 'wphave' ), 'color' => '#1185FE', 'icon' => 'bluesky' ),
			'reddit' => array( 'label' => __( 'Reddit', 'wphave' ), 'color' => '#FF4500', 'icon' => 'reddit' ),
			'whatsapp' => array( 'label' => __( 'WhatsApp', 'wphave' ), 'color' => '#25d366', 'icon' => 'whatsapp' ),
			'telegram' => array( 'label' => __( 'Telegram', 'wphave' ), 'color' => '#229ED9', 'icon' => 'telegram' ),
			'pinterest' => array( 'label' => __( 'Pinterest', 'wphave' ), 'color' => '#E60023', 'icon' => 'pinterest', 'requires_image' => true ),
			'email' => array( 'label' => __( 'Email', 'wphave' ), 'color' => '#62676f', 'icon' => 'email' ),
			'copy' => array( 'label' => __( 'Copy link', 'wphave' ), 'color' => '#62676f', 'icon' => 'copy', 'action' => 'copy' ),
		);

		return apply_filters( 'wphave_social_sharing_services', $services );
	}

	/**
	 * Return a service definition.
	 *
	 * @param string $service Service identifier.
	 * @return array
	 */

	public static function service( $service ) {
		$services = self::services();

		return $services[sanitize_key( $service )] ?? array();
	}

	/**
	 * Normalize selected service identifiers while preserving their order.
	 *
	 * @param mixed $selected Selected identifiers.
	 * @return array
	 */

	public static function sanitize_selection( $selected ) {
		if( ! is_array( $selected ) ) {
			return array();
		}

		$available = self::services();
		$selection = array();

		foreach( $selected as $service ) {
			$service = sanitize_key( $service );

			if( isset( $available[$service] ) && ! in_array( $service, $selection, true ) ) {
				$selection[] = $service;
			}
		}

		return $selection;
	}

	/**
	 * Return sharing data for the current frontend document.
	 *
	 * @return array
	 */

	public static function context() {
		$post_id = get_queried_object_id();
		$url = $post_id ? get_permalink( $post_id ) : '';
		$title = $post_id ? get_the_title( $post_id ) : '';
		$image = $post_id && has_post_thumbnail( $post_id ) ? get_the_post_thumbnail_url( $post_id, 'full' ) : '';

		if( ! $url ) {
			$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
			$url = home_url( $request_uri );
		}

		return array(
			'url' => esc_url_raw( $url ),
			'title' => sanitize_text_field( $title ?: wp_get_document_title() ),
			'image' => esc_url_raw( $image ),
		);
	}

	/**
	 * Build a sharing URL without contacting the destination service.
	 *
	 * @param string $service Service identifier.
	 * @param array  $context Current document data.
	 * @return string
	 */

	public static function url( $service, $context ) {
		$url = (string) ( $context['url'] ?? '' );
		$title = (string) ( $context['title'] ?? '' );
		$image = (string) ( $context['image'] ?? '' );

		switch( $service ) {
			case 'facebook':
				return self::build_url( 'https://www.facebook.com/sharer/sharer.php', array( 'u' => $url ) );
			case 'x':
				return self::build_url( 'https://twitter.com/intent/tweet', array( 'url' => $url, 'text' => $title ) );
			case 'linkedin':
				return self::build_url( 'https://www.linkedin.com/sharing/share-offsite/', array( 'url' => $url ) );
			case 'bluesky':
				return self::build_url( 'https://bsky.app/intent/compose', array( 'text' => trim( $title . ' ' . $url ) ) );
			case 'reddit':
				return self::build_url( 'https://www.reddit.com/submit', array( 'url' => $url, 'title' => $title ) );
			case 'whatsapp':
				return self::build_url( 'https://api.whatsapp.com/send', array( 'text' => trim( $title . ' ' . $url ) ) );
			case 'telegram':
				return self::build_url( 'https://t.me/share/url', array( 'url' => $url, 'text' => $title ) );
			case 'pinterest':
				return $image ? self::build_url( 'https://pinterest.com/pin/create/button/', array( 'url' => $url, 'media' => $image, 'description' => $title ) ) : '';
			case 'email':
				return 'mailto:?' . http_build_query( array( 'subject' => $title, 'body' => $url ), '', '&', PHP_QUERY_RFC3986 );
		}

		return '';
	}

	/**
	 * Append an RFC 3986 query without allowing a shared URL's own parameters
	 * to escape into the destination service query.
	 *
	 * WordPress add_query_arg() deliberately returns display-oriented URLs and
	 * does not preserve this nested URL boundary reliably for every service.
	 *
	 * @param string $base Base sharing endpoint.
	 * @param array  $args Query arguments.
	 * @return string
	 */

	private static function build_url( $base, $args ) {
		$query = http_build_query( $args, '', '&', PHP_QUERY_RFC3986 );

		return $query ? $base . ( strpos( $base, '?' ) === false ? '?' : '&' ) . $query : $base;
	}

	/**
	 * Return the local SVG used for a sharing service.
	 *
	 * @param string $service Service identifier.
	 * @return string
	 */

	public static function icon( $service ) {
		$definition = self::service( $service );
		$icon = $definition['icon'] ?? '';

		return $icon ? wphave_svg_ui_icon( $icon, array( 'inline' => true ) ) : '';
	}
}

endif;
