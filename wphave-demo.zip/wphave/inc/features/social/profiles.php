<?php

/**
 * Normalize social profiles and resolve network presentation data.
 *
 * @package wphave
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

if( ! class_exists( 'WPHAVE_Social_Profiles' ) ) :

/**
 * Own the shared social-profile data contract.
 */

class WPHAVE_Social_Profiles {

	const MAX_PROFILES = 20;
	const MAX_LABEL_LENGTH = 120;
	const MAX_ICON_KEY_LENGTH = 191;
	const MAX_ICON_SVG_LENGTH = 20000;

	/**
	 * Register the site-settings write normalizer.
	 *
	 * @return void
	 */

	public static function init() {
		add_filter( 'wphave_prepare_site_settings_for_write', array( __CLASS__, 'sanitize_site_settings' ), 10, 2 );
	}

	/**
	 * Return supported social-network presentation data.
	 *
	 * Match terms are ordered from specific to general. The X term is matched
	 * as a complete icon-key segment so it can never consume Xing.
	 *
	 * @return array
	 */

	public static function networks() {
		$networks = array(
			'facebook-messenger' => array( 'color' => '#0078FF', 'strings' => array( 'facebook-messenger', 'messenger' ) ),
			'open-street-map' => array( 'color' => '#47c391', 'strings' => array( 'open-street-map' ) ),
			'google-maps' => array( 'color' => '#3fa559', 'strings' => array( 'google-maps', 'google-map' ) ),
			'linkedin' => array( 'color' => '#0077B5', 'strings' => array( 'linkedin', 'linked-in' ) ),
			'instagram' => array( 'color' => '#f00075', 'strings' => array( 'instagram', 'insta' ) ),
			'soundcloud' => array( 'color' => '#ff8800', 'strings' => array( 'soundcloud', 'sound-cloud' ) ),
			'pinterest' => array( 'color' => '#E60023', 'strings' => array( 'pinterest' ) ),
			'facebook' => array( 'color' => '#1778F2', 'strings' => array( 'facebook', 'face-book' ) ),
			'whatsapp' => array( 'color' => '#25d366', 'strings' => array( 'whatsapp' ) ),
			'snapchat' => array( 'color' => '#FFFC00', 'foreground' => '#111111', 'strings' => array( 'snapchat', 'snap-chat' ) ),
			'youtube' => array( 'color' => '#FF0000', 'strings' => array( 'youtube', 'you-tube' ) ),
			'twitter' => array( 'color' => '#00acee', 'strings' => array( 'twitter' ) ),
			'xing' => array( 'color' => '#026466', 'strings' => array( 'xing' ) ),
			'flickr' => array( 'color' => '#fc1685', 'strings' => array( 'flickr' ) ),
			'envelope' => array( 'color' => '#777777', 'strings' => array( 'envelope' ) ),
			'tumblr' => array( 'color' => '#36465D', 'strings' => array( 'tumblr' ) ),
			'dribbble' => array( 'color' => '#ea4c89', 'strings' => array( 'dribbble' ) ),
			'reddit' => array( 'color' => '#5f99cf', 'strings' => array( 'reddit' ) ),
			'vimeo' => array( 'color' => '#1ab7ea', 'strings' => array( 'vimeo' ) ),
			'rss' => array( 'color' => '#f26522', 'strings' => array( 'rss' ) ),
			'bing' => array( 'color' => '#008172', 'strings' => array( 'bing-map', 'bing-maps' ) ),
			'x' => array( 'color' => '#1e3050', 'strings' => array( 'x' ) ),
		);

		return apply_filters( 'wphave_social_networks', $networks );
	}

	/**
	 * Resolve a network color from an icon key.
	 *
	 * @param string $icon_key Stored icon key.
	 * @return string
	 */

	public static function color( $icon_key ) {
		$network = self::network( $icon_key );

		return $network ? (string) ( self::networks()[$network]['color'] ?? '' ) : '';
	}

	/**
	 * Resolve an accessible icon foreground from an icon key.
	 *
	 * @param string $icon_key Stored icon key.
	 * @return string
	 */

	public static function foreground( $icon_key ) {
		$network = self::network( $icon_key );

		return $network ? (string) ( self::networks()[$network]['foreground'] ?? '#ffffff' ) : '';
	}

	/**
	 * Resolve a network identifier from an icon key.
	 *
	 * @param string $icon_key Stored icon key.
	 * @return string
	 */

	public static function network( $icon_key ) {
		$icon_key = strtolower( sanitize_key( (string) $icon_key ) );

		if( $icon_key === '' ) {
			return '';
		}

		foreach( self::networks() as $network => $data ) {
			foreach( $data['strings'] ?? array() as $term ) {
				if( self::icon_key_matches( $icon_key, $term ) ) {
					return $network;
				}
			}
		}

		return '';
	}

	/**
	 * Return sanitized profiles from the global site settings.
	 *
	 * @return array
	 */

	public static function get_profiles() {
		$profiles = wphave_data_get( 'site_settings', 'social.profiles', array() );
		$profiles = apply_filters( 'wphave_social_profiles', $profiles );

		return self::sanitize_profiles( $profiles );
	}

	/**
	 * Return normalized profiles that contain a visual icon for the Social Bar.
	 *
	 * @return array
	 */

	public static function get_renderable_profiles() {
		return array_values( array_filter( self::get_profiles(), function( $profile ) {
			return ! empty( $profile['icon']['svg'] );
		} ) );
	}

	/**
	 * Sanitize social profiles within a site-settings payload.
	 *
	 * @param array $data Incoming site settings.
	 * @param array $config Resource configuration.
	 * @return array
	 */

	public static function sanitize_site_settings( $data, $config = array() ) {
		if( isset( $data['social']['profiles'] ) ) {
			$data['social']['profiles'] = self::sanitize_profiles( $data['social']['profiles'] );
		}

		return $data;
	}

	/**
	 * Normalize, limit and deduplicate a profile collection.
	 *
	 * @param mixed $profiles Raw profiles.
	 * @return array
	 */

	public static function sanitize_profiles( $profiles ) {
		if( ! is_array( $profiles ) ) {
			return array();
		}

		$sanitized = array();
		$seen_urls = array();
		$seen_ids = array();

		foreach( array_slice( $profiles, 0, self::MAX_PROFILES ) as $profile ) {
			$profile = self::sanitize_profile( $profile );

			if( empty( $profile ) || isset( $seen_urls[$profile['url']] ) ) {
				continue;
			}

			// DATA INVARIANT: Profile references are unique and stable because Social
			// blocks persist selections by ID rather than by mutable list position.
			if( isset( $seen_ids[$profile['id']] ) ) {
				$profile['id'] = self::unique_generated_profile_id( $profile['url'], $seen_ids );
			}

			$seen_urls[$profile['url']] = true;
			$seen_ids[$profile['id']] = true;
			$sanitized[] = $profile;
		}

		return $sanitized;
	}

	/**
	 * Normalize one social profile.
	 *
	 * A valid URL is sufficient for identity and Schema.org usage. The Social
	 * Bar applies the stricter visual requirement through get_renderable_profiles().
	 *
	 * @param mixed $profile Raw profile.
	 * @return array
	 */

	public static function sanitize_profile( $profile ) {
		if( ! is_array( $profile ) ) {
			return array();
		}

		$url = esc_url_raw( trim( (string) ( $profile['url'] ?? '' ) ), array( 'http', 'https' ) );
		$icon = self::sanitize_icon( $profile['icon'] ?? array() );

		if( $url === '' ) {
			return array();
		}

		$label = sanitize_text_field( (string) ( $profile['label'] ?? '' ) );
		$label = function_exists( 'mb_substr' ) ? mb_substr( $label, 0, self::MAX_LABEL_LENGTH ) : substr( $label, 0, self::MAX_LABEL_LENGTH );

		$sanitized = array(
			'id' => self::profile_id( $profile, $url ),
			'label' => $label,
			'url' => $url,
		);

		if( ! empty( $icon ) ) {
			$sanitized['icon'] = $icon;
		}

		return $sanitized;
	}

	/**
	 * Preserve or create the stable identifier used by Social blocks.
	 *
	 * @param array  $profile Raw profile.
	 * @param string $url Sanitized profile URL.
	 * @return string
	 */

	private static function profile_id( $profile, $url ) {
		$id = sanitize_key( (string) ( $profile['id'] ?? '' ) );

		if( $id !== '' ) {
			return $id;
		}

		return self::generated_profile_id( $url );
	}

	/**
	 * Build the deterministic fallback used by persisted block references.
	 *
	 * @param string $url Sanitized profile URL.
	 * @return string
	 */

	private static function generated_profile_id( $url ) {
		return 'profile-' . substr( hash( 'sha256', $url ), 0, 16 );
	}

	/**
	 * Resolve the extremely rare collision with another explicit or generated ID.
	 *
	 * @param string $url Sanitized profile URL.
	 * @param array  $seen_ids IDs already owned by earlier profiles.
	 * @return string
	 */

	private static function unique_generated_profile_id( $url, $seen_ids ) {
		$base = self::generated_profile_id( $url );
		$candidate = $base;
		$suffix = 2;

		while( isset( $seen_ids[$candidate] ) ) {
			$candidate = $base . '-' . $suffix;
			$suffix++;
		}

		return $candidate;
	}

	/**
	 * Return a useful accessible label for a normalized profile.
	 *
	 * @param array $profile Normalized profile.
	 * @return string
	 */

	public static function label( $profile ) {
		$label = trim( (string) ( $profile['label'] ?? '' ) );

		if( $label !== '' ) {
			return $label;
		}

		$host = wp_parse_url( $profile['url'] ?? '', PHP_URL_HOST );
		$host = preg_replace( '/^www\./i', '', (string) $host );

		return $host ?: __( 'Social profile', 'wphave' );
	}

	/**
	 * Sanitize a stored IconPicker descriptor.
	 *
	 * @param mixed $icon Raw icon descriptor.
	 * @return array
	 */

	private static function sanitize_icon( $icon ) {
		if( ! is_array( $icon ) ) {
			return array();
		}

		$key = sanitize_key( substr( (string) ( $icon['key'] ?? '' ), 0, self::MAX_ICON_KEY_LENGTH ) );
		$svg = substr( (string) ( $icon['svg'] ?? '' ), 0, self::MAX_ICON_SVG_LENGTH );
		$svg = self::sanitize_icon_svg( $svg );

		if( $key === '' || $svg === '' ) {
			return array();
		}

		return array(
			'key' => $key,
			'svg' => $svg,
		);
	}

	/**
	 * Sanitize inline SVG markup through the central SVG policy.
	 *
	 * @param string $svg Raw SVG markup.
	 * @return string
	 */

	private static function sanitize_icon_svg( $svg ) {
		if( $svg === '' || stripos( $svg, '<svg' ) === false || ! class_exists( 'DOMDocument' ) || ! class_exists( 'WPHAVE_Safe_SVG' ) ) {
			return '';
		}

		$previous = libxml_use_internal_errors( true );
		$document = new DOMDocument();
		$loaded = $document->loadXML( $svg, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING );
		libxml_clear_errors();
		libxml_use_internal_errors( $previous );

		if( ! $loaded || ! $document->documentElement || strtolower( $document->documentElement->tagName ) !== 'svg' ) {
			return '';
		}

		if( ! WPHAVE_Safe_SVG::sanitize_document( $document ) ) {
			return '';
		}

		return (string) $document->saveXML( $document->documentElement );
	}

	/**
	 * Check one network term against a normalized icon key.
	 *
	 * @param string $icon_key Normalized icon key.
	 * @param string $term Match term.
	 * @return bool
	 */

	private static function icon_key_matches( $icon_key, $term ) {
		if( $term === 'x' ) {
			return (bool) preg_match( '/(^|[-_])x($|[-_])/', $icon_key );
		}

		return str_contains( $icon_key, $term );
	}
}

WPHAVE_Social_Profiles::init();

endif;
