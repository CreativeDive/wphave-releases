<?php

require_once __DIR__ . '/atomic-file.php';
require_once __DIR__ . '/file-identity.php';
require_once __DIR__ . '/conditional-file.php';

if (!class_exists('WPHAVE_Safe_SVG')):
	/**
	 * Sanitizes SVG files for upload usage.
	 *
	 * The sanitizer keeps normal SVG drawing primitives, gradients and safe
	 * inline styles intact while removing scriptable elements, event attributes
	 * and external references.
	 */

	class WPHAVE_Safe_SVG {
		const MAX_FILE_SIZE = 2097152;
		const MAX_ELEMENTS = 25000;

		/**
		 * Sanitize SVG markup held in memory.
		 *
		 * This uses the same strict element and attribute policy as uploaded SVG
		 * files, allowing generated UI icons to share one audited trust boundary.
		 *
		 * @param string $svg Raw SVG markup.
		 * @return string|false Sanitized SVG markup or false when invalid.
		 */

		public static function sanitize_markup($svg) {
			if (
				!is_string($svg) ||
				!$svg ||
				strlen($svg) > self::MAX_FILE_SIZE ||
				// SVG WORK INVARIANT: A compact tag flood must be rejected before
				// libxml builds a large tree or the sanitizer traverses it.
				substr_count($svg, '<') > self::MAX_ELEMENTS ||
				stripos($svg, '<svg') === false
			) {
				return false;
			}

			$document = self::load_document($svg);

			if (!$document || !self::sanitize_document($document)) {
				return false;
			}

			$sanitized = $document->saveXML($document->documentElement);

			return $sanitized && self::load_document($sanitized) ? $sanitized : false;
		}

		/**
		 * Normalize a color used by generated SVG markup.
		 *
		 * The intentionally small grammar covers WPHAVE presets and standard
		 * CSS colors without allowing attribute or declaration injection.
		 *
		 * @param string $color Requested color.
		 * @return string Safe color value.
		 */

		public static function sanitize_color($color) {
			$color = trim((string) $color);

			// Declaration delimiters, markup and executable CSS constructs can
			// never be part of one color value.
			if (
				!$color ||
				preg_match('/[\x00-\x1f\x7f;<>{}"\'\\\\]/', $color) ||
				preg_match('/(?:url|expression)\s*\(|[!@]/i', $color)
			) {
				return 'currentColor';
			}

			// Keep hexadecimal and named colors, including CSS-wide keywords.
			if (preg_match('/^#[0-9a-f]{3,8}$/i', $color) || preg_match('/^[a-z]+$/i', $color)) {
				return $color;
			}

			/*
			 * Modern CSS color functions use spaces, slash alpha values and
			 * nested var()/calc() fallbacks. Restrict the function family and
			 * character grammar, then verify balanced parentheses so valid CSS
			 * is preserved without accepting an additional declaration.
			 */
			$allowed_functions =
				'(?:rgb|rgba|hsl|hsla|hwb|lab|lch|oklab|oklch|color|color-mix|light-dark|var)';
			if (
				preg_match('/^' . $allowed_functions . '\([a-z0-9#%.,+\-*\/_\s()]+\)$/i', $color) &&
				self::has_balanced_parentheses($color)
			) {
				return $color;
			}

			return 'currentColor';
		}

		/**
		 * Determine whether a CSS function value has balanced parentheses.
		 *
		 * @param string $value CSS function value.
		 * @return bool Whether every opening parenthesis is closed in order.
		 */

		private static function has_balanced_parentheses($value) {
			$depth = 0;

			foreach (str_split($value) as $character) {
				if ($character === '(') {
					$depth++;
				} elseif ($character === ')') {
					$depth--;
					if ($depth < 0) {
						return false;
					}
				}
			}

			return $depth === 0;
		}

		/**
		 * Normalize a whitespace-separated SVG class list.
		 *
		 * @param string $classes Requested class names.
		 * @return string Safe class list.
		 */

		public static function sanitize_classes($classes) {
			$classes = preg_split('/\s+/', trim((string) $classes));

			return implode(' ', array_filter(array_map('sanitize_html_class', $classes)));
		}

		/**
		 * Sanitizes one SVG file in place.
		 *
		 * @param string $file Absolute file path.
		 * @return bool
		 */

		public static function sanitize_file($file) {
			return self::sanitize_file_with_reason($file) === null;
		}

		/**
		 * Sanitize one SVG and return a safe failure category for upload feedback.
		 * Null means the sanitized bytes were committed successfully.
		 *
		 * @return null|'unreadable'|'invalid'|'storage'
		 */
		public static function sanitize_file_with_reason($file): ?string {
			$prepared = self::prepare_file_contents($file);
			if (isset($prepared['failure'])) {
				return $prepared['failure'];
			}

			$svg = $prepared['original'];
			$sanitized = $prepared['sanitized'];
			$temporary = trailingslashit(dirname($file)) . '.wphave-svg-' . wp_generate_uuid4();
			$sanitized_checksum = hash('sha256', $sanitized);

			// SECURITY INVARIANT: Never partially rewrite a reusable source in place.
			// Commit only if the live path still contains the revision sanitized.
			try {
				WPHAVE_Security_Atomic_File::write(
					$temporary,
					$sanitized,
					__('The sanitized SVG could not be staged safely.', 'wphave'),
				);
				static::before_file_commit($file);
				WPHAVE_Security_Conditional_File::replace_if_matches(
					$file,
					hash('sha256', $svg),
					$temporary,
					$sanitized_checksum,
					__('The SVG changed before sanitized bytes could be committed.', 'wphave'),
				);
			} catch (RuntimeException $error) {
				self::cleanup_staged_file($temporary, $sanitized_checksum);
				return 'storage';
			}

			// COMMIT INVARIANT: Sanitized bytes are already published. Failure to
			// remove their staging source cannot turn that success into rejection.
			self::cleanup_staged_file($temporary, $sanitized_checksum);
			return null;
		}

		/**
		 * Rewrite an unpublished PHP upload temporary file without sibling files.
		 * The caller must reject the upload if this returns a failure. A partial
		 * write can then affect only this uncommitted temporary file, never a live
		 * asset. Keeping the inode also preserves PHP's uploaded-file provenance.
		 *
		 * @return null|'unreadable'|'invalid'|'storage'
		 */
		public static function sanitize_temporary_file_with_reason($file): ?string {
			$prepared = self::prepare_file_contents($file);
			if (isset($prepared['failure'])) {
				return $prepared['failure'];
			}

			$original = $prepared['original'];
			$sanitized = $prepared['sanitized'];
			$handle = null;

			try {
				static::before_file_commit($file);
				clearstatcache(true, $file);
				$path_stat = @lstat($file);
				$regular_path =
					is_array($path_stat) &&
					($path_stat['mode'] & 0170000) === 0100000 &&
					$path_stat['nlink'] === 1 &&
					!is_link($file);
				$handle = $regular_path ? @fopen($file, 'r+b') : false;
				$opened = is_resource($handle) ? @fstat($handle) : false;
				if (
				!is_array($path_stat) ||
				!is_array($opened) ||
				($path_stat['mode'] & 0170000) !== 0100000 ||
					$path_stat['nlink'] !== 1 ||
				$path_stat['dev'] !== $opened['dev'] ||
				$path_stat['ino'] !== $opened['ino'] ||
					$opened['nlink'] !== 1 ||
				!@flock($handle, LOCK_EX)
				) {
				return 'storage';
				}

				clearstatcache(true, $file);
				$current = @lstat($file);
				$observed = @stream_get_contents($handle, self::MAX_FILE_SIZE + 1);
				$locked_stat = @fstat($handle);
				if (
				!is_array($current) ||
				!is_array($locked_stat) ||
				$current['dev'] !== $opened['dev'] ||
				$current['ino'] !== $opened['ino'] ||
					$current['nlink'] !== 1 ||
					$locked_stat['nlink'] !== 1 ||
				$locked_stat['size'] !== strlen($original) ||
				$observed !== $original ||
				!@rewind($handle)
				) {
				return 'storage';
				}

				if (!@ftruncate($handle, 0)) {
					return 'storage';
				}

				$offset = 0;
				$length = strlen($sanitized);
				while ($offset < $length) {
					$written = @fwrite($handle, substr($sanitized, $offset));
					if ($written === false || $written === 0) {
						return 'storage';
					}
					$offset += $written;
				}

				if (!@fflush($handle) || !@rewind($handle)) {
					return 'storage';
				}
				$verified = @stream_get_contents($handle, self::MAX_FILE_SIZE + 1);
				$final_stat = @fstat($handle);
				clearstatcache(true, $file);
				$final_path_stat = @lstat($file);
				if (
				$verified !== $sanitized ||
				!is_array($final_stat) ||
				!is_array($final_path_stat) ||
				$final_stat['size'] !== $length ||
				$final_stat['dev'] !== $opened['dev'] ||
				$final_stat['ino'] !== $opened['ino'] ||
					$final_stat['nlink'] !== 1 ||
				$final_path_stat['dev'] !== $opened['dev'] ||
					$final_path_stat['ino'] !== $opened['ino'] ||
					$final_path_stat['nlink'] !== 1
				) {
				return 'storage';
				}

				return @fclose($handle) ? null : 'storage';
			} catch (Throwable $error) {
				return 'storage';
			} finally {
				if (is_resource($handle)) {
					@fclose($handle);
				}
			}
		}

		/** Read and sanitize one stable bounded source for either file policy. */
		private static function prepare_file_contents($file): array {
			try {
				$original = WPHAVE_Security_File_Identity::read_bounded(
					$file,
					self::MAX_FILE_SIZE + 1,
					false,
					__('The SVG source could not be inspected safely.', 'wphave'),
				);
			} catch (RuntimeException $error) {
				return ['failure' => 'unreadable'];
			}

			// SVG UPLOAD MEMORY INVARIANT: A rejected oversized upload must never
			// be read fully into PHP memory before its size is checked.
			if ($original['sizeBytes'] <= 0 || $original['truncated'] || $original['sizeBytes'] > self::MAX_FILE_SIZE) {
				return ['failure' => 'invalid'];
			}

			$svg = $original['content'];
			if (!$svg || stripos($svg, '<svg') === false) {
				return ['failure' => 'invalid'];
			}

			$sanitized = self::sanitize_markup($svg);

			if (!$sanitized) {
				return ['failure' => 'invalid'];
			}

			return [
				'original' => $svg,
				'sanitized' => $sanitized,
			];
		}

		/**
		 * Accept only bytes that already satisfy the canonical sanitizer policy.
		 * MIME detection is read-only and may be called without an upload prefilter.
		 */
		public static function is_sanitized_file($file): bool {
			try {
				$observation = WPHAVE_Security_File_Identity::read_bounded(
					$file,
					self::MAX_FILE_SIZE + 1,
					false,
					__('The SVG source could not be inspected safely.', 'wphave'),
				);
			} catch (RuntimeException $error) {
				return false;
			}

			if ($observation['sizeBytes'] <= 0 || $observation['truncated']) {
				return false;
			}

			$canonical = self::sanitize_markup($observation['content']);

			// CLASSIFICATION INVARIANT: A .svg suffix never grants image MIME to
			// unsanitized bytes, even when a caller bypasses WordPress upload hooks.
			return is_string($canonical) && hash_equals($canonical, $observation['content']);
		}

		/** Testable boundary immediately before conditional SVG publication. */

		protected static function before_file_commit($file) {
			// Intentionally empty. Subclasses may instrument this phase boundary.
		}

		/** Removes only staging bytes created by this sanitization attempt. */

		private static function cleanup_staged_file(string $temporary, string $checksum): void {
			try {
				WPHAVE_Security_Conditional_File::remove_if_matches(
					$temporary,
					$checksum,
					__('Sanitized SVG staging could not be cleaned up safely.', 'wphave'),
				);
			} catch (RuntimeException $error) {
				// Preserve an unproven staging node rather than deleting a foreign file.
			}
		}

		/**
		 * Removes unsafe tags and attributes from an SVG document.
		 *
		 * @param DOMDocument $document Parsed SVG document.
		 * @return bool
		 */

		public static function sanitize_document(DOMDocument $document) {
			// SVG WORK INVARIANT: DOMNodeList is live; repeated indexed lookups
			// while mutating the tree grow quadratically with element count.
			// Snapshot once, then sanitize each original node in reverse order.
			$nodes = iterator_to_array($document->getElementsByTagName('*'));
			if (count($nodes) > self::MAX_ELEMENTS) {
				return false;
			}
			$allowed_tags = self::allowed_tags();
			$allowed_attributes = self::allowed_attributes();

			for ($i = count($nodes) - 1; $i >= 0; $i--) {
				$node = $nodes[$i];
				$tag = strtolower($node->localName ?: $node->nodeName);

				if (!in_array($tag, $allowed_tags, true)) {
					$node->parentNode->removeChild($node);
					continue;
				}

				if ($tag === 'style') {
					$css = self::sanitize_css($node->textContent);

					if ($css === false) {
						$node->parentNode->removeChild($node);
						continue;
					}

					$node->nodeValue = '';
					$node->appendChild($document->createTextNode($css));
				}

				if (!$node->hasAttributes()) {
					continue;
				}

				foreach (iterator_to_array($node->attributes) as $attribute) {
					$name = strtolower($attribute->name);
					$value = trim($attribute->value);
					$normalized_value = strtolower(
						preg_replace(
							'/\s+/',
							'',
							html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8'),
						),
					);

					if (
						str_starts_with($name, 'on') ||
						!in_array($name, $allowed_attributes, true)
					) {
						$node->removeAttributeNode($attribute);
						continue;
					}

					if (
						in_array($name, ['href', 'xlink:href', 'src'], true) &&
						!str_starts_with($value, '#')
					) {
						$node->removeAttributeNode($attribute);
						continue;
					}

					if ($name === 'style') {
						// SVG-STYLE INVARIANT: WordPress permits HTTPS url() in general
						// inline CSS. SVG uploads have a stricter no-external-reference
						// contract, so validate internal-only references before KSES.
						$internal_css = self::sanitize_css($value);
						$css = $internal_css !== false && function_exists('safecss_filter_attr')
							? safecss_filter_attr($internal_css)
							: $internal_css;

						if (!$css) {
							$node->removeAttributeNode($attribute);
							continue;
						}

						$node->setAttribute($attribute->name, $css);
						continue;
					}

					// SVG-PAINT INVARIANT: Paint/filter attributes are CSS value
					// sinks too. A safe href alone does not prevent an uploaded
					// image from fetching an external resource while it is viewed.
					if (
						in_array($name, ['fill', 'stroke', 'filter', 'mask', 'clip-path', 'marker'], true) &&
						self::sanitize_css($value) === false
					) {
						$node->removeAttributeNode($attribute);
						continue;
					}

					if (
						str_contains($normalized_value, 'javascript:') ||
						str_contains($normalized_value, 'data:') ||
						str_contains($normalized_value, 'vbscript:')
					) {
						$node->removeAttributeNode($attribute);
					}
				}
			}

			return true;
		}

		/**
		 * Validates CSS used inside SVG style blocks and style attributes.
		 *
		 * @param string $css CSS string.
		 * @param bool $check_urls Whether url() values must be internal refs.
		 * @return string|false
		 */

		public static function sanitize_css($css, $check_urls = true) {
			$css = (string) $css;
			// CSS-REFERENCE INVARIANT: Escapes and comments can disguise the url
			// function from string-based admission while browsers still resolve it.
			// SVG CSS has no need for either construct; reject them outright.
			if (str_contains($css, '\\') || str_contains($css, '/*')) {
				return false;
			}
			$normalized_css = strtolower(
				preg_replace(
					'/\s+/',
					'',
					html_entity_decode($css, ENT_QUOTES | ENT_HTML5, 'UTF-8'),
				),
			);
			$unsafe_patterns = [
				'@import',
				'image-set(',
				'expression(',
				'javascript:',
				'data:',
				'vbscript:',
				'behavior:',
				'-moz-binding',
			];

			foreach ($unsafe_patterns as $pattern) {
				if (str_contains($normalized_css, $pattern)) {
					return false;
				}
			}

			if ($check_urls && preg_match_all('/url\(([^)]+)\)/i', $css, $matches)) {
				foreach ($matches[1] as $url) {
					$url = trim($url, " \t\n\r\0\x0B'\"");

					if (!str_starts_with($url, '#')) {
						return false;
					}
				}
			}

			return $css;
		}

		/**
		 * Parses SVG XML with external entity loading disabled.
		 *
		 * @param string $svg Raw SVG string.
		 * @return DOMDocument|false
		 */

		private static function load_document($svg) {
			$previous = libxml_use_internal_errors(true);
			$document = new DOMDocument();
			$loaded = $document->loadXML($svg, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING);

			libxml_clear_errors();
			libxml_use_internal_errors($previous);

			if (
				!$loaded ||
				!$document->documentElement ||
				strtolower($document->documentElement->tagName) !== 'svg'
			) {
				return false;
			}

			return $document;
		}

		/**
		 * Returns the SVG elements allowed in uploaded files.
		 *
		 * @return array
		 */

		private static function allowed_tags() {
			return [
				'circle',
				'clippath',
				'defs',
				'desc',
				'ellipse',
				'fecolormatrix',
				'fecomponenttransfer',
				'fecomposite',
				'feconvolvematrix',
				'fediffuselighting',
				'fedisplacementmap',
				'fedropshadow',
				'feflood',
				'fefunca',
				'fefuncb',
				'fefuncg',
				'fefuncr',
				'fegaussianblur',
				'feimage',
				'femerge',
				'femergenode',
				'femorphology',
				'feoffset',
				'fespecularlighting',
				'fetile',
				'feturbulence',
				'filter',
				'g',
				'image',
				'line',
				'lineargradient',
				'marker',
				'mask',
				'path',
				'pattern',
				'polygon',
				'polyline',
				'radialgradient',
				'rect',
				'stop',
				'style',
				'svg',
				'symbol',
				'text',
				'title',
				'tspan',
				'use',
			];
		}

		/**
		 * Returns the SVG attributes allowed in uploaded files.
		 *
		 * Attribute names are lowercase because DOM attribute checks normalize
		 * before matching.
		 *
		 * @return array
		 */

		private static function allowed_attributes() {
			return [
				'aria-hidden',
				'aria-label',
				'aria-labelledby',
				'class',
				'color',
				'display',
				'visibility',
				'vector-effect',
				'lighting-color',
				'clip-path',
				'clip-rule',
				'clippathunits',
				'color-interpolation-filters',
				'cx',
				'cy',
				'd',
				'dx',
				'dy',
				'edgemode',
				'fill',
				'fill-opacity',
				'fill-rule',
				'filter',
				'filterunits',
				'flood-color',
				'flood-opacity',
				'focusable',
				'font-family',
				'font-size',
				'font-style',
				'font-weight',
				'gradienttransform',
				'gradientunits',
				'height',
				'href',
				'id',
				'in',
				'in2',
				'k1',
				'k2',
				'k3',
				'k4',
				'lengthadjust',
				'letter-spacing',
				'mask',
				'maskcontentunits',
				'maskunits',
				'mode',
				'offset',
				'opacity',
				'operator',
				'overflow',
				'patterncontentunits',
				'patterntransform',
				'patternunits',
				'points',
				'preserveaspectratio',
				'primitiveunits',
				'r',
				'result',
				'role',
				'rx',
				'ry',
				'scale',
				'stddeviation',
				'stop-color',
				'stop-opacity',
				'stroke',
				'stroke-dasharray',
				'stroke-dashoffset',
				'stroke-linecap',
				'stroke-linejoin',
				'stroke-miterlimit',
				'stroke-opacity',
				'stroke-width',
				'style',
				'surfacescale',
				'tablevalues',
				'text-anchor',
				'textlength',
				'title',
				'transform',
				'type',
				'values',
				'version',
				'viewbox',
				'width',
				'x',
				'x1',
				'x2',
				'xlink:href',
				'xml:space',
				'xmlns',
				'xmlns:xlink',
				'y',
				'y1',
				'y2',
			];
		}
	}
endif;
