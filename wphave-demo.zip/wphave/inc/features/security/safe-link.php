<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Validate WordPress-generated links before projecting them into browser UI. */
final class WPHAVE_Safe_Link {
	public static function local_or_http( mixed $candidate ): string {
		if (
			is_string( $candidate )
			&& strlen( $candidate ) <= 2048
			&& preg_match( '~^/(?!/)[^\\x00-\\x20\\\\]*$~', $candidate )
		) {
			// ROOT-PATH INVARIANT: Workspace routes may be root-relative, but
			// protocol-relative and backslash-normalized external URLs may not.
			return $candidate;
		}

		return self::http( $candidate );
	}

	public static function http( mixed $candidate ): string {
		// SECURITY INVARIANT: WordPress permalink/edit-link filters are not a trust
		// boundary. UI href values must remain bounded HTTP(S) URLs to hosts that
		// WordPress permits for safe redirects.
		if ( ! is_string( $candidate ) || '' === $candidate || strlen( $candidate ) > 2048 ) {
			return '';
		}

		if ( ! preg_match( '~^https?://~i', $candidate ) ) {
			return '';
		}
		$parts = wp_parse_url( $candidate );
		// CREDENTIAL-LINK INVARIANT: Core's redirect-host validation permits
		// URL userinfo. Projected UI links must never turn stored or filtered
		// credentials into browser Basic Authentication requests.
		if (
			! is_array( $parts )
			|| array_key_exists( 'user', $parts )
			|| array_key_exists( 'pass', $parts )
		) {
			return '';
		}

		if ( '' === wp_validate_redirect( $candidate, '' ) ) {
			return '';
		}

		return esc_url_raw( $candidate, [ 'http', 'https' ] );
	}

	public static function same_site_http( mixed $candidate ): string {
		$url = self::http( $candidate );
		$site = wp_parse_url( home_url( '/' ) );
		$target = $url ? wp_parse_url( $url ) : false;
		if ( ! is_array( $site ) || ! is_array( $target ) ) {
			return '';
		}

		$site_scheme = strtolower( (string) ( $site['scheme'] ?? '' ) );
		$target_scheme = strtolower( (string) ( $target['scheme'] ?? '' ) );
		$site_host = strtolower( (string) ( $site['host'] ?? '' ) );
		$target_host = strtolower( (string) ( $target['host'] ?? '' ) );
		$site_port = (int) ( $site['port'] ?? ( 'https' === $site_scheme ? 443 : 80 ) );
		$target_port = (int) ( $target['port'] ?? ( 'https' === $target_scheme ? 443 : 80 ) );

		// ORIGIN INVARIANT: Search indexes and other site-owned surfaces never
		// advertise a filtered URL with another scheme, host, port or credentials.
		return $site_scheme === $target_scheme &&
			'' !== $site_host &&
			hash_equals( $site_host, $target_host ) &&
			$site_port === $target_port &&
			! array_key_exists( 'user', $target ) &&
			! array_key_exists( 'pass', $target )
				? $url
				: '';
	}
}
