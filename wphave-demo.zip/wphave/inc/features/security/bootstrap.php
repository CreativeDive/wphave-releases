<?php

/**
 * Bootstrap frontend security services.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Determine whether Security Pro settings may be changed.
 *
 * Existing hardening remains active after a downgrade. The entitlement only
 * controls configuration changes, scanner details and scan automation.
 *
 * @return bool Whether a valid Pro entitlement is available.
 */

function wphave_security_has_pro_access() {
	return function_exists( 'wphave_has_pro_access' ) && wphave_has_pro_access();
}

/**
 * Preserve stored Pro hardening while allowing Free security controls to save.
 *
 * This server-side boundary prevents direct resource requests from changing
 * Pro settings. It intentionally does not disable stored hardening because a
 * downgrade must never reopen protected endpoints, files or login surfaces.
 *
 * @param array $data Prepared site settings.
 * @param array $config Site-settings resource configuration.
 * @return array Entitlement-safe site settings.
 */

function wphave_preserve_security_pro_settings( array $data, array $config ): array {
	if( wphave_security_has_pro_access() || ! class_exists( 'WPHAVE_Data_Resources' ) ) return $data;

	$current = WPHAVE_Data_Resources::get( 'site_settings', false );
	$current_security = $current['advanced']['security'] ?? [];
	$requested_security = $data['advanced']['security'] ?? [];

	if( ! is_array( $current_security ) || ! is_array( $requested_security ) ) return $data;

	$security = $current_security;
	$free_settings = [
		'disable_file_editing',
		'wp_xml_rpc',
		'disable_user_enumeration',
		'login_rate_limiting',
		'unify_login_feedback',
	];

	foreach( $free_settings as $key ) {
		if( array_key_exists( $key, $requested_security ) ) {
			$security[$key] = $requested_security[$key];
		}
	}

	$data['advanced']['security'] = $security;

	return $data;
}

add_filter( 'wphave_prepare_site_settings_for_write', 'wphave_preserve_security_pro_settings', 20, 2 );

require_once __DIR__ . '/crypto.php';
require_once __DIR__ . '/email-protection.php';
require_once __DIR__ . '/safe-svg.php';
require_once __DIR__ . '/kses.php';
require_once __DIR__ . '/manager.php';
