<?php

/** Shared server-side password policy for WPHAVE credential mutations. */

if (!defined('ABSPATH')) {
	exit();
}

final class WPHAVE_Password_Policy {
	public const MAX_BYTES = 4096;

	/** Match the user-facing strength requirements at every credential write. */
	public static function accepts($password): bool {
		if (!is_string($password)) {
			return false;
		}

		$bytes = strlen($password);
		return $bytes >= 8 &&
			$bytes <= self::MAX_BYTES &&
			(bool) preg_match('/[A-Z]/', $password) &&
			(bool) preg_match('/[a-z]/', $password) &&
			(bool) preg_match('/\d/', $password) &&
			(bool) preg_match('/[^A-Za-z0-9]/', $password);
	}
}
