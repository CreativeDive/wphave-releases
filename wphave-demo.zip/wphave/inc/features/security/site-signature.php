<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WPHAVE_Site_Signature' ) ) :
	/** Purpose- and blog-bound integrity signatures for local diagnostic records. */
	final class WPHAVE_Site_Signature {
		public static function sign( string $purpose, $payload ): string {
			// SIGNATURE INVARIANT: Non-encodable data cannot be trusted or signed;
			// callers fail closed when this helper returns an empty signature.
			$encoded = wp_json_encode( $payload );
			if ( ! is_string( $encoded ) ) {
				return '';
			}

			// DOMAIN-SEPARATION INVARIANT: Purpose and blog ID prevent a valid
			// record from being replayed across modules or Multisite blogs.
			return hash_hmac(
				'sha256',
				'wphave-' . $purpose . "\0" . get_current_blog_id() . "\0" . $encoded,
				wp_salt( 'auth' )
			);
		}
	}
endif;
