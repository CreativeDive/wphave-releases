<?php

/**
 * WPHAVE Security Scanner
 *
 * Runs resumable integrity and security-posture checks, stores normalized
 * findings and coordinates manual or scheduled scan workflows.
 */

if (!defined('ABSPATH')) {
	exit();
}

require_once wphave_dir() . 'inc/features/security/boundaries/index.php';
require_once wphave_dir() . 'inc/features/security/email-identity.php';
require_once wphave_dir() . 'inc/background-jobs/lock.php';

require_once dirname(__DIR__, 2) . '/helpers/php-support.php';
require_once dirname(__DIR__, 2) . '/helpers/database-support.php';

class WPHAVE_Security_Scanner {
	const RESULTS_OPTION = 'wphave_security_scan_results';
	const JOB_OPTION = 'wphave_security_scan_job';
	const LOCK_OPTION = 'wphave_security_scan_lock';
	const CANCEL_OPTION = 'wphave_security_scan_cancel_requested';
	const AUTOMATION_LOCK_OPTION = 'wphave_security_scan_automation_lock';
	const SCHEDULE_OPTION = 'wphave_security_scan_schedule';
	const NOTIFIED_OPTION = 'wphave_security_scan_notified_findings';
	const NOTIFICATION_OPTION = 'wphave_security_scan_last_notification';
	const LAST_AUTOMATIC_OPTION = 'wphave_security_scan_last_automatic';
	const CRON_HOOK = 'wphave_security_scan_cron';
	const MAX_FINDINGS = 1000;
	const MAX_TOTAL_TASKS = 100000;
	const MAX_CORE_TASKS = 15000;
	const MAX_UPLOAD_TASKS = 25000;
	const MAX_PLUGIN_TASKS = 60000;
	const BATCH_SIZE = 250;
	const MAX_BATCH_TIME = 20;
	const MAX_AUTOMATION_TIME = 25;
	const MAX_DISCOVERY_TIME_PER_AREA = 10;
	const MAX_SENSITIVE_CANDIDATES = 250;
	const MAX_CHECKSUM_MANIFEST_BYTES = 2 * MB_IN_BYTES;
	const MAX_DIRECTORY_LISTING_BYTES = 16 * KB_IN_BYTES;
	const MAX_USER_ENUMERATION_BYTES = 64 * KB_IN_BYTES;
	const LOCK_TTL = 10 * MINUTE_IN_SECONDS;
	private static bool $routes_registered = false;

	/**
	 * Initialize cron and recovery hooks.
	 *
	 * @return void
	 */

	public static function init(): void {
		// RUNTIME INVARIANT: management.php exclusively owns REST discovery.
		// scanner.php is also the worker engine, so registering routes here would
		// couple Cron automation to an unreachable interactive surface.
		$can_manage_workflow =
			is_admin() ||
			wp_doing_cron() ||
			(defined('REST_REQUEST') && REST_REQUEST) ||
			(defined('WP_CLI') && WP_CLI);

		if ($can_manage_workflow) {
			add_action('init', [__CLASS__, 'sync_cron_schedule']);
			add_action('init', [__CLASS__, 'recover_interrupted_scan'], 20);
		}

		add_action(self::CRON_HOOK, [__CLASS__, 'run_scheduled_scan'], 10, 1);
	}

	/**
	 * Register security scanner REST routes.
	 *
	 * @return void
	 */

	public static function register_rest_routes(): void {
		if (self::$routes_registered) {
			return;
		}

		self::$routes_registered = true;

		register_rest_route('wphave/v1', '/security-scan/start', [
			'methods' => 'POST',
			'callback' => [__CLASS__, 'rest_start'],
			'permission_callback' => [__CLASS__, 'can_manage'],
			'args' => [],
		]);

		register_rest_route('wphave/v1', '/security-scan/process', [
			'methods' => 'POST',
			'callback' => [__CLASS__, 'rest_process'],
			'permission_callback' => [__CLASS__, 'can_manage'],
			'args' => [],
		]);

		register_rest_route('wphave/v1', '/security-scan/results', [
			'methods' => 'GET',
			'callback' => [__CLASS__, 'rest_results'],
			'permission_callback' => [__CLASS__, 'can_manage'],
		]);
	}

	/**
	 * Determine whether the current user can manage security scans.
	 *
	 * @return bool Whether access is allowed.
	 */

	public static function can_manage(): bool {
		return current_user_can('manage_options') ||
			current_user_can('wphave_manage_settings_security');
	}

	/** Handle the start-scan REST request. */

	public static function rest_start() {
		$authorization = self::require_rest_access();
		if (is_wp_error($authorization)) {
			return $authorization;
		}

		$result = self::start();

		return is_wp_error($result)
			? $result
			: self::rest_result_response($result);
	}

	/** Handle the process-batch REST request. */

	public static function rest_process() {
		$authorization = self::require_rest_access();
		if (is_wp_error($authorization)) {
			return $authorization;
		}

		$result = self::process_batch();

		return is_wp_error($result)
			? $result
			: self::rest_result_response($result);
	}

	/** Return the current scan result through REST. */

	public static function rest_results() {
		$authorization = self::require_rest_access();
		if (is_wp_error($authorization)) {
			return $authorization;
		}

		return self::rest_result_response(self::get_results());
	}

	/** Release one projected scanner result only under current authority. */
	private static function rest_result_response(array $results) {
		$prepared = self::prepare_rest_results($results);
		// DISCLOSURE INVARIANT: Scan results and Pro projection read filterable
		// state. An earlier permission decision cannot release paths or findings
		// after capability changes during result construction.
		$authorization = self::require_rest_access();
		if (is_wp_error($authorization)) {
			return $authorization;
		}

		return rest_ensure_response($prepared);
	}

	private static function require_rest_access() {
		// AUTHORIZATION INVARIANT: REST permission callbacks guard transport only.
		// HTTP wrappers re-check Security authority before job mutation or findings
		// disclosure; Cron calls the lower-level persisted-job services separately.
		if (self::can_manage()) {
			return true;
		}

		return new WP_Error(
			'wphave_security_scan_forbidden',
			__('You are not allowed to manage security scans.', 'wphave'),
			['status' => 403],
		);
	}

	/**
	 * Remove Pro analysis data from REST responses for free installations.
	 *
	 * Manual scanning, progress, coverage and severity totals remain available.
	 * Finding messages, paths, technical errors and per-check diagnostics never
	 * cross the REST boundary without verified Pro access.
	 *
	 * @param array $results Complete internal scan results.
	 * @return array Results appropriate for the current license tier.
	 */

	private static function prepare_rest_results(array $results): array {
		if (self::has_detail_access()) {
			return $results;
		}

		// SECURITY INVARIANT: License-restricted paths, messages and diagnostics are
		// removed from the server response itself. Client-side hiding is never the
		// confidentiality boundary for detailed scan data.
		$results['findings'] = [];
		$results['errors'] = [];
		$results['detailsRestricted'] = true;

		foreach ($results['checks'] ?? [] as $name => $check) {
			if (!is_array($check)) {
				continue;
			}

			$results['checks'][$name] = array_intersect_key($check, array_flip(['status']));
		}

		return $results;
	}

	/** Determine whether detailed scanner results may cross the REST boundary. */

	private static function has_detail_access(): bool {
		$allowed = function_exists('wphave_has_pro_access') && wphave_has_pro_access();

		return (bool) apply_filters('wphave_security_scan_details_access', $allowed);
	}

	/**
	 * Get normalized scan results and current automation status.
	 *
	 * @return array Normalized scan result.
	 */

	public static function get_results(): array {
		$results = get_option(self::RESULTS_OPTION, []);
		$results = is_array($results)
			? wp_parse_args($results, self::empty_results())
			: self::empty_results();
		$results['automation'] = self::get_automation_status($results);

		return $results;
	}

	/** Run a complete security scan synchronously. */

	public static function run() {
		$result = self::start();

		if (is_wp_error($result)) {
			return $result;
		}

		$stalled_batches = 0;
		while (($result['state'] ?? '') === 'running') {
			$processed = absint($result['processed'] ?? 0);
			$result = self::process_batch();

			if (is_wp_error($result)) {
				return $result;
			}

			if (absint($result['processed'] ?? 0) === $processed) {
				$stalled_batches++;

				if ($stalled_batches >= 3) {
					return new WP_Error(
						'wphave_security_scan_stalled',
						__('The security scan could not acquire its processing lock.', 'wphave'),
					);
				}

				usleep(100000);
			} else {
				$stalled_batches = 0;
			}
		}

		return $result;
	}

	/**
	 * Start a new scan or resume an active scan job.
	 *
	 * @param bool $scheduled Whether an automatic scan started the job.
	 * @return array|WP_Error Initial scan state or an error.
	 */

	public static function start(bool $scheduled = false) {
		$job = get_option(self::JOB_OPTION, []);
		$stale_job = false;
		if (is_array($job) && isset($job['tasks'], $job['processed'])) {
			$last_update = absint($job['updatedAt'] ?? ($job['createdAt'] ?? time()));

			if (time() - $last_update <= 30 * MINUTE_IN_SECONDS) {
				return self::get_results();
			}

			$stale_job = true;
		}

		$lock = self::acquire_lock();
		if (!$lock) {
			return new WP_Error(
				'wphave_security_scan_running',
				__('A security scan is already running.', 'wphave'),
				['status' => 409],
			);
		}

		$started_at = current_time('mysql');
		$checks = [
			'coreIntegrity' => ['status' => 'pending', 'checked' => 0, 'findings' => 0],
			'uploadExecutables' => ['status' => 'pending', 'checked' => 0, 'findings' => 0],
			'extensionIntegrity' => [
				'status' => 'pending',
				'checked' => 0,
				'findings' => 0,
				'verifiedPackages' => 0,
				'unavailablePackages' => 0,
			],
			'sensitiveExposure' => ['status' => 'pending', 'checked' => 0, 'findings' => 0],
			'securityPosture' => ['status' => 'pending', 'checked' => 0, 'findings' => 0],
		];
		$errors = [];

		try {
			if ($stale_job) {
				$current_job = get_option(self::JOB_OPTION, []);
				$current_update = is_array($current_job)
					? absint($current_job['updatedAt'] ?? ($current_job['createdAt'] ?? 0))
					: 0;
				if ($current_update && time() - $current_update <= 30 * MINUTE_IN_SECONDS) {
					return self::get_results();
				}

				delete_option(self::JOB_OPTION);
			}

			$job = self::create_job($started_at, $checks, $errors);
			$job['scheduled'] = $scheduled;
			$job['createdAt'] = time();
			$job['updatedAt'] = time();
			$results = [
				'state' => 'running',
				'startedAt' => $started_at,
				'finishedAt' => '',
				'processed' => 0,
				'total' => count($job['tasks']),
				'currentCheck' => self::task_check($job['tasks'][0]['type'] ?? ''),
				'findings' => [],
				'counts' => self::count_findings([]),
				'checks' => $checks,
				'errors' => $errors,
				'truncated' => !empty($job['truncated']),
				'coverageLimited' => !empty($job['truncated']),
				'findingsTruncated' => false,
				'limitedAreas' => $job['limitedAreas'],
				'scheduled' => $scheduled,
			];
			update_option(self::JOB_OPTION, $job, false);
			update_option(self::RESULTS_OPTION, $results, false);
			if (class_exists('WPHAVE_Activity_Log')) {
				WPHAVE_Activity_Log::record('security_scan.started', [
					'category' => 'security',
					'action' => 'started',
					'actor_type' => $scheduled ? 'cron' : null,
					'object_type' => 'scan',
					'object_label' => 'Security scan',
					'context' => [
						'total' => count($job['tasks']),
						'scheduled' => $scheduled,
					],
				]);
			}

			return $results;
		} finally {
			self::release_lock($lock);
		}
	}

	/**
	 * Process the next batch of queued scan tasks.
	 *
	 * @param int $max_time Maximum processing time for this batch.
	 * @return array|WP_Error Updated scan state or an error.
	 */

	public static function process_batch(int $max_time = self::MAX_BATCH_TIME) {
		$lock = self::acquire_lock();
		if (!$lock) {
			return self::get_results();
		}

		try {
			$job = get_option(self::JOB_OPTION, []);
			if (!is_array($job) || !isset($job['tasks'], $job['processed'])) {
				return self::get_results();
			}

			if (!empty($job['scheduled']) && get_option(self::CANCEL_OPTION, false)) {
				return self::finalize_cancelled_job();
			}

			$tasks = is_array($job['tasks']) ? array_values($job['tasks']) : [];
			$findings = is_array($job['findings'] ?? null) ? $job['findings'] : [];
			$finding_counts = is_array($job['findingCounts'] ?? null)
				? $job['findingCounts']
				: self::count_findings($findings);
			$checks = is_array($job['checks'] ?? null) ? $job['checks'] : [];
			$errors = is_array($job['errors'] ?? null) ? $job['errors'] : [];
			$processed = absint($job['processed']);
			$end = min(count($tasks), $processed + self::BATCH_SIZE);
			$batch_deadline = microtime(true) + max(1, min(self::MAX_BATCH_TIME, $max_time));

			for ($index = $processed; $index < $end; $index++) {
				$previous_finding_count = count($findings);
				self::process_task($tasks[$index], $job, $findings, $checks, $errors);

				foreach (array_slice($findings, $previous_finding_count) as $finding) {
					$severity = sanitize_key($finding['severity'] ?? '');
					$finding_counts['total'] = absint($finding_counts['total'] ?? 0) + 1;

					if (isset($finding_counts[$severity])) {
						$finding_counts[$severity]++;
					}
				}

				if (count($findings) > self::MAX_FINDINGS) {
					$findings = array_slice($findings, 0, self::MAX_FINDINGS);
				}

				$processed = $index + 1;
				if (microtime(true) >= $batch_deadline) {
					break;
				}
			}

			$complete = $processed >= count($tasks);
			self::finalize_completed_checks($tasks, $processed, $checks);
			if ($complete) {
				self::finalize_checks($checks);
			}
			$current_check = $complete ? '' : self::task_check($tasks[$processed]['type'] ?? '');
			$state = $complete ? (!empty($job['truncated']) ? 'partial' : 'complete') : 'running';
			$results = [
				'state' => $state,
				'startedAt' => sanitize_text_field($job['startedAt'] ?? ''),
				'finishedAt' => $complete ? current_time('mysql') : '',
				'processed' => $processed,
				'total' => count($tasks),
				'currentCheck' => $current_check,
				'findings' => array_values(array_slice($findings, 0, self::MAX_FINDINGS)),
				'counts' => $finding_counts,
				'checks' => $checks,
				'errors' => $errors,
				'truncated' =>
					!empty($job['truncated']) ||
					absint($finding_counts['total'] ?? 0) > self::MAX_FINDINGS,
				'coverageLimited' => !empty($job['truncated']),
				'findingsTruncated' => absint($finding_counts['total'] ?? 0) > self::MAX_FINDINGS,
				'limitedAreas' => is_array($job['limitedAreas'] ?? null)
					? $job['limitedAreas']
					: [],
				'scheduled' => !empty($job['scheduled']),
			];
			update_option(self::RESULTS_OPTION, $results, false);

			if ($complete) {
				delete_option(self::JOB_OPTION);
				if (!empty($job['scheduled'])) {
					delete_option(self::CANCEL_OPTION);
					wp_clear_scheduled_hook(self::CRON_HOOK, ['continue']);
					update_option(self::LAST_AUTOMATIC_OPTION, $results['finishedAt'], false);
				}
				if (class_exists('WPHAVE_Activity_Log')) {
					WPHAVE_Activity_Log::record('security_scan.completed', [
						'category' => 'security',
						'action' => 'completed',
						'actor_type' => !empty($job['scheduled']) ? 'cron' : null,
						'object_type' => 'scan',
						'object_label' => 'Security scan',
						'context' => [
							'processed' => $processed,
							'findings' => absint($finding_counts['total'] ?? 0),
							'errors' => count($errors),
							'partial' => $state === 'partial',
							'scheduled' => !empty($job['scheduled']),
						],
					]);
				}

				if (!empty($job['scheduled'])) {
					self::maybe_send_scan_notification($results, self::get_scan_settings());
				}
			} else {
				$job['processed'] = $processed;
				$job['findings'] = $findings;
				$job['findingCounts'] = $finding_counts;
				$job['checks'] = $checks;
				$job['errors'] = $errors;
				$job['updatedAt'] = time();
				update_option(self::JOB_OPTION, $job, false);
			}
			return $results;
		} finally {
			self::release_lock($lock);
		}
	}

	/**
	 * Build the persistent task queue for a scan.
	 *
	 * @param string $started_at Scan start time.
	 * @param array  $checks     Check summaries, passed by reference.
	 * @param array  $errors     Collection errors, passed by reference.
	 * @return array Prepared scan job.
	 */

	private static function create_job(string $started_at, array &$checks, array &$errors): array {
		global $wp_version;
		$root = trailingslashit((string) apply_filters('wphave_security_scan_root', ABSPATH));
		$uploads = wp_get_upload_dir();
		$upload_directory = trailingslashit(
			(string) apply_filters(
				'wphave_security_scan_upload_directory',
				$uploads['basedir'] ?? '',
			),
		);
		$plugin_directory = trailingslashit(
			(string) apply_filters('wphave_security_scan_plugin_directory', WP_PLUGIN_DIR),
		);
		$tasks = [];
		$expected = [];
		$truncated = false;
		$limited_areas = [];
		$core_start = count($tasks);
		$core_deadline = microtime(true) + self::MAX_DISCOVERY_TIME_PER_AREA;
		$core_limited = false;
		$checksums = apply_filters(
			'wphave_security_scan_core_checksums',
			null,
			$wp_version,
			get_locale(),
		);

		if (!is_array($checksums)) {
			require_once ABSPATH . 'wp-admin/includes/update.php';
			$checksums = get_core_checksums($wp_version, get_locale());
		}

		if (!is_array($checksums) || !$checksums) {
			$checks['coreIntegrity']['status'] = 'error';
			$errors[] = [
				'check' => 'core_integrity',
				'message' => __('Official WordPress checksums could not be loaded.', 'wphave'),
			];
		} else {
			foreach ($checksums as $relative_path => $checksum) {
				$relative_path = self::normalize_relative_path($relative_path);
				if (!$relative_path || str_starts_with($relative_path, 'wp-content/')) {
					continue;
				}
				$expected[$relative_path] = true;
				if (
					self::discovery_limit_reached(
						$tasks,
						$core_deadline,
						$core_start,
						self::MAX_CORE_TASKS,
					)
				) {
					$truncated = true;
					$core_limited = true;
					$limited_areas[] = 'coreIntegrity';
					$checks['coreIntegrity']['limited'] = true;
					break;
				}
				$tasks[] = [
					'type' => 'core_checksum',
					'path' => $relative_path,
					'checksum' => strtolower((string) $checksum),
				];
			}

			if (!$core_limited) {
				foreach (['wp-admin', 'wp-includes'] as $directory) {
					$path = $root . $directory;
					if (!is_dir($path)) {
						continue;
					}
					try {
						$iterator = new RecursiveIteratorIterator(
							new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS),
						);
						foreach ($iterator as $file) {
							if (!$file->isFile() || $file->isLink()) {
								continue;
							}
							$relative_path = self::normalize_relative_path(
								substr($file->getPathname(), strlen($root)),
							);
							if (isset($expected[$relative_path])) {
								continue;
							}
							if (
								self::discovery_limit_reached(
									$tasks,
									$core_deadline,
									$core_start,
									self::MAX_CORE_TASKS,
								)
							) {
								$truncated = true;
								$core_limited = true;
								$limited_areas[] = 'coreIntegrity';
								$checks['coreIntegrity']['limited'] = true;
								break 2;
							}
							$tasks[] = ['type' => 'unknown_core', 'path' => $relative_path];
						}
					} catch (UnexpectedValueException $exception) {
						$errors[] = [
							'check' => 'core_integrity',
							'path' => WPHAVE_Security_Redactor::error_text($directory, 300),
							'message' => WPHAVE_Security_Redactor::error_text(
								$exception->getMessage(),
							),
						];
					}
				}
			}
		}

		$upload_start = count($tasks);
		$upload_deadline = microtime(true) + self::MAX_DISCOVERY_TIME_PER_AREA;

		if (!$upload_directory || !is_dir($upload_directory)) {
			$checks['uploadExecutables']['status'] = 'unavailable';
		} elseif (count($tasks) >= self::MAX_TOTAL_TASKS) {
			$truncated = true;
			$limited_areas[] = 'uploadExecutables';
			$checks['uploadExecutables']['limited'] = true;
		} else {
			try {
				$iterator = new RecursiveIteratorIterator(
					new RecursiveDirectoryIterator(
						$upload_directory,
						FilesystemIterator::SKIP_DOTS,
					),
				);
				foreach ($iterator as $file) {
					if (!$file->isFile() || $file->isLink()) {
						continue;
					}
					if (
						self::discovery_limit_reached(
							$tasks,
							$upload_deadline,
							$upload_start,
							self::MAX_UPLOAD_TASKS,
						)
					) {
						$truncated = true;
						$limited_areas[] = 'uploadExecutables';
						$checks['uploadExecutables']['limited'] = true;
						break;
					}
					$tasks[] = [
						'type' => 'upload',
						'path' => self::normalize_relative_path(
							substr($file->getPathname(), strlen($upload_directory)),
						),
					];
				}
			} catch (UnexpectedValueException $exception) {
				$checks['uploadExecutables']['status'] = 'error';
				$errors[] = [
					'check' => 'upload_executables',
					'message' => WPHAVE_Security_Redactor::error_text($exception->getMessage()),
				];
			}
		}

		$plugin_start = count($tasks);
		$plugin_deadline = microtime(true) + self::MAX_DISCOVERY_TIME_PER_AREA;

		if (count($tasks) >= self::MAX_TOTAL_TASKS) {
			$truncated = true;
			$limited_areas[] = 'extensionIntegrity';
			$checks['extensionIntegrity']['limited'] = true;
		} else {
			self::add_plugin_integrity_tasks(
				$plugin_directory,
				$tasks,
				$checks['extensionIntegrity'],
				$errors,
				$truncated,
				$limited_areas,
				$plugin_deadline,
				$plugin_start,
			);
		}

		$sensitive_candidates_limited = false;
		foreach (
			self::sensitive_file_candidates($root, $sensitive_candidates_limited)
			as $relative_path
		) {
			$tasks[] = ['type' => 'sensitive_file', 'path' => $relative_path];
		}

		if ($sensitive_candidates_limited) {
			$truncated = true;
			$limited_areas[] = 'sensitiveExposure';
			$checks['sensitiveExposure']['limited'] = true;
		}

		$posture_checks = apply_filters('wphave_security_scan_posture_checks', [
			'debug_display',
			'debug_log',
			'file_editor',
			'admin_https',
			'security_headers',
			'xml_rpc',
			'user_enumeration',
			'open_registration',
			'directory_listing',
			'http_methods',
			'login_rate_limiting',
			'config_permissions',
			'uploads_permissions',
			'security_keys',
			'php_runtime',
			'database_runtime',
			'core_updates',
			'plugin_updates',
			'theme_updates',
			'automatic_core_updates',
			'default_admin',
		]);

		if (is_array($posture_checks)) {
			foreach ($posture_checks as $posture_check) {
				$tasks[] = ['type' => 'security_posture', 'path' => sanitize_key($posture_check)];
			}
		}

		if ($truncated) {
			$limited_areas = array_values(array_unique($limited_areas));
			foreach ($limited_areas as $area) {
				$errors[] = [
					'check' => 'scan_limit',
					'path' => $area,
					'message' => __(
						'This file area reached its independent discovery time or file budget and could not be checked completely.',
						'wphave',
					),
				];
			}
		}

		return [
			'startedAt' => $started_at,
			'root' => $root,
			'uploadDirectory' => $upload_directory,
			'pluginDirectory' => $plugin_directory,
			'tasks' => $tasks,
			'processed' => 0,
			'findings' => [],
			'findingCounts' => self::count_findings([]),
			'checks' => $checks,
			'errors' => $errors,
			'truncated' => $truncated,
			'limitedAreas' => $limited_areas,
		];
	}

	/**
	 * Process a single queued scan task.
	 *
	 * @param array $task     Task definition.
	 * @param array $job      Active scan job.
	 * @param array $findings Findings, passed by reference.
	 * @param array $checks   Check summaries, passed by reference.
	 * @param array $errors   Errors, passed by reference.
	 * @return void
	 */

	private static function process_task(
		array $task,
		array $job,
		array &$findings,
		array &$checks,
		array &$errors,
	): void {
		$type = sanitize_key($task['type'] ?? '');
		$relative_path = self::normalize_relative_path($task['path'] ?? '');
		if (!$relative_path) {
			return;
		}

		if ($type === 'core_checksum') {
			$checks['coreIntegrity']['status'] = 'running';
			$checks['coreIntegrity']['checked']++;
			$path = trailingslashit($job['root'] ?? ABSPATH) . $relative_path;
			if (!is_file($path)) {
				self::add_finding(
					$findings,
					'core_file_missing',
					'high',
					'high',
					$relative_path,
					__('A file from the installed WordPress version is missing.', 'wphave'),
				);
				$checks['coreIntegrity']['findings']++;
				return;
			}
			$actual = @md5_file($path);
			if (
				!is_string($actual) ||
				!hash_equals((string) ($task['checksum'] ?? ''), strtolower($actual))
			) {
				self::add_finding(
					$findings,
					'core_file_modified',
					'critical',
					'high',
					$relative_path,
					__(
						'The file does not match the official checksum for the installed WordPress version.',
						'wphave',
					),
				);
				$checks['coreIntegrity']['findings']++;
			}
			return;
		}

		if ($type === 'unknown_core') {
			$checks['coreIntegrity']['status'] = 'running';
			if (!self::is_executable_extension($relative_path)) {
				return;
			}
			self::add_finding(
				$findings,
				'unknown_core_file',
				'critical',
				'high',
				$relative_path,
				__('An unexpected executable file exists in a WordPress core directory.', 'wphave'),
			);
			$checks['coreIntegrity']['findings']++;
			return;
		}

		if ($type === 'upload') {
			$checks['uploadExecutables']['status'] = 'running';
			$checks['uploadExecutables']['checked']++;
			if (!self::is_executable_extension($relative_path)) {
				return;
			}
			$file = new SplFileInfo(
				trailingslashit($job['uploadDirectory'] ?? '') . $relative_path,
			);
			if (!$file->isFile() || self::is_safe_upload_index($file)) {
				return;
			}
			self::add_finding(
				$findings,
				'executable_upload',
				'critical',
				'high',
				'uploads/' . $relative_path,
				__('An executable file exists inside the WordPress uploads directory.', 'wphave'),
			);
			$checks['uploadExecutables']['findings']++;
			return;
		}

		if (in_array($type, ['plugin_checksum', 'unknown_plugin'], true)) {
			$checks['extensionIntegrity']['status'] = 'running';
			$checks['extensionIntegrity']['checked']++;
			$path = trailingslashit($job['pluginDirectory'] ?? WP_PLUGIN_DIR) . $relative_path;
			if ($type === 'plugin_checksum') {
				if (!is_file($path)) {
					self::add_finding(
						$findings,
						'plugin_file_missing',
						'warning',
						'high',
						'wp-content/plugins/' . $relative_path,
						__('A file from the official plugin package is missing.', 'wphave'),
						__('Official plugin file is missing', 'wphave'),
						__(
							'Reinstall the same plugin version from WordPress.org or update it after creating a backup.',
							'wphave',
						),
					);
					$checks['extensionIntegrity']['findings']++;
					return;
				}
				$actual = @md5_file($path);
				if (
					!is_string($actual) ||
					!hash_equals((string) ($task['checksum'] ?? ''), strtolower($actual))
				) {
					$severity = self::is_executable_extension($relative_path) ? 'high' : 'warning';
					self::add_finding(
						$findings,
						'plugin_file_modified',
						$severity,
						'high',
						'wp-content/plugins/' . $relative_path,
						__(
							'The file does not match the official package for the installed plugin version.',
							'wphave',
						),
						__('Official plugin file was modified', 'wphave'),
						__(
							'Review intentional customizations, then reinstall the plugin from a trusted source if the change is unknown.',
							'wphave',
						),
					);
					$checks['extensionIntegrity']['findings']++;
				}
				return;
			}
			if (!self::is_executable_extension($relative_path) || !is_file($path)) {
				return;
			}
			self::add_finding(
				$findings,
				'unknown_plugin_file',
				'high',
				'medium',
				'wp-content/plugins/' . $relative_path,
				__(
					'An executable file exists in the plugin directory but is not part of the official package.',
					'wphave',
				),
				__('Unexpected executable plugin file', 'wphave'),
				__(
					'Confirm whether this file was intentionally added. If not, replace the plugin directory with a clean package.',
					'wphave',
				),
			);
			$checks['extensionIntegrity']['findings']++;
			return;
		}

		if ($type === 'sensitive_file') {
			$checks['sensitiveExposure']['status'] = 'running';
			$checks['sensitiveExposure']['checked']++;
			$path = trailingslashit($job['root'] ?? ABSPATH) . $relative_path;
			if (!is_file($path)) {
				return;
			}
			$exposure = self::check_http_exposure($relative_path, $path);
			if ($exposure === true) {
				self::add_finding(
					$findings,
					'sensitive_file_exposed',
					'critical',
					'high',
					$relative_path,
					__('This sensitive file can be downloaded without authentication.', 'wphave'),
					__('Publicly accessible sensitive file', 'wphave'),
					__(
						'Remove the file from the web root or block direct HTTP access at the web server.',
						'wphave',
					),
					__(
						'The server returned a successful HTTP response for the file URL.',
						'wphave',
					),
				);
				$checks['sensitiveExposure']['findings']++;
			} elseif ($exposure === null) {
				$checks['sensitiveExposure']['status'] = 'unavailable';
				$errors[] = [
					'check' => 'sensitive_exposure',
					'path' => $relative_path,
					'message' => sprintf(
						__('Public access to %s could not be verified.', 'wphave'),
						$relative_path,
					),
				];
			}
			return;
		}

		if ($type === 'security_posture') {
			$checks['securityPosture']['status'] = 'running';
			$checks['securityPosture']['checked']++;
			if (self::process_posture_check($relative_path, $findings, $errors)) {
				$checks['securityPosture']['findings']++;
			}
		}
	}

	/** Finalize every check summary after all tasks have been processed. */

	private static function finalize_checks(array &$checks): void {
		foreach ($checks as &$check) {
			if (in_array($check['status'] ?? '', ['error', 'unavailable'], true)) {
				continue;
			}
			if (!empty($check['limited'])) {
				$check['status'] = 'partial';
				continue;
			}

			$check['status'] = !empty($check['findings']) ? 'findings' : 'passed';
		}
		unset($check);
	}

	/** Finalize checks whose tasks have already been processed. */

	private static function finalize_completed_checks(
		array $tasks,
		int $processed,
		array &$checks,
	): void {
		$remaining = [];
		for ($index = $processed, $total = count($tasks); $index < $total; $index++) {
			$remaining[self::task_check($tasks[$index]['type'] ?? '')] = true;
		}
		foreach ($checks as $name => &$check) {
			if (
				isset($remaining[$name]) ||
				in_array($check['status'] ?? '', ['error', 'unavailable'], true)
			) {
				continue;
			}
			if (!empty($check['limited'])) {
				$check['status'] = 'partial';
				continue;
			}

			$check['status'] = !empty($check['findings']) ? 'findings' : 'passed';
		}
		unset($check);
	}

	/** Map a task type to its public check-summary key. */

	private static function task_check(string $type): string {
		if ($type === 'upload') {
			return 'uploadExecutables';
		}
		if (in_array($type, ['plugin_checksum', 'unknown_plugin'], true)) {
			return 'extensionIntegrity';
		}
		if ($type === 'sensitive_file') {
			return 'sensitiveExposure';
		}
		if ($type === 'security_posture') {
			return 'securityPosture';
		}
		return $type ? 'coreIntegrity' : '';
	}

	/** Acquire the short-lived scanner write lock. */

	private static function acquire_lock(): string|false {
		return WPHAVE_Background_Job_Lock::acquire(self::LOCK_OPTION, self::LOCK_TTL);
	}

	/** Release the scanner write lock owned by the token. */

	private static function release_lock(string $token): void {
		WPHAVE_Background_Job_Lock::release(self::LOCK_OPTION, $token);
	}

	/** Add a normalized finding to the result collection. */

	private static function add_finding(
		array &$findings,
		string $check,
		string $severity,
		string $confidence,
		string $path,
		string $message,
		string $title = '',
		string $recommendation = '',
		string $details = '',
	): void {
		$path = self::normalize_relative_path($path);
		$findings[] = [
			'id' => hash('sha256', $check . '|' . $path),
			'check' => $check,
			'severity' => $severity,
			'confidence' => $confidence,
			'path' => $path,
			'title' => $title ?: $message,
			'message' => $message,
			'recommendation' => $recommendation,
			'details' => $details,
			'status' => 'open',
		];
	}

	/** Add checksum and unexpected-file tasks for verifiable plugins. */

	private static function add_plugin_integrity_tasks(
		string $plugin_directory,
		array &$tasks,
		array &$check,
		array &$errors,
		bool &$truncated,
		array &$limited_areas,
		float $discovery_deadline,
		int $area_start,
	): void {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		$plugins = apply_filters('wphave_security_scan_plugins', get_plugins());
		if (!is_array($plugins) || !$plugins) {
			$check['status'] = 'unavailable';
			return;
		}

		$packages = [];
		foreach ($plugins as $plugin_file => $plugin_data) {
			$plugin_file = self::normalize_relative_path($plugin_file);
			$version = sanitize_text_field($plugin_data['Version'] ?? '');
			$slug =
				dirname($plugin_file) === '.'
					? pathinfo($plugin_file, PATHINFO_FILENAME)
					: dirname($plugin_file);
			if (!$plugin_file || !$version || isset($packages[$slug])) {
				continue;
			}
			$packages[$slug] = [
				'version' => $version,
				'directory' =>
					dirname($plugin_file) === '.' ? '' : trailingslashit(dirname($plugin_file)),
			];
		}

		foreach ($packages as $slug => $package) {
			if (
				self::discovery_limit_reached(
					$tasks,
					$discovery_deadline,
					$area_start,
					self::MAX_PLUGIN_TASKS,
				)
			) {
				$truncated = true;
				$limited_areas[] = 'extensionIntegrity';
				$check['limited'] = true;
				break;
			}

			$manifest = self::get_plugin_checksums($slug, $package['version']);
			if (!is_array($manifest) || !$manifest) {
				$check['unavailablePackages']++;
				continue;
			}
			$check['verifiedPackages']++;
			$expected = [];
			foreach ($manifest as $file => $hashes) {
				$file = self::normalize_relative_path($file);
				$checksum = is_array($hashes) ? $hashes['md5'] ?? '' : $hashes;
				if (
					!$file ||
					!is_string($checksum) ||
					!preg_match('/^[a-f0-9]{32}$/i', $checksum)
				) {
					continue;
				}
				$expected[$file] = true;
				$relative_path = $package['directory'] . $file;
				if (
					self::discovery_limit_reached(
						$tasks,
						$discovery_deadline,
						$area_start,
						self::MAX_PLUGIN_TASKS,
					)
				) {
					$truncated = true;
					$limited_areas[] = 'extensionIntegrity';
					$check['limited'] = true;
					break 2;
				}
				$tasks[] = [
					'type' => 'plugin_checksum',
					'path' => $relative_path,
					'checksum' => strtolower($checksum),
				];
			}
			$directory = $plugin_directory . $package['directory'];
			if (!$package['directory'] || !is_dir($directory)) {
				continue;
			}
			try {
				$iterator = new RecursiveIteratorIterator(
					new RecursiveDirectoryIterator($directory, FilesystemIterator::SKIP_DOTS),
				);
				foreach ($iterator as $file) {
					if (!$file->isFile() || $file->isLink()) {
						continue;
					}
					$path = self::normalize_relative_path(
						substr($file->getPathname(), strlen($directory)),
					);
					if (isset($expected[$path])) {
						continue;
					}
					if (!self::is_executable_extension($path)) {
						continue;
					}
					if (
						self::discovery_limit_reached(
							$tasks,
							$discovery_deadline,
							$area_start,
							self::MAX_PLUGIN_TASKS,
						)
					) {
						$truncated = true;
						$limited_areas[] = 'extensionIntegrity';
						$check['limited'] = true;
						break 2;
					}
					$tasks[] = [
						'type' => 'unknown_plugin',
						'path' => $package['directory'] . $path,
					];
				}
			} catch (UnexpectedValueException $exception) {
				$errors[] = [
					'check' => 'extension_integrity',
					'path' => WPHAVE_Security_Normalizer::plain_text($slug, 190),
					'message' => WPHAVE_Security_Redactor::error_text($exception->getMessage()),
				];
			}
		}
		if (!$check['verifiedPackages']) {
			$check['status'] = 'unavailable';
		}
	}

	/** Determine whether task discovery reached its count or time budget. */

	private static function discovery_limit_reached(
		array $tasks,
		float $deadline,
		int $area_start,
		int $area_limit,
	): bool {
		return count($tasks) >= self::MAX_TOTAL_TASKS ||
			count($tasks) - $area_start >= $area_limit ||
			microtime(true) >= $deadline;
	}

	/** Fetch and cache the official checksum manifest for a plugin version. */

	private static function get_plugin_checksums(string $slug, string $version): ?array {
		$filtered = apply_filters('wphave_security_scan_plugin_checksums', null, $slug, $version);
		if (is_array($filtered)) {
			return $filtered;
		}
		$cache_key = 'wphave_plugin_checksums_' . md5($slug . '|' . $version);
		$cached = get_site_transient($cache_key);
		if (is_array($cached)) {
			return $cached['files'] ?? null;
		}
		$url = sprintf(
			'https://downloads.wordpress.org/plugin-checksums/%s/%s.json',
			rawurlencode($slug),
			rawurlencode($version),
		);
		// TRANSPORT INVARIANT: Plugin integrity trusts only the exact WordPress.org
		// checksum authority and a complete, bounded response from that authority.
		// Redirects must never extend this trust boundary to another host.
		$response = wp_safe_remote_get($url, [
			'timeout' => 8,
			'redirection' => 0,
			'sslverify' => true,
			'limit_response_size' => self::MAX_CHECKSUM_MANIFEST_BYTES + 1,
		]);
		$files = null;
		if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
			$body = (string) wp_remote_retrieve_body($response);
			if (strlen($body) <= self::MAX_CHECKSUM_MANIFEST_BYTES) {
				$data = json_decode($body, true);
				if (is_array($data['files'] ?? null)) {
					$files = $data['files'];
				}
			}
		}
		set_site_transient(
			$cache_key,
			['files' => $files],
			$files ? DAY_IN_SECONDS : HOUR_IN_SECONDS,
		);
		return $files;
	}

	/** Find potentially sensitive files in the public web root. */

	private static function sensitive_file_candidates(string $root, bool &$limited = false): array {
		$candidates = [
			'.env',
			'.env.local',
			'.htaccess.bak',
			'.htpasswd',
			'.user.ini',
			'error_log',
			'php.ini',
			'wp-config.php.bak',
			'wp-config.php.old',
			'wp-config.php.save',
			'wp-content/debug.log',
		];
		$deadline = microtime(true) + 2;

		try {
			$iterator = new DirectoryIterator($root);
			foreach ($iterator as $file) {
				if (!$file->isFile() || $file->isLink()) {
					continue;
				}
				if (
					count($candidates) >= self::MAX_SENSITIVE_CANDIDATES ||
					microtime(true) >= $deadline
				) {
					$limited = true;
					break;
				}

				if (
					preg_match(
						'/\.(?:sql(?:\.gz)?|zip|tar|tar\.gz|tgz|log)$/i',
						$file->getFilename(),
					)
				) {
					$candidates[] = $file->getFilename();
				}
			}
		} catch (UnexpectedValueException $exception) {
			return array_values(array_unique($candidates));
		}
		return array_values(array_unique($candidates));
	}

	/** Verify whether a local sensitive file is publicly downloadable. */

	private static function check_http_exposure(string $relative_path, string $path): ?bool {
		// WEB-ROOT URL INVARIANT: Scanner paths are relative to ABSPATH, whose
		// public counterpart is site_url(), not home_url(). The two intentionally
		// differ when WordPress core lives in a subdirectory. Integrations scanning
		// a filtered filesystem root may replace the complete URL via this filter.
		$url = apply_filters(
			'wphave_security_scan_file_url',
			site_url('/' . $relative_path),
			$relative_path,
		);
		if (!wp_http_validate_url($url)) {
			return null;
		}
		$response = wp_safe_remote_get($url, [
			'timeout' => 4,
			'redirection' => 0,
			'sslverify' => true,
			'limit_response_size' => 1024,
			'headers' => ['Cache-Control' => 'no-cache'],
		]);
		if (is_wp_error($response)) {
			return null;
		}
		$status = wp_remote_retrieve_response_code($response);
		if ($status >= 200 && $status < 300) {
			$local = @file_get_contents($path, false, null, 0, 1024);
			$remote = wp_remote_retrieve_body($response);
			if (!is_string($local) || $local === '' || !is_string($remote)) {
				return null;
			}
			return hash_equals(hash('sha256', $local), hash('sha256', $remote));
		}
		if (in_array($status, [401, 403, 404, 410], true)) {
			return false;
		}
		return null;
	}

	/**
	 * Run one configuration, runtime or update posture check.
	 *
	 * @param string $check    Posture check identifier.
	 * @param array  $findings Findings, passed by reference.
	 * @param array  $errors   Verification errors, passed by reference.
	 * @return bool Whether the check produced a finding.
	 */

	private static function process_posture_check(
		string $check,
		array &$findings,
		array &$errors = [],
	): bool {
		if (
			$check === 'debug_display' &&
			defined('WP_DEBUG') &&
			WP_DEBUG &&
			(!defined('WP_DEBUG_DISPLAY') || WP_DEBUG_DISPLAY)
		) {
			self::add_finding(
				$findings,
				'debug_display_enabled',
				'warning',
				'high',
				'wp-config.php',
				__('WordPress can display PHP errors to website visitors.', 'wphave'),
				__('Debug output is publicly enabled', 'wphave'),
				__(
					'Set WP_DEBUG_DISPLAY to false and log errors outside publicly accessible directories.',
					'wphave',
				),
			);
			return true;
		}
		if ($check === 'debug_log' && defined('WP_DEBUG_LOG') && WP_DEBUG_LOG) {
			$debug_log = is_string(WP_DEBUG_LOG) ? WP_DEBUG_LOG : WP_CONTENT_DIR . '/debug.log';
			$public_content = wp_normalize_path(WP_CONTENT_DIR);
			if (str_starts_with(wp_normalize_path($debug_log), trailingslashit($public_content))) {
				self::add_finding(
					$findings,
					'debug_log_public_path',
					'warning',
					'high',
					'wp-content/debug.log',
					__(
						'WordPress is configured to write debug information inside the public content directory.',
						'wphave',
					),
					__('Debug log uses a public path', 'wphave'),
					__(
						'Store PHP logs outside the public web root and disable debug logging on production websites when it is no longer needed.',
						'wphave',
					),
				);
				return true;
			}
		}
		if ($check === 'file_editor' && (!defined('DISALLOW_FILE_EDIT') || !DISALLOW_FILE_EDIT)) {
			self::add_finding(
				$findings,
				'file_editor_enabled',
				'warning',
				'high',
				'wp-config.php',
				__(
					'Administrators can edit plugin and theme files from the WordPress dashboard.',
					'wphave',
				),
				__('WordPress file editor is enabled', 'wphave'),
				__(
					'Enable “Disable File Editing” in WPHAVE after confirming it fits your workflow.',
					'wphave',
				),
			);
			return true;
		}
		if (
			$check === 'admin_https' &&
			wp_get_environment_type() === 'production' &&
			!wp_is_using_https() &&
			(!defined('FORCE_SSL_ADMIN') || !FORCE_SSL_ADMIN)
		) {
			self::add_finding(
				$findings,
				'admin_https_disabled',
				'high',
				'high',
				'wp-admin',
				__(
					'The production website does not appear to enforce HTTPS for WordPress administration.',
					'wphave',
				),
				__('Admin HTTPS is not enforced', 'wphave'),
				__(
					'Configure a valid TLS certificate, use HTTPS site URLs and enable FORCE_SSL_ADMIN.',
					'wphave',
				),
			);
			return true;
		}
		if ($check === 'security_headers' && wp_get_environment_type() === 'production') {
			// PROBE INVARIANT: Posture results describe the configured site authority,
			// never an arbitrary redirect target selected by its HTTP response.
			$response = wp_safe_remote_head(home_url('/'), [
				'timeout' => 5,
				'redirection' => 0,
				'sslverify' => true,
			]);
			if (!is_wp_error($response)) {
				$headers = wp_remote_retrieve_headers($response);
				$missing = [];
				if (strtolower((string) ($headers['x-content-type-options'] ?? '')) !== 'nosniff') {
					$missing[] = 'X-Content-Type-Options';
				}
				if (
					empty($headers['content-security-policy']) &&
					empty($headers['x-frame-options'])
				) {
					$missing[] = 'Content-Security-Policy/X-Frame-Options';
				}
				if (
					str_starts_with(home_url('/'), 'https://') &&
					empty($headers['strict-transport-security'])
				) {
					$missing[] = 'Strict-Transport-Security';
				}
				if ($missing) {
					self::add_finding(
						$findings,
						'security_headers_missing',
						'warning',
						'high',
						'HTTP headers',
						__(
							'The public website response is missing one or more basic browser security headers.',
							'wphave',
						),
						__('Browser security headers are incomplete', 'wphave'),
						__(
							'Configure the missing headers at the web server or trusted edge proxy after testing them in a staging environment.',
							'wphave',
						),
						implode(', ', $missing),
					);
					return true;
				}
			} else {
				$errors[] = [
					'check' => 'security_headers',
					'message' => __(
						'The public website response could not be requested, so browser security headers were not verified.',
						'wphave',
					),
				];
			}
		}
		if ($check === 'xml_rpc') {
			$xmlrpc_enabled = (bool) apply_filters('xmlrpc_enabled', true);
			$methods = apply_filters('xmlrpc_methods', [
				'system.multicall' => '__return_true',
				'pingback.ping' => '__return_true',
			]);
			$headers = apply_filters('wp_headers', ['X-Pingback' => site_url('xmlrpc.php')]);
			$methods_disabled = is_array($methods) && empty($methods);
			$pingback_header_removed = is_array($headers) && !isset($headers['X-Pingback']);
			if ($xmlrpc_enabled || !$methods_disabled || !$pingback_header_removed) {
				self::add_finding(
					$findings,
					'xml_rpc_exposed',
					'warning',
					'medium',
					'xmlrpc.php',
					__(
						'WordPress XML-RPC methods or the X-Pingback discovery header remain enabled.',
						'wphave',
					),
					__('XML-RPC protection is disabled', 'wphave'),
					__(
						'Enable “Disable WP XML-RPC methods / X-Pingback” in WPHAVE, or block xmlrpc.php at the web server when no integration requires it.',
						'wphave',
					),
					__(
						'Some hosting platforms can block the endpoint outside WordPress. Verify the public HTTP response separately when server-level protection is configured.',
						'wphave',
					),
				);
				return true;
			}
		}
		if ($check === 'user_enumeration') {
			$protection_enabled = (bool) wphave_data_get(
				'site_settings',
				'advanced.security.disable_user_enumeration',
				false,
			);
			$protection_enabled = (bool) apply_filters(
				'wphave_security_scan_user_enumeration_protection_enabled',
				$protection_enabled,
			);

			if ($protection_enabled) {
				return false;
			}

			$exposed = apply_filters('wphave_security_scan_user_enumeration_result', null);
			if ($exposed === null) {
				// PROBE INVARIANT: User enumeration is established only from a complete,
				// bounded JSON response. An overflow sentinel remains unverified.
				$response = wp_safe_remote_get(
					add_query_arg(
						['per_page' => 1, '_fields' => 'id,slug'],
						rest_url('wp/v2/users'),
					),
					[
						'timeout' => 5,
						'redirection' => 0,
						'sslverify' => true,
						'limit_response_size' => self::MAX_USER_ENUMERATION_BYTES + 1,
					],
				);
				if (!is_wp_error($response)) {
					$status = wp_remote_retrieve_response_code($response);
					$response_body = (string) wp_remote_retrieve_body($response);
					$body =
						strlen($response_body) <= self::MAX_USER_ENUMERATION_BYTES
							? json_decode($response_body, true)
							: null;
					if ($status >= 200 && $status < 300 && is_array($body)) {
						$exposed = true;
					}
					if (in_array($status, [401, 403, 404], true)) {
						$exposed = false;
					}
				} else {
					$errors[] = [
						'check' => 'user_enumeration',
						'message' => __(
							'The public users endpoint could not be requested. WPHAVE protection is disabled and protection by another layer remains unverified.',
							'wphave',
						),
					];
				}
			}
			if ($exposed !== false) {
				$message =
					$exposed === true
						? __(
							'The public WordPress REST API exposes user records to unauthenticated visitors.',
							'wphave',
						)
						: __(
							'WPHAVE user-enumeration protection is disabled and protection by another layer could not be verified.',
							'wphave',
						);

				self::add_finding(
					$findings,
					'user_enumeration_exposed',
					'warning',
					$exposed === true ? 'high' : 'medium',
					'wp-json/wp/v2/users',
					$message,
					__('Public user enumeration is not protected', 'wphave'),
					__(
						'Enable “Disable User Enumeration” in WPHAVE unless public user data and author archives are intentionally required.',
						'wphave',
					),
					__(
						'Other plugins or the web server may provide equivalent protection. Verify both the public users REST endpoint and author archives when relying on another layer.',
						'wphave',
					),
				);
				return true;
			}
		}
		if ($check === 'open_registration' && get_option('users_can_register')) {
			$default_role = sanitize_key(get_option('default_role', 'subscriber'));
			$role = get_role($default_role);
			$dangerous_capabilities = [
				'manage_options',
				'promote_users',
				'create_users',
				'edit_users',
				'delete_users',
				'install_plugins',
				'activate_plugins',
				'edit_plugins',
				'install_themes',
				'edit_theme_options',
				'unfiltered_html',
			];
			$granted = $role
				? array_values(
					array_filter(
						$dangerous_capabilities,
						static fn($capability) => $role->has_cap($capability),
					),
				)
				: [];

			if ($granted) {
				self::add_finding(
					$findings,
					'dangerous_registration_default_role',
					'high',
					'high',
					'wp-admin/options-general.php',
					sprintf(
						__(
							'Public registration assigns the “%s” role, which grants privileged capabilities.',
							'wphave',
						),
						$default_role,
					),
					__('Public registration grants a privileged role', 'wphave'),
					__(
						'Immediately select a least-privileged membership role or disable public registration, then review recently created users.',
						'wphave',
					),
					implode(', ', $granted),
				);
				return true;
			}

			self::add_finding(
				$findings,
				'public_registration_enabled',
				'warning',
				'medium',
				'wp-admin/options-general.php',
				sprintf(
					__(
						'Anyone can create an account and receives the “%s” role by default.',
						'wphave',
					),
					$default_role,
				),
				__('Public user registration is enabled', 'wphave'),
				__(
					'Keep this enabled only when the website intentionally accepts registrations. Confirm that the default role has no administrative capabilities and that registration abuse is controlled.',
					'wphave',
				),
			);
			return true;
		}
		if ($check === 'directory_listing') {
			$exposed = apply_filters('wphave_security_scan_directory_listing_result', null);

			if ($exposed === null) {
				$uploads = wp_get_upload_dir();
				$url = trailingslashit(wphave_public_url($uploads['baseurl'] ?? ''));
				// PROBE INVARIANT: Directory exposure is established only by a complete,
				// bounded response from the configured uploads authority itself.
				$response = $url
					? wp_safe_remote_get($url, [
						'timeout' => 5,
						'redirection' => 0,
						'sslverify' => true,
						'limit_response_size' => self::MAX_DIRECTORY_LISTING_BYTES + 1,
					])
					: null;

				if (is_wp_error($response) || !is_array($response)) {
					$errors[] = [
						'check' => 'directory_listing',
						'message' => __(
							'The uploads directory could not be requested, so directory listing could not be verified.',
							'wphave',
						),
					];
					return false;
				}

				$status = wp_remote_retrieve_response_code($response);
				$body = (string) wp_remote_retrieve_body($response);
				if (strlen($body) > self::MAX_DIRECTORY_LISTING_BYTES) {
					$errors[] = [
						'check' => 'directory_listing',
						'message' => __(
							'The uploads directory response exceeded the verification limit, so directory listing remains unverified.',
							'wphave',
						),
					];
					return false;
				}
				$exposed =
					$status >= 200 &&
					$status < 300 &&
					is_string($body) &&
					(bool) preg_match(
						'/(?:<title>\s*Index of\b|<h1>\s*Index of\b|href=["\']\?C=[NMSD];O=[AD]["\'])/i',
						$body,
					);
			}

			if ($exposed) {
				self::add_finding(
					$findings,
					'directory_listing_enabled',
					'warning',
					'high',
					'wp-content/uploads',
					__(
						'The public uploads directory exposes an automatically generated file listing.',
						'wphave',
					),
					__('Directory listing is enabled', 'wphave'),
					__(
						'Disable automatic directory indexes at the web server or hosting layer and verify the uploads URL again.',
						'wphave',
					),
				);
				return true;
			}
		}
		if ($check === 'http_methods') {
			$enabled_methods = apply_filters('wphave_security_scan_unsafe_http_methods', null);

			if ($enabled_methods === null) {
				$enabled_methods = [];
				foreach (['TRACE', 'TRACK'] as $method) {
					$probe = 'wphave-' . wp_generate_password(20, false, false);
					$response = wp_safe_remote_request(home_url('/'), [
						'method' => $method,
						'timeout' => 5,
						'redirection' => 0,
						'sslverify' => true,
						'limit_response_size' => 2048,
						'headers' => ['X-WPHAVE-Trace-Probe' => $probe],
					]);

					if (is_wp_error($response)) {
						$errors[] = [
							'check' => 'http_methods',
							'message' => sprintf(
								__(
									'The %s method could not be requested and remains unverified.',
									'wphave',
								),
								$method,
							),
						];
						continue;
					}

					$status = wp_remote_retrieve_response_code($response);
					$content_type = strtolower(
						(string) wp_remote_retrieve_header($response, 'content-type'),
					);
					$body = wp_remote_retrieve_body($response);
					$reflected = is_string($body) && str_contains($body, $probe);
					if (
						$status >= 200 &&
						$status < 300 &&
						($reflected || str_contains($content_type, 'message/http'))
					) {
						$enabled_methods[] = $method;
					}
				}
			}

			$enabled_methods = is_array($enabled_methods)
				? array_values(
					array_intersect(['TRACE', 'TRACK'], array_map('strtoupper', $enabled_methods)),
				)
				: [];
			if ($enabled_methods) {
				self::add_finding(
					$findings,
					'unsafe_http_methods_enabled',
					'warning',
					'high',
					'HTTP methods',
					__(
						'The web server accepts HTTP diagnostic methods that are unnecessary for a normal WordPress website.',
						'wphave',
					),
					__('Unsafe HTTP methods are enabled', 'wphave'),
					__(
						'Disable TRACE and TRACK at the web server or trusted edge proxy, then verify the public response again.',
						'wphave',
					),
					implode(', ', $enabled_methods),
				);
				return true;
			}
		}
		if ($check === 'config_permissions') {
			$path = self::wordpress_config_path();
			$permissions = is_file($path) ? @fileperms($path) : false;
			if ($permissions !== false && $permissions & 0002) {
				self::add_finding(
					$findings,
					'config_world_writable',
					'high',
					'high',
					'wp-config.php',
					__(
						'The WordPress configuration file is writable by every system user.',
						'wphave',
					),
					__('wp-config.php is world-writable', 'wphave'),
					__(
						'Restrict file permissions so only the required system account can write this file.',
						'wphave',
					),
				);
				return true;
			}
		}
		if ($check === 'uploads_permissions') {
			$uploads = wp_get_upload_dir();
			$path = (string) apply_filters(
				'wphave_security_scan_upload_directory',
				$uploads['basedir'] ?? '',
			);
			$permissions = $path && is_dir($path) ? @fileperms($path) : false;
			if ($permissions !== false && $permissions & 0002) {
				self::add_finding(
					$findings,
					'uploads_world_writable',
					'high',
					'high',
					'wp-content/uploads',
					__('The uploads directory is writable by every system user.', 'wphave'),
					__('Uploads directory is world-writable', 'wphave'),
					__(
						'Restrict directory permissions while keeping the web-server account able to create media files.',
						'wphave',
					),
				);
				return true;
			}
		}
		if ($check === 'security_keys') {
			$constants = [
				'AUTH_KEY',
				'SECURE_AUTH_KEY',
				'LOGGED_IN_KEY',
				'NONCE_KEY',
				'AUTH_SALT',
				'SECURE_AUTH_SALT',
				'LOGGED_IN_SALT',
				'NONCE_SALT',
			];
			$invalid = array_filter($constants, static function ($constant) {
				if (!defined($constant)) {
					return true;
				}
				$value = (string) constant($constant);
				return strlen($value) < 32 ||
					stripos($value, 'put your unique phrase here') !== false;
			});
			if ($invalid) {
				self::add_finding(
					$findings,
					'security_keys_invalid',
					'high',
					'high',
					'wp-config.php',
					__(
						'One or more WordPress authentication keys or salts are missing, too short or still use the installation placeholder.',
						'wphave',
					),
					__('Authentication keys and salts need attention', 'wphave'),
					__(
						'Generate a complete new set of WordPress secret keys, replace all eight values in wp-config.php and expect existing sessions to be signed out.',
						'wphave',
					),
					implode(', ', $invalid),
				);
				return true;
			}
		}
		if ($check === 'core_updates') {
			$updates = get_site_transient('update_core');
			if (
				isset($updates->updates[0]->response) &&
				$updates->updates[0]->response === 'upgrade'
			) {
				self::add_finding(
					$findings,
					'wordpress_update_available',
					'warning',
					'medium',
					'wp-admin/update-core.php',
					__(
						'A newer WordPress version is available. Available updates are not proof of a compromise, but can include security fixes.',
						'wphave',
					),
					__('WordPress update available', 'wphave'),
					__(
						'Review the release and install the update after a current backup and compatibility check.',
						'wphave',
					),
				);
				return true;
			}
		}
		if ($check === 'plugin_updates') {
			$updates = get_site_transient('update_plugins');
			$count =
				is_object($updates) && is_array($updates->response ?? null)
					? count($updates->response)
					: 0;
			if ($count) {
				self::add_finding(
					$findings,
					'plugin_updates_available',
					'warning',
					'medium',
					'wp-admin/plugins.php',
					sprintf(
						_n(
							'%d installed plugin has an available update.',
							'%d installed plugins have available updates.',
							$count,
							'wphave',
						),
						$count,
					),
					__('Plugin updates are available', 'wphave'),
					__(
						'Review changelogs and install trusted updates after creating a current backup and checking compatibility.',
						'wphave',
					),
				);
				return true;
			}
		}
		if ($check === 'theme_updates') {
			$updates = get_site_transient('update_themes');
			$count =
				is_object($updates) && is_array($updates->response ?? null)
					? count($updates->response)
					: 0;
			if ($count) {
				self::add_finding(
					$findings,
					'theme_updates_available',
					'warning',
					'medium',
					'wp-admin/themes.php',
					sprintf(
						_n(
							'%d installed theme has an available update.',
							'%d installed themes have available updates.',
							$count,
							'wphave',
						),
						$count,
					),
					__('Theme updates are available', 'wphave'),
					__(
						'Review changelogs and install trusted updates after creating a current backup and checking compatibility.',
						'wphave',
					),
				);
				return true;
			}
		}
		$automatic_updates_disabled =
			(defined('AUTOMATIC_UPDATER_DISABLED') && AUTOMATIC_UPDATER_DISABLED) ||
			(defined('WP_AUTO_UPDATE_CORE') && WP_AUTO_UPDATE_CORE === false);

		if ($check === 'automatic_core_updates' && $automatic_updates_disabled) {
			self::add_finding(
				$findings,
				'automatic_core_updates_disabled',
				'warning',
				'high',
				'wp-config.php',
				__('Automatic WordPress core updates are explicitly disabled.', 'wphave'),
				__('Automatic core updates are disabled', 'wphave'),
				__(
					'Enable at least automatic security and maintenance releases unless updates are managed reliably by your hosting or deployment process.',
					'wphave',
				),
			);
			return true;
		}
		if ($check === 'default_admin') {
			$user = get_user_by('login', 'admin');
			if ($user && user_can($user, 'manage_options')) {
				self::add_finding(
					$findings,
					'default_admin_username',
					'warning',
					'high',
					'wp-admin/users.php',
					__('An administrator account uses the predictable username “admin”.', 'wphave'),
					__('Predictable administrator username', 'wphave'),
					__(
						'Create a separately named administrator, verify access, transfer ownership where needed and remove the predictable account.',
						'wphave',
					),
				);
				return true;
			}
		}
		if ($check === 'login_rate_limiting') {
			$login_protection = [
				'rate_limiting' => (bool) wphave_data_get(
					'site_settings',
					'advanced.security.login_rate_limiting',
					false,
				),
				'custom_login' => (bool) wphave_data_get(
					'site_settings',
					'advanced.security.login_url_enabled',
					false,
				),
			];
			$login_protection = apply_filters(
				'wphave_security_scan_login_protection',
				$login_protection,
			);
			if (
				empty($login_protection['rate_limiting']) &&
				empty($login_protection['custom_login'])
			) {
				self::add_finding(
					$findings,
					'login_rate_limiting_disabled',
					'warning',
					'high',
					'wp-login.php',
					__(
						'The standard WordPress login endpoint is available without WPHAVE rate limiting.',
						'wphave',
					),
					__('Login rate limiting is disabled', 'wphave'),
					__(
						'Enable Rate Limiting in Login Protection to slow repeated failed logins and credential-stuffing attempts.',
						'wphave',
					),
					__(
						'A custom login path can reduce automated traffic but does not replace rate limiting when the endpoint becomes known.',
						'wphave',
					),
				);
				return true;
			}
		}
		if ($check === 'php_runtime') {
			$minimum = (string) apply_filters(
				'wphave_security_scan_minimum_php_version',
				WPHAVE_PHP_VERSION,
			);
			if (version_compare(PHP_VERSION, $minimum, '<')) {
				self::add_finding(
					$findings,
					'php_runtime_outdated',
					'high',
					'high',
					'PHP',
					sprintf(
						__(
							'The server uses PHP %1$s, below the configured minimum PHP requirement of PHP %2$s.',
							'wphave',
						),
						PHP_VERSION,
						$minimum,
					),
					__('PHP runtime does not meet the minimum requirement', 'wphave'),
					__(
						'Upgrade PHP through the hosting control panel after testing the website and creating a current backup.',
						'wphave',
					),
				);
				return true;
			}
			$support = WPHAVE_PHP_Support::evaluate();
			if ($support['securityStatus'] !== 'supported') {
				self::add_finding(
					$findings,
					'php_runtime_security_support',
					$support['securityStatus'] === 'ended' ? 'high' : 'medium',
					'high',
					'PHP',
					$support['securityStatus'] === 'ended'
						? __(
							'This PHP release no longer receives upstream security updates.',
							'wphave',
						)
						: __(
							'Security support for this PHP release is not verified by the bundled runtime policy.',
							'wphave',
						),
					__('PHP security support', 'wphave'),
					$support['recommendedVersion']
						? sprintf(
							__(
								'Use a supported stable PHP release. WPHAVE recommends PHP %s with the latest patch updates.',
								'wphave',
							),
							$support['recommendedVersion'],
						)
						: __(
							'Verify current PHP maintenance with the official vendor and update WPHAVE to refresh its support information.',
							'wphave',
						),
				);
				return true;
			}
		}
		if ($check === 'database_runtime') {
			global $wpdb;
			$support = WPHAVE_Database_Support::current($wpdb);
			if ($support['isSqlite']) {
				return false;
			}
			$minimum = (string) apply_filters(
				'wphave_security_scan_minimum_database_version',
				$support['minVersion'],
				$support['type'] === 'MariaDB',
			);
			if ($support['versionKnown'] && version_compare($support['version'], $minimum, '<')) {
				self::add_finding(
					$findings,
					'database_runtime_outdated',
					'high',
					'high',
					'Database',
					sprintf(
						__(
							'The database server uses %1$s, below the configured minimum requirement of %2$s.',
							'wphave',
						),
						$support['version'],
						$minimum,
					),
					__('Database runtime does not meet the minimum requirement', 'wphave'),
					__(
						'Ask the hosting provider to upgrade the database after confirming application compatibility and backups.',
						'wphave',
					),
				);
				return true;
			}
			if ($support['securityStatus'] !== 'supported') {
				self::add_finding(
					$findings,
					'database_runtime_security_support',
					'warning',
					'high',
					'Database',
					$support['securityStatus'] === 'ended'
						? __(
							'Public upstream maintenance for this database release has ended.',
							'wphave',
						)
						: __(
							'Public upstream maintenance for this database release could not be verified.',
							'wphave',
						),
					__('Database maintenance status', 'wphave'),
					__(
						'Use a maintained stable database release. Confirm hosting backports or paid extended support with your provider.',
						'wphave',
					),
				);
				return true;
			}
		}

		return false;
	}

	/** Synchronize the automatic scan event with saved settings. */

	public static function sync_cron_schedule(): void {
		$settings = self::get_scan_settings();
		$enabled = $settings['auto_enabled'] && self::has_automation_access();
		$schedule = WPHAVE_Background_Job_Scheduler::schedule_for_frequency($settings['frequency']);

		WPHAVE_Background_Job_Scheduler::sync_recurring(
			self::CRON_HOOK,
			self::SCHEDULE_OPTION,
			$enabled,
			$schedule,
			self::next_time_window_timestamp($settings['time_window']),
			$settings['time_window'],
			true,
		);

		if (!$enabled) {
			self::cancel_scheduled_job();
		}
	}

	/** Run or continue an automatic scan within the worker time budget. */

	public static function run_scheduled_scan($mode = 'start'): void {
		$token = self::acquire_automation_lock();
		if (!$token) {
			return;
		}
		try {
			$settings = self::get_scan_settings();
			if (!$settings['auto_enabled'] || !self::has_automation_access()) {
				self::cancel_scheduled_job();
				return;
			}
			$job = get_option(self::JOB_OPTION, []);
			if (is_array($job) && isset($job['tasks']) && empty($job['scheduled'])) {
				return;
			}
			if (
				$mode === 'continue' &&
				(!is_array($job) || !isset($job['tasks']) || empty($job['scheduled']))
			) {
				return;
			}
			if (!is_array($job) || !isset($job['tasks'])) {
				delete_option(self::CANCEL_OPTION);
			}
			$results =
				is_array($job) && isset($job['tasks']) ? self::get_results() : self::start(true);
			$results = WPHAVE_Background_Job_Runner::run(
				static fn($remaining_time) => self::process_batch($remaining_time),
				static fn($state) => is_array($state) && 'running' === ($state['state'] ?? ''),
				static fn($state) => absint($state['processed'] ?? 0),
				self::MAX_AUTOMATION_TIME,
				$results,
			);

			if (($results['state'] ?? '') === 'running') {
				WPHAVE_Background_Job_Scheduler::ensure_continuation(
					self::CRON_HOOK,
					['continue'],
					2 * MINUTE_IN_SECONDS,
				);
				return;
			}
		} finally {
			self::release_automation_lock($token);
		}
	}

	/** Resume a valid automatic job or safely close a stale job. */

	public static function recover_interrupted_scan(): void {
		$job = get_option(self::JOB_OPTION, []);
		if (
			!is_array($job) ||
			empty($job['scheduled']) ||
			!isset($job['tasks'], $job['processed'])
		) {
			return;
		}

		if (!self::get_scan_settings()['auto_enabled'] || !self::has_automation_access()) {
			self::cancel_scheduled_job();
			return;
		}

		$updated = absint($job['updatedAt'] ?? ($job['createdAt'] ?? 0));
		if ($updated && time() - $updated > 30 * MINUTE_IN_SECONDS) {
			$lock = self::acquire_lock();
			if (!$lock) {
				return;
			}

			try {
				// CONCURRENCY INVARIANT: Recovery revalidates staleness only after
				// acquiring the batch lease; an active successor remains authoritative.
				$current_job = get_option(self::JOB_OPTION, []);
				$current_updated = is_array($current_job)
					? absint($current_job['updatedAt'] ?? ($current_job['createdAt'] ?? 0))
					: 0;
				if (!$current_updated || time() - $current_updated <= 30 * MINUTE_IN_SECONDS) {
					return;
				}

				wp_clear_scheduled_hook(self::CRON_HOOK, ['continue']);
				delete_option(self::JOB_OPTION);
				$results = self::get_results();
				unset($results['automation']);
				$results['state'] = 'failed';
				$results['errors'][] = [
					'check' => 'scan_recovery',
					'message' => __(
						'The previous automatic security check stopped responding and was safely closed. The next scheduled check will start fresh.',
						'wphave',
					),
				];
				update_option(self::RESULTS_OPTION, $results, false);
			} finally {
				self::release_lock($lock);
			}
			return;
		}
		WPHAVE_Background_Job_Scheduler::ensure_continuation(
			self::CRON_HOOK,
			['continue'],
			MINUTE_IN_SECONDS,
		);
	}

	/** Cancel a persisted automatic job without affecting manual scans. */

	private static function cancel_scheduled_job(): void {
		$job = get_option(self::JOB_OPTION, []);
		if (!is_array($job) || empty($job['scheduled'])) {
			delete_option(self::CANCEL_OPTION);
			return;
		}

		wp_clear_scheduled_hook(self::CRON_HOOK, ['continue']);
		update_option(self::CANCEL_OPTION, 1, false);

		$lock = self::acquire_lock();
		if (!$lock) {
			return;
		}

		try {
			self::finalize_cancelled_job();
		} finally {
			self::release_lock($lock);
		}
	}

	/** Persist a cancelled result while the caller owns the scan lock. */

	private static function finalize_cancelled_job(): array {
		delete_option(self::CANCEL_OPTION);
		delete_option(self::JOB_OPTION);

		$results = self::get_results();
		unset($results['automation']);
		$results['state'] = 'cancelled';
		$results['finishedAt'] = current_time('mysql');
		$results['currentCheck'] = '';
		$results['notice'] = __(
			'The automatic security check was cancelled because automatic checks were disabled.',
			'wphave',
		);
		update_option(self::RESULTS_OPTION, $results, false);

		return $results;
	}

	/** Return normalized automatic scan settings. */

	private static function get_scan_settings(): array {
		$settings = wphave_data_get('site_settings', 'advanced.security.scan', []);
		$settings = is_array($settings) ? $settings : [];
		$frequency = sanitize_key($settings['frequency'] ?? 'weekly');
		$time_window = sanitize_key($settings['time_window'] ?? 'night');
		// SECURITY-REPORT INVARIANT: A scheduled posture report cannot be sent
		// to a mailbox produced by lossy sanitization of stored settings.
		$email = WPHAVE_Email_Identity::exact($settings['email'] ?? '');
		return [
			'auto_enabled' => !empty($settings['auto_enabled']),
			'frequency' => in_array($frequency, ['daily', 'weekly', 'monthly'], true)
				? $frequency
				: 'weekly',
			'time_window' => in_array(
				$time_window,
				['night', 'morning', 'afternoon', 'evening'],
				true,
			)
				? $time_window
				: 'night',
			'email' => $email ?: WPHAVE_Email_Identity::exact(get_option('admin_email')),
		];
	}

	/** Determine whether scheduled Pro scanner workflows may run. */

	private static function has_automation_access(): bool {
		$allowed = function_exists('wphave_has_pro_access') && wphave_has_pro_access();

		return (bool) apply_filters('wphave_security_scan_automation_access', $allowed);
	}

	/** Calculate the next start timestamp for a preferred time window. */

	private static function next_time_window_timestamp(string $time_window): int {
		return WPHAVE_Background_Job_Scheduler::next_time_window($time_window);
	}

	/** Build the automation status exposed with scan results. */

	private static function get_automation_status(array $results): array {
		$settings = self::get_scan_settings();
		$next = wp_next_scheduled(self::CRON_HOOK, []);
		$notification = get_option(self::NOTIFICATION_OPTION, []);
		$notification = is_array($notification) ? $notification : [];
		return [
			'enabled' => $settings['auto_enabled'],
			'frequency' => $settings['frequency'],
			'timeWindow' => $settings['time_window'],
			'email' => $settings['email'],
			'nextRun' => $next ? wp_date('Y-m-d H:i:s', $next) : '',
			'timing' => $settings['auto_enabled']
				? WPHAVE_Background_Job_Scheduler::display_timing(self::CRON_HOOK)
				: null,
			'lastAutomaticRun' => sanitize_text_field(
				get_option(
					self::LAST_AUTOMATIC_OPTION,
					!empty($results['scheduled']) ? $results['finishedAt'] ?? '' : '',
				),
			),
			'lastNotification' => sanitize_text_field($notification['sentAt'] ?? ''),
			'lastNotificationAttempt' => sanitize_text_field($notification['attemptedAt'] ?? ''),
			'lastNotificationStatus' => sanitize_key($notification['status'] ?? ''),
			'lastNotificationEmail' => WPHAVE_Email_Identity::exact($notification['email'] ?? ''),
		];
	}

	/** Acquire the longer-lived automatic worker lock. */

	private static function acquire_automation_lock() {
		return WPHAVE_Background_Job_Lock::acquire(
			self::AUTOMATION_LOCK_OPTION,
			self::MAX_AUTOMATION_TIME + MINUTE_IN_SECONDS,
		);
	}

	/** Release the automatic worker lock owned by the token. */

	private static function release_automation_lock(string $token): void {
		WPHAVE_Background_Job_Lock::release(self::AUTOMATION_LOCK_OPTION, $token);
	}

	/** Notify the configured recipient about new or escalated findings. */

	private static function maybe_send_scan_notification(array $results, array $settings): void {
		$findings = is_array($results['findings'] ?? null) ? $results['findings'] : [];
		$current = [];
		foreach ($findings as $finding) {
			$current[(string) ($finding['id'] ?? '')] = sanitize_key(
				$finding['severity'] ?? 'warning',
			);
		}
		$previous = get_option(self::NOTIFIED_OPTION, []);
		$previous = is_array($previous) ? $previous : [];
		$notification_state = !empty($results['coverageLimited'])
			? array_merge($previous, $current)
			: $current;
		$ranks = ['warning' => 1, 'high' => 2, 'critical' => 3];
		$changed = array_values(
			array_filter($findings, static function ($finding) use ($previous, $ranks) {
				$id = (string) ($finding['id'] ?? '');
				$severity = sanitize_key($finding['severity'] ?? 'warning');
				return !isset($previous[$id]) ||
					($ranks[$severity] ?? 0) > ($ranks[$previous[$id]] ?? 0);
			}),
		);
		if (!$changed) {
			update_option(self::NOTIFIED_OPTION, $notification_state, false);
			return;
		}

		if (!$settings['email']) {
			return;
		}
		$has_critical = (bool) array_filter(
			$changed,
			static fn($finding) => ($finding['severity'] ?? '') === 'critical',
		);
		$site_name = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);
		$subject = $has_critical
			? sprintf(__('[%s] Critical security finding detected', 'wphave'), $site_name)
			: sprintf(__('[%s] Security check found changes to review', 'wphave'), $site_name);
		$content =
			'<p><strong>' .
			esc_html(sprintf(__('New or escalated findings: %d', 'wphave'), count($changed))) .
			'</strong></p><ul style="margin: 0; padding-left: 20px;">';

		foreach ($changed as $finding) {
			$severity = strtoupper((string) ($finding['severity'] ?? 'warning'));
			$title = $finding['title'] ?? ($finding['check'] ?? __('Security finding', 'wphave'));
			$path = $finding['path'] ?? '';
			$content .=
				'<li><strong>[' . esc_html($severity) . '] ' . esc_html($title) . '</strong>';
			$content .= $path ? '<br><code>' . esc_html($path) . '</code>' : '';
			$content .= '</li>';
		}

		$content .= '</ul>';

		if (!empty($results['coverageLimited']) || ($results['state'] ?? '') === 'partial') {
			$content .=
				'<p><strong>' .
				esc_html__(
					'Coverage was limited by the scanner resource budget. Review the coverage details and run another check after resolving the displayed findings.',
					'wphave',
				) .
				'</strong></p>';
		}

		if (!empty($results['findingsTruncated'])) {
			$content .=
				'<p><strong>' .
				esc_html__(
					'Only the first 1,000 finding details are included. Severity totals still include every detected finding.',
					'wphave',
				) .
				'</strong></p>';
		}

		$content .=
			'<p>' .
			esc_html__(
				'Open WPHAVE Security Manager to review evidence and recommendations.',
				'wphave',
			) .
			'</p>';

		$message = wphave_build_email_template([
			'title' => $has_critical
				? __('Critical security finding detected', 'wphave')
				: __('Security findings need review', 'wphave'),
			'description' => sprintf(
				__(
					'The automatic security check for %s found new or more severe findings.',
					'wphave',
				),
				esc_html(home_url('/')),
			),
			'content' => $content,
			'footer_content' => esc_html__(
				'This notification was generated automatically by WPHAVE Security.',
				'wphave',
			),
		]);

		$sent = wp_mail($settings['email'], $subject, $message, wphave_email_template_headers());
		$notification = get_option(self::NOTIFICATION_OPTION, []);
		$notification = is_array($notification) ? $notification : [];
		$notification['attemptedAt'] = current_time('mysql');
		$notification['status'] = $sent ? 'sent' : 'failed';
		$notification['email'] = $settings['email'];
		$notification['findings'] = count($changed);

		if ($sent) {
			update_option(self::NOTIFIED_OPTION, $notification_state, false);
			$notification['sentAt'] = $notification['attemptedAt'];
		}

		update_option(self::NOTIFICATION_OPTION, $notification, false);
	}

	/**
	 * Returns the existing WordPress configuration path, if discoverable.
	 */

	private static function wordpress_config_path(): string {
		$root = realpath(ABSPATH);

		if (false === $root || !is_dir($root)) {
			return '';
		}

		$root = untrailingslashit(wp_normalize_path($root));
		$candidates = [dirname($root) . '/wp-config.php', $root . '/wp-config.php'];

		// CONFIG PATH INVARIANT: Parent fallback is derived from the real
		// WordPress root. dirname() must never operate on an ABSPATH spelling that
		// still contains dot segments or a symlink alias.
		foreach ($candidates as $candidate) {
			if (is_file($candidate) && !is_link($candidate)) {
				return $candidate;
			}
		}

		return '';
	}

	/** Normalize and validate a path relative to a scan root. */

	private static function normalize_relative_path($path): string {
		$path = str_replace('\\', '/', trim((string) $path));
		$path = ltrim(preg_replace('#/+#', '/', $path), '/');

		if ($path === '' || preg_match('/[\x00-\x1F\x7F]/', $path)) {
			return '';
		}

		foreach (explode('/', $path) as $segment) {
			if ($segment === '' || $segment === '.' || $segment === '..') {
				return '';
			}
		}

		return $path;
	}

	/** Determine whether a path uses a PHP-executable extension. */

	private static function is_executable_extension(string $path): bool {
		return (bool) preg_match('/\.(?:php(?:[3-8]|s)?|phtml|phar)$/i', $path);
	}

	/** Identify the conventional harmless uploads index.php placeholder. */

	private static function is_safe_upload_index(SplFileInfo $file): bool {
		if (strtolower($file->getFilename()) !== 'index.php' || $file->getSize() > 256) {
			return false;
		}
		$content = @file_get_contents($file->getPathname());
		if (!is_string($content)) {
			return false;
		}
		return (bool) preg_match(
			'/^<\?php\s*(?:\/\/\s*Silence is golden\.\s*|\/\*\s*Silence is golden\.\s*\*\/)$/i',
			trim($content),
		);
	}

	/** Count findings by severity. */

	private static function count_findings(array $findings): array {
		$counts = ['critical' => 0, 'high' => 0, 'warning' => 0, 'total' => count($findings)];
		foreach ($findings as $finding) {
			$severity = $finding['severity'] ?? '';
			if (isset($counts[$severity])) {
				$counts[$severity]++;
			}
		}
		return $counts;
	}

	/** Return the normalized empty result structure. */

	private static function empty_results(): array {
		return [
			'state' => 'idle',
			'startedAt' => '',
			'finishedAt' => '',
			'processed' => 0,
			'total' => 0,
			'currentCheck' => '',
			'findings' => [],
			'counts' => ['critical' => 0, 'high' => 0, 'warning' => 0, 'total' => 0],
			'checks' => [],
			'errors' => [],
			'truncated' => false,
			'coverageLimited' => false,
			'findingsTruncated' => false,
			'limitedAreas' => [],
			'notice' => '',
			'scheduled' => false,
		];
	}
}

WPHAVE_Security_Scanner::init();
