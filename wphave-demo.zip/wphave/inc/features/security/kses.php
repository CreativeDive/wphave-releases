<?php

if (!defined('ABSPATH')) {
	exit();
}

/**
 * Allow the additional HTML required by WPHAVE when content is sanitized with wp_kses_post().
 */

if (!function_exists('wphave_wp_kses_allowed_html')):
	function wphave_wp_kses_allowed_html($tags, $context) {
		if ('post' !== $context) {
			return $tags;
		}

		// Base attributes
		$global_atts = [
			'id' => true,
			'role' => true,
			'class' => true,
			'style' => true, // Filtered via wp "safe_style_css" filter
			'title' => true,
			'hidden' => true,
			'aria-label' => true,
			'aria-labelledby' => true,
			'aria-describedby' => true,
			'aria-description' => true,
			'aria-details' => true,
			'aria-errormessage' => true,
			'aria-hidden' => true,
			'aria-live' => true,
			'aria-atomic' => true,
			'aria-busy' => true,
			'aria-relevant' => true,
			'aria-pressed' => true,
			'aria-checked' => true,
			'aria-selected' => true,
			'aria-expanded' => true,
			'aria-controls' => true,
			'aria-owns' => true,
			'aria-flowto' => true,
			'aria-activedescendant' => true,
			'aria-current' => true,
			'aria-haspopup' => true,
			'aria-modal' => true,
			'aria-invalid' => true,
			'aria-required' => true,
			'aria-readonly' => true,
			'aria-disabled' => true,
			'aria-autocomplete' => true,
			'aria-multiline' => true,
			'aria-multiselectable' => true,
			'aria-orientation' => true,
			'aria-placeholder' => true,
			'aria-keyshortcuts' => true,
			'aria-roledescription' => true,
			'aria-braillelabel' => true,
			'aria-brailleroledescription' => true,
			'aria-level' => true,
			'aria-posinset' => true,
			'aria-setsize' => true,
			'aria-sort' => true,
			'aria-colcount' => true,
			'aria-colindex' => true,
			'aria-colindextext' => true,
			'aria-colspan' => true,
			'aria-rowcount' => true,
			'aria-rowindex' => true,
			'aria-rowindextext' => true,
			'aria-rowspan' => true,
			'aria-valuemax' => true,
			'aria-valuemin' => true,
			'aria-valuenow' => true,
			'aria-valuetext' => true,
		];

		// Media attributes
		$media_atts = [
			'src' => true,
			'alt' => true,
			'loop' => true,
			'muted' => true,
			'sizes' => true,
			'width' => true,
			'height' => true,
			'srcset' => true,
			'poster' => true,
			'loading' => true,
			'controls' => true,
			'autoplay' => true,
			'playsinline' => true,
			'fetchpriority' => true,
		];

		// Form attributes
		$link_atts = [
			'href' => true,
			'target' => true,
			'rel' => true,
		];

		// Link attributes
		$form_atts = [
			'type' => true,
			'name' => true,
			'value' => true,
			'method' => true,
			'action' => true,
			'checked' => true,
			'disabled' => true,
			'enctype' => true,
			'required' => true,
			'selected' => true,
			'tabindex' => true,
			'novalidate' => true,
			'autocomplete' => true,
		];

		// Data attributes
		$data_atts = [
			'data-*' => true,
			'data-id' => true,
			'data-url' => true,
			'data-type' => true,
			'data-view' => true,
			'data-color' => true,
			'data-modal' => true,
			'data-panel' => true,
			'data-toggle' => true,
			'data-parent' => true,
			'data-tooltip' => true,
			'data-popover' => true,
			'data-modal-id' => true,
			'data-thickness' => true,
			'data-placement' => true,
			'data-magnify-src' => true,
			'data-request-url' => true,
			'data-options-url' => true,
			'data-confirm-url' => true,
			'data-confirm-token' => true,
			'data-message-loading' => true,
			'data-message-requested' => true,
			'data-message-updated' => true,
			'data-label-general' => true,
		];

		// Embed attributes
		$embed_atts = [
			'frameborder' => true,
			'allowfullscreen' => true,
			'allowtransparency' => true,
		];

		// iframe attributes
		$iframe_atts = array_merge($global_atts, $embed_atts, [
			'src' => true,
			'width' => true,
			'height' => true,
			'allow' => true,
			'referrerpolicy' => true,
		]);

		// SECURITY INVARIANT (SEC-22): Only passive SVG attributes belong in
		// post KSES. In particular, attributeName is excluded: an animation can
		// otherwise turn a validated #link into javascript: after saving.
		// Svg attributes
		$svg_atts = [
			'd' => true,
			'x' => true,
			'y' => true,
			'r' => true,
			'x1' => true,
			'y1' => true,
			'x2' => true,
			'y2' => true,
			'cx' => true,
			'cy' => true,
			'rx' => true,
			'ry' => true,
			'dur' => true,
			'mask' => true,
			'fill' => true,
			'xmlns' => true,
			'begin' => true,
			'values' => true,
			'offset' => true,
			'stroke' => true,
			'points' => true,
			'opacity' => true,
			'version' => true,
			'viewbox' => true, // <= Must be lower case!
			'xml:space' => true,
			'transform' => true,
			'focusable' => true,
			'fill-rule' => true,
			'stop-color' => true,
			'xmlns:xlink' => true,
			'repeatcount' => true, // <= Must be lower case!
			'pathlength' => true, // <= Must be lower case!
			'patternunits' => true, // <= Must be lower case!
			'fill-opacity' => true,
			'stroke-width' => true,
			'vector-effect' => true,
			'clippathunits' => true, // <= Must be lower case!
			'gradientunits' => true, // <= Must be lower case!
			'stroke-linecap' => true,
			'stroke-linejoin' => true,
			'patterntransform' => true, // <= Must be lower case!
			'stroke-dasharray' => true,
			'stroke-dashoffset' => true,
			'gradienttransform' => true, // <= Must be lower case!
			'preserveaspectratio' => true, // <= Must be lower case!
		];

		// Misc attributes
		$misc_atts = [
			'rev' => true,
			'for' => true,
			'name' => true,
			'align' => true,
			'itemprop' => true,
			'isolation' => true,
		];

		// Combine attributes
		$common_atts = array_merge(
			$global_atts,
			$media_atts,
			$form_atts,
			$link_atts,
			$data_atts,
			$misc_atts,
		);

		$content_tags = [
			'a',
			'p',
			'q',
			'b',
			'i',
			'u',
			's',
			'em',
			'del',
			'ins',
			'bdi',
			'sup',
			'sub',
			'div',
			'pre',
			'span',
			'mark',
			'code',
			'time',
			'abbr',
			'cite',
			'small',
			'strong',
			'address',
			'acronym',
			'blockquote',
		];

		$heading_tags = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'];

		$list_tags = ['ul', 'ol', 'li', 'dl', 'dt', 'dd'];

		$table_tags = ['tr', 'td', 'th', 'table', 'thead', 'tbody', 'tfoot', 'caption'];

		$form_tags = [
			'form',
			'input',
			'label',
			'select',
			'option',
			'button',
			'legend',
			'optgroup',
			'fieldset',
			'textarea',
		];

		$advanced_form_tags = ['meter', 'output', 'keygen', 'progress', 'datalist'];

		$embed_tags = ['embed', 'param', 'object', 'canvas'];

		$media_tags = ['img', 'track', 'video', 'audio', 'source', 'iframe', 'picture'];

		$semantic_tags = [
			'nav',
			'main',
			'aside',
			'header',
			'footer',
			'figure',
			'section',
			'article',
			'figcaption',
		];

		// SECURITY INVARIANT (SEC-22): Do not add animate or other SMIL mutation
		// tags to post HTML. Save-time KSES must reject executable link changes.
		$svg_tags = [
			'g',
			'svg',
			'use',
			'stop',
			'mask',
			'path',
			'rect',
			'line',
			'defs',
			'circle',
			'ellipse',
			'polygon',
			'pattern',
			'clippath',
			'foreignobject',
			'lineargradient',
		];

		$misc_tags = [
			'hr',
			'br',
			'map',
			'wbr',
			'area',
			'math',
			'data',
			//'style',
		];

		$all_groups = array_merge(
			$content_tags,
			$heading_tags,
			$list_tags,
			$table_tags,
			$form_tags,
			$advanced_form_tags,
			$media_tags,
			$semantic_tags,
			$embed_tags,
			$misc_tags,
		);

		foreach ($all_groups as $tag) {
			$tags[$tag] = $common_atts;
		}

		// Links
		$tags['a'] = array_merge($common_atts, $link_atts);

		// Media
		$tags['img'] = array_merge($common_atts, $media_atts);
		$tags['video'] = array_merge($common_atts, $media_atts);
		$tags['audio'] = array_merge($common_atts, $media_atts);

		// iframe
		$tags['iframe'] = $iframe_atts;

		// SVG
		foreach ($svg_tags as $tag) {
			$tags[$tag] = array_merge($common_atts, $svg_atts);
		}

		// Allow "style" for the following svg tags only
		$tags['svg']['style'] = true;
		$tags['path']['style'] = true;

		// Return filtered
		return $tags;
	}
endif;

add_filter('wp_kses_allowed_html', 'wphave_wp_kses_allowed_html', 10, 2);

/**
 * Neutralize SVG attribute animation in content saved before SEC-22 was fixed.
 *
 * KSES runs on new writes, not on previously stored post HTML. Keep the output
 * boundary independent of the current visitor and the saved author's current
 * role: historical bytes must never gain script authority by changing either.
 */
function wphave_neutralize_legacy_svg_animation($html) {
	if (!is_string($html) || stripos($html, '<animate') === false) {
		return $html;
	}

	// SECURITY INVARIANT (SEC-22): An SVG animation must not mutate a link or
	// another browser-interpreted attribute after KSES has checked its URL.
	// The HTML tag processor preserves unrelated block markup and text.
	$processor = new WP_HTML_Tag_Processor($html);
	while ($processor->next_tag()) {
		if ('ANIMATE' !== $processor->get_tag()) {
			continue;
		}

		foreach (['attributeName', 'values', 'from', 'to', 'by'] as $attribute) {
			$processor->remove_attribute($attribute);
		}
	}

	return $processor->get_updated_html();
}

add_filter('the_content', 'wphave_neutralize_legacy_svg_animation', PHP_INT_MAX);
add_filter('render_block', 'wphave_neutralize_legacy_svg_animation', PHP_INT_MAX);

/**
 * Recursively sanitize SVG markup stored inside block attributes.
 *
 * Block JSON lives in HTML comments and must not rely on frontend escaping or
 * editor previews as its first trust boundary.
 *
 * @param mixed $value Attribute value.
 * @param string $key Attribute key.
 * @return mixed Sanitized attribute value.
 */

function wphave_sanitize_block_svg_attribute_value($value, string $key = '') {
	if (is_array($value)) {
		foreach ($value as $child_key => $child_value) {
			$value[$child_key] = wphave_sanitize_block_svg_attribute_value(
				$child_value,
				(string) $child_key,
			);
		}

		return $value;
	}

	if (strtolower($key) !== 'svg' || !is_string($value) || stripos($value, '<svg') === false) {
		return $value;
	}

	$sanitized = WPHAVE_Safe_SVG::sanitize_markup($value);

	return is_string($sanitized) ? $sanitized : '';
}

/**
 * Sanitize SVG attributes throughout one parsed block tree.
 *
 * @param array $block Parsed block.
 * @return array Sanitized block.
 */

function wphave_sanitize_block_svg_attributes(array $block): array {
	if (is_array($block['attrs'] ?? null)) {
		$block['attrs'] = wphave_sanitize_block_svg_attribute_value($block['attrs']);
	}

	if (is_array($block['innerBlocks'] ?? null)) {
		foreach ($block['innerBlocks'] as $index => $inner_block) {
			if (is_array($inner_block)) {
				$block['innerBlocks'][$index] = wphave_sanitize_block_svg_attributes($inner_block);
			}
		}
	}

	return $block;
}

/**
 * Sanitize SVG block attributes before post content is stored.
 *
 * @param string $content Slashed post content.
 * @return string Sanitized post content.
 */

function wphave_sanitize_block_svg_attributes_on_save($content) {
	if (!is_string($content) || !has_blocks($content)) {
		return $content;
	}

	$unslashed_content = wp_unslash($content);

	if (stripos($unslashed_content, '"svg"') === false) {
		return $content;
	}

	$blocks = parse_blocks($unslashed_content);

	foreach ($blocks as $index => $block) {
		if (is_array($block)) {
			$blocks[$index] = wphave_sanitize_block_svg_attributes($block);
		}
	}

	return wp_slash(serialize_blocks($blocks));
}

add_filter('content_save_pre', 'wphave_sanitize_block_svg_attributes_on_save', 12);
