<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Removes explicitly owned directory trees without traversing symbolic links.
 */

final class WPHAVE_Security_Owned_Tree {

	/**
	 * Removes one real descendant directory below a caller-owned root.
	 */

	public static function remove( string $directory, string $allowed_root, string $error_message ): void {
		$root = is_link( $allowed_root ) ? false : realpath( $allowed_root );
		$target = is_link( $directory ) ? false : realpath( $directory );

		if (
			false === $root
			|| false === $target
			|| ! is_dir( $target )
			|| wp_normalize_path( $target ) === untrailingslashit( wp_normalize_path( $root ) )
			|| ! str_starts_with(
				trailingslashit( wp_normalize_path( $target ) ),
				trailingslashit( wp_normalize_path( $root ) )
			)
		) {
			throw new RuntimeException( $error_message );
		}

		$target = untrailingslashit( wp_normalize_path( $target ) );

		try {
			$iterator = new RecursiveIteratorIterator(
				new RecursiveDirectoryIterator( $target, FilesystemIterator::SKIP_DOTS ),
				RecursiveIteratorIterator::CHILD_FIRST
			);
		} catch ( UnexpectedValueException $error ) {
			throw new RuntimeException( $error_message );
		}

		foreach ( $iterator as $item ) {
			$path = wp_normalize_path( $item->getPathname() );

			// SECURITY INVARIANT: Every removed node stays lexically and canonically
			// below the original target. Revalidating the target and node parent before
			// each mutation rejects directory-to-symlink exchanges during iteration.
			if (
				! str_starts_with( $path, trailingslashit( $target ) )
				|| ! self::node_parent_is_owned( $target, $path )
			) {
				throw new RuntimeException( $error_message );
			}

			// OBSERVABILITY INVARIANT: Expected filesystem races become the caller's
			// canonical exception and never leak native warnings or absolute paths into
			// REST, backup-job or uninstall output.
			$removed = $item->isLink() || ! $item->isDir() ? @unlink( $path ) : @rmdir( $path );

			if ( ! $removed ) {
				throw new RuntimeException( $error_message );
			}
		}

		if ( ! self::target_identity_is_stable( $target ) || ! @rmdir( $target ) ) {
			throw new RuntimeException( $error_message );
		}
	}

	/**
	 * Confirm that the canonical target still identifies its original real directory.
	 */

	private static function target_identity_is_stable( string $target ): bool {
		$current_target = is_link( $target ) ? false : realpath( $target );

		return false !== $current_target
			&& untrailingslashit( wp_normalize_path( $current_target ) ) === $target;
	}

	/**
	 * Confirm that a node's current real parent remains inside the owned target.
	 */

	private static function node_parent_is_owned( string $target, string $path ): bool {
		if ( ! self::target_identity_is_stable( $target ) ) {
			return false;
		}

		$parent = realpath( dirname( $path ) );
		if ( false === $parent ) {
			return false;
		}

		$parent = untrailingslashit( wp_normalize_path( $parent ) );

		return $parent === $target
			|| str_starts_with( trailingslashit( $parent ), trailingslashit( $target ) );
	}
}
