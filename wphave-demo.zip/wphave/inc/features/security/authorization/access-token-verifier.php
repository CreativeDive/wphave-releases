<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

	/**
	 * Verifies signed WPHAVE access tokens on the PHP side.
	 *
	 * Browser WebCrypto remains the preferred verification path. This class is
	 * the fallback for valid WordPress installs that do not run the admin over a
	 * secure browser context. It must mirror the JavaScript verifier and must not
	 * grant access from local options or unsigned broker responses.
	 */

	class WPHAVE_License_Token_Verifier {

		// Token versions and public keys are release contracts with the remote
		// broker. Keep v2 verification available during any future rotation; old
		// plugin installations cannot learn a replacement protocol dynamically.
		private const TOKEN_VERSION = 'v2';
		private const TOKEN_MAX_TTL = 172800; // 48 hours.
		private const PRODUCT_ID = 22113;

		/**
		 * Register the REST endpoint used by the browser fallback.
		 *
		 * @return void
		 */

		public static function register_routes(): void {

			register_rest_route( 'wphave/v1', '/license/verify-token', [
				'methods' => 'POST',
				'callback' => [ __CLASS__, 'rest_verify_token' ],
				'permission_callback' => [ __CLASS__, 'can_verify_token' ],
				'args' => [
					'data' => [
						'required' => true,
						'type' => 'object',
						'sanitize_callback' => [ __CLASS__, 'sanitize_route_object' ],
					],
					'expected' => [
						'required' => true,
						'type' => 'object',
						'sanitize_callback' => [ __CLASS__, 'sanitize_route_object' ],
					],
				],
			] );

		}

		/**
		 * Check whether the current user may verify a license token.
		 *
		 * Token verification is read-only, but it is part of the license
		 * activation flow and therefore intentionally restricted to users that
		 * may manage WPHAVE settings.
		 *
		 * @return bool
		 */

		public static function can_verify_token(): bool {

			return current_user_can( 'manage_options' ) && current_user_can( 'edit_theme_options' );

		}

		/**
		 * REST callback for PHP-side signed token verification.
		 *
		 * @param WP_REST_Request $request REST request.
		 * @return array|WP_Error
		 */

		public static function rest_verify_token( WP_REST_Request $request ) {
			// AUTHORIZATION/LICENSE-TOKEN INVARIANT: The REST permission callback is
			// only a transport gate. Direct invocation must not expose signed license
			// claims or offer verification as a deputy without both management caps.
			if( ! self::can_verify_token() ) {
				return new WP_Error(
					'wphave_license_token_forbidden',
					__( 'You are not allowed to verify license tokens.', 'wphave' ),
					[ 'status' => 403 ]
				);
			}

			$data = self::sanitize_token_data( (array) $request->get_param( 'data' ) );
			$expected = self::sanitize_expected_data( (array) $request->get_param( 'expected' ) );
			$payload = self::verified_payload( $data, $expected );

			if( ! $payload ) {
				return new WP_Error(
					'wphave_license_token_invalid',
					__( 'The signed license token could not be verified.', 'wphave' ),
					[ 'status' => 403 ]
				);
			}

			return [
				'valid' => true,
				'payload' => $payload,
			];

		}

		/**
		 * Sanitize a first-level REST object before claim-specific sanitizers run.
		 *
		 * @param mixed $value Raw REST object.
		 * @return array Sanitized first-level object.
		 */

		public static function sanitize_route_object( $value ): array {

			$value = is_array( $value ) ? $value : [];
			$sanitized = [];
			$allowed_keys = [
				'token',
				'uid',
				'licenseId',
				'installId',
				'domain',
				'access',
				'allowExpiredGrace',
				'allowOfflineContinuity',
				'graceUntil',
			];

			foreach( $value as $key => $item ) {
				$key = is_string( $key ) ? $key : '';

				// SECURITY INVARIANT: Claim names are protocol identifiers, not generic
				// option keys. Lowercasing camelCase would silently remove paid-license
				// identity before verification. Unknown keys are rejected instead.
				if( ! in_array( $key, $allowed_keys, true ) ) {
					continue;
				}

				if( is_array( $item ) ) {
					$sanitized[$key] = array_map( 'sanitize_text_field', wp_unslash( $item ) );
					continue;
				}

				$sanitized[$key] = sanitize_text_field( wp_unslash( (string) $item ) );
			}

			return $sanitized;

		}

		/**
		 * Verify token format, signature and expected claims.
		 *
		 * @param array $data License/access token data.
		 * @param array $expected Expected verification constraints.
		 * @return array|false Verified payload or false.
		 */

		public static function verified_payload( array $data, array $expected = [] ) {

			$token = isset( $data['token'] ) ? (string) $data['token'] : '';

			if( ! str_starts_with( $token, self::TOKEN_VERSION . '.' ) ) {
				return false;
			}

			$parts = explode( '.', $token );

			if( count( $parts ) !== 3 || $parts[0] !== self::TOKEN_VERSION ) {
				return false;
			}

			[ $version, $payload_encoded, $signature_encoded ] = $parts;

			$public_key = openssl_pkey_get_public( self::public_key_pem() );

			if( ! $public_key ) {
				return false;
			}

			$signed_data = $version . '.' . $payload_encoded;
			$signature = self::base64url_decode( $signature_encoded );

			// SECURITY INVARIANT: Claims gain authorization value only after the exact
			// version and encoded payload bytes have passed signature verification.
			// Decoded but unsigned payload data is never returned to a caller.
			if( $signature === false || openssl_verify( $signed_data, $signature, $public_key, OPENSSL_ALGO_SHA256 ) !== 1 ) {
				return false;
			}

			$payload_json = self::base64url_decode( $payload_encoded );
			$payload = $payload_json ? json_decode( $payload_json, true ) : null;

			if( ! is_array( $payload ) ) {
				return false;
			}

			// SECURITY INVARIANT: A valid signature establishes origin, not scope.
			// Time, installation and requested-access claims must also match the local
			// request before the signed payload can grant access.
			return self::payload_matches_expected_claims( $payload, $data, $expected ) ? $payload : false;

		}

		/**
		 * Return the public key used for broker token verification.
		 *
		 * @return string PEM encoded public key.
		 */

		public static function public_key_pem(): string {

			$public_key = <<<'PEM'
-----BEGIN PUBLIC KEY-----
MIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEA69Nec825RBOEp2CX4vf6
eBYBeDoxo8pbDt/XcGHDNyzG932O0nFJXLLE14v1O/NIdIv5Kw/2YPb1SQ9cQrJu
a3qVkXlzdzpWG/iWazo05yfIoChDBO3dqpk0THOuJ+IBuyxxjebfXdFJ1w0b9AqT
cDRkDRXyyqPEyJ+gzlD7XzsveK0VhnJokLnzFEPHTnwneRouEvSRjtXsAtyc9rez
lXjgrEEnb+vbXm+MDoXBhCbHaux22ZtDKeTvmJoZQxxKX9tqBUcdfEL8zACtS8b7
X5xBvNkndg1CQB0g8NYzGAijKm+xMymVFqSuqiZ7x7jhf190w2dbTAZwrdJ+vNkg
2Af+tpkbe31+JQZnCv7O1Yz6es9xQd/YAZ7CYQN4jA9oKbC/DjTGcL9xXI45dLAw
pNQWQPSezeEsCWv6gPxf7i9KzWdCq2Ic/MxrfMqn4/cMOuPeIc8R1qY/lxmLMwIm
hxVwpyo3/IlE4GXJBLZCfSJfyo7vzgcrSPl2pGxgWbzZAgMBAAE=
-----END PUBLIC KEY-----
PEM;

			/*
			 * SECURITY INVARIANT: The verification key is a release trust anchor.
			 * WordPress filters must never replace it because another plugin could
			 * otherwise mint tokens against an attacker-controlled key pair.
			 */
			return $public_key;

		}

		/**
		 * Check token payload claims against the local request constraints.
		 *
		 * @param array $payload Verified signed token payload.
		 * @param array $data Local token data.
		 * @param array $expected Expected verification constraints.
		 * @return bool True when all relevant claims match.
		 */

		private static function payload_matches_expected_claims( array $payload, array $data, array $expected ): bool {

			$now = time();
			$valid_until = self::normalize_time( $payload['validUntil'] ?? 0 );
			$expiration = self::normalize_time( $payload['expiration'] ?? 0 );
			$raw_expiration = $payload['expiration'] ?? null;
			// LICENSE INVARIANT: The signed claim may omit expiration for a true
			// lifetime license, but a malformed non-empty date is never equivalent
			// to that omission, even when the signature itself is valid.
			if (
				! in_array( $raw_expiration, [ null, false, '', 0, '0' ], true )
				&& $expiration <= 0
			) {
				return false;
			}

			// SECURITY INVARIANT: A shared signing authority cannot make tokens
			// portable across products. The v2 claim must be the WPHAVE product ID.
			if( ! isset( $payload['productId'] ) || ! is_int( $payload['productId'] ) || self::PRODUCT_ID !== $payload['productId'] ) {
				return false;
			}

			// SECURITY INVARIANT: Recovery may tolerate an elapsed freshness window,
			// but zero and negative deadlines are malformed rather than expired.
			if( $valid_until <= 0 || $valid_until > $now + self::TOKEN_MAX_TTL ) {
				return false;
			}

			if( $valid_until < $now && empty( $expected['allowExpiredGrace'] ) && empty( $expected['allowOfflineContinuity'] ) ) {
				return false;
			}

			if( ! empty( $expected['allowExpiredGrace'] ) ) {
				$grace_until = self::normalize_time( $expected['graceUntil'] ?? 0 );

				if( ! $grace_until || $grace_until < $now || $grace_until > $now + self::TOKEN_MAX_TTL ) {
					return false;
				}
			}

			if( ! empty( $expected['allowOfflineContinuity'] ) ) {
				$continuity_until = self::normalize_time( $expected['graceUntil'] ?? 0 );
				$expected_access = isset( $expected['access'] ) && is_array( $expected['access'] ) ? $expected['access'] : [ $expected['access'] ?? '' ];

				// Offline continuity is a paid-license safety mechanism, not a
				// generic way to extend beta or authorized-domain access.
				if( ! array_intersect( [ 'license', 'local_license' ], $expected_access ) || ! $continuity_until || $continuity_until < $now ) {
					return false;
				}
			}

			if( $expiration && $expiration < $now ) {
				return false;
			}

			$payload_domain = self::normalize_domain( $payload['domain'] ?? '' );
			$expected_domain = self::normalize_domain( $expected['domain'] ?? '' );

			// SECURITY INVARIANT: Missing domains must not compare equal after
			// normalization. Every token is bound to one explicit site hostname.
			if( ! $payload_domain || ! $expected_domain || $payload_domain !== $expected_domain ) {
				return false;
			}

			// SECURITY INVARIANT: A token is bound to both its domain and the exact
			// installation UID. Missing identity claims always fail closed.
			if( empty( $payload['uid'] ) || empty( $data['uid'] ) || (string) $payload['uid'] !== (string) $data['uid'] ) {
				return false;
			}

			if( in_array( $payload['access'] ?? '', [ 'license', 'local_license' ], true ) ) {
				// SECURITY INVARIANT: Paid authority is bound to one explicit
				// Freemius license installation. Missing IDs fail closed instead of
				// degrading into a domain/UID-only token.
				if(
					empty( $payload['licenseId'] )
					|| empty( $data['licenseId'] )
					|| (string) $payload['licenseId'] !== (string) $data['licenseId']
					|| empty( $payload['installId'] )
					|| empty( $data['installId'] )
					|| (string) $payload['installId'] !== (string) $data['installId']
				) {
					return false;
				}
			}

			return self::has_expected_access( $payload, $expected );

		}

		/**
		 * Check the signed access claim.
		 *
		 * @param array $payload Verified signed token payload.
		 * @param array $expected Expected verification constraints.
		 * @return bool True when the access claim is expected.
		 */

		private static function has_expected_access( array $payload, array $expected ): bool {

			if( empty( $expected['access'] ) ) {
				return true;
			}

			$allowed = is_array( $expected['access'] ) ? $expected['access'] : [ $expected['access'] ];
			$access = $payload['access'] ?? '';

			// SECURITY INVARIANT: Signed data without an explicit access class is
			// authenticated but never authorized.
			return in_array( $access, $allowed, true );

		}

		/**
		 * Sanitize the submitted token data.
		 *
		 * @param array $data Raw request data.
		 * @return array Sanitized data.
		 */

		private static function sanitize_token_data( array $data ): array {

			$allowed = [ 'token', 'uid', 'licenseId', 'installId' ];
			$sanitized = [];

			foreach( $allowed as $key ) {
				if( isset( $data[$key] ) ) {
					$sanitized[$key] = sanitize_text_field( wp_unslash( (string) $data[$key] ) );
				}
			}

			return $sanitized;

		}

		/**
		 * Sanitize the expected token constraints.
		 *
		 * @param array $expected Raw request constraints.
		 * @return array Sanitized constraints.
		 */

		private static function sanitize_expected_data( array $expected ): array {

			$sanitized = [
				'domain' => sanitize_text_field( wp_unslash( (string) ( $expected['domain'] ?? '' ) ) ),
				'allowExpiredGrace' => ! empty( $expected['allowExpiredGrace'] ),
				'allowOfflineContinuity' => ! empty( $expected['allowOfflineContinuity'] ),
				'graceUntil' => sanitize_text_field( wp_unslash( (string) ( $expected['graceUntil'] ?? '' ) ) ),
			];

			if( isset( $expected['access'] ) ) {
				$access = is_array( $expected['access'] ) ? $expected['access'] : [ $expected['access'] ];
				$sanitized['access'] = array_values( array_filter( array_map( 'sanitize_key', $access ) ) );
			}

			return $sanitized;

		}

		/**
		 * Decode a base64url string.
		 *
		 * @param string $value Base64url value.
		 * @return string|false Decoded bytes or false.
		 */

		private static function base64url_decode( string $value ) {

			$base64 = strtr( $value, '-_', '+/' );
			$base64 .= str_repeat( '=', ( 4 - strlen( $base64 ) % 4 ) % 4 );

			return base64_decode( $base64, true );

		}

		/**
		 * Normalize timestamps to seconds.
		 *
		 * @param mixed $value Timestamp-like value.
		 * @return int Unix timestamp in seconds.
		 */

		private static function normalize_time( $value ): int {

			if( ! $value ) {
				return 0;
			}

			if( is_numeric( $value ) ) {
				$timestamp = (int) $value;
			} else {
				$date_value = trim( (string) $value );

				// Signed SQL-style dates originate in UTC. The verifier must not
				// reinterpret the same claim according to the WordPress timezone.
				$is_sql_date = 1 === preg_match( '/^\d{4}-\d{2}-\d{2}(?:[ T]\d{2}:\d{2}:\d{2}(?:\.\d+)?)?$/', $date_value );
				$timestamp = strtotime( $is_sql_date ? $date_value . ' UTC' : $date_value );
			}

			if( ! $timestamp ) {
				return 0;
			}

			return $timestamp > 9999999999 ? (int) floor( $timestamp / 1000 ) : $timestamp;

		}

		/**
		 * Normalize domains for token comparison.
		 *
		 * @param string $domain Raw domain.
		 * @return string Comparable domain.
		 */

		private static function normalize_domain( string $domain ): string {

			$domain = strtolower( trim( $domain ) );
			$domain = preg_replace( '/^www\./', '', $domain );

			return rtrim( $domain, '.' );

		}

	}

	add_action( 'rest_api_init', [ 'WPHAVE_License_Token_Verifier', 'register_routes' ] );
