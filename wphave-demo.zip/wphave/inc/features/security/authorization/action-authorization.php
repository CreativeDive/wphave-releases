<?php

/**
 * WPHAVE Critical Action Authorization
 *
 * Adds short-lived, user-, action- and resource-bound password proofs to
 * destructive or otherwise sensitive operations. Proofs are stored hashed and
 * consumed exactly once by the protected mutation.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WPHAVE_Background_Job_Lock' ) ) {
	require_once wphave_dir() . 'inc/background-jobs/lock.php';
}

if ( ! class_exists( 'WPHAVE_Action_Authorization_Exception' ) ) :

	/**
	 * Represents a stable authorization-domain failure for REST consumers.
	 */

	final class WPHAVE_Action_Authorization_Exception extends RuntimeException {

		/** Stable machine-readable REST error code. */

		private string $error_code;

		/** HTTP status returned to the authorization consumer. */

		private int $http_status;

		/**
		 * Create an authorization-domain exception.
		 *
		 * @param string $error_code Stable REST error code.
		 * @param string $message Localized user-facing message.
		 * @param int    $http_status HTTP response status.
		 */

		public function __construct( string $error_code, string $message, int $http_status ) {
			parent::__construct( $message );
			$this->error_code = $error_code;
			$this->http_status = $http_status;
		}

		/** @return string Stable REST error code. */

		public function error_code(): string {
			return $this->error_code;
		}

		/** @return int HTTP response status. */

		public function http_status(): int {
			return $this->http_status;
		}
	}

endif;

if ( ! class_exists( 'WPHAVE_Action_Authorization' ) ) :

	/**
	 * Issues and consumes short-lived proofs for registered critical actions.
	 */

	final class WPHAVE_Action_Authorization {

		/** One-time proof lifetime in seconds. */

		const TTL = 5 * MINUTE_IN_SECONDS;

		/** Failed-password counter lifetime in seconds. */

		const FAILURE_TTL = 15 * MINUTE_IN_SECONDS;

		/** Maximum failed password attempts within FAILURE_TTL. */

		const MAX_FAILURES = 5;

		/** Maximum invalid bearer checks for one live proof. */
		const MAX_CONSUME_FAILURES = 8;

		/** Maximum lifetime for an abandoned authorization mutex. */

		private const LOCK_TTL = 30;

		/**
		 * Registered action permission callbacks keyed by stable action identifier.
		 *
		 * @var array<string, callable>
		 */

		private static array $actions = array();

		/**
		 * Registers a critical action and its current-user permission boundary.
		 *
		 * @param string          $action Stable namespaced action identifier.
		 * @param string|callable $permission Capability or permission callback.
		 * @return void
		 * @throws InvalidArgumentException When the identifier or permission is invalid.
		 */

		public static function register_action( string $action, $permission ): void {
			if ( ! preg_match( '/^[a-z][a-z0-9._-]{2,100}$/', $action ) ) {
				throw new InvalidArgumentException( 'Action authorization identifiers must be stable lowercase namespaced keys.' );
			}
			if ( is_string( $permission ) ) {
				$capability = $permission;
				$permission = static fn(): bool => current_user_can( $capability );
			}
			if ( ! is_callable( $permission ) ) throw new InvalidArgumentException( 'Action authorization requires a capability or callable permission check.' );
			self::$actions[ $action ] = $permission;
		}

		/**
		 * Verify the current user's password and issue a one-time proof.
		 *
		 * The returned plaintext token is never stored. Only its password hash is
		 * retained for the configured lifetime.
		 *
		 * @param string $action Registered critical-action identifier.
		 * @param string $resource Stable resource identifier bound to the proof.
		 * @param string $password Current account password.
		 * @return array{token:string, expiresIn:int} One-time proof and lifetime.
		 * @throws WPHAVE_Action_Authorization_Exception On denial, throttling or invalid input.
		 */

		public static function issue( string $action, string $resource, string $password ): array {
			self::assert_registered( $action );
			self::assert_resource( $resource );
			$user = wp_get_current_user();
			if ( ! $user->exists() || ! call_user_func( self::$actions[ $action ] ) ) {
				throw new WPHAVE_Action_Authorization_Exception( 'wphave_action_authorization_forbidden', __( 'You are not allowed to authorize this action.', 'wphave' ), 403 );
			}

			// SECURITY INVARIANT: Password throttling, password verification and proof
			// publication are serialized per user so concurrent requests cannot bypass
			// the failure budget or publish competing proofs from one observed state.
			return self::with_lock( 'issue|' . $user->ID, static function() use ( $user, $action, $resource, $password ): array {
				$failure_key = self::failure_key( $user->ID );
				$failures = (int) get_transient( $failure_key );
				if ( $failures >= self::MAX_FAILURES ) {
					throw new WPHAVE_Action_Authorization_Exception( 'wphave_action_authorization_rate_limited', __( 'Too many password attempts. Try again later.', 'wphave' ), 429 );
				}
				if ( ! wp_check_password( $password, $user->user_pass, $user->ID ) ) {
					self::persist_authorization_transient( $failure_key, $failures + 1, self::FAILURE_TTL );
					throw new WPHAVE_Action_Authorization_Exception( 'wphave_action_authorization_failed', __( 'The current account password is incorrect.', 'wphave' ), 403 );
				}

				// AUTHORIZATION/TOCTOU INVARIANT: Password verification is filterable
				// and proves identity only. Re-evaluate the registered action permission
				// inside the issue mutex immediately before publishing proof state.
				$current_user = wp_get_current_user();
				if ( ! $current_user->exists() || $current_user->ID !== $user->ID || ! call_user_func( self::$actions[ $action ] ) ) {
					throw new WPHAVE_Action_Authorization_Exception(
						'wphave_action_authorization_forbidden',
						__( 'You are not allowed to authorize this action.', 'wphave' ),
						403
					);
				}

				delete_transient( $failure_key );
				$token = bin2hex( random_bytes( 32 ) );
				self::persist_authorization_transient(
					self::proof_key( $user->ID, $action, $resource ),
					wp_hash_password( $token ),
					self::TTL
				);
				return array( 'token' => $token, 'expiresIn' => self::TTL );
			} );
		}

		/**
		 * Consume a proof exactly once before its protected mutation starts.
		 *
		 * @param string $action Registered critical-action identifier.
		 * @param string $resource Resource identifier used when issuing the proof.
		 * @param string $token Plaintext one-time proof supplied by the caller.
		 * @return void
		 * @throws WPHAVE_Action_Authorization_Exception When the proof is absent or invalid.
		 */

		public static function consume( string $action, string $resource, string $token ): void {
			self::assert_registered( $action );
			self::assert_resource( $resource );
			$key = self::proof_key( get_current_user_id(), $action, $resource );

			// SECURITY INVARIANT: Verification and deletion form one locked transition.
			// A valid proof therefore authorizes at most one protected mutation, even
			// when identical requests arrive concurrently.
			self::with_lock( 'consume|' . $key, static function() use ( $action, $key, $token ): void {
				// AUTHORIZATION/TOCTOU INVARIANT: A proof records recent password
				// verification, not durable authority. Re-evaluate the registered action
				// permission immediately before consuming the proof so capability
				// revocation during its lifetime takes effect without destroying it.
				$user = wp_get_current_user();
				if ( ! $user->exists() || ! call_user_func( self::$actions[ $action ] ) ) {
					throw new WPHAVE_Action_Authorization_Exception(
						'wphave_action_authorization_forbidden',
						__( 'You are not allowed to authorize this action.', 'wphave' ),
						403
					);
				}

				$hash = (string) get_transient( $key );
				// Bind failures to this issued hash, so a fresh password proof
				// cannot inherit a denial caused by an earlier bearer.
				$failure_key = 'wphave_action_consume_fail_' . md5( $key . '|' . $hash );
				$failures = (int) get_transient( $failure_key );
				if ( $failures >= self::MAX_CONSUME_FAILURES ) {
					throw new WPHAVE_Action_Authorization_Exception( 'wphave_action_authorization_rate_limited', __( 'Too many proof attempts. Try again later.', 'wphave' ), 429 );
				}
				if ( ! $hash || ! preg_match( '/\A[a-f0-9]{64}\z/D', $token ) ) {
					throw new WPHAVE_Action_Authorization_Exception( 'wphave_action_authorization_required', __( 'Confirm this action with the current account password.', 'wphave' ), 403 );
				}
				if ( ! wp_check_password( $token, $hash ) ) {
					// PROOF WORK INVARIANT: A session holder cannot make the server
					// verify an unbounded number of expensive bearer hashes. The
					// counter is bound to the same proof mutex and storage failures deny.
					self::persist_authorization_transient( $failure_key, $failures + 1, self::TTL );
					throw new WPHAVE_Action_Authorization_Exception( 'wphave_action_authorization_required', __( 'Confirm this action with the current account password.', 'wphave' ), 403 );
				}

				// SECURITY INVARIANT: A proof authorizes no mutation until storage
				// confirms its removal. An accepted but undeleted bearer remains usable
				// and therefore cannot be reported as successfully consumed.
				if ( ! delete_transient( $key ) || false !== get_transient( $key ) ) {
					throw self::storage_unavailable_exception();
				}
				delete_transient( $failure_key );
			} );
		}

		/** Persist and read back security state before exposing its transition. */

		private static function persist_authorization_transient( string $key, $value, int $ttl ): void {
			// SECURITY INVARIANT: Password-failure budgets and newly issued proofs
			// exist only after an exact storage acknowledgement. A failed write must
			// never grant another password guess or return an unusable plaintext proof.
			if ( ! set_transient( $key, $value, $ttl ) || $value !== get_transient( $key ) ) {
				throw self::storage_unavailable_exception();
			}
		}

		/** Build the stable fail-closed error for authorization-state storage. */

		private static function storage_unavailable_exception(): WPHAVE_Action_Authorization_Exception {
			return new WPHAVE_Action_Authorization_Exception(
				'wphave_action_authorization_unavailable',
				__( 'Action authorization is temporarily unavailable. Try again.', 'wphave' ),
				503
			);
		}

		/** Execute one authorization transition under an atomic database mutex. */

		private static function with_lock( string $scope, callable $callback ) {
			$option = 'wphave_action_auth_' . md5( $scope ) . '_lock';
			$token = WPHAVE_Background_Job_Lock::acquire( $option, self::LOCK_TTL );

			if ( ! $token ) {
				throw new WPHAVE_Action_Authorization_Exception( 'wphave_action_authorization_busy', __( 'Another authorization request is already being processed. Try again.', 'wphave' ), 409 );
			}

			try {
				return $callback();
			} finally {
				// SECURITY INVARIANT: A stale owner never releases a successor's mutex;
				// cleanup authority remains bound to the token acquired by this call.
				WPHAVE_Background_Job_Lock::release( $option, $token );
			}
		}

		/** Assert that an action has registered its permission boundary. */

		private static function assert_registered( string $action ): void {
			if ( ! isset( self::$actions[ $action ] ) ) {
				throw new WPHAVE_Action_Authorization_Exception( 'wphave_action_authorization_unknown', __( 'This action does not support password confirmation.', 'wphave' ), 400 );
			}
		}

		/** Assert that a resource identifier is safe for proof binding. */

		private static function assert_resource( string $resource ): void {
			if ( '' === $resource || strlen( $resource ) > 191 ) {
				throw new WPHAVE_Action_Authorization_Exception( 'wphave_action_authorization_resource_invalid', __( 'The protected action resource is invalid.', 'wphave' ), 400 );
			}
		}

		/** Build the user-, action- and resource-bound proof transient key. */

		private static function proof_key( int $user_id, string $action, string $resource ): string {
			return 'wphave_action_proof_' . md5( $user_id . '|' . $action . '|' . $resource );
		}

		/** Build the per-user failed-password counter transient key. */

		private static function failure_key( int $user_id ): string {
			return 'wphave_action_auth_fail_' . $user_id;
		}
	}

endif;
