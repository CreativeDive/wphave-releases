<?php

/**
 * WPHAVE Critical Action Authorization REST Controller
 *
 * Exposes password-proof issuance through one authenticated endpoint. Feature
 * domains must register their own action permission and consume the returned
 * proof inside the protected mutation.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once wphave_dir() . 'inc/features/security/password-policy.php';
require_once wphave_dir() . 'inc/features/security/rest-body-budget.php';

if ( ! class_exists( 'WPHAVE_Action_Authorization_REST_Controller' ) ) :

	/**
	 * Exposes password verification without coupling security to feature domains.
	 */

	final class WPHAVE_Action_Authorization_REST_Controller {
		private const MAX_JSON_BYTES = 10 * KB_IN_BYTES;
		private const MAX_PASSWORD_BYTES = WPHAVE_Password_Policy::MAX_BYTES;

		/** Register the REST bootstrap hook. */

		public static function init(): void {
			add_action( 'rest_api_init', array( __CLASS__, 'register_rest_route' ) );
		}

		/**
		 * Register the authenticated proof-issuance endpoint and input schema.
		 *
		 * Authentication alone does not authorize an action. The authorization
		 * service evaluates the permission registered for the requested action.
		 *
		 * @return void
		 */

		public static function register_rest_route(): void {
			// PASSWORD-ORACLE INVARIANT: Bound the wire document before Core parses
			// JSON and before a logged-in caller can reach expensive hash checks.
			WPHAVE_REST_Body_Budget::protect(
				'POST',
				'~^/wphave/v1/security/action-authorization$~D',
				self::MAX_JSON_BYTES
			);
			register_rest_route( 'wphave/v1', '/security/action-authorization', array(
				'methods' => WP_REST_Server::CREATABLE,
				'callback' => array( __CLASS__, 'authorize' ),
				'permission_callback' => 'is_user_logged_in',
				'args' => array(
					'action' => array( 'type' => 'string', 'required' => true, 'pattern' => '^[a-z][a-z0-9._-]{2,100}$' ),
					'resource' => array( 'type' => 'string', 'required' => true, 'minLength' => 1, 'maxLength' => 191 ),
					'password' => array( 'type' => 'string', 'required' => true )
				)
			) );
		}

		/**
		 * Verify the password and return a resource-bound one-time proof.
		 *
		 * Known domain failures preserve their stable code and HTTP status. Other
		 * exceptions are intentionally hidden from clients.
		 *
		 * @param WP_REST_Request $request Validated authorization request.
		 * @return WP_REST_Response|WP_Error Proof response or normalized error.
		 */

		public static function authorize( WP_REST_Request $request ) {
			// AUTHORIZATION/ORACLE INVARIANT: The route login check is only an early
			// transport gate. Direct/composed callbacks reject anonymous callers before
			// action lookup, resource validation or password processing can reveal state.
			if ( ! is_user_logged_in() ) {
				return new WP_Error(
					'wphave_action_authorization_forbidden',
					__( 'You are not allowed to authorize this action.', 'wphave' ),
					array( 'status' => 403 )
				);
			}
			$body_error = WPHAVE_REST_Body_Budget::check($request, self::MAX_JSON_BYTES);
			if ($body_error) {
				return $body_error;
			}
			$password = $request->get_param('password');
			// HASH-INPUT INVARIANT: A direct callback can bypass route schemas;
			// password input remains an exact, bounded scalar before hashing.
			if (!is_string($password) || strlen($password) > self::MAX_PASSWORD_BYTES) {
				return new WP_Error(
					'wphave_action_authorization_password_invalid',
					__('The password input is invalid or too long.', 'wphave'),
					array('status' => 400)
				);
			}

			// AUTHORIZATION INVARIANT: Password verification never grants ambient authority;
			// the service may issue only a short-lived, one-time proof bound to this action and resource.
			try {
				return rest_ensure_response( WPHAVE_Action_Authorization::issue( (string) $request['action'], (string) $request['resource'], $password ) );
			} catch ( WPHAVE_Action_Authorization_Exception $error ) {
				return new WP_Error( $error->error_code(), $error->getMessage(), array( 'status' => $error->http_status() ) );
			} catch ( Throwable $error ) {
				return new WP_Error( 'wphave_action_authorization_failed', __( 'The action could not be authorized.', 'wphave' ), array( 'status' => 500 ) );
			}
		}
	}

	WPHAVE_Action_Authorization_REST_Controller::init();

endif;
