<?php

/**
 * WPHAVE Email Protection
 *
 * Obfuscates email addresses in rendered WPHAVE block content when the
 * corresponding security setting is enabled.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPHAVE_Email_Protection {

	/** Email address pattern used for visible text and mailto links. */

	private const EMAIL_PATTERN = '[a-zA-Z0-9.!#$%&\'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+';

	/** Register the rendered-content filter. */

	public static function init(): void {
		add_filter( 'wphave_ready_renderd_block_content', [ __CLASS__, 'filter_content' ] );
	}

	/**
	 * Protect rendered content when email protection is enabled.
	 *
	 * @param mixed $content Rendered block content.
	 * @return mixed Filtered content, or the original non-string value.
	 */

	public static function filter_content( $content ) {
		if( ! is_string( $content ) || $content === '' ) return $content;

		$enabled = (bool) wphave_data_get( 'site_settings', 'advanced.security.mail_protection', false );
		if( ! $enabled ) return $content;

		return self::protect( $content );
	}

	/**
	 * Obfuscate email addresses and mailto link targets in HTML content.
	 *
	 * Mailto links are processed first so their visible labels can be protected
	 * without changing unrelated link attributes. Remaining plain addresses are
	 * handled afterwards.
	 *
	 * @param string $content HTML or plain-text content.
	 * @return string Protected content.
	 */

	public static function protect( string $content ): string {
		$content = preg_replace_callback(
			'/<a\s+([^>]*?)href=(["\'])mailto:(' . self::EMAIL_PATTERN . ')([^"\']*)\2([^>]*)>(.*?)<\/a>/is',
			[ __CLASS__, 'protect_mailto_link' ],
			$content
		);

		if( ! is_string( $content ) ) return '';

		$protected = preg_replace_callback(
			'/(' . self::EMAIL_PATTERN . ')/i',
			static fn( $matches ) => antispambot( $matches[1] ),
			$content
		);

		return is_string( $protected ) ? $protected : $content;
	}

	/**
	 * Protect one complete mailto anchor matched by protect().
	 *
	 * @param array $matches Regular-expression match groups.
	 * @return string Protected anchor markup.
	 */

	private static function protect_mailto_link( array $matches ): string {
		$label = $matches[6];

		if( is_email( $label ) ) {
			$label = antispambot( $label );
		}

		return '<a ' . $matches[1]
			. 'href=' . $matches[2]
			. 'mailto:' . antispambot( $matches[3] )
			. $matches[4] . $matches[2]
			. $matches[5] . '>'
			. $label
			. '</a>';
	}
}

WPHAVE_Email_Protection::init();
