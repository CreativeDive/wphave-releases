<?php

/**
 * WPHAVE Rate Limiter
 *
 * Provides concurrency-safe counters for public request throttles. External
 * object caches use their atomic increment primitive; the database fallback
 * serializes transient updates with a short advisory lock.
 */

if (!defined('ABSPATH')) {
	exit();
}

/**
 * Atomic counter used by public request throttles.
 *
 * Persistent object caches provide atomic increment operations. The database
 * fallback serializes the transient read/write pair with a short MySQL advisory
 * lock so bursts cannot pass by reading the same counter value concurrently.
 */

class WPHAVE_Rate_Limiter {
	/** Stable, privacy-preserving identity for public client budgets. */
	public static function client_key(string $scope, ?string $ip = null): string {
		$ip = $ip ?? WPHAVE_Client_IP::resolve();
		$packed = @inet_pton($ip);
		$identity = false === $packed ? 'unresolved-client' : bin2hex($packed);
		// ABUSE INVARIANT: Client-controlled headers and visitor IDs never renew
		// the independent network budget. Unknown clients share a bounded bucket.
		return 'wphave_client_' . hash_hmac('sha256', $scope . '|' . $identity, wp_salt('nonce'));
	}

	/**
	 * Read the current counter without changing its expiration window.
	 *
	 * @param string $key Stable rate-limit bucket identifier.
	 * @return int Current request count.
	 */

	public static function get(string $key): int {
		$key = sanitize_key($key);

		if (wp_using_ext_object_cache()) {
			return (int) wp_cache_get($key, 'wphave-rate-limits');
		}

		return (int) get_transient($key);
	}

	/**
	 * Atomically increment a counter and create its expiration window.
	 *
	 * The limiter fails closed with PHP_INT_MAX if the configured cache cannot
	 * increment atomically or the database lock cannot be acquired.
	 *
	 * @param string $key Stable rate-limit bucket identifier.
	 * @param int    $window Counter lifetime in seconds.
	 * @return int Updated request count, or PHP_INT_MAX on infrastructure failure.
	 */

	public static function increment(string $key, int $window): int {
		$key = sanitize_key($key);
		$window = max(1, $window);

		if (wp_using_ext_object_cache()) {
			wp_cache_add($key, 0, 'wphave-rate-limits', $window);
			$count = wp_cache_incr($key, 1, 'wphave-rate-limits');
			// SECURITY INVARIANT: A drop-in may advertise an external cache without
			// atomic increments; public throttles fail closed when incrementing fails.
			return $count === false ? PHP_INT_MAX : (int) $count;
		}

		global $wpdb;
		$lock_name = 'wphave_rl_' . md5($key);
		$acquired = (int) $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 1)', $lock_name));

		if ($acquired !== 1) {
			// SECURITY INVARIANT: Database-backed counters mutate only under their
			// per-bucket lock; contention or storage failure is treated as rate-limited.
			return PHP_INT_MAX;
		}

		try {
			$current = get_transient($key);
			$count = (int) $current + 1;

			if (false === $current) {
				$stored = set_transient($key, $count, $window);
			} else {
				// SECURITY INVARIANT: Database-backed throttles use the same fixed
				// window as atomic object-cache counters. Repeated attempts update only
				// the value and must never extend the original timeout indefinitely.
				$stored = update_option('_transient_' . $key, $count, false);
			}

			// SECURITY INVARIANT: A request is counted only when storage confirms the
			// exact new value. A failed or ambiguous counter write must rate-limit the
			// caller rather than repeatedly granting the first request in the window.
			if (!$stored || $count !== (int) get_transient($key)) {
				return PHP_INT_MAX;
			}

			return $count;
		} finally {
			$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lock_name));
		}
	}

	/**
	 * Remove a rate-limit bucket from the active storage backend.
	 *
	 * @param string $key Stable rate-limit bucket identifier.
	 * @return void
	 */

	public static function reset(string $key): void {
		$key = sanitize_key($key);

		if (wp_using_ext_object_cache()) {
			wp_cache_delete($key, 'wphave-rate-limits');
			return;
		}

		delete_transient($key);
	}
}
