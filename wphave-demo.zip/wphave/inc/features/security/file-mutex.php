<?php

if (!defined('ABSPATH')) {
	exit();
}

if (!class_exists('WPHAVE_Security_File_Mutex_Exception')) {
	/**
	 * Describes why a filesystem mutex could not establish authority.
	 */
	final class WPHAVE_Security_File_Mutex_Exception extends RuntimeException {
		private string $reason;

		public function __construct(string $reason) {
			parent::__construct('Filesystem mutex acquisition failed.');
			$this->reason = $reason;
		}

		public function reason(): string {
			return $this->reason;
		}
	}
}

if (!class_exists('WPHAVE_Security_File_Mutex')) {
	/**
	 * Executes critical sections under an identity-bound local file lock.
	 */
	final class WPHAVE_Security_File_Mutex {
		const INVALID = 'invalid';
		const UNAVAILABLE = 'unavailable';
		const BUSY = 'busy';

		/**
		 * Runs a callback while holding a non-blocking exclusive mutex.
		 *
		 * @return mixed Callback result.
		 */
		public static function run(string $path, callable $callback) {
			clearstatcache(true, $path);
			$initial_stat = @lstat($path);

			// CREATION INVARIANT: A missing mutex is created exclusively. The former
			// c+ mode could follow a dangling symlink installed between inspection and
			// open, creating a file outside WPHAVE's lock namespace.
			if (false === $initial_stat) {
				$handle = @fopen($path, 'x+');
			} elseif (self::is_owned_lock_inode($initial_stat)) {
				$handle = @fopen($path, 'r+');
			} else {
				throw new WPHAVE_Security_File_Mutex_Exception(self::INVALID);
			}

			if (false === $handle) {
				throw new WPHAVE_Security_File_Mutex_Exception(self::UNAVAILABLE);
			}

			if (
				!self::handle_matches_path($handle, $path) ||
				(is_array($initial_stat) && !self::handle_matches_stat($handle, $initial_stat))
			) {
				fclose($handle);
				throw new WPHAVE_Security_File_Mutex_Exception(self::INVALID);
			}

			if (!flock($handle, LOCK_EX | LOCK_NB)) {
				fclose($handle);
				throw new WPHAVE_Security_File_Mutex_Exception(self::BUSY);
			}

			// SECURITY INVARIANT: Path exchange during acquisition invalidates the
			// lock even though the original descriptor itself was successfully locked.
			if (!self::handle_matches_path($handle, $path)) {
				flock($handle, LOCK_UN);
				fclose($handle);
				throw new WPHAVE_Security_File_Mutex_Exception(self::INVALID);
			}

			try {
				$private = function_exists('fchmod') ? @fchmod($handle, 0600) : @chmod($path, 0600);
				$mode = fstat($handle);
				// SECURITY INVARIANT: The critical section runs only after private
				// lock permissions and the path/descriptor binding are both verified.
				if (
					!$private ||
					!is_array($mode) ||
					($mode['mode'] & 07777) !== 0600 ||
					!self::handle_matches_path($handle, $path)
				) {
					throw new WPHAVE_Security_File_Mutex_Exception(self::INVALID);
				}
			} catch (Throwable $error) {
				flock($handle, LOCK_UN);
				fclose($handle);
				throw new WPHAVE_Security_File_Mutex_Exception(self::INVALID);
			}

			try {
				return $callback();
			} finally {
				flock($handle, LOCK_UN);
				fclose($handle);
			}
		}

		/**
		 * Verifies that descriptor and pathname identify the same regular inode.
		 */
		private static function handle_matches_path($handle, string $path): bool {
			$handle_stat = fstat($handle);
			clearstatcache(true, $path);
			// OBSERVABILITY INVARIANT: A path disappearing during the identity probe
			// is a normal failed acquisition, not a warning that may corrupt REST output.
			$path_stat = @lstat($path);

			if (!is_array($handle_stat) || !is_array($path_stat)) {
				return false;
			}

			// SECURITY INVARIANT: A lock inode must have exactly one filesystem name.
			// Otherwise chmod or locking through this path would also affect a foreign
			// hard-link alias whose ownership WPHAVE cannot establish.
			return self::is_owned_lock_inode($handle_stat) &&
				self::is_owned_lock_inode($path_stat) &&
				(int) $handle_stat['dev'] === (int) $path_stat['dev'] &&
				(int) $handle_stat['ino'] === (int) $path_stat['ino'];
		}

		/**
		 * Verifies that a descriptor still identifies the inode inspected pre-open.
		 */
		private static function handle_matches_stat($handle, array $expected): bool {
			$actual = fstat($handle);

			return is_array($actual) &&
				self::is_owned_lock_inode($actual) &&
				(int) $actual['dev'] === (int) $expected['dev'] &&
				(int) $actual['ino'] === (int) $expected['ino'];
		}

		/**
		 * Accepts only regular single-name lock inodes.
		 */
		private static function is_owned_lock_inode(array $stat): bool {
			return 0100000 === ((int) $stat['mode'] & 0170000) && 1 === (int) $stat['nlink'];
		}
	}
}
