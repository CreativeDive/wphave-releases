<?php

/**
 * Provides context-scoped encryption helpers for sensitive plugin values.
 *
 * Values are written in a versioned authenticated format.
 */

class WPHAVE_Crypto {
	/**
	 * Current encrypted payload prefix.
	 *
	 * @var string
	 */

	private const PREFIX = 'wphave:v2:';

	/**
	 * Returns or creates the secret key for one context.
	 *
	 * @param string $context Context namespace.
	 * @return string 32-character stored secret.
	 * @throws RuntimeException When canonical key storage is unavailable or invalid.
	 */

	public static function get_secret_key(string $context = 'default'): string {
		global $wpdb;
		$option_name = 'wphave_secret_key_' . sanitize_key($context);
		// KEY AUTHORITY INVARIANT: Read canonical storage, not filtered or cached
		// options. A stale negative cache must never authorize key replacement.
		$read = static function () use ($wpdb, $option_name) {
			$row = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT option_value FROM {$wpdb->options} WHERE option_name = %s",
					$option_name,
				),
			);
			if ($wpdb->last_error) {
				throw new RuntimeException('Unable to read encryption key storage.');
			}
			return $row;
		};
		$row = $read();
		if (null === $row) {
			$generated = bin2hex(random_bytes(16));
			// KEY COMMIT INVARIANT: The unique option name elects one winner.
			// INSERT IGNORE never replaces another request's key. Only the
			// canonical persisted winner may encrypt data, even after a race.
			$written = $wpdb->query(
				$wpdb->prepare(
					"INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')",
					$option_name,
					$generated,
				),
			);
			if (false === $written) {
				throw new RuntimeException('Unable to persist encryption key.');
			}
			wp_cache_delete($option_name, 'options');
			wp_cache_delete('notoptions', 'options');
			$row = $read();
		}
		// RECOVERY INVARIANT: Missing or corrupt persisted keys fail closed.
		// Never silently rotate a key: existing ciphertext would become unreadable.
		if (!$row || !is_string($row->option_value) || strlen($row->option_value) !== 32) {
			throw new RuntimeException('Encryption key is unavailable or invalid.');
		}
		return $row->option_value;
	}

	/**
	 * Encrypts plaintext with the secret key for one context.
	 *
	 * @param string $plaintext Plain text value.
	 * @param string $context Secret context.
	 * @return string|false Encrypted value or false on failure.
	 */

	public static function encrypt(string $plaintext, string $context = 'default') {
		try {
			return self::encrypt_with_key($plaintext, self::get_secret_key($context));
		} catch (Exception $error) {
			return false;
		}
	}

	/**
	 * Decrypts a value with the secret key for one context.
	 *
	 * @param string $encoded Encrypted value.
	 * @param string $context Secret context.
	 * @return string|false Decrypted value or false on failure.
	 */

	public static function decrypt(string $encoded, string $context = 'default') {
		try {
			return self::decrypt_with_key($encoded, self::get_secret_key($context));
		} catch (Exception $error) {
			return false;
		}
	}

	/**
	 * Encrypts plaintext with an explicit key.
	 *
	 * @param string $plaintext Plain text value.
	 * @param string $key Stored or derived secret key.
	 * @return string|false Encrypted value or false on failure.
	 */

	public static function encrypt_with_key(string $plaintext, string $key) {
		if (self::supports_gcm()) {
			return self::encrypt_gcm($plaintext, $key);
		}

		return self::encrypt_cbc_hmac($plaintext, $key);
	}

	/**
	 * Decrypts a value with an explicit key.
	 *
	 * @param string $encoded Encrypted value.
	 * @param string $key Stored or derived secret key.
	 * @return string|false Decrypted value or false on failure.
	 */

	public static function decrypt_with_key(string $encoded, string $key) {
		// SECURITY INVARIANT: Only the current authenticated envelope format is
		// decryptable. Unknown and legacy plaintext-shaped values fail closed
		// instead of being interpreted as protected data.
		if (strpos($encoded, self::PREFIX) === 0) {
			return self::decrypt_v2($encoded, $key);
		}

		return false;
	}

	/**
	 * Returns a binary 256-bit key from the stored secret.
	 *
	 * @param string $key Stored secret key.
	 * @return string Binary encryption key.
	 */

	private static function normalize_key(string $key): string {
		return hash('sha256', $key, true);
	}

	/**
	 * Checks whether AES-GCM is available.
	 *
	 * @return bool
	 */

	private static function supports_gcm(): bool {
		return in_array('aes-256-gcm', openssl_get_cipher_methods(), true);
	}

	/**
	 * Encrypts with AES-256-GCM.
	 *
	 * @param string $plaintext Plain text value.
	 * @param string $key Stored secret key.
	 * @return string|false Encrypted value or false on failure.
	 */

	private static function encrypt_gcm(string $plaintext, string $key) {
		try {
			$iv = random_bytes(12);
		} catch (Exception $e) {
			return false;
		}

		$tag = '';
		$ciphertext = openssl_encrypt(
			$plaintext,
			'aes-256-gcm',
			self::normalize_key($key),
			OPENSSL_RAW_DATA,
			$iv,
			$tag,
		);

		if ($ciphertext === false) {
			return false;
		}

		return self::PREFIX .
			'gcm:' .
			base64_encode(
				wp_json_encode([
					'iv' => base64_encode($iv),
					'tag' => base64_encode($tag),
					'data' => base64_encode($ciphertext),
				]),
			);
	}

	/**
	 * Encrypts with AES-256-CBC plus HMAC when GCM is unavailable.
	 *
	 * @param string $plaintext Plain text value.
	 * @param string $key Stored secret key.
	 * @return string|false Encrypted value or false on failure.
	 */

	private static function encrypt_cbc_hmac(string $plaintext, string $key) {
		$binary_key = self::normalize_key($key);

		try {
			$iv = random_bytes(openssl_cipher_iv_length('AES-256-CBC'));
		} catch (Exception $e) {
			return false;
		}

		$ciphertext = openssl_encrypt(
			$plaintext,
			'AES-256-CBC',
			$binary_key,
			OPENSSL_RAW_DATA,
			$iv,
		);

		if ($ciphertext === false) {
			return false;
		}

		// SECURITY INVARIANT: CBC confidentiality is always paired with an HMAC
		// over the exact IV and ciphertext; no unauthenticated CBC payload is emitted.
		$mac = hash_hmac('sha256', $iv . $ciphertext, $binary_key, true);

		return self::PREFIX .
			'cbc-hmac:' .
			base64_encode(
				wp_json_encode([
					'iv' => base64_encode($iv),
					'mac' => base64_encode($mac),
					'data' => base64_encode($ciphertext),
				]),
			);
	}

	/**
	 * Decrypts a versioned encrypted payload.
	 *
	 * @param string $encoded Encrypted value.
	 * @param string $key Stored secret key.
	 * @return string|false Decrypted value or false on failure.
	 */

	private static function decrypt_v2(string $encoded, string $key) {
		$payload = substr($encoded, strlen(self::PREFIX));
		$parts = explode(':', $payload, 2);

		if (count($parts) !== 2) {
			return false;
		}

		$type = $parts[0];
		$json = base64_decode($parts[1], true);
		if (false === $json) {
			return false;
		}
		$data = json_decode($json, true);

		if (!is_array($data)) {
			return false;
		}

		if ($type === 'gcm') {
			return self::decrypt_gcm($data, $key);
		}

		if ($type === 'cbc-hmac') {
			return self::decrypt_cbc_hmac($data, $key);
		}

		return false;
	}

	/** Decode only explicitly present string fields; malformed input is inert. */
	private static function decode_field(array $data, string $name) {
		return isset($data[$name]) && is_string($data[$name])
			? base64_decode($data[$name], true)
			: false;
	}

	/**
	 * Decrypts an AES-256-GCM payload.
	 *
	 * @param array $data Payload data.
	 * @param string $key Stored secret key.
	 * @return string|false Decrypted value or false on failure.
	 */

	private static function decrypt_gcm(array $data, string $key) {
		$iv = self::decode_field($data, 'iv');
		$tag = self::decode_field($data, 'tag');
		$ciphertext = self::decode_field($data, 'data');

		// AUTHENTICITY INVARIANT: OpenSSL accepts tag prefixes. Enforce the
		// exact lengths emitted by our GCM writer before invoking decryption.
		if (
			$iv === false ||
			$tag === false ||
			$ciphertext === false ||
			strlen($iv) !== 12 ||
			strlen($tag) !== 16
		) {
			return false;
		}

		return openssl_decrypt(
			$ciphertext,
			'aes-256-gcm',
			self::normalize_key($key),
			OPENSSL_RAW_DATA,
			$iv,
			$tag,
		);
	}

	/**
	 * Decrypts an AES-256-CBC + HMAC payload.
	 *
	 * @param array $data Payload data.
	 * @param string $key Stored secret key.
	 * @return string|false Decrypted value or false on failure.
	 */

	private static function decrypt_cbc_hmac(array $data, string $key) {
		$binary_key = self::normalize_key($key);
		$iv = self::decode_field($data, 'iv');
		$mac = self::decode_field($data, 'mac');
		$ciphertext = self::decode_field($data, 'data');

		// FORMAT INVARIANT: CBC uses a complete SHA-256 MAC and a 16-byte IV;
		// malformed envelopes fail without OpenSSL coercion or padding of the IV.
		if (
			$iv === false ||
			$mac === false ||
			$ciphertext === false ||
			strlen($iv) !== 16 ||
			strlen($mac) !== 32 ||
			strlen($ciphertext) === 0 ||
			strlen($ciphertext) % 16 !== 0
		) {
			return false;
		}

		$expected = hash_hmac('sha256', $iv . $ciphertext, $binary_key, true);

		if (!hash_equals($expected, $mac)) {
			return false;
		}

		return openssl_decrypt($ciphertext, 'AES-256-CBC', $binary_key, OPENSSL_RAW_DATA, $iv);
	}
}

/**
 * Returns or creates the secret key for one context.
 *
 * @param string $context Context namespace.
 * @return string
 */

function wphave_get_secret_key($context = 'default') {
	return WPHAVE_Crypto::get_secret_key((string) $context);
}

/**
 * Encrypts a string with an explicit key.
 *
 * @param string $plaintext Plain text value.
 * @param string $key Secret key.
 * @return string|false
 */

function wphave_encrypt($plaintext, $key) {
	return WPHAVE_Crypto::encrypt_with_key((string) $plaintext, (string) $key);
}

/**
 * Decrypts a string with an explicit key.
 *
 * @param string $encoded Encrypted value.
 * @param string $key Secret key.
 * @return string|false
 */

function wphave_decrypt($encoded, $key) {
	return WPHAVE_Crypto::decrypt_with_key((string) $encoded, (string) $key);
}
