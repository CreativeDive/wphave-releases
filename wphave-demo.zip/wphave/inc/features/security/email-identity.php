<?php

/** Preserve an explicitly selected mailbox across notification boundaries. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WPHAVE_Email_Identity {
	/**
	 * Return the exact valid mailbox or an empty value for callers with a fallback.
	 *
	 * IDENTITY INVARIANT: Sanitization is never permission to send private data
	 * to a different mailbox. Check raw size and type before any filter can rewrite it.
	 */
	public static function exact( $candidate ): string {
		if ( ! is_string( $candidate ) || '' === $candidate || strlen( $candidate ) > 254 ) {
			return '';
		}

		return sanitize_email( $candidate ) === $candidate && is_email( $candidate ) === $candidate
			? $candidate
			: '';
	}
}
