<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Authoritative persistence boundary for block-level class names.
 *
 * Users without the feature capability may continue editing block content,
 * but submitted manual or managed class assignments are replaced with the
 * values stored for the same block. Stable contract IDs keep those values
 * attached to their block when blocks are reordered.
 */

if ( ! class_exists( 'WPHAVE_Block_Classnames_Access' ) ) :

class WPHAVE_Block_Classnames_Access {

	const CAPABILITY = 'wphave_manage_block_classnames';
	const CONTRACT_KEY = 'classnamesContract';

	/**
	 * Register the post-content persistence boundary.
	 *
	 * Priority 31 allows the normal WordPress post preparation to run first while
	 * still protecting block attributes before the post is written.
	 *
	 * @return void
	 */
	public static function register_hooks() {
		add_filter( 'wp_insert_post_data', array( __CLASS__, 'protect_stored_classnames' ), 31, 2 );
	}

	/**
	 * Determine whether a normalized classes payload contains assignments.
	 *
	 * Both manually entered class names and managed global class references count
	 * as protected assignments. Other keys do not establish a class contract.
	 *
	 * @param mixed $value Candidate `features.classes` payload.
	 * @return bool True when manual or global assignments are present.
	 */
	private static function has_classnames( $value ) {
		if( ! is_array( $value ) ) return false;
		return ! empty( $value['manual'] ) || ! empty( $value['global'] );
	}

	/**
	 * Build lookup contracts from the previously persisted block tree.
	 *
	 * Every block is indexed by its structural path. Blocks with a stable
	 * `classnamesContract` ID receive a second ID-based entry, allowing approved
	 * classes to follow their original block when blocks are reordered. The first
	 * occurrence of a duplicate ID remains authoritative.
	 *
	 * @param array  $blocks Parsed WordPress block tree.
	 * @param string $path Parent block path used during recursion.
	 * @return array<string,array{id:string,name:string,classes:array}> Contracts keyed by `path:` or `id:`.
	 */
	private static function contracts_from_blocks( $blocks, $path = '' ) {
		$contracts = array();

		foreach( (array) $blocks as $index => $block ) {
			$block_path = $path . '/' . absint( $index );
			$block_name = (string) ( $block['blockName'] ?? '' );
			$features = $block['attrs']['wphave']['features'] ?? array();
			$classes = is_array( $features['classes'] ?? null ) ? $features['classes'] : array();
			$contract_id = sanitize_key( $features[self::CONTRACT_KEY] ?? '' );
			$contract = array( 'id' => $contract_id, 'name' => $block_name, 'classes' => $classes );

			$contracts['path:' . $block_path] = $contract;
			if( $contract_id && ! isset( $contracts['id:' . $contract_id] ) ) $contracts['id:' . $contract_id] = $contract;

			$contracts += self::contracts_from_blocks( $block['innerBlocks'] ?? array(), $block_path );
		}

		return $contracts;
	}

	/**
	 * Count stable contract ID occurrences throughout a submitted block tree.
	 *
	 * The counts detect attempts to duplicate a previously approved contract. A
	 * restricted editor must not copy one approved class assignment onto multiple
	 * blocks by repeating its contract ID.
	 *
	 * @param array $blocks Parsed submitted block tree.
	 * @return array<string,int> Occurrence count keyed by sanitized contract ID.
	 */
	private static function contract_id_counts( $blocks ) {
		$counts = array();

		foreach( (array) $blocks as $block ) {
			$contract_id = sanitize_key( $block['attrs']['wphave']['features'][self::CONTRACT_KEY] ?? '' );
			if( $contract_id ) $counts[$contract_id] = ( $counts[$contract_id] ?? 0 ) + 1;
			foreach( self::contract_id_counts( $block['innerBlocks'] ?? array() ) as $inner_id => $count ) {
				$counts[$inner_id] = ( $counts[$inner_id] ?? 0 ) + $count;
			}
		}

		return $counts;
	}

	/**
	 * Reconcile submitted class assignments with the approved persisted contracts.
	 *
	 * Authorized users keep their submitted values and receive unique contract
	 * IDs for class-bearing blocks. Restricted users receive only the classes from
	 * a matching, unused contract with the same block type. Invalid, mismatched or
	 * reused contracts are removed. Nested blocks are processed recursively.
	 *
	 * @param array  $blocks Submitted parsed block tree.
	 * @param array  $allowed Contracts derived from the stored post content.
	 * @param bool   $changed Set to true when blocks are modified.
	 * @param bool   $can_manage Whether the current user may manage class names.
	 * @param array  $used Mutable set of contract keys already consumed in this tree.
	 * @param string $path Parent block path used during recursion.
	 * @return array Reconciled block tree suitable for serialization.
	 */
	private static function preserve_approved_classnames( $blocks, $allowed, &$changed, $can_manage, &$used = array(), $path = '' ) {
		foreach( $blocks as $index => &$block ) {
			$block_name = (string) ( $block['blockName'] ?? '' );
			$block_path = $path . '/' . absint( $index );

			if( str_starts_with( $block_name, 'wphave/' ) ) {
				$features = $block['attrs']['wphave']['features'] ?? array();
				$source = is_array( $features['classes'] ?? null ) ? $features['classes'] : array();
				$contract_id = sanitize_key( $features[self::CONTRACT_KEY] ?? '' );
				$contract = $contract_id ? ( $allowed['id:' . $contract_id] ?? null ) : null;
				$contract = $contract ?: ( $allowed['path:' . $block_path] ?? null );

				if( $can_manage ) {
					$approved = $source;
					$contract_key = $contract_id ? 'id:' . $contract_id : '';
					$contract_id = self::has_classnames( $source ) && ( ! $contract_key || ! empty( $used[$contract_key] ) ) ? wp_generate_uuid4() : ( self::has_classnames( $source ) ? $contract_id : '' );
					if( $contract_id ) $used['id:' . $contract_id] = true;
				} else {
					$contract_key = ! empty( $contract['id'] ) ? 'id:' . $contract['id'] : 'path:' . $block_path;
					$valid_contract = $contract && $contract['name'] === $block_name && empty( $used[$contract_key] );
					$approved = $valid_contract ? $contract['classes'] : array();
					$contract_id = $valid_contract && self::has_classnames( $approved ) ? ( $contract['id'] ?: wp_generate_uuid4() ) : '';
					$used[$contract_key] = $valid_contract;
				}

				if( $source !== $approved ) {
					if( self::has_classnames( $approved ) ) $block['attrs']['wphave']['features']['classes'] = $approved;
					else unset( $block['attrs']['wphave']['features']['classes'] );
					$changed = true;
				}

				$current_id = sanitize_key( $block['attrs']['wphave']['features'][self::CONTRACT_KEY] ?? '' );
				if( $contract_id && $current_id !== $contract_id ) {
					$block['attrs']['wphave']['features'][self::CONTRACT_KEY] = $contract_id;
					$changed = true;
				} elseif( ! $contract_id && $current_id ) {
					unset( $block['attrs']['wphave']['features'][self::CONTRACT_KEY] );
					$changed = true;
				}
			}

			if( ! empty( $block['innerBlocks'] ) ) {
				$block['innerBlocks'] = self::preserve_approved_classnames( $block['innerBlocks'], $allowed, $changed, $can_manage, $used, $block_path );
			}
		}

		return $blocks;
	}

	/**
	 * Protect WPHAVE block class assignments before post persistence.
	 *
	 * The filter compares submitted blocks with the previously stored post. Users
	 * without the dedicated capability may edit ordinary block content but cannot
	 * add, alter, copy or relocate protected class assignments without a valid
	 * one-use contract. Ambiguous duplicate IDs fail closed by restoring the
	 * complete previous content. Authorized users may update assignments and the
	 * method maintains stable unique contract IDs.
	 *
	 * The returned `post_content` remains slashed because `wp_insert_post_data`
	 * expects database-ready post data.
	 *
	 * @param array $data Sanitized, slashed post data about to be persisted.
	 * @param array $postarr Raw post array supplied to the insert/update operation.
	 * @return array Original or protected post data.
	 */
	public static function protect_stored_classnames( $data, $postarr ) {
		if( empty( $data['post_content'] ) || ! function_exists( 'parse_blocks' ) ) return $data;

		$submitted_content = wp_unslash( $data['post_content'] );
		$post_id = absint( $postarr['ID'] ?? 0 );
		$previous = $post_id ? get_post_field( 'post_content', $post_id ) : '';
		$has_contract = str_contains( $submitted_content, '"classes"' )
			|| str_contains( $submitted_content, '"' . self::CONTRACT_KEY . '"' )
			|| str_contains( (string) $previous, '"classes"' )
			|| str_contains( (string) $previous, '"' . self::CONTRACT_KEY . '"' );
		if( ! $has_contract ) return $data;

		// SECURITY INVARIANT: Unprivileged edits may preserve an existing protected
		// class contract only once and on the block identity that originally owned it.
		$can_manage = current_user_can( self::CAPABILITY ) || current_user_can( 'manage_options' );
		$submitted_blocks = parse_blocks( $submitted_content );
		$allowed = self::contracts_from_blocks( parse_blocks( (string) $previous ) );

		if( ! $can_manage ) {
			foreach( self::contract_id_counts( $submitted_blocks ) as $contract_id => $count ) {
				if( $count > 1 && isset( $allowed['id:' . $contract_id] ) ) {
					$data['post_content'] = wp_slash( (string) $previous );
					return $data;
				}
			}
		}

		$changed = false;
		$used = array();
		$blocks = self::preserve_approved_classnames( $submitted_blocks, $allowed, $changed, $can_manage, $used );
		if( $changed ) $data['post_content'] = wp_slash( serialize_blocks( $blocks ) );

		return $data;
	}
}

endif;

WPHAVE_Block_Classnames_Access::register_hooks();
