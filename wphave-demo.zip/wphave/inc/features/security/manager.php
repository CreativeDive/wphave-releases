<?php

/**
 * Apply the configured WordPress security hardening measures.
 *
 *  - Disabling file editing in admin
 *  - Preventing self-pingbacks
 *  - Disabling XML-RPC
 *  - Preventing user enumeration via REST API and author archives
 *  - Hiding account-specific login feedback
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPHAVE_Security_Manager {

	private $settings = [];

    /**
     * Initialize security manager.
     *
     * Loads settings and registers hooks for enabled features.
     */

	public function __construct() {
        $this->settings = wphave_data_get( 'site_settings', 'advanced.security', [] ) ?? [];

        // Initialize core hardening features early
        add_action( 'init', [ $this, 'init_core_features' ], 1 );

        // User Enumeration Protection
        if( ! empty( $this->settings['disable_user_enumeration'] ) ) {
            add_filter( 'rest_endpoints', [ $this, 'protect_user_endpoints' ] );
            add_action( 'template_redirect', [ $this, 'disable_author_archives' ] );
        }

		if( $this->is_enabled( 'unify_login_feedback' ) ) {
			add_filter( 'wp_login_errors', [ $this, 'normalize_login_error_collection' ] );
			add_filter( 'login_errors', [ $this, 'normalize_login_error_output' ] );
		}
    }

	/**
	 * Initializes all core security features based on settings.
	 */

	public function init_core_features() {
		$this->disable_file_editing();
		$this->disable_self_pingbacks();
		$this->disable_xml_rpc();
		$this->restrict_public_rest_api();
	}

	/**
	 * Reads current security settings.
	 */

	private function is_enabled( string $key ): bool {
		return ! empty( $this->settings[ $key ] );
	}

	/**
	 * Replace account-specific authentication errors with a neutral message.
	 *
	 * Informational messages such as logout and password-reset confirmations are
	 * preserved. The custom login passes its WP_Error collection through the same
	 * core filter, so both login surfaces share this behavior.
	 *
	 * @param WP_Error $errors Login errors.
	 * @return WP_Error Filtered login errors.
	 */

	public function normalize_login_error_collection( $errors ) {
		if( ! is_wp_error( $errors ) ) {
			return $errors;
		}

		$sensitive_codes = [
			'empty_username',
			'empty_password',
			'invalid_username',
			'invalid_email',
			'incorrect_password',
			'authentication_failed',
		];

		if( empty( array_intersect( $sensitive_codes, $errors->get_error_codes() ) ) ) {
			return $errors;
		}

		foreach( $sensitive_codes as $code ) {
			$errors->remove( $code );
		}

		$errors->add( 'wphave_invalid_credentials', $this->get_generic_login_error() );

		return $errors;
	}

	/**
	 * Normalize the final core login error markup and the custom-login error object.
	 *
	 * WordPress passes a string to `login_errors`; the WPHAVE custom login passes
	 * its WP_Error object for compatibility with existing integrations.
	 *
	 * @param string|WP_Error $errors Login error output.
	 * @return string|WP_Error Neutral login error output.
	 */

	public function normalize_login_error_output( $errors ) {
		if( is_wp_error( $errors ) ) {
			$custom_message = $errors->get_error_message( 'custom_error' );
			$invalid_credentials = __( 'The username or password is incorrect.', 'wphave' );

			if( $custom_message !== $invalid_credentials ) {
				return $errors;
			}

			$errors->remove( 'custom_error' );
			$errors->add( 'wphave_invalid_credentials', $this->get_generic_login_error() );

			return $errors;
		}

		return $errors;
	}

	/**
	 * Return the neutral message shared by both login surfaces.
	 *
	 * @return string Generic authentication error.
	 */

	private function get_generic_login_error(): string {
		return __( 'The login details are incorrect.', 'wphave' );
	}

	/**
	 * Prevents editing of theme and plugin files via wp-admin.
	 *
	 * Reduces risk of malicious code injection if an account
	 * gets compromised.
	 */

	private function disable_file_editing() {
		if( empty( $this->settings['disable_file_editing'] ) ) {
			return;
		}

		if( ! defined( 'DISALLOW_FILE_EDIT' ) ) {
			define( 'DISALLOW_FILE_EDIT', true );
		}
	}

	/**
	 * Prevents WordPress from creating pingbacks to itself.
	 *
	 * Helps reduce unnecessary internal requests and clutter.
	 */

	private function disable_self_pingbacks() {
		if( empty( $this->settings['wp_self_pingback'] ) ) {
			return;
		}

		add_action( 'pre_ping', function( &$links ) {
			$home = get_option( 'home' );

			foreach( $links as $l => $link ) {
				if( 0 === strpos( $link, $home ) ) {
					unset( $links[ $l ] );
				}
			}
		} );
	}

	/**
	 * Disables all registered XML-RPC methods.
	 *
	 * Prevents common brute-force and DDoS attack vectors
	 * targeting xmlrpc.php.
	 */

	private function disable_xml_rpc() {
		if( empty( $this->settings['wp_xml_rpc'] ) ) {
			return;
		}

		add_filter( 'xmlrpc_enabled', '__return_false' );
		add_filter( 'xmlrpc_methods', '__return_empty_array', PHP_INT_MAX );

		add_filter( 'wp_headers', function( $headers ) {
			unset( $headers['X-Pingback'] );
			return $headers;
		} );
	}

	/**
	 * Requires authentication for external REST API requests from visitors and
	 * removes the discovery link from the frontend head.
	 *
	 * WPHAVE routes remain under their endpoint-specific permission contracts so
	 * public product functionality and protected admin APIs can share a namespace.
	 */

	private function restrict_public_rest_api() {
		if( ! $this->is_enabled( 'wp_rest_api' ) ) {
			return;
		}

		remove_action( 'wp_head', 'rest_output_link_wp_head', 10 );

		add_filter( 'rest_authentication_errors', function( $result ) {
			if( ! empty( $result ) ) {
				return $result;
			}

			$route = (string) ( $GLOBALS['wp']->query_vars['rest_route'] ?? '' );

			if( str_starts_with( '/' . ltrim( $route, '/' ), '/wphave/v1/' ) ) {
				// WPHAVE owns the complete permission contract for its namespace.
				// Public routes such as analytics, forms and consent endpoints apply
				// endpoint-specific nonces/tokens and rate limits; private routes still
				// reject visitors through their own permission_callback. Blocking the
				// namespace here would run before either protection can be evaluated.
				return $result;
			}

			if( ! is_user_logged_in() ) {
				return new WP_Error(
					'rest_not_logged_in',
					__( 'Sorry, you do not have permission to make REST API requests.', 'wphave' ),
					array( 'status' => 401 )
				);
			}

			return $result;
		} );
	}

    /**
     * Protect the user endpoints.
     *
     *  - /wp-json/wp/v2/users
     *  - /wp-json/wp/v2/users/{id}
     *
     * @param array $endpoints
     * @return array
     */

    public function protect_user_endpoints( $endpoints ) {
        if( empty( $this->settings['disable_user_enumeration'] ) ) {
			return $endpoints;
		}

        $routes = [
            '/wp/v2/users',
            '/wp/v2/users/(?P<id>[\d]+)',
        ];

        foreach( $routes as $route ) {
            if( empty( $endpoints[ $route ] ) || ! is_array( $endpoints[ $route ] ) ) {
                continue;
            }

            foreach( $endpoints[ $route ] as $key => $endpoint ) {
                // Core routes also contain a schema/help metadata entry. Only
                // executable endpoint definitions may receive permissions;
                // mutating the metadata entry breaks REST index generation.
                if( ! is_array( $endpoint ) || empty( $endpoint['methods'] ) || empty( $endpoint['callback'] ) || ! is_callable( $endpoint['callback'] ) ) {
                    continue;
                }

				$core_permission_callback = $endpoint['permission_callback'] ?? null;

				if( ! is_callable( $core_permission_callback ) ) {
					continue;
				}

				// AUTHORIZATION INVARIANT: User-enumeration hardening may add an
				// authentication requirement, but must never replace or weaken Core's
				// operation- and object-specific user permission callback.
				$endpoints[ $route ][ $key ]['permission_callback'] = static function( ...$args ) use ( $core_permission_callback ) {
					if( ! is_user_logged_in() ) {
						return false;
					}

					return call_user_func_array( $core_permission_callback, $args );
				};
            }
        }

        return $endpoints;
    }

    /**
     * Disable the author archives.
     *
     *  - /author/admin
     */

    public function disable_author_archives() {
        if( empty( $this->settings['disable_user_enumeration'] ) ) {
			return;
		}

        if( is_author() && ! is_user_logged_in() ) {
            wp_redirect( home_url(), 301 );
            exit;
        }
    }
}

/**
 * Initialize the security manager after all plugins are available.
 *
 * @return void
 */

add_action( 'plugins_loaded', function() {
	new WPHAVE_Security_Manager();
} );
