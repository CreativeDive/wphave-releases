<?php

/**
 * WPHAVE Client IP Resolver
 *
 * Resolves the direct request address and accepts forwarding headers only when
 * REMOTE_ADDR belongs to an explicitly trusted proxy network.
 */

if (!defined('ABSPATH')) {
	exit();
}

/**
 * Resolve a request IP without trusting client-controlled forwarding headers.
 */

class WPHAVE_Client_IP {
	/**
	 * Resolve the validated client address for the current request.
	 *
	 * Cloudflare and X-Forwarded-For headers remain untrusted unless the direct
	 * peer matches a CIDR supplied through `wphave_trusted_proxy_cidrs`.
	 *
	 * @return string Valid IPv4 or IPv6 address, or an empty string.
	 */

	public static function resolve(): string {
		$remote_addr = self::validate($_SERVER['REMOTE_ADDR'] ?? '');
		if (!$remote_addr || !self::is_trusted_proxy($remote_addr)) {
			return $remote_addr;
		}

		// PROXY INVARIANT: Only the nearest untrusted hop identifies the client.
		// A trusted append-proxy does not make the leftmost client input trusted.
		$header = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? '';
		if (!is_string($header) || strlen($header) > 4096) {
			return $remote_addr;
		}
		$chain = explode(',', $header);
		if (count($chain) > 32) {
			return $remote_addr;
		}
		$peer = $remote_addr;
		foreach (array_reverse($chain) as $hop) {
			if (!self::is_trusted_proxy($peer)) {
				break;
			}
			$address = self::validate($hop);
			if ('' === $address) {
				// Malformed chains cannot create a fresh attacker-chosen identity.
				return $remote_addr;
			}
			$peer = $address;
		}
		// CF-Connecting-IP is deliberately not inferred from generic proxy trust.
		// Provider integrations must supply a sanitized XFF chain at the edge.
		return $peer;
	}

	/**
	 * Normalize and validate an untrusted IP address value.
	 *
	 * @param mixed $ip Untrusted server or forwarding-header value.
	 * @return string Validated address, or an empty string.
	 */

	private static function validate($ip): string {
		if (!is_string($ip)) {
			return '';
		}
		$ip = trim(wp_unslash($ip));
		$packed = @inet_pton($ip);
		if (false === $packed) {
			return '';
		}
		// IDENTITY INVARIANT: Equivalent textual IP forms share one budget.
		if (
			strlen($packed) === 16 &&
			substr($packed, 0, 12) === str_repeat("\0", 10) . "\xff\xff"
		) {
			$packed = substr($packed, 12);
		}
		return inet_ntop($packed);
	}

	/**
	 * Determine whether the direct peer is a configured trusted proxy.
	 *
	 * @param string $remote_addr Validated direct peer address.
	 * @return bool Whether forwarding headers may be trusted.
	 */

	private static function is_trusted_proxy(string $remote_addr): bool {
		$cidrs = apply_filters('wphave_trusted_proxy_cidrs', []);
		if (!is_array($cidrs)) {
			return false;
		}

		foreach ($cidrs as $cidr) {
			if (self::matches_cidr($remote_addr, (string) $cidr)) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Test an IPv4 or IPv6 address against a CIDR network.
	 *
	 * A network without a prefix matches only the complete address family width.
	 * Invalid or mixed-family input never matches.
	 *
	 * @param string $ip Validated request IP address.
	 * @param string $cidr Network address with an optional prefix length.
	 * @return bool Whether the address belongs to the network.
	 */

	private static function matches_cidr(string $ip, string $cidr): bool {
		[$network, $prefix] = array_pad(explode('/', trim($cidr), 2), 2, null);
		$ip_binary = inet_pton($ip);
		$network_binary = inet_pton($network);
		if (
			$ip_binary === false ||
			$network_binary === false ||
			strlen($ip_binary) !== strlen($network_binary)
		) {
			return false;
		}

		$max_bits = strlen($ip_binary) * 8;
		$prefix = $prefix === null ? $max_bits : filter_var($prefix, FILTER_VALIDATE_INT);
		if ($prefix === false || $prefix < 0 || $prefix > $max_bits) {
			return false;
		}

		$bytes = intdiv($prefix, 8);
		$bits = $prefix % 8;
		if ($bytes && substr($ip_binary, 0, $bytes) !== substr($network_binary, 0, $bytes)) {
			return false;
		}
		if (!$bits) {
			return true;
		}

		$mask = (0xff << (8 - $bits)) & 0xff;
		return (ord($ip_binary[$bytes]) & $mask) === (ord($network_binary[$bytes]) & $mask);
	}
}
