<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WPHAVE_Security_Append_File' ) ) :

	/**
	 * Appends bytes only to the expected revision of a regular file.
	 */
	final class WPHAVE_Security_Append_File {

		/**
		 * Appends the complete payload at an exact, caller-authenticated offset.
		 */
		public static function append( string $path, string $contents, int $expected_offset, string $error_message ): int {
			if ( $expected_offset < 0 || is_link( $path ) || ! is_file( $path ) ) {
				throw new RuntimeException( $error_message );
			}

			$identity = lstat( $path );
			$handle = fopen( $path, 'c+b' );

			if ( ! is_resource( $handle ) ) {
				throw new RuntimeException( $error_message );
			}

			$locked = false;
			$mutation_started = false;

			try {
				$locked = flock( $handle, LOCK_EX );
				$opened = fstat( $handle );
				$current = lstat( $path );

				// SECURITY INVARIANT: The authenticated offset, inspected path and opened
				// inode describe one regular-file revision before any bytes are mutated.
				if (
					! $locked
					|| ! is_array( $opened )
					|| ! is_array( $current )
					|| (int) $opened['dev'] !== (int) $current['dev']
					|| (int) $opened['ino'] !== (int) $current['ino']
					|| (int) $opened['size'] !== $expected_offset
					|| 0100000 !== ( (int) $opened['mode'] & 0170000 )
					|| 0 !== fseek( $handle, $expected_offset )
				) {
					throw new RuntimeException( $error_message );
				}

				$length = strlen( $contents );
				$written = 0;

				while ( $written < $length ) {
					$mutation_started = true;
					$chunk = fwrite( $handle, substr( $contents, $written ) );

					if ( false === $chunk || 0 === $chunk ) {
						throw new RuntimeException( $error_message );
					}

					$written += $chunk;
				}

				if ( ! fflush( $handle ) ) {
					throw new RuntimeException( $error_message );
				}

				$final = fstat( $handle );
				if ( ! is_array( $final ) || (int) $final['size'] !== $expected_offset + $length ) {
					throw new RuntimeException( $error_message );
				}

				return $expected_offset + $length;
			} catch ( Throwable $error ) {
				if ( $mutation_started ) {
					// SECURITY INVARIANT: A failed append rolls back through the same locked
					// descriptor; no caller can observe an authorized partial batch as final.
					$rolled_back = ftruncate( $handle, $expected_offset ) && fflush( $handle );
					$rollback_state = fstat( $handle );

					if ( ! $rolled_back || ! is_array( $rollback_state ) || (int) $rollback_state['size'] !== $expected_offset ) {
						throw new RuntimeException( $error_message, 0, $error );
					}
				}

				throw $error;
			} finally {
				if ( $locked ) {
					flock( $handle, LOCK_UN );
				}

				fclose( $handle );
			}
		}
	}

endif;
