<?php

/** Bootstrap Security Scanner automation, recovery and continuation workers. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/scanner.php';
