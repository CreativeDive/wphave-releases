<?php

/** Bootstrap Security Scanner automation, recovery and continuation workers. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Scheduled scan notifications use the shared form-mail rendering contract.
require_once wphave_dir() . 'inc/features/forms/submission/mail-template.php';

require_once __DIR__ . '/scanner.php';
