<?php

/** Small, deliberately bounded SVG presentation language; never emits a stylesheet. */

final class WPHAVE_SVG_Presentation {
	private const COLORS = [
		'fill',
		'stroke',
		'color',
		'stop-color',
		'flood-color',
		'lighting-color',
	];

	private const NUMBERS = [
		'opacity',
		'fill-opacity',
		'stroke-opacity',
		'stop-opacity',
		'flood-opacity',
		'stroke-width',
		'stroke-miterlimit',
		'stroke-dashoffset',
		'font-size',
		'letter-spacing',
	];

	private const ENUMS = [
		'fill-rule' => ['nonzero', 'evenodd'],
		'clip-rule' => ['nonzero', 'evenodd'],
		'stroke-linecap' => ['butt', 'round', 'square'],
		'stroke-linejoin' => ['miter', 'round', 'bevel'],
		'display' => ['none', 'inline'],
		'visibility' => ['visible', 'hidden', 'collapse'],
		'text-anchor' => ['start', 'middle', 'end'],
		'vector-effect' => ['none', 'non-scaling-stroke'],
	];

	private const REFERENCES = ['clip-path', 'mask', 'filter'];

	public static function value(string $property, string $value): ?string {
		$value = trim($value);

		if (preg_match('/[\\\\<>;{}@\x00-\x1f\x7f]/', $value)) {
			return null;
		}

		if (in_array($property, array_merge(self::COLORS, self::REFERENCES), true)) {
			if (preg_match('/^url\(\s*[\'"]?#([a-zA-Z_][\w.-]*)[\'"]?\s*\)$/D', $value, $match)) {
				return 'url(#' . $match[1] . ')';
			}

			if (in_array($property, self::REFERENCES, true)) {
				return $value === 'none' ? $value : null;
			}

			if (
				preg_match(
					'/^(?:#[a-f0-9]{3}|#[a-f0-9]{4}|#[a-f0-9]{6}|#[a-f0-9]{8}|[a-z]+)$/iD',
					$value,
				)
			) {
				return $value;
			}

			return preg_match('/^(?:rgb|rgba|hsl|hsla)\([0-9.%+\-,\s\/]+\)$/iD', $value)
				? $value
				: null;
		}

		if (in_array($property, self::NUMBERS, true)) {
			return preg_match('/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:px|em|rem|%)?$/D', $value)
				? $value
				: null;
		}

		if ($property === 'stroke-dasharray') {
			return $value === 'none' || preg_match('/^[0-9.,\s%+-]+$/D', $value) ? $value : null;
		}

		return in_array($value, self::ENUMS[$property] ?? [], true) ? $value : null;
	}

	/** Returns null for malformed CSS; unsupported declarations are discarded. */

	private static function declarations(string $css): ?array {
		if (preg_match('/[\\\\{}@<>\x00-\x08\x0b\x0c\x0e-\x1f]/', $css)) {
			return null;
		}

		$result = [];
		foreach (explode(';', $css) as $declaration) {
			if (trim($declaration) === '') {
				continue;
			}

			if (!preg_match('/^\s*([a-z-]+)\s*:\s*(.*?)\s*$/isD', $declaration, $match)) {
				return null;
			}

			$property = strtolower($match[1]);
			$important = preg_match('/\s*!important\s*$/i', $match[2]);
			$value = self::value($property, preg_replace('/\s*!important\s*$/i', '', $match[2]));

			if ($value !== null) {
				$result[] = [$property, $value, (int) $important];
			}
		}

		return $result;
	}

	/** Resolve simple tag, class and ID selectors with specificity and source order. */

	public static function flatten(DOMDocument $document): bool {
		$rules = [];
		$css_bytes = 0;
		$declaration_count = 0;

		foreach (iterator_to_array($document->getElementsByTagName('*')) as $style) {
			if (strtolower($style->localName) !== 'style') {
				continue;
			}

			$css_bytes += strlen($style->textContent);

			if ($css_bytes > 65536) {
				return false;
			}

			$css = preg_replace('~/\*.*?\*/~s', '', $style->textContent);

			while (trim($css) !== '') {
				if (
					count($rules) >= 256 ||
					!preg_match('/^\s*([^{}]+)\{([^{}]*)\}/s', $css, $match)
				) {
					return false;
				}

				$declarations = self::declarations($match[2]);

				if ($declarations === null) {
					return false;
				}

				foreach (explode(',', $match[1]) as $selector) {
					$selector = trim($selector);

					if (
						!preg_match('/^(?:[a-zA-Z][\w-]*|[.#][a-zA-Z_][\w-]*)$/D', $selector) ||
						count($rules) >= 256
					) {
						return false;
					}

					$declaration_count += count($declarations);

					if ($declaration_count > 1024) {
						return false;
					}

					$rules[] = [$selector, $declarations];
				}

				$css = substr($css, strlen($match[0]));
			}

			$style->parentNode->removeChild($style);
		}

		foreach ($document->getElementsByTagName('*') as $node) {
			$winners = [];
			foreach ($rules as [$selector, $declarations]) {
				$prefix = $selector[0];

				$matches =
					$prefix === '#'
						? $node->getAttribute('id') === substr($selector, 1)
						: ($prefix === '.'
							? in_array(
								substr($selector, 1),
								preg_split('/\s+/', trim($node->getAttribute('class'))),
								true,
							)
							: $node->tagName === $selector);

				if ($matches) {
					self::apply(
						$winners,
						$declarations,
						$prefix === '#' ? 100 : ($prefix === '.' ? 10 : 1),
					);
				}
			}

			if ($node->hasAttribute('style')) {
				$css_bytes += strlen($node->getAttribute('style'));

				if ($css_bytes > 65536) {
					return false;
				}

				$declarations = self::declarations($node->getAttribute('style'));

				if ($declarations === null) {
					return false;
				}

				$declaration_count += count($declarations);

				if ($declaration_count > 1024) {
					return false;
				}

				self::apply($winners, $declarations, 1000);
				$node->removeAttribute('style');
			}

			foreach ($winners as $property => $winner) {
				$node->setAttribute($property, $winner[2]);
			}
		}

		return true;
	}

	private static function apply(array &$winners, array $declarations, int $specificity): void {
		foreach ($declarations as [$property, $value, $important]) {
			$rank = [$important, $specificity];
			$previous = $winners[$property] ?? null;

			if ($previous === null || $rank >= [$previous[0], $previous[1]]) {
				$winners[$property] = [$important, $specificity, $value];
			}
		}
	}
}
