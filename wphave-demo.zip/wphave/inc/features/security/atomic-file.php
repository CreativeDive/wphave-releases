<?php

if (!defined('ABSPATH')) {
	exit();
}

/**
 * Shared atomic publication primitive for security-sensitive local state.
 */

final class WPHAVE_Security_Atomic_File {
	/**
	 * Copies checksum-bound file bytes through an exclusive sibling staging file.
	 */

	public static function copy_verified(
		string $source,
		string $path,
		string $checksum,
		string $error_message,
		int $permissions = 0600,
	): void {
		$checksum = strtolower($checksum);

		if (!preg_match('/^[a-f0-9]{64}$/', $checksum)) {
			throw new RuntimeException($error_message);
		}

		self::copy_stream($source, $path, $error_message, $checksum, false, $permissions);
	}

	/**
	 * Publishes checksum-bound bytes only when the destination is still absent.
	 */
	public static function copy_verified_new(
		string $source,
		string $path,
		string $checksum,
		string $error_message,
		int $permissions = 0600,
	): void {
		$checksum = strtolower($checksum);

		if (!preg_match('/^[a-f0-9]{64}$/', $checksum)) {
			throw new RuntimeException($error_message);
		}

		self::copy_stream($source, $path, $error_message, $checksum, true, $permissions);
	}

	/**
	 * Materializes a new asset before its owning manifest makes it visible.
	 *
	 * Exclusive creation prevents replacement without requiring hard-link support.
	 * Unlike atomic publication, readers may observe an incomplete unregistered file
	 * during this call. Callers MUST publish its manifest only after success, and
	 * must never use this method for live state, checkpoints or replacement writes.
	 */
	public static function copy_verified_unpublished(
		string $source,
		string $path,
		string $checksum,
		string $error_message,
		int $permissions = 0600,
	): void {
		$checksum = strtolower($checksum);
		if (!preg_match('/^[a-f0-9]{64}$/', $checksum)) {
			throw new RuntimeException($error_message);
		}
		self::copy_stream($source, $path, $error_message, $checksum, true, $permissions, true);
	}

	/**
	 * Copies one coherent source stream and returns the published byte identity.
	 */
	public static function copy_observed(
		string $source,
		string $path,
		string $error_message,
	): array {
		return self::copy_stream($source, $path, $error_message);
	}

	/**
	 * Copies and optionally authorizes one exact stream before atomic publication.
	 */
	private static function copy_stream(
		string $source,
		string $path,
		string $error_message,
		string $expected_checksum = '',
		bool $create_only = false,
		int $permissions = 0600,
		bool $unpublished = false,
	): array {
		$permissions &= 0777;
		if (0 === $permissions) {
			throw new RuntimeException($error_message);
		}
		if (is_link($source) || !is_file($source)) {
			throw new RuntimeException($error_message);
		}

		$input = @fopen($source, 'rb');
		$temporary = $unpublished ? $path : $path . '.tmp-' . wp_generate_uuid4();
		$output = @fopen($temporary, 'x+b');
		$output_identity = is_resource($output) ? fstat($output) : false;
		$permissions_set = false;
		if (is_resource($output)) {
			$permissions_set = @chmod($temporary, $permissions);
		}
		$input_stat = is_resource($input) ? fstat($input) : false;
		$source_stat = lstat($source);

		if (
			!is_resource($input) ||
			!is_resource($output) ||
			!is_array($output_identity) ||
			!is_array($input_stat) ||
			!is_array($source_stat) ||
			0100000 !== ((int) $input_stat['mode'] & 0170000) ||
			(int) $input_stat['dev'] !== (int) $source_stat['dev'] ||
			(int) $input_stat['ino'] !== (int) $source_stat['ino']
		) {
			if (is_resource($input)) {
				fclose($input);
			}
			if (is_resource($output)) {
				fclose($output);
			}
			if (is_array($output_identity)) {
				self::remove_owned_output($temporary, $output_identity);
			}
			throw new RuntimeException($error_message);
		}

		// SECURITY INVARIANT: Path validation and the opened stream must identify
		// the same regular inode; a link or replacement race never gains authority.
		$hash = hash_init('sha256');
		$complete = true;
		$total_bytes = 0;

		while (!feof($input)) {
			$chunk = fread($input, 1024 * 1024);

			if (false === $chunk) {
				$complete = false;
				break;
			}
			if ('' === $chunk) {
				continue;
			}

			hash_update($hash, $chunk);
			$total_bytes += strlen($chunk);
			$offset = 0;
			$length = strlen($chunk);

			while ($offset < $length) {
				$written = fwrite($output, substr($chunk, $offset));
				if (false === $written || 0 === $written) {
					$complete = false;
					break 2;
				}
				$offset += $written;
			}
		}

		$actual_checksum = hash_final($hash);
		// DURABILITY INVARIANT: Failed flush or permissions never publish staged bytes.
		$flushed = fflush($output);
		$input_closed = fclose($input);
		$output_closed = fclose($output);

		// SECURITY INVARIANT: The returned or expected identity is calculated from
		// the exact byte stream committed below, never from a separate path pass.
		if (
			!$complete ||
			!$permissions_set ||
			!$flushed ||
			!$input_closed ||
			!$output_closed ||
			($expected_checksum && !hash_equals($expected_checksum, $actual_checksum))
		) {
			if (is_array($output_identity)) {
				self::remove_owned_output($temporary, $output_identity);
			}
			throw new RuntimeException($error_message);
		}

		if ($unpublished) {
			// Visibility belongs to the caller's manifest transaction, after this return.
			return [
				'bytes' => $total_bytes,
				'checksum' => $actual_checksum,
			];
		}

		// SECURITY INVARIANT: Create-only publication uses an atomic hard-link
		// operation, so a concurrent destination can never be overwritten between
		// an absence check and commit. Staging and target are sibling filesystem nodes.
		if ($create_only) {
			if (!@link($temporary, $path)) {
				self::remove_temporary($temporary);
				throw new RuntimeException($error_message);
			}

			if (!@unlink($temporary)) {
				self::rollback_link_publication($temporary, $path);
				throw new RuntimeException($error_message);
			}
		} elseif (!rename($temporary, $path)) {
			if (is_array($output_identity)) {
				self::remove_owned_output($temporary, $output_identity);
			}
			throw new RuntimeException($error_message);
		}

		return [
			'bytes' => $total_bytes,
			'checksum' => $actual_checksum,
		];
	}

	/**
	 * Publishes bytes through an exclusive random sibling staging file.
	 */

	public static function write(
		string $path,
		string $contents,
		string $error_message,
		int $permissions = 0600,
	): void {
		self::write_contents($path, $contents, $error_message, false, $permissions);
	}

	/**
	 * Publishes complete contents only while the destination remains absent.
	 */
	public static function write_new(
		string $path,
		string $contents,
		string $error_message,
		int $permissions = 0600,
	): void {
		self::write_contents($path, $contents, $error_message, true, $permissions);
	}

	/**
	 * Writes complete contents through an exclusive sibling and atomic commit.
	 */
	private static function write_contents(
		string $path,
		string $contents,
		string $error_message,
		bool $create_only,
		int $permissions,
	): void {
		$permissions &= 0777;
		if (0 === $permissions) {
			throw new RuntimeException($error_message);
		}

		$temporary = $path . '.tmp-' . wp_generate_uuid4();
		$handle = @fopen($temporary, 'x');

		if (!is_resource($handle)) {
			throw new RuntimeException($error_message);
		}

		$permissions_set = @chmod($temporary, $permissions);
		$offset = 0;
		$length = strlen($contents);

		while ($offset < $length) {
			$written = fwrite($handle, substr($contents, $offset));
			if (false === $written || 0 === $written) {
				break;
			}
			$offset += $written;
		}

		// COMMIT INVARIANT: A successful write count alone does not prove flushed storage.
		$flushed = fflush($handle);
		$closed = fclose($handle);

		if ($offset !== $length || !$permissions_set || !$flushed || !$closed) {
			self::remove_temporary($temporary);
			throw new RuntimeException($error_message);
		}

		// SECURITY INVARIANT: Create-only content publication uses the same atomic
		// hard-link boundary as checksum-bound copies. Replacement remains an explicit
		// caller choice and never follows a target symlink.
		if ($create_only) {
			if (!@link($temporary, $path)) {
				self::remove_temporary($temporary);
				throw new RuntimeException($error_message);
			}

			if (!@unlink($temporary)) {
				self::rollback_link_publication($temporary, $path);
				throw new RuntimeException($error_message);
			}
		} elseif (!rename($temporary, $path)) {
			self::remove_temporary($temporary);
			throw new RuntimeException($error_message);
		}
	}

	/** Failed asset materialization must never delete a pre-existing destination. */
	private static function remove_owned_output(string $path, array $identity): void {
		clearstatcache(true, $path);
		$current = @lstat($path);
		if (
			is_array($current) &&
			(int) $current['dev'] === (int) $identity['dev'] &&
			(int) $current['ino'] === (int) $identity['ino']
		) {
			@unlink($path);
		}
	}

	/**
	 * Removes only the exact sibling staging node created by this primitive.
	 */

	private static function remove_temporary(string $temporary): void {
		if (is_file($temporary) || is_link($temporary)) {
			unlink($temporary);
		}
	}

	/**
	 * Rolls back only the hard-link destination created from our staging inode.
	 */
	private static function rollback_link_publication(string $temporary, string $path): void {
		$temporary_stat = @lstat($temporary);
		$path_stat = @lstat($path);

		if (
			is_array($temporary_stat) &&
			is_array($path_stat) &&
			(int) $temporary_stat['dev'] === (int) $path_stat['dev'] &&
			(int) $temporary_stat['ino'] === (int) $path_stat['ino']
		) {
			@unlink($path);
		}

		self::remove_temporary($temporary);
	}
}
