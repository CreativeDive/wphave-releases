<?php

if (!defined('ABSPATH')) {
	exit();
}

/**
 * Shared atomic publication primitive for security-sensitive local state.
 */

require_once __DIR__ . '/file-permissions.php';

final class WPHAVE_Security_Atomic_File {
	/**
	 * Copies checksum-bound file bytes through an exclusive sibling staging file.
	 */

	public static function copy_verified(
		string $source,
		string $path,
		string $checksum,
		string $error_message,
		int $permissions = 0600,
		?int $group = null,
	): void {
		$checksum = strtolower($checksum);

		if (!preg_match('/^[a-f0-9]{64}$/', $checksum)) {
			throw new RuntimeException($error_message);
		}

		self::copy_stream(
			$source,
			$path,
			$error_message,
			$checksum,
			false,
			$permissions,
			false,
			$group,
		);
	}

	/**
	 * Publishes checksum-bound bytes only when the destination is still absent.
	 */

	public static function copy_verified_new(
		string $source,
		string $path,
		string $checksum,
		string $error_message,
		int $permissions = 0600,
		?int $group = null,
	): void {
		$checksum = strtolower($checksum);

		if (!preg_match('/^[a-f0-9]{64}$/', $checksum)) {
			throw new RuntimeException($error_message);
		}

		self::copy_stream(
			$source,
			$path,
			$error_message,
			$checksum,
			true,
			$permissions,
			false,
			$group,
		);
	}

	/**
	 * Materializes a new asset before its owning manifest makes it visible.
	 *
	 * Exclusive creation prevents replacement without requiring hard-link support.
	 * Unlike atomic publication, readers may observe an incomplete unregistered file
	 * during this call. Callers MUST publish its manifest only after success, and
	 * must never use this method for live state, checkpoints or replacement writes.
	 */

	public static function copy_verified_unpublished(
		string $source,
		string $path,
		string $checksum,
		string $error_message,
		int $permissions = 0600,
	): void {
		$checksum = strtolower($checksum);

		if (!preg_match('/^[a-f0-9]{64}$/', $checksum)) {
			throw new RuntimeException($error_message);
		}

		self::copy_stream($source, $path, $error_message, $checksum, true, $permissions, true);
	}

	/**
	 * Copies one coherent source stream and returns the published byte identity.
	 */

	public static function copy_observed(
		string $source,
		string $path,
		string $error_message,
	): array {
		return self::copy_stream($source, $path, $error_message);
	}

	/**
	 * Copies and optionally authorizes one exact stream before atomic publication.
	 */

	private static function copy_stream(
		string $source,
		string $path,
		string $error_message,
		string $expected_checksum = '',
		bool $create_only = false,
		int $permissions = 0600,
		bool $unpublished = false,
		?int $group = null,
	): array {
		$permissions = WPHAVE_Security_File_Permissions::recorded($permissions);
		$temporary = $unpublished ? $path : $path . '.tmp-' . wp_generate_uuid4();
		$input = null;
		$output = null;
		$identity = null;
		$committed = false;
		try {
			clearstatcache(true, $source);
			$source_stat = @lstat($source);
			if (!is_array($source_stat) || ($source_stat['mode'] & 0170000) !== 0100000) {
				throw new RuntimeException($error_message);
			}
			$input = @fopen($source, 'rb');
			$input_stat = is_resource($input) ? fstat($input) : false;
			if (
				!is_array($input_stat) ||
				$source_stat['dev'] !== $input_stat['dev'] ||
				$source_stat['ino'] !== $input_stat['ino'] ||
				!flock($input, LOCK_SH)
			) {
				throw new RuntimeException($error_message);
			}
			$output = @fopen($temporary, 'x+b');
			$identity = is_resource($output) ? fstat($output) : false;
			if (!is_array($identity)) {
				throw new RuntimeException($error_message);
			}
			// SECURITY INVARIANT: No content is written until the exclusive inode
			// has verified private mode. All I/O exceptions share the same cleanup.
			WPHAVE_Security_File_Permissions::apply_file_mode(
				$temporary,
				$identity,
				0600,
				$error_message,
			);
			$hash = hash_init('sha256');
			$total_bytes = 0;
			while (!feof($input)) {
				$chunk = fread($input, 1024 * 1024);
				if (false === $chunk || ('' === $chunk && !feof($input))) {
					throw new RuntimeException($error_message);
				}
				hash_update($hash, $chunk);
				$total_bytes += strlen($chunk);
				self::write_all($output, $chunk, $error_message);
			}
			$actual_checksum = hash_final($hash);
			$final = fstat($input);
			// SNAPSHOT INVARIANT: Source size and metadata belong to the locked
			// stream; failed validation never grants public permissions to its bytes.
			if (
				!is_array($final) ||
				$total_bytes !== (int) $input_stat['size'] ||
				$final['size'] !== $input_stat['size'] ||
				($expected_checksum !== '' && !hash_equals($expected_checksum, $actual_checksum)) ||
				!fflush($output)
			) {
				throw new RuntimeException($error_message);
			}
			if (!fclose($input) || !fclose($output)) {
				throw new RuntimeException($error_message);
			}
			if ($group !== null) {
				WPHAVE_Security_File_Permissions::apply_recorded_group($temporary, $group);
			}
			// PUBLICATION INVARIANT: Only complete verified bytes receive the final
			// mode; the locally authorized group is assigned before opening access.
			WPHAVE_Security_File_Permissions::apply_file_mode(
				$temporary,
				$identity,
				$permissions,
				$error_message,
			);
			if (!$unpublished) {
				self::publish($temporary, $path, $create_only, $error_message);
			}
			$committed = true;
			return [
				'bytes' => $total_bytes,
				'checksum' => $actual_checksum,
				// RECOVERY INVARIANT: Metadata describes the original locked source.
				'permissions' => (int) $input_stat['mode'] & 0777,
				'group' => (int) $input_stat['gid'],
			];
		} catch (Throwable $error) {
			throw new RuntimeException($error_message, 0, $error);
		} finally {
			self::close_safely($input);
			self::close_safely($output);
			// COMMIT INVARIANT: Link success is publication. Post-commit staging
			// cleanup must neither roll it back nor report the write as rejected.
			if (is_array($identity) && (!$committed || !$unpublished)) {
				self::remove_owned_output($temporary, $identity);
			}
		}
	}

	/**
	 * Publishes bytes through an exclusive random sibling staging file.
	 */

	public static function write(
		string $path,
		string $contents,
		string $error_message,
		int $permissions = 0600,
	): void {
		self::write_contents($path, $contents, $error_message, false, $permissions);
	}

	/**
	 * Publishes complete contents only while the destination remains absent.
	 */

	public static function write_new(
		string $path,
		string $contents,
		string $error_message,
		int $permissions = 0600,
	): void {
		self::write_contents($path, $contents, $error_message, true, $permissions);
	}

	/**
	 * Writes complete contents through an exclusive sibling and atomic commit.
	 */

	private static function write_contents(
		string $path,
		string $contents,
		string $error_message,
		bool $create_only,
		int $permissions,
	): void {
		$permissions = WPHAVE_Security_File_Permissions::recorded($permissions);
		$temporary = $path . '.tmp-' . wp_generate_uuid4();
		$handle = null;
		$identity = null;
		try {
			$handle = @fopen($temporary, 'x+b');
			$identity = is_resource($handle) ? fstat($handle) : false;
			if (!is_array($identity)) {
				throw new RuntimeException($error_message);
			}
			// SECURITY INVARIANT: Failed or ineffective chmod stops the first byte.
			WPHAVE_Security_File_Permissions::apply_file_mode(
				$temporary,
				$identity,
				0600,
				$error_message,
			);
			self::write_all($handle, $contents, $error_message);
			if (!fflush($handle) || !fclose($handle)) {
				throw new RuntimeException($error_message);
			}
			WPHAVE_Security_File_Permissions::apply_file_mode(
				$temporary,
				$identity,
				$permissions,
				$error_message,
			);
			self::publish($temporary, $path, $create_only, $error_message);
		} catch (Throwable $error) {
			throw new RuntimeException($error_message, 0, $error);
		} finally {
			self::close_safely($handle);
			if (is_array($identity)) {
				self::remove_owned_output($temporary, $identity);
			}
		}
	}

	/** Write all bytes or reject a stopped/throwing stream without an infinite retry. */
	private static function write_all($handle, string $contents, string $error_message): void {
		$offset = 0;
		$length = strlen($contents);
		while ($offset < $length) {
			$written = fwrite($handle, substr($contents, $offset));
			if (false === $written || $written === 0) {
				throw new RuntimeException($error_message);
			}
			$offset += $written;
		}
	}

	/** Commit complete bytes; cleanup of the sibling is a separate outcome. */
	private static function publish(
		string $temporary,
		string $path,
		bool $create_only,
		string $error_message,
	): void {
		// CONCURRENCY INVARIANT: Create-only publication has no overwrite fallback.
		$published = $create_only
			? function_exists('link') && @link($temporary, $path)
			: @rename($temporary, $path);
		if (!$published) {
			throw new RuntimeException($error_message);
		}
	}

	/** Best-effort resource cleanup must not replace the primary I/O exception. */
	private static function close_safely($handle): void {
		try {
			if (is_resource($handle)) {
				@fclose($handle);
			}
		} catch (Throwable $cleanup_error) {
			// The transaction outcome is already decided; retain its original error.
		}
	}

	/** Failed asset materialization must never delete a pre-existing destination. */

	private static function remove_owned_output(string $path, array $identity): void {
		try {
			clearstatcache(true, $path);
			$current = @lstat($path);
			// RECOVERY INVARIANT: Never clean a reused pathname or let failed
			// staging cleanup hide the primary failure or a successful publication.
			if (
				is_array($current) &&
				$current['dev'] === $identity['dev'] &&
				$current['ino'] === $identity['ino']
			) {
				@unlink($path);
			}
		} catch (Throwable $cleanup_error) {
			// Retain owned staging for explicit cleanup; never mutate the live target.
		}
	}
}
