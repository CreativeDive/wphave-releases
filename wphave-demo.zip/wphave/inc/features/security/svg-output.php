<?php

require_once __DIR__ . '/safe-svg.php';
require_once __DIR__ . '/svg-presentation.php';

/** Final SVG-only HTML boundary. No stylesheet, executable content or remote references. */

final class WPHAVE_SVG_Output {
	private const NS = 'http://www.w3.org/2000/svg';
	private const XLINK = 'http://www.w3.org/1999/xlink';
	private const PAINT = ['fill', 'stroke', 'clip-path', 'mask', 'filter'];

	/** Preparation can be cached; occurrence IDs are assigned only at the final output. */

	public static function sanitize(
		string $markup,
		array $attributes = [],
		bool $scope = true,
	): string {
		if (
			trim($markup) === '' ||
			strlen($markup) > WPHAVE_Safe_SVG::MAX_FILE_SIZE ||
			preg_match('/<!DOCTYPE|<!ENTITY/i', $markup)
		) {
			return '';
		}

		$previous = libxml_use_internal_errors(true);
		$document = new DOMDocument();

		try {
			$loaded = $document->loadXML($markup, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING);
		} finally {
			libxml_clear_errors();
			libxml_use_internal_errors($previous);
		}

		$root = $document->documentElement;

		if (
			!$loaded ||
			!$root ||
			$root->tagName !== 'svg' ||
			$document->doctype ||
			$document->getElementsByTagName('*')->length > 2048
		) {
			return '';
		}

		// Namespace confusion can change inert XML into active HTML when inlined.
		foreach ($document->getElementsByTagName('*') as $node) {
			if ($node->prefix || !in_array($node->namespaceURI, [null, '', self::NS], true)) {
				return '';
			}

			$seen_attributes = [];
			foreach (iterator_to_array($node->attributes) as $attribute) {
				$normalized_name = strtolower($attribute->nodeName);

				if (isset($seen_attributes[$normalized_name])) {
					return '';
				}

				$seen_attributes[$normalized_name] = true;

				if (
					$attribute->prefix &&
					!(
						($attribute->prefix === 'xlink' &&
							$attribute->namespaceURI === self::XLINK &&
							$attribute->localName === 'href') ||
						($attribute->prefix === 'xml' && $attribute->localName === 'space')
					)
				) {
					return '';
				}

				// HTML folds names: use the same spelling before CSS and ID resolution.
				if (
					in_array(
						$normalized_name,
						['id', 'class', 'style', 'href', 'aria-labelledby'],
						true,
					) &&
					$attribute->nodeName !== $normalized_name
				) {
					$value = $attribute->value;
					$node->removeAttributeNode($attribute);
					$node->setAttribute($normalized_name, $value);
				}
			}
		}

		// Caller attributes are part of the same final validation, never appended afterwards.
		foreach ($attributes as $name => $value) {
			if (
				in_array(
					$name,
					['class', 'width', 'height', 'role', 'aria-label', 'aria-hidden', 'focusable'],
					true,
				) &&
				is_scalar($value)
			) {
				if ($name === 'class') {
					$value = trim($root->getAttribute('class') . ' ' . (string) $value);
				}
				$root->setAttribute($name, (string) $value);
			}
		}

		if (
			!WPHAVE_SVG_Presentation::flatten($document) ||
			!WPHAVE_Safe_SVG::sanitize_document($document)
		) {
			return '';
		}

		$xpath = new DOMXPath($document);
		foreach ($xpath->query('//comment() | //processing-instruction()') as $node) {
			$node->parentNode->removeChild($node);
		}

		$ids = [];
		$prefix = $scope ? 'wphave-svg-' . bin2hex(random_bytes(12)) . '-' : '';
		foreach ($document->getElementsByTagName('*') as $node) {
			if (!$node->hasAttribute('id')) {
				continue;
			}

			$id = $node->getAttribute('id');

			if (!preg_match('/^[a-zA-Z_][\w.-]*$/D', $id) || isset($ids[$id])) {
				return '';
			}

			$ids[$id] = [$prefix . $id, $node];
			$node->setAttribute('id', $prefix . $id);
		}

		foreach ($document->getElementsByTagName('*') as $node) {
			foreach (iterator_to_array($node->attributes) as $attribute) {
				$name = strtolower($attribute->nodeName);
				$value = trim($attribute->value);

				if (in_array($name, ['href', 'xlink:href'], true)) {
					$id = substr($value, 1);
					$target = $ids[$id][1] ?? null;

					if (
						!str_starts_with($value, '#') ||
						!$target ||
						self::unsafe_reuse($node, $target)
					) {
						$node->removeAttributeNode($attribute);
					} else {
						$attribute->value = '#' . $ids[$id][0];
					}

					continue;
				}

				if ($name === 'aria-labelledby') {
					$references = [];
					foreach (preg_split('/\s+/', $value) as $id) {
						if (isset($ids[$id])) {
							$references[] = $ids[$id][0];
						}
					}

					$attribute->value = implode(' ', $references);

					continue;
				}

				if (in_array($name, self::PAINT, true)) {
					$value = WPHAVE_SVG_Presentation::value($name, $value);

					if ($value !== null && preg_match('/^url\(#([\w.-]+)\)$/D', $value, $match)) {
						$value = isset($ids[$match[1]]) ? 'url(#' . $ids[$match[1]][0] . ')' : null;
					}

					if ($value === null) {
						$node->removeAttributeNode($attribute);
					} else {
						$attribute->value = $value;
					}

					continue;
				}

				// No other attribute may introduce CSS functions, escapes or a resource URL.
				if (
					!in_array($name, ['xmlns', 'xmlns:xlink', 'aria-label', 'title'], true) &&
					preg_match(
						'/url\s*\(|[\\\\<>]|(?:https?:|data:|javascript:|vbscript:)/i',
						$value,
					)
				) {
					$node->removeAttributeNode($attribute);
				}
			}
		}

		return $document->saveXML($root) ?: '';
	}

	/** Do not allow recursive or chained use trees to amplify rendering work. */

	private static function unsafe_reuse(DOMElement $node, DOMElement $target): bool {
		if ($node === $target) {
			return true;
		}

		if ($node->localName !== 'use') {
			return false;
		}

		if ($target->localName === 'use' || $target->getElementsByTagName('use')->length > 0) {
			return true;
		}

		for ($parent = $node->parentNode; $parent; $parent = $parent->parentNode) {
			if ($parent === $target) {
				return true;
			}
		}

		return false;
	}
}
