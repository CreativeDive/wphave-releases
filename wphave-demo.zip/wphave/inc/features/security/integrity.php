<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Shared integrity primitives for authenticated structured state.
 */

final class WPHAVE_Security_Integrity {

	/**
	 * Signs a payload with explicit domain separation.
	 */

	public static function sign(
		string $context,
		array $payload,
		string $salt_scheme = 'auth'
	): string {
		return hash_hmac('sha256', self::message($context, $payload), wp_salt($salt_scheme));
	}

	/** Canonical bytes shared by transient and durable integrity protocols. */
	public static function message(string $context, array $payload): string {
		$canonical = self::canonicalize($payload);
		$encoded = wp_json_encode($canonical, JSON_UNESCAPED_SLASHES);

		if (false === $encoded) {
			throw new RuntimeException('The integrity payload could not be encoded.');
		}

		// SECURITY INVARIANT: Non-empty protocol contexts are part of the MAC, so
		// valid data cannot authorize another mutation boundary. An empty context is
		// retained only for byte-compatible migration of an established record format.
		return '' === $context ? $encoded : $context . "\n" . $encoded;
	}

	/**
	 * Verifies a lowercase SHA-256 HMAC in constant time.
	 */

	public static function verify( string $context, array $payload, string $signature, string $salt_scheme = 'auth' ): bool {
		$signature = strtolower( $signature );

		return preg_match( '/^[a-f0-9]{64}$/', $signature )
			&& hash_equals( self::sign( $context, $payload, $salt_scheme ), $signature );
	}

	/**
	 * Recursively sorts maps while preserving list order.
	 *
	 * @param mixed $value
	 * @return mixed
	 */

	private static function canonicalize( $value ) {
		if ( ! is_array( $value ) ) {
			return $value;
		}
		if ( array_keys( $value ) !== range( 0, count( $value ) - 1 ) ) {
			ksort( $value );
		}
		foreach ( $value as $key => $item ) {
			$value[ $key ] = self::canonicalize( $item );
		}

		return $value;
	}
}
