<?php

/** Bootstrap security services that affect public rendering. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/css-compiler.php';
require_once __DIR__ . '/block-classnames-access.php';
