<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WPHAVE_Security_File_Identity' ) ) :

	/**
	 * Observes size and content identity from one locked regular-file revision.
	 */
	final class WPHAVE_Security_File_Identity {

		/**
		 * Returns the exact byte count and SHA-256 of one stable file stream.
		 */
		public static function inspect( string $path, string $error_message ): array {
			$observation = self::observe( $path, false, $error_message );
			unset( $observation['contents'] );

			return $observation;
		}

		/**
		 * Returns exact bytes together with their coherent stream identity.
		 */
		public static function read( string $path, string $error_message ): array {
			return self::observe( $path, true, $error_message );
		}

		/** Opens one verified regular-file revision for coherent streaming. */
		public static function open( string $path, string $error_message ): array {
			return self::observe( $path, false, $error_message, true );
		}

		/**
		 * Opens a stable stream without a preliminary full content-hash pass.
		 */
		public static function open_stream( string $path, string $error_message ): array {
			return self::observe( $path, false, $error_message, true, false );
		}

		/** Release a stream retained by open(). */
		public static function close( array $observation ): void {
			$handle = $observation['handle'] ?? null;
			if ( ! is_resource( $handle ) ) {
				return;
			}

			@flock( $handle, LOCK_UN );
			@fclose( $handle );
		}

		/**
		 * Returns exact bytes only when they retain the caller-authorized identity.
		 */
		public static function read_verified( string $path, int $expected_bytes, string $expected_checksum, string $error_message ): string {
			$expected_checksum = strtolower( $expected_checksum );
			if ( $expected_bytes < 0 || 1 !== preg_match( '/^[a-f0-9]{64}$/', $expected_checksum ) ) {
				throw new RuntimeException( $error_message );
			}

			$observation = self::observe( $path, true, $error_message );

			// SECURITY INVARIANT: Authorization and consumption refer to the same
			// captured bytes, never to a checksum from an earlier path-based pass.
			if (
				$observation['bytes'] !== $expected_bytes
				|| ! hash_equals( $expected_checksum, $observation['checksum'] )
			) {
				throw new RuntimeException( $error_message );
			}

			return $observation['contents'];
		}

		/**
		 * Read a bounded prefix or suffix from one stable regular-file inode.
		 */

		public static function read_bounded( string $path, int $bytes, bool $from_end, string $error_message ): array {
			$bytes = max( 1, $bytes );
			clearstatcache( true, $path );
			$identity = @lstat( $path );
			$handle = ! is_link( $path ) && is_file( $path ) ? @fopen( $path, 'rb' ) : false;
			$locked = is_resource( $handle ) && @flock( $handle, LOCK_SH );
			$opened = is_resource( $handle ) ? @fstat( $handle ) : false;
			$size = is_array( $opened ) ? (int) $opened['size'] : 0;
			$offset = $from_end ? max( 0, $size - $bytes ) : 0;
			$positioned = $locked && ( 0 === $offset || 0 === @fseek( $handle, $offset ) );
			$contents = $positioned ? @stream_get_contents( $handle, $bytes ) : false;
			$final = is_resource( $handle ) ? @fstat( $handle ) : false;
			clearstatcache( true, $path );
			$current = @lstat( $path );

			// BOUNDED READ INVARIANT: Size, bytes and truncation metadata all belong
			// to the same locked regular inode that remains at the authorized path.
			$valid = $locked
				&& $positioned
				&& is_string( $contents )
				&& self::same_regular_file( $identity, $opened )
				&& self::same_regular_file( $opened, $final )
				&& self::same_regular_file( $final, $current )
				&& (int) $final['size'] === $size;

			if( is_resource( $handle ) ) {
				if( $locked ) {
					@flock( $handle, LOCK_UN );
				}
				@fclose( $handle );
			}

			if( ! $valid ) {
				throw new RuntimeException( $error_message );
			}

			return array(
				'content' => $contents,
				'truncated' => $from_end ? $offset > 0 : $size > $bytes,
				'bytesRead' => strlen( $contents ),
				'sizeBytes' => $size,
			);
		}

		/**
		 * Observes one stable stream, optionally retaining its exact bytes.
		 */
		private static function observe( string $path, bool $capture_contents, string $error_message, bool $retain_handle = false, bool $calculate_checksum = true ): array {
			clearstatcache( true, $path );
			// Missing or concurrently removed paths are an expected invalid state.
			// Keep the observation fail-closed without leaking filesystem warnings.
			$identity = @lstat( $path );
			$handle = ! is_link( $path ) && is_file( $path ) ? fopen( $path, 'rb' ) : false;
			$locked = is_resource( $handle ) && flock( $handle, LOCK_SH );
			$opened = is_resource( $handle ) ? fstat( $handle ) : false;
			$contents = $capture_contents && $locked ? stream_get_contents( $handle ) : null;
			$context = ! $capture_contents && $calculate_checksum ? hash_init( 'sha256' ) : null;
			if ( ! $capture_contents && $calculate_checksum && $locked ) {
				$observed_bytes = hash_update_stream( $context, $handle );
			} elseif ( $capture_contents ) {
				$observed_bytes = is_string( $contents ) ? strlen( $contents ) : false;
			} else {
				$observed_bytes = is_array( $opened ) ? (int) $opened['size'] : false;
			}
			$checksum = false !== $observed_bytes && $calculate_checksum
				? ( $capture_contents ? hash( 'sha256', $contents ) : hash_final( $context ) )
				: '';
			$positioned = ! $retain_handle || ( is_resource( $handle ) && 0 === @fseek( $handle, 0 ) );
			$final = is_resource( $handle ) ? fstat( $handle ) : false;
			clearstatcache( true, $path );
			$current = @lstat( $path );

			// SECURITY INVARIANT: Reported size and digest come from the same locked
			// regular inode that remains published at the authorized path.
			$valid = $locked
				&& $positioned
				&& self::same_regular_file( $identity, $opened )
				&& self::same_regular_file( $opened, $final )
				&& self::same_regular_file( $final, $current )
				&& is_int( $observed_bytes )
				&& $observed_bytes === (int) $opened['size']
				&& (int) $final['size'] === (int) $opened['size']
				&& ( ! $calculate_checksum || 1 === preg_match( '/^[a-f0-9]{64}$/', $checksum ) );

			if ( is_resource( $handle ) && ( ! $valid || ! $retain_handle ) ) {
				if ( $locked ) {
					flock( $handle, LOCK_UN );
				}
				fclose( $handle );
			}

			if ( ! $valid ) {
				throw new RuntimeException( $error_message );
			}

			return array(
				'bytes' => (int) $opened['size'],
				'checksum' => $checksum,
				'contents' => is_string( $contents ) ? $contents : '',
				'permissions' => (int) $opened['mode'] & 0777,
				'handle' => $retain_handle ? $handle : null,
			);
		}

		/**
		 * Returns whether two stat snapshots identify the same regular file.
		 */
		private static function same_regular_file( $first, $second ): bool {
			return is_array( $first )
				&& is_array( $second )
				&& 0100000 === ( (int) $first['mode'] & 0170000 )
				&& 0100000 === ( (int) $second['mode'] & 0170000 )
				&& (int) $first['dev'] === (int) $second['dev']
				&& (int) $first['ino'] === (int) $second['ino'];
		}
	}

endif;
