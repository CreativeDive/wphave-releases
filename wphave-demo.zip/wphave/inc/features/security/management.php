<?php

/** Bootstrap security management endpoints. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/authorization/action-authorization.php';
require_once __DIR__ . '/authorization/rest-controller.php';

/** Load the scanner synchronously only while its REST surface is registered. */
function wphave_security_scanner_register_management_routes(): void {
	require_once __DIR__ . '/scanner.php';

	WPHAVE_Security_Scanner::register_rest_routes();
}

add_action( 'rest_api_init', 'wphave_security_scanner_register_management_routes' );
