<?php

if (!defined('ABSPATH')) {
	exit();
}

/** Live-file permissions are an explicit policy, separate from atomic publication. */

final class WPHAVE_Security_File_Permissions {
	/** Trusted local snapshot only; never accept permissions from an imported archive. */

	public static function recorded($permissions): int {
		if (!is_int($permissions) || $permissions < 1 || $permissions > 0777) {
			throw new RuntimeException('Original file permissions are unavailable or invalid.');
		}

		return $permissions;
	}

	/** Preserve read/write restrictions of one verified local file identity. */

	public static function existing(array $identity): int {
		return self::recorded(self::recorded($identity['permissions'] ?? null) & 0666);
	}

	/** Caller must already authorize the destination and validate its parent chain. */

	public static function for_new_public_file(string $destination): int {
		$parent = dirname($destination);
		clearstatcache(true, $parent);
		$stat = @lstat($parent);

		if (!is_array($stat) || ($stat['mode'] & 0170000) !== 0040000) {
			throw new RuntimeException('The publication directory is unavailable or unsafe.');
		}

		// SECURITY/PUBLICATION INVARIANT: Match WordPress directory-derived
		// read/write permissions. Never inherit private staging/archive modes,
		// invent a public 0644 fallback, or grant executable/special bits.
		return self::recorded((int) $stat['mode'] & 0666);
	}
	/** Read traversal and inheritance permissions from an authorized local directory. */
	public static function directory(string $path): int {
		clearstatcache(true, $path);
		$stat = @lstat($path);
		if (!is_array($stat) || ($stat['mode'] & 0170000) !== 0040000) {
			throw new RuntimeException('Directory permission authority is unavailable or unsafe.');
		}
		// SECURITY INVARIANT: Only trusted local directories grant traversal,
		// setgid and sticky bits. Archive metadata is never permission authority.
		return (int) $stat['mode'] & 03777;
	}

	/** Match a staging node's group to a trusted local file or directory, preserving its mode.
	 *
	 * The caller owns the isolated staging node and validates all parent paths.
	 * Failure prevents activation; imported archive group IDs never grant authority.
	 */
	public static function apply_group(string $target, string $local_source): void {
		clearstatcache(true, $local_source);
		$source = @lstat($local_source);
		if (!is_array($source) || !in_array($source['mode'] & 0170000, [0040000, 0100000], true)) {
			throw new RuntimeException('Local group authority is unsafe.');
		}
		self::apply_recorded_group($target, self::recorded_group($source['gid'] ?? null));
	}

	/** Validate a GID captured locally, never imported from archive/request metadata. */
	public static function recorded_group($group): int {
		if (!is_int($group) || $group < 0 || $group >= 4294967295) {
			throw new RuntimeException('Original local file group is unavailable or invalid.');
		}
		return $group;
	}

	/** Read group authority from an authorized local parent for a new file. */
	public static function for_new_public_group(string $destination): int {
		$parent = dirname($destination);
		clearstatcache(true, $parent);
		$stat = @lstat($parent);
		if (!is_array($stat) || ($stat['mode'] & 0170000) !== 0040000) {
			throw new RuntimeException('Publication group authority is unavailable or unsafe.');
		}
		return self::recorded_group($stat['gid'] ?? null);
	}

	/** Apply a trusted snapshot GID to caller-owned staging before publication. */
	public static function apply_recorded_group(string $target, int $group): void {
		$group = self::recorded_group($group);
		clearstatcache(true, $target);
		$before = @lstat($target);
		if (!is_array($before) || !in_array($before['mode'] & 0170000, [0040000, 0100000], true)) {
			throw new RuntimeException('Staging node is unsafe.');
		}
		$mode = $before['mode'] & 03777;
		// SECURITY/PUBLICATION INVARIANT: Mode bits refer to a concrete local
		// group. Never activate a tree with a substituted group or ignore chgrp failure.
		// PORTABILITY INVARIANT: A disabled chgrp is a controlled failure only
		// when a group change is needed; an already-correct group needs no syscall.
		if (
			$before['gid'] !== $group &&
			(!function_exists('chgrp') || !@chgrp($target, $group) || !@chmod($target, $mode))
		) {
			throw new RuntimeException('The local publication group could not be retained.');
		}
		clearstatcache(true, $target);
		$after = @lstat($target);
		if (
			!is_array($after) ||
			$before['dev'] !== $after['dev'] ||
			$before['ino'] !== $after['ino'] ||
			($before['mode'] & 0170000) !== ($after['mode'] & 0170000) ||
			$after['gid'] !== $group ||
			($after['mode'] & 03777) !== $mode
		) {
			throw new RuntimeException('The staged publication group could not be verified.');
		}
	}

	/** Set a caller-owned staging directory's final mode before tree activation. */
	public static function apply_directory(string $target, string $local_source): void {
		$permissions = self::directory($local_source);
		self::directory($target);
		self::apply_group($target, $local_source);
		$before = lstat($target);
		if (!@chmod($target, $permissions)) {
			throw new RuntimeException('Staged directory permissions could not be applied.');
		}
		clearstatcache(true, $target);
		$after = @lstat($target);
		if (
			!is_array($after) ||
			$before['dev'] !== $after['dev'] ||
			$before['ino'] !== $after['ino'] ||
			($after['mode'] & 0170000) !== 0040000 ||
			($after['mode'] & 03777) !== $permissions
		) {
			throw new RuntimeException('Staged directory permissions could not be verified.');
		}
	}
	/** Set and verify a mode on the exclusive output inode; never trust chmod alone. */
	public static function apply_file_mode(
		string $path,
		array $identity,
		int $permissions,
		string $error_message,
	): void {
		clearstatcache(true, $path);
		$before = @lstat($path);
		if (
			!is_array($before) ||
			($before['mode'] & 0170000) !== 0100000 ||
			$before['dev'] !== $identity['dev'] ||
			$before['ino'] !== $identity['ino'] ||
			!@chmod($path, $permissions)
		) {
			throw new RuntimeException($error_message);
		}
		clearstatcache(true, $path);
		$after = @lstat($path);
		// SECURITY INVARIANT: A successful syscall alone does not establish
		// privacy; verify mode, type and identity before permitting any write.
		if (
			!is_array($after) ||
			($after['mode'] & 0170000) !== 0100000 ||
			$after['dev'] !== $identity['dev'] ||
			$after['ino'] !== $identity['ino'] ||
			($after['mode'] & 07777) !== $permissions
		) {
			throw new RuntimeException($error_message);
		}
	}

	/** Verify private mode on a caller-owned stream before streaming sensitive bytes. */
	public static function prepare_private_stream(string $path, $handle): void {
		$identity = is_resource($handle) ? fstat($handle) : false;
		if (!is_array($identity)) {
			throw new RuntimeException('Private output stream is unavailable.');
		}
		// SECURITY INVARIANT: Backup streaming follows the same first-byte policy
		// as atomic files. The caller closes and removes its output on failure.
		self::apply_file_mode(
			$path,
			$identity,
			0600,
			'Private output permissions could not be established.',
		);
	}
}
