<?php

/** Exact-route wire-size admission before WordPress materializes REST JSON. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WPHAVE_REST_Body_Budget {
	private static array $rules = array();
	private static bool $hooked = false;

	/** Register a literal route or an anchored route expression owned by its module. */
	public static function protect( string $method, string $route_expression, int $max_bytes ): void {
		if ( $max_bytes < 1 ) {
			throw new InvalidArgumentException( 'REST body budget must be positive.' );
		}

		$key = strtoupper( $method ) . ':' . $route_expression;
		self::$rules[ $key ] = array( strtoupper( $method ), $route_expression, $max_bytes );

		if ( ! self::$hooked ) {
			add_filter( 'rest_pre_dispatch', array( __CLASS__, 'preflight' ), 9, 3 );
			self::$hooked = true;
		}
	}

	/** Preserve earlier dispatch decisions and reject only matching oversized bodies. */
	public static function preflight( $response, $server, $request ) {
		if ( $response || ! $request instanceof WP_REST_Request ) {
			return $response;
		}

		$method = strtoupper( $request->get_method() );
		$route = $request->get_route();
		foreach ( self::$rules as [ $rule_method, $expression, $max_bytes ] ) {
			if ( $method !== $rule_method || ! preg_match( $expression, $route ) ) {
				continue;
			}

			// ADMISSION INVARIANT: REST argument validation decodes JSON before the
			// callback. The raw wire document must fit its route budget first.
			$error = self::check( $request, $max_bytes );
			if ( $error ) {
				return $error;
			}
		}

		return $response;
	}

	/** Repeat the same JSON budget at direct callback boundaries. */
	public static function check( WP_REST_Request $request, int $max_bytes ): ?WP_Error {
		$content_type = strtolower( (string) $request->get_header( 'content-type' ) );
		if ( str_contains( $content_type, 'json' ) && strlen( $request->get_body() ) > $max_bytes ) {
			return new WP_Error(
				'wphave_rest_body_too_large',
				__( 'The request body is too large.', 'wphave' ),
				array( 'status' => 413 )
			);
		}

		return null;
	}
}
