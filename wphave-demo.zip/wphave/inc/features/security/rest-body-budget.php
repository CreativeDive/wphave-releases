<?php

/** Exact-route wire-size admission before WordPress materializes REST parameters. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WPHAVE_REST_Body_Budget {
	private static array $rules = array();
	private static bool $hooked = false;

	/** Register a literal route or an anchored route expression owned by its module. */
	public static function protect( string $method, string $route_expression, int $max_bytes ): void {
		if ( $max_bytes < 1 ) {
			throw new InvalidArgumentException( 'REST body budget must be positive.' );
		}

		$key = strtoupper( $method ) . ':' . $route_expression;
		self::$rules[ $key ] = array( strtoupper( $method ), $route_expression, $max_bytes );

		if ( ! self::$hooked ) {
			add_filter( 'rest_pre_dispatch', array( __CLASS__, 'preflight' ), 9, 3 );
			self::$hooked = true;
		}
	}

	/** Preserve earlier dispatch decisions and reject only matching oversized bodies. */
	public static function preflight( $response, $server, $request ) {
		// WordPress treats every non-null result as a prior dispatch decision.
		if ( null !== $response || ! $request instanceof WP_REST_Request ) {
			return $response;
		}

		$method = strtoupper( $request->get_method() );
		// ROUTE-IDENTITY INVARIANT: Core matches REST routes without case.
		// Admission must do the same or alternate casing bypasses the budget.
		$route = strtolower( $request->get_route() );
		foreach ( self::$rules as [ $rule_method, $expression, $max_bytes ] ) {
			if ( $method !== $rule_method || ! preg_match( $expression, $route ) ) {
				continue;
			}

			// ADMISSION INVARIANT: REST argument validation can decode JSON or
			// URL-encoded parameters before the callback. Bound the raw body first.
			$error = self::check( $request, $max_bytes );
			if ( $error ) {
				return $error;
			}
		}

		return $response;
	}

	/** Repeat the same parsed-body budget at direct callback boundaries. */
	public static function check( WP_REST_Request $request, int $max_bytes ): ?WP_Error {
		// PARSED-BODY INVARIANT: Apply this limit only to body types WordPress
		// parses as arguments; multipart uploads have separate upload limits.
		$content_type = strtolower( trim( (string) $request->get_header( 'content-type' ) ) );
		$media_type   = trim( explode( ';', $content_type, 2 )[0] );
		$parses_body  = '' === $media_type
			|| 'application/x-www-form-urlencoded' === $media_type
			|| str_contains( $media_type, 'json' );

		if ( $parses_body && strlen( $request->get_body() ) > $max_bytes ) {
			return new WP_Error(
				'wphave_rest_body_too_large',
				__( 'The request body is too large.', 'wphave' ),
				array( 'status' => 413 )
			);
		}

		return null;
	}
}
