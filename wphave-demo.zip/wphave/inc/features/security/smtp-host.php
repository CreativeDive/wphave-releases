<?php

if ( ! class_exists( 'WPHAVE_SMTP_Host' ) ) :
	/** A single DNS hostname or IPv4 address for PHPMailer's Host field. */
	class WPHAVE_SMTP_Host {
		public static function is_valid( $candidate ): bool {
			// HOST-IDENTITY INVARIANT: PHPMailer accepts multi-host and scheme
			// syntax here. Only one plain DNS hostname or IPv4 address may pass.
			if ( ! is_string( $candidate ) || $candidate === '' || strlen( $candidate ) > 253 ) {
				return false;
			}

			foreach ( explode( '.', $candidate ) as $label ) {
				if (
					$label === '' ||
					strlen( $label ) > 63 ||
					! preg_match( '/^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/iD', $label )
				) {
					return false;
				}
			}

			return true;
		}
	}
endif;
