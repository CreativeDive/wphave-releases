<?php

/** Bootstrap security primitives required in every request context. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/authorization/access-token-verifier.php';
require_once __DIR__ . '/authorization/action-authorization.php';
require_once __DIR__ . '/authorization/rest-controller.php';
require_once __DIR__ . '/rate-limiter.php';
require_once __DIR__ . '/client-ip.php';
require_once __DIR__ . '/rest-body-budget.php';
require_once __DIR__ . '/safe-svg.php';
