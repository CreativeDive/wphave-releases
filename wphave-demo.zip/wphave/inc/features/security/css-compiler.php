<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Shared security boundary for user-authored CSS.
 *
 * Sources of truth:
 * - Reusable CSS classes store declarations/rules in their post content.
 * - Custom block CSS is stored only in `wphave.features.css`.
 * - Generated attributes such as the former `stylesCustom` are never trusted
 *   or persisted. Editor and frontend compile directly from the source.
 *
 * Supported authored syntax:
 * - Top-level declarations, which are wrapped in the supplied scope.
 * - Normal selectors, `&`, `$class`, and `$block` scope placeholders.
 * - Nested `@media`, `@supports`, and `@container` condition groups.
 * - Commas and braces inside quoted strings and selector functions.
 *
 * Security contract:
 * - The caller owns the scope selector; user input can never choose it.
 * - Imports, executable URL schemes, legacy executable declarations, script
 *   tags, comments, and unsupported/unscoped at-rules are removed.
 * - Source length, nesting depth, and total rule count are bounded before CSS
 *   reaches either the editor preview or server-side rendering.
 * - Server-side compilation is authoritative. The JavaScript equivalent only
 *   provides immediate editor feedback and must remain behaviorally aligned.
 * - This is a deliberately small CSS parser, not a general CSS formatter. New
 *   syntax must be added with matching PHP/JavaScript regression tests.
 *
 * Persistence contract:
 * - Users without `wphave_manage_block_css` may edit ordinary post content but
 *   cannot add or change `features.css` through REST or raw block markup.
 * - Stable server-managed contract IDs retain CSS on the same block instance
 *   across reordering and prevent copied identities from multiplying access.
 * - `stylesCustom` is stripped from every save because WPHAVE has no released
 *   content requiring that redundant legacy representation.
 */

if ( ! class_exists( 'WPHAVE_CSS_Compiler' ) ) :

class WPHAVE_CSS_Compiler {

	const CAPABILITY = 'wphave_manage_block_css';
	const MAX_SOURCE_LENGTH = 65536;
	const MAX_NESTING_DEPTH = 8;
	const MAX_RULES = 500;
	const CONTRACT_KEY = 'cssContract';

	/**
	 * Register the persistence protection hook.
	 *
	 * @return void
	 */

	public static function register_hooks() {
		add_filter( 'wp_insert_post_data', array( __CLASS__, 'protect_stored_block_css' ), 30, 2 );
	}

	/**
	 * Remove unsafe constructs from user-authored CSS.
	 *
	 * Sanitized source is not ready for output until scope_source() has bound it
	 * to a caller-owned selector.
	 *
	 * @param mixed $css Raw CSS source.
	 * @return string Sanitized CSS source.
	 */

	public static function sanitize_source( $css ) {
		$css = is_string( $css ) ? $css : '';
		$css = function_exists( 'mb_substr' ) ? mb_substr( $css, 0, self::MAX_SOURCE_LENGTH ) : substr( $css, 0, self::MAX_SOURCE_LENGTH );
		$css = preg_replace( '#/\*.*?\*/#s', '', $css );
		$css = preg_replace( '/@import\b[^;{}]*(?:;|$)/i', '', $css );
		$css = preg_replace( '/(?:expression|behavior|-moz-binding)\s*:/i', '', $css );
		$css = preg_replace( '/expression\s*\([^)]*\)/i', '', $css );
		$css = preg_replace( '/<\/?(?:script|style)\b[^>]*>/i', '', $css );
		$css = preg_replace_callback( '#url\s*\(\s*(.*?)\s*\)(?=\s*[,;}]|$)#is', function( $matches ) {

			$value = trim( $matches[1], " \t\n\r\0\x0B\"'" );
			$decoded = preg_replace_callback( '/\\\\([0-9a-f]{1,6})\s?/i', function( $escape ) {
				return html_entity_decode( '&#x' . $escape[1] . ';', ENT_QUOTES, 'UTF-8' );
			}, $value );
			$protocol = strtolower( preg_replace( '/[\x00-\x20]+/', '', $decoded ) );

			$is_unsafe = str_starts_with( $protocol, 'javascript:' )
				|| str_starts_with( $protocol, 'vbscript:' )
				|| str_starts_with( $protocol, 'data:text/html' );

			return $is_unsafe ? 'url("")' : $matches[0];

		}, $css );

		return trim( $css );
	}

	/**
	 * Split CSS into top-level declarations and complete rules.
	 *
	 * Quotes and brace depth are tracked so punctuation inside strings or nested
	 * conditional rules cannot be mistaken for a top-level boundary.
	 *
	 * @param string $source Sanitized CSS source.
	 * @return array{declarations:string,rules:array<int,array{selector:string,body:string}>}
	 */

	public static function split_top_level_css( $source ) {
		$source = trim( (string) $source );
		$length = strlen( $source );
		$depth = 0;
		$selector = '';
		$body = '';
		$declarations = '';
		$rules = array();
		$reading_body = false;
		$quote = '';
		$escaped = false;

		for( $i = 0; $i < $length; $i++ ) {
			$char = $source[$i];

			if( $quote ) {
				if( $reading_body ) {
					$body .= $char;
				} else {
					$selector .= $char;
				}

				if( $escaped ) {
					$escaped = false;
				} elseif( $char === '\\' ) {
					$escaped = true;
				} elseif( $char === $quote ) {
					$quote = '';
				}

				continue;
			}

			if( $char === '"' || $char === "'" ) {
				$quote = $char;

				if( $reading_body ) {
					$body .= $char;
				} else {
					$selector .= $char;
				}

				continue;
			}

			if( $char === '{' ) {
				if( $depth === 0 ) {
					$last_declaration = strrpos( $selector, ';' );

					if( $last_declaration !== false ) {
						$declarations .= substr( $selector, 0, $last_declaration + 1 );
						$selector = substr( $selector, $last_declaration + 1 );
					}

					$reading_body = true;
					$body = '';
				} else {
					$body .= $char;
				}

				$depth++;
				continue;
			}

			if( $char === '}' ) {
				if( $depth === 0 ) {
					continue;
				}

				$depth--;

				if( $depth === 0 ) {
					$rules[] = array(
						'selector' => trim( $selector ),
						'body' => trim( $body ),
					);
					$selector = '';
					$body = '';
					$reading_body = false;
					continue;
				}

				$body .= $char;
				continue;
			}

			if( $depth === 0 ) {
				$selector .= $char;
			} elseif( $reading_body ) {
				$body .= $char;
			}
		}

		if( trim( $selector ) ) {
			$declarations .= trim( $selector );
		}

		return array(
			'declarations' => trim( $declarations ),
			'rules' => $rules,
		);
	}

	/**
	 * Split a selector list without breaking commas inside functions or strings.
	 *
	 * @param string $selector CSS selector list.
	 * @return string[] Individual selectors.
	 */

	public static function split_selector_list( $selector ) {
		$output = array();
		$current = '';
		$quote = '';
		$escaped = false;
		$parentheses = 0;

		foreach( str_split( (string) $selector ) as $char ) {
			if( $quote ) {
				$current .= $char;

				if( $escaped ) {
					$escaped = false;
				} elseif( $char === '\\' ) {
					$escaped = true;
				} elseif( $char === $quote ) {
					$quote = '';
				}

				continue;
			}

			if( $char === '"' || $char === "'" ) {
				$quote = $char;
				$current .= $char;
				continue;
			}

			if( $char === '(' ) {
				$parentheses++;
			}

			if( $char === ')' && $parentheses > 0 ) {
				$parentheses--;
			}

			if( $char === ',' && $parentheses === 0 ) {
				$output[] = trim( $current );
				$current = '';
				continue;
			}

			$current .= $char;
		}

		if( trim( $current ) ) {
			$output[] = trim( $current );
		}

		return array_values( array_filter( $output ) );
	}

	/**
	 * Bind every selector in a list to a trusted scope.
	 *
	 * `$block` and `$class` are equivalent aliases for the supplied scope. An
	 * ampersand prefixes the remaining selector with that scope.
	 *
	 * @param string $selector User-authored selector list.
	 * @param string $scope Trusted selector supplied by the caller.
	 * @return string Scoped selector list.
	 */

	public static function scope_selector( $selector, $scope ) {
		$output = array();

		foreach( self::split_selector_list( $selector ) as $item ) {
			if( str_contains( $item, '$block' ) ) {
				$output[] = str_replace( '$block', $scope, $item );
				continue;
			}

			if( str_contains( $item, '$class' ) ) {
				$output[] = str_replace( '$class', $scope, $item );
				continue;
			}

			if( str_starts_with( $item, '&' ) ) {
				$output[] = $scope . substr( $item, 1 );
				continue;
			}

			$output[] = str_starts_with( $item, $scope ) ? $item : $scope . ' ' . $item;
		}

		return implode( ',', $output );
	}

	/**
	 * Sanitize and compile CSS beneath a trusted selector.
	 *
	 * Conditional groups are recursively scoped. Unsupported at-rules such as
	 * @font-face and @keyframes are dropped because they escape local scoping.
	 *
	 * @param mixed  $source Raw CSS source.
	 * @param string $selector Trusted block or class selector.
	 * @return string Compiled and scoped CSS.
	 */

	public static function scope_source( $source, $selector ) {
		$rule_count = 0;

		return self::compile_source( $source, $selector, 0, $rule_count );
	}

	/**
	 * Compile one recursion level while enforcing shared complexity limits.
	 *
	 * @param mixed  $source Raw CSS source.
	 * @param string $selector Trusted block or class selector.
	 * @param int    $depth Current conditional-rule nesting depth.
	 * @param int    $rule_count Number of rules processed by this compilation.
	 * @return string Compiled and scoped CSS.
	 */

	private static function compile_source( $source, $selector, $depth, &$rule_count ) {
		if( $depth > self::MAX_NESTING_DEPTH || $rule_count >= self::MAX_RULES ) {
			return '';
		}

		$source = self::sanitize_source( $source );
		$selector = trim( (string) $selector );

		if( ! $source || ! $selector ) {
			return '';
		}

		$parts = self::split_top_level_css( $source );
		$css = ! empty( $parts['declarations'] ) ? $selector . '{' . $parts['declarations'] . '}' : '';

		foreach( $parts['rules'] as $rule ) {
			$rule_count++;

			if( $rule_count > self::MAX_RULES ) {
				break;
			}

			$rule_selector = $rule['selector'];
			$rule_body = $rule['body'];

			if( ! $rule_selector || ! $rule_body ) {
				continue;
			}

			if( preg_match( '/^@(media|supports|container)\b/i', $rule_selector ) ) {
				$nested_css = self::compile_source( $rule_body, $selector, $depth + 1, $rule_count );

				if( $nested_css ) {
					$css .= $rule_selector . '{' . $nested_css . '}';
				}

				continue;
			}

			if( str_starts_with( $rule_selector, '@' ) ) {
				continue;
			}

			$css .= self::scope_selector( $rule_selector, $selector ) . '{' . self::sanitize_source( $rule_body ) . '}';
		}

		return $css;
	}

	/**
	 * Collect ordered custom CSS values from a parsed block tree.
	 *
	 * Stable IDs are preferred. The structural path is used once to migrate
	 * existing blocks that predate the contract ID.
	 *
	 * @param array $blocks Parsed WordPress blocks.
	 * @return array<string,string[]> CSS values grouped by block name.
	 */

	private static function css_contracts_from_blocks( $blocks, $path = '' ) {
		$contracts = array();

		foreach( (array) $blocks as $index => $block ) {
			$block_name = (string) ( $block['blockName'] ?? '' );
			$block_path = $path . '/' . absint( $index );

			if( str_starts_with( $block_name, 'wphave/' ) ) {
				$wphave = $block['attrs']['wphave'] ?? array();
				$source = is_string( $wphave['features']['css'] ?? null ) ? $wphave['features']['css'] : '';
				$contract_id = sanitize_key( $wphave['features'][self::CONTRACT_KEY] ?? '' );
				$contract = array(
					'id' => $contract_id,
					'name' => $block_name,
					'path' => $block_path,
					'css' => $source,
				);
				$contracts['path:' . $block_path] = $contract;

				if( $contract_id ) {
					$contracts['id:' . $contract_id] = $contract;
				}
			}

			$contracts = array_merge( $contracts, self::css_contracts_from_blocks( $block['innerBlocks'] ?? array(), $block_path ) );
		}

		return $contracts;
	}

	/**
	 * Count submitted contract IDs so duplicated identities can be rejected.
	 *
	 * @param array $blocks Parsed WordPress blocks.
	 * @return array<string,int> Occurrences keyed by contract ID.
	 */

	private static function contract_id_counts( $blocks ) {
		$counts = array();

		foreach( (array) $blocks as $block ) {
			$contract_id = sanitize_key( $block['attrs']['wphave']['features'][self::CONTRACT_KEY] ?? '' );

			if( $contract_id ) {
				$counts[$contract_id] = ( $counts[$contract_id] ?? 0 ) + 1;
			}

			foreach( self::contract_id_counts( $block['innerBlocks'] ?? array() ) as $inner_id => $count ) {
				$counts[$inner_id] = ( $counts[$inner_id] ?? 0 ) + $count;
			}
		}

		return $counts;
	}

	/**
	 * Apply authorized CSS values to a parsed block tree.
	 *
	 * The method also removes the obsolete derived `stylesCustom` attribute from
	 * every WPHAVE block, regardless of the current user's capabilities.
	 *
	 * @param array $blocks Parsed WordPress blocks.
	 * @param array $allowed Ordered CSS values that may remain in the content.
	 * @param bool  $changed Whether the tree was modified.
	 * @return array Updated parsed blocks.
	 */

	private static function preserve_approved_block_css( $blocks, &$allowed, &$changed, $can_manage_css, &$used = array(), $path = '' ) {
		foreach( $blocks as $index => &$block ) {
			$block_name = (string) ( $block['blockName'] ?? '' );
			$block_path = $path . '/' . absint( $index );

			if( str_starts_with( $block_name, 'wphave/' ) ) {
				$wphave = $block['attrs']['wphave'] ?? array();
				$source = is_string( $wphave['features']['css'] ?? null ) ? $wphave['features']['css'] : '';
				$contract_id = sanitize_key( $wphave['features'][self::CONTRACT_KEY] ?? '' );
				$contract = $contract_id ? ( $allowed['id:' . $contract_id] ?? null ) : null;
				$contract = $contract ?: ( $allowed['path:' . $block_path] ?? null );

				if( $can_manage_css ) {
					$previous = $source;
					$contract_key = $contract_id ? 'id:' . $contract_id : '';
					$contract_id = $source && ( ! $contract_key || ! empty( $used[$contract_key] ) ) ? wp_generate_uuid4() : ( $source ? $contract_id : '' );

					if( $contract_id ) {
						$used['id:' . $contract_id] = true;
					}
				} else {
					$contract_key = ! empty( $contract['id'] ) ? 'id:' . $contract['id'] : 'path:' . $block_path;
					$valid_contract = $contract && $contract['name'] === $block_name && empty( $used[$contract_key] );
					$previous = $valid_contract ? $contract['css'] : '';
					$contract_id = $valid_contract && $previous ? ( $contract['id'] ?: wp_generate_uuid4() ) : '';
					$used[$contract_key] = $valid_contract;
				}

				if( $source !== $previous ) {
					if( $previous ) {
						$block['attrs']['wphave']['features']['css'] = $previous;
					} else {
						unset( $block['attrs']['wphave']['features']['css'] );
					}

					$changed = true;
				}

				$current_contract_id = sanitize_key( $block['attrs']['wphave']['features'][self::CONTRACT_KEY] ?? '' );

				if( $contract_id && $current_contract_id !== $contract_id ) {
					$block['attrs']['wphave']['features'][self::CONTRACT_KEY] = $contract_id;
					$changed = true;
				} elseif( ! $contract_id && $current_contract_id ) {
					unset( $block['attrs']['wphave']['features'][self::CONTRACT_KEY] );
					$changed = true;
				}

				if( isset( $block['attrs']['wphave']['stylesCustom'] ) ) {
					unset( $block['attrs']['wphave']['stylesCustom'] );
					$changed = true;
				}
			}

			if( ! empty( $block['innerBlocks'] ) ) {
				$block['innerBlocks'] = self::preserve_approved_block_css( $block['innerBlocks'], $allowed, $changed, $can_manage_css, $used, $block_path );
			}
		}

		return $blocks;
	}

	/**
	 * Protect custom block CSS while WordPress persists post content.
	 *
	 * Authorized users may persist the submitted `features.css` values. For
	 * other users, values from the currently stored post are reapplied before
	 * serialization. WordPress slashing is normalized around block parsing.
	 *
	 * @param array $data Sanitized post data about to be stored.
	 * @param array $postarr Raw post data supplied to wp_insert_post().
	 * @return array Filtered post data.
	 */

	public static function protect_stored_block_css( $data, $postarr ) {
		if( empty( $data['post_content'] ) || ! function_exists( 'parse_blocks' ) ) {
			return $data;
		}

		$submitted_content = wp_unslash( $data['post_content'] );
		$post_id = absint( $postarr['ID'] ?? 0 );
		$previous = $post_id ? get_post_field( 'post_content', $post_id ) : '';
		$has_css_contract = str_contains( $submitted_content, '"css"' )
			|| str_contains( $submitted_content, '"stylesCustom"' )
			|| str_contains( $submitted_content, '"' . self::CONTRACT_KEY . '"' )
			|| str_contains( (string) $previous, '"css"' )
			|| str_contains( (string) $previous, '"stylesCustom"' )
			|| str_contains( (string) $previous, '"' . self::CONTRACT_KEY . '"' );

		if( ! $has_css_contract ) {
			return $data;
		}

		// SECURITY INVARIANT: Without the CSS capability, submitted block trees may
		// retain only CSS contracts already attached to their unambiguous stored block.
		$can_manage_css = current_user_can( self::CAPABILITY ) || current_user_can( 'manage_options' );
		$submitted_blocks = parse_blocks( $submitted_content );
		$stored_blocks = parse_blocks( (string) $previous );
		$allowed = self::css_contracts_from_blocks( $stored_blocks );

		if( ! $can_manage_css ) {
			foreach( self::contract_id_counts( $submitted_blocks ) as $contract_id => $count ) {
				if( $count > 1 && isset( $allowed['id:' . $contract_id] ) ) {
					$data['post_content'] = wp_slash( (string) $previous );
					return $data;
				}
			}
		}

		$changed = false;
		$used = array();
		$blocks = self::preserve_approved_block_css( $submitted_blocks, $allowed, $changed, $can_manage_css, $used );

		if( $changed ) {
			$data['post_content'] = wp_slash( serialize_blocks( $blocks ) );
		}

		return $data;
	}
}

endif;

WPHAVE_CSS_Compiler::register_hooks();
