<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Context-specific normalization for untrusted diagnostic values.
 *
 * These methods protect persistence boundaries. Output still has to be escaped
 * for its final HTML, attribute, URL or JavaScript context.
 */

final class WPHAVE_Security_Normalizer {

	/**
	 * Convert an arbitrary scalar value into bounded, single-line plain text.
	 *
	 * HTML tags and ASCII control characters are removed, whitespace is
	 * collapsed, and the result is truncated to the requested storage limit.
	 * This method does not redact credentials or personal data; use
	 * WPHAVE_Security_Redactor when the text may contain secrets.
	 *
	 * @param mixed $value Untrusted value to normalize.
	 * @param int   $max_length Maximum number of bytes to retain.
	 * @return string Normalized plain text.
	 */

	public static function plain_text( $value, $max_length = 240 ) {
		$value = wp_strip_all_tags( (string) $value );
		$value = preg_replace( '/[\x00-\x1F\x7F]+/u', ' ', (string) $value );
		$value = preg_replace( '/\s+/u', ' ', (string) $value );

		return trim( substr( (string) $value, 0, max( 0, (int) $max_length ) ) );
	}

	/**
	 * Decode URL-encoded input and normalize it as bounded plain text.
	 *
	 * Use this for labels or diagnostic fragments that may arrive in encoded
	 * request data. It intentionally does not preserve URL structure.
	 *
	 * @param mixed $value Untrusted, potentially URL-encoded value.
	 * @param int   $max_length Maximum number of bytes to retain.
	 * @return string Decoded and normalized diagnostic text.
	 */

	public static function diagnostic_text( $value, $max_length = 240 ) {
		return self::plain_text( rawurldecode( (string) $value ), $max_length );
	}

	/**
	 * Reduce a URL or request target to a bounded path without query data.
	 *
	 * The result always begins with `/`. Markup delimiters, quotes and
	 * backticks are removed before parsing. Use this for request grouping and
	 * display when query parameters are unnecessary.
	 *
	 * @param mixed $value URL, request target or path.
	 * @param int   $max_length Maximum number of bytes to retain.
	 * @return string Normalized request path, or `/` when parsing fails.
	 */

	public static function request_path( $value, $max_length = 300 ) {
		$value = self::diagnostic_text( $value, max( 600, (int) $max_length * 2 ) );
		$value = str_replace( array( '<', '>', '"', "'", '`' ), '', $value );
		$parts = wp_parse_url( $value );
		$path = is_array( $parts ) ? (string) ( $parts['path'] ?? '/' ) : '/';
		$path = '/' . ltrim( $path, '/' );

		return substr( $path ?: '/', 0, max( 1, (int) $max_length ) );
	}

	/**
	 * Create a storage-safe diagnostic URL projection.
	 *
	 * Scheme, host, user information and fragment are discarded. Query values
	 * are retained only for the explicit low-risk allowlist; all other values
	 * become `[redacted]`. This is intended for diagnostics, not navigation or
	 * later HTTP requests.
	 *
	 * @param mixed $value Untrusted URL or request target.
	 * @param int   $max_length Maximum number of bytes to retain.
	 * @return string Path and redacted query, or an empty string if invalid.
	 */

	public static function diagnostic_url( $value, $max_length = 500 ) {
		$value = self::diagnostic_text( $value, $max_length );
		$value = str_replace( array( '<', '>', '"', "'", '`' ), '', $value );
		$parts = wp_parse_url( $value );

		if ( ! is_array( $parts ) ) {
			return '';
		}

		$path = self::request_path( $value, 300 );
		$query = array();
		parse_str( (string) ( $parts['query'] ?? '' ), $query );
		$safe_values = array( 'action', 'page', 'post', 'postId', 'postType', 'rest_route', 'screen' );

		foreach ( $query as $key => $query_value ) {
			if ( ! in_array( $key, $safe_values, true ) || is_array( $query_value ) ) {
				$query[ $key ] = '[redacted]';
				continue;
			}

			$query[ $key ] = self::plain_text( $query_value, 80 );
		}

		return substr( $path . ( $query ? '?' . http_build_query( $query ) : '' ), 0, $max_length );
	}

	/**
	 * Reduce a SQL statement to a bounded structural shape.
	 *
	 * Quoted string literals, hexadecimal values and numeric literals are
	 * replaced with `?`, then whitespace is collapsed. The result supports
	 * grouping and performance analysis without persisting query values. It is
	 * not a SQL parser and must never be used to validate or execute SQL.
	 *
	 * @param mixed $query SQL text captured for diagnostics.
	 * @param int   $max_length Maximum number of bytes to retain.
	 * @return string Redacted SQL shape.
	 */

	public static function sql_shape( $query, $max_length = 500 ) {
		$query = (string) $query;
		$query = preg_replace( '~\'(?:\\\\.|\'\'|[^\'\\\\])*\'|"(?:\\\\.|""|[^"\\\\])*"~s', '?', $query );
		$query = preg_replace( '/\b(?:0x[0-9a-f]+|\d+(?:\.\d+)?)\b/i', '?', (string) $query );
		$query = preg_replace( '/\s+/u', ' ', (string) $query );
		$query = wp_strip_all_tags( (string) $query );

		return trim( substr( (string) $query, 0, max( 0, (int) $max_length ) ) );
	}
}
