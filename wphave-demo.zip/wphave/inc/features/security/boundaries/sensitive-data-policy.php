<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Central policy for names that identify credentials or private request data.
 */

final class WPHAVE_Sensitive_Data_Policy {

	private const KEY_FRAGMENTS = array(
		'password',
		'passwd',
		'passphrase',
		'secret',
		'token',
		'nonce',
		'cookie',
		'authorization',
		'api_key',
		'apikey',
		'client_secret',
		'private_key',
		'credential',
		'license',
		'request_body',
	);

	/**
	 * Determine whether a field name conventionally identifies private data.
	 *
	 * Separators and case are normalized before matching known fragments, so
	 * names such as `client-secret`, `api.key` and `request body` are covered.
	 * Matching is deliberately conservative: callers should omit the complete
	 * value instead of attempting to partially redact a sensitive field.
	 *
	 * @param string $key Field, header or payload key.
	 * @return bool True when the value must not be retained in diagnostics.
	 */

	public static function is_sensitive_key( string $key ): bool {
		// SECURITY INVARIANT: A matching key classifies the complete associated value
		// as non-retainable; callers must omit it rather than attempt partial masking.
		$key = strtolower( str_replace( array( '-', '.', ' ' ), '_', $key ) );

		foreach ( self::KEY_FRAGMENTS as $fragment ) {
			if ( str_contains( $key, $fragment ) ) {
				return true;
			}
		}

		return false;
	}
}
