<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Security boundary for values leaving WPHAVE as spreadsheet-readable CSV.
 */
final class WPHAVE_Security_CSV {

	/**
	 * Neutralize a scalar value that spreadsheet software could execute as a formula.
	 *
	 * @param mixed $value Exported value.
	 * @return string Formula-safe cell value.
	 */
	public static function cell( $value ): string {
		$value = is_scalar( $value ) ? (string) $value : (string) wp_json_encode( $value );

		// SECURITY INVARIANT: Stored data is inert when exported. Formula markers
		// remain dangerous after spreadsheet-recognized control/space prefixes, so
		// inspection must cover the complete prefix rather than only the first byte.
		if ( preg_match( '/^(?:[\x00-\x20]|\x{00A0}|\x{FEFF})*[=+\-@]/u', $value ) ) {
			return "'" . $value;
		}

		return $value;
	}
}
