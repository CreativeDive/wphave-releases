<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Removes common credential and personal-data shapes from diagnostic text.
 */

final class WPHAVE_Security_Redactor {

	/**
	 * Remove common credential formats from diagnostic text.
	 *
	 * Covers private-key blocks, Authorization values, named credential
	 * assignments, common provider key formats, JWTs and URL user information.
	 * The final value is normalized as bounded plain text.
	 *
	 * @param mixed $text Diagnostic text that may contain credentials.
	 * @param int   $max_length Maximum number of bytes to retain.
	 * @return string Credential-redacted plain text.
	 */

	public static function credential_text( $text, $max_length = 500 ) {
		$text = (string) $text;
		// SECURITY INVARIANT: Credential-shaped substrings are removed before plain-
		// text normalization and truncation can make a diagnostic value publishable.
		$text = preg_replace( '/-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----/i', '[redacted-private-key]', $text );
		$text = preg_replace( '/\bBearer\s+[A-Za-z0-9._~+\/-]{8,}=*|\bBasic\s+[A-Za-z0-9+\/]{8,}={0,2}/i', '[authorization redacted]', $text );
		$text = preg_replace( '/\b(password|passwd|passphrase|token|secret|api[_-]?key|client[_-]?secret|authorization)\s*[=:]\s*["\']?[^\s,"\';]+/i', '$1=[redacted]', $text );
		$text = preg_replace( '/\b(?:sk|pk)_(?:live|test)_[A-Za-z0-9]{12,}\b|\bgh[opusr]_[A-Za-z0-9]{20,}\b|\bAIza[A-Za-z0-9_-]{20,}\b/', '[redacted-key]', $text );
		$text = preg_replace( '/\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/', '[redacted-token]', $text );
		$text = preg_replace( '#(https?://)[^/@\s:]+:[^/@\s]+@#i', '$1[redacted]@', $text );

		return WPHAVE_Security_Normalizer::plain_text( $text, $max_length );
	}

	/**
	 * Remove credentials and common personal or infrastructure identifiers.
	 *
	 * In addition to credential_text(), this redacts URL query strings, email
	 * addresses, common absolute filesystem paths and caller-supplied private
	 * roots. Pass feature-specific storage roots when they are not represented
	 * by WordPress constants.
	 *
	 * @param mixed $text Diagnostic text to redact.
	 * @param int   $max_length Maximum number of bytes to retain.
	 * @param array $private_roots Absolute path prefixes to replace with `[site]/`.
	 * @return string Redacted and bounded diagnostic text.
	 */

	public static function diagnostic_text( $text, $max_length = 500, array $private_roots = array() ) {
		// SECURITY INVARIANT: Broader diagnostic redaction strictly extends credential
		// redaction; paths, query data and identities are never handled as a substitute.
		$text = self::credential_text( $text, max( 1000, (int) $max_length * 2 ) );

		foreach ( array_filter( $private_roots ) as $root ) {
			$text = str_replace( wp_normalize_path( $root ), '[site]/', wp_normalize_path( $text ) );
		}

		$text = preg_replace( '#https?://([^\s?]+)\?[^\s]+#i', 'https://$1?[redacted]', $text );
		$text = preg_replace( '/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i', '[redacted-email]', $text );
		$text = preg_replace( '#(?<![a-zA-Z0-9])/(?:Users|home|var|private|srv|opt)/[^\s,:;]+#', '[path]', $text );

		return WPHAVE_Security_Normalizer::plain_text( $text, $max_length );
	}

	/**
	 * Normalize an exception, remote-service or runtime error for persistence.
	 *
	 * This is the default write-boundary API for durable errors. It applies
	 * diagnostic_text() with ABSPATH, WP_CONTENT_DIR and WP_PLUGIN_DIR as known
	 * private roots when those constants are available.
	 *
	 * @param mixed $text Exception, WP_Error or runtime error message text.
	 * @param int   $max_length Maximum number of bytes to retain.
	 * @return string Storage-safe error text.
	 */

	public static function error_text( $text, $max_length = 500 ) {
		$private_roots = array();

		foreach ( array( 'ABSPATH', 'WP_CONTENT_DIR', 'WP_PLUGIN_DIR' ) as $constant ) {
			if ( defined( $constant ) ) {
				$private_roots[] = constant( $constant );
			}
		}

		return self::diagnostic_text( $text, $max_length, $private_roots );
	}
}
