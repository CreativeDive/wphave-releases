<?php

if (!defined('ABSPATH')) {
	exit();
}

final class WPHAVE_Serialization_Budget {
	public const MAX_BYTES = 16777216;
	public const MAX_DEPTH = 33;
}

/**
 * Decode a WordPress-serialized scalar or array without instantiating classes.
 *
 * SECURITY INVARIANT: Persisted values are data, never PHP object graphs.
 * Every delayed/background reader must keep class construction disabled so a
 * value stored in a less privileged context cannot execute magic methods when
 * an administrator, backup job, diagnostic screen or cron task reads it later.
 *
 * @param mixed $value Potentially serialized value.
 * @return mixed Decoded value, or the original value when it is not serialized.
 */

function wphave_maybe_unserialize_without_classes($value) {
	if (!is_string($value) || !is_serialized($value)) {
		return $value;
	}

	// DESERIALIZATION INVARIANT: Delayed readers must not materialize an
	// unbounded serialized graph.
	// Returning the original string makes their array checks fail closed.
	if (strlen($value) > WPHAVE_Serialization_Budget::MAX_BYTES) {
		return $value;
	}

	$decoded = @unserialize(
		trim($value),
		[
			'allowed_classes' => false,
			'max_depth' => WPHAVE_Serialization_Budget::MAX_DEPTH,
		],
	);
	return false === $decoded && 'b:0;' !== trim($value) ? $value : $decoded;
}
