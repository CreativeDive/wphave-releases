<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'wphave_maybe_unserialize_without_classes' ) ) :

	/**
	 * Decode a WordPress-serialized scalar or array without instantiating classes.
	 *
	 * SECURITY INVARIANT: Persisted values are data, never PHP object graphs.
	 * Every delayed/background reader must keep class construction disabled so a
	 * value stored in a less privileged context cannot execute magic methods when
	 * an administrator, backup job, diagnostic screen or cron task reads it later.
	 *
	 * @param mixed $value Potentially serialized value.
	 * @return mixed Decoded value, or the original value when it is not serialized.
	 */
	function wphave_maybe_unserialize_without_classes( $value ) {
		if ( ! is_string( $value ) || ! is_serialized( $value ) ) {
			return $value;
		}

		return @unserialize( trim( $value ), array( 'allowed_classes' => false ) );
	}

endif;
