<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/sensitive-data-policy.php';
require_once __DIR__ . '/normalizer.php';
require_once __DIR__ . '/redactor.php';
require_once __DIR__ . '/serialization.php';
require_once __DIR__ . '/csv.php';
