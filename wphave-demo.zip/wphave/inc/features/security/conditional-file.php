<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WPHAVE_Security_Conditional_File' ) ) :

	/**
	 * Mutates a file only when the exact node moved from its path has expected bytes.
	 */
	final class WPHAVE_Security_Conditional_File {

		/**
		 * Replaces an expected target with checksum-bound source bytes.
		 */
		public static function replace_if_matches( string $target, string $target_checksum, string $source, string $source_checksum, string $error_message, int $permissions = 0600 ): void {
			$quarantine = self::quarantine( $target, $target_checksum, $error_message );

			try {
				WPHAVE_Security_Atomic_File::copy_verified( $source, $target, $source_checksum, $error_message, $permissions );
			} catch ( Throwable $error ) {
				self::restore_quarantine( $target, $quarantine, $error_message, $error );
			}

			if ( ! unlink( $quarantine ) ) {
				throw new RuntimeException( $error_message );
			}
		}

		/**
		 * Publishes new literal contents only while the destination remains absent.
		 */
		public static function write_new( string $target, string $contents, string $error_message, int $permissions = 0600 ): string {
			WPHAVE_Security_Atomic_File::write_new( $target, $contents, $error_message, $permissions );

			return hash( 'sha256', $contents );
		}

		/**
		 * Replaces an expected target with exact literal contents.
		 */
		public static function write_if_matches( string $target, string $target_checksum, string $contents, string $error_message, int $permissions = 0600 ): string {
			$source = $target . '.wphave-content-' . wp_generate_uuid4();
			$source_checksum = hash( 'sha256', $contents );

			try {
				WPHAVE_Security_Atomic_File::write_new( $source, $contents, $error_message, $permissions );
				self::replace_if_matches(
					$target,
					$target_checksum,
					$source,
					$source_checksum,
					$error_message,
					$permissions
				);
			} finally {
				if ( file_exists( $source ) || is_link( $source ) ) {
					// SECURITY INVARIANT: The random content source is created exclusively by
					// this invocation and never grants cleanup authority over the stable target.
					self::remove_if_matches( $source, $source_checksum, $error_message );
				}
			}

			return $source_checksum;
		}

		/**
		 * Removes an expected target without unlinking a later replacement node.
		 */
		public static function remove_if_matches( string $target, string $target_checksum, string $error_message ): void {
			if ( ! file_exists( $target ) && ! is_link( $target ) ) {
				return;
			}

			$quarantine = self::quarantine( $target, $target_checksum, $error_message );
			if ( ! unlink( $quarantine ) ) {
				self::restore_quarantine( $target, $quarantine, $error_message );
			}
		}

		/**
		 * Relocates exact source bytes to a destination that must remain absent.
		 */
		public static function relocate_if_matches_to_new( string $source, string $source_checksum, string $destination, string $error_message ): void {
			$source_checksum = strtolower( $source_checksum );
			$published = false;

			try {
				WPHAVE_Security_Atomic_File::copy_verified_new(
					$source,
					$destination,
					$source_checksum,
					$error_message
				);
				$published = true;
				self::remove_if_matches( $source, $source_checksum, $error_message );
			} catch ( Throwable $error ) {
				if ( $published ) {
					try {
						// SECURITY INVARIANT: Failed relocation rollback removes only the
						// checksum-owned destination published by this invocation. A later
						// replacement at either pathname is preserved.
						self::remove_if_matches( $destination, $source_checksum, $error_message );
					} catch ( Throwable $rollback_error ) {
						throw new RuntimeException( $error_message, 0, $rollback_error );
					}
				}

				throw new RuntimeException( $error_message, 0, $error );
			}
		}

		/**
		 * Moves the exact target node aside before granting mutation authority.
		 */
		private static function quarantine( string $target, string $expected_checksum, string $error_message ): string {
			$expected_checksum = strtolower( $expected_checksum );
			$quarantine = $target . '.wphave-quarantine-' . wp_generate_uuid4();

			if (
				1 !== preg_match( '/^[a-f0-9]{64}$/', $expected_checksum )
				|| is_link( $target )
				|| ! is_file( $target )
				|| file_exists( $quarantine )
				|| is_link( $quarantine )
				|| ! rename( $target, $quarantine )
			) {
				throw new RuntimeException( $error_message );
			}

			try {
				$identity = WPHAVE_Security_File_Identity::inspect( $quarantine, $error_message );
			} catch ( Throwable $error ) {
				self::restore_quarantine( $target, $quarantine, $error_message, $error );
			}

			// SECURITY INVARIANT: Authorization applies to the exact node atomically
			// removed from the target path, not to an earlier path observation.
			if ( ! hash_equals( $expected_checksum, $identity['checksum'] ) ) {
				self::restore_quarantine( $target, $quarantine, $error_message );
			}

			return $quarantine;
		}

		/**
		 * Restores rejected or interrupted quarantine when the target remains free.
		 */
		private static function restore_quarantine( string $target, string $quarantine, string $error_message, ?Throwable $previous = null ): void {
			if ( file_exists( $target ) || is_link( $target ) || ! is_file( $quarantine ) || ! rename( $quarantine, $target ) ) {
				throw new RuntimeException( $error_message, 0, $previous );
			}

			throw new RuntimeException( $error_message, 0, $previous );
		}
	}

endif;
