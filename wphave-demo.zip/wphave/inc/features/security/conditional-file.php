<?php

if (!defined('ABSPATH')) {
	exit();
}

if (!class_exists('WPHAVE_Security_Conditional_File')):
	/**
	 * Mutates a file only when the exact node moved from its path has expected bytes.
	 */

	final class WPHAVE_Security_Conditional_File {
		/**
		 * Replaces an expected target with checksum-bound source bytes.
		 *
		 * Normal return always means publication committed. The boolean reports
		 * quarantine cleanup only: false retains the old node for later cleanup.
		 * Callers must record the committed mutation even when cleanup is pending.
		 * @return bool Whether post-commit quarantine cleanup completed.
		 */

		public static function replace_if_matches(
			string $target,
			string $target_checksum,
			string $source,
			string $source_checksum,
			string $error_message,
			int $permissions = 0600,
			?int $group = null,
		): bool {
			$quarantine = self::quarantine($target, $target_checksum, $error_message);

			try {
				// SECURITY INVARIANT: Quarantine leaves a free path, not a lease on it.
				// A concurrent creator must survive the publication boundary.
				WPHAVE_Security_Atomic_File::copy_verified_new(
					$source,
					$target,
					$source_checksum,
					$error_message,
					$permissions,
					$group,
				);
			} catch (Throwable $error) {
				self::restore_quarantine($target, $quarantine, $error_message, $error);
			}

			// COMMIT INVARIANT: Published bytes are already live. Cleanup failure
			// must never masquerade as rejected publication or suppress mutation tracking.
			// RECOVERY INVARIANT: Retain the old quarantine on failure; do not undo
			// a committed write or touch the live path just to clean an obsolete node.
			try {
				return @unlink($quarantine);
			} catch (Throwable $cleanup_error) {
				return false;
			}
		}

		/**
		 * Publishes new literal contents only while the destination remains absent.
		 */

		public static function write_new(
			string $target,
			string $contents,
			string $error_message,
			int $permissions = 0600,
		): string {
			WPHAVE_Security_Atomic_File::write_new(
				$target,
				$contents,
				$error_message,
				$permissions,
			);

			return hash('sha256', $contents);
		}

		/**
		 * Replaces an expected target with exact literal contents.
		 */

		public static function write_if_matches(
			string $target,
			string $target_checksum,
			string $contents,
			string $error_message,
			int $permissions = 0600,
		): string {
			$source = $target . '.wphave-content-' . wp_generate_uuid4();
			$source_checksum = hash('sha256', $contents);

			try {
				WPHAVE_Security_Atomic_File::write_new(
					$source,
					$contents,
					$error_message,
					$permissions,
				);

				self::replace_if_matches(
					$target,
					$target_checksum,
					$source,
					$source_checksum,
					$error_message,
					$permissions,
				);
			} finally {
				if (file_exists($source) || is_link($source)) {
					// SECURITY INVARIANT: The random content source is created exclusively by
					// this invocation and never grants cleanup authority over the stable target.
					try {
						// COMMIT INVARIANT: Content-staging cleanup never hides a committed
						// replacement or masks the primary publication error.
						self::remove_if_matches($source, $source_checksum, $error_message);
					} catch (Throwable $cleanup_error) {
						// Retain the checksum-owned staging file for later cleanup.
					}
				}
			}

			return $source_checksum;
		}

		/**
		 * Removes an expected target without unlinking a later replacement node.
		 */

		public static function remove_if_matches(
			string $target,
			string $target_checksum,
			string $error_message,
		): void {
			if (!file_exists($target) && !is_link($target)) {
				return;
			}

			$quarantine = self::quarantine($target, $target_checksum, $error_message);
			$removed = false;
			$failure = null;
			try {
				$removed = @unlink($quarantine);
			} catch (Throwable $error) {
				$failure = $error;
			}
			// RECOVERY INVARIANT: Both rejected and thrown deletion failures must
			// restore through the create-only recovery boundary. Never leave a live
			// path absent merely because unlink threw instead of returning false.
			if (!$removed) {
				self::restore_quarantine($target, $quarantine, $error_message, $failure);
			}
		}

		/**
		 * Relocates exact source bytes to a destination that must remain absent.
		 */

		public static function relocate_if_matches_to_new(
			string $source,
			string $source_checksum,
			string $destination,
			string $error_message,
			int $permissions = 0600,
			?int $group = null,
		): void {
			$source_checksum = strtolower($source_checksum);
			$published = false;

			try {
				WPHAVE_Security_Atomic_File::copy_verified_new(
					$source,
					$destination,
					$source_checksum,
					$error_message,
					$permissions,
					$group,
				);

				$published = true;

				self::remove_if_matches($source, $source_checksum, $error_message);
			} catch (Throwable $error) {
				if ($published) {
					try {
						// SECURITY INVARIANT: Failed relocation rollback removes only the
						// checksum-owned destination published by this invocation. A later
						// replacement at either pathname is preserved.
						self::remove_if_matches($destination, $source_checksum, $error_message);
					} catch (Throwable $rollback_error) {
						throw new RuntimeException($error_message, 0, $rollback_error);
					}
				}

				throw new RuntimeException($error_message, 0, $error);
			}
		}

		/**
		 * Moves the exact target node aside before granting mutation authority.
		 */

		private static function quarantine(
			string $target,
			string $expected_checksum,
			string $error_message,
		): string {
			$expected_checksum = strtolower($expected_checksum);
			$quarantine = $target . '.wphave-quarantine-' . wp_generate_uuid4();

			if (
				// PORTABILITY INVARIANT: A known unavailable recovery primitive must
				// be rejected before the live inode is moved out of its path.
				!function_exists('link') ||
				1 !== preg_match('/^[a-f0-9]{64}$/', $expected_checksum) ||
				is_link($target) ||
				!is_file($target) ||
				file_exists($quarantine) ||
				is_link($quarantine) ||
				!rename($target, $quarantine)
			) {
				throw new RuntimeException($error_message);
			}

			try {
				$identity = WPHAVE_Security_File_Identity::inspect($quarantine, $error_message);
			} catch (Throwable $error) {
				self::restore_quarantine($target, $quarantine, $error_message, $error);
			}

			// SECURITY INVARIANT: Authorization applies to the exact node atomically
			// removed from the target path, not to an earlier path observation.
			if (!hash_equals($expected_checksum, $identity['checksum'])) {
				self::restore_quarantine($target, $quarantine, $error_message);
			}

			return $quarantine;
		}

		/**
		 * Restores rejected or interrupted quarantine when the target remains free.
		 */

		private static function restore_quarantine(
			string $target,
			string $quarantine,
			string $error_message,
			?Throwable $previous = null,
		): void {
			self::restore_to_new($quarantine, $target);
			// The requested mutation remains rejected even when recovery succeeds.
			throw new RuntimeException($error_message, 0, $previous);
		}

		/**
		 * Restore a caller-owned staged regular inode only into an absent path.
		 * True means restoration committed; a leftover staging alias is non-fatal.
		 * Callers authorize both paths and retain their recovery record on false.
		 */
		public static function restore_to_new(string $staged, string $target): bool {
			try {
				// RECOVERY/CONCURRENCY INVARIANT: Link creation is the absence check.
				// Never substitute check-then-rename, including in font rollback callers.
				if (
					is_link($staged) ||
					!is_file($staged) ||
					!function_exists('link') ||
					!@link($staged, $target)
				) {
					return false;
				}
			} catch (Throwable $error) {
				return false;
			}
			try {
				// COMMIT INVARIANT: After successful restoration, failed alias cleanup
				// cannot revoke it or remove the new live path. Preserve both names.
				@unlink($staged);
			} catch (Throwable $cleanup_error) {
			}
			return true;
		}
	}
endif;
