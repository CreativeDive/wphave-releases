<?php

/** Bounded, exact identities for bulk operations crossing a REST boundary. */

if (!defined('ABSPATH')) {
	exit();
}

final class WPHAVE_Exact_ID_List {
	/**
	 * Return canonical positive IDs, or null if any supplied identity is invalid.
	 *
	 * IDENTITY/WORK INVARIANT: Check the raw batch size before normalization;
	 * deduplication must never turn an oversized request into an admitted batch.
	 * Numeric coercion must never change which object a caller targeted.
	 */
	public static function normalize($values, int $max, bool $allow_empty = false): ?array {
		if (!is_array($values) || count($values) > $max || (!$allow_empty && !$values)) {
			return null;
		}

		$ids = [];
		foreach ($values as $value) {
			$identity = is_int($value) || is_string($value) ? (string) $value : '';
			if (
				'' === $identity ||
				strlen($identity) > strlen((string) PHP_INT_MAX) ||
				1 !== preg_match('/^[1-9][0-9]*$/D', $identity) ||
				(string) (int) $value !== $identity
			) {
				return null;
			}
			$ids[] = (int) $value;
		}

		return array_values(array_unique($ids));
	}
}
