<?php

/**
 * Renders administrator-provided code snippets in the configured theme hooks.
 * The snippets are intentionally not escaped because the feature is designed
 * for trusted users who need to output complete script, style or markup tags.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WPHAVE_Custom_Code' ) ) :

	class WPHAVE_Custom_Code {

		/**
		 * Register the component hooks.
		 *
		 * @return void
		 */

		public static function init() {
			add_action( 'wp_head', [ __CLASS__, 'render_head' ] );
			add_action( 'wp_body_open', [ __CLASS__, 'render_body_open' ] );
			add_action( 'wp_footer', [ __CLASS__, 'render_footer' ], 999 );
		}

		/**
		 * Return the code.
		 *
		 * @param string $location
		 * @return string
		 */

		public static function get_code( $location ) {
			$paths = [
				'head' => [ 'code' => 'advanced.code.header', 'enabled' => 'advanced.code.headerEnabled' ],
				'body_open' => [ 'code' => 'advanced.code.bodyOpen', 'enabled' => 'advanced.code.bodyOpenEnabled' ],
				'footer' => [ 'code' => 'advanced.code.footer', 'enabled' => 'advanced.code.footerEnabled' ],
			];

			if( empty( $paths[ $location ] ) ) {
				return '';
			}

			if( ! wphave_data_get( 'site_settings', $paths[ $location ]['enabled'], true ) ) {
				return '';
			}

			return (string) wphave_data_get( 'site_settings', $paths[ $location ]['code'] );
		}

		/**
		 * Render the code.
		 *
		 * @param string $location
		 * @return void
		 */

		public static function render_code( $location ) {
			$code = self::get_code( $location );

			if( ! $code ) {
				return;
			}

			// SECURITY INVARIANT: This deliberately unescaped value comes only from the
			// centrally protected advanced.code paths requiring wphave_manage_custom_code.
			echo $code;
		}

		/**
		 * Render the head.
		 *
		 * @return void
		 */

		public static function render_head() {
			self::render_code( 'head' );
		}

		/**
		 * Render the body open.
		 *
		 * @return void
		 */

		public static function render_body_open() {
			self::render_code( 'body_open' );
		}

		/**
		 * Render the footer.
		 *
		 * @return void
		 */

		public static function render_footer() {
			self::render_code( 'footer' );
		}

	}

endif;

WPHAVE_Custom_Code::init();
