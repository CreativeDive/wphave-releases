<?php

/**
 * Bootstrap the font providers and their public facade.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once wphave_dir() . 'inc/features/security/atomic-file.php';
require_once wphave_dir() . 'inc/features/security/file-identity.php';
require_once wphave_dir() . 'inc/features/security/conditional-file.php';
require_once __DIR__ . '/identity.php';
require_once __DIR__ . '/security/file-security.php';
require_once __DIR__ . '/normalizer.php';
require_once __DIR__ . '/assignments.php';
require_once __DIR__ . '/google/catalog.php';
require_once __DIR__ . '/google/query.php';
require_once __DIR__ . '/google/loader.php';
require_once __DIR__ . '/google/license.php';
require_once __DIR__ . '/google/installer.php';
require_once __DIR__ . '/local/repository.php';
require_once __DIR__ . '/local/fonts.php';
require_once __DIR__ . '/local/library.php';
require_once __DIR__ . '/local/integrity.php';
require_once __DIR__ . '/local/mutations.php';
require_once __DIR__ . '/local/composition.php';
require_once __DIR__ . '/local/css.php';
require_once __DIR__ . '/resolver.php';
require_once __DIR__ . '/preloader.php';
require_once __DIR__ . '/block-usage.php';

if ( ! class_exists( 'WPHAVE_Fonts' ) ) :

	/**
	 * Public facade and WordPress hook bootstrap for the font system.
	 *
	 * The provider-specific work is intentionally split into resolver, query,
	 * loader, installer, local repository/service and CSS generator classes.
	 *
	 * This facade keeps the existing WPHAVE_Fonts API stable for the rest of the
	 * plugin while making the implementation easier to maintain.
	 */

	class WPHAVE_Fonts {

		/**
		 * Register WordPress hooks owned by the font service.
		 *
		 * @return void
		 */

		public static function init() {
			add_action( 'template_redirect', array( 'WPHAVE_Block_Font_Usage', 'register_output' ), -1 );
			add_filter( 'render_block', array( 'WPHAVE_Block_Font_Usage', 'render' ), 20, 2 );
			add_action( 'enqueue_block_assets', array( 'WPHAVE_Google_Font_Loader', 'enqueue' ) );
			add_action( 'enqueue_block_assets', array( 'WPHAVE_Google_Font_Loader', 'enqueue_async' ) );
			add_action( 'enqueue_block_assets', array( __CLASS__, 'enqueue_adobe_fonts' ) );
			add_action( 'wp_head', array( 'WPHAVE_Font_Preloader', 'render' ), 2 );
		}

		/**
		 * Return the browser/system fonts that are always available as fallbacks.
		 *
		 * @return array
		 */

		public static function web_safe_fonts() {
			return array(
				'Arial',
				'Arial Black',
				'Comic Sans MS',
				'Courier New',
				'Georgia',
				'Impact',
				'Times New Roman',
				'Trebuchet MS',
				'Verdana',
			);
		}

		/**
		 * Return the configured font loading mode.
		 *
		 * @return string
		 */

		public static function loading_mode() {
			$mode = wphave_data_get( 'site_settings', 'fonts.loading', 'local' ) ?: 'local';
			$modes = array( 'mixed', 'local', 'disabled' );

			// PRIVACY INVARIANT: Unknown or damaged settings never enable third-party requests. Keep
			// the invalid-state fallback aligned with the privacy-safe default.
			return in_array( $mode, $modes, true ) ? $mode : 'local';
		}

		/**
		 * Return the configured CSS font-display strategy.
		 *
		 * @return string
		 */

		public static function font_display() {
			$display = wphave_data_get( 'site_settings', 'fonts.display', 'swap' ) ?: 'swap';
			$displays = array( 'auto', 'block', 'swap', 'fallback', 'optional' );

			return in_array( $display, $displays, true ) ? $display : 'swap';
		}

		/** Return whether WPHAVE may preload high-priority local font files. */

		public static function font_preloading() {
			$preloading = wphave_data_get( 'site_settings', 'fonts.preloading', 'automatic' ) ?: 'automatic';

			return in_array( $preloading, array( 'automatic', 'disabled' ), true ) ? $preloading : 'automatic';
		}

		/** Normalize the CSS Fonts Level 4 weight grammar used by uploads and CSS. */

		public static function font_weight( $weight, $fallback = '' ) {
			$weight = trim( sanitize_text_field( $weight ) );
			if( in_array( $weight, array( 'normal', 'bold' ), true ) ) return $weight;
			$values = preg_split( '/\s+/', $weight );
			if( count( $values ) < 1 || count( $values ) > 2 ) return $fallback;
			foreach( $values as $value ) {
				if( ! ctype_digit( $value ) || (int) $value < 1 || (int) $value > 1000 ) return $fallback;
			}
			if( count( $values ) === 2 && (int) $values[0] > (int) $values[1] ) return $fallback;

			return implode( ' ', $values );
		}

		/**
		 * Prevent new external typography assignments while the site-wide loading
		 * policy forbids them. Existing assignments remain editable and preserved so
		 * switching to local-only never makes an unrelated global-style save fail.
		 */

		public static function validate_site_globals_for_write( $data, $config = array() ) {
			$current = WPHAVE_Data_Resources::get( 'site_globals', false );
			$current_typography = is_array( $current['typography'] ?? null ) ? $current['typography'] : array();

			foreach( is_array( $data['typography'] ?? null ) ? $data['typography'] : array() as $role => $settings ) {
				$family = $settings['family'] ?? array();
				$type = $family['type'] ?? '';
				if( ! in_array( $type, array( 'google-fonts', 'adobe-fonts' ), true ) ) continue;

				$current_family = $current_typography[$role]['family'] ?? array();
				if( ( $current_family['type'] ?? '' ) === $type && ( $current_family['name'] ?? '' ) === ( $family['name'] ?? '' ) ) continue;
				if( self::loading_mode() === 'mixed' ) {
					$configured = $type === 'google-fonts' ? self::custom_google_fonts() : wphave_data_get( 'site_settings', 'fonts.external.adobe.fonts', array() );
					foreach( is_array( $configured ) ? $configured : array() as $font ) {
						if( WPHAVE_Font_Identity::key( $font['family'] ?? '' ) === WPHAVE_Font_Identity::key( $family['name'] ?? '' ) ) continue 2;
					}
					return new WP_Error( 'external_font_not_configured', __( 'Configure this external font before assigning it to global typography.', 'wphave' ), array( 'status' => 409 ) );
				}

				return new WP_Error( 'external_font_loading_disabled', __( 'Enable external font loading before assigning a Google or Adobe font.', 'wphave' ), array( 'status' => 409 ) );
			}

			return true;
		}

		/** Validate local activation intent before the settings document is persisted. */

		public static function validate_site_settings_for_write( $data ) {
			$fonts = $data['fonts'] ?? array();
			if( ! is_array( $fonts ) ) return new WP_Error( 'invalid_font_settings', __( 'Font settings must be a structured object.', 'wphave' ), array( 'status' => 400 ) );
			if( ! in_array( $fonts['loading'] ?? 'local', array( 'mixed', 'local', 'disabled' ), true ) ) return new WP_Error( 'invalid_font_loading_mode', __( 'The selected font loading mode is invalid.', 'wphave' ), array( 'status' => 400 ) );
			if( ! in_array( $fonts['display'] ?? 'swap', array( 'auto', 'block', 'swap', 'fallback', 'optional' ), true ) ) return new WP_Error( 'invalid_font_display', __( 'The selected font display strategy is invalid.', 'wphave' ), array( 'status' => 400 ) );
			if( ! in_array( $fonts['preloading'] ?? 'automatic', array( 'automatic', 'disabled' ), true ) ) return new WP_Error( 'invalid_font_preloading', __( 'The selected font preloading preference is invalid.', 'wphave' ), array( 'status' => 400 ) );
			$active = $fonts['local']['active'] ?? array();
			if( ! is_array( $active ) || count( $active ) > 200 ) return new WP_Error( 'invalid_local_font_activations', __( 'Local font activations must be a bounded list.', 'wphave' ), array( 'status' => 400 ) );
			foreach( $active as $family ) {
				if( ! is_string( $family ) || ! WPHAVE_Font_Identity::key( $family ) ) return new WP_Error( 'invalid_local_font_activation', __( 'Every local font activation must identify one font family.', 'wphave' ), array( 'status' => 400 ) );
			}
			$google = $fonts['external']['google']['fonts'] ?? array();
			$adobe = $fonts['external']['adobe']['fonts'] ?? array();
			if( ! is_array( $google ) || ! is_array( $adobe ) || count( $google ) > 200 || count( $adobe ) > 200 ) return new WP_Error( 'invalid_external_fonts', __( 'External fonts must be bounded lists.', 'wphave' ), array( 'status' => 400 ) );
			foreach( $google as $font ) {
				if( ! is_array( $font ) || ! is_array( $font['variants'] ?? array() ) ) return new WP_Error( 'invalid_google_font', __( 'A configured Google Font is invalid.', 'wphave' ), array( 'status' => 400 ) );
				$family = is_string( $font['family'] ?? null ) ? self::canonical_font_family( sanitize_text_field( $font['family'] ) ) : '';
				$variants = $font['variants'] ?? array();
				if( ! $family || ! preg_match( '/^[\p{L}\p{N} _.-]+$/u', $family ) || count( $variants ) > WPHAVE_Google_Font_Query::MAX_VARIANTS ) return new WP_Error( 'invalid_google_font', __( 'A configured Google Font is invalid.', 'wphave' ), array( 'status' => 400 ) );
				$catalog_variants = WPHAVE_Google_Font_Catalog::variants( $family );
				if( empty( $catalog_variants ) ) return new WP_Error( 'unknown_google_font', __( 'The selected Google Font is not part of the bundled catalogue.', 'wphave' ), array( 'status' => 400 ) );
				foreach( $variants as $variant ) {
					if( ! is_string( $variant ) || ! WPHAVE_Google_Font_Catalog::has_variant( $family, $variant ) ) return new WP_Error( 'invalid_google_font_variant', __( 'The selected variant is not available for this Google Font.', 'wphave' ), array( 'status' => 400 ) );
				}
			}
			$adobe_source = $fonts['external']['adobe']['source'] ?? '';
			if( ! is_string( $adobe_source ) || ( $adobe_source && ! self::adobe_fonts_url( $adobe_source ) ) ) return new WP_Error( 'invalid_adobe_font_source', __( 'The Adobe Fonts source URL is invalid.', 'wphave' ), array( 'status' => 400 ) );
			if( isset( $fonts['external']['google']['async'] ) && ! is_bool( $fonts['external']['google']['async'] ) ) return new WP_Error( 'invalid_google_font_loading', __( 'The Google Font loading preference is invalid.', 'wphave' ), array( 'status' => 400 ) );
			foreach( $adobe as $font ) {
				$family = is_array( $font ) && is_string( $font['family'] ?? null ) ? self::canonical_font_family( sanitize_text_field( $font['family'] ) ) : '';
				if( ! $family || ! preg_match( '/^[\p{L}\p{N} _.-]+$/u', $family ) ) return new WP_Error( 'invalid_adobe_font', __( 'A configured Adobe Font is invalid.', 'wphave' ), array( 'status' => 400 ) );
			}

			return true;
		}

		/** Canonicalize activation IDs without persisting provider or file metadata. */

		public static function prepare_site_settings_for_write( $data ) {
			if( ! is_array( $data['fonts'] ?? null ) ) return $data;
			$loading = $data['fonts']['loading'] ?? 'local';
			$display = $data['fonts']['display'] ?? 'swap';
			$preloading = $data['fonts']['preloading'] ?? 'automatic';
			$data['fonts']['loading'] = in_array( $loading, array( 'mixed', 'local', 'disabled' ), true ) ? $loading : 'local';
			$data['fonts']['display'] = in_array( $display, array( 'auto', 'block', 'swap', 'fallback', 'optional' ), true ) ? $display : 'swap';
			$data['fonts']['preloading'] = in_array( $preloading, array( 'automatic', 'disabled' ), true ) ? $preloading : 'automatic';
			if( isset( $data['fonts']['local']['active'] ) && is_array( $data['fonts']['local']['active'] ) ) $data['fonts']['local']['active'] = array_values( array_unique( array_filter( array_map( array( 'WPHAVE_Font_Identity', 'key' ), $data['fonts']['local']['active'] ) ) ) );
			if( isset( $data['fonts']['external']['google']['fonts'] ) && is_array( $data['fonts']['external']['google']['fonts'] ) ) {
				$data['fonts']['external']['google']['fonts'] = array_values( array_map( function( $font ) {
					$family = self::canonical_font_family( $font['family'] ?? '' );
					$variants = WPHAVE_Google_Font_Catalog::safe_variants( $family, array_map( 'sanitize_text_field', $font['variants'] ?? array() ) );
					return array( 'family' => $family, 'variants' => $variants, 'type' => 'google-fonts' );
				}, $data['fonts']['external']['google']['fonts'] ) );
			}
			if( isset( $data['fonts']['external']['google']['async'] ) ) $data['fonts']['external']['google']['async'] = (bool) $data['fonts']['external']['google']['async'];
			if( isset( $data['fonts']['external']['adobe']['source'] ) ) $data['fonts']['external']['adobe']['source'] = self::adobe_fonts_url( $data['fonts']['external']['adobe']['source'] );
			if( isset( $data['fonts']['external']['adobe']['fonts'] ) && is_array( $data['fonts']['external']['adobe']['fonts'] ) ) $data['fonts']['external']['adobe']['fonts'] = array_values( array_map( fn( $font ) => array( 'family' => self::canonical_font_family( $font['family'] ?? '' ), 'type' => 'adobe-fonts' ), $data['fonts']['external']['adobe']['fonts'] ) );

			return $data;
		}

		/**
		 * Determine whether the current authenticated user explicitly allowed an
		 * external provider for admin previews. This personal preference must never
		 * be used as authorization for visitor-facing frontend resources.
		 *
		 * @param string $provider Provider preference key.
		 * @return bool
		 */

		public static function allows_external_preview( $provider ) {
			if( ! is_user_logged_in() || ! class_exists( 'WPHAVE_User_Preferences_Manager' ) ) {
				return false;
			}

			$preferences = WPHAVE_User_Preferences_Manager::get_preferences();

			return ! empty( $preferences['ui']['externalConnections'][sanitize_key( $provider )] );
		}

		/**
		 * Normalize and validate an Adobe Fonts stylesheet URL.
		 *
		 * Adobe projects are external executable stylesheets. Restricting them to
		 * Adobe's HTTPS hosts prevents mixed content and arbitrary stylesheet URLs.
		 *
		 * @param mixed $url Candidate URL.
		 * @return string Empty when invalid.
		 */

		public static function adobe_fonts_url( $url ) {
			$url = esc_url_raw( trim( (string) $url ), array( 'https' ) );
			$parts = wp_parse_url( $url );
			$host = strtolower( $parts['host'] ?? '' );
			$path = $parts['path'] ?? '';

			$allowed_host = in_array( $host, array( 'use.typekit.net', 'use.typekit.com' ), true );
			$valid_css_path = (bool) preg_match( '#^/[a-z0-9._-]+(?:/[a-z0-9._-]+)?\.css$#i', $path );

			if( ( $parts['scheme'] ?? '' ) !== 'https' || ! $allowed_host || ! $valid_css_path ) {
				return '';
			}

			return $url;
		}

		/**
		 * Normalize a font-family value for CSS output.
		 *
		 * @param string $font Font-family value.
		 * @return string
		 */

		public static function normalize_font( $font ) {
			$families = array_map( 'trim', explode( ',', html_entity_decode( (string) $font ) ) );

			return implode( ', ', array_map( array( __CLASS__, 'css_font_family' ), $families ) );
		}

		/**
		 * Return the unquoted family identity used by registries and provider APIs.
		 *
		 * CSS serialization is intentionally kept in normalize_font(). Persisting its
		 * quotes as identity previously produced invalid Google family queries and
		 * made the same family compare differently across providers.
		 */

		public static function canonical_font_family( $font ) {
			return WPHAVE_Font_Identity::family( $font );
		}

		/** Serialize one canonical family name for a CSS font-family declaration. */

		public static function css_font_family( $font ) {
			return WPHAVE_Font_Identity::css( $font );
		}

		/**
		 * Return Google Fonts selected in site settings.
		 *
		 * @return array|false
		 */

		public static function custom_google_fonts() {
			$google_fonts = wphave_data_get( 'site_settings', 'fonts.external.google.fonts' );

			return is_array( $google_fonts ) && ! empty( $google_fonts ) ? $google_fonts : false;
		}

		/**
		 * Return the fonts that are currently effective for global loading.
		 *
		 * @return array
		 */

		public static function active_fonts() {
			return WPHAVE_Font_Resolver::active_fonts();
		}

		/**
		 * Build the editor font registry.
		 *
		 * @return array
		 */

		public static function registry() {
			return WPHAVE_Font_Resolver::registry();
		}

		/**
		 * Build the Google Fonts stylesheet URL for frontend/editor loading.
		 *
		 * @param array $args Optional loading/source arguments.
		 * @return string|void
		 */

		public static function google_webfonts_url( $args = array() ) {
			if( self::loading_mode() !== 'mixed' ) return '';
			if( ( $args['loading'] ?? '' ) === 'import' ) {
				$families = WPHAVE_Font_Assignments::google_query_fragments( WPHAVE_Font_Normalizer::registry( $args['fonts'] ?? array(), 'global-styles' ) );
				return esc_url_raw( WPHAVE_Google_Font_Query::css2_url( $families, self::font_display() ) );
			}

			return WPHAVE_Google_Font_Loader::url();
		}

		/**
		 * Build a Google Fonts URL from a direct array of font definitions.
		 *
		 * @param array $array Font definitions.
		 * @return string
		 */

		public static function google_fonts_url( $array ) {
			if( self::loading_mode() !== 'mixed' ) return '';

			return esc_url_raw( WPHAVE_Google_Font_Query::url( $array, self::font_display() ) );
		}

		/**
		 * Build @font-face CSS for active local fonts.
		 *
		 * @return string|void
		 */

		public static function local_fonts_css() {
			if( self::loading_mode() === 'disabled' ) return '';

			return WPHAVE_Local_Font_CSS::defaults() . WPHAVE_Local_Font_CSS::active();
		}

		/**
		 * Enqueue Adobe Fonts from the configured Typekit CSS URL.
		 *
		 * @return void
		 */

		public static function enqueue_adobe_fonts() {
			if( self::loading_mode() !== 'mixed' ) {
				return;
			}

			$assigned = array_filter( self::active_fonts(), fn( $font ) => ( $font['type'] ?? '' ) === 'adobe-fonts' && ! empty( $font['loadable'] ) );
			if( ! $assigned ) {
				return;
			}

			$font_url = self::adobe_fonts_url( wphave_data_get( 'site_settings', 'fonts.external.adobe.source' ) );

			if( ! $font_url ) {
				return;
			}

			wp_enqueue_style( 'wphave-adobe-fonts', esc_url_raw( $font_url ), array(), null, 'all' );
		}

	}

endif;

WPHAVE_Fonts::init();

require_once __DIR__ . '/google/presets.php';
