<?php

// OWNERSHIP INVARIANT: This immutable manifest is the single source of truth for WPHAVE's bundled
// typography. Runtime CSS, the editor registry and release audits must all use
// these exact families, variants and subsets so they cannot drift apart.

return array(
	array(
		'family' => 'Poppins',
		'roles' => array( 'text' ),
		'variants' => array(
			array( 'file' => 'poppins-400-latin.woff2', 'fontStyle' => 'normal', 'fontWeight' => '400', 'subset' => 'latin', 'unicodeRange' => 'U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD' ),
			array( 'file' => 'poppins-400-latin-ext.woff2', 'fontStyle' => 'normal', 'fontWeight' => '400', 'subset' => 'latin-ext', 'unicodeRange' => 'U+0100-02BA,U+02BD-02C5,U+02C7-02CC,U+02CE-02D7,U+02DD-02FF,U+0304,U+0308,U+0329,U+1D00-1DBF,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF' ),
		),
	),
	array(
		'family' => 'Inter',
		'roles' => array( 'headings' ),
		'variants' => array(
			array( 'file' => 'inter-400-600-latin.woff2', 'fontStyle' => 'normal', 'fontWeight' => '400 600', 'subset' => 'latin', 'unicodeRange' => 'U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD' ),
			array( 'file' => 'inter-800-latin.woff2', 'fontStyle' => 'normal', 'fontWeight' => '800', 'subset' => 'latin', 'unicodeRange' => 'U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD' ),
			array( 'file' => 'inter-800-latin-ext.woff2', 'fontStyle' => 'normal', 'fontWeight' => '800', 'subset' => 'latin-ext', 'unicodeRange' => 'U+0100-02BA,U+02BD-02C5,U+02C7-02CC,U+02CE-02D7,U+02DD-02FF,U+0304,U+0308,U+0329,U+1D00-1DBF,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF' ),
		),
	),
);
