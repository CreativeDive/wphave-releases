/**
 * Load the canonical Google Fonts stylesheet without another script dependency.
 */

( function () {
	var urls = WP_JS_Var_GOOGLE_FONTS && WP_JS_Var_GOOGLE_FONTS.urls;
	if ( ! Array.isArray( urls ) ) return;
	urls.forEach( function ( url ) {
		if ( ! url ) return;
		var stylesheet = document.createElement( 'link' );
		stylesheet.rel = 'stylesheet';
		stylesheet.href = url;
		stylesheet.media = 'print';
		stylesheet.onload = function () { stylesheet.media = 'all'; };
		document.head.appendChild( stylesheet );
	} );
} )();
