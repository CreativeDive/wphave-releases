<?php

if ( ! class_exists( 'WPHAVE_Font_REST_Controller' ) ) :

	/** Owns the HTTP boundary; provider and repository classes remain transport-agnostic. */

	class WPHAVE_Font_REST_Controller {

		public static function register_routes() {
			register_rest_route( 'wphave/v1', '/fonts/registry', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'registry' ), 'permission_callback' => array( __CLASS__, 'can_view_registry' ) ) );
			register_rest_route( 'wphave/v1', '/fonts/google/install', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'install_google' ), 'permission_callback' => array( __CLASS__, 'can_manage_files' ), 'args' => array( 'family' => array( 'type' => 'string', 'required' => true ), 'variants' => array( 'type' => 'array', 'required' => true, 'maxItems' => WPHAVE_Local_Fonts::MAX_VARIANTS_PER_FAMILY ), 'subsets' => array( 'type' => 'array', 'default' => array() ) ) ) );
			register_rest_route( 'wphave/v1', '/fonts/local/delete', array( 'methods' => 'DELETE', 'callback' => array( __CLASS__, 'delete_local_family' ), 'permission_callback' => array( __CLASS__, 'can_manage_files' ), 'args' => array( 'family' => array( 'type' => 'string', 'required' => true ) ) ) );
			register_rest_route( 'wphave/v1', '/fonts/local/file', array( 'methods' => 'DELETE', 'callback' => array( __CLASS__, 'delete_local_file' ), 'permission_callback' => array( __CLASS__, 'can_manage_files' ), 'args' => array( 'file' => array( 'type' => 'string', 'required' => true ) ) ) );
			register_rest_route( 'wphave/v1', '/fonts/local/metadata', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'record_local_metadata' ), 'permission_callback' => array( __CLASS__, 'can_manage_files' ), 'args' => array( 'fonts' => array( 'type' => 'array', 'default' => array(), 'maxItems' => WPHAVE_Local_Fonts::MAX_FAMILIES_PER_REQUEST ), 'family' => array( 'type' => 'string', 'default' => '' ), 'variants' => array( 'type' => 'array', 'default' => array(), 'maxItems' => WPHAVE_Local_Fonts::MAX_VARIANTS_PER_FAMILY ), 'source' => array( 'type' => 'string', 'enum' => array( 'upload' ), 'default' => 'upload' ) ) ) );
			register_rest_route( 'wphave/v1', '/fonts/local/mapping', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'update_local_mapping' ), 'permission_callback' => array( __CLASS__, 'can_manage_files' ), 'args' => array( 'family' => array( 'type' => 'string', 'required' => true ), 'variants' => array( 'type' => 'array', 'required' => true, 'maxItems' => WPHAVE_Local_Fonts::MAX_VARIANTS_PER_FAMILY ) ) ) );
		}

		/** Determine whether the current user may inspect the resolved font registry. */
		public static function can_view_registry(): bool {
			return current_user_can( 'edit_posts' );
		}

		/** Return the resolved registry after repeating the final read boundary. */
		public static function registry() {
			// AUTHORIZATION INVARIANT: The resolved registry contains local filenames,
			// provider state, variants and typography assignments. Direct/composed
			// dispatch repeats the editor capability before resolving any provider.
			if ( ! self::can_view_registry() ) {
				return new WP_Error(
					'wphave_font_registry_forbidden',
					__( 'You are not allowed to inspect the font registry.', 'wphave' ),
					array( 'status' => 403 )
				);
			}

			$registry = WPHAVE_Font_Resolver::registry();

			// AUTHORIZATION/TOCTOU INVARIANT: Registry resolution crosses option,
			// filesystem and provider extension points. Editor authority must still
			// exist immediately before the resolved private inventory is disclosed.
			if ( ! self::can_view_registry() ) {
				return new WP_Error(
					'wphave_font_registry_forbidden',
					__( 'You are not allowed to inspect the font registry.', 'wphave' ),
					array( 'status' => 403 )
				);
			}

			return new WP_REST_Response( $registry, 200 );
		}

		public static function install_google( WP_REST_Request $request ) {
			$authorization = self::require_manage_files();

			if ( is_wp_error( $authorization ) ) {
				return $authorization;
			}

			$result = WPHAVE_Google_Font_Installer::install(
				$request->get_param( 'family' ),
				$request->get_param( 'variants' ),
				$request->get_param( 'subsets' ),
				array( __CLASS__, 'require_manage_files' )
			);

			return is_wp_error( $result ) ? $result : new WP_REST_Response( $result, 200 );
		}

		public static function delete_local_family( WP_REST_Request $request ) {
			$authorization = self::require_manage_files();

			if ( is_wp_error( $authorization ) ) {
				return $authorization;
			}

			return self::response( WPHAVE_Local_Font_Mutations::delete_family( $request->get_param( 'family' ) ) );
		}

		public static function delete_local_file( WP_REST_Request $request ) {
			$authorization = self::require_manage_files();

			if ( is_wp_error( $authorization ) ) {
				return $authorization;
			}

			return self::response( WPHAVE_Local_Font_Mutations::delete_file( $request->get_param( 'file' ) ) );
		}

		public static function record_local_metadata( WP_REST_Request $request ) {
			$authorization = self::require_manage_files();

			if ( is_wp_error( $authorization ) ) {
				return $authorization;
			}

			return self::response( WPHAVE_Local_Font_Mutations::record( $request->get_param( 'fonts' ), $request->get_param( 'family' ), $request->get_param( 'variants' ), $request->get_param( 'source' ) ) );
		}

		public static function update_local_mapping( WP_REST_Request $request ) {
			$authorization = self::require_manage_files();

			if ( is_wp_error( $authorization ) ) {
				return $authorization;
			}

			return self::response( WPHAVE_Local_Font_Mutations::update_mapping( $request->get_param( 'family' ), $request->get_param( 'variants' ) ) );
		}

		public static function require_manage_files() {
			// AUTHORIZATION INVARIANT: Route permissions are only an early dispatch
			// gate. Every public font mutation callback repeats the site-wide settings
			// and filesystem capabilities immediately before provider/repository work.
			if ( ! self::can_manage_files() ) {
				return new WP_Error(
					'wphave_font_management_forbidden',
					__( 'You are not allowed to manage local fonts.', 'wphave' ),
					array( 'status' => 403 )
				);
			}

			return true;
		}

		private static function response( $result ) {
			return is_wp_error( $result ) ? $result : new WP_REST_Response( $result, 200 );
		}

		public static function can_manage_files() {
			// SECURITY INVARIANT: Local font workflows mutate site-wide configuration
			// and filesystem content, so both settings administration and upload
			// authority are required at their shared REST boundary.
			return current_user_can( 'manage_options' ) && current_user_can( 'upload_files' );
		}
	}

endif;
