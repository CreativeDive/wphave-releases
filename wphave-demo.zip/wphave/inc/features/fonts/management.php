<?php

/** Bootstrap font-management endpoints. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/rest-controller.php';

add_action( 'rest_api_init', array( 'WPHAVE_Font_REST_Controller', 'register_routes' ) );
