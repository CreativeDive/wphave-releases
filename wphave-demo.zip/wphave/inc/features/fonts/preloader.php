<?php

if (!class_exists('WPHAVE_Font_Preloader')):
	/**
	 * Preloads a small, deterministic set of locally hosted typography assets.
	 *
	 * Preloading too many fonts competes with the page's critical resources. This
	 * service therefore considers only effective global typography assignments,
	 * trusts the canonical font resolver and emits at most one file per role.
	 * External URLs and merely available or activated-but-unassigned fonts never
	 * cross this boundary.
	 */

	class WPHAVE_Font_Preloader {
		const MAX_FILES = 2;

		/** Render verified font preload links in the public document head. */

		public static function render() {
			foreach (self::files() as $font) {
				printf(
					'<link rel="preload" href="%s" as="font" type="%s" crossorigin="anonymous">' .
						"\n",
					esc_url($font['url']),
					esc_attr($font['type']),
				);
			}
		}

		/**
		 * Resolve preload candidates without keeping a separate cache.
		 *
		 * Font assignments, manifests and Site Composition imports can change in one
		 * request. Reading the canonical resolver here is intentionally cheap and
		 * avoids stale preload URLs or a second invalidation state machine.
		 */

		public static function files() {
			if (
				WPHAVE_Fonts::loading_mode() === 'disabled' ||
				WPHAVE_Fonts::font_preloading() !== 'automatic'
			) {
				return [];
			}
			$fonts = WPHAVE_Font_Resolver::active_local_fonts();
			$files = [];
			$seen = [];

			// Body text usually paints before headings across the whole document. Keep
			// its regular face first, then add at most one heading face.
			foreach (['text', 'headings'] as $role) {
				foreach ($fonts as $font) {
					if (!in_array($role, $font['roles'] ?? [], true)) {
						continue;
					}
					$variant = self::preferred_variant(
						$font['variants'] ?? [],
						self::role_weight($role),
					);
					$file = self::verified_file($font, $variant);
					if (!$file || isset($seen[$file['url']])) {
						continue;
					}
					$seen[$file['url']] = true;
					$files[] = $file;
					break;
				}
				if (count($files) >= self::MAX_FILES) {
					break;
				}
			}

			return $files;
		}

		/** Return the effective weight requested for one global typography role. */

		private static function role_weight($role) {
			$globals = WPHAVE_Global_Data::get_base();
			$typography = WPHAVE_Font_Resolver::effective_typography(
				$role,
				$globals['typography'][$role],
			);

			return absint($typography['weight']);
		}

		/** Select one normal Latin WOFF2 face using CSS font-weight matching order. */

		private static function preferred_variant($variants, $requested_weight) {
			$candidates = [];
			foreach (is_array($variants) ? $variants : [] as $variant) {
				$file = sanitize_file_name($variant['file'] ?? '');
				if (strtolower(pathinfo($file, PATHINFO_EXTENSION)) !== 'woff2') {
					continue;
				}
				$style = strtolower($variant['fontStyle'] ?? 'normal');
				if ($style !== 'normal') {
					continue;
				}
				$range = self::weight_range($variant['fontWeight'] ?? '400');
				if (!$range) {
					continue;
				}
				$rank = self::weight_match_rank($range, $requested_weight);
				$subset = sanitize_key($variant['subset'] ?? '');
				// Basic Latin is the safest single-file prediction. Other subsets still
				// load normally through @font-face when the page actually needs them.
				$subset_rank = $subset === 'latin' ? 0 : ($subset ? 2 : 1);
				$candidates[] = ['variant' => $variant, 'rank' => $rank, 'subset' => $subset_rank];
			}

			usort(
				$candidates,
				fn($a, $b) => $a['rank'] === $b['rank']
					? $a['subset'] <=> $b['subset']
					: $a['rank'] <=> $b['rank'],
			);

			return $candidates[0]['variant'] ?? [];
		}

		/**
		 * Rank a face by CSS Fonts 4 weight search order, then distance.
		 * This predicts the browser's face selection; it does not alter typography.
		 * https://www.w3.org/TR/css-fonts-4/#font-style-matching
		 */
		private static function weight_match_rank($range, $requested_weight) {
			$weight = max($range[0], min($range[1], $requested_weight));
			if ($requested_weight < 400) {
				$priority = $weight <= $requested_weight ? 0 : 1;
			} elseif ($requested_weight > 500) {
				$priority = $weight >= $requested_weight ? 0 : 1;
			} else {
				$priority =
					$weight >= $requested_weight && $weight <= 500
						? 0
						: ($weight < $requested_weight
							? 1
							: 2);
			}

			return [$priority, abs($weight - $requested_weight)];
		}

		/** Normalize a static or variable font weight to an inclusive numeric range. */

		private static function weight_range($weight) {
			$weight = trim((string) $weight);
			if ($weight === 'normal') {
				return [400, 400];
			}
			if ($weight === 'bold') {
				return [700, 700];
			}
			if (preg_match('/^(\d{1,4})(?:\s+(\d{1,4}))?$/', $weight, $matches)) {
				$minimum = (int) $matches[1];
				$maximum = isset($matches[2]) ? (int) $matches[2] : $minimum;
				if ($minimum >= 1 && $maximum <= 1000 && $minimum <= $maximum) {
					return [$minimum, $maximum];
				}
			}

			return [];
		}

		/** Convert one resolver-owned variant to a same-origin, readable file URL. */

		private static function verified_file($font, $variant) {
			$file = sanitize_file_name($variant['file'] ?? '');
			if (!$file) {
				return [];
			}
			$extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
			if ($extension !== 'woff2') {
				return [];
			}

			if (!empty($font['default']) || ($font['source'] ?? '') === 'default') {
				$path = wphave_dir('inc/features/fonts/assets/default-fonts/' . $file);
				$url = WPHAVE_Local_Font_Library::default_base_url() . rawurlencode($file);
			} else {
				$upload_dir = WPHAVE_Local_Font_Library::upload_dir();
				$path = path_join($upload_dir['basedir'] ?? '', $file);
				$url = trailingslashit($upload_dir['baseurl'] ?? '') . rawurlencode($file);
			}

			if (!$url || !is_readable($path)) {
				return [];
			}
			$site_host = strtolower(wp_parse_url(home_url(), PHP_URL_HOST) ?: '');
			$file_host = strtolower(wp_parse_url($url, PHP_URL_HOST) ?: '');
			if (!$site_host || !$file_host || $site_host !== $file_host) {
				return [];
			}

			return ['url' => esc_url_raw($url), 'type' => 'font/woff2'];
		}
	}
endif;
