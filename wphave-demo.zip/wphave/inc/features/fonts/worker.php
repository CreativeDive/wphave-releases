<?php

/** Register checksum-bound staged font cleanup for worker requests. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * WORKER INVARIANT: Staged-file cleanup owns only its authenticated queue,
 * upload boundary and local repository facade. Google providers, CSS,
 * resolution and preload hooks belong exclusively to the frontend runtime.
 */
require_once wphave_dir() . 'inc/data/options/mutations.php';
require_once wphave_dir() . 'inc/helpers/filesystem.php';
require_once wphave_dir() . 'inc/features/security/conditional-file.php';
require_once __DIR__ . '/local/repository.php';
require_once __DIR__ . '/local/fonts.php';

add_action( WPHAVE_Local_Fonts::CLEANUP_HOOK, array( 'WPHAVE_Local_Fonts', 'retry_staged_cleanup' ) );
