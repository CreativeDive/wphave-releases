<?php

if ( ! class_exists( 'WPHAVE_Font_Normalizer' ) ) :

	/** Normalize and merge font records at the boundary between providers and consumers. */

	class WPHAVE_Font_Normalizer {

		public static function registry( $fonts, $source ) {
			$normalized = array();
			foreach( is_array( $fonts ) ? $fonts : array() as $font ) {
				if( is_string( $font ) ) $font = array( 'family' => $font );
				if( ! is_array( $font ) ) continue;
				$family = WPHAVE_Font_Identity::family( $font['family'] ?? $font['font'] ?? ( $font['google_font']['family'] ?? '' ) );
				if( ! $family ) continue;
				$type = $font['type'] ?? self::source_type( $source );
				$variants = $font['variants'] ?? array();
				$subsets = $font['subsets'] ?? array();
				if( is_string( $variants ) ) $variants = array_filter( array_map( 'trim', explode( ',', $variants ) ) );
				if( is_string( $subsets ) ) {
					$decoded = json_decode( $subsets, true );
					$subsets = is_array( $decoded ) ? $decoded : array_filter( array_map( 'trim', explode( ',', $subsets ) ) );
				}
				$origin = $font['origin'] ?? ( $source === 'global-styles' ? $type : ( $font['source'] ?? $source ) );
				$usage_sources = is_array( $font['usageSources'] ?? null ) ? $font['usageSources'] : ( $source === 'global-styles' ? array( 'global-styles' ) : array() );
				$normalized[] = array(
					'key' => WPHAVE_Font_Identity::key( $family ), 'family' => $family, 'name' => $family, 'type' => $type, 'provider' => $font['provider'] ?? $type,
					'source' => $source === 'global-styles' ? 'global-styles' : $origin, 'origin' => $origin, 'usageSources' => array_values( array_unique( array_filter( $usage_sources ) ) ),
					'sources' => array_values( array_unique( array_filter( is_array( $font['sources'] ?? null ) ? $font['sources'] : array( $origin ) ) ) ), 'default' => ! empty( $font['default'] ),
					'managed' => (bool) ( $font['managed'] ?? true ), 'loadable' => (bool) ( $font['loadable'] ?? ( $type !== 'system' ) ), 'integrity' => $font['integrity'] ?? 'valid',
					'license' => is_array( $font['license'] ?? null ) ? $font['license'] : null, 'roles' => array_values( is_array( $font['roles'] ?? null ) ? $font['roles'] : array() ),
					'variants' => array_values( is_array( $variants ) ? $variants : array() ), 'subsets' => array_values( is_array( $subsets ) ? $subsets : array() ),
				);
			}

			return self::unique_registry( $normalized );
		}

		public static function unique_registry( $fonts ) {
			$unique = array();
			foreach( is_array( $fonts ) ? $fonts : array() as $font ) {
				$key = ( $font['source'] ?? '' ) . ':' . WPHAVE_Font_Identity::key( $font['family'] ?? '' );
				if( $key !== ':' && ! isset( $unique[$key] ) ) $unique[$key] = $font;
			}

			return array_values( $unique );
		}

		public static function system_fonts() {
			$fonts = wphave_data_get( 'site_settings', 'fonts.system.fonts', array() );
			if( ! is_array( $fonts ) || empty( $fonts ) ) $fonts = array_map( fn( $font ) => array( 'family' => $font ), WPHAVE_Fonts::web_safe_fonts() );

			return self::registry( $fonts, 'system' );
		}

		private static function source_type( $source ) {
			return array( 'adobe' => 'adobe-fonts', 'default' => 'local', 'google' => 'google-fonts', 'global-styles' => 'system', 'local' => 'local', 'system' => 'system' )[$source] ?? $source;
		}

		public static function variants( $variants ) {
			$unique = array();
			foreach( is_array( $variants ) ? $variants : array() as $variant ) {
				$key = self::variant_key( $variant );
				if( $key !== '' ) $unique[$key] = $variant;
			}

			return array_values( $unique );
		}

		public static function variant_key( $variant ) {
			if( ! is_array( $variant ) ) return (string) $variant;

			return sanitize_file_name( $variant['file'] ?? '' ) . ':' . ( $variant['fontStyle'] ?? 'normal' ) . ':' . ( $variant['fontWeight'] ?? '400' ) . ':' . ( $variant['unicodeRange'] ?? '' ) . ':' . ( $variant['subset'] ?? '' );
		}

		public static function merge( $fonts ) {
			$merged = array();
			foreach( is_array( $fonts ) ? $fonts : array() as $font ) {
				$key = WPHAVE_Font_Identity::key( $font['family'] ?? '' );
				if( ! $key ) continue;
				if( ! isset( $merged[$key] ) ) {
					$font['family'] = WPHAVE_Font_Identity::family( $font['family'] );
					$font['variants'] = self::variants( $font['variants'] ?? array() );
					$merged[$key] = $font;
					continue;
				}

				$merged[$key]['roles'] = array_values( array_unique( array_merge( $merged[$key]['roles'] ?? array(), $font['roles'] ?? array() ) ) );
				$merged[$key]['variants'] = self::variants( array_merge( $merged[$key]['variants'] ?? array(), $font['variants'] ?? array() ) );
				$merged[$key]['subsets'] = array_values( array_unique( array_merge( $merged[$key]['subsets'] ?? array(), $font['subsets'] ?? array() ) ) );
				$merged[$key]['loadable'] = ! empty( $merged[$key]['loadable'] ) || ! empty( $font['loadable'] );
			}

			return array_values( $merged );
		}
	}

endif;
