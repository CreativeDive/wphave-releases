<?php

if ( ! class_exists( 'WPHAVE_Font_Identity' ) ) :

	/**
	 * Owns provider-independent font family identity and CSS serialization.
	 *
	 * Keeping identity below the resolver prevents providers, assignments and the
	 * registry from depending on the public WPHAVE_Fonts facade merely to compare
	 * the same family.
	 */

	class WPHAVE_Font_Identity {

		public static function family( $font ) {
			$font = html_entity_decode( trim( (string) $font ) );
			$font = trim( str_replace( '+', ' ', $font ), " \t\n\r\0\x0B\"'" );

			return preg_replace( '/\s+/', ' ', $font );
		}

		public static function key( $font ) {
			return strtolower( self::family( $font ) );
		}

		/** Reject characters that can alter a generated CSS declaration. */

		public static function is_safe( $font ) {
			$raw = html_entity_decode( (string) $font );
			$family = self::family( $font );

			return $family !== '' && strlen( $family ) <= 200 && ! preg_match( '/[\x00-\x1f\x7f\\\\;{}]/u', $raw );
		}

		/** Serialize one family as a quoted CSS string token. */

		public static function css_string( $font ) {
			if( ! self::is_safe( $font ) ) return '';
			$family = self::family( $font );

			return "'" . addcslashes( $family, "\\'" ) . "'";
		}

		public static function css( $font ) {
			$family = self::family( $font );
			if( ! $family ) return '';
			$generic = array( 'serif', 'sans-serif', 'monospace', 'cursive', 'fantasy', 'system-ui', 'ui-serif', 'ui-sans-serif', 'ui-monospace', 'emoji', 'math', 'fangsong' );
			if( in_array( strtolower( $family ), $generic, true ) || preg_match( '/^[a-zA-Z_-]+$/', $family ) ) return $family;

			return '"' . addcslashes( $family, '"\\' ) . '"';
		}
	}

endif;
