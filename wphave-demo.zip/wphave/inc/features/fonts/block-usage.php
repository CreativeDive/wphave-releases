<?php

/** Font dependencies belong to rendered blocks, never to the library inventory. */
class WPHAVE_Block_Font_Usage {

	/** Hoist and deduplicate only our generated assets after the final tree is known. */
	public static function register_output() {
		WPHAVE_Output_Buffer::instance()->register( array( __CLASS__, 'document' ), 5 );
	}

	public static function document( $html ) {
		if( stripos( $html, '</head>' ) === false ) {
			return $html;
		}
		$assets = array();
		$output = preg_replace_callback(
			'~<style class="wphave-block-fonts">.*?</style>|<link rel="stylesheet" class="wphave-block-fonts" href="[^"]*">~s',
			static function( $match ) use ( &$assets ) {
				$assets[$match[0]] = true;
				return '';
			},
			$html
		);
		if( $output === null || ! $assets ) {
			return $html;
		}
		$position = stripos( $output, '</head>' );
		return substr_replace( $output, implode( '', array_keys( $assets ) ), $position, 0 );
	}

	/** Collect typed family assignments, including responsive and state overrides. */
	public static function families( $attributes, $depth = 0 ) {
		if( ! is_array( $attributes ) || $depth > 32 ) {
			return array();
		}
		$families = array();
		foreach( $attributes as $key => $value ) {
			if(
				in_array( $key, array( 'family', 'fontFamily' ), true )
				&& is_array( $value )
				&& ! empty( $value['name'] )
				&& is_string( $value['name'] )
			) {
				$families[] = $value;
			} elseif( is_array( $value ) ) {
				$families = array_merge( $families, self::families( $value, $depth + 1 ) );
			}
		}
		return $families;
	}

	/** Runs after rendering and block-cache retrieval, including nested/template blocks. */
	public static function render( $content, $block ) {
		if( ! is_string( $content ) || trim( $content ) === '' || WPHAVE_Fonts::loading_mode() === 'disabled' ) {
			return $content;
		}
		$attributes = $block['attrs'] ?? array();
		if( ! empty( $attributes['wphave']['useBlockStyle'] ) && class_exists( 'WPHAVE_Block_Styles' ) ) {
			$attributes['wphave'] = WPHAVE_Block_Styles::apply_attrs(
				$attributes['wphave'],
				$block['blockName'] ?? ''
			);
		}
		$families = self::families( $attributes );
		if( ! $families ) {
			return $content;
		}
		$fonts = WPHAVE_Font_Resolver::assigned_fonts( $families );
		$assets = '';
		$css = WPHAVE_Local_Font_CSS::for_fonts( $fonts );
		if( $css ) {
			$assets .= '<style class="wphave-block-fonts">' . str_ireplace( '</style', '<\\/style', $css ) . '</style>';
		}
		$google = array_filter( $fonts, fn( $font ) => ( $font['type'] ?? '' ) === 'google-fonts' );
		if( $google ) {
			$url = WPHAVE_Google_Font_Query::css2_url(
				WPHAVE_Font_Assignments::google_query_fragments( $google ),
				WPHAVE_Fonts::font_display()
			);
			if( $url ) {
				$assets .= '<link rel="stylesheet" class="wphave-block-fonts" href="' . esc_url( $url ) . '">';
			}
		}
		$adobe = array_filter( $fonts, fn( $font ) => ( $font['type'] ?? '' ) === 'adobe-fonts' );
		if( $adobe ) {
			$url = WPHAVE_Fonts::adobe_fonts_url(
				wphave_data_get( 'site_settings', 'fonts.external.adobe.source', '' )
			);
			if( $url ) {
				$assets .= '<link rel="stylesheet" class="wphave-block-fonts" href="' . esc_url( $url ) . '">';
			}
		}
		return ( $assets && ! str_contains( $content, $assets ) ? $assets : '' ) . $content;
	}
}
