<?php

if ( ! class_exists( 'WPHAVE_Font_Assignments' ) ) :

	/**
	 * Resolves font assignments from site typography.
	 *
	 * This class is the single place where font usage is derived from global
	 * typography, font pair presets, plugin defaults and explicit font settings.
	 */

	class WPHAVE_Font_Assignments {

		/**
		 * Determine whether global typography currently references a custom font.
		 *
		 * @param array|null $typography Optional typography array. Site globals are used when omitted.
		 * @return bool
		 */

		/**
		 * Determine whether default typography is currently effective.
		 *
		 * @return bool
		 */

		/**
		 * Return only bundled defaults whose typography role has no explicit family.
		 * A heading override must not accidentally remove the bundled text face, and
		 * vice versa. This role-aware boundary is also used by CSS generation.
		 */

		/** Filter bundled defaults using an explicit role list; kept pure for regression tests. */

		public static function defaults_for_unassigned_roles( $assigned_roles ) {
			$assigned_roles = array_unique( is_array( $assigned_roles ) ? $assigned_roles : array() );

			return array_values( array_filter( self::default_fonts(), function( $font ) use ( $assigned_roles ) {
				return ! empty( array_diff( $font['roles'] ?? array(), $assigned_roles ) );
			} ) );
		}

		/**
		 * Return the default font definitions used by the initial site typography.
		 *
		 * @return array
		 */

		public static function default_fonts() {
			$fonts = array();

			foreach( WPHAVE_Local_Font_Library::defaults() as $font ) {
				$fonts[] = self::font_item( $font['family'] ?? '', 'local', 'default', $font['roles'] ?? array(), array(
					'default' => true,
					'variants' => WPHAVE_Local_Font_Library::unique_variants( $font['variants'] ?? array() ),
					'subsets' => array_values( array_unique( array_filter( array_map( fn( $variant ) => $variant['subset'] ?? '', $font['variants'] ?? array() ) ) ) ),
				) );
			}

			return WPHAVE_Font_Normalizer::merge( $fonts );
		}

		/**
		 * Return default Google font query fragments.
		 *
		 * @return array
		 */

		/**
		 * Return system fonts assigned through global typography.
		 *
		 * @return array
		 */

		public static function global_system_fonts() {
			$typography = wphave_data_get( 'site_globals', 'typography', array() );
			$preset_typography = wphave_preset_font_pairs();

			$fonts = array();

			foreach( is_array( $preset_typography ) ? array( 'headings', 'text' ) : array() as $role ) {
				$family = $preset_typography[$role] ?? array();
				$family_name = $family['name'] ?? $family['family'] ?? '';
				if( ( $family['type'] ?? '' ) === 'system' && $family_name ) $fonts[] = self::font_item( $family_name, 'system', 'global-styles', array( $role ), array( 'managed' => false, 'loadable' => false ) );
			}

			foreach( is_array( $typography ) ? $typography : array() as $role => $data ) {
				$family = $data['family'] ?? array();
				$family_name = $family['name'] ?? '';
				$family_type = $family['type'] ?? '';

				if( $family_type !== 'system' || ! $family_name ) {
					continue;
				}

				$fonts[] = self::font_item( $family_name, 'system', 'global-styles', array( $role ), array(
					'managed' => false,
					'loadable' => false,
				) );
			}

			return WPHAVE_Font_Normalizer::merge( $fonts );
		}

		/**
		 * Return Google Fonts assigned through global typography.
		 *
		 * @return array
		 */

		public static function global_google_fonts() {
			$typography = wphave_data_get( 'site_globals', 'typography', array() );
			$preset_typography = wphave_preset_font_pairs();
			$fonts = array();

			if( is_array( $preset_typography ) && ! empty( $preset_typography ) ) {
				foreach( array( 'headings', 'text' ) as $role ) {
					$family = $preset_typography[$role]['name'] ?? '';
					$type = $preset_typography[$role]['type'] ?? 'google-fonts';

					if( ! $family || $type !== 'google-fonts' ) {
						continue;
					}

					$fonts[] = self::font_item( $family, 'google-fonts', 'global-styles', array( $role ), array(
						'managed' => false,
						// Persisted assignment metadata describes intent. Never consult the
						// recommendation catalogue as a second runtime provider registry.
						'variants' => self::preset_font_variants( $preset_typography[$role]['styles'] ?? $preset_typography[$role]['weight'] ?? '' ),
					) );
				}
			}

			if( is_array( $typography ) ) {
				foreach( $typography as $role => $data ) {
					$family = $data['family'] ?? array();
					$family_name = $family['name'] ?? '';
					$family_type = $family['type'] ?? '';

					if( $family_type !== 'google-fonts' || ! $family_name ) {
						continue;
					}

					$fonts[] = self::font_item( $family_name, 'google-fonts', 'global-styles', array( $role ), array(
						'managed' => false,
						'variants' => array_filter( array( (string) ( $data['weight'] ?? '' ) ) ),
					) );
				}
			}

			return WPHAVE_Font_Normalizer::merge( $fonts );
		}

		/** Return Adobe Fonts assigned through global typography. */

		public static function global_adobe_fonts() {
			$typography = wphave_data_get( 'site_globals', 'typography', array() );
			$fonts = array();

			foreach( is_array( $typography ) ? $typography : array() as $role => $data ) {
				$family = $data['family'] ?? array();
				if( ( $family['type'] ?? '' ) !== 'adobe-fonts' || empty( $family['name'] ) ) continue;
				$fonts[] = self::font_item( $family['name'], 'adobe-fonts', 'global-styles', array( $role ), array( 'managed' => false, 'variants' => array_filter( array( (string) ( $data['weight'] ?? '' ) ) ) ) );
			}

			return WPHAVE_Font_Normalizer::merge( $fonts );
		}

		/** Return local font families assigned through global typography. */

		public static function global_local_fonts() {
			$typography = wphave_data_get( 'site_globals', 'typography', array() );
			$preset_typography = wphave_preset_font_pairs();
			$fonts = array();

			foreach( is_array( $preset_typography ) ? array( 'headings', 'text' ) : array() as $role ) {
				$family = $preset_typography[$role] ?? array();
				$family_name = $family['name'] ?? $family['family'] ?? '';
				if( ( $family['type'] ?? '' ) === 'local' && $family_name ) $fonts[] = self::font_item( $family_name, 'local', 'global-styles', array( $role ), array( 'managed' => false, 'variants' => self::preset_font_variants( $family['styles'] ?? $family['weight'] ?? '' ) ) );
			}

			foreach( is_array( $typography ) ? $typography : array() as $role => $data ) {
				$family = $data['family'] ?? array();

				if( ( $family['type'] ?? '' ) !== 'local' || empty( $family['name'] ) ) continue;

				$fonts[] = self::font_item( $family['name'], 'local', 'global-styles', array( $role ), array(
					'managed' => false,
					'variants' => array_filter( array( (string) ( $data['weight'] ?? '' ) ) ),
				) );
			}

			return WPHAVE_Font_Normalizer::merge( $fonts );
		}

		/** Check destructive actions against every global local-font assignment. */

		public static function is_local_family_used( $family ) {
			foreach( self::global_local_fonts() as $font ) {
				if( strtolower( WPHAVE_Fonts::canonical_font_family( $font['family'] ?? '' ) ) === strtolower( WPHAVE_Fonts::canonical_font_family( $family ) ) ) return true;
			}

			return false;
		}

		/**
		 * Return the fonts currently effective for typography output.
		 *
		 * @return array
		 */

		/**
		 * Convert font entries to Google Fonts query fragments.
		 *
		 * @param array $fonts Font entries.
		 * @return array
		 */

		public static function google_query_fragments( $fonts ) {
			$query = array();
			$configured = array();

			// Provider configuration owns the variants that may be requested. Global
			// typography owns usage and can ask browsers to synthesize another weight,
			// but it must not inject that arbitrary weight into the Google CSS2 URL. A
			// single unsupported weight makes Google's complete combined stylesheet fail.
			foreach( WPHAVE_Fonts::custom_google_fonts() ?: array() as $font ) {
				$key = WPHAVE_Font_Identity::key( $font['family'] ?? '' );
				if( $key ) $configured[$key] = is_array( $font['variants'] ?? null ) ? $font['variants'] : array();
			}

			foreach( $fonts as $font ) {
				$family = $font['family'] ?? '';
				$key = WPHAVE_Font_Identity::key( $family );

				if( ! $family ) {
					continue;
				}

				// The catalogue is also enforced while reading. That keeps legacy, imported
				// or manually edited options from breaking the complete provider request.
				$variants = WPHAVE_Google_Font_Catalog::safe_variants( $family, array_key_exists( $key, $configured ) ? $configured[$key] : array() );
				if( ! $variants ) continue;

				$query[] = WPHAVE_Google_Font_Query::family( $family, $variants );
			}

			return array_values( array_unique( array_filter( $query ) ) );
		}

		/**
		 * Build a font usage item.
		 *
		 * @param string $family Font family name.
		 * @param string $type Provider type.
		 * @param string $source Usage source.
		 * @param array $roles Typography roles.
		 * @param array $args Additional item data.
		 * @return array
		 */

		private static function font_item( $family, $type, $source, $roles = array(), $args = array() ) {
			return array_merge(
				array(
					'family' => WPHAVE_Fonts::canonical_font_family( $family ),
					'type' => $type,
					'source' => $source,
					'provider' => $type,
					'usageSources' => $source === 'global-styles' ? array( 'global-styles' ) : array(),
					'roles' => $roles,
					'variants' => array(),
					'subsets' => array( 'latin' ),
					'managed' => true,
					'loadable' => $type !== 'system',
				),
				$args
			);
		}

		/**
		 * Merge duplicate font families while preserving role and variant metadata.
		 *
		 * @param array $fonts Font entries.
		 * @return array
		 */

		/**
		 * Return the exact bundled variant used by one default typography role.
		 *
		 * @param string $family Font family name.
		 * @param string $weight Primary role weight.
		 * @return array
		 */

		/**
		 * Convert preset style string to variant list.
		 *
		 * @param string $styles Comma separated Google font styles.
		 * @return array
		 */

		private static function preset_font_variants( $styles ) {
			if( ! $styles ) {
				return array();
			}

			return array_values( array_filter( array_map( 'trim', explode( ',', $styles ) ) ) );
		}

	}

endif;
