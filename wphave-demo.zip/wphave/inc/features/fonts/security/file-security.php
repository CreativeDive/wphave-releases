<?php

if ( ! class_exists( 'WPHAVE_Font_File_Security' ) ) :

	/**
	 * Defines the shared binary admission boundary for font files.
	 *
	 * Extension and container signatures prevent arbitrary files from entering the
	 * public font directory. This is intentionally not presented as a complete font
	 * sanitizer: privileged users remain responsible for choosing trusted binaries.
	 */

	class WPHAVE_Font_File_Security {

		const EXTENSIONS = array( 'ttf', 'otf', 'woff', 'woff2' );

		public static function extension( $file ) {
			return strtolower( pathinfo( (string) $file, PATHINFO_EXTENSION ) );
		}

		public static function is_supported( $file ) {
			return in_array( self::extension( $file ), self::EXTENSIONS, true );
		}

		public static function has_valid_signature( $path, $extension = '' ) {
			$extension = $extension ?: self::extension( $path );
			if( ! in_array( $extension, self::EXTENSIONS, true ) ) return false;
			$handle = is_readable( $path ) ? fopen( $path, 'rb' ) : false;
			if( ! is_resource( $handle ) ) return false;
			$signature = fread( $handle, 4 );
			fclose( $handle );

			return self::valid_signature( $signature, $extension );
		}

		public static function has_valid_body_signature( $body, $extension ) {
			return self::valid_signature( substr( (string) $body, 0, 4 ), $extension );
		}

		private static function valid_signature( $signature, $extension ) {
			$signatures = array(
				'ttf' => array( "\x00\x01\x00\x00", 'true', 'typ1' ),
				'otf' => array( 'OTTO' ),
				'woff' => array( 'wOFF' ),
				'woff2' => array( 'wOF2' ),
			);

			return in_array( $signature, $signatures[$extension] ?? array(), true );
		}
	}

endif;
