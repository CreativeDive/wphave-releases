<?php

if (!class_exists('WPHAVE_Font_Resolver')):
	/**
	 * Resolves the complete font state for every consumer.
	 *
	 * Settings express intent, the local manifest proves available assets and this
	 * resolver is the only place that decides which provider is effective. Registry,
	 * frontend CSS and editor previews must consume this snapshot instead of making
	 * independent availability decisions.
	 */

	class WPHAVE_Font_Resolver {
		/** Return the validated Adobe source that owns every extracted Adobe family. */

		private static function configured_adobe_source() {
			return WPHAVE_Fonts::adobe_fonts_url(
				wphave_data_get('site_settings', 'fonts.external.adobe.source', ''),
			);
		}

		/** Return extracted Adobe families only while their owning source is valid. */

		private static function configured_adobe_fonts() {
			if (!self::configured_adobe_source()) {
				return [];
			}
			return WPHAVE_Font_Normalizer::registry(
				wphave_data_get('site_settings', 'fonts.external.adobe.fonts', []) ?: [],
				'adobe',
			);
		}

		/** Return Google families explicitly enabled in provider settings. */

		private static function configured_google_fonts() {
			return WPHAVE_Font_Normalizer::registry(
				WPHAVE_Fonts::custom_google_fonts() ?: [],
				'google',
			);
		}

		/** Return configured local fonts joined with manifest-backed library records. */

		public static function configured_local_fonts() {
			$active = array_fill_keys(self::active_local_keys(), true);
			$fonts = [];

			// Settings store intent only. Family, source and file metadata always come
			// from the manifest-backed library so stale settings cannot invent assets.
			foreach (self::verified_library_fonts() as $font) {
				$key = self::family_key($font['family'] ?? '');
				if (!isset($active[$key])) {
					continue;
				}
				$fonts[] = $font;
			}

			return WPHAVE_Font_Normalizer::registry($fonts, 'local');
		}

		/** Return immutable defaults required for typography roles without an effective assignment. */

		public static function effective_default_fonts() {
			$mode = WPHAVE_Fonts::loading_mode();
			$assigned = WPHAVE_Font_Assignments::global_system_fonts();

			if ($mode === 'mixed') {
				$assigned = array_merge($assigned, self::resolved_global_google_fonts());
				if (self::configured_adobe_source()) {
					$assigned = array_merge(
						$assigned,
						WPHAVE_Font_Assignments::global_adobe_fonts(),
					);
				}
			}

			if ($mode !== 'disabled') {
				$assigned = array_merge($assigned, self::resolved_global_local_fonts());
			}

			$roles = [];
			foreach ($assigned as $font) {
				$roles = array_merge($roles, $font['roles'] ?? []);
			}

			return self::with_default_variant_urls(
				WPHAVE_Font_Assignments::defaults_for_unassigned_roles($roles),
			);
		}

		/** Resolve the family that CSS can actually render under the loading policy. */

		public static function effective_typography_family($role, $family) {
			return self::effective_typography($role, ['family' => $family])['family'] ?? $family;
		}

		/** Resolve both family and weight so local-only never synthesizes a missing default variant. */

		public static function effective_typography(
			$role,
			$typography,
			?array $font_context = null,
		) {
			$family = $typography['family'] ?? [];
			$type = $family['type'] ?? '';
			// CONTEXT INVARIANT: A non-null inventory is an isolated, caller-verified
			// render context. Never consult this site's policy or installed providers.
			// Null retains the normal website contract; an empty inventory is isolated too.
			if ($font_context !== null) {
				if ($type === 'system' || !$type) {
					return $typography;
				}
				foreach ($font_context as $font) {
					if (
						self::family_key($font['family'] ?? '') ===
							self::family_key($family['name'] ?? '') &&
						($font['integrity'] ?? 'valid') === 'valid'
					) {
						return self::apply_effective_font($typography, $font);
					}
				}
				return self::role_default_typography($role, $typography);
			}
			$mode = WPHAVE_Fonts::loading_mode();
			if ($type === 'system' || !$type) {
				return $typography;
			}
			if ($mode === 'disabled') {
				return self::apply_effective_font($typography, [
					'family' => 'Arial',
					'type' => 'system',
					'variants' => [],
				]);
			}

			// Mixed mode permits external providers, but it does not prove that a local
			// file still exists or that an Adobe project is still connected. Validate
			// those providers before preserving their typography assignment.
			if ($mode === 'mixed' && $type === 'google-fonts') {
				foreach (self::configured_google_fonts() as $font) {
					if (
						self::family_key($font['family'] ?? '') ===
						self::family_key($family['name'] ?? '')
					) {
						return $typography;
					}
				}
				return self::role_default_typography($role, $typography);
			}
			if ($mode === 'mixed' && $type === 'adobe-fonts') {
				foreach (self::configured_adobe_fonts() as $font) {
					if (
						self::family_key($font['family'] ?? '') ===
						self::family_key($family['name'] ?? '')
					) {
						return $typography;
					}
				}
				return self::role_default_typography($role, $typography);
			}

			$available =
				$type === 'local'
					? array_values(self::available_local_providers())
					: self::configured_local_fonts();
			foreach ($available as $font) {
				if (
					self::family_key($font['family'] ?? '') ===
						self::family_key($family['name'] ?? '') &&
					($font['integrity'] ?? 'valid') === 'valid'
				) {
					return self::apply_effective_font($typography, $font);
				}
			}

			return self::role_default_typography($role, $typography);
		}

		/** Fall back to the immutable bundled provider for one typography role. */

		private static function role_default_typography($role, $typography) {
			foreach (WPHAVE_Font_Assignments::default_fonts() as $default) {
				if (!in_array($role, $default['roles'] ?? [], true)) {
					continue;
				}
				return self::apply_effective_font($typography, $default);
			}

			return $typography;
		}

		/** Apply one verified provider and select the closest physically available weight. */

		private static function apply_effective_font($typography, $font) {
			$typography['family'] = [
				'name' => $font['family'] ?? '',
				'type' => $font['type'] ?? 'local',
			];
			$requested = absint($typography['weight'] ?? 400) ?: 400;
			$candidates = [];
			foreach (is_array($font['variants'] ?? null) ? $font['variants'] : [] as $variant) {
				$weight = trim((string) ($variant['fontWeight'] ?? ''));
				if (preg_match('/^([1-9]00)\s+([1-9]00)$/', $weight, $matches)) {
					$minimum = (int) $matches[1];
					$maximum = (int) $matches[2];
					if ($requested >= $minimum && $requested <= $maximum) {
						return array_replace($typography, ['weight' => (string) $requested]);
					}
					$candidates[] = $minimum;
					$candidates[] = $maximum;
					continue;
				}
				$normalized =
					$weight === 'normal' ? 400 : ($weight === 'bold' ? 700 : absint($weight));
				if ($normalized) {
					$candidates[] = $normalized;
				}
			}
			$candidates = array_values(array_unique($candidates));
			if ($candidates) {
				usort(
					$candidates,
					fn($a, $b) => abs($a - $requested) === abs($b - $requested)
						? $a <=> $b
						: abs($a - $requested) <=> abs($b - $requested),
				);
				$typography['weight'] = (string) $candidates[0];
			}

			return $typography;
		}

		/** Return the single effective provider list used by every loader. */

		public static function active_fonts() {
			$mode = WPHAVE_Fonts::loading_mode();
			$fonts = array_merge(
				WPHAVE_Font_Normalizer::registry(
					WPHAVE_Font_Assignments::global_system_fonts(),
					'global-styles',
				),
				self::resolved_global_google_fonts(),
				self::configured_adobe_source()
					? WPHAVE_Font_Normalizer::registry(
						WPHAVE_Font_Assignments::global_adobe_fonts(),
						'global-styles',
					)
					: [],
				self::resolved_global_local_fonts(),
				WPHAVE_Font_Normalizer::registry(self::effective_default_fonts(), 'default'),
			);

			// Inventory and legacy activation preferences never imply usage. Managed
			// local copies may still replace an assigned bundled provider.
			$used_keys = array_fill_keys(
				array_map(fn($font) => self::family_key($font['family'] ?? ''), $fonts),
				true,
			);
			$fonts = array_merge(
				$fonts,
				array_filter(
					self::loadable_local_fonts(),
					fn($font) => isset($used_keys[self::family_key($font['family'] ?? '')]),
				),
			);

			return self::mark_loadable(self::select_provider($fonts), $mode);
		}

		/** Resolve explicit block assignments against verified, permitted providers. */

		public static function assigned_fonts($families) {
			$mode = WPHAVE_Fonts::loading_mode();
			if ($mode === 'disabled') {
				return [];
			}
			$providers = array_values(self::available_local_providers());
			$preferred_local = array_fill_keys(
				array_map(
					fn($font) => self::family_key($font['family'] ?? ''),
					self::configured_local_fonts(),
				),
				true,
			);
			if ($mode === 'mixed') {
				$providers = array_merge(
					$providers,
					self::configured_google_fonts(),
					self::configured_adobe_fonts(),
				);
			}
			$resolved = [];
			foreach ($families as $family) {
				foreach ($providers as $font) {
					if (
						self::family_key($font['family'] ?? '') !==
						self::family_key($family['name'] ?? '')
					) {
						continue;
					}
					$requested_type = $family['type'] ?? '';
					$provider_type = $font['type'] ?? '';
					$local_override =
						$provider_type === 'local' &&
						isset($preferred_local[self::family_key($font['family'] ?? '')]);
					if (
						$requested_type === 'system' ||
						($requested_type !== $provider_type && !$local_override)
					) {
						continue;
					}
					$font['usageSources'] = ['blocks'];
					$resolved[] = $font;
				}
			}
			return array_values(
				array_filter(
					self::mark_loadable(self::select_provider($resolved), $mode),
					fn($font) => !empty($font['loadable']),
				),
			);
		}

		/** Return valid local providers selected by the resolver, including bundled defaults. */

		public static function active_local_fonts() {
			return array_values(
				array_filter(
					self::active_fonts(),
					fn($font) => ($font['type'] ?? '') === 'local' && !empty($font['loadable']),
				),
			);
		}

		/** Build the stable registry payload consumed by React. */

		public static function registry() {
			$local = self::configured_local_fonts();
			$library = WPHAVE_Font_Normalizer::registry(self::verified_library_fonts(), 'local');
			$inventory = WPHAVE_Local_Font_Integrity::audit();
			$issues = array_merge(
				$inventory['issues'] ?? [],
				self::local_activation_issues($library),
			);
			$manifest_issue = WPHAVE_Local_Font_Integrity::manifest_issue();
			if ($manifest_issue) {
				array_unshift($issues, $manifest_issue);
			}
			$groups = [
				'adobe' => self::configured_adobe_fonts(),
				'default' => WPHAVE_Font_Normalizer::registry(
					self::effective_default_fonts(),
					'default',
				),
				// Keep immutable available defaults separate from the currently effective
				// defaults so a React settings draft can derive its own preview correctly.
				'defaultAvailable' => WPHAVE_Font_Normalizer::registry(
					self::with_default_variant_urls(WPHAVE_Local_Font_Library::defaults()),
					'default',
				),
				'google' => self::configured_google_fonts(),
				'library' => $library,
				'local' => $local,
				// Canonical selectable providers, independent from runtime demand.
				'localAvailable' => array_values(self::available_local_providers()),
				'system' => WPHAVE_Font_Normalizer::system_fonts(),
			];
			$fonts = [];
			foreach ($groups as $group) {
				$fonts = array_merge($fonts, $group);
			}
			$active = self::active_fonts();
			$unique_fonts = WPHAVE_Font_Normalizer::unique_registry($fonts);

			return [
				'loading' => WPHAVE_Fonts::loading_mode(),
				'settings' => [
					'adobeSource' =>
						wphave_data_get('site_settings', 'fonts.external.adobe.source', '') ?: '',
					'googleAsync' => (bool) wphave_data_get(
						'site_settings',
						'fonts.external.google.async',
					),
					'fontDisplay' => WPHAVE_Fonts::font_display(),
					'usingDefaultFonts' => !empty($groups['default']),
				],
				'active' => $active,
				'fonts' => $unique_fonts,
				'groups' => $groups,
				'issues' => $issues,
				'counts' => [
					'all' => count($unique_fonts),
					'active' => count($active),
					'adobe' => count($groups['adobe']),
					'default' => count($groups['default']),
					'google' => count($groups['google']),
					'library' => count($groups['library']),
					'local' => count($groups['local']),
					'system' => count($groups['system']),
					'issues' => count($issues),
				],
			];
		}

		private static function loadable_local_fonts() {
			return array_values(
				array_filter(
					self::configured_local_fonts(),
					fn($font) => ($font['integrity'] ?? '') === 'valid',
				),
			);
		}

		/** DATA INTEGRITY INVARIANT: Assignments join intent to verified assets and never invent files. */

		public static function resolved_global_local_fonts() {
			$available = self::available_local_providers();
			$resolved = [];

			foreach (WPHAVE_Font_Assignments::global_local_fonts() as $assignment) {
				$key = self::family_key($assignment['family'] ?? '');
				if (!$key || empty($available[$key])) {
					continue;
				}
				$font = $available[$key];
				$font['roles'] = array_values(
					array_unique(array_merge($font['roles'] ?? [], $assignment['roles'] ?? [])),
				);
				$font['usageSources'] = array_values(
					array_unique(
						array_merge(
							$font['usageSources'] ?? [],
							$assignment['usageSources'] ?? [],
							['global-styles'],
						),
					),
				);
				$resolved[] = $font;
			}

			return $resolved;
		}

		/**
		 * Resolve one local provider per family without conflating family and origin.
		 *
		 * PROVIDER PRECEDENCE INVARIANT: Non-bundled assignments imply their only
		 * verified local provider. A bundled family uses its managed download only
		 * while that copy is explicitly active; otherwise its immutable plugin copy
		 * remains the deterministic fallback. This makes deactivate and delete safe
		 * without changing the semantic typography assignment.
		 */

		private static function available_local_providers() {
			$available = [];
			$active = array_fill_keys(self::active_local_keys(), true);

			foreach (
				WPHAVE_Font_Normalizer::registry(
					self::with_default_variant_urls(WPHAVE_Font_Assignments::default_fonts()),
					'default',
				)
				as $font
			) {
				$available[self::family_key($font['family'] ?? '')] = $font;
			}

			foreach (self::verified_library_fonts() as $font) {
				$key = self::family_key($font['family'] ?? '');
				if (!$key || ($font['integrity'] ?? '') !== 'valid') {
					continue;
				}

				$has_bundled_fallback = isset($available[$key]);
				if (
					self::should_use_managed_local_provider(
						$has_bundled_fallback,
						isset($active[$key]),
					)
				) {
					$available[$key] = $font;
				}
			}

			return $available;
		}

		/** Keep downloaded defaults opt-in while ordinary local assignments remain self-sufficient. */

		private static function should_use_managed_local_provider(
			$has_bundled_fallback,
			$is_active,
		) {
			return !$has_bundled_fallback || $is_active;
		}

		/** PRIVACY INVARIANT: Google assignments never enable an external source. */

		private static function resolved_global_google_fonts() {
			$available = [];
			foreach (self::configured_google_fonts() as $font) {
				$available[self::family_key($font['family'] ?? '')] = $font;
			}
			$resolved = [];

			foreach (WPHAVE_Font_Assignments::global_google_fonts() as $assignment) {
				$key = self::family_key($assignment['family'] ?? '');
				if (!$key || empty($available[$key])) {
					continue;
				}
				$font = $available[$key];
				$font['roles'] = array_values(
					array_unique(array_merge($font['roles'] ?? [], $assignment['roles'] ?? [])),
				);
				$font['usageSources'] = array_values(
					array_unique(
						array_merge(
							$font['usageSources'] ?? [],
							$assignment['usageSources'] ?? [],
							['global-styles'],
						),
					),
				);
				$resolved[] = $font;
			}

			return $resolved;
		}

		private static function select_provider($fonts) {
			$selected = [];
			foreach ($fonts as $font) {
				$key = self::family_key($font['family'] ?? '');
				if (!$key) {
					continue;
				}
				if (!isset($selected[$key])) {
					$selected[$key] = $font;
					continue;
				}

				$current = $selected[$key];
				$roles = array_values(
					array_unique(array_merge($current['roles'] ?? [], $font['roles'] ?? [])),
				);
				$usage_sources = array_values(
					array_unique(
						array_merge($current['usageSources'] ?? [], $font['usageSources'] ?? []),
					),
				);
				// SINGLE OUTPUT INVARIANT: Exactly one provider owns a family in the
				// effective snapshot. A verified managed local copy outranks the bundled
				// recovery copy, which outranks remote and invalid providers. Consumers can
				// therefore generate CSS and preloads without duplicate family providers.
				$replace = self::provider_priority($font) > self::provider_priority($current);
				if ($replace) {
					$font['roles'] = $roles;
					$font['usageSources'] = $usage_sources;
					$selected[$key] = $font;
				} else {
					$selected[$key]['roles'] = $roles;
					$selected[$key]['usageSources'] = $usage_sources;
				}
			}

			return array_values($selected);
		}

		/** Return a stable provider rank independent from merge order. */

		private static function provider_priority($font) {
			$type = $font['type'] ?? '';
			$integrity = $font['integrity'] ?? '';
			$is_default = !empty($font['default']) || ($font['source'] ?? '') === 'default';

			if ($type === 'local' && $integrity === 'valid' && !$is_default) {
				return 30;
			}
			if ($type === 'local' && $integrity === 'valid' && $is_default) {
				return 20;
			}

			return 10;
		}

		private static function mark_loadable($fonts, $mode) {
			return array_map(function ($font) use ($mode) {
				$type = $font['type'] ?? '';
				if ($type === 'system') {
					$font['loadable'] = false;
				} elseif ($mode === 'disabled' || ($mode === 'local' && $type !== 'local')) {
					$font['loadable'] = false;
				} elseif (!empty($font['default']) || ($font['source'] ?? '') === 'default') {
					$font['loadable'] = true;
				} else {
					$font['loadable'] = ($font['integrity'] ?? 'valid') === 'valid';
				}
				return $font;
			}, $fonts);
		}

		private static function family_key($family) {
			return WPHAVE_Font_Identity::key($family);
		}

		/** Attach browser-loadable URLs to immutable bundled font variants. */

		private static function with_default_variant_urls($fonts) {
			$base_url = WPHAVE_Local_Font_Library::default_base_url();

			return array_map(
				static function ($font) use ($base_url) {
					if (!is_array($font)) {
						return $font;
					}

					// RUNTIME URL INVARIANT: Every local variant exposed to browser consumers
					// carries an absolute verified URL. A bare filename would resolve against
					// the editor document root and produce a misleading same-origin 404.
					$font['variants'] = array_map(
						static function ($variant) use ($base_url) {
							if (!is_array($variant)) {
								return $variant;
							}
							$file = sanitize_file_name($variant['file'] ?? '');
							if ($file) {
								$variant['url'] = $base_url . rawurlencode($file);
							}

							return $variant;
						},
						is_array($font['variants'] ?? null) ? $font['variants'] : [],
					);

					return $font;
				},
				is_array($fonts) ? $fonts : [],
			);
		}

		private static function active_local_keys() {
			$active = wphave_data_get('site_settings', 'fonts.local.active', []);
			$active = array_filter(is_array($active) ? $active : [], 'is_string');

			return array_values(
				array_unique(array_filter(array_map(['WPHAVE_Font_Identity', 'key'], $active))),
			);
		}

		private static function verified_library_fonts() {
			$family_states = WPHAVE_Local_Font_Integrity::audit()['familyStates'] ?? [];
			return array_map(function ($font) use ($family_states) {
				$font['key'] = self::family_key($font['family'] ?? '');
				$font['integrity'] = !empty($font['variants']) ? 'valid' : 'missing-files';
				if (in_array('google-fonts', $font['sources'] ?? [$font['source'] ?? ''], true)) {
					$license_file = sanitize_file_name($font['license']['file'] ?? '');
					$license_path = $license_file
						? path_join(
							WPHAVE_Local_Font_Library::upload_dir()['basedir'] ?? '',
							$license_file,
						)
						: '';
					if (!$license_path || !is_readable($license_path)) {
						$font['integrity'] = 'missing-license';
					}
				}
				if (isset($family_states[$font['key']])) {
					$font['integrity'] = $family_states[$font['key']];
				}
				$font['loadable'] = $font['integrity'] === 'valid';

				return $font;
			}, WPHAVE_Local_Font_Library::fonts());
		}

		private static function local_activation_issues($library) {
			$available = array_fill_keys(
				array_map(fn($font) => self::family_key($font['family'] ?? ''), $library),
				true,
			);
			$issues = [];
			foreach (self::active_local_keys() as $key) {
				if (isset($available[$key])) {
					continue;
				}
				$issues[] = [
					'key' => $key,
					'family' => $key,
					'type' => 'local',
					'source' => 'local',
					'integrity' => 'missing-family',
					'loadable' => false,
				];
			}

			return $issues;
		}
	}
endif;
