<?php

if ( ! class_exists( 'WPHAVE_Local_Font_Integrity' ) ) :

	/** OWNERSHIP INVARIANT: Integrity audits report problems and never repair files. */

	class WPHAVE_Local_Font_Integrity {

		public static function audit() {
			return WPHAVE_Local_Fonts::integrity_audit();
		}

		public static function manifest_issue() {
			return WPHAVE_Local_Fonts::manifest_issue();
		}
	}

endif;
