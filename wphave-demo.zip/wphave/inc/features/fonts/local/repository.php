<?php

require_once wphave_dir() . 'inc/features/security/boundaries/index.php';
require_once wphave_dir() . 'inc/background-jobs/functions.php';

if (!class_exists('WPHAVE_Local_Font_Repository')):
	/**
	 * Handles local font files, local font discovery and @font-face CSS output.
	 */

	class WPHAVE_Local_Font_Repository {
		const MANIFEST_FILE = 'wphave-fonts.json';
		const CLEANUP_OPTION = 'wphave_font_cleanup_queue';
		const CLEANUP_HOOK = 'wphave_font_cleanup_retry';
		const MAX_FAMILIES_PER_REQUEST = 50;
		const MAX_VARIANTS_PER_FAMILY = 64;
		const MAX_RECORDS_PER_REQUEST = 200;
		const SOURCES = ['upload', 'google-fonts'];
		private static $manifest_lock_held = false;
		private static $delete_lock_held = false;
		private static $manifest_cache = null;
		private static $manifest_cache_loaded = false;
		private static $library_cache = null;
		private static $integrity_cache = null;

		public static function default_definitions() {
			$manifest = __DIR__ . '/../assets/default-fonts/default-fonts.php';
			$fonts = is_readable($manifest) ? require $manifest : [];

			return is_array($fonts) ? $fonts : [];
		}

		/**
		 * Discover supported font files without optional libc glob extensions.
		 *
		 * The optional glob brace-expansion flag is unavailable in PHP WASM and
		 * on some non-GNU systems.
		 * Keep this filesystem boundary portable and its result deterministic.
		 *
		 * @param string $base_path Local font directory.
		 * @return array
		 */
		private static function font_files($base_path) {
			if (!$base_path || !is_dir($base_path)) {
				return [];
			}

			$files = [];

			foreach (['ttf', 'otf', 'woff', 'woff2'] as $extension) {
				$matches = glob(trailingslashit($base_path) . '*.' . $extension);

				if (is_array($matches)) {
					$files = array_merge($files, $matches);
				}
			}

			$files = array_values(array_unique($files));
			sort($files, SORT_STRING);

			return $files;
		}

		/** Identify families that always retain an immutable bundled fallback. */

		public static function is_default_family($family) {
			$key = WPHAVE_Font_Identity::key($family);
			if (!$key) {
				return false;
			}

			foreach (self::default_definitions() as $font) {
				if (WPHAVE_Font_Identity::key($font['family'] ?? '') === $key) {
					return true;
				}
			}

			return false;
		}

		/**
		 * Scan uploads/fonts and build a library of available local font files.
		 *
		 * @return array
		 */

		public static function library_fonts() {
			if (is_array(self::$library_cache)) {
				return self::$library_cache;
			}
			$upload_dir = self::upload_dir();
			$base_path = $upload_dir['basedir'] ?? '';
			$base_url = $upload_dir['baseurl'] ?? '';

			if (!$base_path || !$base_url || !is_dir($base_path)) {
				return self::$library_cache = [];
			}

			$files = self::font_files($base_path);

			if (!is_array($files) || empty($files)) {
				return self::$library_cache = [];
			}

			$fonts = [];
			$manifest = self::manifest();
			// Discovery is deliberately read-only. Pruning metadata here used to turn an
			// innocent registry read into a competing manifest write during installations.
			$manifest = is_array($manifest) ? $manifest : [];

			foreach ($files as $file_path) {
				$file_name = basename($file_path);
				$manifest_data =
					isset($manifest[$file_name]) && is_array($manifest[$file_name])
						? $manifest[$file_name]
						: [];

				// A file is not a usable font-library record until its parsed metadata was
				// committed. Guessing from filenames exposed incomplete uploads and invented
				// families; pre-release legacy files deliberately do not bypass this contract.
				$manifest_data = self::normalized_manifest_record($manifest_data);
				if (!$manifest_data) {
					continue;
				}

				$font_data = $manifest_data;
				$family = $font_data['family'];
				$family_key = strtolower(WPHAVE_Fonts::canonical_font_family($family));

				if (!isset($fonts[$family_key])) {
					$license = is_array($font_data['license'] ?? null)
						? $font_data['license']
						: null;
					if ($license && !empty($license['file'])) {
						$license['url'] =
							trailingslashit($base_url) . sanitize_file_name($license['file']);
					}
					$fonts[$family_key] = [
						'family' => $family,
						'type' => 'local',
						'source' => $font_data['source'] ?? 'upload',
						'sources' => [$font_data['source'] ?? 'upload'],
						'license' => $license,
						'variants' => [],
					];
				} elseif (
					!in_array(
						$font_data['source'] ?? 'upload',
						$fonts[$family_key]['sources'],
						true,
					)
				) {
					$fonts[$family_key]['sources'][] = $font_data['source'] ?? 'upload';
					$fonts[$family_key]['source'] = 'mixed';
				}
				// A family may contain manual and downloaded variants. Preserve the verified
				// Google license regardless of which filename glob() returned first.
				if (
					empty($fonts[$family_key]['license']) &&
					is_array($font_data['license'] ?? null)
				) {
					$license = $font_data['license'];
					if (!empty($license['file'])) {
						$license['url'] =
							trailingslashit($base_url) . sanitize_file_name($license['file']);
					}
					$fonts[$family_key]['license'] = $license;
				}

				$fonts[$family_key]['variants'][] = [
					'file' => $file_name,
					'url' => trailingslashit($base_url) . $file_name,
					'size' => is_readable($file_path) ? (int) filesize($file_path) : 0,
					'checksum' => $font_data['sha256'],
					'fontStyle' => $font_data['style'],
					'fontWeight' => $font_data['weight'],
					'unicodeRange' => $font_data['unicodeRange'] ?? '',
					'subset' => $font_data['subset'] ?? '',
				];
			}

			foreach ($fonts as $family_key => $font) {
				$fonts[$family_key]['variants'] = self::unique_variants($font['variants']);
			}

			return self::$library_cache = array_values($fonts);
		}

		/**
		 * Compare physical font files with the manifest without changing either side.
		 *
		 * Manual filesystem changes must fail visibly, never trigger implicit imports or
		 * deletion. Consumers use familyStates to keep incomplete families unloadable;
		 * administrators receive actionable issues without exposing absolute paths.
		 *
		 * Do not add repair behavior here. Reconstructing files, hashes, metadata or
		 * licenses creates a second, ambiguous state machine beside installation and
		 * proved too complex to make reliable across concurrent requests and customer
		 * filesystems. The supported recovery is delete plus validated reinstallation;
		 * see this directory's README.md for the complete architecture decision.
		 */

		public static function integrity_audit() {
			if (is_array(self::$integrity_cache)) {
				return self::$integrity_cache;
			}
			$upload_dir = self::upload_dir();
			$base_path = $upload_dir['basedir'] ?? '';
			$manifest = self::manifest(true);
			if (is_wp_error($manifest)) {
				return self::$integrity_cache = ['issues' => [], 'familyStates' => []];
			}

			$physical = [];
			$files = self::font_files($base_path);
			foreach (is_array($files) ? $files : [] as $file) {
				$physical[basename($file)] = true;
			}

			$issues = [];
			$family_states = [];
			$registered = [];
			foreach (is_array($manifest) ? $manifest : [] as $file => $record) {
				$file = sanitize_file_name($file);
				if (
					!$file ||
					!is_array($record) ||
					!in_array(
						strtolower(pathinfo($file, PATHINFO_EXTENSION)),
						['ttf', 'otf', 'woff', 'woff2'],
						true,
					)
				) {
					continue;
				}
				$registered[$file] = true;
				$family = WPHAVE_Fonts::canonical_font_family($record['family'] ?? '');
				$family_key = WPHAVE_Font_Identity::key($family);
				if (!self::normalized_manifest_record($record)) {
					if ($family_key) {
						$family_states[$family_key] = 'invalid-metadata';
					}
					$issues[] = [
						'key' => 'invalid-record:' . $file,
						'family' => $family,
						'file' => $file,
						'type' => 'local',
						'source' => 'manifest',
						'integrity' => 'invalid-metadata',
						'loadable' => false,
						'message' => sprintf(
							__(
								'The registered metadata for %s is invalid. Delete the incomplete family and install it again.',
								'wphave',
							),
							$file,
						),
					];
					continue;
				}
				if (empty($physical[$file])) {
					if ($family_key) {
						$family_states[$family_key] = 'missing-variant';
					}
					$issues[] = [
						'key' => 'missing-file:' . $file,
						'family' => $family,
						'file' => $file,
						'type' => 'local',
						'source' => 'manifest',
						'integrity' => 'missing-file',
						'loadable' => false,
						'message' => sprintf(
							__(
								'The registered font file %s is missing. Delete the incomplete family and install it again.',
								'wphave',
							),
							$file,
						),
					];
				} elseif (
					!self::verified_file_hash(
						path_join($base_path, $file),
						(string) ($record['sha256'] ?? ''),
					)
				) {
					if ($family_key) {
						$family_states[$family_key] = 'checksum-mismatch';
					}
					$issues[] = [
						'key' => 'checksum-mismatch:' . $file,
						'family' => $family,
						'file' => $file,
						'type' => 'local',
						'source' => 'manifest',
						'integrity' => 'checksum-mismatch',
						'loadable' => false,
						'message' => sprintf(
							__(
								'The registered font file %s no longer matches its installation. Delete the incomplete family and install it again.',
								'wphave',
							),
							$file,
						),
					];
				}

				if (($record['source'] ?? '') === 'google-fonts') {
					$license_file = sanitize_file_name($record['license']['file'] ?? '');
					$license_path = $license_file ? path_join($base_path, $license_file) : '';
					$license_hash = sanitize_text_field($record['license']['sha256'] ?? '');
					if (!self::verified_file_hash($license_path, $license_hash)) {
						if ($family_key) {
							$family_states[$family_key] = 'missing-license';
						}
						$issue_key = 'missing-license:' . ($family_key ?: $file);
						$issues[$issue_key] = [
							'key' => $issue_key,
							'family' => $family,
							'file' => $license_file,
							'type' => 'local',
							'source' => 'google-fonts',
							'integrity' => 'missing-license',
							'loadable' => false,
							'message' => sprintf(
								__(
									'The verified license for %s is missing or unreadable. Delete the incomplete family and install it again.',
									'wphave',
								),
								$family ?: $file,
							),
						];
					}
				}
			}

			foreach (array_diff_key($physical, $registered) as $file => $_exists) {
				$issues[] = [
					'key' => 'unregistered-file:' . $file,
					'family' => '',
					'file' => $file,
					'type' => 'local',
					'source' => 'filesystem',
					'integrity' => 'unregistered-file',
					'loadable' => false,
					'message' => sprintf(
						__(
							'The font file %s is not registered and is ignored. Upload it through the Font Manager to create a validated installation.',
							'wphave',
						),
						$file,
					),
				];
			}

			return self::$integrity_cache = [
				'issues' => array_values($issues),
				'familyStates' => $family_states,
			];
		}

		/**
		 * Delete an inactive local family and its manifest records.
		 *
		 * Files remain protected while the family is active, so a stale UI request
		 * cannot break frontend typography. Plugin-owned defaults are never located
		 * in uploads/fonts and therefore cannot be deleted through this endpoint.
		 *
		 * @param string $family Canonical family name.
		 * @return array|WP_Error
		 */

		public static function delete_family($family) {
			$family = sanitize_text_field($family);
			if (!class_exists('WPHAVE_Option_Mutations')) {
				return new WP_Error(
					'font_lock_unavailable',
					__('Safe font file locking is not available.', 'wphave'),
					['status' => 503],
				);
			}

			if (!self::$delete_lock_held) {
				return WPHAVE_Option_Mutations::with_lock('local_font_manifest', function () use (
					$family,
				) {
					self::$delete_lock_held = true;
					try {
						return self::delete_family($family);
					} finally {
						self::$delete_lock_held = false;
					}
				});
			}

			$active = wphave_data_get('site_settings', 'fonts.local.active', []);

			if (!$family) {
				return new WP_Error('missing_font_family', __('Missing font family.', 'wphave'), [
					'status' => 400,
				]);
			}

			// PROVIDER FALLBACK INVARIANT: A managed copy of a bundled family may be
			// removed while typography still references the family. The resolver will
			// atomically expose the immutable plugin copy on its next read. Families
			// without that recovery provider remain protected from destructive deletion.
			if (
				WPHAVE_Font_Assignments::is_local_family_used($family) &&
				!self::is_default_family($family)
			) {
				return new WP_Error(
					'font_still_in_use',
					__(
						'This font is assigned to global typography and cannot be deleted.',
						'wphave',
					),
					['status' => 409],
				);
			}

			$library_font = null;
			foreach (self::library_fonts() as $font) {
				if (
					strtolower(WPHAVE_Fonts::canonical_font_family($font['family'] ?? '')) ===
					strtolower(WPHAVE_Fonts::canonical_font_family($family))
				) {
					$library_font = $font;
					break;
				}
			}

			$upload_dir = self::upload_dir();
			$base_path = $upload_dir['basedir'] ?? '';
			$manifest = self::manifest(true);

			if (is_wp_error($manifest)) {
				return $manifest;
			}
			if (!$library_font) {
				$variants = [];
				$license = null;
				foreach ($manifest as $file => $record) {
					if (
						!is_array($record) ||
						WPHAVE_Font_Identity::key($record['family'] ?? '') !==
							WPHAVE_Font_Identity::key($family)
					) {
						continue;
					}
					$variants[] = ['file' => sanitize_file_name($file)];
					if (!$license && is_array($record['license'] ?? null)) {
						$license = $record['license'];
					}
				}
				if (empty($variants)) {
					return new WP_Error(
						'font_not_found',
						__('The local font was not found.', 'wphave'),
						['status' => 404],
					);
				}
				$library_font = [
					'family' => $family,
					'variants' => $variants,
					'license' => $license,
				];
			}

			$deleted = [];
			$staged = [];
			$staged_checksums = [];

			foreach ($library_font['variants'] ?? [] as $variant) {
				$file = sanitize_file_name($variant['file'] ?? '');
				$path = $file ? path_join($base_path, $file) : '';
				if ($file) {
					unset($manifest[$file]);
				}

				if ($path && is_file($path)) {
					$staged_path =
						$path . '.wphave-delete-' . wp_generate_password(12, false, false);

					if (!rename($path, $staged_path)) {
						$restore_failed = self::restore_staged_files($staged, $staged_checksums);
						if ($restore_failed) {
							return new WP_Error(
								'font_delete_restore_failed',
								__(
									'The font deletion failed and some files could not be restored.',
									'wphave',
								),
								['status' => 500, 'files' => $restore_failed],
							);
						}
						return new WP_Error(
							'font_delete_staging_failed',
							__('The font files could not be prepared for safe deletion.', 'wphave'),
							['status' => 500],
						);
					}

					$staged[$path] = $staged_path;
					$staged_checksums[$staged_path] = self::staged_checksum($staged_path);
					$deleted[] = $file;
				}
			}

			$license_file = sanitize_file_name($library_font['license']['file'] ?? '');
			$license_path = $license_file ? path_join($base_path, $license_file) : '';
			if ($license_path && is_file($license_path)) {
				$staged_path =
					$license_path . '.wphave-delete-' . wp_generate_password(12, false, false);
				if (!rename($license_path, $staged_path)) {
					$restore_failed = self::restore_staged_files($staged, $staged_checksums);
					if ($restore_failed) {
						return new WP_Error(
							'font_delete_restore_failed',
							__(
								'The font deletion failed and some files could not be restored.',
								'wphave',
							),
							['status' => 500, 'files' => $restore_failed],
						);
					}
					return new WP_Error(
						'font_delete_staging_failed',
						__('The font license could not be prepared for safe deletion.', 'wphave'),
						['status' => 500],
					);
				}
				$staged[$license_path] = $staged_path;
				$staged_checksums[$staged_path] = self::staged_checksum($staged_path);
				$deleted[] = $license_file;
			}

			if (!self::write_manifest($manifest)) {
				$restore_failed = self::restore_staged_files($staged, $staged_checksums);
				if ($restore_failed) {
					return new WP_Error(
						'font_delete_restore_failed',
						__(
							'The font metadata update failed and some font files could not be restored.',
							'wphave',
						),
						['status' => 500, 'files' => $restore_failed],
					);
				}
				return new WP_Error(
					'font_manifest_write_failed',
					__(
						'The font metadata could not be updated. No font files were deleted.',
						'wphave',
					),
					['status' => 500],
				);
			}
			$remaining_active = array_values(
				array_filter(
					is_array($active) ? $active : [],
					fn($active_family) => WPHAVE_Font_Identity::key($active_family) !==
						WPHAVE_Font_Identity::key($family),
				),
			);
			if (function_exists('wphave_data_set')) {
				wphave_data_set('site_settings', 'fonts.local.active', $remaining_active);
			}

			$cleanup_failed = self::delete_staged_files($staged_checksums);
			if ($cleanup_failed) {
				return new WP_Error(
					'font_delete_cleanup_failed',
					__(
						'The font was removed from the library, but temporary files could not be deleted.',
						'wphave',
					),
					['status' => 500, 'files' => $cleanup_failed],
				);
			}

			return ['deleted' => $deleted];
		}

		/** Delete one unregistered upload after client-side metadata parsing failed. */

		public static function delete_file($file) {
			$file = sanitize_file_name($file);
			if (!class_exists('WPHAVE_Option_Mutations')) {
				return new WP_Error(
					'font_lock_unavailable',
					__('Safe font file locking is not available.', 'wphave'),
					['status' => 503],
				);
			}

			if (!self::$delete_lock_held) {
				return WPHAVE_Option_Mutations::with_lock('local_font_manifest', function () use (
					$file,
				) {
					self::$delete_lock_held = true;
					try {
						return self::delete_file($file);
					} finally {
						self::$delete_lock_held = false;
					}
				});
			}

			if (!$file) {
				return new WP_Error('missing_font_file', __('Missing font file.', 'wphave'), [
					'status' => 400,
				]);
			}

			$manifest = self::manifest(true);
			if (is_wp_error($manifest)) {
				return $manifest;
			}
			// This endpoint is intentionally limited to physical orphans. Registered
			// variants belong to an atomic family installation and must be removed only
			// through delete_family(), otherwise one click could create a partial font.
			if (isset($manifest[$file])) {
				return new WP_Error(
					'font_file_registered',
					__(
						'Registered font files can only be deleted together with their font family.',
						'wphave',
					),
					['status' => 409],
				);
			}
			$upload_dir = self::upload_dir();
			$path = path_join($upload_dir['basedir'] ?? '', $file);

			if (!is_file($path)) {
				return new WP_Error(
					'font_file_not_found',
					__('The local font file was not found.', 'wphave'),
					['status' => 404],
				);
			}

			$staged_path = $path . '.wphave-delete-' . wp_generate_password(12, false, false);
			if (!rename($path, $staged_path)) {
				return new WP_Error(
					'font_delete_staging_failed',
					__('The font file could not be prepared for safe deletion.', 'wphave'),
					['status' => 500],
				);
			}

			$checksum = self::staged_checksum($staged_path);
			if ($checksum) {
				try {
					WPHAVE_Security_Conditional_File::remove_if_matches(
						$staged_path,
						$checksum,
						__('The staged font changed before deletion.', 'wphave'),
					);
				} catch (RuntimeException $error) {
					// Preserve a replaced stage for operator reconciliation.
				}
			}
			$deleted =
				!file_exists($path) && !is_link($path) &&
				!file_exists($staged_path) && !is_link($staged_path);
			if (!$deleted && $checksum) {
				self::queue_staged_cleanup([basename($staged_path) => $checksum]);
			}

			return $deleted
				? ['deleted' => $file]
				: new WP_Error(
					'font_file_delete_failed',
					__('The local font file could not be deleted.', 'wphave'),
					['status' => 500],
				);
		}

		/**
		 * Remove duplicate local font variants by style, weight and unicode range.
		 *
		 * Google can provide several files for one weight, each covering a different
		 * character range. Collapsing those files by weight would create incomplete
		 * fonts, so unicodeRange is part of the identity whenever it is available.
		 *
		 * @param array $variants Local font variant definitions.
		 * @return array
		 */

		public static function unique_variants($variants) {
			return WPHAVE_Font_Normalizer::variants($variants);
		}

		/**
		 * Persist metadata that cannot be reconstructed from downloaded filenames.
		 *
		 * The manifest deliberately contains only public font metadata. It lets the
		 * library survive a page reload without losing unicode ranges or family names.
		 *
		 * @param string $family Font family.
		 * @param array $variants Installed variants.
		 * @param string $source Trusted origin assigned by the server-side workflow.
		 * @param array $license Verified license metadata required for Google downloads.
		 * @return bool|WP_Error
		 */

		public static function record_variants(
			$family,
			$variants,
			$source = 'google-fonts',
			$license = [],
		) {
			$source = sanitize_key($source);
			if (
				!is_array($variants) ||
				empty($variants) ||
				count($variants) > self::MAX_VARIANTS_PER_FAMILY
			) {
				return new WP_Error(
					'invalid_font_metadata_count',
					__('The font metadata contains an invalid number of variants.', 'wphave'),
					['status' => 400],
				);
			}
			if (!WPHAVE_Font_Identity::is_safe($family)) {
				return new WP_Error(
					'invalid_font_family',
					__('The font family contains unsafe characters.', 'wphave'),
					['status' => 400],
				);
			}
			if (!in_array($source, self::SOURCES, true)) {
				return new WP_Error(
					'invalid_font_source',
					__('The font source is not supported.', 'wphave'),
					['status' => 400],
				);
			}
			// PROVIDER IDENTITY INVARIANT: A verified Google installation may shadow a
			// bundled family without modifying plugin assets. Arbitrary uploads remain
			// blocked because a claimed family name alone cannot establish that the file
			// is a trustworthy replacement for WPHAVE's recovery provider.
			if (self::is_default_family($family) && $source !== 'google-fonts') {
				return new WP_Error(
					'reserved_font_family',
					__(
						'This bundled font family can only be supplemented by a verified Google Fonts download.',
						'wphave',
					),
					['status' => 409],
				);
			}
			if (!class_exists('WPHAVE_Option_Mutations')) {
				return new WP_Error(
					'font_lock_unavailable',
					__('Safe font metadata locking is not available.', 'wphave'),
					['status' => 503],
				);
			}

			if (!self::$manifest_lock_held) {
				return WPHAVE_Option_Mutations::with_lock('local_font_manifest', function () use (
					$family,
					$variants,
					$source,
					$license,
				) {
					self::$manifest_lock_held = true;
					try {
						self::invalidate_cache();
						return self::record_variants($family, $variants, $source, $license);
					} finally {
						self::$manifest_lock_held = false;
					}
				});
			}

			$upload_dir = self::upload_dir();
			$base_path = $upload_dir['basedir'] ?? '';

			if (!$base_path || !is_array($variants)) {
				return false;
			}

			$manifest = self::manifest(true);

			if (is_wp_error($manifest)) {
				return $manifest;
			}

			$records = [];
			$license_record = [];
			if ($source === 'google-fonts') {
				$license_file = sanitize_file_name($license['file'] ?? '');
				$license_type = sanitize_text_field($license['type'] ?? '');
				$license_url = esc_url_raw($license['sourceUrl'] ?? '', ['https']);
				$license_host = strtolower(wp_parse_url($license_url, PHP_URL_HOST) ?: '');
				$license_path = (string) (wp_parse_url($license_url, PHP_URL_PATH) ?: '');
				$license_hash = sanitize_text_field($license['sha256'] ?? '');
				$official_path = (bool) preg_match(
					'#^/google/fonts/(?:main|[a-f0-9]{40})/(?:ofl|apache|ufl)/[a-z0-9]+/(?:OFL|LICENSE|LICENCE|UFL)\.txt$#',
					$license_path,
				);
				$license_local_path = $license_file ? path_join($base_path, $license_file) : '';
				if (
					!in_array($license_type, ['OFL-1.1', 'Apache-2.0', 'UFL-1.0'], true) ||
					!self::verified_file_hash($license_local_path, $license_hash) ||
					$license_host !== 'raw.githubusercontent.com' ||
					!$official_path
				) {
					return new WP_Error(
						'invalid_font_license_metadata',
						__(
							'Verified license metadata is required for every downloaded Google Font.',
							'wphave',
						),
						['status' => 400],
					);
				}
				$license_record = [
					'type' => $license_type,
					'file' => $license_file,
					'sourceUrl' => $license_url,
					'copyright' => sanitize_textarea_field($license['copyright'] ?? ''),
					'sha256' => $license_hash,
				];
			}

			foreach ($variants as $variant) {
				$file = sanitize_file_name($variant['file'] ?? '');

				$file_path = $file ? path_join($base_path, $file) : '';
				if (
					!$file ||
					!WPHAVE_Font_File_Security::is_supported($file) ||
					!WPHAVE_Font_File_Security::has_valid_signature($file_path)
				) {
					return new WP_Error(
						'invalid_font_metadata_file',
						__(
							'Every font metadata record must reference an existing uploaded font file.',
							'wphave',
						),
						['status' => 400, 'file' => $file],
					);
				}

				$style = sanitize_key($variant['fontStyle'] ?? 'normal');
				$weight = sanitize_text_field($variant['fontWeight'] ?? '400');
				$weight = WPHAVE_Fonts::font_weight($weight);
				if (!in_array($style, ['normal', 'italic', 'oblique'], true) || !$weight) {
					return new WP_Error(
						'invalid_font_metadata_value',
						__('Font style or weight metadata is invalid.', 'wphave'),
						['status' => 400],
					);
				}
				if (isset($records[$file]) || isset($manifest[$file])) {
					return new WP_Error(
						'duplicate_font_metadata_file',
						__('A font file can belong to only one metadata record.', 'wphave'),
						['status' => 400, 'file' => $file],
					);
				}

				$records[$file] = [
					'family' => WPHAVE_Fonts::canonical_font_family(sanitize_text_field($family)),
					'style' => $style,
					'weight' => $weight,
					'unicodeRange' => self::sanitize_unicode_range($variant['unicodeRange'] ?? ''),
					'subset' => sanitize_key($variant['subset'] ?? ''),
					'source' => $source,
					'sha256' => hash_file('sha256', path_join($base_path, $file)),
					'license' => $license_record ?: null,
				];
			}

			if (count($records) !== count($variants)) {
				return new WP_Error(
					'incomplete_font_metadata',
					__('The font metadata transaction is incomplete.', 'wphave'),
					['status' => 400],
				);
			}
			$manifest = array_replace($manifest, $records);

			return self::write_manifest($manifest);
		}

		/**
		 * Persist several manually parsed families in one manifest transaction.
		 *
		 * A browser upload may contain multiple families. Validating all records before
		 * the single write prevents a late invalid family from leaving an earlier one
		 * committed even though the UI reports the whole batch as failed.
		 */

		public static function record_families($fonts, $source = 'upload') {
			// Multi-family records originate only from browser-parsed manual uploads.
			// Google ownership requires the dedicated installer and verified license data.
			$source = 'upload';
			if (
				!is_array($fonts) ||
				empty($fonts) ||
				count($fonts) > self::MAX_FAMILIES_PER_REQUEST
			) {
				return new WP_Error(
					'invalid_font_metadata_count',
					__('The font metadata contains an invalid number of families.', 'wphave'),
					['status' => 400],
				);
			}
			if (!class_exists('WPHAVE_Option_Mutations')) {
				return new WP_Error(
					'font_lock_unavailable',
					__('Safe font metadata locking is not available.', 'wphave'),
					['status' => 503],
				);
			}

			if (!self::$manifest_lock_held) {
				return WPHAVE_Option_Mutations::with_lock('local_font_manifest', function () use (
					$fonts,
					$source,
				) {
					self::$manifest_lock_held = true;
					try {
						self::invalidate_cache();
						return self::record_families($fonts, $source);
					} finally {
						self::$manifest_lock_held = false;
					}
				});
			}

			$upload_dir = self::upload_dir();
			$base_path = $upload_dir['basedir'] ?? '';
			$manifest = self::manifest(true);
			if (is_wp_error($manifest)) {
				return $manifest;
			}
			if (!$base_path || !is_array($fonts) || empty($fonts)) {
				return new WP_Error(
					'invalid_font_metadata',
					__('Complete local font metadata is required.', 'wphave'),
					['status' => 400],
				);
			}

			$records = [];
			$variant_count = 0;
			foreach ($fonts as $font) {
				$family = sanitize_text_field($font['family'] ?? '');
				$variants = $font['variants'] ?? [];
				if (
					!WPHAVE_Font_Identity::is_safe($family) ||
					!is_array($variants) ||
					empty($variants) ||
					count($variants) > self::MAX_VARIANTS_PER_FAMILY
				) {
					return new WP_Error(
						'invalid_font_metadata',
						__('Complete and safe local font metadata is required.', 'wphave'),
						['status' => 400],
					);
				}
				// UPLOAD TRUST INVARIANT: Browser-parsed uploads never shadow immutable
				// defaults. Only the server-side Google installer can establish a licensed,
				// signature-checked managed provider for the same family identity.
				if (self::is_default_family($family)) {
					return new WP_Error(
						'reserved_font_family',
						__(
							'This bundled font family can only be supplemented by a verified Google Fonts download.',
							'wphave',
						),
						['status' => 409],
					);
				}
				$variant_count += count($variants);
				if ($variant_count > self::MAX_RECORDS_PER_REQUEST) {
					return new WP_Error(
						'invalid_font_metadata_count',
						__('The font metadata contains too many file records.', 'wphave'),
						['status' => 413],
					);
				}

				foreach ($variants as $variant) {
					$file = sanitize_file_name($variant['file'] ?? '');
					$style = sanitize_key($variant['fontStyle'] ?? 'normal');
					$weight = sanitize_text_field($variant['fontWeight'] ?? '400');
					$file_path = $file ? path_join($base_path, $file) : '';
					if (
						!$file ||
						!WPHAVE_Font_File_Security::is_supported($file) ||
						!WPHAVE_Font_File_Security::has_valid_signature($file_path)
					) {
						return new WP_Error(
							'invalid_font_metadata_file',
							__(
								'Every font metadata record must reference a supported uploaded font file.',
								'wphave',
							),
							['status' => 400, 'file' => $file],
						);
					}
					$weight = WPHAVE_Fonts::font_weight($weight);
					if (!in_array($style, ['normal', 'italic', 'oblique'], true) || !$weight) {
						return new WP_Error(
							'invalid_font_metadata_value',
							__('Font style or weight metadata is invalid.', 'wphave'),
							['status' => 400],
						);
					}
					if (isset($records[$file]) || isset($manifest[$file])) {
						return new WP_Error(
							'duplicate_font_metadata_file',
							__('A font file can belong to only one metadata record.', 'wphave'),
							['status' => 400, 'file' => $file],
						);
					}

					$records[$file] = [
						'family' => WPHAVE_Fonts::canonical_font_family($family),
						'style' => $style,
						'weight' => $weight,
						'unicodeRange' => self::sanitize_unicode_range(
							$variant['unicodeRange'] ?? '',
						),
						'subset' => sanitize_key($variant['subset'] ?? ''),
						'source' => $source,
						'sha256' => hash_file('sha256', $file_path),
					];
				}
			}
			if (count($records) !== $variant_count) {
				return new WP_Error(
					'duplicate_font_metadata_file',
					__('A font file can belong to only one metadata record.', 'wphave'),
					['status' => 400],
				);
			}

			return self::write_manifest(array_replace($manifest, $records));
		}

		/**
		 * Remove exact manifest records during a higher-level rollback.
		 * Callers must pass only files created by their own transaction.
		 */

		public static function remove_manifest_records($files) {
			if (!class_exists('WPHAVE_Option_Mutations')) {
				return new WP_Error(
					'font_lock_unavailable',
					__('Safe font metadata locking is not available.', 'wphave'),
					['status' => 503],
				);
			}

			if (!self::$manifest_lock_held) {
				return WPHAVE_Option_Mutations::with_lock('local_font_manifest', function () use (
					$files,
				) {
					self::$manifest_lock_held = true;
					try {
						self::invalidate_cache();
						return self::remove_manifest_records($files);
					} finally {
						self::$manifest_lock_held = false;
					}
				});
			}

			$manifest = self::manifest(true);
			if (is_wp_error($manifest)) {
				return $manifest;
			}

			foreach (is_array($files) ? $files : [] as $file) {
				unset($manifest[sanitize_file_name($file)]);
			}

			return self::write_manifest($manifest)
				? true
				: new WP_Error(
					'font_manifest_write_failed',
					__('The local font metadata rollback could not be saved.', 'wphave'),
					['status' => 500],
				);
		}

		/** Persist browser-parsed metadata for manually uploaded font files. */

		public static function record($fonts, $family, $variants, $source = 'upload') {
			$family = sanitize_text_field($family);
			// Browser-parsed files are always manual uploads. Only the locked Google
			// installer may assert google-fonts after it has verified and stored a license.
			$source = 'upload';

			if (is_array($fonts) && !empty($fonts)) {
				$result = self::record_families($fonts, $source);
			} elseif (!$family || !is_array($variants) || empty($variants)) {
				return new WP_Error(
					'invalid_font_metadata',
					__('Complete local font metadata is required.', 'wphave'),
					['status' => 400],
				);
			} else {
				$result = self::record_variants($family, $variants, $source);
			}
			if (is_wp_error($result)) {
				return $result;
			}
			if (!$result) {
				return new WP_Error(
					'font_manifest_write_failed',
					__('The local font metadata could not be saved.', 'wphave'),
					['status' => 500],
				);
			}

			return ['recorded' => true];
		}

		/**
		 * Correct weight/style mappings without changing trusted file ownership.
		 *
		 * Unlike the upload endpoint, this operation works for both manual uploads
		 * and verified Google downloads. Source and license metadata come exclusively
		 * from the existing manifest and therefore cannot be forged by the browser.
		 */

		public static function update_mapping($family, $variants) {
			$family = WPHAVE_Fonts::canonical_font_family(sanitize_text_field($family));
			if (
				!$family ||
				!is_array($variants) ||
				empty($variants) ||
				count($variants) > self::MAX_VARIANTS_PER_FAMILY
			) {
				return new WP_Error(
					'invalid_font_metadata',
					__('Complete local font metadata is required.', 'wphave'),
					['status' => 400],
				);
			}
			if (!class_exists('WPHAVE_Option_Mutations')) {
				return new WP_Error(
					'font_lock_unavailable',
					__('Safe font metadata locking is not available.', 'wphave'),
					['status' => 503],
				);
			}

			if (!self::$manifest_lock_held) {
				return WPHAVE_Option_Mutations::with_lock('local_font_manifest', function () use (
					$family,
					$variants,
				) {
					self::$manifest_lock_held = true;
					try {
						self::invalidate_cache();
						return self::update_mapping($family, $variants);
					} finally {
						self::$manifest_lock_held = false;
					}
				});
			}

			$manifest = self::manifest(true);
			if (is_wp_error($manifest)) {
				return $manifest;
			}
			$family_key = WPHAVE_Font_Identity::key($family);
			$family_files = [];
			foreach ($manifest as $file => $record) {
				if (WPHAVE_Font_Identity::key($record['family'] ?? '') === $family_key) {
					$family_files[sanitize_file_name($file)] = $record;
				}
			}

			if (empty($family_files) || count($family_files) !== count($variants)) {
				return new WP_Error(
					'font_mapping_mismatch',
					__('The submitted variants do not match the registered font files.', 'wphave'),
					['status' => 409],
				);
			}
			$updated = [];
			foreach ($variants as $variant) {
				$file = sanitize_file_name($variant['file'] ?? '');
				$style = sanitize_key($variant['fontStyle'] ?? 'normal');
				$weight = sanitize_text_field($variant['fontWeight'] ?? '400');
				if (!$file || !isset($family_files[$file]) || isset($updated[$file])) {
					return new WP_Error(
						'font_mapping_mismatch',
						__(
							'The submitted variants do not match the registered font files.',
							'wphave',
						),
						['status' => 409],
					);
				}
				$weight = WPHAVE_Fonts::font_weight($weight);
				if (!in_array($style, ['normal', 'italic', 'oblique'], true) || !$weight) {
					return new WP_Error(
						'invalid_font_metadata_value',
						__('Font style or weight metadata is invalid.', 'wphave'),
						['status' => 400],
					);
				}

				$updated[$file] = array_merge($family_files[$file], [
					'style' => $style,
					'weight' => $weight,
				]);
			}

			$result = self::write_manifest(array_replace($manifest, $updated));
			if (!$result) {
				return new WP_Error(
					'font_manifest_write_failed',
					__('The local font metadata could not be saved.', 'wphave'),
					['status' => 500],
				);
			}
			self::invalidate_cache();

			return ['updated' => true];
		}

		/**
		 * Return the uploads/fonts directory descriptor.
		 *
		 * @return array
		 */

		public static function upload_dir() {
			return function_exists('wphave_get_upload_dir')
				? wphave_get_upload_dir(['subfolder' => 'fonts'])
				: [];
		}

		/**
		 * Load the optional downloaded-font metadata manifest.
		 *
		 * @return array
		 */

		private static function manifest($strict = false) {
			if (self::$manifest_cache_loaded) {
				if ($strict && is_wp_error(self::$manifest_cache)) {
					return self::$manifest_cache;
				}

				return is_array(self::$manifest_cache) ? self::$manifest_cache : [];
			}

			$upload_dir = self::upload_dir();
			$file_path = path_join($upload_dir['basedir'] ?? '', self::MANIFEST_FILE);

			if (!is_readable($file_path)) {
				self::$manifest_cache_loaded = true;
				return self::$manifest_cache = [];
			}

			$data = json_decode((string) file_get_contents($file_path), true);

			if (!is_array($data)) {
				error_log(
					'WPHAVE font manifest is invalid JSON: ' .
						WPHAVE_Security_Redactor::error_text($file_path, 500),
				);
				self::$manifest_cache = new WP_Error(
					'font_manifest_invalid',
					__('The local font metadata is damaged. No font files were changed.', 'wphave'),
					['status' => 500],
				);
				self::$manifest_cache_loaded = true;
				if ($strict) {
					return self::$manifest_cache;
				}
			}

			self::$manifest_cache = is_array($data) ? $data : self::$manifest_cache;
			self::$manifest_cache_loaded = true;

			return is_array(self::$manifest_cache) ? self::$manifest_cache : [];
		}

		/** Expose manifest corruption without exposing or mutating its raw contents. */

		public static function manifest_issue() {
			$result = self::manifest(true);
			if (!is_wp_error($result)) {
				return null;
			}

			return [
				'key' => 'local-manifest',
				'family' => '',
				'type' => 'local',
				'source' => 'manifest',
				'integrity' => 'invalid-manifest',
				'loadable' => false,
				'message' => $result->get_error_message(),
			];
		}

		/** Restore files staged by a delete transaction. */

		private static function restore_staged_files($staged, $staged_checksums) {
			$failed = [];
			foreach ($staged as $path => $staged_path) {
				$checksum = $staged_checksums[$staged_path] ?? null;
				try {
					if (!is_string($checksum)) {
						throw new RuntimeException('Missing original staged font identity.');
					}
					// RECOVERY INVARIANT: Restore only the originally moved bytes into
					// an absent path; neither a replacement stage nor a new live font
					// gains rollback authority.
					WPHAVE_Security_Conditional_File::relocate_if_matches_to_new(
						$staged_path,
						$checksum,
						$path,
						__('The staged font changed before restoration.', 'wphave'),
					);
				} catch (Throwable $error) {
					$failed[] = basename($path);
				}
			}
			return $failed;
		}

		/** Remove committed staging files and report anything requiring later cleanup. */

		private static function delete_staged_files($staged_checksums) {
			$failed = [];
			foreach ($staged_checksums as $staged_path => $checksum) {
				if (is_string($checksum)) {
					try {
						WPHAVE_Security_Conditional_File::remove_if_matches(
							$staged_path,
							$checksum,
							__('The staged font changed before deletion.', 'wphave'),
						);
					} catch (RuntimeException $error) {
						// Keep the original digest for a later authenticated retry.
					}
				}
				if (is_file($staged_path) || is_link($staged_path)) {
					$failed[basename($staged_path)] = $checksum;
				}
			}
			if ($failed) {
				self::queue_staged_cleanup($failed);
			}
			return array_keys($failed);
		}

		/** Capture the moved node's identity before any manifest hook can run. */
		private static function staged_checksum(string $path): ?string {
			if (!is_file($path) || is_link($path) || !is_readable($path)) {
				return null;
			}
			$checksum = hash_file('sha256', $path);
			return is_string($checksum) ? $checksum : null;
		}

		/** Persist authenticated file identities for a later cleanup attempt. */

		public static function queue_staged_cleanup($files) {
			if (!class_exists('WPHAVE_Option_Mutations')) {
				return;
			}
			$base_path = self::upload_dir()['basedir'] ?? '';
			$records = [];
			foreach (is_array($files) ? $files : [] as $file => $expected_checksum) {
				if (!is_string($file)) {
					continue;
				}
				$file = sanitize_file_name(wp_basename($file));
				$path = $base_path && $file ? path_join($base_path, $file) : '';
				$checksum = $path ? self::staged_checksum($path) : null;
				// CLEANUP INVARIANT: Never mint deletion authority from bytes first
				// encountered after staging. Only the original digest may be signed.
				if (
					!self::is_staged_cleanup_filename($file) ||
					!is_string($expected_checksum) ||
					!preg_match('/^[a-f0-9]{64}$/D', $expected_checksum) ||
					!is_string($checksum) ||
					!hash_equals($expected_checksum, $checksum)
				) {
					continue;
				}
				$records[$file] = [
					'file' => $file,
					'checksum' => $checksum,
					'signature' => self::cleanup_record_signature($file, $checksum),
				];
			}
			if (empty($records)) {
				return;
			}

			$queued = WPHAVE_Option_Mutations::mutate(self::CLEANUP_OPTION, function ($queued) use (
				$records,
			) {
				$next = [];
				foreach (is_array($queued) ? $queued : [] as $record) {
					if (self::is_valid_cleanup_record($record)) {
						$next[$record['file']] = $record;
					}
				}
				foreach ($records as $file => $record) {
					$next[$file] = $record;
				}

				return array_values($next);
			});
			if (!is_wp_error($queued) && $queued) {
				// FILE-LIFECYCLE INVARIANT: A stale cleanup event is not future
				// coverage for authenticated staging files. Repair missed work and
				// collapse concurrent queue attempts through the platform scheduler.
				WPHAVE_Background_Job_Scheduler::ensure_continuation(
					self::CLEANUP_HOOK,
					[],
					MINUTE_IN_SECONDS,
				);
			}
		}

		/** Requeue retained staging cleanup after plugin reactivation. */
		public static function ensure_staged_cleanup_schedule(): void {
			$queued = get_option(self::CLEANUP_OPTION, []);
			if (!is_array($queued) || !$queued) {
				return;
			}

			WPHAVE_Background_Job_Scheduler::ensure_continuation(
				self::CLEANUP_HOOK,
				[],
				MINUTE_IN_SECONDS,
			);
		}

		/** Retry only previously recorded staging files inside the controlled font directory. */

		public static function retry_staged_cleanup() {
			if (!class_exists('WPHAVE_Option_Mutations')) {
				return;
			}
			WPHAVE_Option_Mutations::with_lock(self::CLEANUP_OPTION, function () {
				$upload_dir = self::upload_dir();
				$base_path = $upload_dir['basedir'] ?? '';
				$queued = get_option(self::CLEANUP_OPTION, []);
				$remaining = [];
				foreach (is_array($queued) ? $queued : [] as $record) {
					// SECURITY INVARIANT: Persisted filenames never authorize cron deletion.
					// Require WPHAVE's HMAC plus the exact unchanged, non-symlink live bytes.
					if (!self::is_valid_cleanup_record($record)) {
						continue;
					}
					$file = $record['file'];
					if (!$base_path) {
						$remaining[$file] = $record;
						continue;
					}
					$path = path_join($base_path, $file);
					if (!file_exists($path) && !is_link($path)) {
						continue;
					}
					try {
						// SECURITY INVARIANT: Cron removes the exact node authenticated by the
						// cleanup record, never a path replacement made after an earlier hash.
						WPHAVE_Security_Conditional_File::remove_if_matches(
							$path,
							$record['checksum'],
							__(
								'A staged font file no longer matches its cleanup record.',
								'wphave',
							),
						);
					} catch (RuntimeException $error) {
						$remaining[$file] = $record;
						continue;
					}
					if (is_file($path) || is_link($path)) {
						$remaining[$file] = $record;
					}
				}
				if ($remaining) {
					update_option(self::CLEANUP_OPTION, array_values($remaining), false);
					WPHAVE_Background_Job_Scheduler::ensure_continuation(
						self::CLEANUP_HOOK,
						[],
						HOUR_IN_SECONDS,
					);
				} else {
					delete_option(self::CLEANUP_OPTION);
				}
			});
		}

		private static function is_valid_cleanup_record($record): bool {
			if (!is_array($record)) {
				return false;
			}
			$file = sanitize_file_name(wp_basename((string) ($record['file'] ?? '')));
			$checksum = strtolower((string) ($record['checksum'] ?? ''));
			$signature = strtolower((string) ($record['signature'] ?? ''));

			return $file === (string) ($record['file'] ?? '') &&
				self::is_staged_cleanup_filename($file) &&
				preg_match('/^[a-f0-9]{64}$/', $checksum) &&
				preg_match('/^[a-f0-9]{64}$/', $signature) &&
				hash_equals(self::cleanup_record_signature($file, $checksum), $signature);
		}

		private static function cleanup_record_signature(string $file, string $checksum): string {
			return hash_hmac('sha256', $file . "\n" . $checksum, wp_salt('auth'));
		}

		private static function is_staged_cleanup_filename(string $file): bool {
			return $file !== '' &&
				(str_contains($file, '.wphave-delete-') || str_contains($file, '-wphave-delete-'));
		}

		/**
		 * Atomically replace the metadata manifest so an interrupted write cannot
		 * leave a truncated JSON file. The lock file serializes read-modify-write
		 * operations across parallel font installations.
		 */

		private static function write_manifest($manifest) {
			$upload_dir = self::upload_dir();
			$base_path = $upload_dir['basedir'] ?? '';
			$json = wp_json_encode(
				is_array($manifest) ? $manifest : [],
				JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES,
			);

			if (!$base_path || !is_string($json)) {
				return false;
			}

			$file_path = path_join($base_path, self::MANIFEST_FILE);
			try {
				// COMMIT INVARIANT: The private manifest becomes authoritative only
				// after a complete flushed write. Partial writes preserve the old
				// manifest and request-local caches; the caller holds the font mutex.
				WPHAVE_Security_Atomic_File::write(
					$file_path,
					$json,
					'The font manifest could not be published completely.',
				);
			} catch (RuntimeException $error) {
				return false;
			}
			self::invalidate_cache();
			return true;
		}

		/** Invalidate request-local snapshots after a committed filesystem mutation. */

		public static function invalidate_cache() {
			self::$manifest_cache = null;
			self::$manifest_cache_loaded = false;
			self::$library_cache = null;
			self::$integrity_cache = null;
		}

		/**
		 * Keep only tokens permitted by the CSS unicode-range grammar.
		 *
		 * @param string $value Unicode range declaration.
		 * @return string
		 */

		private static function sanitize_unicode_range($value) {
			return trim(preg_replace('/[^uU+0-9a-fA-F?,\-\s]/', '', (string) $value));
		}

		/** Normalize one persisted record or reject it before it enters the registry. */

		private static function normalized_manifest_record($record) {
			if (!is_array($record)) {
				return null;
			}
			$family = WPHAVE_Fonts::canonical_font_family($record['family'] ?? '');
			$style = sanitize_key($record['style'] ?? '');
			$weight = WPHAVE_Fonts::font_weight(sanitize_text_field($record['weight'] ?? ''));
			$source = sanitize_key($record['source'] ?? '');
			$sha256 = strtolower(sanitize_text_field($record['sha256'] ?? ''));
			if (
				!WPHAVE_Font_Identity::is_safe($family) ||
				!in_array($style, ['normal', 'italic', 'oblique'], true) ||
				!$weight ||
				!in_array($source, ['upload', 'google-fonts'], true) ||
				!preg_match('/^[a-f0-9]{64}$/', $sha256)
			) {
				return null;
			}

			$record['family'] = $family;
			$record['style'] = $style;
			$record['weight'] = $weight;
			$record['source'] = $source;
			$record['sha256'] = $sha256;
			$record['unicodeRange'] = self::sanitize_unicode_range($record['unicodeRange'] ?? '');
			$record['subset'] = sanitize_key($record['subset'] ?? '');

			return $record;
		}

		/** Compare a mandatory SHA-256 proof without trusting a prior readability check. */

		private static function verified_file_hash($path, $expected) {
			if (
				!$path ||
				!is_readable($path) ||
				!preg_match('/^[a-f0-9]{64}$/', (string) $expected)
			) {
				return false;
			}
			$actual = hash_file('sha256', $path);

			return is_string($actual) && hash_equals($expected, $actual);
		}
	}
endif;
