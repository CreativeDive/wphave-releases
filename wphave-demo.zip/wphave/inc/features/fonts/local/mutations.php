<?php

if ( ! class_exists( 'WPHAVE_Local_Font_Mutations' ) ) :

	/** Owns administrator-triggered local font mutations. */

	class WPHAVE_Local_Font_Mutations {

		public static function delete_family( $family ) {
			return WPHAVE_Local_Fonts::delete_family( $family );
		}

		public static function delete_file( $file ) {
			return WPHAVE_Local_Fonts::delete_file( $file );
		}

		public static function record( $fonts, $family, $variants, $source = 'upload' ) {
			return WPHAVE_Local_Fonts::record( $fonts, $family, $variants, $source );
		}

		public static function update_mapping( $family, $variants ) {
			return WPHAVE_Local_Fonts::update_mapping( $family, $variants );
		}

	}

endif;
