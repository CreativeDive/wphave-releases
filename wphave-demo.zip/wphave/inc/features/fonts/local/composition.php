<?php

if (!class_exists('WPHAVE_Local_Font_Composition')):
	/** Installs already verified font files supplied by a Site Composition package. */

	class WPHAVE_Local_Font_Composition {
		public static function install($font, $files, $on_created = null) {
			$family = WPHAVE_Fonts::canonical_font_family(
				sanitize_text_field($font['family'] ?? ''),
			);
			$font_source = sanitize_key($font['source'] ?? 'upload') ?: 'upload';
			$variants = is_array($font['variants'] ?? null) ? $font['variants'] : [];
			if (!WPHAVE_Font_Identity::is_safe($family) || empty($variants) || !is_array($files)) {
				return new WP_Error(
					'composition_font_invalid',
					__('The packaged font metadata is incomplete or unsafe.', 'wphave'),
					['status' => 400],
				);
			}
			if (!in_array($font_source, WPHAVE_Local_Fonts::SOURCES, true)) {
				return new WP_Error(
					'composition_font_source_invalid',
					__('The packaged font source is not supported.', 'wphave'),
					['status' => 400],
				);
			}
			foreach (WPHAVE_Local_Font_Library::fonts() as $installed) {
				if (
					WPHAVE_Font_Identity::key($installed['family'] ?? '') !==
					WPHAVE_Font_Identity::key($family)
				) {
					continue;
				}
				$installed_hashes = [];
				foreach ((array) ($installed['variants'] ?? []) as $variant) {
					$path = path_join(
						WPHAVE_Local_Font_Library::upload_dir()['basedir'] ?? '',
						sanitize_file_name($variant['file'] ?? ''),
					);
					if (is_readable($path)) {
						$installed_hashes[] = hash_file('sha256', $path);
					}
				}
				$package_hashes = array_values(
					array_filter(
						array_map(
							fn($variant) => strtolower(
								sanitize_text_field($variant['checksum'] ?? ''),
							),
							$variants,
						),
					),
				);
				sort($installed_hashes);
				sort($package_hashes);
				return $installed_hashes === $package_hashes
					? $installed
					: new WP_Error(
						'composition_font_conflict',
						sprintf(
							__(
								'The local font family %s already exists with different files.',
								'wphave',
							),
							$family,
						),
						['status' => 409],
					);
			}

			$base_path = WPHAVE_Local_Font_Library::upload_dir()['basedir'] ?? '';
			if (!$base_path || !wp_mkdir_p($base_path)) {
				return new WP_Error(
					'fonts_upload_dir_missing',
					__('The fonts upload directory is not available.', 'wphave'),
					['status' => 500],
				);
			}
			$created = [];
			$records = [];
			foreach ($variants as $variant) {
				$archive_file = (string) ($variant['file'] ?? '');
				$source = $files[$archive_file] ?? '';
				$checksum = strtolower(sanitize_text_field($variant['checksum'] ?? ''));
				if (
					!WPHAVE_Font_File_Security::is_supported($archive_file) ||
					!WPHAVE_Font_File_Security::has_valid_signature(
						$source,
						WPHAVE_Font_File_Security::extension($archive_file),
					) ||
					!self::source_matches_checksum($source, $checksum)
				) {
					return self::rollback(
						$created,
						new WP_Error(
							'composition_font_checksum_invalid',
							__('A packaged font failed its type or integrity check.', 'wphave'),
							['status' => 400],
						),
					);
				}
				$file = wp_unique_filename(
					$base_path,
					sanitize_file_name(wp_basename($archive_file)),
				);
				$target = path_join($base_path, $file);
				try {
					// PHP-WebAssembly rejects hard-link publication with "Too many links".
					// Fonts and licenses can use exclusive creation because registry readers
					// ignore unregistered files until the journal and manifest commit below.
					// SECURITY INVARIANT: The checksum is evaluated over the exact bytes
					// exclusively created before the manifest exposes the complete font family.
					WPHAVE_Security_Atomic_File::copy_verified_unpublished(
						$source,
						$target,
						$checksum,
						__('A packaged font could not be installed.', 'wphave'),
						// PUBLICATION INVARIANT: Installed assets use local directory policy, never archive modes.
						WPHAVE_Security_File_Permissions::for_new_public_file($target),
					);
				} catch (RuntimeException $error) {
					return self::rollback(
						$created,
						new WP_Error('composition_font_copy_failed', $error->getMessage(), [
							'status' => 500,
						]),
					);
				}
				$created[$target] = $checksum;
				$records[] = array_merge($variant, ['file' => $file]);
			}

			$license = is_array($font['license'] ?? null) ? $font['license'] : [];
			if (!empty($license['file'])) {
				$source = $files[(string) $license['file']] ?? '';
				$checksum = strtolower(sanitize_text_field($license['sha256'] ?? ''));
				if (
					strtolower(pathinfo((string) $license['file'], PATHINFO_EXTENSION)) !== 'txt' ||
					!self::source_matches_checksum($source, $checksum)
				) {
					return self::rollback(
						$created,
						new WP_Error(
							'composition_font_license_invalid',
							__(
								'A packaged font license failed its type or integrity check.',
								'wphave',
							),
							['status' => 400],
						),
					);
				}
				$file = wp_unique_filename(
					$base_path,
					sanitize_file_name(wp_basename($license['file'])),
				);
				$target = path_join($base_path, $file);
				try {
					WPHAVE_Security_Atomic_File::copy_verified_unpublished(
						$source,
						$target,
						$checksum,
						__('A packaged font license could not be installed.', 'wphave'),
						// PUBLICATION INVARIANT: Installed assets use local directory policy, never archive modes.
						WPHAVE_Security_File_Permissions::for_new_public_file($target),
					);
				} catch (RuntimeException $error) {
					return self::rollback(
						$created,
						new WP_Error('composition_font_license_copy_failed', $error->getMessage(), [
							'status' => 500,
						]),
					);
				}
				$created[$target] = $checksum;
				$license['file'] = $file;
			}

			// SECURITY INVARIANT: A higher-level transaction must durably bind every
			// created file before its manifest records become live. A request ending
			// between those phases then remains recoverable from the signed journal.
			if (is_callable($on_created) && !$on_created(array_map('wp_basename', array_keys($created)))) {
				return self::rollback(
					$created,
					new WP_Error(
						'composition_font_journal_failed',
						__(
							'The packaged font files could not be bound to their transaction.',
							'wphave',
						),
						['status' => 500],
					),
				);
			}

			$result = WPHAVE_Local_Fonts::record_variants(
				$family,
				$records,
				$font_source,
				$license,
			);
			if (is_wp_error($result) || !$result) {
				return self::rollback(
					$created,
					is_wp_error($result)
						? $result
						: new WP_Error(
							'composition_font_manifest_failed',
							__('The packaged font metadata could not be stored.', 'wphave'),
							['status' => 500],
						),
				);
			}
			WPHAVE_Local_Fonts::invalidate_cache();
			foreach (WPHAVE_Local_Font_Library::fonts() as $installed) {
				if (
					WPHAVE_Font_Identity::key($installed['family'] ?? '') !==
					WPHAVE_Font_Identity::key($family)
				) {
					continue;
				}
				$installed['_createdFiles'] = array_map('wp_basename', array_keys($created));
				return $installed;
			}

			return self::rollback_committed(
				$created,
				wp_list_pluck($records, 'file'),
				new WP_Error(
					'composition_font_install_failed',
					__('The packaged font could not be resolved after installation.', 'wphave'),
					['status' => 500],
				),
			);
		}

		/** ORDERING INVARIANT: Roll back metadata before files so manifests never reference deleted assets. */

		private static function rollback_committed($created, $records, $error) {
			$removed = WPHAVE_Local_Fonts::remove_manifest_records($records);
			if (is_wp_error($removed)) {
				return $removed;
			}

			return self::rollback($created, $error);
		}

		private static function rollback($created, $error) {
			foreach ($created as $path => $checksum) {
				try {
					// ROLLBACK INVARIANT: A failed import owns only the bytes it
					// published, never a later occupant of the same font pathname.
					WPHAVE_Security_Conditional_File::remove_if_matches(
						$path,
						$checksum,
						__('A packaged font changed before rollback.', 'wphave'),
					);
				} catch (RuntimeException $cleanup_error) {
					// Preserve an unproven revision for transaction recovery.
				}
			}

			return $error;
		}

		/** Performs early package feedback; commit independently revalidates the stream. */

		private static function source_matches_checksum(string $source, string $checksum): bool {
			if (!preg_match('/^[a-f0-9]{64}$/', $checksum)) {
				return false;
			}

			try {
				$identity = WPHAVE_Security_File_Identity::inspect(
					$source,
					__('A packaged font source could not be inspected.', 'wphave'),
				);
			} catch (RuntimeException $error) {
				return false;
			}

			// SECURITY: This improves validation feedback only. Mutation authority is
			// recalculated from the exact stream consumed by copy_verified_unpublished().
			return hash_equals($checksum, $identity['checksum']);
		}
	}
endif;
