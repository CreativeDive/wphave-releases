<?php

if ( ! class_exists( 'WPHAVE_Local_Fonts' ) ) :

	/**
	 * Stable public facade for the local font repository.
	 *
	 * Keep call sites on this name. Filesystem, manifest and transaction details
	 * live behind WPHAVE_Local_Font_Repository so UI and provider integrations do
	 * not grow another persistence contract.
	 */

	class WPHAVE_Local_Fonts extends WPHAVE_Local_Font_Repository {
	}

endif;
