<?php

if (!class_exists('WPHAVE_Local_Font_CSS')):
	/** Generates CSS exclusively from resolver-verified local font records. */

	class WPHAVE_Local_Font_CSS {
		public static function defaults() {
			return self::for_fonts(
				array_filter(
					WPHAVE_Font_Resolver::active_local_fonts(),
					fn($font) => !empty($font['default']) || ($font['source'] ?? '') === 'default',
				),
			);
		}

		public static function active() {
			return self::for_fonts(
				array_filter(
					WPHAVE_Font_Resolver::active_local_fonts(),
					fn($font) => empty($font['default']) && ($font['source'] ?? '') !== 'default',
				),
			);
		}

		/**
		 * Serialize verified local records. Isolated composition previews may ignore
		 * the host loading mode for their bundled defaults; this never loads a provider.
		 *
		 * @param array $fonts Verified font inventory.
		 * @param bool $respect_site_policy Whether the site's loading mode applies.
		 * @return string Local font-face CSS.
		 */

		public static function for_fonts($fonts, bool $respect_site_policy = true) {
			if ($respect_site_policy && WPHAVE_Fonts::loading_mode() === 'disabled') {
				return '';
			}
			$css = '';
			$uploads = WPHAVE_Local_Font_Library::upload_dir();
			foreach ($fonts as $font) {
				if (($font['type'] ?? '') !== 'local' || empty($font['loadable'])) {
					continue;
				}
				$is_default = !empty($font['default']) || ($font['source'] ?? '') === 'default';
				$base = $is_default
					? WPHAVE_Local_Font_Library::default_base_url()
					: $uploads['baseurl'] ?? '';
				foreach ($font['variants'] ?? [] as $variant) {
					$file = sanitize_file_name($variant['file'] ?? '');
					if (
						!$file ||
						(!$is_default && !is_file(path_join($uploads['basedir'] ?? '', $file)))
					) {
						continue;
					}
					$css .= self::face([
						'family' => $font['family'] ?? '',
						'style' => $variant['fontStyle'] ?? 'normal',
						'weight' => $variant['fontWeight'] ?? '400',
						'url' => trailingslashit($base) . rawurlencode($file),
						'format' => self::format($file),
						'display' => WPHAVE_Fonts::font_display(),
						'unicodeRange' => $variant['unicodeRange'] ?? '',
					]);
				}
			}
			return $css;
		}

		private static function face($args) {
			$family = WPHAVE_Font_Identity::css_string(sanitize_text_field($args['family'] ?? ''));
			$style = sanitize_key($args['style'] ?? 'normal');
			$style = in_array($style, ['normal', 'italic', 'oblique'], true) ? $style : 'normal';
			$weight = sanitize_text_field($args['weight'] ?? '400');
			$weight = WPHAVE_Fonts::font_weight($weight, '400');
			$url = esc_url_raw($args['url'] ?? '');
			$format = sanitize_key($args['format'] ?? '');
			$display = sanitize_key($args['display'] ?? 'swap');
			$display = in_array($display, ['auto', 'block', 'swap', 'fallback', 'optional'], true)
				? $display
				: 'swap';
			$unicode_range = trim(
				preg_replace('/[^uU+0-9a-fA-F?,\-\s]/', '', (string) ($args['unicodeRange'] ?? '')),
			);
			if (!$family || !$url || !$format) {
				return '';
			}
			$unicode_rule = $unicode_range ? "unicode-range:{$unicode_range};" : '';

			return "@font-face{font-display:{$display};font-family:{$family};font-style:{$style};font-weight:{$weight};src:url('{$url}') format('{$format}');{$unicode_rule}}";
		}

		private static function format($file) {
			$formats = [
				'ttf' => 'truetype',
				'otf' => 'opentype',
				'woff' => 'woff',
				'woff2' => 'woff2',
			];

			return $formats[strtolower(pathinfo($file, PATHINFO_EXTENSION))] ?? '';
		}
	}
endif;
