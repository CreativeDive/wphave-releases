<?php

if ( ! class_exists( 'WPHAVE_Local_Font_Library' ) ) :

	/** Read-only access to bundled definitions and installed local families. */

	class WPHAVE_Local_Font_Library {

		/** Return the canonical public directory for immutable bundled font assets. */

		public static function default_base_url() {
			return trailingslashit( wphave_asset_url( 'inc/features/fonts/assets/default-fonts' ) );
		}

		public static function defaults() {
			return WPHAVE_Local_Fonts::default_definitions();
		}

		public static function fonts() {
			return WPHAVE_Local_Fonts::library_fonts();
		}

		public static function upload_dir() {
			return WPHAVE_Local_Fonts::upload_dir();
		}

		public static function unique_variants( $variants ) {
			return WPHAVE_Local_Fonts::unique_variants( $variants );
		}
	}

endif;
