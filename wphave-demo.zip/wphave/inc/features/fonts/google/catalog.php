<?php

if ( ! class_exists( 'WPHAVE_Google_Font_Catalog' ) ) :

	/**
	 * Provides the versioned Google family and variant contract to PHP.
	 *
	 * React reads the full bundled catalogue while PHP reads its generated compact
	 * contract. Provider settings must never accept a syntactically plausible weight
	 * that the family does not publish, because Google rejects the combined request.
	 */

	class WPHAVE_Google_Font_Catalog {

		private static $fonts = null;
		private static $subsets = array();

		/** Return all published variant identifiers for one canonical family. */

		public static function variants( $family ) {
			$key = WPHAVE_Font_Identity::key( $family );
			$fonts = self::fonts();

			return $key && isset( $fonts[$key] ) ? $fonts[$key] : array();
		}

		/** Return one explicit safe variant for a newly enabled family. */

		public static function default_variants( $family ) {
			$variants = self::variants( $family );
			if( in_array( 'regular', $variants, true ) ) return array( 'regular' );
			if( in_array( '400', $variants, true ) ) return array( '400' );

			return isset( $variants[0] ) ? array( $variants[0] ) : array();
		}

		/** Accept equivalent Google identifiers such as regular and 400. */

		public static function has_variant( $family, $variant ) {
			$requested = self::canonical_variant( $variant );

			return $requested !== '' && in_array( $requested, array_map( array( __CLASS__, 'canonical_variant' ), self::variants( $family ) ), true );
		}

		/** Return character sets published for one family. */

		public static function subsets( $family ) {
			$key = WPHAVE_Font_Identity::key( $family );
			self::fonts();

			return $key && isset( self::$subsets[$key] ) ? self::$subsets[$key] : array();
		}

		/**
		 * Keep persisted provider variants inside the bundled contract.
		 *
		 * Settings validation prevents new invalid data. This runtime boundary also
		 * protects sites carrying manually edited, imported or pre-validation options:
		 * invalid variants fall back to the catalogue default, while an unknown family
		 * is skipped instead of invalidating Google's complete combined stylesheet.
		 */

		public static function safe_variants( $family, $variants ) {
			$available = self::variants( $family );
			if( ! $available ) return array();
			$selected = array();
			$canonical = array_map( array( __CLASS__, 'canonical_variant' ), $available );
			foreach( is_array( $variants ) ? $variants : array() as $variant ) {
				$index = array_search( self::canonical_variant( $variant ), $canonical, true );
				if( $index !== false ) $selected[] = $available[$index];
			}
			$selected = array_values( array_unique( $selected ) );

			return $selected ?: self::default_variants( $family );
		}

		/** Load the generated validation contract without decoding the complete UI JSON. */

		private static function fonts() {
			if( is_array( self::$fonts ) ) return self::$fonts;
			$file = __DIR__ . '/../assets/google-fonts-runtime.php';
			$data = is_readable( $file ) ? require $file : array();
			$fonts = array();

			foreach( is_array( $data ) ? $data : array() as $key => $font ) {
				$key = WPHAVE_Font_Identity::key( $key );
				$variants = array_values( array_unique( array_filter( array_map( 'sanitize_text_field', is_array( $font[0] ?? null ) ? $font[0] : array() ) ) ) );
				if( $variants ) {
					$fonts[$key] = $variants;
					self::$subsets[$key] = array_values( array_unique( array_filter( array_map( 'sanitize_key', is_array( $font[1] ?? null ) ? $font[1] : array() ) ) ) );
				}
			}

			return self::$fonts = $fonts;
		}

		private static function canonical_variant( $variant ) {
			$variant = sanitize_key( $variant );
			if( $variant === 'regular' ) return '400';
			if( $variant === 'italic' ) return '400italic';

			return preg_match( '/^[1-9]00(?:italic)?$/', $variant ) ? $variant : '';
		}
	}

endif;
