<?php

if ( ! class_exists( 'WPHAVE_Google_Font_Query' ) ) :

	/** Pure Google CSS2 query construction; this class performs no I/O or enqueueing. */

	class WPHAVE_Google_Font_Query {
		const MAX_VARIANTS = 24;

		public static function family( $family, $variants = array() ) {
			$family = WPHAVE_Fonts::canonical_font_family( $family );
			if( ! $family ) return '';
			$variants = self::variants( $variants );
			$family = wphave_replace( ' ', '+', $family );
			$has_italic = in_array( 'italic', array_column( $variants, 'style' ), true );
			if( $has_italic ) {
				$values = array_map( fn( $variant ) => ( $variant['style'] === 'italic' ? '1' : '0' ) . ',' . $variant['weight'], $variants );
				return $family . ':ital,wght@' . implode( ';', array_values( array_unique( $values ) ) );
			}

			return $family . ':wght@' . implode( ';', array_values( array_unique( array_column( $variants, 'weight' ) ) ) );
		}

		public static function url( $fonts, $display = 'swap' ) {
			$families = array();
			foreach( is_array( $fonts ) ? $fonts : array() as $font ) {
				$family = $font['family'] ?? $font['font'] ?? '';
				if( ! $family && is_array( $font['google_font'] ?? null ) ) $family = $font['google_font']['family'] ?? $font['google_font']['font'] ?? '';
				if( $family ) $families[] = self::family( $family, $font['variants'] ?? array() );
			}

			return self::css2_url( $families, $display );
		}

		public static function css2_url( $families, $display = 'swap' ) {
			$families = array_values( array_unique( array_filter( is_array( $families ) ? $families : array() ) ) );
			if( empty( $families ) ) return '';
			$query = array_map( fn( $family ) => 'family=' . $family, $families );
			$query[] = 'display=' . rawurlencode( $display ?: 'swap' );
			return 'https://fonts.googleapis.com/css2?' . implode( '&', $query );
		}

		private static function variants( $variants ) {
			if( is_string( $variants ) ) $variants = array_filter( array_map( 'trim', explode( ',', $variants ) ) );
			if( ! is_array( $variants ) || empty( $variants ) ) $variants = array( '400' );
			$variants = array_slice( $variants, 0, self::MAX_VARIANTS );
			$normalized = array();
			foreach( $variants as $variant ) {
				$variant = trim( (string) $variant );
				if( ! $variant ) continue;
				$style = str_contains( $variant, 'italic' ) ? 'italic' : 'normal';
				$weight = $variant === 'regular' ? '400' : ( preg_replace( '/[^0-9]/', '', $variant ) ?: '400' );
				if( ! preg_match( '/^[1-9]00$/', $weight ) ) continue;
				$normalized[$style . ':' . $weight] = array( 'style' => $style, 'weight' => $weight );
			}
			if( empty( $normalized ) ) $normalized['normal:400'] = array( 'style' => 'normal', 'weight' => '400' );
			$normalized = array_values( $normalized );
			usort( $normalized, fn( $a, $b ) => $a['style'] === $b['style'] ? (int) $a['weight'] <=> (int) $b['weight'] : ( $a['style'] === 'normal' ? -1 : 1 ) );

			return $normalized;
		}
	}

endif;
