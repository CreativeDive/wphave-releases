<?php

/**
 * Function to check if a preset typography is used.
 */

if ( ! function_exists( 'wphave_preset_font_pairs' ) ) :

    function wphave_preset_font_pairs() {

		$preset_typography = wphave_data_get( 'site_globals', 'preset.typography' );

		if( $preset_typography ) {
			return $preset_typography;
		}

		return false;

	}

endif;


/**
 * Return the curated font-pair recommendation catalogue.
 *
 * This catalogue provides discovery metadata for Global Styles, Quick Setup and
 * future planning tools. It is deliberately not a runtime font registry: listing
 * OWNERSHIP INVARIANT: A preset never activates a family; provider availability comes from
 * the Google catalogue or local manifest, while saved typography assignments and
 * explicit Font Manager activation are the only runtime loading intents.
 */

if ( ! function_exists( 'wphave_preset_web_fonts' ) ) :

    function wphave_preset_web_fonts( $key = 'inter', $args = [] ) {

		$output = isset( $args['output'] ) ? $args['output'] : '';

		$fonts = array(
			'inter' => array(
				'heading' => array(
					'family' => 'Inter',
					'weight' => '800',
					'styles' => '400,600,800',
				),
				'text' => array(
					'family' => 'Inter',
					'weight' => '400',
					'styles' => '400,600,800',
				),
                'keywords' => array('sans-serif')
			),
			'manrope-inter' => array(
				'heading' => array(
					'family' => 'Manrope',
					'weight' => '800',
					'styles' => '400,600,700,800',
				),
				'text' => array(
					'family' => 'Inter',
					'weight' => '400',
					'styles' => '400,500,600,700',
				),
                'keywords' => array('sans-serif')
			),
			'sora-inter' => array(
				'heading' => array(
					'family' => 'Sora',
					'weight' => '800',
					'styles' => '400,600,700,800',
				),
				'text' => array(
					'family' => 'Inter',
					'weight' => '400',
					'styles' => '400,500,600,700',
				),
                'keywords' => array('sans-serif')
			),
			'space-grotesk-inter' => array(
				'heading' => array(
					'family' => 'Space+Grotesk',
					'weight' => '700',
					'styles' => '400,500,600,700',
				),
				'text' => array(
					'family' => 'Inter',
					'weight' => '400',
					'styles' => '400,500,600,700',
				),
                'keywords' => array('sans-serif')
			),
			'plus-jakarta-sans' => array(
				'heading' => array(
					'family' => 'Plus Jakarta Sans',
					'weight' => '800',
					'styles' => '400,600,800',
				),
				'text' => array(
					'family' => 'Plus Jakarta Sans',
					'weight' => '400',
					'styles' => '400,600,800',
				),
                'keywords' => array('sans-serif')
			),
			'outfit' => array(
				'heading' => array(
					'family' => 'Outfit',
					'weight' => '800',
					'styles' => '400,600,800',
				),
				'text' => array(
					'family' => 'Outfit',
					'weight' => '400',
					'styles' => '400,600,800',
				),
                'keywords' => array('sans-serif')
			),
			'poppins-dm-sans' => array(
				'heading' => array(
					'family' => 'Poppins',
					'weight' => '700',
					'styles' => '400,700,800',
				),
				'text' => array(
					'family' => 'DM Sans',
					'weight' => '400',
					'styles' => '400,700',
				),
                'keywords' => array('sans-serif')
			),
			'poppins-lora' => array(
				'heading' => array(
					'family' => 'Poppins',
					'weight' => '700',
					'styles' => '400,600,700,800',
				),
				'text' => array(
					'family' => 'Lora',
					'weight' => '400',
					'styles' => '400,500,700',
				),
                'keywords' => array('mixed')
			),
			'urbanist-inter' => array(
				'heading' => array(
					'family' => 'Urbanist',
					'weight' => '800',
					'styles' => '400,600,700,800',
				),
				'text' => array(
					'family' => 'Inter',
					'weight' => '400',
					'styles' => '400,500,600,700',
				),
                'keywords' => array('sans-serif')
			),
			'raleway-open-sans' => array(
				'heading' => array(
					'family' => 'Raleway',
					'weight' => '800',
					'styles' => '400,600,700,800',
				),
				'text' => array(
					'family' => 'Open+Sans',
					'weight' => '400',
					'styles' => '300,400,600,700',
				),
                'keywords' => array('sans-serif')
			),
			'montserrat-oswald' => array(
				'heading' => array(
					'family' => 'Montserrat',
					'weight' => '700',
					'styles' => '400,600,700,800',
				),
				'text' => array(
					'family' => 'Oswald',
					'weight' => '400',
					'styles' => '300,400,500,600',
				),
                'keywords' => array('sans-serif')
			),
			'bricolage-grotesque-figtree' => array(
				'heading' => array(
					'family' => 'Bricolage+Grotesque',
					'weight' => '700',
					'styles' => '400,600,700,800',
				),
				'text' => array(
					'family' => 'Figtree',
					'weight' => '400',
					'styles' => '400,500,600,700',
				),
                'keywords' => array('sans-serif')
			),
			'barlow-lato' => array(
				'heading' => array(
					'family' => 'Barlow',
					'weight' => '700',
					'styles' => '400,600,700,800',
				),
				'text' => array(
					'family' => 'Lato',
					'weight' => '400',
					'styles' => '300,400,700',
				),
                'keywords' => array('sans-serif')
			),
			'mulish-lato' => array(
				'heading' => array(
					'family' => 'Mulish',
					'weight' => '800',
					'styles' => '400,600,700,800',
				),
				'text' => array(
					'family' => 'Lato',
					'weight' => '400',
					'styles' => '300,400,700',
				),
                'keywords' => array('sans-serif')
			),
			'fraunces-source-sans-3' => array(
				'heading' => array(
					'family' => 'Fraunces',
					'weight' => '700',
					'styles' => '400,600,700,900',
				),
				'text' => array(
					'family' => 'Source+Sans+3',
					'weight' => '400',
					'styles' => '400,600,700',
				),
                'keywords' => array('mixed')
			),
			'playfair-display-chivo' => array(
				'heading' => array(
					'family' => 'Playfair+Display',
					'weight' => '700',
					'styles' => '400,700',
				),
				'text' => array(
					'family' => 'Chivo',
					'weight' => '300',
					'styles' => '300,400,600',
				),
                'keywords' => array('mixed')
			),
			'bitter-lato' => array(
				'heading' => array(
					'family' => 'Bitter',
					'weight' => '700',
					'styles' => '400,600,700,800',
				),
				'text' => array(
					'family' => 'Lato',
					'weight' => '400',
					'styles' => '300,400,700',
				),
                'keywords' => array('mixed')
			),
			'arapey-lato' => array(
				'heading' => array(
					'family' => 'Arapey',
					'weight' => '400',
					'styles' => '400',
				),
				'text' => array(
					'family' => 'Lato',
					'weight' => '400',
					'styles' => '300,400,700',
				),
                'keywords' => array('mixed')
			),
			'caladea-nunito' => array(
				'heading' => array(
					'family' => 'Caladea',
					'weight' => '700',
					'styles' => '400,700',
				),
				'text' => array(
					'family' => 'Nunito',
					'weight' => '400',
					'styles' => '400,600,700',
				),
                'keywords' => array('mixed')
			),
			'playfair-display-inter' => array(
				'heading' => array(
					'family' => 'Playfair+Display',
					'weight' => '700',
					'styles' => '400,700,900',
				),
				'text' => array(
					'family' => 'Inter',
					'weight' => '400',
					'styles' => '400,500,600,700',
				),
                'keywords' => array('mixed')
			),
			'playfair-display-raleway' => array(
				'heading' => array(
					'family' => 'Playfair+Display',
					'weight' => '700',
					'styles' => '400,700,900',
				),
				'text' => array(
					'family' => 'Raleway',
					'weight' => '400',
					'styles' => '400,500,600,700',
				),
                'keywords' => array('mixed')
			),
			'cormorant-garamond-manrope' => array(
				'heading' => array(
					'family' => 'Cormorant+Garamond',
					'weight' => '700',
					'styles' => '400,700',
				),
				'text' => array(
					'family' => 'Manrope',
					'weight' => '400',
					'styles' => '400,600,700',
				),
                'keywords' => array('mixed')
			),
			'dm-serif-display-dm-sans' => array(
				'heading' => array(
					'family' => 'DM+Serif+Display',
					'weight' => '400',
					'styles' => '400',
				),
				'text' => array(
					'family' => 'DM Sans',
					'weight' => '400',
					'styles' => '400,500,700',
				),
                'keywords' => array('mixed')
			),
			'dm-serif-display-inter' => array(
				'heading' => array(
					'family' => 'DM+Serif+Display',
					'weight' => '400',
					'styles' => '400',
				),
				'text' => array(
					'family' => 'Inter',
					'weight' => '400',
					'styles' => '400,500,600,700',
				),
                'keywords' => array('mixed')
			),
			'instrument-serif-inter' => array(
				'heading' => array(
					'family' => 'Instrument+Serif',
					'weight' => '400',
					'styles' => '400',
				),
				'text' => array(
					'family' => 'Inter',
					'weight' => '400',
					'styles' => '400,500,600',
				),
                'keywords' => array('mixed')
			),
			'libre-baskerville-source-sans-3' => array(
				'heading' => array(
					'family' => 'Libre+Baskerville',
					'weight' => '700',
					'styles' => '400,700',
				),
				'text' => array(
					'family' => 'Source+Sans+3',
					'weight' => '400',
					'styles' => '400,600,700',
				),
                'keywords' => array('mixed')
			),
			'lora-inter' => array(
				'heading' => array(
					'family' => 'Lora',
					'weight' => '700',
					'styles' => '400,500,700',
				),
				'text' => array(
					'family' => 'Inter',
					'weight' => '400',
					'styles' => '400,500,600',
				),
                'keywords' => array('mixed')
			),
			'newsreader-public-sans' => array(
				'heading' => array(
					'family' => 'Newsreader',
					'weight' => '700',
					'styles' => '400,600,700',
				),
				'text' => array(
					'family' => 'Public+Sans',
					'weight' => '400',
					'styles' => '400,500,600,700',
				),
                'keywords' => array('mixed')
			),
			'plus-jakarta-sans-lora' => array(
				'heading' => array(
					'family' => 'Plus Jakarta Sans',
					'weight' => '800',
					'styles' => '400,600,700,800',
				),
				'text' => array(
					'family' => 'Lora',
					'weight' => '400',
					'styles' => '400,500,700',
				),
                'keywords' => array('mixed')
			),
			'work-sans-merriweather' => array(
				'heading' => array(
					'family' => 'Work+Sans',
					'weight' => '700',
					'styles' => '400,600,700',
				),
				'text' => array(
					'family' => 'Merriweather',
					'weight' => '400',
					'styles' => '400,700,900',
				),
                'keywords' => array('mixed')
			),
			'noto-sans-inter' => array(
				'heading' => array(
					'family' => 'Noto+Sans',
					'weight' => '700',
					'styles' => '400,600,700',
				),
				'text' => array(
					'family' => 'Inter',
					'weight' => '400',
					'styles' => '400,500,600,700',
				),
                'keywords' => array('sans-serif')
			),
			'roboto-condensed-roboto' => array(
				'heading' => array(
					'family' => 'Roboto+Condensed',
					'weight' => '700',
					'styles' => '400,700',
				),
				'text' => array(
					'family' => 'Roboto',
					'weight' => '400',
					'styles' => '400,500,700',
				),
                'keywords' => array('sans-serif')
			),
			// Google Sans is deliberately excluded from downloadable presets. Although
			// it appears in the Google Fonts catalogue, the official google/fonts
			// repository currently exposes no license record that our fail-closed
			// installer can verify for local redistribution.
			'cal-sans-inter' => array(
				'heading' => array(
					'family' => 'Cal Sans',
					'weight' => '400',
					'styles' => '400',
				),
				'text' => array(
					'family' => 'Inter',
					'weight' => '400',
					'styles' => '400,500,600,700',
				),
                'keywords' => array('sans-serif')
			),
			'funnel-sans-lato' => array(
				'heading' => array(
					'family' => 'Funnel Sans',
					'weight' => '700',
					'styles' => '400,600,700,800',
				),
				'text' => array(
					'family' => 'Lato',
					'weight' => '400',
					'styles' => '300,400,700',
				),
                'keywords' => array('sans-serif')
			),
			'geom-manrope' => array(
				'heading' => array(
					'family' => 'Geom',
					'weight' => '700',
					'styles' => '400,600,700',
				),
				'text' => array(
					'family' => 'Manrope',
					'weight' => '400',
					'styles' => '400,600,700',
				),
                'keywords' => array('sans-serif')
			),
			'quattrocento-nunito' => array(
				'heading' => array(
					'family' => 'Quattrocento',
					'weight' => '700',
					'styles' => '400,700',
				),
				'text' => array(
					'family' => 'Nunito',
					'weight' => '400',
					'styles' => '400,600,700',
				),
                'keywords' => array('mixed')
			),
			'urbanist-lora' => array(
				'heading' => array(
					'family' => 'Urbanist',
					'weight' => '700',
					'styles' => '400,600,700,800',
				),
				'text' => array(
					'family' => 'Lora',
					'weight' => '400',
					'styles' => '400,500,700',
				),
                'keywords' => array('mixed')
			),
			'spectral-karla' => array(
				'heading' => array(
					'family' => 'Spectral',
					'weight' => '600',
					'styles' => '300,600',
				),
				'text' => array(
					'family' => 'Karla',
					'weight' => '300',
					'styles' => '300,600',
				),
                'keywords' => array('mixed')
			),
			'open-sans' => array(
				'heading' => array(
					'family' => 'Open+Sans',
					'weight' => '800',
					'styles' => '300,400,600,700,800',
				),
				'text' => array(
					'family' => 'Open+Sans',
					'weight' => '400',
					'styles' => '300,400,600,700,800',
				),
                'keywords' => array('sans-serif')
			),
			'archivo-open-sans' => array(
				'heading' => array(
					'family' => 'Archivo',
					'weight' => '700',
					'styles' => '600,700',
				),
				'text' => array(
					'family' => 'Open+Sans',
					'weight' => '400',
					'styles' => '300,400,600,700',
				),
                'keywords' => array('sans-serif')
			)
		);

		$font_order = array(
			'inter',
			'manrope-inter',
			'plus-jakarta-sans',
			'outfit',
			'poppins-dm-sans',
			'poppins-lora',
			'urbanist-inter',
			'sora-inter',
			'space-grotesk-inter',
			'bricolage-grotesque-figtree',
			'cal-sans-inter',
			'funnel-sans-lato',
			'geom-manrope',
			'raleway-open-sans',
			'montserrat-oswald',
			'barlow-lato',
			'mulish-lato',
			'playfair-display-inter',
			'playfair-display-chivo',
			'playfair-display-raleway',
			'dm-serif-display-dm-sans',
			'dm-serif-display-inter',
			'instrument-serif-inter',
			'fraunces-source-sans-3',
			'cormorant-garamond-manrope',
			'newsreader-public-sans',
			'lora-inter',
			'plus-jakarta-sans-lora',
			'bitter-lato',
			'caladea-nunito',
			'arapey-lato',
			'quattrocento-nunito',
			'urbanist-lora',
			'work-sans-merriweather',
			'noto-sans-inter',
			'roboto-condensed-roboto',
			'spectral-karla',
			'open-sans',
			'archivo-open-sans',
			'libre-baskerville-source-sans-3'
		);

		$ordered_fonts = array();
		foreach( $font_order as $font_key ) {
			if( isset( $fonts[$font_key] ) ) {
				$ordered_fonts[$font_key] = $fonts[$font_key];
			}
		}
		$fonts = $ordered_fonts + $fonts;

		/*
		 *
		 * 'montserrat-work-sans'
		 * 'crimson-text-work-sans'
		 * 'quicksand'
		 * 'abril-fatface-roboto'
		 * 'prata-lato'
		 * 'comfortaa-montserrat'
		 * 'fira-sans'
		 * 'merriweather-lora'
		 * 'roboto-slab-roboto'
		 * 'poppins-lato'
		 * 'yeseva-one-josefin-sans'
		 * 'cardo-josefin-sans'
		 * 'noto-sans-source-sans-pro'
		 * 'merriweather-sans-lato'
		 * 'source-sans-pro-raleway'
		 * 'oxygen-noto-serif'
		 * 'arvo-lato'
		 * 'merriweather-sans-dm-sans'
		 * 'work-sans-open-sans'
		 * 'neuton-work-sans'
		 *
		 * 'Lil Grotesk'
		 * 'Muli' is represented by the current Google Fonts family 'Mulish'.
		 */



        if( $output === 'all' ) {
			return $fonts;
		}



        if( ! $key ) {
            return $fonts;
        }

        $data = isset( $fonts[$key] ) ? $fonts[$key] : '';

		return $data;

    }

endif;
