<?php

if ( ! class_exists( 'WPHAVE_Google_Font_Loader' ) ) :

	/** Owns all WordPress enqueueing for externally loaded Google fonts. */

	class WPHAVE_Google_Font_Loader {

		/** Build separate URLs so an unused provider entry cannot block assigned typography. */

		public static function urls() {
			if( WPHAVE_Fonts::loading_mode() !== 'mixed' ) return array();
			$fonts = array_values( array_filter( WPHAVE_Fonts::active_fonts(), fn( $font ) => ( $font['type'] ?? '' ) === 'google-fonts' && ( $font['loadable'] ?? true ) ) );
			$assigned = array_values( array_filter( $fonts, fn( $font ) => ( $font['source'] ?? '' ) === 'global-styles' || in_array( 'global-styles', $font['usageSources'] ?? array(), true ) || ! empty( $font['roles'] ) ) );
			$assigned_keys = array_fill_keys( array_map( fn( $font ) => WPHAVE_Font_Identity::key( $font['family'] ?? '' ), $assigned ), true );
			$available = array_values( array_filter( $fonts, fn( $font ) => ! isset( $assigned_keys[WPHAVE_Font_Identity::key( $font['family'] ?? '' )] ) ) );
			$urls = array();

			// Google CSS2 chooses unicode subsets from request negotiation and exposes no
			// subset parameter. Subset selection therefore belongs only to local downloads.
			foreach( array( 'assigned' => $assigned, 'available' => $available ) as $group => $group_fonts ) {
				$families = WPHAVE_Font_Assignments::google_query_fragments( $group_fonts );
				$url = esc_url_raw( WPHAVE_Google_Font_Query::css2_url( $families, WPHAVE_Fonts::font_display() ) );
				if( $url ) $urls[$group] = $url;
			}

			return $urls;
		}

		/** Preserve the public combined URL API for diagnostics and legacy consumers. */

		public static function url() {
			if( WPHAVE_Fonts::loading_mode() !== 'mixed' ) return '';
			$fonts = array_values( array_filter( WPHAVE_Fonts::active_fonts(), fn( $font ) => ( $font['type'] ?? '' ) === 'google-fonts' && ( $font['loadable'] ?? true ) ) );

			return esc_url_raw( WPHAVE_Google_Font_Query::css2_url( WPHAVE_Font_Assignments::google_query_fragments( $fonts ), WPHAVE_Fonts::font_display() ) );
		}

		public static function enqueue() {
			if( wphave_data_get( 'site_settings', 'fonts.external.google.async' ) ) return;
			foreach( self::urls() as $group => $url ) wp_enqueue_style( 'wphave-google-fonts-' . sanitize_key( $group ), $url, array(), null, 'all' );
		}

		public static function enqueue_async() {
			if( WPHAVE_Fonts::loading_mode() !== 'mixed' || ! wphave_data_get( 'site_settings', 'fonts.external.google.async' ) ) return;
			$urls = array_values( self::urls() );
			if( ! $urls ) return;
			$path = 'inc/features/fonts/assets/js/google-fonts-async.js';
			wp_register_script( 'wphave-google-fonts-async', wphave_asset_url( $path ), array(), WPHAVE_Asset_Registry::version( $path ), true );
			// Pass the canonical CSS2 URL instead of loading Google's third-party
			// WebFont Loader. This preserves display/subset settings and removes an
			// unnecessary executable dependency from the visitor-facing frontend.
			wp_localize_script( 'wphave-google-fonts-async', 'WP_JS_Var_GOOGLE_FONTS', array( 'urls' => $urls ) );
			wp_enqueue_script( 'wphave-google-fonts-async' );
		}
	}

endif;
