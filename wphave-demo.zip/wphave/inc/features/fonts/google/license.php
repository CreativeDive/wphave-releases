<?php

if ( ! class_exists( 'WPHAVE_Google_Font_License' ) ) :

	/** Resolve complete per-family licenses from the official google/fonts repository. */

	class WPHAVE_Google_Font_License {

		const MIN_LICENSE_BYTES = 2000;
		const MAX_LICENSE_BYTES = 262144;

		/** Return verified license metadata and its complete text, or fail closed. */

		public static function resolve( $family ) {
			$slug = preg_replace( '/[^a-z0-9]/', '', strtolower( remove_accents( WPHAVE_Fonts::canonical_font_family( $family ) ) ) );
			if( ! $slug ) return new WP_Error( 'google_font_license_missing', __( 'The font license could not be identified.', 'wphave' ), array( 'status' => 422 ) );

			$candidates = array(
				array( 'type' => 'OFL-1.1', 'path' => 'ofl/' . $slug . '/OFL.txt', 'marker' => 'SIL OPEN FONT LICENSE Version 1.1' ),
				array( 'type' => 'Apache-2.0', 'path' => 'apache/' . $slug . '/LICENSE.txt', 'marker' => 'Apache License' ),
				array( 'type' => 'UFL-1.0', 'path' => 'ufl/' . $slug . '/LICENCE.txt', 'marker' => 'UBUNTU FONT LICENCE' ),
				array( 'type' => 'UFL-1.0', 'path' => 'ufl/' . $slug . '/UFL.txt', 'marker' => 'UBUNTU FONT LICENCE' ),
			);

			foreach( $candidates as $candidate ) {
				$url = 'https://raw.githubusercontent.com/google/fonts/main/' . $candidate['path'];
				// SECURITY INVARIANT: License text is accepted only from a fixed official
				// HTTPS origin without redirects, within strict size bounds and with the
				// marker belonging to the expected license family.
				$response = wp_safe_remote_get( $url, array( 'timeout' => 15, 'redirection' => 0, 'sslverify' => true, 'limit_response_size' => self::MAX_LICENSE_BYTES + 1, 'user-agent' => 'wphave WordPress Font License Resolver' ) );
				if( is_wp_error( $response ) || (int) wp_remote_retrieve_response_code( $response ) !== 200 ) continue;
				$text = str_replace( "\r\n", "\n", (string) wp_remote_retrieve_body( $response ) );
				// A marker alone is not enough: reject truncated error/proxy responses so the
				// complete redistribution terms are always stored beside the font files.
				if( strlen( $text ) < self::MIN_LICENSE_BYTES || strlen( $text ) > self::MAX_LICENSE_BYTES || ! str_contains( $text, $candidate['marker'] ) ) continue;

				$marker_position = strpos( $text, $candidate['marker'] );
				$copyright = trim( substr( $text, 0, $marker_position === false ? 0 : $marker_position ) );

				return array(
					'type' => $candidate['type'],
					'sourceUrl' => $url,
					'copyright' => sanitize_textarea_field( $copyright ),
					'text' => $text,
				);
			}

			return new WP_Error( 'google_font_license_unavailable', __( 'The official license for this Google Font could not be verified. No font files were installed.', 'wphave' ), array( 'status' => 502 ) );
		}
	}

endif;
