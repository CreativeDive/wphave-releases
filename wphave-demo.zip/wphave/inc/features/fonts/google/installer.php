<?php

require_once wphave_dir() . 'inc/features/security/rate-limiter.php';

if (!class_exists('WPHAVE_Google_Font_Installer')):
	/** Downloads, validates and atomically registers Google fonts as local files. */

	class WPHAVE_Google_Font_Installer {
		const MAX_FILE_BYTES = 5242880;
		const MAX_FILES = 32;
		const MAX_TOTAL_BYTES = 26214400;
		const MAX_CSS_BYTES = 1048576;
		const MAX_VARIANTS = 24;
		const MAX_SUBSETS = 16;
		const CSS_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36';
		private static $lock_held = false;

		/** Materialize validated bytes before the font manifest grants loadable status. */
		private static function publish_file(string $path, string $contents): bool {
			$temporary = @tempnam(sys_get_temp_dir(), 'wphave-font-');
			if ($temporary === false) {
				return false;
			}
			try {
				$checksum = hash('sha256', $contents);
				WPHAVE_Security_Atomic_File::write($temporary, $contents, 'Font staging failed.');
				// PUBLICATION INVARIANT: Manifest registration follows complete verified
				// materialization. Exclusive creation needs no hardlinks in PHP-WebAssembly;
				// this path must never replace already registered assets or private state.
				WPHAVE_Security_Atomic_File::copy_verified_unpublished(
					$temporary,
					$path,
					$checksum,
					'The font asset could not be materialized.',
					WPHAVE_Security_File_Permissions::for_new_public_file($path),
				);
				return true;
			} catch (RuntimeException $error) {
				return false;
			} finally {
				// The private random staging file belongs exclusively to this invocation.
				@unlink($temporary);
			}
		}

		public static function install(
			$family,
			$variants = [],
			$subsets = [],
			$authorization_guard = null,
		) {
			$family = WPHAVE_Fonts::canonical_font_family(sanitize_text_field($family));
			if ($family && !preg_match('/^[\p{L}\p{N} _.-]+$/u', $family)) {
				return new WP_Error(
					'invalid_font_family',
					__('The font family contains unsupported characters.', 'wphave'),
					['status' => 400],
				);
			}
			if (!$family) {
				return new WP_Error('missing_font_family', __('Missing font family.', 'wphave'), [
					'status' => 400,
				]);
			}
			$variants =
				is_array($variants) && !empty($variants)
					? array_values(
						array_unique(array_filter(array_map('sanitize_text_field', $variants))),
					)
					: ['regular'];
			$subsets = is_array($subsets)
				? array_values(array_unique(array_filter(array_map('sanitize_key', $subsets))))
				: [];
			if (count($variants) > self::MAX_VARIANTS || count($subsets) > self::MAX_SUBSETS) {
				return new WP_Error(
					'font_request_too_large',
					__('The font request contains too many variants or subsets.', 'wphave'),
					['status' => 413],
				);
			}
			foreach ($variants as $variant) {
				if (!preg_match('/^(?:regular|italic|[1-9]00(?:italic)?)$/', $variant)) {
					return new WP_Error(
						'invalid_font_variant',
						__('The font request contains an invalid variant.', 'wphave'),
						['status' => 400],
					);
				}
			}
			foreach ($subsets as $subset) {
				if (strlen($subset) > 32 || !preg_match('/^[a-z0-9-]+$/', $subset)) {
					return new WP_Error(
						'invalid_font_subset',
						__('The font request contains an invalid subset.', 'wphave'),
						['status' => 400],
					);
				}
			}
			$catalog_variants = WPHAVE_Google_Font_Catalog::variants($family);
			$catalog_subsets = WPHAVE_Google_Font_Catalog::subsets($family);
			if (!$catalog_variants) {
				return new WP_Error(
					'unknown_google_font',
					__('The selected Google Font is not part of the bundled catalogue.', 'wphave'),
					['status' => 400],
				);
			}
			foreach ($variants as $variant) {
				if (!WPHAVE_Google_Font_Catalog::has_variant($family, $variant)) {
					return new WP_Error(
						'unavailable_google_font_variant',
						__('The selected variant is not published for this Google Font.', 'wphave'),
						['status' => 400],
					);
				}
			}
			foreach ($subsets as $subset) {
				if (!in_array($subset, $catalog_subsets, true)) {
					return new WP_Error(
						'unavailable_google_font_subset',
						__(
							'The selected character set is not published for this Google Font.',
							'wphave',
						),
						['status' => 400],
					);
				}
			}
			if (!class_exists('WPHAVE_Option_Mutations')) {
				return new WP_Error(
					'font_lock_unavailable',
					__('Safe font file locking is not available.', 'wphave'),
					['status' => 503],
				);
			}

			if (!self::$lock_held) {
				$rate_key = 'wphave_font_install_' . get_current_user_id();
				$requests = WPHAVE_Rate_Limiter::increment($rate_key, 5 * MINUTE_IN_SECONDS);
				if ($requests > 20) {
					return new WP_Error(
						'font_install_rate_limited',
						__('Too many font download requests. Please wait a few minutes.', 'wphave'),
						['status' => 429],
					);
				}

				return WPHAVE_Option_Mutations::with_lock(
					'font_install_' . sanitize_title($family),
					function () use ($family, $variants, $subsets, $authorization_guard) {
						self::$lock_held = true;
						try {
							return self::install(
								$family,
								$variants,
								$subsets,
								$authorization_guard,
							);
						} finally {
							self::$lock_held = false;
						}
					},
				);
			}

			$css_url = WPHAVE_Google_Font_Query::url(
				[['font' => $family, 'variants' => $variants]],
				WPHAVE_Fonts::font_display(),
			);
			if (!$css_url) {
				return new WP_Error(
					'invalid_font_request',
					__('The Google Fonts request could not be built.', 'wphave'),
					['status' => 400],
				);
			}
			$license = WPHAVE_Google_Font_License::resolve($family);
			if (is_wp_error($license)) {
				return $license;
			}

			// Google varies its CSS response by browser capability. A shortened custom
			// user agent receives one legacy TTF without subset labels or unicode ranges,
			// which makes a validated subset download impossible. Keep a complete modern
			// browser profile here so the CSS2 endpoint returns labelled WOFF2 faces; the
			// downloaded URLs and signatures are still independently restricted below.
			// TRANSPORT INVARIANT: CSS metadata must be complete before it can grant
			// candidate font-file URLs. Reserve and reject one overflow sentinel byte.
			$css_response = wp_safe_remote_get($css_url, [
				'timeout' => 20,
				'redirection' => 0,
				'sslverify' => true,
				'limit_response_size' => self::MAX_CSS_BYTES + 1,
				'user-agent' => self::CSS_USER_AGENT,
				'headers' => ['Accept' => 'text/css,*/*;q=0.1'],
			]);
			if (is_wp_error($css_response)) {
				return $css_response;
			}
			if ((int) wp_remote_retrieve_response_code($css_response) !== 200) {
				return new WP_Error(
					'google_fonts_css_failed',
					__('The Google Fonts CSS could not be loaded.', 'wphave'),
					['status' => 502],
				);
			}

			$css_body = (string) wp_remote_retrieve_body($css_response);
			if (strlen($css_body) > self::MAX_CSS_BYTES) {
				return new WP_Error(
					'google_fonts_css_too_large',
					__('The Google Fonts CSS exceeded the download limit.', 'wphave'),
					['status' => 502],
				);
			}
			$font_faces = self::parse_font_faces($css_body);
			if ($subsets) {
				if (!array_filter($font_faces, fn($font_face) => !empty($font_face['subset']))) {
					return new WP_Error(
						'google_fonts_subset_metadata_missing',
						__(
							'Google Fonts did not identify the character sets in its response. The download was stopped to avoid installing an incomplete package.',
							'wphave',
						),
						['status' => 502],
					);
				}
				$font_faces = array_values(
					array_filter(
						$font_faces,
						fn($font_face) => in_array($font_face['subset'] ?? '', $subsets, true),
					),
				);
			}
			if (empty($font_faces)) {
				return new WP_Error(
					$subsets ? 'google_fonts_subset_unavailable' : 'google_fonts_empty_css',
					$subsets
						? __(
							'Google Fonts did not return the selected character sets. No files were installed.',
							'wphave',
						)
						: __('No downloadable font files were found.', 'wphave'),
					['status' => 502],
				);
			}
			if (!self::complete_response($font_faces, $variants, $subsets)) {
				return new WP_Error(
					'google_fonts_incomplete_response',
					__(
						'Google Fonts did not return every requested variant and character set. No partial package was installed.',
						'wphave',
					),
					['status' => 502],
				);
			}
			if (count($font_faces) > self::MAX_FILES) {
				return new WP_Error(
					'google_fonts_too_many_files',
					__('The font package contains too many files.', 'wphave'),
					['status' => 413],
				);
			}

			$upload_dir = WPHAVE_Local_Font_Library::upload_dir();
			$base_path = $upload_dir['basedir'] ?? '';
			$base_url = $upload_dir['baseurl'] ?? '';
			if (!$base_path || !$base_url) {
				return new WP_Error(
					'fonts_upload_dir_missing',
					__('The fonts upload directory is not available.', 'wphave'),
					['status' => 500],
				);
			}
			if (!file_exists($base_path)) {
				wp_mkdir_p($base_path);
			}
			if (!is_dir($base_path) || !is_writable($base_path)) {
				return new WP_Error(
					'fonts_upload_dir_not_writable',
					__('The fonts upload directory is not writable.', 'wphave'),
					['status' => 500],
				);
			}

			$installed_variants = [];
			$created_variants = [];
			$existing_variants = [];
			foreach (WPHAVE_Local_Font_Library::fonts() as $installed_font) {
				if (
					strcasecmp(
						WPHAVE_Fonts::canonical_font_family($installed_font['family'] ?? ''),
						$family,
					) !== 0 ||
					!in_array(
						'google-fonts',
						$installed_font['sources'] ?? [$installed_font['source'] ?? ''],
						true,
					)
				) {
					continue;
				}
				foreach ($installed_font['variants'] ?? [] as $variant) {
					$existing_variants[self::variant_key($variant)] = $variant;
				}
			}

			$family_slug = sanitize_title($family);
			$total_bytes = 0;
			$download_failed = false;
			foreach ($font_faces as $font_face) {
				$file_url = $font_face['url'] ?? '';
				if (
					strcasecmp(
						WPHAVE_Fonts::canonical_font_family($font_face['family'] ?? ''),
						$family,
					) !== 0 ||
					!self::allowed_url($file_url)
				) {
					$download_failed = true;
					continue;
				}

				$variant_key = self::variant_key([
					'fontStyle' => $font_face['style'] ?? 'normal',
					'fontWeight' => $font_face['weight'] ?? '400',
					'unicodeRange' => $font_face['unicodeRange'] ?? '',
				]);
				if (isset($existing_variants[$variant_key])) {
					$installed_variants[] = array_merge($existing_variants[$variant_key], [
						'subset' => sanitize_key($font_face['subset'] ?? ''),
					]);
					continue;
				}

				// SECURITY INVARIANT: Remote CSS supplies candidates, never download
				// authority. Every font URL is independently host-restricted, fetched
				// without redirects, size-bounded and signature-checked before publication.
				$file_response = wp_safe_remote_get($file_url, [
					'timeout' => 30,
					'redirection' => 0,
					'sslverify' => true,
					'limit_response_size' => self::MAX_FILE_BYTES + 1,
				]);
				if (
					is_wp_error($file_response) ||
					(int) wp_remote_retrieve_response_code($file_response) !== 200
				) {
					$download_failed = true;
					continue;
				}

				$file_body = wp_remote_retrieve_body($file_response);
				$extension = self::extension($file_url, $font_face['format'] ?? '');
				$file_bytes = strlen($file_body);
				$total_bytes += $file_bytes;
				if (
					!$file_body ||
					!$extension ||
					$file_bytes > self::MAX_FILE_BYTES ||
					$total_bytes > self::MAX_TOTAL_BYTES ||
					!WPHAVE_Font_File_Security::has_valid_body_signature($file_body, $extension)
				) {
					$download_failed = true;
					continue;
				}

				// AUTHORIZATION/TOCTOU INVARIANT: Remote transports and their WordPress
				// filters run after REST admission. A downloaded candidate cannot retain
				// stale caller authority when it reaches the filesystem publication sink.
				$authorization = self::authorize_commit($authorization_guard);
				if (is_wp_error($authorization)) {
					self::remove_files($base_path, $created_variants);
					return $authorization;
				}

				$file_name = wp_unique_filename(
					$base_path,
					$family_slug .
						'-' .
						sanitize_key($font_face['style'] ?? 'normal') .
						'-' .
						sanitize_text_field($font_face['weight'] ?? '400') .
						'.' .
						$extension,
				);
				$file_path = path_join($base_path, $file_name);
				if (!self::publish_file($file_path, $file_body)) {
					$download_failed = true;
					continue;
				}

				$created_variant = [
					'file' => $file_name,
					'url' => trailingslashit($base_url) . $file_name,
					'fontStyle' => $font_face['style'] ?? 'normal',
					'fontWeight' => $font_face['weight'] ?? '400',
					'unicodeRange' => $font_face['unicodeRange'] ?? '',
					'subset' => sanitize_key($font_face['subset'] ?? ''),
				];
				$installed_variants[] = $created_variant;
				$created_variants[] = $created_variant;
			}

			// SECURITY INVARIANT: A requested font package is atomic at the workflow
			// boundary. Any rejected or failed member removes every file created by
			// this attempt, so incomplete remote input cannot become installed state.
			if ($download_failed) {
				self::remove_files($base_path, $created_variants);
				return new WP_Error(
					'google_fonts_incomplete',
					__(
						'The complete font package could not be downloaded safely. No partial installation was kept.',
						'wphave',
					),
					['status' => 502],
				);
			}
			if (empty($installed_variants)) {
				return new WP_Error(
					'google_fonts_install_failed',
					__('The Google Font files could not be installed.', 'wphave'),
					['status' => 500],
				);
			}

			$license_file = sanitize_file_name($family_slug . '-LICENSE.txt');
			$license_path = path_join($base_path, $license_file);
			$license_created = false;
			if (
				!is_readable($license_path) ||
				hash_file('sha256', $license_path) !== hash('sha256', $license['text'])
			) {
				$authorization = self::authorize_commit($authorization_guard);
				if (is_wp_error($authorization)) {
					self::remove_files($base_path, $created_variants);
					return $authorization;
				}

				$license_file = wp_unique_filename($base_path, $license_file);
				$license_path = path_join($base_path, $license_file);
				if (!self::publish_file($license_path, $license['text'])) {
					self::remove_files($base_path, $created_variants);
					return new WP_Error(
						'google_font_license_write_failed',
						__(
							'The verified font license could not be stored. No font files were installed.',
							'wphave',
						),
						['status' => 500],
					);
				}
				$license_created = true;
			}
			$license_metadata = [
				'type' => $license['type'],
				'file' => $license_file,
				'sourceUrl' => $license['sourceUrl'],
				'copyright' => $license['copyright'],
				'sha256' => hash('sha256', $license['text']),
			];
			// Existing variants already own immutable manifest records. Re-registering
			// those files would correctly violate the one-file/one-record invariant when
			// a stale client retries a download or supplements a partial installation.
			// Persist only files created by this transaction and merge the existing
			// variants into the response below.
			if (!empty($created_variants)) {
				// AUTHORIZATION/COMMIT INVARIANT: Filesystem publication does not grant
				// authority to register persistent manifest state. Revalidate the REST
				// caller independently at the final metadata commit boundary.
				$authorization = self::authorize_commit($authorization_guard);
				if (is_wp_error($authorization)) {
					self::remove_files($base_path, $created_variants);
					if ($license_created) {
						wp_delete_file($license_path);
					}
					return $authorization;
				}

				$manifest_result = WPHAVE_Local_Fonts::record_variants(
					$family,
					$created_variants,
					'google-fonts',
					$license_metadata,
				);
				if (is_wp_error($manifest_result) || !$manifest_result) {
					self::remove_files($base_path, $created_variants);
					if ($license_created) {
						wp_delete_file($license_path);
					}
					return is_wp_error($manifest_result)
						? $manifest_result
						: new WP_Error(
							'font_manifest_write_failed',
							__('The downloaded font metadata could not be saved.', 'wphave'),
							['status' => 500],
						);
				}
			}

			return [
				'createdFiles' => array_values(
					array_filter(
						array_map(
							fn($variant) => sanitize_file_name($variant['file'] ?? ''),
							$created_variants,
						),
					),
				),
				'font' => [
					'family' => $family,
					'type' => 'local',
					'source' => 'google-fonts',
					'license' => $license_metadata,
					'variants' => WPHAVE_Local_Font_Library::unique_variants($installed_variants),
				],
			];
		}

		/** Revalidate an optional transport-owned authority policy at a commit sink. */

		private static function authorize_commit($authorization_guard) {
			if (!is_callable($authorization_guard)) {
				return true;
			}

			$result = call_user_func($authorization_guard);

			return is_wp_error($result) ? $result : true;
		}

		private static function parse_font_faces($css) {
			// Google labels each CSS2 face with its character subset (for example
			// `/* latin-ext */`). Preserve that label so the server can enforce the
			// user's subset selection instead of relying on an unsupported URL option.
			preg_match_all(
				'/(?:\/\*\s*([a-z0-9-]+)\s*\*\/\s*)?(@font-face\s*\{[^}]+\})/i',
				$css,
				$matches,
				PREG_SET_ORDER,
			);
			$faces = [];
			foreach ($matches as $match) {
				$face = $match[2] ?? '';
				preg_match('/font-family:\s*[\'\"]?([^;\'\"]+)/i', $face, $family);
				preg_match('/font-style:\s*([^;]+)/i', $face, $style);
				preg_match('/font-weight:\s*([^;]+)/i', $face, $weight);
				preg_match('/unicode-range:\s*([^;]+)/i', $face, $range);
				preg_match(
					'/src:\s*url\([\'\"]?([^\'\")]+)[\'\"]?\)\s*format\([\'\"]?([^\'\")]+)[\'\"]?\)/i',
					$face,
					$source,
				);
				if (empty($source[1])) {
					continue;
				}
				$faces[] = [
					'family' => trim($family[1] ?? ''),
					'style' => trim($style[1] ?? 'normal'),
					'weight' => trim($weight[1] ?? '400'),
					'url' => esc_url_raw($source[1]),
					'format' => sanitize_key($source[2] ?? ''),
					'unicodeRange' => trim($range[1] ?? ''),
					'subset' => sanitize_key($match[1] ?? ''),
				];
			}

			return $faces;
		}

		/** Require at least one face for every requested variant/subset combination. */

		private static function complete_response($faces, $variants, $subsets) {
			$available = [];
			foreach ($faces as $face) {
				$available[
					sanitize_key($face['style'] ?? 'normal') .
						':' .
						sanitize_text_field($face['weight'] ?? '400') .
						':' .
						sanitize_key($face['subset'] ?? '')
				] = true;
			}
			foreach ($variants as $variant) {
				$style = str_contains($variant, 'italic') ? 'italic' : 'normal';
				$weight = in_array($variant, ['regular', 'italic'], true)
					? '400'
					: preg_replace('/[^0-9]/', '', $variant);
				if ($subsets) {
					foreach ($subsets as $subset) {
						if (empty($available[$style . ':' . $weight . ':' . $subset])) {
							return false;
						}
					}
				} elseif (
					!array_filter(
						array_keys($available),
						fn($key) => str_starts_with($key, $style . ':' . $weight . ':'),
					)
				) {
					return false;
				}
			}

			return true;
		}

		private static function variant_key($variant) {
			return sanitize_key($variant['fontStyle'] ?? 'normal') .
				':' .
				sanitize_text_field($variant['fontWeight'] ?? '400') .
				':' .
				strtolower(preg_replace('/\s+/', '', (string) ($variant['unicodeRange'] ?? '')));
		}

		private static function allowed_url($url) {
			$parts = wp_parse_url($url);
			return ($parts['scheme'] ?? '') === 'https' &&
				($parts['host'] ?? '') === 'fonts.gstatic.com';
		}

		private static function extension($url, $format) {
			$extension = strtolower(
				pathinfo((string) wp_parse_url($url, PHP_URL_PATH), PATHINFO_EXTENSION),
			);
			if (in_array($extension, ['ttf', 'otf', 'woff', 'woff2'], true)) {
				return $extension;
			}
			return ['truetype' => 'ttf', 'opentype' => 'otf', 'woff' => 'woff', 'woff2' => 'woff2'][
				$format
			] ?? '';
		}

		private static function remove_files($base_path, $variants) {
			foreach ($variants as $variant) {
				$path = path_join($base_path, sanitize_file_name($variant['file'] ?? ''));
				if (is_file($path)) {
					wp_delete_file($path);
				}
			}
		}
	}
endif;
