<?php

/**
 * Handles frontend SEO output, SEO post meta registration and SEO redirects.
 */

if (!defined('ABSPATH')) {
	exit();
}

/**
 * Determine whether XML Sitemap settings and mutations are available.
 *
 * An explicitly stored Sitemap configuration remains effective after a
 * downgrade. Pro access controls future changes, not existing public output.
 *
 * @return bool Whether a valid Pro entitlement is available.
 */

function wphave_seo_sitemap_has_pro_access() {
	return function_exists('wphave_has_pro_access') && wphave_has_pro_access();
}

/**
 * Preserve stored XML Sitemap settings without Pro access.
 *
 * The rest of SEO remains Free and writable. Only the nested `seo.sitemap`
 * branch is restored, so unrelated SEO changes cannot overwrite a former Pro
 * user's active Sitemap settings with disabled UI defaults.
 *
 * @param array $data Prepared site settings.
 * @param array $config Site-settings resource configuration.
 * @return array Entitlement-safe site settings.
 */

function wphave_preserve_seo_sitemap_pro_settings(array $data, array $config): array {
	if (wphave_seo_sitemap_has_pro_access() || !class_exists('WPHAVE_Data_Resources')) {
		return $data;
	}

	$current = WPHAVE_Data_Resources::get('site_settings', false);
	$current_sitemap = $current['seo']['sitemap'] ?? null;

	if (is_array($current_sitemap)) {
		$data['seo']['sitemap'] = $current_sitemap;
	} else {
		unset($data['seo']['sitemap']);
	}

	return $data;
}

add_filter(
	'wphave_prepare_site_settings_for_write',
	'wphave_preserve_seo_sitemap_pro_settings',
	20,
	2,
);

class WPHAVE_SEO {
	/**
	 * Shared SEO instance.
	 *
	 * @var WPHAVE_SEO|null
	 */

	private static ?WPHAVE_SEO $instance = null;

	/**
	 * REST-enabled SEO post meta fields and their schema types.
	 *
	 * @var array<string,array<string,string>>
	 */

	private array $post_meta = [
		'wphave_seo_title' => [
			'type' => 'string',
		],
		'wphave_seo_description' => [
			'type' => 'string',
		],
		'wphave_seo_focus_keywords' => [
			'type' => 'array',
			'items' => 'string',
		],
		'wphave_seo_synonyms' => [
			'type' => 'array',
			'items' => 'string',
		],
		'wphave_seo_robots_meta' => [
			'type' => 'string',
		],
		'wphave_seo_robots_sub_meta' => [
			'type' => 'array',
			'items' => 'string',
		],
		'wphave_seo_canonical_url' => [
			'type' => 'string',
		],
		'wphave_seo_social_title' => [
			'type' => 'string',
		],
		'wphave_seo_social_description' => [
			'type' => 'string',
		],
		'wphave_seo_social_image' => [
			'type' => 'number',
		],
		'wphave_seo_open_graph_title' => [
			'type' => 'string',
		],
		'wphave_seo_open_graph_description' => [
			'type' => 'string',
		],
		'wphave_seo_open_graph_image' => [
			'type' => 'number',
		],
		'wphave_seo_x_card_title' => [
			'type' => 'string',
		],
		'wphave_seo_x_card_description' => [
			'type' => 'string',
		],
		'wphave_seo_x_card_image' => [
			'type' => 'number',
		],
		'wphave_seo_pinterest_description' => [
			'type' => 'string',
		],
		'wphave_seo_pinterest_image' => [
			'type' => 'number',
		],
	];

	/**
	 * Get the shared SEO instance.
	 *
	 * @return WPHAVE_SEO
	 */

	public static function instance(): WPHAVE_SEO {
		if (self::$instance === null) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Register SEO hooks.
	 */

	public function __construct() {
		add_action('init', [$this, 'register_post_meta']);
		add_action('wp_head', [$this, 'render_meta_data'], 1);
		add_action('wp_head', [$this, 'render_webmaster_verification'], 1);
		add_action('wp_head', [$this, 'render_referrer_policy']);
		add_action('wp', [$this, 'redirect_404_to_home']);
		add_action('template_redirect', [$this, 'redirect_attachment_page'], 10);

		add_filter('get_canonical_url', [$this, 'filter_canonical_url'], 10, 2);
		// Decorate the completed Core title; the pre-filter receives an empty string.
		add_filter('document_title', [$this, 'filter_document_title']);
		add_filter('wp_robots', [$this, 'filter_robots_meta']);
	}

	/**
	 * Check whether the built-in SEO feature is disabled in plugin settings.
	 *
	 * @return bool
	 */

	public function is_disabled(): bool {
		$settings = wphave_data_get('site_settings', 'seo');

		// Disabled by default
		return isset($settings['isEnabled']) ? !(bool) $settings['isEnabled'] : false;
	}

	/**
	 * Check the WordPress search engine visibility option without using diagnostics collectors.
	 *
	 * @return bool
	 */

	public function is_visible_for_search_engines(): bool {
		return class_exists('WPHAVE_Multisite')
			? WPHAVE_Multisite::search_engine_visibility()
			: (int) get_option('blog_public', 1) === 1;
	}

	/**
	 * Register SEO meta fields for public post types except attachments.
	 */

	public function register_post_meta(): void {
		$post_types = get_post_types(
			[
				'public' => true,
			],
			'names',
		);

		foreach ($post_types as $post_type) {
			if ($post_type === 'attachment') {
				continue;
			}

			foreach ($this->post_meta as $meta_key => $args) {
				register_post_meta($post_type, $meta_key, $this->get_post_meta_args($args));
			}
		}
	}

	/**
	 * Build WordPress post meta registration arguments from a short field schema.
	 *
	 * @param array<string,string> $args Field schema.
	 * @return array<string,mixed>
	 */

	private function get_post_meta_args(array $args): array {
		$type = $args['type'] ?? 'string';
		$meta_args = [
			'single' => true,
			'type' => $type,
			'show_in_rest' => true,
			'auth_callback' => [$this, 'can_edit_post_meta'],
			'sanitize_callback' => [$this, 'sanitize_post_meta_value'],
		];

		if ($type === 'array') {
			$meta_args['show_in_rest'] = [
				'schema' => [
					'type' => 'array',
					'items' => [
						'type' => $args['items'] ?? 'string',
					],
				],
			];
		}

		return $meta_args;
	}

	/**
	 * Sanitize SEO metadata consistently across REST and internal writes.
	 *
	 * @param mixed  $value Meta value.
	 * @param string $meta_key Registered SEO meta key.
	 * @return mixed Sanitized value matching the registered schema.
	 */

	public function sanitize_post_meta_value($value, string $meta_key) {
		if (in_array($meta_key, ['wphave_seo_focus_keywords', 'wphave_seo_synonyms'], true)) {
			if (!is_array($value)) {
				return [];
			}

			return array_values(
				array_unique(array_filter(array_map('sanitize_text_field', $value))),
			);
		}

		if ($meta_key === 'wphave_seo_robots_sub_meta') {
			if (!is_array($value)) {
				return [];
			}

			$allowed = ['nofollow', 'noarchive', 'nosnippet', 'noimageindex', 'notranslate'];
			$directives = array_map('sanitize_key', $value);

			return array_values(array_unique(array_intersect($directives, $allowed)));
		}

		if ($meta_key === 'wphave_seo_robots_meta') {
			return in_array($value, ['index', 'noindex'], true) ? $value : 'index';
		}

		if ($meta_key === 'wphave_seo_canonical_url') {
			return is_scalar($value) ? esc_url_raw((string) $value) : '';
		}

		if (str_ends_with($meta_key, '_image')) {
			return is_numeric($value) ? absint($value) : 0;
		}

		return is_scalar($value) ? sanitize_text_field((string) $value) : '';
	}

	/**
	 * Check if the current user may edit SEO post meta.
	 *
	 * @return bool
	 */

	public function can_edit_post_meta($allowed = false, $meta_key = '', $object_id = 0): bool {
		$object_id = absint($object_id);

		// SECURITY INVARIANT: SEO metadata inherits the target post's object-level
		// edit capability; general SEO access cannot modify metadata on another post.
		return $object_id
			? current_user_can('edit_post', $object_id)
			: current_user_can('edit_posts');
	}

	/**
	 * Render SEO keyword and description meta tags in the document head.
	 */

	public function render_meta_data(): void {
		if ($this->is_disabled()) {
			return;
		}

		$post = get_post();
		$post_id = $post instanceof WP_Post ? $post->ID : 0;
		$custom_keywords = $post_id
			? get_post_meta($post_id, 'wphave_seo_focus_keywords', true)
			: '';
		$custom_description = $post_id
			? get_post_meta($post_id, 'wphave_seo_description', true)
			: '';

		if (is_array($custom_keywords)) {
			$custom_keywords = implode(
				', ',
				array_filter(array_map('sanitize_text_field', $custom_keywords)),
			);
		}

		if (!$custom_description && $post instanceof WP_Post) {
			$custom_description = get_the_excerpt($post);
		}

		if ($custom_keywords) {
			echo '<meta name="keywords" content="' . esc_attr($custom_keywords) . '">' . "\n";
		}

		if ($custom_description) {
			echo '<meta name="description" content="' . esc_attr($custom_description) . '">' . "\n";
		}
	}

	/**
	 * Render configured webmaster verification meta tags.
	 */

	public function render_webmaster_verification(): void {
		if ($this->is_disabled()) {
			return;
		}

		$verification = wphave_data_get('site_settings', 'seo.webmasterVerification');

		if (!is_array($verification)) {
			return;
		}

		$tags = [
			'google' => 'google-site-verification',
			'bing' => 'msvalidate.01',
			'pinterest' => 'p:domain_verify',
			'yandex' => 'yandex-verification',
		];

		foreach ($tags as $key => $name) {
			$value = isset($verification[$key]) ? trim((string) $verification[$key]) : '';

			if ($value === '') {
				continue;
			}

			echo '<meta name="' . esc_attr($name) . '" content="' . esc_attr($value) . '">' . "\n";
		}
	}

	/**
	 * Replace the canonical URL with a custom SEO canonical URL when available.
	 *
	 * @param string $canonical_url Default canonical URL.
	 * @param WP_Post $post Current post object.
	 * @return string
	 */

	public function filter_canonical_url($canonical_url, $post) {
		if ($this->is_disabled()) {
			return $canonical_url;
		}

		$post_id = $post->ID ?? get_the_ID();
		$custom_canonical_url = get_post_meta($post_id, 'wphave_seo_canonical_url', true);

		if ($custom_canonical_url) {
			return $custom_canonical_url;
		}

		return $canonical_url;
	}

	/**
	 * Apply SEO title settings and custom SEO title meta to the document title.
	 *
	 * @param string $title Default document title.
	 * @return string
	 */

	public function filter_document_title($title): string {
		if ($this->is_disabled()) {
			return $title;
		}

		$post_id = get_the_ID();
		$title_prefix = wphave_data_get('site_settings', 'seo.titlePrefix', '') ?? '';
		$title_suffix = wphave_data_get('site_settings', 'seo.titleSuffix', '') ?? '';
		$title_separator = wphave_data_get('site_settings', 'seo.titleSeparator', ' ') ?? ' ';
		$custom_title = get_post_meta($post_id, 'wphave_seo_title', true);

		if ($custom_title) {
			$title = $custom_title;
		}

		$parts = [];

		if ($title_prefix !== '') {
			$parts[] = $title_prefix;
		}

		$parts[] = $title;

		if ($title_suffix !== '') {
			$parts[] = $title_suffix;
		}

		return esc_html(implode($title_separator, $parts));
	}

	/**
	 * Apply per-post robots settings while respecting WordPress search visibility.
	 *
	 * @param array<string,mixed> $robots WordPress robots directives.
	 * @return array<string,mixed>
	 */

	public function filter_robots_meta(array $robots): array {
		if ($this->is_disabled()) {
			return $robots;
		}

		if (!$this->is_visible_for_search_engines()) {
			return $robots;
		}

		if ($this->should_noindex_current_request()) {
			$robots['index'] = false;
			$robots['follow'] = true;
		}

		if (!is_singular()) {
			return $robots;
		}

		$post_id = get_the_ID();
		$robots_meta = get_post_meta($post_id, 'wphave_seo_robots_meta', true);
		$robots_sub_meta = get_post_meta($post_id, 'wphave_seo_robots_sub_meta', true);

		if (!is_array($robots_sub_meta)) {
			$robots_sub_meta = [];
		}

		$robots_sub_meta = array_map('sanitize_key', $robots_sub_meta);

		if ($robots_meta === 'noindex') {
			$robots['index'] = false;
			$robots['follow'] = true;
		} elseif ($robots_meta === 'index') {
			$robots['index'] = true;
		}

		if (in_array('nofollow', $robots_sub_meta, true)) {
			$robots['follow'] = false;
		}

		if (in_array('noarchive', $robots_sub_meta, true)) {
			$robots['noarchive'] = true;
		}

		if (in_array('nosnippet', $robots_sub_meta, true) && ($robots['index'] ?? null) !== false) {
			$robots['nosnippet'] = true;
		}

		if (in_array('noimageindex', $robots_sub_meta, true)) {
			$robots['noimageindex'] = true;
		}

		if (in_array('notranslate', $robots_sub_meta, true)) {
			$robots['notranslate'] = true;
		}

		return $robots;
	}

	/**
	 * Check whether global noindex defaults should affect the current request.
	 *
	 * @return bool
	 */

	private function should_noindex_current_request(): bool {
		$settings = wphave_data_get('site_settings', 'seo.noindex');

		if (!is_array($settings)) {
			$settings = [];
		}

		$defaults = [
			'search' => true,
			'authorArchives' => false,
			'dateArchives' => true,
			'archives' => false,
			'attachments' => true,
		];

		$settings = array_merge($defaults, $settings);

		if (is_search()) {
			return (bool) $settings['search'];
		}

		if (is_attachment()) {
			return (bool) $settings['attachments'];
		}

		if (is_author()) {
			return (bool) $settings['authorArchives'];
		}

		if (is_date()) {
			return (bool) $settings['dateArchives'];
		}

		if (is_archive()) {
			return (bool) $settings['archives'];
		}

		return false;
	}

	/**
	 * Check whether a post is explicitly marked as noindex.
	 *
	 * @param int $post_id Post ID.
	 * @return bool
	 */

	public function post_is_noindex($post_id): bool {
		return get_post_meta($post_id, 'wphave_seo_robots_meta', true) === 'noindex';
	}

	/**
	 * Check whether a post can be indexed by SEO-driven outputs like the sitemap.
	 *
	 * @param int $post_id Post ID.
	 * @return bool
	 */

	public function is_indexable_post($post_id): bool {
		if ($this->is_disabled()) {
			return false;
		}

		if (!$this->is_visible_for_search_engines()) {
			return false;
		}

		$post = get_post($post_id);
		if (!$post) {
			return false;
		}

		if ($post->post_status !== 'publish') {
			return false;
		}

		$post_type = get_post_type_object($post->post_type);
		if (!$post_type || empty($post_type->public)) {
			return false;
		}

		if (!empty($post->post_password)) {
			return false;
		}

		if ($this->post_is_noindex($post_id)) {
			return false;
		}

		return apply_filters('wphave_is_indexable_post', true, $post_id, $post);
	}

	/**
	 * Render the configured referrer policy meta tag.
	 */

	public function render_referrer_policy(): void {
		$meta_referrer = wphave_data_get('privacy_settings', 'advanced.meta_referrer_policy');

		if (!$meta_referrer || $meta_referrer === 'none') {
			return;
		}

		echo '<meta name="referrer" content="' . esc_html($meta_referrer) . '">';
	}

	/**
	 * Redirect 404 requests to the home URL when the SEO setting is enabled.
	 */

	public function redirect_404_to_home(): void {
		$settings = wphave_data_get('site_settings', 'seo.redirect');
		$is_redirect_enabled = isset($settings['pages404']) ? (bool) $settings['pages404'] : false;

		if (!$is_redirect_enabled) {
			return;
		}

		if (!is_404() || is_admin()) {
			return;
		}

		if (
			(defined('DOING_CRON') && DOING_CRON) ||
			(defined('XMLRPC_REQUEST') && XMLRPC_REQUEST)
		) {
			return;
		}

		wp_redirect(home_url(), 301);
		exit();
	}

	/**
	 * Redirect attachment pages to their media file URL unless this redirect is disabled.
	 */

	public function redirect_attachment_page(): void {
		$settings = wphave_data_get('site_settings', 'seo.redirect');
		$is_redirect_enabled = isset($settings['attachments'])
			? (bool) $settings['attachments']
			: false;

		if (!$is_redirect_enabled) {
			return;
		}

		if (!is_attachment()) {
			return;
		}

		$url = wp_get_attachment_url(get_queried_object_id());

		if (!$url) {
			return;
		}

		wp_safe_redirect($url, 301, 'WordPress');
		exit();
	}
}

WPHAVE_SEO::instance();

require_once __DIR__ . '/sitemap.php';
require_once __DIR__ . '/social-metadata.php';
