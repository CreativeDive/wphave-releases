<?php

/**
 * Handles XML sitemap routing, rendering, REST status and cache invalidation.
 */

if( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPHAVE_Sitemap {

    const QUERY_INDEX = 'wphave_sitemap';
    const QUERY_PAGE = 'wphave_sitemap_page';
    const CACHE_KEY = 'wphave_sitemap_entries_v2';
    const REST_NAMESPACE = 'wphave/v1';

    /**
     * Shared sitemap instance.
     *
     * @var WPHAVE_Sitemap|null
     */

    private static ?WPHAVE_Sitemap $instance = null;

    /**
     * Default sitemap settings stored under seo.sitemap.
     *
     * @var array<string,mixed>
     */

    private array $defaults = array(
        'isEnabled' => false,
        'postTypes' => array( 'post', 'page' ),
        'taxonomies' => array(),
        'perPage' => 2000,
        'cacheTtl' => 600,
        'includeLastmod' => true,
        'addToRobotsTxt' => true,
    );

    /**
     * Get the shared sitemap instance.
     *
     * @return WPHAVE_Sitemap
     */

    public static function instance(): WPHAVE_Sitemap {
        if( self::$instance === null ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Register sitemap hooks.
     */

    public function __construct() {
        add_action( 'init', array( $this, 'register_rewrite_rules' ) );
        add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );
        add_action( 'template_redirect', array( $this, 'maybe_render_sitemap' ) );
        add_action( 'save_post', array( $this, 'flush_cache' ) );
        add_action( 'deleted_post', array( $this, 'flush_cache' ) );
        add_action( 'created_term', array( $this, 'flush_cache' ) );
        add_action( 'edited_term', array( $this, 'flush_cache' ) );
        add_action( 'delete_term', array( $this, 'flush_cache' ) );
        add_action( 'wphave_site_settings_saved', array( $this, 'flush_cache' ) );

        add_filter( 'query_vars', array( $this, 'register_query_vars' ) );
        add_filter( 'redirect_canonical', array( $this, 'disable_canonical_redirect' ), 10, 2 );
        add_filter( 'robots_txt', array( $this, 'add_sitemap_to_robots_txt' ), 20, 2 );
    }

    /**
     * Add sitemap rewrite rules.
     */

    public function register_rewrite_rules(): void {
        add_rewrite_rule( '^wphave-sitemap\.xml/?$', 'index.php?' . self::QUERY_INDEX . '=1', 'top' );
        add_rewrite_rule( '^wphave-sitemap-([0-9]+)\.xml/?$', 'index.php?' . self::QUERY_PAGE . '=$matches[1]', 'top' );
    }

    /**
     * Register sitemap query vars.
     *
     * @param array<int,string> $vars Query vars.
     * @return array<int,string>
     */

    public function register_query_vars( array $vars ): array {
        $vars[] = self::QUERY_INDEX;
        $vars[] = self::QUERY_PAGE;

        return $vars;
    }

    /**
     * Prevent WordPress canonical redirects for sitemap URLs.
     *
     * @param string|false $redirect Redirect URL.
     * @param string $request Requested URL.
     * @return string|false
     */

    public function disable_canonical_redirect( $redirect, $request ) {
        if( strpos( $request, 'wphave-sitemap.xml' ) !== false || strpos( $request, 'wphave-sitemap-' ) !== false ) {
            return false;
        }

        return $redirect;
    }

    /**
     * Render the requested sitemap document.
     */

    public function maybe_render_sitemap(): void {
        $is_index = (int) get_query_var( self::QUERY_INDEX ) === 1;
        $page = (int) get_query_var( self::QUERY_PAGE );

        if( ! $is_index && $page < 1 ) {
            return;
        }

        if( ! $this->is_enabled() ) {
            status_header( 404 );
            nocache_headers();
            exit;
        }

        status_header( 200 );
        nocache_headers();
        header( 'Content-Type: application/xml; charset=utf-8' );
        header( 'X-Robots-Tag: noindex, follow', true );

        if( $is_index ) {
            echo $this->render_index();
            exit;
        }

        echo $this->render_page( $page );
        exit;
    }

    /**
     * Register REST endpoints used by the SEO settings UI.
     */

    public function register_rest_routes(): void {
        register_rest_route( self::REST_NAMESPACE, '/sitemap', array(
            'methods' => 'GET',
            'callback' => array( $this, 'api_status' ),
            'permission_callback' => array( $this, 'can_manage' ),
        ) );

        register_rest_route( self::REST_NAMESPACE, '/sitemap/flush', array(
            'methods' => 'POST',
            'callback' => array( $this, 'api_flush' ),
            'permission_callback' => array( $this, 'can_manage_pro' ),
        ) );
    }

    /**
     * Check if the current user can manage sitemap settings.
     *
     * @return bool
     */

    public function can_manage(): bool {
        return current_user_can( 'manage_options' ) || current_user_can( 'wphave_manage_settings_seo' );
    }

    /**
     * Check whether the current user may mutate Pro Sitemap state.
     *
     * @return bool Whether capability and Pro access are both available.
     */

    public function can_manage_pro(): bool {
        return $this->can_manage() && function_exists( 'wphave_seo_sitemap_has_pro_access' ) && wphave_seo_sitemap_has_pro_access();
    }

    /**
     * Require Sitemap management authority at the final callback boundary.
     *
     * AUTHORIZATION INVARIANT: REST permission callbacks are only an early
     * dispatch gate. Every public callback must repeat the applicable
     * capability and entitlement check immediately before it discloses status
     * or mutates cache and global rewrite state.
     *
     * @param bool $require_pro Whether the operation also requires Pro access.
     * @return true|WP_Error
     */

    private function require_manage_access( bool $require_pro = false ) {
        $allowed = $require_pro ? $this->can_manage_pro() : $this->can_manage();

        if( ! $allowed ) {
            return new WP_Error(
                'wphave_sitemap_forbidden',
                __( 'You are not allowed to manage the sitemap.', 'wphave' ),
                array( 'status' => 403 )
            );
        }

        return true;
    }

    /**
     * Return normalized sitemap status for the settings UI.
     *
     * @return WP_REST_Response|WP_Error
     */

    public function api_status() {
        $authorized = $this->require_manage_access();

        if( is_wp_error( $authorized ) ) {
            return $authorized;
        }

        return rest_ensure_response( $this->get_public_status() );
    }

    /**
     * Flush sitemap caches and rewrite rules from the settings UI.
     *
     * @return WP_REST_Response|WP_Error
     */

    public function api_flush() {
        $authorized = $this->require_manage_access( true );

        if( is_wp_error( $authorized ) ) {
            return $authorized;
        }

        $this->flush_cache();
        $this->register_rewrite_rules();
        flush_rewrite_rules( false );

        return rest_ensure_response( $this->get_public_status() );
    }

    /**
     * Get sanitized sitemap settings from site settings.
     *
     * @return array<string,mixed>
     */

    public function get_settings(): array {
        $stored_settings = wphave_data_get( 'site_settings', 'seo.sitemap' );
        $settings = $stored_settings;

        if( ! is_array( $settings ) ) {
            $settings = array();
        }

        $settings = array_merge( $this->defaults, $settings );

        /*
         * LIFECYCLE INVARIANT: New Free sites do not receive the Pro Sitemap through an implicit
         * default. Once Pro explicitly stores the setting, that exact runtime
         * decision remains authoritative after a later downgrade.
         */

        if( ! is_array( $stored_settings ) || ! array_key_exists( 'isEnabled', $stored_settings ) ) {
            $settings['isEnabled'] = wphave_seo_sitemap_has_pro_access();
        }

        $settings['isEnabled'] = (bool) $settings['isEnabled'];
        $settings['postTypes'] = $this->sanitize_post_types( (array) ( $settings['postTypes'] ?? array() ) );
        $settings['taxonomies'] = $this->sanitize_taxonomies( (array) ( $settings['taxonomies'] ?? array() ) );
        $settings['perPage'] = max( 100, min( 50000, absint( $settings['perPage'] ?? $this->defaults['perPage'] ) ) );
        $settings['cacheTtl'] = max( 60, min( DAY_IN_SECONDS, absint( $settings['cacheTtl'] ?? $this->defaults['cacheTtl'] ) ) );
        $settings['includeLastmod'] = (bool) $settings['includeLastmod'];
        $settings['addToRobotsTxt'] = (bool) $settings['addToRobotsTxt'];

        return $settings;
    }

    /**
     * Check if the sitemap feature should serve XML output.
     *
     * @return bool
     */

    public function is_enabled(): bool {
        $settings = $this->get_settings();

        // Enabled by default
        return isset( $settings['isEnabled'] ) ? (bool) $settings['isEnabled'] : true;
    }

    /**
     * Get the public sitemap index URL.
     *
     * @return string
     */

    public function get_index_url(): string {
        return home_url( '/wphave-sitemap.xml' );
    }

    /**
     * Get the URL for a sitemap page.
     *
     * @param int $page Page number.
     * @return string
     */

    public function get_page_url( int $page ): string {
        return home_url( '/wphave-sitemap-' . max( 1, $page ) . '.xml' );
    }

    /**
     * Collect sitemap entries from configured post types and taxonomies.
     *
     * @return array<int,array<string,mixed>>
     */

    public function collect_entries(): array {
        $settings = $this->get_settings();
        $entries = array();

        foreach( $settings['postTypes'] as $post_type ) {
            $entries = array_merge( $entries, $this->collect_post_type_entries( $post_type, $settings ) );
        }

        foreach( $settings['taxonomies'] as $taxonomy ) {
            $entries = array_merge( $entries, $this->collect_taxonomy_entries( $taxonomy, $settings ) );
        }

        return (array) apply_filters( 'wphave_sitemap_entries', $entries, $settings );
    }

    /**
     * Get cached sitemap entries.
     *
     * @return array<int,array<string,mixed>>
     */

    public function get_entries(): array {
        $cached = get_transient( self::CACHE_KEY );

        if( is_array( $cached ) ) {
            return $cached;
        }

        $entries = $this->collect_entries();

        usort( $entries, static function( $a, $b ) {
            return strcmp( $b['lastmod'] ?? '', $a['lastmod'] ?? '' );
        } );

        set_transient( self::CACHE_KEY, $entries, $this->get_settings()['cacheTtl'] );

        return $entries;
    }

    /**
     * Get sitemap document count.
     *
     * @return int
     */

    public function get_page_count(): int {
        $settings = $this->get_settings();
        $total = count( $this->get_entries() );

        return max( 1, (int) ceil( $total / $settings['perPage'] ) );
    }

    /**
     * Get sitemap entries for a paginated XML document.
     *
     * @param int $page Page number.
     * @return array<int,array<string,mixed>>
     */

    public function get_entries_for_page( int $page ): array {
        $settings = $this->get_settings();
        $page = max( 1, $page );
        $offset = ( $page - 1 ) * $settings['perPage'];

        return array_slice( $this->get_entries(), $offset, $settings['perPage'] );
    }

    /**
     * Render the sitemap index XML.
     *
     * @return string
     */

    public function render_index(): string {
        $count = $this->get_page_count();
        $lastmod = $this->xml_escape( gmdate( 'c' ) );
        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml .= '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

        for( $i = 1; $i <= $count; $i++ ) {
            $xml .= "  <sitemap>\n";
            $xml .= '    <loc>' . $this->xml_escape( $this->get_page_url( $i ) ) . "</loc>\n";
            $xml .= '    <lastmod>' . $lastmod . "</lastmod>\n";
            $xml .= "  </sitemap>\n";
        }

        $xml .= "</sitemapindex>\n";

        return $xml;
    }

    /**
     * Render one sitemap URL set XML document.
     *
     * @param int $page Page number.
     * @return string
     */

    public function render_page( int $page ): string {
        $entries = $this->get_entries_for_page( $page );

        if( empty( $entries ) ) {
            status_header( 404 );
            return '';
        }

        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

        foreach( $entries as $entry ) {
            if( empty( $entry['loc'] ) ) {
                continue;
            }

            $xml .= "  <url>\n";
            $xml .= '    <loc>' . $this->xml_escape( $entry['loc'] ) . "</loc>\n";

            if( ! empty( $entry['lastmod'] ) ) {
                $xml .= '    <lastmod>' . $this->xml_escape( $entry['lastmod'] ) . "</lastmod>\n";
            }

            $xml .= "  </url>\n";
        }

        $xml .= "</urlset>\n";

        return $xml;
    }

    /**
     * Add the sitemap directive to virtual robots.txt output.
     *
     * @param string $output robots.txt output.
     * @param bool $public Search engine visibility flag.
     * @return string
     */

    public function add_sitemap_to_robots_txt( string $output, bool $public ): string {
        $settings = $this->get_settings();

        if( ! $public || ! $settings['addToRobotsTxt'] || ! $this->is_enabled() ) {
            return $output;
        }

        $sitemap = $this->get_index_url();

        if( stripos( $output, $sitemap ) !== false ) {
            return $output;
        }

        return trim( $output ) . "\n\nSitemap: " . esc_url_raw( $sitemap ) . "\n";
    }

    /**
     * Delete generated sitemap entries.
     */

    public function flush_cache(): void {
        delete_transient( self::CACHE_KEY );
    }

    /**
     * Return sitemap data consumed by the settings UI.
     *
     * @return array<string,mixed>
     */

    public function get_public_status(): array {
        $enabled = $this->is_enabled();
        $entries = $enabled ? $this->get_entries() : array();

        return array(
            'enabled' => $enabled,
            'sitemapUrl' => $this->get_index_url(),
            'robotsUrl' => home_url( '/robots.txt' ),
            'settings' => $this->get_settings(),
            'entryCount' => count( $entries ),
            'pageCount' => $enabled ? $this->get_page_count() : 0,
            'postTypes' => $this->get_post_type_options(),
            'taxonomies' => $this->get_taxonomy_options(),
            'generatedAt' => gmdate( 'c' ),
        );
    }

    /**
     * Collect entries for one public post type.
     *
     * @param string $post_type Post type name.
     * @param array<string,mixed> $settings Sitemap settings.
     * @return array<int,array<string,mixed>>
     */

    private function collect_post_type_entries( string $post_type, array $settings ): array {
        $post_type_object = get_post_type_object( $post_type );

        if( ! $post_type_object || empty( $post_type_object->public ) ) {
            return array();
        }

        $entries = array();
        $page = 1;

        do {
            $query = new WP_Query( array(
                'post_type' => $post_type,
                'post_status' => 'publish',
                'posts_per_page' => 500,
                'paged' => $page,
                'no_found_rows' => true,
                'ignore_sticky_posts' => true,
                'orderby' => 'modified',
                'order' => 'DESC',
                'update_post_meta_cache' => false,
                'update_post_term_cache' => false,
                'fields' => 'ids',
            ) );

            foreach( $query->posts as $post_id ) {
                $post_id = absint( $post_id );

                if( ! WPHAVE_SEO::instance()->is_indexable_post( $post_id ) ) {
                    continue;
                }

                $loc = get_permalink( $post_id );
                if( ! $loc ) {
                    continue;
                }

                $entries[] = array(
                    'loc' => $loc,
                    'lastmod' => $settings['includeLastmod'] ? get_post_modified_time( 'c', true, $post_id ) : null,
                    'type' => 'post',
                    'objectType' => $post_type,
                    'objectId' => $post_id,
                );
            }

            $page++;
        } while( count( $query->posts ) === 500 );

        return $entries;
    }

    /**
     * Collect entries for one public taxonomy.
     *
     * @param string $taxonomy Taxonomy name.
     * @param array<string,mixed> $settings Sitemap settings.
     * @return array<int,array<string,mixed>>
     */

    private function collect_taxonomy_entries( string $taxonomy, array $settings ): array {
        $taxonomy_object = get_taxonomy( $taxonomy );

        if( ! $taxonomy_object || empty( $taxonomy_object->public ) ) {
            return array();
        }

        $terms = get_terms( array(
            'taxonomy' => $taxonomy,
            'hide_empty' => true,
            'fields' => 'all',
        ) );

        if( is_wp_error( $terms ) ) {
            return array();
        }

        $entries = array();

        foreach( $terms as $term ) {
            $loc = get_term_link( $term );

            if( is_wp_error( $loc ) || ! $loc ) {
                continue;
            }

            $entries[] = array(
                'loc' => $loc,
                'lastmod' => null,
                'type' => 'term',
                'objectType' => $taxonomy,
                'objectId' => (int) $term->term_id,
            );
        }

        return $entries;
    }

    /**
     * Sanitize configured post types against public post types.
     *
     * @param array<int,string> $post_types Post type names.
     * @return array<int,string>
     */

    private function sanitize_post_types( array $post_types ): array {
        $allowed = array_keys( $this->get_public_post_types() );
        $post_types = array_values( array_intersect( array_map( 'sanitize_key', $post_types ), $allowed ) );

        return $post_types ?: $this->defaults['postTypes'];
    }

    /**
     * Sanitize configured taxonomies against public taxonomies.
     *
     * @param array<int,string> $taxonomies Taxonomy names.
     * @return array<int,string>
     */

    private function sanitize_taxonomies( array $taxonomies ): array {
        $allowed = array_keys( $this->get_public_taxonomies() );

        return array_values( array_intersect( array_map( 'sanitize_key', $taxonomies ), $allowed ) );
    }

    /**
     * Get public post type objects suitable for sitemaps.
     *
     * @return array<string,WP_Post_Type>
     */

    private function get_public_post_types(): array {
        $post_types = get_post_types( array(
            'public' => true,
        ), 'objects' );

        unset( $post_types['attachment'] );

        return $post_types;
    }

    /**
     * Get public taxonomy objects suitable for sitemaps.
     *
     * @return array<string,WP_Taxonomy>
     */

    private function get_public_taxonomies(): array {
        return get_taxonomies( array(
            'public' => true,
        ), 'objects' );
    }

    /**
     * Get post type options for the settings UI.
     *
     * @return array<int,array<string,string>>
     */

    private function get_post_type_options(): array {
        return array_values( array_map( static function( $post_type ) {
            return array(
                'label' => $post_type->labels->singular_name ?: $post_type->label,
                'value' => $post_type->name,
            );
        }, $this->get_public_post_types() ) );
    }

    /**
     * Get taxonomy options for the settings UI.
     *
     * @return array<int,array<string,string>>
     */

    private function get_taxonomy_options(): array {
        return array_values( array_map( static function( $taxonomy ) {
            return array(
                'label' => $taxonomy->labels->singular_name ?: $taxonomy->label,
                'value' => $taxonomy->name,
            );
        }, $this->get_public_taxonomies() ) );
    }

    /**
     * Escape a value for XML text nodes.
     *
     * @param string $value Raw value.
     * @return string
     */

    private function xml_escape( string $value ): string {
        return function_exists( 'esc_xml' ) ? esc_xml( $value ) : htmlspecialchars( $value, ENT_XML1 | ENT_COMPAT, 'UTF-8' );
    }
}

WPHAVE_Sitemap::instance();

register_activation_hook( WPHAVE_FILE_PATH, static function() {
    WPHAVE_Sitemap::instance()->register_rewrite_rules();
    flush_rewrite_rules( false );
} );

register_deactivation_hook( WPHAVE_FILE_PATH, static function() {
    flush_rewrite_rules( false );
} );
