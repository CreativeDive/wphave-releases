<?php

/**
 * Resolve one canonical metadata model for social preview renderers.
 *
 * @package wphave
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

if( ! class_exists( 'WPHAVE_Social_Metadata' ) ) :

/**
 * Normalize document context, fallbacks and social preview media.
 */

class WPHAVE_Social_Metadata {

	const DESCRIPTION_LENGTH = 240;

	/**
	 * Return whether WPHAVE may own social metadata for this request.
	 *
	 * @return bool
	 */

	public static function can_render() {
		$can_render = ! wphave_use_fse()
			&& ! is_admin()
			&& ! is_feed()
			&& ! self::has_conflicting_provider();

		return (bool) apply_filters( 'wphave_social_metadata_can_render', $can_render );
	}

	/**
	 * Resolve the complete metadata model for the current document.
	 *
	 * @param string $channel Network-specific post-meta channel.
	 * @param int    $fallback_image_id Global add-on fallback image.
	 * @return array
	 */

	public static function resolve( $channel, $fallback_image_id = 0 ) {
		$post_id = is_singular() ? get_queried_object_id() : 0;
		$title = self::meta_fallback( $post_id, "wphave_seo_{$channel}_title", 'wphave_seo_social_title' );
		$description = self::meta_fallback( $post_id, "wphave_seo_{$channel}_description", 'wphave_seo_social_description' );
		$image_id = self::image_id( $post_id, $channel, $fallback_image_id );

		if( $title === '' ) {
			$title = self::context_title( $post_id );
		}

		if( $description === '' ) {
			$description = self::context_description( $post_id );
		}

		$data = array(
			'post_id' => $post_id,
			'url' => self::canonical_url( $post_id ),
			'title' => self::plain_text( $title ),
			'description' => self::description( $description ),
			'locale' => str_replace( '-', '_', determine_locale() ),
			'type' => is_singular( 'post' ) ? 'article' : 'website',
			'image' => self::image( $image_id, $title ),
			'published_time' => $post_id ? get_post_time( 'c', true, $post_id ) : '',
			'modified_time' => $post_id ? get_post_modified_time( 'c', true, $post_id ) : '',
			'section' => $post_id ? self::section( $post_id ) : '',
			'tags' => $post_id ? self::tags( $post_id ) : array(),
		);

		return apply_filters( 'wphave_social_metadata', $data, $channel );
	}

	/**
	 * Sanitize an X account name without its optional at-sign.
	 *
	 * @param mixed $username Raw username.
	 * @return string
	 */

	public static function x_username( $username ) {
		$username = ltrim( trim( (string) $username ), '@' );

		return preg_match( '/^[A-Za-z0-9_]{1,15}$/', $username ) ? $username : '';
	}

	/**
	 * Return whether another active plugin is expected to emit social metadata.
	 *
	 * @return bool
	 */

	public static function has_conflicting_provider() {
		$known = array(
			'wordpress-seo/wp-seo.php',
			'wordpress-seo-premium/wp-seo-premium.php',
			'all-in-one-seo-pack/all_in_one_seo_pack.php',
			'aioseo/aioseo.php',
			'seo-by-rank-math/rank-math.php',
			'seo-by-rank-math-pro/rank-math-pro.php',
			'autodescription/autodescription.php',
			'seo-framework/seo-framework.php',
			'squirrly-seo/squirrly.php',
			'slim-seo/slim-seo.php',
			'seopress/seopress.php',
			'wp-seopress/wp-seopress.php',
			'smartcrawl-seo/wpmu-dev-seo.php',
			'wpmu-dev-seo/wpmu-dev-seo.php',
		);
		$known = (array) apply_filters( 'wphave_social_metadata_conflicting_plugins', $known );
		$active = (array) get_option( 'active_plugins', array() );

		if( is_multisite() ) {
			$active = array_merge( $active, array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) );
		}

		return (bool) array_intersect( $known, $active );
	}

	/**
	 * Resolve a network-specific value followed by its shared social fallback.
	 *
	 * @param int    $post_id Current singular post id.
	 * @param string $specific_key Network-specific meta key.
	 * @param string $general_key General social meta key.
	 * @return mixed
	 */

	private static function meta_fallback( $post_id, $specific_key, $general_key ) {
		if( ! $post_id ) {
			return '';
		}

		$specific = get_post_meta( $post_id, $specific_key, true );

		if( $specific !== '' && $specific !== null ) {
			return $specific;
		}

		return get_post_meta( $post_id, $general_key, true );
	}

	/**
	 * Resolve the best title for the current query.
	 *
	 * @param int $post_id Current singular post id.
	 * @return string
	 */

	private static function context_title( $post_id ) {
		if( $post_id ) {
			$title = get_the_title( $post_id );

			return $title ?: get_bloginfo( 'name' );
		}

		if( is_search() ) {
			return sprintf( /* translators: %s: contextual value. */
			__( 'Search results for: %s', 'wphave' ), get_search_query() );
		}

		if( is_archive() ) {
			return wp_strip_all_tags( get_the_archive_title() );
		}

		return wp_get_document_title() ?: get_bloginfo( 'name' );
	}

	/**
	 * Resolve the best description for the current query.
	 *
	 * @param int $post_id Current singular post id.
	 * @return string
	 */

	private static function context_description( $post_id ) {
		if( $post_id ) {
			$excerpt = get_post_field( 'post_excerpt', $post_id );

			if( $excerpt !== '' ) {
				return $excerpt;
			}

			$content = get_post_field( 'post_content', $post_id );

			if( $content !== '' ) {
				return strip_shortcodes( $content );
			}
		}

		if( is_archive() ) {
			$archive_description = get_the_archive_description();

			if( $archive_description !== '' ) {
				return $archive_description;
			}
		}

		return get_bloginfo( 'description' );
	}

	/**
	 * Resolve the canonical URL for singular and non-singular queries.
	 *
	 * @param int $post_id Current singular post id.
	 * @return string
	 */

	private static function canonical_url( $post_id ) {
		if( $post_id ) {
			$url = wp_get_canonical_url( $post_id );

			return esc_url_raw( $url ?: get_permalink( $post_id ) );
		}

		return esc_url_raw( get_pagenum_link( max( 1, get_query_var( 'paged', 1 ) ) ) );
	}

	/**
	 * Resolve an attachment id through the complete image fallback chain.
	 *
	 * @param int    $post_id Current singular post id.
	 * @param string $channel Network-specific post-meta channel.
	 * @param int    $fallback_image_id Global add-on fallback image.
	 * @return int
	 */

	private static function image_id( $post_id, $channel, $fallback_image_id ) {
		$image_id = (int) self::meta_fallback( $post_id, "wphave_seo_{$channel}_image", 'wphave_seo_social_image' );

		if( ! $image_id && $post_id ) {
			$image_id = (int) get_post_thumbnail_id( $post_id );
		}

		if( ! $image_id ) {
			$image_id = absint( $fallback_image_id );
		}

		if( ! $image_id ) {
			$image_id = absint( wphave_data_get( 'site_settings', 'brand.logo', 0 ) );
		}

		if( ! $image_id ) {
			$image_id = (int) get_option( 'site_icon', 0 );
		}

		return $image_id && wp_attachment_is_image( $image_id ) ? $image_id : 0;
	}

	/**
	 * Build validated image metadata for the emitted full-size source.
	 *
	 * @param int    $image_id Attachment id.
	 * @param string $fallback_alt Document title used when media alt is empty.
	 * @return array
	 */

	private static function image( $image_id, $fallback_alt ) {
		if( ! $image_id ) {
			return array();
		}

		$source = wp_get_attachment_image_src( $image_id, 'full' );

		if( ! is_array( $source ) || empty( $source[0] ) ) {
			return array();
		}

		$alt = get_post_meta( $image_id, '_wp_attachment_image_alt', true );

		if( $alt === '' ) {
			$alt = get_the_title( $image_id ) ?: $fallback_alt;
		}

		return array(
			'id' => $image_id,
			'url' => esc_url_raw( $source[0] ),
			'width' => absint( $source[1] ?? 0 ),
			'height' => absint( $source[2] ?? 0 ),
			'type' => sanitize_mime_type( get_post_mime_type( $image_id ) ),
			'alt' => self::plain_text( $alt ),
		);
	}

	/**
	 * Return the primary article category.
	 *
	 * @param int $post_id Current post id.
	 * @return string
	 */

	private static function section( $post_id ) {
		$categories = get_the_category( $post_id );

		return ! empty( $categories[0]->name ) ? self::plain_text( $categories[0]->name ) : '';
	}

	/**
	 * Return article tags as separate values.
	 *
	 * @param int $post_id Current post id.
	 * @return array
	 */

	private static function tags( $post_id ) {
		$terms = get_the_tags( $post_id );

		if( ! is_array( $terms ) ) {
			return array();
		}

		return array_values( array_filter( array_map( array( __CLASS__, 'term_name' ), $terms ) ) );
	}

	/**
	 * Extract a sanitized term name for array mapping.
	 *
	 * @param WP_Term $term Term object.
	 * @return string
	 */

	public static function term_name( $term ) {
		return self::plain_text( $term->name ?? '' );
	}

	/**
	 * Normalize a short text value for metadata attributes.
	 *
	 * @param mixed $value Raw value.
	 * @return string
	 */

	private static function plain_text( $value ) {
		return trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( html_entity_decode( (string) $value, ENT_QUOTES, get_bloginfo( 'charset' ) ?: 'UTF-8' ) ) ) );
	}

	/**
	 * Normalize and conservatively limit a social description.
	 *
	 * @param mixed $value Raw value.
	 * @return string
	 */

	private static function description( $value ) {
		$value = self::plain_text( $value );

		return wp_html_excerpt( $value, self::DESCRIPTION_LENGTH, '…' );
	}
}

endif;
