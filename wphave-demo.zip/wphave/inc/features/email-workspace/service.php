<?php

/** Explicit adapters for WordPress transactional messages. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WPHAVE_Email_Workspace {
	private const OPTION = 'wphave_email_workspace';
	private const TEST_SEND_WINDOW_SECONDS = 60;
	private const TEST_SEND_LIMIT = 2;

	/** These hooks expose a complete message and per-message headers. */
	private const TYPES = array(
		'new-user' => 'wp_new_user_notification_email',
		'new-user-admin' => 'wp_new_user_notification_email_admin',
		'password-reset' => 'retrieve_password_notification_email',
		'password-changed' => 'wp_password_change_notification_email',
	);

	public static function init(): void {
		foreach ( self::TYPES as $id => $hook ) {
			add_filter(
				$hook,
				static function ( $mail ) use ( $id ) {
					return self::decorate( $id, $mail );
				},
				20
			);
		}

		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	public static function register_routes(): void {
		$permission = static function (): bool {
			return self::can_manage();
		};
		$message_args = array(
			'id' => array(
				'type' => 'string',
				'required' => true,
				'enum' => array_keys( self::TYPES ),
			),
			'settings' => array( 'type' => 'object' ),
		);

		register_rest_route(
			'wphave/v1',
			'/email-workspace',
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'read' ), 'permission_callback' => $permission ),
				array(
					'methods' => 'PUT',
					'callback' => array( __CLASS__, 'save' ),
					'permission_callback' => $permission,
					'args' => array(
						'colors' => array( 'type' => 'object', 'required' => true ),
						'messages' => array( 'type' => 'object', 'required' => true ),
						'revision' => array( 'type' => 'string', 'required' => true ),
					),
				),
			)
		);
		register_rest_route(
			'wphave/v1',
			'/email-workspace/preview',
			array(
				'methods' => 'POST',
				'callback' => array( __CLASS__, 'preview' ),
				'permission_callback' => $permission,
				'args' => $message_args,
			)
		);
		register_rest_route(
			'wphave/v1',
			'/email-workspace/test',
			array(
				'methods' => 'POST',
				'callback' => array( __CLASS__, 'test_send' ),
				'permission_callback' => $permission,
				'args' => $message_args,
			)
		);
	}

	private static function can_manage(): bool {
		return wphave_email_workspace_feature_enabled() && current_user_can( 'manage_options' );
	}

	private static function forbidden(): WP_Error {
		return new WP_Error( 'wphave_email_workspace_forbidden', __( 'You cannot manage email settings.', 'wphave' ), array( 'status' => 403 ) );
	}

	private static function settings(): array {
		$stored = get_option( self::OPTION, array() );
		return self::sanitize( is_array( $stored ) ? $stored : array() );
	}

	private static function revision( array $settings ): string {
		return hash( 'sha256', wp_json_encode( $settings ) );
	}

	private static function sanitize( array $input ): array {
		$colors = is_array( $input['colors'] ?? null ) ? $input['colors'] : array();
		$messages = is_array( $input['messages'] ?? null ) ? $input['messages'] : array();
		$clean = array(
			'colors' => array(
				'background' => self::color( $colors['background'] ?? null, '#f3f4f6' ),
				'card' => self::color( $colors['card'] ?? null, '#ffffff' ),
				'text' => self::color( $colors['text'] ?? null, '#1f2937' ),
				'accent' => self::color( $colors['accent'] ?? null, '#3858e9' ),
			),
			'messages' => array(),
		);

		foreach ( self::TYPES as $id => $hook ) {
			$value = is_array( $messages[ $id ] ?? null ) ? $messages[ $id ] : array();
			$clean['messages'][ $id ] = array(
				'enabled' => ! empty( $value['enabled'] ),
				'intro' => self::intro( $value['intro'] ?? null ),
			);
		}

		return $clean;
	}

	private static function has_complete_settings( $input ): bool {
		if ( ! is_array( $input ) || ! is_array( $input['colors'] ?? null ) || ! is_array( $input['messages'] ?? null ) ) {
			return false;
		}

		foreach ( array( 'background', 'card', 'text', 'accent' ) as $color ) {
			if ( ! array_key_exists( $color, $input['colors'] ) ) {
				return false;
			}
		}

		foreach ( self::TYPES as $id => $hook ) {
			$message = $input['messages'][ $id ] ?? null;
			if ( ! is_array( $message ) || ! array_key_exists( 'enabled', $message ) || ! array_key_exists( 'intro', $message ) ) {
				return false;
			}
		}

		return true;
	}

	private static function intro( $value ): string {
		$clean = sanitize_textarea_field( is_string( $value ) ? $value : '' );
		$matches = array();
		// PCRE's UTF-8 mode bounds complete code points without requiring mbstring.
		return 1 === preg_match( '/\A.{0,1000}/us', $clean, $matches ) ? $matches[0] : '';
	}

	private static function color( $value, string $fallback ): string {
		return is_string( $value ) ? ( sanitize_hex_color( $value ) ?: $fallback ) : $fallback;
	}

	public static function read() {
		if ( ! self::can_manage() ) {
			return self::forbidden();
		}

		$settings = self::settings();
		return array(
			'catalog' => self::catalog(),
			'settings' => $settings,
			'revision' => self::revision( $settings ),
		);
	}

	private static function catalog(): array {
		$catalog = array(
			array( 'id' => 'new-user', 'label' => __( 'New user welcome', 'wphave' ), 'mode' => 'editable' ),
			array( 'id' => 'new-user-admin', 'label' => __( 'New user administrator notice', 'wphave' ), 'mode' => 'editable' ),
			array( 'id' => 'password-reset', 'label' => __( 'Password reset', 'wphave' ), 'mode' => 'editable' ),
			array( 'id' => 'password-changed', 'label' => __( 'Password changed notice', 'wphave' ), 'mode' => 'editable' ),
		);

		$catalog[] = array( 'id' => 'comments', 'label' => __( 'Comment notifications', 'wphave' ), 'mode' => 'observed' );
		$catalog[] = array( 'id' => 'wphave-workflows', 'label' => __( 'WPHAVE workflow messages', 'wphave' ), 'mode' => 'existing' );
		$catalog[] = array( 'id' => 'campaigns', 'label' => __( 'Campaigns', 'wphave' ), 'mode' => 'separate' );
		return $catalog;
	}

	public static function save( WP_REST_Request $request ) {
		if ( ! self::can_manage() ) {
			return self::forbidden();
		}

		$value = $request->get_json_params();
		if (
			! self::has_complete_settings( $value )
			|| ! is_string( $value['revision'] ?? null )
			|| ! preg_match( '/\A[a-f0-9]{64}\z/D', $value['revision'] )
		) {
			return new WP_Error( 'wphave_email_workspace_invalid', __( 'Invalid email settings.', 'wphave' ), array( 'status' => 400 ) );
		}

		$settings = self::sanitize( $value );
		if ( ! class_exists( 'WPHAVE_Option_Mutations' ) ) {
			require_once __DIR__ . '/../../data/options/mutations.php';
		}
		$result = WPHAVE_Option_Mutations::mutate(
			self::OPTION,
			static function ( array $stored ) use ( $value, $settings ) {
				$current = self::sanitize( $stored );
				if ( self::revision( $current ) !== $value['revision'] ) {
					return new WP_Error( 'wphave_email_workspace_conflict', __( 'Email settings changed elsewhere. Reload before saving.', 'wphave' ), array( 'status' => 409 ) );
				}
				return $settings;
			},
			false
		);
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return array( 'settings' => $result, 'revision' => self::revision( $result ) );
	}

	public static function preview( WP_REST_Request $request ) {
		if ( ! self::can_manage() ) {
			return self::forbidden();
		}

		$id = $request->get_param( 'id' );
		if ( ! is_string( $id ) || ! isset( self::TYPES[ $id ] ) ) {
			return new WP_Error( 'wphave_email_workspace_unknown_type', __( 'Unknown email type.', 'wphave' ), array( 'status' => 400 ) );
		}

		$input = $request->get_json_params();
		$settings = is_array( $input ) && is_array( $input['settings'] ?? null )
			? self::sanitize( $input['settings'] )
			: self::settings();
		return array( 'html' => self::render( $id, __( 'This is example content. Required links and account details remain in the original WordPress message.', 'wphave' ), $settings ) );
	}

	public static function test_send( WP_REST_Request $request ) {
		// Recheck authorization here: direct callback calls bypass REST permissions.
		if ( ! self::can_manage() ) {
			return self::forbidden();
		}

		$id = $request->get_param( 'id' );
		if ( ! is_string( $id ) || ! isset( self::TYPES[ $id ] ) ) {
			return new WP_Error( 'wphave_email_workspace_unknown_type', __( 'Unknown email type.', 'wphave' ), array( 'status' => 400 ) );
		}

		$user = wp_get_current_user();
		$recipient = is_email( $user->user_email ?? '' );
		if ( ! $recipient ) {
			return new WP_Error( 'wphave_email_workspace_no_recipient', __( 'Your account needs a valid email address for a test send.', 'wphave' ), array( 'status' => 400 ) );
		}

		if ( ! class_exists( 'WPHAVE_Rate_Limiter' ) ) {
			require_once __DIR__ . '/../security/rate-limiter.php';
		}
		$rate_key = 'wphave_email_workspace_test_' . get_current_user_id();
		if ( WPHAVE_Rate_Limiter::increment( $rate_key, self::TEST_SEND_WINDOW_SECONDS ) > self::TEST_SEND_LIMIT ) {
			return new WP_Error( 'wphave_email_workspace_rate_limited', __( 'Wait a moment before sending another test message.', 'wphave' ), array( 'status' => 429 ) );
		}

		$input = $request->get_json_params();
		$settings = is_array( $input ) && is_array( $input['settings'] ?? null )
			? self::sanitize( $input['settings'] )
			: self::settings();
		$html = self::render( $id, __( 'This is a test message. It contains no account token or personal data.', 'wphave' ), $settings );
		$accepted = wp_mail(
			$recipient,
			__( 'WPHAVE email design test', 'wphave' ),
			$html,
			array( 'Content-Type: text/html; charset=UTF-8' )
		);

		if ( true !== $accepted ) {
			return new WP_Error( 'wphave_email_workspace_send_failed', __( 'The mail transport did not accept the test message.', 'wphave' ), array( 'status' => 502 ) );
		}

		return array( 'accepted' => true );
	}

	private static function decorate( string $id, $mail ) {
		if ( ! is_array( $mail ) || ! isset( $mail['message'] ) || ! is_string( $mail['message'] ) ) {
			return $mail;
		}

		$settings = self::settings();
		if ( empty( $settings['messages'][ $id ]['enabled'] ) ) {
			return $mail;
		}

		// Keep the original WordPress message and security links intact.
		$mail['message'] = self::render( $id, $mail['message'], $settings );
		$headers = $mail['headers'] ?? array();
		$headers = is_array( $headers ) ? $headers : preg_split( '/\r?\n/', (string) $headers );
		$headers = array_filter( $headers, static fn ( $header ) => ! preg_match( '/^content-type\s*:/i', (string) $header ) );
		$headers[] = 'Content-Type: text/html; charset=UTF-8';
		$mail['headers'] = $headers;
		return $mail;
	}

	private static function render( string $id, string $message, array $settings ): string {
		$colors = $settings['colors'];
		$intro = $settings['messages'][ $id ]['intro'];
		$site = get_bloginfo( 'name' );
		$body = nl2br( esc_html( $message ) );
		$body = make_clickable( $body );
		$intro_html = $intro ? '<p style="margin:0 0 24px">' . nl2br( esc_html( $intro ) ) . '</p>' : '';

		return '<!doctype html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"></head>'
			. '<body style="margin:0;padding:24px;background:' . esc_attr( $colors['background'] ) . ';color:' . esc_attr( $colors['text'] ) . ';font:16px/1.6 Arial,sans-serif">'
			. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td align="center">'
			. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:640px;background:' . esc_attr( $colors['card'] ) . '">'
			. '<tr><td style="padding:32px;border-top:4px solid ' . esc_attr( $colors['accent'] ) . '">'
			. '<h1 style="margin:0 0 24px;font-size:24px">' . esc_html( $site ) . '</h1>'
			. $intro_html . '<div>' . $body . '</div></td></tr></table></td></tr></table></body></html>';
	}
}
