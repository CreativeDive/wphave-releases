<?php

/** Transactional email workspace. Loaded only behind its release flag. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/service.php';

WPHAVE_Email_Workspace::init();
