<?php

/** Declare the WooCommerce platform features WPHAVE supports. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action(
	'before_woocommerce_init',
	static function (): void {
		if ( ! class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			return;
		}
		if ( ! defined( 'WPHAVE_FILE_PATH' ) ) {
			return;
		}

		// PLUGIN IDENTITY INVARIANT: WooCommerce receives the exact main file that
		// WordPress loaded. A guessed filename could declare another installation.
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', WPHAVE_FILE_PATH, true );
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', WPHAVE_FILE_PATH, true );
	}
);
