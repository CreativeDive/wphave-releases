<?php

/**
 * WooCommerce product validation, mutation and type-transition contracts.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Validate and persist product changes through WooCommerce CRUD APIs.
 */

trait WPHAVE_WooCommerce_REST_Product_Mutations {

	/**
	 * Resolve a product without accessing product post/meta storage directly.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WC_Product|WP_Error
	 */

	private static function find_product( WP_REST_Request $request ) {
		if ( ! function_exists( 'wc_get_product' ) ) {
			return self::unavailable_error();
		}

		$product = wc_get_product( absint( $request->get_param( 'id' ) ) );

		if ( ! $product instanceof WC_Product ) {
			return new WP_Error(
				'wphave_woocommerce_product_not_found',
				__( 'Product not found.', 'wphave' ),
				array( 'status' => 404 )
			);
		}

		return $product;
	}

	/**
	 * Apply the WPHAVE-owned editor contract to a WooCommerce product object.
	 *
	 * @param WC_Product $product Product.
	 * @param array      $data Request data.
	 * @return void
	 */

	private static function apply_product_changes( WC_Product $product, array $data ) {
		$text_fields = array(
			'name'             => 'set_name',
			'slug'             => 'set_slug',
			'sku'              => 'set_sku',
			'taxClass'         => 'set_tax_class',
			'weight'           => 'set_weight',
			'length'           => 'set_length',
			'width'            => 'set_width',
			'height'           => 'set_height',
		);

		foreach ( $text_fields as $key => $setter ) {
			if ( array_key_exists( $key, $data ) ) {
				$product->{$setter}( wc_clean( (string) wp_unslash( $data[ $key ] ) ) );
			}
		}

		if ( array_key_exists( 'description', $data ) ) {
			$product->set_description( wp_kses_post( (string) wp_unslash( $data['description'] ) ) );
		}
		if ( array_key_exists( 'shortDescription', $data ) ) {
			$product->set_short_description( wp_kses_post( (string) wp_unslash( $data['shortDescription'] ) ) );
		}
		if ( array_key_exists( 'purchaseNote', $data ) ) {
			$product->set_purchase_note( wp_kses_post( (string) wp_unslash( $data['purchaseNote'] ) ) );
		}

		$decimal_fields = array(
			'regularPrice' => 'set_regular_price',
			'salePrice'    => 'set_sale_price',
		);
		foreach ( $decimal_fields as $key => $setter ) {
			if ( array_key_exists( $key, $data ) ) {
				$value = '' === (string) $data[ $key ] ? '' : wc_format_decimal( $data[ $key ] );
				$product->{$setter}( $value );
			}
		}

		$date_fields = array(
			'saleStart' => 'set_date_on_sale_from',
			'saleEnd'   => 'set_date_on_sale_to',
		);
		foreach ( $date_fields as $key => $setter ) {
			if ( array_key_exists( $key, $data ) ) {
				$product->{$setter}( $data[ $key ] ?: null );
			}
		}

		$enum_fields = array(
			'status'            => array( 'set_status', array( 'draft', 'pending', 'private', 'publish' ) ),
			'catalogVisibility' => array( 'set_catalog_visibility', array( 'visible', 'catalog', 'search', 'hidden' ) ),
			'stockStatus'       => array( 'set_stock_status', array( 'instock', 'outofstock', 'onbackorder' ) ),
			'backorders'        => array( 'set_backorders', array( 'no', 'notify', 'yes' ) ),
			'taxStatus'         => array( 'set_tax_status', array( 'taxable', 'shipping', 'none' ) ),
		);
		foreach ( $enum_fields as $key => $definition ) {
			if ( isset( $data[ $key ] ) && in_array( $data[ $key ], $definition[1], true ) ) {
				$product->{$definition[0]}( $data[ $key ] );
			}
		}

		$boolean_fields = array(
			'featured'        => 'set_featured',
			'virtual'         => 'set_virtual',
			'downloadable'    => 'set_downloadable',
			'manageStock'     => 'set_manage_stock',
			'soldIndividually' => 'set_sold_individually',
			'reviewsAllowed'   => 'set_reviews_allowed',
		);
		foreach ( $boolean_fields as $key => $setter ) {
			if ( array_key_exists( $key, $data ) ) {
				$product->{$setter}( rest_sanitize_boolean( $data[ $key ] ) );
			}
		}

		if ( array_key_exists( 'stockQuantity', $data ) ) {
			$product->set_stock_quantity(
				'' === (string) $data['stockQuantity'] ? null : wc_stock_amount( $data['stockQuantity'] )
			);
		}

		if ( array_key_exists( 'menuOrder', $data ) ) {
			$product->set_menu_order( max( 0, (int) $data['menuOrder'] ) );
		}

		if ( array_key_exists( 'lowStockAmount', $data ) ) {
			$product->set_low_stock_amount(
				null === $data['lowStockAmount'] || '' === (string) $data['lowStockAmount']
					? ''
					: wc_stock_amount( $data['lowStockAmount'] )
			);
		}

		if ( array_key_exists( 'shippingClassId', $data ) ) {
			$shipping_class_id = absint( $data['shippingClassId'] );

			if ( $shipping_class_id && ! term_exists( $shipping_class_id, 'product_shipping_class' ) ) {
				throw new WC_Data_Exception(
					'wphave_woocommerce_invalid_shipping_class',
					__( 'Invalid shipping class.', 'woocommerce' )
				);
			}

			$product->set_shipping_class_id( $shipping_class_id );
		}

		if ( array_key_exists( 'galleryImageIds', $data ) ) {
			$product->set_gallery_image_ids(
				self::sanitize_product_gallery_image_ids( $data['galleryImageIds'] )
			);
		}

		if ( array_key_exists( 'globalUniqueId', $data ) && method_exists( $product, 'set_global_unique_id' ) ) {
			$product->set_global_unique_id( wc_clean( wp_unslash( $data['globalUniqueId'] ) ) );
		}

		if ( array_key_exists( 'customAttributes', $data ) && array_key_exists( 'globalAttributes', $data ) ) {
			self::apply_product_attributes(
				$product,
				$data['globalAttributes'],
				$data['customAttributes']
			);
		}

		if ( $product->is_type( 'variable' ) && array_key_exists( 'defaultAttributes', $data ) ) {
			self::apply_default_product_attributes( $product, $data['defaultAttributes'] );
		}

		if ( $product->get_downloadable( 'edit' ) ) {
			if ( array_key_exists( 'downloads', $data ) && is_array( $data['downloads'] ) ) {
				self::apply_product_downloads( $product, $data['downloads'] );
			}

			if ( array_key_exists( 'downloadLimit', $data ) ) {
				$product->set_download_limit( (int) $data['downloadLimit'] );
			}

			if ( array_key_exists( 'downloadExpiry', $data ) ) {
				$product->set_download_expiry( (int) $data['downloadExpiry'] );
			}
		}

		if ( $product->is_type( 'external' ) ) {
			if ( array_key_exists( 'externalUrl', $data ) ) {
				$product->set_product_url( esc_url_raw( (string) wp_unslash( $data['externalUrl'] ) ) );
			}

			if ( array_key_exists( 'buttonText', $data ) ) {
				$product->set_button_text( sanitize_text_field( wp_unslash( $data['buttonText'] ) ) );
			}
		}

		if ( $product->is_type( 'grouped' ) && array_key_exists( 'groupedProductIds', $data ) ) {
			$product->set_children(
				self::sanitize_product_reference_ids( $product, $data['groupedProductIds'], false )
			);
		}

		if ( array_key_exists( 'upsellIds', $data ) ) {
			$product->set_upsell_ids(
				self::sanitize_product_reference_ids( $product, $data['upsellIds'] )
			);
		}

		if ( array_key_exists( 'crossSellIds', $data ) ) {
			$product->set_cross_sell_ids(
				self::sanitize_product_reference_ids( $product, $data['crossSellIds'] )
			);
		}
	}

	/**
	 * Apply defaults only for values in variation-enabled parent attributes.
	 *
	 * @param WC_Product $product Variable product.
	 * @param mixed      $values Default values keyed by attribute name.
	 * @return void
	 */

	private static function apply_default_product_attributes( WC_Product $product, $values ) {
		$defaults = array();
		$values = is_array( $values ) ? $values : array();

		foreach ( $product->get_attributes( 'edit' ) as $key => $attribute ) {
			if ( ! $attribute instanceof WC_Product_Attribute || ! $attribute->get_variation() || ! array_key_exists( $key, $values ) ) {
				continue;
			}

			if ( $attribute->is_taxonomy() ) {
				$term_id = absint( $values[ $key ] );
				$term = in_array( $term_id, array_map( 'absint', $attribute->get_options() ), true )
					? get_term( $term_id, $attribute->get_name() )
					: false;

				if ( $term instanceof WP_Term ) {
					$defaults[ $key ] = $term->slug;
				}
			} else {
				$value = wc_clean( wp_unslash( $values[ $key ] ) );

				if ( in_array( $value, $attribute->get_options(), true ) ) {
					$defaults[ $key ] = $value;
				}
			}
		}

		$product->set_default_attributes( $defaults );
	}

	/**
	 * Replace the explicit global and custom attribute contract.
	 *
	 * @param WC_Product $product Product.
	 * @param mixed      $global_values Global attribute rows.
	 * @param mixed      $custom_values Custom attribute rows.
	 * @return void
	 */

	private static function apply_product_attributes( WC_Product $product, $global_values, $custom_values ) {
		$attributes = array();
		$position = 0;
		$catalog = array();

		foreach ( wc_get_attribute_taxonomies() as $taxonomy ) {
			$catalog[ (int) $taxonomy->attribute_id ] = wc_attribute_taxonomy_name( $taxonomy->attribute_name );
		}

		foreach ( is_array( $global_values ) ? $global_values : array() as $value ) {
			$attribute_id = absint( $value['attributeId'] ?? 0 );
			$taxonomy = $catalog[ $attribute_id ] ?? '';
			$option_ids = array_values(
				array_filter(
					array_unique( array_map( 'absint', is_array( $value['optionIds'] ?? null ) ? $value['optionIds'] : array() ) ),
					static function ( $term_id ) use ( $taxonomy ) {
						return $term_id && $taxonomy && term_exists( $term_id, $taxonomy );
					}
				)
			);

			if ( ! $taxonomy || empty( $option_ids ) ) {
				continue;
			}

			$attribute = new WC_Product_Attribute();
			$attribute->set_id( $attribute_id );
			$attribute->set_name( $taxonomy );
			$attribute->set_options( $option_ids );
			$attribute->set_position( $position++ );
			$attribute->set_visible( wc_string_to_bool( $value['visible'] ?? false ) );
			$attribute->set_variation( $product->is_type( 'variable' ) && wc_string_to_bool( $value['variation'] ?? false ) );
			$attributes[] = $attribute;
		}

		foreach ( is_array( $custom_values ) ? $custom_values : array() as $value ) {
			$name = sanitize_text_field( wp_unslash( $value['name'] ?? '' ) );
			$options = array_values(
				array_unique(
					array_filter(
						array_map(
							static function ( $option ) {
								return sanitize_text_field( wp_unslash( $option ) );
							},
							is_array( $value['options'] ?? null ) ? $value['options'] : array()
						),
						static function ( $option ) {
							return '' !== $option;
						}
					)
				)
			);

			if ( '' === $name || empty( $options ) ) {
				continue;
			}

			$attribute = new WC_Product_Attribute();
			$attribute->set_id( 0 );
			$attribute->set_name( $name );
			$attribute->set_options( $options );
			$attribute->set_position( $position++ );
			$attribute->set_visible( wc_string_to_bool( $value['visible'] ?? false ) );
			$attribute->set_variation(
				$product->is_type( 'variable' ) && wc_string_to_bool( $value['variation'] ?? false )
			);
			$attributes[] = $attribute;
		}

		$product->set_attributes( $attributes );
	}

	/**
	 * Keep only unique WordPress image attachments in gallery order.
	 *
	 * @param mixed $values Candidate attachment IDs.
	 * @return array
	 */

	private static function sanitize_product_gallery_image_ids( $values ) {
		$image_ids = array();

		$values = array_slice( is_array( $values ) ? $values : array(), 0, 100 );

		foreach ( array_unique( array_map( 'absint', $values ) ) as $image_id ) {
			if ( ! $image_id ) {
				continue;
			}

			if ( ! wp_attachment_is_image( $image_id ) ) {
				continue;
			}

			// AUTHORIZATION INVARIANT: Product-edit authority does not disclose or attach
			// an arbitrary media object selected by ID. Every relationship target must be
			// a real image the caller may read at the moment it is assigned.
			if ( ! current_user_can( 'read_post', $image_id ) ) {
				throw new WC_Data_Exception(
					'wphave_woocommerce_product_image_forbidden',
					__( 'A selected product image is not available.', 'wphave' )
				);
			}

			$image_ids[] = $image_id;
		}

		return $image_ids;
	}

	/**
	 * Validate product IDs used by WooCommerce relationship setters.
	 *
	 * @param WC_Product $product Grouped product.
	 * @param mixed      $values Candidate product IDs.
	 * @param bool       $allow_grouped Whether grouped products are valid targets.
	 * @return array
	 */

	private static function sanitize_product_reference_ids( WC_Product $product, $values, $allow_grouped = true ) {
		$product_ids = array();

		foreach ( array_unique( array_map( 'absint', is_array( $values ) ? $values : array() ) ) as $child_id ) {
			$child = $child_id && $child_id !== $product->get_id() ? wc_get_product( $child_id ) : false;

			if ( $child instanceof WC_Product && ( $allow_grouped || ! $child->is_type( 'grouped' ) ) ) {
				$product_ids[] = $child_id;
			}
		}

		return $product_ids;
	}

	/**
	 * Apply WooCommerce downloadable-file objects to a product.
	 *
	 * This mirrors WooCommerce Core's REST mutation contract and leaves file
	 * validation and approved-directory enforcement to WC_Product_Download.
	 *
	 * @param WC_Product $product Product.
	 * @param array      $downloads Download rows.
	 * @return void
	 */

	private static function apply_product_downloads( WC_Product $product, array $downloads ) {
		$files = array();
		$downloads = array_slice( $downloads, 0, 100, true );

		foreach ( $downloads as $key => $file ) {
			if ( ! is_array( $file ) || empty( $file['file'] ) ) {
				continue;
			}

			$file_url = (string) wp_unslash( $file['file'] );
			$download = new WC_Product_Download();
			$download->set_id( ! empty( $file['id'] ) ? wc_clean( $file['id'] ) : wp_generate_uuid4() );
			$download->set_name(
				! empty( $file['name'] )
					? wc_clean( wp_unslash( $file['name'] ) )
					: wc_get_filename_from_url( $file_url )
			);
			$download->set_file(
				apply_filters( 'woocommerce_file_download_path', $file_url, $product, $key )
			);
			$files[] = $download;
		}

		$product->set_downloads( $files );
	}

	/**
	 * Apply only the structured fields exposed in the block-editor inspector.
	 *
	 * @param WC_Product $product Product.
	 * @param array      $data Settings data.
	 * @return void
	 */

	private static function apply_product_settings_changes( WC_Product $product, array $data ) {
		$allowed_fields = array_fill_keys(
			array(
				'sku',
				'globalUniqueId',
				'featured',
				'catalogVisibility',
				'galleryImageIds',
				'customAttributes',
				'globalAttributes',
				'defaultAttributes',
				'regularPrice',
				'salePrice',
				'saleStart',
				'saleEnd',
				'taxStatus',
				'taxClass',
				'manageStock',
				'stockQuantity',
				'lowStockAmount',
				'stockStatus',
				'backorders',
				'soldIndividually',
				'virtual',
				'shippingClassId',
				'weight',
				'length',
				'width',
				'height',
				'purchaseNote',
				'downloadable',
				'downloads',
				'downloadLimit',
				'downloadExpiry',
				'externalUrl',
				'buttonText',
				'groupedProductIds',
				'upsellIds',
				'crossSellIds',
				'reviewsAllowed',
				'menuOrder',
			),
			true
		);

		self::apply_product_changes( $product, array_intersect_key( $data, $allowed_fields ) );
	}

	/**
	 * Rehydrate one product ID through WooCommerce's native class for a Core type.
	 *
	 * @param WC_Product $product Current product.
	 * @param array      $data Settings data.
	 * @return WC_Product
	 */

	private static function resolve_product_type_change( WC_Product $product, array $data ) {
		if ( ! array_key_exists( 'type', $data ) ) {
			return $product;
		}

		$type = sanitize_key( (string) $data['type'] );

		if ( $type === $product->get_type() ) {
			return $product;
		}

		if ( ! array_key_exists( $type, self::core_product_types() ) ) {
			throw new WC_Data_Exception( 'wphave_woocommerce_product_type_invalid', __( 'Invalid product type.', 'wphave' ) );
		}

		$classname = WC_Product_Factory::get_classname_from_product_type( $type );

		if ( ! class_exists( $classname ) || ! is_a( $classname, 'WC_Product', true ) ) {
			throw new WC_Data_Exception( 'wphave_woocommerce_product_type_unavailable', __( 'The selected product type is unavailable.', 'wphave' ) );
		}

		return new $classname( $product->get_id() );
	}

	/**
	 * Return only product types owned by WooCommerce Core.
	 *
	 * @return array
	 */

	private static function core_product_types() {
		$core = array( 'simple', 'variable', 'grouped', 'external' );
		$registered = function_exists( 'wc_get_product_types' ) ? wc_get_product_types() : array();
		$types = array();

		foreach ( $core as $type ) {
			if ( isset( $registered[ $type ] ) ) {
				$types[ $type ] = (string) $registered[ $type ];
			}
		}

		return $types;
	}

	/**
	 * Return only stock statuses owned by WooCommerce Core.
	 *
	 * @return array
	 */

	private static function core_stock_statuses() {
		$core = array( 'instock', 'outofstock', 'onbackorder' );
		$registered = function_exists( 'wc_get_product_stock_status_options' )
			? wc_get_product_stock_status_options()
			: array();
		$statuses = array();

		foreach ( $core as $status ) {
			if ( isset( $registered[ $status ] ) ) {
				$statuses[ $status ] = (string) $registered[ $status ];
			}
		}

		return $statuses;
	}
}
