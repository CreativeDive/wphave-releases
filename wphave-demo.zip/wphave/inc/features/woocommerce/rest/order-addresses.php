<?php

/**
 * WooCommerce order address projection, validation and country catalogs.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Validate and persist canonical WooCommerce order addresses.
 */

trait WPHAVE_WooCommerce_REST_Order_Addresses {

	/**
	 * Return canonical editable address values from an order.
	 *
	 * @param WC_Order $order Order.
	 * @param string   $type Address type.
	 * @return array
	 */

	private static function prepare_order_address( WC_Order $order, $type ) {
		$fields = array( 'first_name', 'last_name', 'company', 'address_1', 'address_2', 'city', 'state', 'postcode', 'country' );
		$prepared = array();

		foreach ( $fields as $field ) {
			$getter = 'get_' . $type . '_' . $field;
			$key = lcfirst( str_replace( ' ', '', ucwords( str_replace( '_', ' ', $field ) ) ) );
			$prepared[ $key ] = (string) $order->{$getter}( 'edit' );
		}

		if ( 'billing' === $type ) {
			$prepared['email'] = (string) $order->get_billing_email( 'edit' );
			$prepared['phone'] = (string) $order->get_billing_phone( 'edit' );
		}

		return $prepared;
	}

	/**
	 * Validate an order address against WooCommerce's country/state catalog.
	 *
	 * @param mixed  $value Address payload.
	 * @param string $type Address type.
	 * @return array
	 * @throws WC_Data_Exception When a country, state or email is invalid.
	 */

	private static function validated_order_address( $value, $type ) {
		$value = is_array( $value ) ? $value : array();
		$key_map = array(
			'firstName' => 'first_name',
			'lastName'  => 'last_name',
			'company'   => 'company',
			'address1'  => 'address_1',
			'address2'  => 'address_2',
			'city'      => 'city',
			'state'     => 'state',
			'postcode'  => 'postcode',
			'country'   => 'country',
		);
		$address = array();

		foreach ( $key_map as $input_key => $output_key ) {
			$address[ $output_key ] = substr( sanitize_text_field( wp_unslash( (string) ( $value[ $input_key ] ?? '' ) ) ), 0, 200 );
		}

		$countries = new WC_Countries();
		$country_options = $countries->get_countries();

		if ( '' !== $address['country'] && ! array_key_exists( $address['country'], $country_options ) ) {
			throw new WC_Data_Exception( 'wphave_woocommerce_order_country_invalid', __( 'Invalid order country.', 'wphave' ) );
		}

		$states = '' !== $address['country'] ? $countries->get_states( $address['country'] ) : array();

		if ( is_array( $states ) && $states && '' !== $address['state'] && ! array_key_exists( $address['state'], $states ) ) {
			throw new WC_Data_Exception( 'wphave_woocommerce_order_state_invalid', __( 'Invalid order state.', 'wphave' ) );
		}

		if ( 'billing' === $type ) {
			$email_input = (string) ( $value['email'] ?? '' );
			$email = sanitize_email( $email_input );

			if ( '' !== $email_input && ! is_email( $email ) ) {
				throw new WC_Data_Exception( 'wphave_woocommerce_order_email_invalid', __( 'Invalid billing email address.', 'wphave' ) );
			}

			$address['email'] = $email;
			$address['phone'] = substr( sanitize_text_field( wp_unslash( (string) ( $value['phone'] ?? '' ) ) ), 0, 100 );
		}

		return $address;
	}

	/**
	 * Return WooCommerce's country and state choices for address editing.
	 *
	 * @return array
	 */
    
	private static function order_country_contract() {
		$countries = new WC_Countries();
		$options = array(
			array( 'value' => '', 'label' => __( 'Select a country / region', 'wphave' ) ),
		);
		$states = array_filter( $countries->get_states(), static fn( $country_states ) => is_array( $country_states ) && $country_states );
		$states = array_map(
			static function ( $country_states ) {
				return array_map(
					static function ( $label ) {
						return self::plain_text( $label );
					},
					$country_states
				);
			},
			$states
		);

		foreach ( $countries->get_countries() as $code => $label ) {
			$options[] = array( 'value' => (string) $code, 'label' => self::plain_text( $label ) );
		}

		return array( 'options' => $options, 'states' => $states );
	}
}
