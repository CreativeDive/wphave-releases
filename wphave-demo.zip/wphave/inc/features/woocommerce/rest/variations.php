<?php

/**
 * WooCommerce Core variation collection and mutation workflows.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Expose WooCommerce product-variation projections and mutations.
 */

trait WPHAVE_WooCommerce_REST_Variations {

	/**
	 * Determine whether the current user may edit a variation's parent product.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return bool
	 */

	public static function can_edit_variation( WP_REST_Request $request ) {
		$variation = function_exists( 'wc_get_product' ) ? wc_get_product( absint( $request->get_param( 'id' ) ) ) : false;

		return $variation instanceof WC_Product_Variation
			&& self::has_woocommerce_object_permission(
				'product',
				'edit',
				$variation->get_parent_id()
			);
	}

	/**
	 * Determine whether the current user may delete a variation.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return bool
	 */

	public static function can_delete_variation( WP_REST_Request $request ) {
		$variation = function_exists( 'wc_get_product' )
			? wc_get_product( absint( $request->get_param( 'id' ) ) )
			: false;

		return $variation instanceof WC_Product_Variation
			&& self::has_woocommerce_object_permission(
				'product',
				'delete',
				$variation->get_parent_id()
			);
	}

	/**
	 * Return a paginated variable-product child collection.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */

	public static function get_product_variations( WP_REST_Request $request ) {
		$product = wc_get_product( absint( $request->get_param( 'id' ) ) );

		if ( ! $product instanceof WC_Product_Variable ) {
			return new WP_Error( 'wphave_woocommerce_not_variable', __( 'This product has no variations.', 'wphave' ), array( 'status' => 400 ) );
		}

		$page = max( 1, absint( $request->get_param( 'page' ) ) );
		$per_page = min( 50, max( 1, absint( $request->get_param( 'per_page' ) ) ) );
		$result = wc_get_products(
			array(
				'type'     => 'variation',
				'parent'   => $product->get_id(),
				'limit'    => $per_page,
				'page'     => $page,
				'paginate' => true,
				'orderby'  => 'menu_order',
				'order'    => 'ASC',
				'return'   => 'objects',
			)
		);
		$items = is_object( $result ) && isset( $result->products ) ? $result->products : array();

		return rest_ensure_response(
			array(
				'items' => array_values( array_map( array( __CLASS__, 'prepare_product_variation' ), $items ) ),
				'total' => (int) ( $result->total ?? count( $items ) ),
				'page'  => $page,
				'pages' => (int) ( $result->max_num_pages ?? 1 ),
			)
		);
	}

	/**
	 * Create a disabled variation owned by the requested variable product.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */

	public static function create_product_variation( WP_REST_Request $request ) {
		$product = wc_get_product( absint( $request->get_param( 'id' ) ) );

		if ( ! $product instanceof WC_Product_Variable ) {
			return new WP_Error( 'wphave_woocommerce_not_variable', __( 'This product has no variations.', 'wphave' ), array( 'status' => 400 ) );
		}

		$permission = self::require_woocommerce_object_permission( 'product', 'edit', $product->get_id() );

		if ( is_wp_error( $permission ) ) {
			return $permission;
		}

		$conflict = self::commerce_revision_error( $product, $request->get_param( 'commerceRevision' ) );

		if ( $conflict ) {
			return $conflict;
		}

		try {
			$variation = new WC_Product_Variation();
			$variation->set_parent_id( $product->get_id() );
			$variation->set_status( 'private' );
			$variation->set_attributes( array() );
			$variation->save();
		} catch ( Throwable $exception ) {
			return self::commerce_mutation_error(
				'wphave_woocommerce_variation_invalid',
				__( 'The variation could not be created.', 'wphave' ),
				$exception,
				array( 'product_id' => (int) $product->get_id() )
			);
		}

		$response = rest_ensure_response( self::prepare_product_variation( $variation ) );
		$response->set_status( 201 );

		return $response;
	}

	/**
	 * Persist the explicit editable variation contract.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */

	public static function update_product_variation( WP_REST_Request $request ) {
		$variation = wc_get_product( absint( $request->get_param( 'id' ) ) );

		if ( ! $variation instanceof WC_Product_Variation ) {
			return new WP_Error( 'wphave_woocommerce_variation_not_found', __( 'Variation not found.', 'wphave' ), array( 'status' => 404 ) );
		}

		$permission = self::require_woocommerce_object_permission( 'product', 'edit', $variation->get_parent_id() );

		if ( is_wp_error( $permission ) ) {
			return $permission;
		}

		$conflict = self::commerce_revision_error( $variation, $request->get_param( 'commerceRevision' ) );

		if ( $conflict ) {
			return $conflict;
		}

		$data = array_intersect_key(
			(array) $request->get_json_params(),
			array_fill_keys(
				array( 'attributes', 'enabled', 'imageId', 'description', 'sku', 'globalUniqueId', 'regularPrice', 'salePrice', 'saleStart', 'saleEnd', 'downloadable', 'downloads', 'downloadLimit', 'downloadExpiry', 'taxClass', 'virtual', 'manageStock', 'stockQuantity', 'lowStockAmount', 'stockStatus', 'backorders', 'shippingClassId', 'weight', 'length', 'width', 'height' ),
				true
			)
		);

		try {
			if ( array_key_exists( 'enabled', $data ) ) {
				$variation->set_status( rest_sanitize_boolean( $data['enabled'] ) ? 'publish' : 'private' );
			}
			if ( array_key_exists( 'imageId', $data ) ) {
				$image_id = absint( $data['imageId'] );

				if ( $image_id && ! self::can_use_product_image( $image_id ) ) {
					throw new WC_Data_Exception(
						'wphave_woocommerce_product_image_forbidden',
						__( 'The selected variation image is not available.', 'wphave' )
					);
				}

				$variation->set_image_id( $image_id );
			}
			if ( array_key_exists( 'globalUniqueId', $data ) && method_exists( $variation, 'set_global_unique_id' ) ) {
				$variation->set_global_unique_id( wc_clean( wp_unslash( $data['globalUniqueId'] ) ) );
			}
			if ( array_key_exists( 'attributes', $data ) ) {
				self::apply_variation_attributes( $variation, $data['attributes'] );
			}
			if ( array_key_exists( 'taxClass', $data ) ) {
				$allowed_tax_classes = array_merge( array( 'parent', '' ), array_map( 'sanitize_title', WC_Tax::get_tax_classes() ) );

				if ( ! in_array( $data['taxClass'], $allowed_tax_classes, true ) ) {
					throw new WC_Data_Exception( 'wphave_woocommerce_invalid_variation_tax_class', __( 'Invalid tax class.', 'woocommerce' ) );
				}
			}
			self::apply_product_changes( $variation, $data );
			$variation->save();
		} catch ( Throwable $exception ) {
			return self::commerce_mutation_error(
				'wphave_woocommerce_variation_invalid',
				__( 'The variation could not be saved.', 'wphave' ),
				$exception,
				array( 'variation_id' => (int) $variation->get_id() )
			);
		}

		return rest_ensure_response( self::prepare_product_variation( $variation ) );
	}

	/**
	 * Move a variation to the WordPress trash through WooCommerce CRUD.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */

	public static function delete_product_variation( WP_REST_Request $request ) {
		$variation = wc_get_product( absint( $request->get_param( 'id' ) ) );

		if ( ! $variation instanceof WC_Product_Variation ) {
			return new WP_Error( 'wphave_woocommerce_variation_not_found', __( 'Variation not found.', 'wphave' ), array( 'status' => 404 ) );
		}

		$permission = self::require_woocommerce_object_permission( 'product', 'delete', $variation->get_parent_id() );

		if ( is_wp_error( $permission ) ) {
			return $permission;
		}

		$conflict = self::commerce_revision_error( $variation, $request->get_param( 'commerceRevision' ) );

		if ( $conflict ) {
			return $conflict;
		}

		try {
			$variation->delete( false );
		} catch ( Throwable $exception ) {
			return self::commerce_mutation_error(
				'wphave_woocommerce_variation_delete_failed',
				__( 'The variation could not be moved to the trash.', 'wphave' ),
				$exception,
				array( 'variation_id' => (int) $variation->get_id() )
			);
		}

		return rest_ensure_response(
			array(
				'id'      => (int) $variation->get_id(),
				'deleted' => true,
				'status'  => 'trash',
			)
		);
	}

	/**
	 * Prepare an editable variation view model from WooCommerce CRUD.
	 *
	 * @param WC_Product_Variation $variation Variation.
	 * @return array
	 */

	public static function prepare_product_variation( WC_Product_Variation $variation ) {
		return array(
			'id'               => (int) $variation->get_id(),
			'label'            => wp_strip_all_tags( wc_get_formatted_variation( $variation, true, false, true ) ),
			'attributes'       => self::prepare_variation_attributes( $variation ),
			'enabled'          => 'publish' === $variation->get_status( 'edit' ),
			'imageId'          => (int) $variation->get_image_id( 'edit' ),
			'description'      => (string) $variation->get_description( 'edit' ),
			'sku'              => (string) $variation->get_sku( 'edit' ),
			'globalUniqueId'   => method_exists( $variation, 'get_global_unique_id' ) ? (string) $variation->get_global_unique_id( 'edit' ) : null,
			'regularPrice'     => (string) $variation->get_regular_price( 'edit' ),
			'salePrice'        => (string) $variation->get_sale_price( 'edit' ),
			'saleStart'        => self::format_product_date( $variation->get_date_on_sale_from( 'edit' ) ),
			'saleEnd'          => self::format_product_date( $variation->get_date_on_sale_to( 'edit' ) ),
			'downloadable'     => (bool) $variation->get_downloadable( 'edit' ),
			'downloads'        => self::prepare_product_downloads( $variation ),
			'downloadLimit'    => (int) $variation->get_download_limit( 'edit' ),
			'downloadExpiry'   => (int) $variation->get_download_expiry( 'edit' ),
			'taxClass'         => (string) $variation->get_tax_class( 'edit' ),
			'virtual'          => (bool) $variation->get_virtual( 'edit' ),
			'manageStock'      => (bool) $variation->get_manage_stock( 'edit' ),
			'stockQuantity'    => $variation->get_stock_quantity( 'edit' ),
			'lowStockAmount'   => '' === $variation->get_low_stock_amount( 'edit' ) ? null : $variation->get_low_stock_amount( 'edit' ),
			'stockStatus'      => (string) $variation->get_stock_status( 'edit' ),
			'backorders'       => (string) $variation->get_backorders( 'edit' ),
			'shippingClassId'  => (int) $variation->get_shipping_class_id( 'edit' ),
			'weight'           => (string) $variation->get_weight( 'edit' ),
			'length'           => (string) $variation->get_length( 'edit' ),
			'width'            => (string) $variation->get_width( 'edit' ),
			'height'           => (string) $variation->get_height( 'edit' ),
			'commerceRevision' => self::product_commerce_revision( $variation ),
		);
	}

	/**
	 * Apply only attribute values allowed by the variable parent.
	 *
	 * @param WC_Product_Variation $variation Variation.
	 * @param mixed                $values Values keyed by parent attribute key.
	 * @return void
	 */

	private static function apply_variation_attributes( WC_Product_Variation $variation, $values ) {
		$parent = wc_get_product( $variation->get_parent_id() );

		if ( ! $parent instanceof WC_Product_Variable ) {
			throw new WC_Data_Exception( 'wphave_woocommerce_variation_parent_invalid', __( 'Variable parent product not found.', 'woocommerce' ) );
		}

		$values = is_array( $values ) ? $values : array();
		$current = $variation->get_attributes( 'edit' );
		$attributes = array();

		foreach ( $parent->get_attributes( 'edit' ) as $key => $attribute ) {
			if ( ! $attribute instanceof WC_Product_Attribute || ! $attribute->get_variation() ) {
				continue;
			}

			$value = sanitize_title( wp_unslash( $values[ $key ] ?? $current[ $key ] ?? '' ) );
			$terms = $attribute->is_taxonomy() ? $attribute->get_terms() : array();
			$allowed = $attribute->is_taxonomy()
				? wp_list_pluck( is_array( $terms ) ? $terms : array(), 'slug' )
				: array_map( 'sanitize_title', $attribute->get_options() );

			if ( '' !== $value && ! in_array( $value, $allowed, true ) ) {
				throw new WC_Data_Exception( 'wphave_woocommerce_variation_attribute_invalid', __( 'Invalid variation attribute value.', 'woocommerce' ) );
			}

			$attributes[ $key ] = $value;
		}

		$variation->set_attributes( $attributes );
	}

	/**
	 * Prepare editable variation attributes from the variable parent contract.
	 *
	 * @param WC_Product_Variation $variation Variation.
	 * @return array
	 */

	private static function prepare_variation_attributes( WC_Product_Variation $variation ) {
		$parent = wc_get_product( $variation->get_parent_id() );

		if ( ! $parent instanceof WC_Product_Variable ) {
			return array();
		}

		$current = $variation->get_attributes( 'edit' );
		$prepared = array();

		foreach ( $parent->get_attributes( 'edit' ) as $key => $attribute ) {
			if ( ! $attribute instanceof WC_Product_Attribute || ! $attribute->get_variation() ) {
				continue;
			}

			if ( $attribute->is_taxonomy() ) {
				$terms = $attribute->get_terms();
				$options = array_map(
					static function ( $term ) {
						return array( 'value' => (string) $term->slug, 'label' => (string) $term->name );
					},
					is_array( $terms ) ? $terms : array()
				);
			} else {
				$options = array_map(
					static function ( $option ) {
						return array( 'value' => sanitize_title( $option ), 'label' => (string) $option );
					},
					$attribute->get_options()
				);
			}

			$prepared[] = array(
				'key'     => (string) $key,
				'label'   => (string) wc_attribute_label( $attribute->get_name(), $parent ),
				'value'   => $attribute->is_taxonomy()
					? (string) ( $current[ $key ] ?? '' )
					: sanitize_title( (string) ( $current[ $key ] ?? '' ) ),
				'options' => array_values( $options ),
			);
		}

		return $prepared;
	}
}
