<?php

/**
 * WooCommerce product editor projection and reference catalogs.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once dirname(__DIR__, 2) . '/security/safe-link.php';

/**
 * Provide the canonical data contract for the WPHAVE product editor.
 */

trait WPHAVE_WooCommerce_REST_Product_Editor {

	/**
	 * Prepare the editable WooCommerce Core product contract.
	 *
	 * @param WC_Product $product Product.
	 * @return array
	 */

	public static function prepare_product_editor( WC_Product $product ) {
		return array(
			'id'                => (int) $product->get_id(),
			'sellingModel'      => self::product_selling_model( $product ),
			'readiness'         => self::prepare_product_readiness( $product ),
			'type'              => (string) $product->get_type(),
			'name'              => (string) $product->get_name( 'edit' ),
			'slug'              => (string) $product->get_slug( 'edit' ),
			'description'       => (string) $product->get_description( 'edit' ),
			'shortDescription'  => (string) $product->get_short_description( 'edit' ),
			'status'            => (string) $product->get_status( 'edit' ),
			'featured'          => (bool) $product->get_featured( 'edit' ),
			'catalogVisibility' => (string) $product->get_catalog_visibility( 'edit' ),
			'galleryImageIds'   => array_map( 'absint', $product->get_gallery_image_ids( 'edit' ) ),
			'customAttributes'  => self::prepare_product_attributes( $product, false ),
			'globalAttributes'  => self::prepare_product_attributes( $product, true ),
			'defaultAttributes' => self::prepare_default_product_attributes( $product ),
			'sku'               => (string) $product->get_sku( 'edit' ),
			'globalUniqueId'    => method_exists( $product, 'get_global_unique_id' ) ? (string) $product->get_global_unique_id( 'edit' ) : null,
			'regularPrice'      => (string) $product->get_regular_price( 'edit' ),
			'salePrice'         => (string) $product->get_sale_price( 'edit' ),
			'saleStart'         => self::format_product_date( $product->get_date_on_sale_from( 'edit' ) ),
			'saleEnd'           => self::format_product_date( $product->get_date_on_sale_to( 'edit' ) ),
			'virtual'           => (bool) $product->get_virtual( 'edit' ),
			'downloadable'      => (bool) $product->get_downloadable( 'edit' ),
			'downloads'         => self::prepare_product_downloads( $product ),
			'downloadLimit'     => (int) $product->get_download_limit( 'edit' ),
			'downloadExpiry'    => (int) $product->get_download_expiry( 'edit' ),
			'externalUrl'       => method_exists( $product, 'get_product_url' ) ? (string) $product->get_product_url( 'edit' ) : null,
			'buttonText'        => method_exists( $product, 'get_button_text' ) ? (string) $product->get_button_text( 'edit' ) : null,
			'groupedProductIds' => method_exists( $product, 'get_children' ) ? array_map( 'absint', $product->get_children( 'edit' ) ) : array(),
			'upsellIds'         => array_map( 'absint', $product->get_upsell_ids( 'edit' ) ),
			'crossSellIds'      => array_map( 'absint', $product->get_cross_sell_ids( 'edit' ) ),
			'shippingClassId'   => (int) $product->get_shipping_class_id( 'edit' ),
			'manageStock'       => (bool) $product->get_manage_stock( 'edit' ),
			'stockQuantity'     => $product->get_stock_quantity( 'edit' ),
			'lowStockAmount'    => '' === $product->get_low_stock_amount( 'edit' ) ? null : $product->get_low_stock_amount( 'edit' ),
			'stockStatus'       => (string) $product->get_stock_status( 'edit' ),
			'backorders'        => (string) $product->get_backorders( 'edit' ),
			'soldIndividually'  => (bool) $product->get_sold_individually( 'edit' ),
			'weight'            => (string) $product->get_weight( 'edit' ),
			'length'            => (string) $product->get_length( 'edit' ),
			'width'             => (string) $product->get_width( 'edit' ),
			'height'            => (string) $product->get_height( 'edit' ),
			'purchaseNote'      => (string) $product->get_purchase_note( 'edit' ),
			'reviewsAllowed'    => (bool) $product->get_reviews_allowed( 'edit' ),
			'menuOrder'         => (int) $product->get_menu_order( 'edit' ),
			'taxStatus'         => (string) $product->get_tax_status( 'edit' ),
			'taxClass'          => (string) $product->get_tax_class( 'edit' ),
			'commerceRevision'  => self::product_commerce_revision( $product ),
			'modifiedGmt'       => self::product_modified_gmt( $product ),
			// LINK INVARIANT: Core's filtered edit URL is validated at the REST boundary.
			'nativeEditUrl'     => WPHAVE_Safe_Link::http( get_edit_post_link( $product->get_id(), 'raw' ) ),
		);
	}

	/**
	 * Translate WooCommerce Core types into user-facing selling models.
	 *
	 * The model is a presentation projection only. WooCommerce remains the
	 * canonical source for the persisted type and fulfillment flags.
	 *
	 * @param WC_Product $product Product.
	 * @return array
	 */

	private static function product_selling_model( WC_Product $product ) {
		$type = $product->get_type();

		if ( 'simple' === $type ) {
			if ( $product->get_virtual( 'edit' ) || $product->get_downloadable( 'edit' ) ) {
				return array( 'key' => 'digital', 'label' => __( 'Digital product', 'wphave' ) );
			}

			return array( 'key' => 'physical', 'label' => __( 'Physical product', 'wphave' ) );
		}

		$models = array(
			'variable' => array( 'key' => 'options', 'label' => __( 'Product with options', 'wphave' ) ),
			'external' => array( 'key' => 'external', 'label' => __( 'External product', 'wphave' ) ),
			'grouped'  => array( 'key' => 'group', 'label' => __( 'Product group', 'wphave' ) ),
		);

		return $models[ $type ] ?? array( 'key' => $type, 'label' => wc_get_product_types()[ $type ] ?? $type );
	}

	/**
	 * Derive non-blocking product setup guidance from canonical product data.
	 *
	 * Readiness is deliberately not persisted and never prevents saving or
	 * publishing. It is safe to discard and can evolve with the WPHAVE UI.
	 *
	 * @param WC_Product $product Product.
	 * @return array
	 */

	private static function prepare_product_readiness( WC_Product $product ) {
		$issues = array();
		$type   = $product->get_type();

		if ( '' === trim( $product->get_name( 'edit' ) ) ) {
			$issues[] = array( 'key' => 'name', 'label' => __( 'Add a product name.', 'wphave' ) );
		}

		if ( ! $product->get_image_id( 'edit' ) ) {
			$issues[] = array( 'key' => 'image', 'label' => __( 'Add a primary product image.', 'wphave' ) );
		}

		if ( ! in_array( $type, array( 'grouped', 'external' ), true ) && '' === $product->get_price( 'edit' ) ) {
			$issues[] = array( 'key' => 'price', 'label' => __( 'Set a selling price.', 'wphave' ) );
		}

		if ( 'variable' === $type && ! $product->get_children() ) {
			$issues[] = array( 'key' => 'variations', 'label' => __( 'Create at least one product option.', 'wphave' ) );
		}

		if ( $product->get_downloadable( 'edit' ) && ! $product->get_downloads( 'edit' ) ) {
			$issues[] = array( 'key' => 'downloads', 'label' => __( 'Add a downloadable file.', 'wphave' ) );
		}

		if ( 'external' === $type && '' === trim( $product->get_product_url( 'edit' ) ) ) {
			$issues[] = array( 'key' => 'externalUrl', 'label' => __( 'Add the external product URL.', 'wphave' ) );
		}

		if ( 'grouped' === $type && ! $product->get_children( 'edit' ) ) {
			$issues[] = array( 'key' => 'groupedProducts', 'label' => __( 'Add at least one product to the group.', 'wphave' ) );
		}

		return array(
			'status' => $issues ? 'needs_attention' : 'ready',
			'label'  => $issues ? __( 'Needs attention', 'wphave' ) : __( 'Ready', 'wphave' ),
			'issues' => $issues,
		);
	}

	/**
	 * Prepare the structured settings embedded in the product REST entity.
	 *
	 * @param WC_Product $product Product.
	 * @return array
	 */

	private static function prepare_product_settings( WC_Product $product ) {
		$editor = self::prepare_product_editor( $product );
		$fields = array(
			'type',
			'sku',
			'globalUniqueId',
			'featured',
			'catalogVisibility',
			'galleryImageIds',
			'customAttributes',
			'defaultAttributes',
			'regularPrice',
			'salePrice',
			'saleStart',
			'saleEnd',
			'taxStatus',
			'taxClass',
			'manageStock',
			'stockQuantity',
			'lowStockAmount',
			'stockStatus',
			'backorders',
			'soldIndividually',
			'virtual',
			'shippingClassId',
			'weight',
			'length',
			'width',
			'height',
			'purchaseNote',
			'downloadable',
			'downloads',
			'downloadLimit',
			'downloadExpiry',
			'externalUrl',
			'buttonText',
			'groupedProductIds',
			'upsellIds',
			'crossSellIds',
			'reviewsAllowed',
			'menuOrder',
			'commerceRevision',
		);

		$settings = array_intersect_key( $editor, array_fill_keys( $fields, true ) );
		$settings['sellingModel'] = $editor['sellingModel'];
		$settings['readiness'] = $editor['readiness'];
		$settings['nativeEditUrl'] = $editor['nativeEditUrl'];
		$settings['productTypes'] = array_map(
			static function ( $value, $label ) {
				return array( 'value' => $value, 'label' => $label );
			},
			array_keys( self::core_product_types() ),
			array_values( self::core_product_types() )
		);
		$settings['taxClasses'] = self::tax_class_options();
		$settings['shippingClasses'] = self::shipping_class_options();
		$settings['weightUnit'] = (string) get_option( 'woocommerce_weight_unit', 'kg' );
		$settings['dimensionUnit'] = (string) get_option( 'woocommerce_dimension_unit', 'cm' );
		$settings['globalLowStockAmount'] = (int) get_option( 'woocommerce_notify_low_stock_amount', 2 );
		$settings['supportsGlobalUniqueId'] = method_exists( $product, 'set_global_unique_id' );
		$settings['globalAttributes'] = $editor['globalAttributes'];
		$settings['attributeTaxonomies'] = self::attribute_taxonomy_options();
		$settings['groupedProducts'] = self::product_reference_options( $settings['groupedProductIds'] );
		$settings['upsellProducts'] = self::product_reference_options( $settings['upsellIds'] );
		$settings['crossSellProducts'] = self::product_reference_options( $settings['crossSellIds'] );

		return $settings;
	}

	/**
	 * Return the bounded catalog of WooCommerce global attribute taxonomies.
	 *
	 * @return array
	 */
    
	private static function attribute_taxonomy_options() {
		return array_values(
			array_map(
				static function ( $taxonomy ) {
					return array(
						'id'       => (int) $taxonomy->attribute_id,
						'label'    => (string) $taxonomy->attribute_label,
						'taxonomy' => wc_attribute_taxonomy_name( $taxonomy->attribute_name ),
					);
				},
				wc_get_attribute_taxonomies()
			)
		);
	}

	/**
	 * Prepare either taxonomy-backed or custom product attributes.
	 *
	 * @param WC_Product $product Product.
	 * @param bool       $taxonomy_only Select taxonomy attributes when true.
	 * @return array
	 */

	private static function prepare_product_attributes( WC_Product $product, $taxonomy_only ) {
		$prepared = array();

		foreach ( $product->get_attributes( 'edit' ) as $attribute ) {
			if ( ! $attribute instanceof WC_Product_Attribute || $attribute->is_taxonomy() !== $taxonomy_only ) {
				continue;
			}

			$terms = $taxonomy_only ? $attribute->get_terms() : array();
			$prepared[] = array(
				'attributeId' => $taxonomy_only ? (int) $attribute->get_id() : 0,
				'taxonomy'   => $taxonomy_only ? $attribute->get_name() : '',
				'name'       => $taxonomy_only ? wc_attribute_label( $attribute->get_name() ) : $attribute->get_name(),
				'key'        => $taxonomy_only ? $attribute->get_name() : sanitize_title( $attribute->get_name() ),
				'optionIds'  => $taxonomy_only ? array_map( 'absint', $attribute->get_options() ) : array(),
				'selectedTerms' => $taxonomy_only && $terms ? array_map(
					static function ( $term ) {
						return array( 'id' => (int) $term->term_id, 'name' => (string) $term->name );
					},
					$terms
				) : array(),
				'options'   => $taxonomy_only ? array() : array_values( $attribute->get_options() ),
				'visible'   => $attribute->get_visible(),
				'variation' => $attribute->get_variation(),
			);
		}

		return $prepared;
	}

	/**
	 * Convert stored default slugs to the editor's validated option values.
	 *
	 * @param WC_Product $product Product.
	 * @return array
	 */

	private static function prepare_default_product_attributes( WC_Product $product ) {
		if ( ! $product->is_type( 'variable' ) || ! method_exists( $product, 'get_default_attributes' ) ) {
			return array();
		}

		$prepared = array();
		$defaults = $product->get_default_attributes( 'edit' );

		foreach ( $product->get_attributes( 'edit' ) as $key => $attribute ) {
			if ( ! $attribute instanceof WC_Product_Attribute || ! $attribute->get_variation() || ! isset( $defaults[ $key ] ) ) {
				continue;
			}

			if ( $attribute->is_taxonomy() ) {
				$term = get_term_by( 'slug', $defaults[ $key ], $attribute->get_name() );

				if ( $term instanceof WP_Term ) {
					$prepared[ $key ] = (int) $term->term_id;
				}
			} else {
				$prepared[ $key ] = (string) $defaults[ $key ];
			}
		}

		return $prepared;
	}

	/**
	 * Resolve selected related products so their labels remain stable outside
	 * the current product-query page.
	 *
	 * @param array $product_ids Product IDs.
	 * @return array
	 */

	private static function product_reference_options( array $product_ids ) {
		$options = array();

		foreach ( $product_ids as $product_id ) {
			$product = wc_get_product( $product_id );

			if ( $product instanceof WC_Product ) {
				$options[] = array(
					'id'    => (int) $product->get_id(),
					'type'  => 'product',
					'title' => array( 'rendered' => (string) $product->get_name( 'edit' ) ),
				);
			}
		}

		return $options;
	}

	/**
	 * Return the tax classes configured in WooCommerce Core.
	 *
	 * The empty slug is WooCommerce's canonical standard tax class.
	 *
	 * @return array
	 */

	private static function tax_class_options() {
		$options = array(
			array(
				'value' => '',
				'label' => __( 'Standard', 'woocommerce' ),
			),
		);

		if ( ! class_exists( 'WC_Tax' ) ) {
			return $options;
		}

		foreach ( WC_Tax::get_tax_classes() as $tax_class ) {
			$options[] = array(
				'value' => sanitize_title( $tax_class ),
				'label' => (string) $tax_class,
			);
		}

		return $options;
	}

	/**
	 * Return the shipping classes configured in WooCommerce Core.
	 *
	 * @return array
	 */

	private static function shipping_class_options() {
		$options = array(
			array(
				'value' => 0,
				'label' => __( 'No shipping class', 'woocommerce' ),
			),
		);
		$terms = get_terms(
			array(
				'taxonomy'   => 'product_shipping_class',
				'hide_empty' => false,
			)
		);

		if ( is_wp_error( $terms ) ) {
			return $options;
		}
		$name_counts = array_count_values(
			array_map(
				static function ( $term ) {
					return (string) $term->name;
				},
				$terms
			)
		);

		foreach ( $terms as $term ) {
			$options[] = array(
				'value' => (int) $term->term_id,
				'label' => $name_counts[ $term->name ] > 1
					? sprintf( '%1$s (%2$s)', $term->name, $term->slug )
					: (string) $term->name,
			);
		}

		return $options;
	}

	/**
	 * Format a WooCommerce product date for the REST editor contract.
	 *
	 * @param WC_DateTime|null $date Date.
	 * @return string|null
	 */

	private static function format_product_date( $date ) {
		return $date instanceof WC_DateTime ? $date->format( DATE_ATOM ) : null;
	}

	/**
	 * Prepare WooCommerce download objects for the editor contract.
	 *
	 * @param WC_Product $product Product.
	 * @return array
	 */

	private static function prepare_product_downloads( WC_Product $product ) {
		return array_values(
			array_map(
				static function ( WC_Product_Download $download ) {
					return array(
						'id'   => (string) $download->get_id(),
						'name' => (string) $download->get_name(),
						'file' => (string) $download->get_file(),
					);
				},
				$product->get_downloads( 'edit' )
			)
		);
	}

	/**
	 * Validate a structured Commerce revision token.
	 *
	 * @param WC_Product $product Product.
	 * @param mixed      $expected_revision Expected revision.
	 * @return WP_Error|null
	 */

	private static function commerce_revision_error( WC_Product $product, $expected_revision ) {
		$expected_revision = sanitize_text_field( (string) $expected_revision );

		// SECURITY INVARIANT: Structured product mutations are bound to the commerce
		// fields the editor observed, while unrelated WordPress post changes do not
		// spuriously authorize or invalidate that mutation contract.
		if ( ! $expected_revision || hash_equals( self::product_commerce_revision( $product ), $expected_revision ) ) {
			return null;
		}

		return new WP_Error(
			'wphave_woocommerce_product_conflict',
			__( 'This product changed after it was opened. Reload it before saving.', 'wphave' ),
			array( 'status' => 409 )
		);
	}

	/**
	 * Return a conflict token scoped to structured Commerce fields.
	 *
	 * Block-editor content changes update the product post timestamp but must not
	 * invalidate an otherwise independent Commerce inspector save.
	 *
	 * @param WC_Product $product Product.
	 * @return string
	 */

	private static function product_commerce_revision( WC_Product $product ) {
		$values = array(
			$product->get_type(),
			$product instanceof WC_Product_Variation ? $product->get_attributes( 'edit' ) : null,
			$product->get_status( 'edit' ),
			$product->get_image_id( 'edit' ),
			$product->get_description( 'edit' ),
			array_map( 'absint', $product->get_gallery_image_ids( 'edit' ) ),
			self::prepare_product_attributes( $product, false ),
			self::prepare_product_attributes( $product, true ),
			self::prepare_default_product_attributes( $product ),
			$product->get_sku( 'edit' ),
			method_exists( $product, 'get_global_unique_id' ) ? $product->get_global_unique_id( 'edit' ) : null,
			$product->get_regular_price( 'edit' ),
			$product->get_sale_price( 'edit' ),
			self::format_product_date( $product->get_date_on_sale_from( 'edit' ) ),
			self::format_product_date( $product->get_date_on_sale_to( 'edit' ) ),
			$product->get_tax_status( 'edit' ),
			$product->get_tax_class( 'edit' ),
			$product->get_manage_stock( 'edit' ),
			$product->get_stock_quantity( 'edit' ),
			$product->get_low_stock_amount( 'edit' ),
			$product->get_stock_status( 'edit' ),
			$product->get_backorders( 'edit' ),
			$product->get_sold_individually( 'edit' ),
			$product->get_virtual( 'edit' ),
			$product->get_downloadable( 'edit' ),
			$product->get_shipping_class_id( 'edit' ),
			$product->get_weight( 'edit' ),
			$product->get_length( 'edit' ),
			$product->get_width( 'edit' ),
			$product->get_height( 'edit' ),
			$product->get_purchase_note( 'edit' ),
			$product->get_downloadable( 'edit' ),
			self::prepare_product_downloads( $product ),
			$product->get_download_limit( 'edit' ),
			$product->get_download_expiry( 'edit' ),
			method_exists( $product, 'get_product_url' ) ? $product->get_product_url( 'edit' ) : null,
			method_exists( $product, 'get_button_text' ) ? $product->get_button_text( 'edit' ) : null,
			method_exists( $product, 'get_children' ) ? array_map( 'absint', $product->get_children( 'edit' ) ) : array(),
			array_map( 'absint', $product->get_upsell_ids( 'edit' ) ),
			array_map( 'absint', $product->get_cross_sell_ids( 'edit' ) ),
			$product->get_reviews_allowed( 'edit' ),
			$product->get_menu_order( 'edit' ),
		);

		return hash( 'sha256', wp_json_encode( $values ) );
	}

	/**
	 * Return the optimistic concurrency token for a product.
	 *
	 * @param WC_Product $product Product.
	 * @return string
	 */
    
	private static function product_modified_gmt( WC_Product $product ) {
		$date = $product->get_date_modified( 'edit' );

		return $date ? $date->setTimezone( new DateTimeZone( 'UTC' ) )->format( DATE_ATOM ) : '';
	}

	/**
	 * Describe the stable product editor envelope.
	 *
	 * @return array
	 */

	public static function product_schema() {
		return array(
			'$schema'    => 'http://json-schema.org/draft-04/schema#',
			'title'      => 'wphave-commerce-product',
			'type'       => 'object',
			'properties' => array(
				'id'   => array( 'type' => 'integer', 'readonly' => true ),
				'name' => array( 'type' => 'string' ),
				'type' => array( 'type' => 'string', 'readonly' => true ),
			),
		);
	}
}
