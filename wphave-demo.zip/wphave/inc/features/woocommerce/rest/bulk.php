<?php

/**
 * Bounded Commerce bulk mutations through WooCommerce CRUD objects.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Provide bounded bulk mutation workflows for Commerce resources.
 */

trait WPHAVE_WooCommerce_REST_Bulk {
	/**
	 * Bulk-update canonical products.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */

	public static function bulk_products( WP_REST_Request $request ) {
		$actions = array(
			'publish'     => array( 'field' => 'status', 'value' => 'publish' ),
			'draft'       => array( 'field' => 'status', 'value' => 'draft' ),
			'private'     => array( 'field' => 'status', 'value' => 'private' ),
			'in_stock'    => array( 'field' => 'stock', 'value' => 'instock' ),
			'out_of_stock'=> array( 'field' => 'stock', 'value' => 'outofstock' ),
			'add_category' => array( 'field' => 'category', 'value' => absint( $request->get_param( 'categoryId' ) ) ),
		);
		$contract = self::bulk_contract( $request, array_keys( $actions ) );

		if ( is_wp_error( $contract ) ) {
			return $contract;
		}

		$operation = $actions[ $contract['action'] ];
		if ( 'category' === $operation['field'] && ( ! $operation['value'] || ! term_exists( $operation['value'], 'product_cat' ) ) ) {
			return new WP_Error( 'wphave_woocommerce_bulk_category', __( 'Select a valid product category.', 'wphave' ), array( 'status' => 400 ) );
		}

		return rest_ensure_response(
			array(
				'items' => array_map(
					static function ( $id ) use ( $operation ) {
						$product = wc_get_product( $id );

						if ( ! $product instanceof WC_Product ) {
							return self::bulk_result( $id, 'skipped', __( 'Product was not found.', 'wphave' ) );
						}

						if ( ! self::has_woocommerce_object_permission( 'product', 'edit', $id ) ) {
							return self::bulk_result( $id, 'unauthorized', __( 'Product cannot be edited.', 'wphave' ) );
						}

						if ( 'status' === $operation['field']
							&& in_array( $operation['value'], array( 'publish', 'private' ), true )
							&& ! current_user_can( 'publish_products' ) ) {
							return self::bulk_result( $id, 'unauthorized', __( 'Product cannot be published.', 'wphave' ) );
						}

						try {
							if ( 'status' === $operation['field'] ) {
								$product->set_status( $operation['value'] );
							} elseif ( 'stock' === $operation['field'] ) {
								$product->set_stock_status( $operation['value'] );
							} else {
								$product->set_category_ids( array_values( array_unique( array_merge( $product->get_category_ids(), array( $operation['value'] ) ) ) ) );
							}
							$product->save();
						} catch ( Throwable $error ) {
							return self::bulk_result( $id, 'failed', __( 'Product could not be updated.', 'wphave' ) );
						}

						return self::bulk_result( $id, 'success' );
					},
					$contract['ids']
				),
			)
		);
	}

	/**
	 * Bulk-update canonical orders.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */

	public static function bulk_orders( WP_REST_Request $request ) {
		$contract = self::bulk_contract( $request, array_keys( self::core_order_statuses() ) );

		if ( is_wp_error( $contract ) ) {
			return $contract;
		}

		return rest_ensure_response(
			array(
				'items' => array_map(
					static function ( $id ) use ( $contract ) {
						$order = wc_get_order( $id );

						if ( ! $order instanceof WC_Order ) {
							return self::bulk_result( $id, 'skipped', __( 'Order was not found.', 'wphave' ) );
						}

						if ( ! self::has_woocommerce_object_permission( 'shop_order', 'edit', $id ) ) {
							return self::bulk_result( $id, 'unauthorized', __( 'Order cannot be edited.', 'wphave' ) );
						}

						try {
							$order->set_status( $contract['action'] );
							$order->save();
						} catch ( Throwable $error ) {
							return self::bulk_result( $id, 'failed', __( 'Order could not be updated.', 'wphave' ) );
						}

						return self::bulk_result( $id, 'success' );
					},
					$contract['ids']
				),
			)
		);
	}

	/**
	 * Bulk-enable or disable canonical coupons.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */

	public static function bulk_coupons( WP_REST_Request $request ) {
		$contract = self::bulk_contract( $request, array( 'enable', 'disable' ) );

		if ( is_wp_error( $contract ) ) {
			return $contract;
		}

		return rest_ensure_response(
			array(
				'items' => array_map(
					static function ( $id ) use ( $contract ) {
						$coupon = new WC_Coupon( $id );

						if ( ! $coupon->get_id() ) {
							return self::bulk_result( $id, 'skipped', __( 'Coupon was not found.', 'wphave' ) );
						}

						if ( ! self::has_woocommerce_object_permission( 'shop_coupon', 'edit', $id ) ) {
							return self::bulk_result( $id, 'unauthorized', __( 'Coupon cannot be edited.', 'wphave' ) );
						}

						try {
							$coupon->set_status( 'enable' === $contract['action'] ? 'publish' : 'draft' );
							$coupon->save();
						} catch ( Throwable $error ) {
							return self::bulk_result( $id, 'failed', __( 'Coupon could not be updated.', 'wphave' ) );
						}

						return self::bulk_result( $id, 'success' );
					},
					$contract['ids']
				),
			)
		);
	}

	/**
	 * Validate the shared bounded bulk request envelope.
	 *
	 * @param WP_REST_Request $request Request.
	 * @param array           $allowed_actions Allowed actions.
	 * @return array|WP_Error
	 */

	private static function bulk_contract( WP_REST_Request $request, $allowed_actions ) {
		$ids    = array_values( array_unique( array_filter( array_map( 'absint', (array) $request->get_param( 'ids' ) ) ) ) );
		$action = sanitize_key( (string) $request->get_param( 'action' ) );

		// SECURITY INVARIANT: Bulk authority is closed over a bounded, normalized ID
		// set and an explicit action allowlist. Each accepted ID is still subjected
		// to its native object-level permission immediately before mutation.
		if ( empty( $ids ) ) {
			return new WP_Error( 'wphave_woocommerce_bulk_empty', __( 'Select at least one item.', 'wphave' ), array( 'status' => 400 ) );
		}

		if ( count( $ids ) > 100 ) {
			return new WP_Error( 'wphave_woocommerce_bulk_limit', __( 'No more than 100 items may be changed at once.', 'wphave' ), array( 'status' => 400 ) );
		}

		if ( ! in_array( $action, $allowed_actions, true ) ) {
			return new WP_Error( 'wphave_woocommerce_bulk_action', __( 'This bulk action is not supported.', 'wphave' ), array( 'status' => 400 ) );
		}

		return array( 'ids' => $ids, 'action' => $action );
	}

	/**
	 * Return one explicit per-item mutation result.
	 *
	 * @param int    $id Item ID.
	 * @param string $status Result status.
	 * @param string $message Optional error.
	 * @return array
	 */
    
	private static function bulk_result( $id, $status, $message = '' ) {
		$status = in_array( $status, array( 'success', 'failed', 'skipped', 'unauthorized' ), true )
			? $status
			: 'failed';

		return array(
			'id'      => (int) $id,
			'status'  => $status,
			'success' => 'success' === $status,
			'message' => (string) $message,
		);
	}
}
