<?php

/**
 * WooCommerce order-note collection and append workflows.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Expose WooCommerce order-note timeline and creation workflows.
 */

trait WPHAVE_WooCommerce_REST_Order_Notes {

	/**
	 * Append an internal note through WooCommerce's order-note API.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */

	public static function create_order_note( WP_REST_Request $request ) {
		$order = wc_get_order( absint( $request->get_param( 'id' ) ) );

		if ( ! $order instanceof WC_Order ) {
			return new WP_Error( 'wphave_woocommerce_order_not_found', __( 'Order not found.', 'wphave' ), array( 'status' => 404 ) );
		}

		$permission = self::require_woocommerce_object_permission( 'shop_order', 'edit', $order->get_id() );

		if ( is_wp_error( $permission ) ) {
			return $permission;
		}

		$note = trim( sanitize_textarea_field( wp_unslash( (string) $request->get_param( 'note' ) ) ) );

		if ( '' === $note || strlen( $note ) > 10000 ) {
			return new WP_Error( 'wphave_woocommerce_order_note_invalid', __( 'Enter an internal note of no more than 10,000 characters.', 'wphave' ), array( 'status' => 400 ) );
		}

		try {
			$note_id = $order->add_order_note( $note, false, true );
		} catch ( Throwable $exception ) {
			return self::commerce_mutation_error(
				'wphave_woocommerce_order_note_failed',
				__( 'The internal order note could not be created.', 'wphave' ),
				$exception,
				array( 'order_id' => (int) $order->get_id() )
			);
		}

		if ( ! $note_id ) {
			return new WP_Error( 'wphave_woocommerce_order_note_failed', __( 'The internal order note could not be created.', 'wphave' ), array( 'status' => 500 ) );
		}

		$response = rest_ensure_response( self::prepare_order_detail( $order ) );
		$response->set_status( 201 );

		return $response;
	}

	/**
	 * Return a bounded page of WooCommerce order notes.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */

	public static function get_order_notes( WP_REST_Request $request ) {
		$order = wc_get_order( absint( $request->get_param( 'id' ) ) );

		if ( ! $order instanceof WC_Order ) {
			return new WP_Error( 'wphave_woocommerce_order_not_found', __( 'Order not found.', 'wphave' ), array( 'status' => 404 ) );
		}

		$page = max( 1, absint( $request->get_param( 'page' ) ) );
		$per_page = min( 50, max( 1, absint( $request->get_param( 'per_page' ) ) ) );
		$notes = self::query_order_notes( $order->get_id(), $per_page + 1, ( $page - 1 ) * $per_page );
		$has_more = count( $notes ) > $per_page;

		return rest_ensure_response(
			array(
				'items'   => array_values( array_map( array( __CLASS__, 'prepare_order_note' ), array_slice( $notes, 0, $per_page ) ) ),
				'page'    => $page,
				'hasMore' => $has_more,
			)
		);
	}

	/**
	 * Query recent order notes through WooCommerce's compatibility API.
	 *
	 * @param int $order_id Order ID.
	 * @param int $limit Limit.
	 * @param int $offset Offset.
	 * @return array
	 */

	private static function query_order_notes( $order_id, $limit, $offset = 0 ) {
		return function_exists( 'wc_get_order_notes' )
			? wc_get_order_notes(
				array(
					'order_id' => absint( $order_id ),
					'limit'    => absint( $limit ),
					'offset'   => absint( $offset ),
					'orderby'  => 'date_created',
					'order'    => 'DESC',
				)
			)
			: array();
	}

	/**
	 * Prepare one WooCommerce order note for the Commerce UI.
	 *
	 * @param object $note WooCommerce order note.
	 * @return array
	 */
    
	public static function prepare_order_note( $note ) {
		$date = $note->date_created ?? null;

		return array(
			'id'           => (int) ( $note->id ?? 0 ),
			'content'      => self::plain_text( $note->content ?? '' ),
			'author'       => (string) ( $note->added_by ?? '' ),
			'customerNote' => ! empty( $note->customer_note ),
			'dateCreated'  => self::date_value( $date ),
		);
	}
}
