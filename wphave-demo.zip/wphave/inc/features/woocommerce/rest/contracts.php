<?php

/**
 * Shared permissions, validation and serialization contracts for Commerce REST modules.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Define shared validation, authorization, and response contracts for Commerce REST domains.
 */

trait WPHAVE_WooCommerce_REST_Contracts {
	/**
	 * Require explicit access to the WPHAVE application itself.
	 *
	 * Commerce capabilities never grant access to WPHAVE on their own.
	 *
	 * @return bool
	 */

	public static function can_access_commerce() {
		return current_user_can( 'wphave_access' ) || current_user_can( 'manage_options' );
	}

	/**
	 * Delegate a WooCommerce object permission to its native REST contract.
	 *
	 * @param string $post_type WooCommerce post type.
	 * @param string $context Permission context.
	 * @param int    $object_id Optional object ID.
	 * @return bool
	 */

	private static function has_woocommerce_object_permission( $post_type, $context, $object_id = 0 ) {
		// SECURITY INVARIANT: WPHAVE workspace access and WooCommerce's native
		// object-level permission must both succeed. Neither capability domain may
		// independently widen access to products, orders, coupons or customer data.
		return self::can_access_commerce()
			&& WPHAVE_WooCommerce::is_active()
			&& function_exists( 'wc_rest_check_post_permissions' )
			&& wc_rest_check_post_permissions( $post_type, $context, absint( $object_id ) );
	}

	/**
	 * Require native WooCommerce authority at a final mutation boundary.
	 *
	 * @param string $post_type WooCommerce post type.
	 * @param string $context Permission context.
	 * @param int    $object_id Optional object ID.
	 * @return true|WP_Error
	 */

	private static function require_woocommerce_object_permission( $post_type, $context, $object_id = 0 ) {
		// AUTHORIZATION INVARIANT: Public Commerce callbacks are reusable mutation
		// boundaries and never inherit authority from REST dispatch. Every final sink
		// must repeat WPHAVE access plus WooCommerce's native object-level decision.
		if ( ! self::has_woocommerce_object_permission( $post_type, $context, $object_id ) ) {
			return new WP_Error(
				'wphave_woocommerce_forbidden',
				__( 'You are not allowed to modify this Commerce resource.', 'wphave' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Return a stable public mutation error while retaining diagnostics for hooks.
	 *
	 * Exception messages can contain storage, extension or customer data and must
	 * never become part of the public REST contract.
	 *
	 * @param string    $code Public error code.
	 * @param string    $message Translated public message.
	 * @param Throwable $exception Internal exception.
	 * @param array     $context Non-sensitive diagnostic context.
	 * @return WP_Error
	 */

	private static function commerce_mutation_error( $code, $message, Throwable $exception, $context = array() ) {
		do_action(
			'wphave_woocommerce_mutation_error',
			array(
				'code'      => sanitize_key( $code ),
				'exception' => $exception,
				'context'   => is_array( $context ) ? $context : array(),
			)
		);

		return new WP_Error( $code, $message, array( 'status' => 400 ) );
	}

	/**
	 * Determine whether the current user may read products.
	 *
	 * @return bool
	 */

	public static function can_read_products() {
		return self::has_woocommerce_object_permission( 'product', 'read' )
			|| ( self::can_access_commerce()
				&& WPHAVE_WooCommerce::is_active()
				&& current_user_can( 'edit_products' ) );
	}

	/**
	 * Determine whether the current user may read orders.
	 *
	 * WooCommerce maps shop managers and administrators through this capability.
	 *
	 * @return bool
	 */

	public static function can_read_orders() {
		return self::has_woocommerce_object_permission( 'shop_order', 'read' );
	}

	/**
	 * Determine whether the current user may read one order.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return bool
	 */

	public static function can_read_order( WP_REST_Request $request ) {
		return self::has_woocommerce_object_permission(
			'shop_order',
			'read',
			$request->get_param( 'id' )
		);
	}

	/**
	 * Determine whether the current user may edit one order.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return bool
	 */

	public static function can_edit_order( WP_REST_Request $request ) {
		return self::has_woocommerce_object_permission(
			'shop_order',
			'edit',
			$request->get_param( 'id' )
		);
	}

	/**
	 * Determine whether the current user may read customer identities.
	 *
	 * @return bool
	 */

	public static function can_read_customers() {
		return self::can_read_orders()
			&& function_exists( 'wc_rest_check_user_permissions' )
			&& wc_rest_check_user_permissions( 'read' );
	}

	/**
	 * Determine whether the current user may read one customer identity.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return bool
	 */

	public static function can_read_customer( WP_REST_Request $request ) {
		// AUTHORIZATION INVARIANT: Collection-level order access does not grant
		// access to an arbitrary customer selector. WooCommerce must authorize the
		// exact requested identity as a separate object-level decision.
		return self::can_read_orders()
			&& function_exists( 'wc_rest_check_user_permissions' )
			&& wc_rest_check_user_permissions( 'read', absint( $request->get_param( 'id' ) ) );
	}

	/**
	 * Determine whether the current user may manage WooCommerce coupons.
	 *
	 * @return bool
	 */

	public static function can_read_coupons() {
		return self::has_woocommerce_object_permission( 'shop_coupon', 'read' );
	}

	/**
	 * Determine whether the current user may create coupons.
	 *
	 * @return bool
	 */

	public static function can_create_coupon() {
		return self::has_woocommerce_object_permission( 'shop_coupon', 'create' );
	}

	/**
	 * Determine whether the current user may read one coupon.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return bool
	 */

	public static function can_read_coupon( WP_REST_Request $request ) {
		return self::has_woocommerce_object_permission(
			'shop_coupon',
			'read',
			$request->get_param( 'id' )
		);
	}

	/**
	 * Determine whether the current user may edit one coupon.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return bool
	 */

	public static function can_edit_coupon( WP_REST_Request $request ) {
		return self::has_woocommerce_object_permission(
			'shop_coupon',
			'edit',
			$request->get_param( 'id' )
		);
	}

	/**
	 * Determine whether an attachment can safely be assigned to an object.
	 *
	 * @param int $attachment_id Attachment ID.
	 * @return bool
	 */

	private static function can_use_product_image( $attachment_id ) {
		$attachment_id = absint( $attachment_id );

		return $attachment_id
			&& wp_attachment_is_image( $attachment_id )
			&& current_user_can( 'read_post', $attachment_id );
	}

	/**
	 * Return shared collection route arguments.
	 *
	 * @param string $default_orderby Default sort field.
	 * @return array
	 */

	private static function collection_args( $default_orderby ) {
		return array(
			'page'     => array(
				'default'           => 1,
				'sanitize_callback' => 'absint',
			),
			'per_page' => array(
				'default'           => 20,
				'sanitize_callback' => 'absint',
			),
			'status'   => array(
				'default'           => 'all',
				'sanitize_callback' => 'sanitize_key',
			),
			'search'   => array(
				'default'           => '',
				'sanitize_callback' => 'sanitize_text_field',
			),
			'sku'      => array(
				'default'           => '',
				'sanitize_callback' => 'sanitize_text_field',
			),
			'type'     => array(
				'default'           => '',
				'sanitize_callback' => 'sanitize_key',
			),
			'stock_status' => array(
				'default'           => '',
				'sanitize_callback' => 'sanitize_key',
			),
			'visibility' => array(
				'default'           => '',
				'sanitize_callback' => 'sanitize_key',
			),
			'date_from' => array(
				'default'           => '',
				'sanitize_callback' => 'sanitize_text_field',
			),
			'date_to'   => array(
				'default'           => '',
				'sanitize_callback' => 'sanitize_text_field',
			),
			'featured' => array(
				'default'           => '',
				'sanitize_callback' => 'sanitize_key',
			),
			'virtual' => array(
				'default'           => '',
				'sanitize_callback' => 'sanitize_key',
			),
			'downloadable' => array(
				'default'           => '',
				'sanitize_callback' => 'sanitize_key',
			),
			'orderby'  => array(
				'default'           => $default_orderby,
				'sanitize_callback' => 'sanitize_key',
			),
			'order'    => array(
				'default'           => 'desc',
				'sanitize_callback' => 'sanitize_key',
			),
		);
	}

	/**
	 * Generate mutation argument schemas from the same bounded domain families.
	 *
	 * @param string $domain   Mutation domain.
	 * @param bool   $creating Whether creation-only requirements should be included.
	 * @return array<string,mixed> REST argument schema.
	 */

	private static function mutation_args( $domain, $creating = false ) {
		$revision = array( 'type' => 'string', 'maxLength' => 128, 'sanitize_callback' => 'sanitize_text_field' );
		$contracts = array(
			'bulk' => array(
				'ids' => array( 'type' => 'array', 'required' => true, 'minItems' => 1, 'maxItems' => 100, 'items' => array( 'type' => 'integer', 'minimum' => 1 ) ),
				'action' => array( 'type' => 'string', 'required' => true, 'maxLength' => 50, 'sanitize_callback' => 'sanitize_key' ),
			),
			'order' => array(
				'orderRevision' => array_merge( $revision, array( 'required' => true ) ),
				'status' => array( 'type' => 'string', 'required' => true, 'maxLength' => 30, 'sanitize_callback' => 'sanitize_key' ),
				'customerId' => array( 'type' => 'integer', 'minimum' => 0 ),
				'customerNote' => array( 'type' => 'string', 'maxLength' => 10000 ),
				'billingAddress' => array( 'type' => 'object' ),
				'shippingAddress' => array( 'type' => 'object' ),
			),
			'note' => array( 'note' => array( 'type' => 'string', 'required' => true, 'minLength' => 1, 'maxLength' => 10000 ) ),
			'variation' => array(
				'commerceRevision' => array_merge( $revision, array( 'required' => true ) ),
				'attributes' => array( 'type' => 'object' ),
				'downloads' => array( 'type' => 'array', 'maxItems' => 100 ),
			),
			'coupon' => array(
				'couponRevision' => array_merge( $revision, array( 'required' => ! $creating ) ),
				'code' => array( 'type' => 'string', 'required' => (bool) $creating, 'maxLength' => 200 ),
				'discountType' => array( 'type' => 'string', 'required' => (bool) $creating, 'enum' => array( 'percent', 'fixed_cart', 'fixed_product' ) ),
				'emailRestrictions' => array( 'type' => 'array', 'maxItems' => 100, 'items' => array( 'type' => 'string', 'maxLength' => 320 ) ),
			),
			'duplicate' => array( 'name' => array( 'type' => 'string', 'maxLength' => 200 ) ),
		);

		return $contracts[ $domain ] ?? array();
	}

	/**
	 * Return one allow-listed value.
	 *
	 * @param mixed $value Requested value.
	 * @param array $allowed Allowed values.
	 * @param string $fallback Fallback.
	 * @return string
	 */

	private static function allowed_value( $value, $allowed, $fallback ) {
		$value = sanitize_key( (string) $value );

		return in_array( $value, $allowed, true ) ? $value : $fallback;
	}

	/**
	 * Convert trusted WooCommerce display markup to a transport-safe label.
	 *
	 * @param mixed $value Value.
	 * @return string
	 */

	private static function plain_text( $value ) {
		return html_entity_decode( wp_strip_all_tags( (string) $value ), ENT_QUOTES, get_bloginfo( 'charset' ) ?: 'UTF-8' );
	}

	/**
	 * Preserve WooCommerce-owned display line breaks without transporting HTML.
	 *
	 * @param mixed $value Formatted display value.
	 * @return array
	 */

	private static function formatted_lines( $value ) {
		$value = preg_replace( '/<br\s*\/?\s*>/i', "\n", (string) $value );
		$lines = preg_split( '/\R+/', self::plain_text( $value ) );

		return array_values(
			array_filter(
				array_map( 'trim', is_array( $lines ) ? $lines : array() ),
				static function ( $line ) {
					return '' !== $line;
				}
			)
		);
	}

	/**
	 * Serialize WooCommerce dates consistently for the client contract.
	 *
	 * @param mixed $value Date value.
	 * @return string
	 */

	private static function date_value( $value ) {
		return $value instanceof WC_DateTime ? $value->date( DATE_ATOM ) : '';
	}

	/**
	 * Validate one optional ISO calendar date without applying timezone logic.
	 *
	 * @param mixed $value Date value.
	 * @return string|WP_Error
	 */

	private static function validated_date( $value ) {
		$value = sanitize_text_field( (string) $value );

		if ( '' === $value ) {
			return '';
		}

		if ( ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $value, $parts )
			|| ! checkdate( (int) $parts[2], (int) $parts[3], (int) $parts[1] ) ) {
			return new WP_Error( 'wphave_woocommerce_date_invalid' );
		}

		return $value;
	}

	/**
	 * Convert one optional tri-state transport value to a query boolean.
	 *
	 * @param mixed $value Filter value.
	 * @return bool|string|WP_Error
	 */

	private static function optional_boolean( $value ) {
		$value = sanitize_key( (string) $value );

		if ( '' === $value ) {
			return '';
		}

		if ( ! in_array( $value, array( 'yes', 'no' ), true ) ) {
			return new WP_Error( 'wphave_woocommerce_boolean_invalid' );
		}

		return 'yes' === $value;
	}

	/**
	 * Return a stable unavailable response when WooCommerce is inactive.
	 *
	 * @return WP_Error
	 */
    
	private static function unavailable_error() {
		return new WP_Error(
			'wphave_woocommerce_unavailable',
			__( 'WooCommerce is not available.', 'wphave' ),
			array( 'status' => 503 )
		);
	}
}
