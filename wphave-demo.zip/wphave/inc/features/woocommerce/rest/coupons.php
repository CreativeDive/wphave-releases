<?php

/**
 * WooCommerce Core coupon collection and mutation contracts.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Expose WooCommerce coupon projections and mutations through WPHAVE REST contracts.
 */

trait WPHAVE_WooCommerce_REST_Coupons {
	/**
	 * Return a paginated collection of canonical WooCommerce coupons.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */

	public static function get_coupons( WP_REST_Request $request ) {
		// QUERY INVARIANT: Coupon searches and sorted pagination must consume a
		// bounded selector before WP_Query or extension sanitizers run.
		$page = self::collection_page( $request );
		$search = self::collection_search( $request );
		if ( is_wp_error( $page ) ) {
			return $page;
		}
		if ( is_wp_error( $search ) ) {
			return $search;
		}

		$per_page  = min( 100, max( 1, absint( $request->get_param( 'per_page' ) ) ) );
		$order     = 'asc' === strtolower( (string) $request->get_param( 'order' ) ) ? 'ASC' : 'DESC';
		$orderby   = self::allowed_value( $request->get_param( 'orderby' ), array( 'date', 'title', 'modified' ), 'date' );
		$post_query = new WP_Query(
			array(
				'post_type'      => 'shop_coupon',
				'post_status'    => array( 'publish', 'draft', 'pending' ),
				'posts_per_page' => $per_page,
				'paged'          => $page,
				'orderby'        => $orderby,
				'order'          => $order,
				's'              => $search,
				'fields'         => 'ids',
			)
		);

		return rest_ensure_response(
			array(
				'items' => array_values(
					array_filter(
						array_map(
							static function ( $coupon_id ) {
								return self::prepare_coupon( new WC_Coupon( $coupon_id ), true );
							},
							$post_query->posts
						)
					)
				),
				'total' => (int) $post_query->found_posts,
				'page'  => $page,
				'pages' => max( 1, (int) $post_query->max_num_pages ),
			)
		);
	}

	/**
	 * Return one canonical coupon.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */

	public static function get_coupon( WP_REST_Request $request ) {
		$coupon = self::resolve_coupon( $request->get_param( 'id' ) );

		return is_wp_error( $coupon ) ? $coupon : rest_ensure_response( self::prepare_coupon( $coupon, true ) );
	}

	/**
	 * Create a coupon through WooCommerce CRUD.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */

	public static function create_coupon( WP_REST_Request $request ) {
		$permission = self::require_woocommerce_object_permission( 'shop_coupon', 'create' );

		if ( is_wp_error( $permission ) ) {
			return $permission;
		}

		$coupon = new WC_Coupon();
		$result = self::apply_coupon_payload( $coupon, $request, true );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		try {
			$coupon->save();
		} catch ( Throwable $exception ) {
			return self::commerce_mutation_error(
				'wphave_woocommerce_coupon_save_failed',
				__( 'The coupon could not be saved.', 'wphave' ),
				$exception
			);
		}

		return rest_ensure_response( self::prepare_coupon( $coupon, true ) );
	}

	/**
	 * Update a coupon through WooCommerce CRUD with optimistic concurrency.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */

	public static function update_coupon( WP_REST_Request $request ) {
		$coupon = self::resolve_coupon( $request->get_param( 'id' ) );

		if ( is_wp_error( $coupon ) ) {
			return $coupon;
		}

		$permission = self::require_woocommerce_object_permission( 'shop_coupon', 'edit', $coupon->get_id() );

		if ( is_wp_error( $permission ) ) {
			return $permission;
		}

		$revision = sanitize_text_field( (string) $request->get_param( 'couponRevision' ) );
		// SECURITY INVARIANT: Coupon mutation applies only to the complete commerce
		// revision observed by the editor, preventing a stale form from overwriting
		// concurrent pricing or restriction changes.
		if ( '' === $revision || ! hash_equals( self::coupon_revision( $coupon ), $revision ) ) {
			return new WP_Error( 'wphave_woocommerce_coupon_conflict', __( 'This coupon changed after it was opened. Reload it before saving.', 'wphave' ), array( 'status' => 409 ) );
		}

		$result = self::apply_coupon_payload( $coupon, $request, false );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		try {
			$coupon->save();
		} catch ( Throwable $exception ) {
			return self::commerce_mutation_error(
				'wphave_woocommerce_coupon_save_failed',
				__( 'The coupon could not be saved.', 'wphave' ),
				$exception,
				array( 'coupon_id' => (int) $coupon->get_id() )
			);
		}

		return rest_ensure_response( self::prepare_coupon( $coupon, true ) );
	}

	/**
	 * Resolve a valid shop coupon.
	 *
	 * @param mixed $coupon_id Coupon ID.
	 * @return WC_Coupon|WP_Error
	 */

	private static function resolve_coupon( $coupon_id ) {
		$coupon = new WC_Coupon( absint( $coupon_id ) );

		if ( ! $coupon->get_id() || 'shop_coupon' !== get_post_type( $coupon->get_id() ) ) {
			return new WP_Error( 'wphave_woocommerce_coupon_not_found', __( 'Coupon not found.', 'wphave' ), array( 'status' => 404 ) );
		}

		return $coupon;
	}

	/**
	 * Apply the intentionally supported WooCommerce Core coupon fields.
	 *
	 * @param WC_Coupon      $coupon Coupon.
	 * @param WP_REST_Request $request Request.
	 * @param bool           $creating Whether a new coupon is created.
	 * @return true|WP_Error
	 */

	private static function apply_coupon_payload( WC_Coupon $coupon, WP_REST_Request $request, $creating ) {
		$allowed_fields = array_fill_keys(
			array(
				'code',
				'description',
				'discountType',
				'amount',
				'dateExpires',
				'freeShipping',
				'individualUse',
				'minimumAmount',
				'maximumAmount',
				'excludeSaleItems',
				'usageLimit',
				'usageLimitPerUser',
				'limitUsageToXItems',
				'emailRestrictions',
			),
			true
		);
		$data = array_intersect_key( $request->get_params(), $allowed_fields );

		if ( $creating || array_key_exists( 'code', $data ) ) {
			$code = wc_format_coupon_code( (string) ( $data['code'] ?? '' ) );

			if ( '' === $code ) {
				return new WP_Error( 'wphave_woocommerce_coupon_code_required', __( 'Enter a coupon code.', 'wphave' ), array( 'status' => 400 ) );
			}

			if ( wc_get_coupon_id_by_code( $code, $coupon->get_id() ) ) {
				return new WP_Error( 'wphave_woocommerce_coupon_code_exists', __( 'A coupon with this code already exists.', 'wphave' ), array( 'status' => 409 ) );
			}

			$coupon->set_code( $code );
		}

		if ( $creating || array_key_exists( 'discountType', $data ) ) {
			$discount_type = sanitize_key( (string) ( $data['discountType'] ?? '' ) );

			if ( ! in_array( $discount_type, array( 'percent', 'fixed_cart', 'fixed_product' ), true ) ) {
				return new WP_Error( 'wphave_woocommerce_coupon_type_invalid', __( 'Select a supported WooCommerce Core discount type.', 'wphave' ), array( 'status' => 400 ) );
			}

			$coupon->set_discount_type( $discount_type );
		}

		if ( array_key_exists( 'dateExpires', $data ) ) {
			$date_expires = sanitize_text_field( (string) $data['dateExpires'] );

			if ( '' !== $date_expires
				&& ( ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $date_expires, $date_parts )
					|| ! checkdate( (int) $date_parts[2], (int) $date_parts[3], (int) $date_parts[1] ) ) ) {
				return new WP_Error( 'wphave_woocommerce_coupon_date_invalid', __( 'Enter a valid expiry date.', 'wphave' ), array( 'status' => 400 ) );
			}

			$coupon->set_date_expires( '' === $date_expires ? null : $date_expires );
		}

		$setters = array(
			'description'       => static function ( $value ) use ( $coupon ) {
				$coupon->set_description( sanitize_textarea_field( (string) $value ) );
			},
			'amount'            => static function ( $value ) use ( $coupon ) {
				$coupon->set_amount( wc_format_decimal( $value ) );
			},
			'freeShipping'      => static function ( $value ) use ( $coupon ) {
				$coupon->set_free_shipping( rest_sanitize_boolean( $value ) );
			},
			'individualUse'     => static function ( $value ) use ( $coupon ) {
				$coupon->set_individual_use( rest_sanitize_boolean( $value ) );
			},
			'minimumAmount'     => static function ( $value ) use ( $coupon ) {
				$coupon->set_minimum_amount( wc_format_decimal( $value ) );
			},
			'maximumAmount'     => static function ( $value ) use ( $coupon ) {
				$coupon->set_maximum_amount( wc_format_decimal( $value ) );
			},
			'excludeSaleItems'  => static function ( $value ) use ( $coupon ) {
				$coupon->set_exclude_sale_items( rest_sanitize_boolean( $value ) );
			},
			'usageLimit'        => static function ( $value ) use ( $coupon ) {
				$coupon->set_usage_limit( max( 0, absint( $value ) ) );
			},
			'usageLimitPerUser' => static function ( $value ) use ( $coupon ) {
				$coupon->set_usage_limit_per_user( max( 0, absint( $value ) ) );
			},
			'limitUsageToXItems'=> static function ( $value ) use ( $coupon ) {
				$coupon->set_limit_usage_to_x_items( max( 0, absint( $value ) ) );
			},
		);

		foreach ( $setters as $field => $setter ) {
			if ( array_key_exists( $field, $data ) ) {
				$setter( $data[ $field ] );
			}
		}

		if ( array_key_exists( 'emailRestrictions', $data ) ) {
			$email_restrictions = array_slice( (array) $data['emailRestrictions'], 0, 100 );
			$coupon->set_email_restrictions(
				array_values(
					array_filter(
						array_map(
							static function ( $email_pattern ) {
								$email_pattern = substr( sanitize_text_field( (string) $email_pattern ), 0, 254 );

								return false !== strpos( $email_pattern, '@' ) ? $email_pattern : '';
							},
							$email_restrictions
						)
					)
				)
			);
		}

		if ( $creating ) {
			$coupon->set_status( 'publish' );
		}

		return true;
	}

	/**
	 * Serialize one coupon for WPHAVE without parallel business logic.
	 *
	 * @param WC_Coupon $coupon Coupon.
	 * @param bool      $detail Include editable detail fields.
	 * @return array
	 */

	private static function prepare_coupon( WC_Coupon $coupon, $detail = false ) {
		$date_expires = $coupon->get_date_expires();
		$is_expired   = $date_expires instanceof WC_DateTime && $date_expires->getTimestamp() < current_time( 'timestamp', true );
		$usage_limit  = (int) $coupon->get_usage_limit();
		$usage_count  = (int) $coupon->get_usage_count();
		$formatted_amount = 'percent' === $coupon->get_discount_type()
			? wc_format_localized_decimal( $coupon->get_amount() ) . '%'
			: self::plain_text( wc_price( $coupon->get_amount() ) );
		$data = array(
			'id'              => $coupon->get_id(),
			'code'            => $coupon->get_code(),
			'description'     => $coupon->get_description(),
			'discountType'    => $coupon->get_discount_type(),
			'discountLabel'   => wc_get_coupon_type( $coupon->get_discount_type() ),
			'amount'          => (string) $coupon->get_amount(),
			'formattedAmount' => $formatted_amount,
			'usageCount'      => $usage_count,
			'usageLimit'      => $usage_limit,
			'usageLabel'      => $usage_limit > 0 ? sprintf( '%1$d / %2$d', $usage_count, $usage_limit ) : (string) $usage_count,
			'dateExpires'     => self::date_value( $date_expires ),
			'status'          => $is_expired ? 'expired' : 'active',
			'statusLabel'     => $is_expired ? __( 'Expired', 'wphave' ) : __( 'Active', 'wphave' ),
			'dateModified'    => self::date_value( $coupon->get_date_modified() ),
		);

		if ( $detail ) {
			$data += array(
				'freeShipping'          => $coupon->get_free_shipping(),
				'individualUse'         => $coupon->get_individual_use(),
				'minimumAmount'         => (string) $coupon->get_minimum_amount(),
				'maximumAmount'         => (string) $coupon->get_maximum_amount(),
				'excludeSaleItems'      => $coupon->get_exclude_sale_items(),
				'usageLimitPerUser'     => (int) $coupon->get_usage_limit_per_user(),
				'limitUsageToXItems'    => (int) $coupon->get_limit_usage_to_x_items(),
				'emailRestrictions'     => array_values( $coupon->get_email_restrictions() ),
				'couponRevision'        => self::coupon_revision( $coupon ),
			);
		}

		return $data;
	}

	/**
	 * Return an opaque revision based on WooCommerce-owned values.
	 *
	 * @param WC_Coupon $coupon Coupon.
	 * @return string
	 */
    
	private static function coupon_revision( WC_Coupon $coupon ) {
		return hash(
			'sha256',
			wp_json_encode(
				array(
					'id'                     => $coupon->get_id(),
					'code'                   => $coupon->get_code(),
					'description'            => $coupon->get_description(),
					'discount_type'          => $coupon->get_discount_type(),
					'amount'                 => (string) $coupon->get_amount(),
					'date_expires'           => self::date_value( $coupon->get_date_expires() ),
					'free_shipping'          => $coupon->get_free_shipping(),
					'individual_use'         => $coupon->get_individual_use(),
					'minimum_amount'         => (string) $coupon->get_minimum_amount(),
					'maximum_amount'         => (string) $coupon->get_maximum_amount(),
					'exclude_sale_items'     => $coupon->get_exclude_sale_items(),
					'usage_limit'            => (int) $coupon->get_usage_limit(),
					'usage_limit_per_user'   => (int) $coupon->get_usage_limit_per_user(),
					'limit_usage_to_x_items' => (int) $coupon->get_limit_usage_to_x_items(),
					'email_restrictions'     => array_values( $coupon->get_email_restrictions() ),
				)
			)
		);
	}
}
