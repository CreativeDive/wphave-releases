<?php

/**
 * HPOS-compatible WooCommerce order collection, detail and mutation workflows.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Expose HPOS-compatible WooCommerce order projections and mutations.
 */

trait WPHAVE_WooCommerce_REST_Orders {

	/**
	 * Return a paginated order projection from WC_Order_Query.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */

	public static function get_orders( WP_REST_Request $request ) {
		if ( ! function_exists( 'wc_get_orders' ) ) {
			return self::unavailable_error();
		}

		// QUERY INVARIANT: HPOS and legacy searches share the same bounded
		// admission before wc_order_search or WC_Order_Query runs.
		$page = self::collection_page( $request );
		$search = self::collection_search( $request );
		if ( is_wp_error( $page ) ) {
			return $page;
		}
		if ( is_wp_error( $search ) ) {
			return $search;
		}

		$per_page = min( 100, max( 1, (int) $request->get_param( 'per_page' ) ) );
		$order     = strtolower( (string) $request->get_param( 'order' ) ) === 'asc' ? 'ASC' : 'DESC';
		$orderby   = self::allowed_value(
			$request->get_param( 'orderby' ),
			array( 'date', 'id', 'modified' ),
			'date'
		);
		$status    = sanitize_key( (string) $request->get_param( 'status' ) );
		$date_from = self::validated_date( $request->get_param( 'date_from' ) );
		$date_to   = self::validated_date( $request->get_param( 'date_to' ) );

		if ( is_wp_error( $date_from ) || is_wp_error( $date_to ) ) {
			return new WP_Error( 'wphave_woocommerce_order_date_invalid', __( 'Invalid order date range.', 'wphave' ), array( 'status' => 400 ) );
		}

		if ( $date_from && $date_to && $date_from > $date_to ) {
			return new WP_Error( 'wphave_woocommerce_order_date_invalid', __( 'The start date must not be after the end date.', 'wphave' ), array( 'status' => 400 ) );
		}

		$args = array(
			'limit'    => $per_page,
			'page'     => $page,
			'paginate' => true,
			'type'     => 'shop_order',
			'orderby'  => $orderby,
			'order'    => $order,
			'return'   => 'objects',
		);

		if ( $status && 'all' !== $status ) {
			$status = preg_replace( '/^wc-/', '', $status );

			if ( ! array_key_exists( $status, self::core_order_statuses() ) ) {
				return new WP_Error( 'wphave_woocommerce_order_status_invalid', __( 'Invalid order status.', 'wphave' ), array( 'status' => 400 ) );
			}

			$args['status'] = 'wc-' . $status;
		}

		if ( '' !== $search ) {
			$is_hpos = class_exists( '\\Automattic\\WooCommerce\\Utilities\\OrderUtil' )
				&& \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();

			// COMMERCE QUERY INVARIANT: Order search must retain the same semantic
			// contract across WooCommerce datastores. Legacy CPT queries do not
			// interpret the HPOS `s` argument as WooCommerce customer/order search,
			// so resolve through WooCommerce's public search API before pagination.
			if ( ! $is_hpos && function_exists( 'wc_order_search' ) ) {
				$order_ids = array_values( array_filter( array_map( 'absint', wc_order_search( $search ) ) ) );
				$args['include'] = $order_ids ?: array( 0 );
			} else {
				$args['s'] = $search;
			}
		}

		if ( $date_from || $date_to ) {
			$args['date_created'] = $date_from && $date_to
				? $date_from . '...' . $date_to
				: ( $date_from ? '>=' . $date_from : '<=' . $date_to );
		}

		$result = wc_get_orders( $args );
		$items  = is_object( $result ) && isset( $result->orders ) ? $result->orders : array();
		$total  = is_object( $result ) && isset( $result->total ) ? (int) $result->total : count( $items );

		return rest_ensure_response(
			array(
				'items'     => array_values( array_filter( array_map( array( __CLASS__, 'prepare_order' ), $items ) ) ),
				'total'     => $total,
				'page'      => $page,
				'pages'     => is_object( $result ) && isset( $result->max_num_pages ) ? (int) $result->max_num_pages : 1,
				'statuses'  => self::core_order_statuses(),
				'nativeUrl' => admin_url( 'admin.php?page=wc-orders' ),
			)
		);
	}

	/**
	 * Return an HPOS-safe read-only order detail projection.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */

	public static function get_order( WP_REST_Request $request ) {
		$order = wc_get_order( absint( $request->get_param( 'id' ) ) );

		if ( ! $order instanceof WC_Order ) {
			return new WP_Error( 'wphave_woocommerce_order_not_found', __( 'Order not found.', 'wphave' ), array( 'status' => 404 ) );
		}

		return rest_ensure_response( self::prepare_order_detail( $order ) );
	}

	/**
	 * Update the explicit WooCommerce Core order status contract.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */

	public static function update_order( WP_REST_Request $request ) {
		$order = wc_get_order( absint( $request->get_param( 'id' ) ) );

		if ( ! $order instanceof WC_Order ) {
			return new WP_Error( 'wphave_woocommerce_order_not_found', __( 'Order not found.', 'wphave' ), array( 'status' => 404 ) );
		}

		$permission = self::require_woocommerce_object_permission( 'shop_order', 'edit', $order->get_id() );

		if ( is_wp_error( $permission ) ) {
			return $permission;
		}

		$expected_revision = sanitize_text_field( (string) $request->get_param( 'orderRevision' ) );

		// SECURITY INVARIANT: Order status, customer and note changes apply only to
		// the exact commerce revision loaded by the operator; stale fulfillment state
		// is rejected before any field is mutated.
		if ( ! $expected_revision || ! hash_equals( self::order_revision( $order ), $expected_revision ) ) {
			return new WP_Error( 'wphave_woocommerce_order_conflict', __( 'This order changed after it was opened. Reload it before saving.', 'wphave' ), array( 'status' => 409 ) );
		}

		$status = sanitize_key( (string) $request->get_param( 'status' ) );
		$has_customer_note = null !== $request->get_param( 'customerNote' );
		$customer_note = sanitize_textarea_field( wp_unslash( (string) $request->get_param( 'customerNote' ) ) );
		$has_customer_id = null !== $request->get_param( 'customerId' );
		$customer_id = absint( $request->get_param( 'customerId' ) );

		if ( ! array_key_exists( $status, self::core_order_statuses() ) ) {
			return new WP_Error( 'wphave_woocommerce_order_status_invalid', __( 'Invalid order status.', 'wphave' ), array( 'status' => 400 ) );
		}

		if ( $has_customer_note && strlen( $customer_note ) > 10000 ) {
			return new WP_Error( 'wphave_woocommerce_order_customer_note_invalid', __( 'Enter a customer note of no more than 10,000 characters.', 'wphave' ), array( 'status' => 400 ) );
		}

		if ( $has_customer_id && $customer_id > 0 && ! self::is_assignable_customer( $customer_id ) ) {
			return new WP_Error( 'wphave_woocommerce_order_customer_invalid', __( 'The selected customer is not available on this site.', 'wphave' ), array( 'status' => 400 ) );
		}

		try {
			$address_changes = array();

			foreach ( array( 'billingAddress' => 'billing', 'shippingAddress' => 'shipping' ) as $key => $type ) {
				if ( null !== $request->get_param( $key ) ) {
					$address_changes[ $type ] = self::validated_order_address( $request->get_param( $key ), $type );
				}
			}

			$order->set_status( $status );

			if ( $has_customer_note ) {
				$order->set_customer_note( $customer_note );
			}

			if ( $has_customer_id ) {
				$order->set_customer_id( $customer_id );
			}

			foreach ( $address_changes as $type => $address ) {
				$order->set_address( $address, $type );
			}
			$order->save();
		} catch ( Throwable $exception ) {
			return self::commerce_mutation_error(
				'wphave_woocommerce_order_invalid',
				__( 'The order could not be saved.', 'wphave' ),
				$exception,
				array( 'order_id' => (int) $order->get_id() )
			);
		}

		return rest_ensure_response( self::prepare_order_detail( $order ) );
	}

	/**
	 * Prepare an HPOS-safe order view model.
	 *
	 * @param mixed $order Order object.
	 * @return array|null
	 */

	public static function prepare_order( $order ) {
		if ( ! is_object( $order ) || ! is_a( $order, 'WC_Order' ) ) {
			return null;
		}

		return array(
			'id'          => (int) $order->get_id(),
			'number'      => (string) $order->get_order_number(),
			'dateCreated' => self::date_value( $order->get_date_created() ),
			'dateModified' => self::date_value( $order->get_date_modified() ),
			'customer'    => (string) $order->get_formatted_billing_full_name(),
			'status'      => (string) $order->get_status(),
			'statusLabel' => function_exists( 'wc_get_order_status_name' )
				? (string) wc_get_order_status_name( $order->get_status() )
				: (string) $order->get_status(),
			'total'       => (string) $order->get_total(),
			'formattedTotal' => self::plain_text(
				function_exists( 'wc_price' )
					? wc_price( $order->get_total(), array( 'currency' => $order->get_currency() ) )
					: $order->get_total()
			),
			'currency'    => (string) $order->get_currency(),
			'editUrl'     => method_exists( $order, 'get_edit_order_url' )
				? (string) $order->get_edit_order_url()
				: '',
		);
	}

	/**
	 * Prepare order details without deriving WooCommerce business values.
	 *
	 * @param WC_Order $order Order.
	 * @return array
	 */

	private static function prepare_order_detail( WC_Order $order ) {
		$summary = self::prepare_order( $order );
		$items = array();
		$notes = self::query_order_notes( $order->get_id(), 21 );
		$has_more_notes = count( $notes ) > 20;
		$notes = array_slice( $notes, 0, 20 );
		$refunds = array();
		$totals = array();
		$downloads = array();
		$shipping_lines = array();
		$fee_lines = array();
		$coupon_lines = array();
		$country_contract = self::order_country_contract();
		$customer_id = (int) $order->get_customer_id();
		$customer_identity = $customer_id > 0
			? self::prepare_customer_identity( get_user_by( 'id', $customer_id ) )
			: null;

		foreach ( $order->get_items( 'line_item' ) as $item ) {
			if ( ! $item instanceof WC_Order_Item_Product ) {
				continue;
			}

			$product_id = (int) $item->get_product_id();
			$product = $product_id > 0 ? wc_get_product( $product_id ) : false;
			$formatted_meta = array();

			foreach ( $item->get_formatted_meta_data() as $meta ) {
				$formatted_meta[] = array(
					'key'   => self::plain_text( $meta->display_key ?? '' ),
					'value' => self::plain_text( $meta->display_value ?? '' ),
				);
			}

			$items[] = array(
				'id'             => (int) $item->get_id(),
				'name'           => (string) $item->get_name(),
				'productId'      => $product_id,
				'productEditable' => $product instanceof WC_Product
					&& current_user_can( 'edit_post', $product_id ),
				'variationId'    => (int) $item->get_variation_id(),
				'quantity'       => (float) $item->get_quantity(),
				'sku'            => $product instanceof WC_Product ? (string) $product->get_sku() : '',
				'variation'      => $product instanceof WC_Product_Variation
					? self::plain_text( wc_get_formatted_variation( $product, true, false, true ) )
					: '',
				'meta'           => $formatted_meta,
				'formattedSubtotal' => self::plain_text( $order->get_formatted_line_subtotal( $item ) ),
			);
		}

		foreach ( $order->get_items( 'shipping' ) as $item ) {
			if ( $item instanceof WC_Order_Item_Shipping ) {
				$shipping_lines[] = self::prepare_order_amount_line( $order, $item, $item->get_method_title() );
			}
		}

		foreach ( $order->get_items( 'fee' ) as $item ) {
			if ( $item instanceof WC_Order_Item_Fee ) {
				$fee_lines[] = self::prepare_order_amount_line( $order, $item, $item->get_name() );
			}
		}

		foreach ( $order->get_items( 'coupon' ) as $item ) {
			if ( ! $item instanceof WC_Order_Item_Coupon ) {
				continue;
			}

			$coupon_lines[] = array(
				'id'                => (int) $item->get_id(),
				'code'              => (string) $item->get_code(),
				'formattedDiscount' => self::format_order_amount( $order, $item->get_discount() ),
				'formattedTax'      => self::format_order_amount( $order, $item->get_discount_tax() ),
			);
		}

		foreach ( $order->get_refunds() as $refund ) {
			if ( ! $refund instanceof WC_Order_Refund ) {
				continue;
			}

			$date = $refund->get_date_created();
			$refunds[] = array(
				'id'              => (int) $refund->get_id(),
				'dateCreated'     => self::date_value( $date ),
				'reason'          => (string) $refund->get_reason(),
				'amount'          => (string) $refund->get_amount(),
				'formattedAmount' => self::plain_text( $refund->get_formatted_refund_amount() ),
				'paymentRefunded' => (bool) $refund->get_refunded_payment(),
			);
		}

		foreach ( $order->get_order_item_totals() as $key => $total ) {
			$totals[] = array(
				'key'   => sanitize_key( (string) $key ),
				'label' => self::plain_text( $total['label'] ?? '' ),
				'value' => self::plain_text( $total['value'] ?? '' ),
			);
		}

		foreach ( $order->get_downloadable_items() as $download ) {
			$remaining = $download['downloads_remaining'] ?? '';
			$expires = $download['access_expires'] ?? '';

			$downloads[] = array(
				'id'                 => sanitize_text_field( (string) ( $download['download_id'] ?? '' ) ),
				'productId'          => absint( $download['product_id'] ?? 0 ),
				'productName'        => sanitize_text_field( (string) ( $download['product_name'] ?? '' ) ),
				'name'               => sanitize_text_field( (string) ( $download['download_name'] ?? '' ) ),
				'downloadsRemaining' => '' === $remaining ? null : (int) $remaining,
				'accessExpires'      => sanitize_text_field( (string) $expires ),
			);
		}

		return array_merge(
			$summary,
			array(
				'orderRevision'  => self::order_revision( $order ),
				'customerId'     => $customer_id,
				'customerIdentity' => $customer_identity,
				'statusOptions'  => array_map(
					static function ( $value, $label ) {
						return array( 'value' => $value, 'label' => $label );
					},
					array_keys( self::core_order_statuses() ),
					array_values( self::core_order_statuses() )
				),
				'email'           => (string) $order->get_billing_email(),
				'phone'           => (string) $order->get_billing_phone(),
				'billingAddress'  => self::prepare_order_address( $order, 'billing' ),
				'shippingAddress' => self::prepare_order_address( $order, 'shipping' ),
				'countryOptions'  => $country_contract['options'],
				'countryStates'   => $country_contract['states'],
				'billingAddressLines'  => self::formatted_lines( $order->get_formatted_billing_address() ),
				'shippingAddressLines' => self::formatted_lines( $order->get_formatted_shipping_address() ),
				'paymentMethod'   => (string) $order->get_payment_method_title(),
				'transactionId'   => (string) $order->get_transaction_id(),
				'createdVia'      => (string) $order->get_created_via(),
				'shippingMethod'  => (string) $order->get_shipping_method(),
				'datePaid'        => self::date_value( $order->get_date_paid() ),
				'dateCompleted'   => self::date_value( $order->get_date_completed() ),
				'customerNote'    => (string) $order->get_customer_note(),
				'orderNotes'      => array_values(
					array_map( array( __CLASS__, 'prepare_order_note' ), $notes )
				),
				'hasMoreOrderNotes' => $has_more_notes,
				'items'           => $items,
				'shippingLines'   => $shipping_lines,
				'feeLines'        => $fee_lines,
				'couponLines'     => $coupon_lines,
				'refunds'         => $refunds,
				'totals'          => $totals,
				'downloads'       => $downloads,
				'formattedRefundedTotal' => self::plain_text(
					wc_price( $order->get_total_refunded(), array( 'currency' => $order->get_currency() ) )
				),
			)
		);
	}

	/**
	 * Prepare a fee or shipping line without deriving order totals.
	 *
	 * @param WC_Order      $order Order.
	 * @param WC_Order_Item $item Order item.
	 * @param string        $label Line label.
	 * @return array
	 */

	private static function prepare_order_amount_line( WC_Order $order, WC_Order_Item $item, $label ) {
		return array(
			'id'              => (int) $item->get_id(),
			'label'           => (string) $label,
			'formattedAmount' => self::format_order_amount( $order, $item->get_total() ),
			'formattedTax'    => self::format_order_amount( $order, $item->get_total_tax() ),
		);
	}

	/**
	 * Format one stored order amount through WooCommerce.
	 *
	 * @param WC_Order $order Order.
	 * @param mixed    $amount Stored amount.
	 * @return string
	 */

	private static function format_order_amount( WC_Order $order, $amount ) {
		return self::plain_text( wc_price( $amount, array( 'currency' => $order->get_currency() ) ) );
	}

	/**
	 * Return only statuses owned by WooCommerce Core.
	 *
	 * @return array
	 */

	private static function core_order_statuses() {
		$core = array( 'pending', 'processing', 'on-hold', 'completed', 'cancelled', 'refunded', 'failed' );
		$registered = function_exists( 'wc_get_order_statuses' ) ? wc_get_order_statuses() : array();
		$statuses = array();

		foreach ( $core as $status ) {
			$key = 'wc-' . $status;
			if ( isset( $registered[ $key ] ) ) {
				$statuses[ $status ] = (string) $registered[ $key ];
			}
		}

		return $statuses;
	}

	/**
	 * Return a revision token scoped to the editable order contract.
	 *
	 * @param WC_Order $order Order.
	 * @return string
	 */
    
	private static function order_revision( WC_Order $order ) {
		$modified = $order->get_date_modified();

		return hash( 'sha256', wp_json_encode( array( $order->get_id(), $order->get_status(), $order->get_customer_id(), $order->get_customer_note( 'edit' ), self::prepare_order_address( $order, 'billing' ), self::prepare_order_address( $order, 'shipping' ), $modified ? $modified->getTimestamp() : 0 ) ) );
	}
}
