<?php

/**
 * Bounded operational tasks derived from canonical WooCommerce entities.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Build actionable Commerce notices for the shared WPHAVE banner workflow.
 */

trait WPHAVE_WooCommerce_REST_Inbox {

	/**
	 * Return actionable Commerce work without persisting parallel task state.
	 *
	 * @return WP_REST_Response|WP_Error
	 */

	public static function get_commerce_inbox() {
		if ( ! function_exists( 'wc_get_orders' ) || ! function_exists( 'wc_get_products' ) ) {
			return self::unavailable_error();
		}

		$items = array_merge(
			self::inbox_order_items(),
			self::inbox_product_items(),
			self::inbox_coupon_items()
		);

		usort(
			$items,
			static function ( $left, $right ) {
				$priority = array( 'critical' => 0, 'high' => 1, 'medium' => 2, 'low' => 3 );
				$comparison = ( $priority[ $left['priority'] ] ?? 4 ) <=> ( $priority[ $right['priority'] ] ?? 4 );

				return 0 !== $comparison ? $comparison : strcmp( $right['date'], $left['date'] );
			}
		);

		return rest_ensure_response(
			array(
				'items' => array_slice( $items, 0, 50 ),
				'total' => count( $items ),
			)
		);
	}

	/**
	 * Project orders that need an operational decision.
	 *
	 * @return array
	 */

	private static function inbox_order_items() {
		$orders = wc_get_orders(
			array(
				'limit'   => 20,
				'type'    => 'shop_order',
				'orderby' => 'date',
				'order'   => 'DESC',
				'status'  => array( 'wc-failed', 'wc-pending', 'wc-on-hold' ),
				'return'  => 'objects',
			)
		);

		return array_values(
			array_filter(
				array_map(
					static function ( $order ) {
						if ( ! $order instanceof WC_Order ) {
							return null;
						}

						$status = $order->get_status();

						return array(
							'id'          => 'order:' . $order->get_id(),
							'resource'    => 'order',
							'resourceId'  => $order->get_id(),
							'priority'    => 'failed' === $status ? 'critical' : 'high',
							'title'       => sprintf( __( 'Order #%s needs attention', 'wphave' ), $order->get_order_number() ),
							'description' => sprintf( __( '%1$s · %2$s', 'wphave' ), wc_get_order_status_name( $status ), self::plain_text( $order->get_formatted_order_total() ) ),
							'date'        => self::date_value( $order->get_date_created() ),
							'actionLabel' => __( 'Review order', 'wphave' ),
						);
					},
					is_array( $orders ) ? $orders : array()
				)
			)
		);
	}

	/**
	 * Project products whose canonical catalog state needs attention.
	 *
	 * @return array
	 */

	private static function inbox_product_items() {
		$products = wc_get_products(
			array(
				'limit'        => 20,
				'orderby'      => 'modified',
				'order'        => 'DESC',
				'status'       => array( 'publish', 'draft', 'pending', 'private' ),
				'stock_status' => 'outofstock',
				'return'       => 'objects',
			)
		);

		return array_values(
			array_filter(
				array_map(
					static function ( $product ) {
						if ( ! $product instanceof WC_Product ) {
							return null;
						}

						return array(
							'id'          => 'product:' . $product->get_id(),
							'resource'    => 'product',
							'resourceId'  => $product->get_id(),
							'priority'    => 'high',
							'title'       => sprintf( __( '%s is out of stock', 'wphave' ), $product->get_name() ),
							'description' => $product->get_sku() ? sprintf( __( 'SKU %s', 'wphave' ), $product->get_sku() ) : __( 'Catalog availability requires review.', 'wphave' ),
							'date'        => self::date_value( $product->get_date_modified() ),
							'actionLabel' => __( 'Review product', 'wphave' ),
						);
					},
					is_array( $products ) ? $products : array()
				)
			)
		);
	}

	/**
	 * Project coupons expiring during the next fourteen days.
	 *
	 * @return array
	 */
    
	private static function inbox_coupon_items() {
		$query = new WP_Query(
			array(
				'post_type'      => 'shop_coupon',
				'post_status'    => 'publish',
				'posts_per_page' => 20,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);
		$now   = current_datetime()->getTimestamp();
		$until = current_datetime()->modify( '+14 days' )->getTimestamp();
		$items = array();

		foreach ( $query->posts as $coupon_id ) {
			$coupon  = new WC_Coupon( $coupon_id );
			$expires = $coupon->get_date_expires();

			if ( ! $expires instanceof WC_DateTime || $expires->getTimestamp() < $now || $expires->getTimestamp() > $until ) {
				continue;
			}

			$items[] = array(
				'id'          => 'coupon:' . $coupon->get_id(),
				'resource'    => 'coupon',
				'resourceId'  => $coupon->get_id(),
				'priority'    => 'medium',
				'title'       => sprintf( __( 'Coupon %s expires soon', 'wphave' ), $coupon->get_code() ),
				'description' => sprintf( __( 'Expires %s', 'wphave' ), wp_date( get_option( 'date_format' ), $expires->getTimestamp() ) ),
				'date'        => $expires->date( DATE_ATOM ),
				'actionLabel' => __( 'Review coupon', 'wphave' ),
			);
		}

		return $items;
	}
}
