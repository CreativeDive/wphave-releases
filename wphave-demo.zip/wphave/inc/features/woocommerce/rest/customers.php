<?php

/**
 * Registered WordPress customer identity discovery and validation.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Expose customer projections backed by canonical WooCommerce data.
 */

trait WPHAVE_WooCommerce_REST_Customers {

	/**
	 * Search registered customer identities without loading the complete user table.
	 *
	 * WordPress owns user identity and WooCommerce owns its association with an
	 * order. This endpoint intentionally returns only fields required by the picker.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */

	public static function get_customers( WP_REST_Request $request ) {
		$search = sanitize_text_field( (string) $request->get_param( 'search' ) );
		$mode   = sanitize_key( (string) $request->get_param( 'mode' ) );

		if ( 'picker' === $mode && strlen( $search ) < 2 ) {
			return rest_ensure_response( array( 'items' => array() ) );
		}

		if ( 'picker' !== $mode ) {
			return self::get_customer_collection( $request );
		}

		$query = new WP_User_Query(
			array(
				'number'         => 20,
				'orderby'        => 'display_name',
				'order'          => 'ASC',
				'search'         => '*' . $search . '*',
				'search_columns' => array( 'user_login', 'user_email', 'display_name' ),
				'fields'         => array( 'ID', 'display_name', 'user_login', 'user_email' ),
			)
		);

		return rest_ensure_response(
			array(
				'items' => array_values(
					array_map( array( __CLASS__, 'prepare_customer_identity' ), $query->get_results() )
				),
			)
		);
	}

	/**
	 * Return registered WooCommerce customer accounts in a User Management-shaped contract.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */

	private static function get_customer_collection( WP_REST_Request $request ) {
		$page     = max( 1, absint( $request->get_param( 'page' ) ) );
		$per_page = min( 100, max( 1, absint( $request->get_param( 'per_page' ) ) ) );
		$order     = 'desc' === strtolower( (string) $request->get_param( 'order' ) ) ? 'DESC' : 'ASC';
		$orderby   = self::allowed_value(
			$request->get_param( 'orderby' ),
			array( 'display_name', 'email', 'registered' ),
			'display_name'
		);
		$search    = substr( sanitize_text_field( (string) $request->get_param( 'search' ) ), 0, 100 );
		$args      = array(
			'number'      => $per_page,
			'offset'      => ( $page - 1 ) * $per_page,
			'orderby'     => $orderby,
			'order'       => $order,
			'role'        => 'customer',
			'count_total' => true,
			'fields'      => 'all',
		);

		if ( '' !== $search ) {
			$args['search']         = '*' . $search . '*';
			$args['search_columns'] = array( 'user_login', 'user_email', 'display_name' );
		}

		$query = new WP_User_Query( $args );
		$total = (int) $query->get_total();

		return rest_ensure_response(
			array(
				'items' => array_values(
					array_filter( array_map( array( __CLASS__, 'prepare_customer' ), $query->get_results() ) )
				),
				'total' => $total,
				'page'  => $page,
				'pages' => max( 1, (int) ceil( $total / $per_page ) ),
			)
		);
	}

	/**
	 * Return one customer with a bounded canonical order history.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */

	public static function get_customer( WP_REST_Request $request ) {
		// AUTHORIZATION INVARIANT: Route-level Commerce access permits customer lookup,
		// but the supplied ID must still resolve to an actual customer identity before
		// orders, coupons or billing-derived summaries are projected.
		$user = get_user_by( 'id', absint( $request->get_param( 'id' ) ) );

		if ( ! $user instanceof WP_User || ! in_array( 'customer', (array) $user->roles, true ) ) {
			return new WP_Error( 'wphave_woocommerce_customer_not_found', __( 'Customer not found.', 'wphave' ), array( 'status' => 404 ) );
		}

		$result = wc_get_orders(
			array(
				'customer_id' => $user->ID,
				'limit'       => 10,
				'page'        => 1,
				'paginate'    => true,
				'type'        => 'shop_order',
				'orderby'     => 'date',
				'order'       => 'DESC',
				'return'      => 'objects',
			)
		);
		$orders = is_object( $result ) && isset( $result->orders ) ? $result->orders : array();
		$customer = self::prepare_customer( $user );
		$customer['orders'] = array_values( array_filter( array_map( array( __CLASS__, 'prepare_order' ), $orders ) ) );
		$customer['lastActivity'] = ! empty( $orders ) ? self::date_value( $orders[0]->get_date_created() ) : '';
		$customer['attentionOrders'] = count(
			array_filter(
				$orders,
				static function ( $order ) {
					return $order instanceof WC_Order && in_array( $order->get_status(), array( 'failed', 'pending', 'on-hold' ), true );
				}
			)
		);
		$customer['couponsUsed'] = array_values(
			array_unique(
				array_reduce(
					$orders,
					static function ( $codes, $order ) {
						return $order instanceof WC_Order ? array_merge( $codes, $order->get_coupon_codes() ) : $codes;
					},
					array()
				)
			)
		);
		$customer_object = new WC_Customer( $user->ID );
		$customer['billingAddress'] = implode( ', ', self::formatted_lines( WC()->countries->get_formatted_address( $customer_object->get_billing() ) ) );
		$customer['shippingAddress'] = implode( ', ', self::formatted_lines( WC()->countries->get_formatted_address( $customer_object->get_shipping() ) ) );

		return rest_ensure_response( $customer );
	}

	/**
	 * Determine whether a registered user may be associated with this site order.
	 *
	 * @param int $user_id User ID.
	 * @return bool
	 */

	private static function is_assignable_customer( $user_id ) {
		if ( ! get_user_by( 'id', $user_id ) ) {
			return false;
		}

		return ! is_multisite() || is_user_member_of_blog( $user_id, get_current_blog_id() );
	}

	/**
	 * Prepare the minimal WordPress identity used by the order customer picker.
	 *
	 * @param WP_User|object|false $user User object.
	 * @return array|null
	 */

	private static function prepare_customer_identity( $user ) {
		if ( ! is_object( $user ) || empty( $user->ID ) ) {
			return null;
		}

		$name = (string) ( $user->display_name ?: $user->user_login );

		return array(
			'id'    => (int) $user->ID,
			'name'  => $name,
			'email' => (string) $user->user_email,
		);
	}

	/**
	 * Prepare a registered customer through WordPress identity and WooCommerce helpers.
	 *
	 * @param WP_User|object|false $user User object.
	 * @return array|null
	 */
    
	private static function prepare_customer( $user ) {
		if ( ! $user instanceof WP_User ) {
			return null;
		}

		$customer   = new WC_Customer( $user->ID );
		$total_spent = function_exists( 'wc_get_customer_total_spent' )
			? (string) wc_get_customer_total_spent( $user->ID )
			: '0';

		return array(
			'id'              => (int) $user->ID,
			'name'            => (string) ( $user->display_name ?: $user->user_login ),
			'username'        => (string) $user->user_login,
			'email'           => (string) $user->user_email,
			'avatarUrl'       => (string) get_avatar_url( $user->ID, array( 'size' => 96 ) ),
			'dateRegistered'  => mysql_to_rfc3339( $user->user_registered ),
			'orderCount'      => function_exists( 'wc_get_customer_order_count' ) ? (int) wc_get_customer_order_count( $user->ID ) : 0,
			'totalSpent'      => $total_spent,
			'formattedSpent'  => self::plain_text( wc_price( $total_spent ) ),
			'billingLocation' => implode( ', ', array_filter( array( $customer->get_billing_city(), $customer->get_billing_country() ) ) ),
			'canEdit'         => current_user_can( 'edit_user', $user->ID ),
		);
	}
}
