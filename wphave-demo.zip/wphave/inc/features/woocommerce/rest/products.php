<?php

/**
 * WooCommerce Core product entity and catalog workflows.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once dirname(__DIR__, 2) . '/security/safe-link.php';

/**
 * Expose paginated WooCommerce product projections for WPHAVE DataViews.
 */

trait WPHAVE_WooCommerce_REST_Products {

	/**
	 * Add structured WooCommerce data to the canonical WordPress product entity.
	 *
	 * This lets the WPHAVE block editor keep title, excerpt, blocks and Commerce
	 * settings in one Core Data edit/save lifecycle.
	 *
	 * @return void
	 */

	private static function register_product_entity_field() {
		register_rest_field(
			'product',
			'wphave_commerce',
			array(
				'get_callback'    => array( __CLASS__, 'get_product_entity_field' ),
				'update_callback' => array( __CLASS__, 'update_product_entity_field' ),
				'schema'          => array(
					'type'        => 'object',
					'context'     => array( 'edit' ),
					'description' => __( 'WooCommerce Core product settings managed by WPHAVE.', 'wphave' ),
				),
			)
		);
	}

	/**
	 * Read the structured Commerce field for a WordPress REST product record.
	 *
	 * @param array $object REST product object.
	 * @return array|null
	 */

	public static function get_product_entity_field( $object ) {
		$product_id = absint( $object['id'] ?? 0 );

		// DISCLOSURE INVARIANT: This field is attached to WordPress' native product
		// entity, whose route is not governed by WPHAVE's Commerce permission
		// callback. Editor-only download, stock and pricing data requires both
		// workspace admission and exact WooCommerce product edit authority here.
		if ( ! $product_id || ! self::has_woocommerce_object_permission( 'product', 'edit', $product_id ) ) {
			return null;
		}

		$product = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : false;
		if ( ! $product instanceof WC_Product ) {
			return null;
		}

		$settings = self::prepare_product_settings( $product );

		// Product projection crosses WooCommerce filters and reference catalogs.
		// Revoke the whole field if authority changed before response release.
		return self::has_woocommerce_object_permission( 'product', 'edit', $product_id )
			? $settings
			: null;
	}

	/**
	 * Update the structured Commerce field during the normal product REST save.
	 *
	 * @param mixed   $value Product settings value.
	 * @param WP_Post $object Product post.
	 * @return bool|WP_Error
	 */

	public static function update_product_entity_field( $value, $object ) {
		$product_id = absint( $object->ID ?? 0 );

		// AUTHORIZATION INVARIANT: Core REST field callbacks repeat exact-product
		// authorization because schema context and route authentication alone do not
		// grant permission to mutate the supplied object ID.
		if ( ! $product_id
			|| ! self::can_access_commerce()
			|| ! self::has_woocommerce_object_permission( 'product', 'edit', $product_id ) ) {
			return new WP_Error(
				'wphave_woocommerce_product_forbidden',
				__( 'You are not allowed to edit this product.', 'wphave' ),
				array( 'status' => 403 )
			);
		}

		$product = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : false;

		if ( ! $product instanceof WC_Product ) {
			return new WP_Error(
				'wphave_woocommerce_product_not_found',
				__( 'Product not found.', 'wphave' ),
				array( 'status' => 404 )
			);
		}

		$data = is_array( $value ) ? $value : array();
		$conflict = self::commerce_revision_error( $product, $data['commerceRevision'] ?? '' );

		if ( $conflict ) {
			return $conflict;
		}

		try {
			$product = self::resolve_product_type_change( $product, $data );
			self::apply_product_settings_changes( $product, $data );
			$product->save();
		} catch ( Throwable $exception ) {
			return self::commerce_mutation_error(
				'wphave_woocommerce_product_invalid',
				__( 'The product settings could not be saved.', 'wphave' ),
				$exception,
				array( 'product_id' => $product_id )
			);
		}

		return true;
	}

	/**
	 * Determine whether the current user may edit the requested product.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return bool
	 */

	public static function can_edit_product( WP_REST_Request $request ) {
		$id = absint( $request->get_param( 'id' ) );

		return $id > 0 && self::has_woocommerce_object_permission( 'product', 'edit', $id );
	}

	/**
	 * Determine whether the current user may delete the requested product.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return bool
	 */

	public static function can_delete_product( WP_REST_Request $request ) {
		$id = absint( $request->get_param( 'id' ) );

		return $id > 0 && self::has_woocommerce_object_permission( 'product', 'delete', $id );
	}

	/**
	 * Mirror WooCommerce Core's product-duplication capability contract.
	 *
	 * @return bool
	 */

	public static function can_duplicate_product() {
		$capability = apply_filters( 'woocommerce_duplicate_product_capability', 'manage_woocommerce' );

		return self::can_read_products() && current_user_can( $capability );
	}


	/**
	 * Return a paginated product projection from WC_Product_Query.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */

	public static function get_products( WP_REST_Request $request ) {
		if ( ! function_exists( 'wc_get_products' ) ) {
			return self::unavailable_error();
		}

		// QUERY INVARIANT: Product search and pagination are admitted before
		// sanitizers or WooCommerce catalogue queries consume attacker text.
		$page = self::collection_page( $request );
		$search = self::collection_search( $request );
		$sku = self::collection_search( $request, 'sku' );
		foreach ( array( $page, $search, $sku ) as $admitted ) {
			if ( is_wp_error( $admitted ) ) {
				return $admitted;
			}
		}

		$per_page = min( 100, max( 1, (int) $request->get_param( 'per_page' ) ) );
		$order     = strtolower( (string) $request->get_param( 'order' ) ) === 'asc' ? 'ASC' : 'DESC';
		$orderby   = self::allowed_value(
			$request->get_param( 'orderby' ),
			array( 'date', 'id', 'title', 'name', 'modified', 'menu_order' ),
			'date'
		);
		$status    = sanitize_key( (string) $request->get_param( 'status' ) );
		$type      = sanitize_key( (string) $request->get_param( 'type' ) );
		$stock_status = sanitize_key( (string) $request->get_param( 'stock_status' ) );
		$visibility = sanitize_key( (string) $request->get_param( 'visibility' ) );
		$featured = self::optional_boolean( $request->get_param( 'featured' ) );
		$virtual = self::optional_boolean( $request->get_param( 'virtual' ) );
		$downloadable = self::optional_boolean( $request->get_param( 'downloadable' ) );

		if ( is_wp_error( $featured ) || is_wp_error( $virtual ) || is_wp_error( $downloadable ) ) {
			return new WP_Error( 'wphave_woocommerce_product_filter_invalid', __( 'Invalid product property filter.', 'wphave' ), array( 'status' => 400 ) );
		}

		$args = array(
			'limit'    => $per_page,
			'page'     => $page,
			'paginate' => true,
			'orderby'  => $orderby,
			'order'    => $order,
			'return'   => 'objects',
		);

		if ( $status && 'all' !== $status ) {
			$args['status'] = $status;
		}

		if ( '' !== $search ) {
			$args['s'] = $search;
		}

		if ( '' !== $sku ) {
			$args['sku'] = $sku;
		}

		if ( '' !== $type ) {
			if ( ! array_key_exists( $type, self::core_product_types() ) ) {
				return new WP_Error( 'wphave_woocommerce_product_type_invalid', __( 'Invalid product type.', 'wphave' ), array( 'status' => 400 ) );
			}

			$args['type'] = $type;
		}

		if ( '' !== $stock_status ) {
			if ( ! array_key_exists( $stock_status, self::core_stock_statuses() ) ) {
				return new WP_Error( 'wphave_woocommerce_stock_status_invalid', __( 'Invalid stock status.', 'wphave' ), array( 'status' => 400 ) );
			}

			$args['stock_status'] = $stock_status;
		}

		if ( '' !== $visibility ) {
			if ( ! in_array( $visibility, array( 'visible', 'catalog', 'search', 'hidden' ), true ) ) {
				return new WP_Error( 'wphave_woocommerce_catalog_visibility_invalid', __( 'Invalid catalog visibility.', 'wphave' ), array( 'status' => 400 ) );
			}

			$args['visibility'] = $visibility;
		}

		foreach ( array( 'featured' => $featured, 'virtual' => $virtual, 'downloadable' => $downloadable ) as $key => $value ) {
			if ( '' !== $value ) {
				$args[ $key ] = $value;
			}
		}

		$result = wc_get_products( $args );
		$items  = is_object( $result ) && isset( $result->products ) ? $result->products : array();
		$total  = is_object( $result ) && isset( $result->total ) ? (int) $result->total : count( $items );
		$category_terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'number' => 100 ) );
		$category_terms = is_wp_error( $category_terms ) ? array() : $category_terms;

		return rest_ensure_response(
			array(
				'items'     => array_values( array_filter( array_map( array( __CLASS__, 'prepare_product' ), $items ) ) ),
				'total'     => $total,
				'page'      => $page,
				'pages'     => is_object( $result ) && isset( $result->max_num_pages ) ? (int) $result->max_num_pages : 1,
				'statuses'  => function_exists( 'get_post_statuses' ) ? get_post_statuses() : array(),
				'types'     => self::core_product_types(),
				'stockStatuses' => self::core_stock_statuses(),
				'categories' => array_values(
					array_map(
						static function ( $term ) {
							return array( 'value' => (string) $term->term_id, 'label' => $term->name );
						},
						$category_terms
					)
				),
				'nativeUrl' => admin_url( 'edit.php?post_type=product' ),
			)
		);
	}

	/**
	 * Return the canonical WooCommerce Core fields for one product.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */

	public static function get_product( WP_REST_Request $request ) {
		$product = self::find_product( $request );

		if ( is_wp_error( $product ) ) {
			return $product;
		}

		return rest_ensure_response( self::prepare_product_editor( $product ) );
	}

	/**
	 * Persist supported fields through WC_Product setters only.
	 *
	 * Unknown WooCommerce and extension-owned data is intentionally untouched.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */

	public static function update_product( WP_REST_Request $request ) {
		$permission = self::require_woocommerce_object_permission( 'product', 'edit', absint( $request->get_param( 'id' ) ) );

		if ( is_wp_error( $permission ) ) {
			return $permission;
		}

		$product = self::find_product( $request );

		if ( is_wp_error( $product ) ) {
			return $product;
		}

		$conflict = self::commerce_revision_error( $product, $request->get_param( 'commerceRevision' ) );

		if ( $conflict ) {
			return $conflict;
		}

		try {
			$product = self::resolve_product_type_change( $product, $request->get_json_params() ?: array() );
			self::apply_product_changes( $product, $request->get_json_params() ?: array() );
			$product->save();
		} catch ( Throwable $exception ) {
			return self::commerce_mutation_error(
				'wphave_woocommerce_product_invalid',
				__( 'The product could not be saved.', 'wphave' ),
				$exception,
				array( 'product_id' => (int) $product->get_id() )
			);
		}

		$product = wc_get_product( $product->get_id() );

		return rest_ensure_response( self::prepare_product_editor( $product ) );
	}

	/**
	 * Move a product to trash through WooCommerce CRUD.
	 *
	 * Permanent deletion remains outside the WPHAVE editor workflow.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */

	public static function delete_product( WP_REST_Request $request ) {
		$product_id = absint( $request->get_param( 'id' ) );

		// AUTHORIZATION INVARIANT: Product deletion rechecks exact-object delete
		// authority at the final CRUD boundary. Historically only REST dispatch made
		// this decision, but a public callback can also be invoked internally.
		if ( ! $product_id || ! self::has_woocommerce_object_permission( 'product', 'delete', $product_id ) ) {
			return new WP_Error(
				'wphave_woocommerce_product_forbidden',
				__( 'You are not allowed to delete this product.', 'wphave' ),
				array( 'status' => 403 )
			);
		}

		$product = self::find_product( $request );

		if ( is_wp_error( $product ) ) {
			return $product;
		}

		if ( 'trash' === $product->get_status( 'edit' ) ) {
			return new WP_Error( 'wphave_woocommerce_product_already_trashed', __( 'This product is already in the trash.', 'wphave' ), array( 'status' => 410 ) );
		}

		try {
			$product->delete( false );
		} catch ( Throwable $exception ) {
			return self::commerce_mutation_error(
				'wphave_woocommerce_product_delete_failed',
				__( 'The product could not be moved to the trash.', 'wphave' ),
				$exception,
				array( 'product_id' => (int) $product->get_id() )
			);
		}

		if ( 'trash' !== $product->get_status( 'edit' ) ) {
			return new WP_Error( 'wphave_woocommerce_product_delete_failed', __( 'The product could not be moved to the trash.', 'wphave' ), array( 'status' => 500 ) );
		}

		return rest_ensure_response(
			array(
				'id'      => (int) $product->get_id(),
				'deleted' => true,
				'status'  => 'trash',
			)
		);
	}

	/**
	 * Duplicate a product through WooCommerce Core's duplication service.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */

	public static function duplicate_product( WP_REST_Request $request ) {
		// AUTHORIZATION INVARIANT: Duplication repeats the filtered WooCommerce
		// capability contract at the final callback, independently of REST dispatch.
		if ( ! self::can_duplicate_product() ) {
			return new WP_Error( 'wphave_woocommerce_forbidden', __( 'You are not allowed to duplicate products.', 'wphave' ), array( 'status' => 403 ) );
		}

		$product = self::find_product( $request );

		if ( is_wp_error( $product ) ) {
			return $product;
		}

		if ( ! class_exists( 'WC_Admin_Duplicate_Product' ) && defined( 'WC_ABSPATH' ) ) {
			require_once WC_ABSPATH . 'includes/admin/class-wc-admin-duplicate-product.php';
		}

		if ( ! class_exists( 'WC_Admin_Duplicate_Product' ) ) {
			return self::unavailable_error();
		}

		try {
			$duplicate = ( new WC_Admin_Duplicate_Product() )->product_duplicate( $product );

			if ( ! $duplicate instanceof WC_Product || ! $duplicate->get_id() ) {
				throw new RuntimeException( __( 'WooCommerce could not duplicate this product.', 'wphave' ) );
			}

			$name = substr( sanitize_text_field( wp_unslash( (string) $request->get_param( 'name' ) ) ), 0, 200 );

			if ( '' !== $name && $name !== $duplicate->get_name( 'edit' ) ) {
				$duplicate->set_name( $name );
				$duplicate->save();
			}

			do_action( 'woocommerce_product_duplicate', $duplicate, $product );
		} catch ( Throwable $exception ) {
			return self::commerce_mutation_error(
				'wphave_woocommerce_product_duplicate_failed',
				__( 'The product could not be duplicated.', 'wphave' ),
				$exception,
				array( 'product_id' => (int) $product->get_id() )
			);
		}

		$response = rest_ensure_response( self::prepare_product_editor( $duplicate ) );
		$response->set_status( 201 );

		return $response;
	}


	/**
	 * Prepare a product view model without changing WooCommerce data.
	 *
	 * @param mixed $product Product object.
	 * @return array|null
	 */

	public static function prepare_product( $product ) {
		if ( ! is_object( $product ) || ! is_a( $product, 'WC_Product' ) ) {
			return null;
		}

		$image_id = (int) $product->get_image_id();
		$modified = $product->get_date_modified();

		return array(
			'id'             => (int) $product->get_id(),
			'name'           => (string) $product->get_name(),
			'sellingModel'   => self::product_selling_model( $product ),
			'readiness'      => self::prepare_product_readiness( $product ),
			'sku'            => (string) $product->get_sku(),
			'type'           => (string) $product->get_type(),
			'status'         => (string) $product->get_status(),
			'price'          => (string) $product->get_price(),
			'formattedPrice' => self::product_price_text( $product->get_price_html() ),
			'totalSales'     => (int) $product->get_total_sales(),
			'stockStatus'    => (string) $product->get_stock_status(),
			'stockQuantity'  => $product->get_stock_quantity(),
			'imageUrl'       => $image_id ? (string) wp_get_attachment_image_url( $image_id, 'thumbnail' ) : '',
			'dateModified'   => self::date_value( $modified ),
			// LINK INVARIANT: Product and Core edit-link filters are not trusted hrefs.
			'permalink'      => WPHAVE_Safe_Link::http( $product->get_permalink() ),
			'editUrl'        => WPHAVE_Safe_Link::http( get_edit_post_link( $product->get_id(), 'raw' ) ),
		);
	}

	/**
	 * Convert WooCommerce price markup to one concise visual label.
	 *
	 * WooCommerce appends an accessibility-only explanation to price ranges. The
	 * collection cell already exposes the visible range, so transporting that
	 * hidden sentence as visible text would duplicate and distort the value.
	 *
	 * @param mixed $value WooCommerce price HTML.
	 * @return string
	 */

	private static function product_price_text( $value ) {
		$value = preg_replace(
			'/<span\b[^>]*class=(["\'])[^"\']*\bscreen-reader-text\b[^"\']*\1[^>]*>.*?<\/span>/is',
			'',
			(string) $value
		);
		$value = preg_replace(
			'/<\/del>\s*<ins\b[^>]*>/i',
			'</del> → <ins>',
			$value
		);

		return trim( preg_replace( '/\s+/u', ' ', self::plain_text( $value ) ) );
	}
}
