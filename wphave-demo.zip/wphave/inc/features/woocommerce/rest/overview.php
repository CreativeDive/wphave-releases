<?php

/**
 * WooCommerce-owned operational overview projections.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Build the read-only Commerce overview projection from WooCommerce facts.
 */

trait WPHAVE_WooCommerce_REST_Overview {

	/**
	 * Return an operational Commerce overview without querying storage directly.
	 *
	 * @return WP_REST_Response|WP_Error
	 */

	public static function get_commerce_overview() {
		if ( ! function_exists( 'wc_get_products' ) || ! function_exists( 'wc_get_orders' ) ) {
			return self::unavailable_error();
		}

		$product_statuses = array( 'publish', 'draft', 'pending', 'private' );
		$order_statuses   = self::core_order_statuses();
		$order_counts     = array();

		foreach ( array_keys( $order_statuses ) as $status ) {
			$order_counts[ $status ] = self::overview_order_count( array( 'status' => 'wc-' . $status ) );
		}

		$recent_result = wc_get_orders(
			array(
				'limit'    => 5,
				'page'     => 1,
				'paginate' => true,
				'type'     => 'shop_order',
				'orderby'  => 'date',
				'order'    => 'DESC',
				'status'   => array_map(
					static function ( $status ) {
						return 'wc-' . $status;
					},
					array_keys( $order_statuses )
				),
				'return'   => 'objects',
			)
		);
		$recent_orders = is_object( $recent_result ) && isset( $recent_result->orders )
			? $recent_result->orders
			: array();

		$attention_result = wc_get_products(
			array(
				'limit'        => 5,
				'page'         => 1,
				'paginate'     => true,
				'orderby'      => 'modified',
				'order'        => 'DESC',
				'status'       => $product_statuses,
				'stock_status' => 'outofstock',
				'return'       => 'objects',
			)
		);
		$attention_products = is_object( $attention_result ) && isset( $attention_result->products )
			? $attention_result->products
			: array();
		$revenue = self::overview_revenue();

		return rest_ensure_response(
			array(
				'summary' => array(
					'products'           => self::overview_product_count( array( 'status' => $product_statuses ) ),
					'publishedProducts'  => self::overview_product_count( array( 'status' => 'publish' ) ),
					'outOfStockProducts' => self::overview_product_count(
						array(
							'status'       => $product_statuses,
							'stock_status' => 'outofstock',
						)
					),
					'orders'             => array_sum( $order_counts ),
					'openOrders'         => array_sum(
						array_intersect_key( $order_counts, array_flip( array( 'pending', 'processing', 'on-hold' ) ) )
					),
					'completedOrders'    => (int) ( $order_counts['completed'] ?? 0 ),
				),
				'orderStatuses' => array_map(
					static function ( $status, $label ) use ( $order_counts ) {
						return array(
							'key'   => $status,
							'label' => $label,
							'value' => (int) ( $order_counts[ $status ] ?? 0 ),
						);
					},
					array_keys( $order_statuses ),
					array_values( $order_statuses )
				),
				'recentOrders'      => array_values( array_filter( array_map( array( __CLASS__, 'prepare_order' ), $recent_orders ) ) ),
				'attentionProducts' => array_values( array_filter( array_map( array( __CLASS__, 'prepare_product' ), $attention_products ) ) ),
				'revenue'           => $revenue,
			)
		);
	}

	/**
	 * Project WooCommerce Analytics total sales for the last 30 calendar days.
	 *
	 * Revenue semantics remain owned by WooCommerce Analytics. WPHAVE only
	 * reshapes its public query result for the Commerce overview chart.
	 *
	 * @return array
	 */

	private static function overview_revenue() {
		$query_class = '\\Automattic\\WooCommerce\\Admin\\API\\Reports\\Revenue\\Query';
		$currency    = function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : '';
		$empty       = array(
			'available'  => false,
			'periodDays' => 30,
			'currency'   => $currency,
			'total'      => 0.0,
			'timeseries' => array(),
		);

		if ( ! class_exists( $query_class ) ) {
			return $empty;
		}

		$today = current_datetime();
		$start = $today->modify( '-29 days' );

		try {
			$query  = new $query_class(
				array(
					'after'    => $start->format( 'Y-m-d 00:00:00' ),
					'before'   => $today->format( 'Y-m-d 23:59:59' ),
					'interval' => 'day',
					'per_page' => 30,
					'page'     => 1,
					'orderby'  => 'date',
					'order'    => 'ASC',
					'fields'   => array( 'total_sales', 'net_revenue', 'refunds', 'orders_count' ),
				)
			);
			$report = $query->get_data();
		} catch ( Throwable $error ) {
			return $empty;
		}

		$totals    = is_object( $report ) && isset( $report->totals ) ? (array) $report->totals : array();
		$intervals = is_object( $report ) && isset( $report->intervals ) && is_array( $report->intervals )
			? $report->intervals
			: array();

		return array(
			'available'  => true,
			'periodDays' => 30,
			'currency'   => $currency,
			'total'      => (float) ( $totals['total_sales'] ?? 0 ),
			'netRevenue' => (float) ( $totals['net_revenue'] ?? 0 ),
			'refunds'    => (float) ( $totals['refunds'] ?? 0 ),
			'ordersCount'=> (int) ( $totals['orders_count'] ?? 0 ),
			'timeseries' => array_values(
				array_map(
					static function ( $interval ) {
						$subtotals = isset( $interval['subtotals'] ) ? (array) $interval['subtotals'] : array();

						return array(
							'date'         => (string) ( $interval['interval'] ?? '' ),
							'total_sales'  => (float) ( $subtotals['total_sales'] ?? 0 ),
							'net_revenue'  => (float) ( $subtotals['net_revenue'] ?? 0 ),
							'refunds'      => (float) ( $subtotals['refunds'] ?? 0 ),
							'orders_count' => (int) ( $subtotals['orders_count'] ?? 0 ),
						);
					},
					$intervals
				)
			),
		);
	}

	/**
	 * Count products through WC_Product_Query pagination metadata.
	 *
	 * @param array $args Query arguments.
	 * @return int
	 */

	private static function overview_product_count( $args = array() ) {
		$result = wc_get_products(
			array_merge(
				$args,
				array(
					'limit'    => 1,
					'page'     => 1,
					'paginate' => true,
					'return'   => 'ids',
				)
			)
		);

		return is_object( $result ) && isset( $result->total ) ? (int) $result->total : 0;
	}

	/**
	 * Count orders through the active WooCommerce order datastore.
	 *
	 * @param array $args Query arguments.
	 * @return int
	 */
    
	private static function overview_order_count( $args = array() ) {
		$result = wc_get_orders(
			array_merge(
				$args,
				array(
					'limit'    => 1,
					'page'     => 1,
					'paginate' => true,
					'type'     => 'shop_order',
					'return'   => 'ids',
				)
			)
		);

		return is_object( $result ) && isset( $result->total ) ? (int) $result->total : 0;
	}
}
