<?php

/**
 * Register side-effect-free WooCommerce ownership contracts.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/compatibility.php';

add_filter(
	'wphave_generic_content_excluded_post_types',
	static function( $post_types ) {
		$post_types   = (array) $post_types;
		$post_types[] = 'product';

		return $post_types;
	}
);
