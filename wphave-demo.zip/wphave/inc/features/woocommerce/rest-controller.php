<?php

/**
 * Stable REST facade for the thematically separated WPHAVE Commerce modules.
 *
 * WooCommerce remains the source of truth. Domain traits implement the REST
 * contracts while this class owns route registration and public callback identity.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/rest/contracts.php';
require_once __DIR__ . '/rest/overview.php';
require_once __DIR__ . '/rest/inbox.php';
require_once __DIR__ . '/rest/products.php';
require_once __DIR__ . '/rest/product-mutations.php';
require_once __DIR__ . '/rest/product-editor.php';
require_once __DIR__ . '/rest/variations.php';
require_once __DIR__ . '/rest/orders.php';
require_once __DIR__ . '/rest/order-addresses.php';
require_once __DIR__ . '/rest/order-notes.php';
require_once __DIR__ . '/rest/customers.php';
require_once __DIR__ . '/rest/coupons.php';
require_once __DIR__ . '/rest/bulk.php';

/**
 * Coordinate the stable Commerce REST facade and its domain-specific traits.
 *
 * WooCommerce remains the source of truth; this controller only exposes
 * capability-protected WPHAVE projections and mutation workflows.
 */
class WPHAVE_WooCommerce_REST_Controller {
	use WPHAVE_WooCommerce_REST_Contracts;
	use WPHAVE_WooCommerce_REST_Overview;
	use WPHAVE_WooCommerce_REST_Inbox;
	use WPHAVE_WooCommerce_REST_Products;
	use WPHAVE_WooCommerce_REST_Product_Mutations;
	use WPHAVE_WooCommerce_REST_Product_Editor;
	use WPHAVE_WooCommerce_REST_Variations;
	use WPHAVE_WooCommerce_REST_Orders;
	use WPHAVE_WooCommerce_REST_Order_Addresses;
	use WPHAVE_WooCommerce_REST_Order_Notes;
	use WPHAVE_WooCommerce_REST_Customers;
	use WPHAVE_WooCommerce_REST_Coupons;
	use WPHAVE_WooCommerce_REST_Bulk;

	/**
	 * Register the REST bootstrap hook.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * Register Commerce routes.
	 *
	 * @return void
	 */
	public static function register_routes() {
		self::register_product_entity_field();

		register_rest_route(
			'wphave/v1',
			'/commerce/overview',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_commerce_overview' ),
				'permission_callback' => array( __CLASS__, 'can_read_orders' ),
			)
		);

		register_rest_route(
			'wphave/v1',
			'/commerce/inbox',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_commerce_inbox' ),
				'permission_callback' => array( __CLASS__, 'can_read_orders' ),
			)
		);

		register_rest_route(
			'wphave/v1',
			'/commerce/products/bulk',
			array(
				'methods'             => WP_REST_Server::EDITABLE,
				'callback'            => array( __CLASS__, 'bulk_products' ),
				'permission_callback' => array( __CLASS__, 'can_read_products' ),
				'args'                => self::mutation_args( 'bulk' ),
			)
		);
		register_rest_route(
			'wphave/v1',
			'/commerce/orders/bulk',
			array(
				'methods'             => WP_REST_Server::EDITABLE,
				'callback'            => array( __CLASS__, 'bulk_orders' ),
				'permission_callback' => array( __CLASS__, 'can_read_orders' ),
				'args'                => self::mutation_args( 'bulk' ),
			)
		);
		register_rest_route(
			'wphave/v1',
			'/commerce/coupons/bulk',
			array(
				'methods'             => WP_REST_Server::EDITABLE,
				'callback'            => array( __CLASS__, 'bulk_coupons' ),
				'permission_callback' => array( __CLASS__, 'can_read_coupons' ),
				'args'                => self::mutation_args( 'bulk' ),
			)
		);

		register_rest_route(
			'wphave/v1',
			'/commerce/products',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_products' ),
				'permission_callback' => array( __CLASS__, 'can_read_products' ),
				'args'                => self::collection_args( 'date' ),
			)
		);

		register_rest_route(
			'wphave/v1',
			'/commerce/products/(?P<id>\d+)',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'get_product' ),
					'permission_callback' => array( __CLASS__, 'can_edit_product' ),
				),
				array(
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => array( __CLASS__, 'update_product' ),
					'permission_callback' => array( __CLASS__, 'can_edit_product' ),
				),
				array(
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => array( __CLASS__, 'delete_product' ),
					'permission_callback' => array( __CLASS__, 'can_delete_product' ),
				),
				'schema' => array( __CLASS__, 'product_schema' ),
			)
		);

		register_rest_route(
			'wphave/v1',
			'/commerce/products/(?P<id>\d+)/duplicate',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'duplicate_product' ),
				'permission_callback' => array( __CLASS__, 'can_duplicate_product' ),
				'args'                => self::mutation_args( 'duplicate' ),
			)
		);

		register_rest_route(
			'wphave/v1',
			'/commerce/orders',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_orders' ),
				'permission_callback' => array( __CLASS__, 'can_read_orders' ),
				'args'                => self::collection_args( 'date' ),
			)
		);

		register_rest_route(
			'wphave/v1',
			'/commerce/customers',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_customers' ),
				'permission_callback' => array( __CLASS__, 'can_read_customers' ),
			)
		);

		register_rest_route(
			'wphave/v1',
			'/commerce/customers/(?P<id>\d+)',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_customer' ),
				'permission_callback' => array( __CLASS__, 'can_read_customer' ),
			)
		);

		register_rest_route(
			'wphave/v1',
			'/commerce/coupons',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'get_coupons' ),
					'permission_callback' => array( __CLASS__, 'can_read_coupons' ),
					'args'                => self::collection_args( 'date' ),
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( __CLASS__, 'create_coupon' ),
					'permission_callback' => array( __CLASS__, 'can_create_coupon' ),
					'args'                => self::mutation_args( 'coupon', true ),
				),
			)
		);

		register_rest_route(
			'wphave/v1',
			'/commerce/coupons/(?P<id>\d+)',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'get_coupon' ),
					'permission_callback' => array( __CLASS__, 'can_read_coupon' ),
				),
				array(
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => array( __CLASS__, 'update_coupon' ),
					'permission_callback' => array( __CLASS__, 'can_edit_coupon' ),
					'args'                => self::mutation_args( 'coupon' ),
				),
			)
		);

		register_rest_route(
			'wphave/v1',
			'/commerce/orders/(?P<id>\d+)',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'get_order' ),
					'permission_callback' => array( __CLASS__, 'can_read_order' ),
				),
				array(
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => array( __CLASS__, 'update_order' ),
					'permission_callback' => array( __CLASS__, 'can_edit_order' ),
					'args'                => self::mutation_args( 'order' ),
				),
			)
		);

		register_rest_route(
			'wphave/v1',
			'/commerce/orders/(?P<id>\d+)/notes',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'get_order_notes' ),
					'permission_callback' => array( __CLASS__, 'can_read_order' ),
					'args'                => self::collection_args( 'date' ),
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( __CLASS__, 'create_order_note' ),
					'permission_callback' => array( __CLASS__, 'can_edit_order' ),
					'args'                => self::mutation_args( 'note' ),
				),
			)
		);

		register_rest_route(
			'wphave/v1',
			'/commerce/products/(?P<id>\d+)/variations',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'get_product_variations' ),
					'permission_callback' => array( __CLASS__, 'can_edit_product' ),
					'args'                => self::collection_args( 'menu_order' ),
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( __CLASS__, 'create_product_variation' ),
					'permission_callback' => array( __CLASS__, 'can_edit_product' ),
					'args'                => self::mutation_args( 'variation' ),
				),
			)
		);

		register_rest_route(
			'wphave/v1',
			'/commerce/variations/(?P<id>\d+)',
			array(
				array(
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => array( __CLASS__, 'update_product_variation' ),
					'permission_callback' => array( __CLASS__, 'can_edit_variation' ),
					'args'                => self::mutation_args( 'variation' ),
				),
				array(
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => array( __CLASS__, 'delete_product_variation' ),
					'permission_callback' => array( __CLASS__, 'can_delete_variation' ),
					'args'                => self::mutation_args( 'variation' ),
				),
			)
		);
	}
}
