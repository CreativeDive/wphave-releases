<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Central WooCommerce integration layer.
 *
 * WPHAVE supports WooCommerce through modern block-based templates and shared
 * context helpers. Legacy WooCommerce PHP template overrides are intentionally
 * not modeled here, so scattered feature code can ask one class for the active
 * WooCommerce state without duplicating fragile conditionals.
 */

class WPHAVE_WooCommerce {

	/**
	 * Register frontend optimization hooks.
	 *
	 * @return void
	 */

	public static function init() {

		add_action('wp_enqueue_scripts', [__CLASS__, 'disable_cart_fragments'], 100);

	}

	/**
	 * Check whether WooCommerce is active.
	 *
	 * @return bool
	 */

	public static function is_active() {

		return class_exists( 'WooCommerce' );

	}

	/**
	 * Return the WooCommerce context flags WPHAVE needs.
	 *
	 * Every flag defaults to false so callers can safely read the array even when
	 * WooCommerce is inactive or one of its conditional functions is unavailable.
	 *
	 * @return array
	 */

	public static function context() {

		$context = array(
			'is_shop' => false,
			'is_cart' => false,
			'is_checkout' => false,
			'is_thank_you' => false,
			'is_account_page' => false,
			'is_woocommerce' => false,
			'is_product' => false,
			'is_product_category' => false,
			'is_product_tag' => false,
		);

		if( ! self::is_active() ) {
			return $context;
		}

		$context['is_shop'] = function_exists( 'is_shop' ) ? is_shop() : false;
		$context['is_cart'] = function_exists( 'is_cart' ) ? is_cart() : false;
		$context['is_checkout'] = function_exists( 'is_checkout' ) ? is_checkout() : false;
		$context['is_thank_you'] = function_exists( 'is_wc_endpoint_url' ) ? is_wc_endpoint_url( 'order-received' ) : false;
		$context['is_account_page'] = function_exists( 'is_account_page' ) ? is_account_page() : false;
		$context['is_woocommerce'] = function_exists( 'is_woocommerce' ) ? is_woocommerce() : false;
		$context['is_product'] = function_exists( 'is_product' ) ? is_product() : false;
		$context['is_product_category'] = function_exists( 'is_product_category' ) ? is_product_category() : false;
		$context['is_product_tag'] = function_exists( 'is_product_tag' ) ? is_product_tag() : false;

		return $context;

	}

	/**
	 * Return the configured WooCommerce shop page id.
	 *
	 * @return int
	 */

	public static function shop_page_id() {

		if( ! self::is_active() ) {
			return 0;
		}

		if( function_exists( 'wc_get_page_id' ) ) {
			return (int) wc_get_page_id( 'shop' );
		}

		return (int) get_option( 'woocommerce_shop_page_id' );

	}

	/**
	 * Return the configured shop page post object.
	 *
	 * @return WP_Post|null
	 */

	public static function shop_page() {

		$shop_page_id = self::shop_page_id();

		return $shop_page_id > 0 ? get_post( $shop_page_id ) : null;

	}

	/**
	 * Return the shop page content used by WPHAVE content blocks.
	 *
	 * @return string
	 */

	public static function shop_content() {

		$shop_page = self::shop_page();

		return $shop_page instanceof WP_Post ? (string) $shop_page->post_content : '';

	}

	/**
	 * Return a WooCommerce product object defensively.
	 *
	 * @param int $post_id Product post id.
	 * @return WC_Product|false
	 */

	public static function product( $post_id = 0 ) {

		if( ! self::is_active() || ! function_exists( 'wc_get_product' ) ) {
			return false;
		}

		$post_id = $post_id ? (int) $post_id : get_the_ID();

		return $post_id ? wc_get_product( $post_id ) : false;

	}

	/**
	 * Run a renderer with WooCommerce's canonical single-product global.
	 *
	 * WordPress initially exposes the matched product slug through the global
	 * query variables. Native WooCommerce replaces that value while entering its
	 * loop, but WPHAVE renders block templates without that legacy loop.
	 *
	 * @param int      $post_id Product post id.
	 * @param callable $renderer Render callback.
	 * @return mixed Callback result.
	 */

	public static function with_product_context( $post_id, callable $renderer ) {

		global $product;

		$previous_product = $product ?? null;
		$current_product = self::product( $post_id );

		if( ! $current_product || ! is_object( $current_product ) || ! method_exists( $current_product, 'get_id' ) ) {
			return $renderer();
		}

		// SECURITY: The renderer and WooCommerce blocks must observe the same
		// verified object identity; never let a raw query slug cross this boundary.
		$product = $current_product;

		try {
			return $renderer();
		} finally {
			$product = $previous_product;
		}

	}

	/**
	 * Resolve the WPHAVE template context for a product subtype.
	 *
	 * Specific product-type templates remain optional and fall back to the
	 * generic product template when the concrete WooCommerce type is unknown.
	 *
	 * @param int $post_id Product post id.
	 * @return string
	 */

	public static function product_template_context( $post_id = 0 ) {

		$product = self::product( $post_id );

		if( ! $product || ! is_object( $product ) || ! method_exists( $product, 'is_type' ) ) {
			return 'post_type_product';
		}

		if( $product->is_type('simple') || $product->is_type('single') ) {
			return 'post_type_product_single';
		}

		if( $product->is_type('variable') ) {
			return 'post_type_product_variable';
		}

		if( $product->is_type('grouped') ) {
			return 'post_type_product_grouped';
		}

		if( $product->is_type('external') ) {
			return 'post_type_product_external';
		}

		return 'post_type_product';

	}

	/**
	 * Return the product excerpt used by the WPHAVE content block.
	 *
	 * @param int $post_id Product post id.
	 * @return string
	 */

	public static function product_excerpt( $post_id = 0 ) {

		$post_id = $post_id ? (int) $post_id : get_the_ID();
		$post = $post_id ? get_post( $post_id ) : null;

		return $post instanceof WP_Post ? (string) $post->post_excerpt : '';

	}

	/**
	 * Return WooCommerce gallery image ids for a product.
	 *
	 * @param int $post_id Product post id.
	 * @return array
	 */

	public static function product_gallery_image_ids( $post_id = 0 ) {

		$product = self::product( $post_id );

		if( ! $product || ! is_object( $product ) ) {
			return array();
		}

		$image_ids = array();

		if( method_exists( $product, 'get_image_id' ) ) {
			$image_id = (int) $product->get_image_id();
			if( $image_id ) {
				$image_ids[] = $image_id;
			}
		}

		if( method_exists( $product, 'get_gallery_image_ids' ) ) {
			$image_ids = array_merge( $image_ids, array_map( 'absint', (array) $product->get_gallery_image_ids() ) );
		}

		return array_values( array_unique( array_filter( $image_ids ) ) );

	}

	/**
	 * Render the WooCommerce sale flash for product templates.
	 *
	 * @return void
	 */

	public static function render_sale_flash() {

		if( self::is_active() && function_exists( 'wc_get_template' ) ) {
			wc_get_template( 'single-product/sale-flash.php' );
		}

	}

	/**
	 * Return the product visibility filter used by product query loops.
	 *
	 * @param array $post_types Queried post types.
	 * @return array
	 */

	public static function product_visibility_tax_query( $post_types = array() ) {

		$post_types = is_array( $post_types ) ? $post_types : array( $post_types );
		$post_types = array_values( array_filter( array_map( function( $post_type ) {
			if( is_array( $post_type ) ) {
				$post_type = $post_type['value'] ?? $post_type['slug'] ?? $post_type['name'] ?? '';
			} elseif( is_object( $post_type ) ) {
				$post_type = $post_type->value ?? $post_type->slug ?? $post_type->name ?? '';
			}

			return sanitize_key( $post_type );
		}, $post_types ) ) );

		if( ! in_array( 'product', $post_types, true ) || ! taxonomy_exists( 'product_visibility' ) ) {
			return array();
		}

		return array(
			'taxonomy' => 'product_visibility',
			'field' => 'name',
			'terms' => 'exclude-from-catalog',
			'operator' => 'NOT IN',
		);

	}

	/**
	 * Check whether the current request is a WooCommerce utility page.
	 *
	 * @return bool
	 */

	public static function is_cart_checkout_or_account() {

		$context = self::context();

		return ! empty( $context['is_cart'] ) || ! empty( $context['is_checkout'] ) || ! empty( $context['is_account_page'] );

	}

	/**
	 * Check whether the current request triggers a WooCommerce add-to-cart action.
	 *
	 * @return bool
	 */

	public static function is_add_to_cart_request() {

		return self::is_active() && isset( $_GET['add-to-cart'] );

	}

	/**
	 * Check whether WooCommerce has an active cart/session cookie.
	 *
	 * This is intentionally centralized because cache and asset optimizations must
	 * agree on the same cart-safety rules.
	 *
	 * @return bool
	 */

	public static function has_active_cart_session() {

		if( ! self::is_active() ) {
			return false;
		}

		if( ! empty( $_COOKIE['woocommerce_items_in_cart'] ) ) {
			return true;
		}

		foreach( $_COOKIE as $key => $value ) {
			if( strpos( (string) $key, 'wp_woocommerce_session_' ) !== false ) {
				return true;
			}
		}

		return false;

	}

	/**
	 * Register WooCommerce support for the bundled WPHAVE theme.
	 *
	 * The WPHAVE theme uses block-based WooCommerce templates and disables the
	 * legacy gallery enhancers because product gallery behavior is handled by
	 * WPHAVE blocks and WooCommerce blocks instead.
	 *
	 * @return void
	 */

	public static function register_theme_support() {

		if( ! self::is_active() ) {
			return;
		}

		add_theme_support( 'woocommerce', array(
			'single_image_width' => 800,
			'thumbnail_image_width' => 250,
			'gallery_thumbnail_image_width' => 250,
		) );

		remove_theme_support( 'wc-product-gallery-zoom' );
		remove_theme_support( 'wc-product-gallery-lightbox' );
		remove_theme_support( 'wc-product-gallery-slider' );

	}

	/**
	 * Disable cart fragments for visitors without an active cart.
	 *
	 * WooCommerce cart fragments are expensive on pages that do not need live cart
	 * state. The cookie check preserves correctness for active shopping sessions.
	 *
	 * @return void
	 */

	public static function disable_cart_fragments() {

		if( is_admin() || ! self::is_active() ) return;

		if( ! self::has_active_cart_session() ) {
			wp_dequeue_script('wc-cart-fragments');
		}

	}

}
