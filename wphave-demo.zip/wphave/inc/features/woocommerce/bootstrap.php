<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/woocommerce.php';
require_once __DIR__ . '/reporting/bootstrap.php';

WPHAVE_WooCommerce::init();
