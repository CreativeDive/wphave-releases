<?php

/** Resumable, idempotent backfill for pre-existing WooCommerce orders. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Backfill normalized Commerce events from canonical WooCommerce orders.
 *
 * Processing is resumable, idempotent, bounded, and protected by an expiring
 * ownership lock so retries cannot create duplicate reporting facts.
 */

final class WPHAVE_Commerce_Reporting_Backfill {
	const VERSION = 2;
	const HOOK = 'wphave_commerce_reporting_backfill';
	const STATE_OPTION = 'wphave_commerce_reporting_backfill_v1';
	const LOCK_OPTION = 'wphave_commerce_reporting_backfill_lock';
	const LOCK_TTL = 300;
	const BATCH_SIZE = 50;

	private WPHAVE_Commerce_Reporting_Events $events;
	private string $lock_token = '';

	/**
	 * Create the backfill coordinator.
	 *
	 * @param WPHAVE_Commerce_Reporting_Events $events Event recorder.
	 */

	public function __construct( WPHAVE_Commerce_Reporting_Events $events ) {
		$this->events = $events;
	}

	/**
	 * Register the asynchronous backfill callback.
	 *
	 * @return void
	 */

	public function register(): void {
		add_action( self::HOOK, array( $this, 'run' ), 10, 1 );
	}

	/**
	 * Schedule a backfill unless the current version is already complete.
	 *
	 * @return bool Whether the job is complete or was scheduled successfully.
	 */

	public function schedule(): bool {
		$state = $this->state();
		if ( 'complete' === $state['status'] ) {
			return true;
		}

		$state['status'] = 'scheduled';
		$state['updatedAt'] = current_time( 'mysql', true );
		update_option( self::STATE_OPTION, $state, false );

		$scheduled = class_exists( 'WPHAVE_Background_Job_Scheduler' )
			&& WPHAVE_Background_Job_Scheduler::ensure_single_event( self::HOOK, array( $state['cursor'] ), time() + 5 );
		if ( ! $scheduled ) {
			$state['status'] = 'degraded';
			$state['lastError'] = 'scheduler_unavailable';
			update_option( self::STATE_OPTION, $state, false );
		}

		return $scheduled;
	}

	/**
	 * Process one resumable backfill batch.
	 *
	 * @param int $cursor Order-query offset.
	 * @return void
	 */

	public function run( $cursor = 0 ): void {
		if ( ! WPHAVE_WooCommerce::is_active() ) {
			return;
		}
		if ( ! $this->acquire_lock() ) {
			$this->schedule_retry( absint( $cursor ) );
			return;
		}

		try {
			$this->run_batch( absint( $cursor ) );
		} catch ( Throwable $exception ) {
			$state = $this->state();
			$state['status'] = 'degraded';
			$state['attempts'] = min( 10, $state['attempts'] + 1 );
			$state['lastError'] = sanitize_key( get_class( $exception ) );
			$state['updatedAt'] = current_time( 'mysql', true );
			update_option( self::STATE_OPTION, $state, false );
			do_action( 'wphave_commerce_reporting_backfill_error', $exception, $state );
			$this->schedule_retry( $state['cursor'] );
		} finally {
			$this->release_lock();
		}
	}

	/**
	 * Return the normalized state for the current backfill version.
	 *
	 * @return array<string,mixed> Backfill state.
	 */

	public function state(): array {
		$state = get_option( self::STATE_OPTION, array() );
		$state = is_array( $state ) ? $state : array();
		if ( self::VERSION !== absint( $state['version'] ?? 0 ) ) {
			$state = array();
		}

		return array(
			'version'   => self::VERSION,
			'status'    => sanitize_key( $state['status'] ?? 'idle' ),
			'cursor'    => absint( $state['cursor'] ?? 0 ),
			'processed' => absint( $state['processed'] ?? 0 ),
			'updatedAt' => sanitize_text_field( $state['updatedAt'] ?? '' ),
			'attempts'  => absint( $state['attempts'] ?? 0 ),
			'lastError' => sanitize_key( $state['lastError'] ?? '' ),
		);
	}

	/**
	 * Record one bounded page of canonical orders.
	 *
	 * @param int $cursor Order-query offset.
	 * @return void
	 */

	private function run_batch( int $cursor ): void {
		$orders = wc_get_orders(
			array(
				'limit'   => self::BATCH_SIZE,
				'offset'  => $cursor,
				'type'    => 'shop_order',
				'orderby' => 'ID',
				'order'   => 'ASC',
				'return'  => 'objects',
				'exclude' => array( 0 ),
			)
		);
		$orders = array_values( array_filter( $orders, static fn( $order ) => $order instanceof WC_Order ) );
		foreach ( $orders as $order ) {
			$this->backfill_order( $order );
		}
		$cursor += count( $orders );
		$state = $this->state();
		$state['cursor'] = $cursor;
		$state['processed'] = $cursor;
		$state['updatedAt'] = current_time( 'mysql', true );
		$state['status'] = count( $orders ) < self::BATCH_SIZE ? 'complete' : 'running';
		$state['attempts'] = 0;
		$state['lastError'] = '';
		update_option( self::STATE_OPTION, $state, false );
		if ( 'running' === $state['status'] && class_exists( 'WPHAVE_Background_Job_Scheduler' ) ) {
			WPHAVE_Background_Job_Scheduler::ensure_continuation( self::HOOK, array( $cursor ), 10 );
		}
	}

	/**
	 * Acquire the expiring single-worker lock.
	 *
	 * @return bool Whether this worker owns the lock.
	 */

	private function acquire_lock(): bool {
		$token = WPHAVE_Background_Job_Lock::acquire( self::LOCK_OPTION, self::LOCK_TTL );
		if ( ! $token ) {
			return false;
		}

		$this->lock_token = $token;

		return true;
	}

	/**
	 * Release the lock only when it belongs to this worker.
	 *
	 * @return void
	 */

	private function release_lock(): void {
		// SECURITY INVARIANT: A delayed backfill worker cannot release a successor's
		// lease after timeout recovery; cleanup remains token-owned.
		if ( $this->lock_token ) {
			WPHAVE_Background_Job_Lock::release( self::LOCK_OPTION, $this->lock_token );
		}
		$this->lock_token = '';
	}

	/**
	 * Schedule a delayed continuation after a recoverable failure.
	 *
	 * @param int $cursor Order-query offset.
	 * @return void
	 */

	private function schedule_retry( int $cursor ): void {
		if ( class_exists( 'WPHAVE_Background_Job_Scheduler' ) ) {
			WPHAVE_Background_Job_Scheduler::ensure_continuation( self::HOOK, array( $cursor ), 60 );
		}
	}

	/**
	 * Reconstruct lifecycle events for one canonical order.
	 *
	 * @param WC_Order $order WooCommerce order.
	 * @return void
	 */
    
	private function backfill_order( WC_Order $order ): void {
		$this->events->record_order_event( 'commerce.order_created', $order->get_id(), array( 'isBackfill' => true ) );

		if ( $order->get_date_paid() ) {
			$this->events->record_order_event( 'commerce.order_paid', $order->get_id(), array( 'isBackfill' => true ) );
		}

		if ( $order->get_date_completed() ) {
			$this->events->record_order_event( 'commerce.order_completed', $order->get_id(), array( 'isBackfill' => true ) );
		}

		if ( 'cancelled' === $order->get_status() ) {
			$this->events->record_order_event( 'commerce.order_cancelled', $order->get_id(), array( 'isBackfill' => true ) );
		}

		foreach ( $order->get_refunds() as $refund ) {
			if ( $refund instanceof WC_Order_Refund ) {
				$this->events->record_order_event(
					'commerce.order_refunded',
					$order->get_id(),
					array(
						'subjectType' => 'refund',
						'subjectId'   => $refund->get_id(),
						'amount'      => abs( (float) $refund->get_amount() ),
						'occurredAt'  => $refund->get_date_created() ? $refund->get_date_created()->getTimestamp() : time(),
						'isBackfill'  => true,
					)
				);
			}
		}
	}
}
