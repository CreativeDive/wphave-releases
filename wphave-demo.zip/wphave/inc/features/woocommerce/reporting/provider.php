<?php

/** Read-only Commerce projections consumed by Conversions. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Publish read-only Commerce projections to the Conversions consumer.
 */

final class WPHAVE_Commerce_Reporting_Provider {
	private WPHAVE_Commerce_Reporting_Repository $repository;

	/**
	 * Create the reporting projection provider.
	 *
	 * @param WPHAVE_Commerce_Reporting_Repository $repository Event repository.
	 */

	public function __construct( WPHAVE_Commerce_Reporting_Repository $repository ) {
		$this->repository = $repository;
	}

	/**
	 * Register Commerce as a Conversions provider.
	 *
	 * @return void
	 */

	public function register(): void {
		add_filter( 'wphave_conversion_provider_projections', array( $this, 'conversion_projection' ), 10, 2 );
	}

	/**
	 * Add the Commerce funnel projection to Conversions provider results.
	 *
	 * @param array           $providers Existing provider projections.
	 * @param WP_REST_Request $request   Conversions request.
	 * @return array Updated provider projections.
	 */

	public function conversion_projection( array $providers, WP_REST_Request $request ): array {
		$providers['commerce'] = $this->project( $request );

		return $providers;
	}

	/**
	 * Build the normalized projection without exposing WooCommerce internals.
	 *
	 * @param WP_REST_Request $request Consumer request.
	 * @return array<string,mixed> Versioned Commerce projection.
	 */
	private function project( WP_REST_Request $request ): array {
		if ( ! $this->repository->exists() || ! WPHAVE_WooCommerce::is_active() ) {
			return array_merge( WPHAVE_Commerce_Reporting_Contracts::definition(), array( 'available' => false ) );
		}

		global $wpdb;
		$table = WPHAVE_Commerce_Reporting_Schema::table();
		$days = max( 1, min( 366, absint( $request->get_param( 'days' ) ?: 30 ) ) );
		$from = gmdate( 'Y-m-d 00:00:00', time() - ( ( $days - 1 ) * DAY_IN_SECONDS ) );
		$to = gmdate( 'Y-m-d 23:59:59' );
		$params = array( $from, $to );
		$where = 'WHERE occurred_at BETWEEN %s AND %s';

		foreach ( array( 'source', 'medium', 'campaign' ) as $dimension ) {
			$value = sanitize_text_field( $request->get_param( $dimension ) ?? '' );
			if ( '' !== $value ) {
				$where .= " AND {$dimension} = %s";
				$params[] = $value;
			}
		}

		$json_dimensions = array(
			'product_id'     => 'productIds',
			'category_id'    => 'categoryIds',
			'coupon'         => 'couponCodes',
			'customer_type'  => 'customerType',
			'order_status'   => 'orderStatus',
			'payment_method' => 'paymentMethod',
		);

		foreach ( $json_dimensions as $parameter => $dimension ) {
			$value = sanitize_text_field( $request->get_param( $parameter ) ?? '' );
			if ( '' !== $value ) {
				$where .= ' AND dimensions_json LIKE %s';
				$params[] = '%"' . $wpdb->esc_like( $dimension ) . '":%' . $wpdb->esc_like( wp_json_encode( ctype_digit( $value ) ? absint( $value ) : $value ) ) . '%';
			}
		}

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT event_name, currency, DATE(occurred_at) event_date,
					COUNT(*) event_count, COUNT(DISTINCT order_id) order_count,
					SUM(amount_minor) amount_minor, SUM(gross_minor) gross_minor,
					SUM(tax_minor) tax_minor, SUM(shipping_minor) shipping_minor,
					SUM(discount_minor) discount_minor, SUM(units) units
				FROM {$table} {$where}
				GROUP BY event_name, currency, DATE(occurred_at)
				ORDER BY event_date ASC",
				...$params
			),
			ARRAY_A
		) ?: array();
		$currency = function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : '';
		$backfill_state = ( new WPHAVE_Commerce_Reporting_Backfill( new WPHAVE_Commerce_Reporting_Events( $this->repository ) ) )->state();
		$reporting_state = match ( $backfill_state['status'] ) {
			'complete' => 'ready',
			'degraded' => 'degraded',
			'running', 'scheduled' => 'backfillRunning',
			default => 'initializing',
		};
		$daily = array();
		$metrics = array_fill_keys( WPHAVE_Commerce_Reporting_Contracts::METRICS, 0 );
		$recognized_orders = 0;
		$funnel = array_fill_keys( array( 'productViews', 'cartAdds', 'checkoutStarts', 'orders', 'paidOrders' ), 0 );
		$currency_breakdown = array();

		foreach ( $rows as $row ) {
			$row_currency = $row['currency'] ?: $currency;
			$currency_breakdown[ $row_currency ] ??= array( 'recognizedRevenue' => 0, 'refunds' => 0, 'orders' => 0 );
			if ( 'commerce.order_created' === $row['event_name'] ) {
				$currency_breakdown[ $row_currency ]['orders'] += (int) $row['order_count'];
			}
			if ( 'commerce.order_paid' === $row['event_name'] ) {
				$currency_breakdown[ $row_currency ]['recognizedRevenue'] += (int) $row['amount_minor'];
			}
			if ( 'commerce.order_completed' === $row['event_name'] ) {
				$currency_breakdown[ $row_currency ]['recognizedRevenue'] += (int) $row['amount_minor'];
			}
			if ( 'commerce.order_refunded' === $row['event_name'] ) {
				$currency_breakdown[ $row_currency ]['refunds'] += (int) $row['amount_minor'];
				$currency_breakdown[ $row_currency ]['recognizedRevenue'] -= (int) $row['amount_minor'];
			}

			if ( $currency && $row['currency'] && $currency !== $row['currency'] ) {
				continue;
			}

			$date = $row['event_date'];
			$daily[ $date ] ??= array( 'date' => $date, 'recognizedRevenue' => 0, 'orders' => 0, 'refunds' => 0 );
			$amount = (int) $row['amount_minor'];
			$count = (int) $row['event_count'];

			switch ( $row['event_name'] ) {
				case 'commerce.product_viewed':
					$funnel['productViews'] += $count;
					break;
				case 'commerce.added_to_cart':
					$funnel['cartAdds'] += $count;
					break;
				case 'commerce.checkout_started':
					$funnel['checkoutStarts'] += $count;
					break;
				case 'commerce.order_created':
					$funnel['orders'] += (int) $row['order_count'];
					$metrics['orders'] += (int) $row['order_count'];
					$metrics['grossSales'] += (int) $row['gross_minor'];
					$metrics['taxes'] += (int) $row['tax_minor'];
					$metrics['shipping'] += (int) $row['shipping_minor'];
					$metrics['discounts'] += (int) $row['discount_minor'];
					$metrics['unitsSold'] += (int) $row['units'];
					$daily[ $date ]['orders'] += (int) $row['order_count'];
					break;
				case 'commerce.order_paid':
					$recognized_orders += (int) $row['order_count'];
					$funnel['paidOrders'] += (int) $row['order_count'];
					$metrics['recognizedRevenue'] += $amount;
					$daily[ $date ]['recognizedRevenue'] += $amount;
					break;
				case 'commerce.order_completed':
					if ( 0 !== $amount ) {
						$recognized_orders += (int) $row['order_count'];
					}
					$metrics['recognizedRevenue'] += $amount;
					$daily[ $date ]['recognizedRevenue'] += $amount;
					break;
				case 'commerce.order_refunded':
					$metrics['refunds'] += $amount;
					$metrics['recognizedRevenue'] -= $amount;
					$daily[ $date ]['refunds'] += $amount;
					$daily[ $date ]['recognizedRevenue'] -= $amount;
					break;
			}
		}

		$metrics['netSales'] = $metrics['recognizedRevenue'];
		$metrics['averageOrderValue'] = $recognized_orders ? (int) round( $metrics['recognizedRevenue'] / $recognized_orders ) : 0;
		$metrics['conversionRate'] = $funnel['checkoutStarts'] ? round( ( $funnel['paidOrders'] / $funnel['checkoutStarts'] ) * 100, 2 ) : 0;
		return array_merge(
			WPHAVE_Commerce_Reporting_Contracts::definition(),
			array(
				'available' => true,
				'state'     => $reporting_state,
				'currency'  => $currency,
				'range'     => array( 'days' => $days, 'from' => $from, 'to' => $to ),
				'metrics'   => $metrics,
				'byCurrency'=> $currency_breakdown,
				'timeseries'=> array_values( $daily ),
				'funnel'    => $funnel,
				'drillDown' => array(
					'screen'  => 'commerce',
					'section' => 'orders',
					'filters' => array( 'date_from' => substr( $from, 0, 10 ), 'date_to' => substr( $to, 0, 10 ) ),
				),
			)
		);
	}
}
