<?php

/** Translate WooCommerce lifecycle state into normalized Commerce events. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Translate WooCommerce lifecycle hooks into normalized Commerce events.
 */

final class WPHAVE_Commerce_Reporting_Events {
	const ATTRIBUTION_META = '_wphave_commerce_attribution_v1';

	private WPHAVE_Commerce_Reporting_Repository $repository;

	/**
	 * Create the lifecycle event recorder.
	 *
	 * @param WPHAVE_Commerce_Reporting_Repository $repository Event repository.
	 */

	public function __construct( WPHAVE_Commerce_Reporting_Repository $repository ) {
		$this->repository = $repository;
	}

	/**
	 * Register WooCommerce lifecycle and storefront hooks.
	 *
	 * @return void
	 */

	public function register(): void {
		add_action( 'template_redirect', array( $this, 'capture_attribution' ), 5 );
		add_action( 'woocommerce_checkout_create_order', array( $this, 'attach_attribution' ), 10, 1 );
		add_action( 'woocommerce_new_order', array( $this, 'order_created' ), 10, 1 );
		add_action( 'woocommerce_payment_complete', array( $this, 'order_paid' ), 10, 1 );
		add_action( 'woocommerce_order_status_completed', array( $this, 'order_completed' ), 10, 1 );
		add_action( 'woocommerce_order_status_cancelled', array( $this, 'order_cancelled' ), 10, 1 );
		add_action( 'woocommerce_refund_created', array( $this, 'refund_created' ), 10, 2 );
		add_action( 'woocommerce_add_to_cart', array( $this, 'added_to_cart' ), 10, 2 );
		add_action( 'woocommerce_before_checkout_form', array( $this, 'checkout_started' ), 10, 0 );
		add_action( 'wp', array( $this, 'product_viewed' ), 20 );
	}

	/**
	 * Store a small first-touch attribution snapshot in the WooCommerce session.
	 *
	 * @return void
	 */

	public function capture_attribution(): void {
		if ( ! $this->can_capture_attribution() || ! function_exists( 'WC' ) || ! WC()->session ) {
			return;
		}

		$existing = WC()->session->get( 'wphave_commerce_attribution_v1' );
		if ( is_array( $existing ) && ! empty( $existing['capturedAt'] ) ) {
			return;
		}

		$snapshot = array(
			'version'    => 1,
			'capturedAt' => current_time( 'mysql', true ),
			'source'     => $this->query_value( 'utm_source', 100 ),
			'medium'     => $this->query_value( 'utm_medium', 100 ),
			'campaign'   => $this->query_value( 'utm_campaign', 150 ),
			'content'    => $this->query_value( 'utm_content', 150 ),
			'term'       => $this->query_value( 'utm_term', 150 ),
			'sessionHash'=> hash_hmac( 'sha256', (string) WC()->session->get_customer_id(), wp_salt( 'auth' ) ),
		);

		if ( array_filter( array_intersect_key( $snapshot, array_flip( array( 'source', 'medium', 'campaign', 'content', 'term' ) ) ) ) ) {
			WC()->session->set( 'wphave_commerce_attribution_v1', $snapshot );
		}
	}

	/**
	 * Attach the sanitized session attribution snapshot to a new order.
	 *
	 * @param WC_Order $order WooCommerce order being created.
	 * @return void
	 */

	public function attach_attribution( WC_Order $order ): void {
		if ( ! $this->can_capture_attribution() || ! function_exists( 'WC' ) || ! WC()->session ) {
			return;
		}

		$snapshot = WC()->session->get( 'wphave_commerce_attribution_v1' );
		if ( is_array( $snapshot ) ) {
			$order->update_meta_data( self::ATTRIBUTION_META, $this->sanitize_attribution( $snapshot ) );
		}
	}

	/**
	 * Record a storefront product view when the current request is a product page.
	 *
	 * @return void
	 */

	public function product_viewed(): void {
		if ( function_exists( 'is_product' ) && is_product() ) {
			$this->record_session_event( 'commerce.product_viewed', 'product', get_queried_object_id() );
		}
	}

	/**
	 * Record a product being added to the WooCommerce cart.
	 *
	 * @param string $cart_item_key WooCommerce cart-item key.
	 * @param int    $product_id    Product ID.
	 * @return void
	 */

	public function added_to_cart( $cart_item_key, $product_id ): void {
		$this->record_session_event( 'commerce.added_to_cart', 'product', absint( $product_id ) );
	}

	/**
	 * Record the start of a checkout session.
	 *
	 * @return void
	 */

	public function checkout_started(): void {
		$this->record_session_event( 'commerce.checkout_started', 'checkout', 0 );
	}

	/**
	 * Record order creation.
	 *
	 * @param int $order_id Order ID.
	 * @return void
	 */

	public function order_created( $order_id ): void {
		$this->record_order_event( 'commerce.order_created', $order_id );
	}

	/**
	 * Record successful order payment.
	 *
	 * @param int $order_id Order ID.
	 * @return void
	 */

	public function order_paid( $order_id ): void {
		$this->record_order_event( 'commerce.order_paid', $order_id );
	}

	/**
	 * Record order completion.
	 *
	 * @param int $order_id Order ID.
	 * @return void
	 */

	public function order_completed( $order_id ): void {
		$this->record_order_event( 'commerce.order_completed', $order_id );
	}

	/**
	 * Record order cancellation.
	 *
	 * @param int $order_id Order ID.
	 * @return void
	 */

	public function order_cancelled( $order_id ): void {
		$this->record_order_event( 'commerce.order_cancelled', $order_id );
	}

	/**
	 * Record a WooCommerce refund against its parent order.
	 *
	 * @param int   $refund_id Refund ID.
	 * @param array $args      WooCommerce hook arguments.
	 * @return void
	 */

	public function refund_created( $refund_id, $args = array() ): void {
		$refund = wc_get_order( absint( $refund_id ) );
		if ( ! $refund instanceof WC_Order_Refund ) {
			return;
		}

		$this->record_order_event(
			'commerce.order_refunded',
			$refund->get_parent_id(),
			array(
				'subjectType' => 'refund',
				'subjectId'   => $refund->get_id(),
				'amount'      => abs( (float) $refund->get_amount() ),
				'occurredAt'  => $refund->get_date_created() ? $refund->get_date_created()->getTimestamp() : time(),
			)
		);
	}

	/**
	 * Record one order lifecycle event; safe for live hooks and backfill.
	 *
	 * @param string $name      Normalized event name.
	 * @param int    $order_id  Order ID.
	 * @param array  $overrides Optional subject, amount, timestamp, and backfill overrides.
	 * @return bool Whether a new event was persisted.
	 */

	public function record_order_event( string $name, $order_id, array $overrides = array() ): bool {
		$order = wc_get_order( absint( $order_id ) );
		if ( ! $order instanceof WC_Order || ! in_array( $name, WPHAVE_Commerce_Reporting_Contracts::EVENTS, true ) ) {
			return false;
		}

		$currency = (string) $order->get_currency();
		$amount = array_key_exists( 'amount', $overrides ) ? (float) $overrides['amount'] : (float) $order->get_total();
		if ( 'commerce.order_completed' === $name && $order->get_date_paid() ) {
			$amount = 0.0;
		}
		$subject_type = sanitize_key( $overrides['subjectType'] ?? 'order' );
		$subject_id = absint( $overrides['subjectId'] ?? $order->get_id() );
		$occurred_at = (int) ( $overrides['occurredAt'] ?? $this->order_event_timestamp( $order, $name ) );
		$attribution = $this->sanitize_attribution( $order->get_meta( self::ATTRIBUTION_META, true ) );
		$event_key = hash( 'sha256', implode( ':', array( 'v1', $name, $subject_type, $subject_id ) ) );

		return $this->repository->insert(
			array(
				'eventKey'     => $event_key,
				'name'         => $name,
				'subjectType'  => $subject_type,
				'subjectId'    => $subject_id,
				'orderId'      => $order->get_id(),
				'occurredAt'   => $occurred_at,
				'amountMinor'  => WPHAVE_Commerce_Reporting_Contracts::money_to_minor( $amount, $currency ),
				'currency'     => $currency,
				'customerHash' => $this->customer_hash( $order ),
				'sessionHash'  => (string) ( $attribution['sessionHash'] ?? '' ),
				'attribution'  => $attribution,
				'dimensions'   => $this->order_dimensions( $order ),
				'isBackfill'   => ! empty( $overrides['isBackfill'] ),
			)
		);
	}

	/**
	 * Record one privacy-gated, hourly deduplicated session event.
	 *
	 * @param string $name         Normalized event name.
	 * @param string $subject_type Event subject type.
	 * @param int    $subject_id   Event subject ID.
	 * @return void
	 */

	private function record_session_event( string $name, string $subject_type, int $subject_id ): void {
		if ( ! $this->can_capture_attribution() || ! function_exists( 'WC' ) || ! WC()->session ) {
			return;
		}

		$session_hash = hash_hmac( 'sha256', (string) WC()->session->get_customer_id(), wp_salt( 'auth' ) );
		$bucket = gmdate( 'Y-m-d-H' );
		$this->repository->insert(
			array(
				'eventKey'    => hash( 'sha256', implode( ':', array( 'v1', $name, $session_hash, $subject_type, $subject_id, $bucket ) ) ),
				'name'        => $name,
				'subjectType' => $subject_type,
				'subjectId'   => $subject_id,
				'occurredAt'  => time(),
				'sessionHash' => $session_hash,
				'attribution' => $this->sanitize_attribution( WC()->session->get( 'wphave_commerce_attribution_v1' ) ),
				'dimensions'  => array( 'productIds' => $subject_id ? array( $subject_id ) : array() ),
			)
		);
	}

	/**
	 * Derive bounded, non-personal reporting dimensions from an order.
	 *
	 * @param WC_Order $order WooCommerce order.
	 * @return array<string,mixed> Normalized reporting dimensions.
	 */
    
	private function order_dimensions( WC_Order $order ): array {
		$product_ids = array();
		$category_ids = array();
		$units = 0;

		foreach ( $order->get_items( 'line_item' ) as $item ) {
			$product_id = absint( $item->get_product_id() );
			$product_ids[] = $product_id;
			$units += max( 0, (int) $item->get_quantity() );
			$category_ids = array_merge( $category_ids, wp_get_post_terms( $product_id, 'product_cat', array( 'fields' => 'ids' ) ) ?: array() );
		}

		return array(
			'productIds'    => array_values( array_unique( array_map( 'absint', $product_ids ) ) ),
			'categoryIds'   => array_values( array_unique( array_map( 'absint', $category_ids ) ) ),
			'couponCodes'   => array_values( array_slice( array_map( 'sanitize_text_field', $order->get_coupon_codes() ), 0, 100 ) ),
			'customerType'  => $order->get_customer_id() ? 'registered' : 'guest',
			'orderStatus'   => sanitize_key( $order->get_status() ),
			'paymentMethod' => sanitize_key( $order->get_payment_method() ),
			'units'         => $units,
			'wasPaid'       => (bool) $order->get_date_paid(),
			'grossMinor'    => WPHAVE_Commerce_Reporting_Contracts::money_to_minor( $order->get_total() + $order->get_discount_total(), $order->get_currency() ),
			'taxMinor'      => WPHAVE_Commerce_Reporting_Contracts::money_to_minor( $order->get_total_tax(), $order->get_currency() ),
			'shippingMinor' => WPHAVE_Commerce_Reporting_Contracts::money_to_minor( $order->get_shipping_total(), $order->get_currency() ),
			'discountMinor' => WPHAVE_Commerce_Reporting_Contracts::money_to_minor( $order->get_discount_total(), $order->get_currency() ),
		);
	}

	/**
	 * Resolve the canonical timestamp for an order lifecycle event.
	 *
	 * @param WC_Order $order WooCommerce order.
	 * @param string   $name  Normalized event name.
	 * @return int Unix timestamp.
	 */

	private function order_event_timestamp( WC_Order $order, string $name ): int {
		$date = match ( $name ) {
			'commerce.order_paid' => $order->get_date_paid(),
			'commerce.order_completed' => $order->get_date_completed(),
			'commerce.order_cancelled' => $order->get_date_modified(),
			default => $order->get_date_created(),
		};

		return $date instanceof WC_DateTime ? $date->getTimestamp() : time();
	}

	/**
	 * Build the pseudonymous reporting identity for an order customer.
	 *
	 * @param WC_Order $order WooCommerce order.
	 * @return string Salted customer hash or an empty string.
	 */

	private function customer_hash( WC_Order $order ): string {
		$customer_id = $order->get_customer_id();
		$email = strtolower( (string) $order->get_billing_email() );

		if ( ! $customer_id && '' === $email ) {
			return '';
		}

		$identity = $customer_id ? 'user:' . $customer_id : 'email:' . $email;

		return hash_hmac( 'sha256', $identity, wp_salt( 'auth' ) );
	}

	/**
	 * Determine whether analytics-session processing is currently permitted.
	 *
	 * @return bool Whether attribution and session events may be captured.
	 */

	private function can_capture_attribution(): bool {
		return function_exists( 'wphave_privacy_can_process' )
			&& class_exists( 'WPHAVE_Privacy_Manager' )
			&& wphave_privacy_can_process( WPHAVE_Privacy_Manager::PURPOSE_ANALYTICS_SESSIONS );
	}

	/**
	 * Normalize and bound an attribution payload.
	 *
	 * @param mixed $value Raw attribution payload.
	 * @return array<string,mixed> Sanitized attribution payload.
	 */

	private function sanitize_attribution( $value ): array {
		$value = is_array( $value ) ? $value : array();
		$result = array( 'version' => 1 );

		foreach ( array( 'source' => 100, 'medium' => 100, 'campaign' => 150, 'content' => 150, 'term' => 150 ) as $key => $length ) {
			$result[ $key ] = substr( sanitize_text_field( $value[ $key ] ?? '' ), 0, $length );
		}

		$result['capturedAt'] = sanitize_text_field( $value['capturedAt'] ?? '' );
		$result['sessionHash'] = preg_match( '/^[a-f0-9]{64}$/', (string) ( $value['sessionHash'] ?? '' ) ) ? $value['sessionHash'] : '';

		return $result;
	}

	/**
	 * Read and sanitize one bounded campaign query value.
	 *
	 * @param string $key    Query parameter name.
	 * @param int    $length Maximum value length.
	 * @return string Sanitized query value.
	 */
    
	private function query_value( string $key, int $length ): string {
		return substr( sanitize_text_field( wphave_request_string( $_GET, $key ) ), 0, $length );
	}
}
