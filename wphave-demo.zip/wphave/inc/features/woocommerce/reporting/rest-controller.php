<?php

/** Capability-protected operational routes for Commerce reporting. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Expose capability-protected reporting diagnostics and backfill operations.
 */

final class WPHAVE_Commerce_Reporting_REST_Controller {
	private WPHAVE_Commerce_Reporting_Backfill $backfill;
	private WPHAVE_Commerce_Reporting_Diagnostics $diagnostics;

	/**
	 * Create the operational reporting controller.
	 *
	 * @param WPHAVE_Commerce_Reporting_Backfill    $backfill    Backfill coordinator.
	 * @param WPHAVE_Commerce_Reporting_Diagnostics $diagnostics Diagnostics aggregator.
	 */

	public function __construct( WPHAVE_Commerce_Reporting_Backfill $backfill, WPHAVE_Commerce_Reporting_Diagnostics $diagnostics ) {
		$this->backfill = $backfill;
		$this->diagnostics = $diagnostics;
	}

	/**
	 * Register REST route initialization.
	 *
	 * @return void
	 */

	public function register(): void {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Register reporting status and backfill routes.
	 *
	 * @return void
	 */

	public function register_routes(): void {
		register_rest_route(
			'wphave/v1',
			'/commerce/reporting',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'status' ),
				'permission_callback' => array( $this, 'can_read' ),
			)
		);
		register_rest_route(
			'wphave/v1',
			'/commerce/reporting/backfill',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'schedule_backfill' ),
				'permission_callback' => array( $this, 'can_manage' ),
				'args'                => array(),
			)
		);
	}

	/**
	 * Check whether the current user may read reporting diagnostics.
	 *
	 * @return bool Whether read access is allowed.
	 */

	public function can_read(): bool {
		// SECURITY INVARIANT: Commerce reporting requires entry to the WPHAVE
		// workspace and the dedicated analytics capability; neither permission domain
		// exposes order-derived reporting data independently.
		return ( current_user_can( 'wphave_access' ) || current_user_can( 'manage_options' ) )
			&& current_user_can( 'view_wphave_analytics' );
	}

	/**
	 * Check whether the current user may manage reporting operations.
	 *
	 * @return bool Whether management access is allowed.
	 */

	public function can_manage(): bool {
		// SECURITY INVARIANT: Backfill and reconciliation combine WPHAVE workspace
		// access with WooCommerce's native management authority.
		return ( current_user_can( 'wphave_access' ) || current_user_can( 'manage_options' ) )
			&& current_user_can( 'manage_woocommerce' );
	}

	/**
	 * Return contract, backfill, and reconciliation status.
	 *
	 * @return WP_REST_Response Reporting status response.
	 */

	public function status() {
		// AUTHORIZATION INVARIANT: Reporting diagnostics repeat read authority at
		// the final callback because route dispatch is not the only possible caller.
		if ( ! $this->can_read() ) {
			return new WP_Error( 'wphave_commerce_reporting_forbidden', __( 'You are not allowed to view Commerce reporting diagnostics.', 'wphave' ), array( 'status' => 403 ) );
		}

		return rest_ensure_response(
			array(
				'contract' => WPHAVE_Commerce_Reporting_Contracts::definition(),
				'backfill' => $this->backfill->state(),
				'diagnostics' => $this->diagnostics->snapshot( true ),
			)
		);
	}

	/**
	 * Schedule the resumable reporting backfill.
	 *
	 * @return WP_REST_Response|WP_Error Backfill state or scheduling error.
	 */
    
	public function schedule_backfill() {
		// AUTHORIZATION INVARIANT: Scheduling a reporting backfill repeats management
		// authority immediately before creating persistent state and background work.
		if ( ! $this->can_manage() ) {
			return new WP_Error( 'wphave_commerce_reporting_forbidden', __( 'You are not allowed to manage Commerce reporting.', 'wphave' ), array( 'status' => 403 ) );
		}

		if ( ! $this->backfill->schedule() ) {
			return new WP_Error( 'wphave_commerce_backfill_schedule_failed', __( 'Commerce reporting backfill could not be scheduled.', 'wphave' ), array( 'status' => 503 ) );
		}

		return rest_ensure_response( array( 'backfill' => $this->backfill->state() ) );
	}
}
