<?php

/** Storage-only composition; integration runtime remains feature gated. */
if (!defined('ABSPATH')) {
	exit();
}
require_once __DIR__ . '/schema.php';

WPHAVE_Database_Schema_Manager::register([
	'id' => 'commerce-reporting',
	'enabled' => static function (): bool {
		if (!wphave_release_feature_ready('commerceReporting')) {
			return false;
		}
		// Core activation options are site-scoped; a loaded WooCommerce
		// class alone proves nothing after switch_to_blog().
		$plugin = defined('WC_PLUGIN_BASENAME')
			? WC_PLUGIN_BASENAME
			: 'woocommerce/woocommerce.php';
		$network = is_multisite() ? (int) get_site()->site_id : 0;
		$network_plugins = $network
			? (array) get_network_option($network, 'active_sitewide_plugins', [])
			: [];
		return in_array($plugin, (array) get_option('active_plugins', []), true) ||
			isset($network_plugins[$plugin]);
	},
	'label' => 'Commerce reporting events',
	'version' => WPHAVE_Commerce_Reporting_Schema::DB_VERSION,
	'option' => 'wphave_commerce_reporting_db_version',
	'tables' => [WPHAVE_Commerce_Reporting_Schema::TABLE],
	'callback' => ['WPHAVE_Commerce_Reporting_Schema', 'install'],
	'validator' => ['WPHAVE_Commerce_Reporting_Schema', 'validate'],
]);
