<?php

/** Versioned public contracts for Commerce reporting consumers. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Define the versioned reporting contract consumed by Conversions.
 */

final class WPHAVE_Commerce_Reporting_Contracts {
	const VERSION = '1';

	const EVENTS = array(
		'commerce.product_viewed',
		'commerce.added_to_cart',
		'commerce.checkout_started',
		'commerce.order_created',
		'commerce.order_paid',
		'commerce.order_completed',
		'commerce.order_refunded',
		'commerce.order_cancelled',
	);

	const METRICS = array(
		'grossSales',
		'netSales',
		'taxes',
		'shipping',
		'discounts',
		'refunds',
		'recognizedRevenue',
		'orders',
		'unitsSold',
		'averageOrderValue',
		'conversionRate',
	);

	const DIMENSIONS = array(
		'product',
		'category',
		'coupon',
		'customerType',
		'orderStatus',
		'paymentMethod',
		'source',
		'medium',
		'campaign',
	);

	/**
	 * Return the release contract without exposing WooCommerce implementation details.
	 *
	 * @return array<string,mixed> Versioned reporting contract.
	 */

	public static function definition(): array {
		return array(
			'version'    => self::VERSION,
			'namespace'  => 'commerce',
			'metrics'    => self::METRICS,
			'dimensions' => self::DIMENSIONS,
			'events'     => self::EVENTS,
			'money'      => array(
				'unit' => 'minor',
				'currencyPerValue' => true,
			),
		);
	}

	/**
	 * Convert a WooCommerce decimal to an integer minor-unit amount.
	 *
	 * @param mixed  $amount   Decimal amount accepted by WooCommerce.
	 * @param string $currency ISO currency code.
	 * @return int Amount in the currency's minor unit.
	 */

	public static function money_to_minor( $amount, string $currency ): int {
		$decimals = function_exists( 'wc_get_price_decimals' ) ? wc_get_price_decimals() : 2;
		$decimals = (int) apply_filters( 'wphave_commerce_currency_decimals', $decimals, $currency );

		return (int) round( (float) $amount * ( 10 ** max( 0, min( 6, $decimals ) ) ) );
	}

	/**
	 * Return a stable money transport value.
	 *
	 * @param int    $amount_minor Amount in minor units.
	 * @param string $currency     ISO currency code.
	 * @return array{amount:int,currency:string} Money transport value.
	 */
    
	public static function money( int $amount_minor, string $currency ): array {
		return array(
			'amount'   => $amount_minor,
			'currency' => strtoupper( sanitize_key( $currency ) ),
		);
	}
}
