<?php

/** Passive operational status for Commerce reporting. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Aggregate passive health, storage, backfill, and reconciliation diagnostics.
 */

final class WPHAVE_Commerce_Reporting_Diagnostics {
	private WPHAVE_Commerce_Reporting_Repository $repository;
	private WPHAVE_Commerce_Reporting_Backfill $backfill;
	private WPHAVE_Commerce_Reporting_Reconciliation $reconciliation;

	/**
	 * Create the diagnostics aggregator.
	 *
	 * @param WPHAVE_Commerce_Reporting_Repository     $repository     Event repository.
	 * @param WPHAVE_Commerce_Reporting_Backfill       $backfill       Backfill coordinator.
	 * @param WPHAVE_Commerce_Reporting_Reconciliation $reconciliation Reconciliation service.
	 */

	public function __construct( WPHAVE_Commerce_Reporting_Repository $repository, WPHAVE_Commerce_Reporting_Backfill $backfill, WPHAVE_Commerce_Reporting_Reconciliation $reconciliation ) {
		$this->repository = $repository;
		$this->backfill = $backfill;
		$this->reconciliation = $reconciliation;
	}

	/**
	 * Return a passive operational snapshot.
	 *
	 * @param bool $include_reconciliation Whether to perform the bounded reconciliation check.
	 * @return array<string,mixed> Reporting health snapshot.
	 */
    
	public function snapshot( bool $include_reconciliation = false ): array {
		$backfill = $this->backfill->state();
		$storage = $this->repository->diagnostics();
		$state = match ( $backfill['status'] ) {
			'complete' => $storage['available'] ? 'ready' : 'degraded',
			'degraded' => 'degraded',
			'running', 'scheduled' => 'backfillRunning',
			default => 'initializing',
		};
		$result = array(
			'state'         => $state,
			'schemaVersion' => WPHAVE_Commerce_Reporting_Schema::DB_VERSION,
			'backfill'      => $backfill,
			'storage'       => $storage,
		);
		if ( $include_reconciliation && 'ready' === $state ) {
			$result['reconciliation'] = $this->reconciliation->compare( 30 );
		}

		return $result;
	}
}
