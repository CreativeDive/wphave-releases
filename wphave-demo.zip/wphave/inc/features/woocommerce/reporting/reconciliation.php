<?php

/** Compare Commerce event projections with canonical WooCommerce order facts. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Reconcile normalized reporting projections against canonical WooCommerce facts.
 */

final class WPHAVE_Commerce_Reporting_Reconciliation {
	const MAX_ORDERS = 1000;

	private WPHAVE_Commerce_Reporting_Provider $provider;

	/**
	 * Create the reconciliation service.
	 *
	 * @param WPHAVE_Commerce_Reporting_Provider $provider Reporting projection provider.
	 */

	public function __construct( WPHAVE_Commerce_Reporting_Provider $provider ) {
		$this->provider = $provider;
	}

	/**
	 * Compare a bounded reporting window with canonical WooCommerce orders.
	 *
	 * @param int $days Number of days to compare.
	 * @return array<string,mixed> Reconciliation status and differences.
	 */

	public function compare( int $days = 30 ): array {
		$days = max( 1, min( 366, $days ) );
		$from_timestamp = strtotime( gmdate( 'Y-m-d 00:00:00', time() - ( ( $days - 1 ) * DAY_IN_SECONDS ) ) . ' UTC' );
		$to_timestamp = strtotime( gmdate( 'Y-m-d 23:59:59' ) . ' UTC' );
		$orders = wc_get_orders(
			array(
				'limit'        => self::MAX_ORDERS + 1,
				'type'         => 'shop_order',
				'orderby'      => 'date',
				'order'        => 'DESC',
				'return'       => 'objects',
			)
		);
		$truncated = count( $orders ) > self::MAX_ORDERS;
		$orders = array_slice( $orders, 0, self::MAX_ORDERS );
		$currency = function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : '';
		$canonical = array( 'recognizedRevenue' => 0, 'refunds' => 0, 'orders' => 0 );

		foreach ( $orders as $order ) {
			if ( ! $order instanceof WC_Order || $currency !== $order->get_currency() ) {
				continue;
			}
			$created = $order->get_date_created();
			$paid = $order->get_date_paid();
			$completed = $order->get_date_completed();
			if ( $this->date_in_range( $created, $from_timestamp, $to_timestamp ) ) {
				++$canonical['orders'];
			}
			if ( $this->date_in_range( $paid, $from_timestamp, $to_timestamp ) || ( ! $paid && $this->date_in_range( $completed, $from_timestamp, $to_timestamp ) ) ) {
				$canonical['recognizedRevenue'] += WPHAVE_Commerce_Reporting_Contracts::money_to_minor( $order->get_total(), $currency );
			}
			foreach ( $order->get_refunds() as $refund ) {
				if ( $this->date_in_range( $refund->get_date_created(), $from_timestamp, $to_timestamp ) ) {
					$canonical['refunds'] += WPHAVE_Commerce_Reporting_Contracts::money_to_minor( abs( (float) $refund->get_amount() ), $currency );
				}
			}
		}
		$canonical['recognizedRevenue'] -= $canonical['refunds'];
		$request = new WP_REST_Request( 'GET', '/wphave/v1/analytics/conversion-events' );
		$request->set_param( 'days', $days );
		$projection = $this->provider->conversion_projection( array(), $request )['commerce'] ?? array();
		$reported = array_intersect_key( (array) ( $projection['metrics'] ?? array() ), $canonical );
		$difference = array();
		foreach ( $canonical as $key => $value ) {
			$difference[ $key ] = (int) ( $reported[ $key ] ?? 0 ) - $value;
		}

		return array(
			'status'     => $truncated ? 'incomplete' : ( array_filter( $difference ) ? 'mismatch' : 'matched' ),
			'days'       => $days,
			'currency'   => $currency,
			'canonical'  => $canonical,
			'reported'   => $reported,
			'difference' => $difference,
			'truncated'  => $truncated,
		);
	}

	/**
	 * Determine whether a WooCommerce date is inside an inclusive range.
	 *
	 * @param mixed $date WooCommerce date value.
	 * @param int   $from Inclusive start timestamp.
	 * @param int   $to   Inclusive end timestamp.
	 * @return bool Whether the date is in range.
	 */
    
	private function date_in_range( $date, int $from, int $to ): bool {
		return $date instanceof WC_DateTime && $date->getTimestamp() >= $from && $date->getTimestamp() <= $to;
	}
}
