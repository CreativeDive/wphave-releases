<?php

/** Bootstrap the feature-gated Commerce reporting provider. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once dirname( __DIR__ ) . '/woocommerce.php';

// INTEGRATION INVARIANT: Commerce reporting owns WooCommerce-derived data and
// must not register schemas, workers, providers, or routes without its source system.
if ( ! WPHAVE_WooCommerce::is_active() ) {
	return;
}

if ( ! function_exists( 'wphave_release_feature_ready' ) || ! wphave_release_feature_ready( 'commerceReporting' ) ) {
	return;
}

require_once wphave_dir() . 'inc/background-jobs/functions.php';
require_once __DIR__ . '/contracts.php';
require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/repository.php';
require_once __DIR__ . '/events.php';
require_once __DIR__ . '/provider.php';
require_once __DIR__ . '/backfill.php';
require_once __DIR__ . '/reconciliation.php';
require_once __DIR__ . '/diagnostics.php';
require_once __DIR__ . '/privacy.php';
require_once __DIR__ . '/rest-controller.php';

require_once __DIR__ . '/schema-registration.php';

if ( ! WPHAVE_Database_Schema_Manager::runtime_compatible( 'commerce-reporting' ) ) {
	return;
}

$wphave_commerce_reporting_repository = new WPHAVE_Commerce_Reporting_Repository();
$wphave_commerce_reporting_events = new WPHAVE_Commerce_Reporting_Events( $wphave_commerce_reporting_repository );
$wphave_commerce_reporting_provider = new WPHAVE_Commerce_Reporting_Provider( $wphave_commerce_reporting_repository );
$wphave_commerce_reporting_backfill = new WPHAVE_Commerce_Reporting_Backfill( $wphave_commerce_reporting_events );
$wphave_commerce_reporting_reconciliation = new WPHAVE_Commerce_Reporting_Reconciliation( $wphave_commerce_reporting_provider );
$wphave_commerce_reporting_diagnostics = new WPHAVE_Commerce_Reporting_Diagnostics( $wphave_commerce_reporting_repository, $wphave_commerce_reporting_backfill, $wphave_commerce_reporting_reconciliation );
$wphave_commerce_reporting_privacy = new WPHAVE_Commerce_Reporting_Privacy( $wphave_commerce_reporting_repository );
$wphave_commerce_reporting_rest = new WPHAVE_Commerce_Reporting_REST_Controller( $wphave_commerce_reporting_backfill, $wphave_commerce_reporting_diagnostics );

add_filter(
	'wphave_system_info_provider_data',
	static function ( array $providers ) use ( $wphave_commerce_reporting_diagnostics ): array {
		$providers['commerce'] = $wphave_commerce_reporting_diagnostics->snapshot( false );
		return $providers;
	}
);

$wphave_commerce_reporting_events->register();
$wphave_commerce_reporting_provider->register();
$wphave_commerce_reporting_backfill->register();
$wphave_commerce_reporting_privacy->register();
$wphave_commerce_reporting_rest->register();

add_action(
	'init',
	static function () use ( $wphave_commerce_reporting_backfill ) {
		if ( 'idle' === $wphave_commerce_reporting_backfill->state()['status'] ) {
			$wphave_commerce_reporting_backfill->schedule();
		}
	},
	30
);
