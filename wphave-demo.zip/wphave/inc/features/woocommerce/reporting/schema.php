<?php

/** Commerce reporting schema owned by the Commerce module. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Own installation and validation of the Commerce reporting event schema.
 */

final class WPHAVE_Commerce_Reporting_Schema {
	const DB_VERSION = '1.1.0';
	const TABLE = 'wphave_commerce_events';

	/**
	 * Return the site-prefixed Commerce event table name.
	 *
	 * @return string Database table name.
	 */

	public static function table(): string {
		global $wpdb;

		return $wpdb->prefix . self::TABLE;
	}

	/**
	 * Install or upgrade the normalized Commerce event schema.
	 *
	 * @return void
	 */

	public static function install(): void {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table = self::table();
		$charset = $wpdb->get_charset_collate();
		$sql = "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			event_key char(64) NOT NULL,
			event_name varchar(80) NOT NULL,
			subject_type varchar(30) NOT NULL,
			subject_id bigint(20) unsigned NOT NULL DEFAULT 0,
			order_id bigint(20) unsigned NOT NULL DEFAULT 0,
			occurred_at datetime NOT NULL,
			amount_minor bigint(20) NOT NULL DEFAULT 0,
			gross_minor bigint(20) NOT NULL DEFAULT 0,
			tax_minor bigint(20) NOT NULL DEFAULT 0,
			shipping_minor bigint(20) NOT NULL DEFAULT 0,
			discount_minor bigint(20) NOT NULL DEFAULT 0,
			units bigint(20) unsigned NOT NULL DEFAULT 0,
			currency char(3) NOT NULL DEFAULT '',
			customer_hash char(64) NOT NULL DEFAULT '',
			session_hash char(64) NOT NULL DEFAULT '',
			source varchar(100) NOT NULL DEFAULT '',
			medium varchar(100) NOT NULL DEFAULT '',
			campaign varchar(150) NOT NULL DEFAULT '',
			dimensions_json longtext DEFAULT NULL,
			is_backfill tinyint(1) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY event_key (event_key),
			KEY event_date (event_name, occurred_at),
			KEY order_event (order_id, event_name),
			KEY subject_date (subject_type, subject_id, occurred_at),
			KEY customer_hash (customer_hash),
			KEY campaign_date (campaign, occurred_at)
		) {$charset};";

		dbDelta( $sql );
	}

	/**
	 * Validate that normalized Commerce event storage is available.
	 *
	 * @return bool Whether the schema is ready.
	 */
    
	public static function validate(): bool {
		return class_exists( 'WPHAVE_Database_Metadata' )
			&& WPHAVE_Database_Metadata::table_exists( self::table(), true );
	}
}
