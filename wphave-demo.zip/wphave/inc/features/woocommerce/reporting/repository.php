<?php

/** Idempotent persistence and queries for normalized Commerce events. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Persist and query normalized Commerce events without leaking storage details.
 */

final class WPHAVE_Commerce_Reporting_Repository {
	const CLEANUP_BATCH_SIZE = 500;

	/**
	 * Return passive storage diagnostics without mutating repository state.
	 *
	 * @return array<string,mixed> Storage availability and event bounds.
	 */

	public function diagnostics(): array {
		if ( ! $this->exists() ) {
			return array( 'available' => false, 'events' => 0, 'oldestEvent' => '', 'newestEvent' => '' );
		}

		global $wpdb;
		$table = WPHAVE_Commerce_Reporting_Schema::table();
		$row = $wpdb->get_row( "SELECT COUNT(*) events, MIN(occurred_at) oldest_event, MAX(occurred_at) newest_event FROM {$table}", ARRAY_A );

		return array(
			'available'   => true,
			'events'      => absint( $row['events'] ?? 0 ),
			'oldestEvent' => sanitize_text_field( $row['oldest_event'] ?? '' ),
			'newestEvent' => sanitize_text_field( $row['newest_event'] ?? '' ),
		);
	}

	/**
	 * Determine whether the reporting table exists.
	 *
	 * @return bool Whether normalized event storage is available.
	 */

	public function exists(): bool {
		return class_exists( 'WPHAVE_Database_Metadata' )
			&& WPHAVE_Database_Metadata::table_exists( WPHAVE_Commerce_Reporting_Schema::table() );
	}

	/**
	 * Persist a normalized event once.
	 *
	 * @param array $event Normalized Commerce event.
	 * @return bool Whether a new row was inserted.
	 */

	public function insert( array $event ): bool {
		if ( ! $this->exists() ) {
			return false;
		}

		global $wpdb;
		$dimensions = is_array( $event['dimensions'] ?? null ) ? $event['dimensions'] : array();
		$data = array(
			'event_key'       => (string) $event['eventKey'],
			'event_name'      => (string) $event['name'],
			'subject_type'    => sanitize_key( $event['subjectType'] ?? 'order' ),
			'subject_id'      => absint( $event['subjectId'] ?? 0 ),
			'order_id'        => absint( $event['orderId'] ?? 0 ),
			'occurred_at'     => gmdate( 'Y-m-d H:i:s', (int) ( $event['occurredAt'] ?? time() ) ),
			'amount_minor'    => (int) ( $event['amountMinor'] ?? 0 ),
			'gross_minor'     => (int) ( $dimensions['grossMinor'] ?? 0 ),
			'tax_minor'       => (int) ( $dimensions['taxMinor'] ?? 0 ),
			'shipping_minor'  => (int) ( $dimensions['shippingMinor'] ?? 0 ),
			'discount_minor'  => (int) ( $dimensions['discountMinor'] ?? 0 ),
			'units'           => absint( $dimensions['units'] ?? 0 ),
			'currency'        => strtoupper( substr( sanitize_key( $event['currency'] ?? '' ), 0, 3 ) ),
			'customer_hash'   => (string) ( $event['customerHash'] ?? '' ),
			'session_hash'    => (string) ( $event['sessionHash'] ?? '' ),
			'source'          => sanitize_text_field( $event['attribution']['source'] ?? '' ),
			'medium'          => sanitize_text_field( $event['attribution']['medium'] ?? '' ),
			'campaign'        => sanitize_text_field( $event['attribution']['campaign'] ?? '' ),
			'dimensions_json' => wp_json_encode( $dimensions ),
			'is_backfill'     => empty( $event['isBackfill'] ) ? 0 : 1,
			'created_at'      => current_time( 'mysql', true ),
		);

		$previous = $wpdb->suppress_errors();
		$inserted = $wpdb->insert(
			WPHAVE_Commerce_Reporting_Schema::table(),
			$data,
			array( '%s', '%s', '%s', '%d', '%d', '%s', '%d', '%d', '%d', '%d', '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s' )
		);
		$wpdb->suppress_errors( $previous );
		if ( false === $inserted && ! empty( $event['isBackfill'] ) ) {
			$this->refresh_backfill_event( $data );
		}

		return (bool) $inserted;
	}

	/**
	 * Refresh derived columns during a versioned backfill without creating another event.
	 *
	 * @param array $data Sanitized database row.
	 * @return void
	 */

	private function refresh_backfill_event( array $data ): void {
		global $wpdb;
		$event_key = $data['event_key'];
		unset( $data['event_key'], $data['created_at'] );
		$data['is_backfill'] = 1;

		$wpdb->update(
			WPHAVE_Commerce_Reporting_Schema::table(),
			$data,
			array( 'event_key' => $event_key )
		);
	}

	/**
	 * Delete expired pseudonymous events in a bounded batch.
	 *
	 * @param int $days Retention period in days.
	 * @return int|null Number of deleted rows, or null after a database failure.
	 */

	public function cleanup( int $days = 760 ): ?int {
		if ( ! $this->exists() ) {
			return null;
		}

		global $wpdb;
		$table = WPHAVE_Commerce_Reporting_Schema::table();
		$boundary = gmdate( 'Y-m-d H:i:s', time() - ( max( 30, $days ) * DAY_IN_SECONDS ) );
		$wpdb->last_error = '';
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT id FROM {$table} WHERE occurred_at < %s ORDER BY id ASC LIMIT %d",
				$boundary,
				self::CLEANUP_BATCH_SIZE
			)
		);

		// RESILIENCE INVARIANT: A failed candidate read is not an empty batch.
		// The worker must retry instead of falsely reporting completed retention.
		if ( null === $ids || $wpdb->last_error ) {
			return null;
		}

		if ( ! $ids ) {
			return 0;
		}

		$ids = array_filter( array_map( 'absint', $ids ) );
		if ( ! $ids ) {
			return 0;
		}

		// DATA-INTEGRITY INVARIANT: Revalidate expiry in the destructive query.
		// A stale candidate set must never delete an event whose date changed.
		$deleted = $wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$table} WHERE id IN (" . implode( ',', $ids ) . ') AND occurred_at < %s',
				$boundary
			)
		);

		return false === $deleted ? null : (int) $deleted;
	}

	/**
	 * Erase pseudonymous customer links without deleting aggregate business facts.
	 *
	 * @param string $customer_hash Salted customer hash.
	 * @return bool Whether the anonymization update succeeded.
	 */

	public function erase_customer( string $customer_hash ): bool {
		if ( ! $this->exists() || ! preg_match( '/^[a-f0-9]{64}$/', $customer_hash ) ) {
			return false;
		}

		global $wpdb;
		return false !== $wpdb->update(
			WPHAVE_Commerce_Reporting_Schema::table(),
			array( 'customer_hash' => '' ),
			array( 'customer_hash' => $customer_hash ),
			array( '%s' ),
			array( '%s' )
		);
	}

	/**
	 * Return bounded non-sensitive event facts linked to one customer hash.
	 *
	 * @param string $customer_hash Salted customer hash.
	 * @param int    $offset        Query offset.
	 * @return array<int,array<string,mixed>> Event facts.
	 */
    
	public function customer_events( string $customer_hash, int $offset = 0 ): array {
		if ( ! $this->exists() || ! preg_match( '/^[a-f0-9]{64}$/', $customer_hash ) ) {
			return array();
		}

		global $wpdb;
		$table = WPHAVE_Commerce_Reporting_Schema::table();

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, event_name, order_id, occurred_at, amount_minor, currency FROM {$table} WHERE customer_hash = %s ORDER BY id ASC LIMIT 100 OFFSET %d",
				$customer_hash,
				max( 0, $offset )
			),
			ARRAY_A
		) ?: array();
	}
}
