<?php

/** Privacy and retention integration for Commerce reporting. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Integrate Commerce reporting with WPHAVE retention, export, and erasure workflows.
 */

final class WPHAVE_Commerce_Reporting_Privacy {
	const RETENTION_DAYS = 760;
	const RETENTION_HOOK = 'wphave_commerce_reporting_retention';
	const RETENTION_CONTINUATION_HOOK = 'wphave_commerce_reporting_retention_continuation';
	const RETENTION_SCHEDULE_OPTION = 'wphave_commerce_reporting_retention_schedule';

	private WPHAVE_Commerce_Reporting_Repository $repository;

	/**
	 * Create the privacy integration.
	 *
	 * @param WPHAVE_Commerce_Reporting_Repository $repository Event repository.
	 */

	public function __construct( WPHAVE_Commerce_Reporting_Repository $repository ) {
		$this->repository = $repository;
	}

	/**
	 * Register privacy integration after the shared manager is available.
	 *
	 * @return void
	 */

	public function register(): void {
		add_action( self::RETENTION_HOOK, array( $this, 'cleanup' ) );
		add_action( self::RETENTION_CONTINUATION_HOOK, array( $this, 'cleanup' ) );

		if ( did_action( 'init' ) ) {
			$this->register_with_manager();
			$this->schedule_cleanup();
			return;
		}

		add_action( 'init', array( $this, 'register_with_manager' ), 20 );
		add_action( 'init', array( $this, 'schedule_cleanup' ), 30 );
	}

	/**
	 * Ensure the feature-owned daily retention worker exists.
	 *
	 * @return void
	 */

	public function schedule_cleanup(): void {
		// DATA-MINIMIZATION INVARIANT: Customer-linked reporting facts must have
		// exactly one fixed-duration retention owner. Reconcile legacy drift and
		// duplicates rather than inheriting a schedule that may retain data longer.
		WPHAVE_Background_Job_Scheduler::sync_recurring(
			self::RETENTION_HOOK,
			self::RETENTION_SCHEDULE_OPTION,
			true,
			'daily',
			time() + HOUR_IN_SECONDS,
			'commerce-reporting-retention-v1'
		);
	}

	/**
	 * Register retention, erasure, and export callbacks with WPHAVE privacy.
	 *
	 * @return void
	 */

	public function register_with_manager(): void {
		if ( ! class_exists( 'WPHAVE_Privacy_Manager' ) ) {
			return;
		}

		WPHAVE_Privacy_Manager::register_retention_policy(
			array(
				'id'             => 'commerce-reporting-retention',
				'label'          => __( 'Commerce reporting events', 'wphave' ),
				'retention_days' => self::RETENTION_DAYS,
				'callback'       => array( $this, 'cleanup' ),
			)
		);
		WPHAVE_Privacy_Manager::register_eraser(
			'wphave-commerce-reporting',
			__( 'WPHAVE Commerce reporting', 'wphave' ),
			array( $this, 'erase' )
		);
		WPHAVE_Privacy_Manager::register_exporter(
			'wphave-commerce-reporting',
			__( 'WPHAVE Commerce reporting', 'wphave' ),
			array( $this, 'export' )
		);
	}

	/**
	 * Apply the Commerce reporting retention policy.
	 *
	 * @return bool Whether the bounded cleanup attempt completed successfully.
	 */

	public function cleanup(): bool {
		$deleted = $this->repository->cleanup( self::RETENTION_DAYS );

		if ( null === $deleted ) {
			$this->schedule_continuation( 15 * MINUTE_IN_SECONDS );
			return false;
		}

		if ( WPHAVE_Commerce_Reporting_Repository::CLEANUP_BATCH_SIZE === $deleted ) {
			$this->schedule_continuation( 5 * MINUTE_IN_SECONDS );
		}

		return true;
	}

	/**
	 * Schedule one bounded follow-up without allowing a retry storm.
	 *
	 * @param int $delay Delay in seconds.
	 * @return bool Whether a continuation exists or was scheduled.
	 */

	private function schedule_continuation( int $delay ): bool {
		return WPHAVE_Background_Job_Scheduler::ensure_continuation(
			self::RETENTION_CONTINUATION_HOOK,
			array(),
			max( MINUTE_IN_SECONDS, $delay )
		);
	}

	/**
	 * Remove customer links while retaining anonymous aggregate facts.
	 *
	 * @param string $email_address Customer email address.
	 * @param int    $page          Eraser page requested by WordPress.
	 * @return array<string,mixed> WordPress eraser result.
	 */

	public function erase( string $email_address, int $page = 1 ): array {
		$email = sanitize_email( strtolower( $email_address ) );
		$user = get_user_by( 'email', $email );
		$hashes = array( hash_hmac( 'sha256', 'email:' . $email, wp_salt( 'auth' ) ) );

		if ( $user instanceof WP_User ) {
			$hashes[] = hash_hmac( 'sha256', 'user:' . $user->ID, wp_salt( 'auth' ) );
		}

		$removed = false;
		foreach ( array_unique( $hashes ) as $hash ) {
			$removed = $this->repository->erase_customer( $hash ) || $removed;
		}

		return array(
			'items_removed'  => $removed,
			'items_retained' => true,
			'messages'       => array( __( 'Aggregate Commerce business facts were retained without the customer link.', 'wphave' ) ),
			'done'           => true,
		);
	}

	/**
	 * Export bounded Commerce reporting facts linked to a customer.
	 *
	 * @param string $email_address Customer email address.
	 * @param int    $page          Export page requested by WordPress.
	 * @return array<string,mixed> WordPress exporter result.
	 */

	public function export( string $email_address, int $page = 1 ): array {
		$hashes = $this->customer_hashes( $email_address );
		$rows = array();

		foreach ( $hashes as $hash ) {
			$rows = array_merge( $rows, $this->repository->customer_events( $hash, ( max( 1, $page ) - 1 ) * 100 ) );
		}

		$data = array_map(
			static function ( array $row ): array {
				return array(
					'group_id'    => 'wphave-commerce-reporting',
					'group_label' => __( 'WPHAVE Commerce reporting', 'wphave' ),
					'item_id'     => 'commerce-event-' . absint( $row['id'] ?? 0 ),
					'data'        => array(
						array( 'name' => __( 'Event', 'wphave' ), 'value' => (string) ( $row['event_name'] ?? '' ) ),
						array( 'name' => __( 'Order ID', 'wphave' ), 'value' => (string) absint( $row['order_id'] ?? 0 ) ),
						array( 'name' => __( 'Occurred at', 'wphave' ), 'value' => (string) ( $row['occurred_at'] ?? '' ) ),
					),
				);
			},
			$rows
		);

		return array( 'data' => $data, 'done' => count( $rows ) < 100 );
	}

	/**
	 * Resolve all supported pseudonymous hashes for an email address.
	 *
	 * @param string $email_address Customer email address.
	 * @return string[] Unique customer hashes.
	 */
    
	private function customer_hashes( string $email_address ): array {
		$email = sanitize_email( strtolower( $email_address ) );
		$user = get_user_by( 'email', $email );
		$hashes = array( hash_hmac( 'sha256', 'email:' . $email, wp_salt( 'auth' ) ) );

		if ( $user instanceof WP_User ) {
			$hashes[] = hash_hmac( 'sha256', 'user:' . $user->ID, wp_salt( 'auth' ) );
		}

		return array_unique( $hashes );
	}
}
