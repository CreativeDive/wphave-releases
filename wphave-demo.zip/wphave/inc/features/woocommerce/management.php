<?php

/**
 * Load the WooCommerce management adapter for WPHAVE administration requests.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/woocommerce.php';
require_once __DIR__ . '/reporting/bootstrap.php';
require_once __DIR__ . '/rest-controller.php';

WPHAVE_WooCommerce_REST_Controller::init();
