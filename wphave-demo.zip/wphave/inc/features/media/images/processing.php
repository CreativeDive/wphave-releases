<?php

if (!defined('ABSPATH')) {
	exit();
}

/**
 * Function to set the image optimization pipeline.
 */

if (!function_exists('wphave_optimize_image')):
	function wphave_optimize_image($file, $args = []) {
		$changes = [];
		$args = wp_parse_args($args, [
			'delete_original' => true,
			'force_reencode' => false,
		]);

		if (!file_exists($file)) {
			return $file;
		}
		try {
			$original_identity = WPHAVE_Security_File_Identity::inspect(
				$file,
				__('The original image could not be inspected safely.', 'wphave'),
			);
		} catch (RuntimeException $error) {
			return $file;
		}

		$type = wp_get_image_mime($file);

		// Process images only !
		// Skip GIF "image/gif" to preserve animation
		if (!in_array($type, ['image/jpeg', 'image/png'], true)) {
			// Bail early !
			return $file;
		}

		$image = wp_get_image_editor($file);

		if (is_wp_error($image)) {
			return $file;
		}

		$size_limit = wphave_data_get('site_settings', 'general.media.image_max_size', 'no');
		$max_width =
			$size_limit === 'limit'
				? (int) wphave_data_get('site_settings', 'general.media.image_max_width')
				: 0;
		$size = $image->get_size();

		$needs_resize = false;

		if ($max_width && $size['width'] > $max_width) {
			$image->resize($max_width, null); // proportional
			$changes[] = "resized: {$size['width']}px → {$max_width}px";
			$needs_resize = true;
		}

		$format = wphave_data_get('site_settings', 'general.media.image_file_format');

		$target_mime = $type;

		if ($format !== 'default') {
			$preferred_mime = wphave_get_preferred_image_mime($format);

			if ($preferred_mime) {
				if ($type === 'image/png' && wphave_png_has_transparency($image, $file)) {
					$target_mime = $type; // Keep transparent PNGs lossless.
				} else {
					$target_mime = $preferred_mime;
				}
			}
		}

		if ($target_mime !== $type) {
			$changes[] = "converted: {$type} → {$target_mime}";
		}

		$needs_reencode = !empty($args['force_reencode']) || $type === 'image/png';
		$needs_format_change = $target_mime !== $type;

		if (!$needs_format_change && !$needs_resize && !$needs_reencode) {
			return $file;
		}

		$quality = wphave_data_get('site_settings', 'general.media.image_compression') ?: 82;
		$quality = (int) str_replace('%', '', $quality);

		$image->set_quality($quality);
		$changes[] = "compressed: {$quality}%";

		if ($image instanceof WP_Image_Editor_Imagick) {
			if (isset($image->image) && $image->image instanceof Imagick) {
				$image->image->stripImage();
				$changes[] = 'metadata removed';
			}
		}

		$extension_map = [
			'image/jpeg' => '.jpg',
			'image/png' => '.png',
			'image/webp' => '.webp',
			'image/avif' => '.avif',
		];

		$new_file = $file;

		if ($target_mime !== $type) {
			$new_file = preg_replace('/\.(jpe?g|png)$/i', $extension_map[$target_mime], $file);
			if (!is_string($new_file) || $new_file === $file) {
				return $file;
			}
			// CONVERSION INVARIANT: An existing sibling with the target extension
			// may belong to a different attachment. Reserve a distinct name, then
			// enforce create-only publication below even if allocation races.
			$new_file = trailingslashit(dirname($new_file)) . wp_unique_filename(
				dirname($new_file),
				basename($new_file),
			);
		}

		if ($target_mime === 'image/png') {
			// Imagick (best)
			if ($image instanceof WP_Image_Editor_Imagick) {
				if (isset($image->image) && $image->image instanceof Imagick) {
					$image->image->setOption('png:compression-level', '9');
					$image->image->setOption('png:compression-filter', '5');
					$changes[] = 'png optimized (Imagick)';
				}

				// GD fallback
			} elseif ($image instanceof WP_Image_Editor_GD) {
				if (isset($image->image)) {
					$changes[] = 'png optimized (GD)';
				}
			}
		}

		$temp_file =
			trailingslashit(dirname($new_file)) .
			'.wphave-' .
			wp_generate_uuid4() .
			$extension_map[$target_mime];
		$result = $image->save($temp_file, $target_mime);

		if (is_wp_error($result) || !file_exists($temp_file) || filesize($temp_file) <= 0) {
			if (file_exists($temp_file)) {
				unlink($temp_file);
			}

			return $file;
		}

		if (!wphave_replace_image_file($temp_file, $new_file, $target_mime !== $type)) {
			return $file;
		}

		if (
			!empty($args['delete_original']) &&
			$new_file !== $file &&
			file_exists($file) &&
			file_exists($new_file)
		) {
			try {
				$published_identity = WPHAVE_Security_File_Identity::inspect(
					$new_file,
					__('The optimized image output could not be verified.', 'wphave'),
				);
				if ($published_identity['bytes'] <= 0) {
					return $file;
				}

				// SECURITY INVARIANT: Format conversion deletes only the exact original
				// revision observed before processing. A concurrent rewrite survives and
				// both formats remain available for explicit reconciliation.
				WPHAVE_Security_Conditional_File::remove_if_matches(
					$file,
					$original_identity['checksum'],
					__('The original image changed before conversion cleanup.', 'wphave'),
				);
			} catch (RuntimeException $error) {
				// The optimized output is already valid and published. Preserve any
				// unproven original rather than turning cleanup conflict into data loss.
			}
		}

		$GLOBALS['wphave_image_log'][] = [
			'file' => $new_file,
			'changes' => $changes,
		];

		return $new_file;
	}
endif;

/**
 * Replace an image file.
 *
 * @param string $source
 * @param string $destination
 * @return bool
 */

if (!function_exists('wphave_replace_image_file')):
	function wphave_replace_image_file($source, $destination, $create_only = false) {
		try {
			$source_identity = WPHAVE_Security_File_Identity::inspect(
				$source,
				__('The processed image source could not be inspected safely.', 'wphave'),
			);
		} catch (RuntimeException $error) {
			return false;
		}

		if ($source_identity['bytes'] <= 0 || $source === $destination) {
			return false;
		}

		// SECURITY INVARIANT: Upload and regeneration preserve only the verified
		// WordPress editor output's read/write permissions, never executable bits.
		// The editor derives these from the upload directory; do not widen them to
		// a hardcoded public mode or change the shared primitives' private defaults.
		// PUBLICATION INVARIANT: Atomic publication must retain these permissions
		// so a separate webserver user can still serve the generated thumbnails.
		$permissions = WPHAVE_Security_File_Permissions::existing($source_identity);

		try {
			if (!$create_only && (file_exists($destination) || is_link($destination))) {
				$destination_identity = WPHAVE_Security_File_Identity::inspect(
					$destination,
					__('The current image destination could not be inspected safely.', 'wphave'),
				);

				// SECURITY INVARIANT: Replacing an image targets the exact destination
				// revision observed here. A concurrent path replacement is preserved.
				WPHAVE_Security_Conditional_File::replace_if_matches(
					$destination,
					$destination_identity['checksum'],
					$source,
					$source_identity['checksum'],
					__('The image destination changed before publication.', 'wphave'),
					$permissions,
					WPHAVE_Security_File_Permissions::recorded_group(
						$source_identity['group'] ?? null,
					),
				);
			} else {
				WPHAVE_Security_Atomic_File::copy_verified_new(
					$source,
					$destination,
					$source_identity['checksum'],
					__('The processed image could not be published safely.', 'wphave'),
					$permissions,
					WPHAVE_Security_File_Permissions::recorded_group(
						$source_identity['group'] ?? null,
					),
				);
			}
		} catch (RuntimeException $error) {
			return false;
		}

		try {
			WPHAVE_Security_Conditional_File::remove_if_matches(
				$source,
				$source_identity['checksum'],
				__('Processed image staging could not be cleaned up safely.', 'wphave'),
			);
		} catch (RuntimeException $error) {
			// Publication already committed. Preserve an unproven staging node rather
			// than reporting that the live destination failed or deleting foreign data.
		}

		return true;
	}
endif;

/**
 * Filter to run optimizations for uploaded images.
 */

if (!function_exists('wphave_process_uploaded_image')):
	function wphave_process_uploaded_image($upload) {
		$optimize_on_upload = wphave_data_get(
			'site_settings',
			'general.media.image_optimize_on_upload',
		);

		// Default: OFF (safe)
		$optimize_on_upload = $optimize_on_upload === null ? false : (bool) $optimize_on_upload;

		// No automatic image optimization for original uploaded images by default!
		// Only optimize uploaded images if set by the user!
		if (!$optimize_on_upload) {
			// Bail early !
			return $upload;
		}

		$old_file = $upload['file'];
		$new_file = wphave_optimize_image($old_file);

		if ($new_file !== $old_file && file_exists($new_file)) {
			$upload['file'] = $new_file;
			$upload['type'] = wp_get_image_mime($new_file);
			$upload['url'] = dirname($upload['url']) . '/' . basename($new_file);
		}

		return $upload;
	}
endif;

add_filter('wp_handle_upload', 'wphave_process_uploaded_image');

/**
 * Filter to run optimizations for regenerated image sizes.
 */

if (!function_exists('wphave_process_regenerated_image')):
	function wphave_process_regenerated_image($metadata, $attachment_id) {
		// Safety Guard
		static $processed = [];

		if (isset($processed[$attachment_id])) {
			return $metadata;
		}

		$processed[$attachment_id] = true;

		if (empty($metadata['sizes'])) {
			return $metadata;
		}

		$original = get_attached_file($attachment_id);

		if (!$original) {
			/* ! --> IMPORTANT: Do not modify the ORIGINAL image. */

			return $metadata;
		}

		$dir = trailingslashit(dirname($original));

		$attachment_log = [];

		// Regenerate images sizes ONLY!
		foreach ($metadata['sizes'] as $size => $data) {
			if (empty($data['file'])) {
				continue;
			}

			$file_path = $dir . $data['file'];

			if (!file_exists($file_path)) {
				continue;
			}

			// Reset per file log
			$before = count($GLOBALS['wphave_image_log'] ?? []);

			$result = wphave_optimize_image($file_path, [
				'delete_original' => empty($GLOBALS['wphave_is_regenerating_images']),
				'force_reencode' => !empty($GLOBALS['wphave_is_regenerating_images']),
			]);

			$after = $GLOBALS['wphave_image_log'] ?? [];

			// Neue Logs extrahieren
			$new_logs = array_slice($after, $before);

			foreach ($new_logs as $log) {
				$attachment_log[] = [
					'size' => $size,
					'file' => basename($log['file']),
					'changes' => $log['changes'],
				];
			}

			if ($result !== $file_path) {
				$metadata['sizes'][$size]['file'] = basename($result);
				$metadata['sizes'][$size]['mime-type'] = wp_get_image_mime($result);
			}

			if (file_exists($result)) {
				$metadata['sizes'][$size]['filesize'] = filesize($result);
			}
		}

		if (!empty($attachment_log)) {
			$GLOBALS['wphave_image_log_grouped'][$attachment_id] = [
				'id' => $attachment_id,
				'name' => get_the_title($attachment_id),
				'sizes' => $attachment_log,
			];
		}

		return $metadata;
	}
endif;

add_filter('wp_generate_attachment_metadata', 'wphave_process_regenerated_image', 10, 2);
