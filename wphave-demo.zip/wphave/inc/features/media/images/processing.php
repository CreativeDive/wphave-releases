<?php

if (!defined('ABSPATH')) {
	exit();
}

require_once __DIR__ . '/size-file-identity.php';
require_once __DIR__ . '/source-gate.php';
require_once dirname(__DIR__) . '/attachments/file-registration.php';

/**
 * Function to set the image optimization pipeline.
 */

if (!function_exists('wphave_optimize_image')):
	function wphave_optimize_image($file, $args = []) {
		$changes = [];
		$args = wp_parse_args($args, [
			'delete_original' => true,
			'force_reencode' => false,
		]);

		if (!file_exists($file)) {
			return $file;
		}
		clearstatcache(true, $file);
		$source_bytes = filesize($file);
		// RESOURCE INVARIANT: Reject an oversized source before hashing its
		// contents or calling any image header parser or decoder.
		if (
			!is_int($source_bytes) ||
			$source_bytes < 1 ||
			$source_bytes > WPHAVE_Media_Image_Source_Gate::MAX_BYTES
		) {
			return $file;
		}
		try {
			$original_identity = WPHAVE_Security_File_Identity::inspect_bounded(
				$file,
				WPHAVE_Media_Image_Source_Gate::MAX_BYTES,
				__('The original image could not be inspected safely.', 'wphave'),
			);
		} catch (RuntimeException $error) {
			return $file;
		}

		$type = wp_get_image_mime($file);

		// Process images only !
		// Skip GIF "image/gif" to preserve animation
		if (!in_array($type, ['image/jpeg', 'image/png'], true)) {
			// Bail early !
			return $file;
		}
		if (isset(WPHAVE_Media_Image_Source_Gate::inspect($file, $type)['error'])) {
			return $file;
		}

		$image = wp_get_image_editor($file);

		if (is_wp_error($image)) {
			return $file;
		}

		$size_limit = wphave_data_get('site_settings', 'general.media.image_max_size', 'no');
		$max_width =
			$size_limit === 'limit'
				? (int) wphave_data_get('site_settings', 'general.media.image_max_width')
				: 0;
		$size = $image->get_size();

		$needs_resize = false;

		if ($max_width && $size['width'] > $max_width) {
			$image->resize($max_width, null); // proportional
			$changes[] = "resized: {$size['width']}px → {$max_width}px";
			$needs_resize = true;
		}

		$format = wphave_data_get('site_settings', 'general.media.image_file_format');

		$target_mime = $type;
		$source_has_transparency = false;

		if ($format !== 'default') {
			$preferred_mime = wphave_get_preferred_image_mime($format);

			if ($preferred_mime) {
				$source_has_transparency =
					$type === 'image/png' && wphave_png_has_transparency($image, $file);

				if (
					$source_has_transparency &&
					!($format === 'webp' && $preferred_mime === 'image/webp')
				) {
					$target_mime = $type;
				} else {
					$target_mime = $preferred_mime;
				}
			}
		}

		if ($target_mime !== $type) {
			$changes[] = "converted: {$type} → {$target_mime}";
		}

		$needs_reencode = !empty($args['force_reencode']) || $type === 'image/png';
		$needs_format_change = $target_mime !== $type;

		if (!$needs_format_change && !$needs_resize && !$needs_reencode) {
			return $file;
		}

		$quality = wphave_data_get('site_settings', 'general.media.image_compression') ?: 82;
		$quality = (int) str_replace('%', '', $quality);

		$image->set_quality($quality);
		$changes[] = "compressed: {$quality}%";

		if ($image instanceof WP_Image_Editor_Imagick) {
			if (isset($image->image) && $image->image instanceof Imagick) {
				$image->image->stripImage();
				$changes[] = 'metadata removed';
			}
		}

		$extension_map = [
			'image/jpeg' => '.jpg',
			'image/png' => '.png',
			'image/webp' => '.webp',
			'image/avif' => '.avif',
		];

		$new_file = $file;

		if ($target_mime !== $type) {
			$new_file = preg_replace('/\.(jpe?g|png)$/i', $extension_map[$target_mime], $file);
			if (!is_string($new_file) || $new_file === $file) {
				return $file;
			}
			// CONVERSION INVARIANT: An existing sibling with the target extension
			// may belong to a different attachment. Reserve a distinct name, then
			// enforce create-only publication below even if allocation races.
			$unique_name = wp_unique_filename(
				dirname($new_file),
				basename($new_file),
			);
			// DESTINATION INVARIANT: WordPress filters the final unique filename.
			// It must remain one image filename in this source directory.
			if (
				!is_string($unique_name) ||
				!WPHAVE_Media_Image_Size_File_Identity::is_safe_basename($unique_name) ||
				strtolower('.' . pathinfo($unique_name, PATHINFO_EXTENSION)) !==
					$extension_map[$target_mime]
			) {
				return $file;
			}
			$new_file = trailingslashit(dirname($new_file)) . $unique_name;
		}

		if ($target_mime === 'image/png') {
			// Imagick (best)
			if ($image instanceof WP_Image_Editor_Imagick) {
				if (isset($image->image) && $image->image instanceof Imagick) {
					$image->image->setOption('png:compression-level', '9');
					$image->image->setOption('png:compression-filter', '5');
					$changes[] = 'png optimized (Imagick)';
				}

				// GD fallback
			} elseif ($image instanceof WP_Image_Editor_GD) {
				if (isset($image->image)) {
					$changes[] = 'png optimized (GD)';
				}
			}
		}

		$temp_file =
			trailingslashit(dirname($new_file)) .
			'.wphave-' .
			wp_generate_uuid4() .
			$extension_map[$target_mime];
		$result = $image->save($temp_file, $target_mime);

		clearstatcache(true, $temp_file);
		$output_bytes = is_file($temp_file) ? filesize($temp_file) : false;
		$staging_identity = null;
		if (
			is_int($output_bytes) &&
			$output_bytes <= WPHAVE_Media_Image_Source_Gate::MAX_OUTPUT_BYTES
		) {
			try {
				$staging_identity = WPHAVE_Security_File_Identity::inspect_bounded(
					$temp_file,
					WPHAVE_Media_Image_Source_Gate::MAX_OUTPUT_BYTES,
					__('The encoded image could not be inspected safely.', 'wphave'),
				);
			} catch (RuntimeException $error) {
				// The node cannot be proven as the output we just encoded.
			}
		}
		if (
			is_wp_error($result) ||
			!is_array($result) ||
			($result['path'] ?? null) !== $temp_file ||
			($result['mime-type'] ?? null) !== $target_mime ||
			!is_array($staging_identity) ||
			$staging_identity['bytes'] < 1
		) {
			// An over-limit or replaced node has no bounded identity and survives
			// cleanup; ordinary failed outputs are removed conditionally.
			wphave_discard_optimization_staging(
				$temp_file,
				$staging_identity['checksum'] ?? null,
			);

			return $file;
		}

		if (
			$type === 'image/png' &&
			$target_mime === 'image/webp' &&
			!wphave_png_webp_output_is_valid(
				$temp_file,
				$image->get_size(),
				$source_has_transparency,
			)
		) {
			wphave_discard_optimization_staging($temp_file, $staging_identity['checksum']);
			return $file;
		}

		try {
			$current_source = WPHAVE_Security_File_Identity::inspect_bounded(
				$file,
				WPHAVE_Media_Image_Source_Gate::MAX_BYTES,
				__('The image source changed during optimization.', 'wphave'),
			);
		} catch (RuntimeException $error) {
			wphave_discard_optimization_staging($temp_file, $staging_identity['checksum']);
			return $file;
		}
		if (
			$current_source['bytes'] !== $original_identity['bytes'] ||
			!hash_equals($original_identity['checksum'], $current_source['checksum'])
		) {
			wphave_discard_optimization_staging($temp_file, $staging_identity['checksum']);
			return $file;
		}
		if (
			!wphave_replace_image_file(
				$temp_file,
				$new_file,
				$target_mime !== $type,
				$new_file === $file ? $original_identity['checksum'] : null,
			)
		) {
			wphave_discard_optimization_staging($temp_file, $staging_identity['checksum']);
			return $file;
		}

		if (
			!empty($args['delete_original']) &&
			$new_file !== $file &&
			file_exists($file) &&
			file_exists($new_file) &&
			wphave_can_delete_optimized_source($file)
		) {
			try {
				$published_identity = WPHAVE_Security_File_Identity::inspect(
					$new_file,
					__('The optimized image output could not be verified.', 'wphave'),
				);
				if ($published_identity['bytes'] <= 0) {
					return $file;
				}

				// SECURITY INVARIANT: Format conversion deletes only the exact original
				// revision observed before processing. A concurrent rewrite survives and
				// both formats remain available for explicit reconciliation.
				WPHAVE_Security_Conditional_File::remove_if_matches(
					$file,
					$original_identity['checksum'],
					__('The original image changed before conversion cleanup.', 'wphave'),
				);
			} catch (RuntimeException $error) {
				// The optimized output is already valid and published. Preserve any
				// unproven original rather than turning cleanup conflict into data loss.
			}
		}

		$GLOBALS['wphave_image_log'][] = [
			'file' => $new_file,
			'changes' => $changes,
		];

		return $new_file;
	}
endif;

if (!function_exists('wphave_can_delete_optimized_source')):
	function wphave_can_delete_optimized_source(string $file): bool {
		try {
			$uploads = wp_get_upload_dir();
			$root = realpath((string) ($uploads['basedir'] ?? ''));
			$source = !is_link($file) ? realpath($file) : false;
			$root_prefix = $root ? rtrim($root, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR : '';
			if (!$source || !$root_prefix || !str_starts_with($source, $root_prefix)) {
				return false;
			}

			// OWNERSHIP INVARIANT: A source unregistered at upload start may be
			// claimed while the encoder runs. Matching bytes do not grant deletion
			// authority over a newly registered attachment.
			return !WPHAVE_Attachment_File_Registration::has_any_owner(
				substr($source, strlen($root_prefix)),
				$source,
			);
		} catch (Throwable $error) {
			// An unprovable registration leaves both file revisions for recovery.
			return false;
		}
	}
endif;

if (!function_exists('wphave_discard_optimization_staging')):
	function wphave_discard_optimization_staging(string $path, ?string $checksum): void {
		if ($checksum === null) {
			return;
		}
		try {
			// CLEANUP INVARIANT: A replaced staging node survives the conflict.
			WPHAVE_Security_Conditional_File::remove_if_matches(
				$path,
				$checksum,
				__('The image staging file changed before cleanup.', 'wphave'),
			);
		} catch (RuntimeException $error) {
			// Preserve an unproven node for operator recovery.
		}
	}
endif;

/**
 * Fail closed before publishing a PNG-to-WebP conversion. A WebP encoder can be
 * available while its output is unreadable or loses the source alpha channel.
 */
if (!function_exists('wphave_png_webp_output_is_valid')):
	function wphave_png_webp_output_is_valid($file, $expected_size, $needs_alpha) {
		if (wp_get_image_mime($file) !== 'image/webp') {
			return false;
		}

		$size = wp_getimagesize($file);
		if (
			!$size ||
			$size[0] !== $expected_size['width'] ||
			$size[1] !== $expected_size['height']
		) {
			return false;
		}

		if (!$needs_alpha) {
			return true;
		}

		$converted_image = wp_get_image_editor($file);
		return !is_wp_error($converted_image) &&
			wphave_png_has_transparency($converted_image, $file);
	}
endif;

/**
 * Replace an image file.
 *
 * @param string $source
 * @param string $destination
 * @return bool
 */

if (!function_exists('wphave_replace_image_file')):
	function wphave_replace_image_file(
		$source,
		$destination,
		$create_only = false,
		?string $expected_destination_checksum = null,
	) {
		try {
			$source_identity = WPHAVE_Security_File_Identity::inspect_bounded(
				$source,
				WPHAVE_Media_Image_Source_Gate::MAX_OUTPUT_BYTES,
				__('The processed image source could not be inspected safely.', 'wphave'),
			);
		} catch (RuntimeException $error) {
			return false;
		}

		if ($source_identity['bytes'] <= 0 || $source === $destination) {
			return false;
		}

		// SECURITY INVARIANT: Upload and regeneration preserve only the verified
		// WordPress editor output's read/write permissions, never executable bits.
		// The editor derives these from the upload directory; do not widen them to
		// a hardcoded public mode or change the shared primitives' private defaults.
		// PUBLICATION INVARIANT: Atomic publication must retain these permissions
		// so a separate webserver user can still serve the generated thumbnails.
		$permissions = WPHAVE_Security_File_Permissions::existing($source_identity);

		try {
			if (!$create_only && (file_exists($destination) || is_link($destination))) {
				$destination_identity = WPHAVE_Security_File_Identity::inspect_bounded(
					$destination,
					WPHAVE_Media_Image_Source_Gate::MAX_OUTPUT_BYTES,
					__('The current image destination could not be inspected safely.', 'wphave'),
				);
				// STALE-WRITE INVARIANT: In-place optimization may publish only over
				// the source revision that was decoded, never a later writer's bytes.
				if (
					$expected_destination_checksum !== null &&
					!hash_equals($expected_destination_checksum, $destination_identity['checksum'])
				) {
					return false;
				}

				// SECURITY INVARIANT: Replacing an image targets the exact destination
				// revision observed here. A concurrent path replacement is preserved.
				WPHAVE_Security_Conditional_File::replace_if_matches(
					$destination,
					$destination_identity['checksum'],
					$source,
					$source_identity['checksum'],
					__('The image destination changed before publication.', 'wphave'),
					$permissions,
					WPHAVE_Security_File_Permissions::recorded_group(
						$source_identity['group'] ?? null,
					),
					WPHAVE_Media_Image_Source_Gate::MAX_OUTPUT_BYTES,
					max(1, $destination_identity['bytes']),
				);
			} else {
				if ($expected_destination_checksum !== null) {
					return false;
				}
				WPHAVE_Security_Atomic_File::copy_verified_new(
					$source,
					$destination,
					$source_identity['checksum'],
					__('The processed image could not be published safely.', 'wphave'),
					$permissions,
					WPHAVE_Security_File_Permissions::recorded_group(
						$source_identity['group'] ?? null,
					),
					WPHAVE_Media_Image_Source_Gate::MAX_OUTPUT_BYTES,
				);
			}
		} catch (RuntimeException $error) {
			return false;
		}

		try {
			WPHAVE_Security_Conditional_File::remove_if_matches(
				$source,
				$source_identity['checksum'],
				__('Processed image staging could not be cleaned up safely.', 'wphave'),
				max(1, $source_identity['bytes']),
			);
		} catch (RuntimeException $error) {
			// Publication already committed. Preserve an unproven staging node rather
			// than reporting that the live destination failed or deleting foreign data.
		}

		return true;
	}
endif;

/**
 * Filter to run optimizations for uploaded images.
 */

if (!function_exists('wphave_process_uploaded_image')):
	function wphave_process_uploaded_image($upload) {
		$optimize_on_upload = wphave_data_get(
			'site_settings',
			'general.media.image_optimize_on_upload',
		);

		// Default: OFF (safe)
		$optimize_on_upload = $optimize_on_upload === null ? false : (bool) $optimize_on_upload;

		// No automatic image optimization for original uploaded images by default!
		// Only optimize uploaded images if set by the user!
		if (!$optimize_on_upload) {
			// Bail early !
			return $upload;
		}

		$old_file = is_array($upload) ? ($upload['file'] ?? null) : null;
		$uploads = wp_get_upload_dir();
		$root = realpath((string) ($uploads['basedir'] ?? ''));
		$source = is_string($old_file) && !is_link($old_file) ? realpath($old_file) : false;
		$root_prefix = $root ? rtrim($root, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR : '';
		if (
			!$source ||
			!$root_prefix ||
			!str_starts_with($source, $root_prefix) ||
			!is_file($source) ||
			!is_string($upload['url'] ?? null)
		) {
			return $upload;
		}
		$relative = substr($source, strlen($root_prefix));
		// UPLOAD AUTHORITY INVARIANT: This hook runs before the new attachment
		// is registered. An existing registration means the path belongs to a
		// different media object and must not be converted or deleted here.
		if (WPHAVE_Attachment_File_Registration::has_any_owner($relative, $source)) {
			return $upload;
		}
		$new_file = wphave_optimize_image($old_file);

		if ($new_file !== $old_file && file_exists($new_file)) {
			$upload['file'] = $new_file;
			$upload['type'] = wp_get_image_mime($new_file);
			$upload['url'] = dirname($upload['url']) . '/' . basename($new_file);
		}

		return $upload;
	}
endif;

add_filter('wp_handle_upload', 'wphave_process_uploaded_image');

/**
 * Filter to run optimizations for regenerated image sizes.
 */

if (!function_exists('wphave_process_regenerated_image')):
	function wphave_process_regenerated_image($metadata, $attachment_id) {
		// Safety Guard
		static $processed = [];

		if (isset($processed[$attachment_id])) {
			return $metadata;
		}

		$processed[$attachment_id] = true;

		if (!is_array($metadata) || empty($metadata['sizes']) || !is_array($metadata['sizes'])) {
			return $metadata;
		}

		$original = get_attached_file($attachment_id, true);
		$relative = get_post_meta($attachment_id, '_wp_attached_file', true);
		$uploads = wp_get_upload_dir();
		$root = realpath((string) ($uploads['basedir'] ?? ''));
		$source = is_string($original) && !is_link($original) ? realpath($original) : false;

		if (
			!$root ||
			!$source ||
			!is_string($relative) ||
			($metadata['file'] ?? null) !== $relative ||
			!str_starts_with($source, rtrim($root, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR) ||
			substr($source, strlen(rtrim($root, DIRECTORY_SEPARATOR)) + 1) !== $relative
		) {
			/* ! --> IMPORTANT: Do not modify the ORIGINAL image. */

			return $metadata;
		}

		$dir = trailingslashit(dirname($original));

		$attachment_log = [];

		// Regenerate images sizes ONLY!
		foreach ($metadata['sizes'] as $size => $data) {
			if (!WPHAVE_Media_Image_Size_File_Identity::matches_generated_size($source, $data)) {
				continue;
			}

			$file_path = $dir . $data['file'];

			// FILE AUTHORITY INVARIANT: Filtered metadata is an inventory hint,
			// never permission to rewrite a sibling, symlink or foreign attachment.
			$size_real = !is_link($file_path) ? realpath($file_path) : false;
			if (
				!$size_real ||
				dirname($size_real) !== dirname($source) ||
				WPHAVE_Attachment_File_Registration::has_other_owner(
					(ltrim(dirname($relative), './') === '' ? '' : dirname($relative) . '/') . $data['file'],
					$size_real,
					(int) $attachment_id,
				)
			) {
				continue;
			}

			// Reset per file log
			$before = count($GLOBALS['wphave_image_log'] ?? []);

			$result = wphave_optimize_image($file_path, [
				'delete_original' => empty($GLOBALS['wphave_is_regenerating_images']),
				'force_reencode' => !empty($GLOBALS['wphave_is_regenerating_images']),
			]);

			$after = $GLOBALS['wphave_image_log'] ?? [];

			// Neue Logs extrahieren
			$new_logs = array_slice($after, $before);

			foreach ($new_logs as $log) {
				$attachment_log[] = [
					'size' => $size,
					'file' => basename($log['file']),
					'changes' => $log['changes'],
				];
			}

			if ($result !== $file_path) {
				$metadata['sizes'][$size]['file'] = basename($result);
				$metadata['sizes'][$size]['mime-type'] = wp_get_image_mime($result);
			}

			if (file_exists($result)) {
				$metadata['sizes'][$size]['filesize'] = filesize($result);
			}
		}

		if (!empty($attachment_log)) {
			$GLOBALS['wphave_image_log_grouped'][$attachment_id] = [
				'id' => $attachment_id,
				'name' => get_the_title($attachment_id),
				'sizes' => $attachment_log,
			];
		}

		return $metadata;
	}
endif;

add_filter('wp_generate_attachment_metadata', 'wphave_process_regenerated_image', 10, 2);
