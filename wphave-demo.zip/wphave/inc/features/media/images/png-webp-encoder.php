<?php

/**
 * Save a PNG editor as WebP without losing the selected quality on conversion.
 *
 * WP_Image_Editor::get_output_format() calls set_quality() with no argument
 * during PNG-to-WebP save, replacing an earlier explicit value with the WebP
 * default. Scope the documented quality filter to this one save call so the
 * editor retains its decoded/resized pixels and native GD/Imagick behavior.
 * The caller verifies the staged output before it can be published.
 */
if (!function_exists('wphave_encode_png_as_webp')):
	function wphave_encode_png_as_webp($editor, string $output, int $quality) {
		if ($quality < 1 || $quality > 100 || file_exists($output) || is_link($output)) {
			return false;
		}

		$select_quality = static function ($default, $mime_type) use ($quality) {
			return $mime_type === 'image/webp' ? $quality : $default;
		};
		add_filter('wp_editor_set_quality', $select_quality, PHP_INT_MAX, 2);
		try {
			return $editor->save($output, 'image/webp');
		} finally {
			// Never let a conversion-specific quality override affect later images.
			remove_filter('wp_editor_set_quality', $select_quality, PHP_INT_MAX);
		}
	}
endif;
