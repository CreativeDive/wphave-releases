<?php

require_once __DIR__ . '/source-gate.php';
require_once __DIR__ . '/backup-budget.php';

/**
 * Secure, transactional image editing for existing media attachments.
 *
 * The client submits declarative operations only. Published source and
 * destination paths are resolved from the attachment and confined to uploads;
 * processing stages live in a private workspace outside the web root.
 */

trait WPHAVE_Attachment_Image_Editor {
	private const IMAGE_EDITOR_MAX_OUTPUT_BYTES = WPHAVE_Media_Image_Source_Gate::MAX_OUTPUT_BYTES;
	private const IMAGE_COMPRESSION_MIMES = ['image/jpeg', 'image/png', 'image/webp', 'image/avif'];

	/** Resolve the only permitted format change for per-file compression. */
	private static function compression_output_mime(string $source_mime, $output_format): string|WP_Error {
		// FORMAT INVARIANT: Only PNG may change format, and only to WebP. Other
		// quality edits preserve their existing MIME and public filename.
		if ($source_mime === 'image/png' && $output_format === 'webp') {
			return 'image/webp';
		}
		if ($source_mime !== 'image/png' && $output_format === null) {
			return $source_mime;
		}
		return new WP_Error('wphave_image_compression_invalid_format', __('The requested image format is invalid.', 'wphave'), ['status' => 400]);
	}

	/** Require a bounded integer quality for direct service callers as well as REST. */
	private static function validate_compression_quality($quality): true|WP_Error {
		if (!is_int($quality) || $quality < 40 || $quality > 100) {
			return new WP_Error(
				'wphave_image_compression_invalid_quality',
				__('The image quality is invalid.', 'wphave'),
				['status' => 400],
			);
		}
		return true;
	}

	/** Recheck the license at publication time, including after encoder callbacks. */
	private static function require_compression_pro_access(): true|WP_Error {
		if (!function_exists('wphave_has_pro_access') || !wphave_has_pro_access()) {
			return new WP_Error('wphave_image_compression_pro_required', __('Image compression requires Pro.', 'wphave'), ['status' => 403]);
		}
		return true;
	}

	/** Verify encoded MIME and, for quality edits, unchanged pixel dimensions. */
	private static function encoded_image_matches_source(
		$header,
		string $output_mime,
		array $source,
		bool $quality_only,
	): bool {
		if (!is_array($header) || ($header['mime'] ?? '') !== $output_mime) {
			return false;
		}
		// GEOMETRY INVARIANT: Quality edits may alter encoding, never pixel
		// dimensions. Image transforms have their own validated geometry contract.
		return !$quality_only || (
			(int) ($header[0] ?? 0) === (int) $source['width'] &&
			(int) ($header[1] ?? 0) === (int) $source['height']
		);
	}

	/** Accept only the exact path and MIME requested for a private encoder stage. */
	private static function encoded_image_save_matches_stage($saved, string $path, string $mime): bool {
		// OUTPUT IDENTITY INVARIANT: A codec or save filter must acknowledge the
		// exact stage and MIME that the caller later inspects and publishes.
		return is_array($saved) &&
			($saved['path'] ?? null) === $path &&
			($saved['mime-type'] ?? null) === $mime;
	}

	/** Keep preview disclosure bound to the source bytes that were encoded. */
	private static function compression_source_matches_revision(string $path, string $checksum): bool {
		try {
			$current = WPHAVE_Security_File_Identity::inspect_bounded(
				$path,
				WPHAVE_Media_Image_Source_Gate::MAX_BYTES,
				__('The image changed during preview.', 'wphave'),
			);
			return hash_equals($checksum, $current['checksum']);
		} catch (RuntimeException $error) {
			return false;
		}
	}

	/** Remove only a recognized alternate output in the operation's private workspace. */
	private static function cleanup_unexpected_encoded_stage(
		$saved,
		string $workspace,
		string $expected_path,
	): void {
		$reported_path = is_array($saved) ? ($saved['path'] ?? null) : null;
		$stem = pathinfo($expected_path, PATHINFO_FILENAME);
		// CLEANUP AUTHORITY: Only a sibling produced under this operation's
		// known output stem may be removed. A codec-supplied path elsewhere,
		// including source snapshots, grants no deletion authority.
		if (
			!is_string($reported_path) ||
			$reported_path === $expected_path ||
			dirname($reported_path) !== rtrim($workspace, '/') ||
			!preg_match('/^' . preg_quote($stem, '/') . '\.[a-z0-9]{1,10}$/D', basename($reported_path)) ||
			!is_file($reported_path)
		) {
			return;
		}
		try {
			$identity = WPHAVE_Security_File_Identity::inspect_bounded(
				$reported_path,
				self::IMAGE_EDITOR_MAX_OUTPUT_BYTES,
				__('Unexpected image output could not be inspected safely.', 'wphave'),
			);
			WPHAVE_Security_Conditional_File::remove_if_matches(
				$reported_path,
				$identity['checksum'],
				__('Unexpected image output changed during cleanup.', 'wphave'),
				max(1, $identity['bytes']),
			);
		} catch (RuntimeException $error) {
			// Preserve an unproven private node for operator recovery.
		}
	}

	/** Use the same encoder for preview and publication. */
	private static function encode_compressed_image(
		string $source,
		string $output,
		string $source_mime,
		string $output_mime,
		int $quality,
	): array|WP_Error {
		if ($source_mime === 'image/png' && $output_mime === 'image/webp') {
			$editor = wp_get_image_editor($source);
			if (is_wp_error($editor)) {
				return $editor;
			}
			// ALPHA INVARIANT: The shared media conversion check rejects an output
			// whose dimensions or transparency no longer match the PNG source.
			$needs_alpha = wphave_png_has_transparency($editor, $source);
			$quality_result = $editor->set_quality($quality);
			if (is_wp_error($quality_result) || $quality_result === false) {
				return new WP_Error('wphave_image_compression_quality_failed', __('The image quality could not be set.', 'wphave'), ['status' => 500]);
			}
			$saved = $editor->save($output, $output_mime);
			if (is_wp_error($saved)) {
				return $saved;
			}
			if (!wphave_png_webp_output_is_valid($output, $editor->get_size(), $needs_alpha)) {
				return new WP_Error('wphave_image_compression_alpha_lost', __('The WebP conversion did not preserve the image dimensions or transparency.', 'wphave'), ['status' => 500]);
			}
			return $saved;
		}
		// ENCODING INVARIANT: WordPress preserves lossless WebP and silently forces
		// quality 100. A per-file quality edit must explicitly produce lossy WebP,
		// while retaining the WebP MIME and extension. Fail closed without GD.
		$webp_info = $source_mime === 'image/webp' ? wp_get_webp_info($source) : [];
		if ($source_mime === 'image/webp' && ($webp_info['type'] ?? '') === 'lossless') {
			if (!function_exists('imagecreatefromwebp') || !function_exists('imagewebp')) {
				return new WP_Error('wphave_image_compression_encoder_unavailable', __('Lossless WebP compression is unavailable on this server.', 'wphave'), ['status' => 500]);
			}
			$image = @imagecreatefromwebp($source);
			if ($image === false) {
				return new WP_Error('wphave_image_compression_encode_failed', __('The WebP image could not be compressed.', 'wphave'), ['status' => 500]);
			}
			$encoded = @imagewebp($image, $output, $quality);
			imagedestroy($image);
			if (!$encoded) {
				return new WP_Error('wphave_image_compression_encode_failed', __('The WebP image could not be compressed.', 'wphave'), ['status' => 500]);
			}
			return ['path' => $output, 'mime-type' => $output_mime];
		}

		$editor = wp_get_image_editor($source);
		if (is_wp_error($editor)) {
			return $editor;
		}
		$set_quality = $editor->set_quality($quality);
		if (is_wp_error($set_quality)) {
			return $set_quality;
		}
		if ($set_quality === false) {
			return new WP_Error('wphave_image_compression_quality_failed', __('The image quality could not be set.', 'wphave'), ['status' => 500]);
		}
		return $editor->save($output, $output_mime);
	}

	private static function image_editor_supported_mimes(): array {
		// TYPE INVARIANT: A missing or malformed shared list disables editing;
		// neither the browser MIME claim nor a generic image/* match can widen it.
		static $mimes = null;
		if (null === $mimes) {
			$path = __DIR__ . '/editor-mimes.json';
			$contents = is_readable($path) ? file_get_contents($path) : false;
			$decoded = false === $contents ? null : json_decode($contents, true);
			$mimes = is_array($decoded) ? $decoded : [];
		}
		return $mimes;
	}

	/** Inspect one authorized source through the same limits for GET and POST. */
	private static function inspect_image_editor_source($attachment_id): array|WP_Error {
		$validation = self::validate_attachment($attachment_id);
		if (is_wp_error($validation)) {
			return $validation;
		}
		// PATH INVARIANT: The editor changes the registered local attachment file,
		// never a path substituted by the filterable get_attached_file() API.
		$source = self::normalize_existing_upload_path(get_attached_file($attachment_id, true));
		$mime = get_post_mime_type($attachment_id);
		// TYPE INVARIANT: Both WordPress's attachment classification and the
		// editor's explicit decoder allowlist must agree before processing bytes.
		if (
			!$source ||
			!wp_attachment_is_image($attachment_id) ||
			!in_array($mime, self::image_editor_supported_mimes(), true)
		) {
			return new WP_Error(
				'wphave_image_editor_unsupported_type',
				__('This image type cannot be edited safely.', 'wphave'),
				['status' => 400],
			);
		}
		// OWNERSHIP INVARIANT: Validate the exact unfiltered source read below,
		// independently of the earlier attachment validation call.
		if (self::is_registered_other_attachment_file($source, (int) $attachment_id)) {
			return new WP_Error(
				'wphave_attachment_file_shared',
				__('The attachment file is registered to another media item.', 'wphave'),
				['status' => 409],
			);
		}
		$header = WPHAVE_Media_Image_Source_Gate::inspect($source, $mime);
		if (($header['error'] ?? '') === 'size') {
			return new WP_Error(
				'wphave_image_editor_too_large',
				__('The image exceeds the safe editing limit.', 'wphave'),
				['status' => 400],
			);
		}
		if (($header['error'] ?? '') === 'type') {
			return new WP_Error(
				'wphave_image_editor_unsupported_type',
				__('This image type cannot be edited safely.', 'wphave'),
				['status' => 400],
			);
		}
		try {
			$identity = WPHAVE_Security_File_Identity::inspect_bounded(
				$source,
				WPHAVE_Media_Image_Source_Gate::MAX_BYTES,
				__('The image cannot be opened for editing.', 'wphave'),
			);
		} catch (RuntimeException $error) {
			return new WP_Error(
				'wphave_image_editor_unavailable',
				__('The image cannot be opened for editing.', 'wphave'),
				['status' => 400],
			);
		}
		return [
			'path' => $source,
			'mime' => $mime,
			'width' => $header['width'],
			'height' => $header['height'],
			'bytes' => $identity['bytes'],
			'modified' => $identity['modified'],
			'checksum' => $identity['checksum'],
		];
	}

	/** Publish a verified transform or checksum-bound compression as copy or replacement. */
	private static function edit_attachment_image(
		$attachment_id,
		$operations,
		$mode,
		$expected_modified,
		$expected_checksum,
		$details = [],
		$quality = null,
		$output_format = null,
		$expected_preview_checksum = null,
	) {
		// AUTHORIZATION INVARIANT: This private service can be called without REST
		// dispatch. Reject before reading or decoding attachment bytes; the route
		// permission callback is only the first, not the sole, authorization gate.
		if (!self::current_user_can_manage_attachment_file($attachment_id)) {
			return new WP_Error(
				'wphave_attachment_file_forbidden',
				__('You are not allowed to manage this media file.', 'wphave'),
				['status' => 403],
			);
		}
		// CONTRACT INVARIANT: Direct callers must honor the same save-mode
		// allowlist as REST; an unknown mode must never silently create a copy.
		if (!in_array($mode, ['copy', 'replace'], true)) {
			return new WP_Error(
				'wphave_image_editor_invalid_mode',
				__('The image edit mode is invalid.', 'wphave'),
				['status' => 400],
			);
		}
		// SERVICE POLICY: A transform has a separate site action from quality
		// compression. Direct callers must honor the same action switch as REST.
		if ($quality === null && !self::is_file_action_allowed('edit')) {
			return new WP_Error('wphave_media_file_action_disabled', __('This file action is disabled in Media Settings.', 'wphave'), ['status' => 403]);
		}
		if ($quality !== null) {
			// SERVICE POLICY: Internal callers bypass REST action routing. A
			// disabled compression action must also block direct publication.
			if (!self::is_file_action_allowed('compress')) {
				return new WP_Error('wphave_media_file_action_disabled', __('This file action is disabled in Media Settings.', 'wphave'), ['status' => 403]);
			}
			// LICENSE INVARIANT: Preview may be explored in Free, but direct service
			// calls cannot publish a quality edit without resolved Pro access.
			$pro_access = self::require_compression_pro_access();
			if (is_wp_error($pro_access)) {
				return $pro_access;
			}
			$quality_validation = self::validate_compression_quality($quality);
			if (is_wp_error($quality_validation)) {
				return $quality_validation;
			}
			// PREVIEW BINDING: Saving quality edits requires a digest of the
			// encoded preview, not just a quality number and source revision.
			if (!is_string($expected_preview_checksum) || !preg_match('/^[a-f0-9]{64}$/', $expected_preview_checksum)) {
				return new WP_Error('wphave_image_compression_preview_required', __('Generate a valid compression preview before saving.', 'wphave'), ['status' => 400]);
			}
		} elseif ($expected_preview_checksum !== null) {
			return new WP_Error('wphave_image_compression_preview_unexpected', __('A preview checksum is only valid for quality edits.', 'wphave'), ['status' => 400]);
		}
		// DETAILS-INPUT INVARIANT: Metadata edits are accepted as a small, typed
		// document before image decoding or WordPress text sanitizers run.
		$details_validation = self::validate_edited_attachment_details($details);
		if (is_wp_error($details_validation)) {
			return $details_validation;
		}

		$inspected = self::inspect_image_editor_source($attachment_id);
		if (is_wp_error($inspected)) {
			return $inspected;
		}
		$source = $inspected['path'];
		$mime = $inspected['mime'];
		$output_mime = $quality !== null
			? self::compression_output_mime($mime, $output_format)
			: $mime;
		if (is_wp_error($output_mime)) {
			return $output_mime;
		}
		if ($quality === null && $output_format !== null) {
			return new WP_Error('wphave_image_compression_invalid_format', __('The requested image format is invalid.', 'wphave'), ['status' => 400]);
		}
		if ($output_mime !== $mime && $mode !== 'copy') {
			return new WP_Error('wphave_image_compression_copy_required', __('Format conversion must be saved as a new media item.', 'wphave'), ['status' => 400]);
		}
		if ($quality !== null && !in_array($mime, self::IMAGE_COMPRESSION_MIMES, true)) {
			return new WP_Error('wphave_image_compression_unsupported_type', __('Quality adjustment is unavailable for this image format.', 'wphave'), ['status' => 400]);
		}

		// REVISION INVARIANT: The browser's checksum binds the edit to exact
		// bytes. A changed mtime with identical bytes is not a new image revision
		// and must not invalidate a copy after a harmless touch or metadata sync.
		// mtime alone also cannot detect two writes in the same second.
		if (
			!is_string($expected_checksum) ||
			!preg_match('/^[a-f0-9]{64}$/', $expected_checksum) ||
			!hash_equals($expected_checksum, $inspected['checksum'])
		) {
			return new WP_Error(
				'wphave_image_editor_conflict',
				__(
					'The image changed after the editor was opened. Reload it before saving.',
					'wphave',
				),
				['status' => 409],
			);
		}

		$operations = self::sanitize_image_operations($operations);
		if (is_wp_error($operations)) {
			return $operations;
		}
		if ($quality !== null && $operations) {
			return new WP_Error(
				'wphave_image_compression_mixed_operations',
				__('Compression and image transforms must be saved separately.', 'wphave'),
				['status' => 400],
			);
		}
		$geometry_validation = self::validate_image_edit_geometry(
			$operations,
			$inspected['width'],
			$inspected['height'],
		);
		if (is_wp_error($geometry_validation)) {
			return $geometry_validation;
		}
		if (!$operations && $quality === null) {
			// MODE INVARIANT: A copy request must never fall through to an original
			// metadata edit merely because no pixel operation was supplied.
			return new WP_Error(
				'wphave_image_editor_no_changes',
				__('Make at least one image adjustment before saving.', 'wphave'),
				['status' => 400],
			);
		}

		// SOURCE-SNAPSHOT INVARIANT: Decode an exclusive, private copy of the
		// checksum-bound source outside the public uploads tree. A replaced
		// pathname cannot redirect the decoder after source validation.
		$workspace = self::create_image_editor_private_workspace();
		if (is_wp_error($workspace)) {
			return $workspace;
		}
		$extension = pathinfo($source, PATHINFO_EXTENSION);
		$snapshot = trailingslashit($workspace) . 'source.' . $extension;
		try {
			// PRIVATE SNAPSHOT INVARIANT: This random 0700 workspace is not a
			// public create-only destination. A bounded, checksum-verified rename
			// avoids a hard-link requirement on hosts that disable link().
			WPHAVE_Security_Atomic_File::copy_verified(
				$source,
				$snapshot,
				$expected_checksum,
				__('The image changed before editing could begin.', 'wphave'),
				0600,
				null,
				WPHAVE_Media_Image_Source_Gate::MAX_BYTES,
			);
		} catch (RuntimeException $error) {
			@rmdir($workspace);
			return new WP_Error(
				'wphave_image_editor_conflict',
				__('The image changed after the editor was opened. Reload it before saving.', 'wphave'),
				['status' => 409],
			);
		}
		$temporary = null;
		$temporary_checksum = null;
		$saved = null;
		try {
			// SNAPSHOT INVARIANT: The pre-copy header may describe an earlier
			// revision. Decode only a verified private copy with the same static
			// format and geometry, including the animation gate.
			$snapshot_header = WPHAVE_Media_Image_Source_Gate::inspect($snapshot, $mime);
			if (
				isset($snapshot_header['error']) ||
				$snapshot_header['width'] !== $inspected['width'] ||
				$snapshot_header['height'] !== $inspected['height']
			) {
				return new WP_Error(
					'wphave_image_editor_conflict',
					__('The image changed after the editor was opened. Reload it before saving.', 'wphave'),
					['status' => 409],
				);
			}
			$output_extension = $output_mime === 'image/webp' ? 'webp' : $extension;
			$temporary = trailingslashit($workspace) . 'edited.' . $output_extension;
			$expected_output_size = [
				'width' => $inspected['width'],
				'height' => $inspected['height'],
			];
			if ($quality !== null) {
				$saved = self::encode_compressed_image($snapshot, $temporary, $mime, $output_mime, $quality);
			} else {
				$editor = wp_get_image_editor($snapshot);
				if (is_wp_error($editor)) {
					return $editor;
				}
				foreach ($operations as $operation) {
					$result = true;
					if ($operation['type'] === 'rotate') {
						// WordPress angles rotate counterclockwise; CSS preview angles
						// rotate clockwise in screen coordinates.
						$result = $editor->rotate(-$operation['degrees']);
					}
					if ($operation['type'] === 'flip') {
						// WordPress names the axis of reflection; the UI names the
						// direction of the mirror. These are opposite conventions.
						$result = $editor->flip($operation['vertical'], $operation['horizontal']);
					}
					if ($operation['type'] === 'crop') {
						$canvas = $editor->get_size();
						$crop = self::image_edit_crop_on_canvas(
							$operation,
							(int) ($canvas['width'] ?? 0),
							(int) ($canvas['height'] ?? 0),
						);
						if (is_wp_error($crop)) {
							return $crop;
						}
						$result = $editor->crop(
							$crop['x'],
							$crop['y'],
							$crop['width'],
							$crop['height'],
							$operation['width'],
							$operation['height'],
						);
					}
					if ($operation['type'] === 'resize') {
						$result = $editor->resize($operation['width'], $operation['height'], false);
					}
					if (is_wp_error($result) || $result === false) {
						if ($result === false) {
							return new WP_Error('wphave_image_editor_processing_failed', __('The edited image could not be generated.', 'wphave'), ['status' => 500]);
						}
						return $result;
					}
				}
				$expected_output_size = $editor->get_size();
				if (
					!is_array($expected_output_size) ||
					!is_int($expected_output_size['width'] ?? null) ||
					!is_int($expected_output_size['height'] ?? null) ||
					$expected_output_size['width'] < 1 ||
					$expected_output_size['height'] < 1 ||
					$expected_output_size['width'] * $expected_output_size['height'] > WPHAVE_Media_Image_Source_Gate::MAX_PIXELS
				) {
					return new WP_Error(
						'wphave_image_editor_output_type',
						__('The edited image dimensions are invalid.', 'wphave'),
						['status' => 500],
					);
				}
				$final_operation = end($operations);
				if (
					in_array($final_operation['type'] ?? '', ['crop', 'resize'], true) &&
					(
						$expected_output_size['width'] !== $final_operation['width'] ||
						$expected_output_size['height'] !== $final_operation['height']
					)
				) {
					return new WP_Error(
						'wphave_image_editor_output_type',
						__('The edited image dimensions differ from the requested crop or size.', 'wphave'),
						['status' => 500],
					);
				}
				$saved = $editor->save($temporary, $mime);
			}

			// STAGING INVARIANT: No attachment or live file points to partially
			// rendered bytes. An empty or absent stage cannot enter publication.
			if (
				!self::encoded_image_save_matches_stage($saved, $temporary, $output_mime) ||
				!file_exists($temporary) ||
				filesize($temporary) < 1
			) {
				// RECOVERY INVARIANT: A failed encoder did not produce a verified
				// checksum. Preserve any path occupant instead of deleting by name.
				return new WP_Error(
					'wphave_image_editor_processing_failed',
					__('The edited image could not be generated.', 'wphave'),
					['status' => 500],
				);
			}
			try {
				$temporary_identity = WPHAVE_Security_File_Identity::inspect_bounded(
					$temporary,
					self::IMAGE_EDITOR_MAX_OUTPUT_BYTES,
					__('The edited image output could not be inspected safely.', 'wphave'),
				);
			} catch (RuntimeException $error) {
				return self::image_editor_failure(
					'wphave_image_editor_processing_failed',
					$error->getMessage(),
					500,
				);
			}
			$temporary_checksum = (string) $temporary_identity['checksum'];
			// EXACT-OUTPUT INVARIANT: WordPress codecs or hooks may produce
			// different bytes on a second encode. Never publish an image that
			// differs from the preview the user inspected.
			if ($quality !== null && !hash_equals($expected_preview_checksum, $temporary_checksum)) {
				return new WP_Error('wphave_image_compression_preview_changed', __('The encoded image differs from its preview. Generate a new preview before saving.', 'wphave'), ['status' => 409]);
			}
			$output_header = wp_getimagesize($temporary);
			// OUTPUT INVARIANT: A WordPress editor or save hook may produce a
			// different canvas than the transformed preview. Publish only the
			// dimensions reported by the editor immediately before encoding.
			if (
				!self::encoded_image_matches_source($output_header, $output_mime, $inspected, $quality !== null) ||
				(int) ($output_header[0] ?? 0) !== $expected_output_size['width'] ||
				(int) ($output_header[1] ?? 0) !== $expected_output_size['height']
			) {
				return new WP_Error('wphave_image_editor_output_type', __('The edited image format or dimensions are invalid.', 'wphave'), ['status' => 500]);
			}
			if ($quality !== null && $temporary_identity['bytes'] >= $inspected['bytes']) {
				return new WP_Error('wphave_image_compression_not_smaller', __('The encoded image is not smaller than the source.', 'wphave'), ['status' => 400]);
			}

			/*
			 * AUTHORIZATION/TOCTOU INVARIANT: Image editor selection, decoding and
			 * transformation may invoke extension callbacks. Recheck the exact
			 * attachment authority after that work and before either a replacement or
			 * a new Media Library object can be published.
			 */
			if (!self::current_user_can_manage_attachment_file($attachment_id)) {
				try {
					WPHAVE_Security_Conditional_File::remove_if_matches(
						$temporary,
						$temporary_identity['checksum'],
						__('Revoked image-edit staging could not be cleaned up safely.', 'wphave'),
					);
				} catch (RuntimeException $cleanup_error) {
					// Preserve an unproven staging node for operator recovery.
				}

				return new WP_Error(
					'wphave_attachment_file_forbidden',
					__('You are not allowed to manage this media file.', 'wphave'),
					['status' => 403],
				);
			}
			if ($quality !== null) {
				$pro_access = self::require_compression_pro_access();
				if (is_wp_error($pro_access)) {
					return $pro_access;
				}
			}
			// POLICY INVARIANT: Encoding can run filters that disable the action.
			// Do not publish staged bytes under a revoked site setting.
			if (!self::is_file_action_allowed($quality !== null ? 'compress' : 'edit')) {
				return new WP_Error('wphave_media_file_action_disabled', __('This file action is disabled in Media Settings.', 'wphave'), ['status' => 403]);
			}

			$result =
				$mode === 'replace'
					? self::replace_with_edited_image(
						$attachment_id,
						$source,
						$temporary,
						$temporary_identity,
						$mime,
						$expected_checksum,
						$quality !== null,
					)
					: self::create_edited_image_copy(
						$attachment_id,
						$source,
						$temporary,
						$temporary_identity,
						$output_mime,
						$expected_checksum,
						$mime,
						$quality !== null,
					);

			try {
				WPHAVE_Security_Conditional_File::remove_if_matches(
					$temporary,
					$temporary_identity['checksum'],
					__('Edited image staging could not be cleaned up safely.', 'wphave'),
				);
			} catch (RuntimeException $error) {
				// Preserve a replaced or otherwise unproven staging node.
			}
			if (is_wp_error($result)) {
				return $result;
			}
			$committed_path = $mode === 'replace' ? $source : ($result['_committedPath'] ?? '');
			// RESPONSE INVARIANT: An internal absolute path must never reach REST callers.
			unset($result['_committedPath']);

			if ($details) {
				// COMMIT INVARIANT: A second metadata step cannot revoke an already
				// published file or make a retry create another copy. Report its own
				// outcome separately after checking current object permission.
				$result['detailsApplied'] =
					is_string($committed_path) &&
					$committed_path !== '' &&
					self::current_user_can_manage_attachment_file($result['id']) &&
					self::update_edited_attachment_details(
						$result['id'],
						$details,
						$committed_path,
						$output_mime,
					);
			}
			return $result;
		} finally {
			self::cleanup_unexpected_encoded_stage($saved, $workspace, (string) $temporary);
			// STAGE CLEANUP INVARIANT: Every verified output is owned by its
			// checksum, including outputs rejected before publication. Never
			// remove an exchanged or unverified path by filename alone.
			if ($temporary !== null && $temporary_checksum !== null && is_file($temporary)) {
				try {
					WPHAVE_Security_Conditional_File::remove_if_matches(
						$temporary,
						$temporary_checksum,
						__('Edited image staging could not be cleaned up safely.', 'wphave'),
					);
				} catch (RuntimeException $error) {
					// Preserve an exchanged or otherwise unproven stage for recovery.
				}
			}
			try {
				WPHAVE_Security_Conditional_File::remove_if_matches(
					$snapshot,
					$expected_checksum,
					__('The image source snapshot changed before cleanup.', 'wphave'),
				);
			} catch (RuntimeException $error) {
				// RECOVERY INVARIANT: Preserve an unproven node for inspection.
			}
			// A failed or exchanged stage remains in the private workspace.
			// Remove only an empty owned directory after conditional file cleanup.
			@rmdir($workspace);
		}
	}

	private static function create_image_editor_private_workspace(): string|WP_Error {
		$temporary_root = realpath(get_temp_dir());
		$public_root = realpath(ABSPATH);
		$content_root = defined('WP_CONTENT_DIR') ? realpath(WP_CONTENT_DIR) : false;
		// STORAGE INVARIANT: WordPress can fall back to WP_CONTENT_DIR for temp
		// files. A private mode inside web space is not an HTTP access control.
		if (
			false === $temporary_root ||
			false === $public_root ||
			self::image_editor_path_inside($temporary_root, $public_root) ||
			(false !== $content_root && self::image_editor_path_inside($temporary_root, $content_root))
		) {
			return new WP_Error(
				'wphave_image_editor_private_storage_unavailable',
				__('Private storage for image editing is unavailable.', 'wphave'),
				['status' => 500],
			);
		}
		$workspace = trailingslashit($temporary_root) . 'wphave-media-edit-' . wp_generate_uuid4();
		if (!@mkdir($workspace, 0700)) {
			return new WP_Error(
				'wphave_image_editor_private_storage_unavailable',
				__('Private storage for image editing is unavailable.', 'wphave'),
				['status' => 500],
			);
		}
		clearstatcache(true, $workspace);
		$mode = @fileperms($workspace);
		if (is_link($workspace) || false === $mode || ($mode & 0777) !== 0700) {
			@rmdir($workspace);
			return new WP_Error(
				'wphave_image_editor_private_storage_unavailable',
				__('Private storage for image editing is unavailable.', 'wphave'),
				['status' => 500],
			);
		}
		return $workspace;
	}

	private static function image_editor_path_inside(string $path, string $root): bool {
		return $path === $root || str_starts_with($path, trailingslashit($root));
	}

	private static function validate_edited_attachment_details($details): true|WP_Error {
		$limits = [
			'title' => 200,
			'caption' => 2000,
			'description' => 10000,
			'alt' => 500,
		];
		if (!is_array($details) || count($details) > count($limits)) {
			return new WP_Error(
				'wphave_image_editor_invalid_details',
				__('Invalid image details.', 'wphave'),
				['status' => 400],
			);
		}
		foreach ($details as $key => $value) {
			if (!isset($limits[$key]) || !is_string($value) || strlen($value) > $limits[$key]) {
				return new WP_Error(
					'wphave_image_editor_invalid_details',
					__('Invalid image details.', 'wphave'),
					['status' => 400],
				);
			}
		}
		return true;
	}

	/** Encode a bounded, non-publishing quality preview from the exact source revision. */
	private static function preview_attachment_compression(
		$attachment_id,
		$quality,
		$expected_checksum,
		$output_format = null,
	) {
		if (!self::current_user_can_manage_attachment_file($attachment_id)) {
			return new WP_Error(
				'wphave_attachment_file_forbidden',
				__('You are not allowed to manage this media file.', 'wphave'),
				['status' => 403],
			);
		}
		// SERVICE POLICY: Direct service calls honor the same site action gate as
		// the REST callback before image bytes are read or decoded.
		if (!self::is_file_action_allowed('compress')) {
			return new WP_Error('wphave_media_file_action_disabled', __('This file action is disabled in Media Settings.', 'wphave'), ['status' => 403]);
		}
		$quality_validation = self::validate_compression_quality($quality);
		if (is_wp_error($quality_validation)) {
			return $quality_validation;
		}
		$inspected = self::inspect_image_editor_source($attachment_id);
		if (is_wp_error($inspected)) {
			return $inspected;
		}
		if (!in_array($inspected['mime'], self::IMAGE_COMPRESSION_MIMES, true)) {
			return new WP_Error(
				'wphave_image_compression_unsupported_type',
				__('Quality adjustment is unavailable for this image format.', 'wphave'),
				['status' => 400],
			);
		}
		$output_mime = self::compression_output_mime($inspected['mime'], $output_format);
		if (is_wp_error($output_mime)) {
			return $output_mime;
		}
		if (
			!is_string($expected_checksum) ||
			!preg_match('/^[a-f0-9]{64}$/', $expected_checksum) ||
			!hash_equals($expected_checksum, $inspected['checksum'])
		) {
			return new WP_Error(
				'wphave_image_editor_conflict',
				__('The image changed after the preview was opened. Reload it.', 'wphave'),
				['status' => 409],
			);
		}
		$workspace = self::create_image_editor_private_workspace();
		if (is_wp_error($workspace)) {
			return $workspace;
		}
		$extension = pathinfo($inspected['path'], PATHINFO_EXTENSION);
		$snapshot = trailingslashit($workspace) . 'source.' . $extension;
		$output = trailingslashit($workspace) . 'preview.' . ($output_mime === 'image/webp' ? 'webp' : $extension);
		$output_checksum = null;
		$saved = null;
		try {
			// PRIVATE SNAPSHOT INVARIANT: Preview and save read the same bounded,
			// checksum-verified bytes. Their 0700 workspace permits atomic rename
			// without relying on host support for hard links.
			WPHAVE_Security_Atomic_File::copy_verified(
				$inspected['path'],
				$snapshot,
				$expected_checksum,
				__('The image changed before preview could begin.', 'wphave'),
				0600,
				null,
				WPHAVE_Media_Image_Source_Gate::MAX_BYTES,
			);
			$snapshot_header = WPHAVE_Media_Image_Source_Gate::inspect(
				$snapshot,
				$inspected['mime'],
			);
			// PREVIEW INVARIANT: The encoded preview must be based on the same
			// static geometry that the source state and eventual save validated.
			if (
				isset($snapshot_header['error']) ||
				$snapshot_header['width'] !== $inspected['width'] ||
				$snapshot_header['height'] !== $inspected['height']
			) {
				return new WP_Error(
					'wphave_image_compression_preview_conflict',
					__('The image changed before preview could begin. Reload it.', 'wphave'),
					['status' => 409],
				);
			}
			$saved = self::encode_compressed_image($snapshot, $output, $inspected['mime'], $output_mime, $quality);
			if (!self::encoded_image_save_matches_stage($saved, $output, $output_mime) || !is_file($output)) {
				return new WP_Error(
					'wphave_image_compression_preview_failed',
					__('The compression preview could not be generated.', 'wphave'),
					['status' => 500],
				);
			}
			$identity = WPHAVE_Security_File_Identity::inspect_bounded(
				$output,
				self::IMAGE_EDITOR_MAX_OUTPUT_BYTES,
				__('The compression preview is too large.', 'wphave'),
			);
			$output_checksum = $identity['checksum'];
			$output_header = wp_getimagesize($output);
			// PREVIEW/PUBLISH INVARIANT: Both paths use the same encoded-byte
			// MIME and geometry check before displaying or publishing output.
			if (!self::encoded_image_matches_source($output_header, $output_mime, $inspected, true)) {
				return new WP_Error(
					'wphave_image_compression_preview_type',
					__('The compression preview format or dimensions are invalid.', 'wphave'),
					['status' => 500],
				);
			}
			// DISCLOSURE INVARIANT: Encoding can invoke extension callbacks. A
			// revoked editor or rebound attachment must not receive its preview bytes.
			if (
				!self::current_user_can_manage_attachment_file($attachment_id) ||
				!self::compression_source_matches_revision($inspected['path'], $expected_checksum) ||
				!self::attachment_source_still_registered(
					$attachment_id,
					$inspected['path'],
					$inspected['mime'],
				)
			) {
				return new WP_Error(
					'wphave_image_compression_preview_conflict',
					__('The image or your access changed during preview. Reload it.', 'wphave'),
					['status' => 409],
				);
			}
			// RESPONSE BOUNDARY: Base64 is only returned for small results. The
			// exact encoded size is still available when an image exceeds this cap.
			$data = $identity['bytes'] <= 12 * 1024 * 1024
				? WPHAVE_Security_File_Identity::read_verified(
					$output,
					$identity['bytes'],
					$identity['checksum'],
					__('The compression preview changed during reading.', 'wphave'),
				)
				: false;
			return [
				'quality' => $quality,
				'outputFormat' => $output_format,
				'checksum' => $identity['checksum'],
				'bytes' => $identity['bytes'],
				'originalBytes' => $inspected['bytes'],
				'preview' => $data === false ? null : 'data:' . $output_mime . ';base64,' . base64_encode($data),
			];
		} catch (RuntimeException $error) {
			return new WP_Error(
				'wphave_image_compression_preview_failed',
				__('The compression preview could not be generated safely. Reload the image and try again.', 'wphave'),
				['status' => 409],
			);
		} finally {
			self::cleanup_unexpected_encoded_stage($saved, $workspace, $output);
			// PRIVATE-STAGE INVARIANT: Remove only files still matching our bytes.
			foreach ([$output => $output_checksum, $snapshot => $expected_checksum] as $path => $checksum) {
				if ($checksum !== null && is_file($path)) {
					try {
						WPHAVE_Security_Conditional_File::remove_if_matches($path, $checksum, __('Compression preview cleanup failed.', 'wphave'));
					} catch (RuntimeException $error) {
						// Leave an unproven private stage for operator recovery.
					}
				}
			}
			@rmdir($workspace);
		}
	}

	private static function sanitize_image_operations($operations) {
		$sanitized = [];
		$operation_order = ['flip' => 1, 'rotate' => 2, 'crop' => 3, 'resize' => 4];
		$last_order = 0;
		// INPUT INVARIANT: REST schema validation can be bypassed by internal
		// callers. Never coerce nested or malformed operation documents into a
		// filesystem mutation, and bound work before image decoding starts.
		if (!is_array($operations)) {
			return new WP_Error(
				'wphave_image_editor_invalid_operation',
				__('An unsupported image operation was submitted.', 'wphave'),
				['status' => 400],
			);
		}
		if (count($operations) > 12) {
			return new WP_Error(
				'wphave_image_editor_too_many_operations',
				__('Too many image operations were submitted.', 'wphave'),
				['status' => 400],
			);
		}

		foreach ($operations as $operation) {
			if (!is_array($operation) || !is_string($operation['type'] ?? null)) {
				return new WP_Error(
					'wphave_image_editor_invalid_operation',
					__('An unsupported image operation was submitted.', 'wphave'),
					['status' => 400],
				);
			}
			$type = sanitize_key($operation['type'] ?? '');
			// WORK-BOUND INVARIANT: One canonical pass per operation type keeps a
			// crafted request from repeatedly decoding/resizing a 40 MP image.
			$order = $operation_order[$type] ?? 0;
			if ($order <= $last_order) {
				return new WP_Error(
					'wphave_image_editor_invalid_operation',
					__('An unsupported image operation was submitted.', 'wphave'),
					['status' => 400],
				);
			}
			$last_order = $order;
			if ($type === 'rotate') {
				$raw_degrees = $operation['degrees'] ?? null;
				$degrees = is_int($raw_degrees) || is_float($raw_degrees)
					? (float) $raw_degrees
					: NAN;
				if (!is_finite($degrees) || $degrees < -360 || $degrees > 360 || $degrees == 0) {
					return new WP_Error(
						'wphave_image_editor_invalid_rotate',
						__('The rotation value is invalid.', 'wphave'),
						['status' => 400],
					);
				}
				$sanitized[] = ['type' => $type, 'degrees' => $degrees];
			} elseif ($type === 'flip') {
				if (
					(isset($operation['horizontal']) && !is_bool($operation['horizontal'])) ||
					(isset($operation['vertical']) && !is_bool($operation['vertical']))
				) {
					return new WP_Error(
						'wphave_image_editor_invalid_flip',
						__('The flip operation is invalid.', 'wphave'),
						['status' => 400],
					);
				}
				$horizontal = !empty($operation['horizontal']);
				$vertical = !empty($operation['vertical']);
				if (!$horizontal && !$vertical) {
					return new WP_Error(
						'wphave_image_editor_invalid_flip',
						__('The flip operation is invalid.', 'wphave'),
						['status' => 400],
					);
				}
				$sanitized[] = [
					'type' => $type,
					'horizontal' => $horizontal,
					'vertical' => $vertical,
				];
			} elseif (in_array($type, ['crop', 'resize'], true)) {
				if (
					!is_int($operation['width'] ?? null) ||
					!is_int($operation['height'] ?? null) ||
					($type === 'crop' &&
						(!is_int($operation['referenceWidth'] ?? null) ||
							!is_int($operation['referenceHeight'] ?? null))) ||
					($type === 'crop' &&
						(!is_int($operation['x'] ?? null) ||
							!is_int($operation['y'] ?? null) ||
							$operation['x'] < 0 ||
							$operation['y'] < 0))
				) {
					return new WP_Error(
						'wphave_image_editor_invalid_size',
						__('The requested image dimensions are invalid.', 'wphave'),
						['status' => 400],
					);
				}
				// INPUT INVARIANT: Dimensions are already strictly typed. Do not use
				// absint here: it would turn a negative request into a valid edit.
				$width = $operation['width'];
				$height = $operation['height'];
				if (
					$width < 1 ||
					$height < 1 ||
					$width > 12000 ||
					$height > 12000 ||
					$width * $height > WPHAVE_Media_Image_Source_Gate::MAX_PIXELS
				) {
					return new WP_Error(
						'wphave_image_editor_invalid_size',
						__('The requested image dimensions are invalid.', 'wphave'),
						['status' => 400],
					);
				}
				$item = ['type' => $type, 'width' => $width, 'height' => $height];
				if ($type === 'crop') {
					$item += [
						'x' => $operation['x'],
						'y' => $operation['y'],
						'referenceWidth' => $operation['referenceWidth'],
						'referenceHeight' => $operation['referenceHeight'],
					];
					if (
					$item['referenceWidth'] < 1 ||
					$item['referenceHeight'] < 1 ||
					$item['referenceWidth'] > 12000 ||
					$item['referenceHeight'] > 12000 ||
					$item['referenceWidth'] * $item['referenceHeight'] >
						WPHAVE_Media_Image_Source_Gate::MAX_PIXELS
				) {
					return new WP_Error(
						'wphave_image_editor_invalid_size',
						__('The requested image dimensions are invalid.', 'wphave'),
						['status' => 400],
					);
				}
				}
				$sanitized[] = $item;
			} else {
				return new WP_Error(
					'wphave_image_editor_invalid_operation',
					__('An unsupported image operation was submitted.', 'wphave'),
					['status' => 400],
				);
			}
		}

		return $sanitized;
	}

	/** Reject impossible or excessive geometry before allocating an image editor. */
	private static function validate_image_edit_geometry(
		array $operations,
		int $source_width,
		int $source_height,
	): true|WP_Error {
		$width = $source_width;
		$height = $source_height;
		foreach ($operations as $operation) {
			if ($operation['type'] === 'rotate') {
				// RESOURCE INVARIANT: A valid source can expand to almost twice its
				// pixels during a fine rotation. Bound the intermediate canvas too.
				$radians = deg2rad($operation['degrees']);
				$cosine = abs(cos($radians)) < 1e-10 ? 0 : abs(cos($radians));
				$sine = abs(sin($radians)) < 1e-10 ? 0 : abs(sin($radians));
				$rotated_width = (int) ceil($width * $cosine + $height * $sine);
				$rotated_height = (int) ceil($width * $sine + $height * $cosine);
				if ($rotated_width * $rotated_height > WPHAVE_Media_Image_Source_Gate::MAX_PIXELS) {
					return new WP_Error(
						'wphave_image_editor_too_large',
						__('The image exceeds the safe editing limit of 40 megapixels.', 'wphave'),
						['status' => 400],
					);
				}
				$width = $rotated_width;
				$height = $rotated_height;
			}
			if ($operation['type'] === 'crop') {
				// CONTRACT INVARIANT: Coordinates describe this exact transformed
				// preview, never a client-selected scale for an unrelated canvas.
				if (
					$operation['referenceWidth'] !== $width ||
					$operation['referenceHeight'] !== $height
				) {
					return new WP_Error(
						'wphave_image_editor_invalid_crop',
						__('The crop area does not match the transformed image.', 'wphave'),
						['status' => 400],
					);
				}
				$crop = self::image_edit_crop_on_canvas(
					$operation,
					$width,
					$height,
				);
				if (is_wp_error($crop)) {
					return $crop;
				}
				$width = $operation['width'];
				$height = $operation['height'];
			}
		}
		return true;
	}

	private static function image_edit_crop_on_canvas(
		array $crop,
		int $canvas_width,
		int $canvas_height,
	): array|WP_Error {
		// PREVIEW INVARIANT: The overlay covers the complete transformed canvas.
		// A backend decoder may round its rotated bounds differently from CSS;
		// scale the selection to the actual editor canvas before cropping.
		$reference_width = $crop['referenceWidth'];
		$reference_height = $crop['referenceHeight'];
		// INPUT INVARIANT: Reject out-of-range coordinates before multiplying.
		// PHP can otherwise overflow a large integer through float arithmetic
		// and cast it back to a small, apparently valid crop coordinate.
		if (
			$crop['x'] >= $reference_width ||
			$crop['y'] >= $reference_height ||
			$crop['width'] > $reference_width - $crop['x'] ||
			$crop['height'] > $reference_height - $crop['y']
		) {
			return new WP_Error(
				'wphave_image_editor_invalid_crop',
				__('The crop area exceeds the rotated image.', 'wphave'),
				['status' => 400],
			);
		}
		$x = (int) round($crop['x'] * $canvas_width / $reference_width);
		$y = (int) round($crop['y'] * $canvas_height / $reference_height);
		$width = (int) round(($crop['x'] + $crop['width']) * $canvas_width / $reference_width) - $x;
		$height = (int) round(($crop['y'] + $crop['height']) * $canvas_height / $reference_height) - $y;
		if (
			$x < 0 ||
			$y < 0 ||
			$width < 1 ||
			$height < 1 ||
			$width > $canvas_width - $x ||
			$height > $canvas_height - $y
		) {
			return new WP_Error(
				'wphave_image_editor_invalid_crop',
				__('The crop area exceeds the rotated image.', 'wphave'),
				['status' => 400],
			);
		}
		return ['x' => $x, 'y' => $y, 'width' => $width, 'height' => $height];
	}

	private static function replace_with_edited_image(
		$attachment_id,
		$source,
		$temporary,
		$temporary_identity,
		$mime,
		$expected_checksum,
		$requires_pro = false,
	) {
		$old_metadata = get_post_meta($attachment_id, '_wp_attachment_metadata', true);
		$old_files = self::collect_attachment_files($attachment_id);
		if (is_wp_error($old_files)) {
			return $old_files;
		}
		$backups = [];
		// RECOVERY INVARIANT: Only completed mutations grant rollback authority.
		$mutations = [];
		$target_validation = self::validate_replace_targets($source, $old_files);

		if (is_wp_error($target_validation)) {
			return $target_validation;
		}

		$backup_budget = new WPHAVE_Media_Image_Backup_Budget();
		foreach ($old_files as $file) {
			if (empty($file['exists'])) {
				continue;
			}
			$backup = self::create_backup_path($file['path']);
			try {
				$backup_identity = WPHAVE_Security_Atomic_File::copy_observed(
					$file['path'],
					$backup,
					__('The current image files could not be backed up.', 'wphave'),
					$backup_budget->next_limit(),
				);
			} catch (RuntimeException $error) {
				self::cleanup_backups($backups);
				return self::image_editor_failure(
					'wphave_image_editor_backup_failed',
					$error->getMessage(),
					500,
				);
			}
			// RESOURCE INVARIANT: Every derivative consumes the same bounded backup
			// budget; copy_observed also rejects a source growing while copied.
			$backup_budget->consume($backup_identity['bytes']);
			$backups[] = [
				'path' => $file['path'],
				'backup' => $backup,
				'checksum' => $backup_identity['checksum'],
				'bytes' => $backup_identity['bytes'],
				// RECOVERY INVARIANT: Capture live mode and group before private backup storage.
				'permissions' => $backup_identity['permissions'],
				'group' => $backup_identity['group'],
			];
		}
		$source_backup = self::backup_for_path($backups, $source);
		if (!hash_equals($expected_checksum, (string) ($source_backup['checksum'] ?? ''))) {
			self::cleanup_backups($backups);
			return new WP_Error(
				'wphave_image_editor_conflict',
				__('The image changed after the editor was opened. Reload it before saving.', 'wphave'),
				['status' => 409],
			);
		}
		try {
			// PUBLICATION INVARIANT: A foreign source GID may be unavailable to
			// PHP. Substitute the local staging group only when the old group had
			// no access beyond the old public permissions.
			$publication_group = WPHAVE_Security_File_Permissions::replacement_group($source_backup);
		} catch (RuntimeException $error) {
			self::cleanup_backups($backups);
			return self::image_editor_failure(
				'wphave_image_editor_group_unavailable',
				__('The original image permissions cannot be preserved safely.', 'wphave'),
				409,
			);
		}

		try {
			static::before_replace_commit($attachment_id, $source);
		} catch (Throwable $error) {
			// PRECOMMIT INVARIANT: A throwing extension hook has not changed live
			// files. Release only checksum-owned backup snapshots; the caller owns
			// cleanup of its private encoded stage.
			self::cleanup_backups($backups);
			return new WP_Error(
				'wphave_image_editor_precommit_failed',
				__('Image edit preparation failed. No changes were saved.', 'wphave'),
				['status' => 500],
			);
		}

		// AUTHORIZATION/TOCTOU INVARIANT: The pre-commit seam may execute extension
		// code. Its return does not lease the earlier capability decision across the
		// first live derivative removal or source-image replacement.
		if (!self::current_user_can_manage_attachment_file($attachment_id)) {
			self::cleanup_backups($backups);

			return new WP_Error(
				'wphave_attachment_file_forbidden',
				__('You are not allowed to manage this media file.', 'wphave'),
				['status' => 403],
			);
		}
		// ENTITLEMENT INVARIANT: The pre-commit hook can change license state.
		// Check again before removing any derivative or replacing live bytes.
		if ($requires_pro) {
			$pro_access = self::require_compression_pro_access();
			if (is_wp_error($pro_access)) {
				self::cleanup_backups($backups);
				return $pro_access;
			}
		}
		if (!self::is_file_action_allowed($requires_pro ? 'compress' : 'edit')) {
			self::cleanup_backups($backups);
			return new WP_Error('wphave_media_file_action_disabled', __('This file action is disabled in Media Settings.', 'wphave'), ['status' => 403]);
		}
		if (!self::attachment_source_still_registered((int) $attachment_id, $source, $mime)) {
			self::cleanup_backups($backups);
			return new WP_Error(
				'wphave_image_editor_source_changed',
				__('The attachment file changed while editing. Reload it before saving.', 'wphave'),
				['status' => 409],
			);
		}

		foreach ($old_files as $file) {
			if ($file['path'] === $source || !file_exists($file['path'])) {
				continue;
			}
			// OWNERSHIP INVARIANT: A derivative planned earlier may now be the
			// registered main file of another attachment. Never delete it then.
			if (self::is_registered_other_attachment_file($file['path'], (int) $attachment_id)) {
				$recovery = self::restore_backups((int) $attachment_id, $backups, [], $mutations);
				if (is_wp_error($recovery)) {
					return $recovery;
				}
				self::cleanup_backups($backups);
				return new WP_Error(
					'wphave_image_editor_derivative_reassigned',
					__('An image size changed ownership while editing. Reload it before saving.', 'wphave'),
					['status' => 409],
				);
			}
			$backup = self::backup_for_path($backups, $file['path']);
			try {
				// SECURITY INVARIANT: Editor derivative cleanup owns the exact snapshot
				// node, not a path that another request may have replaced.
				WPHAVE_Security_Conditional_File::remove_if_matches(
					$file['path'],
					(string) ($backup['checksum'] ?? ''),
					__('An edited-image derivative changed before cleanup.', 'wphave'),
					isset($backup['bytes']) && is_int($backup['bytes'])
						? max(1, $backup['bytes'])
						: 0,
				);
				$mutations[$file['path']] = null;
			} catch (RuntimeException $error) {
				$recovery = self::restore_backups((int) $attachment_id, $backups, [$file['path']], $mutations);
				// RECOVERY INVARIANT: Failed rollback retains snapshots and current metadata.
				if (is_wp_error($recovery)) {
					return $recovery;
				}
				self::cleanup_backups($backups);
				return new WP_Error(
					'wphave_image_editor_target_changed',
					__('An image file changed concurrently. The edit was not applied.', 'wphave'),
					['status' => 409],
				);
			}
		}

		try {
			// SECURITY INVARIANT: The edited bytes replace only the source revision
			// that was captured before the editor transaction began mutating files.
			WPHAVE_Security_Conditional_File::replace_if_matches(
				$source,
				(string) ($source_backup['checksum'] ?? ''),
				$temporary,
				(string) $temporary_identity['checksum'],
				__('The original image changed before the edit could be committed.', 'wphave'),
				// PUBLICATION INVARIANT: Retain the captured live mode; group substitution
				// is allowed only when it cannot grant additional effective access.
				WPHAVE_Security_File_Permissions::existing($source_backup),
				$publication_group,
				self::IMAGE_EDITOR_MAX_OUTPUT_BYTES,
				max(1, (int) ($source_backup['bytes'] ?? 0)),
			);
			// COMMIT INVARIANT: Normal return means committed even if quarantine
			// cleanup is pending. Always record ownership before later rollback.
			$mutations[$source] = [
				'checksum' => (string) $temporary_identity['checksum'],
				'bytes' => (int) $temporary_identity['bytes'],
			];
		} catch (RuntimeException $error) {
			$recovery = self::restore_backups((int) $attachment_id, $backups, [$source], $mutations);
			// RECOVERY INVARIANT: Failed rollback retains snapshots and current metadata.
			if (is_wp_error($recovery)) {
				return $recovery;
			}
			self::cleanup_backups($backups);
			return new WP_Error(
				'wphave_image_editor_target_changed',
				__('The original image changed concurrently. The edit was not applied.', 'wphave'),
				['status' => 409],
			);
		}

		try {
			$metadata = self::regenerate_replaced_attachment_metadata($attachment_id, $source);
		} catch (Throwable $error) {
			// EXCEPTION INVARIANT: A throwing WordPress image hook is a failed
			// metadata transaction and must enter the same conditional rollback.
			$metadata = new WP_Error(
				'wphave_image_editor_metadata_failed',
				__('The edited image metadata could not be generated.', 'wphave'),
				['status' => 500],
			);
		}
		// TRANSACTION INVARIANT: Live bytes and WordPress image metadata must
		// advance together; failed regeneration restores the captured file set.
		if (is_wp_error($metadata)) {
			$recovery = self::restore_backups((int) $attachment_id, $backups, [], $mutations);
			// RECOVERY INVARIANT: Failed rollback retains snapshots and current metadata.
			if (is_wp_error($recovery)) {
				return $recovery;
			}
			$record_recovery = self::restore_replacement_record_if_owned(
				(int) $attachment_id,
				$source,
				$old_metadata,
				$mime,
				[$mime],
			);
			if (is_wp_error($record_recovery)) {
				return $record_recovery;
			}
			self::cleanup_backups($backups);
			return $metadata;
		}
		// POST-GENERATION INVARIANT: Image metadata hooks may rebind the record
		// after the file commit. Never report success for a different attachment
		// binding; rollback only the file revisions this transaction published.
		if (
			!self::attachment_source_still_registered((int) $attachment_id, $source, $mime) ||
			!self::published_image_bytes_match_stage($source, $temporary_identity)
		) {
			$recovery = self::restore_backups((int) $attachment_id, $backups, [], $mutations);
			if (is_wp_error($recovery)) {
				return $recovery;
			}
			$record_recovery = self::restore_replacement_record_if_owned(
				(int) $attachment_id,
				$source,
				$old_metadata,
				$mime,
				[$mime],
			);
			if (is_wp_error($record_recovery)) {
				return $record_recovery;
			}
			self::cleanup_backups($backups);
			return new WP_Error(
				'wphave_image_editor_source_changed',
				__('The attachment changed while image metadata was generated.', 'wphave'),
				['status' => 409],
			);
		}

		// RESPONSE INVARIANT: A URL filter may rebind the record after metadata
		// generation. Resolve it while recovery snapshots still exist.
		try {
			$url = wp_get_attachment_url($attachment_id);
		} catch (Throwable $error) {
			// COMMIT INVARIANT: A URL filter runs after file and metadata commit.
			// Its failure cannot turn a published replacement into a failed write.
			$url = null;
		}
		if (
			!self::attachment_source_still_registered((int) $attachment_id, $source, $mime) ||
			!self::published_image_bytes_match_stage($source, $temporary_identity)
		) {
			$recovery = self::restore_backups((int) $attachment_id, $backups, [], $mutations);
			if (is_wp_error($recovery)) {
				return $recovery;
			}
			$record_recovery = self::restore_replacement_record_if_owned(
				(int) $attachment_id,
				$source,
				$old_metadata,
				$mime,
				[$mime],
			);
			if (is_wp_error($record_recovery)) {
				return $record_recovery;
			}
			self::cleanup_backups($backups);
			return new WP_Error(
				'wphave_image_editor_source_changed',
				__('The attachment changed while its URL was resolved.', 'wphave'),
				['status' => 409],
			);
		}
		try {
			clean_post_cache($attachment_id);
		} catch (Throwable $error) {
			// COMMIT INVARIANT: Cache invalidation follows the file and metadata
			// commit. A throwing cache hook cannot turn published bytes into an
			// uncommitted result or invite a duplicate retry.
			$url = null;
		}
		if (
			!self::attachment_source_still_registered((int) $attachment_id, $source, $mime) ||
			!self::published_image_bytes_match_stage($source, $temporary_identity) ||
			get_post_meta($attachment_id, '_wp_attachment_metadata', true) !== $metadata
		) {
			// FINALIZATION INVARIANT: Cache hooks may mutate the record. Keep
			// recovery snapshots until the exact post-hook revision is verified.
			$recovery = self::restore_backups((int) $attachment_id, $backups, [], $mutations);
			return is_wp_error($recovery)
				? $recovery
				: self::replacement_record_recovery_required();
		}
		self::cleanup_backups($backups);
		return [
			'id' => $attachment_id,
			'mode' => 'replace',
			'url' => is_string($url) && $url !== ''
				? add_query_arg('wphave-edited', time(), $url)
				: null,
			'metadata' => $metadata,
		];
	}

	private static function create_edited_image_copy(
		$attachment_id,
		$source,
		$temporary,
		$temporary_identity,
		$mime,
		$expected_checksum,
		$source_mime = null,
		$requires_pro = false,
	) {
		$source_mime = $source_mime ?? $mime;
		// COPY INVARIANT: A copy is still derived from the loaded source revision.
		// Reject a change that happened during image processing before publication.
		try {
			$source_identity = WPHAVE_Security_File_Identity::inspect_bounded(
				$source,
				WPHAVE_Media_Image_Source_Gate::MAX_BYTES,
				__('The source image changed before the copy was published.', 'wphave'),
			);
		} catch (RuntimeException $error) {
			$source_identity = [];
		}
		if (!hash_equals($expected_checksum, (string) ($source_identity['checksum'] ?? ''))) {
			return new WP_Error(
				'wphave_image_editor_conflict',
				__('The image changed after the editor was opened. Reload it before saving.', 'wphave'),
				['status' => 409],
			);
		}
		try {
			$filename = wp_unique_filename(
				dirname($source),
				pathinfo($source, PATHINFO_FILENAME) .
					'-edited.' .
					($mime === 'image/webp' ? 'webp' : pathinfo($source, PATHINFO_EXTENSION)),
			);
		} catch (Throwable $error) {
			return new WP_Error(
				'wphave_image_editor_copy_filename_failed',
				__('A filename for the edited image could not be reserved.', 'wphave'),
				['status' => 500],
			);
		}
		// NAME INVARIANT: A filename filter must not publish image bytes under
		// a misleading extension, even when its destination stays in uploads.
		if (!self::copy_filename_matches_mime($filename, $mime)) {
			return new WP_Error(
				'wphave_image_editor_copy_failed',
				__('The edited image copy could not be created.', 'wphave'),
				['status' => 500],
			);
		}
		$destination = self::normalize_target_upload_path(
			trailingslashit(dirname($source)) . $filename,
		);
		if (!$destination) {
			return new WP_Error(
				'wphave_image_editor_copy_failed',
				__('The edited image copy could not be created.', 'wphave'),
				['status' => 500],
			);
		}
		// Filename filters can run after image processing. Neither the earlier
		// object permission nor source registration is leased across those hooks.
		if (!self::current_user_can_manage_attachment_file($attachment_id)) {
			return new WP_Error(
				'wphave_attachment_file_forbidden',
				__('You are not allowed to manage this media file.', 'wphave'),
				['status' => 403],
			);
		}
		// ENTITLEMENT INVARIANT: Filename filters run after the earlier Pro
		// check. Recheck immediately before publishing any new attachment bytes.
		if ($requires_pro) {
			$pro_access = self::require_compression_pro_access();
			if (is_wp_error($pro_access)) {
				return $pro_access;
			}
		}
		// POLICY INVARIANT: Filename filters run immediately before copy
		// publication and may revoke the site action after earlier checks.
		if (!self::is_file_action_allowed($requires_pro ? 'compress' : 'edit')) {
			return new WP_Error('wphave_media_file_action_disabled', __('This file action is disabled in Media Settings.', 'wphave'), ['status' => 403]);
		}
		if (!self::attachment_source_still_registered((int) $attachment_id, $source, $source_mime)) {
			return new WP_Error(
				'wphave_image_editor_source_changed',
				__('The attachment file changed while editing. Reload it before saving.', 'wphave'),
				['status' => 409],
			);
		}
		// REVISION INVARIANT: Filename callbacks can modify the source bytes
		// without changing its attachment path or MIME. A copy must derive from
		// the same revision immediately before its create-only publication.
		try {
			$current_source = WPHAVE_Security_File_Identity::inspect_bounded(
				$source,
				WPHAVE_Media_Image_Source_Gate::MAX_BYTES,
				__('The source image changed before the copy was published.', 'wphave'),
			);
		} catch (RuntimeException $error) {
			$current_source = [];
		}
		if (!hash_equals($expected_checksum, (string) ($current_source['checksum'] ?? ''))) {
			return new WP_Error(
				'wphave_image_editor_conflict',
				__('The image changed after the editor was opened. Reload it before saving.', 'wphave'),
				['status' => 409],
			);
		}
		try {
			// SECURITY INVARIANT: The filename reservation and publication are one
			// create-only commit; a concurrent destination is never overwritten.
			WPHAVE_Security_Atomic_File::copy_verified_new(
				$temporary,
				$destination,
				(string) $temporary_identity['checksum'],
				__('The edited image copy could not be created.', 'wphave'),
				// PUBLICATION INVARIANT: A new image uses its trusted destination directory.
				WPHAVE_Security_File_Permissions::for_new_public_file($destination),
				null,
				self::IMAGE_EDITOR_MAX_OUTPUT_BYTES,
			);
		} catch (RuntimeException $error) {
			return self::image_editor_failure(
				'wphave_image_editor_copy_failed',
				$error->getMessage(),
				409,
			);
		}

		$parent = get_post($attachment_id);
		// COPY INVARIANT: Register the new attachment only after verified bytes
		// exist at a create-only destination inside uploads.
		try {
			$copy_id = wp_insert_attachment(
				[
					'post_mime_type' => $mime,
					'post_title' => $parent
						? $parent->post_title . ' ' . __('Edited', 'wphave')
						: pathinfo($filename, PATHINFO_FILENAME),
					'post_status' => 'inherit',
				],
				$destination,
				$parent ? $parent->post_parent : 0,
				true,
			);
		} catch (Throwable $error) {
			// REGISTRATION INVARIANT: The database insert may have committed
			// before a hook threw. We cannot prove that the published file is
			// unregistered, so retain it for recovery instead of deleting by path.
			return new WP_Error(
				'wphave_image_editor_copy_registration_uncertain',
				__('The edited image may have been created, but registration could not be confirmed. Inspect the media library before retrying.', 'wphave'),
				['status' => 500],
			);
		}
		// INSERT INVARIANT: A zero/non-ID result is not a registered copy and
		// must take the same conditional file-cleanup path as WP_Error.
		if (is_wp_error($copy_id) || !is_int($copy_id) || $copy_id < 1) {
			try {
				WPHAVE_Security_Conditional_File::remove_if_matches(
					$destination,
					(string) $temporary_identity['checksum'],
					__(
						'Failed edited-image attachment data could not be cleaned up safely.',
						'wphave',
					),
				);
			} catch (RuntimeException $error) {
				// Preserve an unproven destination rather than deleting foreign data.
			}
			return is_wp_error($copy_id)
				? $copy_id
				: new WP_Error(
					'wphave_image_editor_copy_registration_failed',
					__('The edited image copy could not be registered.', 'wphave'),
					['status' => 500],
				);
		}
		if (
			!self::edited_copy_matches_destination($copy_id, $destination, $mime) ||
			!self::published_image_bytes_match_stage($destination, $temporary_identity)
		) {
			// REGISTRATION INVARIANT: Attachment hooks may repurpose the new ID.
			// Do not generate metadata for a record no longer bound to our file.
			return new WP_Error(
				'wphave_image_editor_copy_registration_changed',
				__('The edited image copy changed during registration.', 'wphave'),
				['status' => 409, 'attachment_id' => $copy_id],
			);
		}

		require_once ABSPATH . 'wp-admin/includes/image.php';
		try {
			$metadata = wp_generate_attachment_metadata($copy_id, $destination);
		} catch (Throwable $error) {
			// RECOVERY INVARIANT: The copy is already published. A throwing hook
			// cannot make this an uncommitted edit or authorize deleting its record.
			return new WP_Error(
				'wphave_image_editor_copy_metadata_failed',
				__('The edited image metadata could not be generated.', 'wphave'),
				['status' => 500, 'attachment_id' => $copy_id],
			);
		}
		// BINDING INVARIANT: Metadata generation invokes WordPress hooks. A hook
		// may rebind this newly allocated ID; check it again before writing any
		// metadata to a record that may now belong to a different image.
		if (
			!self::edited_copy_matches_destination($copy_id, $destination, $mime) ||
			!self::published_image_bytes_match_stage($destination, $temporary_identity)
		) {
			return new WP_Error(
				'wphave_image_editor_copy_registration_changed',
				__('The edited image copy changed during metadata generation.', 'wphave'),
				['status' => 409, 'attachment_id' => $copy_id],
			);
		}
		try {
			$metadata_updated = is_array($metadata)
				? wp_update_attachment_metadata($copy_id, $metadata)
				: false;
		} catch (Throwable $error) {
			return new WP_Error(
				'wphave_image_editor_copy_metadata_failed',
				__('The edited image metadata could not be saved.', 'wphave'),
				['status' => 500, 'attachment_id' => $copy_id],
			);
		}
		// update_metadata() returns false both for errors and unchanged values.
		if (
			!is_array($metadata) ||
			(!$metadata_updated && wp_get_attachment_metadata($copy_id) !== $metadata)
		) {
			// ROLLBACK INVARIANT: Metadata hooks may repurpose a newly registered
			// attachment before this failure is observed. A result ID alone does
			// not authorize deletion of its record and referenced image files.
			// Retain the incomplete copy for explicit recovery.
			return new WP_Error(
				'wphave_image_editor_copy_metadata_failed',
				__('The edited image metadata could not be saved.', 'wphave'),
				['status' => 500, 'attachment_id' => $copy_id],
			);
		}
		if (
			!self::edited_copy_matches_destination($copy_id, $destination, $mime, true)
		) {
			return new WP_Error(
				'wphave_image_editor_copy_registration_changed',
				__('The edited image copy changed during metadata generation.', 'wphave'),
				['status' => 409, 'attachment_id' => $copy_id],
			);
		}
		try {
			$url = wp_get_attachment_url($copy_id);
		} catch (Throwable $error) {
			// The copy is already registered and its metadata is committed.
			// Return its ID so the client can reload or reconcile it safely.
			$url = null;
		}
		if (
			!self::edited_copy_matches_destination($copy_id, $destination, $mime, true) ||
			!self::published_image_bytes_match_stage($destination, $temporary_identity)
		) {
			return new WP_Error(
				'wphave_image_editor_copy_registration_changed',
				__('The edited image copy changed while its URL was resolved.', 'wphave'),
				['status' => 409, 'attachment_id' => $copy_id],
			);
		}
		return [
			'id' => $copy_id,
			'mode' => 'copy',
			'url' => is_string($url) && $url !== '' ? $url : null,
			'metadata' => $metadata,
			'_committedPath' => $destination,
		];
	}

	/** Hooks may rewrite published bytes without rebinding their attachment. */
	private static function published_image_bytes_match_stage(string $destination, array $stage): bool {
		try {
			$current = WPHAVE_Security_File_Identity::inspect_bounded(
				$destination,
				self::IMAGE_EDITOR_MAX_OUTPUT_BYTES,
				__('The edited image copy changed during registration.', 'wphave'),
			);
		} catch (RuntimeException $error) {
			return false;
		}
		return hash_equals((string) ($stage['checksum'] ?? ''), (string) ($current['checksum'] ?? ''));
	}

	/** Reject a filtered copy name whose extension disagrees with encoded bytes. */
	private static function copy_filename_matches_mime($filename, $mime): bool {
		if (!is_string($filename) || !is_string($mime)) {
			return false;
		}
		$extensions = [
			'image/jpeg' => ['jpg', 'jpeg', 'jpe'],
			'image/png' => ['png'],
			'image/webp' => ['webp'],
			'image/avif' => ['avif'],
		];
		return in_array(
			strtolower(pathinfo($filename, PATHINFO_EXTENSION)),
			$extensions[$mime] ?? [],
			true,
		);
	}

	/** The newly registered attachment must still name the published file. */
	private static function edited_copy_matches_destination(
		int $attachment_id,
		string $destination,
		string $mime,
		bool $require_metadata = false,
	): bool {
		$post = get_post($attachment_id);
		$relative = self::get_relative_upload_path($destination);
		$metadata = $require_metadata
			? get_post_meta($attachment_id, '_wp_attachment_metadata', true)
			: null;
		return $post &&
			$post->post_type === 'attachment' &&
			$post->post_mime_type === $mime &&
			$relative !== '' &&
			get_post_meta($attachment_id, '_wp_attached_file', true) === $relative &&
			!self::is_registered_other_attachment_file($destination, $attachment_id) &&
			(!$require_metadata ||
				(is_array($metadata) && ($metadata['file'] ?? null) === $relative));
	}

	/**
	 * Map internal filesystem diagnostics onto the public REST error contract.
	 *
	 * SECURITY INVARIANT: Image transactions may fail with absolute upload paths,
	 * filenames or personal identifiers in their exception text. Those details
	 * must cross the REST boundary only through the central diagnostic redactor.
	 */

	private static function image_editor_failure(
		string $code,
		string $message,
		int $status,
	): WP_Error {
		return new WP_Error(sanitize_key($code), WPHAVE_Security_Redactor::error_text($message), [
			'status' => $status,
		]);
	}

	private static function edited_attachment_still_bound(
		int $attachment_id,
		string $expected_path,
		string $mime,
	): bool {
		$relative = self::get_relative_upload_path($expected_path);
		$metadata = get_post_meta($attachment_id, '_wp_attachment_metadata', true);
		return $relative !== '' &&
			self::attachment_source_still_registered($attachment_id, $expected_path, $mime) &&
			is_array($metadata) &&
			($metadata['file'] ?? null) === $relative;
	}

	private static function update_edited_attachment_details(
		int $attachment_id,
		array $details,
		string $expected_path,
		string $mime,
	): bool {
		// IDENTITY INVARIANT: Hooks may rebind an attachment after the file commit.
		// Details belong only to the exact file that this edit published.
		if (!self::edited_attachment_still_bound($attachment_id, $expected_path, $mime)) {
			return false;
		}
		$post = ['ID' => $attachment_id];
		if (array_key_exists('title', $details)) {
			$post['post_title'] = sanitize_text_field($details['title']);
		}
		if (array_key_exists('caption', $details)) {
			$post['post_excerpt'] = sanitize_textarea_field($details['caption']);
		}
		if (array_key_exists('description', $details)) {
			$post['post_content'] = wp_kses_post($details['description']);
		}
		if (count($post) > 1) {
			$updated = wp_update_post($post, true);
			if (is_wp_error($updated) || !$updated) {
				return false;
			}
			if (!self::edited_attachment_still_bound($attachment_id, $expected_path, $mime)) {
				return false;
			}
			foreach (['post_title', 'post_excerpt', 'post_content'] as $field) {
				if (array_key_exists($field, $post) && get_post_field($field, $attachment_id, 'raw') !== $post[$field]) {
					return false;
				}
			}
		}
		if (array_key_exists('alt', $details)) {
			if (
				!self::current_user_can_manage_attachment_file($attachment_id) ||
				!self::edited_attachment_still_bound($attachment_id, $expected_path, $mime)
			) {
				return false;
			}
			$alt = sanitize_text_field($details['alt']);
			update_post_meta(
				$attachment_id,
				'_wp_attachment_image_alt',
				$alt,
			);
			if (get_post_meta($attachment_id, '_wp_attachment_image_alt', true) !== $alt) {
				return false;
			}
		}
		return self::edited_attachment_still_bound($attachment_id, $expected_path, $mime);
	}
}
