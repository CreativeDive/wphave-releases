<?php

/**
 * Secure, transactional image editing for existing media attachments.
 *
 * The client submits declarative operations only. Source and destination paths
 * are always resolved from the attachment and confined to the uploads folder.
 */

trait WPHAVE_Attachment_Image_Editor {
	private static function edit_attachment_image(
		$attachment_id,
		$operations,
		$mode,
		$expected_modified,
		$details = [],
	) {
		$validation = self::validate_attachment($attachment_id);

		if (is_wp_error($validation)) {
			return $validation;
		}

		$source = self::normalize_existing_upload_path(get_attached_file($attachment_id));
		$mime = get_post_mime_type($attachment_id);
		$allowed_mimes = ['image/jpeg', 'image/png', 'image/webp', 'image/avif'];

		if (!wp_attachment_is_image($attachment_id) || !in_array($mime, $allowed_mimes, true)) {
			return new WP_Error(
				'wphave_image_editor_unsupported_type',
				__('This image type cannot be edited safely.', 'wphave'),
				['status' => 400],
			);
		}

		if (!$source || (int) filemtime($source) !== $expected_modified) {
			return new WP_Error(
				'wphave_image_editor_conflict',
				__(
					'The image changed after the editor was opened. Reload it before saving.',
					'wphave',
				),
				['status' => 409],
			);
		}

		$image_size = wp_getimagesize($source);

		if (!$image_size || $image_size[0] * $image_size[1] > 40000000) {
			return new WP_Error(
				'wphave_image_editor_too_large',
				__('The image exceeds the safe editing limit of 40 megapixels.', 'wphave'),
				['status' => 400],
			);
		}

		$operations = self::sanitize_image_operations($operations);
		if (is_wp_error($operations)) {
			return $operations;
		}
		if (!$operations) {
			if (!$details) {
				return new WP_Error(
					'wphave_image_editor_no_changes',
					__('Make at least one image adjustment before saving.', 'wphave'),
					['status' => 400],
				);
			}
			self::update_edited_attachment_details($attachment_id, $details);
			return [
				'id' => $attachment_id,
				'mode' => 'details',
				'url' => wp_get_attachment_url($attachment_id),
				'metadata' => wp_get_attachment_metadata($attachment_id),
			];
		}

		$editor = wp_get_image_editor($source);
		if (is_wp_error($editor)) {
			return $editor;
		}

		foreach ($operations as $operation) {
			$result = true;
			if ($operation['type'] === 'rotate') {
				$result = $editor->rotate($operation['degrees']);
			}
			if ($operation['type'] === 'flip') {
				$result = $editor->flip($operation['horizontal'], $operation['vertical']);
			}
			if ($operation['type'] === 'crop') {
				$result = $editor->crop(
					$operation['x'],
					$operation['y'],
					$operation['width'],
					$operation['height'],
				);
			}
			if ($operation['type'] === 'resize') {
				$result = $editor->resize($operation['width'], $operation['height'], false);
			}
			if (is_wp_error($result)) {
				return $result;
			}
		}

		$extension = pathinfo($source, PATHINFO_EXTENSION);
		$temporary = self::normalize_target_upload_path(
			trailingslashit(dirname($source)) .
				'.wphave-edit-' .
				wp_generate_uuid4() .
				'.' .
				$extension,
		);
		$saved = $temporary ? $editor->save($temporary, $mime) : false;

		if (
			is_wp_error($saved) ||
			!$temporary ||
			!file_exists($temporary) ||
			filesize($temporary) < 1
		) {
			if ($temporary && file_exists($temporary)) {
				@unlink($temporary);
			}
			return new WP_Error(
				'wphave_image_editor_processing_failed',
				__('The edited image could not be generated.', 'wphave'),
				['status' => 500],
			);
		}
		try {
			$temporary_identity = WPHAVE_Security_File_Identity::inspect(
				$temporary,
				__('The edited image output could not be inspected safely.', 'wphave'),
			);
		} catch (RuntimeException $error) {
			return self::image_editor_failure(
				'wphave_image_editor_processing_failed',
				$error->getMessage(),
				500,
			);
		}

		/*
		 * AUTHORIZATION/TOCTOU INVARIANT: Image editor selection, decoding and
		 * transformation may invoke extension callbacks. Recheck the exact
		 * attachment authority after that work and before either a replacement or
		 * a new Media Library object can be published.
		 */
		if (!self::current_user_can_manage_attachment_file($attachment_id)) {
			try {
				WPHAVE_Security_Conditional_File::remove_if_matches(
					$temporary,
					$temporary_identity['checksum'],
					__('Revoked image-edit staging could not be cleaned up safely.', 'wphave'),
				);
			} catch (RuntimeException $cleanup_error) {
				// Preserve an unproven staging node for operator recovery.
			}

			return new WP_Error(
				'wphave_attachment_file_forbidden',
				__('You are not allowed to manage this media file.', 'wphave'),
				['status' => 403],
			);
		}

		$result =
			$mode === 'replace'
				? self::replace_with_edited_image(
					$attachment_id,
					$source,
					$temporary,
					$temporary_identity,
					$mime,
				)
				: self::create_edited_image_copy(
					$attachment_id,
					$source,
					$temporary,
					$temporary_identity,
					$mime,
				);

		try {
			WPHAVE_Security_Conditional_File::remove_if_matches(
				$temporary,
				$temporary_identity['checksum'],
				__('Edited image staging could not be cleaned up safely.', 'wphave'),
			);
		} catch (RuntimeException $error) {
			// Preserve a replaced or otherwise unproven staging node.
		}
		if (is_wp_error($result)) {
			return $result;
		}

		self::update_edited_attachment_details($result['id'], $details);
		return $result;
	}

	private static function sanitize_image_operations($operations) {
		$sanitized = [];
		if (count($operations) > 12) {
			return new WP_Error(
				'wphave_image_editor_too_many_operations',
				__('Too many image operations were submitted.', 'wphave'),
				['status' => 400],
			);
		}

		foreach ($operations as $operation) {
			$type = sanitize_key($operation['type'] ?? '');
			if ($type === 'rotate') {
				$degrees = (float) ($operation['degrees'] ?? 0);
				if ($degrees < -360 || $degrees > 360 || $degrees == 0) {
					return new WP_Error(
						'wphave_image_editor_invalid_rotate',
						__('The rotation value is invalid.', 'wphave'),
						['status' => 400],
					);
				}
				$sanitized[] = ['type' => $type, 'degrees' => $degrees];
			} elseif ($type === 'flip') {
				$horizontal = !empty($operation['horizontal']);
				$vertical = !empty($operation['vertical']);
				if (!$horizontal && !$vertical) {
					return new WP_Error(
						'wphave_image_editor_invalid_flip',
						__('The flip operation is invalid.', 'wphave'),
						['status' => 400],
					);
				}
				$sanitized[] = [
					'type' => $type,
					'horizontal' => $horizontal,
					'vertical' => $vertical,
				];
			} elseif (in_array($type, ['crop', 'resize'], true)) {
				$width = absint($operation['width'] ?? 0);
				$height = absint($operation['height'] ?? 0);
				if (
					$width < 1 ||
					$height < 1 ||
					$width > 12000 ||
					$height > 12000 ||
					$width * $height > 40000000
				) {
					return new WP_Error(
						'wphave_image_editor_invalid_size',
						__('The requested image dimensions are invalid.', 'wphave'),
						['status' => 400],
					);
				}
				$item = ['type' => $type, 'width' => $width, 'height' => $height];
				if ($type === 'crop') {
					$item += [
						'x' => absint($operation['x'] ?? 0),
						'y' => absint($operation['y'] ?? 0),
					];
				}
				$sanitized[] = $item;
			} else {
				return new WP_Error(
					'wphave_image_editor_invalid_operation',
					__('An unsupported image operation was submitted.', 'wphave'),
					['status' => 400],
				);
			}
		}

		return $sanitized;
	}

	private static function replace_with_edited_image(
		$attachment_id,
		$source,
		$temporary,
		$temporary_identity,
		$mime,
	) {
		$old_metadata = wp_get_attachment_metadata($attachment_id);
		$old_files = self::collect_attachment_files($attachment_id);
		$backups = [];
		// RECOVERY INVARIANT: Only completed mutations grant rollback authority.
		$mutations = [];
		$target_validation = self::validate_replace_targets($source, $old_files);

		if (is_wp_error($target_validation)) {
			return $target_validation;
		}

		foreach ($old_files as $file) {
			if (empty($file['exists'])) {
				continue;
			}
			$backup = self::create_backup_path($file['path']);
			try {
				$backup_identity = WPHAVE_Security_Atomic_File::copy_observed(
					$file['path'],
					$backup,
					__('The current image files could not be backed up.', 'wphave'),
				);
			} catch (RuntimeException $error) {
				self::cleanup_backups($backups);
				return self::image_editor_failure(
					'wphave_image_editor_backup_failed',
					$error->getMessage(),
					500,
				);
			}
			$backups[] = [
				'path' => $file['path'],
				'backup' => $backup,
				'checksum' => $backup_identity['checksum'],
				// RECOVERY INVARIANT: Capture live mode and group before private backup storage.
				'permissions' => $backup_identity['permissions'],
				'group' => $backup_identity['group'],
			];
		}

		static::before_replace_commit($attachment_id, $source);

		// AUTHORIZATION/TOCTOU INVARIANT: The pre-commit seam may execute extension
		// code. Its return does not lease the earlier capability decision across the
		// first live derivative removal or source-image replacement.
		if (!self::current_user_can_manage_attachment_file($attachment_id)) {
			self::cleanup_backups($backups);

			return new WP_Error(
				'wphave_attachment_file_forbidden',
				__('You are not allowed to manage this media file.', 'wphave'),
				['status' => 403],
			);
		}

		foreach ($old_files as $file) {
			if ($file['path'] === $source || !file_exists($file['path'])) {
				continue;
			}
			$backup = self::backup_for_path($backups, $file['path']);
			try {
				// SECURITY INVARIANT: Editor derivative cleanup owns the exact snapshot
				// node, not a path that another request may have replaced.
				WPHAVE_Security_Conditional_File::remove_if_matches(
					$file['path'],
					(string) ($backup['checksum'] ?? ''),
					__('An edited-image derivative changed before cleanup.', 'wphave'),
				);
				$mutations[$file['path']] = null;
			} catch (RuntimeException $error) {
				$recovery = self::restore_backups($backups, [$file['path']], $mutations);
				// RECOVERY INVARIANT: Failed rollback retains snapshots and current metadata.
				if (is_wp_error($recovery)) {
					return $recovery;
				}
				self::cleanup_backups($backups);
				return new WP_Error(
					'wphave_image_editor_target_changed',
					__('An image file changed concurrently. The edit was not applied.', 'wphave'),
					['status' => 409],
				);
			}
		}

		$source_backup = self::backup_for_path($backups, $source);
		try {
			// SECURITY INVARIANT: The edited bytes replace only the source revision
			// that was captured before the editor transaction began mutating files.
			WPHAVE_Security_Conditional_File::replace_if_matches(
				$source,
				(string) ($source_backup['checksum'] ?? ''),
				$temporary,
				(string) $temporary_identity['checksum'],
				__('The original image changed before the edit could be committed.', 'wphave'),
				// PUBLICATION INVARIANT: Replacement retains the captured live mode and group.
				WPHAVE_Security_File_Permissions::existing($source_backup),
				WPHAVE_Security_File_Permissions::recorded_group($source_backup['group'] ?? null),
			);
			// COMMIT INVARIANT: Normal return means committed even if quarantine
			// cleanup is pending. Always record ownership before later rollback.
			$mutations[$source] = (string) $temporary_identity['checksum'];
		} catch (RuntimeException $error) {
			$recovery = self::restore_backups($backups, [$source], $mutations);
			// RECOVERY INVARIANT: Failed rollback retains snapshots and current metadata.
			if (is_wp_error($recovery)) {
				return $recovery;
			}
			self::cleanup_backups($backups);
			return new WP_Error(
				'wphave_image_editor_target_changed',
				__('The original image changed concurrently. The edit was not applied.', 'wphave'),
				['status' => 409],
			);
		}

		$metadata = self::regenerate_replaced_attachment_metadata($attachment_id, $source);
		if (is_wp_error($metadata)) {
			$recovery = self::restore_backups($backups, [], $mutations);
			// RECOVERY INVARIANT: Failed rollback retains snapshots and current metadata.
			if (is_wp_error($recovery)) {
				return $recovery;
			}
			self::cleanup_generated_metadata_files($source, $metadata, $old_files);
			self::restore_attachment_file_state($attachment_id, $source, $old_metadata, $mime);
			self::cleanup_backups($backups);
			return $metadata;
		}

		self::cleanup_backups($backups);
		clean_post_cache($attachment_id);
		return [
			'id' => $attachment_id,
			'mode' => 'replace',
			'url' => add_query_arg('wphave-edited', time(), wp_get_attachment_url($attachment_id)),
			'metadata' => $metadata,
		];
	}

	private static function create_edited_image_copy(
		$attachment_id,
		$source,
		$temporary,
		$temporary_identity,
		$mime,
	) {
		$filename = wp_unique_filename(
			dirname($source),
			pathinfo($source, PATHINFO_FILENAME) .
				'-edited.' .
				pathinfo($source, PATHINFO_EXTENSION),
		);
		$destination = self::normalize_target_upload_path(
			trailingslashit(dirname($source)) . $filename,
		);
		if (!$destination) {
			return new WP_Error(
				'wphave_image_editor_copy_failed',
				__('The edited image copy could not be created.', 'wphave'),
				['status' => 500],
			);
		}
		try {
			// SECURITY INVARIANT: The filename reservation and publication are one
			// create-only commit; a concurrent destination is never overwritten.
			WPHAVE_Security_Atomic_File::copy_verified_new(
				$temporary,
				$destination,
				(string) $temporary_identity['checksum'],
				__('The edited image copy could not be created.', 'wphave'),
				// PUBLICATION INVARIANT: A new image uses its trusted destination directory.
				WPHAVE_Security_File_Permissions::for_new_public_file($destination),
			);
		} catch (RuntimeException $error) {
			return self::image_editor_failure(
				'wphave_image_editor_copy_failed',
				$error->getMessage(),
				409,
			);
		}

		$parent = get_post($attachment_id);
		$copy_id = wp_insert_attachment(
			[
				'post_mime_type' => $mime,
				'post_title' => $parent
					? $parent->post_title . ' ' . __('Edited', 'wphave')
					: pathinfo($filename, PATHINFO_FILENAME),
				'post_status' => 'inherit',
			],
			$destination,
			$parent ? $parent->post_parent : 0,
			true,
		);
		if (is_wp_error($copy_id)) {
			try {
				WPHAVE_Security_Conditional_File::remove_if_matches(
					$destination,
					(string) $temporary_identity['checksum'],
					__(
						'Failed edited-image attachment data could not be cleaned up safely.',
						'wphave',
					),
				);
			} catch (RuntimeException $error) {
				// Preserve an unproven destination rather than deleting foreign data.
			}
			return $copy_id;
		}

		require_once ABSPATH . 'wp-admin/includes/image.php';
		$metadata = wp_generate_attachment_metadata($copy_id, $destination);
		$metadata_updated = is_array($metadata)
			? wp_update_attachment_metadata($copy_id, $metadata)
			: false;
		// update_metadata() returns false both for errors and unchanged values.
		if (
			!is_array($metadata) ||
			(!$metadata_updated && wp_get_attachment_metadata($copy_id) !== $metadata)
		) {
			wp_delete_attachment($copy_id, true);
			return new WP_Error(
				'wphave_image_editor_copy_metadata_failed',
				__('The edited image metadata could not be saved.', 'wphave'),
				['status' => 500],
			);
		}
		return [
			'id' => $copy_id,
			'mode' => 'copy',
			'url' => wp_get_attachment_url($copy_id),
			'metadata' => $metadata,
		];
	}

	/**
	 * Map internal filesystem diagnostics onto the public REST error contract.
	 *
	 * SECURITY INVARIANT: Image transactions may fail with absolute upload paths,
	 * filenames or personal identifiers in their exception text. Those details
	 * must cross the REST boundary only through the central diagnostic redactor.
	 */

	private static function image_editor_failure(
		string $code,
		string $message,
		int $status,
	): WP_Error {
		return new WP_Error(sanitize_key($code), WPHAVE_Security_Redactor::error_text($message), [
			'status' => $status,
		]);
	}

	private static function update_edited_attachment_details($attachment_id, $details) {
		$post = ['ID' => $attachment_id];
		if (array_key_exists('title', $details)) {
			$post['post_title'] = sanitize_text_field($details['title']);
		}
		if (array_key_exists('caption', $details)) {
			$post['post_excerpt'] = sanitize_textarea_field($details['caption']);
		}
		if (array_key_exists('description', $details)) {
			$post['post_content'] = wp_kses_post($details['description']);
		}
		if (count($post) > 1) {
			wp_update_post($post);
		}
		if (array_key_exists('alt', $details)) {
			update_post_meta(
				$attachment_id,
				'_wp_attachment_image_alt',
				sanitize_text_field($details['alt']),
			);
		}
	}
}
