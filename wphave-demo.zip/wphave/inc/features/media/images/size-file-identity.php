<?php

/** Shared, metadata-independent naming rules for WordPress image sizes. */
final class WPHAVE_Media_Image_Size_File_Identity {
	public static function is_safe_basename(string $filename): bool {
		if ($filename === '' || strlen($filename) > 255) {
			return false;
		}
		$extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
		return $filename !== '.' &&
			$filename !== '..' &&
			!str_contains($filename, '/') &&
			!str_contains($filename, '\\') &&
			basename($filename) === $filename &&
			in_array($extension, ['jpg', 'jpeg', 'png', 'webp', 'avif', 'gif', 'txt'], true);
	}

	public static function matches_generated_size(string $source, $size): bool {
		if (
			!is_array($size) ||
			!is_string($size['file'] ?? null) ||
			!self::is_safe_basename($size['file']) ||
			!is_numeric($size['width'] ?? null) ||
			!is_numeric($size['height'] ?? null)
		) {
			return false;
		}
		$width = absint($size['width']);
		$height = absint($size['height']);
		if ($width < 1 || $height < 1) {
			return false;
		}
		$main_stem = pathinfo($source, PATHINFO_FILENAME);
		$base_stem = preg_replace('/-(?:scaled|rotated)$/', '', $main_stem);
		$size_stem = pathinfo($size['file'], PATHINFO_FILENAME);
		if ($main_stem === '') {
			return false;
		}

		foreach (array_unique([$main_stem, $base_stem]) as $source_stem) {
			$expected = $source_stem . '-' . $width . 'x' . $height;
			// FILENAME INVARIANT: WordPress adds a positive numeric suffix when
			// a generated size's filename collides. The full source stem and
			// recorded dimensions must still match exactly.
			if (preg_match('/^' . preg_quote($expected, '/') . '(?:-[1-9][0-9]*)?$/D', $size_stem)) {
				return true;
			}
		}

		return false;
	}
}
