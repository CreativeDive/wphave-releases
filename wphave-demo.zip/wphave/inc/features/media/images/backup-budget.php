<?php

/** Bound the temporary copies required to replace one raster attachment. */
final class WPHAVE_Media_Image_Backup_Budget {
	public const MAX_FILE_BYTES = 268435456;
	public const MAX_TOTAL_BYTES = 1073741824;

	private int $remaining = self::MAX_TOTAL_BYTES;

	/** The next copy must satisfy both the per-file and transaction ceilings. */
	public function next_limit(): int {
		return min(self::MAX_FILE_BYTES, $this->remaining);
	}

	/** Debit only bytes from a completed, verified copy. */
	public function consume(int $bytes): void {
		if ($bytes < 0 || $bytes > $this->next_limit()) {
			throw new RuntimeException('The image backup budget was exceeded.');
		}
		$this->remaining -= $bytes;
	}
}
