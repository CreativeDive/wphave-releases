<?php

/** Shared pre-decode resource and byte-format gate for local raster images. */
final class WPHAVE_Media_Image_Source_Gate {
	public const MAX_BYTES = 134217728;
	public const MAX_PIXELS = 40000000;
	public const MAX_OUTPUT_BYTES = 268435456;

	public static function inspect(string $path, string $mime, bool $require_static = true): array {
		clearstatcache(true, $path);
		$bytes = filesize($path);
		// RESOURCE INVARIANT: The header parser and decoder never receive a
		// source that already exceeds the bounded file-size contract.
		if (!is_int($bytes) || $bytes < 1 || $bytes > self::MAX_BYTES) {
			return ['error' => 'size', 'reason' => 'file_size', 'bytes' => $bytes];
		}

		$size = wp_getimagesize($path);
		if (!$size) {
			return ['error' => 'type', 'reason' => 'unreadable_header'];
		}
		if (($size['mime'] ?? '') !== $mime) {
			// TYPE INVARIANT: The file header is authoritative for the actual
			// format. Never decode or regenerate against stale attachment MIME.
			return [
				'error' => 'type',
				'reason' => 'mime_mismatch',
				'registered_mime' => $mime,
				'detected_mime' => $size['mime'] ?? '',
			];
		}
		if (
			!is_int($size[0] ?? null) ||
			!is_int($size[1] ?? null) ||
			$size[0] < 1 ||
			$size[1] < 1 ||
			$size[0] * $size[1] > self::MAX_PIXELS
		) {
			return [
				'error' => 'size',
				'reason' => 'dimensions',
				'width' => $size[0] ?? null,
				'height' => $size[1] ?? null,
			];
		}
		// FRAME INVARIANT: The image editors used by this workflow render a
		// single frame. An animated WebP must not silently become a still image.
		// VP8X feature flags are byte 20; bit 1 declares animation. Read only
		// this bounded header after the MIME and file-size gates above.
		if ($require_static && $mime === 'image/webp') {
			$header = file_get_contents($path, false, null, 0, 21);
			if (
				$header === false ||
				strlen($header) < 21 ||
				(substr($header, 12, 4) === 'VP8X' && (ord($header[20]) & 0x02) !== 0)
			) {
				return ['error' => 'type', 'reason' => 'frame_or_header'];
			}
		}
		if ($require_static && $mime === 'image/avif' && !self::is_static_avif($path)) {
			return ['error' => 'type', 'reason' => 'frame_or_header'];
		}
		if ($require_static && $mime === 'image/png' && !self::is_static_png($path, $bytes)) {
			return ['error' => 'type', 'reason' => 'frame_or_header'];
		}

		return [
			'bytes' => $bytes,
			'width' => $size[0],
			'height' => $size[1],
		];
	}

	private static function is_static_png(string $path, int $bytes): bool {
		// FRAME INVARIANT: APNG declares acTL before the first IDAT chunk.
		// Inspect only chunk headers, with finite file and chunk-count bounds;
		// a single-frame encoder must not discard animation on publication.
		$handle = fopen($path, 'rb');
		if ($handle === false) {
			return false;
		}
		try {
			if (fread($handle, 8) !== "\x89PNG\r\n\x1a\n") {
				return false;
			}
			$offset = 8;
			for ($chunk_count = 0; $chunk_count < 10000; $chunk_count++) {
				if ($offset + 12 > $bytes) {
					return false;
				}
				$header = fread($handle, 8);
				if ($header === false || strlen($header) !== 8) {
					return false;
				}
				$length = unpack('N', substr($header, 0, 4))[1];
				$type = substr($header, 4, 4);
				if (
				$offset + 12 + $length > $bytes ||
				($chunk_count === 0 && ($type !== 'IHDR' || $length !== 13))
				) {
					return false;
				}
				if ($type === 'acTL' || $type === 'IEND') {
					return false;
				}
				if ($type === 'IDAT') {
					return true;
				}
				if (fseek($handle, $length + 4, SEEK_CUR) !== 0) {
					return false;
				}
				$offset += 12 + $length;
			}
			return false;
		} finally {
			fclose($handle);
		}
	}

	private static function is_static_avif(string $path): bool {
		// FRAME INVARIANT: The AVIF sequence brand (avis) denotes multiple
		// frames. Inspect only the bounded ftyp box; a malformed or oversized
		// brand list cannot authorize a single-frame image editor.
		$header = file_get_contents($path, false, null, 0, 16);
		if ($header === false || strlen($header) !== 16 || substr($header, 4, 4) !== 'ftyp') {
			return false;
		}
		$box_size = unpack('N', substr($header, 0, 4))[1];
		if ($box_size < 16 || $box_size > 4096 || ($box_size - 16) % 4 !== 0) {
			return false;
		}
		$brands = file_get_contents($path, false, null, 0, $box_size);
		if ($brands === false || strlen($brands) !== $box_size) {
			return false;
		}
		for ($offset = 8; $offset < $box_size; $offset += 4) {
			if ($offset !== 12 && substr($brands, $offset, 4) === 'avis') {
				return false;
			}
		}
		return true;
	}
}
