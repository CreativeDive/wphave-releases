<?php

/**
 * Central class for analyzing and regenerating existing image sizes.
 *
 * The manager only processes raster images that can produce WordPress
 * intermediate image sizes. SVG files and other non-raster media are
 * excluded. Generated image sizes are recreated through WordPress core
 * metadata generation and optimized by the media helper pipeline.
 */

if (!defined('ABSPATH')) {
	exit();
}

if (!class_exists('WPHAVE_Regenerate_Thumbnails_Manager')):
	class WPHAVE_Regenerate_Thumbnails_Manager {
		/**
		 * Initialize the feature.
		 */

		public static function init() {
			add_action('rest_api_init', [__CLASS__, 'register_rest_routes']);
		}

		/**
		 * Register rest routes.
		 */

		public static function register_rest_routes() {
			$args = [
				'last_id' => [
					'type' => 'integer',
					'default' => 0,
					'sanitize_callback' => 'absint',
				],
				'limit' => [
					'type' => 'integer',
					'default' => 10,
					'sanitize_callback' => 'absint',
				],
			];

			register_rest_route('wphave/v1', '/regenerate-thumbnails', [
				'methods' => WP_REST_Server::CREATABLE,
				'callback' => [__CLASS__, 'rest_regenerate_batch'],
				'permission_callback' => [__CLASS__, 'can_regenerate'],
				'args' => array_merge($args, [
					'mode' => [
						'type' => 'string',
						'default' => 'all',
						'sanitize_callback' => 'sanitize_key',
						'validate_callback' => function ($value) {
							return in_array($value, ['all', 'missing'], true);
						},
					],
				]),
			]);

			register_rest_route('wphave/v1', '/regenerate-thumbnails/(?P<id>\d+)', [
				'methods' => WP_REST_Server::CREATABLE,
				'callback' => [__CLASS__, 'rest_regenerate_attachment'],
				'permission_callback' => [__CLASS__, 'can_regenerate_attachment'],
				'args' => [
					'id' => [
						'type' => 'integer',
						'required' => true,
						'sanitize_callback' => 'absint',
					],
					'mode' => [
						'type' => 'string',
						'default' => 'all',
						'sanitize_callback' => 'sanitize_key',
						'validate_callback' => function ($value) {
							return in_array($value, ['all', 'missing'], true);
						},
					],
				],
			]);

			register_rest_route('wphave/v1', '/regenerate-thumbnails/count', [
				'methods' => WP_REST_Server::READABLE,
				'callback' => [__CLASS__, 'rest_count'],
				'permission_callback' => [__CLASS__, 'can_regenerate'],
			]);

			register_rest_route('wphave/v1', '/regenerate-thumbnails/analyze', [
				'methods' => WP_REST_Server::READABLE,
				'callback' => [__CLASS__, 'rest_analyze'],
				'permission_callback' => [__CLASS__, 'can_regenerate'],
				'args' => $args,
			]);
		}

		/**
		 * Determine whether the current user may regenerate thumbnails.
		 *
		 * @return bool
		 */

		public static function can_regenerate() {
			/*
			 * SECURITY/ENTITLEMENT INVARIANT: Client-side Pro state is presentation
			 * only. A modified React store must not authorize this server-side media
			 * mutation, even when the current user has every WordPress capability.
			 */
			if (!function_exists('wphave_has_pro_access') || !wphave_has_pro_access()) {
				return false;
			}

			if (current_user_can('manage_options')) {
				return true;
			}

			return current_user_can('wphave_manage_image_regeneration') &&
				current_user_can('upload_files');
		}

		/**
		 * Determine whether regenerate attachment.
		 *
		 * @param WP_REST_Request $request
		 * @return bool
		 */

		public static function can_regenerate_attachment(WP_REST_Request $request) {
			$attachment_id = absint($request->get_param('id'));

			// SECURITY INVARIANT: Global regeneration access does not authorize mutation
			// of every media object; the exact attachment must remain editable by the user.
			return self::can_regenerate() && current_user_can('edit_post', $attachment_id);
		}

		private static function require_regeneration_permission($allowed) {
			// AUTHORIZATION INVARIANT: Route-level Pro and capability checks are an
			// early gate. Every public REST callback repeats the applicable global or
			// exact-object policy before inventory access or image processing.
			if (!$allowed) {
				return new WP_Error(
					'wphave_thumbnail_regeneration_forbidden',
					__('You are not allowed to regenerate these image sizes.', 'wphave'),
					['status' => 403],
				);
			}

			return true;
		}

		/**
		 * Return the query where.
		 *
		 * @return string
		 */

		public static function get_query_where() {
			return "
				post_type = 'attachment'
				AND post_status = 'inherit'
				AND post_mime_type LIKE 'image/%'
				AND post_mime_type != 'image/svg+xml'
			";
		}

		/**
		 * Normalize the limit.
		 *
		 * @param int $limit
		 * @return int
		 */

		public static function normalize_limit($limit) {
			$limit = absint($limit);
			$limit = $limit > 0 ? $limit : 10;

			return min($limit, 25);
		}

		/**
		 * Return an attachment IDs.
		 *
		 * @param int $last_id
		 * @param int $limit
		 * @return array
		 */

		public static function get_attachment_ids($last_id = 0, $limit = 10) {
			global $wpdb;

			$last_id = absint($last_id);
			$limit = self::normalize_limit($limit);
			$where = self::get_query_where();

			return array_map(
				'absint',
				$wpdb->get_col(
					$wpdb->prepare(
						"
				SELECT ID FROM {$wpdb->posts}
				WHERE {$where}
				AND ID > %d
				ORDER BY ID ASC
				LIMIT %d
			",
						$last_id,
						$limit,
					),
				),
			);
		}

		/**
		 * Count an attachments.
		 *
		 * @return int
		 */

		public static function count_attachments() {
			global $wpdb;

			$where = self::get_query_where();

			return (int) $wpdb->get_var("
				SELECT COUNT(ID)
				FROM {$wpdb->posts}
				WHERE {$where}
			");
		}

		/**
		 * Determine whether an attachment needs thumbnail regeneration.
		 *
		 * @param int $attachment_id
		 * @param array $registered_sizes
		 * @return array
		 */

		public static function image_needs_regeneration($attachment_id, $registered_sizes) {
			$file = get_attached_file($attachment_id);

			if (!$file || !file_exists($file) || !is_readable($file)) {
				return [
					'needs_regeneration' => false,
					'error' => __('Original file not found or not readable.', 'wphave'),
				];
			}

			$metadata = wp_get_attachment_metadata($attachment_id);
			$existing_sizes =
				is_array($metadata) && !empty($metadata['sizes']) ? $metadata['sizes'] : [];
			$width = isset($metadata['width']) ? absint($metadata['width']) : 0;
			$height = isset($metadata['height']) ? absint($metadata['height']) : 0;

			if (!$width || !$height) {
				$dimensions = wp_getimagesize($file);
				$width = isset($dimensions[0]) ? absint($dimensions[0]) : 0;
				$height = isset($dimensions[1]) ? absint($dimensions[1]) : 0;
			}

			if (!$width || !$height) {
				return [
					'needs_regeneration' => false,
					'error' => __('Image dimensions could not be read.', 'wphave'),
				];
			}

			foreach ($registered_sizes as $size_name => $size_data) {
				$target_width = isset($size_data['width']) ? absint($size_data['width']) : 0;
				$target_height = isset($size_data['height']) ? absint($size_data['height']) : 0;
				$crop = !empty($size_data['crop']);

				if (!$target_width && !$target_height) {
					continue;
				}

				if (
					!image_resize_dimensions($width, $height, $target_width, $target_height, $crop)
				) {
					continue;
				}

				if (empty($existing_sizes[$size_name]['file'])) {
					return [
						'needs_regeneration' => true,
						'error' => null,
					];
				}
			}

			return [
				'needs_regeneration' => false,
				'error' => null,
			];
		}

		/**
		 * Return an error item.
		 *
		 * @param int $attachment_id
		 * @param string $message
		 * @return array
		 */

		public static function get_error_item($attachment_id, $message) {
			// Presentation lookups can invoke the same failing WordPress filter again.
			// Keep them optional so they cannot replace the original diagnostic.
			$context = ['name' => '', 'file' => '', 'editUrl' => ''];
			try {
				$file = get_attached_file($attachment_id);
				$context['name'] = get_the_title($attachment_id);
				$context['file'] = $file ? wp_basename($file) : '';
				$context['editUrl'] = get_edit_post_link($attachment_id, 'raw') ?: '';
			} catch (Throwable $context_error) {
				// The attachment ID still identifies the failed operation.
			}

			return [
				'id' => absint($attachment_id),
				'name' => $context['name'],
				'file' => $context['file'],
				'editUrl' => $context['editUrl'],
				// SECURITY INVARIANT: Image drivers may include absolute source paths or
				// embedded identifiers in failure messages. Batch responses expose only
				// the centrally redacted diagnostic representation.
				'error' => WPHAVE_Security_Redactor::error_text($message),
			];
		}

		/**
		 * Analyze a batch of attachments for missing image sizes.
		 *
		 * @param int $last_id
		 * @param int $limit
		 * @return array
		 */

		public static function analyze_batch($last_id = 0, $limit = 10) {
			$limit = self::normalize_limit($limit);
			$attachment_ids = self::get_attachment_ids($last_id, $limit);
			$registered_sizes = wp_get_registered_image_subsizes();
			$total = 0;
			$needs_regeneration = 0;
			$ok = 0;
			$errors = [];

			foreach ($attachment_ids as $attachment_id) {
				$total++;

				// SECURITY INVARIANT: A delegated global workflow may enumerate a
				// bounded cursor, but it may neither inspect nor mutate an attachment
				// unless WordPress authorizes that exact object for the current user.
				if (!current_user_can('edit_post', $attachment_id)) {
					continue;
				}

				$result = self::image_needs_regeneration($attachment_id, $registered_sizes);

				if (!empty($result['error'])) {
					$errors[] = self::get_error_item($attachment_id, $result['error']);
					continue;
				}

				if (!empty($result['needs_regeneration'])) {
					$needs_regeneration++;
				} else {
					$ok++;
				}
			}

			return [
				'total' => $total,
				'needs_regeneration' => $needs_regeneration,
				'ok' => $ok,
				'errors' => $errors,
				'last_id' => !empty($attachment_ids) ? end($attachment_ids) : absint($last_id),
				'done' => count($attachment_ids) < $limit,
			];
		}

		/**
		 * Regenerate a batch of attachment image sizes.
		 *
		 * @param int $last_id
		 * @param int $limit
		 * @param string $mode
		 * @return array
		 */

		public static function regenerate_batch($last_id = 0, $limit = 10, $mode = 'all') {
			self::ensure_image_runtime();

			$limit = self::normalize_limit($limit);
			$mode = in_array($mode, ['all', 'missing'], true) ? $mode : 'all';
			$attachment_ids = self::get_attachment_ids($last_id, $limit);
			$registered_sizes = wp_get_registered_image_subsizes();
			$current = null;
			$processed = 0;
			$skipped = 0;
			$scanned = 0;
			$last_scanned_id = absint($last_id);
			$errors = [];

			$GLOBALS['wphave_image_log'] = [];
			$GLOBALS['wphave_image_log_grouped'] = [];
			$GLOBALS['wphave_is_regenerating_images'] = true;

			try {
				try {
					foreach ($attachment_ids as $attachment_id) {
						$scanned++;
						$last_scanned_id = absint($attachment_id);

						// SECURITY INVARIANT: The batch capability authorizes the workflow,
						// never every media object returned by a global attachment query.
						// Recheck the native meta capability immediately before file work.
						if (!current_user_can('edit_post', $attachment_id)) {
							$skipped++;
							continue;
						}

						$file = get_attached_file($attachment_id);
						$current = [
							'id' => $attachment_id,
							'url' => wp_get_attachment_image_url($attachment_id, 'thumbnail'),
							'name' => get_the_title($attachment_id),
						];

						if (!$file || !file_exists($file) || !is_readable($file)) {
							$errors[] = self::get_error_item(
								$attachment_id,
								__('Original file not found or not readable.', 'wphave'),
							);
							continue;
						}

						if ($mode === 'missing') {
							$check = self::image_needs_regeneration(
								$attachment_id,
								$registered_sizes,
							);

							if (!empty($check['error'])) {
								$errors[] = self::get_error_item($attachment_id, $check['error']);
								continue;
							}

							if (empty($check['needs_regeneration'])) {
								$skipped++;
								continue;
							}
						}

						$metadata = null;
						$result = self::regenerate_attachment_file($attachment_id, $file);

						if (!empty($result['error'])) {
							$errors[] = self::get_error_item($attachment_id, $result['error']);
							continue;
						}

						$metadata = $result['metadata'];

						$processed++;
					}
				} catch (Throwable $e) {
					$errors[] = self::get_error_item($last_scanned_id, $e->getMessage());
				}

				$log = array_values($GLOBALS['wphave_image_log_grouped'] ?? []);
			} finally {
				$GLOBALS['wphave_image_log'] = [];
				$GLOBALS['wphave_image_log_grouped'] = [];
				$GLOBALS['wphave_is_regenerating_images'] = false;
			}

			return [
				'processed' => $processed,
				'skipped' => $skipped,
				'scanned' => $scanned,
				// Never advance past images that an interrupted batch did not visit.
				'last_id' => $last_scanned_id,
				'done' => $scanned === count($attachment_ids) && count($attachment_ids) < $limit,
				'mode' => $mode,
				'errors' => $errors,
				'current' => $current,
				'log' => $log,
			];
		}

		/**
		 * Regenerate metadata and image sizes for an attachment file.
		 *
		 * @param int $attachment_id
		 * @param string $file
		 * @return array
		 */

		public static function regenerate_attachment_file($attachment_id, $file) {
			$metadata = null;
			$exception = null;

			set_error_handler(function () {
				return true;
			});

			try {
				$metadata = wp_generate_attachment_metadata($attachment_id, $file);
			} catch (Throwable $e) {
				$exception = $e;
			} finally {
				restore_error_handler();
			}

			if ($exception) {
				return [
					'metadata' => null,
					'error' => WPHAVE_Security_Redactor::error_text($exception->getMessage()),
				];
			}

			if (is_wp_error($metadata) || empty($metadata) || !is_array($metadata)) {
				return [
					'metadata' => null,
					'error' => is_wp_error($metadata)
						? WPHAVE_Security_Redactor::error_text($metadata->get_error_message())
						: __('Metadata could not be generated.', 'wphave'),
				];
			}

			$updated = wp_update_attachment_metadata($attachment_id, $metadata);
			// WordPress also returns false for unchanged values. Confirm those from
			// stored metadata, without presentation filters, before reporting success.
			if (!$updated && wp_get_attachment_metadata($attachment_id, true) !== $metadata) {
				return [
					'metadata' => null,
					'error' => __(
						'The generated image metadata could not be confirmed as saved. Refresh the image details before trying again.',
						'wphave',
					),
				];
			}

			return [
				'metadata' => $metadata,
				'error' => null,
			];
		}

		/**
		 * Regenerate the requested attachment image sizes.
		 *
		 * @param int $attachment_id
		 * @param string $mode
		 * @return array
		 */

		public static function regenerate_attachment($attachment_id, $mode = 'all') {
			self::ensure_image_runtime();

			$attachment_id = absint($attachment_id);
			$mode = in_array($mode, ['all', 'missing'], true) ? $mode : 'all';
			$post = get_post($attachment_id);
			$mime_type = get_post_mime_type($attachment_id);
			$errors = [];
			$skipped = 0;

			$GLOBALS['wphave_image_log'] = [];
			$GLOBALS['wphave_image_log_grouped'] = [];
			$GLOBALS['wphave_is_regenerating_images'] = true;

			try {
				if (
					!$post ||
					$post->post_type !== 'attachment' ||
					strpos((string) $mime_type, 'image/') !== 0 ||
					$mime_type === 'image/svg+xml'
				) {
					$errors[] = self::get_error_item(
						$attachment_id,
						__('This attachment is not a supported image file.', 'wphave'),
					);
				} else {
					$file = get_attached_file($attachment_id);

					if (!$file || !file_exists($file) || !is_readable($file)) {
						$errors[] = self::get_error_item(
							$attachment_id,
							__('Original file not found or not readable.', 'wphave'),
						);
					} else {
						if ($mode === 'missing') {
							$check = self::image_needs_regeneration(
								$attachment_id,
								wp_get_registered_image_subsizes(),
							);

							if (!empty($check['error'])) {
								$errors[] = self::get_error_item($attachment_id, $check['error']);
							} elseif (empty($check['needs_regeneration'])) {
								$skipped = 1;
							}
						}

						if (empty($errors) && !$skipped) {
							$result = self::regenerate_attachment_file($attachment_id, $file);

							if (!empty($result['error'])) {
								$errors[] = self::get_error_item($attachment_id, $result['error']);
							}
						}
					}
				}

				$log = array_values($GLOBALS['wphave_image_log_grouped'] ?? []);
			} finally {
				$GLOBALS['wphave_image_log'] = [];
				$GLOBALS['wphave_image_log_grouped'] = [];
				$GLOBALS['wphave_is_regenerating_images'] = false;
			}

			return [
				'processed' => empty($errors) && !$skipped ? 1 : 0,
				'skipped' => $skipped,
				'errors' => $errors,
				'mode' => $mode,
				'current' => [
					'id' => $attachment_id,
					'url' => wp_get_attachment_image_url($attachment_id, 'thumbnail'),
					'name' => get_the_title($attachment_id),
				],
				'log' => $log,
			];
		}

		/**
		 * Loads WordPress image helpers and raises safe runtime limits.
		 */

		public static function ensure_image_runtime() {
			if (!function_exists('wp_generate_attachment_metadata')) {
				require_once ABSPATH . 'wp-admin/includes/image.php';
			}

			if (function_exists('wp_raise_memory_limit')) {
				wp_raise_memory_limit('image');
			}

			if (function_exists('set_time_limit')) {
				@set_time_limit(60);
			}
		}

		/**
		 * Return the number of attachments eligible for regeneration.
		 */

		public static function rest_count() {
			$authorization = self::require_regeneration_permission(self::can_regenerate());

			if (is_wp_error($authorization)) {
				return $authorization;
			}

			return rest_ensure_response([
				'total' => self::count_attachments(),
			]);
		}

		/**
		 * Analyze a batch of attachments through the REST API.
		 */

		public static function rest_analyze(WP_REST_Request $request) {
			$authorization = self::require_regeneration_permission(self::can_regenerate());

			if (is_wp_error($authorization)) {
				return $authorization;
			}

			return rest_ensure_response(
				self::analyze_batch($request->get_param('last_id'), $request->get_param('limit')),
			);
		}

		/**
		 * Regenerate a batch of attachments through the REST API.
		 */

		public static function rest_regenerate_batch(WP_REST_Request $request) {
			$authorization = self::require_regeneration_permission(self::can_regenerate());

			if (is_wp_error($authorization)) {
				return $authorization;
			}

			return rest_ensure_response(
				self::regenerate_batch(
					$request->get_param('last_id'),
					$request->get_param('limit'),
					sanitize_key($request->get_param('mode') ?: 'all'),
				),
			);
		}

		/**
		 * Regenerate a single attachment through the REST API.
		 */

		public static function rest_regenerate_attachment(WP_REST_Request $request) {
			$authorization = self::require_regeneration_permission(
				self::can_regenerate_attachment($request),
			);

			if (is_wp_error($authorization)) {
				return $authorization;
			}

			return rest_ensure_response(
				self::regenerate_attachment(
					$request->get_param('id'),
					sanitize_key($request->get_param('mode') ?: 'all'),
				),
			);
		}
	}
endif;

WPHAVE_Regenerate_Thumbnails_Manager::init();
