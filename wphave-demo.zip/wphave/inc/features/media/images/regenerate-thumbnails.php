<?php

/**
 * Central class for analyzing and regenerating existing image sizes.
 *
 * The manager only processes raster images that can produce WordPress
 * intermediate image sizes. SVG files and other non-raster media are
 * excluded. Generated image sizes are recreated through WordPress core
 * metadata generation and optimized by the media helper pipeline.
 */

if (!defined('ABSPATH')) {
	exit();
}

require_once dirname(__DIR__, 2) . '/security/safe-link.php';
require_once __DIR__ . '/size-file-identity.php';
require_once __DIR__ . '/source-gate.php';
require_once dirname(__DIR__, 2) . '/security/file-identity.php';
require_once dirname(__DIR__) . '/attachments/file-registration.php';

if (!class_exists('WPHAVE_Regenerate_Thumbnails_Manager')):
	class WPHAVE_Regenerate_Thumbnails_Manager {
		/**
		 * Initialize the feature.
		 */

		public static function init() {
			add_action('rest_api_init', [__CLASS__, 'register_rest_routes']);
		}

		/**
		 * Register rest routes.
		 */

		public static function register_rest_routes() {
			$args = [
				'last_id' => [
					'type' => 'integer',
					'default' => 0,
					'sanitize_callback' => 'absint',
				],
				'limit' => [
					'type' => 'integer',
					'default' => 10,
					'sanitize_callback' => 'absint',
				],
			];

			register_rest_route('wphave/v1', '/regenerate-thumbnails', [
				'methods' => WP_REST_Server::CREATABLE,
				'callback' => [__CLASS__, 'rest_regenerate_batch'],
				'permission_callback' => [__CLASS__, 'can_regenerate'],
				'args' => array_merge($args, [
					'mode' => [
						'type' => 'string',
						'default' => 'all',
						'sanitize_callback' => 'sanitize_key',
						'validate_callback' => function ($value) {
							return in_array($value, ['all', 'missing'], true);
						},
					],
				]),
			]);

			register_rest_route('wphave/v1', '/regenerate-thumbnails/(?P<id>\d+)', [
				'methods' => WP_REST_Server::CREATABLE,
				'callback' => [__CLASS__, 'rest_regenerate_attachment'],
				'permission_callback' => [__CLASS__, 'can_regenerate_attachment'],
				'args' => [
					'id' => [
						'type' => 'integer',
						'required' => true,
						'sanitize_callback' => 'absint',
					],
					'mode' => [
						'type' => 'string',
						'default' => 'all',
						'sanitize_callback' => 'sanitize_key',
						'validate_callback' => function ($value) {
							return in_array($value, ['all', 'missing'], true);
						},
					],
				],
			]);

			register_rest_route('wphave/v1', '/regenerate-thumbnails/count', [
				'methods' => WP_REST_Server::READABLE,
				'callback' => [__CLASS__, 'rest_count'],
				'permission_callback' => [__CLASS__, 'can_regenerate'],
			]);

			register_rest_route('wphave/v1', '/regenerate-thumbnails/analyze', [
				'methods' => WP_REST_Server::READABLE,
				'callback' => [__CLASS__, 'rest_analyze'],
				'permission_callback' => [__CLASS__, 'can_regenerate'],
				'args' => $args,
			]);
		}

		/**
		 * Determine whether the current user may regenerate thumbnails.
		 *
		 * @return bool
		 */

		public static function can_regenerate() {
			/*
			 * SECURITY/ENTITLEMENT INVARIANT: Client-side Pro state is presentation
			 * only. A modified React store must not authorize this server-side media
			 * mutation, even when the current user has every WordPress capability.
			 */
			if (!function_exists('wphave_has_pro_access') || !wphave_has_pro_access()) {
				return false;
			}

			if (current_user_can('manage_options')) {
				return true;
			}

			return current_user_can('wphave_manage_image_regeneration') &&
				current_user_can('upload_files');
		}

		/**
		 * Determine whether regenerate attachment.
		 *
		 * @param WP_REST_Request $request
		 * @return bool
		 */

		public static function can_regenerate_attachment(WP_REST_Request $request) {
			$attachment_id = absint($request->get_param('id'));

			// SECURITY INVARIANT: Global regeneration access does not authorize mutation
			// of every media object; the exact attachment must remain editable by the user.
			return self::can_regenerate() && current_user_can('edit_post', $attachment_id);
		}

		/**
		 * Enforce the server-side entitlement and capability decision for direct callbacks.
		 *
		 * @param bool $allowed Whether the caller passed the applicable policy.
		 * @return true|WP_Error
		 */
		private static function require_regeneration_permission($allowed) {
			// AUTHORIZATION INVARIANT: Route-level Pro and capability checks are an
			// early gate. Every public REST callback repeats the applicable global or
			// exact-object policy before inventory access or image processing.
			if (!$allowed) {
				return new WP_Error(
					'wphave_thumbnail_regeneration_forbidden',
					__('You are not allowed to regenerate these image sizes.', 'wphave'),
					['status' => 403],
				);
			}

			return true;
		}

		/**
		 * Return the query where.
		 *
		 * @return string
		 */

		public static function get_query_where() {
			return "
				post_type = 'attachment'
				AND post_status = 'inherit'
				AND post_mime_type LIKE 'image/%'
				AND post_mime_type != 'image/svg+xml'
			";
		}

		/**
		 * Normalize the limit.
		 *
		 * @param int $limit
		 * @return int
		 */

		public static function normalize_limit($limit) {
			$limit = absint($limit);
			$limit = $limit > 0 ? $limit : 10;

			return min($limit, 25);
		}

		/**
		 * Return an attachment IDs.
		 *
		 * @param int $last_id
		 * @param int $limit
		 * @return array
		 */

		public static function get_attachment_ids($last_id = 0, $limit = 10) {
			// INVENTORY INVARIANT: A direct helper call cannot enumerate media IDs
			// without the same entitlement and capability as the REST workflow.
			if (!self::can_regenerate()) {
				return [];
			}

			global $wpdb;

			$last_id = absint($last_id);
			$limit = self::normalize_limit($limit);
			$where = self::get_query_where();

			return array_map(
				'absint',
				$wpdb->get_col(
					$wpdb->prepare(
						"
				SELECT ID FROM {$wpdb->posts}
				WHERE {$where}
				AND ID > %d
				ORDER BY ID ASC
				LIMIT %d
			",
						$last_id,
						$limit,
					),
				),
			);
		}

		/**
		 * Count an attachments.
		 *
		 * @return int|WP_Error
		 */

		public static function count_attachments() {
			$authorization = self::require_regeneration_permission(self::can_regenerate());
			if (is_wp_error($authorization)) {
				return $authorization;
			}

			global $wpdb;

			$where = self::get_query_where();

			return (int) $wpdb->get_var("
				SELECT COUNT(ID)
				FROM {$wpdb->posts}
				WHERE {$where}
			");
		}

		/**
		 * Determine whether an attachment needs thumbnail regeneration.
		 *
		 * @param int $attachment_id
		 * @param array $registered_sizes
		 * @return array
		 */

		public static function image_needs_regeneration($attachment_id, $registered_sizes) {
			$attachment_id = absint($attachment_id);
			if (
				!self::can_regenerate() ||
				!current_user_can('edit_post', $attachment_id)
			) {
				return [
					'needs_regeneration' => false,
					'error' => __('Original file not found or not readable.', 'wphave'),
				];
			}

			// AUTHORIZATION INVARIANT: The raw attachment path is read only after
			// entitlement and exact-object permission have been confirmed.
			$file = get_attached_file($attachment_id, true);
			if (
				!self::regeneration_source_still_registered($attachment_id, $file) ||
				!is_readable($file)
			) {
				return [
					'needs_regeneration' => false,
					'error' => __('Original file not found or not readable.', 'wphave'),
				];
			}

			// MISSING-SIZE INVARIANT: Presentation filters cannot invent a stored
			// size and suppress the regeneration decision.
			$metadata = get_post_meta($attachment_id, '_wp_attachment_metadata', true);
			$source_relative = get_post_meta($attachment_id, '_wp_attached_file', true);
			$relative_directory = dirname($source_relative);
			$relative_directory = $relative_directory === '.'
				? ''
				: trailingslashit($relative_directory);
			$existing_sizes =
				is_array($metadata) && is_array($metadata['sizes'] ?? null)
					? $metadata['sizes']
					: [];
			$width = isset($metadata['width']) ? absint($metadata['width']) : 0;
			$height = isset($metadata['height']) ? absint($metadata['height']) : 0;

			if (!$width || !$height) {
				// ANALYSIS INVARIANT: Missing dimensions must not send an unbounded
				// source to the header parser in a read-only inventory request.
				$source_gate = WPHAVE_Media_Image_Source_Gate::inspect(
					$file,
					(string) get_post_mime_type($attachment_id),
				);
				if (isset($source_gate['error'])) {
					return array_merge(
						['needs_regeneration' => false],
						self::source_gate_failure($source_gate),
					);
				}
				$width = $source_gate['width'] ?? 0;
				$height = $source_gate['height'] ?? 0;
			}

			if (!$width || !$height) {
				return [
					'needs_regeneration' => false,
					'error' => __('Image dimensions could not be read.', 'wphave'),
				];
			}

			foreach ($registered_sizes as $size_name => $size_data) {
				$target_width = isset($size_data['width']) ? absint($size_data['width']) : 0;
				$target_height = isset($size_data['height']) ? absint($size_data['height']) : 0;
				$crop = !empty($size_data['crop']);

				if (!$target_width && !$target_height) {
					continue;
				}

				if (
					!image_resize_dimensions($width, $height, $target_width, $target_height, $crop)
				) {
					continue;
				}

				$size_file = $existing_sizes[$size_name]['file'] ?? '';
				$size_path = WPHAVE_Media_Image_Size_File_Identity::matches_generated_size(
					$file,
					$existing_sizes[$size_name] ?? null,
				)
					? dirname($file) . DIRECTORY_SEPARATOR . $size_file
					: '';
				// Metadata can outlive a deleted intermediate file. Missing mode must
				// inspect the filesystem before deciding that regeneration is unnecessary.
				if (
					!$size_path ||
					is_link($size_path) ||
					!is_file($size_path) ||
					!is_readable($size_path) ||
					WPHAVE_Attachment_File_Registration::has_other_owner(
						$relative_directory . $size_file,
						$size_path,
						$attachment_id,
					)
				) {
					return [
						'needs_regeneration' => true,
						'error' => null,
					];
				}
			}

			return [
				'needs_regeneration' => false,
				'error' => null,
			];
		}

		/**
		 * Return an error item.
		 *
		 * @param int $attachment_id
		 * @param string $message
		 * @return array
		 */

		public static function get_error_item($attachment_id, $message, $details = []) {
			// Presentation lookups can invoke the same failing WordPress filter again.
			// Keep them optional so they cannot replace the original diagnostic.
			$context = ['name' => '', 'file' => '', 'editUrl' => '', 'thumbnailUrl' => ''];
			try {
				$file = get_attached_file($attachment_id);
				$context['name'] = get_the_title($attachment_id);
				$context['file'] = $file ? wp_basename($file) : '';
				// LINK INVARIANT: A filtered attachment edit URL is browser input.
				$context['editUrl'] = WPHAVE_Safe_Link::http(get_edit_post_link($attachment_id, 'raw'));
				// PREVIEW INVARIANT: Do not fall back to the full source for a failed
				// image. Only a registered thumbnail may be shown in the findings list.
				$metadata = wp_get_attachment_metadata($attachment_id);
				if (is_array($metadata) && !empty($metadata['sizes']['thumbnail'])) {
					$thumbnail = image_get_intermediate_size($attachment_id, 'thumbnail');
					$context['thumbnailUrl'] = WPHAVE_Safe_Link::http(
						is_array($thumbnail) ? ($thumbnail['url'] ?? '') : ''
					);
				}
			} catch (Throwable $context_error) {
				// The attachment ID still identifies the failed operation.
			}

			return [
				'id' => absint($attachment_id),
				'name' => $context['name'],
				'file' => $context['file'],
				'editUrl' => $context['editUrl'],
				'thumbnailUrl' => $context['thumbnailUrl'],
				// SECURITY INVARIANT: Image drivers may include absolute source paths or
				// embedded identifiers in failure messages. Batch responses expose only
				// the centrally redacted diagnostic representation.
				'error' => WPHAVE_Security_Redactor::error_text($message),
				'details' => is_array($details) ? $details : [],
			];
		}

		/**
		 * Analyze a batch of attachments for missing image sizes.
		 *
		 * @param int $last_id
		 * @param int $limit
		 * @return array|WP_Error
		 */

		public static function analyze_batch($last_id = 0, $limit = 10) {
			$authorization = self::require_regeneration_permission(self::can_regenerate());
			if (is_wp_error($authorization)) {
				return $authorization;
			}

			$limit = self::normalize_limit($limit);
			$attachment_ids = self::get_attachment_ids($last_id, $limit);
			$registered_sizes = wp_get_registered_image_subsizes();
			$total = 0;
			$needs_regeneration = 0;
			$ok = 0;
			$errors = [];

			foreach ($attachment_ids as $attachment_id) {
				$total++;

				// SECURITY INVARIANT: A delegated global workflow may enumerate a
				// bounded cursor, but it may neither inspect nor mutate an attachment
				// unless WordPress authorizes that exact object for the current user.
				if (!current_user_can('edit_post', $attachment_id)) {
					continue;
				}

				$result = self::image_needs_regeneration($attachment_id, $registered_sizes);

				if (!empty($result['error'])) {
					$errors[] = self::get_error_item($attachment_id, $result['error'], $result['details'] ?? []);
					continue;
				}

				if (!empty($result['needs_regeneration'])) {
					$needs_regeneration++;
				} else {
					$ok++;
				}
			}

			return [
				'total' => $total,
				'needs_regeneration' => $needs_regeneration,
				'ok' => $ok,
				'errors' => $errors,
				'last_id' => !empty($attachment_ids) ? end($attachment_ids) : absint($last_id),
				'done' => count($attachment_ids) < $limit,
			];
		}

		/**
		 * Regenerate a batch of attachment image sizes.
		 *
		 * @param int $last_id
		 * @param int $limit
		 * @param string $mode
		 * @return array
		 */

		public static function regenerate_batch($last_id = 0, $limit = 10, $mode = 'all') {
			// AUTHORIZATION INVARIANT: Public service calls do not inherit the REST
			// permission decision; reject before querying media or entering context.
			$authorization = self::require_regeneration_permission(self::can_regenerate());
			if (is_wp_error($authorization)) {
				return $authorization;
			}

			// MODE INVARIANT: A direct service call cannot turn an unknown value
			// into the destructive "all" operation by bypassing REST validation.
			if (!in_array($mode, ['all', 'missing'], true)) {
				return new WP_Error(
					'wphave_regeneration_invalid_mode',
					__('The image regeneration mode is invalid.', 'wphave'),
					['status' => 400],
				);
			}
			self::ensure_image_runtime();

			$limit = self::normalize_limit($limit);
			$attachment_ids = self::get_attachment_ids($last_id, $limit);
			$registered_sizes = wp_get_registered_image_subsizes();
			$current = null;
			$processed = 0;
			$skipped = 0;
			$scanned = 0;
			$last_scanned_id = absint($last_id);
			$errors = [];

			$previous_context = self::begin_regeneration_context();

			try {
				try {
					foreach ($attachment_ids as $attachment_id) {
						$scanned++;
						$last_scanned_id = absint($attachment_id);

						// SECURITY INVARIANT: The batch capability authorizes the workflow,
						// never every media object returned by a global attachment query.
						// Recheck the native meta capability immediately before file work.
						if (!current_user_can('edit_post', $attachment_id)) {
							$skipped++;
							continue;
						}

						$file = get_attached_file($attachment_id);
						$current = [
							'id' => $attachment_id,
							'url' => wp_get_attachment_image_url($attachment_id, 'thumbnail'),
							'name' => get_the_title($attachment_id),
							'mime' => get_post_mime_type($attachment_id),
						];

						if (!$file || !file_exists($file) || !is_readable($file)) {
							$errors[] = self::get_error_item(
								$attachment_id,
								__('Original file not found or not readable.', 'wphave'),
							);
							continue;
						}

						if ($mode === 'missing') {
							$check = self::image_needs_regeneration(
								$attachment_id,
								$registered_sizes,
							);

							if (!empty($check['error'])) {
								$errors[] = self::get_error_item($attachment_id, $check['error'], $check['details'] ?? []);
								continue;
							}

							if (empty($check['needs_regeneration'])) {
								$skipped++;
								continue;
							}
						}

						$metadata = null;
						$result = self::regenerate_attachment_file($attachment_id, $file);

						if (!empty($result['error'])) {
							$errors[] = self::get_error_item($attachment_id, $result['error'], $result['details'] ?? []);
							continue;
						}

						$metadata = $result['metadata'];

						$processed++;
					}
				} catch (Throwable $e) {
					$errors[] = self::get_error_item($last_scanned_id, $e->getMessage());
				}

				$log = array_values($GLOBALS['wphave_image_log_grouped'] ?? []);
			} finally {
				self::end_regeneration_context($previous_context);
			}

			return [
				'processed' => $processed,
				'skipped' => $skipped,
				'scanned' => $scanned,
				// Never advance past images that an interrupted batch did not visit.
				'last_id' => $last_scanned_id,
				'done' => $scanned === count($attachment_ids) && count($attachment_ids) < $limit,
				'mode' => $mode,
				'errors' => $errors,
				'current' => $current,
				'log' => $log,
			];
		}

		/**
		 * Translate a bounded source-gate result into a safe user diagnostic.
		 *
		 * @param array $source_gate
		 * @return array
		 */

		private static function source_gate_failure($source_gate) {
			$reason = $source_gate['reason'] ?? '';
			$messages = [
				'file_size' => __('The image file exceeds the 128 MiB processing limit or is empty.', 'wphave'),
				'dimensions' => __('The image dimensions are invalid or exceed the 40 megapixel processing limit.', 'wphave'),
				'unreadable_header' => __('The image header could not be read.', 'wphave'),
				'mime_mismatch' => __('The detected file format differs from the registered media type.', 'wphave'),
				'frame_or_header' => __('The image is animated or has an invalid frame header.', 'wphave'),
			];

			// DIAGNOSTIC INVARIANT: Return bounded numeric facts and a fixed reason,
			// never source paths, decoder errors, or untrusted file contents.
			return [
				'error' => $messages[$reason] ?? __('The image source failed validation.', 'wphave'),
				'details' => [
					'reason' => $reason,
					'registeredMime' => isset($source_gate['registered_mime']) && is_string($source_gate['registered_mime']) ? sanitize_mime_type($source_gate['registered_mime']) : null,
					'detectedMime' => isset($source_gate['detected_mime']) && is_string($source_gate['detected_mime']) ? sanitize_mime_type($source_gate['detected_mime']) : null,
					'bytes' => isset($source_gate['bytes']) && is_int($source_gate['bytes']) ? $source_gate['bytes'] : null,
					'width' => isset($source_gate['width']) && is_int($source_gate['width']) ? $source_gate['width'] : null,
					'height' => isset($source_gate['height']) && is_int($source_gate['height']) ? $source_gate['height'] : null,
				],
			];
		}

		/**
		 * Regenerate metadata and image sizes for an attachment file.
		 *
		 * @param int $attachment_id
		 * @param string $file
		 * @return array
		 */
		public static function regenerate_attachment_file($attachment_id, $file) {
			// AUTHORITY INVARIANT: This public service is callable outside REST.
			// Neither an earlier route check nor a filterable file path is authority
			// to generate files or metadata for another attachment.
			if (
				!self::can_regenerate() ||
				!current_user_can('edit_post', $attachment_id) ||
				!self::regeneration_source_still_registered($attachment_id, $file)
			) {
				return [
					'metadata' => null,
					'error' => __('The image source is no longer authorized or registered.', 'wphave'),
				];
			}
			$source_gate = WPHAVE_Media_Image_Source_Gate::inspect(
				$file,
				(string) get_post_mime_type($attachment_id),
			);
			if (isset($source_gate['error'])) {
				return array_merge(['metadata' => null], self::source_gate_failure($source_gate));
			}
			try {
				$source_identity = WPHAVE_Security_File_Identity::inspect_bounded(
					$file,
					WPHAVE_Media_Image_Source_Gate::MAX_BYTES,
					__('The image source changed during regeneration.', 'wphave'),
				);
			} catch (Throwable $error) {
				return [
					'metadata' => null,
					'error' => __('The image source changed during regeneration.', 'wphave'),
				];
			}
			$metadata = null;
			$exception = null;
			$previous_regeneration_flag = $GLOBALS['wphave_is_regenerating_images'] ?? false;
			$GLOBALS['wphave_is_regenerating_images'] = true;

			set_error_handler(function () {
				return true;
			});

			try {
				$metadata = wp_generate_attachment_metadata($attachment_id, $file);
			} catch (Throwable $e) {
				$exception = $e;
			} finally {
				restore_error_handler();
				$GLOBALS['wphave_is_regenerating_images'] = $previous_regeneration_flag;
			}

			if ($exception) {
				return [
					'metadata' => null,
					'error' => WPHAVE_Security_Redactor::error_text($exception->getMessage()),
				];
			}

			if (is_wp_error($metadata) || empty($metadata) || !is_array($metadata)) {
				return [
					'metadata' => null,
					'error' => is_wp_error($metadata)
						? WPHAVE_Security_Redactor::error_text($metadata->get_error_message())
						: __('Metadata could not be generated.', 'wphave'),
				];
			}
			// METADATA INVARIANT: Generated metadata must describe the same main
			// file; extension filters cannot redirect this attachment to another image.
			if (($metadata['file'] ?? null) !== get_post_meta($attachment_id, '_wp_attached_file', true)) {
				return [
					'metadata' => null,
					'error' => __('Generated image metadata points to another file.', 'wphave'),
				];
			}
			if (
				!self::can_regenerate() ||
				!current_user_can('edit_post', $attachment_id) ||
				!self::regeneration_source_still_registered($attachment_id, $file) ||
				!self::regeneration_source_matches_identity($file, $source_identity)
			) {
				return [
					'metadata' => null,
					'error' => __('The image source changed during regeneration.', 'wphave'),
				];
			}

			wp_update_attachment_metadata($attachment_id, $metadata);
			// A truthy update result is not proof that a later metadata hook kept
			// the requested document. Compare canonical stored data in every case.
			if (wp_get_attachment_metadata($attachment_id, true) !== $metadata) {
				return [
					'metadata' => null,
					'error' => __(
						'The generated image metadata could not be confirmed as saved. Refresh the image details before trying again.',
						'wphave',
					),
				];
			}
			if (
				!self::regeneration_source_still_registered($attachment_id, $file) ||
				!self::regeneration_source_matches_identity($file, $source_identity)
			) {
				return [
					'metadata' => null,
					'error' => __('The image source changed while metadata was saved.', 'wphave'),
				];
			}

			return [
				'metadata' => $metadata,
				'error' => null,
			];
		}

		/**
		 * Confirm that generation did not replace or modify the authorized source bytes.
		 *
		 * @param string $file Absolute source path.
		 * @param array $expected Bounded identity captured before generation.
		 * @return bool
		 */
		private static function regeneration_source_matches_identity(string $file, array $expected): bool {
			try {
				$current = WPHAVE_Security_File_Identity::inspect_bounded(
					$file,
					WPHAVE_Media_Image_Source_Gate::MAX_BYTES,
					__('The image source changed during regeneration.', 'wphave'),
				);
			} catch (Throwable $error) {
				return false;
			}

			// SOURCE INVARIANT: Core may persist intermediate metadata before it
			// returns. A stable path alone cannot prove those sizes belong to the
			// source revision we authorized at the start of this operation.
			return $current['bytes'] === $expected['bytes'] &&
				hash_equals($expected['checksum'], $current['checksum']);
		}

		/**
		 * Require an unfiltered, uniquely owned image source inside the uploads root.
		 *
		 * @param int $attachment_id Attachment being regenerated.
		 * @param string $file Absolute path proposed for generation.
		 * @return bool
		 */
		private static function regeneration_source_still_registered($attachment_id, $file): bool {
			$post = get_post($attachment_id);
			$mime = get_post_mime_type($attachment_id);
			if (
				!$post ||
				$post->post_type !== 'attachment' ||
				!is_string($mime) ||
				!str_starts_with($mime, 'image/') ||
				$mime === 'image/svg+xml' ||
				!is_string($file) ||
				$file === '' ||
				is_link($file) ||
				!is_file($file)
			) {
				return false;
			}
			$uploads = wp_get_upload_dir();
			$root = realpath((string) ($uploads['basedir'] ?? ''));
			$source = realpath($file);
			$registered = get_attached_file($attachment_id, true);
			if (!$root || !$source || !is_string($registered) || $registered !== $file) {
				return false;
			}
			$root = rtrim(wp_normalize_path($root), '/') . '/';
			$source = wp_normalize_path($source);
			if (!str_starts_with($source, $root)) {
				return false;
			}
			$relative = substr($source, strlen($root));
			return $relative !== '' &&
				get_post_meta($attachment_id, '_wp_attached_file', true) === $relative &&
				// REGENERATION INVARIANT: A valid own registration does not grant
				// permission to process a main file shared with another attachment.
				!WPHAVE_Attachment_File_Registration::has_other_owner(
					$relative,
					$source,
					$attachment_id,
				);
		}

		/**
		 * Regenerate the requested attachment image sizes.
		 *
		 * @param int $attachment_id
		 * @param string $mode
		 * @return array
		 */

		public static function regenerate_attachment($attachment_id, $mode = 'all') {
			// AUTHORIZATION INVARIANT: Check the exact media object before reading
			// metadata, a filterable pathname, or entering regeneration context.
			$attachment_id = absint($attachment_id);
			$authorization = self::require_regeneration_permission(
				self::can_regenerate() && current_user_can('edit_post', $attachment_id),
			);
			if (is_wp_error($authorization)) {
				return $authorization;
			}

			if (!in_array($mode, ['all', 'missing'], true)) {
				return new WP_Error(
					'wphave_regeneration_invalid_mode',
					__('The image regeneration mode is invalid.', 'wphave'),
					['status' => 400],
				);
			}
			self::ensure_image_runtime();

			$post = get_post($attachment_id);
			$mime_type = get_post_mime_type($attachment_id);
			$errors = [];
			$skipped = 0;

			$previous_context = self::begin_regeneration_context();

			try {
				if (
					!$post ||
					$post->post_type !== 'attachment' ||
					strpos((string) $mime_type, 'image/') !== 0 ||
					$mime_type === 'image/svg+xml'
				) {
					$errors[] = self::get_error_item(
						$attachment_id,
						__('This attachment is not a supported image file.', 'wphave'),
					);
				} else {
					$file = get_attached_file($attachment_id);

					if (!$file || !file_exists($file) || !is_readable($file)) {
						$errors[] = self::get_error_item(
							$attachment_id,
							__('Original file not found or not readable.', 'wphave'),
						);
					} else {
						if ($mode === 'missing') {
							$check = self::image_needs_regeneration(
								$attachment_id,
								wp_get_registered_image_subsizes(),
							);

							if (!empty($check['error'])) {
								$errors[] = self::get_error_item($attachment_id, $check['error'], $check['details'] ?? []);
							} elseif (empty($check['needs_regeneration'])) {
								$skipped = 1;
							}
						}

						if (empty($errors) && !$skipped) {
							$result = self::regenerate_attachment_file($attachment_id, $file);

							if (!empty($result['error'])) {
								$errors[] = self::get_error_item($attachment_id, $result['error'], $result['details'] ?? []);
							}
						}
					}
				}

				$log = array_values($GLOBALS['wphave_image_log_grouped'] ?? []);
			} finally {
				self::end_regeneration_context($previous_context);
			}

			return [
				'processed' => empty($errors) && !$skipped ? 1 : 0,
				'skipped' => $skipped,
				'errors' => $errors,
				'mode' => $mode,
				'current' => [
					'id' => $attachment_id,
					'url' => wp_get_attachment_image_url($attachment_id, 'thumbnail'),
					'name' => get_the_title($attachment_id),
					'mime' => get_post_mime_type($attachment_id),
				],
				'log' => $log,
			];
		}

		/**
		 * Isolate image logs and no-delete mode, preserving any enclosing run.
		 *
		 * @return array Previous context to pass to end_regeneration_context().
		 */
		private static function begin_regeneration_context(): array {
			$nested = !empty($GLOBALS['wphave_is_regenerating_images']);
			$previous = [
				'flag' => $nested,
				'log' => $nested ? ($GLOBALS['wphave_image_log'] ?? []) : [],
				'grouped' => $nested ? ($GLOBALS['wphave_image_log_grouped'] ?? []) : [],
			];
			$GLOBALS['wphave_image_log'] = [];
			$GLOBALS['wphave_image_log_grouped'] = [];
			$GLOBALS['wphave_is_regenerating_images'] = true;
			return $previous;
		}

		/**
		 * Restore the enclosing run's logs and no-delete mode after every exit.
		 *
		 * @param array $previous Context returned by begin_regeneration_context().
		 * @return void
		 */
		private static function end_regeneration_context(array $previous): void {
			// REENTRANCY INVARIANT: A nested regeneration must not disable the
			// outer operation's no-delete mode or discard its diagnostic log.
			$GLOBALS['wphave_image_log'] = $previous['log'];
			$GLOBALS['wphave_image_log_grouped'] = $previous['grouped'];
			$GLOBALS['wphave_is_regenerating_images'] = $previous['flag'];
		}

		/**
		 * Loads WordPress image helpers and raises safe runtime limits.
		 *
		 * @return void
		 */

		public static function ensure_image_runtime() {
			if (!function_exists('wp_generate_attachment_metadata')) {
				require_once ABSPATH . 'wp-admin/includes/image.php';
			}

			if (function_exists('wp_raise_memory_limit')) {
				wp_raise_memory_limit('image');
			}

			if (function_exists('set_time_limit')) {
				@set_time_limit(60);
			}
		}

		/**
		 * Return the number of attachments eligible for regeneration.
		 *
		 * @return WP_REST_Response|WP_Error
		 */

		public static function rest_count() {
			$authorization = self::require_regeneration_permission(self::can_regenerate());

			if (is_wp_error($authorization)) {
				return $authorization;
			}

			return rest_ensure_response([
				'total' => self::count_attachments(),
			]);
		}

		/**
		 * Analyze a batch of attachments through the REST API.
		 *
		 * @param WP_REST_Request $request Analysis request.
		 * @return WP_REST_Response|WP_Error
		 */

		public static function rest_analyze(WP_REST_Request $request) {
			$authorization = self::require_regeneration_permission(self::can_regenerate());

			if (is_wp_error($authorization)) {
				return $authorization;
			}

			return rest_ensure_response(
				self::analyze_batch($request->get_param('last_id'), $request->get_param('limit')),
			);
		}

		/**
		 * Validate a direct REST callback's mode without coercing invalid input.
		 *
		 * @param WP_REST_Request $request Regeneration request.
		 * @return string|WP_Error Valid mode or a client error.
		 */
		private static function requested_regeneration_mode(WP_REST_Request $request): string|WP_Error {
			$mode = $request->get_param('mode');
			if ($mode === null) {
				return 'all';
			}
			if (!is_string($mode) || !in_array($mode, ['all', 'missing'], true)) {
				return new WP_Error(
					'wphave_regeneration_invalid_mode',
					__('The image regeneration mode is invalid.', 'wphave'),
					['status' => 400],
				);
			}
			return $mode;
		}

		/**
		 * Regenerate a bounded batch through the REST API after reauthorization.
		 *
		 * @param WP_REST_Request $request Batch request.
		 * @return WP_REST_Response|WP_Error
		 */
		public static function rest_regenerate_batch(WP_REST_Request $request) {
			$authorization = self::require_regeneration_permission(self::can_regenerate());

			if (is_wp_error($authorization)) {
				return $authorization;
			}
			$mode = self::requested_regeneration_mode($request);
			if (is_wp_error($mode)) {
				return $mode;
			}

			return rest_ensure_response(
				self::regenerate_batch(
					$request->get_param('last_id'),
					$request->get_param('limit'),
					$mode,
				),
			);
		}

		/**
		 * Regenerate a single attachment through the REST API.
		 *
		 * @param WP_REST_Request $request Attachment request.
		 * @return WP_REST_Response|WP_Error
		 */

		public static function rest_regenerate_attachment(WP_REST_Request $request) {
			$authorization = self::require_regeneration_permission(
				self::can_regenerate_attachment($request),
			);

			if (is_wp_error($authorization)) {
				return $authorization;
			}
			$mode = self::requested_regeneration_mode($request);
			if (is_wp_error($mode)) {
				return $mode;
			}

			return rest_ensure_response(
				self::regenerate_attachment(
					$request->get_param('id'),
					$mode,
				),
			);
		}
	}
endif;

WPHAVE_Regenerate_Thumbnails_Manager::init();
