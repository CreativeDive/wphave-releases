<?php

/**
 * Handle privileged uploads to dedicated folders below the WordPress uploads directory.
 */

if (!defined('ABSPATH')) {
	exit();
}

if (!class_exists('WPHAVE_File_Upload')):
	/**
	 * Validate and store files uploaded through the WPHAVE REST API.
	 */

	class WPHAVE_File_Upload {
		const MAX_FONT_FILE_BYTES = 10 * MB_IN_BYTES;
		const MAX_SUBFOLDER_BYTES = 1024;
		const MAX_SUBFOLDER_SEGMENTS = 8;
		const MAX_MIME_SELECTOR_BYTES = 2048;
		const MAX_FILENAME_BYTES = 255;

		/**
		 * Register WordPress hooks owned by the upload service.
		 *
		 * @return void
		 */

		public static function init() {
			add_action('rest_api_init', [__CLASS__, 'register_rest_route']);
		}

		/**
		 * Register the privileged file upload endpoint.
		 *
		 * @return void
		 */

		public static function register_rest_route() {
			register_rest_route('wphave/v1', '/file-upload', [
				'methods' => 'POST',
				'callback' => [__CLASS__, 'upload'],
				'permission_callback' => [__CLASS__, 'permissions_check'],
			]);
		}

		/**
		 * Determine whether the current user may upload files through WPHAVE.
		 *
		 * @return bool Whether the current user has both required capabilities.
		 */

		public static function permissions_check() {
			return current_user_can('manage_options') && current_user_can('upload_files');
		}

		/**
		 * Return MIME types accepted for local font files.
		 *
		 * @return array Supported font MIME types.
		 */

		private static function font_mimes() {
			return [
				'font/ttf',
				'application/x-font-ttf',
				'font/otf',
				'application/x-font-otf',
				'application/x-font-opentype',
				'application/vnd.ms-opentype',
				'font/sfnt',
				'font/woff',
				'application/font-woff',
				'application/x-font-woff',
				'font/woff2',
				'application/font-woff2',
				'application/x-font-woff2',
				'application/octet-stream',
			];
		}

		/**
		 * Validate a canonical requested subfolder without allowing path traversal.
		 *
		 * @param mixed $folder Requested uploads subfolder.
		 * @return string|WP_Error Exact relative folder path or validation error.
		 */

		protected static function validate_subfolder($folder) {
			if ($folder === null || $folder === '') {
				return '';
			}

			// RESOURCE INVARIANT: Validate the raw path before splitting and
			// sanitizing it; a privileged malformed request cannot allocate an
			// unbounded array or induce deep directory creation.
			if (!is_string($folder) || strlen($folder) > self::MAX_SUBFOLDER_BYTES) {
				return new WP_Error(
					'upload_destination_invalid',
					__('The upload destination is invalid.', 'wphave'),
					['status' => 400],
				);
			}

			$requested_folder = trim($folder, "/ \t\n\r\0\x0B");

			if (!$requested_folder) {
				return new WP_Error(
					'upload_destination_invalid',
					__('The upload destination is invalid.', 'wphave'),
					['status' => 400],
				);
			}

			$parts = explode('/', $requested_folder);
			if (count($parts) > self::MAX_SUBFOLDER_SEGMENTS) {
				return new WP_Error(
					'upload_destination_invalid',
					__('The upload destination is invalid.', 'wphave'),
					['status' => 400],
				);
			}
			$parts = array_map('sanitize_file_name', $parts);
			$destination_folder = implode('/', $parts);

			// SECURITY INVARIANT: A destination is a filesystem authorization
			// identity. Never repair traversal, empty segments or lossy characters
			// into a different allowed directory such as the privileged fonts root.
			if (
				$folder !== $requested_folder ||
				$destination_folder !== $requested_folder ||
				in_array('', $parts, true) ||
				in_array('.', $parts, true) ||
				in_array('..', $parts, true)
			) {
				return new WP_Error(
					'upload_destination_invalid',
					__('The upload destination is invalid.', 'wphave'),
					['status' => 400],
				);
			}

			return $destination_folder;
		}

		/**
		 * Move the PHP upload into a request-owned sibling stage.
		 *
		 * Kept as a narrow seam so the create-only publication contract can be
		 * exercised without weakening PHP's uploaded-file check in production.
		 */

		protected static function move_uploaded_file_to_stage($source, $stage) {
			return move_uploaded_file($source, $stage);
		}

		/**
		 * Publish uploaded bytes without replacing a concurrently created target.
		 *
		 * @return true|WP_Error
		 */

		protected static function publish_uploaded_file($source, $target) {
			$stage = $target . '.upload-' . wp_generate_uuid4();

			if (!static::move_uploaded_file_to_stage($source, $stage)) {
				return new WP_Error(
					'upload_error',
					__('The file could not be staged safely.', 'wphave'),
					['status' => 500],
				);
			}

			try {
				$checksum = hash_file('sha256', $stage);

				if (!is_string($checksum)) {
					throw new RuntimeException('upload_stage_hash_failed');
				}

				// SECURITY INVARIANT: Filename allocation does not grant replacement
				// authority. The exact staged upload may be published only while the
				// selected destination is still absent; a concurrent node is preserved.
				WPHAVE_Security_Atomic_File::copy_verified_new(
					$stage,
					$target,
					$checksum,
					__('The upload destination changed before the file could be saved.', 'wphave'),
					// PUBLICATION INVARIANT: Uploads follow the trusted target directory policy.
					WPHAVE_Security_File_Permissions::for_new_public_file($target),
				);
			} catch (Throwable $error) {
				return new WP_Error(
					'upload_destination_conflict',
					__(
						'The upload destination changed before the file could be saved. Please try again.',
						'wphave',
					),
					['status' => 409],
				);
			} finally {
				// COMMIT INVARIANT: This request owns the unpredictable staging
				// sibling. Cleanup failure must not turn a published upload into
				// an API failure or mask the original publication error.
				try {
					if (is_file($stage) || is_link($stage)) {
						@unlink($stage);
					}
				} catch (Throwable $cleanup_error) {
					// Retain the staging file; the publication result is authoritative.
				}
			}

			return true;
		}

		/**
		 * Resolve the server-controlled MIME allowlist for an upload request.
		 *
		 * @param mixed $allowed_file_types_string Client-requested MIME types.
		 * @param string $destination_folder Sanitized destination folder.
		 * @return array Allowed MIME types.
		 */

		private static function allowed_mimes($allowed_file_types_string, $destination_folder) {
			$requested_mimes = array_filter(
				array_map('trim', explode(',', (string) $allowed_file_types_string)),
			);

			$server_mimes = array_values(get_allowed_mime_types());

			if ($destination_folder === 'fonts') {
				$server_mimes = array_merge($server_mimes, self::font_mimes());
			}

			$server_mimes = array_values(array_unique($server_mimes));

			// Client-provided MIME types may narrow the server allowlist, but can never expand it.
			if ($requested_mimes) {
				return array_values(array_intersect($requested_mimes, $server_mimes));
			}

			return $server_mimes;
		}

		/**
		 * Validate upload integrity, extension and MIME type before moving a file.
		 *
		 * @param mixed $file Uploaded file data.
		 * @param array $allowed_mimes Server-controlled MIME allowlist.
		 * @param string $destination_folder Sanitized destination folder.
		 * @return true|WP_Error True when valid, otherwise an upload error.
		 */

		protected static function validate_file($file, $allowed_mimes, $destination_folder) {
			if (empty($file) || !is_array($file)) {
				return new WP_Error('upload_error', __('No file was provided.', 'wphave'), [
					'status' => 400,
				]);
			}

			if (!empty($file['error'])) {
				return new WP_Error('upload_error', __('The file upload failed.', 'wphave'), [
					'status' => 400,
				]);
			}

			if (
				empty($file['tmp_name']) ||
				!is_string($file['tmp_name']) ||
				!static::is_valid_uploaded_file_path($file['tmp_name'])
			) {
				return new WP_Error(
					'upload_error',
					__('The uploaded file could not be verified.', 'wphave'),
					['status' => 400],
				);
			}

			// INPUT INVARIANT: Multipart filename metadata must be a bounded
			// scalar before any sanitizer, extension parser or unique-name filter.
			if (
				!isset($file['name']) ||
				!is_string($file['name']) ||
				'' === $file['name'] ||
				strlen($file['name']) > self::MAX_FILENAME_BYTES
			) {
				return new WP_Error('upload_error', __('The filename is invalid.', 'wphave'), [
					'status' => 400,
				]);
			}
			$file_name = sanitize_file_name($file['name']);
			$extension = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
			if (
				isset($file['type']) &&
				(!is_string($file['type']) || strlen($file['type']) > 128)
			) {
				return new WP_Error('upload_error', __('The reported file type is invalid.', 'wphave'), [
					'status' => 400,
				]);
			}
			$reported_mime = sanitize_mime_type($file['type'] ?? '');
			$detected_mime = function_exists('mime_content_type')
				? mime_content_type($file['tmp_name'])
				: '';
			$validated_mime = $detected_mime ?: $reported_mime;

			if ($destination_folder === 'fonts') {
				$allowed_extensions = ['ttf', 'otf', 'woff', 'woff2'];

				if (!in_array($extension, $allowed_extensions, true)) {
					return new WP_Error(
						'upload_error',
						__('This font file type is not allowed.', 'wphave'),
						['status' => 400],
					);
				}

				// SECURITY INVARIANT: Signature, size policy, and the later move must all
				// describe the same server-side temporary file. Multipart metadata is
				// never authoritative for a filesystem limit.
				$size = filesize($file['tmp_name']);

				if ($size === false || $size < 1 || $size > self::MAX_FONT_FILE_BYTES) {
					return new WP_Error(
						'upload_error',
						__('Font files must be smaller than 10 MB.', 'wphave'),
						['status' => 413],
					);
				}

				if (!self::has_valid_font_signature($file['tmp_name'], $extension)) {
					return new WP_Error(
						'upload_error',
						__('The uploaded file is not a valid web font.', 'wphave'),
						['status' => 400],
					);
				}
			} else {
				// SECURITY INVARIANT: This endpoint moves files directly and therefore must
				// apply the same SVG preparation normally owned by WordPress prefilters.
				if (function_exists('wphave_prepare_special_media_upload')) {
					$prepared = wphave_prepare_special_media_upload($file);

					if (is_wp_error($prepared)) {
						return new WP_Error('upload_error', $prepared->get_error_message(), [
							'status' => 400,
						]);
					}
				}

				$type_check = wp_check_filetype_and_ext(
					$file['tmp_name'],
					$file_name,
					get_allowed_mime_types(),
				);

				if (empty($type_check['ext']) || empty($type_check['type'])) {
					return new WP_Error(
						'upload_error',
						__('This file type is not allowed.', 'wphave'),
						['status' => 400],
					);
				}

				$validated_mime = $type_check['type'];
			}

			if (!$validated_mime || !in_array($validated_mime, $allowed_mimes, true)) {
				return new WP_Error(
					'upload_error',
					__('This file type is not allowed.', 'wphave'),
					['status' => 400],
				);
			}

			return true;
		}

		/**
		 * Verify upload provenance at the mutation boundary.
		 *
		 * Kept as a narrow seam so integration tests can exercise the complete
		 * validation contract with controlled local fixtures.
		 *
		 * @param string $path Temporary upload path.
		 * @return bool Whether PHP recognizes the path as an HTTP upload.
		 */

		protected static function is_valid_uploaded_file_path($path) {
			return is_uploaded_file($path);
		}

		/**
		 * Validate the container signature instead of trusting the extension or the
		 * broadly reported application/octet-stream MIME type.
		 */

		private static function has_valid_font_signature($path, $extension) {
			// This shared check rejects renamed arbitrary files, but intentionally does
			// not claim to fully sanitize font programs supplied by a privileged user.

			return WPHAVE_Font_File_Security::has_valid_signature($path, $extension);
		}

		/**
		 * Validate and move one uploaded file into its requested uploads folder.
		 *
		 * @param WP_REST_Request $request REST upload request.
		 * @return WP_REST_Response|WP_Error Upload response or validation error.
		 */

		public static function upload(WP_REST_Request $request) {
			// AUTHORIZATION INVARIANT: A public callback can be invoked outside REST
			// dispatch. Recheck both capabilities before resolving or creating a path.
			if (!self::permissions_check()) {
				return new WP_Error(
					'wphave_file_upload_forbidden',
					__('You are not allowed to upload files through WPHAVE.', 'wphave'),
					['status' => 403],
				);
			}

			$destination_folder = self::validate_subfolder(
				$request->get_param('destinationFolder'),
			);

			if (is_wp_error($destination_folder)) {
				return $destination_folder;
			}

			$requested_mimes = $request->get_param('allowedFileTypes');
			// RESOURCE INVARIANT: Client MIME selectors may narrow the server
			// policy, but must be bounded before comma expansion and intersection.
			if (
				null !== $requested_mimes &&
				(!is_string($requested_mimes) || strlen($requested_mimes) > self::MAX_MIME_SELECTOR_BYTES)
			) {
				return new WP_Error('upload_error', __('The file type selector is invalid.', 'wphave'), [
					'status' => 400,
				]);
			}
			$allowed_file_types = self::allowed_mimes(
				$requested_mimes,
				$destination_folder,
			);
			$files = $request->get_file_params();
			$file = $files['file'] ?? null;
			$validation = self::validate_file($file, $allowed_file_types, $destination_folder);

			if (is_wp_error($validation)) {
				return $validation;
			}

			// MUTATION INVARIANT: Invalid uploads never create an uploads
			// subdirectory. Resolve the destination only after byte validation.
			// Resolve every destination through the shared uploads helper to keep the file inside uploads.
			$upload_args = [];
			if ($destination_folder) {
				$upload_args = ['subfolder' => $destination_folder];
			}

			$upload_dir = wphave_get_upload_dir($upload_args);
			$base_path = $upload_dir['basedir'];
			$base_url = $upload_dir['baseurl'];

			if (!empty($upload_dir['error']) || !$base_path || !$base_url) {
				return new WP_Error(
					'upload_error',
					$upload_dir['error'] ?:
					__('The upload directory could not be resolved.', 'wphave'),
					['status' => 500],
				);
			}

			if (!file_exists($base_path)) {
				wp_mkdir_p($base_path);
			}

			if (!is_dir($base_path) || !is_writable($base_path)) {
				return new WP_Error(
					'upload_error',
					__('The upload destination is not writable.', 'wphave'),
					['status' => 500],
				);
			}

			// AUTHORIZATION/TOCTOU INVARIANT: Upload provenance, special-media
			// preparation and MIME detection cross filterable extension code. Repeat
			// both capabilities after validation and before destination allocation.
			if (!self::permissions_check()) {
				return new WP_Error(
					'wphave_file_upload_forbidden',
					__('You are not allowed to upload files through WPHAVE.', 'wphave'),
					['status' => 403],
				);
			}

			$file_name = wp_unique_filename($base_path, sanitize_file_name($file['name']));
			$file_path = path_join($base_path, $file_name);
			$file_url = trailingslashit($base_url) . $file_name;

			// AUTHORIZATION/TOCTOU INVARIANT: Filename sanitization and unique-name
			// allocation are themselves filterable. Repeat both capabilities after the
			// final destination identity exists and immediately before moving bytes.
			if (!self::permissions_check()) {
				return new WP_Error(
					'wphave_file_upload_forbidden',
					__('You are not allowed to upload files through WPHAVE.', 'wphave'),
					['status' => 403],
				);
			}

			$published = self::publish_uploaded_file($file['tmp_name'], $file_path);

			if (true === $published) {
				return new WP_REST_Response(
					[
						'url' => $file_url,
						'file' => $file_name,
						'type' => $file['type'] ?? '',
					],
					200,
				);
			}

			return $published;
		}
	}

	WPHAVE_File_Upload::init();
endif;
