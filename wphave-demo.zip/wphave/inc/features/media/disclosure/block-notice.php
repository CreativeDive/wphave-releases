<?php

/**
 * Adapt author-enabled block notices to the shared AI label presentation.
 *
 * Notices belong to a block occurrence, outside inherited design settings. They
 * never suppress attachment labels or become children of a grid/slider track.
 */

class WPHAVE_Block_AI_Notice {
	/**
	 * Register the content-slot adapter independently of background rendering.
	 *
	 * @return void
	 */

	public static function init(): void {
		add_action('wphave_block_content_notices', [self::class, 'output'], 10, 2);
	}

	/**
	 * Emit the selected notice at a shared block-wrapper content slot.
	 *
	 * @param array $args Final block rendering arguments, including raw attributes.
	 * @param string $position Current slot: before or after the content container.
	 * @return void
	 */

	public static function output(array $args, string $position): void {
		echo self::render($args, $position);
	}

	/**
	 * Resolve safe defaults for a content-owned notice configuration.
	 *
	 * Only Group can declare section scope. Device/interaction styles never alter
	 * this configuration. Keep runtime normalization aligned with the JS adapter.
	 *
	 * @param mixed $value Persisted aiNotice attribute, possibly malformed.
	 * @param string $block_name Registered WPHAVE block name.
	 * @return array{mode:string,enabled:bool,scope:string,position:string,align:string} Canonical notice.
	 */

	public static function normalize($value, string $block_name): array {
		$notice = is_array($value) ? $value : [];
		$contract = WPHAVE_Media_Disclosure_Presentation::contract();
		$mode = in_array($notice['mode'] ?? null, $contract['noticeModes'], true)
			? $notice['mode']
			: (array_key_exists('enabled', $notice)
				? ($notice['enabled'] === true
					? 'show'
					: 'hide')
				: $contract['notice']['mode']);

		return [
			'mode' => $mode,
			'enabled' => $mode === 'show',
			'scope' =>
				$mode === 'show' &&
				$block_name === $contract['sectionBlock'] &&
				($notice['scope'] ?? '') === 'section'
					? 'section'
					: $contract['notice']['scope'],
			'position' =>
				($notice['position'] ?? '') === 'after' ? 'after' : $contract['notice']['position'],
			'align' => in_array($notice['align'] ?? '', $contract['noticeAlignments'], true)
				? $notice['align']
				: $contract['notice']['align'],
		];
	}

	/**
	 * Resolve attachment IDs using the same image/video precedence as background output.
	 *
	 * External URLs and video posters cannot establish the video's provenance.
	 * Featured images follow the current WordPress post, including loop contexts.
	 *
	 * @param array $wphave Resolved block styles after global-style application.
	 * @return int[] Unique selected local background attachment IDs.
	 */

	public static function background_media_ids(array $wphave): array {
		$ids = [];
		$layers = $wphave['background']['layers'] ?? [];
		foreach (is_array($layers) ? $layers : [] as $layer) {
			$media = is_array($layer) && is_array($layer['media'] ?? null) ? $layer['media'] : [];
			$image = is_array($media['image'] ?? null) ? $media['image'] : [];

			if (in_array($image['type'] ?? '', ['custom', 'featured', 'url'], true)) {
				if ($image['type'] === 'custom') {
					$ids[] = $image['data']['id'] ?? 0;
				}

				if ($image['type'] === 'featured' && !is_tax() && !is_category() && !is_tag()) {
					$ids[] = get_post_thumbnail_id();
				}
			} elseif (!empty($media['video']['type']) && $media['video']['type'] !== 'extern') {
				$ids[] = $media['video']['file'] ?? 0;
				$video = WPHAVE_Background_Media_Persistence::video($media['video']);
				$ids[] = $video['fileAlternate'] ?? 0;
			}
		}

		return array_values(
			array_unique(
				array_filter(
					array_map(
						static fn($id) => is_numeric($id) && (int) $id > 0 ? (int) $id : 0,
						$ids,
					),
				),
			),
		);
	}

	/**
	 * Render one content-flow label only when support, activation and slot match.
	 *
	 * The description identifies the declared scope and information source.
	 * Automatic mode follows attachment policy; explicit mode remains independent
	 * of global activation. Neither promises visibility under ancestor CSS.
	 *
	 * @param array $args Final wrapper arguments with block, block_name, supports and blockWrapper.
	 * @param string $position Current wrapper slot: before or after.
	 * @return string Escaped container and shared label/popover, or an empty string.
	 */

	public static function render(array $args, string $position): string {
		if (empty($args['supports']['wphave']['aiNotice']) || empty($args['blockWrapper'])) {
			return '';
		}

		$notice = self::normalize($args['block']['aiNotice'] ?? [], $args['block_name'] ?? '');

		if ($notice['mode'] === 'hide' || $notice['position'] !== $position) {
			return '';
		}

		if ($notice['mode'] === 'auto') {
			if (!WPHAVE_Media_Disclosure_Presentation::settings()['enabled']) {
				return '';
			}

			$ids = self::background_media_ids(
				$args['renderWphave'] ?? ($args['block']['wphave'] ?? []),
			);

			if (!array_filter($ids, [WPHAVE_Media_Disclosure::class, 'should_disclose'])) {
				return '';
			}
		}

		$text =
			$notice['scope'] === 'section'
				? __('This section contains images created or edited with AI.', 'wphave')
				: __('The background media of this block was created or edited with AI.', 'wphave');

		return '<div class="wphave-ai-notice" data-ai-notice-scope="' .
			esc_attr($notice['scope']) .
			'" data-ai-notice-position="' .
			esc_attr($notice['position']) .
			'" data-ai-notice-align="' .
			esc_attr($notice['align']) .
			'">' .
			WPHAVE_Media_Disclosure_Presentation::render(
				[],
				__('AI-generated or manipulated', 'wphave'),
				[
					'explicit' => $notice['mode'] === 'show',
					'flow' => true,
					'description' => $text,
					'source' =>
						$notice['mode'] === 'show'
							? __('Information provided by the website author.', 'wphave')
							: __('Information from the media library.', 'wphave'),
				],
			) .
			'</div>';
	}
}
