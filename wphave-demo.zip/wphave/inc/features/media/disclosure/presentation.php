<?php

/**
 * Render the shared public AI label and information popover.
 *
 * Attachment policy belongs to WPHAVE_Media_Disclosure; explicit block notice
 * policy belongs to WPHAVE_Block_AI_Notice. Both use this renderer and the same
 * CSS contract. This class does not infer or verify content provenance.
 */

class WPHAVE_Media_Disclosure_Presentation {
	/**
	 * Read immutable display defaults and choices shared with the editor.
	 *
	 * @return array<string,mixed> Bundled presentation contract; cached per request.
	 */

	public static function contract(): array {
		static $contract = null;

		if ($contract === null) {
			$contract = json_decode(
				file_get_contents(__DIR__ . '/contract.json'),
				true,
				512,
				JSON_THROW_ON_ERROR,
			);
		}

		return $contract;
	}

	/**
	 * Normalize saved or partial settings without modifying their stored values.
	 *
	 * @param mixed $value Untrusted or legacy settings resource value.
	 * @return array<string,mixed> Complete, canonical display settings.
	 */

	public static function normalize_settings($value): array {
		$value = is_array($value) ? $value : [];
		$contract = self::contract();
		$settings = $contract['settings'];
		$settings['enabled'] = false !== ($value['enabled'] ?? $settings['enabled']);
		$settings['show_provider'] =
			true === ($value['show_provider'] ?? $settings['show_provider']);

		foreach ($contract['choices'] as $key => $choices) {
			if (in_array($value[$key] ?? null, $choices, true)) {
				$settings[$key] = $value[$key];
			}
		}

		return $settings;
	}

	/**
	 * Restrict changes to premium presentation fields while preserving saved output.
	 *
	 * Compare canonical values so unchanged settings remain writable after a
	 * downgrade. Removing a saved premium choice also counts as a change.
	 * Entitlement is checked only when writing, never when rendering a label.
	 *
	 * @param mixed $next Complete proposed AI settings.
	 * @param mixed $current Previously persisted AI settings.
	 * @return true|WP_Error True when allowed, otherwise a Pro entitlement error.
	 */

	public static function validate_appearance_write($next, $current) {
		$next = self::normalize_settings($next);
		$current = self::normalize_settings($current);
		foreach (['variant', 'placement', 'tone'] as $key) {
			if ($next[$key] !== $current[$key]) {
				if (function_exists('wphave_has_pro_access') && wphave_has_pro_access()) {
					return true;
				}

				return new WP_Error(
					'wphave_ai_appearance_pro_required',
					__('Changing AI label appearance requires WPHAVE Pro.', 'wphave'),
					['status' => 403],
				);
			}
		}

		return true;
	}

	/**
	 * Read the canonical website-wide AI label configuration.
	 *
	 * Settings are deliberately not request-cached: previews and resource writes
	 * may change the active value while the same request continues rendering.
	 *
	 * @return array<string,mixed> Normalized presentation settings.
	 */

	public static function settings(): array {
		return self::normalize_settings(wphave_data_get('site_settings', 'general.media.ai', []));
	}

	/**
	 * Validate a partial resource update without silently accepting unknown fields.
	 *
	 * Legacy placements remain saveable and normalize to the default corner.
	 *
	 * @param mixed $value Submitted AI display settings.
	 * @return true|WP_Error True for valid input, otherwise a resource validation error.
	 */

	public static function validate($value) {
		if (!is_array($value)) {
			return new WP_Error(
				'wphave_invalid_media_ai',
				__('Choose valid AI label settings.', 'wphave'),
				['status' => 400],
			);
		}

		$choices = self::contract()['choices'];

		foreach ($value as $key => $setting) {
			// Accept legacy payloads from existing resources; rendering always uses a corner.
			if (
				$key === 'placement' &&
				in_array($setting, self::contract()['legacyPlacements'], true)
			) {
				$setting = self::contract()['settings']['placement'];
			}

			$valid = in_array($key, ['enabled', 'show_provider'], true)
				? is_bool($setting)
				: isset($choices[$key]) && in_array($setting, $choices[$key], true);

			if (!$valid) {
				return new WP_Error(
					'wphave_invalid_media_ai',
					__('Choose valid AI label settings.', 'wphave'),
					['status' => 400],
				);
			}
		}

		return true;
	}

	/**
	 * Sanitize renderer output while preserving the no-JavaScript disclosure.
	 *
	 * @param string $markup Renderer-produced markup, including its noscript fallback.
	 * @return string Allowed HTML for inline output or lightbox transport.
	 */

	public static function sanitize(string $markup): string {
		$allowed = wp_kses_allowed_html('post');
		$allowed['noscript'] = [];

		return wp_kses($markup, $allowed);
	}

	/**
	 * Describe an attachment origin without making an authenticity claim.
	 *
	 * @param string $origin Normalized origin or an unknown value.
	 * @return string Localized plain-text description.
	 */

	public static function description(string $origin): string {
		if ($origin === 'generated') {
			return __('This image was created with AI.', 'wphave');
		}

		if ($origin === 'manipulated') {
			return __('This image was edited with AI.', 'wphave');
		}

		return __('This image was created or edited with AI.', 'wphave');
	}

	/**
	 * Return shared disclosure root attributes for standalone and embedded output.
	 *
	 * @param array $settings Appearance settings normalized against the contract.
	 * @param bool $flow Whether the label participates in normal content flow.
	 * @return array<string,string> Unescaped attributes for the owning element.
	 */

	public static function root_attributes(array $settings, bool $flow = false): array {
		$settings = self::normalize_settings($settings);

		return [
			'class' => 'wphave-ai-disclosure',
			'data-ai-variant' => $settings['variant'],
			'data-ai-tone' => $settings['tone'],
			$flow ? 'data-ai-layout' : 'data-ai-placement' => $flow
				? 'flow'
				: $settings['placement'],
		];
	}

	/**
	 * Render one occurrence with unique IDs, shared assets and an accessible trigger.
	 *
	 * Presentation overrides are internal adapter inputs, never block HTML. The
	 * explicit flag preserves author-enabled notices when automatic labels are off;
	 * flow removes corner positioning. contentOnly lets a platform block own the
	 * shared root attributes without nesting another label. All text is escaped.
	 *
	 * @param array $data Normalized attachment data; empty for an author declaration.
	 * @param string $label Localized full label used for accessibility and fallback.
	 * @param array{explicit?:bool,flow?:bool,contentOnly?:bool,description?:string,source?:string,appearance?:array{variant?:string,tone?:string}} $presentation Adapter overrides.
	 * @return string Complete label/popover markup, or empty when output is disabled.
	 */

	public static function render(array $data, string $label, array $presentation = []): string {
		$settings = self::settings();

		if (isset($presentation['appearance']) && is_array($presentation['appearance'])) {
			// Only appearance is overridable; activation and placement remain explicit contracts.
			$appearance = array_intersect_key($presentation['appearance'], [
				'variant' => true,
				'tone' => true,
			]);
			$settings = self::normalize_settings(array_replace($settings, $appearance));
		}

		if (!$label || (!$settings['enabled'] && ($presentation['explicit'] ?? false) !== true)) {
			return '';
		}

		$id = wp_unique_id('wphave-ai-disclosure-');

		$content =
			'<div class="wphave-ai-information">' .
			'<p class="wphave-ai-information-title" tabindex="-1"><strong>' .
			esc_html(__('AI information', 'wphave')) .
			'</strong></p>' .
			'<p>' .
			esc_html($presentation['description'] ?? self::description($data['origin'] ?? '')) .
			'</p>';

		if ($settings['show_provider'] && !empty($data['provider'])) {
			$content .=
				'<p class="wphave-ai-information-provider"><strong>' .
				esc_html(__('AI provider:', 'wphave')) .
				'</strong> <span>' .
				esc_html($data['provider']) .
				'</span></p>';
		}

		$content .=
			'<p class="wphave-ai-information-source">' .
			esc_html(
				$presentation['source'] ?? __('Information from the media library.', 'wphave'),
			) .
			'</p></div>';

		wp_enqueue_script('wphave-popover');
		wp_enqueue_style('wphave-popover');

		$popover = wphave_render_popover(
			[
				'id' => $id,
				'label' => __('AI information', 'wphave'),
				'class' => 'wphave-ai-disclosure-popover',
				'portal' => true,
			],
			$content,
		);

		$markup = sprintf(
			'<button type="button" data-lightbox-ignore data-popover="%1$s" aria-controls="%1$s" aria-haspopup="dialog" aria-expanded="false" aria-label="%2$s"><span>%3$s</span></button><noscript><span>%5$s</span></noscript>%4$s',
			esc_attr($id),
			esc_attr(sprintf(__('%s — more information', 'wphave'), $label)),
			esc_html($settings['variant'] === 'compact' ? __('AI', 'wphave') : $label),
			$popover,
			esc_html($label),
		);

		if (($presentation['contentOnly'] ?? false) === true) {
			return $markup;
		}

		$attributes = '';
		foreach (
			self::root_attributes($settings, ($presentation['flow'] ?? false) === true)
			as $name => $value
		) {
			$attributes .= ' ' . $name . '="' . esc_attr($value) . '"';
		}

		return '<div' . $attributes . ' data-lightbox-ignore>' . $markup . '</div>';
	}
}
