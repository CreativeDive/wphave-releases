<?php

/**
 * Store and render disclosure information for AI-generated media.
 */

if (!defined('ABSPATH')) {
	exit();
}

/**
 * Own attachment provenance, visibility policy and disclosure cache invalidation.
 *
 * Public metadata describes author/provider records, not verified credentials.
 * Rendering is delegated to the shared presentation class; cached values contain
 * normalized data only, never per-occurrence markup or interactive IDs.
 */
class WPHAVE_Media_Disclosure {
	public const META_ORIGIN = '_wphave_ai_origin';
	public const META_DISCLOSURE = '_wphave_ai_disclosure';
	public const META_DEEPFAKE = '_wphave_ai_deepfake';
	public const META_PROVIDER = '_wphave_ai_provider';
	public const META_CREATED_AT = '_wphave_ai_created_at';

	public const ORIGIN_GENERATED = 'generated';
	public const ORIGIN_MANIPULATED = 'manipulated';
	public const ORIGIN_HUMAN = 'human';
	public const ORIGIN_UNKNOWN = 'unknown';

	public const DISCLOSURE_AUTO = 'auto';
	public const DISCLOSURE_VISIBLE = 'visible';
	public const DISCLOSURE_HIDDEN = 'hidden';

	public const DEEPFAKE_YES = 'yes';
	public const DEEPFAKE_NO = 'no';
	public const DEEPFAKE_UNKNOWN = 'unknown';

	/**
	 * Normalized attachment data already resolved during this request.
	 *
	 * WordPress caches attachment posts and metadata independently, but keeping
	 * the normalized result here also avoids repeating sanitization and business
	 * rules when attributes and the visible label are rendered together.
	 *
	 * @var array<int,array>
	 */

	private static array $request_cache = [];

	/**
	 * Register attachment metadata and make it available to the media REST API.
	 *
	 * @return void
	 */

	public static function init(): void {
		add_action('init', [self::class, 'register_meta']);
		add_action('wphave_site_settings_saved', ['WPHAVE_Post_Cache', 'delete_all_cache']);
		add_action('added_post_meta', [self::class, 'handle_meta_change'], 10, 4);
		add_action('updated_post_meta', [self::class, 'handle_meta_change'], 10, 4);
		add_action('deleted_post_meta', [self::class, 'handle_meta_change'], 10, 4);
	}

	/**
	 * Register the individual fields instead of one opaque object so other
	 * media integrations can inspect and update disclosure data selectively.
	 *
	 * @return void
	 */

	public static function register_meta(): void {
		$fields = [
			self::META_ORIGIN => [
				'default' => self::ORIGIN_UNKNOWN,
				'sanitize_callback' => [self::class, 'sanitize_origin'],
			],
			self::META_DISCLOSURE => [
				'default' => self::DISCLOSURE_AUTO,
				'sanitize_callback' => [self::class, 'sanitize_disclosure'],
			],
			self::META_DEEPFAKE => [
				'default' => self::DEEPFAKE_UNKNOWN,
				'sanitize_callback' => [self::class, 'sanitize_deepfake'],
			],
			self::META_PROVIDER => [
				'default' => '',
				'sanitize_callback' => 'sanitize_text_field',
			],
			self::META_CREATED_AT => [
				'default' => '',
				'sanitize_callback' => [self::class, 'sanitize_created_at'],
			],
		];

		foreach ($fields as $meta_key => $args) {
			register_post_meta('attachment', $meta_key, [
				'single' => true,
				'type' => 'string',
				'show_in_rest' => true,
				'default' => $args['default'],
				'sanitize_callback' => $args['sanitize_callback'],
				'auth_callback' => [self::class, 'can_access_meta'],
			]);
		}
	}

	/**
	 * Allow public provenance reads and restrict changes to attachment editors.
	 *
	 * @param bool $allowed Default authorization result.
	 * @param string $meta_key Registered meta key.
	 * @param int $post_id Attachment ID.
	 * @param int $user_id User ID.
	 * @param string $cap Meta capability.
	 * @return bool
	 */

	public static function can_access_meta(
		$allowed = false,
		$meta_key = '',
		$post_id = 0,
		$user_id = 0,
		$cap = '',
	): bool {
		if ($cap === 'read_post_meta') {
			return true;
		}

		$post_id = absint($post_id);
		$user_id = absint($user_id) ?: get_current_user_id();
		return $post_id
			? user_can($user_id, 'edit_post', $post_id)
			: user_can($user_id, 'upload_files');
	}

	/**
	 * Return normalized disclosure data for an attachment.
	 *
	 * @param int $attachment_id Attachment ID.
	 * @return array
	 */

	public static function get($attachment_id): array {
		$attachment_id = absint($attachment_id);
		if (!$attachment_id) {
			return self::defaults();
		}

		if (isset(self::$request_cache[$attachment_id])) {
			return self::$request_cache[$attachment_id];
		}

		if (get_post_type($attachment_id) !== 'attachment') {
			self::$request_cache[$attachment_id] = self::defaults();
			return self::$request_cache[$attachment_id];
		}

		self::$request_cache[$attachment_id] = [
			'origin' => self::sanitize_origin(
				get_post_meta($attachment_id, self::META_ORIGIN, true),
			),
			'disclosure' => self::sanitize_disclosure(
				get_post_meta($attachment_id, self::META_DISCLOSURE, true),
			),
			'deepfake' => self::sanitize_deepfake(
				get_post_meta($attachment_id, self::META_DEEPFAKE, true),
			),
			'provider' => sanitize_text_field(
				get_post_meta($attachment_id, self::META_PROVIDER, true),
			),
			'created_at' => self::sanitize_created_at(
				get_post_meta($attachment_id, self::META_CREATED_AT, true),
			),
		];

		return self::$request_cache[$attachment_id];
	}

	/**
	 * Render each occurrence separately. Only normalized provenance is cached:
	 * interactive IDs belong to the occurrence, never
	 * to the attachment or its persistent image cache entry.
	 *
	 * @param int $attachment_id Attachment ID; invalid IDs resolve to unknown origin.
	 * @param array{lightbox?:bool} $context Whether a separate lightbox occurrence is needed.
	 * @return array{attributes:string,label:string,lightbox_markup:string,lightbox_label:string,placement:string} Rendered occurrence.
	 */

	public static function render($attachment_id, array $context = []): array {
		$data = self::get($attachment_id);
		$settings = WPHAVE_Media_Disclosure_Presentation::settings();
		$visible = $settings['enabled'] && self::should_disclose_data($data);

		return [
			'attributes' => self::render_attributes_from_data($data),
			'label' => $visible
				? WPHAVE_Media_Disclosure_Presentation::render(
					$data,
					self::get_label_from_data($data),
				)
				: '',
			'lightbox_markup' =>
				$visible && !empty($context['lightbox'])
					? WPHAVE_Media_Disclosure_Presentation::render(
						$data,
						self::get_label_from_data($data),
					)
					: '',
			'lightbox_label' => $visible ? self::get_label_from_data($data) : '',
			'placement' => $settings['placement'],
		];
	}

	/**
	 * Update supported disclosure fields for an attachment.
	 *
	 * @param int $attachment_id Attachment ID.
	 * @param array $data Disclosure data.
	 * @return bool True after every submitted field is verified; false after a failed write and attempted rollback.
	 */

	public static function update($attachment_id, $data): bool {
		$attachment_id = absint($attachment_id);
		if (!$attachment_id || get_post_type($attachment_id) !== 'attachment' || !is_array($data)) {
			return false;
		}

		$fields = [
			'origin' => [self::META_ORIGIN, [self::class, 'sanitize_origin']],
			'disclosure' => [self::META_DISCLOSURE, [self::class, 'sanitize_disclosure']],
			'deepfake' => [self::META_DEEPFAKE, [self::class, 'sanitize_deepfake']],
			'provider' => [self::META_PROVIDER, 'sanitize_text_field'],
			'created_at' => [self::META_CREATED_AT, [self::class, 'sanitize_created_at']],
		];
		$updates = [];
		$previous = [];

		foreach ($fields as $field => $config) {
			if (array_key_exists($field, $data)) {
				$meta_key = $config[0];
				$updates[$meta_key] = call_user_func($config[1], $data[$field]);
				$previous[$meta_key] = [
					'exists' => metadata_exists('post', $attachment_id, $meta_key),
					'value' => get_post_meta($attachment_id, $meta_key, true),
				];
			}
		}

		foreach ($updates as $meta_key => $value) {
			// WordPress unslashes metadata input; preserve literal provider backslashes
			// on both commit and rollback (including transported composition metadata).
			update_post_meta($attachment_id, $meta_key, wp_slash($value));

			if ($value === get_post_meta($attachment_id, $meta_key, true)) {
				continue;
			}

			// DATA/ROLLBACK INVARIANT: Origin, disclosure duty, deepfake state,
			// provider and timestamp form one provenance projection. A caller sees
			// success only when every submitted field is exact; otherwise restore
			// both prior values and prior metadata absence before returning false.
			foreach (array_reverse($previous, true) as $rollback_key => $snapshot) {
				if ($snapshot['exists']) {
					update_post_meta($attachment_id, $rollback_key, wp_slash($snapshot['value']));
				} else {
					delete_post_meta($attachment_id, $rollback_key);
				}
			}

			return false;
		}

		return true;
	}

	/**
	 * Invalidate cached page output when disclosure metadata changes.
	 *
	 * Attachments can be used on several pages and the post cache deliberately
	 * has no reverse attachment-to-page index. Invalidation is therefore global,
	 * matching the existing attachment image invalidation strategy. Each change invalidates
	 * again because output may have been cached between writes in one request.
	 *
	 * @param int|int[] $meta_id Metadata row ID, or deleted row IDs for deleted_post_meta.
	 * @param int $attachment_id Attachment ID.
	 * @param string $meta_key Metadata key.
	 * @param mixed $meta_value Metadata value.
	 * @return void
	 */

	public static function handle_meta_change(
		$meta_id,
		$attachment_id,
		$meta_key,
		$meta_value,
	): void {
		if (!in_array($meta_key, self::meta_keys(), true)) {
			return;
		}

		unset(self::$request_cache[absint($attachment_id)]);
		if (!in_array($meta_key, self::render_meta_keys(), true)) {
			return;
		}

		WPHAVE_Post_Cache::delete_all_cache();
	}

	/**
	 * Mark an attachment as generated by an AI system.
	 *
	 * @param int $attachment_id Attachment ID.
	 * @param string $provider Provider name.
	 * @return bool
	 */

	public static function mark_generated($attachment_id, $provider = ''): bool {
		return self::update($attachment_id, [
			'origin' => self::ORIGIN_GENERATED,
			'disclosure' => self::DISCLOSURE_AUTO,
			'deepfake' => self::DEEPFAKE_UNKNOWN,
			'provider' => $provider,
			'created_at' => current_time('c', true),
		]);
	}

	/**
	 * Mark an attachment as substantially manipulated by an AI system.
	 *
	 * @param int $attachment_id Attachment ID.
	 * @param string $provider Provider name.
	 * @return bool
	 */

	public static function mark_manipulated($attachment_id, $provider = ''): bool {
		return self::update($attachment_id, [
			'origin' => self::ORIGIN_MANIPULATED,
			'disclosure' => self::DISCLOSURE_AUTO,
			'deepfake' => self::DEEPFAKE_UNKNOWN,
			'provider' => $provider,
			'created_at' => current_time('c', true),
		]);
	}

	/**
	 * Evaluate the attachment visibility policy independently of global output.
	 * A deepfake classification overrides the attachment-level hidden preference;
	 * the global automatic-label switch is applied by the presentation layer.
	 *
	 * @param int $attachment_id Attachment ID.
	 * @return bool
	 */

	public static function should_disclose($attachment_id): bool {
		return self::should_disclose_data(self::get($attachment_id));
	}

	/**
	 * Evaluate disclosure visibility without resolving attachment data again.
	 *
	 * @param array $data Normalized disclosure data.
	 * @return bool
	 */

	private static function should_disclose_data($data): bool {
		if ($data['deepfake'] === self::DEEPFAKE_YES) {
			return true;
		}

		return $data['disclosure'] === self::DISCLOSURE_VISIBLE &&
			in_array($data['origin'], [self::ORIGIN_GENERATED, self::ORIGIN_MANIPULATED], true);
	}

	/**
	 * Return the localized visible label for an attachment.
	 *
	 * @param int $attachment_id Attachment ID.
	 * @return string
	 */

	public static function get_label($attachment_id): string {
		return self::get_label_from_data(self::get($attachment_id));
	}

	/**
	 * Return the localized label for normalized disclosure data.
	 *
	 * @param array $data Normalized disclosure data.
	 * @return string
	 */

	private static function get_label_from_data($data): string {
		if ($data['origin'] === self::ORIGIN_MANIPULATED) {
			return __('AI-manipulated', 'wphave');
		}

		if ($data['origin'] === self::ORIGIN_GENERATED) {
			return __('AI-generated', 'wphave');
		}

		if ($data['deepfake'] === self::DEEPFAKE_YES) {
			return __('AI-generated or manipulated', 'wphave');
		}

		return '';
	}

	/**
	 * Return machine-readable HTML attributes for known AI media.
	 *
	 * @param int $attachment_id Attachment ID.
	 * @return array
	 */

	public static function get_attributes($attachment_id): array {
		return self::get_attributes_from_data(self::get($attachment_id));
	}

	/**
	 * Return machine-readable attributes for normalized disclosure data.
	 *
	 * @param array $data Normalized disclosure data.
	 * @return array
	 */

	private static function get_attributes_from_data($data): array {
		if (!in_array($data['origin'], [self::ORIGIN_GENERATED, self::ORIGIN_MANIPULATED], true)) {
			return [];
		}

		return [
			'data-ai-origin' => $data['origin'],
			'data-ai-disclosure' => self::should_disclose_data($data)
				? self::DISCLOSURE_VISIBLE
				: $data['disclosure'],
		];
	}

	/**
	 * Convert machine-readable disclosure attributes to escaped HTML.
	 *
	 * @param int $attachment_id Attachment ID.
	 * @return string
	 */

	public static function render_attributes($attachment_id): string {
		return self::render_attributes_from_data(self::get($attachment_id));
	}

	/**
	 * Serialize attributes from an already normalized data set.
	 *
	 * @param array $data Normalized disclosure data.
	 * @return string
	 */

	private static function render_attributes_from_data($data): string {
		$attributes = [];
		foreach (self::get_attributes_from_data($data) as $name => $value) {
			$attributes[] = esc_attr($name) . '="' . esc_attr($value) . '"';
		}

		return implode(' ', $attributes);
	}

	/**
	 * Render the visible disclosure label when required.
	 *
	 * @param int $attachment_id Attachment ID.
	 * @return string
	 */

	public static function render_label($attachment_id): string {
		return self::render_label_from_data(self::get($attachment_id));
	}

	/**
	 * Render a label from an already normalized data set.
	 *
	 * @param array $data Normalized disclosure data.
	 * @return string
	 */

	private static function render_label_from_data($data): string {
		if (!self::should_disclose_data($data)) {
			return '';
		}

		$label = self::get_label_from_data($data);
		return WPHAVE_Media_Disclosure_Presentation::render($data, $label);
	}

	/**
	 * Return metadata keys that affect cached disclosure output.
	 *
	 * @return array
	 */

	private static function meta_keys(): array {
		return [
			self::META_ORIGIN,
			self::META_DISCLOSURE,
			self::META_DEEPFAKE,
			self::META_PROVIDER,
			self::META_CREATED_AT,
		];
	}

	/**
	 * Return metadata keys represented in persistent frontend markup.
	 *
	 * @return array
	 */

	private static function render_meta_keys(): array {
		return [self::META_ORIGIN, self::META_DISCLOSURE, self::META_DEEPFAKE, self::META_PROVIDER];
	}

	/**
	 * Sanitize the media origin enum.
	 *
	 * @param mixed $value Origin value.
	 * @return string
	 */

	public static function sanitize_origin($value): string {
		$value = is_scalar($value) ? sanitize_key((string) $value) : '';
		return in_array(
			$value,
			[
				self::ORIGIN_GENERATED,
				self::ORIGIN_MANIPULATED,
				self::ORIGIN_HUMAN,
				self::ORIGIN_UNKNOWN,
			],
			true,
		)
			? $value
			: self::ORIGIN_UNKNOWN;
	}

	/**
	 * Sanitize the disclosure preference enum.
	 *
	 * @param mixed $value Disclosure value.
	 * @return string
	 */

	public static function sanitize_disclosure($value): string {
		$value = is_scalar($value) ? sanitize_key((string) $value) : '';
		return in_array(
			$value,
			[self::DISCLOSURE_AUTO, self::DISCLOSURE_VISIBLE, self::DISCLOSURE_HIDDEN],
			true,
		)
			? $value
			: self::DISCLOSURE_AUTO;
	}

	/**
	 * Sanitize the deepfake classification enum.
	 *
	 * @param mixed $value Deepfake value.
	 * @return string
	 */

	public static function sanitize_deepfake($value): string {
		$value = is_scalar($value) ? sanitize_key((string) $value) : '';
		return in_array(
			$value,
			[self::DEEPFAKE_YES, self::DEEPFAKE_NO, self::DEEPFAKE_UNKNOWN],
			true,
		)
			? $value
			: self::DEEPFAKE_UNKNOWN;
	}

	/**
	 * Normalize a creation timestamp to an ISO 8601 value.
	 *
	 * @param mixed $value Timestamp value.
	 * @return string
	 */

	public static function sanitize_created_at($value): string {
		$value = sanitize_text_field($value);
		if (!$value || strtotime($value) === false) {
			return '';
		}

		return gmdate('c', strtotime($value));
	}

	/**
	 * Return defaults for attachments without disclosure data.
	 *
	 * @return array
	 */

	private static function defaults(): array {
		return [
			'origin' => self::ORIGIN_UNKNOWN,
			'disclosure' => self::DISCLOSURE_AUTO,
			'deepfake' => self::DEEPFAKE_UNKNOWN,
			'provider' => '',
			'created_at' => '',
		];
	}
}
