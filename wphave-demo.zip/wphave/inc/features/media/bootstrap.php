<?php
/**
 * Bootstrap the WPHAVE media feature modules.
 */

if (!defined('ABSPATH')) {
	exit();
}

require_once wphave_dir() . 'inc/features/security/atomic-file.php';
require_once wphave_dir() . 'inc/features/security/file-identity.php';
require_once wphave_dir() . 'inc/features/security/conditional-file.php';
require_once __DIR__ . '/disclosure/presentation.php';
require_once __DIR__ . '/disclosure/block-notice.php';
require_once __DIR__ . '/disclosure/media-disclosure.php';
require_once __DIR__ . '/images/processing.php';
require_once __DIR__ . '/file-types.php';
require_once __DIR__ . '/output.php';

// Bootstrap owns hook registration; class files only declare their contracts.
WPHAVE_Media_Disclosure::init();
WPHAVE_Block_AI_Notice::init();
