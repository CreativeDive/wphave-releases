<?php

/**
 * Bootstrap media services used by management requests.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/attachments/manager.php';
require_once __DIR__ . '/images/regenerate-thumbnails.php';
require_once __DIR__ . '/folders.php';
require_once __DIR__ . '/file-upload.php';
