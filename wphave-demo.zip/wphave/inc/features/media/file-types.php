<?php

if (!defined('ABSPATH')) {
	exit();
}
/**
 * Add optional support for SVG uploads. SVG files are sanitized before
 * WordPress moves them into the uploads folder.
 */

function wphave_svg_upload_support_enabled() {
	return (bool) wphave_data_get('site_settings', 'general.media.svg_upload_support', false);
}

/**
 * Apply the canonical SVG policy to bytes before any upload mutation.
 *
 * @param array $file PHP upload-style file data.
 * @return true|WP_Error
 */

function wphave_prepare_special_media_upload($file) {
	$extension = strtolower(pathinfo($file['name'] ?? '', PATHINFO_EXTENSION));
	$temporary = (string) ($file['tmp_name'] ?? '');

	if ('svg' === $extension) {
		if (!wphave_svg_upload_support_enabled()) {
			return new WP_Error(
				'wphave_svg_upload_disabled',
				__('SVG uploads are disabled.', 'wphave'),
			);
		}

		if (!wphave_sanitize_svg_file($temporary)) {
			return new WP_Error(
				'wphave_svg_upload_unsafe',
				__('The SVG file is invalid or contains unsafe content.', 'wphave'),
			);
		}
	}

	return true;
}

/**
 * Media upload mimes.
 *
 * @param mixed $mimes Mimes.
 */

function wphave_media_upload_mimes($mimes) {
	if (wphave_svg_upload_support_enabled()) {
		$mimes['svg'] = 'image/svg+xml';
	}

	return $mimes;
}

add_filter('upload_mimes', 'wphave_media_upload_mimes');

/**
 * Add SVG to the temporary MIME catalog used by an attachment read request.
 *
 * @param array $mimes Allowed MIME types.
 * @return array
 */

function wphave_existing_svg_read_mime($mimes) {
	$mimes['svg'] = 'image/svg+xml';
	return $mimes;
}

/**
 * Keep existing SVG attachments visible in image selection queries.
 *
 * WordPress derives `media_type=image` from the upload MIME allow-list. The
 * SVG MIME is added only while handling this exact GET collection callback,
 * then removed again. Upload authorization and pagination parameters remain
 * unchanged.
 *
 * @param mixed           $response Current REST response.
 * @param array           $handler Matched REST route handler.
 * @param WP_REST_Request $request REST request.
 * @return mixed
 */

function wphave_prepare_existing_svg_attachment_read($response, $handler, $request) {
	if (
		!($request instanceof WP_REST_Request) ||
		$request->get_method() !== 'GET' ||
		$request->get_route() !== '/wp/v2/media'
	) {
		return $response;
	}

	$requested_media_types = array_filter((array) $request->get_param('media_type'));

	if (in_array('image', $requested_media_types, true)) {
		add_filter('upload_mimes', 'wphave_existing_svg_read_mime', PHP_INT_MAX);
	}

	return $response;
}

/**
 * Remove the request-scoped existing-SVG MIME extension.
 *
 * @param mixed           $response Current REST response.
 * @param array           $handler Matched REST route handler.
 * @param WP_REST_Request $request REST request.
 * @return mixed
 */

function wphave_finish_existing_svg_attachment_read($response, $handler, $request) {
	remove_filter('upload_mimes', 'wphave_existing_svg_read_mime', PHP_INT_MAX);
	return $response;
}

add_filter('rest_request_before_callbacks', 'wphave_prepare_existing_svg_attachment_read', 10, 3);
add_filter('rest_request_after_callbacks', 'wphave_finish_existing_svg_attachment_read', 10, 3);

/**
 * Sanitize SVG file.
 *
 * @param mixed $file File.
 */

function wphave_sanitize_svg_file($file) {
	if (!class_exists('WPHAVE_Safe_SVG')) {
		return false;
	}

	return WPHAVE_Safe_SVG::sanitize_file($file);
}

/**
 * Sanitize SVG upload.
 *
 * @param mixed $file File.
 */

function wphave_sanitize_svg_upload($file) {
	$extension = strtolower(pathinfo($file['name'] ?? '', PATHINFO_EXTENSION));

	if ('svg' !== $extension) {
		return $file;
	}

	$prepared = wphave_prepare_special_media_upload($file);

	if (is_wp_error($prepared)) {
		$file['error'] = $prepared->get_error_message();
		return $file;
	}

	$file['type'] = 'image/svg+xml';

	// SECURITY INVARIANT: Every mutation path calls the same preparation contract;
	// SVG bytes are sanitized before authorization.

	return $file;
}

add_filter('wp_handle_upload_prefilter', 'wphave_sanitize_svg_upload');
add_filter('wp_handle_sideload_prefilter', 'wphave_sanitize_svg_upload');

/**
 * Check SVG filetype.
 *
 * @param mixed $data Data.
 * @param mixed $file File.
 * @param mixed $filename Filename.
 * @param mixed $mimes Mimes.
 */

function wphave_check_svg_filetype($data, $file, $filename, $mimes) {
	$extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

	// MIME INVARIANT: Other callers can reach this global Core filter without
	// running our upload prefilter. Classify only canonical sanitized file bytes.
	if (
		$extension === 'svg' &&
		wphave_svg_upload_support_enabled() &&
		isset($mimes['svg']) &&
		class_exists('WPHAVE_Safe_SVG') &&
		WPHAVE_Safe_SVG::is_sanitized_file($file)
	) {
		$data['ext'] = 'svg';
		$data['type'] = 'image/svg+xml';
		$data['proper_filename'] = $filename;
	}

	return $data;
}

add_filter('wp_check_filetype_and_ext', 'wphave_check_svg_filetype', 10, 4);

/**
 * Return the preferred image MIME.
 *
 * @param string $format
 * @return string|null
 */

if (!function_exists('wphave_get_preferred_image_mime')):
	function wphave_get_preferred_image_mime($format) {
		switch ($format) {
			case 'avif':
				return function_exists('imageavif') ? 'image/avif' : null;

			case 'webp':
				return function_exists('imagewebp') ? 'image/webp' : null;

			case 'auto':
				if (function_exists('imageavif')) {
					return 'image/avif';
				}

				if (function_exists('imagewebp')) {
					return 'image/webp';
				}

				return null;
		}

		return null;
	}
endif;

/**
 * Function to check if a PNG image has transparency.
 */

if (!function_exists('wphave_png_has_transparency')):
	function wphave_png_has_transparency($image, $file = null) {
		if ($image instanceof WP_Image_Editor_Imagick) {
			if (isset($image->image) && $image->image instanceof Imagick) {
				try {
					$image->image->setIteratorIndex(0);

					if (method_exists($image->image, 'getImageChannelRange')) {
						$range = $image->image->getImageChannelRange(Imagick::CHANNEL_ALPHA);
						$min = isset($range['minima']) ? (float) $range['minima'] : 1;
						$max = isset($range['maxima']) ? (float) $range['maxima'] : 1;

						return $min < $max || $min < 1;
					}

					return (bool) $image->image->getImageAlphaChannel();
				} catch (Exception $e) {
					return true; // fallback safe
				}
			}
		}

		if ($image instanceof WP_Image_Editor_GD) {
			if (
				isset($image->image) &&
				(is_resource($image->image) ||
					(class_exists('GdImage') && $image->image instanceof GdImage))
			) {
				$gd_image = $image->image;
				$transparent_index = imagecolortransparent($gd_image);

				if ($transparent_index >= 0) {
					return true;
				}

				$width = imagesx($gd_image);
				$height = imagesy($gd_image);

				for ($y = 0; $y < $height; $y++) {
					for ($x = 0; $x < $width; $x++) {
						$rgba = imagecolorat($gd_image, $x, $y);
						$alpha = ($rgba & 0x7f000000) >> 24;

						if ($alpha > 0) {
							return true;
						}
					}
				}

				return false;
			}
		}

		if ($file && file_exists($file) && is_readable($file)) {
			return wphave_png_file_can_have_transparency($file);
		}

		// If we can't detect → assume transparency (safe fallback)
		return true;
	}
endif;

if (!function_exists('wphave_png_file_can_have_transparency')):
	/**
	 * Png file can have transparency.
	 *
	 * @param mixed $file File.
	 */

	function wphave_png_file_can_have_transparency($file) {
		$handle = fopen($file, 'rb');

		if (!$handle) {
			return true;
		}

		$signature = fread($handle, 8);

		if ($signature !== "\x89PNG\r\n\x1a\n") {
			fclose($handle);
			return true;
		}

		$header = fread($handle, 25);

		if (strlen($header) >= 25 && substr($header, 4, 4) === 'IHDR') {
			$color_type = ord($header[17]);

			if (in_array($color_type, [4, 6], true)) {
				fclose($handle);
				return true;
			}
		}

		while (!feof($handle)) {
			$length_bytes = fread($handle, 4);

			if (strlen($length_bytes) !== 4) {
				break;
			}

			$length = unpack('N', $length_bytes)[1];
			$type = fread($handle, 4);

			if ($type === 'tRNS') {
				fclose($handle);
				return true;
			}

			if ($type === 'IDAT' || $type === 'IEND') {
				break;
			}

			fseek($handle, $length + 4, SEEK_CUR);
		}

		fclose($handle);

		return false;
	}
endif;
