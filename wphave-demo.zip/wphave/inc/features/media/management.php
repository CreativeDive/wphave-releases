<?php

/** Bootstrap Media management endpoints. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/admin.php';
