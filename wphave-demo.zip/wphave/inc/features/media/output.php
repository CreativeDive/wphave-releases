<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * Change the default WordPress image compression level.
 * Notice: Default WordPress image compression is 82%.
 */

if ( ! function_exists( 'wphave_image_compression_quality' ) ) :

	function wphave_image_compression_quality( $quality ) {

		$compression = wphave_data_get( 'site_settings', 'general.media.image_compression' );

		if( $compression ) {
            $compression = str_replace('%', '', $compression);
			return $compression;
		}

		// Default compression level
		return 82; // <-- 100 is highest quality
	}

endif;

add_filter( 'jpeg_quality', 'wphave_image_compression_quality', 10, 1 );
add_filter( 'wp_editor_set_quality', 'wphave_image_compression_quality', 10, 1 );


/**
 * Image metadata (EXIF) is removed automatically during image processing.
 * Some servers keep metadata by default, so we ensure it is always stripped
 * for consistent optimization results.
 */

if ( ! function_exists( 'wphave_strip_image_metadata' ) ) :

	function wphave_strip_image_metadata( $image ) {

        // Imagick preserves metadata, so we strip it manually.
		if ( $image instanceof WP_Image_Editor_Imagick ) {

			if ( isset( $image->image ) && $image->image instanceof Imagick ) {
				$image->image->stripImage();
			}
		}

		// GD removes metadata automatically when saving.
		return $image;

	}

endif;

add_filter( 'wp_image_editor_before_save', 'wphave_strip_image_metadata' );


/**
 * By default the WP RSS feed contains no related featured image. In this way we can assign it.
 */

if ( ! function_exists( 'wphave_feed_featured_image' ) ) :

    function wphave_feed_featured_image( $content ) {

        global $post;

        if( has_post_thumbnail( $post->ID ) ) {
            $content = get_the_post_thumbnail( $post->ID, 'thumbnail' ) . $content;
        }

        return $content;

    }

endif;

add_filter( 'the_excerpt_rss', 'wphave_feed_featured_image' );
add_filter( 'the_content_feed', 'wphave_feed_featured_image' );


/**
 * Fix the wrong width and height attribute values on the <img> tag, if a SVG is included via wp_get_attachment_url().
 */

if ( ! function_exists( 'wphave_wp_svg_image_fix' ) ) :

	function wphave_wp_svg_image_fix( $out, $id ) {

        $image_url = wp_get_attachment_url( $id );
        $file_ext = pathinfo( $image_url, PATHINFO_EXTENSION );

        if( 'svg' !== $file_ext ) {
            return false;
        }

        // Prevent adding [width="1"] and [height="1"] to the <img> tag for SVGs
        return array( $image_url, null, null, false );

	}

endif;

add_filter( 'image_downsize', 'wphave_wp_svg_image_fix', 10, 2 );


/**
 * If we have the same identical SVG multiple times in use, we can use the <use id="" /> tag to save DOM size.
 */

if ( ! function_exists( 'wphave_svg_element_use' ) ) :

	function wphave_svg_element_use( $svg ) {

        // Count the use of each unique SVG
        static $counters = array();

        if( ! isset( $counters[$svg] ) ) {
            $counters[$svg] = 0;
        }

        $counters[$svg]++;

        if( $counters[$svg] == 0 ) {
            // Make sure the first use of this SVG file is output normally so that it serves as a reference for other <use /> tags
            return $svg;
        }

        /**
         * Function to register "media_details" rest route. In this way we can update attachment "media_details" date, which is not a part of post meta.
         */

		// Find the "id" attribute value
        // We use the id inside the <g id="my_svg_id"> tag to group all paths and replace these by <use href="#my_svg_id />
        preg_match('/id="([^"]+)"/', $svg, $matches);
        $id = isset( $matches[1] ) ? $matches[1] : '';

        if( $id ) {

            // Find the whole element with "id" attribute
            $pattern = '/<([^\/\s>]+)[^>]*id="([^"]+)"[^>]*>(.*?)<\/\1>/';

            // Replace the whole element with the <use /> tag
            $svg_with_use = preg_replace($pattern, '<use href="#$2" />', $svg);

            // Return <use /> tag to save DOM size
            return $svg_with_use;

        }

        /**
         * Function to register "media_details" rest route. In this way we can update attachment "media_details" date, which is not a part of post meta.
         */

        return $svg;

	}

endif;


/**
 * Function to register "media_details" rest route. In this way we can update attachment "media_details" date, which is not a part of post meta.
 */

if ( ! function_exists( 'wphave_register_media_details_rest_route' ) ) :

	function wphave_can_update_media_details( $request ) {
		$id = absint( $request['id'] ?? 0 );

		// SECURITY INVARIANT: Library-wide upload access never authorizes metadata
		// mutation; the caller must also be able to edit this exact attachment.
		return $id && current_user_can( 'upload_files' ) && current_user_can( 'edit_post', $id );
	}

	function wphave_update_media_details( $request ) {
		// AUTHORIZATION INVARIANT: The route permission is only an early gate.
		// Recheck the exact attachment immediately before reading or writing metadata.
		if ( ! wphave_can_update_media_details( $request ) ) {
			return new WP_Error(
				'wphave_media_details_forbidden',
				__( 'You are not allowed to update this media file.', 'wphave' ),
				array( 'status' => 403 )
			);
		}

		$id = absint( $request['id'] );
		$params = $request->get_json_params();
		$meta = wp_get_attachment_metadata( $id );

		if ( ! is_array( $meta ) ) {
			$meta = array();
		}

		if ( isset( $params['artist'] ) ) {
			$meta['artist'] = sanitize_text_field( $params['artist'] );
		}

		if ( isset( $params['album'] ) ) {
			$meta['album'] = sanitize_text_field( $params['album'] );
		}

		// AUTHORIZATION/TOCTOU INVARIANT: Sanitization filters are extension-code
		// boundaries. Re-evaluate upload and exact-object authority after every
		// payload transformation and immediately before canonical metadata changes.
		if ( ! wphave_can_update_media_details( $request ) ) {
			return new WP_Error(
				'wphave_media_details_forbidden',
				__( 'You are not allowed to update this media file.', 'wphave' ),
				array( 'status' => 403 )
			);
		}

		wp_update_attachment_metadata( $id, $meta );

		// DATA/COMMIT INVARIANT: The response may expose only metadata confirmed in
		// canonical attachment storage. An attempted write is not a commit, and a
		// filtered or failed update must never return an imaginary successful state.
		if ( $meta !== wp_get_attachment_metadata( $id ) ) {
			return new WP_Error(
				'wphave_media_details_write_failed',
				__( 'The media details could not be saved.', 'wphave' ),
				array( 'status' => 500 )
			);
		}

		return rest_ensure_response(
			array(
				'success' => true,
				'meta' => $meta,
			)
		);
	}

    function wphave_register_media_details_rest_route() {

        register_rest_route('wphave/v1', '/media/(?P<id>\d+)/details', [
            'methods' => 'POST',
			'callback' => 'wphave_update_media_details',
			'permission_callback' => 'wphave_can_update_media_details',
        ]);

    }

endif;

add_action( 'rest_api_init', 'wphave_register_media_details_rest_route' );
