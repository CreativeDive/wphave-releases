<?php

/** Shared, read-time image source resolution for WPHAVE galleries. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/thumbnail-gallery.php';
require_once dirname( __DIR__ ) . '/content-models/field-types/attachment-access.php';

/** Normalize current and pre-release gallery source attributes at one boundary. */
function wphave_gallery_source_key( array $attributes ): string {
	$source = sanitize_key( $attributes['source'] ?? 'manual' );
	return 'custom' === $source
		? sanitize_key( $attributes['customSource'] ?? 'post_gallery' )
		: $source;
}

/** Restrict gallery image actions to destinations owned by the image itself. */
function wphave_gallery_image_action( array $attributes ): string {
	$link = is_array( $attributes['link'] ?? null ) ? $attributes['link'] : array();
	$type = $link['type'] ?? 'none';
	return in_array( $type, array( 'lightbox', 'image-new-tab' ), true ) ? $type : 'none';
}

/** Read an explicitly selected Gallery Content Field from an accessible post. */
function wphave_gallery_content_field_ids( int $post_id, string $field_key ): array {
	$post = get_post( $post_id );
	$field_key = sanitize_key( $field_key );

	if (
		! $post
		|| ! $field_key
		|| ( ! is_post_publicly_viewable( $post ) && ! current_user_can( 'read_post', $post_id ) )
		|| post_password_required( $post )
		|| ! class_exists( 'WPHAVE_Content_Model_Registry' )
		|| ! class_exists( 'WPHAVE_Content_Model_Value_Repository' )
	) {
		return array();
	}

	$field = WPHAVE_Content_Model_Registry::field( $post->post_type, $field_key );
	if ( ! $field || 'gallery' !== ( $field['type'] ?? '' ) ) {
		return array();
	}

	$value = WPHAVE_Content_Model_Value_Repository::get( $post, $field_key );
	if ( ! is_string( $value ) ) {
		return array();
	}

	$ids = json_decode( $value, true );
	if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $ids ) || count( $ids ) > 50 ) {
		return array();
	}

	$normalized = array();
	foreach ( $ids as $id ) {
		if ( ! is_int( $id ) || $id <= 0 || isset( $normalized[ $id ] ) ) {
			return array();
		}
		$normalized[ $id ] = $id;
	}

	return array_values( $normalized );
}

/** Project every source through the same current attachment disclosure policy. */
function wphave_gallery_items( string $source, int $post_id = 0, string $field_key = '', array $manual_ids = array(), bool $include_featured = true ): array {
	if ( 'manual' === $source ) {
		$ids = $manual_ids;
	} elseif ( 'post_gallery' === $source ) {
		$ids = wphave_thumbnail_gallery_post_image_ids( $post_id, $include_featured );
	} elseif ( 'content_field' === $source ) {
		$ids = wphave_gallery_content_field_ids( $post_id, $field_key );
	} else {
		return array();
	}

	if ( ! class_exists( 'WPHAVE_Content_Model_Attachment_Access' ) ) {
		return array();
	}

	$ids = array_values( array_filter(
		array_slice( $ids, 0, 50 ),
		static fn( $id ) => is_numeric( $id )
			&& WPHAVE_Content_Model_Attachment_Access::can_read( (int) $id )
	) );

	return wphave_thumbnail_gallery_attachment_items( $ids );
}
