<?php

/** Resolve ordered post-gallery IDs without copying provider data into block attributes. */
function wphave_thumbnail_gallery_post_image_ids( int $post_id, bool $include_featured ): array {
	if ( ! $post_id || ! get_post( $post_id ) ) {
		return array();
	}

	if (
		( ! is_post_publicly_viewable( $post_id ) && ! current_user_can( 'read_post', $post_id ) )
		|| post_password_required( $post_id )
	) {
		return array();
	}

	$featured_id = (int) get_post_thumbnail_id( $post_id );
	$is_woocommerce_product = 'product' === get_post_type( $post_id )
		&& class_exists( 'WPHAVE_WooCommerce' )
		&& WPHAVE_WooCommerce::is_active();

	if ( $is_woocommerce_product ) {
		$ids = WPHAVE_WooCommerce::product_gallery_image_ids( $post_id );
	} else {
		$ids = get_post_meta( $post_id, 'wphave_post_gallery_images', true );
		$ids = is_array( $ids ) ? $ids : array();

		if ( $include_featured && $featured_id ) {
			array_unshift( $ids, $featured_id );
		}
	}

	if ( ! $include_featured && $featured_id ) {
		$ids = array_filter(
			$ids,
			static function ( $id ) use ( $featured_id ): bool {
				return (int) $id !== $featured_id;
			}
		);
	}

	return array_slice( array_values( array_unique( array_map( 'absint', $ids ) ) ), 0, 50 );
}

/** Both manual and post sources share one attachment-to-gallery projection. */
function wphave_thumbnail_gallery_attachment_items( array $ids ): array {
	$items = array();

	foreach ( array_slice( $ids, 0, 50 ) as $image_id ) {
		$image_id = absint( $image_id );

		if ( ! $image_id || ! wp_attachment_is_image( $image_id ) ) {
			continue;
		}

		$src = wp_get_attachment_image_url( $image_id, 'full' );

		if ( ! $src ) {
			continue;
		}

		$items[] = array(
			'id' => (string) $image_id,
			'src' => $src,
			'thumbnail' => wp_get_attachment_image_url( $image_id, 'thumbnail' ) ?: $src,
			'alt' => (string) get_post_meta( $image_id, '_wp_attachment_image_alt', true ),
			'label' => get_the_title( $image_id ),
		);
	}

	return $items;
}
