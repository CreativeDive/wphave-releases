<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Attachment_File_Operations {
	/**
	 * Validate an attachment.
	 *
	 * @param int $attachment_id
	 * @return true|WP_Error
	 */

	private static function validate_attachment($attachment_id) {
		$post = get_post($attachment_id);

		if (!$post || $post->post_type !== 'attachment') {
			return new WP_Error(
				'wphave_invalid_attachment',
				__('The requested attachment could not be found.', 'wphave'),
				['status' => 404],
			);
		}

		$file = get_attached_file($attachment_id);

		if (!$file || !file_exists($file) || !is_readable($file)) {
			return new WP_Error(
				'wphave_attachment_file_missing',
				__('The attachment file could not be found or is not readable.', 'wphave'),
				['status' => 400],
			);
		}

		if (!self::normalize_existing_upload_path($file)) {
			return new WP_Error(
				'wphave_attachment_file_outside_uploads',
				__('The attachment file is outside the WordPress upload directory.', 'wphave'),
				['status' => 400],
			);
		}

		return true;
	}

	/**
	 * Prepare the new basename.
	 *
	 * @param string $filename
	 * @param string $current_file
	 * @return string|WP_Error
	 */

	private static function prepare_new_basename($filename, $current_file) {
		$current_extension = strtolower(pathinfo($current_file, PATHINFO_EXTENSION));
		$filename = sanitize_file_name(remove_accents($filename));
		$filename = preg_replace('/\.[a-z0-9]{2,5}$/i', '', $filename);
		$filename = preg_replace('/[^a-z0-9_-]/', '-', strtolower($filename));
		$filename = preg_replace('/-+/', '-', $filename);
		$filename = trim($filename, '-_');

		if (!$filename) {
			return new WP_Error(
				'wphave_invalid_filename',
				__('Please enter a valid file name.', 'wphave'),
				['status' => 400],
			);
		}

		if (!$current_extension) {
			return new WP_Error(
				'wphave_missing_file_extension',
				__('The current attachment file has no file extension.', 'wphave'),
				['status' => 400],
			);
		}

		if ($filename . '.' . $current_extension === wp_basename($current_file)) {
			return new WP_Error(
				'wphave_filename_unchanged',
				__('Please enter a different file name.', 'wphave'),
				['status' => 400],
			);
		}

		return $filename . '.' . $current_extension;
	}

	/**
	 * Collect an attachment files.
	 *
	 * @param int $attachment_id
	 * @return array
	 */

	private static function collect_attachment_files($attachment_id) {
		$main_file = get_attached_file($attachment_id);
		$metadata = wp_get_attachment_metadata($attachment_id);
		$files = [];

		self::add_file_item($files, [
			'role' => 'main',
			'size' => 'full',
			'path' => $main_file,
		]);

		if (is_array($metadata) && !empty($metadata['original_image'])) {
			self::add_file_item($files, [
				'role' => 'original',
				'size' => 'original',
				'path' => trailingslashit(dirname($main_file)) . $metadata['original_image'],
			]);
		}

		if (is_array($metadata) && !empty($metadata['sizes'])) {
			foreach ($metadata['sizes'] as $size_name => $size) {
				if (empty($size['file'])) {
					continue;
				}

				self::add_file_item($files, [
					'role' => 'size',
					'size' => $size_name,
					'path' => trailingslashit(dirname($main_file)) . $size['file'],
				]);
			}
		}

		return array_values($files);
	}

	/**
	 * Add the file item.
	 *
	 * @param array $files
	 * @param array $item
	 */

	private static function add_file_item(&$files, $item) {
		$path = isset($item['path']) ? self::normalize_plan_source_path($item['path']) : '';

		if (!$path || isset($files[$path])) {
			return;
		}

		$item['path'] = $path;
		$item['file'] = wp_basename($path);
		$item['exists'] = file_exists($path);
		$files[$path] = $item;
	}

	/**
	 * Build the rename plan.
	 *
	 * @param array $files
	 * @param string $main_file
	 * @param string $new_basename
	 * @return array
	 */

	private static function build_rename_plan($files, $main_file, $new_basename) {
		$current_basename = wp_basename($main_file);
		$current_stem = pathinfo($current_basename, PATHINFO_FILENAME);
		$new_stem = pathinfo($new_basename, PATHINFO_FILENAME);

		return array_map(function ($file) use ($current_stem, $new_stem) {
			$current_file = $file['file'];
			$new_file = self::rename_derivative_file($current_file, $current_stem, $new_stem);
			$new_path = self::normalize_target_upload_path(
				trailingslashit(dirname($file['path'])) . $new_file,
			);

			return [
				'role' => $file['role'],
				'size' => $file['size'],
				'currentPath' => $file['path'],
				'newPath' => $new_path,
				'currentFile' => $current_file,
				'newFile' => $new_file,
				'exists' => $file['exists'],
				'conflict' => $new_path && $new_path !== $file['path'] && file_exists($new_path),
			];
		}, $files);
	}

	/**
	 * Remove internal paths from a rename plan response.
	 *
	 * @param array $plan
	 * @return array
	 */

	private static function sanitize_plan_for_response($plan) {
		return array_map(function ($file) {
			return [
				'role' => $file['role'],
				'size' => $file['size'],
				'currentFile' => $file['currentFile'],
				'newFile' => $file['newFile'],
				'exists' => $file['exists'],
				'conflict' => $file['conflict'],
			];
		}, $plan);
	}

	/**
	 * Validate the rename plan.
	 *
	 * @param array $plan
	 * @return true|WP_Error
	 */

	private static function validate_rename_plan($plan) {
		$targets = [];

		foreach ($plan as $file) {
			if (empty($file['currentPath']) || empty($file['newPath'])) {
				return new WP_Error(
					'wphave_rename_invalid_path',
					__(
						'One or more attachment file paths are invalid. Rename was not applied.',
						'wphave',
					),
					['status' => 409],
				);
			}

			if (
				!self::is_path_inside_uploads($file['currentPath']) ||
				!self::is_path_inside_uploads($file['newPath'])
			) {
				return new WP_Error(
					'wphave_rename_path_outside_uploads',
					__(
						'One or more attachment files are outside the upload directory. Rename was not applied.',
						'wphave',
					),
					['status' => 409],
				);
			}

			if (
				empty($file['exists']) ||
				!file_exists($file['currentPath']) ||
				!is_readable($file['currentPath']) ||
				!is_writable($file['currentPath'])
			) {
				return new WP_Error(
					'wphave_rename_missing_file',
					__(
						'One or more attachment files are missing or not writable. Rename was not applied.',
						'wphave',
					),
					['status' => 409],
				);
			}

			if (
				!is_writable(dirname($file['currentPath'])) ||
				!is_writable(dirname($file['newPath']))
			) {
				return new WP_Error(
					'wphave_rename_directory_not_writable',
					__(
						'The attachment directory is not writable. Rename was not applied.',
						'wphave',
					),
					['status' => 409],
				);
			}

			if (!empty($file['conflict'])) {
				return new WP_Error(
					'wphave_rename_conflict',
					__('One or more target files already exist. Rename was not applied.', 'wphave'),
					['status' => 409],
				);
			}

			if (
				isset($targets[$file['newPath']]) &&
				$targets[$file['newPath']] !== $file['currentPath']
			) {
				return new WP_Error(
					'wphave_rename_duplicate_target',
					__(
						'Multiple files would be renamed to the same target file. Rename was not applied.',
						'wphave',
					),
					['status' => 409],
				);
			}

			$targets[$file['newPath']] = $file['currentPath'];
		}

		return true;
	}

	/**
	 * Rename an attachment and all managed derivative files.
	 *
	 * @param int $attachment_id
	 * @param string $filename
	 * @return array|WP_Error
	 */

	private static function rename_attachment_files($attachment_id, $filename) {
		$validation = self::validate_attachment($attachment_id);

		if (is_wp_error($validation)) {
			return $validation;
		}

		$main_file = get_attached_file($attachment_id);
		$new_basename = self::prepare_new_basename($filename, $main_file);

		if (is_wp_error($new_basename)) {
			return $new_basename;
		}

		$files = self::collect_attachment_files($attachment_id);
		$plan = self::build_rename_plan($files, $main_file, $new_basename);
		$plan_validation = self::validate_rename_plan($plan);
		$old_metadata = wp_get_attachment_metadata($attachment_id);

		if (is_wp_error($plan_validation)) {
			return $plan_validation;
		}

		/**
		 * AUTHORIZATION/TOCTOU INVARIANT: Attachment metadata filters execute while
		 * the rename plan is assembled. Re-evaluate both the media capability and
		 * exact-object permission after those callbacks and immediately before the
		 * first live path mutation; route admission is not a transferable lease.
		 */
		if (!self::current_user_can_manage_attachment_file($attachment_id)) {
			return new WP_Error(
				'wphave_attachment_file_forbidden',
				__('You are not allowed to manage this media file.', 'wphave'),
				['status' => 403],
			);
		}

		$renamed = [];

		foreach ($plan as $file) {
			if ($file['currentPath'] === $file['newPath']) {
				continue;
			}

			$relocated = self::relocate_file_to_new_path($file['currentPath'], $file['newPath']);
			if (!is_array($relocated)) {
				self::rollback_renamed_files($renamed);
				return new WP_Error(
					'wphave_rename_target_changed',
					__(
						'An attachment file changed while the rename was being committed. No changes were saved.',
						'wphave',
					),
					['status' => 409],
				);
			}

			$renamed[] = array_merge($file, $relocated);
		}

		$metadata = self::update_attachment_metadata_after_rename(
			$attachment_id,
			$main_file,
			$new_basename,
			$plan,
		);

		if (is_wp_error($metadata)) {
			self::rollback_renamed_files($renamed);
			self::restore_attachment_file_state($attachment_id, $main_file, $old_metadata);
			return $metadata;
		}

		return [
			'id' => $attachment_id,
			'title' => get_the_title($attachment_id),
			'currentFile' => wp_basename($main_file),
			'newFile' => $new_basename,
			'hasConflicts' => false,
			'files' => self::sanitize_plan_for_response($plan),
		];
	}

	/**
	 * Replace an attachment file.
	 *
	 * @param int $attachment_id
	 * @param array|null $upload
	 * @return array|WP_Error
	 */

	protected static function replace_attachment_file($attachment_id, $upload) {
		$validation = self::validate_attachment($attachment_id);

		if (is_wp_error($validation)) {
			return $validation;
		}

		$upload_validation = self::validate_replacement_upload($attachment_id, $upload);

		if (is_wp_error($upload_validation)) {
			return $upload_validation;
		}

		$target_file = self::normalize_existing_upload_path(get_attached_file($attachment_id));
		$old_size = file_exists($target_file) ? filesize($target_file) : 0;
		$old_mime = get_post_mime_type($attachment_id);
		$old_metadata = wp_get_attachment_metadata($attachment_id);
		$old_files = self::collect_attachment_files($attachment_id);
		$backups = [];
		$target_validation = self::validate_replace_targets($target_file, $old_files);

		if (is_wp_error($target_validation)) {
			return $target_validation;
		}

		// SECURITY INVARIANT: Materialize the exact validated bytes beside the target
		// before touching existing files. The commit below never rereads raw upload data.
		$staged_file = self::create_backup_path($target_file);

		try {
			WPHAVE_Security_Atomic_File::copy_verified_new(
				$upload['tmp_name'],
				$staged_file,
				$upload_validation['checksum'],
				__(
					'The replacement upload changed during validation. Replace was not applied.',
					'wphave',
				),
			);
		} catch (RuntimeException $error) {
			return new WP_Error(
				'wphave_replace_upload_changed',
				__(
					'The replacement upload changed during validation. Replace was not applied.',
					'wphave',
				),
				['status' => 409],
			);
		}

		foreach ($old_files as $file) {
			if (empty($file['exists']) || !file_exists($file['path'])) {
				continue;
			}

			$backup_path = self::create_backup_path($file['path']);

			try {
				$backup_identity = WPHAVE_Security_Atomic_File::copy_observed(
					$file['path'],
					$backup_path,
					__(
						'The current attachment files could not be backed up. Replace was not applied.',
						'wphave',
					),
				);
			} catch (RuntimeException $error) {
				@unlink($staged_file);
				self::cleanup_backups($backups);
				return new WP_Error(
					'wphave_replace_backup_failed',
					__(
						'The current attachment files could not be backed up. Replace was not applied.',
						'wphave',
					),
					['status' => 500],
				);
			}

			$backups[] = [
				'path' => $file['path'],
				'backup' => $backup_path,
				'checksum' => $backup_identity['checksum'],
			];
		}

		static::before_replace_commit($attachment_id, $target_file);

		/*
		 * AUTHORIZATION/TOCTOU INVARIANT: Upload preparation, MIME filters and
		 * backup creation may execute extension code. Re-evaluate both native
		 * capabilities after those callbacks and immediately before the first
		 * live attachment byte can be removed or replaced. A revoked request owns
		 * cleanup of its checksum-bound staging and snapshots, never a live write.
		 */
		if (!self::current_user_can_manage_attachment_file($attachment_id)) {
			try {
				WPHAVE_Security_Conditional_File::remove_if_matches(
					$staged_file,
					$upload_validation['checksum'],
					__('Revoked replacement staging could not be cleaned up safely.', 'wphave'),
				);
			} catch (RuntimeException $cleanup_error) {
				// Preserve an unproven staging node for operator recovery.
			}

			self::cleanup_backups($backups);

			return new WP_Error(
				'wphave_attachment_file_forbidden',
				__('You are not allowed to manage this media file.', 'wphave'),
				['status' => 403],
			);
		}

		foreach ($old_files as $file) {
			if ($file['path'] !== $target_file && file_exists($file['path'])) {
				$backup = self::backup_for_path($backups, $file['path']);
				try {
					// SECURITY INVARIANT: Derivative cleanup consumes the exact node that
					// was snapshotted. A concurrent replacement at the same path survives.
					WPHAVE_Security_Conditional_File::remove_if_matches(
						$file['path'],
						(string) ($backup['checksum'] ?? ''),
						__(
							'An attachment derivative changed before replacement cleanup.',
							'wphave',
						),
					);
				} catch (RuntimeException $error) {
					@unlink($staged_file);
					self::restore_backups($backups, [$file['path']]);
					self::cleanup_backups($backups);
					self::restore_attachment_file_state(
						$attachment_id,
						$target_file,
						$old_metadata,
						$old_mime,
					);
					return new WP_Error(
						'wphave_replace_target_changed',
						__(
							'An attachment file changed concurrently. Replace was not applied.',
							'wphave',
						),
						['status' => 409],
					);
				}
			}
		}

		$target_backup = self::backup_for_path($backups, $target_file);
		try {
			// SECURITY INVARIANT: Replacement authority applies to the exact main-file
			// node captured in the backup, not merely to its reusable pathname.
			WPHAVE_Security_Conditional_File::replace_if_matches(
				$target_file,
				(string) ($target_backup['checksum'] ?? ''),
				$staged_file,
				$upload_validation['checksum'],
				__('The attachment main file changed before replacement commit.', 'wphave'),
			);
		} catch (RuntimeException $error) {
			// SECURITY: The main mutation was rejected, so its live path belongs to the
			// conflicting writer and must be excluded from rollback restoration.
			try {
				WPHAVE_Security_Conditional_File::remove_if_matches(
					$staged_file,
					$upload_validation['checksum'],
					__('Rejected replacement staging could not be cleaned up safely.', 'wphave'),
				);
			} catch (RuntimeException $cleanup_error) {
				// Preserve an unproven staging node for operator recovery.
			}
			self::restore_backups($backups, [$target_file]);
			self::cleanup_backups($backups);
			self::restore_attachment_file_state(
				$attachment_id,
				$target_file,
				$old_metadata,
				$old_mime,
			);
			return new WP_Error(
				'wphave_replace_target_changed',
				__(
					'The attachment main file changed concurrently. Replace was not applied.',
					'wphave',
				),
				['status' => 409],
			);
		}

		try {
			WPHAVE_Security_Conditional_File::remove_if_matches(
				$staged_file,
				$upload_validation['checksum'],
				__(
					'The committed replacement staging file could not be cleaned up safely.',
					'wphave',
				),
			);
		} catch (RuntimeException $error) {
			self::restore_backups($backups);
			self::cleanup_backups($backups);
			self::restore_attachment_file_state(
				$attachment_id,
				$target_file,
				$old_metadata,
				$old_mime,
			);
			return new WP_Error(
				'wphave_replace_failed',
				__('Replacement staging cleanup failed. No changes were saved.', 'wphave'),
				['status' => 500],
			);
		}

		$metadata = self::regenerate_replaced_attachment_metadata($attachment_id, $target_file);

		if (is_wp_error($metadata)) {
			self::restore_backups($backups);
			self::cleanup_backups($backups);
			self::restore_attachment_file_state(
				$attachment_id,
				$target_file,
				$old_metadata,
				$old_mime,
			);
			return $metadata;
		}

		$post_update = wp_update_post(
			[
				'ID' => $attachment_id,
				'post_mime_type' => $upload_validation['mime'],
			],
			true,
		);

		if (is_wp_error($post_update)) {
			self::cleanup_generated_metadata_files($target_file, $metadata, $old_files);
			self::restore_backups($backups);
			self::cleanup_backups($backups);
			self::restore_attachment_file_state(
				$attachment_id,
				$target_file,
				$old_metadata,
				$old_mime,
			);
			return new WP_Error(
				'wphave_replace_post_update_failed',
				__('The attachment record could not be updated. No changes were saved.', 'wphave'),
				['status' => 500],
			);
		}

		self::cleanup_backups($backups);
		clean_post_cache($attachment_id);
		clearstatcache(true, $target_file);

		return [
			'id' => $attachment_id,
			'title' => get_the_title($attachment_id),
			'file' => wp_basename($target_file),
			'url' => wp_get_attachment_url($attachment_id),
			'oldSize' => $old_size,
			'newSize' => file_exists($target_file) ? filesize($target_file) : 0,
			'oldMime' => $old_mime,
			'newMime' => $upload_validation['mime'],
			'metadata' => is_array($metadata) ? $metadata : [],
		];
	}

	/**
	 * Validate the replacement upload.
	 *
	 * @param int $attachment_id
	 * @param array|null $upload
	 * @return array|WP_Error
	 */

	protected static function validate_replacement_upload($attachment_id, $upload) {
		if (empty($upload) || !is_array($upload)) {
			return new WP_Error(
				'wphave_replace_missing_file',
				__('Please choose a replacement file.', 'wphave'),
				['status' => 400],
			);
		}

		if (!empty($upload['error'])) {
			return new WP_Error(
				'wphave_replace_upload_error',
				__('The replacement file could not be uploaded.', 'wphave'),
				['status' => 400],
			);
		}

		if (
			empty($upload['tmp_name']) ||
			!static::is_valid_replacement_upload_path($upload['tmp_name']) ||
			!is_readable($upload['tmp_name'])
		) {
			return new WP_Error(
				'wphave_replace_invalid_upload',
				__('The uploaded replacement file is invalid.', 'wphave'),
				['status' => 400],
			);
		}

		// SECURITY: Multipart size metadata is attacker-controlled. All limits and the
		// later mutation plan must use the actual temporary file on disk.
		try {
			$initial_identity = WPHAVE_Security_File_Identity::inspect(
				$upload['tmp_name'],
				__('The replacement upload could not be verified.', 'wphave'),
			);
		} catch (RuntimeException $error) {
			return self::attachment_operation_failure(
				'wphave_replace_upload_hash_failed',
				$error->getMessage(),
				500,
			);
		}

		$upload_size = $initial_identity['bytes'];

		$max_size = wp_max_upload_size();

		if ($max_size > 0 && $upload_size > $max_size) {
			return new WP_Error(
				'wphave_replace_upload_too_large',
				__('The replacement file exceeds the maximum upload size.', 'wphave'),
				['status' => 400],
			);
		}

		$target_file = self::normalize_existing_upload_path(get_attached_file($attachment_id));
		$current_extension = self::normalize_file_extension(
			pathinfo($target_file, PATHINFO_EXTENSION),
		);
		$upload_extension = self::normalize_file_extension(
			pathinfo($upload['name'] ?? '', PATHINFO_EXTENSION),
		);
		$current_mime = get_post_mime_type($attachment_id);

		if (!$current_mime) {
			return new WP_Error(
				'wphave_replace_missing_current_type',
				__('The current attachment media type could not be resolved.', 'wphave'),
				['status' => 400],
			);
		}

		if (!$current_extension || !$upload_extension || $current_extension !== $upload_extension) {
			return new WP_Error(
				'wphave_replace_extension_mismatch',
				__(
					'The replacement file must use the same file extension to keep the current URL stable.',
					'wphave',
				),
				['status' => 400],
			);
		}

		if (!is_writable($target_file) || !is_writable(dirname($target_file))) {
			return new WP_Error(
				'wphave_replace_target_not_writable',
				__('The current attachment file or its directory is not writable.', 'wphave'),
				['status' => 409],
			);
		}

		// SECURITY INVARIANT: Replacement bypasses WordPress upload prefilters. Apply
		// the shared SVG byte policy before computing the immutable size and hash.
		if (function_exists('wphave_prepare_special_media_upload')) {
			$prepared = wphave_prepare_special_media_upload($upload);

			if (is_wp_error($prepared)) {
				return new WP_Error('wphave_replace_invalid_type', $prepared->get_error_message(), [
					'status' => 400,
				]);
			}
		}

		$checked = wp_check_filetype_and_ext($upload['tmp_name'], $upload['name']);
		$upload_mime = $checked['type'] ?? '';

		if (!$upload_mime) {
			return new WP_Error(
				'wphave_replace_invalid_type',
				__('The replacement file type is not allowed.', 'wphave'),
				['status' => 400],
			);
		}

		if (self::get_mime_family($upload_mime) !== self::get_mime_family($current_mime)) {
			return new WP_Error(
				'wphave_replace_mime_mismatch',
				__(
					'The replacement file must be the same media type as the current attachment.',
					'wphave',
				),
				['status' => 400],
			);
		}

		try {
			// SECURITY INVARIANT: Special-media sanitization is an authorized byte
			// transformation. Only the coherent post-transformation revision may grant
			// staging and commit authority; the initial identity enforces limits only.
			$upload_identity = WPHAVE_Security_File_Identity::inspect(
				$upload['tmp_name'],
				__('The prepared replacement upload could not be verified.', 'wphave'),
			);
		} catch (RuntimeException $error) {
			return self::attachment_operation_failure(
				'wphave_replace_upload_hash_failed',
				$error->getMessage(),
				500,
			);
		}

		$upload_size = $upload_identity['bytes'];
		if ($upload_size < 1) {
			return new WP_Error(
				'wphave_replace_empty_upload',
				__('The replacement file is empty.', 'wphave'),
				['status' => 400],
			);
		}
		if ($max_size > 0 && $upload_size > $max_size) {
			return new WP_Error(
				'wphave_replace_upload_too_large',
				__('The prepared replacement file exceeds the maximum upload size.', 'wphave'),
				['status' => 400],
			);
		}

		return [
			'mime' => $upload_mime,
			'bytes' => $upload_size,
			// SECURITY INVARIANT: This fingerprint binds validation to the staged bytes
			// that are later committed, closing upload-path TOCTOU and metadata drift.
			'checksum' => $upload_identity['checksum'],
		];
	}

	/**
	 * Map an internal attachment-mutation failure onto its public REST contract.
	 *
	 * SECURITY INVARIANT: Upload identity and filesystem exceptions may contain
	 * temporary paths, filenames or personal identifiers. Mutation endpoints
	 * expose those details only through the central diagnostic redactor.
	 */

	protected static function attachment_operation_failure(
		string $code,
		string $message,
		int $status,
	): WP_Error {
		return new WP_Error(sanitize_key($code), WPHAVE_Security_Redactor::error_text($message), [
			'status' => $status,
		]);
	}

	/** Testable boundary immediately before checksum-conditional live mutation. */

	protected static function before_replace_commit($attachment_id, $target_file) {
		// Intentionally empty. Subclasses may instrument the cross-phase boundary.
	}

	/**
	 * Verify that replacement bytes originate from the current HTTP upload request.
	 */

	protected static function is_valid_replacement_upload_path($path) {
		return is_uploaded_file($path);
	}

	/**
	 * Validate the replace targets.
	 *
	 * @param string $target_file
	 * @param array $old_files
	 * @return true|WP_Error
	 */

	private static function validate_replace_targets($target_file, $old_files) {
		if (!$target_file || !self::is_path_inside_uploads($target_file)) {
			return new WP_Error(
				'wphave_replace_invalid_target',
				__('The current attachment file path is invalid.', 'wphave'),
				['status' => 409],
			);
		}

		if (
			!file_exists($target_file) ||
			!is_readable($target_file) ||
			!is_writable($target_file) ||
			!is_writable(dirname($target_file))
		) {
			return new WP_Error(
				'wphave_replace_target_not_writable',
				__('The current attachment file or its directory is not writable.', 'wphave'),
				['status' => 409],
			);
		}

		foreach ($old_files as $file) {
			if (empty($file['path']) || !self::is_path_inside_uploads($file['path'])) {
				return new WP_Error(
					'wphave_replace_invalid_derivative',
					__('One or more generated attachment file paths are invalid.', 'wphave'),
					['status' => 409],
				);
			}

			if (empty($file['exists'])) {
				continue;
			}

			if (
				!file_exists($file['path']) ||
				!is_readable($file['path']) ||
				!is_writable($file['path']) ||
				!is_writable(dirname($file['path']))
			) {
				return new WP_Error(
					'wphave_replace_derivative_not_writable',
					__('One or more generated attachment files are not writable.', 'wphave'),
					['status' => 409],
				);
			}
		}

		return true;
	}

	/**
	 * Regenerate metadata after replacing an attachment file.
	 *
	 * @param int $attachment_id
	 * @param string $target_file
	 * @return array|true|WP_Error
	 */

	private static function regenerate_replaced_attachment_metadata($attachment_id, $target_file) {
		if (!wp_attachment_is_image($attachment_id)) {
			wp_update_attachment_metadata($attachment_id, []);
			return true;
		}

		require_once ABSPATH . 'wp-admin/includes/image.php';

		add_filter('big_image_size_threshold', '__return_false', 99);
		$metadata = wp_generate_attachment_metadata($attachment_id, $target_file);
		remove_filter('big_image_size_threshold', '__return_false', 99);

		if (!is_array($metadata)) {
			return new WP_Error(
				'wphave_replace_metadata_failed',
				__('The replacement image metadata could not be generated.', 'wphave'),
				['status' => 500],
			);
		}

		$relative_path = self::get_relative_upload_path($target_file);

		if ($relative_path) {
			$metadata['file'] = $relative_path;
		}

		unset($metadata['original_image']);

		// WordPress may already persist this metadata while generating subsizes.
		// Its update API also returns false for unchanged values; verify the
		// canonical postcondition before treating that result as a failed write.
		wp_update_attachment_metadata($attachment_id, $metadata);
		if (get_post_meta($attachment_id, '_wp_attachment_metadata', true) !== $metadata) {
			return new WP_Error(
				'wphave_replace_metadata_failed',
				__('The replacement image metadata could not be saved.', 'wphave'),
				['status' => 500],
			);
		}

		return $metadata;
	}

	/**
	 * Update an attachment metadata after rename.
	 *
	 * @param int $attachment_id
	 * @param string $main_file
	 * @param string $new_basename
	 * @param array $plan
	 * @return array|true|WP_Error
	 */

	private static function update_attachment_metadata_after_rename(
		$attachment_id,
		$main_file,
		$new_basename,
		$plan,
	) {
		$metadata = wp_get_attachment_metadata($attachment_id);
		$upload_dir = wp_get_upload_dir();
		$new_main_path = trailingslashit(dirname($main_file)) . $new_basename;

		if (empty($upload_dir['basedir'])) {
			return new WP_Error(
				'wphave_rename_metadata_failed',
				__('Attachment metadata could not be updated.', 'wphave'),
				['status' => 500],
			);
		}

		$new_relative_path = self::get_relative_upload_path($new_main_path);

		if (!$new_relative_path) {
			return new WP_Error(
				'wphave_rename_metadata_failed',
				__('Attachment metadata could not be updated.', 'wphave'),
				['status' => 500],
			);
		}

		if (!update_attached_file($attachment_id, $new_relative_path)) {
			return new WP_Error(
				'wphave_rename_metadata_failed',
				__('Attachment file metadata could not be updated.', 'wphave'),
				['status' => 500],
			);
		}

		if (!is_array($metadata)) {
			return true;
		}

		$metadata['file'] = $new_relative_path;

		foreach ($plan as $file) {
			if ($file['role'] === 'original') {
				$metadata['original_image'] = $file['newFile'];
			}

			if ($file['role'] === 'size' && isset($metadata['sizes'][$file['size']])) {
				$metadata['sizes'][$file['size']]['file'] = $file['newFile'];
			}
		}

		$updated = wp_update_attachment_metadata($attachment_id, $metadata);

		if (!$updated) {
			return new WP_Error(
				'wphave_rename_metadata_failed',
				__('Attachment metadata could not be updated.', 'wphave'),
				['status' => 500],
			);
		}

		return $metadata;
	}
}
