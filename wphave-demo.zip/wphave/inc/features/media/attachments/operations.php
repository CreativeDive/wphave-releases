<?php

require_once dirname(__DIR__) . '/images/size-file-identity.php';
require_once dirname(__DIR__) . '/images/backup-budget.php';
require_once __DIR__ . '/file-registration.php';

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Attachment_File_Operations {
	private const MAX_REPLACEMENT_BYTES = 1073741824;
	/**
	 * Validate an attachment.
	 *
	 * @param int $attachment_id
	 * @return true|WP_Error
	 */

	private static function validate_attachment($attachment_id) {
		$post = get_post($attachment_id);

		if (!$post || $post->post_type !== 'attachment') {
			return new WP_Error(
				'wphave_invalid_attachment',
				__('The requested attachment could not be found.', 'wphave'),
				['status' => 404],
			);
		}

		// SOURCE INVARIANT: Destructive file operations use the raw attachment
		// registration. A get_attached_file filter cannot redirect the target.
		$file = get_attached_file($attachment_id, true);

		if (!$file || !file_exists($file) || !is_readable($file)) {
			return new WP_Error(
				'wphave_attachment_file_missing',
				__('The attachment file could not be found or is not readable.', 'wphave'),
				['status' => 400],
			);
		}

		$canonical_file = self::normalize_existing_upload_path($file);
		if (!$canonical_file) {
			return new WP_Error(
				'wphave_attachment_file_outside_uploads',
				__('The attachment file is outside the WordPress upload directory.', 'wphave'),
				['status' => 400],
			);
		}
		// OWNERSHIP INVARIANT: Edit permission on this attachment cannot grant
		// authority over another attachment's registered main file, including
		// a same-directory symlink alias that resolves to that file.
		if (self::is_registered_other_attachment_file($canonical_file, (int) $attachment_id)) {
			return new WP_Error(
				'wphave_attachment_file_shared',
				__('The attachment file is registered to another media item.', 'wphave'),
				['status' => 409],
			);
		}

		return true;
	}

	/**
	 * Prepare the new basename.
	 *
	 * @param string $filename
	 * @param string $current_file
	 * @return string|WP_Error
	 */

	private static function prepare_new_basename($filename, $current_file) {
		// FILENAME INVARIANT: An attachment rename may not send unbounded input
		// through transliteration, sanitizers or a filesystem name allocation.
		if (!is_string($filename) || strlen($filename) > 200) {
			return new WP_Error(
				'wphave_invalid_filename',
				__('Please enter a shorter file name.', 'wphave'),
				['status' => 400],
			);
		}

		$current_extension = strtolower(pathinfo($current_file, PATHINFO_EXTENSION));
		$filename = sanitize_file_name(remove_accents($filename));
		$filename = preg_replace('/\.[a-z0-9]{2,5}$/i', '', $filename);
		$filename = preg_replace('/[^a-z0-9_-]/', '-', strtolower($filename));
		$filename = preg_replace('/-+/', '-', $filename);
		$filename = trim($filename, '-_');

		if (!$filename) {
			return new WP_Error(
				'wphave_invalid_filename',
				__('Please enter a valid file name.', 'wphave'),
				['status' => 400],
			);
		}

		if (!$current_extension) {
			return new WP_Error(
				'wphave_missing_file_extension',
				__('The current attachment file has no file extension.', 'wphave'),
				['status' => 400],
			);
		}

		if ($filename . '.' . $current_extension === wp_basename($current_file)) {
			return new WP_Error(
				'wphave_filename_unchanged',
				__('Please enter a different file name.', 'wphave'),
				['status' => 400],
			);
		}

		return $filename . '.' . $current_extension;
	}

	/**
	 * Collect an attachment files.
	 *
	 * @param int $attachment_id
	 * @return array
	 */

	private static function collect_attachment_files($attachment_id) {
		$main_file = get_attached_file($attachment_id, true);
		// FILE-PLAN INVARIANT: Display filters on attachment metadata cannot
		// grant ownership of extra files to a destructive rename or replace.
		$metadata = get_post_meta($attachment_id, '_wp_attachment_metadata', true);
		// FILE-PLAN INVARIANT: A truncated derivative plan is unsafe for rename,
		// replacement and rollback. Reject oversized inventories before planning.
		if (
			is_array($metadata) &&
			isset($metadata['sizes']) &&
			(!is_array($metadata['sizes']) || count($metadata['sizes']) > 128)
		) {
			return new WP_Error(
				'wphave_attachment_sizes_invalid',
				__('The stored image size inventory is invalid or too large.', 'wphave'),
				['status' => 400],
			);
		}
		$files = [];
		$main_stem = pathinfo((string) $main_file, PATHINFO_FILENAME);
		$base_stem = preg_replace('/-(?:scaled|rotated)$/', '', $main_stem);

		self::add_file_item($files, [
			'role' => 'main',
			'size' => 'full',
			'path' => $main_file,
		]);

		if (
			is_array($metadata) &&
			is_string($metadata['original_image'] ?? null) &&
			self::is_safe_attachment_metadata_basename($metadata['original_image']) &&
			$base_stem !== $main_stem &&
			pathinfo($metadata['original_image'], PATHINFO_FILENAME) === $base_stem &&
			!self::is_registered_other_attachment_file(
				trailingslashit(dirname($main_file)) . $metadata['original_image'],
				$attachment_id,
			)
		) {
			// OWNERSHIP INVARIANT: Only WordPress's original of a scaled or
			// rotated source can be included in a destructive file plan.
			self::add_file_item($files, [
				'role' => 'original',
				'size' => 'original',
				'path' => trailingslashit(dirname($main_file)) . $metadata['original_image'],
			]);
		}

		if (is_array($metadata) && !empty($metadata['sizes'])) {
			foreach ($metadata['sizes'] as $size_name => $size) {
				if (
					!is_array($size) ||
					!is_string($size['file'] ?? null) ||
					!self::is_safe_attachment_metadata_basename($size['file']) ||
					!is_numeric($size['width'] ?? null) ||
					!is_numeric($size['height'] ?? null)
				) {
					continue;
				}
				// OWNERSHIP INVARIANT: Metadata is mutable plugin data, not a file
				// capability. A derivative must bear this source's stem and exact
				// generated dimensions before it enters rename or replace plans.
				if (
					!WPHAVE_Media_Image_Size_File_Identity::matches_generated_size(
						$main_file,
						$size,
					)
				) {
					continue;
				}
				$candidate = trailingslashit(dirname($main_file)) . $size['file'];
				if (
					file_exists($candidate) &&
					self::is_registered_other_attachment_file($candidate, $attachment_id)
				) {
					continue;
				}

				self::add_file_item($files, [
					'role' => 'size',
					'size' => $size_name,
					'path' => $candidate,
				]);
			}
		}

		return array_values($files);
	}

	/** Metadata filenames may name only local, single-component regular files. */
	private static function is_safe_attachment_metadata_basename(string $filename): bool {
		return WPHAVE_Media_Image_Size_File_Identity::is_safe_basename($filename);
	}

	/** A derivative path cannot be the registered main file of another item. */
	private static function is_registered_other_attachment_file(
		string $path,
		int $attachment_id,
	): bool {
		$relative = self::get_relative_upload_path($path);
		if ($relative === '') {
			return true;
		}
		return WPHAVE_Attachment_File_Registration::has_other_owner(
			$relative,
			$path,
			$attachment_id,
		);
	}

	/** Recheck the attachment-to-file binding after filterable planning work. */
	private static function attachment_source_still_registered(
		int $attachment_id,
		string $source,
		string $mime,
	): bool {
		$post = get_post($attachment_id);
		$relative = self::get_relative_upload_path($source);
		// BINDING INVARIANT: Permission on an attachment ID does not authorize
		// mutation of a captured path after a callback rebinds that ID.
		return $post &&
			$post->post_type === 'attachment' &&
			$post->post_mime_type === $mime &&
			$relative !== '' &&
			get_post_meta($attachment_id, '_wp_attached_file', true) === $relative &&
			!self::is_registered_other_attachment_file($source, $attachment_id);
	}

	/**
	 * Add the file item.
	 *
	 * @param array $files
	 * @param array $item
	 */

	private static function add_file_item(&$files, $item) {
		$path = isset($item['path']) ? self::normalize_plan_source_path($item['path']) : '';

		if (!$path || isset($files[$path])) {
			return;
		}

		$item['path'] = $path;
		$item['file'] = wp_basename($path);
		$item['exists'] = file_exists($path);
		$files[$path] = $item;
	}

	/**
	 * Build the rename plan.
	 *
	 * @param array $files
	 * @param string $main_file
	 * @param string $new_basename
	 * @return array
	 */

	private static function build_rename_plan($files, $main_file, $new_basename, int $attachment_id) {
		$current_basename = wp_basename($main_file);
		$current_stem = pathinfo($current_basename, PATHINFO_FILENAME);
		$new_stem = pathinfo($new_basename, PATHINFO_FILENAME);

		return array_map(function ($file) use ($current_stem, $new_stem, $attachment_id) {
			$current_file = $file['file'];
			$new_file = self::rename_derivative_file($current_file, $current_stem, $new_stem);
			$new_path = self::normalize_target_upload_path(
				trailingslashit(dirname($file['path'])) . $new_file,
			);

			// OWNERSHIP INVARIANT: A missing target can still be registered to
			// another attachment. Preview and commit must report that reservation
			// as the same conflict before any source file is moved.
			$conflict = $new_path && $new_path !== $file['path'] && (
				file_exists($new_path) ||
				self::is_registered_other_attachment_file($new_path, $attachment_id)
			);

			return [
				'role' => $file['role'],
				'size' => $file['size'],
				'currentPath' => $file['path'],
				'newPath' => $new_path,
				'currentFile' => $current_file,
				'newFile' => $new_file,
				'exists' => $file['exists'],
				'conflict' => $conflict,
			];
		}, $files);
	}

	/** Every stored filename rewritten by rename must belong to its file plan. */
	private static function validate_rename_metadata_coverage($metadata, array $plan): true|WP_Error {
		if (!is_array($metadata)) {
			return true;
		}
		if (isset($metadata['sizes']) && !is_array($metadata['sizes'])) {
			return new WP_Error(
				'wphave_rename_incomplete_file_plan',
				__('Stored image sizes cannot be renamed safely. Repair the media metadata first.', 'wphave'),
				['status' => 409],
			);
		}

		$planned_size_files = [];
		$planned_original = null;
		foreach ($plan as $file) {
			if ($file['role'] === 'size') {
				$planned_size_files[$file['currentFile']] = true;
			} elseif ($file['role'] === 'original') {
				$planned_original = $file['currentFile'];
			}
		}

		foreach (($metadata['sizes'] ?? []) as $size) {
			if (
				!is_array($size) ||
				!is_string($size['file'] ?? null) ||
				!isset($planned_size_files[$size['file']])
			) {
				return new WP_Error(
					'wphave_rename_incomplete_file_plan',
					__('Stored image sizes cannot be renamed safely. Repair the media metadata first.', 'wphave'),
					['status' => 409],
				);
			}
		}

		if (
			isset($metadata['original_image']) &&
			$metadata['original_image'] !== $planned_original
		) {
			return new WP_Error(
				'wphave_rename_incomplete_file_plan',
				__('The original image cannot be renamed safely. Repair the media metadata first.', 'wphave'),
				['status' => 409],
			);
		}

		return true;
	}

	/** One physical derivative may be registered under several image-size names. */
	private static function rewrite_renamed_size_aliases(array $metadata, array $renamed_size_files): array {
		if (!isset($metadata['sizes']) || !is_array($metadata['sizes'])) {
			return $metadata;
		}

		// FILE-ALIAS INVARIANT: Move a shared derivative once and update every
		// metadata entry pointing to its old filename, regardless of size name.
		foreach ($metadata['sizes'] as &$size) {
			if (is_array($size) && isset($renamed_size_files[$size['file'] ?? ''])) {
				$size['file'] = $renamed_size_files[$size['file']];
			}
		}
		unset($size);

		return $metadata;
	}

	/**
	 * Remove internal paths from a rename plan response.
	 *
	 * @param array $plan
	 * @return array
	 */

	private static function sanitize_plan_for_response($plan) {
		return array_map(function ($file) {
			return [
				'role' => $file['role'],
				'size' => $file['size'],
				'currentFile' => $file['currentFile'],
				'newFile' => $file['newFile'],
				'exists' => $file['exists'],
				'conflict' => $file['conflict'],
			];
		}, $plan);
	}

	/**
	 * Validate the rename plan.
	 *
	 * @param array $plan
	 * @return true|WP_Error
	 */

	private static function validate_rename_plan($plan) {
		$targets = [];

		foreach ($plan as $file) {
			if (empty($file['currentPath']) || empty($file['newPath'])) {
				return new WP_Error(
					'wphave_rename_invalid_path',
					__(
						'One or more attachment file paths are invalid. Rename was not applied.',
						'wphave',
					),
					['status' => 409],
				);
			}

			if (
				!self::is_path_inside_uploads($file['currentPath']) ||
				!self::is_path_inside_uploads($file['newPath'])
			) {
				return new WP_Error(
					'wphave_rename_path_outside_uploads',
					__(
						'One or more attachment files are outside the upload directory. Rename was not applied.',
						'wphave',
					),
					['status' => 409],
				);
			}

			if (
				empty($file['exists']) ||
				!file_exists($file['currentPath']) ||
				!is_readable($file['currentPath']) ||
				!is_writable($file['currentPath'])
			) {
				return new WP_Error(
					'wphave_rename_missing_file',
					__(
						'One or more attachment files are missing or not writable. Rename was not applied.',
						'wphave',
					),
					['status' => 409],
				);
			}

			if (
				!is_writable(dirname($file['currentPath'])) ||
				!is_writable(dirname($file['newPath']))
			) {
				return new WP_Error(
					'wphave_rename_directory_not_writable',
					__(
						'The attachment directory is not writable. Rename was not applied.',
						'wphave',
					),
					['status' => 409],
				);
			}

			if (!empty($file['conflict'])) {
				return new WP_Error(
					'wphave_rename_conflict',
					__('One or more target files already exist. Rename was not applied.', 'wphave'),
					['status' => 409],
				);
			}

			if (
				isset($targets[$file['newPath']]) &&
				$targets[$file['newPath']] !== $file['currentPath']
			) {
				return new WP_Error(
					'wphave_rename_duplicate_target',
					__(
						'Multiple files would be renamed to the same target file. Rename was not applied.',
						'wphave',
					),
					['status' => 409],
				);
			}

			$targets[$file['newPath']] = $file['currentPath'];
		}

		return true;
	}

	/**
	 * Rename an attachment and all managed derivative files.
	 *
	 * @param int $attachment_id
	 * @param string $filename
	 * @return array|WP_Error
	 */

	private static function rename_attachment_files($attachment_id, $filename, bool $replace_content = false) {
		// AUTHORIZATION INVARIANT: Direct service calls must not inspect attachment
		// files or build a rename/content plan before object-level authorization.
		if (!self::current_user_can_manage_attachment_file($attachment_id)) {
			return new WP_Error(
				'wphave_attachment_file_forbidden',
				__('You are not allowed to manage this media file.', 'wphave'),
				['status' => 403],
			);
		}
		// SERVICE POLICY: REST admission is not the only caller of this method.
		// Disabled file actions cannot be revived through an internal call.
		if (!self::is_file_action_allowed('rename')) {
			return new WP_Error('wphave_media_file_action_disabled', __('This file action is disabled in Media Settings.', 'wphave'), ['status' => 403]);
		}

		$validation = self::validate_attachment($attachment_id);

		if (is_wp_error($validation)) {
			return $validation;
		}

		$main_file = get_attached_file($attachment_id, true);
		$source_mime = (string) get_post_mime_type($attachment_id);
		$new_basename = self::prepare_new_basename($filename, $main_file);

		if (is_wp_error($new_basename)) {
			return $new_basename;
		}

		$files = self::collect_attachment_files($attachment_id);
		if (is_wp_error($files)) {
			return $files;
		}
		$plan = self::build_rename_plan($files, $main_file, $new_basename, (int) $attachment_id);
		$old_metadata = get_post_meta($attachment_id, '_wp_attachment_metadata', true);
		$coverage = self::validate_rename_metadata_coverage($old_metadata, $plan);
		if (is_wp_error($coverage)) {
			return $coverage;
		}
		$plan_validation = self::validate_rename_plan($plan);

		if (is_wp_error($plan_validation)) {
			return $plan_validation;
		}
		// CONTENT-PLAN INVARIANT: Optional post URL replacements must describe
		// precisely the file plan this transaction is about to commit.
		$content_replacements = [];
		if ($replace_content) {
			$content_replacements = self::build_url_replacements_from_plan($plan);
			if (is_wp_error($content_replacements)) {
				return $content_replacements;
			}
		}

		/**
		 * AUTHORIZATION/TOCTOU INVARIANT: Attachment metadata filters execute while
		 * the rename plan is assembled. Re-evaluate both the media capability and
		 * exact-object permission after those callbacks and immediately before the
		 * first live path mutation; route admission is not a transferable lease.
		 */
		if (!self::current_user_can_manage_attachment_file($attachment_id)) {
			return new WP_Error(
				'wphave_attachment_file_forbidden',
				__('You are not allowed to manage this media file.', 'wphave'),
				['status' => 403],
			);
		}
		// POLICY INVARIANT: Planning hooks can change site settings. A disabled
		// Rename action cannot proceed to its first live relocation.
		if (!self::is_file_action_allowed('rename')) {
			return new WP_Error('wphave_media_file_action_disabled', __('This file action is disabled in Media Settings.', 'wphave'), ['status' => 403]);
		}
		if (
			!self::attachment_source_still_registered(
				(int) $attachment_id,
				$main_file,
				$source_mime,
			)
		) {
			return new WP_Error(
				'wphave_rename_source_changed',
				__('The attachment file changed while renaming it. Reload it before saving.', 'wphave'),
				['status' => 409],
			);
		}
		// METADATA-REVISION INVARIANT: A callback may replace the stored size
		// inventory after the file plan was built. Never move the planned files
		// while another revision is already authoritative for this attachment.
		if (get_post_meta($attachment_id, '_wp_attachment_metadata', true) !== $old_metadata) {
			return new WP_Error(
				'wphave_rename_metadata_changed',
				__('The attachment metadata changed while renaming it. Reload before saving.', 'wphave'),
				['status' => 409],
			);
		}

		$renamed = [];

		foreach ($plan as $file) {
			if ($file['currentPath'] === $file['newPath']) {
				continue;
			}
			// OWNERSHIP INVARIANT: An absent destination may still be registered to
			// another attachment, and a planned derivative may change owner after
			// metadata filters run. Neither path may be relocated in that state.
			if (
				self::is_registered_other_attachment_file($file['currentPath'], (int) $attachment_id) ||
				self::is_registered_other_attachment_file($file['newPath'], (int) $attachment_id)
			) {
				$recovery = self::rollback_renamed_files($renamed, (int) $attachment_id);
				if (is_wp_error($recovery)) {
					return $recovery;
				}
				return new WP_Error(
					'wphave_rename_file_reassigned',
					__('An attachment file changed ownership while renaming it. Reload before saving.', 'wphave'),
					['status' => 409],
				);
			}

			$relocated = self::relocate_file_to_new_path($file['currentPath'], $file['newPath']);
			if (!is_array($relocated)) {
				$recovery = self::rollback_renamed_files($renamed, (int) $attachment_id);
				if (is_wp_error($recovery)) {
					return $recovery;
				}
				return new WP_Error(
					'wphave_rename_target_changed',
					__(
						'An attachment file changed while the rename was being committed. No changes were saved.',
						'wphave',
					),
					['status' => 409],
				);
			}

			$renamed[] = array_merge($file, $relocated);
		}

		try {
			$metadata = self::update_attachment_metadata_after_rename(
				$attachment_id,
				$main_file,
				$new_basename,
				$plan,
				$old_metadata,
			);
		} catch (Throwable $error) {
			// TRANSACTION INVARIANT: Metadata hooks run after file relocation.
			// Their exceptions must enter the same file and record rollback.
			$metadata = new WP_Error(
				'wphave_rename_metadata_failed',
				__('Attachment metadata could not be updated.', 'wphave'),
				['status' => 500],
			);
		}

		if (is_wp_error($metadata)) {
			$recovery = self::rollback_renamed_files($renamed, (int) $attachment_id);
			if (is_wp_error($recovery)) {
				return $recovery;
			}
			// The metadata-drift check runs before update_attached_file(). Once
			// files are restored, preserve the other writer's metadata revision.
			if ($metadata->get_error_code() === 'wphave_rename_metadata_changed') {
				return self::attachment_source_still_registered(
					(int) $attachment_id,
					$main_file,
					$source_mime,
				)
					? $metadata
					: self::replacement_record_recovery_required();
			}
			$new_main_path = trailingslashit(dirname($main_file)) . $new_basename;
			$record_recovery = self::restore_renamed_attachment_record(
				(int) $attachment_id,
				$main_file,
				$new_main_path,
				$old_metadata,
				$source_mime,
			);
			if (is_wp_error($record_recovery)) {
				return $record_recovery;
			}
			return $metadata;
		}
		$new_main_path = trailingslashit(dirname($main_file)) . $new_basename;
		$expected_metadata = is_array($metadata) ? $metadata : $old_metadata;
		if (
			!self::current_user_can_manage_attachment_file($attachment_id) ||
			get_post_meta($attachment_id, '_wp_attachment_metadata', true) !== $expected_metadata ||
			!self::attachment_source_still_registered((int) $attachment_id, $new_main_path, $source_mime)
		) {
			// RECORD INVARIANT: Metadata hooks can revoke permission or rewrite the
			// record while preserving its main file binding. File rollback alone
			// cannot reconcile a foreign revision.
			$recovery = self::rollback_renamed_files($renamed, (int) $attachment_id);
			if (is_wp_error($recovery)) {
				return $recovery;
			}
			// RECOVERY INVARIANT: Metadata may already point to the renamed files.
			// A hook-owned rebind forbids restoring the record automatically, so
			// rolling back file names alone cannot be reported as a clean conflict.
			return self::replacement_record_recovery_required();
		}

		// RESPONSE INVARIANT: Title filters can run after the metadata commit.
		// Resolve them before declaring the renamed attachment successful.
		try {
			$title = get_the_title($attachment_id);
		} catch (Throwable $error) {
			// RESPONSE INVARIANT: Title presentation cannot undo a committed rename.
			// The client may reload the renamed record when the filter recovers.
			$title = null;
		}
		if (
			!self::current_user_can_manage_attachment_file($attachment_id) ||
			get_post_meta($attachment_id, '_wp_attachment_metadata', true) !== $expected_metadata ||
			!self::attachment_source_still_registered((int) $attachment_id, $new_main_path, $source_mime)
		) {
			// FINALIZATION INVARIANT: A title hook can mutate the record after the
			// metadata check. Never return success for that mixed revision.
			$recovery = self::rollback_renamed_files($renamed, (int) $attachment_id);
			return is_wp_error($recovery)
				? $recovery
				: self::replacement_record_recovery_required();
		}
		return [
			'id' => $attachment_id,
			'title' => $title,
			'currentFile' => wp_basename($main_file),
			'newFile' => $new_basename,
			'hasConflicts' => false,
			'files' => self::sanitize_plan_for_response($plan),
			// Internal to the REST facade; never return this map to the client.
			'_contentReplacements' => $content_replacements,
		];
	}

	/**
	 * Replace an attachment file.
	 *
	 * @param int $attachment_id
	 * @param array|null $upload
	 * @return array|WP_Error
	 */

	protected static function replace_attachment_file($attachment_id, $upload) {
		// AUTHORIZATION INVARIANT: Direct service callers must pass the object-level
		// gate before reading the source or staging any replacement and backup bytes.
		if (!self::current_user_can_manage_attachment_file($attachment_id)) {
			return new WP_Error(
				'wphave_attachment_file_forbidden',
				__('You are not allowed to manage this media file.', 'wphave'),
				['status' => 403],
			);
		}

		// ENTITLEMENT INVARIANT: UI gating is advisory. Direct service callers
		// must have a verified local Pro grant before source or upload inspection.
		if (!function_exists('wphave_has_pro_access') || !wphave_has_pro_access()) {
			return new WP_Error(
				'wphave_replace_file_pro_required',
				__('Replace File requires Pro access.', 'wphave'),
				['status' => 403],
			);
		}
		// SERVICE POLICY: The Pro grant does not override the site's Replace
		// action setting when this service is called without REST dispatch.
		if (!self::is_file_action_allowed('replace')) {
			return new WP_Error('wphave_media_file_action_disabled', __('This file action is disabled in Media Settings.', 'wphave'), ['status' => 403]);
		}

		$validation = self::validate_attachment($attachment_id);

		if (is_wp_error($validation)) {
			return $validation;
		}

		$upload_validation = self::validate_replacement_upload($attachment_id, $upload);

		if (is_wp_error($upload_validation)) {
			return $upload_validation;
		}

		$target_file = self::normalize_existing_upload_path(get_attached_file($attachment_id, true));
		$old_size = file_exists($target_file) ? filesize($target_file) : 0;
		$old_mime = get_post_mime_type($attachment_id);
		$old_metadata = get_post_meta($attachment_id, '_wp_attachment_metadata', true);
		$old_files = self::collect_attachment_files($attachment_id);
		if (is_wp_error($old_files)) {
			return $old_files;
		}
		$backups = [];
		// RECOVERY INVARIANT: Only completed mutations grant rollback authority.
		$mutations = [];
		$target_validation = self::validate_replace_targets($target_file, $old_files);

		if (is_wp_error($target_validation)) {
			return $target_validation;
		}

		// SECURITY INVARIANT: Materialize the exact validated bytes beside the target
		// before touching existing files. The commit below never rereads raw upload data.
		$staged_file = self::create_backup_path($target_file);

		try {
			WPHAVE_Security_Atomic_File::copy_verified_new(
				$upload['tmp_name'],
				$staged_file,
				$upload_validation['checksum'],
				__(
					'The replacement upload changed during validation. Replace was not applied.',
					'wphave',
				),
				0600,
				null,
				$upload_validation['maxBytes'],
			);
		} catch (RuntimeException $error) {
			return new WP_Error(
				'wphave_replace_upload_changed',
				__(
					'The replacement upload changed during validation. Replace was not applied.',
					'wphave',
				),
				['status' => 409],
			);
		}

		if ($upload_validation['convert']) {
			$converted = self::convert_replacement_stage(
				$staged_file,
				$upload_validation['checksum'],
				$upload_validation['sourceMime'],
				$old_mime,
			);
			if (is_wp_error($converted)) {
				self::cleanup_replacement_stage($staged_file, $upload_validation['checksum']);
				return $converted;
			}
			$staged_file = $converted['path'];
			$upload_validation['checksum'] = $converted['checksum'];
			$upload_validation['bytes'] = $converted['bytes'];
		}

		$image_backup_budget = in_array($old_mime, self::image_editor_supported_mimes(), true)
			? new WPHAVE_Media_Image_Backup_Budget()
			: null;
		foreach ($old_files as $file) {
			if (empty($file['exists']) || !file_exists($file['path'])) {
				continue;
			}

			$backup_path = self::create_backup_path($file['path']);

			try {
				$backup_identity = WPHAVE_Security_Atomic_File::copy_observed(
					$file['path'],
					$backup_path,
					__(
						'The current attachment files could not be backed up. Replace was not applied.',
						'wphave',
					),
					$image_backup_budget?->next_limit(),
				);
			} catch (RuntimeException $error) {
				self::cleanup_replacement_stage($staged_file, $upload_validation['checksum']);
				self::cleanup_backups($backups);
				return new WP_Error(
					'wphave_replace_backup_failed',
					__(
						'The current attachment files could not be backed up. Replace was not applied.',
						'wphave',
					),
					['status' => 500],
				);
			}
			// RESOURCE INVARIANT: Raster replacements share the editor's finite
			// backup budget, while non-image files keep their own size contract.
			$image_backup_budget?->consume($backup_identity['bytes']);

			$backups[] = [
				'path' => $file['path'],
				'backup' => $backup_path,
				'checksum' => $backup_identity['checksum'],
				'bytes' => $backup_identity['bytes'],
				// RECOVERY INVARIANT: Capture live mode and group before private backup storage.
				'permissions' => $backup_identity['permissions'],
				'group' => $backup_identity['group'],
			];
		}

		try {
			static::before_replace_commit($attachment_id, $target_file);
		} catch (Throwable $error) {
			// PRECOMMIT INVARIANT: A throwing extension boundary has not touched live
			// files. Release only checksum-owned staging and snapshots before returning.
			self::cleanup_replacement_stage($staged_file, $upload_validation['checksum']);
			self::cleanup_backups($backups);
			return new WP_Error(
				'wphave_replace_precommit_failed',
				__('Replacement preparation failed. No changes were saved.', 'wphave'),
				['status' => 500],
			);
		}

		/*
		 * AUTHORIZATION/TOCTOU INVARIANT: Upload preparation, MIME filters and
		 * backup creation may execute extension code. Re-evaluate both native
		 * capabilities after those callbacks and immediately before the first
		 * live attachment byte can be removed or replaced. A revoked request owns
		 * cleanup of its checksum-bound staging and snapshots, never a live write.
		 */
		if (
			!self::current_user_can_manage_attachment_file($attachment_id) ||
			!function_exists('wphave_has_pro_access') ||
			!wphave_has_pro_access() ||
			!self::is_file_action_allowed('replace')
		) {
			try {
				WPHAVE_Security_Conditional_File::remove_if_matches(
					$staged_file,
					$upload_validation['checksum'],
					__('Revoked replacement staging could not be cleaned up safely.', 'wphave'),
					self::MAX_REPLACEMENT_BYTES,
				);
			} catch (RuntimeException $cleanup_error) {
				// Preserve an unproven staging node for operator recovery.
			}

			self::cleanup_backups($backups);

			return new WP_Error(
				'wphave_attachment_file_forbidden',
				__('You are not allowed to manage this media file.', 'wphave'),
				['status' => 403],
			);
		}

		// BINDING INVARIANT: Extension callbacks can rebind the attachment after
		// validation. A capability on its ID does not authorize replacing the old
		// pathname once that ID points elsewhere.
		if (
			!self::attachment_source_still_registered(
				(int) $attachment_id,
				$target_file,
				(string) $old_mime,
			)
		) {
			self::cleanup_replacement_stage($staged_file, $upload_validation['checksum']);
			self::cleanup_backups($backups);
			return new WP_Error(
				'wphave_replace_source_changed',
				__('The attachment file changed while replacing it. Reload it before saving.', 'wphave'),
				['status' => 409],
			);
		}
		// METADATA-REVISION INVARIANT: Backups and extension callbacks do not
		// reserve the attachment's derivative inventory. Never remove planned
		// files or replace the source after another writer changed that record.
		if (get_post_meta($attachment_id, '_wp_attachment_metadata', true) !== $old_metadata) {
			self::cleanup_replacement_stage($staged_file, $upload_validation['checksum']);
			self::cleanup_backups($backups);
			return new WP_Error(
				'wphave_replace_metadata_changed',
				__('The attachment metadata changed while preparing the replacement. Reload before saving.', 'wphave'),
				['status' => 409],
			);
		}
		$target_backup = self::backup_for_path($backups, $target_file);
		try {
			// PUBLICATION INVARIANT: An unassignable source group is optional only
			// when the original mode grants no group-only access. Check before any
			// derivative is removed, then pass the same policy into the commit.
			$publication_group = WPHAVE_Security_File_Permissions::replacement_group($target_backup);
		} catch (RuntimeException $error) {
			self::cleanup_replacement_stage($staged_file, $upload_validation['checksum']);
			self::cleanup_backups($backups);
			return new WP_Error(
				'wphave_replace_target_permissions',
				__('The current file permissions cannot be preserved safely.', 'wphave'),
				['status' => 409],
			);
		}

		foreach ($old_files as $file) {
			if ($file['path'] !== $target_file && file_exists($file['path'])) {
				// OWNERSHIP INVARIANT: Planning and backup do not reserve a
				// derivative. A later attachment registration revokes removal authority.
				if (self::is_registered_other_attachment_file($file['path'], (int) $attachment_id)) {
					self::cleanup_replacement_stage($staged_file, $upload_validation['checksum']);
					// OWNERSHIP INVARIANT: This path has not been mutated by this
					// transaction. A new owner forbids even rollback inspection of
					// that path; restore only earlier, transaction-owned mutations.
					$recovery = self::restore_backups(
						(int) $attachment_id,
						$backups,
						[$file['path']],
						$mutations,
					);
					if (is_wp_error($recovery)) {
						return $recovery;
					}
					self::cleanup_backups($backups);
					return new WP_Error(
						'wphave_replace_derivative_reassigned',
						__('An attachment file changed ownership while replacing it. Reload before saving.', 'wphave'),
						['status' => 409],
					);
				}
				$backup = self::backup_for_path($backups, $file['path']);
				try {
					// SECURITY INVARIANT: Derivative cleanup consumes the exact node that
					// was snapshotted. A concurrent replacement at the same path survives.
					WPHAVE_Security_Conditional_File::remove_if_matches(
						$file['path'],
						(string) ($backup['checksum'] ?? ''),
						__(
							'An attachment derivative changed before replacement cleanup.',
							'wphave',
						),
						isset($backup['bytes']) && is_int($backup['bytes'])
							? max(1, $backup['bytes'])
							: 0,
					);
					$mutations[$file['path']] = null;
				} catch (RuntimeException $error) {
					self::cleanup_replacement_stage($staged_file, $upload_validation['checksum']);
					$recovery = self::restore_backups((int) $attachment_id, $backups, [$file['path']], $mutations);
					// RECOVERY INVARIANT: Failed rollback retains snapshots and current metadata.
					if (is_wp_error($recovery)) {
						return $recovery;
					}
					self::cleanup_backups($backups);
					return new WP_Error(
						'wphave_replace_target_changed',
						__(
							'An attachment file changed concurrently. Replace was not applied.',
							'wphave',
						),
						['status' => 409],
					);
				}
			}
		}

		try {
			// SECURITY INVARIANT: Replacement authority applies to the exact main-file
			// node captured in the backup, not merely to its reusable pathname.
			WPHAVE_Security_Conditional_File::replace_if_matches(
				$target_file,
				(string) ($target_backup['checksum'] ?? ''),
				$staged_file,
				$upload_validation['checksum'],
				__('The attachment main file changed before replacement commit.', 'wphave'),
				// PUBLICATION INVARIANT: Retain captured live mode and group, never staging permissions.
				WPHAVE_Security_File_Permissions::existing($target_backup),
				$publication_group,
				null,
				max(1, (int) ($target_backup['bytes'] ?? 0)),
			);
			// COMMIT INVARIANT: Normal return means committed even if quarantine
			// cleanup is pending. Always record ownership before later rollback.
			$mutations[$target_file] = [
				'checksum' => (string) $upload_validation['checksum'],
				'bytes' => (int) $upload_validation['bytes'],
			];
		} catch (RuntimeException $error) {
			// SECURITY: The main mutation was rejected, so its live path belongs to the
			// conflicting writer and must be excluded from rollback restoration.
			try {
				WPHAVE_Security_Conditional_File::remove_if_matches(
					$staged_file,
					$upload_validation['checksum'],
					__('Rejected replacement staging could not be cleaned up safely.', 'wphave'),
					self::MAX_REPLACEMENT_BYTES,
				);
			} catch (RuntimeException $cleanup_error) {
				// Preserve an unproven staging node for operator recovery.
			}
			$recovery = self::restore_backups((int) $attachment_id, $backups, [$target_file], $mutations);
			// RECOVERY INVARIANT: Failed rollback retains snapshots and current metadata.
			if (is_wp_error($recovery)) {
				return $recovery;
			}
			self::cleanup_backups($backups);
			return new WP_Error(
				'wphave_replace_target_changed',
				__(
					'The attachment main file changed concurrently. Replace was not applied.',
					'wphave',
				),
				['status' => 409],
			);
		}

		try {
			WPHAVE_Security_Conditional_File::remove_if_matches(
				$staged_file,
				$upload_validation['checksum'],
				__(
					'The committed replacement staging file could not be cleaned up safely.',
					'wphave',
				),
				self::MAX_REPLACEMENT_BYTES,
			);
		} catch (RuntimeException $error) {
			$recovery = self::restore_backups((int) $attachment_id, $backups, [], $mutations);
			// RECOVERY INVARIANT: Failed rollback retains snapshots and current metadata.
			if (is_wp_error($recovery)) {
				return $recovery;
			}
			self::cleanup_backups($backups);
			return new WP_Error(
				'wphave_replace_failed',
				__('Replacement staging cleanup failed. No changes were saved.', 'wphave'),
				['status' => 500],
			);
		}

		try {
			$metadata = self::regenerate_replaced_attachment_metadata($attachment_id, $target_file);
		} catch (Throwable $error) {
			// RECOVERY INVARIANT: Extension callbacks may throw while generating or
			// persisting metadata. Route them through the same file and record rollback.
			$metadata = new WP_Error(
				'wphave_replace_metadata_failed',
				__('Replacement metadata could not be generated. No changes were saved.', 'wphave'),
				['status' => 500],
			);
		}

		if (is_wp_error($metadata)) {
			$recovery = self::restore_backups((int) $attachment_id, $backups, [], $mutations);
			// RECOVERY INVARIANT: Failed rollback retains snapshots and current metadata.
			if (is_wp_error($recovery)) {
				return $recovery;
			}
			$record_recovery = self::restore_replacement_record_if_owned(
				$attachment_id,
				$target_file,
				$old_metadata,
				$old_mime,
				[$old_mime],
			);
			if (is_wp_error($record_recovery)) {
				return $record_recovery;
			}
			self::cleanup_backups($backups);
			return $metadata;
		}

		// POST-GENERATION INVARIANT: Metadata generation invokes extension hooks.
		// A rebind or revoked permission cannot authorize the following MIME write.
		if (
			!self::current_user_can_manage_attachment_file($attachment_id) ||
			!self::attachment_source_still_registered(
				(int) $attachment_id,
				$target_file,
				(string) $old_mime,
			)
		) {
			$recovery = self::restore_backups((int) $attachment_id, $backups, [], $mutations);
			if (is_wp_error($recovery)) {
				return $recovery;
			}
			// RECOVERY INVARIANT: Generation may already have persisted metadata.
			// A rebind or revoked permission forbids rewriting that record, so keep
			// snapshots for explicit recovery even when file rollback succeeds.
			return self::replacement_record_recovery_required();
		}

		try {
			$post_update = wp_update_post(
				[
					'ID' => $attachment_id,
					'post_mime_type' => $upload_validation['mime'],
				],
				true,
			);
		} catch (Throwable $error) {
			// RECORD INVARIANT: A post-update hook exception still requires the
			// same conditional file and metadata recovery as a returned WP_Error.
			$post_update = new WP_Error(
				'wphave_replace_post_update_failed',
				__('The attachment record could not be updated.', 'wphave'),
				['status' => 500],
			);
		}

		if (is_wp_error($post_update) || !$post_update) {
			// RECOVERY INVARIANT: Generated metadata names do not prove that the
			// current file at each path belongs to this transaction. Preserve
			// unproven derivatives for explicit recovery instead of unlinking them.
			$recovery = self::restore_backups((int) $attachment_id, $backups, [], $mutations);
			// RECOVERY INVARIANT: Failed rollback retains snapshots and current metadata.
			if (is_wp_error($recovery)) {
				return $recovery;
			}
			$record_recovery = self::restore_replacement_record_if_owned(
				$attachment_id,
				$target_file,
				$old_metadata,
				$old_mime,
				[$old_mime, $upload_validation['mime']],
			);
			if (is_wp_error($record_recovery)) {
				return $record_recovery;
			}
			self::cleanup_backups($backups);
			return new WP_Error(
				'wphave_replace_post_update_failed',
				__('The attachment record could not be updated. No changes were saved.', 'wphave'),
				['status' => 500],
			);
		}
		if (
			!self::attachment_source_still_registered(
				(int) $attachment_id,
				$target_file,
				(string) $upload_validation['mime'],
		)
		) {
			$recovery = self::restore_backups((int) $attachment_id, $backups, [], $mutations);
			if (is_wp_error($recovery)) {
				return $recovery;
			}
			// RECOVERY INVARIANT: The post-update hook can rebind the record after
			// metadata has been persisted. Retain snapshots until reconciled.
			return self::replacement_record_recovery_required();
		}

		// RESPONSE INVARIANT: Presentation filters run before backups are
		// released; they may rebind this ID after the post-update check.
		// RESPONSE INVARIANT: Presentation hooks run after the file commit. Their
		// exceptions must not turn a successful write into an ambiguous failure or
		// strand its recovery backups. The client can refresh the committed record.
		try {
			$title = get_the_title($attachment_id);
			$url = wp_get_attachment_url($attachment_id);
		} catch (Throwable $error) {
			$title = null;
			$url = null;
		}
		if (
			!self::attachment_source_still_registered(
				(int) $attachment_id,
				$target_file,
				(string) $upload_validation['mime'],
			)
		) {
			$recovery = self::restore_backups((int) $attachment_id, $backups, [], $mutations);
			return is_wp_error($recovery)
				? $recovery
				: self::replacement_record_recovery_required();
		}
		try {
			clean_post_cache($attachment_id);
		} catch (Throwable $error) {
			// A cache hook runs after commit. Preserve the committed result and
			// verify its file and binding before releasing recovery snapshots.
			$title = null;
			$url = null;
		}
		try {
			$published_identity = WPHAVE_Security_File_Identity::inspect_bounded(
				$target_file,
				self::MAX_REPLACEMENT_BYTES,
				__('The replacement file changed before completion.', 'wphave'),
			);
		} catch (RuntimeException $error) {
			$published_identity = [];
		}
		// BYTE INVARIANT: Metadata, record and presentation hooks all run after
		// the conditional commit. Success requires the exact approved bytes now.
		if (
			!hash_equals($upload_validation['checksum'], (string) ($published_identity['checksum'] ?? '')) ||
			// An empty non-image metadata result is represented by a deleted row.
			($metadata === []
				? metadata_exists('post', $attachment_id, '_wp_attachment_metadata')
				: get_post_meta($attachment_id, '_wp_attachment_metadata', true) !== $metadata) ||
			!self::attachment_source_still_registered(
				(int) $attachment_id,
				$target_file,
				(string) $upload_validation['mime'],
			)
		) {
			// RECORD INVARIANT: Presentation and cache hooks may mutate stored
			// metadata while leaving the main file binding intact. Keep snapshots
			// for reconciliation rather than reporting a mixed revision as success.
			$recovery = self::restore_backups((int) $attachment_id, $backups, [], $mutations);
			return is_wp_error($recovery)
				? $recovery
				: self::replacement_record_recovery_required();
		}
		self::cleanup_backups($backups);
		clearstatcache(true, $target_file);

		return [
			'id' => $attachment_id,
			'title' => $title,
			'file' => wp_basename($target_file),
			'url' => $url,
			'oldSize' => $old_size,
			'newSize' => file_exists($target_file) ? filesize($target_file) : 0,
			'oldMime' => $old_mime,
			'newMime' => $upload_validation['mime'],
			'metadata' => is_array($metadata) ? $metadata : [],
		];
	}

	/**
	 * Restore the prior media record only while this transaction still owns it.
	 *
	 * @param int $attachment_id Attachment being replaced.
	 * @param string $target_file Registered live file path.
	 * @param mixed $old_metadata Metadata captured before replacement.
	 * @param string $old_mime MIME type captured before replacement.
	 * @param array $allowed_current_mimes MIME types that may still belong to this transaction.
	 * @return true|WP_Error
	 */
	private static function restore_replacement_record_if_owned(
		int $attachment_id,
		string $target_file,
		$old_metadata,
		string $old_mime,
		array $allowed_current_mimes,
	) {
		try {
			return self::attempt_restore_replacement_record_if_owned(
				$attachment_id,
				$target_file,
				$old_metadata,
				$old_mime,
				$allowed_current_mimes,
			);
		} catch (Throwable $error) {
			// RECOVERY INVARIANT: A throwing WordPress hook must not bypass the
			// caller's recovery-required result or release retained snapshots.
			return self::replacement_record_recovery_required();
		}
	}

	/**
	 * Perform the conditional record restore behind the exception boundary.
	 *
	 * @param int $attachment_id Attachment being replaced.
	 * @param string $target_file Registered live file path.
	 * @param mixed $old_metadata Metadata captured before replacement.
	 * @param string $old_mime MIME type captured before replacement.
	 * @param array $allowed_current_mimes MIME types that may still belong to this transaction.
	 * @return true|WP_Error
	 */
	private static function attempt_restore_replacement_record_if_owned(
		int $attachment_id,
		string $target_file,
		$old_metadata,
		string $old_mime,
		array $allowed_current_mimes,
	) {
		// RECOVERY INVARIANT: A hook may repurpose the ID during generation. A
		// backup of our file never grants authority to rewrite that foreign record.
		$current_mime = get_post_mime_type($attachment_id);
		if (
			!self::current_user_can_manage_attachment_file($attachment_id) ||
			!in_array($current_mime, $allowed_current_mimes, true) ||
			!self::attachment_source_still_registered($attachment_id, $target_file, $current_mime)
		) {
			return self::replacement_record_recovery_required();
		}

		if (is_array($old_metadata)) {
			wp_update_attachment_metadata($attachment_id, $old_metadata);
		} else {
			delete_post_meta($attachment_id, '_wp_attachment_metadata');
		}
		if (
			!self::current_user_can_manage_attachment_file($attachment_id) ||
			!self::attachment_source_still_registered($attachment_id, $target_file, $current_mime)
		) {
			return self::replacement_record_recovery_required();
		}
		if ($current_mime !== $old_mime) {
			$updated = wp_update_post(
				[
					'ID' => $attachment_id,
					'post_mime_type' => $old_mime,
				],
				true,
			);
			if (is_wp_error($updated)) {
				return self::replacement_record_recovery_required();
			}
		}
		$expected_metadata = is_array($old_metadata) ? $old_metadata : '';
		if (
			!self::attachment_source_still_registered($attachment_id, $target_file, $old_mime) ||
			get_post_meta($attachment_id, '_wp_attachment_metadata', true) !== $expected_metadata
		) {
			return self::replacement_record_recovery_required();
		}
		clean_post_cache($attachment_id);
		return true;
	}

	/** Return an explicit recovery-required result without deleting snapshots. */
	private static function replacement_record_recovery_required(): WP_Error {
		return new WP_Error(
			'wphave_attachment_recovery_required',
			__('The media record changed during recovery. Backups have been retained for inspection.', 'wphave'),
			['status' => 500],
		);
	}

	/** Encode a different raster upload into the attachment's existing format. */
	private static function convert_replacement_stage(
		string $source,
		string $source_checksum,
		string $source_mime,
		string $target_mime,
	): array|WP_Error {
		// DECODE INVARIANT: Only bounded, byte-verified raster input reaches the
		// decoder. The encoder writes into the editor's private workspace; the
		// original-format URL never serves a partially converted file.
		try {
			$source_identity = WPHAVE_Security_File_Identity::inspect_bounded(
				$source,
				WPHAVE_Media_Image_Source_Gate::MAX_BYTES,
				__('The replacement image could not be verified for conversion.', 'wphave'),
			);
			$source_inspection = WPHAVE_Media_Image_Source_Gate::inspect($source, $source_mime);
		} catch (Throwable $error) {
			$source_identity = [];
			$source_inspection = ['error' => true];
		}
		if (
			!hash_equals($source_checksum, (string) ($source_identity['checksum'] ?? '')) ||
			isset($source_inspection['error'])
		) {
			return new WP_Error(
				'wphave_replace_conversion_invalid_source',
				__('The replacement image could not be verified for conversion.', 'wphave'),
				['status' => 400],
			);
		}

		$workspace = self::create_image_editor_private_workspace();
		if (is_wp_error($workspace)) {
			return $workspace;
		}
		$source_extensions = [
			'image/jpeg' => 'jpg',
			'image/png' => 'png',
			'image/webp' => 'webp',
			'image/avif' => 'avif',
		];
		$private_source = trailingslashit($workspace) . 'source.' . $source_extensions[$source_mime];
		// FORMAT INVARIANT: WordPress may normalize save() paths by their suffix.
		// Stage the conversion with the destination format's extension so the
		// returned path and encoded MIME describe the same file.
		$output = trailingslashit($workspace) . 'converted.' . $source_extensions[$target_mime];
		$published_stage = self::create_backup_path($source);
		$output_checksum = '';
		try {
			WPHAVE_Security_Atomic_File::copy_verified_new(
				$source,
				$private_source,
				$source_checksum,
				__('The replacement image changed before decoding.', 'wphave'),
				0600,
				null,
				max(1, $source_identity['bytes']),
			);
			// SNAPSHOT INVARIANT: Image headers may have changed between the
			// initial inspection and the checksum-bound copy. Recheck the actual
			// decoder input, including its static-frame requirement.
			$private_inspection = WPHAVE_Media_Image_Source_Gate::inspect(
				$private_source,
				$source_mime,
			);
			if (
				isset($private_inspection['error']) ||
				$private_inspection['width'] !== $source_inspection['width'] ||
				$private_inspection['height'] !== $source_inspection['height']
			) {
				return new WP_Error(
					'wphave_replace_conversion_invalid_source',
					__('The replacement image changed before conversion.', 'wphave'),
					['status' => 409],
				);
			}
			$editor = wp_get_image_editor($private_source);
			if (is_wp_error($editor)) {
				return new WP_Error(
					'wphave_replace_conversion_unsupported',
					__('This image format cannot be converted on this server.', 'wphave'),
					['status' => 400],
				);
			}
			$saved = $editor->save($output, $target_mime);
			$output_inspection = is_file($output)
				? WPHAVE_Media_Image_Source_Gate::inspect($output, $target_mime)
				: ['error' => 'missing'];
			if (
				is_wp_error($saved) ||
				!is_array($saved) ||
				($saved['path'] ?? '') !== $output ||
				($saved['mime-type'] ?? '') !== $target_mime ||
				isset($output_inspection['error']) ||
				$output_inspection['width'] !== $private_inspection['width'] ||
				$output_inspection['height'] !== $private_inspection['height']
			) {
				return new WP_Error(
					'wphave_replace_conversion_failed',
					__('The replacement image could not be encoded in the current format.', 'wphave'),
					['status' => 400],
				);
			}
			$output_identity = WPHAVE_Security_File_Identity::inspect_bounded(
				$output,
				WPHAVE_Media_Image_Source_Gate::MAX_OUTPUT_BYTES,
				__('The converted image could not be verified.', 'wphave'),
			);
			$output_checksum = $output_identity['checksum'];
			WPHAVE_Security_Atomic_File::copy_verified_new(
				$output,
				$published_stage,
				$output_checksum,
				__('The converted image changed before staging.', 'wphave'),
				0600,
				null,
				max(1, $output_identity['bytes']),
			);
			// STAGING INVARIANT: Do not publish the converted stage while the
			// original-format upload snapshot remains in the uploads tree.
			WPHAVE_Security_Conditional_File::remove_if_matches(
				$source,
				$source_checksum,
				__('The replacement source changed before conversion cleanup.', 'wphave'),
				max(1, $source_identity['bytes']),
			);
			return [
				'path' => $published_stage,
				'checksum' => $output_checksum,
				'bytes' => $output_identity['bytes'],
			];
		} catch (Throwable $error) {
			self::cleanup_replacement_stage($published_stage, $output_checksum);
			return new WP_Error(
				'wphave_replace_conversion_failed',
				__('The replacement image could not be converted safely.', 'wphave'),
				['status' => 400],
			);
		} finally {
			if (!$output_checksum && is_file($output)) {
				try {
					$output_identity = WPHAVE_Security_File_Identity::inspect_bounded(
						$output,
						WPHAVE_Media_Image_Source_Gate::MAX_OUTPUT_BYTES,
						__('The failed converted image could not be inspected.', 'wphave'),
					);
					$output_checksum = $output_identity['checksum'];
				} catch (RuntimeException $error) {
					// Preserve an unproven node inside private storage for recovery.
				}
			}
			if ($output_checksum) {
				self::cleanup_replacement_stage($output, $output_checksum);
			}
			self::cleanup_replacement_stage($private_source, $source_checksum);
			@rmdir($workspace);
		}
	}

	/**
	 * Validate the replacement upload.
	 *
	 * @param int $attachment_id
	 * @param array|null $upload
	 * @return array|WP_Error
	 */

	protected static function validate_replacement_upload($attachment_id, $upload) {
		if (empty($upload) || !is_array($upload)) {
			return new WP_Error(
				'wphave_replace_missing_file',
				__('Please choose a replacement file.', 'wphave'),
				['status' => 400],
			);
		}

		if (!empty($upload['error'])) {
			return new WP_Error(
				'wphave_replace_upload_error',
				__('The replacement file could not be uploaded.', 'wphave'),
				['status' => 400],
			);
		}

		if (
			empty($upload['tmp_name']) ||
			!static::is_valid_replacement_upload_path($upload['tmp_name']) ||
			!is_readable($upload['tmp_name'])
		) {
			return new WP_Error(
				'wphave_replace_invalid_upload',
				__('The uploaded replacement file is invalid.', 'wphave'),
				['status' => 400],
			);
		}

		// RESOURCE INVARIANT: Client size metadata is untrusted. Resolve the site's
		// upload limit before hashing and keep a finite ceiling if it reports zero.
		$site_limit = (int) wp_max_upload_size();
		$max_size = $site_limit > 0
			? min($site_limit, self::MAX_REPLACEMENT_BYTES)
			: self::MAX_REPLACEMENT_BYTES;
		try {
			$initial_identity = WPHAVE_Security_File_Identity::inspect_bounded(
				$upload['tmp_name'],
				$max_size,
				__('The replacement upload could not be verified.', 'wphave'),
			);
		} catch (RuntimeException $error) {
			return new WP_Error(
				'wphave_replace_upload_too_large',
				__('The replacement file exceeds the maximum upload size or could not be verified.', 'wphave'),
				['status' => 400],
			);
		}

		$upload_size = $initial_identity['bytes'];

		if ($upload_size > $max_size) {
			return new WP_Error(
				'wphave_replace_upload_too_large',
				__('The replacement file exceeds the maximum upload size.', 'wphave'),
				['status' => 400],
			);
		}

		$target_file = self::normalize_existing_upload_path(get_attached_file($attachment_id, true));
		$current_extension = self::normalize_file_extension(
			pathinfo($target_file, PATHINFO_EXTENSION),
		);
		$upload_extension = self::normalize_file_extension(
			pathinfo($upload['name'] ?? '', PATHINFO_EXTENSION),
		);
		$current_mime = get_post_mime_type($attachment_id);

		if (!$current_mime) {
			return new WP_Error(
				'wphave_replace_missing_current_type',
				__('The current attachment media type could not be resolved.', 'wphave'),
				['status' => 400],
			);
		}

		if (!$current_extension || !$upload_extension) {
			return new WP_Error(
				'wphave_replace_extension_mismatch',
				__(
					'The replacement file needs a supported file extension.',
					'wphave',
				),
				['status' => 400],
			);
		}

		if (!is_writable($target_file) || !is_writable(dirname($target_file))) {
			return new WP_Error(
				'wphave_replace_target_not_writable',
				__('The current attachment file or its directory is not writable.', 'wphave'),
				['status' => 409],
			);
		}

		// SECURITY INVARIANT: Replacement bypasses WordPress upload prefilters. Apply
		// the shared SVG byte policy before computing the immutable size and hash.
		if (function_exists('wphave_prepare_special_media_upload')) {
			$prepared = wphave_prepare_special_media_upload($upload);

			if (is_wp_error($prepared)) {
				return new WP_Error(
					'wphave_replace_invalid_type',
					WPHAVE_Security_Redactor::error_text($prepared->get_error_message()),
					['status' => 400],
				);
			}
		}

		try {
			// TRANSFORMATION INVARIANT: Revalidate the complete prepared bytes
			// before a MIME sniffer or staging copy can consume the changed file.
			$upload_identity = WPHAVE_Security_File_Identity::inspect_bounded(
				$upload['tmp_name'],
				$max_size,
				__('The prepared replacement upload could not be verified.', 'wphave'),
			);
		} catch (RuntimeException $error) {
			return new WP_Error(
				'wphave_replace_upload_too_large',
				__('The prepared replacement file exceeds the maximum upload size or could not be verified.', 'wphave'),
				['status' => 400],
			);
		}

		$upload_size = $upload_identity['bytes'];
		if ($upload_size < 1) {
			return new WP_Error(
				'wphave_replace_empty_upload',
				__('The replacement file is empty.', 'wphave'),
				['status' => 400],
			);
		}
		// RESOURCE INVARIANT: A raster replacement is decoded again during
		// WordPress metadata generation. Reject a large image before asking the
		// WordPress MIME sniffer to inspect its bytes.
		if (
			in_array($upload_extension, ['jpg', 'jpeg', 'jpe', 'png', 'webp', 'avif'], true) &&
			$upload_size > WPHAVE_Media_Image_Source_Gate::MAX_BYTES
		) {
			return new WP_Error(
				'wphave_replace_image_too_large',
				__('The replacement image exceeds the safe processing limit.', 'wphave'),
				['status' => 400],
			);
		}

		$checked = wp_check_filetype_and_ext($upload['tmp_name'], $upload['name']);
		$upload_mime = $checked['type'] ?? '';

		if (!$upload_mime) {
			return new WP_Error(
				'wphave_replace_invalid_type',
				__('The replacement file type is not allowed.', 'wphave'),
				['status' => 400],
			);
		}

		// TYPE/URL INVARIANT: Source bytes must agree with their own extension.
		// A different raster format is decoded and re-encoded to the existing
		// attachment MIME before publication under the stable public URL.
		$convert = $upload_mime !== $current_mime;
		if (
			!empty($checked['proper_filename']) ||
			($convert && (
				!in_array($current_mime, self::image_editor_supported_mimes(), true) ||
				!in_array($upload_mime, self::image_editor_supported_mimes(), true)
			)) ||
			(!$convert && $current_extension !== $upload_extension)
		) {
			return new WP_Error(
				'wphave_replace_mime_mismatch',
				__(
					'The replacement file must match the current format or use a supported image format.',
					'wphave',
				),
				['status' => 400],
			);
		}
		if (in_array($upload_mime, self::image_editor_supported_mimes(), true)) {
			// Same-format replacement preserves the uploaded original, including
			// animation. Conversion uses a single-frame encoder and must reject it.
			$image_inspection = WPHAVE_Media_Image_Source_Gate::inspect(
				$upload['tmp_name'],
				$upload_mime,
				$convert,
			);
			if (isset($image_inspection['error'])) {
				return new WP_Error(
					'wphave_replace_image_too_large',
					__('The replacement image cannot be processed safely.', 'wphave'),
					['status' => 400],
				);
			}
		}

		return [
			'mime' => $current_mime,
			'convert' => $convert,
			'sourceMime' => $upload_mime,
			'bytes' => $upload_size,
			// RESOURCE INVARIANT: Staging enforces this same bound after validation;
			// checksum rejection alone would occur only after copying a growing file.
			'maxBytes' => $max_size,
			// SECURITY INVARIANT: This fingerprint binds validation to the staged bytes
			// that are later committed, closing upload-path TOCTOU and metadata drift.
			'checksum' => $upload_identity['checksum'],
		];
	}

	/**
	 * Map an internal attachment-mutation failure onto its public REST contract.
	 *
	 * SECURITY INVARIANT: Upload identity and filesystem exceptions may contain
	 * temporary paths, filenames or personal identifiers. Mutation endpoints
	 * expose those details only through the central diagnostic redactor.
	 */

	protected static function attachment_operation_failure(
		string $code,
		string $message,
		int $status,
	): WP_Error {
		return new WP_Error(sanitize_key($code), WPHAVE_Security_Redactor::error_text($message), [
			'status' => $status,
		]);
	}

	/** Testable boundary immediately before checksum-conditional live mutation. */

	protected static function before_replace_commit($attachment_id, $target_file) {
		// Intentionally empty. Subclasses may instrument the cross-phase boundary.
	}

	/**
	 * Verify that replacement bytes originate from the current HTTP upload request.
	 */

	protected static function is_valid_replacement_upload_path($path) {
		return is_uploaded_file($path);
	}

	/**
	 * Validate the replace targets.
	 *
	 * @param string $target_file
	 * @param array $old_files
	 * @return true|WP_Error
	 */

	private static function validate_replace_targets($target_file, $old_files) {
		// RECOVERY INVARIANT: No same-directory snapshot may be created until
		// the public server has proved that WPHAVE backup names are inaccessible.
		if (
			!function_exists('wphave_sync_uploads_htaccess') ||
			!wphave_sync_uploads_htaccess(
				(bool) wphave_data_get('site_settings', 'advanced.security.block_executable_uploads', false),
			) ||
			!wphave_verify_upload_backup_http_protection()
		) {
			return new WP_Error(
				'wphave_upload_backup_exposed',
				__('The upload server did not verify private recovery files. No files were changed.', 'wphave'),
				['status' => 503],
			);
		}

		if (!$target_file || !self::is_path_inside_uploads($target_file)) {
			return new WP_Error(
				'wphave_replace_invalid_target',
				__('The current attachment file path is invalid.', 'wphave'),
				['status' => 409],
			);
		}

		if (
			!file_exists($target_file) ||
			!is_readable($target_file) ||
			!is_writable($target_file) ||
			!is_writable(dirname($target_file))
		) {
			return new WP_Error(
				'wphave_replace_target_not_writable',
				__('The current attachment file or its directory is not writable.', 'wphave'),
				['status' => 409],
			);
		}

		foreach ($old_files as $file) {
			if (empty($file['path']) || !self::is_path_inside_uploads($file['path'])) {
				return new WP_Error(
					'wphave_replace_invalid_derivative',
					__('One or more generated attachment file paths are invalid.', 'wphave'),
					['status' => 409],
				);
			}

			if (empty($file['exists'])) {
				continue;
			}

			if (
				!file_exists($file['path']) ||
				!is_readable($file['path']) ||
				!is_writable($file['path']) ||
				!is_writable(dirname($file['path']))
			) {
				return new WP_Error(
					'wphave_replace_derivative_not_writable',
					__('One or more generated attachment files are not writable.', 'wphave'),
					['status' => 409],
				);
			}
		}

		return true;
	}

	/**
	 * Regenerate metadata after replacing an attachment file.
	 *
	 * @param int $attachment_id
	 * @param string $target_file
	 * @return array|true|WP_Error
	 */

	private static function regenerate_replaced_attachment_metadata($attachment_id, $target_file) {
		if (!wp_attachment_is_image($attachment_id)) {
			wp_update_attachment_metadata($attachment_id, []);
			// WordPress deletes an attachment metadata row when given an empty
			// array. Require actual absence so a failed delete or concurrent write
			// cannot be mistaken for a successful non-image replacement.
			if (metadata_exists('post', $attachment_id, '_wp_attachment_metadata')) {
				return new WP_Error(
					'wphave_replace_metadata_failed',
					__('The replacement metadata could not be saved.', 'wphave'),
					['status' => 500],
				);
			}
			return [];
		}

		require_once ABSPATH . 'wp-admin/includes/image.php';

		$existing_threshold_filter = has_filter('big_image_size_threshold', '__return_false');
		if ($existing_threshold_filter === false) {
			add_filter('big_image_size_threshold', '__return_false', 99);
		}
		try {
			$metadata = wp_generate_attachment_metadata($attachment_id, $target_file);
		} finally {
			// HOOK LIFECYCLE INVARIANT: A throwing processor cannot leak our
			// temporary policy or remove another caller's existing registration.
			if ($existing_threshold_filter === false) {
				remove_filter('big_image_size_threshold', '__return_false', 99);
			}
		}

		if (!is_array($metadata)) {
			return new WP_Error(
				'wphave_replace_metadata_failed',
				__('The replacement image metadata could not be generated.', 'wphave'),
				['status' => 500],
			);
		}

		$relative_path = self::get_relative_upload_path($target_file);

		if ($relative_path) {
			$metadata['file'] = $relative_path;
		}

		unset($metadata['original_image']);

		// WordPress may already persist this metadata while generating subsizes.
		// Its update API also returns false for unchanged values; verify the
		// canonical postcondition before treating that result as a failed write.
		wp_update_attachment_metadata($attachment_id, $metadata);
		if (get_post_meta($attachment_id, '_wp_attachment_metadata', true) !== $metadata) {
			return new WP_Error(
				'wphave_replace_metadata_failed',
				__('The replacement image metadata could not be saved.', 'wphave'),
				['status' => 500],
			);
		}

		return $metadata;
	}

	/**
	 * Update an attachment metadata after rename.
	 *
	 * @param int $attachment_id
	 * @param string $main_file
	 * @param string $new_basename
	 * @param array $plan
	 * @return array|true|WP_Error
	 */

	/**
	 * Delete only the checksum-bound private stage; retain a changed path for recovery.
	 *
	 * @param string $path Private staging path.
	 * @param string $checksum Expected staged byte checksum.
	 * @return void
	 */
	private static function cleanup_replacement_stage(string $path, string $checksum): void {
		try {
			// STAGING INVARIANT: Backup and derivative failures own only the
			// checksum-bound upload revision, never a later path replacement.
			WPHAVE_Security_Conditional_File::remove_if_matches(
				$path,
				$checksum,
				__('Replacement staging changed before cleanup.', 'wphave'),
				self::MAX_REPLACEMENT_BYTES,
			);
		} catch (RuntimeException $error) {
			// Preserve unproven staging for operator recovery.
		}
	}

	private static function update_attachment_metadata_after_rename(
		$attachment_id,
		$main_file,
		$new_basename,
		$plan,
		$expected_metadata,
	) {
		// Persist only the exact raw record whose files entered the validated plan.
		$metadata = get_post_meta($attachment_id, '_wp_attachment_metadata', true);
		if ($metadata !== $expected_metadata) {
			return new WP_Error(
				'wphave_rename_metadata_changed',
				__('The attachment metadata changed while renaming it. Reload before saving.', 'wphave'),
				['status' => 409],
			);
		}
		$upload_dir = wp_get_upload_dir();
		$new_main_path = trailingslashit(dirname($main_file)) . $new_basename;

		if (empty($upload_dir['basedir'])) {
			return new WP_Error(
				'wphave_rename_metadata_failed',
				__('Attachment metadata could not be updated.', 'wphave'),
				['status' => 500],
			);
		}

		$new_relative_path = self::get_relative_upload_path($new_main_path);

		if (!$new_relative_path) {
			return new WP_Error(
				'wphave_rename_metadata_failed',
				__('Attachment metadata could not be updated.', 'wphave'),
				['status' => 500],
			);
		}

		if (!update_attached_file($attachment_id, $new_relative_path)) {
			return new WP_Error(
				'wphave_rename_metadata_failed',
				__('Attachment file metadata could not be updated.', 'wphave'),
				['status' => 500],
			);
		}

		if (!is_array($metadata)) {
			return true;
		}

		$metadata['file'] = $new_relative_path;

		$renamed_size_files = [];
		foreach ($plan as $file) {
			if ($file['role'] === 'original') {
				$metadata['original_image'] = $file['newFile'];
			}

			if ($file['role'] === 'size') {
				$renamed_size_files[$file['currentFile']] = $file['newFile'];
			}
		}
		$metadata = self::rewrite_renamed_size_aliases($metadata, $renamed_size_files);

		$updated = wp_update_attachment_metadata($attachment_id, $metadata);

		if (!$updated && get_post_meta($attachment_id, '_wp_attachment_metadata', true) !== $metadata) {
			return new WP_Error(
				'wphave_rename_metadata_failed',
				__('Attachment metadata could not be updated.', 'wphave'),
				['status' => 500],
			);
		}
		if (get_post_meta($attachment_id, '_wp_attachment_metadata', true) !== $metadata) {
			return new WP_Error(
				'wphave_rename_metadata_failed',
				__('Attachment metadata could not be updated.', 'wphave'),
				['status' => 500],
			);
		}

		return $metadata;
	}
}
