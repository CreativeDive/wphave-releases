<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Attachment_File_Backups {
	/**
	 * Roll back attachment files renamed before an error.
	 *
	 * @param array $renamed
	 */

	private static function rollback_renamed_files($renamed) {
		foreach (array_reverse($renamed) as $file) {
			if (
				!file_exists($file['newPath']) ||
				file_exists($file['currentPath']) ||
				is_link($file['currentPath'])
			) {
				continue;
			}

			self::relocate_file_to_new_path(
				$file['newPath'],
				$file['currentPath'],
				(string) ($file['checksum'] ?? ''),
			);
		}
	}

	/**
	 * Relocates one exact regular-file revision without overwriting a destination.
	 */

	private static function relocate_file_to_new_path(
		string $source,
		string $destination,
		string $expected_checksum = '',
	) {
		try {
			$identity = WPHAVE_Security_File_Identity::inspect(
				$source,
				__('The attachment file could not be inspected before relocation.', 'wphave'),
			);

			if (
				$expected_checksum !== '' &&
				!hash_equals(strtolower($expected_checksum), $identity['checksum'])
			) {
				return false;
			}

			WPHAVE_Security_Conditional_File::relocate_if_matches_to_new(
				$source,
				$identity['checksum'],
				$destination,
				__('The attachment file destination changed before relocation.', 'wphave'),
				// PUBLICATION INVARIANT: Renaming preserves the verified local source mode and group.
				WPHAVE_Security_File_Permissions::recorded($identity['permissions']),
				WPHAVE_Security_File_Permissions::recorded_group($identity['group'] ?? null),
			);
		} catch (RuntimeException $error) {
			return false;
		}

		return ['checksum' => $identity['checksum']];
	}

	/**
	 * Restore the attachment file and metadata state after failure.
	 *
	 * @param int $attachment_id
	 * @param string $file
	 * @param array|false $metadata
	 * @param string|null $mime
	 */

	private static function restore_attachment_file_state(
		$attachment_id,
		$file,
		$metadata = false,
		$mime = null,
	) {
		$relative_path = self::get_relative_upload_path($file);

		if ($relative_path) {
			update_attached_file($attachment_id, $relative_path);
		}

		if (is_array($metadata)) {
			wp_update_attachment_metadata($attachment_id, $metadata);
		} else {
			delete_post_meta($attachment_id, '_wp_attachment_metadata');
		}

		if ($mime !== null) {
			wp_update_post([
				'ID' => $attachment_id,
				'post_mime_type' => $mime,
			]);
		}

		clean_post_cache($attachment_id);
	}

	/**
	 * Create the backup path.
	 *
	 * @param string $path
	 * @return string
	 */

	private static function create_backup_path($path) {
		return trailingslashit(dirname($path)) .
			'.wphave-replace-' .
			wp_generate_uuid4() .
			'-' .
			wp_basename($path);
	}

	/** Find the checksum-bound snapshot record for one live attachment path. */

	private static function backup_for_path(array $backups, string $path): array {
		foreach ($backups as $backup) {
			if (hash_equals($path, (string) ($backup['path'] ?? ''))) {
				return $backup;
			}
		}

		return [];
	}

	/**
	 * Restore attachment files from their temporary backups.
	 *
	 * @param array $backups
	 * @return true|WP_Error Recovery failure must stop cleanup and metadata restoration.
	 */

	private static function restore_backups($backups, $excluded_paths = [], $mutations = []) {
		$failed = false;
		foreach ($backups as $backup) {
			if (in_array((string) ($backup['path'] ?? ''), $excluded_paths, true)) {
				continue;
			}
			try {
				// RECOVERY INVARIANT: Missing snapshots are failures, never evidence
				// that rollback succeeded. Preserve the complete recovery set on failure.
				if (empty($backup['backup']) || !is_file($backup['backup'])) {
					throw new RuntimeException('Attachment recovery snapshot is unavailable.');
				}
				$path = $backup['path'];
				// RECOVERY INVARIANT: A snapshot alone never grants write authority.
				// Untouched files are checked, not rewritten; concurrent changes survive.
				if (!array_key_exists($path, $mutations)) {
					$current = WPHAVE_Security_File_Identity::inspect(
						$path,
						'Recovery target changed.',
					);
					if (!hash_equals($backup['checksum'], $current['checksum'])) {
						throw new RuntimeException('Recovery target changed.');
					}
					continue;
				}
				$args = [
					$backup['backup'],
					$path,
					(string) ($backup['checksum'] ?? ''),
					__('An attachment file changed before rollback.', 'wphave'),
					WPHAVE_Security_File_Permissions::recorded($backup['permissions'] ?? null),
					WPHAVE_Security_File_Permissions::recorded_group($backup['group'] ?? null),
				];
				if ($mutations[$path] === null) {
					// RECOVERY INVARIANT: A removed derivative is restored only into an
					// absent path. Regenerated or concurrent files require explicit recovery.
					WPHAVE_Security_Atomic_File::copy_verified_new(...$args);
				} else {
					// RECOVERY INVARIANT: Replace only the checksum this transaction
					// published, never whatever currently occupies the reusable pathname.
					WPHAVE_Security_Conditional_File::replace_if_matches(
						$path,
						$mutations[$path],
						$backup['backup'],
						$args[2],
						$args[3],
						$args[4],
						$args[5],
					);
				}
			} catch (Throwable $error) {
				// RECOVERY INVARIANT: Attempt independent restores, but never conceal
				// a partial failure or authorize subsequent backup/metadata cleanup.
				$failed = true;
			}
		}
		return $failed
			? new WP_Error(
				'wphave_attachment_recovery_required',
				__(
					'The original media files could not be fully restored. Recovery backups have been retained.',
					'wphave',
				),
				['status' => 500],
			)
			: true;
	}

	/**
	 * Remove temporary attachment backup files.
	 *
	 * @param array $backups
	 */

	private static function cleanup_backups($backups) {
		foreach ($backups as $backup) {
			if (empty($backup['backup'])) {
				continue;
			}

			try {
				// SECURITY INVARIANT: Cleanup authority belongs to the exact snapshot
				// RECOVERY INVARIANT: Rollback authority follows bytes created by this transaction, never a reused path.
				WPHAVE_Security_Conditional_File::remove_if_matches(
					$backup['backup'],
					(string) ($backup['checksum'] ?? ''),
					__('An attachment backup changed before cleanup.', 'wphave'),
				);
			} catch (RuntimeException $error) {
				// Preserve unproven recovery data instead of deleting a foreign node.
			}
		}
	}

	/**
	 * Remove obsolete files from regenerated attachment metadata.
	 *
	 * @param string $target_file
	 * @param array|true $metadata
	 * @param array $old_files
	 */

	private static function cleanup_generated_metadata_files($target_file, $metadata, $old_files) {
		if (!is_array($metadata) || empty($metadata['sizes'])) {
			return;
		}

		$old_paths = array_flip(
			array_map(function ($file) {
				return $file['path'];
			}, $old_files),
		);

		$directory = trailingslashit(dirname($target_file));

		foreach ($metadata['sizes'] as $size) {
			if (empty($size['file'])) {
				continue;
			}

			$path = self::normalize_target_upload_path($directory . $size['file']);

			if ($path && !isset($old_paths[$path]) && file_exists($path)) {
				@unlink($path);
			}
		}
	}
}
