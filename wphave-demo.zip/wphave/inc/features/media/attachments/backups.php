<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Attachment_File_Backups {
	/**
	 * Roll back attachment files renamed before an error.
	 *
	 * @param array $renamed
	 * @param int $attachment_id
	 */

	private static function rollback_renamed_files($renamed, int $attachment_id): true|WP_Error {
		$failed = false;
		foreach (array_reverse($renamed) as $file) {
			// RECOVERY INVARIANT: Every successfully relocated file must return to
			// its old path before attachment metadata may be restored. A reused old
			// path or missing new file requires operator recovery, not a silent skip.
			if (
				self::is_registered_other_attachment_file($file['newPath'], $attachment_id) ||
				self::is_registered_other_attachment_file($file['currentPath'], $attachment_id)
			) {
				$failed = true;
				continue;
			}
			$restored = self::relocate_file_to_new_path(
				$file['newPath'],
				$file['currentPath'],
				(string) ($file['checksum'] ?? ''),
				$file['bytes'] ?? null,
			);
			if (!is_array($restored)) {
				$failed = true;
			}
		}
		return $failed
			? new WP_Error(
				'wphave_attachment_recovery_required',
				__('Renamed media files could not be fully restored. Resolve the file conflict before retrying.', 'wphave'),
				['status' => 500],
			)
			: true;
	}

	/**
	 * Relocates one exact regular-file revision without overwriting a destination.
	 */

	private static function relocate_file_to_new_path(
		string $source,
		string $destination,
		string $expected_checksum = '',
		?int $expected_bytes = null,
	) {
		try {
			clearstatcache(true, $source);
			$stat = @lstat($source);
			if (!is_array($stat) || !is_int($stat['size'] ?? null) || $stat['size'] < 0) {
				return false;
			}
			$maximum_bytes = $expected_bytes === null
				? max(1, $stat['size'])
				: max(1, $expected_bytes);
			$identity = WPHAVE_Security_File_Identity::inspect_bounded(
				$source,
				$maximum_bytes,
				__('The attachment file could not be inspected before relocation.', 'wphave'),
			);

			if (
				($expected_bytes !== null && $identity['bytes'] !== $expected_bytes) ||
				(
					$expected_checksum !== '' &&
					!hash_equals(strtolower($expected_checksum), $identity['checksum'])
				)
			) {
				return false;
			}

			WPHAVE_Security_Conditional_File::relocate_if_matches_to_new(
				$source,
				$identity['checksum'],
				$destination,
				__('The attachment file destination changed before relocation.', 'wphave'),
				// PUBLICATION INVARIANT: Renaming preserves the verified local source mode and group.
				WPHAVE_Security_File_Permissions::recorded($identity['permissions']),
				WPHAVE_Security_File_Permissions::recorded_group($identity['group'] ?? null),
				$maximum_bytes,
			);
		} catch (RuntimeException $error) {
			return false;
		}

		return [
			'checksum' => $identity['checksum'],
			'bytes' => $identity['bytes'],
		];
	}

	/**
	 * Restore a renamed attachment record only while its identity remains ours.
	 *
	 * @param int $attachment_id
	 * @param string $old_file
	 * @param string $new_file
	 * @param array|false $metadata
	 * @param string $mime
	 */

	private static function restore_renamed_attachment_record(
		int $attachment_id,
		string $old_file,
		string $new_file,
		$metadata,
		string $mime,
	) {
		try {
			return self::attempt_restore_renamed_attachment_record(
				$attachment_id,
				$old_file,
				$new_file,
				$metadata,
				$mime,
			);
		} catch (Throwable $error) {
			// RECOVERY INVARIANT: A throwing WordPress hook cannot make a
			// partially restored record look like a completed rollback.
			return self::replacement_record_recovery_required();
		}
	}

	private static function attempt_restore_renamed_attachment_record(
		int $attachment_id,
		string $old_file,
		string $new_file,
		$metadata,
		string $mime,
	) {
		// RECOVERY INVARIANT: A hook may rebind the ID between restoring its
		// pathname and metadata. Each write requires the expected live binding.
		if (!self::current_user_can_manage_attachment_file($attachment_id)) {
			return self::replacement_record_recovery_required();
		}
		if (self::attachment_source_still_registered($attachment_id, $new_file, $mime)) {
			$old_relative = self::get_relative_upload_path($old_file);
			if ($old_relative === '') {
				return self::replacement_record_recovery_required();
			}
			update_attached_file($attachment_id, $old_relative);
		} elseif (!self::attachment_source_still_registered($attachment_id, $old_file, $mime)) {
			return self::replacement_record_recovery_required();
		}
		if (
			!self::current_user_can_manage_attachment_file($attachment_id) ||
			!self::attachment_source_still_registered($attachment_id, $old_file, $mime)
		) {
			return self::replacement_record_recovery_required();
		}
		if (is_array($metadata)) {
			wp_update_attachment_metadata($attachment_id, $metadata);
		} else {
			delete_post_meta($attachment_id, '_wp_attachment_metadata');
		}
		$expected_metadata = is_array($metadata) ? $metadata : '';
		if (
			!self::attachment_source_still_registered($attachment_id, $old_file, $mime) ||
			get_post_meta($attachment_id, '_wp_attachment_metadata', true) !== $expected_metadata
		) {
			return self::replacement_record_recovery_required();
		}
		clean_post_cache($attachment_id);
		return true;
	}

	/**
	 * Create the backup path.
	 *
	 * @param string $path
	 * @return string
	 */

	private static function create_backup_path($path) {
		return trailingslashit(dirname($path)) .
			'.wphave-replace-' .
			wp_generate_uuid4() .
			'-' .
			wp_basename($path);
	}

	/** Find the checksum-bound snapshot record for one live attachment path. */

	private static function backup_for_path(array $backups, string $path): array {
		foreach ($backups as $backup) {
			if (hash_equals($path, (string) ($backup['path'] ?? ''))) {
				return $backup;
			}
		}

		return [];
	}

	/**
	 * Restore attachment files from their temporary backups.
	 *
	 * @param int $attachment_id The attachment whose file set is being restored.
	 * @param array $backups
	 * @return true|WP_Error Recovery failure must stop cleanup and metadata restoration.
	 */

	private static function restore_backups(int $attachment_id, $backups, $excluded_paths = [], $mutations = []) {
		$failed = false;
		foreach ($backups as $backup) {
			if (in_array((string) ($backup['path'] ?? ''), $excluded_paths, true)) {
				continue;
			}
			try {
				// RECOVERY INVARIANT: Missing snapshots are failures, never evidence
				// that rollback succeeded. Preserve the complete recovery set on failure.
				if (empty($backup['backup']) || !is_file($backup['backup'])) {
					throw new RuntimeException('Attachment recovery snapshot is unavailable.');
				}
				if (!isset($backup['bytes']) || !is_int($backup['bytes']) || $backup['bytes'] < 0) {
					throw new RuntimeException('Attachment recovery snapshot size is unavailable.');
				}
				// RESOURCE INVARIANT: A snapshot's recorded size bounds inspection of
				// untouched targets and copying its backup stream during recovery.
				$maximum_bytes = max(1, $backup['bytes']);
				$path = $backup['path'];
				// OWNERSHIP INVARIANT: A removed path may have become another
				// attachment's main file before rollback. Snapshot ownership does
				// not authorize recreating or replacing that registered path.
				if (self::is_registered_other_attachment_file($path, $attachment_id)) {
					throw new RuntimeException('Recovery target changed ownership.');
				}
				// RECOVERY INVARIANT: A snapshot alone never grants write authority.
				// Untouched files are checked, not rewritten; concurrent changes survive.
				if (!array_key_exists($path, $mutations)) {
					$current = WPHAVE_Security_File_Identity::inspect_bounded(
						$path,
						$maximum_bytes,
						'Recovery target changed.',
					);
					if (!hash_equals($backup['checksum'], $current['checksum'])) {
						throw new RuntimeException('Recovery target changed.');
					}
					continue;
				}
				$args = [
					$backup['backup'],
					$path,
					(string) ($backup['checksum'] ?? ''),
					__('An attachment file changed before rollback.', 'wphave'),
					WPHAVE_Security_File_Permissions::recorded($backup['permissions'] ?? null),
					// RECOVERY INVARIANT: A foreign group may be unassignable after
					// snapshotting; substitute only when it grants no extra access.
					WPHAVE_Security_File_Permissions::replacement_group($backup),
					$maximum_bytes,
				];
				if ($mutations[$path] === null) {
					// RECOVERY INVARIANT: A removed derivative is restored only into an
					// absent path. Regenerated or concurrent files require explicit recovery.
					WPHAVE_Security_Atomic_File::copy_verified_new(...$args);
				} else {
					$mutation = $mutations[$path];
					if (
						!is_array($mutation) ||
						!is_string($mutation['checksum'] ?? null) ||
						!is_int($mutation['bytes'] ?? null) ||
						$mutation['bytes'] < 0
					) {
						throw new RuntimeException('Published recovery identity is unavailable.');
					}
					// RECOVERY INVARIANT: Replace only the checksum this transaction
					// published, and bound the quarantine read by its published size.
					WPHAVE_Security_Conditional_File::replace_if_matches(
						$path,
						$mutation['checksum'],
						$backup['backup'],
						$args[2],
						$args[3],
						$args[4],
						$args[5],
						$args[6],
						max(1, $mutation['bytes']),
					);
				}
			} catch (Throwable $error) {
				// RECOVERY INVARIANT: Attempt independent restores, but never conceal
				// a partial failure or authorize subsequent backup/metadata cleanup.
				$failed = true;
			}
		}
		return $failed
			? new WP_Error(
				'wphave_attachment_recovery_required',
				__(
					'The original media files could not be fully restored. Recovery backups have been retained.',
					'wphave',
				),
				['status' => 500],
			)
			: true;
	}

	/**
	 * Remove temporary attachment backup files.
	 *
	 * @param array $backups
	 */

	private static function cleanup_backups($backups) {
		foreach ($backups as $backup) {
			if (empty($backup['backup'])) {
				continue;
			}

			try {
				// SECURITY INVARIANT: Cleanup authority belongs to the exact snapshot
				// RECOVERY INVARIANT: Rollback authority follows bytes created by this transaction, never a reused path.
				WPHAVE_Security_Conditional_File::remove_if_matches(
					$backup['backup'],
					(string) ($backup['checksum'] ?? ''),
					__('An attachment backup changed before cleanup.', 'wphave'),
					isset($backup['bytes']) && is_int($backup['bytes'])
						? max(1, $backup['bytes'])
						: 0,
				);
			} catch (RuntimeException $error) {
				// Preserve unproven recovery data instead of deleting a foreign node.
			}
		}
	}

}
