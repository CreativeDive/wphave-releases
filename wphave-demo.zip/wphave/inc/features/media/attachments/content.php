<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Attachment_File_Content {

    /**
     * Build the content replacements.
     *
     * @param int $attachment_id
     * @param string $filename
     * @return array|WP_Error
     */

    private static function build_content_replacements( $attachment_id, $filename ) {
        $validation = self::validate_attachment( $attachment_id );

        if( is_wp_error( $validation ) ) {
            return $validation;
        }

        $main_file = get_attached_file( $attachment_id );
        $new_basename = self::prepare_new_basename( $filename, $main_file );

        if( is_wp_error( $new_basename ) ) {
            return $new_basename;
        }

        $files = self::collect_attachment_files( $attachment_id );
        $plan = self::build_rename_plan( $files, $main_file, $new_basename );
        $plan_validation = self::validate_rename_plan( $plan );

        if( is_wp_error( $plan_validation ) ) {
            return $plan_validation;
        }

        return self::build_url_replacements_from_plan( $plan );
    }

    /**
     * Build an URL replacements from plan.
     *
     * @param array $plan
     * @return array|WP_Error
     */

    private static function build_url_replacements_from_plan( $plan ) {
        $upload_dir = wp_get_upload_dir();
        $basedir = self::get_upload_basedir();
		$baseurl = empty( $upload_dir['baseurl'] ) ? '' : wphave_public_url( $upload_dir['baseurl'] );
        $replacements = [];

        if( ! $basedir || ! $baseurl ) {
            return new WP_Error( 'wphave_upload_dir_missing', __( 'The upload directory could not be resolved.', 'wphave' ), [ 'status' => 500 ] );
        }

        foreach( $plan as $file ) {
            $current_path = wp_normalize_path( $file['currentPath'] );
            $new_path = wp_normalize_path( $file['newPath'] );

            if( strpos( $current_path, trailingslashit( $basedir ) ) !== 0 || strpos( $new_path, trailingslashit( $basedir ) ) !== 0 ) {
                continue;
            }

            $current_relative = ltrim( substr( $current_path, strlen( trailingslashit( $basedir ) ) ), '/' );
            $new_relative = ltrim( substr( $new_path, strlen( trailingslashit( $basedir ) ) ), '/' );
            $current_url = trailingslashit( $baseurl ) . str_replace( '%2F', '/', rawurlencode( $current_relative ) );
            $new_url = trailingslashit( $baseurl ) . str_replace( '%2F', '/', rawurlencode( $new_relative ) );

            $replacements[ $current_url ] = $new_url;
        }

        return $replacements;
    }

    /**
     * Scan post content for references to an attachment URL.
     *
     * @param array $replacements
     * @return array
     */

    private static function scan_content_usage( $replacements ) {
        $post_ids = self::find_posts_containing_urls( array_keys( $replacements ) );
        $items = [];
        $total_occurrences = 0;

        foreach( $post_ids as $post_id ) {
            $post = get_post( $post_id );

            if( ! $post || ! current_user_can( 'edit_post', $post_id ) ) {
                continue;
            }

            $occurrences = self::count_content_occurrences( $post->post_content, array_keys( $replacements ) );

            if( $occurrences < 1 ) {
                continue;
            }

            $total_occurrences += $occurrences;
            $items[] = [
                'id' => $post_id,
                'title' => get_the_title( $post_id ),
                'type' => $post->post_type,
                'status' => $post->post_status,
                'editUrl' => get_edit_post_link( $post_id, 'raw' ),
                'occurrences' => $occurrences,
            ];
        }

        return [
            'totalPosts' => count( $items ),
            'totalOccurrences' => $total_occurrences,
            'items' => $items,
        ];
    }

    /**
     * Replace the content usage.
     *
     * @param array $replacements
     * @param array $post_ids
     * @return array
     */

    private static function replace_content_usage( $replacements, $post_ids ) {
        $updated = [];
        $skipped = [];
        $total_replacements = 0;
        $scan = self::scan_content_usage( $replacements );
        $allowed_post_ids = array_map( 'absint', wp_list_pluck( $scan['items'], 'id' ) );

		// SECURITY INVARIANT: Attachment URL replacement is closed over the exact
		// editable posts discovered by the current scan, and object permission is
		// checked again immediately before each content mutation.
        foreach( array_unique( $post_ids ) as $post_id ) {
            if( ! in_array( $post_id, $allowed_post_ids, true ) ) {
                $skipped[] = $post_id;
                continue;
            }

            $post = get_post( $post_id );

            if( ! $post || ! current_user_can( 'edit_post', $post_id ) ) {
                $skipped[] = $post_id;
                continue;
            }

            $before = $post->post_content;
            $count = 0;
            $after = str_replace( array_keys( $replacements ), array_values( $replacements ), $before, $count );

            if( $count < 1 || $after === $before ) {
                $skipped[] = $post_id;
                continue;
            }

            $result = wp_update_post( [
                'ID' => $post_id,
                'post_content' => $after,
            ], true );

            if( is_wp_error( $result ) ) {
                $skipped[] = $post_id;
                continue;
            }

            $total_replacements += $count;
            $updated[] = [
                'id' => $post_id,
                'title' => get_the_title( $post_id ),
                'replacements' => $count,
            ];
        }

        return [
            'totalPosts' => count( $updated ),
            'totalReplacements' => $total_replacements,
            'updated' => $updated,
            'skipped' => $skipped,
        ];
    }

    /**
     * Find posts whose content contains any requested URL.
     *
     * @param array $urls
     * @return array
     */

    private static function find_posts_containing_urls( $urls ) {
        global $wpdb;

        $post_types = array_values( array_diff( get_post_types( [ 'public' => true ], 'names' ), [ 'attachment' ] ) );
        $post_statuses = array_values( array_diff( get_post_stati( [ 'internal' => false ], 'names' ), [ 'trash', 'auto-draft' ] ) );
        $url_wheres = [];

        if( empty( $post_types ) || empty( $post_statuses ) || empty( $urls ) ) {
            return [];
        }

        foreach( $urls as $url ) {
            $url_wheres[] = $wpdb->prepare( 'post_content LIKE %s', '%' . $wpdb->esc_like( $url ) . '%' );
        }

        $type_placeholders = implode( ', ', array_fill( 0, count( $post_types ), '%s' ) );
        $status_placeholders = implode( ', ', array_fill( 0, count( $post_statuses ), '%s' ) );
        $sql = "SELECT ID FROM {$wpdb->posts} WHERE post_type IN ({$type_placeholders}) AND post_status IN ({$status_placeholders}) AND (" . implode( ' OR ', $url_wheres ) . ') ORDER BY post_modified_gmt DESC LIMIT 200';

        return array_map( 'absint', $wpdb->get_col( $wpdb->prepare( $sql, array_merge( $post_types, $post_statuses ) ) ) );
    }

    /**
     * Count the content occurrences.
     *
     * @param string $content
     * @param array $urls
     * @return int
     */

    private static function count_content_occurrences( $content, $urls ) {
        $count = 0;

        foreach( $urls as $url ) {
            $count += substr_count( $content, $url );
        }

        return $count;
    }

}
