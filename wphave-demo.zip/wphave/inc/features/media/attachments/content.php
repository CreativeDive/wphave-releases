<?php

require_once dirname(__DIR__, 2) . '/security/safe-link.php';

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Attachment_File_Content {

    /**
     * Build the content replacements.
     *
     * @param int $attachment_id
     * @param string $filename
     * @return array|WP_Error
     */

    private static function build_content_replacements( $attachment_id, $filename ) {
        $validation = self::validate_attachment( $attachment_id );

        if( is_wp_error( $validation ) ) {
            return $validation;
        }

        // SCAN INVARIANT: The URL plan must match the unfiltered rename source.
        $main_file = get_attached_file( $attachment_id, true );
        $new_basename = self::prepare_new_basename( $filename, $main_file );

        if( is_wp_error( $new_basename ) ) {
            return $new_basename;
        }

        $files = self::collect_attachment_files( $attachment_id );
        if ( is_wp_error( $files ) ) {
            return $files;
        }
        $plan = self::build_rename_plan( $files, $main_file, $new_basename, (int) $attachment_id );
		$coverage = self::validate_rename_metadata_coverage(
			get_post_meta( $attachment_id, '_wp_attachment_metadata', true ),
			$plan
		);
		if ( is_wp_error( $coverage ) ) {
			return $coverage;
		}
        $plan_validation = self::validate_rename_plan( $plan );

        if( is_wp_error( $plan_validation ) ) {
            return $plan_validation;
        }

        return self::build_url_replacements_from_plan( $plan );
    }

    /**
     * Build an URL replacements from plan.
     *
     * @param array $plan
     * @return array|WP_Error
     */

    private static function build_url_replacements_from_plan( $plan ) {
        $upload_dir = wp_get_upload_dir();
        $basedir = self::get_upload_basedir();
		$baseurl = empty( $upload_dir['baseurl'] ) ? '' : wphave_public_url( $upload_dir['baseurl'] );
        $replacements = [];

        if( ! $basedir || ! $baseurl ) {
            return new WP_Error( 'wphave_upload_dir_missing', __( 'The upload directory could not be resolved.', 'wphave' ), [ 'status' => 500 ] );
        }

        foreach( $plan as $file ) {
            $current_path = wp_normalize_path( $file['currentPath'] );
            $new_path = wp_normalize_path( $file['newPath'] );

            if( strpos( $current_path, trailingslashit( $basedir ) ) !== 0 || strpos( $new_path, trailingslashit( $basedir ) ) !== 0 ) {
                continue;
            }

            $current_relative = ltrim( substr( $current_path, strlen( trailingslashit( $basedir ) ) ), '/' );
            $new_relative = ltrim( substr( $new_path, strlen( trailingslashit( $basedir ) ) ), '/' );
            $current_url = trailingslashit( $baseurl ) . str_replace( '%2F', '/', rawurlencode( $current_relative ) );
            $new_url = trailingslashit( $baseurl ) . str_replace( '%2F', '/', rawurlencode( $new_relative ) );

            $replacements[ $current_url ] = $new_url;
        }

        return $replacements;
    }

    /**
     * Scan post content for references to an attachment URL.
     *
     * @param array $replacements
     * @return array
     */

    private static function scan_content_usage( $replacements ) {
        $post_ids = self::find_posts_containing_urls( array_keys( $replacements ) );
		if ( is_wp_error( $post_ids ) ) {
			return $post_ids;
		}
		// COVERAGE INVARIANT: One sentinel row distinguishes a complete scan from
		// the bounded first page. Never present 200 matches as all matches.
		$has_more = count( $post_ids ) > 200;
		$post_ids = array_slice( $post_ids, 0, 200 );
		$pattern = self::content_url_pattern( array_keys( $replacements ) );
        $items = [];
        $total_occurrences = 0;

        foreach( $post_ids as $post_id ) {
            $post = get_post( $post_id );

            if( ! $post || ! current_user_can( 'edit_post', $post_id ) ) {
                continue;
            }

			$occurrences = self::count_content_occurrences( $post->post_content, $pattern );

            if( $occurrences < 1 ) {
                continue;
            }

            $total_occurrences += $occurrences;
            $items[] = [
                'id' => $post_id,
                'title' => get_the_title( $post_id ),
                'type' => $post->post_type,
                'status' => $post->post_status,
				// Open a supported WPHAVE editor in a separate tab. Unsupported
				// post types expose no edit action in the rename workflow.
				'editUrl' => WPHAVE_Safe_Link::http(
					WPHAVE_Frontend_Editor_Routing::get_editor_url($post_id, $post->post_type),
				),
				// Only project a published URL when its content is public.
				'viewUrl' => $post->post_status === 'publish'
					? WPHAVE_Safe_Link::http( get_permalink( $post_id ) )
					: '',
                'occurrences' => $occurrences,
            ];
        }

        return [
            'totalPosts' => count( $items ),
            'totalOccurrences' => $total_occurrences,
            'items' => $items,
			'hasMore' => $has_more,
        ];
    }

    /**
     * Replace the content usage.
     *
     * @param array $replacements
     * @param array $post_ids
     * @return array
     */

    private static function replace_content_usage( $replacements, $post_ids ) {
        global $wpdb;
        $updated = [];
        $skipped = [];
        $total_replacements = 0;
        $scan = self::scan_content_usage( $replacements );
		if ( is_wp_error( $scan ) ) {
			// The file rename has already committed. Let the REST facade report
			// incomplete content coverage instead of claiming zero matches.
			throw new RuntimeException( 'Attachment content scan failed.' );
		}
        $allowed_post_ids = array_map( 'absint', wp_list_pluck( $scan['items'], 'id' ) );
		$pattern = self::content_url_pattern( array_keys( $replacements ) );

		// SECURITY INVARIANT: Attachment URL replacement is closed over the exact
		// editable posts discovered by the current scan, and object permission is
		// checked again immediately before each content mutation.
        foreach( array_unique( $post_ids ) as $post_id ) {
            if( ! in_array( $post_id, $allowed_post_ids, true ) ) {
                $skipped[] = $post_id;
                continue;
            }

            $post = get_post( $post_id );

            if( ! $post || ! current_user_can( 'edit_post', $post_id ) ) {
                $skipped[] = $post_id;
                continue;
            }

            $before = $post->post_content;
			// CONTENT-REVISION INVARIANT: The scan and get_post() may observe a
			// cached revision. Never submit a rewrite based on bytes that are
			// already different in the canonical posts table.
		$live_content = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT post_content FROM {$wpdb->posts} WHERE ID = %d LIMIT 1",
					$post_id,
				),
			);
			if ( ! empty( $wpdb->last_error ) ) {
				// CONTENT INVARIANT: A failed revision lookup cannot authorize
				// overwriting a post whose current bytes are unknown.
				$skipped[] = $post_id;
				continue;
			}
			if (!is_string($live_content) || $live_content !== $before) {
				$skipped[] = $post_id;
				continue;
			}
            $count = 0;
			$after = preg_replace_callback(
				$pattern,
				static function ( $match ) use ( $replacements ) {
					return $replacements[ $match[0] ];
				},
				$before,
				-1,
				$count
			);

			if( ! is_string( $after ) || $count < 1 || $after === $before ) {
                $skipped[] = $post_id;
                continue;
            }

            $result = wp_update_post( [
                'ID' => $post_id,
                // WordPress unslashes post input. Preserve the existing block
                // JSON escapes when only attachment URLs are being rewritten.
                'post_content' => wp_slash( $after ),
            ], true );

            if( is_wp_error( $result ) ) {
                $skipped[] = $post_id;
                continue;
            }
			// CONTENT-COMMIT INVARIANT: wp_update_post() may return a numeric ID
			// while a filter discards or rewrites the requested content. Report a
			// replacement only when the exact new bytes are canonical.
			if ( $after !== get_post_field( 'post_content', $post_id, 'raw' ) ) {
				$skipped[] = $post_id;
				continue;
			}

            $total_replacements += $count;
            $updated[] = [
                'id' => $post_id,
                'title' => get_the_title( $post_id ),
                'replacements' => $count,
            ];
        }

        return [
            'totalPosts' => count( $updated ),
            'totalReplacements' => $total_replacements,
            'updated' => $updated,
            'skipped' => $skipped,
        ];
    }

    /**
     * Find posts whose content contains any requested URL.
     *
     * @param array $urls
     * @return array
     */

    private static function find_posts_containing_urls( $urls ) {
        global $wpdb;

        $post_types = array_values( array_diff( get_post_types( [ 'public' => true ], 'names' ), [ 'attachment' ] ) );
        $post_statuses = array_values( array_diff( get_post_stati( [ 'internal' => false ], 'names' ), [ 'trash', 'auto-draft' ] ) );
        $url_wheres = [];

        if( empty( $post_types ) || empty( $post_statuses ) || empty( $urls ) ) {
            return [];
        }

        foreach( $urls as $url ) {
            $url_wheres[] = $wpdb->prepare( 'post_content LIKE %s', '%' . $wpdb->esc_like( $url ) . '%' );
        }

        $type_placeholders = implode( ', ', array_fill( 0, count( $post_types ), '%s' ) );
        $status_placeholders = implode( ', ', array_fill( 0, count( $post_statuses ), '%s' ) );
        $sql = "SELECT ID FROM {$wpdb->posts} WHERE post_type IN ({$type_placeholders}) AND post_status IN ({$status_placeholders}) AND (" . implode( ' OR ', $url_wheres ) . ') ORDER BY post_modified_gmt DESC LIMIT 201';

        $post_ids = $wpdb->get_col( $wpdb->prepare( $sql, array_merge( $post_types, $post_statuses ) ) );
		if ( ! empty( $wpdb->last_error ) || ! is_array( $post_ids ) ) {
			// COVERAGE INVARIANT: A failed query is not an empty usage scan.
			return new WP_Error(
				'wphave_attachment_content_scan_failed',
				__( 'Media references could not be scanned. Retry before updating content.', 'wphave' ),
				[ 'status' => 500 ],
			);
		}

		return array_map( 'absint', $post_ids );
    }

    /**
     * Count the content occurrences.
     *
     * @param string $content
     * @param array $urls
     * @return int
     */

    private static function content_url_pattern( $urls ) {
		// URL-BOUNDARY INVARIANT: A media URL must not match a longer filename or
		// path. One alternation also prevents a new URL from being rewritten again.
		if ( ! $urls ) {
			return '~(?!)~';
		}
		usort( $urls, static function ( $left, $right ) {
			return strlen( $right ) <=> strlen( $left );
		} );
		$alternatives = array_map( static function ( $url ) {
			return preg_quote( $url, '~' );
		}, $urls );
		return '~(?<![A-Za-z0-9%._/-])(?:' . implode( '|', $alternatives ) . ')(?![A-Za-z0-9%_/-]|\\.[A-Za-z0-9])~';
    }

    private static function count_content_occurrences( $content, $pattern ) {
		$count = preg_match_all( $pattern, $content );
		return $count === false ? 0 : $count;
    }

}
