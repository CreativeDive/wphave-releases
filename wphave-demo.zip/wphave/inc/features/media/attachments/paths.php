<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Attachment_File_Paths {

    /**
     * Return an upload basedir.
     *
     * @return string
     */

    private static function get_upload_basedir() {
        $upload_dir = wp_get_upload_dir();

        if( empty( $upload_dir['basedir'] ) ) {
            return '';
        }

        $real = realpath( $upload_dir['basedir'] );

        return $real ? wp_normalize_path( $real ) : wp_normalize_path( $upload_dir['basedir'] );
    }

    /**
     * Normalize an existing upload path.
     *
     * @param string $path
     * @return string
     */

    private static function normalize_existing_upload_path( $path ) {
        // SECURITY INVARIANT: An existing attachment path is authorized by its
        // canonical filesystem location, not its caller-supplied spelling. Links
        // and traversal segments therefore cannot escape the uploads root.
        $real = realpath( $path );

        if( ! $real ) {
            return '';
        }

        $path = wp_normalize_path( $real );

        return self::is_path_inside_uploads( $path ) ? $path : '';
    }

    /**
     * Normalize the plan source path.
     *
     * @param string $path
     * @return string
     */

    private static function normalize_plan_source_path( $path ) {
        $existing = self::normalize_existing_upload_path( $path );

        if( $existing ) {
            return $existing;
        }

        return self::normalize_target_upload_path( $path );
    }

    /**
     * Normalize the target upload path.
     *
     * @param string $path
     * @return string
     */

    private static function normalize_target_upload_path( $path ) {
        // SECURITY INVARIANT: A not-yet-created target inherits authority only
        // from its canonical existing parent and a basename-only final component.
        // The untrusted full target path is never used for containment checks.
        $directory = realpath( dirname( $path ) );

        if( ! $directory ) {
            return '';
        }

        $path = trailingslashit( wp_normalize_path( $directory ) ) . wp_basename( $path );

        return self::is_path_inside_uploads( $path ) ? $path : '';
    }

    /**
     * Determine whether path inside uploads.
     *
     * @param string $path
     * @return bool
     */

    private static function is_path_inside_uploads( $path ) {
        $basedir = self::get_upload_basedir();

        if( ! $basedir || ! $path ) {
            return false;
        }

        $path = wp_normalize_path( $path );
        $basedir = trailingslashit( $basedir );

        return strpos( $path, $basedir ) === 0;
    }

    /**
     * Return the relative upload path.
     *
     * @param string $path
     * @return string
     */

    private static function get_relative_upload_path( $path ) {
        $basedir = self::get_upload_basedir();
        $path = self::normalize_target_upload_path( $path );

        if( ! $basedir || ! $path || strpos( $path, trailingslashit( $basedir ) ) !== 0 ) {
            return '';
        }

        return ltrim( substr( $path, strlen( trailingslashit( $basedir ) ) ), '/' );
    }

    /**
     * Return the MIME family.
     *
     * @param string $mime
     * @return string
     */

    private static function get_mime_family( $mime ) {
        $parts = explode( '/', (string) $mime );

        return $parts[0] ?? '';
    }

    /**
     * Normalize the file extension.
     *
     * @param string $extension
     * @return string
     */

    private static function normalize_file_extension( $extension ) {
        $extension = strtolower( (string) $extension );
        $aliases = [
            'jpeg' => 'jpg',
            'tiff' => 'tif',
        ];

        return $aliases[ $extension ] ?? $extension;
    }

    /**
     * Rename a single attachment derivative file.
     *
     * @param string $filename
     * @param string $current_stem
     * @param string $new_stem
     * @return string
     */

    private static function rename_derivative_file( $filename, $current_stem, $new_stem ) {
        $extension = pathinfo( $filename, PATHINFO_EXTENSION );
        $stem = pathinfo( $filename, PATHINFO_FILENAME );

        if( $stem === $current_stem ) {
            return $new_stem . '.' . $extension;
        }

        if( strpos( $stem, $current_stem . '-' ) === 0 ) {
            return $new_stem . substr( $stem, strlen( $current_stem ) ) . '.' . $extension;
        }

        return $new_stem . '-' . $stem . '.' . $extension;
    }

}
