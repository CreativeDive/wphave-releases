<?php

/** Raw WordPress attachment registration check for a canonical uploads path. */
final class WPHAVE_Attachment_File_Registration {
	public static function has_any_owner(string $relative, string $absolute): bool {
		return self::find_owner($relative, $absolute, null);
	}

	public static function has_other_owner(
		string $relative,
		string $absolute,
		int $attachment_id,
	): bool {
		if ($relative === '' || $absolute === '' || $attachment_id < 1) {
			return true;
		}
		return self::find_owner($relative, $absolute, $attachment_id);
	}

	private static function find_owner(string $relative, string $absolute, ?int $excluded_id): bool {
		if ($relative === '' || $absolute === '') {
			return true;
		}

		global $wpdb;
		$uploads = wp_get_upload_dir();
		$configured_absolute = !empty($uploads['basedir'])
			? trailingslashit($uploads['basedir']) . $relative
			: $absolute;
		// OWNERSHIP INVARIANT: WordPress accepts both uploads-relative and
		// absolute _wp_attached_file values. The configured root may itself
		// be an alias of the canonical root (for example /var on macOS).
		$owner_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value IN (%s, %s, %s)" .
					($excluded_id === null ? '' : ' AND post_id <> %d') .
					' LIMIT 1',
				...array_merge(
					['_wp_attached_file', $relative, $absolute, $configured_absolute],
					$excluded_id === null ? [] : [$excluded_id],
				),
			),
		);

		// OWNERSHIP INVARIANT: A failed postmeta lookup is not proof that a
		// pathname is unclaimed. Block publication and rollback on DB errors.
		if (!empty($wpdb->last_error)) {
			return true;
		}

		return null !== $owner_id;
	}
}
