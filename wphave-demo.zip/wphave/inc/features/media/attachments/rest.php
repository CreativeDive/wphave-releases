<?php

require_once dirname(__DIR__, 3) . '/features/security/exact-id-list.php';

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Attachment_File_REST {

    /**
     * Registers preview, apply and content-scan routes for attachment file
     * rename operations and the safe replace endpoint.
     */

    public static function register_rest_routes() {
        register_rest_route( 'wphave/v1', '/media/(?P<id>\d+)/file/rename-preview', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [ __CLASS__, 'rest_rename_preview' ],
            'permission_callback' => [ __CLASS__, 'can_manage_attachment_file' ],
            'args' => [
                'id' => [
                    'type' => 'integer',
                    'required' => true,
                    'sanitize_callback' => 'absint',
                ],
                'filename' => [
                    'type' => 'string',
                    'required' => true,
                    'sanitize_callback' => 'sanitize_text_field',
                ],
            ],
        ] );

        register_rest_route( 'wphave/v1', '/media/(?P<id>\d+)/file/rename', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [ __CLASS__, 'rest_rename' ],
            'permission_callback' => [ __CLASS__, 'can_manage_attachment_file' ],
            'args' => [
                'id' => [
                    'type' => 'integer',
                    'required' => true,
                    'sanitize_callback' => 'absint',
                ],
                'filename' => [
                    'type' => 'string',
                    'required' => true,
                    'sanitize_callback' => 'sanitize_text_field',
                ],
                'posts' => [
                    'type' => 'array',
                    'required' => false,
                    'maxItems' => 200,
                    'items' => [
                        'type' => 'integer',
                    ],
                ],
            ],
        ] );

        register_rest_route( 'wphave/v1', '/media/(?P<id>\d+)/file/rename-content-scan', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [ __CLASS__, 'rest_rename_content_scan' ],
            'permission_callback' => [ __CLASS__, 'can_manage_attachment_file' ],
            'args' => [
                'id' => [
                    'type' => 'integer',
                    'required' => true,
                    'sanitize_callback' => 'absint',
                ],
                'filename' => [
                    'type' => 'string',
                    'required' => true,
                    'sanitize_callback' => 'sanitize_text_field',
                ],
            ],
        ] );

        register_rest_route( 'wphave/v1', '/media/(?P<id>\d+)/file/replace', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [ __CLASS__, 'rest_replace' ],
            'permission_callback' => [ __CLASS__, 'can_manage_attachment_file' ],
            'args' => [
                'id' => [
                    'type' => 'integer',
                    'required' => true,
                    'sanitize_callback' => 'absint',
                ],
            ],
        ] );

        register_rest_route( 'wphave/v1', '/media/(?P<id>\d+)/image/edit', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [ __CLASS__, 'rest_edit_image' ],
            'permission_callback' => [ __CLASS__, 'can_manage_attachment_file' ],
            'args' => [
                'id' => [ 'type' => 'integer', 'required' => true, 'sanitize_callback' => 'absint' ],
                'mode' => [ 'type' => 'string', 'required' => true, 'enum' => [ 'copy', 'replace' ] ],
                'operations' => [ 'type' => 'array', 'required' => true ],
                'expectedModified' => [ 'type' => 'integer', 'required' => true, 'sanitize_callback' => 'absint' ],
                'details' => [ 'type' => 'object', 'required' => false ],
            ],
        ] );

        register_rest_route( 'wphave/v1', '/media/(?P<id>\d+)/image/editor', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [ __CLASS__, 'rest_image_editor_state' ],
            'permission_callback' => [ __CLASS__, 'can_manage_attachment_file' ],
            'args' => [ 'id' => [ 'type' => 'integer', 'required' => true, 'sanitize_callback' => 'absint' ] ],
        ] );

    }

    /**
     * Determine whether manage attachment file.
     *
     * @param WP_REST_Request $request
     * @return bool|WP_Error
     */

    public static function can_manage_attachment_file( WP_REST_Request $request ) {
        $attachment_id = absint( $request->get_param( 'id' ) );
        $post = get_post( $attachment_id );

        if( ! $post || $post->post_type !== 'attachment' ) {
            return new WP_Error( 'wphave_invalid_attachment', __( 'The requested attachment could not be found.', 'wphave' ), [ 'status' => 404 ] );
        }

        // SECURITY INVARIANT: General upload permission never grants mutation of
        // another attachment. File operations require both media capability and
        // WordPress's object-level edit permission for the exact attachment.
        return self::current_user_can_manage_attachment_file( $attachment_id );
    }

    /** Return the live capability decision for one validated attachment. */

    private static function current_user_can_manage_attachment_file( $attachment_id ) {
        return current_user_can( 'upload_files' ) && current_user_can( 'edit_post', absint( $attachment_id ) );
    }

    private static function require_attachment_file_permission( WP_REST_Request $request ) {
        // AUTHORIZATION INVARIANT: Object authorization belongs at the final
        // public callback as well as the REST route. The exact attachment ID is
        // re-evaluated immediately before any metadata or filesystem access.
        $permission = self::can_manage_attachment_file( $request );

        if( is_wp_error( $permission ) ) {
            return $permission;
        }

        if( ! $permission ) {
            return new WP_Error( 'wphave_attachment_file_forbidden', __( 'You are not allowed to manage this media file.', 'wphave' ), [ 'status' => 403 ] );
        }

        return true;
    }

    /**
     * Handle the rename preview REST request.
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */

    public static function rest_rename_preview( WP_REST_Request $request ) {
        $authorization = self::require_attachment_file_permission( $request );

        if( is_wp_error( $authorization ) ) {
            return $authorization;
        }

        $attachment_id = absint( $request->get_param( 'id' ) );
        $filename = $request->get_param( 'filename' );
        $validation = self::validate_attachment( $attachment_id );

        if( is_wp_error( $validation ) ) {
            return $validation;
        }

        $main_file = get_attached_file( $attachment_id );
        $new_basename = self::prepare_new_basename( $filename, $main_file );

        if( is_wp_error( $new_basename ) ) {
            return $new_basename;
        }

        $files = self::collect_attachment_files( $attachment_id );
        $preview = self::build_rename_plan( $files, $main_file, $new_basename );
        $has_conflicts = ! empty( array_filter( $preview, function( $file ) {
            return ! empty( $file['conflict'] );
        } ) );

        return rest_ensure_response( [
            'id' => $attachment_id,
            'title' => get_the_title( $attachment_id ),
            'currentFile' => wp_basename( $main_file ),
            'newFile' => $new_basename,
            'hasConflicts' => $has_conflicts,
            'files' => self::sanitize_plan_for_response( $preview ),
        ] );
    }

    /**
     * Handle the rename REST request.
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */

    public static function rest_rename( WP_REST_Request $request ) {
        $authorization = self::require_attachment_file_permission( $request );

        if( is_wp_error( $authorization ) ) {
            return $authorization;
        }

        $attachment_id = absint( $request->get_param( 'id' ) );
        $filename = $request->get_param( 'filename' );
		$raw_post_ids = $request->get_param( 'posts' );
		// CONTENT-MUTATION INVARIANT: Route schema is only an early gate. A direct
		// callback cannot make the replacement scan copy an unbounded ID list.
		$post_ids = WPHAVE_Exact_ID_List::normalize( $raw_post_ids ?? [], 200, true );
		if ( null === $post_ids ) {
			return new WP_Error(
				'wphave_attachment_posts_invalid',
				__( 'The selected posts are invalid or too numerous.', 'wphave' ),
				[ 'status' => 400 ]
			);
		}
        $replacements = [];

        if( ! empty( $post_ids ) ) {
            $replacements = self::build_content_replacements( $attachment_id, $filename );

            if( is_wp_error( $replacements ) ) {
                return $replacements;
            }
        }

        $result = self::rename_attachment_files( $attachment_id, $filename );

        if( is_wp_error( $result ) ) {
            return $result;
        }

        if( ! empty( $post_ids ) ) {
            $result['content'] = self::replace_content_usage( $replacements, $post_ids );
        }

        return rest_ensure_response( $result );
    }

    /**
     * Handle the rename content scan REST request.
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */

    public static function rest_rename_content_scan( WP_REST_Request $request ) {
        $authorization = self::require_attachment_file_permission( $request );

        if( is_wp_error( $authorization ) ) {
            return $authorization;
        }

        $attachment_id = absint( $request->get_param( 'id' ) );
        $filename = $request->get_param( 'filename' );
        $replacements = self::build_content_replacements( $attachment_id, $filename );

        if( is_wp_error( $replacements ) ) {
            return $replacements;
        }

        return rest_ensure_response( self::scan_content_usage( $replacements ) );
    }

    /**
     * Handle the replace REST request.
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */

    public static function rest_replace( WP_REST_Request $request ) {
        $authorization = self::require_attachment_file_permission( $request );

        if( is_wp_error( $authorization ) ) {
            return $authorization;
        }

        $attachment_id = absint( $request->get_param( 'id' ) );
        $files = $request->get_file_params();
        $result = self::replace_attachment_file( $attachment_id, $files['file'] ?? null );

        if( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response( $result );
    }

    public static function rest_edit_image( WP_REST_Request $request ) {
        $authorization = self::require_attachment_file_permission( $request );

        if( is_wp_error( $authorization ) ) {
            return $authorization;
        }

        $result = self::edit_attachment_image(
            absint( $request->get_param( 'id' ) ),
            (array) $request->get_param( 'operations' ),
            (string) $request->get_param( 'mode' ),
            absint( $request->get_param( 'expectedModified' ) ),
            (array) $request->get_param( 'details' )
        );

        return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
    }

    public static function rest_image_editor_state( WP_REST_Request $request ) {
        $authorization = self::require_attachment_file_permission( $request );

        if( is_wp_error( $authorization ) ) {
            return $authorization;
        }

        $attachment_id = absint( $request->get_param( 'id' ) );
        $file = self::normalize_existing_upload_path( get_attached_file( $attachment_id ) );
        $size = $file ? wp_getimagesize( $file ) : false;

        if( ! $file || ! $size ) return new WP_Error( 'wphave_image_editor_unavailable', __( 'The image cannot be opened for editing.', 'wphave' ), [ 'status' => 400 ] );

        return rest_ensure_response( [
            'id' => $attachment_id,
            'url' => wp_get_attachment_url( $attachment_id ),
            'width' => (int) $size[0],
            'height' => (int) $size[1],
            'modified' => (int) filemtime( $file ),
            'mime' => get_post_mime_type( $attachment_id ),
        ] );
    }

}
