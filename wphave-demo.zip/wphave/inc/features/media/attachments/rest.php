<?php

require_once dirname(__DIR__, 3) . '/features/security/exact-id-list.php';
require_once dirname(__DIR__) . '/images/size-file-identity.php';

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Attachment_File_REST {

    /**
     * Registers preview, apply and content-scan routes for attachment file
     * rename operations and the safe replace endpoint.
     */

    public static function register_rest_routes() {
        register_rest_route( 'wphave/v1', '/media/(?P<id>\d+)/image/size-availability', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [ __CLASS__, 'rest_image_size_availability' ],
            'permission_callback' => [ __CLASS__, 'can_manage_attachment_file' ],
            'args' => [
                'id' => [
                    'type' => 'integer',
                    'required' => true,
                    'sanitize_callback' => 'absint',
                ],
            ],
        ] );

        register_rest_route( 'wphave/v1', '/media/(?P<id>\d+)/file/rename-preview', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [ __CLASS__, 'rest_rename_preview' ],
            'permission_callback' => [ __CLASS__, 'can_manage_attachment_file' ],
            'args' => [
                'id' => [
                    'type' => 'integer',
                    'required' => true,
                    'sanitize_callback' => 'absint',
                ],
                'filename' => [
                    'type' => 'string',
                    'required' => true,
                    'sanitize_callback' => 'sanitize_text_field',
                ],
            ],
        ] );

        register_rest_route( 'wphave/v1', '/media/(?P<id>\d+)/file/rename', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [ __CLASS__, 'rest_rename' ],
            'permission_callback' => [ __CLASS__, 'can_manage_attachment_file' ],
            'args' => [
                'id' => [
                    'type' => 'integer',
                    'required' => true,
                    'sanitize_callback' => 'absint',
                ],
                'filename' => [
                    'type' => 'string',
                    'required' => true,
                    'sanitize_callback' => 'sanitize_text_field',
                ],
                'posts' => [
                    'type' => 'array',
                    'required' => false,
                    'maxItems' => 200,
                    'items' => [
                        'type' => 'integer',
                    ],
                ],
            ],
        ] );

        register_rest_route( 'wphave/v1', '/media/(?P<id>\d+)/file/rename-content-scan', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [ __CLASS__, 'rest_rename_content_scan' ],
            'permission_callback' => [ __CLASS__, 'can_manage_attachment_file' ],
            'args' => [
                'id' => [
                    'type' => 'integer',
                    'required' => true,
                    'sanitize_callback' => 'absint',
                ],
                'filename' => [
                    'type' => 'string',
                    'required' => true,
                    'sanitize_callback' => 'sanitize_text_field',
                ],
            ],
        ] );

        register_rest_route( 'wphave/v1', '/media/(?P<id>\d+)/file/replace', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [ __CLASS__, 'rest_replace' ],
            'permission_callback' => [ __CLASS__, 'can_manage_attachment_file' ],
            'args' => [
                'id' => [
                    'type' => 'integer',
                    'required' => true,
                    'sanitize_callback' => 'absint',
                ],
            ],
        ] );

        register_rest_route( 'wphave/v1', '/media/(?P<id>\d+)/image/edit', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [ __CLASS__, 'rest_edit_image' ],
            'permission_callback' => [ __CLASS__, 'can_manage_attachment_file' ],
            'args' => [
                'id' => [ 'type' => 'integer', 'required' => true, 'sanitize_callback' => 'absint' ],
                'mode' => [ 'type' => 'string', 'required' => true, 'enum' => [ 'copy', 'replace' ] ],
                'operations' => [ 'type' => 'array', 'required' => true ],
                'expectedModified' => [ 'type' => 'integer', 'required' => true, 'sanitize_callback' => 'absint' ],
                'expectedChecksum' => [ 'type' => 'string', 'required' => true, 'pattern' => '^[a-f0-9]{64}$' ],
                'details' => [ 'type' => 'object', 'required' => false ],
                'quality' => [ 'type' => 'integer', 'required' => false, 'minimum' => 40, 'maximum' => 100 ],
                'outputFormat' => [ 'type' => 'string', 'required' => false, 'enum' => [ 'webp' ] ],
                'expectedPreviewChecksum' => [ 'type' => 'string', 'required' => false, 'pattern' => '^[a-f0-9]{64}$' ],
            ],
        ] );

        register_rest_route( 'wphave/v1', '/media/(?P<id>\d+)/image/editor', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [ __CLASS__, 'rest_image_editor_state' ],
            'permission_callback' => [ __CLASS__, 'can_manage_attachment_file' ],
            'args' => [ 'id' => [ 'type' => 'integer', 'required' => true, 'sanitize_callback' => 'absint' ] ],
        ] );

        register_rest_route( 'wphave/v1', '/media/(?P<id>\d+)/image/compression-preview', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [ __CLASS__, 'rest_image_compression_preview' ],
            'permission_callback' => [ __CLASS__, 'can_manage_attachment_file' ],
            'args' => [
                'id' => [ 'type' => 'integer', 'required' => true, 'sanitize_callback' => 'absint' ],
                'quality' => [ 'type' => 'integer', 'required' => true, 'minimum' => 40, 'maximum' => 100 ],
                'outputFormat' => [ 'type' => 'string', 'required' => false, 'enum' => [ 'webp' ] ],
                'expectedChecksum' => [ 'type' => 'string', 'required' => true, 'pattern' => '^[a-f0-9]{64}$' ],
            ],
        ] );

    }

    /**
     * Determine whether manage attachment file.
     *
     * @param WP_REST_Request $request
     * @return bool|WP_Error
     */

    public static function can_manage_attachment_file( WP_REST_Request $request ) {
        $attachment_id = absint( $request->get_param( 'id' ) );
        $post = get_post( $attachment_id );

        if( ! $post || $post->post_type !== 'attachment' ) {
            return new WP_Error( 'wphave_invalid_attachment', __( 'The requested attachment could not be found.', 'wphave' ), [ 'status' => 404 ] );
        }

        // SECURITY INVARIANT: General upload permission never grants mutation of
        // another attachment. File operations require both media capability and
        // WordPress's object-level edit permission for the exact attachment.
        return self::current_user_can_manage_attachment_file( $attachment_id );
    }

    /** Return the live capability decision for one validated attachment. */

    private static function current_user_can_manage_attachment_file( $attachment_id ) {
        return current_user_can( 'upload_files' ) && current_user_can( 'edit_post', absint( $attachment_id ) );
    }

    private static function require_attachment_file_permission( WP_REST_Request $request, ?string $action = null ) {
        // AUTHORIZATION INVARIANT: Object authorization belongs at the final
        // public callback as well as the REST route. The exact attachment ID is
        // re-evaluated immediately before any metadata or filesystem access.
        $permission = self::can_manage_attachment_file( $request );

        if( is_wp_error( $permission ) ) {
            return $permission;
        }

        if( ! $permission ) {
            return new WP_Error( 'wphave_attachment_file_forbidden', __( 'You are not allowed to manage this media file.', 'wphave' ), [ 'status' => 403 ] );
        }

        // POLICY INVARIANT: File-action settings are an additional fail-closed
        // site policy, never a substitute for attachment-specific capabilities.
        // Recheck at the callback so direct invocations cannot bypass it.
        if ( null !== $action && ! self::is_file_action_allowed( $action ) ) {
            return new WP_Error( 'wphave_media_file_action_disabled', __( 'This file action is disabled in Media Settings.', 'wphave' ), [ 'status' => 403 ] );
        }

        return true;
    }

    private static function is_file_action_allowed( string $action ): bool {
        if ( ! in_array( $action, [ 'replace', 'compress', 'edit', 'rename' ], true ) ) {
            return false;
        }

        $settings = wphave_data_get( 'site_settings', 'general.media.allowed_file_actions', [] );
        return is_array( $settings ) && isset( $settings[ $action ] ) && true === $settings[ $action ];
    }

    /** Check the files named by current attachment metadata without modifying it. */
    public static function rest_image_size_availability( WP_REST_Request $request ) {
        $permission = self::require_attachment_file_permission( $request );
        if ( is_wp_error( $permission ) ) {
            return $permission;
        }

        $attachment_id = absint( $request->get_param( 'id' ) );
        // INVENTORY INVARIANT: A filtered alias or symlink is not proof that
        // the registered local attachment file can be opened safely.
        $original_file = get_attached_file( $attachment_id, true );
        // INVENTORY INVARIANT: A metadata display filter cannot add paths
        // whose existence is then exposed as this attachment's image sizes.
        $metadata = get_post_meta( $attachment_id, '_wp_attachment_metadata', true );
        $sizes = is_array( $metadata ) && isset( $metadata['sizes'] ) && is_array( $metadata['sizes'] )
            ? $metadata['sizes']
            : [];
        // A malformed metadata map must not turn one read request into an
        // unbounded sequence of filesystem probes or misleading partial results.
        if ( count( $sizes ) > 128 ) {
            return new WP_Error( 'wphave_image_size_inventory_too_large', __( 'The image size inventory could not be verified.', 'wphave' ), [ 'status' => 400 ] );
        }
        $original_available = $original_file
            && self::normalize_existing_upload_path( $original_file )
            && ! is_link( $original_file )
            && is_file( $original_file ) && is_readable( $original_file )
            && ! self::is_registered_other_attachment_file( $original_file, $attachment_id );
        $files = [];

        foreach ( $sizes as $name => $size ) {
            $filename = is_array( $size ) && isset( $size['file'] ) && is_string( $size['file'] )
                ? $size['file']
                : '';
            // SIZE PATH INVARIANT: WordPress writes intermediate files beside
            // the original. Metadata cannot authorize probes of arbitrary files.
			$candidate = $original_available && WPHAVE_Media_Image_Size_File_Identity::matches_generated_size(
				$original_file,
				$size,
			)
                ? dirname( $original_file ) . DIRECTORY_SEPARATOR . $filename
                : '';
			$files[ $name ] = $candidate && self::normalize_existing_upload_path( $candidate )
                && ! is_link( $candidate )
                && is_file( $candidate )
				&& is_readable( $candidate )
				&& ! self::is_registered_other_attachment_file( $candidate, $attachment_id );
        }

        return [
            'id' => $attachment_id,
            'original' => $original_available,
            'files' => $files,
        ];
    }

    /**
     * Handle the rename preview REST request.
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */

    public static function rest_rename_preview( WP_REST_Request $request ) {
        $authorization = self::require_attachment_file_permission( $request, 'rename' );

        if( is_wp_error( $authorization ) ) {
            return $authorization;
        }

        $attachment_id = absint( $request->get_param( 'id' ) );
        $filename = $request->get_param( 'filename' );
        $validation = self::validate_attachment( $attachment_id );

        if( is_wp_error( $validation ) ) {
            return $validation;
        }

        // PREVIEW INVARIANT: Show the same registered source used by the commit.
        $main_file = get_attached_file( $attachment_id, true );
        $new_basename = self::prepare_new_basename( $filename, $main_file );

        if( is_wp_error( $new_basename ) ) {
            return $new_basename;
        }

        $files = self::collect_attachment_files( $attachment_id );
        if ( is_wp_error( $files ) ) {
            return $files;
        }
        $preview = self::build_rename_plan( $files, $main_file, $new_basename, (int) $attachment_id );
		$coverage = self::validate_rename_metadata_coverage(
			get_post_meta( $attachment_id, '_wp_attachment_metadata', true ),
			$preview
		);
		if ( is_wp_error( $coverage ) ) {
			return $coverage;
		}
        $has_conflicts = ! empty( array_filter( $preview, function( $file ) {
            return ! empty( $file['conflict'] );
        } ) );

        return rest_ensure_response( [
            'id' => $attachment_id,
            'title' => get_the_title( $attachment_id ),
            'currentFile' => wp_basename( $main_file ),
            'newFile' => $new_basename,
            'hasConflicts' => $has_conflicts,
            'files' => self::sanitize_plan_for_response( $preview ),
        ] );
    }

    /**
     * Handle the rename REST request.
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */

    public static function rest_rename( WP_REST_Request $request ) {
        $authorization = self::require_attachment_file_permission( $request, 'rename' );

        if( is_wp_error( $authorization ) ) {
            return $authorization;
        }

        $attachment_id = absint( $request->get_param( 'id' ) );
        $filename = $request->get_param( 'filename' );
		$raw_post_ids = $request->get_param( 'posts' );
		// CONTENT-MUTATION INVARIANT: Route schema is only an early gate. A direct
		// callback cannot make the replacement scan copy an unbounded ID list.
		$post_ids = WPHAVE_Exact_ID_List::normalize( $raw_post_ids ?? [], 200, true );
		if ( null === $post_ids ) {
			return new WP_Error(
				'wphave_attachment_posts_invalid',
				__( 'The selected posts are invalid or too numerous.', 'wphave' ),
				[ 'status' => 400 ]
			);
		}
        $result = self::rename_attachment_files( $attachment_id, $filename, ! empty( $post_ids ) );

        if( is_wp_error( $result ) ) {
            return $result;
        }

        // RESPONSE INVARIANT: The internal URL map is bound to the committed
        // file plan, but must not become part of the public rename response.
        $replacements = $result['_contentReplacements'] ?? [];
        unset( $result['_contentReplacements'] );
        if( ! empty( $post_ids ) ) {
			// COMMIT INVARIANT: The file rename has already committed. A throwing
			// content hook must not turn that success into an ambiguous REST failure.
			// Earlier post writes may have succeeded, so report uncertain coverage.
			try {
				$result['content'] = self::replace_content_usage( $replacements, $post_ids );
				if ( ! empty( $result['content']['skipped'] ) ) {
					// COMMIT INVARIANT: A post skipped after the file commit still
					// contains its old URL. Report partial coverage explicitly.
					$result['contentUpdateIncomplete'] = true;
				}
			} catch ( Throwable $error ) {
				$result['contentUpdateIncomplete'] = true;
			}
        }

        return rest_ensure_response( $result );
    }

    /**
     * Handle the rename content scan REST request.
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */

    public static function rest_rename_content_scan( WP_REST_Request $request ) {
        $authorization = self::require_attachment_file_permission( $request, 'rename' );

        if( is_wp_error( $authorization ) ) {
            return $authorization;
        }

        $attachment_id = absint( $request->get_param( 'id' ) );
        $filename = $request->get_param( 'filename' );
        $replacements = self::build_content_replacements( $attachment_id, $filename );

        if( is_wp_error( $replacements ) ) {
            return $replacements;
        }

        $scan = self::scan_content_usage( $replacements );
		return is_wp_error( $scan ) ? $scan : rest_ensure_response( $scan );
    }

    /**
     * Handle the replace REST request.
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */

    public static function rest_replace( WP_REST_Request $request ) {
        $authorization = self::require_attachment_file_permission( $request, 'replace' );

        if( is_wp_error( $authorization ) ) {
            return $authorization;
        }

        $attachment_id = absint( $request->get_param( 'id' ) );
        $files = $request->get_file_params();
        $result = self::replace_attachment_file( $attachment_id, $files['file'] ?? null );

        if( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response( $result );
    }

    /** Route transforms and quality edits through the attachment image editor service. */
    public static function rest_edit_image( WP_REST_Request $request ) {
        // Empty operations are reserved for quality/format processing; editor
        // transformations must carry at least one operation.
        $operations = $request->get_param( 'operations' );
        $action = is_array( $operations ) && empty( $operations ) ? 'compress' : 'edit';
        $authorization = self::require_attachment_file_permission( $request, $action );

        if( is_wp_error( $authorization ) ) {
            return $authorization;
        }

        // POLICY INVARIANT: An edit request cannot smuggle compression or
        // conversion parameters past the separate compression setting.
        if ( 'edit' === $action && ( $request->has_param( 'quality' ) || $request->has_param( 'outputFormat' ) ) && ! self::is_file_action_allowed( 'compress' ) ) {
            return new WP_Error( 'wphave_media_file_action_disabled', __( 'This file action is disabled in Media Settings.', 'wphave' ), [ 'status' => 403 ] );
        }

        $result = self::edit_attachment_image(
            absint( $request->get_param( 'id' ) ),
            (array) $request->get_param( 'operations' ),
            (string) $request->get_param( 'mode' ),
            absint( $request->get_param( 'expectedModified' ) ),
            (string) $request->get_param( 'expectedChecksum' ),
            (array) $request->get_param( 'details' ),
            $request->has_param( 'quality' ) ? $request->get_param( 'quality' ) : null,
            $request->has_param( 'outputFormat' ) ? $request->get_param( 'outputFormat' ) : null,
            $request->has_param( 'expectedPreviewChecksum' ) ? $request->get_param( 'expectedPreviewChecksum' ) : null
        );

        return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
    }

    /** Return a read-only encoded preview after the compression action gate. */
    public static function rest_image_compression_preview( WP_REST_Request $request ) {
        $authorization = self::require_attachment_file_permission( $request, 'compress' );
        if ( is_wp_error( $authorization ) ) {
            return $authorization;
        }
        $result = self::preview_attachment_compression(
            absint( $request->get_param( 'id' ) ),
            $request->get_param( 'quality' ),
            $request->get_param( 'expectedChecksum' ),
            $request->has_param( 'outputFormat' ) ? $request->get_param( 'outputFormat' ) : null
        );
        return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
    }

    public static function rest_image_editor_state( WP_REST_Request $request ) {
        $authorization = self::require_attachment_file_permission( $request );

        if( is_wp_error( $authorization ) ) {
            return $authorization;
        }

        if ( ! self::is_file_action_allowed( 'edit' ) && ! self::is_file_action_allowed( 'compress' ) ) {
            return new WP_Error( 'wphave_media_file_action_disabled', __( 'This file action is disabled in Media Settings.', 'wphave' ), [ 'status' => 403 ] );
        }

        $attachment_id = absint( $request->get_param( 'id' ) );
        // SOURCE INVARIANT: GET and POST share MIME, pixel, byte and checksum
        // gates; a preview must never authorize a source save would reject.
        $inspected = self::inspect_image_editor_source( $attachment_id );
        if ( is_wp_error( $inspected ) ) {
            return $inspected;
        }

        return rest_ensure_response( [
            'id' => $attachment_id,
            'url' => wp_get_attachment_url( $attachment_id ),
            'width' => $inspected['width'],
            'height' => $inspected['height'],
            'bytes' => $inspected['bytes'],
            'modified' => $inspected['modified'],
            'checksum' => $inspected['checksum'],
            'mime' => $inspected['mime'],
            'defaultQuality' => min(
                100,
                max(40, (int) (wphave_data_get('site_settings', 'general.media.image_compression') ?: 82))
            ),
        ] );
    }

}
