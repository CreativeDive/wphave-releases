<?php

require_once __DIR__ . '/rest.php';
require_once __DIR__ . '/operations.php';
require_once __DIR__ . '/content.php';
require_once __DIR__ . '/backups.php';
require_once __DIR__ . '/paths.php';
require_once __DIR__ . '/../images/editor.php';


/**
 * Handles safe attachment file operations for the wphave media admin UI.
 *
 * The file manager deliberately exposes a preview-first flow. Mutating
 * requests are only allowed after WordPress capability checks, upload
 * directory boundary checks and target conflict checks have passed.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WPHAVE_Attachment_File_Manager' ) ) :

	class WPHAVE_Attachment_File_Manager {

	use WPHAVE_Attachment_File_REST,
		WPHAVE_Attachment_File_Operations,
		WPHAVE_Attachment_File_Content,
		WPHAVE_Attachment_File_Backups,
		WPHAVE_Attachment_File_Paths,
		WPHAVE_Attachment_Image_Editor;

		/**
		 * Registers the REST route bootstrap on WordPress' REST API init hook.
		 */

		public static function init() {
			add_action( 'rest_api_init', [ __CLASS__, 'register_rest_routes' ] );
		}

	}

endif;

WPHAVE_Attachment_File_Manager::init();
