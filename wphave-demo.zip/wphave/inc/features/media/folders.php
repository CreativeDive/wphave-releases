<?php

/**
 * Provides virtual media folders for attachments using a hierarchical
 * taxonomy and a small REST API for folder tree operations.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WPHAVE_Media_Folders' ) ) :

	class WPHAVE_Media_Folders {

		const TAXONOMY = 'wphave_media_folder';
		const REST_NAMESPACE = 'wphave/v1';
		const MAX_FOLDER_DEPTH = 3;

		/**
		 * Register the component hooks.
		 *
		 * @return void
		 */

		public static function init() {
			add_action( 'init', array( __CLASS__, 'register_taxonomy' ), 20 );
			add_action( 'rest_api_init', array( __CLASS__, 'register_rest_routes' ) );
			add_filter( 'rest_attachment_query', array( __CLASS__, 'filter_attachment_query' ), 10, 2 );
		}

		/**
		 * Register the taxonomy.
		 *
		 * @return void
		 */

		public static function register_taxonomy() {
			register_taxonomy(
				self::TAXONOMY,
				array( 'attachment' ),
				array(
					'labels' => array(
						'name' => __( 'Media Folders', 'wphave' ),
						'singular_name' => __( 'Media Folder', 'wphave' ),
						'search_items' => __( 'Search media folders', 'wphave' ),
						'all_items' => __( 'All media folders', 'wphave' ),
						'parent_item' => __( 'Parent media folder', 'wphave' ),
						'parent_item_colon' => __( 'Parent media folder:', 'wphave' ),
						'edit_item' => __( 'Edit media folder', 'wphave' ),
						'update_item' => __( 'Update media folder', 'wphave' ),
						'add_new_item' => __( 'Add new media folder', 'wphave' ),
						'new_item_name' => __( 'New media folder name', 'wphave' ),
						'menu_name' => __( 'Media Folders', 'wphave' ),
					),
					'public' => false,
					'show_ui' => false,
					'show_admin_column' => false,
					'show_in_rest' => true,
					'rest_base' => self::TAXONOMY,
					'hierarchical' => true,
					'query_var' => self::TAXONOMY,
					'rewrite' => false,
					'capabilities' => array(
						'manage_terms' => 'upload_files',
						'edit_terms' => 'upload_files',
						'delete_terms' => 'upload_files',
						'assign_terms' => 'upload_files',
					),
				)
			);
		}

		/**
		 * Register the REST API routes.
		 *
		 * @return void
		 */

		public static function register_rest_routes() {
			register_rest_route(
				self::REST_NAMESPACE,
				'/media-folders',
				array(
					array(
						'methods' => WP_REST_Server::READABLE,
						'callback' => array( __CLASS__, 'get_folders' ),
						'permission_callback' => array( __CLASS__, 'can_read' ),
					),
					array(
						'methods' => WP_REST_Server::CREATABLE,
						'callback' => array( __CLASS__, 'create_folder' ),
						'permission_callback' => array( __CLASS__, 'can_manage' ),
						'args' => array(
							'name' => array(
								'required' => true,
								'type' => 'string',
								'sanitize_callback' => 'sanitize_text_field',
							),
							'parent' => array(
								'type' => 'integer',
								'default' => 0,
							),
						),
					),
				)
			);

			register_rest_route(
				self::REST_NAMESPACE,
				'/media-folders/(?P<id>\d+)',
				array(
					array(
						'methods' => WP_REST_Server::EDITABLE,
						'callback' => array( __CLASS__, 'update_folder' ),
						'permission_callback' => array( __CLASS__, 'can_manage' ),
						'args' => array(
							'name' => array(
								'type' => 'string',
								'sanitize_callback' => 'sanitize_text_field',
							),
							'parent' => array(
								'type' => 'integer',
							),
						),
					),
					array(
						'methods' => WP_REST_Server::DELETABLE,
						'callback' => array( __CLASS__, 'delete_folder' ),
						'permission_callback' => array( __CLASS__, 'can_manage' ),
					),
				)
			);

			register_rest_route(
				self::REST_NAMESPACE,
				'/media-folders/tree',
				array(
					'methods' => WP_REST_Server::EDITABLE,
					'callback' => array( __CLASS__, 'update_tree' ),
					'permission_callback' => array( __CLASS__, 'can_manage' ),
					'args' => array(
						'tree' => array(
							'required' => true,
							'type' => 'array',
						),
					),
				)
			);

			register_rest_route(
				self::REST_NAMESPACE,
				'/media-folders/assign',
				array(
					'methods' => WP_REST_Server::CREATABLE,
					'callback' => array( __CLASS__, 'assign_attachment' ),
					'permission_callback' => array( __CLASS__, 'can_assign' ),
					'args' => array(
						'attachmentId' => array(
							'type' => 'integer',
						),
						'attachmentIds' => array(
							'type' => 'array',
						),
						'folderId' => array(
							'type' => 'integer',
						),
					),
				)
			);
		}

		/**
		 * Determine whether the current user may read media folders.
		 *
		 * @return bool
		 */

		public static function can_read() {
			return current_user_can( 'upload_files' );
		}

		/**
		 * Determine whether the current user can manage media folders.
		 */

		public static function can_manage() {
			return current_user_can( 'upload_files' );
		}

		/**
		 * Determine whether the current user can assign.
		 */

		public static function can_assign() {
			return current_user_can( 'upload_files' );
		}

		private static function require_capability( $allowed ) {
			// AUTHORIZATION INVARIANT: REST permission callbacks are an early gate.
			// Public folder callbacks repeat their canonical policy immediately before
			// reading or mutating the shared media-folder taxonomy.
			if ( ! $allowed ) {
				return new WP_Error(
					'wphave_media_folder_forbidden',
					__( 'You are not allowed to manage media folders.', 'wphave' ),
					array( 'status' => 403 )
				);
			}

			return true;
		}

		/**
		 * Return the folders.
		 *
		 * @param WP_REST_Request $request
		 * @return WP_REST_Response|WP_Error
		 */

		public static function get_folders( $request ) {
			$authorization = self::require_capability( self::can_read() );

			if ( is_wp_error( $authorization ) ) {
				return $authorization;
			}

			$data = self::get_folders_data();
			if ( is_wp_error( $data ) ) {
				return $data;
			}

			// AUTHORIZATION/MEDIA-FOLDER-LIST-RESPONSE INVARIANT: Folder terms,
			// relationship counts, metadata and attachment aggregates cross filterable
			// WordPress and database boundaries. Revalidate upload authority after the
			// complete private projection and immediately before releasing it.
			$authorization = self::require_capability( self::can_read() );
			if ( is_wp_error( $authorization ) ) {
				return $authorization;
			}

			return rest_ensure_response( $data );
		}

		/**
		 * Return folders data.
		 */

		private static function get_folders_data() {
			$terms = get_terms(
				array(
					'taxonomy' => self::TAXONOMY,
					'hide_empty' => false,
					'meta_key' => 'wphave_order',
					'orderby' => 'meta_value_num',
					'order' => 'ASC',
				)
			);

			if( is_wp_error( $terms ) ) {
				return $terms;
			}

			$term_ids = wp_list_pluck( $terms, 'term_id' );
			$counts = self::get_folder_attachment_counts( $term_ids );
			$items = array();

			foreach( $terms as $term ) {
				$items[] = self::prepare_folder_item( $term, $counts[ $term->term_id ] ?? 0 );
			}

			return array(
				'items' => $items,
				'tree' => self::build_tree( $items ),
				'taxonomy' => self::TAXONOMY,
				'totalCount' => self::get_total_attachment_count(),
				'unassignedCount' => self::get_unassigned_attachment_count(),
				'typeCounts' => self::get_attachment_type_counts(),
			);
		}

		/**
		 * Create the folder.
		 *
		 * @param WP_REST_Request $request
		 * @return WP_REST_Response|WP_Error
		 */

		public static function create_folder( $request ) {
			$authorization = self::require_capability( self::can_manage() );

			if ( is_wp_error( $authorization ) ) {
				return $authorization;
			}

			$name = sanitize_text_field( $request->get_param( 'name' ) );
			$parent = absint( $request->get_param( 'parent' ) );

			if( ! $name ) {
				return new WP_Error( 'wphave_media_folder_missing_name', __( 'Folder name is required.', 'wphave' ), array( 'status' => 400 ) );
			}

			if( $parent && ! term_exists( $parent, self::TAXONOMY ) ) {
				return new WP_Error( 'wphave_media_folder_invalid_parent', __( 'Parent folder is invalid.', 'wphave' ), array( 'status' => 400 ) );
			}

			if( $parent && self::get_folder_depth( $parent ) >= self::MAX_FOLDER_DEPTH ) {
				return new WP_Error( 'wphave_media_folder_max_depth', __( 'Maximum folder depth reached.', 'wphave' ), array( 'status' => 400 ) );
			}

			// AUTHORIZATION/TOCTOU INVARIANT: REST and callback sanitizers execute
			// extension code before taxonomy insertion. Recheck the canonical folder
			// capability after all validation and immediately before creating the term.
			$authorization = self::require_capability( self::can_manage() );

			if ( is_wp_error( $authorization ) ) {
				return $authorization;
			}

			$result = wp_insert_term(
				$name,
				self::TAXONOMY,
				array(
					'parent' => $parent,
				)
			);

			if( is_wp_error( $result ) ) {
				return $result;
			}

			$term_id = absint( $result['term_id'] );
			$order = self::get_next_order( $parent );
			update_term_meta( $term_id, 'wphave_order', $order );

			// DATA/ROLLBACK INVARIANT: A folder exists only with its explicit canonical
			// ordering metadata. A missing zero value is not equivalent to stored zero;
			// an unconfirmed initial order deletes the uncommitted taxonomy term.
			if(
				! metadata_exists( 'term', $term_id, 'wphave_order' )
				|| $order !== (int) get_term_meta( $term_id, 'wphave_order', true )
			) {
				wp_delete_term( $term_id, self::TAXONOMY );

				return new WP_Error(
					'wphave_media_folder_order_write_failed',
					__( 'The media folder could not be created.', 'wphave' ),
					array( 'status' => 500 )
				);
			}

			return self::get_folder_response( $term_id );
		}

		/**
		 * Update the folder.
		 *
		 * @param WP_REST_Request $request
		 * @return WP_REST_Response|WP_Error
		 */

		public static function update_folder( $request ) {
			$authorization = self::require_capability( self::can_manage() );

			if ( is_wp_error( $authorization ) ) {
				return $authorization;
			}

			$term_id = absint( $request['id'] );
			$args = array();

			if( $request->has_param( 'name' ) ) {
				$args['name'] = sanitize_text_field( $request->get_param( 'name' ) );
			}

			if( $request->has_param( 'parent' ) ) {
				$parent = absint( $request->get_param( 'parent' ) );

				if( $parent === $term_id || self::is_descendant_folder( $parent, $term_id ) ) {
					return new WP_Error( 'wphave_media_folder_invalid_parent', __( 'A folder cannot be moved into itself or one of its subfolders.', 'wphave' ), array( 'status' => 400 ) );
				}

				if( $parent && ! term_exists( $parent, self::TAXONOMY ) ) {
					return new WP_Error( 'wphave_media_folder_invalid_parent', __( 'Parent folder is invalid.', 'wphave' ), array( 'status' => 400 ) );
				}

				if( $parent && self::get_folder_depth( $parent ) + 1 + self::get_folder_subtree_depth( $term_id ) > self::MAX_FOLDER_DEPTH ) {
					return new WP_Error( 'wphave_media_folder_max_depth', __( 'Maximum folder depth reached.', 'wphave' ), array( 'status' => 400 ) );
				}

				$args['parent'] = $parent;
			}

			if( empty( $args ) ) {
				return self::get_folder_response( $term_id );
			}

			// AUTHORIZATION/TOCTOU INVARIANT: Folder updates cross sanitizer and
			// hierarchy-query extension points after REST admission. Repeat the shared
			// taxonomy capability immediately before mutating the existing term.
			$authorization = self::require_capability( self::can_manage() );

			if ( is_wp_error( $authorization ) ) {
				return $authorization;
			}

			$result = wp_update_term( $term_id, self::TAXONOMY, $args );

			if( is_wp_error( $result ) ) {
				return $result;
			}

			return self::get_folder_response( $term_id );
		}

		/**
		 * Delete the folder.
		 *
		 * @param WP_REST_Request $request
		 * @return WP_REST_Response|WP_Error
		 */

		public static function delete_folder( $request ) {
			$authorization = self::require_capability( self::can_manage() );

			if ( is_wp_error( $authorization ) ) {
				return $authorization;
			}

			$term_id = absint( $request['id'] );
			$children = get_terms(
				array(
					'taxonomy' => self::TAXONOMY,
					'parent' => $term_id,
					'hide_empty' => false,
					'fields' => 'ids',
				)
			);

			if( is_wp_error( $children ) ) {
				return $children;
			}

			if( ! empty( $children ) ) {
				return new WP_Error( 'wphave_media_folder_has_children', __( 'Delete subfolders before deleting this folder.', 'wphave' ), array( 'status' => 400 ) );
			}

			$term = get_term( $term_id, self::TAXONOMY );

			if( is_wp_error( $term ) ) {
				return $term;
			}

			if( ! $term ) {
				return new WP_Error( 'wphave_media_folder_not_found', __( 'Folder not found.', 'wphave' ), array( 'status' => 404 ) );
			}

			if( self::get_folder_attachment_count( $term_id ) > 0 ) {
				return new WP_Error( 'wphave_media_folder_not_empty', __( 'Move media files out of this folder before deleting it.', 'wphave' ), array( 'status' => 400 ) );
			}

			// AUTHORIZATION/TOCTOU INVARIANT: Child, term and attachment-count queries
			// cross extension boundaries after route admission. Recheck folder-management
			// authority immediately before deleting the shared taxonomy object.
			$authorization = self::require_capability( self::can_manage() );

			if ( is_wp_error( $authorization ) ) {
				return $authorization;
			}

			$result = wp_delete_term( $term_id, self::TAXONOMY );

			if( is_wp_error( $result ) ) {
				return $result;
			}

			return rest_ensure_response( array( 'deleted' => (bool) $result ) );
		}

		/**
		 * Update the tree.
		 *
		 * @param WP_REST_Request $request
		 * @return WP_REST_Response|WP_Error
		 */

		public static function update_tree( $request ) {
			$authorization = self::require_capability( self::can_manage() );

			if ( is_wp_error( $authorization ) ) {
				return $authorization;
			}

			$tree = $request->get_param( 'tree' );

			if( ! is_array( $tree ) ) {
				return new WP_Error( 'wphave_media_folder_invalid_tree', __( 'Folder tree is invalid.', 'wphave' ), array( 'status' => 400 ) );
			}

			$validation = self::validate_tree_items( $tree );

			if( is_wp_error( $validation ) ) {
				return $validation;
			}

			$previous_tree_state = self::snapshot_tree_items( $tree );

			// AUTHORIZATION/TOCTOU INVARIANT: Snapshot reads cross term and metadata
			// filters. Recheck the shared folder capability after the complete snapshot
			// and before save_tree_items() can publish the first parent or order change.
			$authorization = self::require_capability( self::can_manage() );

			if ( is_wp_error( $authorization ) ) {
				return $authorization;
			}

			$result = self::save_tree_items( $tree, 0 );

			if( is_wp_error( $result ) ) {
				// DATA/ROLLBACK INVARIANT: A submitted folder-tree projection is one
				// logical commit. If any parent or ordering write cannot be confirmed,
				// restore every touched term before returning a fail-closed response.
				self::restore_tree_items( $previous_tree_state );

				return new WP_Error(
					'wphave_media_folder_tree_update_failed',
					__( 'The media folder tree could not be saved.', 'wphave' ),
					array( 'status' => 500 )
				);
			}

			return self::get_folders( $request );
		}

		/**
		 * Assign an attachment.
		 *
		 * @param WP_REST_Request $request
		 * @return WP_REST_Response|WP_Error
		 */

		public static function assign_attachment( $request ) {
			$authorization = self::require_capability( self::can_assign() );

			if ( is_wp_error( $authorization ) ) {
				return $authorization;
			}

			$attachment_id = absint( $request->get_param( 'attachmentId' ) );
			$attachment_ids = $request->get_param( 'attachmentIds' );
			$folder_id = absint( $request->get_param( 'folderId' ) );

			if( empty( $attachment_ids ) ) {
				$attachment_ids = $attachment_id ? array( $attachment_id ) : array();
			}

			$attachment_ids = array_values(
				array_filter(
					array_map( 'absint', (array) $attachment_ids )
				)
			);

			if( empty( $attachment_ids ) ) {
				return new WP_Error( 'wphave_media_folder_invalid_attachment', __( 'Attachment is invalid.', 'wphave' ), array( 'status' => 400 ) );
			}

			if( $folder_id && ! term_exists( $folder_id, self::TAXONOMY ) ) {
				return new WP_Error( 'wphave_media_folder_invalid_folder', __( 'Folder is invalid.', 'wphave' ), array( 'status' => 400 ) );
			}

			$previous_folder_ids = array();

			foreach( $attachment_ids as $id ) {
				// SECURITY INVARIANT: Validate the complete attachment batch and every
				// object-level edit capability before changing the first folder assignment.
				if( get_post_type( $id ) !== 'attachment' ) {
					return new WP_Error( 'wphave_media_folder_invalid_attachment', __( 'Attachment is invalid.', 'wphave' ), array( 'status' => 400 ) );
				}

				if( ! current_user_can( 'edit_post', $id ) ) {
					return new WP_Error( 'wphave_media_folder_attachment_forbidden', __( 'You are not allowed to move this media file.', 'wphave' ), array( 'status' => 403 ) );
				}

				$existing_folder_ids = wp_get_object_terms( $id, self::TAXONOMY, array( 'fields' => 'ids' ) );

				if( is_wp_error( $existing_folder_ids ) ) {
					return $existing_folder_ids;
				}

				$previous_folder_ids[ $id ] = array_map( 'absint', $existing_folder_ids );
			}

			// AUTHORIZATION/TOCTOU INVARIANT: Relationship snapshot queries execute
			// extension filters. After the complete batch snapshot and before its first
			// write, recheck both global assignment authority and every exact object.
			$authorization = self::require_capability( self::can_assign() );

			if ( is_wp_error( $authorization ) ) {
				return $authorization;
			}

			foreach( $attachment_ids as $id ) {
				if( ! current_user_can( 'edit_post', $id ) ) {
					return new WP_Error( 'wphave_media_folder_attachment_forbidden', __( 'You are not allowed to move this media file.', 'wphave' ), array( 'status' => 403 ) );
				}
			}

			$expected_folder_ids = $folder_id ? array( $folder_id ) : array();

			foreach( $attachment_ids as $id ) {
				$result = wp_set_object_terms( $id, $folder_id ? array( $folder_id ) : array(), self::TAXONOMY, false );
				$persisted_folder_ids = wp_get_object_terms( $id, self::TAXONOMY, array( 'fields' => 'ids' ) );
				$commit_failed = is_wp_error( $result ) || is_wp_error( $persisted_folder_ids );

				if( ! $commit_failed ) {
					$persisted_folder_ids = array_map( 'absint', $persisted_folder_ids );
					sort( $persisted_folder_ids );
					$commit_failed = $expected_folder_ids !== $persisted_folder_ids;
				}

				if( $commit_failed ) {
					// DATA/ROLLBACK INVARIANT: A folder-assignment batch either publishes
					// the exact requested relationship set for every attachment or restores
					// every attachment snapshot before reporting a fail-closed error.
					foreach( $previous_folder_ids as $rollback_id => $rollback_folder_ids ) {
						wp_set_object_terms( $rollback_id, $rollback_folder_ids, self::TAXONOMY, false );
					}

					return new WP_Error(
						'wphave_media_folder_assignment_failed',
						__( 'The media folder assignment could not be saved.', 'wphave' ),
						array( 'status' => 500 )
					);
				}
			}

			$folders = self::get_folders_data();

			if ( is_wp_error( $folders ) ) {
				return $folders;
			}

			// AUTHORIZATION/MEDIA-FOLDER-ASSIGN-RESPONSE INVARIANT: A committed
			// assignment does not lease its earlier authority into the private folder
			// inventory response. Revalidate both the shared assignment capability and
			// every exact attachment after the complete aggregate projection and
			// immediately before releasing any result.
			$authorization = self::require_capability( self::can_assign() );

			if ( is_wp_error( $authorization ) ) {
				return $authorization;
			}

			foreach( $attachment_ids as $id ) {
				if( ! current_user_can( 'edit_post', $id ) ) {
					return new WP_Error( 'wphave_media_folder_attachment_forbidden', __( 'You are not allowed to move this media file.', 'wphave' ), array( 'status' => 403 ) );
				}
			}

			return rest_ensure_response(
				array(
					'attachmentId' => count( $attachment_ids ) === 1 ? $attachment_ids[0] : null,
					'attachmentIds' => $attachment_ids,
					'folderId' => $folder_id ?: null,
					'count' => count( $attachment_ids ),
					'folders' => $folders,
				)
			);
		}

		/**
		 * Filter attachment query.
		 *
		 * @param array $args Function arguments.
		 * @param WP_REST_Request $request REST request.
		 */

		public static function filter_attachment_query( $args, $request ) {
			if( ! $request->get_param( 'wphave_media_folder_unassigned' ) ) {
				return $args;
			}

			unset( $args[ self::TAXONOMY ] );
			unset( $args['wphave_media_folder_unassigned'] );

			if( empty( $args['tax_query'] ) || ! is_array( $args['tax_query'] ) ) {
				$args['tax_query'] = array();
			}

			$args['tax_query'][] = array(
				'taxonomy' => self::TAXONOMY,
				'operator' => 'NOT EXISTS',
			);

			return $args;
		}

		/**
		 * Return folder response.
		 *
		 * @param int $term_id Term ID.
		 */

		private static function get_folder_response( $term_id ) {
			$term = get_term( $term_id, self::TAXONOMY );

			if( is_wp_error( $term ) ) {
				return $term;
			}

			if( ! $term ) {
				return new WP_Error( 'wphave_media_folder_not_found', __( 'Folder not found.', 'wphave' ), array( 'status' => 404 ) );
			}

			$item = self::prepare_folder_item( $term );

			// AUTHORIZATION/MEDIA-FOLDER-MUTATION-RESPONSE INVARIANT: Creating,
			// updating or reading an unchanged mutation target does not lease its
			// earlier authority across term, metadata and attachment-count projection.
			// Revalidate the canonical management capability immediately before the
			// private folder item is released.
			$authorization = self::require_capability( self::can_manage() );

			if ( is_wp_error( $authorization ) ) {
				return $authorization;
			}

			return rest_ensure_response( $item );
		}

		/**
		 * Prepare folder item.
		 *
		 * @param mixed $term Term.
		 * @param int $count Count.
		 */

		private static function prepare_folder_item( $term, $count = null ) {
			return array(
				'id' => (int) $term->term_id,
				'key' => (string) $term->term_id,
				'label' => html_entity_decode( $term->name, ENT_QUOTES, get_bloginfo( 'charset' ) ),
				'name' => html_entity_decode( $term->name, ENT_QUOTES, get_bloginfo( 'charset' ) ),
				'slug' => $term->slug,
				'parent' => (int) $term->parent,
				'parentId' => $term->parent ? (int) $term->parent : null,
				'count' => $count === null ? self::get_folder_attachment_count( $term->term_id ) : (int) $count,
				'order' => (int) get_term_meta( $term->term_id, 'wphave_order', true ),
				'children' => array(),
			);
		}

		/**
		 * Return folder attachment counts.
		 *
		 * @param mixed $term_ids Term IDs.
		 */

		private static function get_folder_attachment_counts( $term_ids ) {
			global $wpdb;

			$term_ids = array_values(
				array_filter(
					array_map( 'absint', (array) $term_ids )
				)
			);

			if( empty( $term_ids ) ) {
				return array();
			}

			$placeholders = implode( ',', array_fill( 0, count( $term_ids ), '%d' ) );
			$prepared = $wpdb->prepare(
				"SELECT tt.term_id, COUNT(DISTINCT p.ID) AS attachment_count
				FROM {$wpdb->term_taxonomy} tt
				INNER JOIN {$wpdb->term_relationships} tr ON tr.term_taxonomy_id = tt.term_taxonomy_id
				INNER JOIN {$wpdb->posts} p ON p.ID = tr.object_id
				WHERE tt.taxonomy = %s
				AND tt.term_id IN ($placeholders)
				AND p.post_type = 'attachment'
				AND p.post_status = 'inherit'
				GROUP BY tt.term_id",
				array_merge( array( self::TAXONOMY ), $term_ids )
			);
			$rows = $wpdb->get_results( $prepared );
			$counts = array_fill_keys( $term_ids, 0 );

			foreach( $rows as $row ) {
				$counts[ (int) $row->term_id ] = (int) $row->attachment_count;
			}

			return $counts;
		}

		/**
		 * Return folder attachment count.
		 *
		 * @param int $term_id Term ID.
		 */

		private static function get_folder_attachment_count( $term_id ) {
			$counts = self::get_folder_attachment_counts( array( $term_id ) );

			return (int) ( $counts[ absint( $term_id ) ] ?? 0 );
		}

		/**
		 * Return total attachment count.
		 */

		private static function get_total_attachment_count() {
			global $wpdb;

			return (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(ID)
					FROM {$wpdb->posts}
					WHERE post_type = %s
					AND post_status = %s",
					'attachment',
					'inherit'
				)
			);
		}

		/**
		 * Return attachment counts grouped by MIME type.
		 *
		 * The media folder response already accompanies the attachment collection.
		 * Keeping the aggregate here avoids loading every paginated attachment or
		 * issuing a dedicated statistics request in the media screen.
		 *
		 * @return array
		 */

		private static function get_attachment_type_counts() {
			global $wpdb;

			$rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT post_mime_type AS mime_type, COUNT(ID) AS attachment_count
					FROM {$wpdb->posts}
					WHERE post_type = %s
					AND post_status = %s
					AND post_mime_type != %s
					GROUP BY post_mime_type
					ORDER BY attachment_count DESC, post_mime_type ASC",
					'attachment',
					'inherit',
					''
				)
			);

			return array_map(
				static function( $row ) {
					return array(
						'mimeType' => sanitize_mime_type( $row->mime_type ),
						'count' => (int) $row->attachment_count,
					);
				},
				$rows ?: array()
			);
		}

		/**
		 * Return unassigned attachment count.
		 */

		private static function get_unassigned_attachment_count() {
			global $wpdb;

			return (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(p.ID)
					FROM {$wpdb->posts} p
					LEFT JOIN (
						{$wpdb->term_relationships} tr
						INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id AND tt.taxonomy = %s
					) ON tr.object_id = p.ID
					WHERE p.post_type = %s
					AND p.post_status = %s
					AND tt.term_taxonomy_id IS NULL",
					self::TAXONOMY,
					'attachment',
					'inherit'
				)
			);
		}

		/**
		 * Build tree.
		 *
		 * @param array $items Items.
		 */

		private static function build_tree( array $items ) {
			$map = array();
			$tree = array();

			foreach( $items as $item ) {
				$item['children'] = array();
				$map[ $item['id'] ] = $item;
			}

			foreach( $map as $id => &$item ) {
				$parent = $item['parent'];

				if( $parent && isset( $map[ $parent ] ) ) {
					$map[ $parent ]['children'][] = &$item;
				} else {
					$tree[] = &$item;
				}
			}

			return $tree;
		}

		/**
		 * Validate tree items.
		 *
		 * @param array $items Items.
		 * @param mixed $parent Parent.
		 * @param mixed $seen Seen.
		 * @param mixed $depth Depth.
		 */

		private static function validate_tree_items( array $items, $parent = 0, &$seen = array(), $depth = 0 ) {
			foreach( $items as $item ) {
				$term_id = absint( $item['id'] ?? 0 );

				if( $depth > self::MAX_FOLDER_DEPTH ) {
					return new WP_Error( 'wphave_media_folder_max_depth', __( 'Maximum folder depth reached.', 'wphave' ), array( 'status' => 400 ) );
				}

				if( ! $term_id ) {
					return new WP_Error( 'wphave_media_folder_invalid_tree', __( 'Folder tree contains an invalid item.', 'wphave' ), array( 'status' => 400 ) );
				}

				if( isset( $seen[ $term_id ] ) ) {
					return new WP_Error( 'wphave_media_folder_duplicate_tree_item', __( 'Folder tree contains duplicate items.', 'wphave' ), array( 'status' => 400 ) );
				}

				if( ! term_exists( $term_id, self::TAXONOMY ) ) {
					return new WP_Error( 'wphave_media_folder_not_found', __( 'Folder not found.', 'wphave' ), array( 'status' => 404 ) );
				}

				if( $parent && self::is_descendant_folder( $parent, $term_id ) ) {
					return new WP_Error( 'wphave_media_folder_invalid_tree', __( 'A folder cannot be moved into itself or one of its subfolders.', 'wphave' ), array( 'status' => 400 ) );
				}

				$seen[ $term_id ] = true;

				if( ! empty( $item['children'] ) && is_array( $item['children'] ) ) {
					$validation = self::validate_tree_items( $item['children'], $term_id, $seen, $depth + 1 );

					if( is_wp_error( $validation ) ) {
						return $validation;
					}
				}
			}

			return true;
		}

		/**
		 * Return folder depth.
		 *
		 * @param int $term_id Term ID.
		 */

		private static function get_folder_depth( $term_id ) {
			$ancestors = get_ancestors( $term_id, self::TAXONOMY, 'taxonomy' );
			return count( $ancestors );
		}

		/**
		 * Return the maximum depth below a folder.
		 *
		 * @param int $term_id Term ID.
		 * @return int
		 */

		private static function get_folder_subtree_depth( $term_id ) {
			$children = get_terms(
				array(
					'taxonomy' => self::TAXONOMY,
					'parent' => absint( $term_id ),
					'hide_empty' => false,
					'fields' => 'ids',
				)
			);

			if( is_wp_error( $children ) || empty( $children ) ) {
				return 0;
			}

			$depth = 0;

			foreach( $children as $child_id ) {
				$depth = max( $depth, 1 + self::get_folder_subtree_depth( $child_id ) );
			}

			return $depth;
		}

		/**
		 * Save tree items.
		 *
		 * @param array $items Items.
		 * @param mixed $parent Parent.
		 */

		private static function save_tree_items( array $items, $parent ) {
			foreach( $items as $index => $item ) {
				$term_id = absint( $item['id'] ?? 0 );

				if( ! $term_id ) {
					continue;
				}

				$updated_term = wp_update_term( $term_id, self::TAXONOMY, array( 'parent' => absint( $parent ) ) );

				if( is_wp_error( $updated_term ) ) {
					return $updated_term;
				}

				update_term_meta( $term_id, 'wphave_order', $index );
				$persisted_term = get_term( $term_id, self::TAXONOMY );

				if(
					! $persisted_term
					|| is_wp_error( $persisted_term )
					|| absint( $parent ) !== absint( $persisted_term->parent )
					|| $index !== (int) get_term_meta( $term_id, 'wphave_order', true )
				) {
					return new WP_Error( 'wphave_media_folder_tree_commit_failed' );
				}

				if( ! empty( $item['children'] ) && is_array( $item['children'] ) ) {
					$result = self::save_tree_items( $item['children'], $term_id );

					if( is_wp_error( $result ) ) {
						return $result;
					}
				}
			}

			return true;
		}

		/**
		 * Snapshot canonical state for every submitted tree item.
		 *
		 * @param array $items Items.
		 * @return array
		 */

		private static function snapshot_tree_items( array $items ) {
			$state = array();

			foreach( $items as $item ) {
				$term_id = absint( $item['id'] ?? 0 );
				$term = get_term( $term_id, self::TAXONOMY );

				if( $term && ! is_wp_error( $term ) ) {
					$state[ $term_id ] = array(
						'parent' => absint( $term->parent ),
						'has_order' => metadata_exists( 'term', $term_id, 'wphave_order' ),
						'order' => get_term_meta( $term_id, 'wphave_order', true ),
					);
				}

				if( ! empty( $item['children'] ) && is_array( $item['children'] ) ) {
					$state += self::snapshot_tree_items( $item['children'] );
				}
			}

			return $state;
		}

		/**
		 * Restore a previously captured tree projection in reverse mutation order.
		 *
		 * @param array $state State.
		 */

		private static function restore_tree_items( array $state ) {
			foreach( array_reverse( $state, true ) as $term_id => $item_state ) {
				wp_update_term( $term_id, self::TAXONOMY, array( 'parent' => $item_state['parent'] ) );

				if( $item_state['has_order'] ) {
					update_term_meta( $term_id, 'wphave_order', $item_state['order'] );
				} else {
					delete_term_meta( $term_id, 'wphave_order' );
				}
			}
		}

		/**
		 * Return next order.
		 *
		 * @param mixed $parent Parent.
		 */

		private static function get_next_order( $parent ) {
			$terms = get_terms(
				array(
					'taxonomy' => self::TAXONOMY,
					'parent' => absint( $parent ),
					'hide_empty' => false,
					'fields' => 'ids',
				)
			);

			return is_array( $terms ) ? count( $terms ) : 0;
		}

		/**
		 * Determine whether descendant folder.
		 *
		 * @param int $term_id Term ID.
		 * @param mixed $ancestor_id Ancestor ID.
		 */

		private static function is_descendant_folder( $term_id, $ancestor_id ) {
			$term_id = absint( $term_id );
			$ancestor_id = absint( $ancestor_id );

			while( $term_id ) {
				if( $term_id === $ancestor_id ) {
					return true;
				}

				$term = get_term( $term_id, self::TAXONOMY );

				if( ! $term || is_wp_error( $term ) ) {
					return false;
				}

				$term_id = absint( $term->parent );
			}

			return false;
		}

	}

endif;

WPHAVE_Media_Folders::init();
