<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

if( ! class_exists( 'WPHAVE_Content_Type_Validator' ) ) :

/**
 * Manage the content type validator feature.
 */

class WPHAVE_Content_Type_Validator {

	const SCHEMA_VERSION = 1;
	const POST_TYPE_PATTERN = '/^[a-z0-9_-]{1,20}$/';
	const TAXONOMY_PATTERN = '/^[a-z0-9_-]{1,32}$/';

	/**
	 * Return the complete default configuration for a custom post type.
	 *
	 * @return array Default post type configuration using the persisted schema.
	 */

	public static function post_type_defaults() {
		return array(
			'schemaVersion' => self::SCHEMA_VERSION,
			'singularName' => '',
			'description' => '',
			'public' => true,
			'publiclyQueryable' => true,
			'excludeFromSearch' => false,
			'showUi' => true,
			'showInMenu' => true,
			'showInNavMenus' => true,
			'showInRest' => true,
			'useBlockEditor' => true,
			'useDocumentEditor' => false,
			'hierarchical' => false,
			'hasArchive' => true,
			'queryVar' => true,
			'deleteWithUser' => false,
			'menuPosition' => null,
			'menuIcon' => 'admin-post',
			'supports' => array( 'title', 'editor' ),
			'taxonomies' => array(),
			'labels' => array(),
			'rewrite' => array( 'enabled' => true, 'slug' => '', 'withFront' => true, 'feeds' => true, 'pages' => true ),
			'wphave' => array( 'showInNavigation' => true ),
		);
	}

	/**
	 * Return the complete default configuration for a custom taxonomy.
	 *
	 * @return array Default taxonomy configuration using the persisted schema.
	 */

	public static function taxonomy_defaults() {
		return array(
			'schemaVersion' => self::SCHEMA_VERSION,
			'singularName' => '',
			'description' => '',
			'objectTypes' => array( 'post' ),
			'public' => true,
			'publiclyQueryable' => true,
			'showUi' => true,
			'showInMenu' => true,
			'showInNavMenus' => true,
			'showTagcloud' => true,
			'showInQuickEdit' => true,
			'showAdminColumn' => false,
			'showInRest' => true,
			'hierarchical' => false,
			'sort' => false,
			'queryVar' => true,
			'labels' => array(),
			'rewrite' => array( 'enabled' => true, 'slug' => '', 'withFront' => true, 'hierarchical' => false ),
			'defaultTerm' => array( 'enabled' => false, 'name' => '', 'slug' => '', 'description' => '' ),
		);
	}

	/**
	 * Sanitize a custom post type configuration against the supported schema.
	 *
	 * @param mixed $data Raw configuration data.
	 * @return array Sanitized post type configuration with all defaults applied.
	 */

	public static function sanitize_post_type( $data ) {
		return self::sanitize( $data, self::post_type_defaults(), 'post_type' );
	}

	/**
	 * Sanitize a custom taxonomy configuration against the supported schema.
	 *
	 * @param mixed $data Raw configuration data.
	 * @return array Sanitized taxonomy configuration with all defaults applied.
	 */

	public static function sanitize_taxonomy( $data ) {
		return self::sanitize( $data, self::taxonomy_defaults(), 'taxonomy' );
	}

	/**
	 * Upgrade a persisted definition to the current schema before validation.
	 *
	 * Persisted definitions are a public data contract. When SCHEMA_VERSION is
	 * increased, add one explicit case per previous version to this loop. Never
	 * make callers depend on the current array shape or silently rewrite a newer
	 * schema, because either change can make content types disappear on update or
	 * after a plugin downgrade.
	 *
	 * @param mixed $data Raw persisted definition.
	 * @return array|WP_Error Migrated definition or an unsupported-schema error.
	 */

	public static function migrate( $data ) {
		if( ! is_array( $data ) ) return new WP_Error( 'wphave_content_type_schema_invalid', __( 'The content type definition is invalid.', 'wphave' ) );
		$version = absint( $data['schemaVersion'] ?? 1 );
		if( $version < 1 || $version > self::SCHEMA_VERSION ) return new WP_Error( 'wphave_content_type_schema_unsupported', __( 'The content type definition uses an unsupported schema version.', 'wphave' ) );

		while( $version < self::SCHEMA_VERSION ) {
			switch( $version ) {
				// Add the v1-to-v2 transformation here before raising SCHEMA_VERSION.
				default:
					return new WP_Error( 'wphave_content_type_schema_migration_missing', __( 'The content type definition cannot be migrated.', 'wphave' ) );
			}
			$version++;
			$data['schemaVersion'] = $version;
		}

		$data['schemaVersion'] = self::SCHEMA_VERSION;
		return $data;
	}

	/**
	 * Normalize a content type configuration and discard unsupported values.
	 *
	 * @param mixed $data Raw configuration data.
	 * @param array $defaults Schema defaults and allowed top-level keys.
	 * @param string $type Configuration type: post_type or taxonomy.
	 * @return array Sanitized configuration.
	 */

	private static function sanitize( $data, $defaults, $type ) {
		$data = is_array( $data ) ? $data : array();
		$config = $defaults;
		foreach( array_intersect_key( $data, $defaults ) as $key => $value ) {
			$config[$key] = is_array( $value ) && self::is_associative_array( $value ) && is_array( $defaults[$key] )
				? array_replace_recursive( $defaults[$key], $value )
				: $value;
		}
		$boolean_keys = 'post_type' === $type
			? array( 'public', 'publiclyQueryable', 'excludeFromSearch', 'showUi', 'showInMenu', 'showInNavMenus', 'showInRest', 'useBlockEditor', 'useDocumentEditor', 'hierarchical', 'hasArchive', 'queryVar', 'deleteWithUser' )
			: array( 'public', 'publiclyQueryable', 'showUi', 'showInMenu', 'showInNavMenus', 'showTagcloud', 'showInQuickEdit', 'showAdminColumn', 'showInRest', 'hierarchical', 'sort', 'queryVar' );
		foreach( $boolean_keys as $key ) {
			$config[$key] = rest_sanitize_boolean( $config[$key] );
		}
		$config['schemaVersion'] = self::SCHEMA_VERSION;
		$config['singularName'] = sanitize_text_field( $config['singularName'] );
		$config['description'] = sanitize_textarea_field( $config['description'] );
		$config['labels'] = self::sanitize_labels( $config['labels'], 'post_type' === $type ? self::post_type_label_keys() : self::taxonomy_label_keys() );
		$config['rewrite'] = self::sanitize_rewrite( $config['rewrite'], $type );
		if( 'post_type' === $type ) {
			$allowed_supports = array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'trackbacks', 'custom-fields', 'comments', 'revisions', 'page-attributes', 'post-formats' );
			$config['supports'] = array_values( array_intersect( array_map( 'sanitize_key', (array) $config['supports'] ), $allowed_supports ) );
			$config['taxonomies'] = self::sanitize_keys( $config['taxonomies'], 32 );
			$config['menuPosition'] = null === $config['menuPosition'] || '' === $config['menuPosition'] ? null : absint( $config['menuPosition'] );
			$config['menuIcon'] = self::sanitize_menu_icon( $config['menuIcon'] );
			$config['wphave']['showInNavigation'] = rest_sanitize_boolean( $config['wphave']['showInNavigation'] ?? true );
		} else {
			$config['objectTypes'] = self::sanitize_keys( $config['objectTypes'], 20 );
			$config['defaultTerm']['enabled'] = rest_sanitize_boolean( $config['defaultTerm']['enabled'] ?? false );
			foreach( array( 'name', 'slug', 'description' ) as $key ) {
				$config['defaultTerm'][$key] = 'description' === $key ? sanitize_textarea_field( $config['defaultTerm'][$key] ?? '' ) : sanitize_text_field( $config['defaultTerm'][$key] ?? '' );
			}
		}
		return $config;
	}

	/**
	 * Determine whether an array represents a keyed configuration object.
	 *
	 * List-valued fields are atomic values in the persisted schema. In
	 * particular, an explicitly empty list must replace its defaults instead of
	 * being recursively merged with their numeric indexes.
	 *
	 * @param array $value Configuration value.
	 * @return bool Whether the value has at least one string key.
	 */

	private static function is_associative_array( $value ) {
		// DATA INTEGRITY INVARIANT: Persisted list fields are atomic; especially,
		// an explicit empty list replaces defaults instead of merging indexes.
		foreach( array_keys( $value ) as $key ) {
			if( is_string( $key ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Sanitize a Dashicon name or a restricted inline SVG menu icon.
	 *
	 * @param mixed $menu_icon Raw icon value.
	 * @return string|array Sanitized Dashicon name, SVG descriptor, or empty array.
	 */

	private static function sanitize_menu_icon( $menu_icon ) {
		if( ! is_array( $menu_icon ) ) {
			return sanitize_text_field( $menu_icon );
		}
		$allowed_svg = array(
			'svg' => array( 'xmlns' => true, 'viewbox' => true, 'width' => true, 'height' => true, 'fill' => true, 'stroke' => true, 'stroke-width' => true, 'stroke-linecap' => true, 'stroke-linejoin' => true, 'aria-hidden' => true, 'role' => true ),
			'g' => array( 'fill' => true, 'stroke' => true, 'transform' => true ),
			'path' => array( 'd' => true, 'fill' => true, 'stroke' => true, 'stroke-width' => true, 'fill-rule' => true, 'clip-rule' => true, 'transform' => true ),
			'circle' => array( 'cx' => true, 'cy' => true, 'r' => true, 'fill' => true, 'stroke' => true ),
			'ellipse' => array( 'cx' => true, 'cy' => true, 'rx' => true, 'ry' => true, 'fill' => true, 'stroke' => true ),
			'line' => array( 'x1' => true, 'x2' => true, 'y1' => true, 'y2' => true, 'stroke' => true, 'stroke-width' => true ),
			'polyline' => array( 'points' => true, 'fill' => true, 'stroke' => true, 'stroke-width' => true ),
			'polygon' => array( 'points' => true, 'fill' => true, 'stroke' => true, 'stroke-width' => true ),
			'rect' => array( 'x' => true, 'y' => true, 'width' => true, 'height' => true, 'rx' => true, 'ry' => true, 'fill' => true, 'stroke' => true ),
		);
		$svg = substr( (string) ( $menu_icon['svg'] ?? '' ), 0, 20000 );
		$svg = wp_kses( $svg, $allowed_svg );
		if( '' === $svg || 0 !== strpos( ltrim( $svg ), '<svg' ) ) {
			return array();
		}
		$svg = preg_replace( '/\sviewbox=/', ' viewBox=', $svg );
		$svg = str_replace( '"', "'", $svg );
		return array(
			'key' => sanitize_text_field( substr( (string) ( $menu_icon['key'] ?? '' ), 0, 191 ) ),
			'svg' => $svg,
		);
	}

	/**
	 * Sanitize rewrite settings for a post type or taxonomy.
	 *
	 * @param mixed $rewrite Raw rewrite configuration.
	 * @param string $type Configuration type: post_type or taxonomy.
	 * @return array Normalized rewrite configuration.
	 */

	private static function sanitize_rewrite( $rewrite, $type ) {
		$rewrite = is_array( $rewrite ) ? $rewrite : array();
		$result = array(
			'enabled' => rest_sanitize_boolean( $rewrite['enabled'] ?? true ),
			'slug' => sanitize_title( $rewrite['slug'] ?? '' ),
			'withFront' => rest_sanitize_boolean( $rewrite['withFront'] ?? true ),
		);
		if( 'post_type' === $type ) {
			$result['feeds'] = rest_sanitize_boolean( $rewrite['feeds'] ?? true );
			$result['pages'] = rest_sanitize_boolean( $rewrite['pages'] ?? true );
		} else {
			$result['hierarchical'] = rest_sanitize_boolean( $rewrite['hierarchical'] ?? false );
		}
		return $result;
	}

	/**
	 * Return label keys accepted by WordPress post type registration.
	 *
	 * @return string[] Allowed post type label keys.
	 */

	public static function post_type_label_keys() {
		return array( 'singular_name', 'menu_name', 'all_items', 'add_new', 'add_new_item', 'edit_item', 'new_item', 'view_item', 'view_items', 'search_items', 'not_found', 'not_found_in_trash', 'parent_item_colon', 'archives', 'attributes', 'insert_into_item', 'uploaded_to_this_item', 'featured_image', 'set_featured_image', 'remove_featured_image', 'use_featured_image', 'filter_items_list', 'items_list_navigation', 'items_list' );
	}

	/**
	 * Return label keys accepted by WordPress taxonomy registration.
	 *
	 * @return string[] Allowed taxonomy label keys.
	 */

	public static function taxonomy_label_keys() {
		return array( 'singular_name', 'menu_name', 'all_items', 'edit_item', 'view_item', 'update_item', 'add_new_item', 'new_item_name', 'search_items', 'not_found', 'back_to_items', 'parent_item', 'popular_items', 'separate_items_with_commas', 'parent_item_colon', 'add_or_remove_items', 'choose_from_most_used' );
	}

	/**
	 * Sanitize labels while retaining only explicitly supported keys.
	 *
	 * @param mixed $labels Raw label map.
	 * @param string[] $allowed_keys Allowed label keys.
	 * @return array Sanitized label map.
	 */

	private static function sanitize_labels( $labels, $allowed_keys ) {
		$result = array();
		foreach( (array) $labels as $key => $value ) {
			$key = sanitize_key( $key );
			if( in_array( $key, $allowed_keys, true ) && is_scalar( $value ) && strlen( (string) $value ) <= 200 ) {
				$result[$key] = sanitize_text_field( $value );
			}
		}
		return $result;
	}

	/**
	 * Sanitize, limit and deduplicate WordPress object keys.
	 *
	 * @param mixed $values Raw list of keys.
	 * @param int $max_length Maximum permitted key length.
	 * @return string[] Sanitized unique keys.
	 */

	private static function sanitize_keys( $values, $max_length ) {
		return array_values( array_unique( array_filter( array_map( function( $value ) use ( $max_length ) {
			$value = sanitize_key( $value );
			return strlen( $value ) <= $max_length ? $value : '';
		}, (array) $values ) ) ) );
	}
}

endif;
