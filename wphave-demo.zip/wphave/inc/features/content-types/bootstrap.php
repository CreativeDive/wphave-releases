<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/validator.php';
require_once __DIR__ . '/generic-ui-policy.php';

if( ! class_exists( 'WPHAVE_Content_Types' ) ) :

/**
 * Manage the content types feature.
 */

class WPHAVE_Content_Types {

	const POST_TYPE = 'wphave_post_type';
	const TAXONOMY = 'wphave_taxonomy';
	const FLUSH_OPTION = 'wphave_content_types_flush_rewrite_rules';
	private static $definition_cache = array();
	private static $block_editor_preferences = array();

	/**
	 * Register content type hooks for storage, runtime registration and cleanup.
	 *
	 * @return void
	 */

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_storage_types' ), 6 );
		add_action( 'init', array( __CLASS__, 'register_post_types' ), 20 );
		add_action( 'init', array( __CLASS__, 'register_taxonomies' ), 25 );
		add_action( 'init', array( __CLASS__, 'maybe_flush_rewrite_rules' ), 30 );
		add_filter( 'use_block_editor_for_post_type', array( __CLASS__, 'filter_block_editor_for_post_type' ), 10, 2 );
		add_filter( 'wp_insert_post_data', array( __CLASS__, 'sanitize_storage_content' ), 10, 2 );
		add_action( 'transition_post_status', array( __CLASS__, 'handle_status_change' ), 10, 3 );
		add_action( 'before_delete_post', array( __CLASS__, 'handle_delete' ), 10, 2 );
		if( defined( 'WPHAVE_FILE_PATH' ) ) {
			register_deactivation_hook( WPHAVE_FILE_PATH, array( __CLASS__, 'deactivate' ) );
		}
	}

	/**
	 * Register the private post types used to persist WPHAVE definitions.
	 *
	 * @return void
	 */

	public static function register_storage_types() {
		// AUTHORIZATION INVARIANT: Definition posts are private implementation state;
		// even their Core REST exposure is gated by wphave_manage_content_types.
		$common = array(
			'public' => false,
			'publicly_queryable' => false,
			'show_ui' => false,
			'show_in_menu' => false,
			'show_in_rest' => true,
			'rewrite' => false,
			'query_var' => false,
			'supports' => array( 'title', 'editor' ),
			'capabilities' => array(
				'read' => 'wphave_manage_content_types',
				'create_posts' => 'wphave_manage_content_types',
				'edit_posts' => 'wphave_manage_content_types',
				'edit_others_posts' => 'wphave_manage_content_types',
				'edit_published_posts' => 'wphave_manage_content_types',
				'publish_posts' => 'wphave_manage_content_types',
				'delete_posts' => 'wphave_manage_content_types',
				'delete_others_posts' => 'wphave_manage_content_types',
				'delete_published_posts' => 'wphave_manage_content_types',
			),
			'map_meta_cap' => true,
		);
		register_post_type( self::POST_TYPE, array_merge( $common, array(
			'label' => __( 'Content post types', 'wphave' ),
			'rest_base' => 'wphave-content-post-types',
		) ) );
		register_post_type( self::TAXONOMY, array_merge( $common, array(
			'label' => __( 'Content taxonomies', 'wphave' ),
			'rest_base' => 'wphave-content-taxonomies',
		) ) );
	}

	/**
	 * Sanitize JSON definition content before WordPress writes a storage post.
	 *
	 * @param array $data Slashed post data prepared by WordPress.
	 * @param array $postarr Original post data supplied to the write operation.
	 * @return array Filtered post data.
	 */

	public static function sanitize_storage_content( $data, $postarr ) {
		$post_type = $data['post_type'] ?? '';
		if( ! in_array( $post_type, array( self::POST_TYPE, self::TAXONOMY ), true ) || ! isset( $data['post_content'] ) ) {
			return $data;
		}
		$config = json_decode( wp_unslash( $data['post_content'] ), true );
		if( ! is_array( $config ) ) {
			$data['post_content'] = wp_json_encode( array() );
			return $data;
		}
		$config = WPHAVE_Content_Type_Validator::migrate( $config );
		// A downgraded plugin must preserve a newer schema byte-for-byte instead of
		// destructively sanitizing it as the current schema.
		if( is_wp_error( $config ) ) return $data;
		$config = self::POST_TYPE === $post_type ? WPHAVE_Content_Type_Validator::sanitize_post_type( $config ) : WPHAVE_Content_Type_Validator::sanitize_taxonomy( $config );
		$data['post_content'] = wp_json_encode( $config );
		return $data;
	}

	/**
	 * Retrieve stored definitions with a request-local cache.
	 *
	 * @param string $storage_type Internal definition post type.
	 * @param string|array $status Post status or list of statuses to include.
	 * @return WP_Post[] Stored definition posts.
	 */

	public static function get_definitions( $storage_type, $status = 'publish' ) {
		$cache_key = $storage_type . ':' . wp_json_encode( $status );
		if( isset( self::$definition_cache[$cache_key] ) ) return self::$definition_cache[$cache_key];
		self::$definition_cache[$cache_key] = get_posts( array(
			'post_type' => $storage_type,
			'post_status' => $status,
			'posts_per_page' => -1,
			'orderby' => 'title',
			'order' => 'ASC',
			'no_found_rows' => true,
			'suppress_filters' => true,
		) );
		return self::$definition_cache[$cache_key];
	}

	/**
	 * Clear cached definition queries after a definition changes.
	 *
	 * @return void
	 */

	public static function clear_definition_cache() {
		self::$definition_cache = array();
	}

	/**
	 * Decode the JSON configuration stored on a definition post.
	 *
	 * @param WP_Post $post Definition post.
	 * @return array Decoded configuration, or an empty array for invalid JSON.
	 */

	public static function decode( $post ) {
		$config = json_decode( (string) $post->post_content, true );
		$config = WPHAVE_Content_Type_Validator::migrate( $config );
		return is_wp_error( $config ) ? array() : $config;
	}

	/**
	 * Determine whether a definition contains a supported configuration schema.
	 *
	 * @param WP_Post $post Definition post.
	 * @return bool Whether the stored configuration is valid and supported.
	 */

	public static function has_valid_config( $post ) {
		$config = json_decode( (string) $post->post_content, true );
		return JSON_ERROR_NONE === json_last_error() && ! is_wp_error( WPHAVE_Content_Type_Validator::migrate( $config ) );
	}

	/**
	 * Register all active user-defined post types with WordPress.
	 *
	 * Invalid definitions and slugs already owned by another provider are skipped.
	 *
	 * @return void
	 */

	public static function register_post_types() {
		foreach( self::get_definitions( self::POST_TYPE ) as $post ) {
			$slug = $post->post_name;
			if( ! self::has_valid_config( $post ) || ! preg_match( WPHAVE_Content_Type_Validator::POST_TYPE_PATTERN, $slug ) || post_type_exists( $slug ) ) {
				continue;
			}
			$config = WPHAVE_Content_Type_Validator::sanitize_post_type( self::decode( $post ) );
			$singular = $config['singularName'] ?: $post->post_title;
			$labels = array_merge( array( 'name' => $post->post_title, 'singular_name' => $singular ), array_filter( $config['labels'] ) );
			// WordPress treats an empty supports array like an omitted value and adds
			// title/editor defaults. Pass false to preserve an intentional empty list.
			$supports = $config['supports'] ?: false;
			if( $config['hierarchical'] && ( false === $supports || ! in_array( 'page-attributes', $supports, true ) ) ) {
				$supports = false === $supports ? array() : $supports;
				$supports[] = 'page-attributes';
			}
			$rewrite = false;
			if( $config['rewrite']['enabled'] ) {
				$rewrite = array(
					'slug' => $config['rewrite']['slug'] ?: $slug,
					'with_front' => $config['rewrite']['withFront'],
					'feeds' => $config['rewrite']['feeds'],
					'pages' => $config['rewrite']['pages'],
				);
			}
			$args = array(
				'labels' => $labels,
				'description' => $config['description'],
				'public' => $config['public'],
				'publicly_queryable' => $config['publiclyQueryable'],
				'exclude_from_search' => $config['excludeFromSearch'],
				'show_ui' => $config['showUi'],
				'show_in_menu' => $config['showInMenu'],
				'show_in_nav_menus' => $config['showInNavMenus'],
				'show_in_rest' => $config['showInRest'],
				'hierarchical' => $config['hierarchical'],
				'has_archive' => $config['hasArchive'],
				'query_var' => $config['queryVar'],
				'delete_with_user' => $config['deleteWithUser'],
				'menu_position' => $config['menuPosition'],
				'menu_icon' => self::prepare_menu_icon( $config['menuIcon'] ),
				'supports' => $supports,
				'rewrite' => $rewrite,
			);
			if( $config['taxonomies'] ) {
				$args['taxonomies'] = array_values( array_filter( $config['taxonomies'], 'taxonomy_exists' ) );
			}
			$registered = register_post_type( $slug, $args );
			if ( ! is_wp_error( $registered ) ) {
				self::$block_editor_preferences[ $slug ] = $config['useBlockEditor'];
			}
		}
	}

	/** Apply the stored block-editor preference to WPHAVE-owned post types. */
	public static function filter_block_editor_for_post_type( $use_block_editor, $post_type ) {
		if (
			isset( self::$block_editor_preferences[ $post_type ] )
			&& ! self::$block_editor_preferences[ $post_type ]
		) {
			return false;
		}

		return $use_block_editor;
	}

	/**
	 * Convert a sanitized menu icon into a WordPress registration value.
	 *
	 * @param string|array $menu_icon Dashicon name or sanitized SVG descriptor.
	 * @return string Dashicon name or SVG data URI.
	 */

	private static function prepare_menu_icon( $menu_icon ) {
		if( is_array( $menu_icon ) ) {
			if( empty( $menu_icon['svg'] ) ) return 'dashicons-admin-post';
			$admin_svg = str_ireplace( 'currentColor', '#a7aaad', $menu_icon['svg'] );
			if( preg_match( '/<svg\b[^>]*\sfill=/i', $admin_svg ) ) {
				$admin_svg = preg_replace( '/(<svg\b[^>]*\sfill=)(["\']).*?\2/i', '$1$2#a7aaad$2', $admin_svg, 1 );
			} else {
				$admin_svg = preg_replace( '/<svg\b/i', "<svg fill='#a7aaad'", $admin_svg, 1 );
			}
			return 'data:image/svg+xml;base64,' . base64_encode( $admin_svg );
		}
		$menu_icon = sanitize_text_field( $menu_icon );
		if( '' === $menu_icon ) return 'dashicons-admin-post';
		return 0 === strpos( $menu_icon, 'dashicons-' ) ? $menu_icon : 'dashicons-' . $menu_icon;
	}

	/**
	 * Register all active user-defined taxonomies with WordPress.
	 *
	 * Definitions without an available object type are deliberately skipped.
	 *
	 * @return void
	 */

	public static function register_taxonomies() {
		foreach( self::get_definitions( self::TAXONOMY ) as $post ) {
			$slug = $post->post_name;
			if( ! self::has_valid_config( $post ) || ! preg_match( WPHAVE_Content_Type_Validator::TAXONOMY_PATTERN, $slug ) || taxonomy_exists( $slug ) ) {
				continue;
			}
			$config = WPHAVE_Content_Type_Validator::sanitize_taxonomy( self::decode( $post ) );
			$object_types = array_values( array_filter( $config['objectTypes'], 'post_type_exists' ) );
			if( ! $object_types ) {
				continue;
			}
			$rewrite = false;
			if( $config['rewrite']['enabled'] ) {
				$rewrite = array( 'slug' => $config['rewrite']['slug'] ?: $slug, 'with_front' => $config['rewrite']['withFront'], 'hierarchical' => $config['rewrite']['hierarchical'] );
			}
			$args = array(
				'labels' => array_merge( array( 'name' => $post->post_title, 'singular_name' => $config['singularName'] ?: $post->post_title ), array_filter( $config['labels'] ) ),
				'description' => $config['description'],
				'public' => $config['public'],
				'publicly_queryable' => $config['publiclyQueryable'],
				'show_ui' => $config['showUi'],
				'show_in_menu' => $config['showInMenu'],
				'show_in_nav_menus' => $config['showInNavMenus'],
				'show_tagcloud' => $config['showTagcloud'],
				'show_in_quick_edit' => $config['showInQuickEdit'],
				'show_admin_column' => $config['showAdminColumn'],
				'show_in_rest' => $config['showInRest'],
				'hierarchical' => $config['hierarchical'],
				'sort' => $config['sort'],
				'query_var' => $config['queryVar'],
				'rewrite' => $rewrite,
			);
			if( $config['defaultTerm']['enabled'] && $config['defaultTerm']['name'] ) {
				$args['default_term'] = array_filter( array( 'name' => $config['defaultTerm']['name'], 'slug' => $config['defaultTerm']['slug'], 'description' => $config['defaultTerm']['description'] ) );
			}
			register_taxonomy( $slug, $object_types, $args );
		}
	}

	/**
	 * Schedule a single non-destructive rewrite-rule flush for the next init.
	 *
	 * @return void
	 */

	public static function schedule_rewrite_flush() {
		update_option( self::FLUSH_OPTION, '1', false );
	}

	/**
	 * React to definition status changes and synchronize dependent state.
	 *
	 * @param string $new_status New post status.
	 * @param string $old_status Previous post status.
	 * @param WP_Post $post Updated post object.
	 * @return void
	 */

	public static function handle_status_change( $new_status, $old_status, $post ) {
		if( in_array( $post->post_type, array( self::POST_TYPE, self::TAXONOMY ), true ) && $new_status !== $old_status ) {
			self::clear_definition_cache();
			self::schedule_rewrite_flush();
			if( self::POST_TYPE === $post->post_type ) {
				self::sync_navigation_slug( $post->post_name, 'publish' === $new_status && ! empty( self::decode( $post )['wphave']['showInNavigation'] ) );
			}
		}
	}

	/**
	 * Clear derived state before a stored content type definition is deleted.
	 *
	 * @param int $post_id ID of the post being deleted.
	 * @param WP_Post $post Post object being deleted.
	 * @return void
	 */

	public static function handle_delete( $post_id, $post ) {
		if( $post && in_array( $post->post_type, array( self::POST_TYPE, self::TAXONOMY ), true ) ) {
			self::clear_definition_cache();
			self::schedule_rewrite_flush();
			if( self::POST_TYPE === $post->post_type ) {
				self::sync_navigation_slug( $post->post_name, false );
			}
		}
	}

	/**
	 * Add or remove a custom post type from the WPHAVE navigation settings.
	 *
	 * @param string $slug Post type slug.
	 * @param bool $enabled Whether the post type should be shown.
	 * @return void
	 */

	private static function sync_navigation_slug( $slug, $enabled ) {
		if( ! function_exists( 'wphave_data_get' ) || ! function_exists( 'wphave_data_set' ) ) {
			return;
		}
		$items = array_values( array_diff( (array) wphave_data_get( 'site_settings', 'advanced.ui.postTypes', array() ), array( $slug ) ) );
		if( $enabled ) {
			$items[] = $slug;
		}
		wphave_data_set( 'site_settings', 'advanced.ui.postTypes', array_values( array_unique( $items ) ) );
	}

	/**
	 * Flush rewrite rules once when a pending content type change requires it.
	 *
	 * @return void
	 */

	public static function maybe_flush_rewrite_rules() {
		if( ! get_option( self::FLUSH_OPTION ) ) {
			return;
		}
		delete_option( self::FLUSH_OPTION );
		flush_rewrite_rules( false );
	}

	/**
	 * Schedule rewrite regeneration when the plugin is activated.
	 *
	 * @return void
	 */

	public static function activate() {
		self::schedule_rewrite_flush();
	}

	/**
	 * Remove pending state and flush rewrite rules during deactivation.
	 *
	 * @return void
	 */

	public static function deactivate() {
		delete_option( self::FLUSH_OPTION );
		flush_rewrite_rules( false );
	}
}

WPHAVE_Content_Types::init();

endif;
