<?php

/**
 * Canonical policy for post types that may use the generic WPHAVE content UI.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WPHAVE_Generic_Content_Post_Type_Policy {

	/**
	 * Return the canonical editor capabilities for one post type.
	 *
	 * Content storage and the editing surface are deliberately separate: the
	 * `editor` support enables `post_content`, while WordPress independently
	 * decides whether that content uses the block editor.
	 */
	public static function editor_capabilities( string $post_type ): array {
		$post_type_object = get_post_type_object( $post_type );
		$supports_editor = post_type_supports( $post_type, 'editor' );

		return array(
			'supports_editor' => $supports_editor,
			'uses_block_editor' => $supports_editor
				&& $post_type_object
				&& use_block_editor_for_post_type( $post_type ),
		);
	}

	/** Return editor capabilities for all post types exposed in the admin UI. */
	public static function editor_capabilities_map(): array {
		$result = array();

		foreach ( get_post_types( array( 'show_ui' => true ), 'names' ) as $post_type ) {
			$result[ $post_type ] = self::editor_capabilities( $post_type );
		}

		/**
		 * Allow owned, hidden post types to publish their editor contract without
		 * making them visible in WordPress or the generic content workspace.
		 */
		return apply_filters( 'wphave_post_type_editor_capabilities', $result );
	}

	/**
	 * Return post types excluded from the generic content workspace.
	 *
	 * Integrations may register owned post types without creating a dependency
	 * from generic WPHAVE infrastructure back to the integration.
	 *
	 * @return string[]
	 */
	public static function excluded_post_types() {
		$post_types = apply_filters(
			'wphave_generic_content_excluded_post_types',
			array( 'page', 'attachment' )
		);

		return array_values(
			array_unique(
				array_filter(
					array_map( 'sanitize_key', (array) $post_types )
				)
			)
		);
	}

	/**
	 * Normalize a user selection to post types owned by the generic workspace.
	 *
	 * @param array $post_types Post type slugs.
	 * @return string[]
	 */
	public static function filter_selection( $post_types ) {
		$post_types = array_values(
			array_unique(
				array_filter(
					array_map( 'sanitize_key', (array) $post_types )
				)
			)
		);

		return array_values(
			array_diff(
				$post_types,
				self::excluded_post_types()
			)
		);
	}
}
