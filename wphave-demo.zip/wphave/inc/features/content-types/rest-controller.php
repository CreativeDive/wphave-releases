<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

if( ! class_exists( 'WPHAVE_Content_Types_REST_Controller' ) ) :

/**
 * Manage the content types REST feature.
 */

class WPHAVE_Content_Types_REST_Controller {
	const MAX_DEFINITION_BODY_BYTES = 131072;
	const MAX_IMPORT_BODY_BYTES = 1048576;

	/**
	 * Register the REST route bootstrap hook.
	 *
	 * @return void
	 */

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * Determine whether the current user may manage content types.
	 *
	 * @return bool Whether the current user has an accepted management capability.
	 */

	public static function can_manage() {
		return current_user_can( 'manage_options' ) || current_user_can( 'wphave_manage_content_types' );
	}

	private static function require_manage() {
		// AUTHORIZATION INVARIANT: Content Type callbacks expose and mutate global
		// WordPress registration contracts. REST permission callbacks are an early
		// gate, so every public operation repeats the canonical management policy.
		if ( ! self::can_manage() ) {
			return new WP_Error(
				'wphave_content_types_forbidden',
				__( 'You are not allowed to manage content types.', 'wphave' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Release a prepared management payload only while authority is still current.
	 *
	 * @param mixed $data Prepared response data.
	 * @return WP_REST_Response|WP_Error
	 */

	private static function authorized_read_response( $data ) {
		// AUTHORIZATION/READ INVARIANT: Definition projection crosses WordPress queries and extension filters; private management data is released only after a final capability check.
		$authorization = self::require_manage();
		return is_wp_error( $authorization ) ? $authorization : rest_ensure_response( $data );
	}

	/**
	 * Register all content type CRUD, import and export routes.
	 *
	 * Every route uses the same explicit content type capability check.
	 *
	 * @return void
	 */

	public static function register_routes() {
		foreach ( array( 'post-types', 'taxonomies' ) as $definition_type ) {
			WPHAVE_REST_Body_Budget::protect(
				'POST',
				'~^/wphave/v1/content-types/' . $definition_type . '$~D',
				self::MAX_DEFINITION_BODY_BYTES
			);
			foreach ( array( 'POST', 'PUT', 'PATCH' ) as $method ) {
				WPHAVE_REST_Body_Budget::protect(
					$method,
					'~^/wphave/v1/content-types/' . $definition_type . '/[0-9]+$~D',
					self::MAX_DEFINITION_BODY_BYTES
				);
			}
		}
		WPHAVE_REST_Body_Budget::protect(
			'POST',
			'~^/wphave/v1/content-types/import$~D',
			self::MAX_IMPORT_BODY_BYTES
		);
		register_rest_route( 'wphave/v1', '/content-types', array(
			'methods' => WP_REST_Server::READABLE,
			'callback' => array( __CLASS__, 'index' ),
			'permission_callback' => array( __CLASS__, 'can_manage' ),
		) );

		foreach( array( 'post-types', 'taxonomies' ) as $type ) {
			register_rest_route( 'wphave/v1', '/content-types/' . $type, array(
				array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( __CLASS__, 'list_items' ), 'permission_callback' => array( __CLASS__, 'can_manage' ) ),
				array( 'methods' => WP_REST_Server::CREATABLE, 'callback' => array( __CLASS__, 'create_item' ), 'permission_callback' => array( __CLASS__, 'can_manage' ), 'args' => self::write_args() ),
			) );

			register_rest_route( 'wphave/v1', '/content-types/' . $type . '/(?P<id>\d+)', array(
				array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( __CLASS__, 'get_item' ), 'permission_callback' => array( __CLASS__, 'can_manage' ) ),
				array( 'methods' => WP_REST_Server::EDITABLE, 'callback' => array( __CLASS__, 'update_item' ), 'permission_callback' => array( __CLASS__, 'can_manage' ), 'args' => array_merge( self::id_args(), self::write_args() ) ),
				array( 'methods' => WP_REST_Server::DELETABLE, 'callback' => array( __CLASS__, 'delete_item' ), 'permission_callback' => array( __CLASS__, 'can_manage' ), 'args' => array_merge( self::id_args(), array( 'force' => array( 'type' => 'boolean', 'default' => false, 'sanitize_callback' => 'rest_sanitize_boolean' ) ) ) ),
			) );

			register_rest_route( 'wphave/v1', '/content-types/' . $type . '/(?P<id>\d+)/duplicate', array(
				'methods' => WP_REST_Server::CREATABLE,
				'callback' => array( __CLASS__, 'duplicate_item' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
				'args' => self::id_args(),
			) );
		}

		register_rest_route( 'wphave/v1', '/content-types/export', array(
			'methods' => WP_REST_Server::READABLE,
			'callback' => array( __CLASS__, 'export' ),
			'permission_callback' => array( __CLASS__, 'can_manage' ),
		) );

		register_rest_route( 'wphave/v1', '/content-types/import', array(
			'methods' => WP_REST_Server::CREATABLE,
			'callback' => array( __CLASS__, 'import' ),
			'permission_callback' => array( __CLASS__, 'can_manage' ),
			'args' => array(
				'schemaVersion' => array( 'type' => 'integer', 'required' => true ),
				'postTypes' => array( 'type' => 'array', 'required' => false, 'maxItems' => 100 ),
				'taxonomies' => array( 'type' => 'array', 'required' => false, 'maxItems' => 100 ),
				'conflict' => array( 'type' => 'string', 'required' => false, 'default' => 'skip', 'enum' => array( 'skip', 'rename', 'update' ) ),
				'dryRun' => array( 'type' => 'boolean', 'required' => false, 'default' => false, 'sanitize_callback' => 'rest_sanitize_boolean' ),
			),
		) );
	}

	/**
	 * Return the shared numeric definition ID route argument.
	 *
	 * @return array REST argument schema.
	 */

	private static function id_args() {
		return array( 'id' => array( 'type' => 'integer', 'required' => true, 'sanitize_callback' => 'absint' ) );
	}

	/**
	 * Return the validated arguments shared by create and update routes.
	 *
	 * @return array REST argument schema.
	 */

	private static function write_args() {
		return array(
			'pluralName' => array( 'type' => 'string', 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ),
			'slug' => array( 'type' => 'string', 'required' => true, 'sanitize_callback' => 'sanitize_key' ),
			'active' => array( 'type' => 'boolean', 'required' => false, 'sanitize_callback' => 'rest_sanitize_boolean' ),
			'status' => array( 'type' => 'string', 'required' => false, 'enum' => array( 'publish', 'draft' ) ),
			'config' => array( 'type' => 'object', 'required' => true ),
			'confirmSlugChange' => array( 'type' => 'boolean', 'required' => false, 'default' => false, 'sanitize_callback' => 'rest_sanitize_boolean' ),
		);
	}

	/**
	 * Resolve the internal definition storage type from a REST route.
	 *
	 * @param WP_REST_Request $request Current REST request.
	 * @return string Internal post type used for the definition.
	 */

	private static function route_type( $request ) {
		return false !== strpos( $request->get_route(), '/taxonomies' ) ? WPHAVE_Content_Types::TAXONOMY : WPHAVE_Content_Types::POST_TYPE;
	}

	/**
	 * Convert an internal storage type into its public API type name.
	 *
	 * @param string $storage_type Internal definition post type.
	 * @return string Public type name.
	 */

	private static function type_name( $storage_type ) {
		return WPHAVE_Content_Types::TAXONOMY === $storage_type ? 'taxonomy' : 'post_type';
	}

	/**
	 * Prepare a stored definition for REST responses.
	 *
	 * Adds registration state, content counts, relationships and warnings.
	 *
	 * @param WP_Post $post Definition post.
	 * @return array REST response data.
	 */

	private static function prepare( $post ) {
		$storage_type = $post->post_type;
		$config = WPHAVE_Content_Types::decode( $post );
		$slug = $post->post_name;
		$is_taxonomy = WPHAVE_Content_Types::TAXONOMY === $storage_type;
		$count = $is_taxonomy ? self::taxonomy_count( $slug ) : self::post_type_count( $slug );
		$collision = $is_taxonomy ? taxonomy_exists( $slug ) : post_type_exists( $slug );
		$registered = 'publish' === $post->post_status && $collision;
		$warnings = array();
		if( ! WPHAVE_Content_Types::has_valid_config( $post ) ) $warnings[] = __( 'The stored configuration is invalid and this definition will not be registered.', 'wphave' );
		if( ! $is_taxonomy ) {
			$config['taxonomies'] = array_values( array_unique( array_merge( (array) ( $config['taxonomies'] ?? array() ), self::user_taxonomies_for_post_type( $slug ) ) ) );
		}
		if( 'publish' === $post->post_status && ! $registered ) {
			$warnings[] = __( 'The active definition could not be registered. Check its key and relationships.', 'wphave' );
		}
		if( ! $is_taxonomy && empty( $config['showInRest'] ) ) {
			$warnings[] = __( 'The REST API is disabled, so the block editor is unavailable for this post type.', 'wphave' );
		}
		return array(
			'id' => $post->ID,
			'type' => self::type_name( $storage_type ),
			'pluralName' => $post->post_title,
			'slug' => $slug,
			'status' => $post->post_status,
			'active' => 'publish' === $post->post_status,
			'config' => $config,
			'count' => $count,
			'registration' => array( 'registered' => $registered, 'warnings' => $warnings, 'errors' => array() ),
			'modified' => mysql_to_rfc3339( $post->post_modified_gmt ),
		);
	}

	/**
	 * Load a definition and verify that it belongs to the requested type.
	 *
	 * @param int $id Definition post ID.
	 * @param string $storage_type Expected internal definition post type.
	 * @return WP_Post|WP_Error Matching post or a not-found error.
	 */

	private static function get_post_or_error( $id, $storage_type ) {
		$post = get_post( absint( $id ) );
		if( ! $post || $storage_type !== $post->post_type ) {
			return new WP_Error( 'wphave_content_type_not_found', __( 'Content type definition not found.', 'wphave' ), array( 'status' => 404 ) );
		}
		return $post;
	}

	/**
	 * Validate and normalize a create or update request payload.
	 *
	 * This protects WordPress key limits, provider collisions, relationship
	 * allowlists and explicit confirmation for changes affecting existing data.
	 *
	 * @param WP_REST_Request $request Current REST request.
	 * @param string $storage_type Internal definition post type.
	 * @param int $current_id Existing definition ID when updating.
	 * @return array|WP_Error Normalized write payload or validation error.
	 */

	private static function validate_payload( $request, $storage_type, $current_id = 0 ) {
		// DIRECT-CALL INVARIANT: Validate the raw body before JSON decoding even
		// when an internal importer invokes this validator without REST dispatch.
		if ( strlen( (string) $request->get_body() ) > self::MAX_DEFINITION_BODY_BYTES ) {
			return new WP_Error(
				'wphave_content_type_payload_too_large',
				__( 'The content type payload exceeds the 128 KB limit.', 'wphave' ),
				array( 'status' => 413 )
			);
		}
		$data = $request->get_json_params();
		if( ! is_array( $data ) ) return new WP_Error( 'wphave_content_type_payload_invalid', __( 'A valid JSON object is required.', 'wphave' ), array( 'status' => 400 ) );
		$name = sanitize_text_field( $data['pluralName'] ?? '' );
		$slug = sanitize_key( $data['slug'] ?? '' );
		$pattern = WPHAVE_Content_Types::TAXONOMY === $storage_type ? WPHAVE_Content_Type_Validator::TAXONOMY_PATTERN : WPHAVE_Content_Type_Validator::POST_TYPE_PATTERN;
		if( '' === $name ) {
			return new WP_Error( 'wphave_content_type_name_required', __( 'A plural name is required.', 'wphave' ), array( 'status' => 400 ) );
		}
		if( strlen( $name ) > 200 ) return new WP_Error( 'wphave_content_type_name_too_long', __( 'The plural name may not exceed 200 characters.', 'wphave' ), array( 'status' => 400 ) );
		if( ! preg_match( $pattern, $slug ) ) {
			return new WP_Error( 'wphave_content_type_slug_invalid', __( 'The key contains invalid characters or exceeds the WordPress limit.', 'wphave' ), array( 'status' => 400 ) );
		}
		$existing = get_posts( array( 'post_type' => $storage_type, 'post_status' => 'any', 'name' => $slug, 'posts_per_page' => 1, 'post__not_in' => $current_id ? array( $current_id ) : array(), 'fields' => 'ids' ) );
		if( $existing ) {
			return new WP_Error( 'wphave_content_type_slug_taken', __( 'This key is already used by another wphave definition.', 'wphave' ), array( 'status' => 409 ) );
		}
		$is_registered = WPHAVE_Content_Types::TAXONOMY === $storage_type ? taxonomy_exists( $slug ) : post_type_exists( $slug );
		$current = $current_id ? get_post( $current_id ) : null;
		if( $is_registered && ( ! $current || $current->post_name !== $slug ) ) {
			return new WP_Error( 'wphave_content_type_slug_reserved', __( 'This key is already registered by WordPress, a theme, or another plugin.', 'wphave' ), array( 'status' => 409 ) );
		}
		if( $current && $current->post_name !== $slug ) {
			$count = WPHAVE_Content_Types::TAXONOMY === $storage_type ? self::taxonomy_count( $current->post_name ) : self::post_type_count( $current->post_name );
			if( $count > 0 && ! rest_sanitize_boolean( $data['confirmSlugChange'] ?? false ) ) {
				return new WP_Error( 'wphave_content_type_slug_confirmation_required', sprintf( /* translators: %d: contextual value. */
				__( 'Changing this key affects %d existing records and requires explicit confirmation.', 'wphave' ), $count ), array( 'status' => 409, 'affected' => $count ) );
			}
		}
		$config = $data['config'] ?? $data;
		$config = WPHAVE_Content_Types::TAXONOMY === $storage_type ? WPHAVE_Content_Type_Validator::sanitize_taxonomy( $config ) : WPHAVE_Content_Type_Validator::sanitize_post_type( $config );
		$current_config = $current ? WPHAVE_Content_Types::decode( $current ) : array();
		$relationship_key = WPHAVE_Content_Types::TAXONOMY === $storage_type ? 'objectTypes' : 'taxonomies';
		$allowed_relationships = WPHAVE_Content_Types::TAXONOMY === $storage_type ? self::allowed_post_type_slugs() : self::allowed_taxonomy_slugs();
		$existing_relationships = (array) ( $current_config[$relationship_key] ?? array() );
		$blocked_relationships = array_values( array_diff( (array) ( $config[$relationship_key] ?? array() ), $allowed_relationships, $existing_relationships ) );
		if( $blocked_relationships ) {
			return new WP_Error( 'wphave_content_type_relationship_not_allowed', sprintf( /* translators: %s: contextual value. */
			__( 'These content relationships are not available: %s', 'wphave' ), implode( ', ', $blocked_relationships ) ), array( 'status' => 400, 'relationships' => $blocked_relationships ) );
		}
		if( WPHAVE_Content_Types::TAXONOMY === $storage_type && ! $config['objectTypes'] ) {
			return new WP_Error( 'wphave_content_type_objects_required', __( 'Select at least one post type for this taxonomy.', 'wphave' ), array( 'status' => 400 ) );
		}
		if( WPHAVE_Content_Types::TAXONOMY === $storage_type && ! empty( $config['defaultTerm']['enabled'] ) && '' === trim( $config['defaultTerm']['name'] ) ) return new WP_Error( 'wphave_content_type_default_term_name', __( 'A default term name is required when the default term is enabled.', 'wphave' ), array( 'status' => 400 ) );
		$user_taxonomies = array();
		if( WPHAVE_Content_Types::POST_TYPE === $storage_type ) {
			$user_taxonomy_slugs = array_keys( self::user_taxonomy_posts_by_slug() );
			$user_taxonomies = array_values( array_intersect( $config['taxonomies'], $user_taxonomy_slugs ) );
			$config['taxonomies'] = array_values( array_diff( $config['taxonomies'], $user_taxonomy_slugs ) );
		}
		$is_active = array_key_exists( 'active', $data ) ? rest_sanitize_boolean( $data['active'] ) : 'publish' === ( $data['status'] ?? '' );
		return array( 'name' => $name, 'slug' => $slug, 'status' => $is_active ? 'publish' : 'draft', 'config' => $config, 'userTaxonomies' => $user_taxonomies );
	}

	/**
	 * Persist a definition and synchronize all dependent configuration.
	 *
	 * @param array $payload Validated definition payload.
	 * @param string $storage_type Internal definition post type.
	 * @param int $id Existing definition ID, or zero to create.
	 * @return array|WP_Error Prepared definition data or a WordPress error.
	 */

	private static function save( $payload, $storage_type, $id = 0 ) {
		// AUTHORIZATION/PERSISTENCE INVARIANT: Every caller crosses filterable
		// validation, lookup, or slug-allocation work before reaching this shared
		// sink. Repeat the canonical Content Types policy here so create, update,
		// duplicate, and import cannot lease entry authority into persistence.
		$authorization = self::require_manage();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$previous = $id ? get_post( $id ) : null;
		$old_slug = $previous ? $previous->post_name : '';
		$postarr = array(
			'ID' => absint( $id ),
			'post_type' => $storage_type,
			'post_title' => $payload['name'],
			'post_name' => $payload['slug'],
			'post_status' => $payload['status'],
			'post_content' => wp_json_encode( $payload['config'] ),
		);
		$result = $id ? wp_update_post( wp_slash( $postarr ), true ) : wp_insert_post( wp_slash( $postarr ), true );
		if( is_wp_error( $result ) ) {
			return $result;
		}
		WPHAVE_Content_Types::clear_definition_cache();
		WPHAVE_Content_Types::schedule_rewrite_flush();
		self::sync_wphave_navigation( $storage_type, $payload, $old_slug );
		if( WPHAVE_Content_Types::POST_TYPE === $storage_type ) {
			self::sync_taxonomy_relationships( $old_slug, $payload['slug'], $payload['userTaxonomies'] ?? array() );
		}
		clean_post_cache( $result );
		return self::prepare( get_post( $result ) );
	}

	/**
	 * Return the complete content type manager bootstrap payload.
	 *
	 * @return WP_REST_Response Definitions, relationship options and summary counts.
	 */

	public static function index() {
		$authorization = self::require_manage();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}
		$post_types = array_map( array( __CLASS__, 'prepare' ), WPHAVE_Content_Types::get_definitions( WPHAVE_Content_Types::POST_TYPE, array( 'publish', 'draft' ) ) );
		$taxonomies = array_map( array( __CLASS__, 'prepare' ), WPHAVE_Content_Types::get_definitions( WPHAVE_Content_Types::TAXONOMY, array( 'publish', 'draft' ) ) );
		return self::authorized_read_response( array(
			'postTypes' => $post_types,
			'taxonomies' => $taxonomies,
			'availablePostTypes' => self::available_post_types(),
			'availableTaxonomies' => self::available_taxonomies(),
			'counts' => array( 'postTypes' => count( $post_types ), 'taxonomies' => count( $taxonomies ), 'active' => count( array_filter( array_merge( $post_types, $taxonomies ), function( $item ) { return $item['active']; } ) ) ),
		) );
	}

	/**
	 * List definitions for the type represented by the current route.
	 *
	 * @param WP_REST_Request $request Current REST request.
	 * @return WP_REST_Response
	 */

	public static function list_items( $request ) {
		$authorization = self::require_manage();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}
		return self::authorized_read_response( array_map( array( __CLASS__, 'prepare' ), WPHAVE_Content_Types::get_definitions( self::route_type( $request ), array( 'publish', 'draft' ) ) ) );
	}

	/**
	 * Return one stored content type definition.
	 *
	 * @param WP_REST_Request $request Current REST request.
	 * @return WP_REST_Response|WP_Error
	 */

	public static function get_item( $request ) {
		$authorization = self::require_manage();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}
		$post = self::get_post_or_error( $request['id'], self::route_type( $request ) );
		return is_wp_error( $post ) ? $post : self::authorized_read_response( self::prepare( $post ) );
	}

	/**
	 * Validate and create a content type definition.
	 *
	 * @param WP_REST_Request $request Current REST request.
	 * @return WP_REST_Response|WP_Error
	 */

	public static function create_item( $request ) {
		$authorization = self::require_manage();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}
		$storage_type = self::route_type( $request );
		$payload = self::validate_payload( $request, $storage_type );
		if( is_wp_error( $payload ) ) return $payload;
		$result = self::save( $payload, $storage_type );
		if( is_wp_error( $result ) ) return $result;
		$response = rest_ensure_response( $result );
		$response->set_status( 201 );
		return $response;
	}

	/**
	 * Validate and update an existing content type definition.
	 *
	 * @param WP_REST_Request $request Current REST request.
	 * @return WP_REST_Response|WP_Error
	 */

	public static function update_item( $request ) {
		$authorization = self::require_manage();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}
		$storage_type = self::route_type( $request );
		$post = self::get_post_or_error( $request['id'], $storage_type );
		if( is_wp_error( $post ) ) return $post;
		$payload = self::validate_payload( $request, $storage_type, $post->ID );
		return is_wp_error( $payload ) ? $payload : rest_ensure_response( self::save( $payload, $storage_type, $post->ID ) );
	}

	/**
	 * Trash or permanently delete a definition while preserving its content.
	 *
	 * @param WP_REST_Request $request Current REST request.
	 * @return WP_REST_Response|WP_Error
	 */

	public static function delete_item( $request ) {
		$authorization = self::require_manage();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}
		$storage_type = self::route_type( $request );
		$post = self::get_post_or_error( $request['id'], $storage_type );
		if( is_wp_error( $post ) ) return $post;
		$force = rest_sanitize_boolean( $request->get_param( 'force' ) );
		$count = WPHAVE_Content_Types::TAXONOMY === $storage_type ? self::taxonomy_count( $post->post_name ) : self::post_type_count( $post->post_name );
		// AUTHORIZATION/DELETE INVARIANT: Impact discovery may invoke third-party taxonomy filters, so authority must be current immediately before the irreversible definition deletion.
		$authorization = self::require_manage();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}
		$deleted = wp_delete_post( $post->ID, $force );
		if( ! $deleted ) return new WP_Error( 'wphave_content_type_delete_failed', __( 'The definition could not be deleted.', 'wphave' ), array( 'status' => 500 ) );
		WPHAVE_Content_Types::schedule_rewrite_flush();
		self::remove_navigation_slug( $post->post_name );
		if( WPHAVE_Content_Types::POST_TYPE === $storage_type ) self::sync_taxonomy_relationships( $post->post_name, '', array() );
		return rest_ensure_response( array( 'deleted' => true, 'force' => $force, 'contentPreserved' => $count ) );
	}

	/**
	 * Create an inactive copy of an existing definition with a unique slug.
	 *
	 * @param WP_REST_Request $request Current REST request.
	 * @return WP_REST_Response|WP_Error
	 */

	public static function duplicate_item( $request ) {
		$authorization = self::require_manage();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}
		$storage_type = self::route_type( $request );
		$post = self::get_post_or_error( $request['id'], $storage_type );
		if( is_wp_error( $post ) ) return $post;
		$slug = self::unique_slug( $post->post_name, $storage_type );
		$payload = array( 'name' => sprintf( /* translators: %s: contextual value. */
		__( '%s (Copy)', 'wphave' ), $post->post_title ), 'slug' => $slug, 'status' => 'draft', 'config' => WPHAVE_Content_Types::decode( $post ) );
		$result = self::save( $payload, $storage_type );
		if( is_wp_error( $result ) ) return $result;
		$response = rest_ensure_response( $result );
		$response->set_status( 201 );
		return $response;
	}

	/**
	 * Export all definitions in the versioned interchange schema.
	 *
	 * @return WP_REST_Response Portable content type definition payload.
	 */

	public static function export() {
		$authorization = self::require_manage();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}
		$index = self::index();
		if ( is_wp_error( $index ) ) {
			return $index;
		}
		$response = $index->get_data();
		return rest_ensure_response( array( 'schemaVersion' => WPHAVE_Content_Type_Validator::SCHEMA_VERSION, 'pluginVersion' => defined( 'WPHAVE_VERSION' ) ? WPHAVE_VERSION : '', 'postTypes' => $response['postTypes'], 'taxonomies' => $response['taxonomies'] ) );
	}

	/**
	 * Validate and import a bounded collection of content type definitions.
	 *
	 * Imports are inactive by default and support skip, rename and update
	 * conflict strategies as well as a non-mutating dry run.
	 *
	 * @param WP_REST_Request $request Current REST request.
	 * @return WP_REST_Response|WP_Error
	 */

	public static function import( $request ) {
		$authorization = self::require_manage();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}
		if ( strlen( (string) $request->get_body() ) > self::MAX_IMPORT_BODY_BYTES ) {
			return new WP_Error(
				'wphave_content_types_import_too_large',
				__( 'The import file exceeds the 1 MB limit.', 'wphave' ),
				array( 'status' => 413 )
			);
		}
		$data = $request->get_json_params();
		$data = self::migrate_import( is_array( $data ) ? $data : array() );
		if( is_wp_error( $data ) ) return $data;
		if( count( (array) ( $data['postTypes'] ?? array() ) ) > 100 || count( (array) ( $data['taxonomies'] ?? array() ) ) > 100 ) return new WP_Error( 'wphave_content_types_import_limit', __( 'An import may contain at most 100 post types and 100 taxonomies.', 'wphave' ), array( 'status' => 400 ) );
		$created = array();
		$errors = array();
		$skipped = array();
		$plan = array();
		$conflict = in_array( $data['conflict'] ?? 'skip', array( 'skip', 'rename', 'update' ), true ) ? $data['conflict'] : 'skip';
		$dry_run = rest_sanitize_boolean( $data['dryRun'] ?? false );
		foreach( array( 'postTypes' => WPHAVE_Content_Types::POST_TYPE, 'taxonomies' => WPHAVE_Content_Types::TAXONOMY ) as $key => $storage_type ) {
			foreach( (array) ( $data[$key] ?? array() ) as $item ) {
				// IMPORT INVARIANT: Every envelope member must be a definition
				// object with a bounded scalar identity before any offset access,
				// slug normalization or partial batch persistence.
				if (
					! is_array( $item )
					|| ! is_string( $item['slug'] ?? null )
					|| strlen( $item['slug'] ) > 200
				) {
					$errors[] = array( 'slug' => '', 'code' => 'wphave_content_types_import_item_invalid', 'message' => __( 'An import definition is invalid.', 'wphave' ) );
					continue;
				}
				// SECURITY INVARIANT: Portable definitions are imported inactive and as
				// drafts, then passed through the same canonical validator as interactive
				// edits before any individual definition is persisted.
				$item['active'] = false;
				$item['status'] = 'draft';
				$existing = get_page_by_path( sanitize_key( $item['slug'] ?? '' ), OBJECT, $storage_type );
				if( $existing && 'skip' === $conflict ) { $skipped[] = $item['slug']; continue; }
				if( $existing && 'rename' === $conflict ) { $item['slug'] = self::unique_slug( $item['slug'], $storage_type ); $existing = null; }
				$fake = new WP_REST_Request( 'POST', '/wphave/v1/content-types/import' );
				$fake->set_header( 'content-type', 'application/json' );
				$fake->set_body( wp_json_encode( $item ) );
				$payload = self::validate_payload( $fake, $storage_type, $existing ? $existing->ID : 0 );
				if( is_wp_error( $payload ) ) { $errors[] = array( 'slug' => $item['slug'] ?? '', 'code' => $payload->get_error_code(), 'message' => $payload->get_error_message() ); continue; }
				$plan[] = array( 'slug' => $payload['slug'], 'type' => self::type_name( $storage_type ), 'action' => $existing ? 'update' : 'create' );
				if( $dry_run ) continue;

				$result = self::save( $payload, $storage_type, $existing ? $existing->ID : 0 );
				// AUTHORIZATION/ERROR INVARIANT: Loss of batch authority is a
				// request-level denial, never an item validation error inside a 200
				// response. Stop immediately and preserve the canonical 403 contract.
				if (
					is_wp_error( $result )
					&& 'wphave_content_types_forbidden' === $result->get_error_code()
				) {
					return $result;
				}

				is_wp_error( $result ) ? $errors[] = array( 'slug' => $payload['slug'], 'code' => $result->get_error_code(), 'message' => $result->get_error_message() ) : $created[] = $result;
			}
		}

		// AUTHORIZATION/IMPORT-RESPONSE INVARIANT: Schema migration, conflict
		// planning and canonical validation cross filterable WordPress registries
		// even for a non-mutating dry run. Revalidate the Content Types policy after
		// the complete plan/result projection and immediately before releasing it.
		$authorization = self::require_manage();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		return rest_ensure_response( array( 'dryRun' => $dry_run, 'plan' => $plan, 'created' => $created, 'skipped' => $skipped, 'errors' => $errors ) );
	}

	/**
	 * Upgrade a portable import envelope before its definitions are validated.
	 *
	 * Keep every released schema readable. When the export schema changes, add
	 * the preceding-version transformation here before changing the exported
	 * version; only genuinely newer schemas should remain unsupported.
	 *
	 * @param array $data Decoded import envelope.
	 * @return array|WP_Error Migrated envelope or an unsupported-schema error.
	 */

	private static function migrate_import( array $data ) {
		$version = absint( $data['schemaVersion'] ?? 0 );
		if( $version < 1 || $version > WPHAVE_Content_Type_Validator::SCHEMA_VERSION ) return new WP_Error( 'wphave_content_types_import_schema', __( 'The import file uses an unsupported schema version.', 'wphave' ), array( 'status' => 400 ) );

		while( $version < WPHAVE_Content_Type_Validator::SCHEMA_VERSION ) {
			switch( $version ) {
				// Add the v1-to-v2 envelope transformation here before raising the schema version.
				default:
					return new WP_Error( 'wphave_content_types_import_migration_missing', __( 'The import file cannot be migrated.', 'wphave' ), array( 'status' => 400 ) );
			}
			$version++;
			$data['schemaVersion'] = $version;
		}

		return $data;
	}

	/**
	 * Return post type slugs users may assign to managed taxonomies.
	 *
	 * Internal WordPress and WPHAVE storage types are excluded. Extensions may
	 * adjust the final allowlist through wphave_content_types_allowed_post_types.
	 *
	 * @return string[] Allowed post type slugs.
	 */

	private static function allowed_post_type_slugs() {
		$blocked = array( 'attachment', 'revision', 'nav_menu_item', 'custom_css', 'customize_changeset', 'oembed_cache', 'user_request', 'wp_block', 'wp_template', 'wp_template_part', 'wp_global_styles', 'wp_navigation', 'wp_font_family', 'wp_font_face', 'shop_order', 'shop_order_refund', 'shop_coupon', 'shop_webhook', WPHAVE_Content_Types::POST_TYPE, WPHAVE_Content_Types::TAXONOMY );
		$allowed = array();
		foreach( get_post_types( array(), 'objects' ) as $item ) {
			if( in_array( $item->name, $blocked, true ) || 0 === strpos( $item->name, 'wphave_' ) ) continue;
			if( in_array( $item->name, array( 'post', 'page', 'product' ), true ) || ( ! empty( $item->public ) && ! empty( $item->show_ui ) ) ) $allowed[] = $item->name;
		}
		foreach( WPHAVE_Content_Types::get_definitions( WPHAVE_Content_Types::POST_TYPE, array( 'publish', 'draft' ) ) as $post ) $allowed[] = $post->post_name;
		return array_values( array_unique( array_filter( (array) apply_filters( 'wphave_content_types_allowed_post_types', $allowed ) ) ) );
	}

	/**
	 * Prepare allowed post types as select options for the manager UI.
	 *
	 * @return array[] Options containing value, label and caption.
	 */

	private static function available_post_types() {
		$result = array();
		$definition_posts = array();
		foreach( WPHAVE_Content_Types::get_definitions( WPHAVE_Content_Types::POST_TYPE, array( 'publish', 'draft' ) ) as $post ) $definition_posts[$post->post_name] = $post;
		foreach( self::allowed_post_type_slugs() as $slug ) {
			$item = get_post_type_object( $slug );
			$post = $definition_posts[$slug] ?? null;
			$config = $post ? WPHAVE_Content_Types::decode( $post ) : array();
			$label = $post ? ( $config['singularName'] ?? $post->post_title ) : ( $item ? ( $item->labels->singular_name ?? $item->label ) : $slug );
			$result[] = array( 'value' => $slug, 'label' => $label, 'caption' => $slug );
		}
		return $result;
	}

	/**
	 * Return taxonomy slugs users may assign to managed post types.
	 *
	 * Internal and provider-managed taxonomies are excluded. Extensions may
	 * adjust the final allowlist through wphave_content_types_allowed_taxonomies.
	 *
	 * @return string[] Allowed taxonomy slugs.
	 */

	private static function allowed_taxonomy_slugs() {
		$blocked = array( 'link_category', 'nav_menu', 'post_format', 'wp_theme', 'wp_template_part_area', 'wp_pattern_category', 'product_cat', 'product_tag', 'product_brand' );
		$allowed = array();
		foreach( get_taxonomies( array(), 'objects' ) as $item ) {
			if( in_array( $item->name, $blocked, true ) || 0 === strpos( $item->name, 'wphave_' ) ) continue;
			if( in_array( $item->name, array( 'category', 'post_tag' ), true ) || ( ! empty( $item->public ) && ! empty( $item->show_ui ) ) ) $allowed[] = $item->name;
		}
		foreach( WPHAVE_Content_Types::get_definitions( WPHAVE_Content_Types::TAXONOMY, array( 'publish', 'draft' ) ) as $post ) $allowed[] = $post->post_name;
		return array_values( array_unique( array_filter( (array) apply_filters( 'wphave_content_types_allowed_taxonomies', $allowed ) ) ) );
	}

	/**
	 * Prepare allowed taxonomies as select options for the manager UI.
	 *
	 * @return array[] Options containing value, label and caption.
	 */

	private static function available_taxonomies() {
		$result = array();
		$definition_posts = array();
		foreach( WPHAVE_Content_Types::get_definitions( WPHAVE_Content_Types::TAXONOMY, array( 'publish', 'draft' ) ) as $post ) $definition_posts[$post->post_name] = $post;
		foreach( self::allowed_taxonomy_slugs() as $slug ) {
			$item = get_taxonomy( $slug );
			$post = $definition_posts[$slug] ?? null;
			$config = $post ? WPHAVE_Content_Types::decode( $post ) : array();
			$label = $post ? ( $config['singularName'] ?? $post->post_title ) : ( $item ? ( $item->labels->singular_name ?? $item->label ) : $slug );
			$result[] = array( 'value' => $slug, 'label' => $label, 'caption' => $slug );
		}
		return $result;
	}

	/**
	 * Count persisted, non-temporary posts belonging to a registered post type.
	 *
	 * @param string $slug Post type slug.
	 * @return int Number of matching posts.
	 */

	private static function post_type_count( $slug ) {
		global $wpdb;
		return post_type_exists( $slug ) ? (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(ID) FROM {$wpdb->posts} WHERE post_type = %s AND post_status NOT IN ('trash','auto-draft')", $slug ) ) : 0;
	}

	/**
	 * Count all terms belonging to a registered taxonomy.
	 *
	 * @param string $slug Taxonomy slug.
	 * @return int Number of matching terms.
	 */

	private static function taxonomy_count( $slug ) {
		$taxonomy = taxonomy_exists( $slug ) ? get_taxonomy( $slug ) : null;
		$count = $taxonomy ? wp_count_terms( array( 'taxonomy' => $slug, 'hide_empty' => false ) ) : 0;
		return is_wp_error( $count ) ? 0 : (int) $count;
	}

	/**
	 * Generate an unused definition and provider slug within WordPress limits.
	 *
	 * @param string $slug Preferred base slug.
	 * @param string $storage_type Internal definition post type.
	 * @return string Unique slug.
	 */

	private static function unique_slug( $slug, $storage_type ) {
		$max = WPHAVE_Content_Types::TAXONOMY === $storage_type ? 32 : 20;
		for( $i = 2; $i < 100; $i++ ) {
			$suffix = '-' . $i;
			$candidate = substr( $slug, 0, $max - strlen( $suffix ) ) . $suffix;
			if( ! get_page_by_path( $candidate, OBJECT, $storage_type ) && ( WPHAVE_Content_Types::TAXONOMY === $storage_type ? ! taxonomy_exists( $candidate ) : ! post_type_exists( $candidate ) ) ) return $candidate;
		}
		return substr( wp_generate_uuid4(), 0, $max );
	}

	/**
	 * Index all user-managed taxonomy definitions by their slug.
	 *
	 * @return array<string,WP_Post> Taxonomy definition posts keyed by slug.
	 */

	private static function user_taxonomy_posts_by_slug() {
		$result = array();
		foreach( WPHAVE_Content_Types::get_definitions( WPHAVE_Content_Types::TAXONOMY, array( 'publish', 'draft' ) ) as $post ) {
			$result[$post->post_name] = $post;
		}
		return $result;
	}

	/**
	 * Find user-managed taxonomies related to a post type definition.
	 *
	 * @param string $post_type_slug Post type slug.
	 * @return string[] Related taxonomy slugs.
	 */

	private static function user_taxonomies_for_post_type( $post_type_slug ) {
		$result = array();
		foreach( self::user_taxonomy_posts_by_slug() as $slug => $post ) {
			$config = WPHAVE_Content_Type_Validator::sanitize_taxonomy( WPHAVE_Content_Types::decode( $post ) );
			if( in_array( $post_type_slug, $config['objectTypes'], true ) ) $result[] = $slug;
		}
		return $result;
	}

	/**
	 * Synchronize post type relationships stored by managed taxonomies.
	 *
	 * @param string $old_slug Previous post type slug.
	 * @param string $new_slug Current post type slug, or empty on removal.
	 * @param string[] $selected_taxonomies Managed taxonomies selected for the post type.
	 * @return void
	 */

	private static function sync_taxonomy_relationships( $old_slug, $new_slug, $selected_taxonomies ) {
		$selected_taxonomies = array_map( 'sanitize_key', (array) $selected_taxonomies );
		foreach( self::user_taxonomy_posts_by_slug() as $taxonomy_slug => $post ) {
			$config = WPHAVE_Content_Type_Validator::sanitize_taxonomy( WPHAVE_Content_Types::decode( $post ) );
			$object_types = array_values( array_diff( $config['objectTypes'], array_filter( array( $old_slug, $new_slug ) ) ) );
			if( $new_slug && in_array( $taxonomy_slug, $selected_taxonomies, true ) ) $object_types[] = $new_slug;
			$object_types = array_values( array_unique( $object_types ) );
			if( $object_types === $config['objectTypes'] ) continue;
			$config['objectTypes'] = $object_types;
			wp_update_post( wp_slash( array( 'ID' => $post->ID, 'post_content' => wp_json_encode( $config ) ) ) );
		}
	}

	/**
	 * Synchronize the post type visibility setting used by WPHAVE navigation.
	 *
	 * @param string $storage_type Internal definition post type.
	 * @param array $payload Validated definition payload.
	 * @param string $old_slug Previous slug when updating.
	 * @return void
	 */

	private static function sync_wphave_navigation( $storage_type, $payload, $old_slug = '' ) {
		if( WPHAVE_Content_Types::POST_TYPE !== $storage_type || ! function_exists( 'wphave_data_get' ) || ! function_exists( 'wphave_data_set' ) ) return;
		$items = (array) wphave_data_get( 'site_settings', 'advanced.ui.postTypes', array() );
		$items = array_values( array_diff( $items, array_filter( array( $old_slug, $payload['slug'] ) ) ) );
		if( 'publish' === $payload['status'] && ! empty( $payload['config']['wphave']['showInNavigation'] ) ) $items[] = $payload['slug'];
		wphave_data_set( 'site_settings', 'advanced.ui.postTypes', array_values( array_unique( $items ) ) );
	}

	/**
	 * Remove a deleted post type slug from WPHAVE navigation settings.
	 *
	 * @param string $slug Post type slug.
	 * @return void
	 */

	private static function remove_navigation_slug( $slug ) {
		if( ! function_exists( 'wphave_data_get' ) || ! function_exists( 'wphave_data_set' ) ) return;
		$items = (array) wphave_data_get( 'site_settings', 'advanced.ui.postTypes', array() );
		wphave_data_set( 'site_settings', 'advanced.ui.postTypes', array_values( array_diff( $items, array( $slug ) ) ) );
	}
}

WPHAVE_Content_Types_REST_Controller::init();

endif;
