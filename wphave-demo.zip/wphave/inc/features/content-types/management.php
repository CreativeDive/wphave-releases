<?php

/** Bootstrap Content Types management endpoints. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/rest-controller.php';
