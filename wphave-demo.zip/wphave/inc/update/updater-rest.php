<?php

/**
 * Handles manual update actions and management REST endpoints.
 */

trait WPHAVE_Plugin_Updater_REST {
	/*
	 * INHERITANCE INVARIANT: This trait is composed into the interactive child
	 * updater, while manifest and compatibility traits live on its base class.
	 * Cross-boundary helpers used below must therefore remain protected; private
	 * base methods are not callable from this trait and cause a PHP fatal.
	 */

	/** Register hooks owned only by interactive updater requests. */

	protected function register_interactive_hooks() {
		add_filter('plugin_auto_update_setting_html', [$this, 'auto_update_not_available_info'], 10, 3);
		add_filter('plugin_row_meta', [$this, 'remove_plugin_details_link'], 10, 4);
		add_action('admin_post_wphave_check_updates', [$this, 'manual_check']);
		add_action('rest_api_init', [$this, 'register_rest_routes']);
	}

	/**
	 * Handle the manual "check updates" admin action.
	 *
	 * @return void
	 */

	public function manual_check() {
		if( ! current_user_can('update_plugins') ) {
			wp_die(__('You are not allowed to update plugins.', 'wphave'));
		}

		check_admin_referer('wphave_check_updates');

		// AUTHORIZATION/ADMIN-POST INVARIANT: The nonce proves request intent,
		// not continuing update authority. Nonce hooks are extension-controlled,
		// so repeat Core's mapped capability immediately before cache mutation and
		// outbound update discovery instead of leasing the entry decision.
		if( ! current_user_can('update_plugins') ) {
			wp_die(__('You are not allowed to update plugins.', 'wphave'));
		}

		delete_transient( $this->cache_key );
		delete_site_transient('update_plugins');

		wp_clean_plugins_cache(true);
		wp_update_plugins();

		wp_safe_redirect(
            add_query_arg('wphave_update_checked', 1, admin_url('plugins.php'))
        );

		exit;
	}

	/**
	 * Register REST endpoints used by the React updater UI.
	 *
	 * @return void
	 */

	public function register_rest_routes() {
        register_rest_route('wphave/v1', '/update-status', [
            'methods' => 'GET',
            'permission_callback' => [ $this, 'can_update_plugins' ],
            'callback' => [$this, 'rest_update_status'],
        ]);

        register_rest_route('wphave/v1', '/check-updates', [
            'methods' => 'POST',
            'permission_callback' => [ $this, 'can_update_plugins' ],
            'callback' => [$this, 'rest_check_updates'],
        ]);

        register_rest_route('wphave/v1', '/run-update', [
            'methods' => 'POST',
            'permission_callback' => [ $this, 'can_update_plugins' ],
            'callback' => [$this, 'rest_run_update'],
        ]);
	    }

	/**
	 * Determine whether the current user may update plugins.
	 *
	 * @return bool Whether plugin updates are permitted.
	 */

	public function can_update_plugins() {
		// AUTHORIZATION INVARIANT: WPHAVE does not reinterpret roles or duplicate
		// multisite policy here. Core's mapped update_plugins capability is the
		// sole authority for installing executable plugin code.
		return current_user_can( 'update_plugins' );
	}

	/**
	 * Load plugin administration functions for frontend REST requests.
	 *
	 * @return true|WP_Error True when the plugin API is ready, otherwise an error.
	 */

	private function load_plugin_functions() {
		$required_functions = array(
			'activate_plugin',
			'get_plugin_data',
			'is_plugin_active',
			'wp_clean_plugins_cache',
		);
		$functions_available = static function() use ( $required_functions ) {
			foreach( $required_functions as $function ) {
				if( ! function_exists( $function ) ) {
					return false;
				}
			}

			return true;
		};

		if( $functions_available() ) {
			return true;
		}

		$plugin_functions = ABSPATH . 'wp-admin/includes/plugin.php';

		if( ! is_readable( $plugin_functions ) ) {
			return new WP_Error(
				'wphave_update_core_dependency_missing',
				__(
					'A required WordPress update component is unavailable. Please verify the WordPress installation and try again.',
					'wphave'
				),
				array( 'status' => 500 )
			);
		}

		require_once $plugin_functions;

		if( ! $functions_available() ) {
			return new WP_Error(
				'wphave_update_core_api_unavailable',
				__(
					'The WordPress plugin API could not be initialized. Please verify the WordPress installation and try again.',
					'wphave'
				),
				array( 'status' => 500 )
			);
		}

		return true;
	}

	/**
	 * Load the canonical WordPress plugin updater dependencies.
	 *
	 * WordPress exposes the upgrader through class-wp-upgrader.php, which also
	 * loads Plugin_Upgrader and its skins for backwards compatibility. Never use
	 * the historical wp-upgrader.php path here: it is not part of the supported
	 * Core file layout and is absent from current WordPress installations.
	 *
	 * Every path is checked before loading so an incomplete Core installation is
	 * reported to the React UI instead of terminating the REST request with a PHP
	 * fatal error.
	 *
	 * @return true|WP_Error True when the updater API is ready, otherwise an error.
	 */

	private function load_plugin_upgrader_dependencies() {
		$plugin_functions = $this->load_plugin_functions();

		if( is_wp_error( $plugin_functions ) ) {
			return $plugin_functions;
		}

		$files = array(
			ABSPATH . 'wp-admin/includes/file.php',
			ABSPATH . 'wp-admin/includes/class-wp-upgrader.php',
		);

		foreach( $files as $file ) {
			if( ! is_readable($file) ) {
				return new WP_Error('wphave_update_core_dependency_missing', __('A required WordPress update component is unavailable. Please verify the WordPress installation and try again.', 'wphave'), array('status' => 500));
			}

			require_once $file;
		}

		if( ! class_exists('Plugin_Upgrader') || ! class_exists('Automatic_Upgrader_Skin') ) {
			return new WP_Error('wphave_update_core_api_unavailable', __('The WordPress plugin updater could not be initialized. Please verify the WordPress installation and try again.', 'wphave'), array('status' => 500));
		}

		return true;
	}

	/**
	 * Return update status for the React updater UI.
	 *
	 * @return array
	 */

    public function rest_update_status() {
		$authorization = $this->require_update_authority();
		if( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$plugin_functions = $this->load_plugin_functions();

		if( is_wp_error( $plugin_functions ) ) {
			return $plugin_functions;
		}

        $file = $this->config['plugin_file'];

        $plugin_data = get_plugin_data(
            WP_PLUGIN_DIR . '/' . $file,
            false,
            false
        );

        $current = $plugin_data['Version'] ?? $this->config['version'];

        $data = $this->get_update_data();
		$error = $this->get_update_error();

        $latest = $data['version'] ?? null;

		$compatibility = $data ? $this->validate_runtime_requirements( $data ) : true;

        return [
            'current_version' => $current,
            'available_version' => $latest,
            'has_update' => $latest
                ? version_compare($current, $latest, '<')
                : false,
            'tested' => $data['tested'] ?? '',
            'requires' => $data['requires'] ?? '',
            'requires_php' => $data['requires_php'] ?? '',
            'last_updated' => $data['last_updated'] ?? '',
            'changelog' => $data['changelog'] ?? '',
            'source' => $data['source'] ?? 'wphave',
			'error' => $error['message'] ?? '',
			'error_code' => $error['code'] ?? '',
			'status_known' => ! $error,
			'is_compatible' => ! is_wp_error( $compatibility ),
			'compatibility_error' => is_wp_error( $compatibility ) ? $compatibility->get_error_message() : '',
        ];
    }

	/**
	 * Force WordPress to refresh update data for the React updater UI.
	 *
	 * @return array
	 */

	public function rest_check_updates() {
		$authorization = $this->require_update_authority();
		if( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$plugin_functions = $this->load_plugin_functions();

		if( is_wp_error( $plugin_functions ) ) {
			return $plugin_functions;
		}

		delete_transient($this->cache_key);
		delete_site_transient('update_plugins');
		wp_clean_plugins_cache(true);

		$data = $this->get_update_data();

		if (!$data) {
			$error = $this->get_update_error();

			if ($error) {
				return new WP_Error(
					$error['code'] ?? 'wphave_update_manifest_unavailable',
					$error['message'] ?? __('The update server could not be reached. Please try again later.', 'wphave'),
					[
						'status' => 503,
						'data' => $error['data'] ?? [],
					]
				);
			}
		}

		wp_update_plugins();

		return [
			'success' => true,
			'version' => $data['version'] ?? null,
		];
	}

	/**
	 * Reactivate the plugin using WordPress' native activation API.
	 *
	 * Do not write to active_plugins directly. Using activate_plugin() exposes
	 * the same activation problems WordPress would see and prevents the custom UI
	 * from reporting success when the updated plugin cannot actually load.
	 *
	 * @param string $file Plugin basename.
	 * @param bool $was_network_active Whether the plugin was network-active.
	 * @return true|WP_Error
	 */

	private function restore_plugin_active_state( $file, $was_network_active = false ) {
		if( ! function_exists('activate_plugin') ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$main_file = WP_PLUGIN_DIR . '/' . $file;

		if( ! file_exists( $main_file ) ) {
			return new WP_Error(
				'wphave_plugin_main_file_missing',
				__('The plugin main file is missing after the update attempt.', 'wphave')
			);
		}

		$result = activate_plugin($file, '', (bool) $was_network_active, true);

		if( is_wp_error($result) ) {
			error_log('WPHAVE activation after update failed: ' . $this->normalize_update_diagnostic_text( $result->get_error_message(), 1000 ));
			return $result;
		}

		return true;
	}

	/**
	 * Run the update from the React updater UI.
	 *
	 * This uses Plugin_Upgrader::bulk_upgrade() even for a single plugin because
	 * that is the same Core path used by the WordPress Plugin Screen AJAX updater.
	 * Keeping both entry points on the same path avoids false success states in
	 * the custom UI.
	 *
	 * @return array
	 */

	public function rest_run_update() {
		$authorization = $this->require_update_authority();
		if( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$dependencies = $this->load_plugin_upgrader_dependencies();

		if( is_wp_error($dependencies) ) {
			return array(
				'success' => false,
				'message' => $dependencies->get_error_message(),
				'code' => $dependencies->get_error_code(),
				'data' => $dependencies->get_error_data(),
			);
		}

		$file = $this->config['plugin_file'];
		$was_active = is_plugin_active($file);
		$was_network_active = class_exists( 'WPHAVE_Multisite' ) && WPHAVE_Multisite::is_plugin_network_active($file);

		delete_transient($this->cache_key);
		delete_site_transient('update_plugins');
		wp_clean_plugins_cache(true);
		wp_update_plugins();

		$updates = get_site_transient('update_plugins');

		if (empty($updates->response[$file])) {
			$error = $this->get_update_error();

			if ($error) {
				return [
					'success' => false,
					'message' => $error['message'] ?? __('The update server could not be reached. Please try again later.', 'wphave'),
					'code' => $error['code'] ?? 'wphave_update_manifest_unavailable',
					'data' => $error['data'] ?? [],
				];
			}

			return [
				'success' => false,
				'message' => __('No update available.', 'wphave'),
			];
		}

		$manifest = $this->get_update_data();
		// SECURITY INVARIANT: The update transient is discovery state, not install
		// authority. A validated current manifest and its runtime requirements must
		// be re-established immediately before WordPress may replace plugin files.
		$compatibility = is_array( $manifest ) ? $this->validate_runtime_requirements( $manifest ) : new WP_Error( 'wphave_update_manifest_unavailable', __( 'The update requirements could not be verified.', 'wphave' ), array( 'status' => 503 ) );
		if( is_wp_error( $compatibility ) ) {
			return array(
				'success' => false,
				'message' => $compatibility->get_error_message(),
				'code' => $compatibility->get_error_code(),
				'data' => $compatibility->get_error_data(),
			);
		}

		$authorization = $this->require_update_authority();
		// AUTHORIZATION/TOCTOU INVARIANT: Manifest retrieval, cache refresh and
		// update hooks may run arbitrary extension code after the entry check. Core's
		// live update_plugins capability must therefore still hold immediately before
		// executable plugin files are replaced; earlier authority is never leased
		// across those phases.
		if( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$skin = new Automatic_Upgrader_Skin();
		$upgrader = new Plugin_Upgrader($skin);

		$results = $upgrader->bulk_upgrade([$file]);
		$result = is_array($results) && array_key_exists($file, $results)
			? $results[$file]
			: $results;

		delete_site_transient('update_plugins');
		wp_clean_plugins_cache(true);

		if (is_wp_error($result)) {
			$reactivation = ($was_active || $was_network_active)
				? $this->restore_plugin_active_state($file, $was_network_active)
				: true;

			return [
				'success' => false,
				'message' => $result->get_error_message(),
				'code' => $result->get_error_code(),
				'data' => $result->get_error_data(),
				'reactivated' => ! is_wp_error($reactivation),
				'activationError' => is_wp_error($reactivation) ? $reactivation->get_error_message() : null,
			];
		}

		if (!$result) {
			$reactivation = ($was_active || $was_network_active)
				? $this->restore_plugin_active_state($file, $was_network_active)
				: true;

			return [
				'success' => false,
				'message' => __('Plugin update failed.', 'wphave'),
				'reactivated' => ! is_wp_error($reactivation),
				'activationError' => is_wp_error($reactivation) ? $reactivation->get_error_message() : null,
			];
		}

		if ($was_active || $was_network_active) {
			$activation = $this->restore_plugin_active_state($file, $was_network_active);

			if (is_wp_error($activation)) {
				return [
					'success' => false,
					'message' => $activation->get_error_message(),
				];
			}
		}

		return [
			'success' => true,
			'message' => __('Plugin updated successfully.', 'wphave'),
			'reload' => true,
		];
	}

	private function require_update_authority() {
		// AUTHORIZATION INVARIANT: REST route permission is only the first gate.
		// Every public updater callback must re-check Core update_plugins before
		// inspecting package state, refreshing caches, fetching, or replacing code.
		if( $this->can_update_plugins() ) {
			return true;
		}

		return new WP_Error(
			'wphave_update_forbidden',
			__( 'You are not allowed to update plugins.', 'wphave' ),
			array( 'status' => 403 )
		);
	}

}
