<?php

/**
 * Coordinates native WordPress update integration for WPHAVE.
 */

class WPHAVE_Plugin_Updater_Base {

	use WPHAVE_Plugin_Updater_Manifest;
	use WPHAVE_Plugin_Updater_Package;
	use WPHAVE_Plugin_Updater_Compatibility;

	/** @var WPHAVE_Plugin_Updater|null */
	private static $instance = null;

	/**
	 * Runtime configuration for plugin slug, manifest URL, file basename and UI metadata.
	 *
	 * @var array
	 */

	protected $config;

	/**
	 * Transient key for the parsed update manifest.
	 *
	 * @var string
	 */

	protected $cache_key;

	/**
	 * Transient key for the most recent manifest fetch error.
	 *
	 * This keeps "no update available" separate from "the update server could
	 * not be reached", which matters for the React updater UI.
	 *
	 * @var string
	 */

	protected $error_key;

	/**
	 * Build the updater configuration and stable transient keys.
	 *
	 * @param array $config Updater configuration.
	 */

	public function __construct( $config = [] ) {
		$this->config = wp_parse_args($config, [
			'slug' => '',
			'name' => '',
			'author' => '',
			'homepage' => '',
			'plugin_file' => '',
			'version' => '',
			'manifest_url' => '',

			'support_auto_updates' => false,
			// This public broker URL is the long-lived client contract. Storage
			// providers remain a server concern and may change without a plugin release.
			'download_url' => 'https://wphave.com/server/updates/download.php',

			'cache_ttl' => 10 * MINUTE_IN_SECONDS,
			'error_ttl' => 5 * MINUTE_IN_SECONDS,
		]);

		$this->cache_key = 'wphave_update_' . md5( $this->config['slug'] );
		$this->error_key = 'wphave_update_error_' . md5( $this->config['slug'] );
	}

	/**
	 * Register updater hooks.
	 *
	 * Hook order matters:
	 * - `disable_external_update_notice()` runs first to remove false update data
	 *   from WordPress.org or other sources.
	 * - `inject_update()` runs later and adds only the wphave manifest result.
	 * - The updater intentionally does not hook into `site_transient_update_plugins`
	 *   for injection. Updates are written when WordPress refreshes the transient,
	 *   which keeps the Plugin Screen and REST updater behavior predictable.
	 *
	 * @return void
	 */

	public function init() {
		add_filter('pre_set_site_transient_update_plugins', [$this, 'disable_external_update_notice'], 12);
		add_filter('pre_set_site_transient_update_plugins', [$this, 'inject_update'], 99);

		add_filter('plugins_api', [$this, 'plugin_info'], 20, 3);
		add_filter('auto_update_plugin', [$this, 'auto_update'], 10, 2);

		add_filter('upgrader_pre_download', [$this, 'preflight_download'], 10, 4);
		add_filter('upgrader_source_selection', [$this, 'validate_update_source'], 10, 4);
		add_filter('upgrader_post_install', [$this, 'post_install_check'], 10, 3);

		add_action('upgrader_process_complete', [$this, 'after_update'], 10, 2);

		/*
		 * PERFORMANCE INVARIANT: Scheduled update checks and automatic installs
		 * retain manifest and package verification, but never register interactive
		 * plugin-row, manual-action or REST UI hooks.
		 */
		$this->register_interactive_hooks();
	}

	/** Interactive updater hooks are absent from the worker composition. */

	protected function register_interactive_hooks() {
	}

	/**
	 * Boot the configured plugin updater once.
	 *
	 * @return WPHAVE_Plugin_Updater Shared updater instance.
	 */

	public static function boot() {
		if( self::$instance === null ) {
			self::$instance = new static( [
				'slug' => 'wphave',
				'name' => WPHAVE_PLUGIN_NAME,
				'author' => '<a href="' . esc_url( WPHAVE_AUTHOR_URL ) . '">' . esc_html( WPHAVE_AUTHOR_NAME ) . '</a>',
				'homepage' => WPHAVE_AUTHOR_URL,
				'plugin_file' => WPHAVE_BASENAME,
				'version' => WPHAVE_VERSION,
				// This endpoint is embedded in every release. Keep it stable or deploy a
				// server-side bridge before a future client URL is shipped.
				'manifest_url' => 'https://wphave.com/server/updates/update.php',
				'support_auto_updates' => false,
			] );
			self::$instance->init();
		}

		return self::$instance;
	}

}

if( trait_exists( 'WPHAVE_Plugin_Updater_REST', false ) ) {
	class WPHAVE_Plugin_Updater extends WPHAVE_Plugin_Updater_Base {
		use WPHAVE_Plugin_Updater_REST;
	}
} else {
	class WPHAVE_Plugin_Updater extends WPHAVE_Plugin_Updater_Base {
	}
}

add_action( 'plugins_loaded', [ 'WPHAVE_Plugin_Updater', 'boot' ], 1 );
