<?php

/**
 * Bootstrap the WPHAVE plugin updater.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once wphave_dir() . 'inc/features/security/file-identity.php';
require_once __DIR__ . '/updater-manifest.php';
require_once __DIR__ . '/updater-package.php';
require_once __DIR__ . '/updater-compatibility.php';
if( ! wp_doing_cron() ) {
	require_once __DIR__ . '/updater-rest.php';
}
require_once __DIR__ . '/plugin-updater.php';
