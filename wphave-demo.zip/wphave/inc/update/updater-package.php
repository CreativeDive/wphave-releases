<?php

/**
 * Validates packages around WordPress' native update and rollback lifecycle.
 */

trait WPHAVE_Plugin_Updater_Package {

	/**
	 * Version identity frozen from the checksum-verified package manifest for the
	 * current native updater request.
	 *
	 * @var string
	 */

	private $verified_package_version = '';

	/**
	 * Control WordPress automatic updates for this plugin.
	 *
	 * Automatic updates are disabled by default because release publishing is tied
	 * to a validated ZIP workflow and a controlled server manifest update.
	 *
	 * @param bool|null $update Whether WordPress should auto-update.
	 * @param object $item Update item.
	 * @return bool|null
	 */

	public function auto_update( $update, $item ) {
		if( empty( $item->plugin ) || $item->plugin !== $this->config['plugin_file'] ) {
			return $update;
		}

		return $this->config['support_auto_updates'] ? $update : false;
	}

	/**
	 * Validate package URL before WordPress downloads it.
	 *
	 * WordPress still owns extraction, filesystem credentials and installation.
	 * This last pre-write boundary downloads through Core's download_url() so the
	 * exact archive can be matched against the broker's SHA-256 before extraction.
	 * The work done here is:
	 * - block empty, incompatible or untrusted package metadata,
	 * - return only a checksum-verified Core temporary file.
	 *
	 * WPHAVE deliberately does not create its own filesystem backup here. Core's
	 * Plugin_Upgrader connects through WP_Filesystem before this hook and moves the
	 * installed plugin into `wp-content/upgrade-temp-backup` before replacement.
	 * This Core safety mechanism exists since WordPress 6.3 and is therefore inside
	 * WPHAVE's supported WordPress range; the contract smoke protects that boundary.
	 * Returning WP_Error later in post_install_check() activates Core's restore
	 * path without introducing direct-filesystem assumptions on managed hosting.
	 *
	 * @param bool|WP_Error $reply Existing pre-download result.
	 * @param string $package Package URL from the update transient.
	 * @param WP_Upgrader $upgrader Upgrader instance.
	 * @param array $hook_extra Upgrader context.
	 * @return bool|WP_Error
	 */

	public function preflight_download( $reply, $package, $upgrader, $hook_extra ) {
		if( empty( $hook_extra['plugin'] ) || $hook_extra['plugin'] !== $this->config['plugin_file'] ) {
			return $reply;
		}

		// SECURITY: Never retain identity from an earlier download attempt in the
		// same PHP process. Only a fresh digest match may authorize extraction.
		$this->verified_package_version = '';

		// Core and the custom updater both pass through this hook. Re-check the
		// manifest here so an incompatible release cannot be installed through a
		// different UI or a stale update transient.
		$manifest = $this->get_update_data();
		$compatibility = is_array( $manifest ) ? $this->validate_runtime_requirements( $manifest ) : new WP_Error( 'wphave_update_manifest_unavailable', __( 'The update requirements could not be verified.', 'wphave' ) );
		if( is_wp_error( $compatibility ) ) return $compatibility;

		if( empty($package) ) {
			return new WP_Error(
				'wphave_update_package_missing',
				__('The update package URL is missing.', 'wphave')
			);
		}

		if( ! $this->package_url_is_allowed( $package, $manifest['version'], $manifest['file_name'] ) ) {
			return new WP_Error(
				'wphave_update_package_host_invalid',
					__('The update package must be downloaded through the official WPHAVE update broker.', 'wphave')
			);
		}

		// Let Core download the archive, but return its temporary file only after
		// the bytes match the digest published by the release manifest.
		$download = download_url( $package, 300 );
		if( is_wp_error( $download ) ) return $download;
		try {
			$identity = WPHAVE_Security_File_Identity::inspect( $download, __( 'The downloaded update package could not be inspected safely.', 'wphave' ) );
		} catch( RuntimeException $error ) {
			wp_delete_file( $download );
			return new WP_Error( 'wphave_update_package_identity_invalid', $error->getMessage() );
		}

		// SECURITY INVARIANT: Package authorization is calculated from one locked,
		// path-bound regular descriptor. Links and exchanged temporary nodes cannot
		// inherit the broker manifest's extraction authority.
		if( ! hash_equals( strtolower( (string) $manifest['sha256'] ), $identity['checksum'] ) ) {
			wp_delete_file( $download );
			return new WP_Error( 'wphave_update_checksum_mismatch', __('The downloaded update package failed its integrity check.', 'wphave') );
		}

		// SECURITY INVARIANT: Freeze the identity that authorized these exact bytes.
		// Source validation must not fetch or reinterpret a newer manifest later.
		$this->verified_package_version = (string) $manifest['version'];

		return $download;
	}

	/**
	 * Verify the stable package identity without coupling old updaters to future
	 * internal file layouts.
	 *
	 * The main plugin file and its WordPress headers form the public package
	 * contract. Files below `inc/`, `build/` or any other internal directory may
	 * be moved or replaced by future releases and must never be required here.
	 * The release ZIP audit remains responsible for validating the complete file
	 * set required by the version that is being published.
	 *
	 * @param string $dir Extracted or installed plugin directory.
	 * @return bool
	 */

	private function package_dir_has_valid_plugin( $dir, $expected_version = '' ) {
		$plugin_file = trailingslashit($dir) . basename($this->config['plugin_file']);

		if( ! is_readable($plugin_file) ) {
			error_log('WPHAVE package main plugin file is missing or unreadable: ' . $this->normalize_update_diagnostic_text( $plugin_file, 500 ));
			return false;
		}

		$headers = get_file_data($plugin_file, [
			'name' => 'Plugin Name',
			'version' => 'Version',
			'text_domain' => 'Text Domain',
		]);

		if(
			empty($headers['name'])
			|| strtolower((string) $headers['name']) !== 'wphave'
			|| empty($headers['version'])
			|| ($headers['text_domain'] ?? '') !== 'wphave'
		) {
			error_log('WPHAVE package main plugin file has an invalid identity or version header: ' . $this->normalize_update_diagnostic_text( $plugin_file, 500 ));
			return false;
		}

		if( $expected_version !== '' && ! hash_equals( (string) $expected_version, (string) $headers['version'] ) ) {
			error_log('WPHAVE package version does not match its verified manifest identity: ' . $this->normalize_update_diagnostic_text( $plugin_file, 500 ));
			return false;
		}

		return true;
	}

	/**
	 * Validate the extracted update package before installation.
	 *
	 * Older versions renamed/moved the extracted source manually. That caused the
	 * custom updater to diverge from WordPress' native behavior. The current code
	 * only validates the stable plugin identity and returns the original source path so Core
	 * can continue its normal installation process.
	 *
	 * @param string|WP_Error $source Extracted package source.
	 * @param string $remote_source Parent upgrade directory.
	 * @param WP_Upgrader $upgrader Upgrader instance.
	 * @param array $hook_extra Upgrader context.
	 * @return string|WP_Error
	 */

    public function validate_update_source( $source, $remote_source, $upgrader, $hook_extra ) {
        if( empty( $hook_extra['plugin'] ) || $hook_extra['plugin'] !== $this->config['plugin_file'] ) {
            return $source;
        }

        if( is_wp_error( $source ) ) {
            return $source;
        }

		// SECURITY INVARIANT: The extracted source is accepted only as the identity
		// frozen after checksum verification. Missing identity fails closed because
		// this hook must never validate an unbound local archive.
		if( $this->verified_package_version === '' || ! $this->package_dir_has_valid_plugin( $source, $this->verified_package_version ) ) {
			return new WP_Error(
				'wphave_update_invalid_package',
				__('The update package does not contain a valid WPHAVE plugin.', 'wphave')
            );
        }

        return $source;
    }

	/**
	 * Validate the installed plugin directory before Core completes the update.
	 *
	 * This catches edge cases where extraction/install technically completed but
	 * the stable plugin identity is missing. Returning WP_Error is intentional:
	 * Plugin_Upgrader then restores its native temporary backup through the active
	 * WP_Filesystem transport. Do not add a second WPHAVE rollback implementation;
	 * it would bypass hosting credentials and duplicate Core's safety mechanism.
	 *
	 * @param bool|WP_Error $response Current post-install response.
	 * @param array $hook_extra Upgrader context.
	 * @param array $result Installation result.
	 * @return bool|WP_Error
	 */

	public function post_install_check( $response, $hook_extra, $result ) {
		if( empty( $hook_extra['plugin'] ) || $hook_extra['plugin'] !== $this->config['plugin_file'] ) {
			return $response;
		}

		$plugin_dir = WP_PLUGIN_DIR . '/' . dirname($this->config['plugin_file']);

		// SECURITY INVARIANT: Post-install validation consumes the same manifest
		// version frozen from the checksum-approved download. A structurally valid
		// WPHAVE directory from another release must trigger Core's native rollback.
		if( $this->installed_package_matches_verified_version( $plugin_dir ) ) {
			return $response;
		}

		return new WP_Error(
			'wphave_update_invalid_install',
			__('The installed update was not a valid WPHAVE plugin. WordPress will restore the previous version.', 'wphave')
		);
	}

	/**
	 * Clear updater caches after WordPress completes an update.
	 *
	 * @param WP_Upgrader $upgrader Upgrader instance.
	 * @param array $options Update context.
	 * @return void
	 */

	public function after_update( $upgrader, $options ) {
		if(
			($options['action'] ?? '') === 'update' &&
			($options['type'] ?? '') === 'plugin' &&
			!empty($options['plugins']) &&
				in_array($this->config['plugin_file'], $options['plugins'], true)
			) {
				$plugin_dir = WP_PLUGIN_DIR . '/' . dirname($this->config['plugin_file']);
				if( $this->installed_package_matches_verified_version( $plugin_dir ) ) {
					$this->record_lifecycle_update();
				}
			delete_transient( $this->cache_key );
			delete_site_transient('update_plugins');
			wp_clean_plugins_cache(true);
		}
	}

	/**
	 * Requires an installed package to retain the download-authorized version.
	 */
	private function installed_package_matches_verified_version( string $plugin_dir ): bool {
		return $this->verified_package_version !== ''
			&& $this->package_dir_has_valid_plugin( $plugin_dir, $this->verified_package_version );
	}

	/**
	 * Record the completed plugin version transition in lifecycle metadata.
	 *
	 * @return void
	 */

	private function record_lifecycle_update() {
		if( ! class_exists( 'WPHAVE_Lifecycle' ) || ! method_exists( 'WPHAVE_Lifecycle', 'record_version_update' ) ) {
			return;
		}

		if( ! function_exists( 'get_plugin_data' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$plugin_data = get_plugin_data( WP_PLUGIN_DIR . '/' . $this->config['plugin_file'], false, false );
		$new_version = (string) ( $plugin_data['Version'] ?? '' );
		if( $new_version === '' || version_compare( $new_version, (string) $this->config['version'], '<=' ) ) return;

		WPHAVE_Lifecycle::record_version_update( (string) $this->config['version'], $new_version );
	}

}
