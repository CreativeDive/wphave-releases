<?php

/**
 * Resolves, validates, caches, and exposes update manifest data.
 */

trait WPHAVE_Plugin_Updater_Manifest {
	private const MAX_MANIFEST_BYTES = 262144;

	/**
	 * Normalize updater diagnostics without depending on the installed package's
	 * internal directory layout. Update and rollback code must remain standalone.
	 *
	 * @param mixed $value Raw diagnostic value.
	 * @param int   $max_length Maximum retained length.
	 * @return string
	 */
	protected function normalize_update_diagnostic_text($value, $max_length = 500) {
		$value = (string) $value;
		$value = preg_replace(
			'/\bBearer\s+[^\s]+|\bBasic\s+[^\s]+/i',
			'[authorization redacted]',
			$value,
		);
		$value = preg_replace(
			'/\b(password|passwd|passphrase|token|secret|api[_-]?key|client[_-]?secret|authorization)\s*[=:]\s*["\']?[^\s,"\';]+/i',
			'$1=[redacted]',
			$value,
		);

		foreach (['ABSPATH', 'WP_CONTENT_DIR', 'WP_PLUGIN_DIR'] as $constant) {
			if (defined($constant)) {
				$value = str_replace(
					wp_normalize_path(constant($constant)),
					'[site]/',
					wp_normalize_path($value),
				);
			}
		}

		$value = wp_strip_all_tags($value);
		$value = preg_replace('/[\x00-\x1F\x7F]+/u', ' ', $value);
		$value = preg_replace('/\s+/u', ' ', $value);

		return trim(substr((string) $value, 0, max(0, (int) $max_length)));
	}

	/**
	 * Public accessor used by internal UI code.
	 *
	 * @return array|false
	 */

	public function get_update() {
		return $this->get_update_data();
	}

	/**
	 * Clear the cached manifest response.
	 *
	 * @return void
	 */

	public function clear_cache() {
		delete_transient($this->cache_key);
		delete_transient($this->error_key);
	}

	/**
	 * Store the last manifest fetch error for short-lived UI feedback.
	 *
	 * @param string $code Stable error code.
	 * @param string $message User-facing error message.
	 * @param array $data Optional diagnostic data.
	 * @return void
	 */

	private function set_update_error($code, $message, $data = []) {
		set_transient(
			$this->error_key,
			[
				'code' => $code,
				'message' => $message,
				'data' => $data,
			],
			(int) $this->config['error_ttl'],
		);
	}

	/**
	 * Clear the stored manifest fetch error after a successful broker response.
	 *
	 * @return void
	 */

	private function clear_update_error() {
		delete_transient($this->error_key);
	}

	/**
	 * Get the most recent manifest fetch error, if any.
	 *
	 * @return array|null
	 */

	protected function get_update_error() {
		$error = get_transient($this->error_key);

		return is_array($error) ? $error : null;
	}

	/**
	 * Remove update data for this plugin before adding our own manifest result.
	 *
	 * This protects against accidental matches from WordPress.org or another
	 * updater using the same plugin basename. It must run before `inject_update()`.
	 *
	 * @param object|mixed $transient WordPress update transient.
	 * @return object|mixed
	 */

	public function disable_external_update_notice($transient) {
		if (!is_object($transient)) {
			return $transient;
		}

		$file = $this->config['plugin_file'];

		if (
			isset($transient->response) &&
			is_array($transient->response) &&
			isset($transient->response[$file])
		) {
			unset($transient->response[$file]);
		}

		if (
			isset($transient->no_update) &&
			is_array($transient->no_update) &&
			isset($transient->no_update[$file])
		) {
			unset($transient->no_update[$file]);
		}

		return $transient;
	}

	/**
	 * Replace the auto-update UI text when automatic updates are disabled.
	 *
	 * Auto-updates are disabled for now because this updater is intentionally tied
	 * to a controlled release process and package validation step.
	 *
	 * @param string $html Existing auto-update setting HTML.
	 * @param string $plugin_file Plugin basename.
	 * @param array $plugin_data Plugin header data.
	 * @return string
	 */

	public function auto_update_not_available_info($html, $plugin_file, $plugin_data) {
		if ($plugin_file !== $this->config['plugin_file']) {
			return $html;
		}

		if ($this->config['support_auto_updates']) {
			return $html;
		}

		return __('Auto-updates are not available for this plugin.', 'wphave');
	}

	/**
	 * Remove the standard "View details" link from the plugin row.
	 *
	 * The plugin does not currently provide a complete public details modal. The
	 * update notice can still use WordPress' update UI; this only removes the row
	 * metadata link below the plugin description.
	 *
	 * @param string[] $plugin_meta Row metadata links.
	 * @param string $plugin_file Plugin basename.
	 * @param array $plugin_data Plugin header data.
	 * @param string $status Current plugin status tab.
	 * @return string[]
	 */

	public function remove_plugin_details_link($plugin_meta, $plugin_file, $plugin_data, $status) {
		if ($plugin_file !== $this->config['plugin_file'] || !is_array($plugin_meta)) {
			return $plugin_meta;
		}

		return array_values(
			array_filter($plugin_meta, static function ($meta) {
				return false === strpos((string) $meta, 'open-plugin-details-modal') &&
					false === strpos((string) $meta, 'plugin-install.php?tab=plugin-information');
			}),
		);
	}

	/**
	 * Inject the custom update response into WordPress' plugin update transient.
	 *
	 * The update object follows WordPress' expected shape. The `package` value is
	 * the canonical WPHAVE broker URL; the broker owns the replaceable storage
	 * provider while WordPress performs installation natively.
	 *
	 * @param object|mixed $transient WordPress update transient.
	 * @return object|mixed
	 */

	public function inject_update($transient) {
		if (!is_object($transient)) {
			return $transient;
		}

		$file = $this->config['plugin_file'];

		if (!isset($transient->response) || !is_array($transient->response)) {
			$transient->response = [];
		}

		if (!isset($transient->no_update) || !is_array($transient->no_update)) {
			$transient->no_update = [];
		}

		$current_version = $this->config['version'];

		if (isset($transient->checked[$file])) {
			$current_version = $transient->checked[$file];
		}

		$data = $this->get_update_data();

		if ($data && version_compare($current_version, $data['version'], '<')) {
			$transient->response[$file] = (object) [
				'id' => $file,
				'slug' => $this->config['slug'],
				'plugin' => $file,
				'new_version' => $data['version'],
				'package' => $data['download_url'],
				'url' => $this->config['homepage'],
				'tested' => $data['tested'] ?? '',
				'requires' => $data['requires'] ?? '',
				'requires_php' => $data['requires_php'] ?? '',
			];

			unset($transient->no_update[$file]);

			return $transient;
		}

		if (!isset($transient->response[$file])) {
			$transient->no_update[$file] = (object) [
				'id' => $file,
				'slug' => $this->config['slug'],
				'plugin' => $file,
				'new_version' => $current_version,
				'package' => '',
				'url' => $this->config['homepage'],
			];
		}

		return $transient;
	}

	/**
	 * Get update manifest data, using a short-lived cache.
	 *
	 * Invalid cached data is discarded so broken manifests do not poison the
	 * updater. A false return means "no usable update data", not necessarily an
	 * error the user should see.
	 *
	 * @return array|false
	 */

	protected function get_update_data() {
		$cached = get_transient($this->cache_key);

		if (is_array($cached) && !empty($cached['no_update'])) {
			$this->clear_update_error();
			return false;
		}

		if (is_array($cached) && $this->is_valid_update($cached)) {
			$this->clear_update_error();
			return $cached;
		}

		if (false !== $cached) {
			delete_transient($this->cache_key);
		}

		$data = $this->fetch_manifest();

		if (!$this->is_valid_update($data)) {
			// A valid "no update" broker response is a cacheable result. Without a
			// sentinel every status read would contact the broker again because the
			// public return contract intentionally uses false for this state.
			if (!$this->get_update_error()) {
				set_transient(
					$this->cache_key,
					['no_update' => true],
					(int) $this->config['cache_ttl'],
				);
			}
			return false;
		}

		$this->clear_update_error();
		set_transient($this->cache_key, $data, $this->get_update_cache_ttl($data));

		return $data;
	}

	/**
	 * Force a manifest refresh.
	 *
	 * @return array|false
	 */

	private function get_fresh_update_data() {
		delete_transient($this->cache_key);

		return $this->get_update_data();
	}

	/**
	 * Fetch the update manifest from the wphave update broker.
	 *
	 * The broker runs outside WordPress and returns plain JSON. It should not
	 * perform license checks for update access; updates must remain available
	 * regardless of whether Pro features are currently licensed.
	 *
	 * @return array|false
	 */

	private function fetch_manifest() {
		if (empty($this->config['manifest_url'])) {
			$this->set_update_error(
				'wphave_update_manifest_missing',
				__('The update server URL is not configured.', 'wphave'),
			);
			return false;
		}

		$url = add_query_arg(
			[
				'plugin' => $this->config['slug'],
				'install' => $this->installation_fingerprint(),
				// Website identity selects explicitly configured preview offers.
				'site' => home_url('/'),
				'edition' =>
					function_exists('wphave_has_pro_access') && wphave_has_pro_access()
						? 'pro'
						: 'free',
				'environment' => $this->installation_environment(),
				'version' => $this->config['version'],
			],
			$this->config['manifest_url'],
		);

		// SECURITY INVARIANT: The configured update endpoint may return manifest
		// bytes only. Redirects must not delegate WPHAVE's server-side network
		// authority, and a manifest response may never consume unbounded memory.
		// One extra byte is an overflow sentinel; a truncated JSON prefix must never
		// become update authority even when that prefix remains syntactically valid.
		$response = wp_safe_remote_get($url, [
			'timeout' => 5,
			'redirection' => 0,
			'sslverify' => true,
			'limit_response_size' => self::MAX_MANIFEST_BYTES + 1,
			'headers' => [
				'Accept' => 'application/json',
			],
		]);

		if (is_wp_error($response)) {
			$this->set_update_error(
				'wphave_update_manifest_unavailable',
				__(
					'The update server could not be reached. Please check your connection and try again.',
					'wphave',
				),
				[
					'wp_error_code' => $response->get_error_code(),
					'wp_error_message' => $response->get_error_message(),
				],
			);
			return false;
		}

		$response_code = (int) wp_remote_retrieve_response_code($response);

		if (200 !== $response_code) {
			$this->set_update_error(
				'wphave_update_manifest_http_error',
				__(
					'The update server returned an unexpected response. Please try again later.',
					'wphave',
				),
				[
					'status' => $response_code,
				],
			);
			return false;
		}

		$body = (string) wp_remote_retrieve_body($response);

		if (strlen($body) > self::MAX_MANIFEST_BYTES) {
			$this->set_update_error(
				'wphave_update_manifest_too_large',
				__(
					'The update server returned more update data than allowed. Please try again later.',
					'wphave',
				),
			);
			return false;
		}

		$data = json_decode($body, true);

		if (!is_array($data)) {
			$this->set_update_error(
				'wphave_update_manifest_invalid_json',
				__(
					'The update server returned invalid update data. Please try again later.',
					'wphave',
				),
			);
			return false;
		}

		if (!empty($data['no_update'])) {
			$this->clear_update_error();
			return false;
		}

		if (isset($data['version'], $data['download_url'])) {
			$this->clear_update_error();
			return $data;
		}

		if (isset($data[$this->config['slug']]) && is_array($data[$this->config['slug']])) {
			$this->clear_update_error();
			return $data[$this->config['slug']];
		}

		$this->set_update_error(
			'wphave_update_manifest_invalid_shape',
			__('The update server response is missing required update fields.', 'wphave'),
		);

		return false;
	}

	/**
	 * Return the stable, non-reversible installation reference used by the update broker.
	 *
	 * IDENTITY INVARIANT: Updates preserve this reference while home URL and auth
	 * salt remain unchanged. A move or salt rotation creates a new reference; an
	 * exact clone with both values unchanged cannot be distinguished. Do not change
	 * this algorithm without a migration: that would recount existing installations.
	 * The manifest separately sends the site URL for preview selection.
	 *
	 * @return string
	 */

	private function installation_fingerprint() {
		return hash_hmac('sha256', home_url('/'), wp_salt('auth'));
	}

	/**
	 * Classify whether this update check belongs to a countable public site.
	 *
	 * Statistics receive only this classification. The manifest request separately
	 * includes the home URL for configured preview selection.
	 *
	 * @return string Public or excluded.
	 */

	private function installation_environment() {
		if (
			(defined('WPHAVE_PLAYGROUND_DEMO') && WPHAVE_PLAYGROUND_DEMO) ||
			(defined('WPHAVE_PLAYGROUND_DIAGNOSTICS') && WPHAVE_PLAYGROUND_DIAGNOSTICS) ||
			(defined('WP_PLAYGROUND') && WP_PLAYGROUND) ||
			(defined('IS_WORDPRESS_PLAYGROUND') && IS_WORDPRESS_PLAYGROUND)
		) {
			return 'excluded';
		}
		if (
			function_exists('wp_get_environment_type') &&
			in_array(wp_get_environment_type(), ['local', 'development', 'staging'], true)
		) {
			return 'excluded';
		}
		$host = strtolower((string) wp_parse_url(home_url('/'), PHP_URL_HOST));
		if (
			!$host ||
			in_array($host, ['localhost', 'playground.internal'], true) ||
			str_ends_with($host, '.localhost') ||
			str_ends_with($host, '.local') ||
			str_ends_with($host, '.test') ||
			str_ends_with($host, '.invalid') ||
			str_contains($host, 'playground.wordpress.net') ||
			str_contains($host, 'wp-playground') ||
			str_contains($host, 'wp-env')
		) {
			return 'excluded';
		}
		if (
			filter_var($host, FILTER_VALIDATE_IP) &&
			!filter_var(
				$host,
				FILTER_VALIDATE_IP,
				FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE,
			)
		) {
			return 'excluded';
		}
		return 'public';
	}

	/**
	 * Validate manifest data and ensure it describes a newer version.
	 *
	 * @param mixed $data Manifest data.
	 * @return bool
	 */

	private function is_valid_update($data) {
		if (!is_array($data)) {
			return false;
		}

		if (!empty($data['no_update'])) {
			return false;
		}

		if (empty($data['version']) || empty($data['download_url']) || empty($data['file_name'])) {
			return false;
		}

		// Runtime requirements and the archive digest are mandatory release
		// contracts. Treating missing values as compatible would silently disable
		// the two checks precisely when a broker is incomplete or misconfigured.
		foreach (['requires', 'requires_php'] as $requirement) {
			if (
				empty($data[$requirement]) ||
				!preg_match('/^\d+(?:\.\d+){1,3}$/', (string) $data[$requirement])
			) {
				return false;
			}
		}

		if (empty($data['sha256']) || !preg_match('/^[a-f0-9]{64}$/i', (string) $data['sha256'])) {
			return false;
		}
		if (basename((string) $data['file_name']) !== 'wphave-' . $data['version'] . '.zip') {
			return false;
		}
		if (
			!$this->package_url_is_allowed(
				(string) $data['download_url'],
				(string) $data['version'],
				(string) $data['file_name'],
			)
		) {
			return false;
		}

		if (version_compare($this->config['version'], $data['version'], '>=')) {
			return false;
		}

		return true;
	}

	/**
	 * Get manifest cache duration.
	 *
	 * The canonical broker URL is stable and does not expose a storage-provider
	 * token, so the cache can use the configured TTL.
	 *
	 * @param array $data Manifest data.
	 * @return int
	 */

	private function get_update_cache_ttl($data) {
		return max(60, (int) $this->config['cache_ttl']);
	}

	/**
	 * Check whether a package URL points to the stable WPHAVE download broker.
	 *
	 * The provider behind this endpoint is deliberately not part of the released
	 * client contract. The broker may redirect to GitHub today and another object
	 * store later; SHA-256 verification remains the provider-neutral trust boundary.
	 *
	 * @param string $package Package URL.
	 * @return bool
	 */

	private function package_url_is_allowed($package, $version = '', $file_name = '') {
		$package_authority = wp_parse_url($package);
		$broker_authority = wp_parse_url($this->config['download_url']);

		if (
			!is_array($package_authority) ||
			!is_array($broker_authority) ||
			empty($package_authority['host']) ||
			empty($broker_authority['host']) ||
			'https' !== strtolower((string) ($package_authority['scheme'] ?? '')) ||
			'https' !== strtolower((string) ($broker_authority['scheme'] ?? ''))
		) {
			return false;
		}

		// SECURITY INVARIANT: A manifest may authorize only the configured HTTPS
		// broker authority and path for this plugin and exact release. URL
		// credentials, alternate ports, provider URLs and lookalike hosts or paths
		// never become executable update sources.
		$package_port = (int) ($package_authority['port'] ?? 443);
		$broker_port = (int) ($broker_authority['port'] ?? 443);
		if (
			!empty($package_authority['user']) ||
			!empty($package_authority['pass']) ||
			!empty($broker_authority['user']) ||
			!empty($broker_authority['pass']) ||
			$package_port !== $broker_port ||
			!hash_equals(
				strtolower((string) $broker_authority['host']),
				strtolower((string) $package_authority['host']),
			) ||
			!hash_equals(
				(string) ($broker_authority['path'] ?? ''),
				(string) ($package_authority['path'] ?? ''),
			)
		) {
			return false;
		}

		parse_str((string) ($package_authority['query'] ?? ''), $query);
		return ($query['plugin'] ?? '') === $this->config['slug'] &&
			($query['version'] ?? '') === $version;
	}

	/**
	 * Provide metadata for WordPress' plugin information API.
	 *
	 * The normal row-level "View details" link is removed, but WordPress may still
	 * request plugin info from update notices or other admin contexts. Returning a
	 * complete object keeps those contexts from falling back to WordPress.org data.
	 *
	 * @param false|object|array $res Existing plugin API response.
	 * @param string $action Requested API action.
	 * @param object $args Request arguments.
	 * @return false|object|array
	 */

	public function plugin_info($res, $action, $args) {
		if (
			'plugin_information' !== $action ||
			empty($args->slug) ||
			$args->slug !== $this->config['slug']
		) {
			return $res;
		}

		$data = $this->get_update_data();

		$response = (object) [
			'name' => $this->config['name'],
			'slug' => $this->config['slug'],
			'version' => $data['version'] ?? $this->config['version'],
			'author' => $this->config['author'],
			'author_profile' => $this->config['homepage'],
			'homepage' => $this->config['homepage'],
			'requires' => $data['requires'] ?? '',
			'requires_php' => $data['requires_php'] ?? '',
			'tested' => $data['tested'] ?? '',
			'last_updated' => $data['last_updated'] ?? '',
			'sections' => [
				'description' =>
					$data['description'] ??
					__(
						'wphave extends WordPress with custom blocks, site tools and workflow features.',
						'wphave',
					),
				'changelog' =>
					$data['changelog'] ??
					__('No changelog is available for this release.', 'wphave'),
			],
		];

		if (!empty($data['download_url'])) {
			$response->download_link = $data['download_url'];
		}

		return $response;
	}
}
