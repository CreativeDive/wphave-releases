<?php

/** Runtime compatibility checks shared by automatic and interactive updates. */

trait WPHAVE_Plugin_Updater_Compatibility {

	/**
	 * Reject an update before files are replaced when its runtime is unsupported.
	 *
	 * @param array $data Validated update manifest.
	 * @return true|WP_Error True when compatible, otherwise a blocking error.
	 */

	protected function validate_runtime_requirements( array $data ) {
		$requires_php = trim( (string) ( $data['requires_php'] ?? '' ) );
		$requires_wp = trim( (string) ( $data['requires'] ?? '' ) );

		if( '' !== $requires_php && version_compare( PHP_VERSION, $requires_php, '<' ) ) {
			return new WP_Error(
				'wphave_update_php_incompatible',
				sprintf(
					/* translators: 1: required PHP version, 2: installed PHP version. */
					__( 'This update requires PHP %1$s or newer. This website currently uses PHP %2$s.', 'wphave' ),
					$requires_php,
					PHP_VERSION
				),
				array( 'status' => 409, 'requires_php' => $requires_php, 'current_php' => PHP_VERSION )
			);
		}

		$current_wp = get_bloginfo( 'version' );
		if( '' !== $requires_wp && version_compare( $current_wp, $requires_wp, '<' ) ) {
			return new WP_Error(
				'wphave_update_wordpress_incompatible',
				sprintf(
					/* translators: 1: required WordPress version, 2: installed WordPress version. */
					__( 'This update requires WordPress %1$s or newer. This website currently uses WordPress %2$s.', 'wphave' ),
					$requires_wp,
					$current_wp
				),
				array( 'status' => 409, 'requires' => $requires_wp, 'current_wordpress' => $current_wp )
			);
		}

		return true;
	}
}
