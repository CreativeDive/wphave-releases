<?php

require_once __DIR__ . '/background-jobs/owned-hooks.php';

/**
 * Manage local installation and lifecycle markers.
 */

/**
 * Coordinates installation, activation, version and site identity markers.
 *
 * Lifecycle state is stored in one option so migrations, setup flows and
 * diagnostics share a consistent view of the local installation.
 */

class WPHAVE_Lifecycle {
	const OPTION = 'wphave_lifecycle';
	const INSTALLED_AT = 'installed_at';
	const ACTIVATED_AT = 'activated_at';
	const FIRST_VERSION = 'first_version';
	const CURRENT_VERSION = 'current_version';
	const PREVIOUS_VERSION = 'previous_version';
	const THEME_INSTALLED_AT = 'theme_installed_at';
	const THEME_ACTIVATED_AT = 'theme_activated_at';
	const THEME_MANAGED = 'theme_managed';
	const SITE_FINGERPRINT = 'site_fingerprint';
	const WP_FIRST_SEEN_AT = 'wp_first_seen_at';
	const LICENSE_UID = 'license_uid';
	const RUN_ONCE_FLAGS = 'run_once_flags';

	/**
	 * Request-local lifecycle data cache.
	 *
	 * All lifecycle markers are stored in one option. Keeping one local
	 * cache avoids repeated option reads and keeps writes atomic enough for
	 * marker-style data.
	 *
	 * @var array|null
	 */

	private static $data_cache = null;

	/**
	 * Request-local rejected license proofs by proof identity.
	 *
	 * SECURITY INVARIANT: Positive authorization results are never cached as
	 * mutable PHP values. A plugin running in the same process could replace
	 * such a value through Reflection and bypass signature verification. Only
	 * denials are memoized, which can reduce repeated invalid-token work but
	 * can never upgrade access.
	 *
	 * @var array<string,true>
	 */

	private static $denied_license_proof_cache = [];

	/**
	 * Initialize lifecycle markers during normal plugin load.
	 *
	 * @return void
	 */

	public static function init() {
		if (!self::should_maintain_markers()) {
			return;
		}

		self::ensure_install_markers();
		self::maybe_update_version_markers();
		self::ensure_site_markers();
	}

	/**
	 * Mark an explicit plugin activation event.
	 *
	 * This can run before the normal plugin bootstrap, so it only uses native WordPress APIs.
	 *
	 * @return void
	 */

	public static function activate() {
		self::ensure_install_markers();
		self::set_option(self::ACTIVATED_AT, self::now());
		self::maybe_update_version_markers();
		self::ensure_site_markers();

		if (class_exists('WPHAVE_Content_Types')) {
			WPHAVE_Content_Types::activate();
		}
	}

	/**
	 * Remove executable background state while preserving customer data.
	 *
	 * LIFECYCLE INVARIANT: Deactivation is reversible. Tables, settings and documents therefore stay
	 * intact, while cron hooks and stale locks are removed so WordPress does not
	 * retain jobs whose callbacks are no longer loaded.
	 */

	public static function deactivate() {
		foreach (self::background_hooks() as $hook) {
			wp_unschedule_hook($hook);
		}
		foreach (self::background_locks() as $option) {
			delete_option($option);
		}
		self::delete_dynamic_action_authorization_locks();
	}

	/** Remove only ephemeral, hash-scoped critical-action mutexes. */

	private static function delete_dynamic_action_authorization_locks() {
		global $wpdb;

		// SECURITY INVARIANT: The anchored hash shape prevents lifecycle cleanup
		// from matching customer options or authorization proof transients.
		$option_names = $wpdb->get_col(
			"SELECT option_name FROM {$wpdb->options} WHERE option_name REGEXP '^wphave_action_auth_[a-f0-9]{32}_lock$'",
		);

		foreach ($option_names as $option_name) {
			delete_option($option_name);
		}
	}

	public static function background_hooks() {
		return wphave_owned_background_hooks();
	}

	public static function background_locks() {
		return [
			'wphave_database_schema_update_lock',
			'wphave_database_schema_network_lock',
			'wphave_database_schema_network_job',
			'wphave_privacy_scan_lock',
			'wphave_privacy_scan_automation_lock',
			'wphave_privacy_scan_schedule',
			'wphave_privacy_export_cleanup_schedule',
			'wphave_security_scan_lock',
			'wphave_security_scan_automation_lock',
			'wphave_backup_creation_lock',
			'wphave_backup_network_schedule_authorization',
			'wphave_content_audit_process_lock',
			'wphave_content_audit_start_lock',
			'wphave_content_audit_automation_lock',
			'wphave_content_audit_cleanup_schedule',
			'wphave_cache_warmup_worker_lock',
			'wphave_cache_data_lock',
			'wphave_site_composition_apply_lock',
			'wphave_global_block_style_usage_lock_v1',
			'wphave_global_block_style_repair_lock_v1',
			'wphave_synced_pattern_library_install_lock',
			'wphave_campaign_delivery_lock',
			'wphave_audience_outbox_schedule_signature',
			'wphave_audience_retention_schedule',
			'wphave_commerce_reporting_backfill_lock',
			'wphave_commerce_reporting_retention_schedule',
			'wphave_content_models_write_lock',
			'wphave_font_cleanup_queue',
			'wphave_activity_environment_snapshot_lock',
			'wphave_activity_environment_monitor_schedule',
			'wphave_activity_privacy_lock',
			'wphave_activity_cleanup_schedule',
			'wphave_analytics_cleanup_lock',
			'wphave_analytics_aggregation_schedule',
			'wphave_analytics_cleanup_schedule',
			'wphave_performance_monitor_cleanup_schedule',
			'wphave_performance_monitor_last_cleanup',
		];
	}

	/**
	 * Ensure first-install markers exist without overwriting historical values.
	 *
	 * @return void
	 */

	public static function ensure_install_markers() {
		self::add_option_once(self::INSTALLED_AT, self::now());
		self::add_option_once(self::FIRST_VERSION, self::plugin_version());
	}

	/**
	 * Track current and previous plugin versions for future migrations.
	 *
	 * @return void
	 */

	public static function maybe_update_version_markers() {
		$version = self::plugin_version();
		$data = get_option(self::OPTION, []);
		$data = is_array($data) ? $data : [];
		$current = (string) ($data[self::CURRENT_VERSION] ?? '');

		if ($current === $version) {
			self::$data_cache = $data;
			return;
		}

		if ($current !== '') {
			$data[self::PREVIOUS_VERSION] = $current;
		}

		$data[self::CURRENT_VERSION] = $version;

		self::$data_cache = $data;
		update_option(self::OPTION, $data, false);
	}

	/**
	 * Record an explicit plugin version transition after a completed update.
	 *
	 * The native WordPress updater replaces plugin files inside the current
	 * request. During that request the loaded PHP constants may still reflect
	 * the old plugin code, so the updater passes both versions explicitly.
	 *
	 * @param string $previous_version Version before the update.
	 * @param string $current_version Version installed by the update.
	 * @return void
	 */

	public static function record_version_update($previous_version, $current_version) {
		$previous_version = sanitize_text_field((string) $previous_version);
		$current_version = sanitize_text_field((string) $current_version);

		if (!$current_version || $previous_version === $current_version) {
			return;
		}

		$data = get_option(self::OPTION, []);
		$data = is_array($data) ? $data : [];

		if (!empty($previous_version)) {
			$data[self::PREVIOUS_VERSION] = $previous_version;
		}

		$data[self::CURRENT_VERSION] = $current_version;

		self::$data_cache = $data;
		update_option(self::OPTION, $data, false);
	}

	/**
	 * Ensure stable local site markers exist.
	 *
	 * @return void
	 */

	public static function ensure_site_markers() {
		if (!self::has(self::WP_FIRST_SEEN_AT)) {
			self::set_option(self::WP_FIRST_SEEN_AT, self::detect_wp_first_seen_at());
		}

		if (!self::has(self::SITE_FINGERPRINT)) {
			self::set_option(self::SITE_FINGERPRINT, self::generate_site_fingerprint());
		}
	}

	/**
	 * Mark that the bundled theme was installed or updated through WPHAVE.
	 *
	 * @return void
	 */

	public static function mark_theme_installed() {
		self::add_option_once(self::THEME_INSTALLED_AT, self::now());
		self::set_option(self::THEME_MANAGED, 1);
	}

	/**
	 * Mark that the bundled child theme was activated through WPHAVE.
	 *
	 * @return void
	 */

	public static function mark_theme_activated() {
		self::mark_theme_installed();
		self::set_option(self::THEME_ACTIVATED_AT, self::now());
	}

	/**
	 * Return the central WPHAVE installation date.
	 *
	 * @return string Installation datetime.
	 */

	public static function activation_date() {
		self::ensure_install_markers();

		return (string) self::get(self::INSTALLED_AT, '');
	}

	/**
	 * Return a stable local UID for license and installation flows.
	 *
	 * Freemius requires this UID to be exactly 32 alphanumeric characters.
	 * Activation can appear to work with shorter values, but deactivation
	 * fails later with "Invalid uid". Keep this marker stable and 32 chars.
	 *
	 * @return string Local license UID.
	 */

	public static function license_uid() {
		$uid = (string) self::get(self::LICENSE_UID, '');

		if (preg_match('/^[a-f0-9]{32}$/', $uid)) {
			return $uid;
		}

		try {
			$uid = bin2hex(random_bytes(16));
		} catch (Exception $e) {
			$uid = wp_generate_password(32, false, false);
		}

		self::set_option(self::LICENSE_UID, $uid);

		return $uid;
	}

	/**
	 * Check whether local Pro access is currently available for PHP-only admin flows.
	 *
	 * The JavaScript app performs the detailed signed-token validation used
	 * by the product UI. PHP-only WordPress screens cannot reuse that async
	 * verifier directly, so this method deliberately exposes only a generic
	 * yes/no result to feature code. Keep license storage details inside the
	 * lifecycle layer instead of scattering option paths across features.
	 *
	 * @return bool True when a locally stored Pro/access grant is still usable.
	 */

	public static function has_pro_access() {
		$payload = self::verified_license_access_payload();

		return is_array($payload) && self::license_payload_covers_current_site($payload);
	}

	/**
	 * Build the non-sensitive license status exposed to administration UIs.
	 *
	 * Subsite users must not receive the network-owned license resource, but
	 * they still need the entitlement result derived from its signed proof.
	 * Only claims required for deterministic multisite coverage are projected.
	 *
	 * @return array Public entitlement status without license credentials.
	 */

	public static function license_status_projection() {
		// PERFORMANCE INVARIANT: One snapshot and one existing verification
		// path serve entitlement and health. Health never queries or revalidates.
		$license = self::license_access_data();
		$payload = self::verified_license_access_payload($license);
		$access = is_array($payload) ? (string) ($payload['access'] ?? '') : '';
		$claims = [];

		foreach (['quota', 'multisiteSubsiteMultiplier', 'allowedSubsites'] as $claim) {
			if (
				is_array($payload) &&
				array_key_exists($claim, $payload) &&
				is_numeric($payload[$claim])
			) {
				$claims[$claim] = self::normalize_license_coverage_claim($payload[$claim]);
			}
		}

		/*
		 * SECURITY INVARIANT: This projection is an authorization result, not
		 * a proof transport. Tokens, keys, installation IDs, license IDs, UIDs
		 * and domain identity must remain inside the lifecycle/data boundary.
		 */
		return [
			// The client needs the verified base entitlement to distinguish a
			// quota denial from a genuinely unlicensed installation. Server
			// feature gates apply coverage separately in has_pro_access().
			'isPro' => (bool) $payload,
			// CROSS-RUNTIME INVARIANT: PHP projections and the browser use
			// the same semantic access labels. Authorized domain access is
			// not a local environment and must never be projected as LOCAL.
			'isAuthorized' =>
				'beta' === $access
					? 'BETA'
					: ('demo' === $access
						? 'PLAYGROUND_DEMO'
						: ('authorized' === $access
							? 'DOMAIN'
							: ('local_license' === $access
								? 'LOCAL_LICENSE'
								: false))),
			'isBeta' => 'beta' === $access,
			'licenseClaims' => $claims,
			'licenseHealth' => self::license_health_projection($license, $payload),
		];
	}

	/** Derive public health facts without exposing network billing metadata. */
	private static function license_health_projection(array $license, $payload): array {
		// PRIVACY INVARIANT: Subsites receive a health result, never credentials,
		// IDs, the exact billing date, or a substitute entitlement proof.
		$access = is_array($payload) ? (string) ($payload['access'] ?? '') : '';
		$is_paid =
			!in_array($access, ['beta', 'authorized', 'demo'], true) &&
			(in_array($access, ['license', 'local_license'], true) ||
				!empty($license['key']) ||
				!empty($license['licenseId']) ||
				!empty($license['installId']) ||
				!empty($license['token']));
		$expiration = self::license_time($license, 'expiration');
		$remaining = $expiration - time();
		// POLICY INVARIANT: Match the paid health check's 28-day warning
		// boundary. Missing private preload data is not a missing license.
		$validity = !$is_paid
			? 'not-applicable'
			: (!$expiration
				? ($payload
					? 'undated'
					: 'missing')
				: ($remaining <= 0
					? 'expired'
					: ($remaining <= 28 * DAY_IN_SECONDS
						? 'expiring'
						: 'valid')));
		return ['isPaid' => $is_paid, 'validity' => $validity];
	}

	/**
	 * Verify the locally stored signed access proof and return its claims.
	 *
	 * @return array|false Verified claims or false when access must fail closed.
	 */

	private static function verified_license_access_payload($license = null) {
		$license = $license ?? self::license_access_data();

		if (!self::has_license_access_marker($license)) {
			return false;
		}

		// SECURITY INVARIANT: PHP feature gates must never infer authority from
		// a non-empty option value. If the synchronous OpenSSL verifier is not
		// loaded or available, access fails closed regardless of bootstrap order.
		if (!class_exists('WPHAVE_License_Token_Verifier') || !function_exists('openssl_verify')) {
			return false;
		}

		$now = time();
		$domain = self::license_authority_domain();
		$cache_key = hash('sha256', serialize([$license, $domain]));

		if (!empty(self::$denied_license_proof_cache[$cache_key])) {
			return false;
		}

		if (!empty($license['accessToken'])) {
			$access_grace_until = self::license_time($license, 'accessGraceUntil');
			$access_data = array_merge($license, ['token' => $license['accessToken']]);
			$allowed_access = ['authorized', 'beta'];

			/*
			 * SECURITY INVARIANT: A signed demo claim is necessary but insufficient.
			 * It is accepted only when this installation explicitly opted into the
			 * official Playground demo runtime, so a copied token fails closed.
			 */
			if (self::is_playground_demo_context()) {
				$allowed_access[] = 'demo';
			}

			$access_payload = WPHAVE_License_Token_Verifier::verified_payload($access_data, [
				'access' => $allowed_access,
				'domain' => (string) $domain,
				'allowExpiredGrace' => $access_grace_until >= $now,
				'graceUntil' => $access_grace_until,
			]);

			if ($access_payload) {
				if ('demo' === ($access_payload['access'] ?? '')) {
					$demo_valid_until = self::license_time($access_payload, 'validUntil');

					/*
					 * SECURITY INVARIANT: Demo authority never inherits the generic access
					 * grace window. Its signed context and short freshness deadline must
					 * both remain valid at the exact time a PHP feature gate is evaluated.
					 */
					if (
						'playground-demo' !== ($access_payload['context'] ?? '') ||
						$demo_valid_until < $now
					) {
						return false;
					}
				}

				return $access_payload;
			}
		}

		if (empty($license['token'])) {
			self::$denied_license_proof_cache[$cache_key] = true;

			return false;
		}

		$expiration = self::license_time($license, 'expiration');

		if ($expiration && $expiration < $now) {
			self::$denied_license_proof_cache[$cache_key] = true;

			return false;
		}

		$continuity_until = $expiration ?: 253402300799;
		$verified_payload = WPHAVE_License_Token_Verifier::verified_payload($license, [
			'access' => ['license', 'local_license'],
			'domain' => (string) $domain,
			'allowOfflineContinuity' => true,
			'graceUntil' => $continuity_until,
		]);

		if (!$verified_payload) {
			self::$denied_license_proof_cache[$cache_key] = true;
		}

		return $verified_payload;
	}

	/**
	 * Resolve the hostname that owns the shared license proof.
	 *
	 * @return string Canonical activation hostname.
	 */

	public static function license_authority_domain() {
		$authority_url = home_url();

		if (
			function_exists('is_multisite') &&
			is_multisite() &&
			function_exists('get_main_site_id') &&
			function_exists('get_home_url')
		) {
			$authority_url = get_home_url((int) get_main_site_id());
		}

		/*
		 * MULTISITE IDENTITY INVARIANT: A network token is activated for the
		 * main site. Subdomain and mapped-domain subsites must verify that same
		 * signed identity instead of substituting their request hostname.
		 */
		return (string) wp_parse_url($authority_url, PHP_URL_HOST);
	}

	/**
	 * Return whether this installation may consume a Playground demo proof.
	 */

	private static function is_playground_demo_context() {
		if (!defined('WPHAVE_PLAYGROUND_DEMO') || true !== WPHAVE_PLAYGROUND_DEMO) {
			return false;
		}

		$domain = strtolower(self::license_authority_domain());

		return (defined('IS_WP_PLAYGROUND') && true === IS_WP_PLAYGROUND) ||
			in_array($domain, ['playground.internal', 'playground.wordpress.net'], true);
	}

	/**
	 * Check the signed multisite coverage claims for the active site.
	 *
	 * @param array $payload Verified signed token claims.
	 * @return bool True when the current site is inside the signed allowance.
	 */

	private static function license_payload_covers_current_site(array $payload) {
		if (!function_exists('is_multisite') || !is_multisite()) {
			return true;
		}

		if (function_exists('is_main_site') && is_main_site()) {
			return true;
		}

		if (
			!class_exists('WPHAVE_Multisite') ||
			!array_key_exists('allowedSubsites', $payload) ||
			!is_numeric($payload['allowedSubsites'])
		) {
			return false;
		}

		$allowed_subsites = self::normalize_license_coverage_claim($payload['allowedSubsites']);

		if ($allowed_subsites < 0) {
			return true;
		}

		$context = WPHAVE_Multisite::license_context();
		$current_subsite_index = (int) ($context['currentSubsiteIndex'] ?? 0);

		/*
		 * SECURITY/QUOTA INVARIANT: PHP feature gates enforce the same signed,
		 * deterministic subsite allowance as the client. Missing coverage or
		 * an unresolved site index fails closed rather than granting all sites.
		 */
		return $current_subsite_index > 0 && $current_subsite_index <= $allowed_subsites;
	}

	/**
	 * Normalize a signed numeric coverage claim exactly like the browser.
	 *
	 * @param mixed $value Signed claim value.
	 * @return int Positive integer, -1 for unlimited, or zero.
	 */

	private static function normalize_license_coverage_claim($value) {
		if (!is_numeric($value)) {
			return 0;
		}

		$numeric_value = (float) $value;

		if (!is_finite($numeric_value)) {
			return 0;
		}

		/*
		 * LICENSE CLAIM INVARIANT: Browser and PHP must normalize the same
		 * signed bytes to the same quota decision. Every negative value means
		 * unlimited; non-negative fractions are rounded down deterministically.
		 */
		return $numeric_value < 0 ? -1 : max(0, (int) floor($numeric_value));
	}

	/**
	 * Get a lifecycle option value.
	 *
	 * @param string $key Option key.
	 * @param mixed $default Fallback value.
	 * @return mixed Stored option value.
	 */

	public static function get($key, $default = null) {
		$data = self::data();

		return array_key_exists($key, $data) ? $data[$key] : $default;
	}

	/**
	 * Return all lifecycle markers as a compact array.
	 *
	 * @return array Lifecycle marker values.
	 */

	public static function all() {
		return [
			'installedAt' => self::get(self::INSTALLED_AT, ''),
			'activatedAt' => self::get(self::ACTIVATED_AT, ''),
			'firstVersion' => self::get(self::FIRST_VERSION, ''),
			'currentVersion' => self::get(self::CURRENT_VERSION, ''),
			'previousVersion' => self::get(self::PREVIOUS_VERSION, ''),
			'themeInstalledAt' => self::get(self::THEME_INSTALLED_AT, ''),
			'themeActivatedAt' => self::get(self::THEME_ACTIVATED_AT, ''),
			'themeManaged' => self::has_managed_theme(),
			'siteFingerprint' => self::get(self::SITE_FINGERPRINT, ''),
			'licenseUid' => self::license_uid(),
			'wpFirstSeenAt' => self::get(self::WP_FIRST_SEEN_AT, ''),
			'brandNewInstall' => self::is_brand_new_install(),
			'upgrade' => self::is_upgrade(),
			'brandNewWpInstall' => self::is_brand_new_wp_install(),
		];
	}

	/**
	 * Check whether this WPHAVE install is still in its first short-lived setup window.
	 *
	 * @param int $window_seconds Time window in seconds.
	 * @return bool True when the plugin was installed recently.
	 */

	public static function is_brand_new_install($window_seconds = DAY_IN_SECONDS) {
		$installed_at = strtotime((string) self::get(self::INSTALLED_AT, ''));

		return $installed_at && time() - $installed_at <= absint($window_seconds);
	}

	/**
	 * Check whether the currently loaded version differs from the first installed version.
	 *
	 * @return bool True when this installation has been upgraded at least once.
	 */

	public static function is_upgrade() {
		$first = (string) self::get(self::FIRST_VERSION, '');
		$current = (string) self::get(self::CURRENT_VERSION, self::plugin_version());

		return $first !== '' && $current !== '' && $first !== $current;
	}

	/**
	 * Check whether WordPress still considers this a fresh site.
	 *
	 * @return bool True when the WordPress fresh_site marker is still active.
	 */

	public static function is_brand_new_wp_install() {
		return (int) get_option('fresh_site', 0) === 1;
	}

	/**
	 * Check whether the bundled theme is managed by WPHAVE.
	 *
	 * @return bool True when the theme was installed through WPHAVE.
	 */

	public static function has_managed_theme() {
		return (bool) self::get(self::THEME_MANAGED, false);
	}

	/**
	 * Check whether the managed theme setup is complete.
	 *
	 * @return bool True when the child theme is active and the theme was installed through WPHAVE.
	 */

	public static function is_theme_setup_complete() {
		return self::has_managed_theme() &&
			class_exists('WPHAVE_Theme_Setup') &&
			WPHAVE_Theme_Setup::is_child_active();
	}

	/**
	 * Check whether a named one-time lifecycle task should still run.
	 *
	 * @param string $key Stable task or migration key.
	 * @return bool True when the task has not been marked as completed.
	 */

	public static function should_run_once($key) {
		$key = self::normalize_run_once_key($key);

		if (!$key) {
			return false;
		}

		$flags = self::run_once_flags();

		return ($flags[$key] ?? 'unset') !== 'set';
	}

	/**
	 * Mark a named one-time lifecycle task as completed.
	 *
	 * @param string $key Stable task or migration key.
	 * @return void
	 */

	public static function mark_run_once_complete($key) {
		$key = self::normalize_run_once_key($key);

		if (!$key) {
			return;
		}

		$flags = self::run_once_flags();
		$flags[$key] = 'set';

		self::set_option(self::RUN_ONCE_FLAGS, $flags);
	}

	/**
	 * Run a callback once and only mark it complete after a successful result.
	 *
	 * Returning false or WP_Error from the callback keeps the task open for a later retry.
	 *
	 * @param string $key Stable task or migration key.
	 * @param callable $callback One-time task callback.
	 * @return mixed Callback result, false when skipped, or WP_Error on callback failure.
	 */

	public static function run_once($key, $callback) {
		if (!self::should_run_once($key)) {
			return false;
		}

		if (!is_callable($callback)) {
			return new WP_Error(
				'wphave_lifecycle_invalid_callback',
				__('The lifecycle task callback is not callable.', 'wphave'),
			);
		}

		$result = call_user_func($callback);

		if ($result === false || is_wp_error($result)) {
			return $result;
		}

		self::mark_run_once_complete($key);

		return $result;
	}

	/**
	 * Get the current plugin version.
	 *
	 * @return string Plugin version.
	 */

	public static function plugin_version() {
		return defined('WPHAVE_VERSION') ? WPHAVE_VERSION : '0.0.0';
	}

	/**
	 * Store an option only when it does not exist yet.
	 *
	 * @param string $key Option key.
	 * @param mixed $value Option value.
	 * @return void
	 */

	private static function add_option_once($key, $value) {
		if (self::has($key)) {
			return;
		}

		self::set_option($key, $value);
	}

	/**
	 * Store a lifecycle option with autoload disabled for newly created rows.
	 *
	 * @param string $key Option key.
	 * @param mixed $value Option value.
	 * @return void
	 */

	private static function set_option($key, $value) {
		$data = self::data();
		$data[$key] = $value;

		self::$data_cache = $data;
		update_option(self::OPTION, $data, false);
	}

	/**
	 * Check whether a lifecycle key exists in the central option.
	 *
	 * @param string $key Lifecycle marker key.
	 * @return bool True when the key exists, even if its value is falsey.
	 */

	private static function has($key) {
		$data = self::data();

		return array_key_exists($key, $data);
	}

	/**
	 * Return the central lifecycle data array.
	 *
	 * @return array Lifecycle data.
	 */

	private static function data() {
		if (self::$data_cache !== null) {
			return self::$data_cache;
		}

		$data = get_option(self::OPTION, null);

		if (is_array($data)) {
			self::$data_cache = $data;

			return self::$data_cache;
		}

		self::$data_cache = [];

		return self::$data_cache;
	}

	/**
	 * Return all completed one-time lifecycle task flags.
	 *
	 * @return array Run-once flags.
	 */

	private static function run_once_flags() {
		$flags = self::get(self::RUN_ONCE_FLAGS, []);

		return is_array($flags) ? $flags : [];
	}

	/**
	 * Check whether this request should maintain lifecycle marker rows.
	 *
	 * Frontend requests can read lifecycle data when a feature explicitly
	 * asks for it, but they should not spend time checking and updating
	 * marker options during the global init hook.
	 *
	 * @return bool True when lifecycle marker writes are appropriate.
	 */

	private static function should_maintain_markers() {
		return is_admin() ||
			wp_doing_ajax() ||
			wp_doing_cron() ||
			(defined('REST_REQUEST') && REST_REQUEST) ||
			(defined('WP_CLI') && WP_CLI);
	}

	/**
	 * Normalize a run-once task key while keeping common migration separators readable.
	 *
	 * @param string $key Raw task key.
	 * @return string Normalized task key.
	 */

	private static function normalize_run_once_key($key) {
		$key = strtolower(trim((string) $key));
		$key = preg_replace('/[^a-z0-9_\-:.]/', '_', $key);

		return trim($key, '_');
	}

	/**
	 * Get the current local WordPress timestamp.
	 *
	 * @return string MySQL datetime.
	 */

	private static function now() {
		return current_time('mysql');
	}

	/**
	 * Generate a stable local fingerprint without storing raw URLs or paths.
	 *
	 * @return string SHA-256 fingerprint.
	 */

	private static function generate_site_fingerprint() {
		$parts = [home_url('/'), site_url('/'), defined('ABSPATH') ? ABSPATH : '', wp_salt('auth')];

		return hash('sha256', implode('|', $parts));
	}

	/**
	 * Detect the earliest WordPress timestamp that is locally available.
	 *
	 * @return string MySQL datetime.
	 */

	private static function detect_wp_first_seen_at() {
		$admin_user = get_user_by('id', 1);

		if (
			$admin_user &&
			!empty($admin_user->user_registered) &&
			$admin_user->user_registered !== '0000-00-00 00:00:00'
		) {
			return $admin_user->user_registered;
		}

		return self::now();
	}

	/**
	 * Return locally stored license access data.
	 *
	 * Kept private so individual features do not depend on storage details.
	 *
	 * @return array
	 */

	private static function license_access_data() {
		return function_exists('wphave_data_get')
			? (array) wphave_data_get('license_settings', '', [])
			: [];
	}

	/**
	 * Check whether local license data contains an access marker.
	 *
	 * @param array $license Local license data.
	 * @return bool
	 */

	private static function has_license_access_marker(array $license) {
		return !empty($license['token']) || !empty($license['accessToken']);
	}

	/**
	 * Normalize a local license timestamp.
	 *
	 * @param array $license Local license data.
	 * @param string $key Timestamp key.
	 * @return int Unix timestamp or zero.
	 */

	private static function license_time(array $license, $key) {
		if (empty($license[$key])) {
			return 0;
		}

		$timestamp = is_numeric($license[$key])
			? (int) $license[$key]
			: strtotime((string) $license[$key]);

		if (!$timestamp) {
			return 0;
		}

		return $timestamp > 9999999999 ? (int) floor($timestamp / 1000) : $timestamp;
	}
}

/**
 * Return all local WPHAVE lifecycle markers.
 *
 * @return array Lifecycle marker values.
 */

function wphave_lifecycle() {
	return class_exists('WPHAVE_Lifecycle') ? WPHAVE_Lifecycle::all() : [];
}

/**
 * Check whether Pro access is currently available for PHP-only flows.
 *
 * SECURITY INVARIANT: This authority wrapper is deliberately declared
 * unconditionally. A previously loaded plugin must cause a symbol collision
 * and fail closed instead of substituting its own entitlement decision.
 *
 * @return bool True when Pro access is locally available.
 */

function wphave_has_pro_access() {
	return class_exists('WPHAVE_Lifecycle') && WPHAVE_Lifecycle::has_pro_access();
}

/**
 * Return the stable local UID used by license and installation flows.
 *
 * COMPATIBILITY INVARIANT: The Freemius-compatible value remains exactly 32 characters.
 *
 * @return string Local license UID.
 */

function wphave_get_or_create_uid() {
	return class_exists('WPHAVE_Lifecycle') ? WPHAVE_Lifecycle::license_uid() : '';
}

/**
 * Check whether WPHAVE was installed recently.
 *
 * @param int $window_seconds Time window in seconds.
 * @return bool True for a recent WPHAVE install.
 */

function wphave_is_brand_new_install($window_seconds = DAY_IN_SECONDS) {
	return class_exists('WPHAVE_Lifecycle') &&
		WPHAVE_Lifecycle::is_brand_new_install($window_seconds);
}

/**
 * Check whether WPHAVE has been upgraded from its first installed version.
 *
 * @return bool True when this is an upgraded WPHAVE install.
 */

function wphave_is_upgrade() {
	return class_exists('WPHAVE_Lifecycle') && WPHAVE_Lifecycle::is_upgrade();
}

/**
 * Check whether WordPress still marks this site as fresh.
 *
 * @return bool True for a fresh WordPress install.
 */

function wphave_is_brand_new_wp_install() {
	return class_exists('WPHAVE_Lifecycle') && WPHAVE_Lifecycle::is_brand_new_wp_install();
}

/**
 * Check whether the WPHAVE theme was installed through WPHAVE.
 *
 * @return bool True when WPHAVE manages the bundled theme.
 */

function wphave_has_managed_theme() {
	return class_exists('WPHAVE_Lifecycle') && WPHAVE_Lifecycle::has_managed_theme();
}

/**
 * Check whether the managed WPHAVE child theme is active.
 *
 * @return bool True when the WPHAVE theme setup is complete.
 */

function wphave_is_theme_setup_complete() {
	return class_exists('WPHAVE_Lifecycle') && WPHAVE_Lifecycle::is_theme_setup_complete();
}

/**
 * Check whether a named one-time WPHAVE task should still run.
 *
 * @param string $key Stable task or migration key.
 * @return bool True when the task has not completed yet.
 */

function wphave_should_run_once($key) {
	return class_exists('WPHAVE_Lifecycle') && WPHAVE_Lifecycle::should_run_once($key);
}

/**
 * Mark a named one-time WPHAVE task as completed.
 *
 * @param string $key Stable task or migration key.
 * @return void
 */

function wphave_mark_run_once_complete($key) {
	if (class_exists('WPHAVE_Lifecycle')) {
		WPHAVE_Lifecycle::mark_run_once_complete($key);
	}
}

/**
 * Run a named WPHAVE task once and mark it complete after success.
 *
 * @param string $key Stable task or migration key.
 * @param callable $callback One-time task callback.
 * @return mixed Callback result, false when skipped, or WP_Error on callback failure.
 */

function wphave_run_once($key, $callback) {
	return class_exists('WPHAVE_Lifecycle') ? WPHAVE_Lifecycle::run_once($key, $callback) : false;
}

add_action('init', ['WPHAVE_Lifecycle', 'init'], 1);
