<?php

/**
 * Bootstrap bundled WPHAVE theme management.
 */

require_once __DIR__ . '/runtime.php';
require_once __DIR__ . '/installer.php';
require_once __DIR__ . '/rest.php';
require_once __DIR__ . '/manager.php';

require_once __DIR__ . '/customizer.php';
