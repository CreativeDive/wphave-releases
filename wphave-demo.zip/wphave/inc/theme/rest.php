<?php

/**
 * Exposes theme setup and status operations to management clients.
 */

trait WPHAVE_Theme_REST {

    /**
     * Register the manual theme setup REST endpoint.
     *
     * @return void
     */

    public static function register_rest_routes() {
        register_rest_route( 'wphave/v1', '/theme/setup', [
            'methods' => 'POST',
            'callback' => [ __CLASS__, 'setup_rest_callback' ],
            'permission_callback' => [ __CLASS__, 'can_manage_theme' ],
        ] );
    }

    /**
     * Determine whether the current user may install and switch themes.
     *
     * @return bool Whether bundled theme setup is permitted.
     */

    public static function can_manage_theme() {
        // SECURITY INVARIANT: Bundled theme setup may both write code and change
        // the active frontend. It therefore requires WordPress authority for each
        // operation rather than treating either capability as sufficient alone.
        return current_user_can( 'switch_themes' )
            && current_user_can( 'install_themes' )
            && ( ! is_multisite() || current_user_can( 'manage_network_themes' ) );
    }

    /**
     * REST callback for installing/updating and activating the bundled theme pair.
     *
     * @return WP_REST_Response|WP_Error REST response on success, WP_Error on setup failure.
     */

    public static function setup_rest_callback() {
        // AUTHORIZATION INVARIANT: The REST permission callback is only an early
        // dispatch gate. Re-check both code-installation and activation authority
        // immediately before the installer can write files or switch the theme.
        if( ! self::can_manage_theme() ) {
            return new WP_Error(
                'wphave_theme_setup_forbidden',
                __( 'You are not allowed to install and activate the bundled theme.', 'wphave' ),
                array( 'status' => 403 )
            );
        }

        $result = self::setup_default_theme();

        if( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response( [
            'success' => true,
            'active' => self::is_active(),
            'stylesheet' => get_stylesheet(),
            'template' => get_template(),
        ] );
    }

    /**
     * Check whether the installed parent theme differs from the bundled parent theme.
     *
     * @return bool True when the overview banner should offer a manual theme update.
     */

    public static function update_available() {
        $plugin_theme_dir = self::plugin_parent_theme_dir();
        $installed_theme_dir = self::installed_parent_theme_dir();

        if(
            ! is_dir( $plugin_theme_dir ) ||
            ! is_dir( $installed_theme_dir ) ||
            is_link( $plugin_theme_dir ) ||
            is_link( $installed_theme_dir )
        ) {
            return false;
        }

        return self::theme_needs_update( $plugin_theme_dir, $installed_theme_dir );
    }

    /**
     * Return the current bundled theme status for app/UI consumers.
     *
     * @return array Theme status including active state, install state and update availability.
     */

    public static function status() {
        return [
            'active' => self::is_active(),
            'parentInstalled' => self::theme_directory_exists( self::installed_parent_theme_dir() ),
            'childInstalled' => self::theme_directory_exists( self::installed_child_theme_dir() ),
            'parentActive' => self::is_parent_active(),
            'childActive' => self::is_child_active(),
            'requiresChildThemeActivation' => self::requires_child_theme_activation(),
            'updateAvailable' => self::update_available(),
            'parentSlug' => self::parent_slug(),
            'childSlug' => self::child_slug(),
            'stylesheet' => get_stylesheet(),
            'template' => get_template(),
        ];
    }

}
