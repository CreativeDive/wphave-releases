<?php

/**
 * Coordinates bundled WPHAVE theme management.
 */

class WPHAVE_Theme_Setup {

    use WPHAVE_Theme_Runtime;
    use WPHAVE_Theme_Installer;
    use WPHAVE_Theme_REST;

    /**
     * Register theme management hooks.
     *
     * @return void
     */

    public static function init() {
        add_action( 'rest_api_init', [ __CLASS__, 'register_rest_routes' ] );
    }

}

WPHAVE_Theme_Setup::init();
