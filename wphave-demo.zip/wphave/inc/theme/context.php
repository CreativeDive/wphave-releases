<?php

/**
 * Resolve the active WPHAVE theme and editing context.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}


if ( ! function_exists( 'wphave_theme_is_active' ) ) :

	function wphave_theme_is_active() {
		if( class_exists( 'WPHAVE_Theme_Setup' ) ) {
			return WPHAVE_Theme_Setup::is_active();
		}

		$stylesheet = (string) get_stylesheet();
		$template = (string) get_template();
		$theme_slugs = array_filter( [
			defined( 'WPHAVE_DEFAULT_THEME_SLUG' ) ? WPHAVE_DEFAULT_THEME_SLUG : 'wphave',
			defined( 'WPHAVE_DEFAULT_CHILD_THEME_SLUG' ) ? WPHAVE_DEFAULT_CHILD_THEME_SLUG : 'wphave-child',
			'wphave',
		] );

		return in_array( $stylesheet, $theme_slugs, true ) || in_array( $template, $theme_slugs, true );
	}

endif;



if ( ! function_exists( 'wphave_use_fse' ) ) :

	/**
	 * Use fse.
	 */

	function wphave_use_fse() {

		return class_exists( 'WPHAVE_Theme_Setup' ) ? ! WPHAVE_Theme_Setup::is_active() : ! wphave_theme_is_active();

	}

endif;
