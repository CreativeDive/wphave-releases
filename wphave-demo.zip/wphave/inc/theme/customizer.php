<?php

/**
 * Keep the native Customizer outside WPHAVE's own theme editing workflow.
 * Stored custom CSS and theme modifications remain available after a theme switch.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Restrict the native Customizer while the WPHAVE theme workflow is active.
 *
 * Every callback resolves the current theme context independently so the policy
 * also follows multisite blog switches. No capabilities, theme modifications,
 * or custom CSS records are changed in persistent storage.
 */

final class WPHAVE_Theme_Customizer_Policy {

	/**
	 * Register the policy during the shared theme-management bootstrap.
	 *
	 * Capability and CSS filters run at the latest priority to apply the policy
	 * after ordinary filters. The request guard runs at setup_theme priority zero,
	 * before the Customizer manager can substitute a preview theme or its options.
	 * Registration is unconditional; each callback checks the active theme when
	 * invoked, leaving foreign-theme requests unaffected.
	 *
	 * @return void
	 */

	public static function init(): void {
		add_filter( 'map_meta_cap', array( __CLASS__, 'filter_capabilities' ), PHP_INT_MAX, 2 );
		add_filter( 'wp_get_custom_css', array( __CLASS__, 'filter_custom_css' ), PHP_INT_MAX );
		// Run before WP_Customize_Manager can substitute the preview theme/options.
		add_action( 'setup_theme', array( __CLASS__, 'block_customizer_request' ), 0 );
	}

	/**
	 * Deny the Customizer capability in the WPHAVE theme context.
	 *
	 * WordPress uses this capability for Customizer access and its standard UI
	 * entry points. Returning do_not_allow also denies access to multisite super
	 * administrators. Other capabilities, including edit_theme_options, retain
	 * their original mapping; user roles and stored permissions are not modified.
	 *
	 * @param string[] $caps Primitive capabilities required by the existing mapping.
	 * @param string   $cap  Meta capability currently being checked.
	 * @return string[] Explicit denial for customize in WPHAVE mode, otherwise $caps.
	 */

	public static function filter_capabilities( array $caps, string $cap ): array {
		if ( 'customize' === $cap && wphave_theme_is_active() ) {
			return array( 'do_not_allow' );
		}

		return $caps;
	}

	/**
	 * Suppress native Additional CSS at its shared WordPress retrieval point.
	 *
	 * Filtering wp_get_custom_css covers the standard frontend style output and
	 * editor settings that obtain CSS through this function. The stored CSS post
	 * and its revisions remain untouched. Outside the WPHAVE theme context, the
	 * supplied CSS is returned unchanged. This does not remove CSS already present
	 * in cached HTML or an open editor, nor CSS emitted through unrelated sources.
	 *
	 * @param string $css Custom CSS supplied by WordPress and earlier filters.
	 * @return string Empty CSS in WPHAVE mode, otherwise the original CSS.
	 */

	public static function filter_custom_css( string $css ): string {
		return wphave_theme_is_active() ? '' : $css;
	}

	/**
	 * Stop Customizer requests before preview settings can affect theme resolution.
	 *
	 * The global manager identifies Customizer control, preview, and AJAX requests
	 * initialized by WordPress. Checking it before its setup_theme callback also
	 * blocks changeset previews that would otherwise be accessible without the
	 * customize capability. Ordinary requests and foreign-theme requests return
	 * immediately. Blocked requests terminate through wp_die with HTTP status 403.
	 *
	 * @global WP_Customize_Manager|null $wp_customize Customizer manager, if initialized.
	 * @return void Returns for unaffected requests; wp_die terminates blocked requests.
	 */
    
	public static function block_customizer_request(): void {
		global $wp_customize;

		if ( ! ( $wp_customize instanceof WP_Customize_Manager ) || ! wphave_theme_is_active() ) {
			return;
		}

		wp_die(
			__( 'The WordPress Customizer is disabled while a WPHAVE theme is active. Use the WPHAVE workspace to edit your website.', 'wphave' ),
			__( 'Customizer disabled', 'wphave' ),
			array( 'response' => 403 )
		);
	}
}

WPHAVE_Theme_Customizer_Policy::init();
