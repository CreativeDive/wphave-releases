<?php

if ( ! function_exists( 'wphave_theme_is_plugin_active' ) ) :

	/**
	 * Theme is plugin active.
	 */

	function wphave_theme_is_plugin_active() {

		return defined( 'WPHAVE_VERSION' ) && function_exists( 'wphave_dir' );

	}

endif;


if ( ! function_exists( 'wphave_theme_setup' ) ) :

	/**
	 * Theme setup.
	 */

	function wphave_theme_setup() {

        $use_fse = wphave_use_fse();

		// Let WordPress manage the document title
		add_theme_support( 'title-tag' );

		// Theme supports wp_body_open()
		add_theme_support( 'body-open' );

		// Enable support for Post Thumbnails on posts and pages.
		add_theme_support( 'post-thumbnails' );

		// Editor styles (TinyMCE and WP block editor)
		add_theme_support( 'editor-styles' );

		// Post Formats are no longer relevant in times of the block editor
		remove_theme_support('post-formats');

		// Default posts and comments RSS feed links to head
		add_theme_support( 'automatic-feed-links' );

		// Responsive embedded content for WP block editor (Gutenberg)
		add_theme_support( 'responsive-embeds' );

		// Add custom excerpt support for other post types
		add_post_type_support( 'page', 'excerpt' );

		// Remove the default core block patterns
		remove_theme_support( 'core-block-patterns' );

        if( ! $use_fse ) {
            // Remove core layout styles to prevent these styles overrides our own
            //add_theme_support( 'disable-layout-styles' );

            // Remove "site-logo" query
            remove_filter( 'theme_mod_custom_logo', '_override_custom_logo_theme_mod' );
        }

		// Switch default core markup to output valid HTML5
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'script',
			'style',
		));

		if( wphave_theme_is_plugin_active() ) {
            if( ! $use_fse ) {
                // Remove WP block styles on frontend
                remove_theme_support( 'wp-block-styles' );

                // Remove custom block templates
                remove_theme_support( 'block-templates' );

                if( class_exists('WPHAVE_WooCommerce') ) {
                    // WooCommerce support is centralized in the plugin feature layer.
                    WPHAVE_WooCommerce::register_theme_support();
                }
            }

            // Set the content width in pixels, based on global width
            // Let WordPress interpret the correct image size assigned to the content width.
            $content_width = wphave_data_get( 'site_globals', 'layout.width', WPHAVE_DEFAULT_WIDTH ) ?? 1170;
            $GLOBALS['content_width'] = apply_filters( 'wphave_theme_setup', (float)$content_width );
        }
	}

endif;

add_action( 'after_setup_theme', 'wphave_theme_setup' );



if ( ! function_exists( 'wphave_theme_body_class' ) ) :

	/**
	 * Theme body class.
	 *
	 * @param mixed $classes Classes.
	 */

	function wphave_theme_body_class( $classes ) {

        // Get body classes passed through this filter
        $classes = apply_filters( 'wphave_add_theme_body_classes', $classes );

        return $classes;

    }

endif;

add_filter( 'body_class', 'wphave_theme_body_class' );


/*
 * INCLUDE FUNCTIONS
 *
 *	The following included functions are required to use the whole theme functionality.
 *	! Notice: The fallback.php handles minimal fallbacks if the WPHAVE plugin is inactive.
 *



 *
 *
*/

$dir = get_template_directory();

	if( ! wphave_theme_is_plugin_active() ) {
		include_once $dir . '/inc/fallback.php';
	}

include_once $dir . '/inc/constants.php';
include_once $dir . '/inc/enqueue-styles.php';
include_once $dir . '/inc/enqueue-blocks.php';
