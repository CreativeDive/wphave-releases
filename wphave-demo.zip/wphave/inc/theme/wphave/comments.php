<?php

/**
 * The template for displaying comments.
 *
 * Provides the comments block while preventing WordPress from treating the
 * bundled block theme as if it had no comments template.
 */

// Use the comments block
if( function_exists( 'wphave_theme_is_plugin_active' ) && wphave_theme_is_plugin_active() ) {
    include( wphave_dir() . 'build/block-types/blocks-templates/comments/include.php' );
}
