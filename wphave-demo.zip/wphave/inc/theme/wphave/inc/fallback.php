<?php


if( ! function_exists( 'wphave_body_classes' ) ) {
	/**
	 * Body classes.
	 *
	 * @param mixed $classes Classes.
	 */

	function wphave_body_classes( $classes ) {

		$classes[] = 'frontend';

		return $classes;

	}
}

add_filter( 'wphave_add_theme_body_classes', 'wphave_body_classes', 2, 1 );

if( ! function_exists( 'wphave_use_fse' ) ) {
	/**
	 * Use fse.
	 */

	function wphave_use_fse() { return true; }
}

if( ! function_exists( 'wphave_data_get' ) ) {
	/**
	 * Read WPHAVE data when the platform is available, otherwise fail safely.
	 *
	 * The theme can load before the platform has completed its bootstrap. In that
	 * case this compatibility function must not permanently shadow the canonical
	 * resource API with an empty-array stub: the same function remains active for
	 * the rest of the request. Delegating once the repository class exists keeps
	 * the standalone-theme fallback while preserving late platform bootstraps.
	 *
	 * @param string $resource Resource id.
	 * @param string $path Optional nested path.
	 * @param mixed  $default Fallback value.
	 * @return mixed
	 */

	function wphave_data_get( $resource, $path = '', $default = null ) {
		if( ! class_exists( 'WPHAVE_Data_Resources' ) ) {
			return $path === '' || $path === null ? array() : $default;
		}

		$data = WPHAVE_Data_Resources::get( (string) $resource, false );

		if( $path === '' || $path === null ) {
			return $data;
		}

		return WPHAVE_Data_Resources::get_path_value( $data, (string) $path, $default );
	}
}
