<?php


if ( ! function_exists( 'wphave_theme_get_version' ) ) :

	/**
	 * Theme get version.
	 */

	function wphave_theme_get_version() {

		$theme = wp_get_theme();

		// If the child theme is used, we have to get the version number of the parent theme.
		// Otherwise we get the wrong version number of the child theme.
		if( is_child_theme() ) {
			$theme = wp_get_theme( get_template() );
		}

		return $theme->get( 'Version' );

	}

endif;


/*
 * THEME CONSTANTS
 *
 *	Define the default theme constants.
 *



 *
 *
*/

define( 'WPHAVE_THEME_VER', wphave_theme_get_version() );
define( 'WPHAVE_THEME', 'WPHAVE by wphave.com' );

// Get all WordPress core block styles from the theme directory.
static $core_blocks_style_folder;
$core_blocks_style_folder = glob( get_template_directory() . '/assets/css/blocks/' . '*', GLOB_ONLYDIR );

if( ! is_array( $core_blocks_style_folder ) ) {
	$core_blocks_style_folder = array();
}

define( 'WPHAVE_THEME_CORE_BLOCKS_STYLE_FOLDER', $core_blocks_style_folder );
