<?php


if ( ! function_exists( 'wphave_theme_remove_default_wp_inline_styles' ) ) :

	/**
	 * Theme remove default wp inline styles.
	 */

	function wphave_theme_remove_default_wp_inline_styles() {

			if( ! wphave_theme_is_plugin_active() ) {
				return;
			}

		/*
		* Filter to disallow the usage of Wordpress core block inline styles.
		*/

		add_filter( 'styles_inline_size_limit', '__return_zero' );

		/*
		* Filter to opt-in loading core block assets conditionally.
		*/

		add_filter( 'should_load_separate_core_block_assets', '__return_true' );

	}

endif;

add_action( 'init', 'wphave_theme_remove_default_wp_inline_styles', 99 );



if ( ! function_exists( 'wphave_theme_remove_default_wp_global_styles' ) ) :

	/**
	 * Theme remove default wp global styles.
	 */

	function wphave_theme_remove_default_wp_global_styles() {

	        if( ! wphave_theme_is_plugin_active() ) {
				return;
			}

		remove_action( 'wp_body_open', 'wp_global_styles_render_svg_filters' );
		remove_action( 'wp_body_open', 'gutenberg_global_styles_render_svg_filters' );

        remove_action( 'wp_enqueue_scripts', 'wp_enqueue_global_styles' );
        remove_action( 'wp_enqueue_scripts', 'gutenberg_enqueue_global_styles' );

        remove_action( 'wp_footer', 'wp_enqueue_global_styles', 1 );
        remove_action( 'wp_footer', 'gutenberg_enqueue_global_styles', 1 );

	}

endif;

add_action( 'init', 'wphave_theme_remove_default_wp_global_styles', 99 );



if ( ! function_exists( 'wphave_theme_remove_default_core_block_styles' ) ) :

	/**
	 * Theme remove default core block styles.
	 */

	function wphave_theme_remove_default_core_block_styles() {

			if( ! wphave_theme_is_plugin_active() ) {
				return;
			}

        /*
        * Remove general block styles files
        */

		wp_dequeue_style( 'wp-block-library' );
		wp_deregister_style( 'wp-block-library' );

		wp_dequeue_style( 'wp-block-library-theme' );
		wp_deregister_style( 'wp-block-library-theme' );

        /*
        * Remove block type specific inline styles
        * ! Note: wphave is already doing that job by registering out own core block styles
        */

        /*
        global $wp_styles;

        foreach( $wp_styles->queue as $key => $handle ) {
            if( strpos( $handle, 'wp-block-' ) === 0 ) {
                wp_dequeue_style( $handle );
                wp_deregister_style( $handle );
            }
        }
        */

		/*
        * DO NOT REMOVE "core-block-supports"
        * Otherwise the specific core block inline styles are not present
        */

		//wp_dequeue_style( 'core-block-supports' );
		//wp_deregister_style( 'core-block-supports' );

	}

endif;

add_action( 'wp_enqueue_scripts', 'wphave_theme_remove_default_core_block_styles' );



if ( ! function_exists( 'wphave_theme_remove_default_core_block_editor_styles' ) ) :

	/**
	 * Theme remove default core block editor styles.
	 *
	 * @param mixed $styles Styles.
	 */

	function wphave_theme_remove_default_core_block_editor_styles( $styles ) {

			if( ! wphave_theme_is_plugin_active() ) {
				return $styles;
			}

        $handles = [
            'wp-block-library',
            'wp-block-library-theme',
        ];

        foreach( $handles as $handle ) {

            // Remove style
            unset( $styles->registered[ $handle ] );

            // Loop dependencies and remove the defined style handle from other styles
            foreach( $styles->registered as $key => $style_val ) {

                // The dependencies.
                $deps = $style_val->deps;
                $style_pos = array_search( $handle, $deps );

                if( ! $style_pos ) {
                    continue;
                }

                // If the style-handle was located as a dependency, remove it.
                unset( $deps[ $style_pos ] );
                $styles->registered[ $key ]->deps = $deps;

            }

        }

        return $styles;

    }

endif;

add_action( 'wp_default_styles', 'wphave_theme_remove_default_core_block_editor_styles', PHP_INT_MAX );



if ( ! function_exists( 'wphave_theme_add_wp_core_block_styles' ) ) :

	/**
	 * Theme add wp core block styles.
	 *
	 * @param mixed $block_styles Block styles.
	 */

	function wphave_theme_add_wp_core_block_styles( $block_styles = array() ) {
		// The core block styles are bundled into assets/dist/theme.css by the plugin build step.
		// Returning the existing map prevents loading the same CSS again as separate block files.
		return $block_styles;

	}

endif;

add_filter('wphave_core_blocks_types', 'wphave_theme_add_wp_core_block_styles');



if ( ! function_exists( 'wphave_theme_add_wp_core_block_editor_styles' ) ) :

	/**
	 * Theme add wp core block editor styles.
	 *
	 * @param mixed $compine_css Compine css.
	 */

	function wphave_theme_add_wp_core_block_editor_styles( $compine_css ) {

		// Get all WordPress core block styles from the theme directory
		$core_blocks = WPHAVE_THEME_CORE_BLOCKS_STYLE_FOLDER;
		$block_path = get_template_directory() . '/assets/css/blocks/';

		foreach( $core_blocks as $core_block ) {

			// Get the block name only
			$block_name = basename( $core_block );
			$block_style = $block_name . '/editor.css';

			// Check if the core block contains a "style.css" file
			if( file_exists( $block_path . $block_style ) ) {
				// If so, then add the core block to the wphave block style check
				$compine_css[] = $block_path . $block_style;
			}

		}

		return $compine_css;

	}

endif;

add_filter('wphave_theme_editor_style_import_before', 'wphave_theme_add_wp_core_block_editor_styles');
