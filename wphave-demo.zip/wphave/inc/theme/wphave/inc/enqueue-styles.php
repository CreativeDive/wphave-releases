<?php


if ( ! function_exists( 'wphave_theme_default_assets' ) ) :

    /**
     * Theme default assets.
     */

    function wphave_theme_default_assets() {

        $js_assets = [
            //'handle' => '../path/.file.js
        ];

        $style_assets = [
            //'handle' => '../path/.file.css
			'wphave-theme' => 'assets/dist/theme.css',
        ];

        $js_assets_paths = [];
        foreach( $js_assets as $handle => $path ) {
            $js_assets_paths[$handle] = [
				// THEME ASSET INVARIANT: WordPress owns both the registered theme root
				// and its public URI. Never rebuild one from a directory URI plus text.
				'dir' => get_parent_theme_file_path( ltrim( $path, '/' ) ),
				'path' => get_parent_theme_file_uri( ltrim( $path, '/' ) ),
                'relative' => ltrim( $path, '/' ),
            ];
        }

        $style_assets_paths = [];
        foreach( $style_assets as $handle => $path ) {
            $style_assets_paths[$handle] = [
				'dir' => get_parent_theme_file_path( ltrim( $path, '/' ) ),
				'path' => get_parent_theme_file_uri( ltrim( $path, '/' ) ),
                'relative' => ltrim( $path, '/' ),
            ];
        }

        return [
            'js' => $js_assets_paths,
            'css' => $style_assets_paths
        ];

    }

endif;



if ( ! function_exists('wphave_theme_enqueue_styles') ) :

	/**
	 * Theme enqueue styles.
	 */

	function wphave_theme_enqueue_styles() {

        if( is_admin() ) {
            // Bail early!
            // Not for wp admin, otherwise the theme styles are applied to the block editor ui too !
            return;
        }

		// Get the global theme styles
        $theme_styles = wphave_theme_default_assets()['css'] ?? [];

        foreach( $theme_styles as $handle => $paths ) {
            $file_dir = $paths['dir'];
            $file_path = $paths['path'];
            if( file_exists( $file_dir ) ) {
                wp_enqueue_style(
                    $handle, $file_path, array(), filemtime( $file_dir ), 'all'
                );
            }
        }

	}

endif;

add_action( 'enqueue_block_assets', 'wphave_theme_enqueue_styles', 24 );



if ( ! function_exists('wphave_theme_enqueue_editor_styles') ) :

	/**
	 * Theme enqueue editor styles.
	 */

	function wphave_theme_enqueue_editor_styles() {

        if( ! is_admin() ) {
            // Bail early!
            return;
        }

		// Get the global theme styles
        $theme_styles = wphave_theme_default_assets()['css'] ?? [];

        foreach( $theme_styles as $handle => $paths ) {
            $file_dir = $paths['dir'];
            $relative_path = $paths['relative'];
            if( file_exists( $file_dir ) ) {
                // WordPress reads relative editor styles directly from the theme directory.
                // Passing the public URL would trigger an avoidable HTTP loopback request.
                add_editor_style( $relative_path );
            }
        }

	}

endif;

add_action( 'after_setup_theme', 'wphave_theme_enqueue_editor_styles');
