<?php

if ( ! function_exists( 'wphave_theme_child_wp_enqueue_scripts' ) ) :

	/**
	 * Enqueue project-specific child-theme styles.
	 */
	function wphave_theme_child_wp_enqueue_scripts() {
		// WordPress resolves the active stylesheet and its registered theme root.
		wp_enqueue_style( 'wphave-child', get_stylesheet_uri() );
	}

endif;

add_action( 'wp_enqueue_scripts', 'wphave_theme_child_wp_enqueue_scripts', 99 );

/* Add project-specific functions below this line. */
