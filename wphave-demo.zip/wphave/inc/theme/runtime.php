<?php

require_once __DIR__ . '/../features/security/file-mutex.php';

/**
 * Resolves bundled and installed theme state and runtime files.
 */

trait WPHAVE_Theme_Runtime {

    /**
     * Get the bundled parent theme directory inside the plugin.
     *
     * @return string Absolute path to the bundled parent theme directory.
     */

    public static function plugin_parent_theme_dir() {
		// FILESYSTEM LOCATION INVARIANT: Bundled resources resolve from the loaded
		// plugin identity, never from the location of an intermediate module.
		return wphave_dir( 'inc/theme/' . WPHAVE_DEFAULT_THEME_SLUG );
    }

    /**
     * Get the bundled child theme directory inside the plugin.
     *
     * @return string Absolute path to the bundled child theme directory.
     */

    public static function plugin_child_theme_dir() {
		return wphave_dir( 'inc/theme/' . WPHAVE_DEFAULT_CHILD_THEME_SLUG );
    }

    /**
     * Get the installed parent theme directory in wp-content/themes.
     *
     * @return string Absolute path to the installed parent theme directory.
     */

    public static function installed_parent_theme_dir() {
		$theme_root = get_theme_root( WPHAVE_DEFAULT_THEME_SLUG );

		// THEME LOCATION INVARIANT: WordPress may register or filter a theme root
		// outside wp-content/themes. Installation must target that owned root.
		return is_string( $theme_root ) && '' !== $theme_root
			? trailingslashit( $theme_root ) . WPHAVE_DEFAULT_THEME_SLUG
			: '';
    }

    /**
     * Get the installed child theme directory in wp-content/themes.
     *
     * @return string Absolute path to the installed child theme directory.
     */

    public static function installed_child_theme_dir() {
		$theme_root = get_theme_root( WPHAVE_DEFAULT_CHILD_THEME_SLUG );

		return is_string( $theme_root ) && '' !== $theme_root
			? trailingslashit( $theme_root ) . WPHAVE_DEFAULT_CHILD_THEME_SLUG
			: '';
    }

    /**
     * Read theme metadata from an explicit theme directory.
     *
     * wp_get_theme() expects a stylesheet slug plus a theme root, not the theme directory as
     * the root. Keeping this wrapper avoids accidental fallbacks to the currently active theme.
     *
     * @param string $theme_dir Absolute theme directory.
     * @return WP_Theme Theme object for the given directory.
     */

    public static function theme_from_directory( $theme_dir ) {
        $theme_dir = untrailingslashit( $theme_dir );

        return wp_get_theme( basename( $theme_dir ), dirname( $theme_dir ) );
    }

    /**
     * Check whether a theme directory exists with a readable stylesheet.
     *
     * WP_Theme can reuse cached header data inside a long-running request. The direct
     * style.css check keeps install-state detection accurate after theme files changed.
     *
     * @param string $theme_dir Absolute theme directory.
     * @return bool True when the directory contains a readable WordPress theme stylesheet.
     */

    public static function theme_directory_exists( $theme_dir ) {
        $theme_dir = untrailingslashit( $theme_dir );
        $stylesheet = $theme_dir . '/style.css';

        // SECURITY INVARIANT: Installation detection must describe an owned local
        // theme tree and must not follow a linked root or linked stylesheet.
        if( is_link( $theme_dir ) || is_link( $stylesheet ) ) {
            return false;
        }

        return is_readable( $stylesheet ) && self::theme_from_directory( $theme_dir )->exists();
    }

    /**
     * Get the bundled parent theme slug.
     *
     * @return string Parent theme slug.
     */

    public static function parent_slug() {
        return defined( 'WPHAVE_DEFAULT_THEME_SLUG' ) ? WPHAVE_DEFAULT_THEME_SLUG : 'wphave';
    }

    /**
     * Get the bundled child theme slug.
     *
     * @return string Child theme slug.
     */

    public static function child_slug() {
        return defined( 'WPHAVE_DEFAULT_CHILD_THEME_SLUG' ) ? WPHAVE_DEFAULT_CHILD_THEME_SLUG : 'wphave-child';
    }

    /**
     * Return all theme slugs that identify the WPHAVE theme environment.
     *
     * @return array Theme slugs.
     */

    public static function theme_slugs() {
        return array_filter( [
            self::parent_slug(),
            self::child_slug(),
            'wphave',
        ] );
    }

    /**
     * Check whether the bundled WPHAVE theme environment is active.
     *
     * This intentionally accepts the parent theme as active, because older installs may use
     * the parent theme directly. Use is_child_active() when the actual child-theme requirement matters.
     *
     * @return bool True when the configured parent or child theme slug is active.
     */

    public static function is_active() {
        $stylesheet = (string) get_stylesheet();
        $template = (string) get_template();

        return in_array( $stylesheet, self::theme_slugs(), true ) || in_array( $template, self::theme_slugs(), true );
    }

    /**
     * Check whether the bundled parent theme is the active template.
     *
     * @return bool True when the active template is the bundled parent theme.
     */

    public static function is_parent_active() {
        return get_template() === self::parent_slug();
    }

    /**
     * Check whether the bundled child theme is the active stylesheet.
     *
     * @return bool True when the bundled child theme is active.
     */

    public static function is_child_active() {
        return get_stylesheet() === self::child_slug();
    }

    /**
     * Check whether the parent theme is active directly and should be replaced by the child theme.
     *
     * @return bool True when the child theme should be activated.
     */

    public static function requires_child_theme_activation() {
        return self::is_parent_active() && ! self::is_child_active();
    }

    /**
     * Check whether the installed parent theme differs from the bundled parent theme.
     *
     * The version check catches normal theme releases. The runtime hash catches file changes
     * where the theme version was not changed yet.
     *
     * @param string $source_dir Absolute source theme directory.
     * @param string $target_dir Absolute installed theme directory.
     * @return bool True when the installed theme should be updated.
     */

    public static function theme_needs_update( $source_dir, $target_dir ) {
        if( is_link( $source_dir ) || is_link( $target_dir ) ) {
            return true;
        }

        $source_theme = self::theme_from_directory( $source_dir );
        $target_theme = self::theme_from_directory( $target_dir );

        if( $source_theme->get( 'Version' ) !== $target_theme->get( 'Version' ) ) {
            return true;
        }

        return self::runtime_hash( $source_dir ) !== self::runtime_hash( $target_dir );
    }

    /**
     * Return the parent theme files and directories that may be copied to wp-content/themes.
     *
     * @return array Runtime-only paths relative to the parent theme root.
     */

    public static function runtime_paths() {
        return [
            'assets',
            'comments.php',
            'functions.php',
            'inc',
            'index.php',
            'screenshot.png',
            'style.css',
            'templates',
            'theme.json',
        ];
    }

    /**
     * Delete a bounded runtime path inside the installed parent theme.
     *
     * @param string $path Absolute file or directory path to delete.
     * @param string $theme_dir Absolute installed parent theme directory.
     * @return void
     */

    public static function delete_runtime_path( $path, $theme_dir ) {
        $path = wp_normalize_path( $path );
        $theme_dir = untrailingslashit( wp_normalize_path( $theme_dir ) );

        if( is_link( $theme_dir ) ) {
            return;
        }

        $real_theme_dir = realpath( $theme_dir );

        if( ! $real_theme_dir ) {
            return;
        }

        $theme_dir = trailingslashit( wp_normalize_path( $real_theme_dir ) );

        // SECURITY INVARIANT: A symlink is an owned node only when its lexical
        // node identity (canonical parent plus lexical basename) is below the
        // canonical theme root. Remove the link itself and never authorize or
        // traverse its external target.
        if( is_link( $path ) ) {
            $real_parent = realpath( dirname( $path ) );
            $link_node = $real_parent
                ? wp_normalize_path( trailingslashit( $real_parent ) . basename( $path ) )
                : '';

            if( $link_node && strpos( $link_node, $theme_dir ) === 0 ) {
                unlink( $path );
            }
            return;
        }

        if( ! file_exists( $path ) ) {
            return;
        }

        $real_path = realpath( $path );

        if( ! $real_path ) {
            return;
        }

        $path = wp_normalize_path( $real_path );

        // SECURITY INVARIANT: Runtime cleanup follows canonical filesystem identities
        // and may remove only nodes below the installed theme root; lexical caller
        // paths never authorize deletion.
        if( strpos( $path, $theme_dir ) !== 0 ) {
            return;
        }

        if( is_dir( $path ) ) {
            $dir_iterator = new RecursiveDirectoryIterator( $path, RecursiveDirectoryIterator::SKIP_DOTS );
            $iterator = new RecursiveIteratorIterator( $dir_iterator, RecursiveIteratorIterator::CHILD_FIRST );

            foreach( $iterator as $file ) {
                // SECURITY INVARIANT: Linked directories are owned nodes, not
                // traversal roots. Unlink the node without touching its target.
                if( $file->isLink() ) {
                    unlink( $file->getPathname() );
                    continue;
                }

                if( $file->isDir() ) {
                    rmdir( $file->getPathname() );
                    continue;
                }

                unlink( $file->getPathname() );
            }

            rmdir( $path );
            return;
        }

        unlink( $path );
    }

    /**
     * Create a deterministic hash for the theme runtime files.
     *
     * @param string $theme_dir Absolute theme directory.
     * @return string Runtime file hash, or an empty string when the directory is missing.
     */

    public static function runtime_hash( $theme_dir ) {
        $theme_dir = untrailingslashit( $theme_dir );
        $files = [];

        if( ! is_dir( $theme_dir ) || is_link( $theme_dir ) ) {
            return '';
        }

        foreach( self::runtime_paths() as $relative_path ) {
            $path = $theme_dir . DIRECTORY_SEPARATOR . $relative_path;

            if( is_link( $path ) ) {
                $files[$relative_path] = 'linked';
                continue;
            }

            if( ! file_exists( $path ) ) {
                $files[$relative_path] = 'missing';
                continue;
            }

            if( is_dir( $path ) ) {
                $files = array_merge( $files, self::runtime_directory_hashes( $path, $relative_path ) );
                continue;
            }

            $file_hash = md5_file( $path );
            $files[$relative_path] = false === $file_hash ? 'unreadable' : $file_hash;
        }

        ksort( $files );

        return md5( wp_json_encode( $files ) );
    }

    /**
     * Hash all files in an allowed runtime directory.
     *
     * @param string $source Absolute directory to scan.
     * @param string $base_path Runtime path prefix relative to the theme root.
     * @return array Map of relative runtime paths to file hashes.
     */

    public static function runtime_directory_hashes( $source, $base_path ) {
        $files = [];

        if( is_link( $source ) ) {
            return [ $base_path => 'linked' ];
        }

        try {
            $dir_iterator = new RecursiveDirectoryIterator( $source, RecursiveDirectoryIterator::SKIP_DOTS );
            $iterator = new RecursiveIteratorIterator( $dir_iterator, RecursiveIteratorIterator::SELF_FIRST );
        } catch( UnexpectedValueException $exception ) {
            return [ $base_path => 'unreadable' ];
        }

        foreach( $iterator as $file ) {
            $relative_path = str_replace( '\\', '/', $iterator->getSubPathName() );

            if( self::runtime_path_is_excluded( $relative_path ) ) {
                continue;
            }

            if( $file->isLink() ) {
                $files[$base_path . '/' . $relative_path] = 'linked';
                continue;
            }

            if( $file->isDir() ) {
                continue;
            }

            $file_hash = md5_file( $file->getPathname() );
            $files[$base_path . '/' . $relative_path] = false === $file_hash ? 'unreadable' : $file_hash;
        }

        return $files;
    }

    /**
     * Validate every managed source node before mutating the installed parent theme.
     *
     * SECURITY INVARIANT: Parent-theme updates never follow source links.
     * DATA INTEGRITY INVARIANT: A source validation failure leaves the installed
     * runtime completely untouched.
     *
     * @param string $source Absolute bundled parent-theme directory.
     * @return bool Whether every managed source node is readable and link-free.
     */

    private static function runtime_source_is_safe( $source ) {
        if( ! is_dir( $source ) || is_link( $source ) || ! is_readable( $source ) ) {
            return false;
        }

        foreach( self::runtime_paths() as $relative_path ) {
            $source_path = $source . DIRECTORY_SEPARATOR . $relative_path;

            if( is_link( $source_path ) ) {
                return false;
            }

            if( ! file_exists( $source_path ) ) {
                continue;
            }

            if( ! is_readable( $source_path ) ) {
                return false;
            }

            if( ! is_dir( $source_path ) ) {
                continue;
            }

            try {
                $dir_iterator = new RecursiveDirectoryIterator( $source_path, RecursiveDirectoryIterator::SKIP_DOTS );
                $iterator = new RecursiveIteratorIterator( $dir_iterator, RecursiveIteratorIterator::SELF_FIRST );
            } catch( UnexpectedValueException $exception ) {
                return false;
            }

            foreach( $iterator as $file ) {
                $nested_path = str_replace( '\\', '/', $iterator->getSubPathName() );

                if( self::runtime_path_is_excluded( $nested_path ) ) {
                    continue;
                }

                if( $file->isLink() || ! $file->isReadable() ) {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * Mirror the bundled parent theme runtime files to wp-content/themes.
     *
     * Only files listed by runtime_paths() are managed. Missing bundled paths remove the
     * matching installed paths, and managed directories are rebuilt before copying so deleted
     * source files do not leave stale files behind in the installed parent theme.
     *
     * @param string $source Absolute bundled parent theme directory.
     * @param string $destination Absolute installed parent theme directory.
     * @return bool True when copying was attempted, false when the source is missing.
     */

    public static function copy_parent_theme_to_destination( $source, $destination ) {
        $source = untrailingslashit( $source );
        $destination = untrailingslashit( $destination );

        if( ! self::runtime_source_is_safe( $source ) || is_link( $destination ) ) {
            return false;
        }

        $destination_root = dirname( $destination );
        if( ! is_dir( $destination_root ) && ! mkdir( $destination_root, 0755, true ) ) {
            return false;
        }

        $transaction_root = realpath( $destination_root );
        if( false === $transaction_root ) {
            return false;
        }

        if( ! is_dir( $destination ) && ! mkdir( $destination, 0755, true ) ) {
            return false;
        }

        $lock_path = $destination . '.wphave-update.lock';
        try {
            // CONCURRENCY INVARIANT: Exactly one request may mutate the managed parent
            // runtime at a time. A busy lock fails quickly instead of interleaving commits.
            return WPHAVE_Security_File_Mutex::run(
                $lock_path,
                static function() use ( $source, $destination, $transaction_root ) {
                    return self::commit_parent_theme_transaction( $source, $destination, $transaction_root );
                }
            );
        } catch( WPHAVE_Security_File_Mutex_Exception $error ) {
            return false;
        }
    }

    /**
     * Stage and commit one exclusively locked parent-theme update.
     *
     * @param string $source Absolute bundled parent-theme directory.
     * @param string $destination Absolute installed parent-theme directory.
     * @param string $transaction_root Canonical root owning transaction directories.
     * @return bool Whether the complete transaction committed successfully.
     */

    private static function commit_parent_theme_transaction( $source, $destination, $transaction_root ) {
        $transaction_id = wp_generate_uuid4();
        $staging = $destination . '.wphave-update-' . $transaction_id;
        $backup = $destination . '.wphave-backup-' . $transaction_id;

        // OWNERSHIP INVARIANT: A transaction owns only directories created by this
        // invocation. Namespace collisions fail closed and are never cleaned up.
        if(
            file_exists( $staging ) ||
            is_link( $staging ) ||
            file_exists( $backup ) ||
            is_link( $backup )
        ) {
            return false;
        }

        if( ! mkdir( $staging, 0755, true ) ) {
            return false;
        }

        if( ! mkdir( $backup, 0755, true ) ) {
            self::delete_runtime_path( $staging, $transaction_root );
            return false;
        }

        // DATA INTEGRITY INVARIANT: Every source byte is staged successfully
        // before the first installed runtime path is changed.
        foreach( self::runtime_paths() as $relative_path ) {
            $source_path = $source . DIRECTORY_SEPARATOR . $relative_path;
            $staging_path = $staging . DIRECTORY_SEPARATOR . $relative_path;

            if( ! file_exists( $source_path ) ) {
                continue;
            }

            if( is_dir( $source_path ) ) {
                if( ! self::copy_runtime_directory( $source_path, $staging_path ) ) {
                    self::delete_runtime_path( $staging, $transaction_root );
                    self::delete_runtime_path( $backup, $transaction_root );
                    return false;
                }
                continue;
            }

            $staging_dir = dirname( $staging_path );
            if( ! is_dir( $staging_dir ) && ! mkdir( $staging_dir, 0755, true ) ) {
                self::delete_runtime_path( $staging, $transaction_root );
                self::delete_runtime_path( $backup, $transaction_root );
                return false;
            }

            if( ! copy( $source_path, $staging_path ) ) {
                self::delete_runtime_path( $staging, $transaction_root );
                self::delete_runtime_path( $backup, $transaction_root );
                return false;
            }
        }

        $committed_paths = [];

        foreach( self::runtime_paths() as $relative_path ) {
            $staging_path = $staging . DIRECTORY_SEPARATOR . $relative_path;
            $destination_path = $destination . DIRECTORY_SEPARATOR . $relative_path;
            $backup_path = $backup . DIRECTORY_SEPARATOR . $relative_path;
            $destination_exists = file_exists( $destination_path ) || is_link( $destination_path );
            $staging_exists = file_exists( $staging_path ) || is_link( $staging_path );

            if( ! $destination_exists && ! $staging_exists ) {
                continue;
            }

            if( $destination_exists ) {
                $backup_dir = dirname( $backup_path );
                if( ( ! is_dir( $backup_dir ) && ! mkdir( $backup_dir, 0755, true ) ) || ! rename( $destination_path, $backup_path ) ) {
                    $rolled_back = self::rollback_parent_theme_commit( $committed_paths, $destination, $backup );
                    self::delete_runtime_path( $staging, $transaction_root );
                    if( $rolled_back ) {
                        self::delete_runtime_path( $backup, $transaction_root );
                    }
                    return false;
                }

                $committed_paths[] = $relative_path;
            } else {
                $committed_paths[] = $relative_path;
            }

            if( $staging_exists && ! rename( $staging_path, $destination_path ) ) {
                $rolled_back = self::rollback_parent_theme_commit( $committed_paths, $destination, $backup );
                self::delete_runtime_path( $staging, $transaction_root );
                if( $rolled_back ) {
                    self::delete_runtime_path( $backup, $transaction_root );
                }
                return false;
            }
        }

        self::delete_runtime_path( $staging, $transaction_root );
        self::delete_runtime_path( $backup, $transaction_root );

        return true;
    }

    /**
     * Restore managed runtime paths after an interrupted parent-theme commit.
     *
     * @param array $committed_paths Paths whose commit phase was entered.
     * @param string $destination Installed parent-theme directory.
     * @param string $backup Transaction backup directory.
     * RECOVERY INVARIANT: Failed restores leave the backup tree intact for
     * subsequent recovery instead of deleting the last known-good runtime.
     *
     * @return bool Whether every entered path was restored successfully.
     */

    private static function rollback_parent_theme_commit( $committed_paths, $destination, $backup ) {
        $destination = untrailingslashit( wp_normalize_path( $destination ) );
        $backup = untrailingslashit( wp_normalize_path( $backup ) );
        $expected_backup_prefix = basename( $destination ) . '.wphave-backup-';

        if(
            is_link( $destination ) ||
            is_link( $backup ) ||
            realpath( dirname( $destination ) ) !== realpath( dirname( $backup ) ) ||
            strpos( basename( $backup ), $expected_backup_prefix ) !== 0
        ) {
            return false;
        }

        $restored = true;

        // RECOVERY INVARIANT: One failed path must not prevent restoration of
        // independent paths. The caller still receives failure and retains the
        // backup tree whenever any path could not be recovered.
        foreach( array_reverse( $committed_paths ) as $relative_path ) {
            $destination_path = $destination . DIRECTORY_SEPARATOR . $relative_path;
            $backup_path = $backup . DIRECTORY_SEPARATOR . $relative_path;

            self::delete_runtime_path( $destination_path, $destination );

            if( file_exists( $destination_path ) || is_link( $destination_path ) ) {
                $restored = false;
                continue;
            }

            if( ! file_exists( $backup_path ) && ! is_link( $backup_path ) ) {
                continue;
            }

            $destination_dir = dirname( $destination_path );
            if( ! is_dir( $destination_dir ) && ! @mkdir( $destination_dir, 0755, true ) ) {
                $restored = false;
                continue;
            }

            if( ! rename( $backup_path, $destination_path ) ) {
                $restored = false;
            }
        }

        return $restored;
    }

    /**
     * Copy a runtime directory recursively while excluding development-only files.
     *
     * @param string $source Absolute source directory.
     * @param string $destination Absolute destination directory.
     * @return bool True when the complete directory was copied successfully.
     */

    public static function copy_runtime_directory( $source, $destination ) {
        if( is_link( $source ) || ( ! is_dir( $destination ) && ! mkdir( $destination, 0755, true ) ) ) {
            return false;
        }

        try {
            $dir_iterator = new RecursiveDirectoryIterator( $source, RecursiveDirectoryIterator::SKIP_DOTS );
            $iterator = new RecursiveIteratorIterator( $dir_iterator, RecursiveIteratorIterator::SELF_FIRST );
        } catch( UnexpectedValueException $exception ) {
            return false;
        }

        foreach( $iterator as $file ) {
            $relative_path = $iterator->getSubPathName();

            if( self::runtime_path_is_excluded( $relative_path ) ) {
                continue;
            }

            if( $file->isLink() ) {
                return false;
            }

            $target_path = $destination . DIRECTORY_SEPARATOR . $relative_path;

            if( $file->isDir() ) {
                if( ! is_dir( $target_path ) && ! mkdir( $target_path, 0755, true ) ) {
                    return false;
                }
                continue;
            }

            $target_dir = dirname( $target_path );
            if( ! is_dir( $target_dir ) && ! mkdir( $target_dir, 0755, true ) ) {
                return false;
            }

            if( ! copy( $file->getPathname(), $target_path ) ) {
                return false;
            }
        }

        return true;
    }

}
