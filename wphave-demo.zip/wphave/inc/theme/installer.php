<?php

require_once __DIR__ . '/../features/security/file-mutex.php';

/**
 * Validates, installs, updates, and activates the bundled theme pair.
 */

require_once wphave_dir() . 'inc/features/security/boundaries/index.php';
require_once wphave_dir() . 'inc/features/security/owned-tree.php';

trait WPHAVE_Theme_Installer {

    /**
     * Decide whether a runtime path must be excluded from hashing and copying.
     *
     * @param string $relative_path Path relative to the scanned runtime directory.
     * @return bool True when the path is development-only or unsafe for runtime copying.
     */

    public static function runtime_path_is_excluded( $relative_path ) {
        $relative_path = str_replace( '\\', '/', (string) $relative_path );
        $parts = array_filter( explode( '/', $relative_path ) );

        foreach( $parts as $part ) {
            // FILESYSTEM INVARIANT: Dot files and dot directories never enter the public theme folder.
            if( strpos( $part, '.' ) === 0 ) {
                return true;
            }

            if( in_array( $part, [ '.git', 'node_modules', 'src' ], true ) ) {
                return true;
            }
        }

        $basename = basename( $relative_path );

        if( in_array( $basename, [ 'package.json', 'package-lock.json' ], true ) ) {
            return true;
        }

        return substr( $basename, -4 ) === '.map';
    }

    /**
     * Log theme setup diagnostics only in explicit debug mode.
     *
     * OBSERVABILITY INVARIANT: REST-triggered theme setup never emits incidental output that could
     * interfere with JSON responses. Keeping logs behind WP_DEBUG makes local troubleshooting
     * possible without making production installs noisy.
     *
     * @param string $message Debug message.
     * @return void
     */

    public static function debug_log( $message ) {
        if( ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
            return;
        }

        if( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            error_log( '[wphave] ' . WPHAVE_Security_Redactor::error_text( $message, 1000 ) );
        }
    }

    /**
     * Install or update the bundled parent theme.
     *
     * This method does not activate a theme by itself. Activation is only done through the
     * explicit setup flow after the user confirms the action in the app.
     *
     * @param string $type Optional log context, for example "update".
     * @return true|WP_Error True when no copy is needed or copying succeeds; otherwise WP_Error.
     */

    public static function install_parent_theme( $type = '' ) {
        $plugin_theme_parent_src = self::plugin_parent_theme_dir();
        $parent_dest = self::installed_parent_theme_dir();

        // SECURITY INVARIANT: Theme metadata and runtime files may be read only
        // through real bundled and installed directories, never through symlinks.
        if( is_link( $plugin_theme_parent_src ) || is_link( $parent_dest ) ) {
            return new WP_Error(
                'wphave_parent_theme_path_linked',
                __( 'The WPHAVE parent theme uses an unsafe linked directory.', 'wphave' )
            );
        }

        $plugin_theme_data = self::theme_from_directory( $plugin_theme_parent_src );
        $plugin_theme_version = $plugin_theme_data->get( 'Version' );

        $installed_theme_data = self::theme_from_directory( $parent_dest );
        $installed_theme_version = $installed_theme_data->get( 'Version' );

        if( ! is_dir( $parent_dest ) || self::theme_needs_update( $plugin_theme_parent_src, $parent_dest ) ) {
            $copied = self::copy_parent_theme_to_destination( $plugin_theme_parent_src, $parent_dest );

            // LIFECYCLE INVARIANT: Installation state may advance only after the
            // complete managed parent-theme runtime has been copied successfully.
            if( true !== $copied ) {
                return new WP_Error(
                    'wphave_parent_theme_copy_failed',
                    __( 'The bundled WPHAVE parent theme could not be installed.', 'wphave' )
                );
            }

            if( class_exists( 'WPHAVE_Lifecycle' ) ) {
                WPHAVE_Lifecycle::mark_theme_installed();
            }
            if( $type === 'update' ) {
                self::debug_log( 'theme updated from plugin. Version ' . $installed_theme_version . ' to ' . $plugin_theme_version );
            } else {
                self::debug_log( 'default theme installed.' );
            }
        }

        return true;
    }

    /**
     * Install the bundled child theme when it does not exist yet.
     *
     * The child theme is intentionally not updated automatically because it is the expected
     * place for project-specific code and user changes.
     *
     * @return true|WP_Error True when already installed or copied successfully; otherwise WP_Error.
     */

    public static function install_child_theme() {
        $plugin_theme_child_src = self::plugin_child_theme_dir();
        $child_dest = self::installed_child_theme_dir();

        // SECURITY INVARIANT: An installed-theme path must be a real directory owned by
        // the themes root. Treating a linked directory as an existing installation would
        // silently accept a child theme located outside that boundary.
        if( is_link( $child_dest ) ) {
            return new WP_Error( 'wphave_child_theme_destination_linked', __( 'The child theme destination is an unsafe linked directory.', 'wphave' ) );
        }

        if( is_dir( $child_dest ) && self::theme_directory_exists( $child_dest ) ) {
            return true;
        }

        $destination_root = dirname( $child_dest );
        if( ! is_dir( $destination_root ) && ! wp_mkdir_p( $destination_root ) ) {
            return new WP_Error( 'wphave_child_theme_lock_failed', __( 'The child theme installation lock could not be created.', 'wphave' ) );
        }

        $lock_path = $child_dest . '.wphave-install.lock';
        if( is_link( $lock_path ) ) {
            return new WP_Error( 'wphave_child_theme_lock_linked', __( 'The child theme installation lock is an unsafe linked file.', 'wphave' ) );
        }

        try {
            // CONCURRENCY INVARIANT: Only one request may decide and commit the
            // initial child-theme installation. Contending requests fail without mutation.
            return WPHAVE_Security_File_Mutex::run(
                $lock_path,
                static function() use ( $plugin_theme_child_src, $child_dest ) {
                    // Re-evaluate installation state under the lock. Another request may
                    // have completed between the initial check and lock acquisition.
                    if( is_link( $child_dest ) ) {
                        return new WP_Error( 'wphave_child_theme_destination_linked', __( 'The child theme destination is an unsafe linked directory.', 'wphave' ) );
                    }

                    if( is_dir( $child_dest ) ) {
                        if( self::theme_directory_exists( $child_dest ) ) {
                            return true;
                        }

                        // OWNERSHIP INVARIANT: WPHAVE may recover an empty abandoned
                        // install directory, but never overwrites a non-empty invalid
                        // directory that may contain customer-owned files.
                        if( ! self::child_theme_directory_is_empty( $child_dest ) ) {
                            return new WP_Error( 'wphave_child_theme_destination_invalid', __( 'The child theme destination contains files but is not a valid WordPress theme.', 'wphave' ) );
                        }

                        if( ! rmdir( $child_dest ) ) {
                            return new WP_Error( 'wphave_child_theme_destination_cleanup_failed', __( 'The empty child theme destination could not be prepared for installation.', 'wphave' ) );
                        }
                    }

                    $result = self::copy_child_theme_to_destination( $plugin_theme_child_src, $child_dest );
                    if( is_wp_error( $result ) ) {
                        return $result;
                    }

                    self::debug_log( 'default child theme installed.' );

                    return true;
                }
            );
        } catch( WPHAVE_Security_File_Mutex_Exception $error ) {
            if( WPHAVE_Security_File_Mutex::INVALID === $error->reason() ) {
                return new WP_Error( 'wphave_child_theme_lock_invalid', __( 'The child theme installation lock is not a regular file.', 'wphave' ) );
            }

            if( WPHAVE_Security_File_Mutex::BUSY === $error->reason() ) {
                return new WP_Error( 'wphave_child_theme_install_busy', __( 'The child theme is already being installed.', 'wphave' ) );
            }

            return new WP_Error( 'wphave_child_theme_lock_failed', __( 'The child theme installation lock could not be created.', 'wphave' ) );
        }
    }

    /**
     * Determine whether an invalid child-theme destination contains no entries.
     *
     * @param string $directory Absolute child-theme destination.
     * @return bool Whether the directory is readable and empty.
     */

    private static function child_theme_directory_is_empty( $directory ) {
        if( ! is_dir( $directory ) || is_link( $directory ) ) {
            return false;
        }

        try {
            $iterator = new FilesystemIterator( $directory, FilesystemIterator::SKIP_DOTS );
        } catch( UnexpectedValueException $exception ) {
            return false;
        }

        return ! $iterator->valid();
    }

    /**
     * Copy the complete bundled child theme to its installation directory.
     *
     * OWNERSHIP INVARIANT: Unlike the managed parent, the child theme is copied only once and
     * never synchronized afterward, preserving all project-specific changes.
     *
     * @param string $source Absolute bundled child-theme directory.
     * @param string $destination Absolute installation directory.
     * @return true|WP_Error True on success, WP_Error when copying fails.
     */

    private static function copy_child_theme_to_destination( $source, $destination ) {
        $source = untrailingslashit( wp_normalize_path( (string) $source ) );
        $destination = untrailingslashit( wp_normalize_path( (string) $destination ) );

        if( ! is_dir( $source ) || ! $destination ) {
            return new WP_Error( 'wphave_copy_source_missing', __( 'The bundled child theme directory does not exist.', 'wphave' ) );
        }

        // SECURITY INVARIANT: The bundled child-theme root itself must be a real
        // directory. Inspecting only nested iterator entries would allow a linked
        // root to import files owned by an unrelated filesystem location.
        if( is_link( $source ) ) {
            return new WP_Error( 'wphave_copy_source_linked', __( 'The bundled child theme uses an unsafe linked directory.', 'wphave' ) );
        }

        if( file_exists( $destination ) || is_link( $destination ) ) {
            return new WP_Error( 'wphave_copy_destination_exists', __( 'The child theme destination already exists.', 'wphave' ) );
        }

        $destination_root = dirname( $destination );
        if( ! is_dir( $destination_root ) && ! wp_mkdir_p( $destination_root ) ) {
            return new WP_Error( 'wphave_copy_destination_failed', __( 'The child theme directory could not be created.', 'wphave' ) );
        }

        $staging = $destination . '.wphave-install-' . wp_generate_uuid4();
        if( ! wp_mkdir_p( $staging ) ) {
            return new WP_Error( 'wphave_copy_destination_failed', __( 'The child theme directory could not be created.', 'wphave' ) );
        }

        $cleanup = static function() use ( $staging, $destination_root ): void {
            if( ! is_dir( $staging ) || is_link( $staging ) ) {
                return;
            }

            try {
                WPHAVE_Security_Owned_Tree::remove(
                    $staging,
                    $destination_root,
                    __( 'Incomplete child theme installation data could not be removed safely.', 'wphave' )
                );
            } catch( RuntimeException $error ) {
                // The original installation error remains authoritative. The owned-tree
                // boundary prevents a cleanup failure from expanding deletion scope.
            }
        };

        try {
            $dir_iterator = new RecursiveDirectoryIterator( $source, RecursiveDirectoryIterator::SKIP_DOTS );
            $iterator = new RecursiveIteratorIterator( $dir_iterator, RecursiveIteratorIterator::SELF_FIRST );
        } catch( UnexpectedValueException $exception ) {
            $cleanup();
            return new WP_Error( 'wphave_copy_source_unreadable', __( 'The bundled child theme directory could not be read.', 'wphave' ) );
        }

        foreach( $iterator as $file ) {
            // SECURITY INVARIANT: Bundled theme entries must be real source nodes.
            // Copying through a source symlink could disclose or package files that
            // are not owned by the bundled child theme.
            if( $file->isLink() ) {
                $cleanup();
                return new WP_Error( 'wphave_copy_source_linked', __( 'The bundled child theme contains an unsafe linked file.', 'wphave' ) );
            }

            $target_path = $staging . DIRECTORY_SEPARATOR . $iterator->getSubPathName();

            if( $file->isDir() ) {
                if( ! is_dir( $target_path ) && ! wp_mkdir_p( $target_path ) ) {
                    $cleanup();
                    return new WP_Error( 'wphave_copy_directory_failed', __( 'A child theme subdirectory could not be created.', 'wphave' ) );
                }
                continue;
            }

            if( ! copy( $file->getPathname(), $target_path ) ) {
                $cleanup();
                return new WP_Error( 'wphave_copy_file_failed', __( 'A child theme file could not be copied.', 'wphave' ) );
            }
        }

        // DATA INTEGRITY INVARIANT: The installed child theme becomes visible only
        // after every source entry has been copied successfully.
        if( ! rename( $staging, $destination ) ) {
            $cleanup();
            return new WP_Error( 'wphave_copy_commit_failed', __( 'The child theme installation could not be committed.', 'wphave' ) );
        }

        return true;
    }

    /**
     * Run the complete explicit setup flow for the bundled theme pair.
     *
     * LIFECYCLE INVARIANT: Parent files may update; child files are only installed
     * when missing. The child theme is activated only after this user-triggered flow succeeds.
     *
     * @return true|WP_Error True on success, WP_Error if parent or child installation failed.
     */

    public static function setup_default_theme() {
        $parent_result = self::install_parent_theme();

        if( is_wp_error( $parent_result ) ) {
            return $parent_result;
        }

        $child_result = self::install_child_theme();

        if( is_wp_error( $child_result ) ) {
            return $child_result;
        }

        // WordPress may have cached the available themes before this request copied files.
        // Clear the theme cache before checking existence and switching to the new child theme.
        if( function_exists( 'wp_clean_themes_cache' ) ) {
            wp_clean_themes_cache( false );
        }

        if( ! self::theme_directory_exists( self::installed_parent_theme_dir() ) ) {
            return new WP_Error(
                'wphave_theme_install_failed',
                __( 'The bundled WPHAVE parent theme could not be installed.', 'wphave' )
            );
        }

        if( ! self::theme_directory_exists( self::installed_child_theme_dir() ) ) {
            return new WP_Error(
                'wphave_child_theme_install_failed',
                __( 'The bundled WPHAVE child theme could not be installed.', 'wphave' )
            );
        }

        // Match Network Admin's per-site theme enablement. The parent is a
        // dependency, not a separately selectable project theme. Never enable
        // themes for unrelated sites as a side effect of setting up this site.
        if ( is_multisite() && ! wp_get_theme( self::child_slug() )->is_allowed() ) {
            $allowed_themes = (array) get_option( 'allowedthemes', array() );
            $allowed_themes[self::child_slug()] = true;
            update_option( 'allowedthemes', $allowed_themes );
            $stored_allowed_themes = (array) get_option( 'allowedthemes', array() );
            if ( empty( $stored_allowed_themes[self::child_slug()] ) ) {
                return new WP_Error(
                    'wphave_child_theme_enable_failed',
                    __( 'The WPHAVE child theme could not be enabled for this site.', 'wphave' )
                );
            }
        }

        switch_theme( self::child_slug() );

        // LIFECYCLE INVARIANT: WordPress is authoritative for activation state.
        // Persist activation only after the requested stylesheet is observable.
        if( self::child_slug() !== (string) get_stylesheet() ) {
            return new WP_Error(
                'wphave_child_theme_activation_failed',
                __( 'The bundled WPHAVE child theme could not be activated.', 'wphave' )
            );
        }

        if( class_exists( 'WPHAVE_Lifecycle' ) ) {
            WPHAVE_Lifecycle::mark_theme_activated();
        }
        self::debug_log( 'Child theme "' . self::child_slug() . '" activated by explicit user action.' );

        return true;
    }

}
