<?php

/**
 * Provides runtime fallback template parts when no global user-defined part exists.
 *
 * These parts are not persisted as posts. They keep fresh installs presentable
 * without creating or assigning content on the user's behalf.
 */

if( ! class_exists( 'WPHAVE_Template_Parts_Base' ) ) :

	class WPHAVE_Template_Parts_Base {

		/**
		 * Return fallback block content for a supported template part type.
		 *
		 * @param string $type Template part type.
		 * @return string
		 */

		public static function get_template_part( $type ) {

			if( $type === 'header' ) {
				return self::get_header_template_part();
			}

			if( $type === 'footer' ) {
				return self::get_footer_template_part();
			}

			return '';

		}

		/**
		 * Return the default runtime header block content.
		 *
		 * @return string
		 */

		private static function get_header_template_part() {

			return '
				<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"space-between"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-layout-gap);--ly-row-gap: var(--wphave-site-layout-gap);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: space-between;--ly-fl-direction: row","dimensions":{"spacing":{"padding":"1rem var(--wphave-site-layout-margin) 1rem var(--wphave-site-layout-margin)"}},"styles":"--pa: 1rem var(--wphave-site-layout-margin) 1rem var(--wphave-site-layout-margin);--left-spacing: var(--wphave-site-layout-margin);--right-spacing: var(--wphave-site-layout-margin)","classNames":"pa ly ly-fl ly-fl-wp"}} -->
					<!-- wp:wphave/site-logo /-->
					<!-- wp:wphave/navigation {"wphave":{"settings":{"collapseBehavior":"auto","collapseBreakpoint":768}}} -->
						<!-- wp:wphave/navigation-link {"content":"Home"} /-->
						<!-- wp:wphave/navigation-link {"content":"Blog"} /-->
						<!-- wp:wphave/navigation-link {"content":"Contact"} /-->
					<!-- /wp:wphave/navigation -->
				<!-- /wp:wphave/group -->
			';

		}

		/**
		 * Return the default runtime footer block content.
		 *
		 * @return string
		 */

		private static function get_footer_template_part() {

			return '
				<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"space-between"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-layout-gap);--ly-row-gap: var(--wphave-site-layout-gap);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: space-between;--ly-fl-direction: row","dimensions":{"spacing":{"padding":"2rem var(--wphave-site-layout-margin) 2rem var(--wphave-site-layout-margin)"}},"styles":"--pa: 2rem var(--wphave-site-layout-margin) 2rem var(--wphave-site-layout-margin);--left-spacing: var(--wphave-site-layout-margin);--right-spacing: var(--wphave-site-layout-margin)","classNames":"pa ly ly-fl ly-fl-wp"}} -->
					<!-- wp:wphave/paragraph {"content":"&copy; ' . esc_attr( date_i18n( 'Y' ) ) . ' ' . esc_attr( get_bloginfo( 'name' ) ) . '"} /-->
					<!-- wp:wphave/navigation {"wphave":{"settings":{"collapseBehavior":"never"}}} -->
						<!-- wp:wphave/navigation-link {"content":"Privacy"} /-->
						<!-- wp:wphave/navigation-link {"content":"Imprint"} /-->
					<!-- /wp:wphave/navigation -->
				<!-- /wp:wphave/group -->
			';

		}

	}

endif;
