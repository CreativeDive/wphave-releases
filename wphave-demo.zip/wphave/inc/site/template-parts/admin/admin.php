<?php

/**
 * Provide the management-only REST API for template part data.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

if( ! class_exists( 'WPHAVE_Template_Parts_Admin' ) ) :

	/**
	 * Coordinates template part data for WPHAVE administration screens.
	 */

	class WPHAVE_Template_Parts_Admin {

		/**
		 * Register admin REST routes.
		 *
		 * @return void
		 */

		public static function init() {
			add_action( 'rest_api_init', array( __CLASS__, 'register_rest_routes' ) );
		}

		/**
		 * Register template part management endpoints used by the WPHAVE app.
		 *
		 * @return void
		 */

		public static function register_rest_routes() {
			register_rest_route(WPHAVE_Template_Parts::REST_NAMESPACE, '/template-parts', array(
				'methods' => 'GET',
				'callback' => array( 'WPHAVE_Template_Parts', 'get_templates_parts' ),
				'permission_callback' => array( __CLASS__, 'can_manage' )
			));

			register_rest_route(WPHAVE_Template_Parts::REST_NAMESPACE, '/template-part-types', array(
				'methods' => 'GET',
				'callback' => array( 'WPHAVE_Template_Parts', 'get_templates_parts_types' ),
				'permission_callback' => array( __CLASS__, 'can_manage' )
			));
		}

		/**
		 * Check whether the current user can read template part management data.
		 *
		 * @return bool
		 */

		public static function can_manage() {
			// AUTHORIZATION INVARIANT: Template-part inventory reveals global render
			// structure and follows its dedicated feature capability, independently from
			// ordinary post editing and the Templates capability.
			return current_user_can('wphave_manage_template_parts') || current_user_can('wphave_manage_options') || current_user_can('manage_options');
		}

	}

endif;

WPHAVE_Template_Parts_Admin::init();
