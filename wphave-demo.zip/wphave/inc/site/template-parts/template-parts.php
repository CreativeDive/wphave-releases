<?php

/**
 * Handles template part registration, cache data and app REST endpoints.
 */

if( ! class_exists( 'WPHAVE_Template_Parts' ) ) :

	class WPHAVE_Template_Parts {

		const POST_TYPE = 'wphave-template-part';
		const META_PART_TYPE = 'wphave_template_part_type';
		const META_PART_SETTINGS = 'wphave_template_part_settings';
		const CACHE_BUCKET = 'post_type_features_data';
		const CACHE_KEY = 'wphave_template_part';
		const GLOBAL_PARTS_KEY = 'wphave_global_template_parts';
		const REST_NAMESPACE = 'wphave/v1';

		/**
		 * Template-part read model resolved during the current request.
		 *
		 * @var array|null
		 */

		private static $request_data = null;

		/**
		 * Register the template parts post type.
		 *
		 * @return void
		 */

		public static function register_post_type() {

			// WPHAVE template parts belong to its theme renderer; WordPress FSE provides native template parts instead.
			if( wphave_use_fse() ) {
				return;
			}

			register_post_type( self::POST_TYPE,
				array(
					'label' => __( 'Template Parts', 'wphave' ),
					'description' => __( 'Create and manage shared structural parts for your website.', 'wphave' ),
					'menu_icon' => 'data:image/svg+xml;base64,' . base64_encode( wphave_svg_ui_icon( 'header' ) ),
					'menu_position' => 47,
					'supports' => array(
						'title',
						'editor' => [
							'notes'
						],
						'revisions',
						'custom-fields'
					),
					'public' => false,
					'show_ui' => true,
					'rewrite' => false,
					'show_in_menu' => false,
					'show_in_rest' => true,
					'map_meta_cap' => true,
					'capabilities' => self::get_post_type_capabilities(),
					'has_archive' => false,
					'exclude_from_search' => true,
					'show_in_nav_menus' => false,
					'show_in_admin_bar' => false,
					'publicly_queryable' => false,
					'query_var' => false,
				)
			);

		}

		/**
		 * Return WordPress post type capabilities mapped to template part feature access.
		 *
		 * @return array
		 */

		private static function get_post_type_capabilities() {

			$capability = 'wphave_manage_template_parts';

			return array(
				'edit_post' => 'edit_wphave_template_part',
				'read_post' => 'read_wphave_template_part',
				'delete_post' => 'delete_wphave_template_part',
				'edit_posts' => $capability,
				'edit_others_posts' => $capability,
				'delete_posts' => $capability,
				'publish_posts' => $capability,
				'read_private_posts' => $capability,
				'create_posts' => $capability,
				'delete_private_posts' => $capability,
				'delete_published_posts' => $capability,
				'delete_others_posts' => $capability,
				'edit_private_posts' => $capability,
				'edit_published_posts' => $capability,
			);

		}

		/**
		 * Register template part post meta exposed to the editor/app.
		 *
		 * @return void
		 */

		public static function register_post_meta() {

			register_post_meta(self::POST_TYPE, self::META_PART_TYPE, array(
				'single' => true,
				'type' => 'string',
				'show_in_rest' => true,
				'default' => 'general',
				'auth_callback' => array( __CLASS__, 'can_manage_template_parts' )
			));

			register_post_meta(self::POST_TYPE, self::META_PART_SETTINGS, array(
				'single' => true,
				'type' => 'object',
				'default' => array(),
				'show_in_rest' => array(
					'schema' => array(
						'type' => 'object',
						'additionalProperties' => true,
					),
				),
				'auth_callback' => array( __CLASS__, 'can_manage_template_parts' )
			));

		}

		/**
		 * Determine whether the current user may edit template parts.
		 *
		 * @return bool Whether template-part management is permitted.
		 */

		public static function can_manage_template_parts() {
			return current_user_can( 'wphave_manage_template_parts' ) || current_user_can( 'wphave_manage_options' ) || current_user_can( 'manage_options' );
		}

		/**
		 * Cache and return template parts grouped by type.
		 *
		 * @return array
		 */

		public static function get_template_parts_data() {

			// PERFORMANCE INVARIANT: Public requests cannot populate the shared
			// internal-post-type cache. Retain empty and populated groupings locally
			// so repeated slot resolution does not reload posts and metadata.
			if( self::$request_data !== null ) {
				return self::$request_data;
			}

			$cached = wphave_has_cached_data( self::CACHE_BUCKET, array(
				'key' => self::CACHE_KEY,
				'admin_cache' => true,
			) );

			if( $cached !== false ) {
				self::$request_data = $cached;

				return self::$request_data;
			}

			wphave_events( 'CACHE', 'Template parts data.' );

			$save_data = self::build_template_parts_cache_data();

			wphave_save_query( $save_data, self::CACHE_BUCKET, array(
				'key' => self::CACHE_KEY,
				'admin_cache' => true,
				'frontend_write' => false,
			) );

			self::$request_data = $save_data;

			return self::$request_data;

		}

		/**
		 * Clear persistent and request-local template-part data.
		 *
		 * @return void
		 */

		public static function clear_cache() {

			// DATA INTEGRITY INVARIANT: No save or permanent deletion may leave
			// subsequent slot selection on the request-local pre-mutation grouping.
			self::$request_data = null;
			WPHAVE_Internal_Post_Type_Cache::invalidate( self::POST_TYPE );

		}

		/**
		 * Invalidate template-part data after a direct canonical meta mutation.
		 *
		 * @param int    $meta_id Metadata row ID.
		 * @param int    $post_id Template-part post ID.
		 * @param string $meta_key Metadata key.
		 * @return void
		 */

		public static function clear_cache_on_meta_change( $meta_id, $post_id, $meta_key ) {

			if(
				! in_array( $meta_key, array( self::META_PART_TYPE, self::META_PART_SETTINGS ), true )
				|| self::POST_TYPE !== get_post_type( $post_id )
			) {
				return;
			}

			// DATA INTEGRITY INVARIANT: Canonical meta may be written independently
			// of post content. Its type grouping and settings must become visible in
			// the same request and in every subsequent shared-cache reader.
			self::clear_cache();

		}

		/**
		 * Return general template parts.
		 *
		 * @return WP_Post[]
		 */

		public static function get_general_template_parts() {

			return get_posts( array(
				'post_type' => self::POST_TYPE,
				'numberposts' => -1,
				'post_status' => 'publish',
				'suppress_filters' => false,
				'cache_results' => true,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
				'meta_key' => self::META_PART_TYPE,
				'meta_value' => 'general',
			) );

		}

		/**
		 * REST response with template parts and global assignments.
		 *
		 * @param WP_REST_Request $request Request object.
		 * @return WP_REST_Response
		 */

		public static function get_templates_parts( $request ) {
			// AUTHORIZATION INVARIANT: The management callback repeats Template Parts authority before loading published parts or global slot assignments; frontend render helpers remain a separate trusted runtime path.
			if( ! self::can_manage_template_parts() ) {
				return self::management_forbidden();
			}

			$type = sanitize_text_field( $request->get_param( 'type' ) );
			$data = self::get_template_parts_data();
			$global = self::get_global_template_parts();

			if( $type ) {
				$data = self::is_valid_template_part_type( $type ) ? ( $data[ $type ] ?? [] ) : [];
			}

			return self::prepare_template_parts_response( $data, $global );

		}

		/**
		 * Return the available template part types for app creation screens.
		 *
		 * @return array
		 */

		public static function get_templates_parts_types() {
			// AUTHORIZATION INVARIANT: The administrative type catalog is not made public merely because individual template parts can render on the frontend.
			if( ! self::can_manage_template_parts() ) {
				return self::management_forbidden();
			}

			return self::get_template_part_types();

		}

		/** Return the stable denial for Template Parts management callbacks. */

		private static function management_forbidden() {
			return new WP_Error(
				'wphave_template_parts_forbidden',
				__( 'You are not allowed to inspect Template Parts.', 'wphave' ),
				array( 'status' => 403 )
			);
		}

		/**
		 * Query published template part ids for cache building.
		 *
		 * @return int[]
		 */

		private static function get_template_part_post_ids() {

			return wphave_internal_post_type_all_ids( self::POST_TYPE );

		}

		/**
		 * Build the cache payload grouped by template part type.
		 *
		 * CACHE INVARIANT: Only known template-part types are cached. This keeps stale or manually
		 * corrupted meta values out of the app and frontend lookup data.
		 *
		 * @return array
		 */

		private static function build_template_parts_cache_data() {

			$post_ids = self::get_template_part_post_ids();
			$save_data = [];

			if( empty( $post_ids ) ) {
				return $save_data;
			}

			foreach( $post_ids as $post_id ) {
				$template_part = self::get_template_part_data_from_post_id( $post_id );

				if( empty( $template_part ) ) {
					continue;
				}

				$type = $template_part['type'];

				if( ! isset( $save_data[$type] ) ) {
					$save_data[$type] = [];
				}

				unset( $template_part['type'] );

				$save_data[$type][$post_id] = $template_part;
			}

			return $save_data;

		}

		/**
		 * Build one template part cache record from a post id.
		 *
		 * @param int $post_id Template part post id.
		 * @return array
		 */

		private static function get_template_part_data_from_post_id( $post_id ) {

			$type = get_post_meta($post_id, self::META_PART_TYPE, true);

			if( ! self::is_valid_template_part_type( $type ) ) {
				return [];
			}

			$post = get_post( $post_id );

			if( ! $post || $post->post_type !== self::POST_TYPE || $post->post_status !== 'publish' ) {
				return [];
			}

			$content = $post->post_content ?? '';

			/*
			 * Keep cache creation side-effect free. Rendering blocks here used to run
			 * every published template part while merely resolving the active header
			 * or footer. Dynamic blocks can register request-scoped output during
			 * render_block (for example modal, popover and side-panel targets), so that
			 * preview render polluted the frontend footer with layers from unrelated
			 * template parts. Consumers already receive the serialized block content
			 * and render only the selected part in the actual page render pass.
			 */

			return [
				'type' => $type,
				'id' => $post_id,
				'title' => get_the_title( $post_id ),
				'content' => $content,
				'settings' => self::get_template_part_settings( $post_id ),
			];

		}

		/**
		 * Return sanitized template part settings stored on a template part post.
		 *
		 * @param int $post_id Template part post id.
		 * @return array
		 */

		public static function get_template_part_settings( $post_id ) {

			$settings = get_post_meta( $post_id, self::META_PART_SETTINGS, true );

			return is_array( $settings ) ? $settings : array();

		}

		/**
		 * Return global header/footer assignments from the data bundle.
		 *
		 * @return array
		 */

		private static function get_global_template_parts() {

			$assignments = wphave_data_get( 'template_parts', '', [] );

			if( ! is_array( $assignments ) ) {
				return array();
			}

			return array_intersect_key(
				$assignments,
				array(
					'header' => true,
					'footer' => true,
				)
			);

		}

		/**
		 * Validate persisted global header and footer assignments.
		 *
		 * @param array $data Proposed assignment map.
		 * @return true|WP_Error
		 */
		public static function validate_global_assignments( $data ) {
			if( ! is_array( $data ) ) return new WP_Error( 'wphave_template_part_assignments_invalid', __( 'Template part assignments must be a structured object.', 'wphave' ), array( 'status' => 400 ) );
			$allowed = array( 'header', 'footer' );
			$current = WPHAVE_Data_Resources::get( 'template_parts', false );
			foreach( $data as $slot => $post_id ) {
				if( ! in_array( $slot, $allowed, true ) ) return new WP_Error( 'wphave_template_part_slot_invalid', __( 'The selected global template part slot is invalid.', 'wphave' ), array( 'status' => 400 ) );
				if( array_key_exists( $slot, $current ) && $current[$slot] === $post_id ) continue;
				$post = get_post( absint( $post_id ) );
				$type = $post ? sanitize_key( (string) get_post_meta( $post->ID, self::META_PART_TYPE, true ) ) : '';
				if( ! $post || self::POST_TYPE !== $post->post_type || 'publish' !== $post->post_status || $type !== $slot ) {
					return new WP_Error( 'wphave_template_part_assignment_invalid', __( 'The selected template part cannot be assigned to this global slot.', 'wphave' ), array( 'status' => 400 ) );
				}
			}
			return true;
		}

		/**
		 * Prepare the REST response shape expected by the editor hook.
		 *
		 * @param array $template_parts Template parts grouped by type or filtered type.
		 * @param array $global Global template part assignments.
		 * @return WP_REST_Response
		 */

		private static function prepare_template_parts_response( $template_parts, $global ) {

			return rest_ensure_response([
				'templateParts' => $template_parts ?: [],
				'global' => $global ?: [],
			]);

		}

		/**
		 * Check whether a template part type belongs to the supported type map.
		 *
		 * @param string $type Template part type.
		 * @return bool
		 */

		private static function is_valid_template_part_type( $type ) {

			return is_string( $type ) && isset( self::get_template_part_types()[$type] );

		}

		/**
		 * Return the canonical template part type map used by REST and cache validation.
		 *
		 * @return array
		 */

		private static function get_template_part_types() {

			return [
				'header' => [
					'id' => 'header',
					'icon' => 'header',
					'label' => __('Header', 'wphave'),
					'description' => __('Defines the top section of the site layout. Typically contains the logo, navigation, announcement bars, or other elements shown at the beginning of a page.', 'wphave'),
					'starter_pattern_category' => 'wphave-header',
				],
				'footer' => [
					'id' => 'footer',
					'icon' => 'footer',
					'label' => __('Footer', 'wphave'),
					'description' => __('Defines the bottom section of the site layout. Often contains site credits, secondary navigation, social links, or supplementary content.', 'wphave'),
					'starter_pattern_category' => 'wphave-footer',
				],
				'general' => [
					'id' => 'general',
					'icon' => 'patterns',
					'label' => __('General', 'wphave'),
					'description' => __('A centrally managed website section that can be used in templates, pages, and posts. Changes are applied everywhere it appears.', 'wphave'),
				],
			];

		}

	}

endif;

add_action( 'init', array( 'WPHAVE_Template_Parts', 'register_post_type' ), 16 );
add_action( 'init', array( 'WPHAVE_Template_Parts', 'register_post_meta' ) );
add_action( 'save_post_' . WPHAVE_Template_Parts::POST_TYPE, array( 'WPHAVE_Template_Parts', 'clear_cache' ) );
add_action( 'delete_post_' . WPHAVE_Template_Parts::POST_TYPE, array( 'WPHAVE_Template_Parts', 'clear_cache' ) );
add_action( 'added_post_meta', array( 'WPHAVE_Template_Parts', 'clear_cache_on_meta_change' ), 10, 3 );
add_action( 'updated_post_meta', array( 'WPHAVE_Template_Parts', 'clear_cache_on_meta_change' ), 10, 3 );
add_action( 'deleted_post_meta', array( 'WPHAVE_Template_Parts', 'clear_cache_on_meta_change' ), 10, 3 );
