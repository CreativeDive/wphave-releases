<?php

/**
 * Bootstrap custom template part services.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/template-parts.php';
require_once __DIR__ . '/base.php';
