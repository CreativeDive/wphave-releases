<?php

/**
 * Central style orchestration layer.
 *
 * Responsibilities:
 * - Collect inline styles (queue system)
 * - Handle frontend vs backend output logic
 * - Print final CSS into <head>
 * - Integrate global styles (cached)
 *
 * Architecture:
 * - WPHAVE_Global_Styles → builds CSS
 * - WPHAVE_Style_Engine → outputs CSS
 *
 * Flow:
 * add() → collect → print_site_head_styles() → output
 */

if( ! defined('ABSPATH') ) {
    exit;
}

class WPHAVE_Style_Engine {

    /** COMPATIBILITY INVARIANT: Increase whenever cached global CSS serialization changes incompatibly. */

	// Version 4 drops font faces generated from inventory activation alone.
	private const GLOBAL_STYLES_CACHE_VERSION = 4;

    private static ?self $instance = null;

    /**
     * Stores all inline styles (deduplicated via hash).
     *
     * @var array<string, string>
     */

    private array $inline_styles = [];

    /**
     * Singleton instance
     */

    public static function instance(): self {
        return self::$instance ??= new self();
    }

    /**
     * Initialize the style engine service.
     */

    private function __construct() {}

    /**
     * Hooks the engine into WordPress lifecycle.
     */

    public function boot() {
        add_action('wp_enqueue_scripts', [ $this, 'apply_global_styles' ]);
    }

    /**
     * Add inline CSS to the queue
     *
     * - Deduplicated via md5 hash
     * - Used by blocks and global styles
     *
     * @param string $css
     */

    public function add( $css ) {
        if( ! $css ) {
            return;
        }

        $this->inline_styles[md5($css)] = $css;
    }

    /**
     * Handles where styles should be printed:
     *
     * - Backend / Editor → print immediately
     * - SSR / special cases → print immediately
     * - Frontend → collect in queue
     *
     * @param string|array $css
     * @param array $args
     * @return bool
     */

    function print_inline_styles( $css, $args = '' ) {
        if( ! $css ) {
            return false;
        }

        // Convert array-based CSS to string
        if( is_array( $css ) ) {
            $css = WPHAVE_Global_Styles::build_css_from_array( $css );
        }

        $stay_here = isset( $args['stay_here'] ) && $args['stay_here'];

        // Print styles immediately when they cannot safely be deferred to the frontend queue.

        if(
            is_admin() ||
            $stay_here ||
            wphave_use_fse() ||
            wphave_is_server_side_render_block_request()
        ) {
            echo $this->wrap_style_tag( $css ); // phpcs:ignore WordPress.Security.EscapeOutput
            return true;
        }

        /**
         * FRONTEND: collect styles
         */

        $this->add( $css );

        return true;
    }

    /**
     * Builds the final <style> tag output.
     *
     * Order:
     * 1. Font imports
     * 2. Collected inline styles
     * 3. Filter extensions
     *
     * @return string
     */

    public function print_site_head_styles() {
        /**
         * Fonts
         */

        $fonts = apply_filters('wphave_block_import_fonts', $fonts = '');

        if( $fonts ) {
            $fonts = wphave_array_unique_multidimensional( $fonts );
        }

        $font_import = '';
        if( $fonts ) {
            $font_url = WPHAVE_Fonts::google_fonts_url( $fonts );
            if( $font_url ) $font_import = "@import url('" . $font_url . "');";
        }

        /**
         * Inline styles
         * e.g. custom block styles
         */

        // Inline styles queue
        $styles = implode('', $this->inline_styles);

        // External systems can modify or extend styles.
        $styles = apply_filters('wphave_block_inline_style', $styles);

        // Combine both and return the final styles output
        // ! Make sure, font @import is placed first, before all other styles
        return $this->wrap_style_tag( $font_import . $styles );
    }

    /**
     * Wraps CSS into a <style> tag and minifies it.
     *
     * @param string $styles
     * @return string
     */

    public function wrap_style_tag( $styles ) {
        $styles = wphave_minify_css( (string) $styles );

        /*
         * CSS may originate from block attributes or extension filters. Escape
         * every case variant of the HTML end tag so CSS can never terminate the
         * trusted style element and inject following markup.
         */

        $styles = preg_replace( '/<\/style/i', '<\/style', $styles );

        return '<style>' . $styles . '</style>';
    }

    /**
     * Retrieves cached global styles or rebuilds them.
     *
     * @param array $wphave
     * @return string
     */

    public function get_global_styles_string( $wphave = [] ) {
		// Load cached styles
		$options = WPHAVE_Data_Repository::get_option_data( 'wphave_data' );
		$styles = $options['wphave_site_global_styles'] ?? '';
		$cache_version = (int) ( $options['wphave_site_global_styles_version'] ?? 0 );
		if( $cache_version !== self::GLOBAL_STYLES_CACHE_VERSION ) $styles = '';

        /**
         * REBUILD if cache is empty, if deleted after saving site globals
         */

        if( ! $styles ) {
            $styles = WPHAVE_Global_Styles::compose_global_styles_string( $wphave, array(
                'global_vars' => true,
                'color_mode_vars' => true,
                'colors_rgb_vars' => true,
                'palette_color_vars' => true,
                'color_context_vars' => true,
                'color_scales_vars' => true,
                'include_local_fonts' => true,
            ) );

            /* <- {event tracking} -> */

            wphave_events( 'UPDATE', 'Global styles.' );

            /*
             * CACHE INVARIANT: Frontend requests must not persist rebuilt CSS into wp_options.
             * Public rendering may still rebuild the missing CSS for the current
             * response, but persistent cache writes belong to controlled contexts
             * such as admin, REST saves, cron, AJAX, or WP-CLI.
             */

            if( $this->can_persist_global_styles_cache() ) {
                // The generated CSS owns only its cache key. Never route this
                // through a writable full option snapshot.
	            WPHAVE_Data_Repository::update_option_value( 'wphave_data', 'wphave_site_global_styles', $styles );
	            WPHAVE_Data_Repository::update_option_value( 'wphave_data', 'wphave_site_global_styles_version', self::GLOBAL_STYLES_CACHE_VERSION );
            }
		}

        return $styles;
	}

    /**
     * Checks whether this request may write the global styles cache.
     *
     * @return bool True for controlled backend/system contexts.
     */

    private function can_persist_global_styles_cache(): bool {
        return is_admin()
            || wp_doing_ajax()
            || wp_doing_cron()
            || ( defined( 'REST_REQUEST' ) && REST_REQUEST )
            || ( defined( 'WP_CLI' ) && WP_CLI );
    }

    /**
     * Injects global styles into the system.
     *
     * Behavior:
     * - FSE → inline via wp_add_inline_style
     * - Classic → push into style queue
     */

    public function apply_global_styles() {
        // Get the global styles generated css string
		$global_styles = $this->get_global_styles_string();

        // In FSE mode, attach the generated styles to the WordPress stylesheet.

        if( wphave_use_fse() ) {
            wp_add_inline_style( 'wphave', $global_styles );

            // Exit !
            return;
        }

        // In WPHAVE mode, defer the styles through the engine queue.

        $this->add( $global_styles );
    }
}
