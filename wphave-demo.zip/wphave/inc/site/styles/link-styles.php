<?php

/**
 * Add the passed state to each link selector.
 */

if ( ! function_exists( 'wphave_link_selectors' ) ) :

	function wphave_link_selectors( $selectors, $state = '' ) {

		$selectors_new = array();

		foreach( $selectors as $selector ) {
			$selectors_new[] = ( $selector . $state );
		}

		return implode(',', $selectors_new);

	}

endif;


/**
 * Selection of different link styles.
 */

if ( ! function_exists( 'wphave_link_style' ) ) :

    function wphave_link_style( $args = '' ) {

		$output = isset( $args['output'] ) ? $args['output'] : '';
		$output_type = isset( $args['outputType'] ) ? $args['outputType'] : 'keys'; // keys, css
		$style = $args['style'] ?? 'default';
		$selector_custom = isset( $args['selector'] ) ? $args['selector'] : '';

		// Get all link selectors
		$selectors = array(
			'a.wphave-text-link',
		);

        $selectors = $selector_custom ? array( $selector_custom ) : $selectors;



		/*static $cache = array();

		$cache_key = md5( $style . implode( '', $selectors ) . 'link_styles' );
		$memoized_value = wphave_request_memoization_read( $cache, $cache_key, array('output' => $output) );

		if( $memoized_value ) {
			// Reuse memoized value for this request
			return $memoized_value;
		}*/



        $selector = wphave_link_selectors( $selectors );
        $selector_hover = wphave_link_selectors( $selectors, ':is(:hover, :focus-visible)' );
        $selector_before = wphave_link_selectors( $selectors, '::before' );
        $selector_hover_before = wphave_link_selectors( $selectors, ':is(:hover, :focus-visible)::before' );
        $selector_after = wphave_link_selectors( $selectors, '::after' );
        $selector_hover_after = wphave_link_selectors( $selectors, ':is(:hover, :focus-visible)::after' );

		$styles = array( 'default' => array() );



		$css = array();

            // Default
            $css[$selector]['position'] = 'relative';

            // Before
            $css[$selector_before]['content'] = '""';
            $css[$selector_before]['position'] = 'absolute';
            $css[$selector_before]['top'] = '100%';
            $css[$selector_before]['left'] = '0';
            $css[$selector_before]['width'] = '100%';
            $css[$selector_before]['height'] = '1px';
            $css[$selector_before]['background'] = 'currentColor';
            $css[$selector_before]['pointer-events'] = 'none';
            $css[$selector_before]['transform'] = 'scale3d(0, 1, 1)';
            $css[$selector_before]['transform-origin'] = '100% 50%';
            $css[$selector_before]['transition'] = 'transform 0.3s';

            // Hover Before
            $css[$selector_hover_before]['transform'] = 'scale3d(1, 1, 1)';
            $css[$selector_hover_before]['transform-origin'] = '0% 50%';

		$styles['underline-slide'] = $css;



		$css = array();

            // Default
            $css[$selector]['position'] = 'relative';

            // Before
            $css[$selector_before]['content'] = '""';
            $css[$selector_before]['position'] = 'absolute';
            $css[$selector_before]['top'] = '0';
            $css[$selector_before]['left'] = '0';
            $css[$selector_before]['width'] = '100%';
            $css[$selector_before]['height'] = '100%';
            $css[$selector_before]['background'] = 'currentColor';
            $css[$selector_before]['opacity'] = '0';
            $css[$selector_before]['pointer-events'] = 'none';
            $css[$selector_before]['transform'] = 'scale3d(0, 1, 1)';
            $css[$selector_before]['transform-origin'] = '100% 50%';
            $css[$selector_before]['transition'] = 'transform 0.3s';

            // Hover Before
            $css[$selector_hover_before]['opacity'] = '1';
            $css[$selector_hover_before]['animation'] = 'linkCoverUp 0.2s ease forwards';

            // Keyframes animation
            $css['@keyframes linkCoverUp'] = array(
                '0%' => array(
                    'transform-origin' => '50% 100%',
                    'transform' => 'scale3d(1, 0.045, 1)',
                ),
                '50%' => array(
                    'transform-origin' => '50% 100%',
                    'transform' => 'scale3d(1, 1, 1)',
                ),
                '51%' => array(
                    'transform-origin' => '50% 0%',
                    'transform' => 'scale3d(1, 1, 1)',
                ),
                '100%' => array(
                    'transform-origin' => '50% 0%',
                    'transform' => 'scale3d(1, 0.045, 1)',
                ),
            );

		$styles['cover-swipe'] = $css;



		$css = array();

            // Default
            $css[$selector]['position'] = 'relative';

            // Before
            $css[$selector_before]['content'] = '""';
            $css[$selector_before]['position'] = 'absolute';
            $css[$selector_before]['top'] = '100%';
            $css[$selector_before]['left'] = '0';
            $css[$selector_before]['width'] = '100%';
            $css[$selector_before]['height'] = '10px';
            $css[$selector_before]['background'] = 'currentColor';
            $css[$selector_before]['opacity'] = '0';
            $css[$selector_before]['pointer-events'] = 'none';
            $css[$selector_before]['transform'] = 'scale3d(0, 1, 1)';
            $css[$selector_before]['transform-origin'] = '100% 50%';
            $css[$selector_before]['transition'] = 'transform 0.3s';

            // Hover Before
            $css[$selector_hover_before]['opacity'] = '1';
            $css[$selector_hover_before]['animation'] = 'linkLineUp 0.2s ease forwards';

            // Keyframes animation
            $css['@keyframes linkLineUp'] = array(
                '0%' => array(
                    'transform-origin' => '50% 100%',
                    'transform' => 'scale3d(1, 0.045, 1)',
                ),
                '50%' => array(
                    'transform-origin' => '50% 100%',
                    'transform' => 'scale3d(1, 1, 1)',
                ),
                '51%' => array(
                    'transform-origin' => '50% 0%',
                    'transform' => 'scale3d(1, 1, 1)',
                ),
                '100%' => array(
                    'transform-origin' => '50% 0%',
                    'transform' => 'scale3d(1, 0.045, 1)',
                ),
            );

		$styles['thick-line-swipe'] = $css;



		$css = array();

            // Default
            $css[$selector]['position'] = 'relative';

            // Before
            $css[$selector_before]['content'] = '""';
            $css[$selector_before]['border-bottom'] = 'solid 1px currentColor';
            $css[$selector_before]['position'] = 'absolute';
            $css[$selector_before]['bottom'] = '0';
            $css[$selector_before]['left'] = '0';
            $css[$selector_before]['width'] = '0';
            $css[$selector_before]['pointer-events'] = 'none';
            $css[$selector_before]['transition'] = 'width 0.3s ease';

            // After
            $css[$selector_after]['content'] = '""';
            $css[$selector_after]['border-bottom'] = 'solid 1px currentColor';
            $css[$selector_after]['position'] = 'absolute';
            $css[$selector_after]['bottom'] = '0';
            $css[$selector_after]['right'] = '0';
            $css[$selector_after]['width'] = '0';
            $css[$selector_after]['pointer-events'] = 'none';
            $css[$selector_after]['transition'] = 'width 0.3s ease';

            // Hover Before
            $css[$selector_hover_before]['width'] = '50%';

            // Hover After
            $css[$selector_hover_after]['width'] = '50%';

		$styles['split-underline'] = $css;



		$css = array();

            // Default
            $css[$selector]['position'] = 'relative';

            // Before
            $css[$selector_before]['content'] = '""';
            $css[$selector_before]['border-bottom'] = 'solid 1px currentColor';
            $css[$selector_before]['position'] = 'absolute';
            $css[$selector_before]['bottom'] = '0';
            $css[$selector_before]['left'] = '0';
            $css[$selector_before]['width'] = '100%';
            $css[$selector_before]['opacity'] = '0';
            $css[$selector_before]['pointer-events'] = 'none';
            $css[$selector_before]['transition'] = 'opacity 0.2s ease';

            // Hover Before
            $css[$selector_hover_before]['opacity'] = '1';

		$styles['fade-underline'] = $css;



		$css = array();

            // Default
            $css[$selector]['position'] = 'relative';

            // Before
            $css[$selector_before]['content'] = '""';
            $css[$selector_before]['border-bottom'] = 'solid 1px currentColor';
            $css[$selector_before]['position'] = 'absolute';
            $css[$selector_before]['bottom'] = '0';
            $css[$selector_before]['left'] = '0';
            $css[$selector_before]['width'] = '100%';
            $css[$selector_before]['pointer-events'] = 'none';
            $css[$selector_before]['transition'] = 'bottom 0.3s ease, transform 0.3s ease';

            // Hover Before
            $css[$selector_hover_before]['bottom'] = '-1px';
            $css[$selector_hover_before]['transform'] = 'scaleY(4)';

		$styles['grow-underline'] = $css;



		$css = array();

            // Default
            $css[$selector]['position'] = 'relative';
            $css[$selector]['padding'] = '3px 8px';
            $css[$selector]['z-index'] = '1';
			$css[$selector]['isolation'] = 'isolate';

            // Before
            $css[$selector_before]['content'] = '""';
            $css[$selector_before]['display'] = 'block';
            $css[$selector_before]['position'] = 'absolute';
            $css[$selector_before]['top'] = '0';
            $css[$selector_before]['left'] = '0';
            $css[$selector_before]['width'] = '100%';
            $css[$selector_before]['height'] = '100%';
            $css[$selector_before]['z-index'] = '-1';
            $css[$selector_before]['opacity'] = '0.15';
            $css[$selector_before]['pointer-events'] = 'none';
            $css[$selector_before]['transition'] = '100ms ease-out 50ms';
            $css[$selector_before]['transform-origin'] = '0 24px';
            $css[$selector_before]['background'] = 'var(--wphave-site-color-link-hover)';

            // Hover Before
            $css[$selector_hover_before]['top'] = '8px';
            $css[$selector_hover_before]['transform'] = 'scaleY(.1)';
            $css[$selector_hover_before]['transition'] = '100ms ease-out';

		$styles['highlight-drop'] = $css;



		$css = array();

            // Default
            $css[$selector]['text-decoration'] = 'underline';
            $css[$selector]['text-decoration-skip-ink'] = 'none';
            $css[$selector]['text-decoration-thickness'] = '2px';
            $css[$selector]['text-underline-offset'] = '4px';
            // Default Hover
            $css[$selector_hover]['text-decoration'] = 'underline wavy';

		$styles['wavy-underline'] = $css;



		$css = array();

            // Default
            $css[$selector]['position'] = 'relative';
            $css[$selector]['z-index'] = '1';
            $css[$selector]['isolation'] = 'isolate';

            // Before
            $css[$selector_before]['content'] = '""';
            $css[$selector_before]['position'] = 'absolute';
            $css[$selector_before]['right'] = '-0.08em';
            $css[$selector_before]['bottom'] = '0.08em';
            $css[$selector_before]['left'] = '-0.08em';
            $css[$selector_before]['height'] = '0.45em';
            $css[$selector_before]['z-index'] = '-1';
            $css[$selector_before]['background'] = 'var(--wphave-site-color-link-hover)';
            $css[$selector_before]['opacity'] = '0.2';
            $css[$selector_before]['pointer-events'] = 'none';
            $css[$selector_before]['transform'] = 'scaleX(0.15) skewX(-8deg)';
            $css[$selector_before]['transform-origin'] = '0 50%';
            $css[$selector_before]['transition'] = 'opacity 0.3s ease, transform 0.3s ease';

            // Hover Before
            $css[$selector_hover_before]['opacity'] = '0.35';
            $css[$selector_hover_before]['transform'] = 'scaleX(1) skewX(-8deg)';

		$styles['marker-highlight'] = $css;
        if( $output === 'all' ) {
			$labels = array(
				'default' => __( 'Default', 'wphave' ),
				'underline-slide' => __( 'Underline Slide', 'wphave' ),
				'cover-swipe' => __( 'Cover Swipe', 'wphave' ),
				'thick-line-swipe' => __( 'Thick Line Swipe', 'wphave' ),
				'split-underline' => __( 'Split Underline', 'wphave' ),
				'fade-underline' => __( 'Fade Underline', 'wphave' ),
				'grow-underline' => __( 'Grow Underline', 'wphave' ),
				'highlight-drop' => __( 'Highlight Drop', 'wphave' ),
				'wavy-underline' => __( 'Wavy Underline', 'wphave' ),
				'marker-highlight' => __( 'Marker Highlight', 'wphave' ),
			);

			if( $output_type === 'catalog' ) {
				$catalog = array();
				foreach( $styles as $id => $definition ) {
					$catalog[$id] = array(
						'id' => $id,
						'label' => $labels[$id],
						'css' => WPHAVE_Global_Styles::build_css_from_array( $definition ),
					);
				}
				return $catalog;
			}
            if( $output_type === 'css' ) {
                $css_styles = [];
				foreach( $styles as $id => $definition ) {
					$css_styles[$id] = WPHAVE_Global_Styles::build_css_from_array( $definition );
                }
                return $css_styles;
            }
			return $styles;
		}

        $data = $styles[$style] ?? $styles['default'];



		//$cache[ $cache_key ] = $data;

		return $output_type === 'css' ? WPHAVE_Global_Styles::build_css_from_array( $data ) : $data;

    }

endif;
