<?php

/**
 * Color validation and palette generation for the WPHAVE design system.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Determine whether a value is a three- or six-digit hexadecimal color.
 *
 * @param string $hex Color value including the leading hash.
 * @return bool Whether the value is a valid hexadecimal color.
 */

if ( ! function_exists( 'wphave_is_valid_hex' ) ) :

	function wphave_is_valid_hex( $hex ) {
        return preg_match('/^#([0-9A-F]{3}){1,2}$/i', $hex);
	}

endif;


/**
 * Generate stable physical and semantic color scales.
 *
 * @param string $color              Base hexadecimal color.
 * @param int    $steps              Number of colors per scale.
 * @param string $contrast_direction Auto, lighter or darker.
 * @return array Physical and semantic color scales.
 */

if ( ! function_exists( 'wphave_get_color_scales' ) ) :

    function wphave_get_color_scales( $color, $steps = 10, $contrast_direction = 'auto' ) {
        $physical_scales = wphave_get_physical_color_scales( $color, $steps );
        $lighter = $physical_scales['lighter'] ?? [];
        $darker = $physical_scales['darker'] ?? [];
        $resolved_direction = $contrast_direction;

        if( ! in_array( $resolved_direction, ['lighter', 'darker'], true ) && wphave_is_valid_hex( $color ) ) {
            $rgb = wphave_hex_to_rgb( $color );
            $channels = array_map(function( $channel ) {
                $channel = $channel / 255;
                return $channel <= 0.04045 ? $channel / 12.92 : pow( ($channel + 0.055) / 1.055, 2.4 );
            }, $rgb);
            $luminance = 0.2126 * $channels[0] + 0.7152 * $channels[1] + 0.0722 * $channels[2];
            $resolved_direction = $luminance > 0.179 ? 'darker' : 'lighter';
        }

        return [
            'lighter' => $lighter,
            'darker' => $darker,
            'contrast' => $resolved_direction === 'lighter' ? $lighter : $darker,
            'subtle' => $resolved_direction === 'lighter' ? $darker : $lighter,
            'contrastDirection' => $resolved_direction
        ];
    }

endif;


/**
 * Convert a hexadecimal color to RGB channels.
 *
 * @param string $hex Three- or six-digit hexadecimal color.
 * @return array RGB channel values.
 */

if ( ! function_exists( 'wphave_hex_to_rgb' ) ) :

	function wphave_hex_to_rgb( $hex ) {
        $hex = ltrim($hex, '#');

        if (strlen($hex) === 3) {
            $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
        }

        return [
            hexdec(substr($hex, 0, 2)),
            hexdec(substr($hex, 2, 2)),
            hexdec(substr($hex, 4, 2))
        ];
    }

endif;


/**
 * Convert RGB channels to a hexadecimal color.
 *
 * @param array $rgb RGB channel values.
 * @return string Six-digit hexadecimal color.
 */

if ( ! function_exists( 'wphave_rgb_to_hex' ) ) :

	function wphave_rgb_to_hex( $rgb ) {
        return sprintf("#%02x%02x%02x", $rgb[0], $rgb[1], $rgb[2]);
    }

endif;


/**
 * Blend two RGB colors by the given factor.
 *
 * @param array $color1 Starting RGB channels.
 * @param array $color2 Target RGB channels.
 * @param float $factor Blend factor between zero and one.
 * @return array Blended RGB channels.
 */

if ( ! function_exists( 'wphave_blend_colors' ) ) :

	function wphave_blend_colors( $color1, $color2, $factor ) {
        return [
            round($color1[0] + $factor * ($color2[0] - $color1[0])),
            round($color1[1] + $factor * ($color2[1] - $color1[1])),
            round($color1[2] + $factor * ($color2[2] - $color1[2]))
        ];
    }

endif;


/**
 * Generate stable physical scales from a base color.
 *
 * The JavaScript design utilities mirror this calculation so editor and PHP
 * output retain the same palette progression.
 *
 * @param string $color  Base hexadecimal color.
 * @param int    $steps  Number of colors to generate per physical scale.
 * @return array Generated lighter and darker scales.
 */

if ( ! function_exists( 'wphave_get_physical_color_scales' ) ) :

    function wphave_get_physical_color_scales( $color, $steps = 10 ) {
        if( ! wphave_is_valid_hex( $color ) ) {
            return [
                'lighter' => [],
                'darker' => []
            ];
        }

        try {
            $lighter = [];
            $darker = [];

            $rgb = wphave_hex_to_rgb( $color );
            $black = [0, 0, 0];
            $white = [255, 255, 255];

            for( $i = 1; $i <= $steps; $i++ ) {
                $maxFactor = 0.68; // Begrenzung auf 68% des gesamten Spektrums
                // Nicht-linearer Verlauf: sanfte Abstufung zu Beginn
                $factor = pow( $i / $steps, 1.20 ) * $maxFactor;

                $lighter[] = wphave_rgb_to_hex( wphave_blend_colors( $rgb, $white, $factor ) );
                $darker[] = wphave_rgb_to_hex( wphave_blend_colors( $rgb, $black, $factor ) );
            }

            return [
                'lighter' => $lighter,
                'darker' => $darker
            ];
        } catch (Exception $e) {
            return [
                'lighter' => [],
                'darker' => []
            ];
        }
    }

endif;
