<?php

/**
 * Return the built-in WPHAVE color palette.
 *
 * @return array Named color presets for design controls.
 */

if ( ! function_exists( 'wphave_color_collection' ) ) :

    function wphave_color_collection() {

        return array(
			array(
				'name' => __( 'Black', 'wphave' ),
				'slug' => 'black',
				'color' => '#000000',
			),
			array(
				'name' => __( 'Concrete', 'wphave' ),
				'slug' => 'concrete',
				'color' => '#c8cbd3',
			),
			array(
				'name' => __( 'Paper', 'wphave' ),
				'slug' => 'paper',
				'color' => '#f1f2f6',
			),
			array(
				'name' => __( 'Light Grey', 'wphave' ),
				'slug' => 'light-grey',
				'color' => '#f9f9f9',
			),
            array(
				'name' => __( 'White', 'wphave' ),
				'slug' => 'white',
				'color' => '#FFFFFF',
			),
			array(
				'name' => __( 'Pastel Red', 'wphave' ),
				'slug' => 'pastel-red',
				'color' => '#f17e7e',
			),
			array(
				'name' => __( 'Strawberry', 'wphave' ),
				'slug' => 'strawberry',
				'color' => '#dc6068',
			),
			array(
				'name' => __( 'Hibiscus', 'wphave' ),
				'slug' => 'hibiscus',
				'color' => '#dd685b',
			),
			array(
				'name' => __( 'Carrot', 'wphave' ),
				'slug' => 'carrot',
				'color' => '#e9845c',
			),
			array(
				'name' => __( 'Pumpkin', 'wphave' ),
				'slug' => 'pumpkin',
				'color' => '#f0b464',
			),
			array(
				'name' => __( 'Pastel Orange', 'wphave' ),
				'slug' => 'pastel-orange',
				'color' => '#ebce95',
			),
			array(
				'name' => __( 'Sunflower', 'wphave' ),
				'slug' => 'sunflower',
				'color' => '#f5cf69',
			),
			array(
				'name' => __( 'Pastel Yellow', 'wphave' ),
				'slug' => 'pastel-yellow',
				'color' => '#f6edcf',
			),
			array(
				'name' => __( 'Pastel Green', 'wphave' ),
				'slug' => 'pastel-green',
				'color' => '#dcedc1',
			),
			array(
				'name' => __( 'Avocado', 'wphave' ),
				'slug' => 'avocado',
				'color' => '#c5d377',
			),
			array(
				'name' => __( 'Grass', 'wphave' ),
				'slug' => 'grass',
				'color' => '#a5d276',
			),
			array(
				'name' => __( 'Emerald', 'wphave' ),
				'slug' => 'emerald',
				'color' => '#6cc878',
			),
			array(
				'name' => __( 'Light Mint', 'wphave' ),
				'slug' => 'light-mint',
				'color' => '#e4f2f0',
			),
			array(
				'name' => __( 'Pastel Mint', 'wphave' ),
				'slug' => 'pastel-mint',
				'color' => '#badfdb',
			),
			array(
				'name' => __( 'Mint', 'wphave' ),
				'slug' => 'mint',
				'color' => '#6fcbc0',
			),
			array(
				'name' => __( 'Light Blue', 'wphave' ),
				'slug' => 'light-blue',
				'color' => '#b0deff',
			),
			array(
				'name' => __( 'Pastel Blue', 'wphave' ),
				'slug' => 'pastel-blue',
				'color' => '#deecfc',
			),
			array(
				'name' => __( 'Swimming Pool', 'wphave' ),
				'slug' => 'swimming-pool',
				'color' => '#6ebfe3',
			),
			array(
				'name' => __( 'Blue Jeans', 'wphave' ),
				'slug' => 'blue-jeans',
				'color' => '#6b9ce7',
			),
			array(
				'name' => __( 'Pastel Purple', 'wphave' ),
				'slug' => 'pastel-purple',
				'color' => '#c6cfff',
			),
			array(
				'name' => __( 'Royal', 'wphave' ),
				'slug' => 'royal',
				'color' => '#9498e6',
			),
			array(
				'name' => __( 'Lavender', 'wphave' ),
				'slug' => 'lavender',
				'color' => '#a979d2',
			),
			array(
				'name' => __( 'Pastel Pink', 'wphave' ),
				'slug' => 'pastel-pink',
				'color' => '#ffe6eb',
			),
			array(
				'name' => __( 'Rose', 'wphave' ),
				'slug' => 'rose',
				'color' => '#df8cbc',
			),
			array(
				'name' => __( 'Beige', 'wphave' ),
				'slug' => 'beige',
				'color' => '#dfd3c3',
			),
			array(
				'name' => __( 'Light Brown', 'wphave' ),
				'slug' => 'light-brown',
				'color' => '#d5ab9c',
			),
			array(
				'name' => __( 'Brown', 'wphave' ),
				'slug' => 'brown',
				'color' => '#796465',
			),
			array(
				'name' => __( 'Transparent', 'wphave' ),
				'slug' => 'transparent',
				'color' => 'transparent',
			)
		);

    }

endif;


/**
 * Return the built-in single-layer gradient collection.
 *
 * @return array Named gradient presets for design controls.
 */

if ( ! function_exists( 'wphave_gradient_collection' ) ) :

    function wphave_gradient_collection() {

        return array(
            array(
                'slug' => 'wphave-warm-flame',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 0,
                    'position' => 'right',
                    'colorStops' => [[
                        'color' => 'rgba(255, 236, 210, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(252, 182, 159, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Warm Flame',
            ),
            array(
                'slug' => 'wphave-juicy-peach',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 45,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(255, 154, 158, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(250, 208, 196, 1)',
                        'position' => 99
                    ],[
                        'color' => 'rgba(250, 208, 196, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Juicy Peach',
            ),
            array(
                'slug' => 'wphave-night-fade',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 45,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(161, 140, 209, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(251, 194, 235, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Night Fade',
            ),
            array(
                'slug' => 'wphave-rainy-ashville',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 0,
                    'position' => 'top',
                    'colorStops' => [[
                        'color' => 'rgba(251, 194, 235, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(166, 193, 238, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Rainy Ashville',
            ),
            array(
                'slug' => 'wphave-winter-neva',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 120,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(161, 196, 253, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(194, 233, 251, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Winter Neva',
            ),
            array(
                'slug' => 'wphave-tempting-azure',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 120,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(132, 250, 176, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(143, 211, 244, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Tempting Azure',
            ),
            array(
                'slug' => 'wphave-heavy-rain',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 0,
                    'position' => 'top',
                    'colorStops' => [[
                        'color' => 'rgba(207, 217, 223, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(226, 235, 240, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Heavy Rain',
            ),
            array(
                'slug' => 'wphave-cloufy-knoxville',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 120,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(253, 251, 251, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(235, 237, 238, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Cloudy Knoxville',
            ),
            array(
                'slug' => 'wphave-wild-apple',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 0,
                    'position' => 'top',
                    'colorStops' => [[
                        'color' => 'rgba(210, 153, 194, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(254, 249, 215, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Wild Apple',
            ),
            array(
                'slug' => 'wphave-everlasting-sky',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 135,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(253, 252, 251, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(226, 209, 195, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Everlasting Sky',
            ),
            array(
                'slug' => 'wphave-clean-mirror',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 45,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(147, 165, 207, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(228, 239, 233, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Clean Mirror',
            ),
            array(
                'slug' => 'wphave-plum-plate',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 135,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(102, 126, 234, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(118, 75, 162, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Plum Plate',
            ),
            array(
                'slug' => 'wphave-dirty-beauty',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 0,
                    'position' => 'top',
                    'colorStops' => [[
                        'color' => 'rgba(106, 133, 182, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(186, 200, 224, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Dirty Beauty',
            ),
            array(
                'slug' => 'wphave-premium-dark',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 0,
                    'position' => 'right',
                    'colorStops' => [[
                        'color' => 'rgba(67, 67, 67, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(0, 0, 0, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Premium Dark',
            ),
            array(
                'slug' => 'wphave-eternal-constance',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 0,
                    'position' => 'top',
                    'colorStops' => [[
                        'color' => 'rgba(9, 32, 63, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(83, 120, 149, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Eternal Constance',
            ),
            array(
                'slug' => 'wphave-juicy-cake',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 0,
                    'position' => 'top',
                    'colorStops' => [[
                        'color' => 'rgba(225, 79, 173, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(249, 212, 35, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Juicy Cake',
            ),
            array(
                'slug' => 'wphave-black-sea',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 225,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(44, 216, 213, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(107, 141, 214, 1)',
                        'position' => 48
                    ],[
                        'color' => 'rgba(142, 55, 215, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Black Sea',
            ),
            array(
                'slug' => 'vivid-cyan-blue-to-vivid-purple',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 135,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(6, 147, 227, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(155, 81, 224, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Vivid cyan blue to vivid purple',
            ),
            array(
                'slug' => 'vivid-green-cyan-to-vivid-cyan-blue',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 135,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(0, 208, 132, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(6, 147, 227, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Vivid green cyan to vivid cyan blue',
            ),
            array(
                'slug' => 'light-green-cyan-to-vivid-green-cyan',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 135,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(122, 220, 180, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(0, 208, 130, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Light green cyan to vivid green cyan',
            ),
            array(
                'slug' => 'luminous-vivid-amber-to-luminous-vivid-orange',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 135,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(252, 185, 0, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(255, 105, 0, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Luminous vivid amber to luminous vivid orange',
            ),
            array(
                'slug' => 'luminous-vivid-orange-to-vivid-red',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 135,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(255, 105, 0, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(207, 46, 46, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Luminous vivid orange to vivid red',
            ),
            array(
                'slug' => 'insta',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 225,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(35, 21, 87, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(68, 16, 122, 1)',
                        'position' => 29
                    ],[
                        'color' => 'rgba(255, 19, 97, 1)',
                        'position' => 67
                    ],[
                        'color' => 'rgba(255, 248, 0, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Insta',
            ),
            array(
                'slug' => 'velvet-dusk',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 0,
                    'position' => 'top',
                    'colorStops' => [[
                        'color' => 'rgba(219, 220, 215, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(221, 220, 215, 1)',
                        'position' => 24
                    ],[
                        'color' => 'rgba(226, 201, 204, 1)',
                        'position' => 30
                    ],[
                        'color' => 'rgba(231, 98, 125, 1)',
                        'position' => 46
                    ],[
                        'color' => 'rgba(184, 35, 90, 1)',
                        'position' => 59
                    ],[
                        'color' => 'rgba(128, 19, 87, 1)',
                        'position' => 71
                    ],[
                        'color' => 'rgba(61, 22, 53, 1)',
                        'position' => 84
                    ],[
                        'color' => 'rgba(28, 26, 39, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Velvet Dusk',
            ),
            array(
                'slug' => 'celestial-dawn',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 0,
                    'position' => 'bottom',
                    'colorStops' => [[
                        'color' => 'rgba(13, 11, 28, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(21, 50, 92, 1)',
                        'position' => 14
                    ],[
                        'color' => 'rgba(79, 114, 182, 1)',
                        'position' => 25
                    ],[
                        'color' => 'rgba(223, 168, 189, 1)',
                        'position' => 39
                    ],[
                        'color' => 'rgba(249, 198, 184, 1)',
                        'position' => 48
                    ],[
                        'color' => 'rgba(242, 225, 232, 1)',
                        'position' => 61
                    ],[
                        'color' => 'rgba(219, 215, 251, 1)',
                        'position' => 67
                    ],[
                        'color' => 'rgba(163, 174, 237, 1)',
                        'position' => 77
                    ],[
                        'color' => 'rgba(179, 187, 250, 1)',
                        'position' => 90
                    ],[
                        'color' => 'rgba(62, 111, 216, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Celestial Dawn',
            ),
            array(
                'slug' => 'polar-split',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 45,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(20, 30, 49, 1)',
                        'position' => 50
                    ],[
                        'color' => 'rgba(35, 58, 84, 1)',
                        'position' => 50
                    ]]
                ],
                'name' => 'Polar Split',
            ),
            array(
                'slug' => 'color-circle',
                'gradient' => [
                    'type' => 'conic',
                    'angle' => 0,
                    'position' => 'center',
                    'colorStops' => [[
                        'color' => 'rgba(89, 191, 118, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(34, 113, 177, 1)',
                        'position' => 25
                    ],[
                        'color' => 'rgba(217, 121, 122, 1)',
                        'position' => 50
                    ],[
                        'color' => 'rgba(233, 212, 67, 1)',
                        'position' => 75
                    ],[
                        'color' => 'rgba(89, 191, 118, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Color Circle',
            ),
            array(
                'slug' => 'midnight-to-morning',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 0,
                    'position' => 'top',
                    'colorStops' => [[
                        'color' => 'rgba(59, 65, 197, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(169, 129, 187, 1)',
                        'position' => 49
                    ],[
                        'color' => 'rgba(255, 200, 169, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Midnight to Morning',
            ),
            array(
                'slug' => 'sunrise-symphony',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 0,
                    'position' => 'top',
                    'colorStops' => [[
                        'color' => 'rgba(63, 81, 177, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(90, 85, 174, 1)',
                        'position' => 13
                    ],[
                        'color' => 'rgba(123, 95, 172, 1)',
                        'position' => 25
                    ],[
                        'color' => 'rgba(143, 106, 174, 1)',
                        'position' => 38
                    ],[
                        'color' => 'rgba(168, 106, 164, 1)',
                        'position' => 50
                    ],[
                        'color' => 'rgba(204, 107, 142, 1)',
                        'position' => 62
                    ],[
                        'color' => 'rgba(241, 130, 113, 1)',
                        'position' => 75
                    ],[
                        'color' => 'rgba(243, 164, 105, 1)',
                        'position' => 87
                    ],[
                        'color' => 'rgba(247, 201, 120, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Sunrise Symphony',
            ),
            array(
                'slug' => 'velvet-eclipse',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 0,
                    'position' => 'top',
                    'colorStops' => [[
                        'color' => 'rgba(52, 36, 39, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(61, 30, 54, 1)',
                        'position' => 16
                    ],[
                        'color' => 'rgba(217, 28, 52, 1)',
                        'position' => 31
                    ],[
                        'color' => 'rgba(254, 125, 60, 1)',
                        'position' => 38
                    ],[
                        'color' => 'rgba(251, 122, 100, 1)',
                        'position' => 50
                    ],[
                        'color' => 'rgba(163, 52, 69, 1)',
                        'position' => 62
                    ],[
                        'color' => 'rgba(111, 46, 76, 1)',
                        'position' => 71
                    ],[
                        'color' => 'rgba(99, 34, 71, 1)',
                        'position' => 76
                    ],[
                        'color' => 'rgba(67, 29, 68, 1)',
                        'position' => 84
                    ],[
                        'color' => 'rgba(36, 33, 59, 1)',
                        'position' => 93
                    ]]
                ],
                'name' => 'Velvet Eclipse',
            ),
            array(
                'slug' => 'mystic-fade',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 0,
                    'position' => 'top',
                    'colorStops' => [[
                        'color' => 'rgba(243, 177, 103, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(236, 56, 188, 1)',
                        'position' => 33
                    ],[
                        'color' => 'rgba(115, 3, 192, 1)',
                        'position' => 66
                    ],[
                        'color' => 'rgba(3, 0, 30, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Mystic Fade',
            ),
            array(
                'slug' => 'blue-awakening',
                'gradient' => [
                    'type' => 'radial',
                    'position' => [
                        "x" => 52,
                        "y" => 129
                    ],
                    'radialSize' => [
                        'x' => 100,
                        'y' => 106,
                    ],
                    'radialShape' => 'size',
                    'colorStops' => [[
                        'color' => 'rgba(255, 255, 255, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(0, 3, 83, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Blue Awakening',
            ),
            array(
                'slug' => 'flarepoint',
                'gradient' => [
                    'type' => 'radial',
                    'position' => [
                        "x" => 30,
                        "y" => 110
                    ],
                    'radialShape' => 'circle',
                    'colorStops' => [[
                        'color' => 'rgba(255, 219, 139, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(238, 101, 61, 1)',
                        'position' => 25
                    ],[
                        'color' => 'rgba(212, 46, 129, 1)',
                        'position' => 50
                    ],[
                        'color' => 'rgba(162, 55, 182, 1)',
                        'position' => 75
                    ],[
                        'color' => 'rgba(62, 95, 188, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Flarepoint',
            ),
            array(
                'slug' => 'quantum-drift',
                'gradient' => [
                    'type' => 'radial',
                    'position' => [
                        "x" => 100,
                        "y" => 50
                    ],
                    'radialShape' => 'circle',
                    'colorStops' => [[
                        'color' => 'rgba(56, 189, 248, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(49, 46, 129, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Quantum Drift',
            ),
            array(
                'slug' => 'blush-noir',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 152,
                    'position' => 'top',
                    'colorStops' => [[
                        'color' => 'rgba(97, 20, 71, 1)',
                        'position' => 17
                    ],[
                        'color' => 'rgba(230, 106, 131, 1)',
                        'position' => 73
                    ]]
                ],
                'name' => 'Blush Noir',
            ),
            array(
                'slug' => 'dream-spill',
                'gradient' => [
                    'type' => 'radial',
                    'position' => [
                        "x" => 69,
                        "y" => -5
                    ],
                    'radialSize' => [
                        "x" => 90,
                        "y" => 90
                    ],
                    'radialShape' => 'size',
                    'colorStops' => [[
                        'color' => 'rgba(107, 208, 234, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(191, 221, 226, 1)',
                        'position' => 14
                    ],[
                        'color' => 'rgba(200, 216, 217, 1)',
                        'position' => 20
                    ],[
                        'color' => 'rgba(209, 203, 183, 1)',
                        'position' => 46
                    ],[
                        'color' => 'rgba(204, 185, 180, 1)',
                        'position' => 57
                    ],[
                        'color' => 'rgba(149, 109, 222, 1)',
                        'position' => 78
                    ],[
                        'color' => 'rgba(108, 80, 241, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Dream Spill',
            ),
            array(
                'slug' => 'galactic-bloom',
                'gradient' => [
                    'type' => 'radial',
                    'position' => [
                        "x" => 50,
                        "y" => 10
                    ],
                    'radialSize' => [
                        "x" => 140,
                        "y" => 107
                    ],
                    'radialShape' => 'size',
                    'colorStops' => [[
                        'color' => 'rgba(0, 3, 20, 1)',
                        'position' => 37
                    ],[
                        'color' => 'rgba(102, 51, 238, 1)',
                        'position' => 69
                    ],[
                        'color' => 'rgba(255, 255, 255, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Galactic Bloom',
            ),
            array(
                'slug' => 'dreamwave',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 43,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(65, 88, 208, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(200, 80, 192, 1)',
                        'position' => 46
                    ],[
                        'color' => 'rgba(255, 204, 112, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Dreamwave',
            ),
            array(
                'slug' => 'wphave-dusk',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 45,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(41, 51, 82, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(93, 93, 111, 1)',
                        'position' => 25
                    ],[
                        'color' => 'rgba(162, 123, 137, 1)',
                        'position' => 50
                    ],[
                        'color' => 'rgba(211, 162, 134, 1)',
                        'position' => 75
                    ],[
                        'color' => 'rgba(240, 216, 195, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Dusk',
            ),
            array(
                'slug' => 'wphave-cappuccino',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 45,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(75, 56, 50, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(133, 100, 91, 1)',
                        'position' => 25
                    ],[
                        'color' => 'rgba(198, 155, 123, 1)',
                        'position' => 50
                    ],[
                        'color' => 'rgba(242, 221, 199, 1)',
                        'position' => 75
                    ],[
                        'color' => 'rgba(245, 237, 229, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Cappuccino',
            ),
            array(
                'slug' => 'wphave-loyalty',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 45,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(15, 12, 156, 1)',
                        'position' => 33
                    ],[
                        'color' => 'rgba(241, 65, 250, 1)',
                        'position' => 66
                    ],[
                        'color' => 'rgba(255, 233, 166, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Loyalty',
            ),
            array(
                'slug' => 'wphave-material',
                'gradient' => [
                    'type' => 'linear',
                    'angle' => 45,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(216, 218, 191, 1)',
                        'position' => 33
                    ],[
                        'color' => 'rgba(170, 23, 241, 1)',
                        'position' => 66
                    ],[
                        'color' => 'rgba(58, 0, 145, 1)',
                        'position' => 100
                    ]]
                ],
                'name' => 'Material',
            ),
        );

    }

endif;


/**
 * Return the built-in multi-layer gradient collection.
 *
 * @return array Named multi-layer gradient presets for design controls.
 */

if ( ! function_exists( 'wphave_multi_gradient_collection' ) ) :

    function wphave_multi_gradient_collection() {

        return array(
            array(
                'name' => 'Warm Flame',
                'slug' => 'multi-1',
                'gradient' => [[
                    'type' => 'radial',
                    'angle' => 94,
                    'position' => [
                        "x" => 12,
                        "y" => -47
                    ],
                    'colorStops' => [[
                        'color' => 'var(--wphave-site-color-palette-mint)',
                        'position' => 40
                    ],[
                        'color' => 'rgba(209, 209, 209, 0)',
                        'position' => 61
                    ]],
                    "radialShape" => "circle"
                ],[
                    'type' => 'radial',
                    'angle' => 94,
                    'position' => [
                        "x" => -61,
                        "y" => 78
                    ],
                    'colorStops' => [[
                        'color' => 'var(--wphave-site-color-palette-pastel-mint)',
                        'position' => 25
                    ],[
                        'color' => 'rgba(209, 209, 209, 0)',
                        'position' => 72
                    ]],
                    "radialShape" => "ellipse"
                ],[
                    'type' => 'radial',
                    'angle' => 94,
                    'position' => [
                        "x" => 90,
                        "y" => -15
                    ],
                    'colorStops' => [[
                        'color' => 'var(--wphave-site-color-palette-pastel-blue)',
                        'position' => 40
                    ],[
                        'color' => 'rgba(209, 209, 209, 0)',
                        'position' => 61
                    ]],
                    "radialShape" => "circle"
                ],[
                    'type' => 'radial',
                    'angle' => 94,
                    'position' => [
                        "x" => 87,
                        "y" => 118
                    ],
                    'colorStops' => [[
                        'color' => 'rgba(97, 185, 214, 1)',
                        'position' => 40
                    ],[
                        'color' => 'rgba(209, 209, 209, 0)',
                        'position' => 61
                    ]],
                    "radialShape" => "ellipse"
                ]],
            ),
            array(
                'name' => 'Warm Flame 2',
                'slug' => 'multi-2',
                'gradient' => [[
                    'type' => 'linear',
                    'angle' => 90,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 10
                    ],[
                        'color' => 'rgba(0, 0, 0, 0.1)',
                        'position' => 10
                    ]]
                ],[
                    'type' => 'linear',
                    'angle' => 90,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 20
                    ],[
                        'color' => 'rgba(0, 0, 0, 0.1)',
                        'position' => 20
                    ]]
                ],[
                    'type' => 'linear',
                    'angle' => 90,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 30
                    ],[
                        'color' => 'rgba(0, 0, 0, 0.1)',
                        'position' => 30
                    ]]
                ],[
                    'type' => 'linear',
                    'angle' => 90,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 40
                    ],[
                        'color' => 'rgba(0, 0, 0, 0.1)',
                        'position' => 40
                    ]]
                ],[
                    'type' => 'linear',
                    'angle' => 90,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 50
                    ],[
                        'color' => 'rgba(0, 0, 0, 0.1)',
                        'position' => 50
                    ]]
                ],[
                    'type' => 'linear',
                    'angle' => 90,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 60
                    ],[
                        'color' => 'rgba(0, 0, 0, 0.1)',
                        'position' => 60
                    ]]
                ],[
                    'type' => 'linear',
                    'angle' => 90,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 70
                    ],[
                        'color' => 'rgba(0, 0, 0, 0.1)',
                        'position' => 70
                    ]]
                ],[
                    'type' => 'linear',
                    'angle' => 90,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 80
                    ],[
                        'color' => 'rgba(0, 0, 0, 0.1)',
                        'position' => 80
                    ]]
                ],[
                    'type' => 'linear',
                    'angle' => 90,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 90
                    ],[
                        'color' => 'rgba(0, 0, 0, 0.1)',
                        'position' => 90
                    ]]
                ],[
                    'type' => 'linear',
                    'angle' => 90,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 100
                    ],[
                        'color' => 'rgba(0, 0, 0, 0.1)',
                        'position' => 100
                    ]]
                ]],
            ),
            array(
                'name' => 'Warm Flame',
                'slug' => 'multi-3',
                'gradient' => [[
                    'type' => 'conic',
                    'angle' => 51,
                    'position' => 'bottom',
                    'colorStops' => [[
                        'color' => 'rgba(255, 236, 209, 0)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(252, 182, 159, 1)',
                        'position' => 100
                    ]]
                ],[
                    'type' => 'conic',
                    'angle' => 51,
                    'position' => 'left',
                    'colorStops' => [[
                        'color' => 'rgba(255, 236, 209, 0)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(252, 182, 159, 1)',
                        'position' => 100
                    ]]
                ]],
            ),
            array(
                'name' => 'Warm Flame',
                'slug' => 'multi-4',
                'gradient' => [[
                    'type' => 'radial',
                    'position' => [
                        'x' => 10,
                        'y' => 70,
                    ],
                    'colorStops' => [[
                        'color' => 'rgba(163, 155, 243, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 50
                    ]]
                ],[
                    'type' => 'radial',
                    'position' => [
                        'x' => 34,
                        'y' => 31,
                    ],
                    'colorStops' => [[
                        'color' => 'rgba(244, 148, 254, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 50
                    ]]
                ],[
                    'type' => 'radial',
                    'position' => [
                        'x' => 6,
                        'y' => 30,
                    ],
                    'colorStops' => [[
                        'color' => 'rgba(252, 227, 151, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 50
                    ]]
                ],[
                    'type' => 'radial',
                    'position' => [
                        'x' => 28,
                        'y' => 12,
                    ],
                    'colorStops' => [[
                        'color' => 'rgba(247, 140, 130, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 50
                    ]]
                ],[
                    'type' => 'radial',
                    'position' => [
                        'x' => 9,
                        'y' => 75,
                    ],
                    'colorStops' => [[
                        'color' => 'rgba(239, 78, 113, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 50
                    ]]
                ],[
                    'type' => 'radial',
                    'position' => [
                        'x' => 11,
                        'y' => 33,
                    ],
                    'colorStops' => [[
                        'color' => 'rgba(232, 140, 163, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 50
                    ]]
                ],[
                    'type' => 'linear',
                    'angle' => 90,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(158, 153, 255, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(158, 153, 255, 1)',
                        'position' => 100
                    ]]
                ]],
            ),
            array(
                'name' => 'Warm Flame',
                'slug' => 'multi-5',
                'gradient' => [[
                    'type' => 'radial',
                    'position' => [
                        'x' => 72,
                        'y' => 7,
                    ],
                    'colorStops' => [[
                        'color' => 'rgba(221, 34, 44, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 50
                    ]]
                ],[
                    'type' => 'radial',
                    'position' => [
                        'x' => 24,
                        'y' => 87,
                    ],
                    'colorStops' => [[
                        'color' => 'rgba(115, 91, 236, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 50
                    ]]
                ],[
                    'type' => 'radial',
                    'position' => [
                        'x' => 91,
                        'y' => 90,
                    ],
                    'colorStops' => [[
                        'color' => 'rgba(241, 65, 165, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 50
                    ]]
                ],[
                    'type' => 'radial',
                    'position' => [
                        'x' => 59,
                        'y' => 49,
                    ],
                    'colorStops' => [[
                        'color' => 'rgba(226, 166, 121, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 50
                    ]]
                ],[
                    'type' => 'radial',
                    'position' => [
                        'x' => 53,
                        'y' => 82,
                    ],
                    'colorStops' => [[
                        'color' => 'rgba(163, 190, 239, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 50
                    ]]
                ],[
                    'type' => 'radial',
                    'position' => [
                        'x' => 47,
                        'y' => 9,
                    ],
                    'colorStops' => [[
                        'color' => 'rgba(187, 113, 224, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 50
                    ]]
                ],[
                    'type' => 'radial',
                    'position' => [
                        'x' => 9,
                        'y' => 77,
                    ],
                    'colorStops' => [[
                        'color' => 'rgba(64, 195, 247, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 50
                    ]]
                ],[
                    'type' => 'linear',
                    'angle' => 90,
                    'position' => 'custom',
                    'colorStops' => [[
                        'color' => 'rgba(153, 197, 255, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(153, 197, 255, 1)',
                        'position' => 100
                    ]]
                ]]
            ),
            array(
                'name' => 'Warm Flame',
                'slug' => 'multi-6',
                'gradient' => [[
                    'type' => 'linear',
                    'angle' => 128,
                    'position' => [
                        'x' => 72,
                        'y' => 7,
                    ],
                    'colorStops' => [[
                        'color' => 'var(--wphave-site-color-background)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 74
                    ]]
                ],[
                    'type' => 'conic',
                    'angle' => 34,
                    'position' => [
                        'x' => 101,
                        'y' => -1,
                    ],
                    'colorStops' => [[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 6
                    ],[
                        'color' => 'var(--wphave-site-color-background)',
                        'position' => 82
                    ]]
                ],[
                    'type' => 'repeating-radial',
                    'position' => [
                        'x' => 4,
                        'y' => 3,
                    ],
                    'colorStops' => [[
                        'color' => 'var(--wphave-site-color-accent)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 10
                    ],[
                        'color' => 'var(--wphave-site-color-accent)',
                        'position' => 10
                    ],[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 20
                    ],[
                        'color' => 'var(--wphave-site-color-accent)',
                        'position' => 20
                    ],[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 30
                    ],[
                        'color' => 'var(--wphave-site-color-accent)',
                        'position' => 30
                    ],[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 40
                    ],[
                        'color' => 'var(--wphave-site-color-accent)',
                        'position' => 40
                    ],[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 50
                    ],[
                        'color' => 'var(--wphave-site-color-accent)',
                        'position' => 50
                    ],[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 60
                    ],[
                        'color' => 'var(--wphave-site-color-accent)',
                        'position' => 60
                    ],[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 70
                    ],[
                        'color' => 'var(--wphave-site-color-accent)',
                        'position' => 70
                    ],[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 80
                    ],[
                        'color' => 'var(--wphave-site-color-accent)',
                        'position' => 80
                    ],[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 90
                    ],[
                        'color' => 'var(--wphave-site-color-accent)',
                        'position' => 90
                    ],[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 100
                    ]],
                    'radialShape' => 'circle'
                ],[
                    'type' => 'linear',
                    'angle' => 46,
                    'position' => [
                        'x' => 59,
                        'y' => 49,
                    ],
                    'colorStops' => [[
                        'color' => 'var(--wphave-site-color-background)',
                        'position' => 17
                    ],[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 63
                    ]]
                ]]
            ),
            array(
                'name' => 'Warm Flame',
                'slug' => 'multi-6',
                'gradient' => [[
                    'type' => 'radial',
                    'position' => [
                        'x' => 43,
                        'y' => 102,
                    ],
                    'radialSize' => [
                        'x' => 57,
                        'y' => 58,
                    ],
                    'radialShape' => 'size',
                    'colorStops' => [[
                        'color' => 'rgba(255, 185, 162, 0.5)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(36, 31, 71, 0)',
                        'position' => 100
                    ]]
                ],[
                    'type' => 'radial',
                    'position' => [
                        'x' => 7,
                        'y' => 96,
                    ],
                    'radialSize' => [
                        'x' => 92,
                        'y' => 103,
                    ],
                    'radialShape' => 'size',
                    'colorStops' => [[
                        'color' => 'rgba(117, 116, 230, 0.9)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(36, 31, 71, 0)',
                        'position' => 100
                    ]]
                ]]
            ),
            array(
                'name' => 'Warm Flame',
                'slug' => 'multi-7',
                'gradient' => [[
                    'type' => 'linear',
                    'angle' => 123,
                    'position' => 'top',
                    'colorStops' => [[
                        'color' => 'rgba(235, 243, 208, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(235, 243, 208, 0)',
                        'position' => 18
                    ]]
                ],[
                    'type' => 'radial',
                    'position' => [
                        'x' => 44,
                        'y' => 87,
                    ],
                    'radialSize' => [
                        'x' => 30,
                        'y' => 71,
                    ],
                    'radialShape' => 'size',
                    'colorStops' => [[
                        'color' => 'rgba(220, 141, 220, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(220, 141, 220, 0)',
                        'position' => 100
                    ]]
                ],[
                    'type' => 'radial',
                    'position' => [
                        'x' => 36,
                        'y' => 100,
                    ],
                    'radialSize' => [
                        'x' => 34,
                        'y' => 54,
                    ],
                    'radialShape' => 'size',
                    'colorStops' => [[
                        'color' => 'rgba(220, 141, 220, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(220, 141, 220, 0)',
                        'position' => 100
                    ]]
                ],[
                    'type' => 'radial',
                    'position' => [
                        'x' => 46,
                        'y' => 45,
                    ],
                    'radialSize' => [
                        'x' => 34,
                        'y' => 50,
                    ],
                    'radialShape' => 'size',
                    'colorStops' => [[
                        'color' => 'rgba(203, 173, 235, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(194, 166, 241, 0)',
                        'position' => 100
                    ]]
                ],[
                    'type' => 'linear',
                    'angle' => 135,
                    'position' => 'top',
                    'colorStops' => [[
                        'color' => 'rgba(205, 249, 232, 1)',
                        'position' => 21
                    ],[
                        'color' => 'rgba(205, 249, 232, 0)',
                        'position' => 48
                    ]]
                ],[
                    'type' => 'linear',
                    'angle' => 216,
                    'position' => 'top',
                    'colorStops' => [[
                        'color' => 'rgba(192, 169, 240, 0)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(192, 169, 240, 1)',
                        'position' => 1
                    ],[
                        'color' => 'rgba(192, 169, 240, 0)',
                        'position' => 16
                    ]]
                ],[
                    'type' => 'linear',
                    'angle' => 129,
                    'position' => 'top',
                    'colorStops' => [[
                        'color' => 'rgba(192, 169, 240, 0)',
                        'position' => 28
                    ],[
                        'color' => 'rgba(192, 169, 240, 1)',
                        'position' => 39
                    ],[
                        'color' => 'rgba(192, 169, 240, 0)',
                        'position' => 50
                    ]]
                ],[
                    'type' => 'radial',
                    'position' => [
                        'x' => 91,
                        'y' => 40,
                    ],
                    'radialSize' => [
                        'x' => 41,
                        'y' => 97,
                    ],
                    'radialShape' => 'size',
                    'colorStops' => [[
                        'color' => 'rgba(255, 253, 177, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(254, 228, 191, 1)',
                        'position' => 35
                    ],[
                        'color' => 'rgba(240, 189, 208, 1)',
                        'position' => 70
                    ],[
                        'color' => 'rgba(255, 129, 38, 0)',
                        'position' => 100
                    ]]
                ]]
            ),
            array(
                'name' => 'Warm Flame',
                'slug' => 'multi-8',
                'gradient' => [[
                    'type' => 'radial',
                    'position' => [
                        'x' => 27,
                        'y' => 78,
                    ],
                    'radialSize' => [
                        'x' => 54,
                        'y' => 62,
                    ],
                    'radialShape' => 'size',
                    'colorStops' => [[
                        'color' => 'rgba(0, 0, 0, 0.2)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 100
                    ]]
                ],[
                    'type' => 'radial',
                    'position' => [
                        'x' => 87,
                        'y' => 64,
                    ],
                    'radialSize' => [
                        'x' => 32,
                        'y' => 32,
                    ],
                    'radialShape' => 'size',
                    'colorStops' => [[
                        'color' => 'rgba(255, 255, 255, 0.2)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(255, 255, 255, 0)',
                        'position' => 100
                    ]]
                ],[
                    'type' => 'radial',
                    'position' => [
                        'x' => 61,
                        'y' => 20,
                    ],
                    'radialSize' => [
                        'x' => 45,
                        'y' => 45,
                    ],
                    'radialShape' => 'size',
                    'colorStops' => [[
                        'color' => 'rgba(0, 14, 116, 0.5)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 100
                    ]]
                ],[
                    'type' => 'linear',
                    'angle' => 54,
                    'position' => 'top',
                    'colorStops' => [[
                        'color' => 'rgba(255, 255, 255, 0.2)',
                        'position' => 29
                    ],[
                        'color' => 'rgba(0, 0, 0, 0)',
                        'position' => 64
                    ]]
                ],[
                    'type' => 'linear',
                    'angle' => 231,
                    'position' => 'top',
                    'colorStops' => [[
                        'color' => 'rgba(1, 1, 3, 1)',
                        'position' => 15
                    ],[
                        'color' => 'rgba(0, 16, 125, 1)',
                        'position' => 34
                    ],[
                        'color' => 'rgba(49, 116, 177, 1)',
                        'position' => 47
                    ],[
                        'color' => 'rgba(170, 178, 188, 1)',
                        'position' => 64
                    ],[
                        'color' => 'rgba(190, 179, 189, 1)',
                        'position' => 73
                    ],[
                        'color' => 'rgba(187, 173, 184, 1)',
                        'position' => 90
                    ]]
                ]]
            ),
            array(
                'name' => 'Warm Flame',
                'slug' => 'multi-9',
                'gradient' => [[
                    'type' => 'linear',
                    'angle' => 90,
                    'position' => 'top',
                    'colorStops' => [[
                        'color' => 'rgba(0, 0, 0, 0.5)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(49, 96, 174, 0.5)',
                        'position' => 30
                    ],[
                        'color' => 'rgba(67, 117, 191, 0.5)',
                        'position' => 44
                    ],[
                        'color' => 'rgba(81, 132, 208, 0.5)',
                        'position' => 60
                    ],[
                        'color' => 'rgba(94, 146, 215, 0.5)',
                        'position' => 100
                    ]]
                ],[
                    'type' => 'linear',
                    'angle' => 0,
                    'position' => 'top',
                    'colorStops' => [[
                        'color' => 'rgba(37, 85, 155, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(21, 69, 139, 1)',
                        'position' => 13
                    ],[
                        'color' => 'rgba(40, 93, 189, 1)',
                        'position' => 33
                    ],[
                        'color' => 'rgba(65, 117, 207, 1)',
                        'position' => 46
                    ],[
                        'color' => 'rgba(78, 132, 207, 1)',
                        'position' => 55
                    ],[
                        'color' => 'rgba(113, 167, 228, 1)',
                        'position' => 68
                    ],[
                        'color' => 'rgba(123, 175, 230, 1)',
                        'position' => 83
                    ],[
                        'color' => 'rgba(97, 150, 212, 1)',
                        'position' => 93
                    ],[
                        'color' => 'rgba(83, 136, 202, 1)',
                        'position' => 100
                    ]]
                ]]
            ),
            array(
                'name' => 'Warm Flame',
                'slug' => 'multi-10',
                'gradient' => [[
                    'type' => 'radial',
                    'position' => [
                        'x' => 55,
                        'y' => 0,
                    ],
                    'radialSize' => [
                        'x' => 100,
                        'y' => 100,
                    ],
                    'radialShape' => 'size',
                    'colorStops' => [[
                        'color' => 'rgba(255, 255, 255, 0.2)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(255, 255, 255, 0)',
                        'position' => 100
                    ]]
                ],[
                    'type' => 'linear',
                    'angle' => 119,
                    'position' => 'top',
                    'colorStops' => [[
                        'color' => 'rgba(231, 163, 117, 1)',
                        'position' => 1
                    ],[
                        'color' => 'rgba(250, 67, 87, 1)',
                        'position' => 20
                    ],[
                        'color' => 'rgba(243, 47, 109, 1)',
                        'position' => 30
                    ],[
                        'color' => 'rgba(60, 98, 178, 1)',
                        'position' => 46
                    ],[
                        'color' => 'rgba(23, 206, 211, 1)',
                        'position' => 64
                    ],[
                        'color' => 'rgba(84, 238, 205, 1)',
                        'position' => 76
                    ],[
                        'color' => 'rgba(170, 240, 178, 1)',
                        'position' => 94
                    ],[
                        'color' => 'rgba(231, 225, 163, 1)',
                        'position' => 100
                    ]]
                ]]
            ),
            array(
                'name' => 'Warm Flame',
                'slug' => 'multi-11',
                'gradient' => [[
                    'type' => 'radial',
                    'position' => [
                        'x' => 8,
                        'y' => 128,
                    ],
                    'radialSize' => [
                        'x' => 93,
                        'y' => 93,
                    ],
                    'radialShape' => 'size',
                    'colorStops' => [[
                        'color' => 'rgba(255, 238, 194, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(255, 238, 194, 0.2)',
                        'position' => 60
                    ],[
                        'color' => 'rgba(194, 233, 255, 0)',
                        'position' => 100
                    ]]
                ],[
                    'type' => 'radial',
                    'position' => [
                        'x' => 27,
                        'y' => -14,
                    ],
                    'radialSize' => [
                        'x' => 49,
                        'y' => 88,
                    ],
                    'radialShape' => 'size',
                    'colorStops' => [[
                        'color' => 'rgba(93, 227, 236, 0.7)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(93, 227, 236, 0.2)',
                        'position' => 60
                    ],[
                        'color' => 'rgba(93, 227, 236, 0)',
                        'position' => 100
                    ]]
                ],[
                    'type' => 'radial',
                    'position' => [
                        'x' => 90,
                        'y' => 89,
                    ],
                    'radialSize' => [
                        'x' => 115,
                        'y' => 156,
                    ],
                    'radialShape' => 'size',
                    'colorStops' => [[
                        'color' => 'rgba(75, 254, 222, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(75, 254, 222, 0)',
                        'position' => 100
                    ]]
                ],[
                    'type' => 'linear',
                    'angle' => 234,
                    'position' => 'top',
                    'colorStops' => [[
                        'color' => 'rgba(69, 74, 187, 1)',
                        'position' => 25
                    ],[
                        'color' => 'rgba(69, 74, 187, 0.8)',
                        'position' => 35
                    ],[
                        'color' => 'rgba(69, 74, 187, 0.4)',
                        'position' => 50
                    ],[
                        'color' => 'rgba(91, 196, 229, 0)',
                        'position' => 84
                    ]]
                ],[
                    'type' => 'radial',
                    'position' => [
                        'x' => 3,
                        'y' => 26,
                    ],
                    'radialSize' => [
                        'x' => 119,
                        'y' => 119,
                    ],
                    'radialShape' => 'size',
                    'colorStops' => [[
                        'color' => 'rgba(48, 142, 230, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(48, 158, 230, 0)',
                        'position' => 74
                    ]]
                ],[
                    'type' => 'linear',
                    'angle' => 359,
                    'position' => 'top',
                    'colorStops' => [[
                        'color' => 'rgba(242, 245, 250, 1)',
                        'position' => 0
                    ],[
                        'color' => 'rgba(242, 245, 250, 1)',
                        'position' => 100
                    ]]
                ]]
            ),
            array(
                'name' => 'Warm Flame',
                'slug' => 'multi-12',
                'gradient' => array(
                    array(
                        'type' => 'linear',
                        'angle' => 0,
                        'position' => 'left',
                        'colorStops' => array(
                            array(
                                'color' => '#200bc4',
                                'position' => 3
                            ),
                            array(
                                'color' => 'rgba(255, 255, 255, 0)',
                                'position' => 27
                            )
                        )
                    ),
                    array(
                        'type' => 'repeating-radial',
                        'position' => array(
                            'x' => 50,
                            'y' => 108
                        ),
                        'colorStops' => array(
                            array(
                                'color' => 'rgba(0, 0, 0, 0)',
                                'position' => 18
                            ),
                            array(
                                'color' => 'rgba(69, 93, 250, 0.11)',
                                'position' => 31
                            ),
                            array(
                                'color' => 'rgba(0, 0, 0, 0)',
                                'position' => 61
                            )
                        ),
                        'radialShape' => 'size',
                        'radialSize' => array(
                            'x' => 0,
                            'y' => 96
                        )
                    ),
                    array(
                        'type' => 'radial',
                        'position' => array(
                            'x' => 50,
                            'y' => 107
                        ),
                        'colorStops' => array(
                            array(
                                'color' => '#2009b4',
                                'position' => 31
                            ),
                            array(
                                'color' => '#f09aff',
                                'position' => 61
                            ),
                            array(
                                'color' => 'rgba(0, 0, 0, 0)',
                                'position' => 61
                            )
                        ),
                        'radialShape' => 'size',
                        'radialSize' => array(
                            'x' => 50,
                            'y' => 96
                        )
                    ),
                    array(
                        'type' => 'linear',
                        'angle' => 0,
                        'position' => 'left',
                        'colorStops' => array(
                            array(
                                'color' => '#200bc3',
                                'position' => -2
                            ),
                            array(
                                'color' => '#0a0618',
                                'position' => 100
                            )
                        )
                    )
                )
            ),
            array(
                'name' => 'Warm Flame',
                'slug' => 'multi-13',
                'gradient' => array(
                    array(
                        'type' => 'linear',
                        'angle' => 8,
                        'position' => 'left',
                        'colorStops' => array(
                            array(
                                'color' => '#0e0937',
                                'position' => 2
                            ),
                            array(
                                'color' => 'rgba(255, 255, 255, 0)',
                                'position' => 41
                            )
                        )
                    ),
                    array(
                        'type' => 'repeating-radial',
                        'position' => array(
                            'x' => 50,
                            'y' => 108
                        ),
                        'colorStops' => array(
                            array(
                                'color' => 'rgba(0, 0, 0, 0)',
                                'position' => 18
                            ),
                            array(
                                'color' => 'rgba(69, 93, 250, 0.11)',
                                'position' => 31
                            ),
                            array(
                                'color' => 'rgba(0, 0, 0, 0)',
                                'position' => 61
                            )
                        ),
                        'radialShape' => 'size',
                        'radialSize' => array(
                            'x' => 0,
                            'y' => 96
                        )
                    ),
                    array(
                        'type' => 'radial',
                        'position' => array(
                            'x' => 4,
                            'y' => 105
                        ),
                        'colorStops' => array(
                            array(
                                'color' => '#0d0928',
                                'position' => 21
                            ),
                            array(
                                'color' => '#231781',
                                'position' => 61
                            ),
                            array(
                                'color' => 'rgba(0, 0, 0, 0)',
                                'position' => 61
                            )
                        ),
                        'radialShape' => 'size',
                        'radialSize' => array(
                            'x' => 50,
                            'y' => 96
                        )
                    ),
                    array(
                        'type' => 'radial',
                        'position' => array(
                            'x' => 4,
                            'y' => 105
                        ),
                        'colorStops' => array(
                            array(
                                'color' => '#0d0928',
                                'position' => 21
                            ),
                            array(
                                'color' => '#42388e',
                                'position' => 61
                            ),
                            array(
                                'color' => 'rgba(0, 0, 0, 0)',
                                'position' => 61
                            )
                        ),
                        'radialShape' => 'size',
                        'radialSize' => array(
                            'x' => 52,
                            'y' => 96
                        )
                    ),
                    array(
                        'type' => 'radial',
                        'position' => array(
                            'x' => 4,
                            'y' => 105
                        ),
                        'colorStops' => array(
                            array(
                                'color' => '#5951a4',
                                'position' => 23
                            ),
                            array(
                                'color' => 'rgba(0, 0, 0, 0)',
                                'position' => 77
                            )
                        ),
                        'radialShape' => 'size',
                        'radialSize' => array(
                            'x' => 84,
                            'y' => 93
                        )
                    ),
                    array(
                        'type' => 'radial',
                        'position' => array(
                            'x' => 96,
                            'y' => -16
                        ),
                        'colorStops' => array(
                            array(
                                'color' => '#190a87',
                                'position' => -22
                            ),
                            array(
                                'color' => '#100a44',
                                'position' => 61
                            ),
                            array(
                                'color' => 'rgba(0, 0, 0, 0)',
                                'position' => 61
                            )
                        ),
                        'radialShape' => 'size',
                        'radialSize' => array(
                            'x' => 51,
                            'y' => 96
                        )
                    ),
                    array(
                        'type' => 'radial',
                        'position' => array(
                            'x' => 96,
                            'y' => -16
                        ),
                        'colorStops' => array(
                            array(
                                'color' => '#45399e',
                                'position' => -22
                            ),
                            array(
                                'color' => '#2d2181',
                                'position' => 61
                            ),
                            array(
                                'color' => 'rgba(0, 0, 0, 0)',
                                'position' => 61
                            )
                        ),
                        'radialShape' => 'size',
                        'radialSize' => array(
                            'x' => 53,
                            'y' => 96
                        )
                    ),
                    array(
                        'type' => 'radial',
                        'position' => array(
                            'x' => 96,
                            'y' => -16
                        ),
                        'colorStops' => array(
                            array(
                                'color' => '#41378d',
                                'position' => 26
                            ),
                            array(
                                'color' => 'rgba(0, 0, 0, 0)',
                                'position' => 118
                            )
                        ),
                        'radialShape' => 'size',
                        'radialSize' => array(
                            'x' => 60,
                            'y' => 63
                        )
                    ),
                    array(
                        'type' => 'linear',
                        'angle' => 0,
                        'position' => 'left',
                        'colorStops' => array(
                            array(
                                'color' => '#200bc3',
                                'position' => -2
                            ),
                            array(
                                'color' => '#0a0618',
                                'position' => 100
                            )
                        )
                    )
                )
            ),
            array(
                'name' => 'Warm Flame',
                'slug' => 'multi-14',
                'gradient' => array(
                    array(
                        'type' => 'radial',
                        'radialShape' => 'size',
                        'radialSize' => [
                            'x' => 29,
                            'y' => 45
                        ],
                        'position' => [
                            'x' => 66,
                            'y' => 8
                        ],
                        'colorStops' => array(
                            array(
                                'color' => '#152f84',
                                'position' => 31
                            ),
                            array(
                                'color' => 'var(--wphave-site-color-palette-transparent)',
                                'position' => 133
                            )
                        )
                    ),
                    array(
                        'type' => 'radial',
                        'radialShape' => 'size',
                        'radialSize' => [
                            'x' => 25,
                            'y' => 41
                        ],
                        'position' => [
                            'x' => 54,
                            'y' => 86
                        ],
                        'colorStops' => array(
                            array(
                                'color' => '#152f84',
                                'position' => 31
                            ),
                            array(
                                'color' => 'var(--wphave-site-color-palette-transparent)',
                                'position' => 133
                            )
                        )
                    ),
                    array(
                        'type' => 'linear',
                        'angle' => 47,
                        'position' => [
                            'x' => 50,
                            'y' => 50
                        ],
                        'colorStops' => array(
                            array(
                                'color' => 'var(--wphave-site-color-palette-transparent)',
                                'position' => 52
                            ),
                            array(
                                'color' => 'rgba(32, 73, 197, 1)',
                                'position' => 72
                            ),
                            array(
                                'color' => 'var(--wphave-site-color-palette-transparent)',
                                'position' => 72
                            )
                        )
                    ),
                    array(
                        'type' => 'linear',
                        'angle' => 47,
                        'position' => [
                            'x' => 50,
                            'y' => 50
                        ],
                        'colorStops' => array(
                            array(
                                'color' => 'var(--wphave-site-color-palette-transparent)',
                                'position' => 35
                            ),
                            array(
                                'color' => 'rgba(32, 73, 197, 1)',
                                'position' => 44
                            ),
                            array(
                                'color' => 'var(--wphave-site-color-palette-transparent)',
                                'position' => 44
                            )
                        )
                    ),
                    array(
                        'type' => 'radial',
                        'radialShape' => 'size',
                        'radialSize' => [
                            'x' => 42,
                            'y' => 70
                        ],
                        'position' => [
                            'x' => 26,
                            'y' => 82
                        ],
                        'colorStops' => array(
                            array(
                                'color' => '#152f84',
                                'position' => 0
                            ),
                            array(
                                'color' => 'var(--wphave-site-color-palette-transparent)',
                                'position' => 100
                            )
                        )
                    ),
                    array(
                        'type' => 'radial',
                        'radialShape' => 'size',
                        'radialSize' => [
                            'x' => 29,
                            'y' => 45
                        ],
                        'position' => [
                            'x' => 68,
                            'y' => 18
                        ],
                        'colorStops' => array(
                            array(
                                'color' => '#152f84',
                                'position' => 0
                            ),
                            array(
                                'color' => 'var(--wphave-site-color-palette-transparent)',
                                'position' => 100
                            )
                        )
                    ),
                    array(
                        'type' => 'linear',
                        'angle' => 47,
                        'position' => [
                            'x' => 50,
                            'y' => 50
                        ],
                        'colorStops' => array(
                            array(
                                'color' => 'var(--wphave-site-color-palette-transparent)',
                                'position' => 49
                            ),
                            array(
                                'color' => 'rgba(32, 73, 197, 1)',
                                'position' => 74
                            ),
                            array(
                                'color' => 'var(--wphave-site-color-palette-transparent)',
                                'position' => 93
                            )
                        )
                    ),
                    array(
                        'type' => 'linear',
                        'angle' => 47,
                        'position' => [
                            'x' => 50,
                            'y' => 50
                        ],
                        'colorStops' => array(
                            array(
                                'color' => 'var(--wphave-site-color-palette-transparent)',
                                'position' => -4
                            ),
                            array(
                                'color' => 'rgba(32, 73, 197, 1)',
                                'position' => 30
                            ),
                            array(
                                'color' => 'var(--wphave-site-color-palette-transparent)',
                                'position' => 73
                            )
                        )
                    ),
                    array(
                        'type' => 'linear',
                        'angle' => 0,
                        'position' => 'left',
                        'colorStops' => array(
                            array(
                                'color' => '#011255',
                                'position' => 0
                            ),
                            array(
                                'color' => '#0e277a',
                                'position' => 100
                            )
                        )
                    ),
                )
            ),

        );

    }

endif;
