<?php

/**
 * This function allows you to output a specific CSS photo filters by passing the style.
 */

if ( ! function_exists( 'wphave_photo_filter' ) ) :

    function wphave_photo_filter( $args = array() ) {

		$output = $args['output'] ?? '';
		$style = $args['style'] ?? 'xpro2';



		static $cache = array();

		$cache_key = md5( implode( '', $args ) );
		$memoized_value = wphave_request_memoization_read( $cache, $cache_key, array('output' => $output) );

		if( $memoized_value ) {
			// Reuse memoized value for this request
			return $memoized_value;
		}



		$filters = array();

		$filters['xpro2'] = array(
			'--phfi-fi' => 'contrast(100%) brightness(100%) saturate(100%) sepia(30%)',
			'--phfi-bg' => 'rgba(62, 162, 253, 0.5)',
			'--phfi-mbm' => 'color-burn',
		);

		$filters['valencia'] = array(
			'--phfi-fi' => 'contrast(108%) brightness(108%) saturate(100%) sepia(8%)',
			'--phfi-bg' => 'rgb(58 3 26 / 50%)',
			'--phfi-mbm' => 'exclusion',
		);

		$filters['walden'] = array(
			'--phfi-fi' => 'contrast(140%) brightness(75%) sepia(10%)',
			'--phfi-bg' => 'rgba(204, 68, 0, 0.5)',
			'--phfi-mbm' => 'lighten',
		);

		$filters['toaster'] = array(
			'--phfi-fi' => 'contrast(110%) brightness(110%) saturate(130%)',
			'--phfi-bg' => 'rgb(15, 78, 128)',
			'--phfi-mbm' => 'screen',
		);

		$filters['stinson'] = array(
			'--phfi-fi' => 'contrast(75%) brightness(115%) saturate(85%)',
			'--phfi-bg' => 'rgba(240, 149, 128, 0.2)',
			'--phfi-mbm' => 'soft-light',
		);

		$filters['reyes'] = array(
			'--phfi-fi' => 'contrast(85%) brightness(110%) saturate(75%) sepia(22%)',
			'--phfi-bg' => 'rgba(173, 205, 239, 1)',
			'--phfi-mbm' => 'soft-light',
		);

		$filters['perpetue'] = array(
			'--phfi-bg' => 'linear-gradient(to bottom, rgba(0, 91, 154, 1) 1%, rgba(61, 193, 230, 0)) 100%',
			'--phfi-mbm' => 'soft-light',
		);

		$filters['maven'] = array(
			'--phfi-fi' => 'contrast(90%) sepia(20%)',
			'--phfi-bg' => 'radial-gradient(50% 50%, circle closest-corner, rgba(208, 186, 142, 1) 20, rgba(29, 2, 16, 0.2))',
			'--phfi-mbm' => 'overlay',
		);

		$filters['lofi'] = array(
			'--phfi-fi' => 'contrast(150%) saturate(110%)',
			'--phfi-bg' => 'radial-gradient(50% 50%, circle closest-corner, rgba(0, 0, 0, 0) 70, rgba(34, 34, 34, 1))',
			'--phfi-mbm' => 'multiply',
		);

		$filters['hudson'] = array(
			'--phfi-fi' => 'sepia(.25) contrast(1.2) brightness(1.2) saturate(1.05) hue-rotate(-15deg)',
			'--phfi-bg' => 'radial-gradient(50% 50%, circle closest-corner, transparent 25%, rgba(25,62,167,.25) 100%)',
			'--phfi-mbm' => 'multiply',
		);

		$filters['gingham'] = array(
			'--phfi-fi' => 'brightness(105%) hue-rotate(350deg)',
			'--phfi-bg' => 'rgba(66, 10, 14, 0.2)',
			'--phfi-mbm' => 'color',
		);

		$filters['clarendon'] = array(
			'--phfi-fi' => 'contrast(120%) saturate(125%)',
			'--phfi-bg' => 'rgba(127, 187, 227, 0.2)',
			'--phfi-mbm' => 'overlay',
		);

		$filters['brooklyn'] = array(
			'--phfi-fi' => 'contrast(90%) brightness(110%)',
			'--phfi-bg' => 'rgba(127, 187, 227, 0.2)',
			'--phfi-mbm' => 'overlay',
		);

		$filters['brannan'] = array(
			'--phfi-fi' => 'contrast(140%) sepia(50%)',
			'--phfi-bg' => 'rgba(161, 44, 199, 0.31)',
			'--phfi-mbm' => 'lighten',
		);

		$filters['amaro'] = array(
			'--phfi-fi' => 'contrast(90%) brightness(110%) saturate(150%) hue-rotate(-10deg)',
			'--phfi-bg' => 'rgba(0, 0, 0, 0)',
		);

		$filters['aden'] = array(
			'--phfi-fi' => 'contrast(90%) brightness(120%) saturate(85%) hue-rotate(20deg)',
			'--phfi-bg' => 'linear-gradient(to right, rgba(66, 10, 14, 0.2) 1%, rgba(66, 10, 14, 0)) 100%',
			'--phfi-mbm' => 'darken',
		);

		$filters['1977'] = array(
			'--phfi-fi' => 'contrast(110%) brightness(110%) saturate(130%)',
			'--phfi-bg' => 'rgba(243, 106, 188, 0.3)',
			'--phfi-mbm' => 'screen',
		);

        $filters['kelvin'] = array(
			'--phfi-fi' => 'sepia(.15) contrast(1.5) brightness(1.1) hue-rotate(-10deg)',
			'--phfi-bg' => 'radial-gradient(50% 50%, circle closest-corner, rgba(128, 78, 15, .25) 0, rgba(128, 78, 15, .5) 100%)',
			'--phfi-mbm' => 'overlay',
		);

        $filters['ludwig'] = array(
			'--phfi-fi' => 'sepia(.25) contrast(1.05) brightness(1.05) saturate(2)',
			'--phfi-bg' => 'rgba(125, 105, 24, .1)',
			'--phfi-mbm' => 'overlay',
		);

        $filters['mayfair'] = array(
			'--phfi-fi' => 'contrast(1.1) brightness(1.15) saturate(1.1)',
			'--phfi-bg' => 'radial-gradient(50% 50%, circle closest-corner, transparent 0, rgba(175, 105, 24, .4) 100%)',
			'--phfi-mbm' => 'multiply',
		);

        $filters['rise'] = array(
			'--phfi-fi' => 'sepia(.25) contrast(1.25) brightness(1.2) saturate(.9)',
			'--phfi-bg' => 'radial-gradient(50% 50%, circle closest-corner, transparent 0, rgba(230, 193, 61, .25) 100%)',
			'--phfi-mbm' => 'lighten',
		);

        $filters['sierra'] = array(
			'--phfi-fi' => 'sepia(.25) contrast(1.5) brightness(.9) hue-rotate(-15deg)',
			'--phfi-bg' => 'radial-gradient(50% 50%, circle closest-corner, rgba(128, 78, 15, .5) 0, rgba(0, 0, 0, .65) 100%)',
			'--phfi-mbm' => 'screen',
		);

		$filters['inkwell'] = array(
			'--phfi-fi' => 'contrast(110%) brightness(110%) saturate(100%) grayscale(100%)',
			'--phfi-bg' => 'rgba(0, 0, 0, 0)',
		);

        $filters['moon'] = array(
			'--phfi-fi' => 'grayscale(1) contrast(1.1) brightness(1.1)',
			'--phfi-bg' => '#383838',
			'--phfi-mbm' => 'lighten',
		);

        $filters['leaden'] = array(
			'--phfi-fi' => 'contrast(1.8) brightness(1.1) grayscale(1)',
			'--phfi-bg' => '#ffffff',
			'--phfi-mbm' => 'soft-light',
		);

        $filters['vintage'] = array(
			'--phfi-fi' => 'contrast(2.6) brightness(0.8) grayscale(1) sepia(0.29)',
			'--phfi-bg' => 'rgb(211 157 27 / 30%)',
			'--phfi-mbm' => 'luminosity',
		);



		if( $output === 'all' ) {
			return $filters;
		}

		$data = $filters[$style] ?? '';



		$cache[ $cache_key ] = $data;

		return $data;

    }

endif;
