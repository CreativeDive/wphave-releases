<?php

/**
 * This function allows you to output a specific overlay style by passing the type.
 */

if ( ! function_exists( 'wphave_overlay' ) ) :

    function wphave_overlay( $args = array() ) {

		$output = $args['output'] ?? '';
		$type = $args['type'] ?? 'cover';

        $gradients = array(
            'left-right' => 'linear-gradient(to right, var(--ov-co) var(--ov-ax), transparent 100%)',
            'right-left' => 'linear-gradient(to left, var(--ov-co) var(--ov-ax), transparent 100%)',
            'top-bottom' => 'linear-gradient(to bottom, var(--ov-co) var(--ov-ax), transparent 100%)',
            'bottom-top' => 'linear-gradient(to top, var(--ov-co) var(--ov-ax), transparent 100%)',

            'top-right-diagonal' => 'linear-gradient(to top right, var(--ov-co) var(--ov-ax), transparent 100%)',
            'top-left-diagonal' => 'linear-gradient(to top left, var(--ov-co) var(--ov-ax), transparent 100%)',
            'bottom-right-diagonal' => 'linear-gradient(to bottom right, var(--ov-co) var(--ov-ax), transparent 100%)',
            'bottom-left-diagonal' => 'linear-gradient(to bottom left, var(--ov-co) var(--ov-ax), transparent 100%)',

            'vertical-center' => 'linear-gradient(to top, var(--ov-co) calc(var(--ov-ax) / 3), transparent 50%), linear-gradient(to bottom, var(--ov-co) calc(var(--ov-ax) / 3), transparent 50%)',
            'horizontal-center' => 'linear-gradient(to right, var(--ov-co) calc(var(--ov-ax) / 3), transparent 50%), linear-gradient(to left, var(--ov-co) calc(var(--ov-ax) / 3), transparent 50%)',
            'radial-closest-side' => 'radial-gradient(circle closest-side, transparent 0%, var(--ov-co) calc(100% - var(--ov-ax)))',
            'radial-closest-corner' => 'radial-gradient(circle closest-corner, transparent 0%, var(--ov-co) calc(100% - var(--ov-ax)))',
            'ellipse-closest-side' => 'radial-gradient(ellipse closest-side, transparent 0%, var(--ov-co) calc(100% - var(--ov-ax)))',
            'ellipse-closest-corner' => 'radial-gradient(ellipse closest-corner, transparent 0%, var(--ov-co) calc(100% - var(--ov-ax)))',

            'cover' => 'var(--ov-co)',
        );

		if( $output === 'all' ) {
			return $gradients;
		}

		$data = $gradients[$type] ?? '';

		return $data;

    }

endif;
