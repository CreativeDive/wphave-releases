<?php

/** Additional CSS artwork. IDs are permanent; labels never enter compiled CSS. */
function wphave_additional_css_patterns($base_patterns) {
	return [
		19 => [
			'label' => __('Herringbone', 'wphave'),
			'styles' => array_replace($base_patterns[14], [
				'--cssp-siz' => 'calc(var(--cssp-si) * 2) var(--cssp-si)',
				'--cssp-img' => str_replace(
					'var(--cssp-co) -6.25%',
					'var(--cssp-co-55) -6.25%',
					$base_patterns[14]['--cssp-img'],
				),
			]),
		],
		20 => [
			'label' => __('Basket weave', 'wphave'),
			'styles' => [
				'--cssp-rpt' => 'repeat',
				'--cssp-siz' => 'var(--cssp-si) var(--cssp-si)',
				'--cssp-pos' => '0 0',
				'--cssp-img' =>
					'conic-gradient(var(--cssp-co) 25%, transparent 0 50%, var(--cssp-co-55) 0 75%, transparent 0)',
			],
		],
		21 => [
			'label' => __('Brick bond', 'wphave'),
			'styles' => [
				'--cssp-rpt' => 'repeat',
				'--cssp-siz' =>
					'var(--cssp-si) calc(var(--cssp-si) / 2), var(--cssp-si) var(--cssp-si), var(--cssp-si) var(--cssp-si)',
				'--cssp-pos' => '0 0, 0 0, calc(var(--cssp-si) / 2) 0',
				'--cssp-img' =>
					'linear-gradient(var(--cssp-co) var(--cssp-sw), transparent 0), conic-gradient(at var(--cssp-sw) 50%, transparent 0 75%, var(--cssp-co) 0), conic-gradient(at var(--cssp-sw) 50%, transparent 0 50%, var(--cssp-co) 0 75%, transparent 0)',
			],
		],
		22 => [
			'label' => __('Elongated diamond grid', 'wphave'),
			'styles' => [
				'--cssp-rpt' => 'repeat',
				'--cssp-siz' => 'var(--cssp-si) calc(var(--cssp-si) * 1.732)',
				'--cssp-pos' => '0 0',
				'--cssp-img' =>
					'linear-gradient(60deg, transparent calc(50% - var(--cssp-sw)), var(--cssp-co) 0 50%, transparent 0), linear-gradient(-60deg, transparent calc(50% - var(--cssp-sw)), var(--cssp-co) 0 50%, transparent 0)',
			],
		],
		23 => [
			'label' => __('Scales', 'wphave'),
			'styles' => [
				'--cssp-rpt' => 'repeat',
				'--cssp-siz' => 'var(--cssp-si) var(--cssp-si)',
				'--cssp-pos' => '0 0, calc(var(--cssp-si) / 2) calc(var(--cssp-si) / 2)',
				'--cssp-img' =>
					'radial-gradient(ellipse at 50% 0, transparent 65%, var(--cssp-co) 66% 70%, transparent 71%), radial-gradient(ellipse at 50% 0, transparent 65%, var(--cssp-co-55) 66% 70%, transparent 71%)',
			],
		],
		24 => [
			'label' => __('Wave lines', 'wphave'),
			'styles' => [
				'--cssp-rpt' => 'repeat',
				'--cssp-siz' => 'var(--cssp-si) calc(var(--cssp-si) / 2)',
				'--cssp-pos' => '0 0, calc(var(--cssp-si) / 2) calc(var(--cssp-si) / 2)',
				'--cssp-img' =>
					'radial-gradient(ellipse at 50% 100%, transparent 62%, var(--cssp-co) 63% 68%, transparent 69%), radial-gradient(ellipse at 50% 0, transparent 62%, var(--cssp-co) 63% 68%, transparent 69%)',
			],
		],
		25 => [
			'label' => __('Capsule grid', 'wphave'),
			'styles' => [
				'--cssp-rpt' => 'repeat',
				'--cssp-siz' => 'var(--cssp-si) calc(var(--cssp-si) / 2)',
				'--cssp-pos' => '0 0',
				'--cssp-img' =>
					'radial-gradient(ellipse at center, var(--cssp-co) 48%, transparent 50%)',
			],
		],
		26 => [
			'label' => __('Confetti', 'wphave'),
			'styles' => [
				'--cssp-rpt' => 'repeat',
				'--cssp-siz' => 'calc(var(--cssp-si) * 2) calc(var(--cssp-si) * 2)',
				'--cssp-pos' => '0 0',
				'--cssp-img' =>
					'radial-gradient(circle at 20% 25%, var(--cssp-co) 0 7%, transparent 8%), radial-gradient(ellipse at 75% 20%, var(--cssp-co-55) 0 9%, transparent 10%), radial-gradient(ellipse at 65% 75%, var(--cssp-co) 0 8%, transparent 9%), radial-gradient(circle at 15% 85%, var(--cssp-co-55) 0 4%, transparent 5%)',
			],
		],
		27 => [
			'label' => __('Cross stitch', 'wphave'),
			'styles' => [
				'--cssp-rpt' => 'space',
				'--cssp-siz' => 'var(--cssp-si) var(--cssp-si)',
				'--cssp-pos' => '0 0',
				'--cssp-img' =>
					'radial-gradient(ellipse 8% 30% at center, var(--cssp-co) 90%, transparent 100%), radial-gradient(ellipse 30% 8% at center, var(--cssp-co) 90%, transparent 100%)',
			],
		],
		28 => [
			'label' => __('Star points', 'wphave'),
			'styles' => [
				'--cssp-rpt' => 'repeat',
				'--cssp-siz' => 'var(--cssp-si) var(--cssp-si)',
				'--cssp-pos' => '0 0',
				'--cssp-img' =>
					'radial-gradient(ellipse 7% 38% at center, var(--cssp-co) 75%, transparent 85%), radial-gradient(ellipse 38% 7% at center, var(--cssp-co) 75%, transparent 85%)',
			],
		],
		29 => [
			'label' => __('Perforated metal', 'wphave'),
			'styles' => [
				'--cssp-rpt' => 'repeat',
				'--cssp-siz' => 'var(--cssp-si) var(--cssp-si)',
				'--cssp-pos' => '0 0',
				'--cssp-img' =>
					'radial-gradient(circle, transparent calc(var(--cssp-do-si) - var(--cssp-sw)), var(--cssp-co) 0 var(--cssp-do-si), transparent calc(var(--cssp-do-si) + 0.5px)), radial-gradient(circle at 52% 54%, transparent calc(var(--cssp-do-si) - var(--cssp-sw)), var(--cssp-co-55) 0 var(--cssp-do-si), transparent calc(var(--cssp-do-si) + 1px))',
			],
		],
		30 => [
			'label' => __('Pearl chains', 'wphave'),
			'styles' => [
				'--cssp-rpt' => 'repeat',
				'--cssp-siz' => 'calc(var(--cssp-si) / 2) var(--cssp-si)',
				'--cssp-pos' => '0 0',
				'--cssp-img' =>
					'radial-gradient(circle, var(--cssp-co) 0 var(--cssp-do-si), transparent calc(var(--cssp-do-si) + 0.5px))',
			],
		],
		31 => [
			'label' => __('Woven fabric', 'wphave'),
			'styles' => [
				'--cssp-rpt' => 'repeat',
				'--cssp-siz' => 'var(--cssp-si) var(--cssp-si)',
				'--cssp-pos' => '0 0',
				'--cssp-img' =>
					'repeating-linear-gradient(0deg, var(--cssp-co-55) 0 var(--cssp-sw), transparent 0 calc(var(--cssp-sw) * 3)), repeating-linear-gradient(90deg, var(--cssp-co) 0 var(--cssp-sw), transparent 0 calc(var(--cssp-sw) * 4))',
			],
		],
		32 => [
			'label' => __('Waffle grid', 'wphave'),
			'styles' => [
				'--cssp-rpt' => 'repeat',
				'--cssp-siz' => 'var(--cssp-si) var(--cssp-si)',
				'--cssp-pos' => '0 0',
				'--cssp-img' =>
					'linear-gradient(var(--cssp-co) 0 8%, var(--cssp-co-55) 8% 16%, transparent 0 84%, var(--cssp-co-55) 0 92%, var(--cssp-co) 0), linear-gradient(90deg, var(--cssp-co) 0 8%, var(--cssp-co-55) 8% 16%, transparent 0 84%, var(--cssp-co-55) 0 92%, var(--cssp-co) 0)',
			],
		],
		33 => [
			'label' => __('Staggered arches', 'wphave'),
			'styles' => [
				'--cssp-rpt' => 'repeat',
				'--cssp-siz' => 'var(--cssp-si) calc(var(--cssp-si) / 2)',
				'--cssp-pos' => '0 0',
				'--cssp-img' =>
					'radial-gradient(ellipse at 50% 100%, transparent 45%, var(--cssp-co) 46% 54%, transparent 55%)',
			],
		],
		34 => [
			'label' => __('Double stripes', 'wphave'),
			'styles' => [
				'--cssp-rpt' => 'repeat',
				'--cssp-siz' => 'var(--cssp-si) var(--cssp-si)',
				'--cssp-pos' => '0 0',
				'--cssp-img' =>
					'linear-gradient(90deg, var(--cssp-co) 0 8%, transparent 0 18%, var(--cssp-co) 0 26%, transparent 0)',
			],
		],
		35 => [
			'label' => __('Diamond dots', 'wphave'),
			'styles' => [
				'--cssp-rpt' => 'space',
				'--cssp-siz' => 'var(--cssp-si) var(--cssp-si)',
				'--cssp-pos' => '0 0',
				'--cssp-img' =>
					'linear-gradient(45deg, var(--cssp-co) 10%, transparent 0 90%, var(--cssp-co) 0), linear-gradient(-45deg, var(--cssp-co) 10%, transparent 0 90%, var(--cssp-co) 0)',
			],
		],
		36 => [
			'label' => __('Fan tiles', 'wphave'),
			'styles' => [
				'--cssp-rpt' => 'repeat',
				'--cssp-siz' => 'var(--cssp-si) var(--cssp-si)',
				'--cssp-pos' => '0 0',
				'--cssp-img' =>
					'repeating-conic-gradient(from -90deg at 50% 100%, var(--cssp-co) 0 15deg, transparent 15deg 30deg)',
			],
		],
		37 => [
			'label' => __('Shaded cubes', 'wphave'),
			'styles' => array_replace($base_patterns[18], [
				'--cssp-img' =>
					$base_patterns[18]['--cssp-img'] .
					', linear-gradient(color-mix(in srgb, var(--cssp-co) 20%, transparent), color-mix(in srgb, var(--cssp-co) 20%, transparent))',
			]),
		],
		38 => [
			'label' => __('Broken grid', 'wphave'),
			'styles' => [
				'--cssp-rpt' => 'repeat',
				'--cssp-siz' => 'var(--cssp-si) var(--cssp-si)',
				'--cssp-pos' => '0 0',
				'--cssp-img' =>
					'conic-gradient(at 60% var(--cssp-sw), transparent 0 75%, var(--cssp-co) 0), conic-gradient(at var(--cssp-sw) 60%, transparent 0 75%, var(--cssp-co) 0)',
			],
		],
	];
}
