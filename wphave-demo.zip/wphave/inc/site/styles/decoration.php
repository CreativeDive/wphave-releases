<?php
/** Shared Decoration rendering contract; mirrored by general/js/decoration/model.js. */
function wphave_decoration_dimension($value, $fallback, $units, $min, $max) {
	if (
		!is_string($value) ||
		!preg_match('/^(-?(?:\d+(?:\.\d+)?|\.\d+))(px|rem|vw|%|deg)$/', trim($value), $match)
	) {
		return $fallback;
	}
	$number = (float) $match[1];
	if (
		!in_array($match[2], $units, true) ||
		!is_finite($number) ||
		$number < $min ||
		$number > $max
	) {
		return $fallback;
	}
	return (string) ($number == 0 ? 0 : $number) . $match[2];
}

function wphave_decoration_styles($value) {
	$data = is_array($value) ? $value : [];
	$opacity = $data['opacity'] ?? null;
	$opacity =
		(is_int($opacity) || is_float($opacity)) && is_finite((float) $opacity)
			? max(0, min(1, $opacity))
			: 1;
	$colors = isset($data['colors']) && is_array($data['colors']) ? $data['colors'] : [];
	$position = isset($data['position']) && is_array($data['position']) ? $data['position'] : [];
	$color = $colors['deco'] ?? null;
	return [
		'--deco-si' => wphave_decoration_dimension($data['size'] ?? null, '50%', ['%'], 0, 150),
		'--deco-bl' => wphave_decoration_dimension(
			$data['blur'] ?? null,
			'0px',
			['px', 'rem', 'vw'],
			0,
			100,
		),
		'--deco-co' => is_string($color) && trim($color) !== '' ? $color : '#000',
		'--deco-op' => $opacity,
		'--deco-ro' => wphave_decoration_dimension(
			$data['rotate'] ?? null,
			'0deg',
			['deg'],
			-36000,
			36000,
		),
		'--deco-po-x' => wphave_decoration_dimension(
			$position['x'] ?? null,
			'50%',
			['%'],
			-150,
			150,
		),
		'--deco-po-y' => wphave_decoration_dimension(
			$position['y'] ?? null,
			'50%',
			['%'],
			-150,
			150,
		),
	];
}
