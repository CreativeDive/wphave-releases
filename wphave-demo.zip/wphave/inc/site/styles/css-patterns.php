<?php

/**
 * This function allows you to output a specific CSS pattern by passing the style.
 */

if (!function_exists('wphave_css_pattern')):
	function wphave_css_pattern($args = []) {
		$output = isset($args['output']) ? $args['output'] : '';
		$style = isset($args['style']) && $args['style'] ? $args['style'] : '0';

		if (!is_string($style) && !is_int($style)) {
			return null;
		}

		static $cache = [];

		$cache_key = md5(wp_json_encode($args));
		$memoized_value = wphave_request_memoization_read($cache, $cache_key, [
			'output' => $output,
		]);

		if ($memoized_value) {
			// Reuse memoized value for this request
			return $memoized_value;
		}

		$pattern = [];

		$pattern[0] = [
			'--cssp-img' => '
                repeating-linear-gradient(
                    45deg,
                    var(--cssp-co), var(--cssp-co) var(--cssp-sw), transparent var(--cssp-sw), transparent var(--cssp-si)
                )
            ',
		];

		$pattern[1] = [
			'--cssp-img' => '
                repeating-linear-gradient(
                    -45deg,
                    var(--cssp-co), var(--cssp-co) var(--cssp-sw), transparent var(--cssp-sw), transparent var(--cssp-si)
                )
            ',
		];

		$pattern[2] = [
			'--cssp-img' => '
                repeating-linear-gradient(
                    45deg,
                    var(--cssp-co), var(--cssp-co) var(--cssp-sw), transparent var(--cssp-sw), transparent var(--cssp-si)
                ), repeating-linear-gradient(
                    -45deg,
                    var(--cssp-co), var(--cssp-co) var(--cssp-sw), transparent var(--cssp-sw), transparent var(--cssp-si)
                )
            ',
		];

		$pattern[3] = [
			'--cssp-siz' => 'var(--cssp-si) 100%',
			'--cssp-img' => '
                linear-gradient(
                    to right,
                    var(--cssp-co), var(--cssp-co) var(--cssp-sw), transparent var(--cssp-sw), transparent
                )
            ',
		];

		$pattern[4] = [
			'--cssp-siz' => '100% var(--cssp-si)',
			'--cssp-img' => '
                linear-gradient(
                    to top,
                    var(--cssp-co), var(--cssp-co) var(--cssp-sw), transparent var(--cssp-sw), transparent
                )
            ',
		];

		$pattern[5] = [
			'--cssp-siz' => 'var(--cssp-si) var(--cssp-si)',
			'--cssp-pos' => 'calc( -1 * var(--cssp-sw) ) calc( -1 * var(--cssp-sw) )',
			'--cssp-img' => '
                linear-gradient(
                    var(--cssp-co) var(--cssp-sw), transparent var(--cssp-sw)
                ), linear-gradient(
                    to right,
                    var(--cssp-co) var(--cssp-sw), transparent var(--cssp-sw)
                )
            ',
		];

		$pattern[6] = [
			'--cssp-siz' =>
				'var(--cssp-si) var(--cssp-si), var(--cssp-si) var(--cssp-si), 4px 4px, 4px 4px',
			'--cssp-pos' => '-0.8px -0.8px, -0.8px -0.8px, -0.4px -0.4px, -0.4px -0.4px',
			'--cssp-img' => '
                linear-gradient(
                    var(--cssp-co) 0.8px, transparent 0.8px
                ), linear-gradient(
                    90deg,
                    var(--cssp-co) 0.8px, transparent 0.8px
                ), linear-gradient(
                    var(--cssp-co) 0.4px, transparent 0.4px
                ), linear-gradient(
                    90deg, var(--cssp-co) 0.4px, transparent 0.4px
                )
            ',
		];

		$pattern[7] = [
			'--cssp-siz' =>
				'calc( var(--cssp-si-wu) * var(--cssp-do-si) ) calc( var(--cssp-si-wu) * var(--cssp-do-si) )',
			'--cssp-pos' =>
				'0 0, calc( calc(var(--cssp-si-wu) / 2) * var(--cssp-do-si) ) calc( calc(var(--cssp-si-wu) / 2) * var(--cssp-do-si) )',
			'--cssp-img' => '
                radial-gradient(
                    var(--cssp-co) var(--cssp-do-si), transparent var(--cssp-do-si)
                ), radial-gradient(
                    var(--cssp-co) var(--cssp-do-si), transparent var(--cssp-do-si)
                )
            ',
		];

		$pattern[8] = [
			'--cssp-siz' =>
				'calc( var(--cssp-si-wu) * var(--cssp-do-si) ) calc( var(--cssp-si-wu) * var(--cssp-do-si) )',
			'--cssp-img' => '
                radial-gradient(
                    var(--cssp-co) var(--cssp-do-si), transparent var(--cssp-do-si)
                )
            ',
		];

		$pattern[9] = [
			'--cssp-siz' => 'var(--cssp-si) var(--cssp-si)',
			'--cssp-img' => '
                linear-gradient(
                    0deg,
                    transparent 50%, var(--cssp-co) 50%
                )
            ',
		];

		$pattern[10] = [
			'--cssp-rpt' => 'repeat',
			'--cssp-siz' => 'calc( 2 * var(--cssp-si) ) calc( 2 * var(--cssp-si) )',
			'--cssp-pos' => '0 0, var(--cssp-si) var(--cssp-si)',
			'--cssp-img' => '
                repeating-linear-gradient(
                    45deg,
                    var(--cssp-co) 25%, transparent 25%, transparent 75%, var(--cssp-co) 75%, var(--cssp-co)
                ), repeating-linear-gradient(
                    45deg,
                    var(--cssp-co) 25%, transparent 25%, transparent 75%, var(--cssp-co) 75%, var(--cssp-co)
                )
            ',
		];

		$pattern[11] = [
			'--cssp-rpt' => 'repeat',
			'--cssp-siz' => 'var(--cssp-si) var(--cssp-si)',
			'--cssp-pos' => 'var(--cssp-si) 0, var(--cssp-si) 0, 0 0, 0 0',
			'--cssp-img' => '
                linear-gradient(
                    135deg,
                    var(--cssp-co) 25%, transparent 25%
                ), linear-gradient(
                    225deg,
                    var(--cssp-co) 25%, transparent 25%
                ), linear-gradient(
                    45deg,
                    var(--cssp-co) 25%, transparent 25%
                ), linear-gradient(
                    315deg,
                    var(--cssp-co) 25%, transparent 25%
                )
            ',
		];

		$pattern[12] = [
			'--cssp-rpt' => 'repeat',
			'--cssp-siz' => 'calc(var(--cssp-si) * 2) calc(var(--cssp-si) * 2)',
			'--cssp-pos' => 'var(--cssp-si) 0, var(--cssp-si) 0, 0 0, 0 0',
			'--cssp-img' => '
                linear-gradient(
                    135deg,
                    var(--cssp-co) 25%, transparent 25%
                ), linear-gradient(
                    225deg,
                    var(--cssp-co) 25%, transparent 25%
                ), linear-gradient(
                    45deg,
                    var(--cssp-co) 25%, transparent 25%
                ), linear-gradient(
                    315deg,
                    var(--cssp-co) 25%, transparent 25%
                )
            ',
		];

		$pattern[13] = [
			'--cssp-rpt' => 'repeat',
			'--cssp-pos' =>
				'calc(-1 * var(--cssp-si)) 0, calc(-1 * var(--cssp-si)) 0, 0px 0, 0px 0',
			'--cssp-siz' =>
				'calc(var(--cssp-si) * 2) calc(var(--cssp-si) * 2), calc(var(--cssp-si) * 2) calc(var(--cssp-si) * 2), calc(var(--cssp-si) * 2) calc(var(--cssp-si) * 2), calc(var(--cssp-si) * 2) calc(var(--cssp-si) * 2)',
			'--cssp-img' => '
                linear-gradient(
                    135deg,
                    var(--cssp-co-55) 25%, transparent 25%
                ), linear-gradient(
                    225deg,
                    var(--cssp-co) 25%, transparent 25%
                ), linear-gradient(
                    315deg,
                    var(--cssp-co-55) 25%, transparent 25%
                ), linear-gradient(
                    45deg,
                    var(--cssp-co) 25%, transparent 25%
                )
            ',
		];

		$pattern[14] = [
			'--cssp-siz' => 'var(--cssp-si) var(--cssp-si)',
			'--cssp-img' => '
                linear-gradient(
                    135deg,
                    #0000 18.75%, var(--cssp-co) 0 31.25%, #0000 0
                ), repeating-linear-gradient(
                    45deg,
                    var(--cssp-co) -6.25% 6.25%, transparent 0 18.75%
                )
            ',
		];

		$pattern[15] = [
			'--cssp-rpt' => 'repeat',
			'--cssp-siz' => 'calc(2* var(--cssp-si)) calc(1* var(--cssp-si))',
			'--cssp-pos' => 'top left, calc(5* var(--cssp-si)) calc(3* var(--cssp-si)), top left',
			'--cssp-img' => '
                radial-gradient(
                    30% 50% at 30% 100%,
                    #0000 66%, var(--cssp-co) 67% 98%, #0000
                ), radial-gradient(
                    30% 50% at 30% 100%,
                    #0000 66%, var(--cssp-co) 67% 98%, #0000
                ), repeating-linear-gradient(
                    90deg,
                    var(--cssp-co) 0 10%, transparent 0 50%
                )
            ',
		];

		$pattern[16] = [
			'--cssp-rpt' => 'repeat',
			'--cssp-pos' => 'var(--cssp-si) var(--cssp-si), var(--cssp-si) var(--cssp-si), 0% 0%',
			'--cssp-siz' => 'calc( var(--cssp-si) * 2 ) calc( var(--cssp-si) * 2 )',
			'--cssp-img' => '
                radial-gradient(
                    100% 100% at 100% 100%,
                    #0000 46%, var(--cssp-co) 47% 53%, #0000 54%
                ), radial-gradient(
                    100% 100% at 0 0,
                    #0000 46%, var(--cssp-co) 47% 53%, #0000 54%
                ), radial-gradient(
                    100% 100%,
                    #0000 22%, var(--cssp-co) 23% 29%, #0000 30% 34%, var(--cssp-co) 35% 41%, #0000 42%
                )
            ',
		];

		$pattern[17] = [
			'--cssp-img' => '
                radial-gradient(
                    circle at center center,
                    var(--cssp-co), transparent
                ), repeating-radial-gradient(
                    circle at center center,
                    var(--cssp-co), var(--cssp-co), var(--cssp-si), transparent calc(var(--cssp-si) * 2), transparent var(--cssp-si)
                )
            ',
		];

		$pattern[18] = [
			'--cssp-rpt' => 'repeat',
			'--cssp-size-a' => 'var(--cssp-si)',
			'--cssp-size-b' => 'calc(var(--cssp-size-a) * (14 / 8))',
			'--cssp-size-a-half' => 'calc(var(--cssp-size-a) / 2)',
			'--cssp-size-b-half' => 'calc(var(--cssp-size-b) / 2)',
			'--cssp-siz' => 'var(--cssp-size-a) var(--cssp-size-b)',
			'--cssp-pos' =>
				'0 0, 0 0, var(--cssp-size-a-half) var(--cssp-size-b-half), var(--cssp-size-a-half) var(--cssp-size-b-half), 0 0, var(--cssp-size-a-half) var(--cssp-size-b-half)',
			'--cssp-img' => '
                linear-gradient(
                    30deg,
                    var(--cssp-co) 12%, transparent 12.5%, transparent 87%, var(--cssp-co) 87.5%, var(--cssp-co)
                ), linear-gradient(
                    150deg,
                    var(--cssp-co) 12%, transparent 12.5%, transparent 87%, var(--cssp-co) 87.5%, var(--cssp-co)
                ), linear-gradient(
                    30deg,
                    var(--cssp-co) 12%, transparent 12.5%, transparent 87%, var(--cssp-co) 87.5%, var(--cssp-co)
                ), linear-gradient(
                    150deg,
                    var(--cssp-co) 12%, transparent 12.5%, transparent 87%, var(--cssp-co) 87.5%, var(--cssp-co)
                ), linear-gradient(
                    60deg,
                    var(--cssp-co-55) 25%, transparent 25.5%, transparent 75%, var(--cssp-co-55) 75%, var(--cssp-co-55)
                ), linear-gradient(
                    60deg,
                    var(--cssp-co-55) 25%, transparent 25.5%, transparent 75%, var(--cssp-co-55) 75%, var(--cssp-co-55)
                )
            ',
		];

		require_once __DIR__ . '/css-pattern-presets.php';
		$labels = [];
		foreach (wphave_additional_css_patterns($pattern) as $id => $preset) {
			$pattern[$id] = $preset['styles'];
			$labels[$id] = $preset['label'];
		}

		if ($output === 'labels') {
			return $labels;
		}

		if ($output === 'all') {
			return $pattern;
		}

		$data = isset($pattern[$style]) ? $pattern[$style] : '';

		$cache[$cache_key] = $data;

		return $data;
	}
endif;
