<?php

/**
 * Add the passed state to each button selector.
 */

if ( ! function_exists( 'wphave_button_selectors' ) ) :

	function wphave_button_selectors( $selectors, $state = '' ) {

		$selectors_new = array();

		foreach( $selectors as $selector ) {
			$selectors_new[] = ( $selector . $state );
		}

		return implode(',', $selectors_new);

	}

endif;


/**
 * Selection of different button hover styles.
 */

if ( ! function_exists( 'wphave_button_style' ) ) :

    function wphave_button_style( $args = '' ) {

		$output = isset( $args['output'] ) ? $args['output'] : '';
		$type = isset( $args['type'] ) && $args['type'] ? $args['type'] : '';
		$style = isset( $args['style'] ) && $args['style'] ? $args['style'] : '0';
		$selector_custom = isset( $args['selector'] ) ? $args['selector'] : '';

		// Get all button selectors
		$selectors = array(
			$type ? '.btn.' . $type : '.btn',
			$type ? '.button.' . $type : '.button',
			//'input[type=submit]',
			//'.wp-block-button__link',
			//'.wp-block-file__button',
			//'.wp-block-search__button',
			//'.search-form input[type=submit]',
			//'.woocommerce-product-search input[type=submit]',
		);

        $selectors = $selector_custom ? array( $selector_custom ) : $selectors;



		static $cache = array();

		$cache_key = md5( $style . implode( '', $selectors ) );
		$memoized_value = wphave_request_memoization_read( $cache, $cache_key, array('output' => $output) );

		if( $memoized_value ) {
			// Reuse memoized value for this request
			return $memoized_value;
		}



        $button_color = wphave_data_get( 'site_globals', 'buttons.primary.colors.background' );
        $button_color_lighten_25 = $button_color/*wphave_hex_brightness( $button_color, 0.25 )*/;
        $button_color_darken_35 = $button_color/*wphave_hex_brightness( $button_color, -0.35 )*/;

        $button_color_hover = wphave_data_get( 'site_globals', 'buttons.primary.colors.backgroundHover' );
        $button_color_hover_lighten_25 = $button_color_hover/*wphave_hex_brightness( $button_color_hover, 0.25 )*/;
        $button_color_hover_darken_35 = $button_color_hover/*wphave_hex_brightness( $button_color_hover, -0.35 )*/;



        $selector = wphave_button_selectors( $selectors );
        $selector_hover = wphave_button_selectors( $selectors, ':hover' );
        $selector_before = wphave_button_selectors( $selectors, ':before' );
        $selector_hover_before = wphave_button_selectors( $selectors, ':hover:before' );
        $selector_after = wphave_button_selectors( $selectors, ':after' );
        $selector_hover_after = wphave_button_selectors( $selectors, ':hover:after' );
        $selector_active = wphave_button_selectors( $selectors, ':active' );

		$styles = array();



		$css = array();

            // Default
            $css[$selector]['border'] = '0!important';
            $css[$selector]['border-radius'] = '4px!important';
            $css[$selector]['background-image'] = 'radial-gradient(100% 100% at 100% 0, ' . $button_color . ' 0, var(--wphave-site-color-button-background) 100%)';

            // Hover
            $css[$selector_hover]['background-image'] = 'radial-gradient(100% 100% at 0 100%, ' . $button_color_hover . ' 0, var(--wphave-site-color-button-background-hover) 100%)';

            // Default before
            $css[$selector_before]['content'] = '""';
            $css[$selector_before]['position'] = 'absolute';
            $css[$selector_before]['top'] = '-2px';
            $css[$selector_before]['left'] = '-2px';
            $css[$selector_before]['z-index'] = '-1';
            $css[$selector_before]['width'] = 'calc(100% + 4px)';
            $css[$selector_before]['height'] = 'calc(100% + 4px)';
            $css[$selector_before]['animation'] = 'glowing 20s linear infinite';
            $css[$selector_before]['background'] = 'linear-gradient(45deg, #ff0000, #ff7300, #fffb00, #48ff00, #00ffd5, #002bff, #7a00ff, #ff00c8, #ff0000)';
            $css[$selector_before]['background-size'] = '400%';
            $css[$selector_before]['filter'] = 'blur(5px)';
            $css[$selector_before]['transform'] = 'translate3d(0, 0, 0)';
            $css[$selector_before]['opacity'] = '0';
            $css[$selector_before]['transition'] = 'opacity .3s ease-in-out';
            $css[$selector_before]['border-radius'] = 'calc( 4px - 1px )';

            // Hover before
            $css[$selector_hover_before]['opacity'] = '1';

            // Keyframes
            $css['@keyframes glowing'] = array(
                '0%' => array(
                    'background-position' => '0 0',
                ),
                '50%' => array(
                    'background-position' => '400% 0',
                ),
                '100%' => array(
                    'background-position' => '0 0',
                )
            );

		$styles[0] = $css;



		$css = array();

            // Default
            $css[$selector]['border-radius'] = '2px!important';
            $css[$selector]['border'] = '2px solid var(--wphave-site-color-button-border)!important';
            $css[$selector]['background-color'] = 'var(--wphave-site-color-button-background)!important';
            $css[$selector]['overflow'] = 'hidden';

            // Hover
            $css[$selector_hover]['border-color'] = 'var(--wphave-site-color-button-border-hover)!important';
            $css[$selector_hover]['background-color'] = 'transparent!important';
            $css[$selector_hover]['transition'] = 'background-color .3s ease-in-out';

            // Default Before
            $css[$selector_before]['content'] = '""';
            $css[$selector_before]['position'] = 'absolute';
            $css[$selector_before]['left'] = '0';
            $css[$selector_before]['bottom'] = '0';
            $css[$selector_before]['width'] = '0';
            $css[$selector_before]['height'] = '100%';
            $css[$selector_before]['border-radius'] = 'calc( var(--wphave-site-button-radius) - 2px )';
            $css[$selector_before]['z-index'] = '-1';

            // Hover Before
            $css[$selector_hover_before]['width'] = '100%';
            $css[$selector_hover_before]['background-color'] = 'var(--wphave-site-color-button-background-hover)';
            $css[$selector_hover_before]['transition'] = 'width .5s ease-in-out';

		$styles[1] = $css;



		$css = array();

            // Default
            $css[$selector]['border'] = '0!important';
            $css[$selector]['border-radius'] = '0!important';
            $css[$selector]['transition'] = 'all 0.3s ease-in-out';
            $css[$selector]['background-image'] = 'radial-gradient(33% 100% at 50% 27%, ' . $button_color . ' 0, var(--wphave-site-color-button-background) 100%)';

            // Hover
            $css[$selector_hover]['background-image'] = 'radial-gradient(33% 100% at 50% 100%, ' . $button_color . ' 0, var(--wphave-site-color-button-background) 100%)!important';

            // Default Before
            $css[$selector_before]['content'] = '""';
            $css[$selector_before]['position'] = 'absolute';
            $css[$selector_before]['left'] = '0';
            $css[$selector_before]['width'] = '100%';
            $css[$selector_before]['height'] = '100%';
            $css[$selector_before]['z-index'] = '1';
            $css[$selector_before]['opacity'] = '0';
            $css[$selector_before]['transition'] = 'all 0.3s';
            $css[$selector_before]['border-top-width'] = '2px';
            $css[$selector_before]['border-bottom-width'] = '2px';
            $css[$selector_before]['border-top-style'] = 'solid';
            $css[$selector_before]['border-bottom-style'] = 'solid';
            $css[$selector_before]['border-top-color'] = 'rgba( var(--wphave-site-color-button-border-hover-rgb), 0.5)';
            $css[$selector_before]['border-bottom-color'] = 'rgba( var(--wphave-site-color-button-border-hover-rgb), 0.5)';
            $css[$selector_before]['transform'] = 'scale(0.1, 1)';

            // Hover Before
            $css[$selector_hover_before]['opacity'] = '1';
            $css[$selector_hover_before]['transform'] = 'scale(1, 1)';

		$styles[2] = $css;



		$css = array();

            // Default
            $css[$selector]['border'] = '0!important';
            $css[$selector]['border-radius'] = '3px!important';
            $css[$selector]['background-color'] = 'var(--wphave-site-color-button-background)!important';
            $css[$selector]['transition'] = 'all 0.3s';

            // Hover
            $css[$selector_hover]['background-color'] = 'rgba( var(--wphave-site-color-button-background-hover-rgb), 0.5 )!important';
            $css[$selector_hover]['transition'] = 'background-color .3s ease-in-out';

            // Default Before
            $css[$selector_before]['content'] = '""';
            $css[$selector_before]['position'] = 'absolute';
            $css[$selector_before]['left'] = '0';
            $css[$selector_before]['width'] = '100%';
            $css[$selector_before]['height'] = '100%';
            $css[$selector_before]['z-index'] = '1';
            $css[$selector_before]['background-color'] = 'rgba( var(--wphave-site-color-button-background-hover-rgb), 0.1 )';
            $css[$selector_before]['border-radius'] = 'calc( var(--wphave-site-button-radius) - 2px )';
            $css[$selector_before]['transition'] = 'all 0.3s';

            // Hover Before
            $css[$selector_hover_before]['opacity'] = '0';
            $css[$selector_hover_before]['transform'] = 'scale(0.5,0.5)';

            // Default After
            $css[$selector_after]['content'] = '""';
            $css[$selector_after]['position'] = 'absolute';
            $css[$selector_after]['left'] = '-2px';
            $css[$selector_after]['width'] = '100%';
            $css[$selector_after]['height'] = '100%';
            $css[$selector_after]['z-index'] = '1';
            $css[$selector_after]['opacity'] = '0';
            $css[$selector_after]['transition'] = 'all 0.3s';
            $css[$selector_after]['border'] = '2px solid var(--wphave-site-color-button-border-hover)';
            $css[$selector_after]['border-radius'] = '6px';
            $css[$selector_after]['transform'] = 'scale(1.2,1.2)';

            // Hover After
            $css[$selector_hover_after]['opacity'] = '1';
            $css[$selector_hover_after]['transform'] = 'scale(1,1)';

		$styles[3] = $css;



		$css = array();

            // Default
            $css[$selector]['background-color'] = 'var(--wphave-site-color-button-background)!important';

            // Hover
            $css[$selector_hover]['transform'] = 'translateY(-1px)';
            $css[$selector_hover]['box-shadow'] = '0 4px 9px -3px rgba(0, 0, 0, 0.4)';

            // Default After
            $css[$selector_after]['content'] = '""';
            $css[$selector_after]['position'] = 'absolute';
            $css[$selector_after]['top'] = '0';
            $css[$selector_after]['left'] = '0';
            $css[$selector_after]['z-index'] = '-1';
            $css[$selector_after]['display'] = 'inline-block';
            $css[$selector_after]['width'] = '100%';
            $css[$selector_after]['height'] = '100%';
            $css[$selector_after]['border-radius'] = 'calc( var(--wphave-site-button-radius) - 2px )';
            $css[$selector_after]['background-color'] = 'var(--wphave-site-color-button-background-hover)';
            $css[$selector_after]['transition'] = 'all .8s';

            // Hover After
            $css[$selector_hover_after]['transform'] = 'scaleX(1.1) scaleY(1.4)';
            $css[$selector_hover_after]['opacity'] = '0';

		$styles[4] = $css;



		$css = array();

            // Default
            $css[$selector]['border'] = '0!important';
            $css[$selector]['border-radius'] = '4px!important';
            $css[$selector]['background-color'] = 'var(--wphave-site-color-button-background)!important';
            $css[$selector]['overflow'] = 'hidden';

            // Default After
            $css[$selector_after]['content'] = '""';
            $css[$selector_after]['position'] = 'absolute';
            $css[$selector_after]['top'] = '-50px';
            $css[$selector_after]['left'] = '-75px';
            $css[$selector_after]['z-index'] = '1';
            $css[$selector_after]['width'] = '50px';
            $css[$selector_after]['height'] = '155px';
            $css[$selector_after]['opacity'] = '0.2';
            $css[$selector_after]['background'] = '#fff';
            $css[$selector_after]['transform'] = 'rotate(35deg)';
            $css[$selector_after]['transition'] = 'all 1s cubic-bezier(0.19, 1, 0.22, 1)';

            // Hover After
            $css[$selector_hover_after]['left'] = '120%';
            $css[$selector_hover_after]['transition'] = 'all 1s cubic-bezier(0.19, 1, 0.22, 1)';

		$styles[5] = $css;



		$css = array();

            // Default
            $css[$selector]['border-color'] = 'transparent';
            $css[$selector]['box-shadow'] = 'inset 0 0 20px rgba(255, 255, 255, 0)';
            $css[$selector]['outline'] = '1px solid!important';
            $css[$selector]['outline-color'] = 'rgba( var(--wphave-site-color-button-border-rgb), 0.5)!important';
            $css[$selector]['outline-offset'] = '0px';
            $css[$selector]['background-color'] = 'var(--wphave-site-color-button-background)!important';
            $css[$selector]['transition'] = 'all 1250ms cubic-bezier(0.19, 1, 0.22, 1)';

            // Hover
            $css[$selector_hover]['border-color'] = 'var(--wphave-site-color-button-border)!important';
            $css[$selector_hover]['box-shadow'] = 'inset 0 0 20px rgba(255, 255, 255, 0.5), 0 0 20px rgba(255, 255, 255, 0.2)';
            $css[$selector_hover]['outline-color'] = 'rgba( var(--wphave-site-color-button-border-hover-rgb), 0)!important';
            $css[$selector_hover]['outline-offset'] = '15px';
            $css[$selector_hover]['background-color'] = 'rgba( var(--wphave-site-color-button-background-hover-rgb), 0.5 )';

		$styles[6] = $css;



		$css = array();

            // Default
            $css[$selector]['background'] = 'var(--wphave-site-color-button-background)';
            $css[$selector]['box-shadow'] = 'inset -2px -2px 7px 4px rgba(255,255,255,0.1), 0 5px 0px ' . $button_color_darken_35 . '!important';
            $css[$selector]['border-radius'] = '40px!important';
            $css[$selector]['transition'] = 'all .2s';

            // Hover + Active
            $selector_compo = array();
            $selector_compo[] = $selector_hover;
            $selector_compo[] = $selector_active;
            $selector_compo = implode(',', $selector_compo);

            $css[$selector_compo]['transform'] = 'translateY(3px)';
            $css[$selector_compo]['box-shadow'] = 'inset 2px 2px 7px 4px rgba(0,0,0,0.1), 0 2px 0px ' . $button_color_hover_darken_35 . '!important';

		$styles[7] = $css;



		$css = array();

            // Default
            $css[$selector]['background'] = 'var(--wphave-site-color-button-background)';
            $css[$selector]['box-shadow'] = 'inset -2px -2px 0 -1px ' . $button_color_lighten_25 . ', inset 0 -4px 16px -2px ' . $button_color_lighten_25 . ', 0 5px 0 ' . $button_color_darken_35 . '!important';
            $css[$selector]['border-radius'] = '3px!important';
            $css[$selector]['transition'] = 'all .2s';

            // Hover + Active
            $selector_compo = array();
            $selector_compo[] = $selector_hover;
            $selector_compo[] = $selector_active;
            $selector_compo = implode(',', $selector_compo);

            $css[$selector_compo]['transform'] = 'translateY(3px)';
            $css[$selector_compo]['box-shadow'] = 'inset -2px -2px 0 -1px ' . $button_color_hover_darken_35 . ', inset 0 -4px 16px -2px ' . $button_color_hover_darken_35 . ', 0 2px 0px ' . $button_color_hover_darken_35 . '!important';

		$styles[8] = $css;



		$css = array();

            // Default
            $css[$selector]['border'] = '0!important';
            $css[$selector]['background'] = 'var(--wphave-site-color-button-background)';
            $css[$selector]['box-shadow'] = 'rgba(45, 35, 66, 0.4) 0 2px 4px,rgba(45, 35, 66, 0.3) 0 7px 13px -3px, ' . $button_color_darken_35 . ' 0 -2px 0 inset!important';
            $css[$selector]['border-radius'] = '5px!important';

            // Hover
            $css[$selector_hover]['box-shadow'] = 'rgba(45, 35, 66, 0.4) 0 4px 8px, rgba(45, 35, 66, 0.3) 0 7px 13px -3px, ' . $button_color_hover_darken_35 . ' 0 -2px 0 inset!important';
            $css[$selector_hover]['transform'] = 'translateY(-2px)';

		$styles[9] = $css;



		$css = array();

            // Default
            $css[$selector]['position'] = 'relative!important';
            $css[$selector]['overflow'] = 'hidden';
            $css[$selector]['transition'] = 'all 1650ms';
            $css[$selector]['background-color'] = 'var(--wphave-site-color-button-background)!important';

            // Default Before
            $css[$selector_before]['content'] = '""';
            $css[$selector_before]['position'] = 'absolute';
            $css[$selector_before]['top'] = '0';
            $css[$selector_before]['left'] = '-100%';
            $css[$selector_before]['width'] = '100%';
            $css[$selector_before]['height'] = '100%';
            $css[$selector_before]['background'] = 'linear-gradient( 120deg, transparent, rgba( var(--wphave-site-color-button-background-hover-rgb), 0.5 ), transparent )!important';
            $css[$selector_before]['transition'] = 'all 650ms';

            // Hover
            $css[$selector_before]['box-shadow'] = '0px 3px 0px rgba( var(--wphave-site-color-button-background-hover-rgb),0.5 ), 0px -3px 0px rgba( var(--wphave-site-color-button-background-hover-rgb),0.5 )';

            // Hover Before
            $css[$selector_hover_before]['left'] = '100%';

		$styles[10] = $css;



		$css = array();

            // Default
            $css[$selector]['border'] = '0!important';
            $css[$selector]['background-color'] = 'var(--wphave-site-color-button-background)!important';

            // Default After
            $css[$selector_after]['content'] = '""';
            $css[$selector_after]['position'] = 'absolute';
            $css[$selector_after]['top'] = '3px';
            $css[$selector_after]['left'] = '3px';
            $css[$selector_after]['z-index'] = '-1';
            $css[$selector_after]['width'] = '100%';
            $css[$selector_after]['height'] = '100%';
            $css[$selector_after]['transition'] = '0.2s';
            $css[$selector_after]['border'] = '2px solid var(--wphave-site-color-button-border)!important';

            // Hover After
            $css[$selector_hover_after]['top'] = '-2px';
            $css[$selector_hover_after]['left'] = '-2px';

            $styles[11] = $css;



		$css = array();

            // Default
            $css[$selector]['border-radius'] = '50px';
            $css[$selector]['border'] = '1px solid rgba( var(--wphave-site-color-button-border-rgb), 0.2 )';
            $css[$selector]['box-shadow'] = '0px 4px 7px -2px rgba(0,0,0,0.2), inset 0px 4px 1px -3px rgba(255,255,255,0.25), inset 0 0 0 rgba(255,255,255,0)';
            $css[$selector]['background-color'] = 'var(--wphave-site-color-button-background)';
            $css[$selector]['transition'] = 'all 0.2s ease-in-out';

            // Hover
            $css[$selector_hover]['border'] = '1px solid rgba( var(--wphave-site-color-button-border-hover-rgb), 0.2 )';
            $css[$selector_hover]['box-shadow'] = '0px 4px 7px -2px rgba(0, 0, 0, 0), inset 0px 4px 1px -3px rgba(0, 0, 0, 0.5), inset 0 0 0 rgba(0, 0, 0, 0.1)';

		$styles[12] = $css;



		$css = array();

            // Default
            $css[$selector]['background'] = 'none!important';
            $css[$selector]['border'] = '0!important';
            $css[$selector]['box-shadow'] = 'none!important';

            // Default (Before + After)
            $selector_compo = array();
            $selector_compo[] = $selector_before;
            $selector_compo[] = $selector_after;
            $selector_compo = implode(',', $selector_compo);

            $css[$selector_compo]['border-radius'] = '80px';

            // Default Before
            $css[$selector_before]['content'] = '""';
            $css[$selector_before]['position'] = 'absolute';
            $css[$selector_before]['top'] = '0';
            $css[$selector_before]['left'] = '0';
            $css[$selector_before]['z-index'] = '-2';
            $css[$selector_before]['width'] = '100%';
            $css[$selector_before]['height'] = '100%';
            $css[$selector_before]['display'] = 'block';
            $css[$selector_before]['overflow'] = 'hidden';
            $css[$selector_before]['background-color'] = 'rgba( var(--wphave-site-color-button-border-rgb), 0.32 )';

            // Default After
            $css[$selector_after]['content'] = '""';
            $css[$selector_after]['position'] = 'absolute';
            $css[$selector_after]['top'] = '4px';
            $css[$selector_after]['right'] = '4px';
            $css[$selector_after]['bottom'] = '4px';
            $css[$selector_after]['left'] = '4px';
            $css[$selector_after]['z-index'] = '-1';
            $css[$selector_after]['display'] = 'block';
            $css[$selector_after]['display'] = 'block';
            $css[$selector_after]['transition'] = 'all 100ms ease-out';
            $css[$selector_after]['background-color'] = 'initial';
            $css[$selector_after]['background-image'] = 'linear-gradient(92.83deg, ' . $button_color_lighten_25 . ' 0, var(--wphave-site-color-button-background) 100%)';

            // Hover After
            $css[$selector_hover_after]['top'] = '0';
            $css[$selector_hover_after]['right'] = '0';
            $css[$selector_hover_after]['bottom'] = '0';
            $css[$selector_hover_after]['left'] = '0';
            $css[$selector_hover_after]['transition-timing-function'] = 'ease-in';

		$styles[13] = $css;



		$css = array();

            // Default
            $css[$selector]['border-radius'] = '10px';
            $css[$selector]['border'] = '1px solid rgba( var(--wphave-site-color-button-border-rgb), 0.2 )';
            $css[$selector]['box-shadow'] = '0 4px 7px -2px rgba(0,0,0,0.2), inset 1px -2px 0px -1px rgba(0,0,0,0.2), inset 0 1.5em 0px 1px rgba(255,255,255,0.15), inset 0 0 0 rgba(255,255,255,0)';
            $css[$selector]['background-color'] = 'var(--wphave-site-color-button-background)';
            $css[$selector]['transition'] = 'all 0.2s ease-in-out';

            // Hover
            $css[$selector_hover]['border'] = '1px solid rgba( var(--wphave-site-color-button-border-hover-rgb), 0.2 )';
            $css[$selector_hover]['box-shadow'] = '0px 4px 7px -2px rgba(0, 0, 0, 0), inset 1px 2px 0px -1px rgba(255,255,255,0.6), inset 0 -1.5em 0px 1px rgba(0,0,0,0.15), inset 0 0 0 rgba(0,0,0,0)';
            $css[$selector_hover]['background-color'] = 'var(--wphave-site-color-button-background-hover)';

		$styles[14] = $css;



        if( $output === 'all' ) {
			return $styles;
		}

        $data = isset( $styles[$style] ) ? $styles[$style] : array();



		$cache[ $cache_key ] = $data;

		return $data;

    }

endif;
