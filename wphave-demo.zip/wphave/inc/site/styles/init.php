<?php

/**
 * Load site-wide style presets and render helpers.
 */

if (!defined('ABSPATH')) {
	exit();
}

include_once __DIR__ . '/colors.php';
include_once __DIR__ . '/presets.php';

include_once __DIR__ . '/svg/encoder.php';
include_once __DIR__ . '/svg/duotones.php';
include_once __DIR__ . '/svg/decorations.php';
include_once __DIR__ . '/svg/dividers.php';
include_once __DIR__ . '/svg/underlines.php';
include_once __DIR__ . '/svg/clip-paths.php';
include_once __DIR__ . '/svg/lines.php';
include_once __DIR__ . '/svg/patterns.php';

include_once __DIR__ . '/overlays.php';
include_once __DIR__ . '/link-styles.php';
include_once __DIR__ . '/button-styles.php';
include_once __DIR__ . '/css-patterns.php';
include_once __DIR__ . '/photo-filters.php';

include_once __DIR__ . '/decoration.php';
