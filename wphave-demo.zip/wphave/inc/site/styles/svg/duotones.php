<?php

/**
 * Build the configured SVG duotone definitions.
 *
 * 	@ https://yoksel.github.io/svg-gradient-map/#/
 * 	@ https://duotone.shapefactory.co/
 */

if ( ! function_exists( 'wphave_duotones' ) ) :

    function wphave_duotones( $args = array() ) {

		$output = $args['output'] ?? '';
		$type = $args['type'] ?? '0';
		$load = $args['load'] ?? array();



        $tones = array(
			0 => array(
				'0, 0, 126', // <-- rgb shadows
				'106, 255, 127', // <-- rgb highlights
			),
			1 => array(
				'96, 36, 87',
				'172, 212, 157',
			),
			2 => array(
				'73, 0, 123',
				'1, 219, 254',
			),
			3 => array(
				'41, 9, 0',
				'145, 207, 248',
			),
			4 => array(
				'141, 21, 154',
				'128, 228, 255',
			),
			5 => array(
				'17, 36, 94',
				'220, 67, 121',
			),
			6 => array(
				'51, 66, 164',
				'239, 0, 158',
			),
			7 => array(
				'0, 0, 151',
				'255, 71, 71',
			),
			8 => array(
				'25, 0, 216',
				'255, 169, 107',
			),
			9 => array(
				'47, 7, 129',
				'223, 178, 51',
			),
			10 => array(
				'59, 13, 136',
				'246, 216, 156',
			),
			11 => array(
				'199, 0, 99',
				'255, 242, 120',
			),
			12 => array(
				'7, 132, 126',
				'255, 253, 182',
			),
			13 => array(
				'140, 0, 183',
				'252, 255, 65',
			),
			14 => array(
				'119, 10, 176',
				'255, 202, 204',
			),
			15 => array(
				'0, 94, 172',
				'246, 205, 225',
			),
			16 => array(
				'90, 10, 63',
				'255, 255, 255',
			),
			17 => array(
				'23, 60, 152',
				'255, 255, 255',
			),
		);

        /**
         * Function to generate a SVG including all active duotones filters.
         * @ https://gusbemacbe.github.io/color-mixer-telinkrin/
         */

        if( $output === 'all' ) {
			return $tones;
		}

        /**
         * Function to generate a SVG including all active duotones filters.
         * @ https://gusbemacbe.github.io/color-mixer-telinkrin/
         */

		if( $load ) {
			$active_filters = array();
			foreach( $load as $key => $id ) {
				if( isset( $tones[$id] ) ) {
					$active_filters[$id] = $tones[$id];
				}
			}
			return $active_filters;
		}

        /**
         * Function to generate a SVG including all active duotones filters.
         * @ https://gusbemacbe.github.io/color-mixer-telinkrin/
         */

        $data = $tones[$type] ?? '';

        return $data;

    }

endif;
