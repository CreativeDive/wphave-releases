<?php

/**
 * Encode special characters for using SVG in "data:image/svg+xml".
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Encode special characters for using SVG in "data:image/svg+xml".
 */

if ( ! function_exists( 'wphave_encode_svg_css_background_image' ) ) :

	function wphave_encode_svg_css_background_image( $data ) {

        $data = wphave_replace('"', "'", $data);
        $data = wphave_replace('<', "%3C", $data);
        $data = wphave_replace('>', "%3E", $data);
        $data = wphave_replace( '#', '%23', $data );
        //$data = wphave_replace( ';', '', $data );

		return $data;

	}

endif;
