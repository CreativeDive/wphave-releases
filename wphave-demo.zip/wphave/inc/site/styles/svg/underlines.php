<?php

/**
 * This function allows you to output a specific SVG underline.
 */

if ( ! function_exists( 'wphave_svg_underline' ) ) :

    function wphave_svg_underline( $args = array() ) {

		$output = $args['output'] ?? '';
		$class = $args['class'] ?? '';
		$style = $args['style'] ?? 0;



        $underlines = array();

        $underlines[0] = '<svg viewBox="-1 -1 14.13 3.47"><path d="m.28.82c.34-.23.76-.29,1.17-.31.94-.05,1.89.06,2.82.15,2.6.26,5.22.41,7.82.23"/></svg>';

		$underlines[1] = '<svg viewBox="-1 -1 16.74 3.99"><path d="m.33.86c.53.47,1.33.63,2,.39.29-.1.57-.27.87-.26.19,0,.36.08.54.15.65.26,1.41.43,2.02.09.14-.07.26-.17.42-.2.19-.03.36.07.53.16.26.14.52.27.81.3.47.05.92-.16,1.35-.33.42-.17.86-.32,1.3-.43.23-.06.47-.11.7-.07.21.04.39.16.59.25.48.21,1.02.22,1.53.11.54-.11,1.05-.34,1.55-.56"/></svg>';

        $underlines[2] = '<svg viewBox="-1 -1 11.69 3.63"><path d="m1.91.12c2.3.18,4.59.46,6.87.84-.53.06-1.06.03-1.6.01C4.79.88,2.41.76.02.62c1.51.28,3.03.55,4.54.83l-1.96-.03.32.1"/></svg>';

        $underlines[3] = '<svg viewBox="-1 -1 12.63 3.52"><path d="m.23,1.08c.25-.13.54-.19.82-.24,1.07-.2,2.16-.26,3.25-.29,2.1-.07,4.21-.06,6.31.04"/></svg>';

        $underlines[4] = '<svg viewBox="-1 -1 19.82 3.06"><path d="m.05.55c3.15-1.51,13.61,1.59,17.27.02"/></svg>';

        $underlines[5] = '<svg viewBox="-1 -1 15.18 3.39"><path d="m.34.71C1.86-.02,2.61,1.54,5.83.62c3.55-1.01,4.84,1.44,6.89.04"/></svg>';

        $underlines[6] = '<svg viewBox="-1 -1 15.76 3.02"><path d="m.06.79C.85.4,1.73.17,2.62.13c-.02.13.1.25.22.29s.26.02.4,0c.67-.07,1.35-.02,2.03.03.74.06,1.47.12,2.21.18,2.09.17,4.19.35,6.28.2"/></svg>';

        $underlines[7] = '<svg viewBox="-1 -1 9.68 3.17"><path d="m.67.73l6.79.17c-2.43-.23-4.88-.28-7.32-.16,2.4-.05,4.81-.1,7.21-.15-1.7.09-3.4-.12-5.09-.32"/></svg>';

        $underlines[8] = '<svg viewBox="-1 -1 15.55 5"><path d="m.09,2.13C.7,1.49,1.38.91,2.1.4c.08.6.17,1.2.25,1.8.45-.71.97-1.41,1.61-1.96.12.63.25,1.26.54,1.83.3-.51.65-.99,1.05-1.43.09.56.24,1.11.47,1.63.37-.73.86-1.4,1.46-1.96.04.64.2,1.26.49,1.83.44-.5.88-1.01,1.32-1.51.17.7.45,1.38.81,2,.1-.75.4-1.48.84-2.09-.03.64.1,1.29.38,1.87.47-.59.96-1.15,1.48-1.69.09.69.31,1.36.65,1.96"/></svg>';

        $underlines[9] = '<svg viewBox="-1 -1 12.82 3.59"><path d="m.21.46c.61.28,1.27.39,1.93.47,2.86.35,5.76.09,8.62-.3"/></svg>';

        $underlines[10] = '<svg viewBox="-2 -2 82.98 11.9"><path d="m.38,8.46C2.47,5.97,4.57,3.47,6.66.98c1.37,2.68,3.16,5.15,5.29,7.27,2.15-2.17,4.06-4.57,5.69-7.15,2.16,2.34,4.23,4.76,6.21,7.26,1.87-2.46,3.73-4.93,5.6-7.39,1.55,2.85,3.38,5.56,5.45,8.06,1.77-3.06,4.18-5.73,7.04-7.8.5,2.73,1.67,5.33,3.37,7.52,2.14-2.55,4.43-4.98,6.84-7.27,2.3,2,4.35,4.3,6.07,6.83,1.36-2.74,3.41-5.13,5.91-6.89.8,2.45,1.98,4.77,3.48,6.86,2.1-2.72,4.49-5.22,7.12-7.45,1.27,3.03,3.34,5.71,5.95,7.7"/></svg>';

        $underlines[11] = '<svg viewBox="-2 -2 40.17 7.09"><path d="m6.28,1.16c-1.56-.26-3.46-.36-4.96.23-.38.15-.77.42-.81.82-.26,2.59,7.5,1.02,8.68.81,2.8-.51,5.57-1.16,8.36-1.68C23.7.2,30.08.02,36.07,2.07c.82.28,1.79.9,1.58,1.73-.16.64-.91.84-1.49.79"/></svg>';


        /**
         * WPHAVE svg underline modifier.
         */

		if( $output === 'all' ) {
            $all = [];
            foreach( $underlines as $underline ) {
                $all[] = wphave_svg_underline_modifier( $underline, $class );
            }
			return $all;
		}

		$data = isset( $underlines[$style] ) ? $underlines[$style] : '';

		if( ! $data ) {
			return;
		}

		$data = wphave_svg_underline_modifier( $data, $class );

		/**
		 * WPHAVE svg underline modifier.
		 */

		return $data;

    }

endif;

if ( ! function_exists( 'wphave_svg_underline_modifier' ) ) :

    function wphave_svg_underline_modifier( $svg, $class ) {

		$class = WPHAVE_Safe_SVG::sanitize_classes( $class );
        $svg = wphave_replace('<svg', '<svg xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" ', $svg);
        $svg = wphave_replace('<path', '<path pathLength="1" fill="none" stroke="%23000000" stroke-width="0.5" stroke-linecap="round" ', $svg);

        if( $class ) {
            $svg = wphave_replace('<svg', '<svg class="' . $class . '" ', $svg);
        }

        return WPHAVE_Safe_SVG::sanitize_markup( $svg );

    }

endif;
