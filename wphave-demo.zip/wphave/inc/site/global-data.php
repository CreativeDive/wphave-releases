<?php

if( ! defined('ABSPATH') ) {
    exit;
}

/**
 * Central data layer for all global design settings.
 *
 * Responsibilities:
 * - Provide default site design settings
 * - Merge user settings with defaults
 * - Generate structured data for styling
 * - Map settings → CSS variables
 * - Provide color schemes
 *
 * This class acts as the "Design System Backbone"
 * for the entire frontend rendering pipeline.
 */

class WPHAVE_Global_Data {

    /**
     * Build the default semantic gradient for one design-color role.
     *
     * The stops reference color-scale variables so one default gradient follows
     * both palette changes and alternate color mode without duplicating colors.
     *
     * @param string $role Semantic design-color role.
     * @return array
     */

    private static function get_default_design_gradient( $role ) {
        $role = in_array( $role, [ 'primary', 'secondary', 'tertiary', 'accent' ], true ) ? $role : 'primary';

        return [
            'type' => 'linear',
            'angle' => 135,
            'position' => 'custom',
            'colorStops' => [
                [
                    'color' => 'var(--wphave-site-color-' . $role . '-lighter-4)',
                    'position' => 0,
                ],
                [
                    'color' => 'var(--wphave-site-color-' . $role . '-darker-3)',
                    'position' => 100,
                ],
            ],
        ];
    }

    /**
     * Returns the default structure for all global settings.
     * Used as fallback when user has not defined values.
     *
     * @param array $globals Optional existing globals
     * @return array
     */

    public static function get_defaults( $globals = [] ) {
	    $globals = ! empty( $globals ) ? $globals : wphave_data_get( 'site_globals' );

        /**
         * Resolve active color scheme
         */

        $schemes = self::color_schemes();
        $color_scheme = $globals['preset']['colors']['name'] ?? wphave_data_get( 'site_globals', 'preset.colors.name', 'default' ) ?? 'default';
        $scheme_data = $schemes[$color_scheme] ?? $schemes['default'];

        /**
         * Full default design system
         */

        $defaults = array(
            'layout' => [
                'width' => '1300', // --wphave-site-content-width (<-- Save always without unit !)
                'wideWidth' => '1600px', // --wphave-site-width-wide
                'mediumWidth' => '930px', // --wphave-site-width-medium
                'narrowWidth' => '700px', // --wphave-site-width-narrow
                'spacing' => '2.5rem', // --wphave-site-spacing
                'padding' => '2rem 2rem 2rem 2rem', // --wphave-padding-spacing
                'paddingTop' => '3.5rem', // --wphave-site-padding
                'paddingRight' => '3.5rem', // --wphave-site-padding
                'paddingBottom' => '3.5rem', // --wphave-site-padding
                'paddingLeft' => '3.5rem', // --wphave-site-padding
                'sizeRatio' => '100%', // --wphave-site-size-ratio
                'regionMargin' => '2rem', // --wphave-site-region-margin
                'margin' => '2rem', // --wphave-site-margin
                'layoutGap' => '1.5rem', // --wphave-site-layout-gap
                'corners' => '0rem' // --wphave-site-corners
            ],
            'tokens' => [
                'gapSizes' => [
                    'xs' => [
                        'min' => '4px',
                        'value' => '0.5rem'
                    ],
                    's' => [
                        'min' => '12px',
                        'value' => '1rem'
                    ],
                    'm' => [
                        'min' => '14px',
                        'value' => '1.5rem'
                    ],
                    'l' => [
                        'min' => '16px',
                        'value' => '2rem'
                    ],
                    'xl' => [
                        'min' => '18px',
                        'value' => '2.5rem'
                    ],
                    'xxl' => [
                        'min' => '20px',
                        'value' => '3rem'
                    ],
                    '3xl' => [
                        'min' => '22px',
                        'value' => '3.5rem'
                    ],
                    '4xl' => [
                        'min' => '24px',
                        'value' => '4rem'
                    ]
                ],
                'paddingSizes' => [
                    'xxs' => [
                        'min' => '6px',
                        'value' => '0.5rem'
                    ],
                    'xs' => [
                        'min' => '6px',
                        'value' => '1rem'
                    ],
                    's' => [
                        'min' => '6px',
                        'value' => '1.5rem'
                    ],
                    'm' => [
                        'min' => '6px',
                        'value' => '2rem'
                    ],
                    'l' => [
                        'min' => '10px',
                        'value' => '3rem'
                    ],
                    'xl' => [
                        'min' => '6px',
                        'value' => '4rem'
                    ],
                    'xxl' => [
                        'min' => '6px',
                        'value' => '6rem'
                    ],
                    '3xl' => [
                        'min' => '6px',
                        'value' => '8rem'
                    ],
                    '4xl' => [
                        'min' => '6px',
                        'value' => '10rem'
                    ]
                ],
                'marginSizes' => [
                    'xxs' => [
                        'min' => '6px',
                        'value' => '0.5rem'
                    ],
                    'xs' => [
                        'min' => '6px',
                        'value' => '1rem'
                    ],
                    's' => [
                        'min' => '6px',
                        'value' => '1.5rem'
                    ],
                    'm' => [
                        'min' => '6px',
                        'value' => '2rem'
                    ],
                    'l' => [
                        'min' => '6px',
                        'value' => '3rem'
                    ],
                    'xl' => [
                        'min' => '6px',
                        'value' => '4rem'
                    ],
                    'xxl' => [
                        'min' => '6px',
                        'value' => '6rem'
                    ],
                    '3xl' => [
                        'min' => '6px',
                        'value' => '8rem'
                    ],
                    '4xl' => [
                        'min' => '6px',
                        'value' => '10rem'
                    ]
                ],
                'cornerSizes' => [
                    'xs' => [
                        'min' => '1px',
                        'value' => '2px'
                    ],
                    's' => [
                        'min' => '1px',
                        'value' => '6px'
                    ],
                    'm' => [
                        'min' => '1px',
                        'value' => '10px'
                    ],
                    'l' => [
                        'min' => '1px',
                        'value' => '15px'
                    ],
                    'xl' => [
                        'min' => '1px',
                        'value' => '25px'
                    ],
                    'xxl' => [
                        'min' => '1px',
                        'value' => '50px'
                    ]
                ],
                'cornerPercentSizes' => [
                    'xs' => [
                        'min' => '1px',
                        'value' => '5%'
                    ],
                    's' => [
                        'min' => '1px',
                        'value' => '10%'
                    ],
                    'm' => [
                        'min' => '1px',
                        'value' => '15%'
                    ],
                    'l' => [
                        'min' => '1px',
                        'value' => '30%'
                    ],
                    'xl' => [
                        'min' => '1px',
                        'value' => '50%'
                    ],
                    'xxl' => [
                        'min' => '1px',
                        'value' => '100%'
                    ]
                ],
                'borderSizes' => [
                    'xs' => [
                        'min' => '1px',
                        'value' => '1px'
                    ],
                    's' => [
                        'min' => '1px',
                        'value' => '2px'
                    ],
                    'm' => [
                        'min' => '1px',
                        'value' => '3px'
                    ],
                    'l' => [
                        'min' => '1px',
                        'value' => '4px'
                    ],
                    'xl' => [
                        'min' => '1px',
                        'value' => '6px'
                    ],
                    'xxl' => [
                        'min' => '1px',
                        'value' => '8px'
                    ]
                ],
                'outlineSizes' => [
                    'xs' => [
                        'min' => '1px',
                        'value' => '1px'
                    ],
                    's' => [
                        'min' => '1px',
                        'value' => '2px'
                    ],
                    'm' => [
                        'min' => '1px',
                        'value' => '3px'
                    ],
                    'l' => [
                        'min' => '1px',
                        'value' => '4px'
                    ],
                    'xl' => [
                        'min' => '1px',
                        'value' => '6px'
                    ],
                    'xxl' => [
                        'min' => '1px',
                        'value' => '8px'
                    ]
                ]
            ],
            'frame' => [
                'width' => '0rem 0rem 0rem 0rem', // --wphave-site-frame-width
                'style' => 'solid solid solid solid', // --wphave-site-frame-style
                'color' => 'transparent transparent transparent transparent', // --wphave-site-frame-color
            ],
            'colors' => [
                'primary' => [
                    'base' => $scheme_data['primary'] ?? WPHAVE_MAIN_COLOR, // --wphave-site-color-primary
                    'gradient' => self::get_default_design_gradient( 'primary' ),
                    'colorMode' => [
                        'base' => '#393f4d' // [data-wphave-color-mode="alternate"] --wphave-site-color-primary
                    ]
                ],
                'secondary' => [
                    'base' => $scheme_data['secondary'] ?? WPHAVE_MAIN_COLOR_SECOND, // --wphave-site-color-secondary
                    'gradient' => self::get_default_design_gradient( 'secondary' ),
                    'colorMode' => [
                        'base' => '#4A4E56' // [data-wphave-color-mode="alternate"] --wphave-site-color-secondary
                    ]
                ],
                'tertiary' => [
                    'base' => $scheme_data['tertiary'] ?? WPHAVE_MAIN_COLOR_TERTIARY, // --wphave-site-color-tertiary
                    'gradient' => self::get_default_design_gradient( 'tertiary' ),
                    'colorMode' => [
                        'base' => '#414651' // [data-wphave-color-mode="alternate"] --wphave-site-color-tertiary
                    ]
                ],
                'accent' => [
                    'base' => $scheme_data['accent'] ?? WPHAVE_MAIN_COLOR_ACCENT, // --wphave-site-color-accent
                    'gradient' => self::get_default_design_gradient( 'accent' ),
                    'colorMode' => [
                        'base' => '#ffd96a' // [data-wphave-color-mode="alternate"] --wphave-site-color-accent
                    ]
                ],
                'error' => [
                    'base' => $scheme_data['error'] ?? '#d63638', // --wphave-site-color-error
                    'colorMode' => [
                        'base' => '#ff6b6b' // [data-wphave-color-mode="alternate"] --wphave-site-color-error
                    ]
                ],
                'text' => [
                    'base' => $scheme_data['text'] ?? '#4a4947', // --wphave-site-color-text
                    'colorMode' => [
                        'base' => '#ffffff' // [data-wphave-color-mode="alternate"] --wphave-site-color-text
                    ]
                ],
                'heading' => [
                    'base' => $scheme_data['heading'] ?? WPHAVE_MAIN_COLOR, // --wphave-site-color-heading
                    'colorMode' => [
                        'base' => '#ffffff' // [data-wphave-color-mode="alternate"] --wphave-site-color-heading
                    ]
                ],
                'background' => [
                    'base' => $scheme_data['background'] ?? '#ffffff', // --wphave-site-color-background
                    'colorMode' => [
                        'base' => '#1c1d1f' // [data-wphave-color-mode="alternate"] --wphave-site-color-background
                    ]
                ],
                'icon' => [
                    'base' => $scheme_data['icon'] ?? 'var(--wphave-site-color-text)' // --wphave-site-color-icon
                ],
                'tooltip' => [
                    'base' => $scheme_data['tooltip'] ?? WPHAVE_MAIN_COLOR // --wphave-site-color-tooltip
                ],
                'tooltipText' => [
                    'base' => $scheme_data['tooltipText'] ?? '#ffffff' // --wphave-site-color-tooltip-text
                ],
                'overlay' => [
                    'base' => $scheme_data['overlay'] ?? '#000000' // --wphave-site-color-overlay
                ],
                'price' => [
                    'base' => $scheme_data['price'] ?? WPHAVE_MAIN_COLOR_ACCENT // --wphave-site-color-price
                ]
            ],
            'typography' => [
                'text' => [
                    'font' => 'base',
                    'size' => [
                        'custom' => [
                            'min' => '16px', // --wphave-site-typo-base-font-size-min (<-- ! Use "px" because pixels do not scale down by --wphave-site-size-ratio)
                            'max' => '0.85rem', // --wphave-site-typo-base-font-size-max
                        ]
                    ],
                    'family' => [
                        'name' => WPHAVE_Fonts::normalize_font('Poppins') // --wphave-site-typo-base-family
                    ],
                    'weight' => 400, // --wphave-site-typo-base-font-weight
                    'lineHeight' => '1.3', // --wphave-site-typo-base-line-height
                    'hyphens' => 'auto', // --wphave-site-typo-base-hyphens
                    'wordBreak' => 'break-word', // --wphave-site-typo-base-word-break
                    'textWrap' => 'pretty', // --wphave-site-typo-base-text-wrap
                    'wordSpacing' => 'normal', // --wphave-site-typo-base-word-spacing
                    'letterSpacing' => 'normal', // --wphave-site-typo-base-letter-spacing
                ],
                'headings' => [
                    'font' => 'base',
                    'size' => [
                        'custom' => [
                            'min' => '20px', // --wphave-site-typo-headings-font-size-min (<-- ! Use "px" because pixels do not scale down by --wphave-site-size-ratio)
                            'max' => '2rem', // --wphave-site-typo-headings-font-size-max
                        ]
                    ],
                    'family' => [
                        'name' => WPHAVE_Fonts::normalize_font('Inter') // --wphave-site-typo-headings-family
                    ],
                    'weight' => 800, // --wphave-site-typo-headings-font-weight
                    'lineHeight' => '1.15', // --wphave-site-typo-headings-line-height
                    'hyphens' => 'auto', // --wphave-site-typo-headings-hyphens
                    'wordBreak' => 'break-word', // --wphave-site-typo-headings-word-break
                    'textWrap' => 'balance', // --wphave-site-typo-headings-text-wrap
                    'wordSpacing' => 'normal', // --wphave-site-typo-headings-word-spacing
                    'letterSpacing' => 'normal', // --wphave-site-typo-headings-letter-spacing
                ]
            ],
            'links' => [
				'style' => 'default',
                'colors' => [
                    'text' => 'var(--wphave-site-color-accent)', // --wphave-site-color-link
                    'textHover' => 'var(--wphave-site-color-primary)' // --wphave-site-color-link-hover
                ],
            ],
            'buttons' => [
                'primary' => [
                    'size' => '0',
                    'padding' => '', // <-- No default padding set (controlled via CSS by default)
                    'borderWidth' => '2px',
                    'borderRadius' => '50px',
                    'colors' => [
                        'text' => '#fff',
                        'textHover' => '#fff',
                        'border' => 'var(--wphave-site-color-accent)',
                        'borderHover' => 'var(--wphave-site-color-primary)',
                        'background' => 'var(--wphave-site-color-accent)',
                        'backgroundHover' => 'var(--wphave-site-color-primary)'
                    ]
                ],
                'secondary' => [
                    'size' => '0',
                    'padding' => '', // <-- No default padding set (controlled via CSS by default)
                    'borderWidth' => '2px',
                    'borderRadius' => '50px',
                    'colors' => [
                        'text' => '#fff',
                        'textHover' => '#fff',
                        'border' => 'var(--wphave-site-color-secondary)',
                        'borderHover' => 'var(--wphave-site-color-secondary)',
                        'background' => 'var(--wphave-site-color-secondary)',
                        'backgroundHover' => 'var(--wphave-site-color-accent)'
                    ]
                ],
                'tertiary' => [
                    'size' => '0',
                    'padding' => '', // <-- No default padding set (controlled via CSS by default)
                    'borderWidth' => '2px',
                    'borderRadius' => '50px',
                    'colors' => [
                        'text' => $scheme_data['text'] ?? '#4a4947',
                        'textHover' => $scheme_data['text'] ?? '#4a4947',
                        'border' => 'var(--wphave-site-color-accent)',
                        'borderHover' => 'var(--wphave-site-color-primary)',
                        'background' => 'rgba(0,0,0,0)',
                        'backgroundHover' => 'var(--wphave-site-color-primary)'
                    ]
                ],
                'ghost' => [
                    'size' => '0',
                    'padding' => '', // <-- No default padding set (controlled via CSS by default)
                    'borderWidth' => '2px',
                    'borderRadius' => '50px',
                    'colors' => [
                        'text' => $scheme_data['text'] ?? '#4a4947',
                        'textHover' => $scheme_data['text'] ?? '#4a4947',
                        'border' => 'rgba(0,0,0,0)',
                        'borderHover' => 'var(--wphave-site-color-primary)',
                        'background' => 'rgba(0,0,0,0)',
                        'backgroundHover' => 'var(--wphave-site-color-primary)'
                    ]
                ],
            ],
            'forms' => [
                'size' => '2',
                'borderWidth' => '1px',
                'borderRadius' => '2px',
                'colors' => [
                    'text' => 'var(--wphave-site-color-text)',
                    //'textHover' => 'var(--wphave-site-color-text)',
                    'textHover' => '',
					'placeholder' => 'var(--wphave-site-color-text-subtle-5)',
                    'border' => 'var(--wphave-site-color-primary)',
                    'borderHover' => 'var(--wphave-site-color-accent)',
                    'background' => '',
                    'backgroundHover' => ''
                ]
            ],
            'advanced' => [],
            'colorMode' => [
                'enabled' => false,
                'preset' => [],
                'preference' => 'default'
            ],
            'colorContexts' => []
        );

		return $defaults;
    }

    /**
     * Recursively merges user settings with defaults.
     *
     * - Preserves user values
     * - Fills missing values with defaults
     *
     * @param array $globals
     * @param array $defaults
     * @return array
     */

    public static function merge_globals( $globals = [], $defaults = [] ) {
        if( ! is_array( $globals ) || empty( $globals ) ) {
            $globals = [];
        }

        foreach( $defaults as $key => $value ) {
            // Überprüfen, ob der Schlüssel existiert und nicht leer ist
            if( ! array_key_exists($key, $globals) || $globals[$key] === null ) {
                $globals[$key] = $value; // Setze den Standardwert
            } elseif( is_array($value) ) {
                // Rekursiv für verschachtelte Arrays
                $globals[$key] = self::merge_globals( $globals[$key], $value );
            }
        }

        return $globals;
    }

    /**
     * Combines:
     * - User settings
     * - Default settings
     *
     * → Returns final usable design system
     *
     * @return array
     */

    public static function get_base( $wphave = [] ) {
        $globals = $wphave['settings'] ?? wphave_data_get( 'site_globals' ) ?? [];
        $defaults = self::get_defaults( $globals );
        $wphave = self::merge_globals( $globals, $defaults );

        return $wphave;
    }

    /**
     * Maps data structure → CSS variables.
     *
     * Example:
     *   layout.width → --wphave-site-content-width
     *
     * @return array
     */

    private static function get_css_variable_map() {
        return [
            'layout' => [
                'width' => 'var(--wphave-site-content-width)',
                'wideWidth' => 'var(--wphave-site-width-wide)',
                'mediumWidth' => 'var(--wphave-site-width-medium)',
                'narrowWidth' => 'var(--wphave-site-width-narrow)',
                'spacing' => 'var(--wphave-site-spacing)',
                'padding' => 'var(--wphave-site-padding)',
                'paddingTop' => 'var(--wphave-site-padding-top)',
                'paddingRight' => 'var(--wphave-site-padding-right)',
                'paddingBottom' => 'var(--wphave-site-padding-bottom)',
                'paddingLeft' => 'var(--wphave-site-padding-left)',
                'sizeRatio' => 'var(--wphave-site-size-ratio)',
                'regionMargin' => 'var(--wphave-site-region-margin)',
                'margin' => 'var(--wphave-site-margin)',
                'layoutGap' => 'var(--wphave-site-layout-gap)',
                'corners' => 'var(--wphave-site-corners)'
            ],
            'frame' => [
                'width' => 'var(--wphave-site-frame-width)',
                'style' => 'var(--wphave-site-frame-style)',
                'color' => 'var(--wphave-site-frame-color)',
            ],
            'colors' => [
                'primary' => [
                    'base' => 'var(--wphave-site-color-primary)'
                ],
                'secondary' => [
                    'base' => 'var(--wphave-site-color-secondary)'
                ],
                'tertiary' => [
                    'base' => 'var(--wphave-site-color-tertiary)'
                ],
                'accent' => [
                    'base' => 'var(--wphave-site-color-accent)'
                ],
                'text' => [
                    'base' => 'var(--wphave-site-color-text)'
                ],
                'heading' => [
                    'base' => 'var(--wphave-site-color-heading)'
                ],
                'background' => [
                    'base' => 'var(--wphave-site-color-background)'
                ],
                'icon' => [
                    'base' => 'var(--wphave-site-color-icon)'
                ],
                'tooltip' => [
                    'base' => 'var(--wphave-site-color-tooltip)'
                ],
                'tooltipText' => [
                    'base' => 'var(--wphave-site-color-tooltip-text)'
                ],
                'overlay' => [
                    'base' => 'var(--wphave-site-color-overlay)'
                ],
                'price' => [
                    'base' => 'var(--wphave-site-color-price)'
                ]
            ],
            'typography' => [
                'text' => [
                    'family' => [
                        'name' => 'var(--wphave-site-typo-base-family)'
                    ],
                    'size' => [
                        'custom' => [
                            'min' => 'var(--wphave-site-typo-base-font-size-min)',
                            'max' => 'var(--wphave-site-typo-base-font-size-max)'
                        ]
                    ],
                    'weight' => 'var(--wphave-site-typo-base-font-weight)',
                    'lineHeight' => 'var(--wphave-site-typo-base-line-height)',
                    'hyphens' => 'var(--wphave-site-typo-base-hyphens)',
                    'wordBreak' => 'var(--wphave-site-typo-base-word-break)',
                    'textWrap' => 'var(--wphave-site-typo-base-text-wrap)',
                    'wordSpacing' => 'var(--wphave-site-typo-base-word-spacing)',
                    'letterSpacing' => 'var(--wphave-site-typo-base-letter-spacing)',
                ],
                'headings' => [
                    'family' => [
                        'name' => 'var(--wphave-site-typo-headings-family)'
                    ],
                    'size' => [
                        'custom' => [
                            'min' => 'var(--wphave-site-typo-headings-font-size-min)',
                            'max' => 'var(--wphave-site-typo-headings-font-size-max)'
                        ]
                    ],
                    'weight' => 'var(--wphave-site-typo-headings-font-weight)',
                    'lineHeight' => 'var(--wphave-site-typo-headings-line-height)',
                    'hyphens' => 'var(--wphave-site-typo-headings-hyphens)',
                    'wordBreak' => 'var(--wphave-site-typo-headings-word-break)',
                    'textWrap' => 'var(--wphave-site-typo-headings-text-wrap)',
                    'wordSpacing' => 'var(--wphave-site-typo-headings-word-spacing)',
                    'letterSpacing' => 'var(--wphave-site-typo-headings-letter-spacing)',
                ]
            ],
            'links' => [
                'colors' => [
                    'text' => 'var(--wphave-site-color-link)',
                    'textHover' => 'var(--wphave-site-color-link-hover)'
                ],
            ],
            'buttons' => [
                'primary' => [
                    'size' => 'var(--wphave-site-button-size)',
                    'padding' => 'var(--wphave-site-button-padding)',
                    'borderWidth' => 'var(--wphave-site-button-border-width)',
                    'borderRadius' => 'var(--wphave-site-button-radius)',
                    'colors' => [
                        'text' => 'var(--wphave-site-color-button)',
                        'textHover' => 'var(--wphave-site-color-button-hover)',
                        'border' => 'var(--wphave-site-color-button-border)',
                        'borderHover' => 'var(--wphave-site-color-button-border-hover)',
                        'background' => 'var(--wphave-site-color-button-background)',
                        'backgroundHover' => 'var(--wphave-site-color-button-background-hover)'
                    ]
                ],
                'secondary' => [
                    'size' => 'var(--wphave-site-button-secondary-size)',
                    'padding' => 'var(--wphave-site-button-secondary-padding)',
                    'borderWidth' => 'var(--wphave-site-button-secondary-border-width)',
                    'borderRadius' => 'var(--wphave-site-button-secondary-radius)',
                    'colors' => [
                        'text' => 'var(--wphave-site-color-button-secondary)',
                        'textHover' => 'var(--wphave-site-color-button-secondary-hover)',
                        'border' => 'var(--wphave-site-color-button-secondary-border)',
                        'borderHover' => 'var(--wphave-site-color-button-secondary-border-hover)',
                        'background' => 'var(--wphave-site-color-button-secondary-background)',
                        'backgroundHover' => 'var(--wphave-site-color-button-secondary-background-hover)'
                    ]
                ],
                'tertiary' => [
                    'size' => 'var(--wphave-site-button-tertiary-size)',
                    'padding' => 'var(--wphave-site-button-tertiary-padding)',
                    'borderWidth' => 'var(--wphave-site-button-tertiary-border-width)',
                    'borderRadius' => 'var(--wphave-site-button-tertiary-radius)',
                    'colors' => [
                        'text' => 'var(--wphave-site-color-button-tertiary)',
                        'textHover' => 'var(--wphave-site-color-button-tertiary-hover)',
                        'border' => 'var(--wphave-site-color-button-tertiary-border)',
                        'borderHover' => 'var(--wphave-site-color-button-tertiary-border-hover)',
                        'background' => 'var(--wphave-site-color-button-tertiary-background)',
                        'backgroundHover' => 'var(--wphave-site-color-button-tertiary-background-hover)'
                    ]
                ],
                'ghost' => [
                    'size' => 'var(--wphave-site-button-ghost-size)',
                    'padding' => 'var(--wphave-site-button-ghost-padding)',
                    'borderWidth' => 'var(--wphave-site-button-ghost-border-width)',
                    'borderRadius' => 'var(--wphave-site-button-ghost-radius)',
                    'colors' => [
                        'text' => 'var(--wphave-site-color-button-ghost)',
                        'textHover' => 'var(--wphave-site-color-button-ghost-hover)',
                        'border' => 'var(--wphave-site-color-button-ghost-border)',
                        'borderHover' => 'var(--wphave-site-color-button-ghost-border-hover)',
                        'background' => 'var(--wphave-site-color-button-ghost-background)',
                        'backgroundHover' => 'var(--wphave-site-color-button-ghost-background-hover)'
                    ]
                ],
            ],
            'forms' => [
                'size' => 'var(--wphave-site-form-size)',
                'borderWidth' => 'var(--wphave-site-form-border-width)',
                'borderRadius' => 'var(--wphave-site-form-radius)',
                'colors' => [
                    'text' => 'var(--wphave-site-color-form)',
                    'textHover' => 'var(--wphave-site-color-form-hover)',
                    'placeholder' => 'var(--wphave-site-color-form-placeholder)',
                    'border' => 'var(--wphave-site-color-form-border)',
                    'borderHover' => 'var(--wphave-site-color-form-border-hover)',
                    'background' => 'var(--wphave-site-color-form-background)',
                    'backgroundHover' => 'var(--wphave-site-color-form-background-hover)'
                ]
            ],
            'advanced' => [

            ],
        ];
    }

     /**
      * Converts global settings into CSS variables.
      *
      * Output:
      * :root {
      *   --wphave-site-color-primary: #000;
      * }
      *
      * @param bool $root Wrap in :root selector
      * @param array $globals
      * @return string
      */

    public static function generate_css_variables( $root = true, $globals = [] ) {
        $variables = self::get_css_variable_map();
        $defaults = self::get_defaults( $globals );
        $button_inherited_keys = [
            'size' => true,
            'padding' => true,
            'borderWidth' => true,
            'borderRadius' => true
        ];

        foreach( ['secondary', 'tertiary', 'ghost'] as $variant ) {
            foreach( $button_inherited_keys as $key => $_ ) {
                $value = $globals['buttons'][$variant][$key] ?? null;
                $default_value = $defaults['buttons'][$variant][$key] ?? null;

                if( $value !== null && (string) $value === (string) $default_value ) {
                    unset( $globals['buttons'][$variant][$key] );
                }
            }
        }

        $css = [];

        if( $root ) {
            $css[] = ':root {';
        }

        // Rekursive Funktion zum Durchlaufen der Werte
        $parse_globals = function( $values, $variables ) use ( &$css, &$parse_globals ) {
            foreach( $values as $key => $value ) {
                if( is_array( $value ) ) {
                    $parse_globals($value, $variables[$key] ?? []);
                } elseif( isset( $variables[$key] ) && is_string( $variables[$key] ) && strpos( $variables[$key], 'var(--' ) === 0 ) {
                    // Falls ein Key exakt in der Struktur des Defaults übereinstimmt, wird er übernommen
                    $cleaned_var = preg_replace('/var\((.*?)\)/', '$1', $variables[$key]);
                    // Only if a value is set !
                    if( $cleaned_var && $value ) {
						if( in_array( $cleaned_var, array( '--wphave-site-typo-base-family', '--wphave-site-typo-headings-family' ), true ) ) {
							$value = WPHAVE_Fonts::normalize_font( $value );
						}
                        // CSS inside a <style> element is raw text: esc_attr() would
                        // turn quoted font families into literal &quot; tokens. Let
                        // WordPress validate the complete custom-property declaration
                        // while preserving valid CSS quotes and functions.
                        $declaration = safecss_filter_attr( $cleaned_var . ': ' . html_entity_decode( (string) $value, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
                        // safecss_filter_attr() validates the declaration but returns
                        // quotes HTML-encoded. Decode its validated output because the
                        // destination is CSS raw text, not an HTML attribute.
                        $declaration = html_entity_decode( $declaration, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
                        if( $declaration ) $css[] = rtrim( $declaration, ';' ) . ';';
                    }
                }
            }
        };

        // Starte die Rekursion
        $parse_globals( $globals, $variables );

        $tokens = array_replace_recursive( $defaults['tokens'] ?? [], $globals['tokens'] ?? [] );
        $token_groups = [
            'gapSizes' => '--wphave-site-gap-size-',
            'paddingSizes' => '--wphave-site-padding-',
            'marginSizes' => '--wphave-site-margin-',
            'cornerSizes' => '--wphave-site-corner-',
            'cornerPercentSizes' => '--wphave-site-corner-percent-',
            'borderSizes' => '--wphave-site-border-',
            'outlineSizes' => '--wphave-site-outline-'
        ];

        foreach( $token_groups as $group => $prefix ) {
            $items = $tokens[$group] ?? [];

            foreach( $items as $key => $value ) {
                $min = $value['min'] ?? '';
                $default_value = $value['value'] ?? '';

                if( $key && $min && $default_value ) {
                    $css[] = esc_attr( $prefix . $key ) . ': max(' . esc_attr( $min ) . ', ' . esc_attr( $default_value ) . ');';
                }
            }
        }

        if( $root ) {
            $css[] = '}';
        }

        return implode('', $css);
    }

    /**
     * Predefined color palettes.
     *
     * Used for:
     * - Theme presets
     * - Quick design switching
     *
     * @return array
     */

    public static function color_schemes() {
        $schemes = array(
            /*
            * Bright schemes
            */

            'default' => array(
                'primary' => '#20242c',
                'secondary' => '#667085',
                'tertiary' => '#e9ecf1',
                'accent' => '#4f5fdb',
                'text' => '#272b33',
                'heading' => '#20242c',
                'background' => '#fafaf8',
                'icon' => '#4f5fdb',
                'tooltip' => '#20242c',
                'tooltipText' => '#ffffff',
                'keywords' => array('bright')
            ),
            'iridescent_cloud' => array(
                'primary' => '#2b4f9d',
                'secondary' => '#e3969b',
                'tertiary' => '#825d87',
                'accent' => '#825d87',
                'text' => '#825d87',
                'heading' => '#2b4f9d',
                'background' => '#ecf4fb',
                'icon' => '#2b4f9d',
                'tooltip' => '#2b4f9d',
                'tooltipText' => '#ecf4fb',
                'keywords' => array('bright', 'pastel', 'colorful')
            ),
            'opal' => array(
                'primary' => '#aadee6',
                'secondary' => '#c1b5f2',
                'tertiary' => '#eebad7',
                'accent' => '#eebad7',
                'text' => '#473f65',
                'heading' => '#473f65',
                'background' => '#f6f9fe',
                'icon' => '#c1b5f2',
                'tooltip' => '#473f65',
                'tooltipText' => '#f6f9fe',
                'keywords' => array('bright', 'pastel', 'colorful')
            ),
            'lagoon' => array(
                'primary' => '#81e0e4',
                'secondary' => '#4699be',
                'tertiary' => '#2f4974',
                'accent' => '#2f4974',
                'text' => '#2f4974',
                'heading' => '#2f4974',
                'background' => '#edfaf7',
                'icon' => '#4699be',
                'tooltip' => '#2f4974',
                'tooltipText' => '#edfaf7',
                'keywords' => array('bright', 'pastel', 'colorful')
            ),
            'emerald' => array(
                'primary' => '#a2e1b4',
                'secondary' => '#5fc49d',
                'tertiary' => '#2a5e52',
                'accent' => '#2a5e52',
                'text' => '#2a5e52',
                'heading' => '#2a5e52',
                'background' => '#f2fbf0',
                'icon' => '#5fc49d',
                'tooltip' => '#2a5e52',
                'tooltipText' => '#f2fbf0',
                'keywords' => array('bright', 'pastel', 'colorful')
            ),
            'solar_flare' => array(
                'primary' => '#f6c561',
                'secondary' => '#e36f56',
                'tertiary' => '#80355d',
                'accent' => '#80355d',
                'text' => '#80355d',
                'heading' => '#80355d',
                'background' => '#fef7e1',
                'icon' => '#e36f56',
                'tooltip' => '#80355d',
                'tooltipText' => '#fef7e1',
                'keywords' => array('bright', 'colorful')
            ),
            'orchid' => array(
                'primary' => '#db98c6',
                'secondary' => '#9179c8',
                'tertiary' => '#47398f',
                'accent' => '#47398f',
                'text' => '#47398f',
                'heading' => '#47398f',
                'background' => '#f9effa',
                'icon' => '#9179c8',
                'tooltip' => '#47398f',
                'tooltipText' => '#f9effa',
                'keywords' => array('bright', 'pastel', 'colorful')
            ),
            'peach_glow' => array(
                'primary' => '#f6cba8',
                'secondary' => '#e28f8e',
                'tertiary' => '#aa628a',
                'accent' => '#aa628a',
                'text' => '#844b6b',
                'heading' => '#844b6b',
                'background' => '#fdf3ed',
                'icon' => '#e28f8e',
                'tooltip' => '#844b6b',
                'tooltipText' => '#fdf3ed',
                'keywords' => array('bright', 'pastel')
            ),
            'electric_tide' => array(
                'primary' => '#89d6ef',
                'secondary' => '#4e5bd8',
                'tertiary' => '#29244d',
                'accent' => '#29244d',
                'text' => '#29244d',
                'heading' => '#29244d',
                'background' => '#e5fafe',
                'icon' => '#4e5bd8',
                'tooltip' => '#29244d',
                'tooltipText' => '#e5fafe',
                'keywords' => array('bright', 'colorful')
            ),
            'sunset' => array(
                'primary' => '#f3b256',
                'secondary' => '#de6254',
                'tertiary' => '#572d63',
                'accent' => '#572d63',
                'text' => '#572d63',
                'heading' => '#572d63',
                'background' => '#fbeac8',
                'icon' => '#de6254',
                'tooltip' => '#572d63',
                'tooltipText' => '#fbeac8',
                'keywords' => array('bright', 'colorful')
            ),
            'mint_ice' => array(
                'primary' => '#b7eedd',
                'secondary' => '#74c8b1',
                'tertiary' => '#387860',
                'accent' => '#387860',
                'text' => '#285847',
                'heading' => '#285847',
                'background' => '#f4fcf9',
                'icon' => '#74c8b1',
                'tooltip' => '#285847',
                'tooltipText' => '#f4fcf9',
                'keywords' => array('bright', 'pastel')
            ),
            'midnight_bloom' => array(
                'primary' => '#49398f',
                'secondary' => '#ac88e2',
                'tertiary' => '#eec8e0',
                'accent' => '#eec8e0',
                'text' => '#eec8e0',
                'heading' => '#eec8e0',
                'background' => '#12132c',
                'icon' => '#ac88e2',
                'tooltip' => '#eec8e0',
                'tooltipText' => '#12132c',
                'keywords' => array('dark', 'pastel', 'colorful')
            ),
            'rose_gold' => array(
                'primary' => '#f3cbb0',
                'secondary' => '#dc9ea8',
                'tertiary' => '#875c73',
                'accent' => '#875c73',
                'text' => '#70495f',
                'heading' => '#70495f',
                'background' => '#fdf4e9',
                'icon' => '#dc9ea8',
                'tooltip' => '#70495f',
                'tooltipText' => '#fdf4e9',
                'keywords' => array('bright', 'pastel')
            ),
            'sienna' => array(
                'primary' => '#c98686',
                'secondary' => '#f2b880',
                'tertiary' => '#e7cfbc',
                'accent' => '#966b9d',
                'text' => '#746459',
                'heading' => '#746459',
                'background' => '#fff4ec',
                'icon' => '#966b9d',
                'tooltip' => '#000000',
                'tooltipText' => '#ffffff',
                'keywords' => array('bright', 'pastel')
            ),
            'serenity' => array(
                'primary' => '#9E99BC',
                'secondary' => '#b8bedd',
                'tertiary' => '#B0AECC',
                'accent' => '#83749a',
                'text' => '#5c5663',
                'heading' => '#5c5663',
                'background' => '#eeeae7',
                'icon' => '#83749a',
                'tooltip' => '#000000',
                'tooltipText' => '#ffffff',
                'keywords' => array('bright', 'pastel', 'neutral')
            ),
            'elegance' => array(
                'primary' => '#eedacd',
                'secondary' => '#bfb9ab',
                'tertiary' => '#424d52',
                'accent' => '#80b3aa',
                'text' => '#67635a',
                'heading' => '#67635a',
                'background' => '#f9f2ec',
                'icon' => '#80b3aa',
                'tooltip' => '#000000',
                'tooltipText' => '#ffffff',
                'keywords' => array('bright', 'pastel')
            ),
            'sandy' => array(
                'primary' => '#d1b084',
                'secondary' => '#E6D5BE',
                'tertiary' => '#DBC3A1',
                'accent' => '#7cacb3',
                'text' => '#6c6559',
                'heading' => '#6c6559',
                'background' => '#fbfbf9',
                'icon' => '#7cacb3',
                'tooltip' => '#000000',
                'tooltipText' => '#ffffff',
                'keywords' => array('bright', 'pastel')
            ),
            'blueberry' => array(
                'primary' => '#1e477f',
                'secondary' => '#A1B5D8',
                'tertiary' => '#5F7EAB',
                'accent' => '#1e477f',
                'text' => '#70747b',
                'heading' => '#70747b',
                'background' => '#eef2f8',
                'icon' => '#1e477f',
                'tooltip' => '#000000',
                'tooltipText' => '#ffffff',
                'keywords' => array('bright', 'pastel', 'monochrome')
            ),
            'rose' => array(
                'primary' => '#773243',
                'secondary' => '#dec3c3',
                'tertiary' => '#AA7A83',
                'accent' => '#773243',
                'text' => '#626060',
                'heading' => '#626060',
                'background' => '#f9f4f4',
                'icon' => '#773243',
                'tooltip' => '#000000',
                'tooltipText' => '#ffffff',
                'keywords' => array('bright', 'pastel', 'monochrome')
            ),
            'cold_ember' => array(
                'primary' => '#8d99ae',
                'secondary' => '#2b2d42',
                'tertiary' => '#5C6378',
                'accent' => '#c82d3f',
                'text' => '#484848',
                'heading' => '#484848',
                'background' => '#edf2f4',
                'icon' => '#c82d3f',
                'tooltip' => '#000000',
                'tooltipText' => '#ffffff',
                'keywords' => array('bright')
            ),
            'terracotta' => array(
                'primary' => '#4E3B31',
                'secondary' => '#DFD3C3',
                'tertiary' => '#D0B8A8',
                'accent' => '#795869',
                'text' => '#64535c',
                'heading' => '#64535c',
                'background' => '#f2ede8',
                'icon' => '#795869',
                'tooltip' => '#000000',
                'tooltipText' => '#ffffff',
                'keywords' => array('bright', 'pastel')
            ),
            'lavender' => array(
                'primary' => '#A6B1E1',
                'secondary' => '#ddd9f2',
                'tertiary' => '#C1C4EC',
                'accent' => '#424874',
                'text' => '#6c7087',
                'heading' => '#6c7087',
                'background' => '#f5f1fe',
                'icon' => '#6c7087',
                'tooltip' => '#000000',
                'tooltipText' => '#ffffff',
                'keywords' => array('bright', 'pastel', 'monochrome')
            ),
            'snug' => array(
                'primary' => '#4E3B31',
                'secondary' => '#624f45',
                'tertiary' => '#4e4a52',
                'accent' => '#3a4660',
                'text' => '#5d5956',
                'heading' => '#5d5956',
                'background' => '#d5cbbd',
                'icon' => '#3a4660',
                'tooltip' => '#000000',
                'tooltipText' => '#ffffff',
                'keywords' => array('bright')
            ),
            'coastal' => array(
                'primary' => '#efe9e6',
                'secondary' => '#4d4d4c',
                'tertiary' => '#49596A',
                'accent' => '#456587',
                'text' => '#5b5041',
                'heading' => '#5b5041',
                'background' => '#e2c68d',
                'icon' => '#456587',
                'tooltip' => '#000000',
                'tooltipText' => '#ffffff',
                'keywords' => array('colorful')
            ),
            'atelier' => array(
                'primary' => '#1f2937',
                'secondary' => '#d6c7b5',
                'tertiary' => '#efe8de',
                'accent' => '#b7795b',
                'text' => '#4b5563',
                'heading' => '#111827',
                'background' => '#faf7f2',
                'icon' => '#b7795b',
                'tooltip' => '#111827',
                'tooltipText' => '#ffffff',
                'keywords' => array('bright', 'modern', 'minimal', 'editorial', 'neutral')
            ),
            'signal' => array(
                'primary' => '#0f172a',
                'secondary' => '#334155',
                'tertiary' => '#e2e8f0',
                'accent' => '#2563eb',
                'text' => '#475569',
                'heading' => '#0f172a',
                'background' => '#f8fafc',
                'icon' => '#2563eb',
                'tooltip' => '#0f172a',
                'tooltipText' => '#ffffff',
                'keywords' => array('bright', 'modern', 'saas', 'minimal', 'monochrome')
            ),
            'mintlab' => array(
                'primary' => '#123c3a',
                'secondary' => '#d8f3dc',
                'tertiary' => '#b7e4c7',
                'accent' => '#2d6a4f',
                'text' => '#3f4f46',
                'heading' => '#123c3a',
                'background' => '#f6fbf7',
                'icon' => '#2d6a4f',
                'tooltip' => '#123c3a',
                'tooltipText' => '#ffffff',
                'keywords' => array('bright', 'modern', 'organic', 'pastel')
            ),
            'clay' => array(
                'primary' => '#3f2f2c',
                'secondary' => '#d7b49e',
                'tertiary' => '#ead2c3',
                'accent' => '#a35d3a',
                'text' => '#594b45',
                'heading' => '#3f2f2c',
                'background' => '#f8efe8',
                'icon' => '#a35d3a',
                'tooltip' => '#3f2f2c',
                'tooltipText' => '#ffffff',
                'keywords' => array('bright', 'modern', 'craft', 'warm')
            ),
            'blush' => array(
                'primary' => '#3b2630',
                'secondary' => '#f8d7da',
                'tertiary' => '#fde2e4',
                'accent' => '#d45d79',
                'text' => '#5f4b53',
                'heading' => '#3b2630',
                'background' => '#fff7f8',
                'icon' => '#d45d79',
                'tooltip' => '#3b2630',
                'tooltipText' => '#ffffff',
                'keywords' => array('bright', 'modern', 'boutique', 'soft')
            ),
            'studio_mist' => array(
                'primary' => '#24313f',
                'secondary' => '#d8dee6',
                'tertiary' => '#edf1f5',
                'accent' => '#6a8f8a',
                'text' => '#48515b',
                'heading' => '#1d2733',
                'background' => '#f7f8fa',
                'icon' => '#6a8f8a',
                'tooltip' => '#1d2733',
                'tooltipText' => '#ffffff',
                'keywords' => array('bright', 'modern', 'studio', 'neutral')
            ),
            'friendly_peach' => array(
                'primary' => '#334155',
                'secondary' => '#ffd9c7',
                'tertiary' => '#fff0e6',
                'accent' => '#f9735b',
                'text' => '#5f534c',
                'heading' => '#334155',
                'background' => '#fff8f3',
                'icon' => '#f9735b',
                'tooltip' => '#334155',
                'tooltipText' => '#ffffff',
                'keywords' => array('bright', 'modern', 'friendly', 'warm', 'soft')
            ),
            'minimal_ink' => array(
                'primary' => '#111111',
                'secondary' => '#e5e7eb',
                'tertiary' => '#f3f4f6',
                'accent' => '#64748b',
                'text' => '#4b5563',
                'heading' => '#111111',
                'background' => '#fbfbfa',
                'icon' => '#64748b',
                'tooltip' => '#111111',
                'tooltipText' => '#ffffff',
                'keywords' => array('bright', 'modern', 'minimal', 'monochrome')
            ),
            'champagne_noir' => array(
                'primary' => '#171412',
                'secondary' => '#d8c7a3',
                'tertiary' => '#eee6d6',
                'accent' => '#b88a44',
                'text' => '#5a5145',
                'heading' => '#171412',
                'background' => '#fbf8f0',
                'icon' => '#b88a44',
                'tooltip' => '#171412',
                'tooltipText' => '#ffffff',
                'keywords' => array('bright', 'modern', 'luxury', 'editorial')
            ),
            'playful_pop' => array(
                'primary' => '#25215f',
                'secondary' => '#ffe066',
                'tertiary' => '#b8f7d4',
                'accent' => '#ff4d8d',
                'text' => '#3f3d56',
                'heading' => '#25215f',
                'background' => '#fffaf0',
                'icon' => '#ff4d8d',
                'tooltip' => '#25215f',
                'tooltipText' => '#ffffff',
                'keywords' => array('bright', 'modern', 'playful', 'colorful')
            ),

            /*
            * Dark schemes
            */

            'dark' => array(
                'primary' => '#4A484C',
                'secondary' => '#423d46',
                'tertiary' => '#2E2D2F',
                'accent' => '#956ac8',
                'text' => '#f5eff6',
                'heading' => '#f5eff6',
                'background' => '#131313',
                'icon' => '#956ac8',
                'tooltip' => '#000000',
                'tooltipText' => '#ffffff',
                'keywords' => array('dark')
            ),
            'dark_horse' => array(
                'primary' => '#393f4d',
                'secondary' => '#4A4E56',
                'tertiary' => '#414651',
                'accent' => '#ffd96a',
                'text' => '#f6f4ef',
                'heading' => '#f6f4ef',
                'background' => '#1c1d1f',
                'icon' => '#ffd96a',
                'tooltip' => '#000000',
                'tooltipText' => '#ffffff',
                'keywords' => array('dark')
            ),
            'dark_light' => array(
                'primary' => '#484848',
                'secondary' => '#6E6E6E',
                'tertiary' => '#5B5B5B',
                'accent' => '#46beae',
                'text' => '#f2f2f2',
                'heading' => '#f2f2f2',
                'background' => '#333',
                'icon' => '#46beae',
                'tooltip' => '#000000',
                'tooltipText' => '#ffffff',
                'keywords' => array('dark')
            ),
            'midnight_lagoon' => array(
                'primary' => '#1c2541',
                'secondary' => '#3a506b',
                'tertiary' => '#5bc0be',
                'accent' => '#86eadb',
                'text' => '#e1e3f4',
                'heading' => '#e1e3f4',
                'background' => '#0b132b',
                'icon' => '#86eadb',
                'tooltip' => '#000000',
                'tooltipText' => '#ffffff',
                'keywords' => array('dark')
            ),
            'nightfall' => array(
                'primary' => '#322f2b',
                'secondary' => '#857c80',
                'tertiary' => '#918c87',
                'accent' => '#e8cd7b',
                'text' => '#f5f4ed',
                'heading' => '#f5f4ed',
                'background' => '#1c171b',
                'icon' => '#e8cd7b',
                'tooltip' => '#000000',
                'tooltipText' => '#ffffff',
                'keywords' => array('dark')
            ),
            'dark_blue' => array(
                'primary' => '#474872',
                'secondary' => '#8288a3',
                'tertiary' => '#64688A',
                'accent' => '#d10138',
                'text' => '#f0f2ff',
                'heading' => '#f0f2ff',
                'background' => '#0c0841',
                'icon' => '#d10138',
                'tooltip' => '#000000',
                'tooltipText' => '#ffffff',
                'keywords' => array('dark')
            ),
            'double_blue' => array(
                'primary' => '#007CC7',
                'secondary' => '#203647',
                'tertiary' => '#105987',
                'accent' => '#007CC7',
                'text' => '#e8f0f3',
                'heading' => '#e8f0f3',
                'background' => '#12232E',
                'icon' => '#007CC7',
                'tooltip' => '#000000',
                'tooltipText' => '#ffffff',
                'keywords' => array('dark')
            ),
            'moonlit' => array(
                'primary' => '#5C5470',
                'secondary' => '#B9B4C7',
                'tertiary' => '#8B849C',
                'accent' => '#FAF0E6',
                'text' => '#e6e6e6',
                'heading' => '#e6e6e6',
                'background' => '#352F44',
                'icon' => '#FAF0E6',
                'tooltip' => '#000000',
                'tooltipText' => '#ffffff',
                'keywords' => array('dark', 'neutral', 'monochrome')
            ),
            'cactus' => array(
                'primary' => '#4D774E',
                'secondary' => '#3F6C4B',
                'tertiary' => '#316148',
                'accent' => '#F1B24A',
                'text' => '#edfff2',
                'heading' => '#edfff2',
                'background' => '#164A41',
                'icon' => '#F1B24A',
                'tooltip' => '#000000',
                'tooltipText' => '#ffffff',
                'keywords' => array('colorful')
            ),
            'bubblegum' => array(
                'primary' => '#4D3082',
                'secondary' => '#673ab7',
                'tertiary' => '#5A359C',
                'accent' => '#f56161',
                'text' => '#dbcfef',
                'heading' => '#dbcfef',
                'background' => '#33264E',
                'icon' => '#f56161',
                'tooltip' => '#000000',
                'tooltipText' => '#ffffff',
                'keywords' => array('colorful')
            ),
            'mocha' => array(
                'primary' => '#322c28',
                'secondary' => '#B39B84',
                'tertiary' => '#726356',
                'accent' => '#1e477f',
                'text' => '#eae4dd',
                'heading' => '#eae4dd',
                'background' => '#5e564e',
                'icon' => '#1e477f',
                'tooltip' => '#000000',
                'tooltipText' => '#ffffff',
                'keywords' => array('colorful')
            ),
            'sunflower' => array(
                'primary' => '#9a031e',
                'secondary' => '#0f4c5c',
                'tertiary' => '#e36414',
                'accent' => '#e08229',
                'text' => '#ebd7e3',
                'heading' => '#ebd7e3',
                'background' => '#5f0f40',
                'icon' => '#e08229',
                'tooltip' => '#000000',
                'tooltipText' => '#ffffff',
                'keywords' => array('colorful')
            ),
            'retro_romance' => array(
                'primary' => '#b56576',
                'secondary' => '#6d597a',
                'tertiary' => '#e56b6f',
                'accent' => '#eaac8b',
                'text' => '#eaeaea',
                'heading' => '#eaeaea',
                'background' => '#355070',
                'icon' => '#eaac8b',
                'tooltip' => '#000000',
                'tooltipText' => '#ffffff',
                'keywords' => array('colorful')
            ),
            'obsidian' => array(
                'primary' => '#111827',
                'secondary' => '#1f2937',
                'tertiary' => '#374151',
                'accent' => '#38bdf8',
                'text' => '#e5e7eb',
                'heading' => '#f9fafb',
                'background' => '#030712',
                'icon' => '#38bdf8',
                'tooltip' => '#000000',
                'tooltipText' => '#ffffff',
                'keywords' => array('dark', 'modern', 'saas', 'minimal', 'noir')
            ),
            'electric_plum' => array(
                'primary' => '#2e1065',
                'secondary' => '#4c1d95',
                'tertiary' => '#6d28d9',
                'accent' => '#22d3ee',
                'text' => '#ede9fe',
                'heading' => '#ffffff',
                'background' => '#16052e',
                'icon' => '#22d3ee',
                'tooltip' => '#000000',
                'tooltipText' => '#ffffff',
                'keywords' => array('dark', 'modern', 'vibrant', 'colorful')
            ),
            'forest_noir' => array(
                'primary' => '#0f2f24',
                'secondary' => '#224c3d',
                'tertiary' => '#356859',
                'accent' => '#c6f6d5',
                'text' => '#e3f5ea',
                'heading' => '#f4fff8',
                'background' => '#081c15',
                'icon' => '#c6f6d5',
                'tooltip' => '#000000',
                'tooltipText' => '#ffffff',
                'keywords' => array('dark', 'modern', 'organic')
            ),
            'deep_sea' => array(
                'primary' => '#0b2545',
                'secondary' => '#134074',
                'tertiary' => '#13315c',
                'accent' => '#8ecae6',
                'text' => '#d8eef8',
                'heading' => '#f7fbff',
                'background' => '#061826',
                'icon' => '#8ecae6',
                'tooltip' => '#000000',
                'tooltipText' => '#ffffff',
                'keywords' => array('dark', 'modern', 'deep', 'calm')
            ),
            'ruby_night' => array(
                'primary' => '#3b0714',
                'secondary' => '#881337',
                'tertiary' => '#9f1239',
                'accent' => '#fb7185',
                'text' => '#ffe4e6',
                'heading' => '#fff1f2',
                'background' => '#19040a',
                'icon' => '#fb7185',
                'tooltip' => '#000000',
                'tooltipText' => '#ffffff',
                'keywords' => array('dark', 'modern', 'boutique', 'dramatic')
            ),
            'ultraviolet' => array(
                'primary' => '#312e81',
                'secondary' => '#4338ca',
                'tertiary' => '#6366f1',
                'accent' => '#f0abfc',
                'text' => '#e0e7ff',
                'heading' => '#ffffff',
                'background' => '#11103a',
                'icon' => '#f0abfc',
                'tooltip' => '#000000',
                'tooltipText' => '#ffffff',
                'keywords' => array('dark', 'modern', 'creative', 'vibrant')
            ),
        );

		return $schemes;
	}
}
