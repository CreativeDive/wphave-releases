<?php

/**
 * Builds template selection data consumed by the management UI.
 */

trait WPHAVE_Template_Catalog {
	/**
	 * Base app groups with stable ids expected by the template selection UI.
	 *
	 * @return array
	 */

	private static function get_base_template_groups() {
		return [
			'postTypesAll' => array_merge(
				[
					'id' => 'single',
					'icon' => '',
					'label' => __('All Single Content', 'wphave'),
					'description' => __(
						'Default layout for single posts and custom content types when no more specific template exists.',
						'wphave',
					),
					'used_for' => 'is_single()',
				],
				wphave_template_starter_contract('singular'),
			),
			'pagesAll' => array_merge(
				[
					'id' => 'post_type_page',
					'icon' => 'pages',
					'label' => __('All Pages', 'wphave'),
					'description' => __(
						'Default layout for regular pages when no special page template applies.',
						'wphave',
					),
				],
				wphave_template_starter_contract('page'),
			),
			'pages' => [
				array_merge(
					[
						'id' => 'homepage',
						'icon' => 'home',
						'label' => __('Homepage', 'wphave'),
						'description' => __(
							'Layout for the front page visitors see first.',
							'wphave',
						),
						'used_for' => 'is_front_page()',
					],
					wphave_template_starter_contract('page'),
				),
				array_merge(
					[
						'id' => 'search',
						'icon' => 'search',
						'label' => __('Search', 'wphave'),
						'description' => __('Layout for search result pages.', 'wphave'),
						'used_for' => 'is_search()',
					],
					wphave_template_starter_contract('system_search'),
				),
				array_merge(
					[
						'id' => '404_page',
						'icon' => 'alert',
						'label' => __('Not Found', 'wphave'),
						'description' => __(
							'Layout shown when a visitor opens a page that does not exist.',
							'wphave',
						),
						'used_for' => 'is_404()',
					],
					wphave_template_starter_contract('system_not_found'),
				),
				array_merge(
					[
						'id' => 'privacy_policy',
						'icon' => 'privacy',
						'label' => __('Privacy Policy', 'wphave'),
						'description' => __(
							'Optional dedicated layout for the WordPress privacy policy page.',
							'wphave',
						),
						'used_for' => 'is_privacy_policy()',
					],
					wphave_template_starter_contract('page'),
				),
				array_merge(
					[
						'id' => 'protected',
						'icon' => 'locked',
						'label' => __('Password Protected', 'wphave'),
						'description' => __(
							'Layout shown before visitors enter the password for protected content.',
							'wphave',
						),
						'used_for' => 'post_password_required()',
					],
					wphave_template_starter_contract('system_protected'),
				),
			],
			'archivesAll' => array_merge(
				[
					'id' => 'archive',
					'icon' => '',
					'label' => __('All Archives', 'wphave'),
					'description' => __(
						'Default layout for archive, taxonomy, date and author listings when no more specific archive template exists.',
						'wphave',
					),
				],
				wphave_template_starter_contract('archive'),
			),
			'customNew' => array_merge(
				[
					'id' => 'custom',
					'icon' => 'plus',
					'label' => __('Custom Template', 'wphave'),
					'description' => __(
						'Create a reusable layout that can be assigned manually to individual posts or pages.',
						'wphave',
					),
				],
				wphave_template_starter_contract('custom'),
			),
			'system' => [
				array_merge(
					[
						'id' => 'attachment',
						'icon' => 'image',
						'label' => __('Media Pages', 'wphave'),
						'description' => __(
							'Layout for individual images, videos, audio and file attachments.',
							'wphave',
						),
						'used_for' => 'is_attachment()',
					],
					wphave_template_starter_contract('attachment'),
				),
				array_merge(
					[
						'id' => 'subscriber_confirmation',
						'icon' => 'mail',
						'label' => __('Subscriber Confirmation', 'wphave'),
						'description' => __(
							'Layout for the public confirmation page shown after a subscriber confirms by email.',
							'wphave',
						),
						'used_for' => 'wphave/confirm-subscription',
					],
					wphave_template_starter_contract('subscriber_confirmation'),
				),
			],
			'woocommerce' => [],
		];
	}

	/**
	 * Attach active template records to the static app groups.
	 *
	 * @param array $data App data.
	 * @param array $template_lookup Active template lookup keyed by template id.
	 * @return array
	 */

	private static function add_active_template_flags($data, $template_lookup) {
		$data['postTypesAll']['template'] = self::get_active_template_from_lookup(
			$data['postTypesAll']['id'],
			$template_lookup,
		);
		$data['pagesAll']['template'] = self::get_active_template_from_lookup(
			$data['pagesAll']['id'],
			$template_lookup,
		);
		$data['archivesAll']['template'] = self::get_active_template_from_lookup(
			$data['archivesAll']['id'],
			$template_lookup,
		);

		foreach ($data['pages'] as $key => $page) {
			$data['pages'][$key]['template'] = self::get_active_template_from_lookup(
				$page['id'],
				$template_lookup,
			);
		}

		foreach ($data['system'] as $key => $template) {
			$data['system'][$key]['template'] = self::get_active_template_from_lookup(
				$template['id'],
				$template_lookup,
			);
		}

		return $data;
	}

	/**
	 * Build app items for post-type-specific templates.
	 *
	 * @param array $template_lookup Active template lookup keyed by template id.
	 * @return array
	 */

	private static function get_post_type_template_items($template_lookup) {
		$items = [];
		$template_post_types = self::get_template_post_types(['data' => true]);

		foreach ($template_post_types as $slug => $post_type) {
			if ($slug === 'product' || $slug === 'page') {
				continue;
			}

			$template_id = 'post_type_' . $slug;
			$recommended_variant = 'post' === $slug ? 'post-editorial' : 'content-standard';
			$items[$slug] = array_merge(
				[
					'id' => $template_id,
					'icon' => '',
					'label' => $post_type->label ?? 'n/a',
					'description' => sprintf(
						/* translators: %s: post type label. */
						__(
							'Layout for individual %s entries. Used before the global single content template.',
							'wphave',
						),
						$post_type->labels->singular_name ??
							($post_type->label ?? __('content', 'wphave')),
					),
					'template' => self::get_active_template_from_lookup(
						$template_id,
						$template_lookup,
					),
				],
				wphave_template_starter_contract('singular', [
					'recommended_variant' => $recommended_variant,
				]),
			);
		}

		return $items;
	}

	/**
	 * Build app items for date/author/taxonomy archive templates.
	 *
	 * @param array $template_lookup Active template lookup keyed by template id.
	 * @return array
	 */

	private static function get_archive_template_items($template_lookup) {
		$items = [];
		$fixed_archives = [
			[
				'id' => 'author',
				'icon' => 'businessperson',
				'label' => __('Author', 'wphave'),
				'description' => __(
					'Layout for author archive pages that list content by one author.',
					'wphave',
				),
				'used_for' => 'is_author()',
			],
			[
				'id' => 'date',
				'icon' => 'calendar',
				'label' => __('Date', 'wphave'),
				'description' => __(
					'Layout for date archive pages such as year, month or day listings.',
					'wphave',
				),
				'used_for' => 'is_date()',
			],
		];

		foreach ($fixed_archives as $archive) {
			$template_id = $archive['id'];
			$items[] = array_merge(
				[
					'id' => $template_id,
					'icon' => '',
					'label' => $archive['label'] ?? 'n/a',
					'description' => $archive['description'],
					'template' => self::get_active_template_from_lookup(
						$template_id,
						$template_lookup,
					),
				],
				wphave_template_starter_contract('archive'),
			);
		}

		foreach (self::get_template_taxonomies(['data' => true]) as $taxonomy) {
			$template_id = 'taxonomy_' . $taxonomy->name;
			$items[] = array_merge(
				[
					'id' => $template_id,
					'icon' => '',
					'label' => $taxonomy->label ?? 'n/a',
					'description' => sprintf(
						/* translators: %s: related post type label. */
						__('Layout for this taxonomy archive. Related content type: %s.', 'wphave'),
						self::get_taxonomy_post_type_label($taxonomy),
					),
					'template' => self::get_active_template_from_lookup(
						$template_id,
						$template_lookup,
					),
				],
				wphave_template_starter_contract('archive'),
			);
		}

		return $items;
	}

	/**
	 * Build app items for modern block-based WooCommerce templates.
	 *
	 * Legacy WooCommerce PHP hook templates are intentionally not modeled here.
	 * WPHAVE supports WooCommerce through block-first templates; product subtype
	 * templates are optional and fall back to post_type_product at runtime.
	 *
	 * @param array $template_lookup Active template lookup keyed by template id.
	 * @return array
	 */

	private static function get_woocommerce_template_items($template_lookup) {
		if (!WPHAVE_WooCommerce::is_active()) {
			return [];
		}

		$items = [
			[
				'id' => 'shop',
				'icon' => 'cart',
				'label' => __('Shop', 'wphave'),
				'description' => __(
					'Layout for the main product catalog using modern WooCommerce blocks.',
					'wphave',
				),
				'used_for' => 'is_shop()',
			],
			[
				'id' => 'post_type_product',
				'icon' => 'box',
				'label' => __('Product', 'wphave'),
				'description' => __(
					'Default layout for product pages. Specific product type templates use this layout as their fallback.',
					'wphave',
				),
				'used_for' => 'is_product()',
			],
			[
				'id' => 'post_type_product_single',
				'icon' => 'box',
				'label' => __('Simple Product', 'wphave'),
				'description' => __(
					'Optional layout used only for simple products. Falls back to Product when inactive.',
					'wphave',
				),
			],
			[
				'id' => 'post_type_product_variable',
				'icon' => 'box',
				'label' => __('Variable Product', 'wphave'),
				'description' => __(
					'Optional layout used only for variable products. Falls back to Product when inactive.',
					'wphave',
				),
			],
			[
				'id' => 'post_type_product_grouped',
				'icon' => 'box',
				'label' => __('Grouped Product', 'wphave'),
				'description' => __(
					'Optional layout used only for grouped products. Falls back to Product when inactive.',
					'wphave',
				),
			],
			[
				'id' => 'post_type_product_external',
				'icon' => 'box',
				'label' => __('External Product', 'wphave'),
				'description' => __(
					'Optional layout used only for external products. Falls back to Product when inactive.',
					'wphave',
				),
			],
			[
				'id' => 'cart',
				'icon' => 'cart',
				'label' => __('Cart', 'wphave'),
				'description' => __(
					'Layout for the cart page where customers review products before checkout.',
					'wphave',
				),
				'used_for' => 'is_cart()',
			],
			[
				'id' => 'checkout',
				'icon' => 'cart',
				'label' => __('Checkout', 'wphave'),
				'description' => __(
					'Layout for the checkout page where customers enter payment and shipping details.',
					'wphave',
				),
				'used_for' => 'is_checkout()',
			],
			[
				'id' => 'account',
				'icon' => 'user',
				'label' => __('Account', 'wphave'),
				'description' => __(
					'Layout for the customer account area, including orders, addresses and account details.',
					'wphave',
				),
				'used_for' => 'is_account_page()',
			],
			[
				'id' => 'thank_you',
				'icon' => 'check',
				'label' => __('Order Confirmation', 'wphave'),
				'description' => __(
					'Layout shown after a successful order when WooCommerce displays the order confirmation.',
					'wphave',
				),
			],
		];

		foreach ($items as $key => $item) {
			$template_id = $item['id'];
			$starter_family = self::get_woocommerce_starter_family($template_id);
			$items[$key] = array_merge($item, wphave_template_starter_contract($starter_family), [
				'template' => self::get_active_template_from_lookup($template_id, $template_lookup),
			]);
		}

		return $items;
	}

	/**
	 * Resolve the structurally compatible starter family for a Commerce route.
	 *
	 * @param string $template_id Template identifier.
	 * @return string
	 */

	private static function get_woocommerce_starter_family($template_id) {
		if (strpos($template_id, 'post_type_product') === 0) {
			return 'commerce_product';
		}

		$families = [
			'shop' => 'commerce_archive',
			'cart' => 'commerce_cart',
			'checkout' => 'commerce_checkout',
			'account' => 'commerce_account',
			'thank_you' => 'commerce_confirmation',
		];

		return $families[$template_id] ?? '';
	}

	/**
	 * Build app items for custom templates assignable per post/page.
	 *
	 * @return array
	 */

	private static function get_custom_template_items() {
		$items = [];
		$custom_user_templates = self::get_custom_user_templates() ?? [];

		foreach ($custom_user_templates as $template) {
			$template_id = 'custom';
			$template_custom_id = $template->ID ?? '';
			$template_content = $template->post_content ?? '';
			$items[] = [
				'id' => $template_id,
				'icon' => '',
				'label' => $template->post_title ?? 'n/a',
				'description' => __(
					'Custom layout that can be assigned manually where a reusable page or post design is needed.',
					'wphave',
				),
				'template' => [
					'post_id' => $template_custom_id,
					'template_id' => $template_id,
					'template_content' => $template_content,
				],
			];
		}

		return $items;
	}

	/**
	 * Return a readable label for the first post type attached to a taxonomy.
	 *
	 * @param WP_Taxonomy $taxonomy Taxonomy object.
	 * @return string
	 */

	private static function get_taxonomy_post_type_label($taxonomy) {
		$post_type_slug = $taxonomy->object_type[0] ?? '';
		$post_type = $post_type_slug ? get_post_type_object($post_type_slug) : null;

		return $post_type->labels->singular_name ?? 'n/a';
	}
}
