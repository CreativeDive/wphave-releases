<?php

/**
 * Provides lightweight fallback templates when no user-defined template exists.
 *
 * These templates are intentionally minimal. They are a safety net for contexts
 * that do not have useful post content on their own, such as archives, search
 * results, 404 pages and protected content.
 */

if (!class_exists('WPHAVE_Template_Base')):
	class WPHAVE_Template_Base {
		/**
		 * Return the fallback template for a resolved template context.
		 *
		 * @param string $context Optional template context.
		 * @return string
		 */

		public static function get_template($context = '') {
			wphave_events('CHECK', 'For basic template.');

			$context = $context ?: WPHAVE_Templates::get_templates_context();
			$templates = self::get_templates();

			if (!$context) {
				return $templates['page'];
			}

			if (isset($templates[$context])) {
				return $templates[$context];
			}

			if (strpos($context, 'taxonomy_') === 0) {
				return $templates['archive'];
			}

			if (strpos($context, 'post_type_product_') === 0) {
				return $templates['post_type_product'];
			}

			if (strpos($context, 'post_type_') === 0) {
				return $templates['single'];
			}

			return $templates['page'];
		}

		/**
		 * Return one fallback template by type, or all templates for internal lookups.
		 *
		 * @param string|false $type Template type.
		 * @param array|string $args Options. Use output => all to return the raw map.
		 * @return array|string
		 */

		public static function get_template_content($type, $args = '') {
			$args = is_array($args) ? $args : [];
			$output = $args['output'] ?? '';
			$templates = self::get_templates();

			if ($output === 'all') {
				return $templates;
			}

			$content = isset($templates[$type]) ? $templates[$type] : '';

			return $content;
		}

		/**
		 * Return the canonical fallback template map.
		 *
		 * @return array
		 */

		private static function get_templates() {
			return [
				'protected' => self::get_protected_template(),
				'single' => self::get_single_template(),
				'attachment' => '<!-- wp:wphave/title /--><!-- wp:wphave/content /-->',
				'archive' => self::get_archive_template(),
				'search' => self::get_search_template(),
				'page' => self::get_page_template(),
				'post_type_page' => self::get_page_template(),
				'homepage' => self::get_page_template(),
				'privacy_policy' => self::get_page_template(),
				'posts_page' => self::get_archive_template(),
				'index' => self::get_archive_template(),
				'404_page' => self::get_404_template(),
				'subscriber_confirmation' => self::get_subscriber_confirmation_template(),
				'post_type_product' => self::get_product_template(),
				'post_type_product_single' => self::get_product_template(),
				'post_type_product_variable' => self::get_product_template(),
				'post_type_product_grouped' => self::get_product_template(),
				'post_type_product_external' => self::get_product_template(),
				'shop' => self::get_shop_template(),
				'cart' => self::get_cart_template(),
				'checkout' => self::get_checkout_template(),
				'account' => self::get_account_template(),
				'thank_you' => self::get_thank_you_template(),
			];
		}

		/**
		 * Fallback for password protected content.
		 *
		 * @return string
		 */

		private static function get_protected_template() {
			return '<!-- wp:wphave/hero {"wphave":{"layout":{"spacing":{"padding":"0 2.25rem 4rem 2.25rem"}},"styles":"\u002d\u002dpa: 0 2.25rem 4rem 2.25rem;\u002d\u002dleft-spacing: 2.25rem;\u002d\u002dright-spacing: 2.25rem","classNames":"fh pa bg ly ly-stk","features":{"fullHeight":true},"background":{"decoration":[{"deco":{"type":"21","size":"50%","blur":"0px","colors":{"deco":"var(--wphave-site-color-tertiary)"},"opacity":0.17,"position":{"x":"50%","y":"50%"}}}]}}} -->
				<!-- wp:wphave/paragraph {"wphave":{"text":{"align":"center","typeface":{"size":{"type":"title-l"}}},"styles":"\u002d\u002dtxta: center","classNames":"txta tf-fs tf-fs-title-l","settings":{"appearance":"heading"}},"content":"Protected Content"} /-->
				<!-- wp:wphave/paragraph {"wphave":{"text":{"align":"center"},"styles":"\u002d\u002dtxta: center","classNames":"txta"},"content":"This content is password protected. To view it please enter your password below."} /-->
				<!-- wp:wphave/password-protected-form {"wphave":{"styles":"\u002d\u002dwi: 342px","classNames":"wi wi-max","layout":{"width":{"limit":"max","custom":"342px"}}}} /-->
			<!-- /wp:wphave/hero -->';
		}

		/**
		 * Fallback for singular posts and custom post types.
		 *
		 * @return string
		 */

		private static function get_single_template() {
			return '
				<!-- wp:wphave/title {} /-->
				<!-- wp:wphave/subtitle {} /-->
				<!-- wp:wphave/taxonomy-terms {} /-->
				<!-- wp:wphave/date {} /-->
				<!-- wp:wphave/meta-author {} /-->
				<!-- wp:wphave/meta-comments {} /-->
				<!-- wp:wphave/meta-read-time {} /-->
				<!-- wp:wphave/featured-image {} /-->
				<!-- wp:wphave/content {} /-->
				<!-- wp:wphave/group {"wphave":{"layout":{"type":"flex","flex":{"flexWrap":"wrap","flexBasis":"auto","flexMotion":"static","flexDirection":"row","flexItemSizing":"auto","alignVertical":"center","alignHorizontal":"space-between"}},"stylesLayout":"--ly-column-gap: var(--wphave-site-layout-gap);--ly-row-gap: var(--wphave-site-layout-gap);--ly-fl-wrap: wrap;--ly-fl-itm: 0 1 auto;--ly-valign: center;--ly-halign: space-between;--ly-fl-direction: row","dimensions":{"innerWidth":{"custom":"100%"}},"styles":"--wi-in: 100%","classNames":"wi-in ly ly-fl ly-fl-wp"}} -->
				<!-- wp:wphave/loop-pagination-previous {} /-->
				<!-- wp:wphave/loop-pagination-next {} /-->
				<!-- /wp:wphave/group -->
				<!-- wp:wphave/comments {} /-->
			';
		}

		/**
		 * Fallback for archives, taxonomy archives and blog indexes.
		 *
		 * @return string
		 */

		private static function get_archive_template() {
			return '
				<!-- wp:wphave/title {} /-->
				<!-- wp:wphave/subtitle {} /-->
				<!-- wp:wphave/loop -->
					<!-- wp:wphave/loop-template -->
						<!-- wp:wphave/title {"wphave":{"settings":{"headingLevel":"h3"}}} /-->
						<!-- wp:wphave/excerpt /-->
						<!-- wp:wphave/read-more /-->
					<!-- /wp:wphave/loop-template -->
				<!-- /wp:wphave/loop -->
				<!-- wp:wphave/loop-empty /-->
				<!-- wp:wphave/loop-pagination /-->
			';
		}

		/**
		 * Fallback for search results.
		 *
		 * @return string
		 */

		private static function get_search_template() {
			return '
				<!-- wp:wphave/search-form /-->
				<!-- wp:wphave/title {} /-->
				<!-- wp:wphave/loop -->
					<!-- wp:wphave/loop-template -->
						<!-- wp:wphave/title {"wphave":{"settings":{"headingLevel":"h3"}}} /-->
						<!-- wp:wphave/excerpt /-->
						<!-- wp:wphave/read-more /-->
					<!-- /wp:wphave/loop-template -->
				<!-- /wp:wphave/loop -->
				<!-- wp:wphave/loop-empty /-->
				<!-- wp:wphave/loop-pagination /-->
			';
		}

		/**
		 * Fallback for pages.
		 *
		 * @return string
		 */

		private static function get_page_template() {
			return '
				<!-- wp:wphave/title {} /-->
				<!-- wp:wphave/subtitle {} /-->
				<!-- wp:wphave/content {} /-->
			';
		}

		/**
		 * Fallback for 404 requests.
		 *
		 * @return string
		 */

		private static function get_404_template() {
			return '
				<!-- wp:wphave/hero {"wphave":{"layout":{"spacing":{"padding":"120px 24px 120px 24px"}},"styles":"\u002d\u002dpa: 120px 24px 120px 24px;\u002d\u002dleft-spacing: 24px;\u002d\u002dright-spacing: 24px","classNames":"pa ly ly-stk"}} -->
					<!-- wp:wphave/paragraph {"wphave":{"text":{"align":"center","typeface":{"size":{"type":"title-l"}}},"styles":"\u002d\u002dtxta: center","classNames":"txta tf-fs tf-fs-title-l","settings":{"appearance":"heading"}},"content":"404"} /-->
					<!-- wp:wphave/paragraph {"wphave":{"text":{"align":"center"},"styles":"\u002d\u002dtxta: center","classNames":"txta"},"content":"Oops! That page cannot be found."} /-->
				<!-- /wp:wphave/hero -->
			';
		}

		/**
		 * Fallback for public subscriber confirmation screens.
		 *
		 * @return string
		 */

		private static function get_subscriber_confirmation_template() {
			return '
				<!-- wp:wphave/group {"wphave":{"layout":{"type":"stacked","stacked":{"contentPosition":"center"}},"classNames":"ly ly-stk ly-co-pos","styles":"\u002d\u002dly-co-pos-h: center;\u002d\u002dly-co-pos-v: center"}} -->
					<!-- wp:wphave/heading {"wphave":{"settings":{"headingLevel":"h3"}},"content":"<span class=\"rt-dyd\" data-source=\"audience\" data-field=\"subscriber_confirmation_title\">{{audience.subscriber.confirmation.title}}</span>"} /-->
					<!-- wp:wphave/paragraph {"content":"<span class=\"rt-dyd\" data-source=\"audience\" data-field=\"subscriber_confirmation_message\">{{audience.subscriber.confirmation.message}}</span>"} /-->
					<!-- wp:wphave/button {"content":"{{audience.subscriber.confirmation.action_label}}","link":{"type":"external","external":{"url":"{{audience.subscriber.confirmation.action_url}}"}}} /-->
				<!-- /wp:wphave/group -->
			';
		}

		/**
		 * Fallback for WooCommerce products.
		 *
		 * This is intentionally block-first. Legacy WooCommerce PHP hook templates
		 * are not reproduced in WPHAVE templates.
		 *
		 * @return string
		 */

		private static function get_product_template() {
			return '
				<!-- wp:woocommerce/store-notices /-->
				<!-- wp:woocommerce/breadcrumbs /-->
				<!-- wp:wphave/group {"wphave":{"layout":{"type":"grid","grid":{"columns":"1fr 1fr"}},"stylesLayout":"--ly-grid-cols: 1fr 1fr","classNames":"ly ly-grid"}} -->
					<!-- wp:wphave/featured-image {} /-->
					<!-- wp:wphave/group {"wphave":{"layout":{"type":"stack"}},"classNames":"ly ly-stk"}} -->
						<!-- wp:wphave/title {} /-->
						<!-- wp:woocommerce/product-price /-->
						<!-- wp:wphave/excerpt /-->
						<!-- wp:woocommerce/add-to-cart-form /-->
					<!-- /wp:wphave/group -->
				<!-- /wp:wphave/group -->
				<!-- wp:woocommerce/product-details /-->
				<!-- wp:wphave/content {} /-->
			';
		}

		/**
		 * Fallback for the WooCommerce shop archive.
		 *
		 * @return string
		 */

		private static function get_shop_template() {
			return '
				<!-- wp:woocommerce/store-notices /-->
				<!-- wp:wphave/title {} /-->
				<!-- wp:woocommerce/product-results-count /-->
				<!-- wp:woocommerce/catalog-sorting /-->
				<!-- wp:woocommerce/product-collection {"queryId":1,"query":{"perPage":12,"pages":0,"offset":0,"postType":"product","order":"asc","orderBy":"title","search":"","exclude":[],"inherit":true,"taxQuery":{},"isProductCollectionBlock":true,"woocommerceOnSale":false,"woocommerceStockStatus":["instock","outofstock","onbackorder"],"woocommerceAttributes":[],"woocommerceHandPickedProducts":[]},"tagName":"div","dimensions":{"widthType":"fill","fixedWidth":""},"displayLayout":{"type":"flex","columns":3},"align":"wide"} -->
					<div class="wp-block-woocommerce-product-collection alignwide">
						<!-- wp:woocommerce/product-template -->
							<!-- wp:woocommerce/product-image {"showSaleBadge":true,"isDescendentOfLoop":true} /-->
							<!-- wp:post-title {"textAlign":"center","level":2,"isLink":true,"style":{"spacing":{"margin":{"bottom":"0.75rem","top":"0"}}},"fontSize":"medium","__woocommerceNamespace":"woocommerce/product-collection/product-title"} /-->
							<!-- wp:woocommerce/product-price {"isDescendentOfLoop":true,"textAlign":"center","fontSize":"small"} /-->
							<!-- wp:woocommerce/product-button {"isDescendentOfLoop":true,"textAlign":"center","fontSize":"small"} /-->
						<!-- /wp:woocommerce/product-template -->
					</div>
				<!-- /wp:woocommerce/product-collection -->
			';
		}

		/**
		 * Fallback for the WooCommerce cart page.
		 *
		 * @return string
		 */

		private static function get_cart_template() {
			return '
				<!-- wp:woocommerce/store-notices /-->
				<!-- wp:woocommerce/cart /-->
			';
		}

		/**
		 * Fallback for the WooCommerce checkout page.
		 *
		 * @return string
		 */

		private static function get_checkout_template() {
			return '
				<!-- wp:woocommerce/store-notices /-->
				<!-- wp:woocommerce/checkout /-->
			';
		}

		/**
		 * Fallback for the WooCommerce account page.
		 *
		 * Account pages are normally normal WordPress pages containing the account
		 * block/shortcode, so the safest block-first fallback is page content.
		 *
		 * @return string
		 */

		private static function get_account_template() {
			return '
				<!-- wp:woocommerce/store-notices /-->
				<!-- wp:wphave/content {} /-->
			';
		}

		/**
		 * Fallback for WooCommerce order confirmation.
		 *
		 * @return string
		 */

		private static function get_thank_you_template() {
			return '
				<!-- wp:woocommerce/store-notices /-->
				<!-- wp:wphave/content {} /-->
			';
		}
	}
endif;

if (!function_exists('wphave_basic_template')):
	/**
	 * Basic template.
	 *
	 * @param array $context Request or rendering context.
	 */

	function wphave_basic_template($context = '') {
		return WPHAVE_Template_Base::get_template($context);
	}
endif;

if (!function_exists('wphave_basic_template_content')):
	/**
	 * Basic template content.
	 *
	 * @param string $type Type.
	 * @param array $args Function arguments.
	 */

	function wphave_basic_template_content($type, $args = '') {
		return WPHAVE_Template_Base::get_template_content($type, $args);
	}
endif;
