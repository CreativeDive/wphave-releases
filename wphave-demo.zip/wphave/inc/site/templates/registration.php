<?php

/**
 * Registers the template post type and its REST-exposed metadata.
 */

if( ! class_exists( 'WPHAVE_Templates_REST_Controller' ) ) {

    class WPHAVE_Templates_REST_Controller extends WP_REST_Posts_Controller {

        /**
         * Restrict template collections to the feature management boundary.
         *
         * @param WP_REST_Request $request Request object.
         * @return true|WP_Error
         */

        public function get_items_permissions_check( $request ) {

            if( ! WPHAVE_Templates::can_manage_templates() ) {
                return new WP_Error( 'rest_forbidden', __( 'Sorry, you are not allowed to manage templates.', 'wphave' ), array( 'status' => rest_authorization_required_code() ) );
            }

            return parent::get_items_permissions_check( $request );

        }

        /**
         * Restrict direct template reads to the feature management boundary.
         *
         * @param WP_REST_Request $request Request object.
         * @return true|WP_Error
         */

        public function get_item_permissions_check( $request ) {

            if( ! WPHAVE_Templates::can_manage_templates() ) {
                return new WP_Error( 'rest_forbidden', __( 'Sorry, you are not allowed to manage templates.', 'wphave' ), array( 'status' => rest_authorization_required_code() ) );
            }

            return parent::get_item_permissions_check( $request );

        }

    }

}

trait WPHAVE_Template_Registration {

    /**
     * Register the custom templates post type.
     *
     * @return void
     */

    public static function register_post_type() {

        // WPHAVE templates are resolved only by the bundled theme render engine.
        if( wphave_use_fse() ) {
            return;
        }

        register_post_type( self::POST_TYPE,
            array(
                'label' => __( 'Templates', 'wphave' ),
                'description' => __( 'Create and manage layouts for pages, posts, archives, system screens and supported integrations.', 'wphave' ),
                'menu_icon' => 'data:image/svg+xml;base64,' . base64_encode( wphave_svg_ui_icon( 'header' ) ),
                'menu_position' => 47,
                'supports' => array(
                    'title',
                    'editor' => [
                        'notes'
                    ],
                    'revisions',
                    'custom-fields'
                ),
                'public' => false,
                'show_ui' => true,
                'rewrite' => false,
                'show_in_menu' => false,
                'show_in_rest' => true,
                'rest_controller_class' => 'WPHAVE_Templates_REST_Controller',
                'map_meta_cap' => true,
                'capabilities' => self::get_post_type_capabilities(),
                'has_archive' => false,
                'exclude_from_search' => true,
                'show_in_nav_menus' => false,
                'show_in_admin_bar' => false,
                'publicly_queryable' => false,
                'query_var' => false,
            )
        );

    }

    /**
     * Return WordPress post type capabilities mapped to template feature access.
     *
     * @return array
     */

    private static function get_post_type_capabilities() {

        $capability = 'wphave_manage_templates';

        return array(
            'edit_post' => 'edit_wphave_template',
            'read_post' => 'read_wphave_template',
            'delete_post' => 'delete_wphave_template',
            'edit_posts' => $capability,
            'edit_others_posts' => $capability,
            'delete_posts' => $capability,
            'publish_posts' => $capability,
            'read_private_posts' => $capability,
            'create_posts' => $capability,
            'delete_private_posts' => $capability,
            'delete_published_posts' => $capability,
            'delete_others_posts' => $capability,
            'edit_private_posts' => $capability,
            'edit_published_posts' => $capability,
        );

    }

    /**
     * Register template post meta exposed to the editor/app.
     *
     * @return void
     */

    public static function register_post_meta() {

        register_post_meta(self::POST_TYPE, self::META_TEMPLATE_ID, array(
            'single' => true,
            'type' => 'string',
            'show_in_rest' => true,
            'auth_callback' => array( __CLASS__, 'can_manage_templates' )
        ));

        register_post_meta(self::POST_TYPE, self::META_LAYOUT_VISIBILITY, array(
            'single' => true,
            'type' => 'object',
            'default' => array(),
            'show_in_rest' => array(
                'schema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'header' => array(
                            'type' => 'string',
                            'enum' => array( 'default', 'hidden' ),
                        ),
                        'footer' => array(
                            'type' => 'string',
                            'enum' => array( 'default', 'hidden' ),
                        ),
                    ),
                    'additionalProperties' => false,
                ),
            ),
            'sanitize_callback' => array( __CLASS__, 'sanitize_layout_visibility' ),
            'auth_callback' => array( __CLASS__, 'can_manage_template_layout' )
        ));

    }

    /**
     * Determine whether the current user may edit templates.
     *
     * @return bool Whether template management is permitted.
     */

    public static function can_manage_templates() {
        return current_user_can( 'wphave_manage_templates' ) || current_user_can( 'wphave_manage_options' ) || current_user_can( 'manage_options' );
    }

    /**
     * Determine whether the current user may change template layout slots.
     *
     * @return bool Whether template and template-part management is permitted.
     */

    public static function can_manage_template_layout() {
		// SECURITY INVARIANT: Layout slots join template and template-part domains;
		// scoped users must hold both capabilities before changing that relationship.
        return ( current_user_can( 'wphave_manage_templates' ) && current_user_can( 'wphave_manage_template_parts' ) ) || current_user_can( 'wphave_manage_options' ) || current_user_can( 'manage_options' );
    }

    /**
     * Sanitize template-level layout slot visibility settings.
     *
     * These settings only opt a slot out. The default state intentionally
     * keeps normal rendering behavior: assigned global part first, base
     * fallback second.
     *
     * @param mixed $value Raw meta value.
     * @return array
     */

    public static function sanitize_layout_visibility( $value ) {

        if( ! is_array( $value ) ) {
            return array();
        }

        $allowed_slots = array( 'header', 'footer' );
        $sanitized = array();

        foreach( $allowed_slots as $slot ) {
            $state = isset( $value[$slot] ) && is_string( $value[$slot] ) ? $value[$slot] : 'default';

            if( $state === 'hidden' ) {
                $sanitized[$slot] = 'hidden';
            }
        }

        return $sanitized;

    }

}
