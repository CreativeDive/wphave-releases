<?php

/**
 * Provide management-only REST endpoints for template selection data.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

if( ! class_exists( 'WPHAVE_Templates_Admin' ) ) :

	/**
	 * Coordinates template data requested by WPHAVE administration screens.
	 */

	class WPHAVE_Templates_Admin {

		/**
		 * Register admin REST routes.
		 *
		 * @return void
		 */

		public static function init() {
			add_action( 'rest_api_init', array( __CLASS__, 'register_rest_routes' ) );
		}

		/**
		 * Register template management endpoints used by the WPHAVE app.
		 *
		 * @return void
		 */

		public static function register_rest_routes() {
			register_rest_route('wphave/v1', '/get-templates-data', array(
				'methods' => 'GET',
				'callback' => array( __CLASS__, 'get_templates_data' ),
				'permission_callback' => array( __CLASS__, 'can_manage' )
			));
		}

		/**
		 * Check whether the current user can read template management data.
		 *
		 * @return bool
		 */

		public static function can_manage() {
			// AUTHORIZATION INVARIANT: Template catalog metadata is part of the site-wide
			// rendering configuration and remains behind its dedicated capability; generic
			// post editing or knowledge of this REST route grants no access.
			return current_user_can('wphave_manage_templates') || current_user_can('wphave_manage_options') || current_user_can('manage_options');
		}

		/**
		 * Return template selection data from the runtime template service.
		 *
		 * @return WP_REST_Response
		 */

		public static function get_templates_data() {
			// AUTHORIZATION INVARIANT: The executable template-catalog callback repeats its dedicated policy before loading global rendering and selection metadata.
			if( ! self::can_manage() ) {
				return new WP_Error(
					'wphave_templates_forbidden',
					__( 'You are not allowed to inspect template configuration.', 'wphave' ),
					array( 'status' => 403 )
				);
			}

			return rest_ensure_response( WPHAVE_Templates::get_templates_data() );
		}

	}

endif;

WPHAVE_Templates_Admin::init();
