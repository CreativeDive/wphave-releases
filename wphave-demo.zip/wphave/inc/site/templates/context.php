<?php

/**
 * Resolves stored templates and the active WordPress request context.
 */

trait WPHAVE_Template_Context {
	/**
	 * Cache and return the minimal template lookup data.
	 *
	 * @return array
	 */

	public static function get_custom_template_data() {
		// PERFORMANCE INVARIANT: Public requests cannot populate the shared
		// internal-post-type cache. Retain empty and populated lookups locally
		// so repeated context selection does not reload and resort templates.
		if (self::$request_data !== null) {
			return self::$request_data;
		}

		$cached = wphave_has_cached_data(self::CACHE_BUCKET, [
			'key' => self::CACHE_KEY,
			'admin_cache' => true,
		]);

		// CACHE INVARIANT: The feature payload is authoritative on a cache hit. Looking up IDs
		// first would defeat the shared-cache contract after an index eviction.
		if ($cached !== false) {
			self::$request_data = $cached;

			return self::$request_data;
		}

		$post_ids = wphave_internal_post_type_all_ids(self::POST_TYPE);

		if (!$post_ids) {
			self::$request_data = [];

			wphave_save_query([], self::CACHE_BUCKET, [
				'key' => self::CACHE_KEY,
				'admin_cache' => true,
				'frontend_write' => false,
			]);
			return self::$request_data;
		}

		wphave_events('CACHE', 'Custom template data.');

		$save_data = [];

		foreach ($post_ids as $post_id) {
			$template_data = self::get_template_data_from_post_id($post_id);

			if (empty($template_data)) {
				continue;
			}

			$save_data[$post_id] = $template_data;
		}

		$save_data = self::move_parent_contexts_to_end($save_data);

		wphave_save_query($save_data, self::CACHE_BUCKET, [
			'key' => self::CACHE_KEY,
			'admin_cache' => true,
			'frontend_write' => false,
		]);

		self::$request_data = $save_data;

		return self::$request_data;
	}

	/**
	 * OWNERSHIP INVARIANT: Derive template context from the single source of truth: wphave_template_id.
	 *
	 * @param string $template_id Template identifier.
	 * @return array
	 */

	public static function get_template_context_data($template_id = '') {
		$template_id = is_string($template_id) ? $template_id : '';
		$data = [
			'template_id' => $template_id,
			'post_type' => '',
			'taxonomy' => '',
		];

		if (!$template_id) {
			return $data;
		}

		if (strpos($template_id, 'post_type_') === 0) {
			$post_type = substr($template_id, strlen('post_type_'));

			// WooCommerce product sub contexts still belong to the product post type.
			if (strpos($post_type, 'product') === 0 && post_type_exists('product')) {
				$data['post_type'] = 'product';
				return $data;
			}

			if (post_type_exists($post_type)) {
				$data['post_type'] = $post_type;
			}

			return $data;
		}

		if (strpos($template_id, 'taxonomy_') === 0) {
			$taxonomy = substr($template_id, strlen('taxonomy_'));

			if (taxonomy_exists($taxonomy)) {
				$data['taxonomy'] = $taxonomy;
			}
		}

		return $data;
	}

	/**
	 * Return a matching template for a context.
	 *
	 * @param string $context Optional template context.
	 * @return array|false
	 */

	public static function custom_template($context = '') {
		$context = $context ?: self::get_templates_context();

		// DATA INTEGRITY INVARIANT: A direct post-to-template assignment is
		// authoritative and must not depend on the shared context catalog.
		// The catalog may legitimately be empty or stale while the assigned
		// published template remains resolvable by its stored post ID.
		if ($context === 'custom') {
			return self::get_assigned_custom_template();
		}

		if (!wphave_is_internal_post_type(self::POST_TYPE)) {
			return false;
		}

		$templates = self::get_custom_template_data();

		if (!$templates) {
			return false;
		}

		wphave_events('CHECK', 'Has custom template.');

		$template = self::find_template_by_id($context, $templates);

		if ($template) {
			return $template;
		}

		if (strpos($context, 'post_type_product_') === 0) {
			return self::find_template_by_id('post_type_product', $templates);
		}

		return false;
	}

	/**
	 * Return public post types that can receive templates.
	 *
	 * @param array|string $args Options.
	 * @return array
	 */

	public static function get_template_post_types($args = '') {
		$args = is_array($args) ? $args : [];
		$return_objects = isset($args['data']) && $args['data'] ? true : false;
		$post_args = [
			'public' => true,
		];
		$disallowed_post_types = ['attachment'];

		if ($return_objects) {
			$post_types = get_post_types($post_args, 'objects');

			foreach ($post_types as $post_type => $post_type_object) {
				if (in_array($post_type, $disallowed_post_types)) {
					unset($post_types[$post_type]);
				}
			}

			return $post_types;
		}

		$post_types = get_post_types($post_args);
		$allowed_post_types = [];

		foreach ($post_types as $post_type) {
			if (in_array($post_type, $disallowed_post_types)) {
				continue;
			}

			$allowed_post_types[] = $post_type;
		}

		return $allowed_post_types;
	}

	/**
	 * Return public taxonomies that can receive templates.
	 *
	 * @param array|string $args Options.
	 * @return array
	 */

	public static function get_template_taxonomies($args = '') {
		$args = is_array($args) ? $args : [];
		$return_objects = isset($args['data']) && $args['data'] ? true : false;
		$taxonomies_by_post_type = self::get_taxonomies_by_template_post_type();
		$disallowed_taxonomies = ['post_format', 'product_type', 'pa_colors', 'pa_sizes'];

		if ($return_objects) {
			$all_taxonomies = [];

			foreach ($taxonomies_by_post_type as $taxonomies) {
				foreach ($taxonomies as $taxonomy => $taxonomy_data) {
					if (
						in_array($taxonomy, $disallowed_taxonomies, true) ||
						!self::is_template_taxonomy_eligible($taxonomy_data)
					) {
						continue;
					}

					$all_taxonomies[$taxonomy] = $taxonomy_data;
				}
			}

			return $all_taxonomies;
		}

		$allowed_taxonomies = [];

		foreach ($taxonomies_by_post_type as $taxonomies) {
			foreach ($taxonomies as $taxonomy_slug => $taxonomy_data) {
				if (
					in_array($taxonomy_slug, $disallowed_taxonomies, true) ||
					!self::is_template_taxonomy_eligible($taxonomy_data)
				) {
					continue;
				}

				$allowed_taxonomies[] = $taxonomy_slug;
			}
		}

		return array_values(array_unique($allowed_taxonomies));
	}

	/**
	 * Determine whether a taxonomy has a frontend archive that can receive a template.
	 *
	 * ARCHIVE INVARIANT: Assignment to a public post type is not sufficient. A taxonomy
	 * must itself be public and publicly queryable; otherwise WPHAVE would offer a
	 * template for a route WordPress intentionally does not expose.
	 *
	 * @param WP_Taxonomy $taxonomy Taxonomy object.
	 * @return bool
	 */

	private static function is_template_taxonomy_eligible($taxonomy) {
		return $taxonomy instanceof WP_Taxonomy &&
			true === $taxonomy->public &&
			true === $taxonomy->publicly_queryable;
	}

	/**
	 * Resolve the current WordPress request into a template context id.
	 *
	 * The order is intentional: special states override page/post/archive
	 * contexts, and broad fallbacks are only returned after specific checks.
	 *
	 * @return string|false
	 */

	public static function get_templates_context() {
		$resolvers = [
			'resolve_password_context',
			'resolve_woocommerce_context',
			'resolve_custom_assignment_context',
			'resolve_search_context',
			'resolve_page_context',
			'resolve_attachment_context',
			'resolve_single_context',
			'resolve_archive_context',
			'resolve_home_context',
			'resolve_error_context',
		];

		foreach ($resolvers as $resolver) {
			$context = self::{$resolver}();

			if ($context) {
				return $context;
			}
		}

		return false;
	}

	/**
	 * Return all custom templates assignable per post/page.
	 *
	 * @return WP_Post[]
	 */

	public static function get_custom_user_templates() {
		return get_posts([
			'post_type' => self::POST_TYPE,
			'numberposts' => -1,
			'post_status' => 'publish',
			'suppress_filters' => false,
			'cache_results' => true,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
			'meta_key' => self::META_TEMPLATE_ID,
			'meta_value' => 'custom',
		]);
	}

	/**
	 * Return template selection data for the app.
	 *
	 * @return array
	 */

	public static function get_templates_data() {
		$templates = self::get_custom_template_data();
		$template_lookup = self::get_template_lookup($templates);
		$data = self::get_base_template_groups();
		$data = self::add_active_template_flags($data, $template_lookup);
		$data['postTypes'] = self::get_post_type_template_items($template_lookup);
		$data['archives'] = self::get_archive_template_items($template_lookup);
		$data['woocommerce'] = self::get_woocommerce_template_items($template_lookup);
		$data['customs'] = self::get_custom_template_items();

		return $data;
	}

	/**
	 * Build one cached template record from a template post.
	 *
	 * @param int $post_id Template post id.
	 * @return array
	 */

	private static function get_template_data_from_post_id($post_id) {
		$template_id = get_post_meta($post_id, self::META_TEMPLATE_ID, true);

		if (!$template_id) {
			return [];
		}

		$post = get_post($post_id);

		return [
			'template_id' => $template_id,
			'template_content' => $post->post_content ?? '',
		];
	}

	/**
	 * Keep broad parent contexts last for legacy duplicate-template precedence.
	 *
	 * @param array $templates Template data keyed by post id.
	 * @return array
	 */

	private static function move_parent_contexts_to_end($templates) {
		$parent_templates = ['archive', 'single', 'post_type_product'];
		$end_of_array = [];

		foreach ($templates as $template_post_id => $data) {
			$template_id = $data['template_id'] ?? '';

			if (in_array($template_id, $parent_templates)) {
				unset($templates[$template_post_id]);
				$end_of_array[$template_post_id] = $data;
			}
		}

		foreach ($end_of_array as $key => $value) {
			$templates[$key] = $value;
		}

		return $templates;
	}

	/**
	 * Build a lookup table for exact template ids.
	 *
	 * Custom templates are intentionally excluded because multiple custom
	 * templates share the same template_id and are resolved by assigned post id.
	 *
	 * @param array $templates Template data keyed by post id.
	 * @return array
	 */

	private static function get_template_lookup($templates) {
		$lookup = [];

		foreach ($templates as $post_id => $template) {
			$template_id = $template['template_id'] ?? '';

			if (!$template_id || $template_id === 'custom' || isset($lookup[$template_id])) {
				continue;
			}

			$lookup[$template_id] = [
				'post_id' => $post_id,
				'template_id' => $template_id,
				'template_content' => $template['template_content'] ?? '',
			];
		}

		return $lookup;
	}

	/**
	 * Find a template by exact template id.
	 *
	 * @param string $template_id Template id.
	 * @param array $templates Template data keyed by post id.
	 * @return array|false
	 */

	private static function find_template_by_id($template_id, $templates) {
		$lookup = self::get_template_lookup($templates);

		return $lookup[$template_id] ?? false;
	}

	/**
	 * Read one active template from an already prepared lookup table.
	 *
	 * @param string $template_id Template id.
	 * @param array $lookup Template lookup keyed by template id.
	 * @return array|false
	 */

	private static function get_active_template_from_lookup($template_id, $lookup) {
		return $lookup[$template_id] ?? false;
	}

	/**
	 * Resolve the custom template assigned to the current queried post.
	 *
	 * @return array|false
	 */

	private static function get_assigned_custom_template() {
		// REQUEST INVARIANT: Template resolution runs before the main Loop, so
		// the queried document ID is authoritative. The global post is only a
		// compatibility fallback for direct calls outside a normal query.
		$content_post_id = get_queried_object_id() ?: get_the_ID();
		$custom_template_post_id = (int) get_post_meta(
			$content_post_id,
			self::META_CUSTOM_TEMPLATE,
			true,
		);

		if (!$custom_template_post_id) {
			return false;
		}

		$template_id = get_post_meta($custom_template_post_id, self::META_TEMPLATE_ID, true);

		if ($template_id !== 'custom') {
			return false;
		}

		$post = get_post($custom_template_post_id);

		if (!$post || $post->post_type !== self::POST_TYPE || $post->post_status !== 'publish') {
			return false;
		}

		return [
			'post_id' => $custom_template_post_id,
			'template_id' => 'custom',
			'template_content' => $post->post_content ?? '',
		];
	}

	/**
	 * Collect taxonomies grouped by every templateable public post type.
	 *
	 * @return array
	 */

	private static function get_taxonomies_by_template_post_type() {
		$taxonomies_by_post_type = [];
		$post_types = self::get_template_post_types();

		foreach ($post_types as $post_type) {
			$tax_args = [
				'object_type' => [$post_type],
			];

			$taxonomies_by_post_type[$post_type] = get_taxonomies($tax_args, 'objects');
		}

		return $taxonomies_by_post_type;
	}

	/**
	 * Resolve password protected content before all other contexts.
	 *
	 * @return string|false
	 */

	private static function resolve_password_context() {
		return post_password_required() ? 'protected' : false;
	}

	/**
	 * Resolve WooCommerce-specific contexts when WooCommerce is active.
	 *
	 * @return string|false
	 */

	private static function resolve_woocommerce_context() {
		if (!WPHAVE_WooCommerce::is_active()) {
			return false;
		}

		$woo = WPHAVE_WooCommerce::context();

		$is_woocommerce = !empty($woo['is_woocommerce']);
		$is_shop = !empty($woo['is_shop']);
		$is_product = !empty($woo['is_product']);

		if (($is_woocommerce || $is_shop) && is_single() && $is_product) {
			return self::resolve_woocommerce_product_context();
		}

		if ($is_shop) {
			return 'shop';
		}

		if (!empty($woo['is_cart'])) {
			return 'cart';
		}

		if (!empty($woo['is_checkout'])) {
			return 'checkout';
		}

		if (!empty($woo['is_account_page'])) {
			return 'account';
		}

		if (!empty($woo['is_thank_you'])) {
			return 'thank_you';
		}

		return false;
	}

	/**
	 * Resolve WooCommerce product sub contexts defensively.
	 *
	 * @return string
	 */

	private static function resolve_woocommerce_product_context() {
		return WPHAVE_WooCommerce::product_template_context(get_the_ID());
	}

	/**
	 * Resolve a manually assigned custom template on the queried post.
	 *
	 * @return string|false
	 */

	private static function resolve_custom_assignment_context() {
		$content_post_id = get_queried_object_id() ?: get_the_ID();
		$custom_template_post_id = get_post_meta(
			$content_post_id,
			self::META_CUSTOM_TEMPLATE,
			true,
		);

		return $custom_template_post_id && $custom_template_post_id !== 'default'
			? 'custom'
			: false;
	}

	/**
	 * Resolve search result pages.
	 *
	 * @return string|false
	 */

	private static function resolve_search_context() {
		return is_search() ? 'search' : false;
	}

	/**
	 * Resolve page contexts, including static special pages.
	 *
	 * @return string|false
	 */

	private static function resolve_page_context() {
		if (!is_page()) {
			return false;
		}

		if (is_front_page()) {
			return 'homepage';
		}

		if (is_privacy_policy()) {
			return 'privacy_policy';
		}

		return 'post_type_page';
	}

	/**
	 * Resolve specific single post type templates before the broad single fallback.
	 *
	 * @return string|false
	 */

	private static function resolve_single_context() {
		if (!is_single()) {
			return false;
		}

		$post_types = self::get_template_post_types();

		foreach ($post_types as $post_type) {
			if ($post_type === 'page' || $post_type === 'product') {
				continue;
			}

			if (is_singular($post_type)) {
				return 'post_type_' . $post_type;
			}
		}

		return 'single';
	}

	/**
	 * Resolve taxonomy/date/author archive templates before the broad archive fallback.
	 *
	 * @return string|false
	 */

	private static function resolve_archive_context() {
		if (!is_archive() && !is_post_type_archive()) {
			return false;
		}

		$taxonomies = self::get_template_taxonomies();

		foreach ($taxonomies as $taxonomy_slug) {
			$taxonomy_context = 'taxonomy_' . $taxonomy_slug;

			if (is_category() && $taxonomy_slug === 'category') {
				return $taxonomy_context;
			}

			if (is_tag() && $taxonomy_slug === 'post_tag') {
				return $taxonomy_context;
			}

			if (is_tax($taxonomy_slug)) {
				return $taxonomy_context;
			}
		}

		if (is_date()) {
			return 'date';
		}

		if (is_author()) {
			return 'author';
		}

		return 'archive';
	}

	/**
	 * Resolve blog index and posts page contexts.
	 *
	 * @return string|false
	 */

	private static function resolve_home_context() {
		if (is_home() && is_front_page()) {
			return 'index';
		}

		if (is_home() && !is_front_page()) {
			return 'posts_page';
		}

		return false;
	}

	/**
	 * Resolve error page contexts.
	 *
	 * @return string|false
	 */

	private static function resolve_error_context() {
		return is_404() ? '404_page' : false;
	}

	/**
	 * Resolve attachment contexts.
	 *
	 * @return string|false
	 */

	private static function resolve_attachment_context() {
		return is_attachment() ? 'attachment' : false;
	}
}
