<?php

/**
 * Bootstrap custom templates and their server-rendered block integrations.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once wphave_dir() . 'inc/editor/pattern/starter/templates/registry.php';
require_once __DIR__ . '/registration.php';
require_once __DIR__ . '/context.php';
require_once __DIR__ . '/catalog.php';
require_once __DIR__ . '/templates.php';
require_once __DIR__ . '/base.php';

wphave_include_file( wphave_dir() . 'build/block-types/blocks-templates/title/functions.php' );
wphave_include_file( wphave_dir() . 'build/block-types/blocks-templates/content/functions.php' );
wphave_include_file( wphave_dir() . 'build/block-types/blocks-templates/avatar/functions.php' );
wphave_include_file( wphave_dir() . 'build/block-types/blocks-templates/excerpt/functions.php' );
wphave_include_file( wphave_dir() . 'build/block-types/blocks-templates/comments/functions.php' );
wphave_include_file( wphave_dir() . 'build/block-types/blocks-templates/featured-image/functions.php' );
wphave_include_file( wphave_dir() . 'build/block-types/blocks-templates/like-button/functions.php' );
wphave_include_file( wphave_dir() . 'build/block-types/blocks-templates/rating/functions.php' );
wphave_include_file( wphave_dir() . 'build/block-types/blocks-templates/taxonomy-terms/functions.php' );
wphave_include_file( wphave_dir() . 'build/block-types/blocks-templates/loop/functions.php' );
wphave_include_file( wphave_dir() . 'build/block-types/blocks-templates/search-form/functions.php' );
wphave_include_file( wphave_dir() . 'build/block-types/blocks-templates/password-protected-form/functions.php' );
