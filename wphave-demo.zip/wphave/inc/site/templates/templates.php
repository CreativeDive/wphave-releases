<?php

/**
 * WPHAVE custom template facade.
 *
 * The facade keeps the established static API while registration, request
 * context resolution, repository access, and app catalog generation live in
 * focused traits beside it.
 */

class WPHAVE_Templates {

	use WPHAVE_Template_Registration;
	use WPHAVE_Template_Context;
	use WPHAVE_Template_Catalog;

	const POST_TYPE = 'wphave-templates';
	const META_TEMPLATE_ID = 'wphave_template_id';
	const META_CUSTOM_TEMPLATE = 'wphave_custom_template';
	const META_LAYOUT_VISIBILITY = 'wphave_layout_visibility';
	const CACHE_BUCKET = 'post_type_features_data';
	const CACHE_KEY = 'wphave_templates';

	/**
	 * Template lookup resolved during the current request.
	 *
	 * @var array|null
	 */

	private static $request_data = null;

	/**
	 * Register template hooks.
	 *
	 * @return void
	 */

	public static function init() {
		add_action( 'init', [ __CLASS__, 'register_post_type' ], 16 );
		add_action( 'init', [ __CLASS__, 'register_post_meta' ] );
		add_action( 'save_post_' . self::POST_TYPE, [ __CLASS__, 'clear_cache' ] );
		add_action( 'delete_post_' . self::POST_TYPE, [ __CLASS__, 'clear_cache' ] );
		add_action( 'added_post_meta', [ __CLASS__, 'clear_cache_on_template_id_change' ], 10, 3 );
		add_action( 'updated_post_meta', [ __CLASS__, 'clear_cache_on_template_id_change' ], 10, 3 );
		add_action( 'deleted_post_meta', [ __CLASS__, 'clear_cache_on_template_id_change' ], 10, 3 );
	}

	/**
	 * Clear persistent and request-local template lookup data.
	 *
	 * @return void
	 */

	public static function clear_cache() {
		// DATA INTEGRITY INVARIANT: No save or permanent deletion may leave
		// subsequent selection on the request-local pre-mutation template lookup.
		self::$request_data = null;
		WPHAVE_Internal_Post_Type_Cache::invalidate( self::POST_TYPE );
	}

	/**
	 * Invalidate template lookup data after a direct template-ID mutation.
	 *
	 * @param int    $meta_id Metadata row ID.
	 * @param int    $post_id Template post ID.
	 * @param string $meta_key Metadata key.
	 * @return void
	 */

	public static function clear_cache_on_template_id_change( $meta_id, $post_id, $meta_key ) {
		if( self::META_TEMPLATE_ID !== $meta_key || self::POST_TYPE !== get_post_type( $post_id ) ) {
			return;
		}

		// DATA INTEGRITY INVARIANT: The canonical template ID may be written
		// independently of post content and must immediately update selection.
		self::clear_cache();
	}

}

WPHAVE_Templates::init();
