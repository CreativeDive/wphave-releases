<?php
/** Shared context identifier contract, mirrored by the JavaScript color model. */
if (!defined('ABSPATH')) {
	exit();
}

function wphave_normalize_color_context_id($value): string {
	if (!is_string($value)) {
		return '';
	}
	return trim(preg_replace('/[^a-z0-9_-]+/', '-', strtolower($value)), '-');
}
