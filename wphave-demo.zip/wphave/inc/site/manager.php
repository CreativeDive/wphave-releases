<?php

/**
 * Handles general site-level WordPress behavior.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPHAVE_Site_Manager {

	/**
	 * Initialize the component.
	 *
	 * @var array
	 */

	private $settings = [];

	/**
	 * Initialize the component.
	 *
	 * @var array
	 */

	private $performance_settings = [];

	/**
	 * Initialize site manager.
	 *
	 * Loads settings and registers site-level feature hooks.
	 */

	public function __construct() {
		$this->settings = wphave_data_get( 'site_settings', 'general', [] ) ?? [];
		$this->performance_settings = wphave_data_get( 'site_settings', 'advanced.performance', [] ) ?? [];

		add_action( 'init', [ $this, 'init_features' ], 1 );
	}

	/**
	 * Initializes all site-level features based on settings.
	 */

	public function init_features() {
		$this->remove_wp_emoji();
		$this->disable_rss_feeds();
		$this->disable_comments();
		$this->disable_pings();
	}

	/**
	 * Reads current general site settings.
	 */

	private function is_enabled( string $key ): bool {
		return ! empty( $this->settings[ $key ] );
	}

	/**
	 * Comments disabled.
	 *
	 * @return bool Comments disabled.
	 */

	private function comments_disabled(): bool {
		return ! empty( $this->settings['comments']['disabled'] );
	}

	/**
	 * Pingbacks and trackbacks disabled.
	 *
	 * @return bool Pingbacks and trackbacks disabled.
	 */

	private function pings_disabled(): bool {
		return ! empty( $this->settings['comments']['disable_pings'] );
	}

	/**
	 * Removes WordPress emoji scripts, styles and content filters.
	 */

	private function remove_wp_emoji() {
		if( ! function_exists( 'wphave_optimization_has_pro_access' ) || ! wphave_optimization_has_pro_access() ) return;

		$is_disabled = isset( $this->performance_settings['disable_wp_emoji'] ) ? (bool) $this->performance_settings['disable_wp_emoji'] : true;

		if( ! $is_disabled ) {
			return;
		}

		remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
		remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
		remove_action( 'admin_print_styles', 'print_emoji_styles' );
		remove_action( 'wp_print_styles', 'print_emoji_styles' );
		remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
		remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
		remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
		add_filter( 'tiny_mce_plugins', [ $this, 'remove_tinymce_emoji' ] );
	}

	/**
	 * Remove the TinyMCE emoji.
	 *
	 * @param array $plugins
	 * @return array
	 */

	public function remove_tinymce_emoji( $plugins ) {
		if( ! is_array( $plugins ) ) {
			return array();
		}

		return array_diff( $plugins, array( 'wpemoji' ) );
	}

	/**
	 * Removes RSS feed discovery links and blocks direct feed endpoints.
	 */

	private function disable_rss_feeds() {
		if( ! $this->is_enabled( 'wp_feed_links' ) ) {
			return;
		}

		remove_action( 'wp_head', 'feed_links', 2 );
		remove_action( 'wp_head', 'feed_links_extra', 3 );

		add_action( 'do_feed', [ $this, 'render_disabled_feed' ], 1 );
		add_action( 'do_feed_rdf', [ $this, 'render_disabled_feed' ], 1 );
		add_action( 'do_feed_rss', [ $this, 'render_disabled_feed' ], 1 );
		add_action( 'do_feed_rss2', [ $this, 'render_disabled_feed' ], 1 );
		add_action( 'do_feed_atom', [ $this, 'render_disabled_feed' ], 1 );
		add_action( 'do_feed_rss2_comments', [ $this, 'render_disabled_feed' ], 1 );
		add_action( 'do_feed_atom_comments', [ $this, 'render_disabled_feed' ], 1 );
	}

	/**
	 * Shows a simple message when a disabled feed endpoint is requested.
	 */

	public function render_disabled_feed() {
		wp_die(
			esc_html__( 'No feed available, please visit our', 'wphave' ) . ' <a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Homepage', 'wphave' ) . '</a>!'
		);
	}

	/**
	 * Globally disables frontend comment output and comment submissions.
	 * This is stronger than WordPress' default_comment_status option, which
	 * only affects newly created posts.
	 */

	private function disable_comments() {
		if( ! $this->comments_disabled() ) {
			return;
		}

		add_filter( 'comments_open', '__return_false', 20 );
		add_filter( 'comments_array', [ $this, 'hide_comments' ], 20 );
		add_filter( 'get_comments_number', [ $this, 'hide_comments_number' ], 20 );
		add_filter( 'feed_links_show_comments_feed', '__return_false', 20 );
		add_filter( 'post_comments_feed_link_html', '__return_empty_string', 20 );
		add_action( 'pre_comment_on_post', [ $this, 'block_comment_submission' ], 1 );
	}

	/**
	 * Hide the comments.
	 *
	 * @param array $comments
	 * @return array
	 */

	public function hide_comments( $comments ) {
		return is_admin() ? $comments : array();
	}

	/**
	 * Hide the comments number.
	 *
	 * @param int|string $count
	 * @return int|string
	 */

	public function hide_comments_number( $count ) {
		return is_admin() ? $count : 0;
	}

	/**
	 * Prevents direct comment submissions even if a theme or plugin renders
	 * its own form.
	 */

	public function block_comment_submission() {
		if( is_admin() ) {
			return;
		}

		wp_die( esc_html__( 'Comments are disabled.', 'wphave' ), 403 );
	}

	/**
	 * Globally blocks incoming and outgoing pingbacks and trackbacks without
	 * changing the individual status stored on existing posts.
	 */

	private function disable_pings() {
		if( ! $this->pings_disabled() ) {
			return;
		}

		add_filter( 'pings_open', '__return_false', PHP_INT_MAX );
		add_filter( 'get_default_comment_status', [ $this, 'close_default_pings' ], PHP_INT_MAX, 3 );
		add_action( 'pre_ping', [ $this, 'clear_outgoing_pingbacks' ], PHP_INT_MAX, 1 );
		add_filter( 'get_to_ping', '__return_empty_array', PHP_INT_MAX );
		add_filter( 'xmlrpc_methods', [ $this, 'remove_pingback_xmlrpc_methods' ], PHP_INT_MAX );
	}

	/**
	 * Closes the effective default only for pingbacks and trackbacks.
	 */

	public function close_default_pings( $status, $post_type, $comment_type ) {
		return in_array( $comment_type, [ 'pingback', 'trackback' ], true ) ? 'closed' : $status;
	}

	/**
	 * Removes links before WordPress sends outgoing pingbacks.
	 */

	public function clear_outgoing_pingbacks( &$links ) {
		$links = array();
	}

	/**
	 * Removes incoming XML-RPC pingback methods while the global block is active.
	 */

	public function remove_pingback_xmlrpc_methods( $methods ) {
		unset( $methods['pingback.ping'], $methods['pingback.extensions.getPingbacks'] );
		return $methods;
	}
}

/**
 * Initialize the site manager after plugins have loaded.
 *
 * @return void
 */

function wphave_initialize_site_manager() {
	new WPHAVE_Site_Manager();
}

add_action( 'plugins_loaded', 'wphave_initialize_site_manager' );
