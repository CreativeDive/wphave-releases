<?php

if (!defined('ABSPATH')) {
	exit();
}

require_once __DIR__ . '/color-context-model.php';

/**
 * Converts structured global data into CSS output.
 *
 * Responsibilities:
 * - Build CSS strings from structured arrays
 * - Generate global CSS variables (Design Tokens)
 * - Compose full global stylesheet string
 * - Provide component styles (Typography, Buttons, Links)
 * - Handle physical and semantic color scales, RGB values and color modes
 *
 * Architectural Role:
 * This class acts as the "CSS Compiler Layer"
 * between:
 *
 *   WPHAVE_Global_Data  → raw structured design data
 *   WPHAVE_Style_Engine → final CSS output handler
 *
 * In short:
 * → DATA → CSS → OUTPUT
 */

class WPHAVE_Global_Styles {
	/**
	 * Converts structured style arrays into flat CSS strings.
	 *
	 * This is used as a low-level compiler utility across the system.
	 *
	 * Supported syntax inside $array:
	 * - Standard selectors
	 * - @media queries
	 * - @keyframes animations
	 * - @import rules
	 * - @cssvars (raw CSS variables block)
	 *
	 * Important Output Order:
	 * 1. @import rules
	 * 2. base styles
	 * 3. media queries (always last!)
	 *
	 * @param array $array Structured CSS definition
	 * @return string Compiled CSS string
	 */

	public static function build_css_from_array($array) {
		$css = [];
		$import_css = [];
		$media_css = [];

		foreach ($array as $key => $value) {
			$is_custom_properties = strpos($key, '@cssvars') !== false;
			$is_media_query = strpos($key, '@media') !== false;
			$is_keyframes = strpos($key, '@keyframes') !== false;
			$is_import = strpos($key, '@import') !== false;

			/**
			 * CSS variables block
			 */

			if ($is_custom_properties) {
				$css[] = $value;

				/**
				 * Media queries
				 */
			} elseif ($is_media_query) {
				$media_css[] = $key . ' {';

				foreach ($value as $selector => $styles) {
					if (is_array($styles)) {
						$media_css[] = $selector . ' {';
						foreach ($styles as $property => $style) {
							$media_css[] = $property . ': ' . $style . ';';
						}
						$media_css[] = '}';
					}
				}

				$media_css[] = '}';

				/**
				 * Keyframes
				 */
			} elseif ($is_keyframes) {
				$css[] = $key . ' {';

				foreach ($value as $percentage => $styles) {
					$css[] = $percentage . ' {';

					foreach ($styles as $property => $style) {
						$css[] = $property . ': ' . $style . ';';
					}

					$css[] = '}';
				}

				$css[] = '}';

				/**
				 * Imports
				 */
			} elseif ($is_import) {
				if (is_array($value)) {
					foreach ($value as $url) {
						//$import_css[] = $key . " url('" . $url . "');";
						$import_css[] = $key . ' ' . $url . ';';
					}
				} else {
					//$import_css[] = $key . " url('" . $value . "');";
					$import_css[] = $key . ' ' . $value . ';';
				}

				/**
				 * Standard CSS blocks
				 */
			} else {
				if (is_array($value)) {
					$css[] = $key . ' {';

					foreach ($value as $property => $style) {
						$css[] = $property . ': ' . $style . ';';
					}

					$css[] = '}';
				}
			}
		}

		// ! [$import_css] must be at first position
		// ! [$media_css] must be at last position
		return implode('', $import_css) . implode('', $css) . implode('', $media_css);
	}

	/**
	 * Main entry point for generating full CSS output.
	 *
	 * Combines:
	 * - Fonts
	 * - CSS variables
	 * - Typography
	 * - Links
	 * - Buttons
	 *
	 * @param array $wphave
	 * @param array $args
	 * @return string
	 */

	public static function compose_global_styles_string($wphave = [], $args = []) {
		/* <- {event tracking} -> */

		wphave_events('GET', 'Site global styles string.');

		$globals = WPHAVE_Global_Data::get_base($wphave);

		$forms = $globals['forms'] ?? [];
		$links = $globals['links'] ?? [];
		$layout = $globals['layout'] ?? [];
		$buttons = $globals['buttons'] ?? [];
		$typography = $globals['typography'] ?? [];

		$css_vars = self::site_css_variables($wphave, $args);
		$include_link_styles = array_key_exists('include_link_styles', $args)
			? (bool) $args['include_link_styles']
			: true;
		$link_styles = $include_link_styles ? self::get_global_link_styles($links) : '';
		$button_styles = self::get_global_button_preset_styles($buttons);
		$typography_styles = self::get_global_typography_element_styles($typography);
		$imported_fonts = self::get_global_fonts_import($globals, $args);
		// OWNERSHIP INVARIANT: Composition previews pass their own typography snapshot and must never
		// inherit local-font CSS from the currently active website.
		$include_local_fonts = array_key_exists('include_local_fonts', $args)
			? (bool) $args['include_local_fonts']
			: empty($wphave);
		$local_font_styles = $include_local_fonts ? WPHAVE_Fonts::local_fonts_css() : '';

		// ! [$imported_fonts] and [$local_font_styles] should be at first position
		return $imported_fonts .
			$local_font_styles .
			$css_vars .
			$typography_styles .
			$link_styles .
			$button_styles;
	}

	/**
	 * Generates ALL global CSS variables used by the system.
	 *
	 * Controlled via $args flags:
	 * - global_vars → core variables
	 * - color_mode_vars → alternate color-mode overrides
	 * - colors_rgb_vars → RGB variants
	 * - palette_color_vars → editor palette
	 * - color_context_vars → scoped semantic color contexts
	 * - color_scales_vars → physical and semantic color scales
	 *
	 * This is the core "Design Token Generator".
	 *
	 * @param array $wphave
	 * @param array $args
	 * @return string
	 */

	private static function site_css_variables($wphave = [], $args = []) {
		$wphave = WPHAVE_Global_Data::get_base($wphave);
		foreach (
			is_array($wphave['typography'] ?? null) ? $wphave['typography'] : []
			as $role => $typography
		) {
			$typography = WPHAVE_Font_Resolver::effective_typography(
				$role,
				$typography,
				$args['font_context'] ?? null,
			);
			if (!empty($typography['family']['name'])) {
				$typography['family']['name'] = WPHAVE_Fonts::css_font_family(
					$typography['family']['name'],
				);
			}
			$wphave['typography'][$role] = $typography;
		}

		$root = $args['root'] ?? true; // Wrapped in ":root {}"
		$use_global_vars = $args['global_vars'] ?? true; // Global vars generated from site settings
		$use_color_mode_vars = $args['color_mode_vars'] ?? true; // Site color mode vars from settings
		$use_colors_rgb_vars = $args['colors_rgb_vars'] ?? true; // Site setting color RGB variants
		$use_palette_color_vars = $args['palette_color_vars'] ?? true; // Palette color vars
		$use_color_context_vars = $args['color_context_vars'] ?? true;
		$use_color_scales_vars = $args['color_scales_vars'] ?? true;

		$global_vars = $use_global_vars
			? WPHAVE_Global_Data::generate_css_variables($root, $wphave)
			: '';
		$design_gradient_vars = $use_global_vars
			? self::get_design_gradient_vars($root, $wphave)
			: '';
		$global_color_mode_vars = $use_color_mode_vars
			? self::get_global_color_mode_vars($root, $wphave)
			: '';
		$global_palette_color_vars = $use_palette_color_vars
			? self::get_global_palette_color_vars($root)
			: '';
		$global_color_context_vars = $use_color_context_vars
			? self::get_color_context_vars($wphave)
			: '';
		$global_color_scales_vars = $use_color_scales_vars
			? self::get_site_color_scales_vars($root, $wphave)
			: '';
		$global_colors_rgb_vars = $use_colors_rgb_vars
			? self::get_site_colors_rgb_vars($root, $wphave, $use_color_scales_vars)
			: '';

		return $global_vars .
			$design_gradient_vars .
			$global_color_scales_vars .
			$global_colors_rgb_vars .
			$global_color_mode_vars .
			$global_palette_color_vars .
			$global_color_context_vars;
	}

	/**
	 * Extracts all Google Fonts from typography settings
	 * and generates a single @import statement.
	 *
	 * Important:
	 * - Only active if explicitly enabled via args
	 * - Avoids duplicate font imports
	 *
	 * @param array $globals
	 * @param array $args
	 * @return string
	 */

	private static function get_global_fonts_import($globals = [], $args = []) {
		$typography = $globals['typography'] ?? [];
		$import_google_fonts = $args['import_google_fonts'] ?? false;

		if (!$import_google_fonts) {
			return '';
		}

		$fonts_url = WPHAVE_Fonts::google_webfonts_url([
			'loading' => 'import',
			'fonts' => self::get_global_google_font_items($typography),
		]);

		return $fonts_url ? "@import url('{$fonts_url}');" : '';
	}

	/**
	 * Output Google font family names loaded externally and defined in the site typography settings.
	 */

	public static function get_global_google_fonts($settings) {
		$font_family_names = [];
		foreach ($settings as $text_element => $data) {
			$font_family = $data['family'] ?? [];
			$font_family_type = $font_family['type'] ?? '';
			$font_family_name = $font_family['name'] ?? '';

			if ($font_family_type === 'google-fonts' && $font_family_name) {
				$font_family_names[] = $font_family_name;
			}
		}

		return $font_family_names;
	}

	/**
	 * Output Google font items including variants for direct typography imports.
	 *
	 * @param array $settings
	 * @return array
	 */

	private static function get_global_google_font_items($settings) {
		$font_items = [];

		foreach ($settings as $text_element => $data) {
			$font_family = $data['family'] ?? [];
			$font_family_type = $font_family['type'] ?? '';
			$font_family_name = $font_family['name'] ?? '';
			$font_weight = $data['weight'] ?? '';
			$font_key = strtolower(WPHAVE_Fonts::canonical_font_family($font_family_name));

			if ($font_family_type === 'google-fonts' && $font_family_name) {
				if (!isset($font_items[$font_key])) {
					$font_items[$font_key] = [
						'font' => $font_family_name,
						'variants' => [],
						'subsets' => ['latin'],
					];
				}

				$font_items[$font_key]['variants'] = array_values(
					array_unique(
						array_filter(
							array_merge($font_items[$font_key]['variants'], [
								(string) $font_weight,
							]),
						),
					),
				);
			}
		}

		return array_map(function ($font) {
			if (empty($font['variants'])) {
				$font['variants'] = ['400'];
			}

			return $font;
		}, array_values($font_items));
	}

	/**
	 * Outputs:
	 * --wphave-site-color-palette-*
	 *
	 * @param bool $root
	 * @return string
	 */

	public static function get_global_palette_color_vars($root = true) {
		$css = [];
		$palette_colors = wphave_color_collection() ?: [];

		if ($root) {
			$css[] = ':root {';
		}

		$i = 0;
		if ($palette_colors) {
			foreach ($palette_colors as $color) {
				$slug =
					isset($color['slug']) && $color['slug']
						? $color['slug']
						: 'undefined-slug-' . $i;
				$hex = isset($color['color']) && $color['color'] ? $color['color'] : '';
				$css[] = '--wphave-site-color-palette-' . $slug . ': ' . $hex . ';';
				if (wphave_is_valid_hex($hex)) {
					$css[] =
						'--wphave-site-color-palette-' .
						$slug .
						'-rgb: ' .
						implode(', ', wphave_hex_to_rgb($hex)) .
						';';
				}
				$i++;
			}
		}

		// Add user defined color to color palette vars
		$user_colors = wphave_data_get('site_settings', 'editor.presets.colors', []) ?: [];

		$i = 0;
		if ($user_colors) {
			foreach ($user_colors as $color) {
				$slug = isset($color['slug']) && $color['slug'] ? $color['slug'] : 'custom-' . $i;
				$hex = isset($color['color']) && $color['color'] ? $color['color'] : '';
				$css[] = '--wphave-site-color-palette-' . $slug . ': ' . $hex . ';';
				if (wphave_is_valid_hex($hex)) {
					$css[] =
						'--wphave-site-color-palette-' .
						$slug .
						'-rgb: ' .
						implode(', ', wphave_hex_to_rgb($hex)) .
						';';
				}
				$i++;
			}
		}

		if ($root) {
			$css[] = '}';
		}

		return implode('', $css);
	}

	/**
	 * Outputs variables for:
	 * :root[data-wphave-color-mode="alternate"]
	 *
	 * @param bool $root
	 * @param array $wphave
	 * @return string
	 */

	public static function get_global_color_mode_vars($root = true, $wphave = []) {
		$colors = $wphave['colors'] ?? [];

		$css = [];

		if ($root) {
			$css[] = ':root[data-wphave-color-mode="alternate"] {';
		}

		foreach ($colors as $key => $color) {
			$color_key = wphave_camel_to_kebab_case($key);
			$color_mode_base_color = $color['colorMode']['base'] ?? '';

			if ($color_mode_base_color) {
				$css[] = "--wphave-site-color-{$color_key} : {$color_mode_base_color};";
				$contrast_direction =
					$color['colorMode']['contrastDirection'] ??
					($color['contrastDirection'] ?? 'auto');
				$css[] = self::get_color_scales_vars(
					$color_mode_base_color,
					$color_key,
					$contrast_direction,
				);
			}

			$gradient = $color['colorMode']['gradient'] ?? ($color['gradient'] ?? []);
			$gradient_css = self::design_gradient_to_css($gradient);
			if (
				in_array($key, ['primary', 'secondary', 'tertiary', 'accent'], true) &&
				$gradient_css
			) {
				$declaration = safecss_filter_attr(
					'--wphave-site-gradient-' . $key . ': ' . $gradient_css,
				);
				if ($declaration) {
					$css[] =
						rtrim(
							html_entity_decode($declaration, ENT_QUOTES | ENT_HTML5, 'UTF-8'),
							';',
						) . ';';
				}
			}
		}

		if ($root) {
			$css[] = '}';
		}

		return implode('', $css);
	}

	/**
	 * Generate the default-mode Design Gradient custom properties.
	 *
	 * @param bool  $root Wrap declarations in :root.
	 * @param array $wphave Global Styles data.
	 * @return string
	 */

	public static function get_design_gradient_vars($root = true, $wphave = []) {
		$css = $root ? [':root {'] : [];
		$colors = $wphave['colors'] ?? [];

		foreach (['primary', 'secondary', 'tertiary', 'accent'] as $role) {
			$gradient_css = self::design_gradient_to_css($colors[$role]['gradient'] ?? []);
			if (!$gradient_css) {
				continue;
			}

			$declaration = safecss_filter_attr(
				'--wphave-site-gradient-' . $role . ': ' . $gradient_css,
			);
			if ($declaration) {
				$css[] =
					rtrim(html_entity_decode($declaration, ENT_QUOTES | ENT_HTML5, 'UTF-8'), ';') .
					';';
			}
		}

		if ($root) {
			$css[] = '}';
		}
		return implode('', $css);
	}

	/**
	 * Serialize the shared single-gradient data model defensively.
	 *
	 * @param array $gradient Structured gradient.
	 * @return string
	 */

	private static function design_gradient_to_css($gradient) {
		if (
			!is_array($gradient) ||
			!is_array($gradient['colorStops'] ?? null) ||
			count($gradient['colorStops']) < 2
		) {
			return '';
		}

		$type = sanitize_key($gradient['type'] ?? 'linear');
		if (
			!in_array(
				$type,
				[
					'linear',
					'radial',
					'conic',
					'repeating-linear',
					'repeating-radial',
					'repeating-conic',
				],
				true,
			)
		) {
			return '';
		}

		$stops = $gradient['colorStops'];
		usort(
			$stops,
			static fn($left, $right) => (float) ($left['position'] ?? 0) <=>
				(float) ($right['position'] ?? 0),
		);
		$serialized_stops = [];
		foreach ($stops as $stop) {
			if (
				!is_array($stop) ||
				!is_string($stop['color'] ?? null) ||
				!is_numeric($stop['position'] ?? null)
			) {
				return '';
			}
			$serialized_stops[] =
				trim($stop['color']) . ' ' . round((float) $stop['position']) . '%';
		}

		$angle = is_numeric($gradient['angle'] ?? null) ? (float) $gradient['angle'] : 0;
		$position = $gradient['position'] ?? 'left';
		$position_css = is_array($position)
			? (float) ($position['x'] ?? 50) . '% ' . (float) ($position['y'] ?? 50) . '%'
			: str_replace('-', ' ', sanitize_key($position));

		if (false !== strpos($type, 'linear')) {
			$placement = $angle . 'deg';
		} elseif (false !== strpos($type, 'conic')) {
			$placement =
				$angle > 0 ? 'from ' . $angle . 'deg at ' . $position_css : 'at ' . $position_css;
		} else {
			$shape = sanitize_key($gradient['radialShape'] ?? 'circle');
			if ('size' === $shape) {
				$size = is_array($gradient['radialSize'] ?? null) ? $gradient['radialSize'] : [];
				$placement =
					(float) ($size['x'] ?? 60) .
					'% ' .
					(float) ($size['y'] ?? 60) .
					'% at ' .
					$position_css;
			} elseif (false !== strpos($shape, '-side') || false !== strpos($shape, '-corner')) {
				$placement = $shape;
			} else {
				$placement = $shape . ' at ' . $position_css;
			}
		}

		return $type . '-gradient(' . $placement . ', ' . implode(', ', $serialized_stops) . ')';
	}

	/**
	 * Generates physical and semantic color scale variables.
	 *
	 * @param string $color
	 * @param string $key
	 * @param bool $reverse
	 * @return string
	 */

	public static function get_color_scales_vars($color, $color_key, $contrast_direction = 'auto') {
		$css = [];

		$scales = wphave_get_color_scales($color, 10, $contrast_direction);
		foreach (['lighter', 'darker', 'contrast', 'subtle'] as $scale_name) {
			foreach ($scales[$scale_name] ?? [] as $index => $scale_color) {
				$number = $index + 1;
				$css[] = "--wphave-site-color-{$color_key}-{$scale_name}-{$number} : {$scale_color};";
			}
		}

		return implode('', $css);
	}

	/**
	 * Generates all design color scales.
	 *
	 * @param string $color
	 * @param string $key
	 * @param bool $reverse
	 * @return string
	 */

	public static function get_site_color_scales_vars($root = true, $wphave = []) {
		$colors = $wphave['colors'] ?? [];

		$css = [];

		if ($root) {
			$css[] = ':root {';
		}

		foreach ($colors as $key => $color) {
			$base_color = $color['base'] ?? '';
			$contrast_direction = $color['contrastDirection'] ?? 'auto';

			if (!$base_color) {
				continue;
			}

			$css[] = self::get_color_scales_vars($base_color, $key, $contrast_direction);
		}

		if ($root) {
			$css[] = '}';
		}

		return implode('', $css);
	}

	/**
	 * Converts HEX → RGB variables
	 *
	 * @param bool $root
	 * @param array $wphave
	 * @return string
	 */

	public static function get_site_colors_rgb_vars(
		$root = true,
		$wphave = [],
		$color_scales = true,
	) {
		$colors = $wphave['colors'] ?? [];

		$css = [];

		if ($root) {
			$css[] = ':root {';
		}

		foreach ($colors as $color_key => $color_data) {
			$base_color = $color_data['base'] ?? '';

			// Base
			if (wphave_is_valid_hex($base_color)) {
				$rgb = wphave_hex_to_rgb($base_color);
				//$css[] = "--wphave-site-color-{$color_key}: {$base_color};";
				$css[] = "--wphave-site-color-{$color_key}-rgb: {$rgb[0]}, {$rgb[1]}, {$rgb[2]};";
			}

			if ($color_scales) {
				$scales = wphave_get_color_scales(
					$base_color,
					10,
					$color_data['contrastDirection'] ?? 'auto',
				);
				foreach (['lighter', 'darker', 'contrast', 'subtle'] as $scale_name) {
					foreach ($scales[$scale_name] ?? [] as $i => $scale_color) {
						$index = $i + 1;
						if (wphave_is_valid_hex($scale_color)) {
							$rgb = wphave_hex_to_rgb($scale_color);
							$css[] = "--wphave-site-color-{$color_key}-{$scale_name}-{$index}-rgb: {$rgb[0]}, {$rgb[1]}, {$rgb[2]};";
						}
					}
				}
			}
		}

		if ($root) {
			$css[] = '}';
		}

		return implode('', $css);
	}

	/**
	 * Generate scoped semantic variables for reusable container color contexts.
	 *
	 * Contexts override the established global variable contract, so every
	 * descendant block automatically follows the nearest context through normal
	 * CSS inheritance without requiring block-specific color handling.
	 *
	 * @param array $wphave Global design data.
	 * @return string
	 */

	public static function get_color_context_vars($wphave = []) {
		$colors = $wphave['colors'] ?? [];
		$contexts = array_slice(
			is_array($wphave['colorContexts'] ?? null) ? $wphave['colorContexts'] : [],
			0,
			3,
		);
		$links = $wphave['links']['colors'] ?? [];
		$buttons = $wphave['buttons'] ?? [];
		$forms = $wphave['forms']['colors'] ?? [];
		$allowed_keys = [
			'primary',
			'secondary',
			'tertiary',
			'accent',
			'error',
			'background',
			'text',
			'heading',
			'icon',
			'tooltip',
			'tooltipText',
			'overlay',
			'price',
		];
		$button_variants = ['primary', 'secondary', 'tertiary', 'ghost'];
		$button_color_keys = [
			'text',
			'textHover',
			'border',
			'borderHover',
			'background',
			'backgroundHover',
		];
		$form_color_keys = [
			'text',
			'textHover',
			'placeholder',
			'border',
			'borderHover',
			'background',
			'backgroundHover',
		];
		$definitions = [
			'default' => [
				'colors' => [],
				'links' => $links,
				'buttons' => [],
				'forms' => $forms,
			],
			'alternate' => [
				'colors' => [],
				'links' => $links,
				'buttons' => [],
				'forms' => $forms,
			],
		];

		foreach ($allowed_keys as $key) {
			$default_color = $colors[$key]['base'] ?? '';
			$alternate_color = $colors[$key]['colorMode']['base'] ?? $default_color;
			$default_direction = $colors[$key]['contrastDirection'] ?? 'auto';
			$alternate_direction =
				$colors[$key]['colorMode']['contrastDirection'] ?? $default_direction;

			if ($default_color) {
				$definitions['default']['colors'][$key] = [
					'base' => $default_color,
					'contrastDirection' => $default_direction,
				];
			}
			if ($alternate_color) {
				$definitions['alternate']['colors'][$key] = [
					'base' => $alternate_color,
					'contrastDirection' => $alternate_direction,
				];
			}
		}

		foreach ($button_variants as $variant) {
			$definitions['default']['buttons'][$variant] = $buttons[$variant]['colors'] ?? [];
			$definitions['alternate']['buttons'][$variant] = $buttons[$variant]['colors'] ?? [];
		}

		foreach ($contexts as $context) {
			$id = wphave_normalize_color_context_id($context['id'] ?? '');
			if (!$id || in_array($id, ['default', 'alternate'], true)) {
				continue;
			}

			$definitions[$id] =
				'alternate' === ($context['source'] ?? 'default')
					? $definitions['alternate']
					: $definitions['default'];
			foreach ($allowed_keys as $key) {
				$context_color = $context['colors'][$key] ?? [];
				$base_color = $context_color['base'] ?? '';
				if ($base_color && wphave_is_valid_hex($base_color)) {
					$definitions[$id]['colors'][$key] = [
						'base' => $base_color,
						'contrastDirection' => $context_color['contrastDirection'] ?? 'auto',
					];
				}
			}
			foreach (['text', 'textHover'] as $key) {
				if (
					!empty($context['links']['colors'][$key]) &&
					wphave_is_valid_hex($context['links']['colors'][$key])
				) {
					$definitions[$id]['links'][$key] = $context['links']['colors'][$key];
				}
			}
			foreach ($button_variants as $variant) {
				foreach ($button_color_keys as $key) {
					if (
						!empty($context['buttons'][$variant]['colors'][$key]) &&
						wphave_is_valid_hex($context['buttons'][$variant]['colors'][$key])
					) {
						$definitions[$id]['buttons'][$variant][$key] =
							$context['buttons'][$variant]['colors'][$key];
					}
				}
			}
			foreach ($form_color_keys as $key) {
				if (
					!empty($context['forms']['colors'][$key]) &&
					wphave_is_valid_hex($context['forms']['colors'][$key])
				) {
					$definitions[$id]['forms'][$key] = $context['forms']['colors'][$key];
				}
			}
		}

		$css = [];
		foreach ($definitions as $id => $definition) {
			if (empty($definition['colors'])) {
				continue;
			}

			$css[] =
				':root[data-wphave-color-context="' .
				esc_attr($id) .
				'"], [data-wphave-color-context="' .
				esc_attr($id) .
				'"] {';
			if (!empty($definition['colors']['text']['base'])) {
				$css[] = 'color: var(--wphave-site-color-text);';
			}
			foreach ($definition['colors'] as $key => $color) {
				$color_key = wphave_camel_to_kebab_case($key);
				$css[] =
					'--wphave-site-color-' . $color_key . ': ' . esc_html($color['base']) . ';';
				if (wphave_is_valid_hex($color['base'])) {
					$rgb = wphave_hex_to_rgb($color['base']);
					$css[] =
						'--wphave-site-color-' .
						$color_key .
						'-rgb: ' .
						(int) $rgb[0] .
						', ' .
						(int) $rgb[1] .
						', ' .
						(int) $rgb[2] .
						';';
				}
				$css[] = self::get_color_scales_vars(
					$color['base'],
					$color_key,
					$color['contrastDirection'],
				);
			}
			foreach ($definition['links'] as $key => $color) {
				$suffix = 'textHover' === $key ? '-hover' : '';
				$css[] = '--wphave-site-color-link' . $suffix . ': ' . esc_html($color) . ';';
			}
			foreach ($definition['buttons'] as $variant => $variant_colors) {
				$variant_suffix = 'primary' === $variant ? '' : '-' . $variant;
				foreach ($variant_colors as $key => $color) {
					$color_suffix =
						'text' === $key
							? ''
							: '-' . wphave_camel_to_kebab_case(preg_replace('/^text/', '', $key));
					$css[] =
						'--wphave-site-color-button' .
						$variant_suffix .
						$color_suffix .
						': ' .
						esc_html($color) .
						';';
				}
			}
			foreach ($definition['forms'] as $key => $color) {
				$color_suffix =
					'text' === $key
						? ''
						: '-' . wphave_camel_to_kebab_case(preg_replace('/^text/', '', $key));
				$css[] = '--wphave-site-color-form' . $color_suffix . ': ' . esc_html($color) . ';';
			}
			$css[] = '}';
		}

		return implode('', $css);
	}

	/**
	 * Applies the selected Link Style.
	 *
	 * Note:
	 * Styles are applied to `.wphave-text-link` (JS controlled).
	 *
	 * @param array $data
	 * @return string
	 */

	public static function get_global_link_styles($data) {
		$link_style = $data['style'] ?? 'default';

		$link_styles = wphave_link_style([
			'style' => $link_style,
			'outputType' => 'css',
		]);

		return $link_styles;
	}

	/**
	 * Define custom typography elements for h1, h2, h3, h4, h5, h6 and buttons.
	 *
	 * @return array
	 */

	public static function individual_typography_elements() {
		return [
			[
				'value' => 'buttons',
				'label' => __('Buttons', 'wphave'),
				'icon' => 'buttons',
				'selectors' => '.wp-block-wphave-button',
			],
			[
				'value' => 'h1',
				'label' => 'H1 ' . __('Heading', 'wphave'),
				'icon' => 'h1',
				'selectors' => 'h1, .wphave-fstyle-heading-h1',
			],
			[
				'value' => 'h2',
				'label' => 'H2 ' . __('Heading', 'wphave'),
				'icon' => 'h2',
				'selectors' => 'h2, .wphave-fstyle-heading-h2',
			],
			[
				'value' => 'h3',
				'label' => 'H3 ' . __('Heading', 'wphave'),
				'icon' => 'h3',
				'selectors' => 'h3, .wphave-fstyle-heading-h3',
			],
			[
				'value' => 'h4',
				'label' => 'H4 ' . __('Heading', 'wphave'),
				'icon' => 'h4',
				'selectors' => 'h4, .wphave-fstyle-heading-h4',
			],
			[
				'value' => 'h5',
				'label' => 'H5 ' . __('Heading', 'wphave'),
				'icon' => 'h5',
				'selectors' => 'h5, .wphave-fstyle-heading-h5',
			],
			[
				'value' => 'h6',
				'label' => 'H6 ' . __('Heading', 'wphave'),
				'icon' => 'h6',
				'selectors' => 'h6, .wphave-fstyle-heading-h6',
			],
			[
				'value' => 'subheadings',
				'label' => __('Subheadings', 'wphave'),
				'icon' => 'hover',
				'selectors' => '.wphave-fstyle-subheadings',
			],
			[
				'value' => 'labels',
				'label' => __('Labels', 'wphave'),
				'icon' => 'hover',
				'selectors' => '.wphave-fstyle-labels',
			],
			[
				'value' => 'captions',
				'label' => __('Captions', 'wphave'),
				'icon' => 'hover',
				'selectors' => '.wphave-fstyle-captions',
			],
			[
				'value' => 'footnotes',
				'label' => __('Footnotes', 'wphave'),
				'icon' => 'hover',
				'selectors' => '.wphave-fstyle-footnotes',
			],
		];
	}

	/**
	 * Generates CSS for:
	 * - headings
	 * - buttons
	 *
	 * @param array $settings
	 * @return string
	 */

	public static function get_global_typography_element_styles($settings) {
		$elements = self::individual_typography_elements();

		$css = [];

		foreach ($elements as $element) {
			$key = $element['value'] ?? '';
			$selector = $element['selectors'] ?? '';

			$is_custom = $settings[$key] ?? '';

			if ($is_custom) {
				$css[] =
					$selector .
					" {
                    font-family: var(--wphave-site-typo-{$key}-family)!important;
                    font-weight: var(--wphave-site-typo-{$key}-font-weight)!important;
                    font-variant: var(--wphave-site-typo-{$key}-font-variant)!important;
                    text-transform: var(--wphave-site-typo-{$key}-transform)!important;
                    line-height: var(--wphave-site-typo-{$key}-line-height)!important;
                    font-size: clamp( var(--wphave-site-typo-{$key}-font-size-min), 3vmin, var(--wphave-site-typo-{$key}-font-size-max) )!important;
                }";
			}
		}

		return implode('', $css);
	}

	/**
	 * Applies selected button presets
	 *
	 * @param array $data
	 * @return string
	 */

	public static function get_global_button_preset_styles($data) {
		$types = ['primary', 'secondary', 'tertiary', 'ghost'];

		$css = [];

		foreach ($types as $type => $key) {
			$button_type = $data[$key]['type'] ?? 'default';
			$button_preset = $data[$key]['preset'] ?? '0';

			if ($button_type === 'preset') {
				$button_preset = wphave_button_style([
					'type' => $key,
					'style' => $button_preset,
				]);
				$css[] = self::build_css_from_array($button_preset);
			}
		}

		return implode('', $css);
	}
}
