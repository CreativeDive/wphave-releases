<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Render the configured Global Styles background through the WPHAVE pipeline.
 */

class WPHAVE_Global_Background {

	private const ID = 'wphave-site-background';

	public static function boot(): void {
		add_filter( 'wphave_post_render_before', array( __CLASS__, 'render' ), 5 );
	}

	/**
	 * Prepend the decorative site background to the rendered canvas content.
	 *
	 * @param string $content Existing pipeline content.
	 * @return string
	 */

	public static function render( $content = '' ): string {
		$globals = WPHAVE_Global_Data::get_base();
		$background = is_array( $globals['background'] ?? null ) ? $globals['background'] : array();
		$background = apply_filters( 'wphave_global_background_data', $background, $globals );

		return self::render_background( $background, $content );
	}

	/**
	 * Render normalized Global Styles background data.
	 *
	 * @param array  $background Global background settings.
	 * @param string $content Existing pipeline content.
	 * @return string
	 */

	public static function render_background( $background, $content = '' ): string {
		$background = is_array( $background ) ? $background : array();
		$layers = is_array( $background['layers'] ?? null ) ? $background['layers'] : array();

		if( empty( $layers ) ) {
			return (string) $content;
		}

		$behavior = sanitize_key( $background['behavior'] ?? 'scroll' );
		$behavior = in_array( $behavior, array( 'scroll', 'fixed' ), true ) ? $behavior : 'scroll';
		$wphave = array(
			'background' => array( 'layers' => $layers ),
			'classNamesBackground' => is_array( $background['classNamesBackground'] ?? null ) ? $background['classNamesBackground'] : array(),
			'stylesBackgrounds' => is_array( $background['stylesBackgrounds'] ?? null ) ? $background['stylesBackgrounds'] : array(),
		);

		self::collect_layer_styles( $wphave );
		self::collect_clip_paths( $layers );

		ob_start();
		do_action( 'block_background', $wphave, array( 'tag' => 'div' ) );
		$layers_markup = ob_get_clean();

		if( ! $layers_markup ) {
			return (string) $content;
		}

		$classes = array( 'wph-b', 'bg', 'wphave-site-background', 'is-' . $behavior );
		$markup = '<div id="' . esc_attr( self::ID ) . '" class="' . esc_attr( implode( ' ', $classes ) ) . '" aria-hidden="true">';
		$markup .= $layers_markup;
		$markup .= '</div>';

		return $markup . (string) $content;
	}

	private static function collect_layer_styles( array $wphave ): void {
		$styles = '';

		foreach( $wphave['stylesBackgrounds'] as $index => $layer_css ) {
			if( ! is_string( $layer_css ) || $layer_css === '' ) {
				continue;
			}

			$styles .= '#' . self::ID . ' > .bgly-' . absint( $index ) . '{' . $layer_css . '}';
		}

		WPHAVE_Style_Engine::instance()->add( $styles );
	}

	private static function collect_clip_paths( array $layers ): void {
		if( ! function_exists( 'wphave_call_block_clip_path_masks' ) ) {
			return;
		}

		foreach( $layers as $layer ) {
			if( is_array( $layer ) ) {
				wphave_call_block_clip_path_masks( $layer );
			}
		}
	}
}

WPHAVE_Global_Background::boot();
