<!DOCTYPE html>

<?php do_action('wphave_after_doctype'); ?>

<html
    <?php language_attributes(); ?>
    <?php if ($page_color_context): ?>
        data-wphave-color-context="<?php echo esc_attr($page_color_context); ?>"
    <?php endif; ?>
    data-wphave-color-mode="<?php echo esc_attr($color_mode_resolved); ?>"
    data-wphave-color-mode-preference="<?php echo esc_attr($color_mode_preference); ?>"
    data-wphave-color-mode-enabled="<?php echo $color_mode_enabled ? 'true' : 'false'; ?>"
>

<head <?php if (
    WPHAVE_Add_On_Manager::has('open-graph')
) { ?> prefix="og: https://ogp.me/ns#"<?php } ?>>
	<meta charset="<?php bloginfo('charset'); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5">
    <meta name="generator" content="Theme: <?php echo esc_attr(
        (defined('WPHAVE_THEME') ? WPHAVE_THEME : 'WPHAVE') .
            ' | Version: ' .
            (defined('WPHAVE_THEME_VER') ? WPHAVE_THEME_VER : ''),
    ); ?>" />
	<?php
 do_action('wphave_head_comment');
 wp_head();
 // Output block specific inline styles in the <head> via "wphave_block_inline_style" filter
 echo WPHAVE_Style_Engine::instance()->print_site_head_styles();

// phpcs:ignore WordPress.Security.EscapeOutput
?>
</head>

<body <?php body_class(); ?>>
	<?php
 if (function_exists('wp_body_open')) {
     wp_body_open();
 }

 do_action('wphave_after_body_open');

 // !!! PASSWORD PROTECTED PAGE BEGINS HERE
 do_action('wphave_template_part_password_protection');

 // BLOCK CONTENT
 echo $block_content; // phpcs:ignore WordPress.Security.EscapeOutput

 wp_footer();

 do_action('wphave_before_body_close');
 ?>
</body>

</html>
