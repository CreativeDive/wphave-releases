<?php

/**
 * WPHAVE navigation manager.
 *
 * Centralizes the reusable navigation post type, REST endpoints, cached data,
 * block content normalization, and render helpers for global navigations.
 */

class WPHAVE_Navigation_Manager {

	/**
	 * Navigation post type slug.
	 *
	 * @var string
	 */

	const POST_TYPE = 'wphave-navigations';

	/**
	 * Shared transient group used by the post type feature cache.
	 *
	 * @var string
	 */

	const CACHE_TRANSIENT = 'post_type_features_data';

	/**
	 * Navigation cache key inside the shared transient.
	 *
	 * @var string
	 */

	const CACHE_KEY = 'wphave_navigations';

	/**
	 * Request-local navigation item cache.
	 *
	 * @var array
	 */

	private static $item_cache = [];

	/**
	 * Published navigation collection resolved during the current request.
	 *
	 * @var array|null
	 */

	private static $published_collection_cache = null;

	/**
	 * Request-local navigation source cache.
	 *
	 * CACHE INVARIANT: Rendered HTML must never be cached here: every render pass generates
	 * instance-specific block IDs used by CSS and ARIA relationships.
	 *
	 * @var array
	 */

	private static $render_source_cache = [];

	/**
	 * Navigation IDs currently being rendered.
	 *
	 * @var array
	 */

	private static $render_stack = [];

	/**
	 * Register WordPress hooks for the navigation domain.
	 *
	 * @return void
	 */

	public static function init() {
		add_action( 'init', [ __CLASS__, 'register_post_type' ], 16 );
		add_action( 'save_post_' . self::POST_TYPE, [ __CLASS__, 'normalize_saved_navigation_post' ], 9, 3 );
		add_action( 'save_post_' . self::POST_TYPE, [ __CLASS__, 'clear_cache' ] );
		add_action( 'delete_post', [ __CLASS__, 'clear_cache_for_post' ] );
	}

	/**
	 * Register the reusable navigation custom post type.
	 *
	 * @return void
	 */

	public static function register_post_type() {
		// Keep reusable navigations registered in compatibility mode so navigation blocks embedded in existing content can resolve and render them.

		register_post_type(
			self::POST_TYPE,
			[
				'label' => __( 'Navigations', 'wphave' ),
				'description' => __( 'Add and customize reusable navigations for your site.', 'wphave' ),
				'menu_icon' => 'data:image/svg+xml;base64,' . base64_encode( wphave_svg_ui_icon( 'header' ) ),
				'menu_position' => 47,
				'supports' => [
					'title',
					'editor' => [
						'notes'
					],
					'revisions',
					'custom-fields'
				],
				'public' => false,
				'show_ui' => true,
				'rewrite' => false,
				'show_in_menu' => false,
				'show_in_rest' => true,
				'map_meta_cap' => true,
				'capabilities' => self::get_post_type_capabilities(),
				'has_archive' => false,
				'exclude_from_search' => true,
				'show_in_nav_menus' => false,
				'show_in_admin_bar' => false,
				'publicly_queryable' => false,
				'query_var' => false,
			]
		);
	}

	/**
	 * Return WordPress post type capabilities mapped to navigation feature access.
	 *
	 * @return array
	 */

	private static function get_post_type_capabilities() {

		$capability = 'wphave_manage_navigations';

		return [
			'edit_post' => 'edit_wphave_navigation',
			'read_post' => 'read_wphave_navigation',
			'delete_post' => 'delete_wphave_navigation',
			'edit_posts' => $capability,
			'edit_others_posts' => $capability,
			'delete_posts' => $capability,
			'publish_posts' => $capability,
			'read_private_posts' => $capability,
			'create_posts' => $capability,
			'delete_private_posts' => $capability,
			'delete_published_posts' => $capability,
			'delete_others_posts' => $capability,
			'edit_private_posts' => $capability,
			'edit_published_posts' => $capability,
		];

	}

	/**
	 * Check whether the current user can manage reusable navigations.
	 *
	 * @return bool True when the current user can manage reusable navigations.
	 */

	public static function can_manage_navigations() {
		return current_user_can( 'wphave_manage_navigations' ) || current_user_can( 'wphave_manage_options' ) || current_user_can( 'manage_options' );
	}

	/**
	 * Require the canonical reusable-navigation management capability.
	 *
	 * @return true|WP_Error True when authorized, otherwise a stable REST error.
	 */

	private static function require_manage_navigations() {
		if( self::can_manage_navigations() ) {
			return true;
		}

		return new WP_Error(
			'wphave_navigations_forbidden',
			__( 'Sorry, you are not allowed to manage reusable navigations.', 'wphave' ),
			[ 'status' => 403 ]
		);
	}

	/**
	 * Get cached reusable navigation data.
	 *
	 * The returned inner_blocks value always contains the navigation-link level
	 * content. The canonical top-level wphave/navigation wrapper is removed
	 * before returning data intended for reusable block insertion.
	 *
	 * @return array Navigation data keyed by post ID.
	 */

	public static function get_navigations( $request = null ) {
		// SECURITY INVARIANT: Internal frontend reads deliberately pass no REST
		// request. Any invocation acting as the administrative REST callback must
		// repeat the route capability before request context can widen the result
		// to draft or management-only navigation data.
		if( $request instanceof WP_REST_Request ) {
			$authorization = self::require_manage_navigations();
			if( is_wp_error( $authorization ) ) {
				return $authorization;
			}
		}

		if( $request instanceof WP_REST_Request && $request->get_param( 'context' ) === 'summary' ) {
			$items = [];
			$post_ids = get_posts( [
				'post_type' => self::POST_TYPE,
				'post_status' => [ 'publish', 'draft' ],
				'fields' => 'ids',
				'posts_per_page' => -1,
				'orderby' => 'ID',
				'order' => 'DESC',
			] );

			foreach( $post_ids as $post_id ) {
				$item = self::get_navigation_item( $post_id, [ 'published_only' => false ] );
				if( $item ) $items[$post_id] = $item;
			}

			return self::prepare_navigation_collection( $items, $request );
		}

		// PERFORMANCE INVARIANT: Summary requests intentionally remain separate
		// because they include drafts. Public collection reads may reuse even an
		// empty request-local result without widening the published-only boundary.
		if( self::$published_collection_cache !== null ) {
			return self::prepare_navigation_collection( self::$published_collection_cache, $request );
		}

		$cached = wphave_has_cached_data( self::CACHE_TRANSIENT, [
			'key' => self::CACHE_KEY,
			'admin_cache' => true,
		] );

		if( $cached !== false ) {
			self::$published_collection_cache = $cached;

			return self::prepare_navigation_collection( self::$published_collection_cache, $request );
		}

		wphave_events( 'CACHE', 'Navigations data.' );

		$post_ids = wphave_internal_post_type_all_ids( self::POST_TYPE );

		if( empty( $post_ids ) ) {
			self::$published_collection_cache = [];

			wphave_save_query( [], self::CACHE_TRANSIENT, [
				'key' => self::CACHE_KEY,
				'admin_cache' => true,
				'frontend_write' => false,
			] );
			return self::$published_collection_cache;
		}

		$save_data = [];

		foreach( $post_ids as $post_id ) {
			$item = self::get_navigation_item( $post_id, [
				'rendered' => false,
			] );

			if( $item ) {
				$save_data[$post_id] = $item;
			}
		}

		wphave_save_query( $save_data, self::CACHE_TRANSIENT, [
			'key' => self::CACHE_KEY,
			'admin_cache' => true,
			'frontend_write' => false,
		] );

		self::$published_collection_cache = $save_data;

		return self::prepare_navigation_collection( self::$published_collection_cache, $request );
	}

	/**
	 * Remove block content when only navigation metadata was requested.
	 *
	 * @param array $items Navigation items.
	 * @param WP_REST_Request|null $request Optional REST request.
	 * @return array Prepared collection.
	 */

	private static function prepare_navigation_collection( $items, $request = null ) {
		if( ! $request instanceof WP_REST_Request || $request->get_param( 'context' ) !== 'summary' ) {
			return $items;
		}

		return array_map( static function( $item ) {
			return [
				'id' => $item['id'],
				'root_block' => $item['root_block'] ?? 'wphave/navigation',
				'title' => $item['title'],
				'status' => $item['status'] ?? 'draft',
				'modified_gmt' => $item['modified_gmt'] ?? '',
				'version' => $item['version'] ?? '',
				'overview' => $item['overview'] ?? self::get_navigation_overview( $item['inner_blocks'] ?? '' ),
			];
		}, $items );
	}

	/**
	 * Summarize navigation block content for collection views.
	 *
	 * Keeping this calculation in the navigation domain prevents list screens
	 * from depending on incomplete WordPress collection records or reparsing
	 * full navigation documents in the browser.
	 *
	 * @param string $content Navigation inner-block markup.
	 * @return array Navigation counts and validation totals.
	 */

	private static function get_navigation_overview( $content ) {
		$overview = [
			'itemCount' => 0,
			'linkCount' => 0,
			'depth' => 0,
			'validation' => [
				'emptyLabels' => 0,
				'missingLinks' => 0,
				'emptyMenus' => 0,
			],
		];

		self::summarize_navigation_blocks( parse_blocks( (string) $content ), 1, $overview );

		return $overview;
	}

	/**
	 * Add one parsed navigation level to an overview.
	 *
	 * @param array $blocks Parsed Gutenberg blocks.
	 * @param int $depth Current navigation depth.
	 * @param array $overview Mutable overview accumulator.
	 * @return void
	 */

	private static function summarize_navigation_blocks( $blocks, $depth, &$overview ) {
		foreach( $blocks as $block ) {
			$name = $block['blockName'] ?? '';

			if( ! $name ) continue;

			if( $name === 'wphave/navigation' ) {
				self::summarize_navigation_blocks( $block['innerBlocks'] ?? [], $depth, $overview );
				continue;
			}

			$overview['itemCount']++;
			$overview['depth'] = max( $overview['depth'], $depth );

			if( $name !== 'wphave/navigation-link' ) continue;

			$overview['linkCount']++;
			$attributes = is_array( $block['attrs'] ?? null ) ? $block['attrs'] : [];
			$label = trim( wp_strip_all_tags( (string) ( $attributes['content'] ?? '' ) ) );
			$link = is_array( $attributes['link'] ?? null ) ? $attributes['link'] : [];
			$link_type = trim( (string) ( $link['type'] ?? '' ) );
			$menu = null;

			foreach( $block['innerBlocks'] ?? [] as $inner_block ) {
				$inner_name = $inner_block['blockName'] ?? '';
				$is_submenu = $link_type === 'submenu' && $inner_name === 'wphave/navigation-submenu';
				$is_megamenu = $link_type === 'megamenu' && $inner_name === 'wphave/panel';

				if( $is_submenu || $is_megamenu ) {
					$menu = $inner_block;
					break;
				}
			}

			if( $label === '' ) $overview['validation']['emptyLabels']++;
			if( $link_type === '' || $link_type === 'none' ) $overview['validation']['missingLinks']++;
			$is_menu_link = in_array( $link_type, [ 'submenu', 'megamenu' ], true );
			if( $is_menu_link && ( ! $menu || empty( $menu['innerBlocks'] ) ) ) $overview['validation']['emptyMenus']++;
			if( $menu ) self::summarize_navigation_blocks( $menu['innerBlocks'] ?? [], $depth + 1, $overview );
		}
	}

	/**
	 * Return one published reusable navigation through REST.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @return WP_REST_Response|WP_Error Navigation response.
	 */

	public static function get_navigation( WP_REST_Request $request ) {
		$post_id = absint( $request->get_param( 'id' ) );

		// SECURITY INVARIANT: Collection-level navigation access does not expose an
		// arbitrary draft document. Full content requires edit permission on the exact
		// reusable navigation post requested by ID.
		if( ! current_user_can( 'edit_post', $post_id ) ) {
			return new WP_Error( 'rest_forbidden', __( 'Sorry, you are not allowed to view this navigation.', 'wphave' ), [ 'status' => 403 ] );
		}

		$item = self::get_navigation_item( $post_id, [ 'published_only' => false ] );

		if( ! $item ) {
			return new WP_Error( 'wphave_navigation_not_found', __( 'Navigation not found.', 'wphave' ), [ 'status' => 404 ] );
		}

		return rest_ensure_response( $item );
	}

	/**
	 * Get one reusable navigation item from the post type.
	 *
	 * @param int $post_id Navigation post ID.
	 * @param array $args Optional item arguments.
	 * @return array|null Navigation data or null when the post is invalid.
	 */

	public static function get_navigation_item( $post_id, $args = [] ) {
		$post_id = absint( $post_id );
		$args = is_array( $args ) ? $args : [];
		$include_rendered = ! empty( $args['rendered'] );
		$published_only = ! array_key_exists( 'published_only', $args ) || ! empty( $args['published_only'] );
		$cache_key = $post_id . ':' . ( $include_rendered ? 'rendered' : 'raw' ) . ':' . ( $published_only ? 'published' : 'any' );

		// CACHE INVARIANT: null is an authoritative negative lookup and must not
		// repeatedly resolve an invalid, draft, or deleted navigation post.
		if( array_key_exists( $cache_key, self::$item_cache ) ) {
			return self::$item_cache[$cache_key];
		}

		$post = get_post( absint( $post_id ) );

		if( ! $post || $post->post_type !== self::POST_TYPE || ( $published_only && $post->post_status !== 'publish' ) ) {
			self::$item_cache[$cache_key] = null;

			return null;
		}

		$content = $post->post_content;
		$inner_blocks = self::get_inner_blocks_content( $content );
		$root_block = self::get_root_block_name( $content );

		$item = [
			'id' => $post->ID,
			'type' => self::POST_TYPE,
			'status' => $post->post_status,
			'title' => $post->post_title,
			'modified_gmt' => $post->post_modified_gmt,
			'version' => self::get_navigation_version( $post ),
			'content' => $content,
			'root_block' => $root_block,
			'inner_blocks' => $inner_blocks,
			'overview' => self::get_navigation_overview( $inner_blocks ),
		];

		if( $include_rendered ) {
			$item['rendered'] = $inner_blocks ? do_blocks( $inner_blocks ) : '';
		}

		self::$item_cache[$cache_key] = $item;

		return self::$item_cache[$cache_key];
	}

	/**
	 * Build an exact optimistic-lock token for a navigation post.
	 *
	 * @param WP_Post $post Navigation post.
	 * @return string Version token.
	 */

	private static function get_navigation_version( $post ) {
		return hash( 'sha256', implode( '|', [ $post->post_modified_gmt, $post->post_status, $post->post_title, $post->post_content ] ) );
	}

	/**
	 * Return the supported navigation root contained in block markup.
	 *
	 * @param string $content Stored block content.
	 * @return string Navigation root block name.
	 */

	public static function get_root_block_name( $content ) {
		foreach( parse_blocks( (string) $content ) as $block ) {
			$name = $block['blockName'] ?? '';

			if( $name === 'wphave/navigation' ) {
				return $name;
			}
		}

		return 'wphave/navigation';
	}

	/**
	 * Extract reusable navigation inner block markup from stored post content.
	 *
	 * Navigation posts intentionally store a top-level wphave/navigation block
	 * because the block editor requires a stable root. Rendering and reusable
	 * block insertion consume only that root block's navigable children.
	 *
	 * @param string $content Stored block content from post_content.
	 * @return string Raw inner navigation block content.
	 */

	public static function get_inner_blocks_content( $content ) {
		if( ! $content ) {
			return '';
		}

		$blocks = parse_blocks( $content );

		foreach( $blocks as $block ) {
			if( ( $block['blockName'] ?? '' ) === 'wphave/navigation' ) {
				return serialize_blocks( $block['innerBlocks'] ?? [] );
			}
		}

		return $content;
	}

	/**
	 * Ensure stored navigation post content contains the root navigation block.
	 *
	 * The block editor for navigation posts needs a top-level wphave/navigation
	 * wrapper. Consumers that render or inject reusable navigations can still
	 * call get_inner_blocks_content() to access only the navigable child blocks.
	 *
	 * @param string $content Raw inner block markup or full navigation markup.
	 * @param int $post_id Optional existing navigation post ID.
	 * @return string Full navigation block markup.
	 */

	public static function ensure_navigation_wrapper_content( $content, $post_id = 0 ) {
		$content = is_string( $content ) ? trim( $content ) : '';
		$existing_attrs = [];
		$root_block_name = 'wphave/navigation';
		$normalize_attrs = function( $attrs ) use ( $post_id ) {
			$attrs = is_array( $attrs ) ? $attrs : [];

			if( $post_id ) {
				$attrs['wphave'] = $attrs['wphave'] ?? [];
				$attrs['wphave']['settings'] = $attrs['wphave']['settings'] ?? [];
				$attrs['wphave']['settings']['nav'] = (string) $post_id;
			}

			return $attrs;
		};

		if( $post_id ) {
			$existing_post = get_post( absint( $post_id ) );

			if( $existing_post && $existing_post->post_type === self::POST_TYPE ) {
				$existing_blocks = parse_blocks( $existing_post->post_content );

				foreach( $existing_blocks as $existing_block ) {
					if( ( $existing_block['blockName'] ?? '' ) === 'wphave/navigation' ) {
						$root_block_name = $existing_block['blockName'];
						$existing_attrs = $normalize_attrs( $existing_block['attrs'] ?? [] );
						break;
					}
				}
			}
		}

		if( ! $content ) {
			return serialize_blocks( [
				[
					'blockName' => $root_block_name,
					'attrs' => $normalize_attrs( $existing_attrs ),
					'innerBlocks' => [],
					'innerHTML' => '',
					'innerContent' => []
				]
			] );
		}

		$blocks = parse_blocks( $content );

		foreach( $blocks as $block ) {
			if( ( $block['blockName'] ?? '' ) === 'wphave/navigation' ) {
				$block['attrs'] = $normalize_attrs( $block['attrs'] ?? [] );

				return serialize_blocks( [ $block ] );
			}
		}

		return serialize_blocks( [
			[
				'blockName' => $root_block_name,
				'attrs' => $normalize_attrs( $existing_attrs ),
				'innerBlocks' => $blocks,
				'innerHTML' => '',
				'innerContent' => array_fill( 0, count( $blocks ), null )
			]
		] );
	}

	/**
	 * Render the inner blocks for a reusable navigation post.
	 *
	 * @param int $post_id Navigation post ID.
	 * @return string Rendered navigation inner block markup.
	 */

	public static function render_navigation( $post_id ) {
		return self::get_navigation_rendered( $post_id );
	}

	/**
	 * Render the inner blocks for a reusable navigation post.
	 *
	 * Only the serialized source is cached. Each instance must pass through
	 * do_blocks() independently so the block renderer can generate unique IDs,
	 * CSS selectors, and ARIA relationships for repeated global navigations.
	 *
	 * @param int $post_id Navigation post ID.
	 * @return string Rendered navigation inner block markup.
	 */

	public static function get_navigation_rendered( $post_id ) {
		$post_id = absint( $post_id );

		if( isset( self::$render_stack[$post_id] ) ) {
			return '';
		}

		if( ! array_key_exists( $post_id, self::$render_source_cache ) ) {
			$item = self::get_navigation_item( $post_id, [
				'rendered' => false,
			] );
			self::$render_source_cache[$post_id] = $item && $item['inner_blocks'] ? $item['inner_blocks'] : '';
		}

		$inner_blocks = self::$render_source_cache[$post_id];

		if( ! $inner_blocks ) {
			return '';
		}

		self::$render_stack[$post_id] = true;

		try {
			return do_blocks( $inner_blocks );
		} finally {
			unset( self::$render_stack[$post_id] );
		}
	}

	/**
	 * Save, update, or delete a reusable navigation via REST.
	 *
	 * REST JSON params are unslashed. WordPress post insert/update APIs unslash
	 * internally, so block content must be passed through wp_slash() before it
	 * is written to post_content. This preserves escaped JSON sequences such as
	 * \u003csvg in block attributes.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @return WP_REST_Response REST response with save result.
	 */

	public static function save_navigation( WP_REST_Request $request ) {
		// SECURITY INVARIANT: Route permission callbacks are dispatch metadata, not
		// authorization for this privileged deputy. Every direct or indirect
		// mutation must repeat the feature capability before parsing attacker-
		// controlled data or resolving an object ID.
		$authorization = self::require_manage_navigations();
		if( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$data = $request->get_json_params();
		$data = is_array( $data ) ? $data : [];
		$action = $data['action'] ?? 'save';
		$post_id = absint( $data['id'] ?? 0 );
		$title = sanitize_text_field( $data['title'] ?? '' );
		$raw_content = $data['inner_blocks'] ?? '';
		$raw_content = is_string( $raw_content ) ? $raw_content : '';
		$expected_version = sanitize_text_field( $data['expected_version'] ?? '' );
		$requested_status = sanitize_key( $data['status'] ?? '' );
		$create_status = $requested_status === 'draft' ? 'draft' : 'publish';

		if( $requested_status && ! in_array( $requested_status, [ 'draft', 'publish' ], true ) ) {
			return new WP_Error( 'wphave_invalid_navigation_status', __( 'Invalid navigation status.', 'wphave' ), [ 'status' => 400 ] );
		}

		if( ! in_array( $action, [ 'save', 'delete' ], true ) ) {
			return new WP_Error( 'wphave_invalid_navigation_action', __( 'Invalid navigation action.', 'wphave' ), [ 'status' => 400 ] );
		}

		$existing_post = $post_id ? get_post( $post_id ) : null;

		if( $post_id && ( ! $existing_post || $existing_post->post_type !== self::POST_TYPE ) ) {
			return new WP_Error( 'wphave_navigation_not_found', __( 'Navigation not found.', 'wphave' ), [ 'status' => 404 ] );
		}

		if( $action === 'delete' ) {
			if( ! $post_id ) {
				return new WP_Error( 'wphave_navigation_not_found', __( 'Navigation not found.', 'wphave' ), [ 'status' => 404 ] );
			}

			if( ! current_user_can( 'delete_post', $post_id ) ) {
				return new WP_Error( 'rest_forbidden', __( 'Sorry, you are not allowed to delete this navigation.', 'wphave' ), [ 'status' => 403 ] );
			}

			if( ! wp_delete_post( $post_id, true ) ) {
				return new WP_Error( 'wphave_navigation_delete_failed', __( 'The navigation could not be deleted.', 'wphave' ), [ 'status' => 500 ] );
			}

			self::clear_cache();

			return rest_ensure_response( [
				'success' => true,
				'deleted' => $post_id
			] );
		}

		if( $post_id && ! current_user_can( 'edit_post', $post_id ) ) {
			return new WP_Error( 'rest_forbidden', __( 'Sorry, you are not allowed to edit this navigation.', 'wphave' ), [ 'status' => 403 ] );
		}

		if( $post_id && ( ! $expected_version || ! hash_equals( self::get_navigation_version( $existing_post ), $expected_version ) ) ) {
			return new WP_Error(
				'wphave_navigation_conflict',
				__( 'This navigation was changed elsewhere. Reload it before saving.', 'wphave' ),
				[
					'status' => 409,
					'modified_gmt' => $existing_post->post_modified_gmt
				]
			);
		}

		$content = wp_slash( self::ensure_navigation_wrapper_content( $raw_content, $post_id ) );

		if( ! $post_id ) {
			$post_id = wp_insert_post( [
				'post_type' => self::POST_TYPE,
				'post_status' => $create_status,
				'post_title' => wp_slash( $title ?: __( 'My Navigation', 'wphave' ) ),
				'post_content' => $content
			], true );

			if( is_wp_error( $post_id ) ) {
				return $post_id;
			}

			if( $post_id ) {
				$updated = wp_update_post( [
					'ID' => $post_id,
					'post_content' => wp_slash( self::ensure_navigation_wrapper_content( $raw_content, $post_id ) )
				], true );

				if( is_wp_error( $updated ) ) {
					// DATA INTEGRITY INVARIANT: Creation and wrapper-ID finalization are
					// one logical mutation. A failed second phase must remove only the
					// post created by this request before the client can safely retry.
					$rolled_back = wp_delete_post( $post_id, true );

					if( ! $rolled_back ) {
						return new WP_Error(
							'wphave_navigation_create_recovery_required',
							__( 'Navigation creation was interrupted and requires recovery.', 'wphave' ),
							array(
								'status' => 500,
								'post_id' => $post_id,
							)
						);
					}

					return $updated;
				}
			}
		} else {
			$post_data = [
				'ID' => $post_id,
				'post_title' => wp_slash( $title ),
				'post_content' => $content
			];

			if( $requested_status ) $post_data['post_status'] = $requested_status;

			$updated = wp_update_post( $post_data, true );

			if( is_wp_error( $updated ) ) {
				return $updated;
			}
		}

		self::clear_cache();
		$saved_post = get_post( $post_id );

		return rest_ensure_response( [
			'success' => true,
			'id' => $post_id,
			'modified_gmt' => $saved_post ? $saved_post->post_modified_gmt : '',
			'version' => $saved_post ? self::get_navigation_version( $saved_post ) : '',
			'item' => self::get_navigation_item( $post_id, [ 'published_only' => false ] )
		] );
	}

	/**
	 * Normalize navigation posts saved through the standard block editor.
	 *
	 * Direct editor saves bypass the custom REST route, so the wrapper block
	 * still needs to be repaired and linked to its own navigation post ID here.
	 *
	 * @param int $post_id Navigation post ID.
	 * @param WP_Post $post Saved post object.
	 * @param bool $update Whether this is an existing post update.
	 * @return void
	 */

	public static function normalize_saved_navigation_post( $post_id, $post, $update ) {
		if( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}

		if( ! $post || $post->post_type !== self::POST_TYPE ) {
			return;
		}

		$normalized_content = self::ensure_navigation_wrapper_content( $post->post_content, $post_id );

		if( $normalized_content === $post->post_content ) {
			return;
		}

		remove_action( 'save_post_' . self::POST_TYPE, [ __CLASS__, 'normalize_saved_navigation_post' ], 9 );

		wp_update_post( [
			'ID' => $post_id,
			'post_content' => wp_slash( $normalized_content )
		] );

		add_action( 'save_post_' . self::POST_TYPE, [ __CLASS__, 'normalize_saved_navigation_post' ], 9, 3 );
	}

	/**
	 * Clear cached reusable navigation data.
	 *
	 * @return void
	 */

	public static function clear_cache() {
		self::$item_cache = [];
		self::$published_collection_cache = null;
		self::$render_source_cache = [];
		self::$render_stack = [];
		WPHAVE_Internal_Post_Type_Cache::invalidate( self::POST_TYPE );
	}

	/**
	 * Clear navigation cache when a navigation post is deleted.
	 *
	 * @param int $post_id Deleted post ID.
	 * @return void
	 */

	public static function clear_cache_for_post( $post_id ) {
		if( get_post_type( $post_id ) === self::POST_TYPE ) {
			self::clear_cache();
		}
	}

}

WPHAVE_Navigation_Manager::init();
