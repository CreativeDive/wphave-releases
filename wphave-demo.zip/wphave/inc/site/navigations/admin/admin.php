<?php

/**
 * Provide the management-only REST API for reusable navigations.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

if( ! class_exists( 'WPHAVE_Navigations_Admin' ) ) :

	/**
	 * Coordinates reusable navigation data for WPHAVE administration screens.
	 */

	class WPHAVE_Navigations_Admin {

		/**
		 * Register admin REST routes.
		 *
		 * @return void
		 */

		public static function init() {
			add_action( 'rest_api_init', array( __CLASS__, 'register_rest_routes' ) );
		}

		/**
		 * Register navigation management endpoints used by the WPHAVE app.
		 *
		 * @return void
		 */

		public static function register_rest_routes() {
			// AUTHORIZATION INVARIANT: Navigation inventory, object reads and mutations
			// share the server-side navigation-management capability; UI visibility is irrelevant.
			register_rest_route( 'wphave/v1', '/navigations', [
				'methods' => 'GET',
				'callback' => [ 'WPHAVE_Navigation_Manager', 'get_navigations' ],
				'permission_callback' => [ 'WPHAVE_Navigation_Manager', 'can_manage_navigations' ]
			] );

			register_rest_route( 'wphave/v1', '/navigations/(?P<id>\d+)', [
				'methods' => 'GET',
				'callback' => [ 'WPHAVE_Navigation_Manager', 'get_navigation' ],
				'permission_callback' => [ 'WPHAVE_Navigation_Manager', 'can_manage_navigations' ],
				'args' => [
					'id' => [
						'required' => true,
						'sanitize_callback' => 'absint'
					]
				]
			] );

			register_rest_route( 'wphave/v1', '/navigation_save', [
				'methods' => 'POST',
				'callback' => [ 'WPHAVE_Navigation_Manager', 'save_navigation' ],
				'permission_callback' => [ 'WPHAVE_Navigation_Manager', 'can_manage_navigations' ]
			] );
		}

	}

endif;

WPHAVE_Navigations_Admin::init();
