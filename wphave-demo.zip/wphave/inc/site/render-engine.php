<?php

if (!defined('ABSPATH')) {
	exit();
}

/**
 * Core rendering pipeline for the frontend.
 *
 * Responsibilities:
 * - Resolve correct content source (page/template)
 * - Build full layout (header, main, footer)
 * - Apply content overrides & filters
 * - Render block content via WordPress
 * - Inject into custom canvas template
 * - Detect and enqueue required assets
 *
 * Architecture:
 * - Raw Content → build_raw_site_content()
 * - Rendered Content → render_content()
 * - Final Output → canvas.php
 */

class WPHAVE_Render_Engine {
	private static ?self $instance = null;

	/**
	 * Raw block content (before WP rendering)
	 */

	private string $raw_content = '';

	/**
	 * Fully rendered HTML content
	 */

	private string $rendered_content = '';

	/**
	 * Serialized block source used for block-attribute based CSS collection.
	 */

	private string $style_source_content = '';

	/**
	 * Post or template post currently used as the main content source.
	 */

	private int $content_post_id = 0;

	/**
	 * Collected assets based on content analysis
	 */

	private array $assets = [
		'styles' => [],
		'scripts' => [],
	];

	/**
	 * Prevent double boot
	 */

	private bool $booted = false;

	private bool $rendering = false;

	/**
	 * Whether a request-level feature replaced the resolved template content.
	 */

	private bool $content_overridden = false;

	/**
	 * Singleton
	 */

	public static function instance(): self {
		return self::$instance ??= new self();
	}

	/**
	 * Initialize the render engine service.
	 */

	private function __construct() {}

	/**
	 * Register the render pipeline with the WordPress lifecycle.
	 *
	 * The boot guard prevents duplicate filters and asset hooks when the shared
	 * service is requested more than once.
	 *
	 * @return void
	 */

	public function boot() {
		if ($this->booted) {
			return;
		}

		$this->booted = true;

		add_filter('template_include', [$this, 'template_include'], 66);

		add_action('enqueue_block_assets', [$this, 'enqueue_site_assets'], 0);

		add_filter('body_class', [$this, 'filter_body_classes'], 20);
	}

	/**
	 * Prevents engine from running in unsupported contexts.
	 */

	private function should_bypass_engine() {
		if (wphave_use_fse()) {
			return true;
		}

		$request_path = wp_parse_url((string) ($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH);
		$special_text_paths = [
			wp_parse_url(home_url('/robots.txt'), PHP_URL_PATH),
			wp_parse_url(home_url('/llms.txt'), PHP_URL_PATH),
			wp_parse_url(home_url('/.well-known/llms.txt'), PHP_URL_PATH),
		];

		// Root discovery files are owned by WordPress, the web server or another
		// dedicated provider. Rendering the WPHAVE canvas for an unresolved text
		// request would turn a legitimate 404 into an HTML soft-404 that crawlers
		// and Lighthouse then attempt to parse as robots.txt or Markdown.
		if (
			is_string($request_path) &&
			in_array(
				untrailingslashit($request_path),
				array_map('untrailingslashit', $special_text_paths),
				true,
			)
		) {
			return true;
		}

		if (is_admin() || wp_doing_ajax()) {
			return true;
		}

		if (defined('REST_REQUEST') && REST_REQUEST) {
			return true;
		}

		return false;
	}

	/**
	 * Prevent custom template loading in special cases.
	 */

	private function should_not_load_custom_template() {
		// Maintenance Mode
		// The dedicated maintenance content replaces the normal site template.
		if (WPHAVE_Maintenance_Mode::is_active()) {
			return true;
		}

		// Coming Soon Mode
		// In this case we use a separate template to view the coming soon page
		if (WPHAVE_Coming_Soon::is_active()) {
			return true;
		}

		return false;
	}

	/**
	 * Get custom template ID based on current context.
	 */

	private function get_custom_template_id_by_context() {
		if ($this->should_not_load_custom_template()) {
			// Break here, in the case if a custom template should not be loaded
			return false;
		}

		// Check if there is a custom template context
		$custom_template = WPHAVE_Templates::custom_template();
		$custom_template_post_id = isset($custom_template['post_id'])
			? $custom_template['post_id']
			: '';

		if ($custom_template && $custom_template_post_id) {
			/* <- {event tracking} -> */

			wphave_events('INCLUDE', 'Standalone custom template by context.');

			// --> Return the custom template post id
			return $custom_template_post_id;
		}

		return false;
	}

	/**
	 * Resolve final post ID (page or custom template).
	 */

	private function resolve_post_id_to_render() {
		$post_id = get_queried_object_id();
		$template_id = $this->get_custom_template_id_by_context();

		if ($template_id) {
			return (int) $template_id;
		}

		return (int) $post_id;
	}

	/**
	 * Return the serialized block content for a post.
	 *
	 * @param int $post_id Post ID.
	 * @return string Stored post content, or an empty string when unavailable.
	 */

	private function get_post_content($post_id) {
		if (!$post_id) {
			return '';
		}

		$post = get_post($post_id);
		return $post->post_content ?? '';
	}

	/**
	 * Apply filters that override content (preview, coming soon, etc.)
	 */

	private function apply_content_overrides($content, $post_id) {
		// Manipulate the post id of the current template via "wphave_template_content_post_id" filter
		// For example used with "coming soon" mode
		$new_post_id = apply_filters('wphave_template_content_post_id', '');

		// Manipulate the content of the current template via "wphave_template_content" filter
		// For example used with "block layout" preview
		$new_content = apply_filters('wphave_template_content', '');

		if ($new_post_id) {
			$content = $this->get_post_content((int) $new_post_id);
			$this->content_overridden = true;
		}

		if ($new_content) {
			$content = $new_content;
			$this->content_overridden = true;
		}

		$custom_template = WPHAVE_Templates::custom_template();
		$content = apply_filters('wphave_template_content_extend', $content, $custom_template);

		return $content;
	}

	/**
	 * Replace placeholder block with actual page content.
	 */

	private function replace_content_slot($template_content, $template_post_id) {
		$content_block = WPHAVE_Block_Patterns::find_single('wphave/content', $template_content);

		if (!$content_block) {
			return $template_content;
		}

		$actual_post_id = get_queried_object_id();
		$actual_content = wphave_get_page_content($actual_post_id);
		if (is_attachment()) {
			$actual_content = WPHAVE_Attachment_Content::render($actual_post_id, $actual_content);
		}

		return wphave_replace($content_block, $actual_content, $template_content);
	}

	/**
	 * Load a base template when no user-defined WPHAVE template exists.
	 */

	private function apply_base_template_fallback($content) {
		/*
		 * Request-level content overrides are already complete documents for
		 * the main slot. Replacing them with a base template here would undo
		 * Coming Soon, Maintenance, previews, and any future override using the
		 * documented content filters.
		 */

		if ($this->content_overridden) {
			return $content;
		}

		if (!class_exists('WPHAVE_Template_Base')) {
			return $content;
		}

		if ($this->get_custom_template_id_by_context()) {
			return $content;
		}

		$context = WPHAVE_Templates::get_templates_context();

		if (!$this->should_use_base_template_fallback($context)) {
			return $content;
		}

		return WPHAVE_Template_Base::get_template($context);
	}

	/**
	 * Use base templates for every context WPHAVE can resolve and safely map.
	 *
	 * Page and single templates keep editable post content through the wphave/content
	 * placeholder replacement step. This makes base templates the default layout
	 * layer while user-defined WPHAVE templates remain the first priority.
	 */

	private function should_use_base_template_fallback($context) {
		if (!$context) {
			return false;
		}

		$fallback_contexts = [
			'protected',
			'single',
			'attachment',
			'search',
			'404_page',
			'archive',
			'date',
			'author',
			'homepage',
			'post_type_page',
			'privacy_policy',
			'posts_page',
			'index',
			'shop',
			'cart',
			'checkout',
			'account',
			'thank_you',
			'subscriber_confirmation',
		];

		if (in_array($context, $fallback_contexts, true)) {
			return true;
		}

		if (strpos($context, 'taxonomy_') === 0) {
			return true;
		}

		return strpos($context, 'post_type_') === 0;
	}

	/**
	 * Compose header, main content, attached hero, and footer markup.
	 *
	 * The unrendered composition is retained separately for block-style asset
	 * collection before WordPress transforms the blocks into HTML.
	 *
	 * @param string $content Serialized main-content blocks.
	 * @return string Serialized full-layout content.
	 */

	private function compose_layout($content) {
		/*
		 * LIFECYCLE INVARIANT: Public access modes must not retain the regular site header or footer
		 * behind their full-screen block. Besides unnecessary output, that
		 * could expose navigation and site content to assistive technology,
		 * crawlers, or styles that alter the overlay positioning.
		 */

		if (
			(class_exists('WPHAVE_Maintenance_Mode') && WPHAVE_Maintenance_Mode::is_active()) ||
			(class_exists('WPHAVE_Coming_Soon') && WPHAVE_Coming_Soon::is_active())
		) {
			$this->style_source_content = $content;
			return '<main class="wp-block-wphave-slot wphave-access-mode-content" id="content-scroll" tabindex="-1">' .
				$content .
				'</main>';
		}

		// Announcement add-ons own their content; this wrapper is only a technical root slot.
		$announcement_content = class_exists('WPHAVE_Add_On_Manager')
			? WPHAVE_Add_On_Manager::get_content(['announcement-bar'])
			: '';
		$announcement = $announcement_content
			? '<aside class="wp-block-wphave-slot wp-block-wphave-slot-announcement" data-wphave-slot="announcement" aria-label="' .
				esc_attr__('Announcements', 'wphave') .
				'">' .
				$announcement_content .
				'</aside>'
			: '';

		// Render "<header>" global section
		$header = $this->render_global_template_part('header');

		// Render "<footer>" global section
		$footer = $this->render_global_template_part('footer');

		// Keep the original serialized blocks available for style collection.
		// Attached heroes are rendered early, so raw_content may no longer contain
		// the hero/header block attributes needed by global block styles.
		$this->style_source_content =
			$announcement . "\n" . $header . "\n" . $content . "\n" . $footer;

		/*
		 * The Hero is a top-of-page boundary in the content model. When it owns
		 * the global header, render both as one structure before <main> and
		 * remove the serialized Hero from main content to avoid duplicate output.
		 *
		 * The editor enforces the Hero as the first root block even while
		 * attachHeader is disabled. This keeps stored order, editor order and
		 * this frontend composition identical when the setting is toggled.
		 * See docs/hero-rendering-architecture.md.
		 */

		$hero_composition = WPHAVE_Hero_Composition::compose($content, $header);
		$content = $hero_composition['content'];
		$header = $hero_composition['header'];

		// Use the "wphave_render_after_header_section" filter to extend the content
		$header = apply_filters('wphave_render_after_header_section', $header);
		$announcement = apply_filters('wphave_render_after_announcement_section', $announcement);

		// Render "<main>" section with post content
		$main = '<main class="wp-block-wphave-slot" id="content-scroll" tabindex="-1">';
		$main .= $content;
		$main .= '</main>';

		// Use the "wphave_render_after_main_section" filter to extend the content
		$main = apply_filters('wphave_render_after_main_section', $main);

		// Use the "wphave_render_after_footer_section" filter to extend the content
		$footer = apply_filters('wphave_render_after_footer_section', $footer);

		// Compose final
		$skip_link =
			'<a class="wphave-skip-link" href="#content-scroll">' .
			esc_html__('Skip to main content', 'wphave') .
			'</a>';

		return $skip_link . $announcement . $header . $main . $footer;
	}

	/**
	 * Build full raw site content (before WP rendering).
	 */

	private function build_raw_site_content() {
		$this->content_overridden = false;
		$post_id = $this->resolve_post_id_to_render();
		$this->content_post_id = (int) $post_id;

		$content = $this->get_post_content($post_id);

		$content = $this->apply_content_overrides($content, $post_id);

		$content = $this->apply_base_template_fallback($content);

		$content = $this->replace_content_slot($content, $post_id);

		$content = $this->compose_layout($content);

		// Filter to change the whole passed block content.
		return apply_filters('wphave_render_late_block_content', $content);
	}

	/**
	 * Get the current template part id for "header" and "footer".
	 */

	private function get_global_template_part_id($type) {
		$template_parts = wphave_data_get('template_parts');

		return $template_parts[$type] ?? null;
	}

	/**
	 * Render header/footer template part (RAW).
	 */

	public function render_global_template_part($type) {
		if ($this->is_layout_slot_hidden($type)) {
			return '';
		}

		$global_id = $this->get_global_template_part_id($type);

		$content = '';

		if ($global_id) {
			// Get cached template part block content
			$cached = WPHAVE_Template_Parts::get_template_parts_data();
			$content = $cached[$type][$global_id]['content'] ?? '';

			if (!$content) {
				// Get uncached template part block content
				$template_post = get_post($global_id);

				if (
					!$template_post ||
					$template_post->post_type !== WPHAVE_Template_Parts::POST_TYPE ||
					$template_post->post_status !== 'publish'
				) {
					return '';
				}

				$content = $template_post->post_content ?? '';
			}
		}

		if (!$content && class_exists('WPHAVE_Template_Parts_Base')) {
			$content = WPHAVE_Template_Parts_Base::get_template_part($type);
		}

		if (!$content) {
			return '';
		}

		$tag = match ($type) {
			'header' => 'header',
			'footer' => 'footer',
			default => 'div',
		};

		return sprintf(
			'<%1$s %2$s>%3$s</%1$s>',
			esc_html($tag),
			$this->get_template_part_slot_attributes($type, $global_id),
			$content,
		);
	}

	/**
	 * Check whether the active template explicitly hides a layout slot.
	 */

	private function is_layout_slot_hidden($type) {
		if (!in_array($type, ['header', 'footer'], true)) {
			return false;
		}

		if (!$this->content_post_id || !class_exists('WPHAVE_Templates')) {
			return false;
		}

		if (get_post_type($this->content_post_id) !== WPHAVE_Templates::POST_TYPE) {
			return false;
		}

		$visibility = get_post_meta(
			$this->content_post_id,
			WPHAVE_Templates::META_LAYOUT_VISIBILITY,
			true,
		);

		return is_array($visibility) && ($visibility[$type] ?? '') === 'hidden';
	}

	/**
	 * Build slot wrapper attributes for global template parts.
	 */

	private function get_template_part_slot_attributes($type, $template_part_id) {
		$classes = [
			'wp-block-wphave-slot',
			'wp-block-wphave-slot-' . sanitize_html_class($type),
			//'wph-b',
			//'bsz-full',
		];

		$styles = [];
		$attributes = [
			'class' => '',
			'data-wphave-slot' => esc_attr($type),
		];

		if ($type === 'header') {
			$sticky = $this->get_header_sticky_settings($template_part_id);

			if (!empty($sticky['enabled'])) {
				$classes[] = 'has-header-sticky';
				$classes[] = 'stcy';
				$classes[] = 'stcy-pos-top';
				$styles[] = '--wphave-header-sticky-offset: ' . $sticky['offset'] . ';';
				$styles[] = '--wphave-header-z-index: ' . $sticky['zIndex'] . ';';
				$styles[] = '--stcy-oft: ' . $sticky['offset'] . ';';
			}
		}

		$attributes['class'] = esc_attr(implode(' ', array_filter($classes)));

		if (!empty($styles)) {
			$attributes['style'] = safecss_filter_attr(implode('', $styles));
		}

		$output = [];
		foreach ($attributes as $name => $value) {
			if ($value === '') {
				continue;
			}

			$output[] = sprintf('%s="%s"', esc_attr($name), esc_attr($value));
		}

		return implode(' ', $output);
	}

	/**
	 * Read header sticky settings from the assigned header template part.
	 */

	private function get_header_sticky_settings($template_part_id) {
		$settings = WPHAVE_Template_Parts::get_template_part_settings($template_part_id);
		$sticky =
			isset($settings['sticky']) && is_array($settings['sticky']) ? $settings['sticky'] : [];

		$offset =
			isset($sticky['offset']) && is_string($sticky['offset'])
				? trim($sticky['offset'])
				: '0px';

		// Sticky offsets are single dimensions, never arbitrary declaration lists.
		if (!preg_match('/^-?(?:\d+|\d*\.\d+)(?:px|rem|em|%|vh|vw|vmin|vmax)?$/i', $offset)) {
			$offset = '0px';
		}

		return [
			'enabled' => !empty($sticky['enabled']),
			'offset' => $offset,
			'zIndex' => isset($sticky['zIndex']) ? (int) $sticky['zIndex'] : 412,
		];
	}

	/**
	 * Render template part WITH block parsing.
	 */

	public function render_template_part_by_id($template_part_id) {
		$template_part_id = (int) $template_part_id;
		if (!$template_part_id) {
			return '';
		}

		$template_post = get_post($template_part_id);
		if (
			!$template_post ||
			$template_post->post_type !== WPHAVE_Template_Parts::POST_TYPE ||
			$template_post->post_status !== 'publish'
		) {
			return '';
		}

		// Preserve global post state
		global $post;
		$original_post = $post ?? null;

		// Setup post context (important for get_the_ID(), filters, etc.)
		$post = $template_post;
		setup_postdata($post);

		// Render blocks (triggers your full wphave render pipeline)
		try {
			$content = $template_post->post_content ?? '';

			return $content ? do_blocks($content) : '';
		} finally {
			wp_reset_postdata();
			$post = $original_post;
		}
	}

	/**
	 * Render block content through WP.
	 */

	private function render_content($content) {
		$content = str_replace(']]>', ']]&gt;', $content);

		$this->rendering = true;

		try {
			$renderer = static function () use ($content) {
				return WPHAVE_Attachment_Content::with_layout_filters(static function () use (
					$content,
				) {
					return apply_filters('the_content', $content);
				});
			};

			if (class_exists('WPHAVE_WooCommerce') && is_singular('product')) {
				$content = WPHAVE_WooCommerce::with_product_context(
					get_queried_object_id(),
					$renderer,
				);
			} else {
				$content = $renderer();
			}
		} finally {
			$this->rendering = false;
		}

		$content = apply_filters('wphave_ready_renderd_block_content', $content);

		$before = apply_filters('wphave_post_render_before', '') ?: '';
		$after = apply_filters('wphave_post_render_after', '') ?: '';

		return $before . $content . $after;
	}

	/**
	 * Collect all content sources relevant to block and asset inspection.
	 *
	 * @return string Combined effective content.
	 */

	private function get_effective_content() {
		$content = $this->get_post_content(get_the_ID());

		if (!is_admin()) {
			$content .= "\n" . $this->raw_content;
			$content .= "\n" . $this->rendered_content;
		}

		return $content;
	}

	/**
	 * Return style source content.
	 */

	private function get_style_source_content() {
		return trim($this->style_source_content . "\n" . $this->raw_content);
	}

	/**
	 * Collect assets from content.
	 *
	 * @param string $content Content to process.
	 */

	private function collect_assets_from_content($content) {
		// BUTTON
		if (str_contains($content, '<button') || str_contains($content, 'type="button')) {
			$this->assets['styles']['wphave-button-style'] = true;
		}

		// FORM
		if (str_contains($content, '<form')) {
			$this->assets['styles']['wphave-form-style'] = true;
		}

		// DEVICE BLOCK
		foreach (
			['imac', 'macbook', 'macbook-pro', 'ipad-pro', 'iphone-14-pro', 'pro-display-xdr']
			as $device
		) {
			if (is_admin() || str_contains($content, "device-$device")) {
				$this->assets['styles']["device-$device-style"] = true;
			}
		}

		// TEXT WRITER
		if (str_contains($content, 'rt-ty-an')) {
			$this->assets['scripts']['wphave-text-writer'] = true;
		}

		// COLOR MODE
		$color_mode_enabled = wphave_data_get('site_globals', 'colorMode.enabled', false);
		$color_mode_preference = wphave_data_get('site_globals', 'colorMode.preference', 'default');
		if (
			true === $color_mode_enabled &&
			($color_mode_preference === 'system' || str_contains($content, 'action-color-mode'))
		) {
			// Static Default/Alternate sites need no runtime unless visitors can toggle the mode.
			$this->assets['scripts']['wphave-color-mode'] = true;
		}

		// TOOLTIP
		if (str_contains($content, 'data-tooltip')) {
			$this->assets['scripts']['wphave-tooltip'] = true;
			$this->assets['styles']['wphave-tooltip'] = true;
		}

		// LIVE SEARCH
		if (
			str_contains($content, 'action-search') ||
			str_contains($content, 'wp-block-wphave-search-form') ||
			str_contains($content, 'wp-block-search')
		) {
			WPHAVE_Live_Search::enqueue_assets(true);
		}

		// LIGHTBOX
		if (str_contains($content, 'data-lightbox')) {
			$this->assets['scripts']['wphave-lightbox'] = true;
			$this->assets['styles']['wphave-lightbox'] = true;
			$this->assets['scripts']['wphave-tooltip'] = true;
			$this->assets['styles']['wphave-tooltip'] = true;
		}

		if (str_contains($content, 'msk-txt')) {
			$this->assets['scripts']['wphave-text-mask'] = true;
		}

		// FIT TEXT
		if (str_contains($content, 'txt-str')) {
			$this->assets['scripts']['wphave-fit-text'] = true;
		}

		// MODAL
		if (
			wphave_consent_is_enabled() ||
			str_contains($content, 'data-modal') ||
			str_contains($content, 'data-modal-id')
		) {
			$this->assets['scripts']['wphave-modal'] = true;
			$this->assets['styles']['wphave-modal'] = true;
			$this->assets['scripts']['wphave-tooltip'] = true;
			$this->assets['styles']['wphave-tooltip'] = true;
		}

		// POPOVER
		if (str_contains($content, 'data-popover') || str_contains($content, 'data-popover-id')) {
			$this->assets['scripts']['wphave-popover'] = true;
			$this->assets['styles']['wphave-popover'] = true;
		}

		// SIDE PANEL
		if (str_contains($content, 'data-panel') || str_contains($content, 'data-panel-id')) {
			$this->assets['scripts']['wphave-side-panel'] = true;
			$this->assets['styles']['wphave-side-panel'] = true;
			$this->assets['scripts']['wphave-tooltip'] = true;
			$this->assets['styles']['wphave-tooltip'] = true;
		}

		// SWIPER
		if (str_contains($content, 'swiper')) {
			$this->assets['scripts']['wphave-swiper'] = true;
		}

		// PARALLAX
		if (str_contains($content, 'palx-img')) {
			$this->assets['scripts']['wphave-parallax'] = true;
		}

		// SCROLL NAV
		if (str_contains($content, 'data-wphave-scroll-nav')) {
			$this->assets['scripts']['wphave-scroll-nav'] = true;
		}

		// FLEX SCROLL
		if (str_contains($content, 'ly-fl-scrl')) {
			$this->assets['scripts']['wphave-flex-scroll'] = true;
		}

		// FLEX ANIMATION
		if (str_contains($content, 'ly-fl-ani')) {
			$this->assets['scripts']['wphave-flex-animation'] = true;
		}

		// STICKY
		if (str_contains($content, 'stcy')) {
			$this->assets['scripts']['wphave-sticky'] = true;
		}

		// ANIMATE IN
		if (str_contains($content, 'has-entrance')) {
			$this->assets['scripts']['wphave-animate-in'] = true;
		}

		// CANVAS ANIMATION BACKGROUND
		if (str_contains($content, 'data-wphave-canvas-animation')) {
			$this->assets['scripts']['wphave-canvas-animation'] = true;
		}
	}

	/**
	 * Enqueue collected assets.
	 */

	private function enqueue_collected_assets() {
		foreach (array_keys($this->assets['styles'] ?? []) as $handle) {
			wp_enqueue_style($handle);
		}

		foreach (array_keys($this->assets['scripts'] ?? []) as $handle) {
			wp_enqueue_script($handle);
		}
	}

	/**
	 * Enqueue collected block and site assets.
	 */

	public function enqueue_site_assets() {
		if ($this->should_bypass_engine()) {
			return;
		}

		/**
		 * Enqueue block assets.
		 */

		$content = $this->get_effective_content();

		// RESET
		$this->assets = [
			'styles' => [],
			'scripts' => [],
		];

		$this->collect_assets_from_content($content);
		$this->enqueue_collected_assets();

		/**
		 * Enqueue site assets.
		 */

		// Common styles and scripts
		wp_enqueue_script('wphave');
		wp_enqueue_style('wphave');

		// Print styles
		/*
		$path = 'inc/site/styles/print.css';
        wp_enqueue_style( 'wphave-print', wphave_asset_url( $path ), [], WPHAVE_Asset_Registry::version( $path ), 'print' );
        */
	}

	/**
	 * Canvas output.
	 * @ https://developer.wordpress.org/reference/hooks/template_include/
	 * @ https://developer.wordpress.org/reference/hooks/type_template/
	 */

	private function include_canvas() {
		$block_content = $this->rendered_content;

		$site_globals = wphave_data_get('site_globals') ?? [];
		$page_color_context = wphave_get_page_color_context();
		$color_mode_enabled =
			!$page_color_context && true === ($site_globals['colorMode']['enabled'] ?? false);
		$color_mode_preference = $site_globals['colorMode']['preference'] ?? 'default';

		if (!in_array($color_mode_preference, ['default', 'alternate', 'system'], true)) {
			$color_mode_preference = 'default';
		}

		if (!$color_mode_enabled) {
			$color_mode_preference = 'default';
		}

		$color_mode_resolved = $color_mode_preference === 'alternate' ? 'alternate' : 'default';

		include wphave_dir() . 'inc/site/canvas.php';
	}

	/**
	 * Main WordPress template entry point.
	 */

	public function template_include($template) {
		if (!is_string($template) || empty($template)) {
			return $template;
		}

		if ($this->should_bypass_engine()) {
			return $template;
		}

		$this->raw_content = $this->build_raw_site_content();

		WPHAVE_Attachment_Primer::prime_content($this->raw_content);

		$style_source_content = $this->get_style_source_content();
		wphave_enqueue_used_css_classes($style_source_content);

		$this->rendered_content = $this->render_content($this->raw_content);

		$this->collect_assets_from_content($this->rendered_content);
		$this->enqueue_collected_assets();

		$this->include_canvas();

		exit();
	}

	/**
	 * Normalize frontend body classes for the WPHAVE canvas.
	 *
	 * @param array $classes Existing WordPress body classes.
	 * @return array Normalized body classes.
	 */

	public function filter_body_classes($classes = []) {
		// Remove unwanted classes
		$remove = ['no-customize-support', 'id-', 'wp-custom-logo', '-template'];

		foreach ($classes as $key => $class) {
			foreach ($remove as $needle) {
				if (str_contains($class, $needle)) {
					unset($classes[$key]);
					continue 2;
				}
			}
		}

		// Add post type
		if ($post_type = get_post_type()) {
			$classes[] = 'post-type-' . $post_type;
		}

		// Frontend marker
		if (!is_admin()) {
			$classes[] = 'frontend';
		}

		// Optional browser classes
		$classes = $this->add_browser_classes($classes);

		return array_values($classes);
	}

	/**
	 * Add browser classes.
	 *
	 * @param mixed $classes Classes.
	 */

	private function add_browser_classes($classes = []) {
		if (apply_filters('wphave_enable_browser_classes', false) !== true) {
			return $classes;
		}

		$browsers = ['is_iphone', 'is_chrome', 'is_safari', 'is_opera', 'is_edge'];

		foreach ($browsers as $browser) {
			if (!empty($GLOBALS[$browser])) {
				$classes[] = $browser;
			}
		}

		return $classes;
	}

	/**
	 * Public access for debug.
	 */

	public function get_assets(): array {
		return $this->assets;
	}

	/**
	 * Return raw content.
	 *
	 * @return string Return raw content.
	 */

	public function get_raw_content(): string {
		return $this->raw_content;
	}

	/**
	 * Determine whether the render engine is currently rendering content.
	 *
	 * @return bool Determine whether rendering.
	 */

	public function is_rendering(): bool {
		return $this->rendering;
	}
}

if (!function_exists('wphave_render_engine_is_rendering')) {
	/**
	 * Render engine is rendering.
	 */

	function wphave_render_engine_is_rendering() {
		return WPHAVE_Render_Engine::instance()->is_rendering();
	}
}

/**
 * Boot engines
 */

add_action('plugins_loaded', function () {
	WPHAVE_Render_Engine::instance()->boot();
	WPHAVE_Style_Engine::instance()->boot();
});
