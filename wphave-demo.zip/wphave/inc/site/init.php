<?php

/**
 * Bootstrap site-wide services required in every request context.
 */

if (!defined('ABSPATH')) {
	exit();
}

require_once __DIR__ . '/multisite.php';
require_once __DIR__ . '/post-meta.php';
require_once __DIR__ . '/page-color-context.php';
require_once __DIR__ . '/preview-context.php';
