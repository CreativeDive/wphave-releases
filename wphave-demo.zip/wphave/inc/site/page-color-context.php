<?php
/** Page assignments reference the shared Color Context model; never copy colors. */
if (!defined('ABSPATH')) {
	exit();
}

require_once __DIR__ . '/color-context-model.php';

function wphave_resolve_page_color_context($value, $globals): string {
	if (!is_string($value) || $value === '') {
		return '';
	}
	$ids = ['default', 'alternate'];
	$contexts = is_array($globals['colorContexts'] ?? null) ? $globals['colorContexts'] : [];
	foreach (array_slice($contexts, 0, 3) as $context) {
		$ids[] = wphave_normalize_color_context_id($context['id'] ?? '');
	}
	return in_array($value, $ids, true) ? $value : '';
}

/** Resolve the requested page, never the template or the current loop item. */
function wphave_get_page_color_context(): string {
	if (wphave_use_fse() || !is_singular('page')) {
		return '';
	}
	return wphave_resolve_page_color_context(
		get_post_meta(get_queried_object_id(), 'wphave_color_context', true),
		wphave_data_get('site_globals') ?? [],
	);
}

/** Reject malformed input while allowing stale references to fall back at read time. */
function wphave_sanitize_page_color_context($value): string {
	return wphave_resolve_page_color_context($value, wphave_data_get('site_globals') ?? []);
}

function wphave_register_page_color_context_meta(): void {
	if (wphave_use_fse()) {
		return;
	}
	register_post_meta('page', 'wphave_color_context', [
		'single' => true,
		'type' => 'string',
		'default' => '',
		'show_in_rest' => true,
		'revisions_enabled' => true,
		'sanitize_callback' => 'wphave_sanitize_page_color_context',
		'auth_callback' => 'wphave_can_edit_custom_post_meta',
	]);
}
add_action('init', 'wphave_register_page_color_context_meta');

/** REST metadata is written after save_post; invalidate again after persistence. */
function wphave_page_color_context_changed($meta_id, $post_id, $meta_key): void {
	if ($meta_key !== 'wphave_color_context' || get_post_type($post_id) !== 'page') {
		return;
	}
	do_action('wphave_page_color_context_changed', $post_id);
}
foreach (['added_post_meta', 'updated_post_meta', 'deleted_post_meta'] as $hook) {
	add_action($hook, 'wphave_page_color_context_changed', 10, 3);
}
