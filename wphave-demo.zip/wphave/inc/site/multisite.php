<?php

if( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

if( ! class_exists( 'WPHAVE_Multisite' ) ) :

    /**
     * Centralizes WordPress multisite helpers and app payloads.
     */

    class WPHAVE_Multisite {

        /**
         * Request-local license contexts keyed by network and current site.
         *
         * @var array<string,array>
         */

        private static $license_context_cache = array();

        /**
         * Clear request-local topology projections after a site mutation.
         *
         * WordPress may create, delete, archive or move a site and then continue
         * processing within the same request. Subsequent entitlement decisions
         * must observe the mutated network rather than a pre-mutation position.
         *
         * @return void
         */

        public static function clear_license_context_cache() {

            self::$license_context_cache = array();

        }

        /**
         * Check whether WordPress runs in multisite mode.
         *
         * @return bool
         */

        public static function is_enabled() {

            return is_multisite();

        }

        /**
         * Get the current site/blog id.
         *
         * @return int
         */

        public static function current_site_id() {

            return (int) get_current_blog_id();

        }

        /**
         * Get the network main site id.
         *
         * @return int
         */

        public static function main_site_id() {

            return function_exists( 'get_main_site_id' ) ? (int) get_main_site_id() : 1;

        }

        /**
         * Check whether the current request runs on the main site.
         *
         * @return bool
         */

        public static function is_main_site() {

            return self::current_site_id() === self::main_site_id();

        }

        /**
         * Switch the WordPress context to the main network site.
         *
         * @return bool
         */

        public static function switch_to_main_site() {

            if( ! self::is_enabled() ) {
                return false;
            }

            switch_to_blog( self::main_site_id() );
            return true;

        }

        /**
         * Restore the previous WordPress site context after a multisite switch.
         *
         * @return void
         */

        public static function restore_current_site() {

            if( self::is_enabled() ) {
                restore_current_blog();
            }

        }

        /**
         * Read the search engine visibility flag in single-site or multisite mode.
         *
         * @return bool
         */

        public static function search_engine_visibility() {

            $visibility = self::is_enabled()
                ? get_blog_option( self::current_site_id(), 'blog_public', 1 )
                : get_option( 'blog_public', 1 );

            return (int) $visibility === 1;

        }

        /**
         * Check whether a plugin is network active.
         *
         * @param string $plugin_file Plugin basename.
         * @return bool
         */

        public static function is_plugin_network_active( $plugin_file ) {

            return self::is_enabled()
                && function_exists( 'is_plugin_active_for_network' )
                && is_plugin_active_for_network( $plugin_file );

        }

        /**
         * Build the static network license context for the React app.
         *
         * License coverage itself comes from the signed server token. This
         * payload exposes only local network facts, such as active subsite count
         * and the deterministic position of the current site.
         *
         * @return array
         */

        public static function license_context() {

            global $wpdb;

            $current_site_id = self::current_site_id();
            $main_site_id = self::main_site_id();
			$is_multisite = self::is_enabled();
			$network_id = $is_multisite && function_exists( 'get_current_network_id' )
				? (int) get_current_network_id()
				: 0;
			$cache_key = sprintf( '%d:%d:%d:%d', $is_multisite ? 1 : 0, $network_id, $main_site_id, $current_site_id );

			if( isset( self::$license_context_cache[$cache_key] ) ) {
				return self::$license_context_cache[$cache_key];
			}

            $active_site_count = 1;
            $active_subsite_count = 0;
            $current_subsite_index = 0;

			if( $is_multisite && isset( $wpdb->blogs ) ) {
				$active_where = $wpdb->prepare(
					'site_id = %d AND deleted = 0 AND archived = 0 AND spam = 0',
					$network_id
				);
                $active_site_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->blogs} WHERE {$active_where}" );
                $active_subsite_count = (int) $wpdb->get_var( $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$wpdb->blogs} WHERE {$active_where} AND blog_id != %d",
                    $main_site_id
                ) );

                if( $current_site_id !== $main_site_id ) {
                    $current_subsite_index = (int) $wpdb->get_var( $wpdb->prepare(
                        "SELECT COUNT(*) FROM {$wpdb->blogs} WHERE {$active_where} AND blog_id != %d AND blog_id <= %d",
                        $main_site_id,
                        $current_site_id
                    ) );
                }
            }

			$context = array(
				'isMultisite' => $is_multisite,
                'isMainSite' => self::is_main_site(),
                'mainSiteId' => $main_site_id,
                'currentSiteId' => $current_site_id,
                'activeSiteCount' => $active_site_count,
                'activeSubsiteCount' => $active_subsite_count,
                'currentSubsiteIndex' => $current_subsite_index,
            );

			/*
			 * PERFORMANCE/CONTEXT INVARIANT: The cache key includes the active network
			 * and blog, so network switching and switch_to_blog() never cross scopes.
			 * WordPress site-mutation hooks clear all projections before another gate
			 * can observe changed topology within the same request.
			 *
			 * SECURITY/MULTI-NETWORK INVARIANT: Every topology query is constrained
			 * to the current network. Sites owned by another network must never affect
			 * entitlement counts or the deterministic subsite coverage position.
			 */
			self::$license_context_cache[$cache_key] = $context;

			return $context;

        }

        /**
         * Build the site switcher payload for multisite admin screens.
         *
         * The React shell only needs this list on multisite installs. Normal users
         * receive their assigned sites via get_blogs_of_user(), while super admins
         * receive a bounded network list to avoid loading very large networks into
         * the app header.
         *
         * @return array
         */

        public static function site_switcher_data() {

            if( ! self::is_enabled() ) {
                return array(
                    'sites' => array(),
                    'hasMore' => false,
                );
            }

            $current_site_id = self::current_site_id();
            $main_site_id = self::main_site_id();
			$network_id = function_exists( 'get_current_network_id' ) ? (int) get_current_network_id() : 0;
            $site_limit = 100;
            $site_ids = array();
            $has_more = false;

            if( is_super_admin() ) {
                $network_sites = get_sites( array(
					'network_id' => $network_id,
                    'number' => $site_limit + 1,
                    'deleted' => 0,
                    'archived' => 0,
                    'spam' => 0,
                    'fields' => 'ids',
                ) );

                $site_ids = array_map( 'intval', $network_sites );
                $has_more = count( $site_ids ) > $site_limit;
                $site_ids = array_slice( $site_ids, 0, $site_limit );
            } else {
                $user_sites = get_blogs_of_user( get_current_user_id() );
                foreach( $user_sites as $site ) {
					$site_id = self::membership_site_id( $site );

					if( $site_id && self::membership_belongs_to_network( $site, $site_id, $network_id ) ) {
						$site_ids[] = $site_id;
					}
                }
            }

            if( ! in_array( $current_site_id, $site_ids, true ) ) {
                array_unshift( $site_ids, $current_site_id );
            }

            $site_ids = array_values( array_unique( $site_ids ) );
            $sites = array();

			/*
			 * MULTI-NETWORK WORKSPACE INVARIANT: A workspace switcher represents the
			 * current network. Cross-network memberships require their own network
			 * context and must not inherit this network's main-site or license state.
			 */

            foreach( $site_ids as $site_id ) {
                $title = get_blog_option( $site_id, 'blogname' );
                $home_url = get_home_url( $site_id, '/' );

                $sites[] = array(
                    'id' => $site_id,
                    'title' => html_entity_decode( wp_strip_all_tags( $title ?: sprintf( /* translators: %d: contextual value. */
                    __( 'Site #%d', 'wphave' ), $site_id ) ), ENT_QUOTES, get_bloginfo( 'charset' ) ),
                    'url' => esc_url_raw( $home_url ),
                    'adminUrl' => esc_url_raw( get_admin_url( $site_id, 'admin.php?page=workspace' ) ),
                    'dashboardUrl' => esc_url_raw( get_admin_url( $site_id ) ),
                    'isCurrent' => $site_id === $current_site_id,
                    'isMain' => $site_id === $main_site_id,
                );
            }

            usort( $sites, function( $a, $b ) {
                if( $a['isCurrent'] !== $b['isCurrent'] ) {
                    return $a['isCurrent'] ? -1 : 1;
                }

                if( $a['isMain'] !== $b['isMain'] ) {
                    return $a['isMain'] ? -1 : 1;
                }

                return strcasecmp( $a['title'], $b['title'] );
            } );

            return array(
                'sites' => $sites,
                'hasMore' => $has_more,
            );

        }

        /**
         * Resolve a site id from the WordPress membership projection.
         *
         * @param object|array $membership User site membership.
         * @return int Site id or zero.
         */

        private static function membership_site_id( $membership ) {

            if( is_object( $membership ) ) {
                return (int) ( $membership->userblog_id ?? $membership->blog_id ?? 0 );
            }

            if( is_array( $membership ) ) {
                return (int) ( $membership['userblog_id'] ?? $membership['blog_id'] ?? 0 );
            }

            return 0;

        }

        /**
         * Verify that a user membership belongs to the active network.
         *
         * @param object|array $membership User site membership.
         * @param int $site_id Site id.
         * @param int $network_id Expected network id.
         * @return bool True only for a resolved matching network.
         */

        private static function membership_belongs_to_network( $membership, $site_id, $network_id ) {

            $membership_network_id = is_object( $membership )
                ? (int) ( $membership->site_id ?? $membership->network_id ?? 0 )
                : (int) ( $membership['site_id'] ?? $membership['network_id'] ?? 0 );

            if( ! $membership_network_id && function_exists( 'get_site' ) ) {
                $canonical_site = get_site( $site_id );
                $membership_network_id = $canonical_site
                    ? (int) ( $canonical_site->network_id ?? $canonical_site->site_id ?? 0 )
                    : 0;
            }

            /*
             * SECURITY/NETWORK INVARIANT: Filtered membership projections are
             * untrusted routing hints. Missing or unresolvable network ownership
             * fails closed instead of entering the current workspace implicitly.
             */
            return $network_id > 0 && $membership_network_id === $network_id;

        }

    }

endif;

if( function_exists( 'add_action' ) ) {
    add_action( 'clean_site_cache', array( 'WPHAVE_Multisite', 'clear_license_context_cache' ), 10, 0 );
    add_action( 'wp_insert_site', array( 'WPHAVE_Multisite', 'clear_license_context_cache' ), 20, 0 );
    add_action( 'wp_update_site', array( 'WPHAVE_Multisite', 'clear_license_context_cache' ), 20, 0 );
    add_action( 'wp_delete_site', array( 'WPHAVE_Multisite', 'clear_license_context_cache' ), 20, 0 );
}
