<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Resolves authenticated WPHAVE site-preview requests across frontend services.
 */
final class WPHAVE_Site_Preview_Context {

	/** Determine whether the current request is an authorized workspace preview. */
	public static function is_current_request(): bool {
		return self::is_authorized_parameters( $_GET );
	}

	/** Determine whether a URL represents an authorized workspace preview. */
	public static function is_url( $url ): bool {
		if( ! is_string( $url ) || '' === $url ) {
			return false;
		}

		$query = wp_parse_url( $url, PHP_URL_QUERY );
		if( ! is_string( $query ) || '' === $query ) {
			return false;
		}

		parse_str( $query, $parameters );

		return self::is_authorized_parameters( $parameters );
	}

	/** Determine whether the current request is an authorized post preview. */
	public static function is_post_preview(): bool {
		$post_id = absint( wphave_request_string( $_GET, 'wphave_page_preview' ) );
		$nonce = sanitize_text_field(
			wphave_request_string( $_GET, '_wphave_preview_nonce' )
		);

		// AUTHORIZATION INVARIANT: Hiding WordPress chrome is allowed only for the
		// exact post an authenticated workspace user may edit. A numeric public
		// query marker is never sufficient preview authority.
		return $post_id > 0
			&& is_user_logged_in()
			&& current_user_can( 'edit_post', $post_id )
			&& (bool) wp_verify_nonce( $nonce, 'wphave_site_preview' );
	}

	/**
	 * Validate preview markers at the shared trust boundary.
	 *
	 * SECURITY INVARIANT: Neither presentation nor telemetry may treat a public
	 * query marker as an internal preview. The current user, capability and nonce
	 * must authorize the same request in every consuming subsystem.
	 */
	private static function is_authorized_parameters( $parameters ): bool {
		if( ! is_array( $parameters ) ) {
			return false;
		}

		$mode_value = $parameters['mode'] ?? '';
		$global_preview_value = $parameters['wphave-global-styles-preview'] ?? '';
		$nonce_value = $parameters['_wphave_preview_nonce'] ?? '';
		$mode = is_string( $mode_value ) ? sanitize_key( wp_unslash( $mode_value ) ) : '';
		$has_preview_marker = 'preview' === $mode
			|| ( is_string( $global_preview_value ) && '' !== $global_preview_value );
		$nonce = is_string( $nonce_value )
			? sanitize_text_field( wp_unslash( $nonce_value ) )
			: '';

		return $has_preview_marker
			&& is_user_logged_in()
			&& ( current_user_can( 'wphave_view_system_status' ) || current_user_can( 'manage_options' ) )
			&& (bool) wp_verify_nonce( $nonce, 'wphave_site_preview' );
	}
}
