<?php

/**
 * Shared utility functions for the WPHAVE site style system.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Convert a camelCase property name to CSS-compatible kebab-case.
 *
 * For example, textColor becomes text-color when JavaScript-style property
 * names are translated into generated CSS declarations.
 *
 * @param string $string Property name to convert.
 * @return string Kebab-case property name.
 */

if ( ! function_exists( 'wphave_camel_to_kebab_case' ) ) :

	function wphave_camel_to_kebab_case( $string ) {

		return strtolower(preg_replace('/([a-z])([A-Z])/', '$1-$2', $string));

	}

endif;


/**
 * Remove duplicate entries from a multidimensional array.
 *
 * @param array $array Values to deduplicate.
 * @return array Unique values with sequential numeric keys.
 */

if ( ! function_exists('wphave_array_unique_multidimensional') ) :

	function wphave_array_unique_multidimensional( $array ) {
		$unique = array();

		foreach( is_array( $array ) ? $array : array() as $value ) {
			$key = wp_json_encode( $value );

			if( $key === false || isset( $unique[$key] ) ) {
				continue;
			}

			$unique[$key] = $value;
		}

		return array_values( $unique );

	}

endif;
