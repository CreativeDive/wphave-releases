<?php

/**
 * Bootstrap site rendering, global styles and layout block helpers.
 */

include_once __DIR__ . '/style-utilities.php';
include_once __DIR__ . '/global-data.php';
include_once __DIR__ . '/global-styles.php';
include_once __DIR__ . '/style-engine.php';
include_once __DIR__ . '/global-background.php';
include_once __DIR__ . '/attachment-content.php';
include_once __DIR__ . '/render-engine.php';
include_once __DIR__ . '/manager.php';

wphave_include_file(wphave_dir() . 'build/block-types/blocks-layout/breadcrumb/functions.php');
wphave_include_file(wphave_dir() . 'build/block-types/blocks-layout/action/functions.php');
