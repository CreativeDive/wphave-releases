<?php

/**
 * Attachment presentation belongs inside the template's existing Content slot.
 * No media markup may be prepended to the assembled site layout. Core's filter
 * is suspended only for that rendering scope and restored even after errors.
 */

final class WPHAVE_Attachment_Content {

	/**
	 * Render a layout without WordPress prepending attachment markup to its content.
	 *
	 * Only attachment requests suspend prepend_attachment. Its original priority
	 * is restored after the callback, including when rendering throws an exception.
	 *
	 * @param callable $render Callback that renders the complete site layout.
	 * @return mixed Unmodified return value of the rendering callback.
	 */

	public static function with_layout_filters(callable $render) {
		$priority = is_attachment() ? has_filter('the_content', 'prepend_attachment') : false;

		if (false !== $priority) {
			remove_filter('the_content', 'prepend_attachment', $priority);
		}

		try {
			return $render();
		} finally {
			if (false !== $priority) {
				add_filter('the_content', 'prepend_attachment', $priority);
			}
		}
	}

	/**
	 * Build the media preview, caption and description for an attachment Content slot.
	 *
	 * Respects password protection on the attachment and its parent before rendering
	 * media. Images use a dedicated frame for disclosure overlays; audio and video
	 * use WordPress players. Other files fall back to a link with available metadata.
	 * Enqueues the preview stylesheet only when an attachment URL is available.
	 *
	 * @param int $post_id Attachment post ID.
	 * @param string $description Already-rendered content HTML, included without further escaping.
	 * @return string Media content HTML, a password form, or the unchanged description
	 *                when the post is not an attachment or has no attachment URL.
	 */

	public static function render($post_id, $description = '') {
		$post = get_post($post_id);

		if (!$post || 'attachment' !== $post->post_type) {
			return $description;
		}

		$parent = $post->post_parent ? get_post($post->post_parent) : null;

		if (post_password_required($post) || ($parent && post_password_required($parent))) {
			return get_the_password_form(
				$parent && post_password_required($parent) ? $parent : $post,
			);
		}

		$url = wp_get_attachment_url($post->ID);

		if (!$url) {
			return $description;
		}

		wp_enqueue_style(
			'wphave-attachment-content',
			wphave_asset_url('inc/site/assets/attachment-content.css'),
			[],
			(string) filemtime(__DIR__ . '/assets/attachment-content.css'),
		);

		$media = '';
		if (wp_attachment_is_image($post)) {
			$media = wp_get_attachment_image($post->ID, 'large', false, [
				'class' => 'wphave-attachment-image',
				'alt' =>
					get_post_meta($post->ID, '_wp_attachment_image_alt', true) ?: $post->post_title,
			]);

			if ($media) {
				$media =
					'<a href="' .
					esc_url($url) .
					'" aria-label="' .
					esc_attr($post->post_title ?: __('Open file', 'wphave')) .
					'">' .
					$media .
					'</a>';

				if (class_exists('WPHAVE_Media_Disclosure')) {
					$disclosure = WPHAVE_Media_Disclosure::render($post->ID);
					$media =
						'<div class="wphave-attachment-image-frame" ' .
						($disclosure['attributes'] ?? '') .
						'>' .
						$media .
						($disclosure['label'] ?? '') .
						'</div>';
				}
			}
		} elseif (wp_attachment_is('video', $post)) {
			$meta = wp_get_attachment_metadata($post->ID);
			$media = wp_video_shortcode([
				'src' => $url,
				'preload' => 'metadata',
				'width' => absint($meta['width'] ?? 640),
				'height' => absint($meta['height'] ?? 360),
			]);
		} elseif (wp_attachment_is('audio', $post)) {
			$media = wp_audio_shortcode(['src' => $url, 'preload' => 'metadata']);
		}

		if (!$media) {
			$media =
				'<p><a href="' .
				esc_url($url) .
				'">' .
				esc_html($post->post_title ?: __('Open file', 'wphave')) .
				'</a></p>';

			$mime = get_post_mime_type($post);
			$meta = wp_get_attachment_metadata($post->ID);

			$details = [$mime];
			if (!empty($meta['filesize'])) {
				$details[] = size_format($meta['filesize']);
			}

			$media .=
				'<p class="wphave-attachment-details">' .
				esc_html(implode(' · ', array_filter($details))) .
				'</p>';
		}

		$caption = wp_get_attachment_caption($post->ID);

		return '<div class="wphave-attachment-content"><figure class="wphave-attachment-preview">' .
			$media .
			($caption ? '<figcaption>' . wp_kses_post($caption) . '</figcaption>' : '') .
			'</figure><div class="wphave-attachment-description">' .
			$description .
			'</div></div>';
	}
}
