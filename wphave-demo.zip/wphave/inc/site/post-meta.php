<?php

/**
 * Register WPHAVE post metadata for public post types.
 *
 * REST exposure is required so block-editor sidebar controls can persist the
 * values through the entity API. Attachments keep their dedicated data flow.
 *
 * @return void
 */

if ( ! function_exists( 'wphave_register_custom_post_meta' ) ) :

	/** Authorize WPHAVE metadata against the exact owning post. */
	function wphave_can_edit_custom_post_meta( $allowed, $meta_key, $post_id, $user_id = 0 ) {
		$user_id = absint( $user_id ?: get_current_user_id() );
		$post_id = absint( $post_id );

		// AUTHORIZATION INVARIANT: General edit_posts capability grants access to an
		// editor workflow, not metadata on an arbitrary object. Every Core REST meta
		// write follows edit_post for the exact target immediately before persistence.
		return $user_id > 0 && $post_id > 0 && user_can( $user_id, 'edit_post', $post_id );
	}

    function wphave_register_custom_post_meta() {

        $post_types = get_post_types(
            array(
                'public' => true,
            ),
            'names'
        );

        foreach( $post_types as $post_type ) {

            if( $post_type === 'attachment' ) {
                continue;
            }

            // Post title hide
            register_post_meta( $post_type, 'wphave_title_visibility', array(
                'single' => true,
                'type' => 'string',
                'show_in_rest' => true,
				'auth_callback' => 'wphave_can_edit_custom_post_meta'
            ));

            // Post title alternative
            register_post_meta( $post_type, 'wphave_title_alternative', array(
                'single' => true,
                'type' => 'string',
                'show_in_rest' => true,
				'auth_callback' => 'wphave_can_edit_custom_post_meta'
            ));

            // Post subtitle
            register_post_meta( $post_type, 'wphave_subtitle', array(
                'single' => true,
                'type' => 'string',
                'show_in_rest' => true,
				'auth_callback' => 'wphave_can_edit_custom_post_meta'
            ));

            // Post sponsored
            register_post_meta( $post_type, 'wphave_sponsored', array(
                'single' => true,
                'type' => 'boolean',
                'show_in_rest' => true,
				'auth_callback' => 'wphave_can_edit_custom_post_meta'
            ));

            // Post ribbon label
            register_post_meta( $post_type, 'wphave_post_ribbon_label', array(
                'single' => true,
                'type' => 'string',
                'show_in_rest' => true,
				'auth_callback' => 'wphave_can_edit_custom_post_meta'
            ));

            // Post ribbon color
            register_post_meta( $post_type, 'wphave_post_ribbon_color', array(
                'single' => true,
                'type' => 'string',
                'show_in_rest' => true,
				'auth_callback' => 'wphave_can_edit_custom_post_meta'
            ));

            // Post gallery images
            register_post_meta( $post_type, 'wphave_post_gallery_images', array(
                'type' => 'array',
                'single' => true,
                'show_in_rest' => array(
                    'schema' => array(
                        'type'  => 'array',
                        'items' => array(
                            'type' => 'integer'
                        )
                    )
                ),
				'auth_callback' => 'wphave_can_edit_custom_post_meta'
            ));

            // Post custom template assignment
            register_post_meta( $post_type, 'wphave_custom_template', array(
                'single' => true,
                'type' => 'integer',
                'show_in_rest' => true,
				'auth_callback' => 'wphave_can_edit_custom_post_meta'
            ));

            // Analytics views (synced from the analytics aggregation)
            register_post_meta( $post_type, 'wphave_views_recent', array(
                'single' => true,
                'type' => 'integer',
                'default' => 0,
                'show_in_rest' => true,
				'auth_callback' => 'wphave_can_edit_custom_post_meta'
            ));

            register_post_meta( $post_type, 'wphave_views_lifetime', array(
                'single' => true,
                'type' => 'integer',
                'default' => 0,
                'show_in_rest' => true,
				'auth_callback' => 'wphave_can_edit_custom_post_meta'
            ));
        }

    }

endif;

add_action( 'init', 'wphave_register_custom_post_meta' );


/**
 * Protect WPHAVE post meta from the legacy Custom Fields meta box.
 *
 * When the legacy panel is enabled, the Classic Meta Box system processes all
 * metadata during save, including fields registered for useEntityProp() and
 * the REST API. It can overwrite or remove values submitted by Gutenberg.
 * Marking WPHAVE keys as protected keeps them out of that legacy save path so
 * REST-registered metadata continues to persist reliably.
 *
 * @param bool $protected Whether WordPress currently treats the key as protected.
 * @param string $meta_key Metadata key being inspected.
 * @return bool Whether the metadata key must be protected.
 */

if ( ! function_exists( 'wphave_protected_custom_post_meta' ) ) :

    function wphave_protected_custom_post_meta( $protected, $meta_key ) {

        if( strpos($meta_key, 'wphave_') === 0 ) {
            return true;
        }

        return $protected;

    }

endif;

add_filter( 'is_protected_meta', 'wphave_protected_custom_post_meta', 10, 2 );


/**
 * Return supported REST orderby values and their analytics meta keys.
 *
 * This mapping allows PostManager/useEntityRecords to request views_recent or
 * views_lifetime without exposing arbitrary meta-key sorting.
 *
 * @return array REST orderby values mapped to numeric metadata keys.
 */

if ( ! function_exists( 'wphave_analytics_views_orderby_map' ) ) :

    function wphave_analytics_views_orderby_map() {

        return array(
            'views_recent' => 'wphave_views_recent',
            'views_lifetime' => 'wphave_views_lifetime',
        );

    }

endif;


/**
 * Add analytics view sorting options to REST collection parameters.
 *
 * @param array $params REST collection parameters.
 * @return array Updated REST collection parameters.
 */

if ( ! function_exists( 'wphave_add_analytics_views_rest_orderby_params' ) ) :

    function wphave_add_analytics_views_rest_orderby_params( $params ) {

        $orderbys = array_keys( wphave_analytics_views_orderby_map() );

        if ( isset( $params['orderby']['enum'] ) && is_array( $params['orderby']['enum'] ) ) {
            $params['orderby']['enum'] = array_values(
                array_unique(
                    array_merge(
                        $params['orderby']['enum'],
                        $orderbys
                    )
                )
            );
        }

        return $params;

    }

endif;


/**
 * Translate an analytics REST orderby value into a numeric meta query.
 *
 * @param array $args WordPress query arguments.
 * @param WP_REST_Request $request Current REST request.
 * @return array Updated query arguments.
 */

if ( ! function_exists( 'wphave_apply_analytics_views_rest_orderby_query' ) ) :

    function wphave_apply_analytics_views_rest_orderby_query( $args, $request ) {

        $orderby = $request->get_param( 'orderby' );
        $map = wphave_analytics_views_orderby_map();

        if ( empty( $orderby ) || empty( $map[ $orderby ] ) ) {
            return $args;
        }

        $args['meta_key'] = $map[ $orderby ];
        $args['orderby'] = 'meta_value_num';

        if ( empty( $args['order'] ) ) {
            $args['order'] = 'DESC';
        }

        return $args;

    }

endif;


/**
 * Register analytics orderby filters for REST-enabled post types.
 *
 * @return void
 */

if ( ! function_exists( 'wphave_register_analytics_views_rest_orderby_filters' ) ) :

    function wphave_register_analytics_views_rest_orderby_filters() {

        $post_types = get_post_types(
            array(
                'show_in_rest' => true,
            ),
            'names'
        );

        foreach( $post_types as $post_type ) {
            add_filter( "rest_{$post_type}_collection_params", 'wphave_add_analytics_views_rest_orderby_params' );
            add_filter( "rest_{$post_type}_query", 'wphave_apply_analytics_views_rest_orderby_query', 10, 2 );
        }

    }

endif;

add_action( 'init', 'wphave_register_analytics_views_rest_orderby_filters', 20 );


/**
 * Determine whether a REST post object has empty block content.
 *
 * @param array|WP_Post $object REST post data or post object.
 * @return bool Whether the referenced post has no content.
 */

if ( ! function_exists( 'wphave_is_rest_post_empty' ) ) :

    function wphave_is_rest_post_empty( $object ) {

        $post_id = 0;

        if( is_array( $object ) && isset( $object['id'] ) ) {
            $post_id = (int) $object['id'];
        } elseif( is_object( $object ) && isset( $object->ID ) ) {
            $post_id = (int) $object->ID;
        }

        if( ! $post_id ) {
            return true;
        }

        $content = get_post_field( 'post_content', $post_id );

        return trim( (string) $content ) === '';

    }

endif;


/**
 * Register the read-only empty-content field for REST-enabled post types.
 *
 * @return void
 */

if ( ! function_exists( 'wphave_register_empty_post_rest_field' ) ) :

    function wphave_register_empty_post_rest_field() {

        $post_types = get_post_types(
            array(
                'show_in_rest' => true,
            ),
            'names'
        );

        foreach( $post_types as $post_type ) {
            register_rest_field(
                $post_type,
                'wphave_is_empty',
                array(
                    'get_callback' => 'wphave_is_rest_post_empty',
                    'schema' => array(
                        'description' => __( 'Whether the post content is empty.', 'wphave' ),
                        'type' => 'boolean',
                        'context' => array( 'view', 'edit' ),
                        'readonly' => true,
                    ),
                )
            );
        }

    }

endif;

add_action( 'rest_api_init', 'wphave_register_empty_post_rest_field' );
