<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Serialize read-modify-write operations on shared option collections.
 *
 * Browser-side queues only coordinate one JavaScript realm. This server-side
 * boundary also protects mutations arriving from multiple tabs and requests.
 */

class WPHAVE_Option_Mutations {
	private static array $held_locks = [];

	/** Invalidate every WordPress read path before reading under a mutation lock. */
	public static function clear_read_cache(string $option): void {
		// CONCURRENCY INVARIANT: get_option() checks alloptions and notoptions
		// before the individual entry. A lock cannot make those older snapshots
		// authoritative after another request has committed its write.
		wp_cache_delete('alloptions', 'options');
		wp_cache_delete('notoptions', 'options');
		wp_cache_delete($option, 'options');
	}

	public static function with_lock( string $option, callable $callback ) {
		global $wpdb;
		$lock_name = 'wphave_opt_' . md5( $option );

		// CONCURRENCY INVARIANT: Nested mutations in this request reuse ownership;
		// independent requests must acquire the same database-level option lock.
		if( ! empty( self::$held_locks[$lock_name] ) ) {
			return $callback();
		}

		$acquired = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 2)', $lock_name ) );

		if( $acquired !== 1 ) {
			return new WP_Error( 'wphave_option_mutation_locked', __( 'This resource is currently being updated. Please try again.', 'wphave' ), [ 'status' => 409 ] );
		}

		self::$held_locks[$lock_name] = true;

		try {
			return $callback();
		} finally {
			unset( self::$held_locks[$lock_name] );
			$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock_name ) );
		}
	}

	/**
	 * Mutate one shared option while preserving WordPress' autoload contract.
	 *
	 * @param string           $option Option name.
	 * @param callable         $mutation State transformer.
	 * @param bool|string|null $autoload WordPress autoload mode.
	 * @param string|null      $lock_scope Optional storage-specific lock scope.
	 */
	public static function mutate(
		string $option,
		callable $mutation,
		$autoload = false,
		?string $lock_scope = null
	) {
		return self::with_lock($lock_scope ?? $option, function () use (
			$option,
			$mutation,
			$autoload
		) {
			self::clear_read_cache($option);
			$current = get_option($option, []);
			$next = $mutation(is_array($current) ? $current : []);

			if (is_wp_error($next)) {
				return $next;
			}

			if (!is_array($next)) {
				return new WP_Error(
					'wphave_invalid_option_mutation',
					__('Invalid resource mutation.', 'wphave'),
					['status' => 500]
				);
			}

			$saved = update_option($option, $next, $autoload);

			if (!$saved) {
				self::clear_read_cache($option);
				$stored = get_option($option, null);

				// DATA-INTEGRITY INVARIANT: WordPress returns false for both an
				// unchanged value and a failed write. Only the former is success;
				// callers must never adopt state that persistence did not confirm.
				if ($stored !== $next) {
					return new WP_Error(
						'wphave_option_mutation_failed',
						__('The resource update could not be stored.', 'wphave'),
						['status' => 500]
					);
				}
			}

			return $next;
		});
	}
}
