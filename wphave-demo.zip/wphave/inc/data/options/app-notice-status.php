<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Builds the small, non-sensitive status model required by global app notices.
 *
 * OWNERSHIP INVARIANT: Global notices never mount complete settings resources or operational
 * controllers merely to decide whether a banner is visible. Detail screens
 * continue to load the complete data when the user opens them.
 *
 * @return array Notice status snapshot.
 */

function wphave_app_notice_status(): array {
	$can_view_privacy = current_user_can( 'manage_options' ) || current_user_can( 'wphave_manage_settings_privacy' );
	$can_view_mail = current_user_can( 'manage_options' ) || current_user_can( 'wphave_manage_settings_mail' );
	$can_view_performance = current_user_can( 'manage_options' ) || current_user_can( 'wphave_manage_performance' );
	$can_view_security = current_user_can( 'manage_options' ) || current_user_can( 'wphave_manage_settings_security' );
	$privacy = (array) wphave_data_get( 'privacy_settings', '', [] );
	$consent = (array) ( $privacy['consent'] ?? [] );
	$scripts = is_array( $consent['scripts'] ?? null ) ? $consent['scripts'] : [];
	$stored_services = is_array( $consent['services'] ?? null ) ? $consent['services'] : [];
	$valid_categories = [ 'necessary', 'analytics', 'marketing', 'preferences' ];
	$incomplete_custom_scripts = 0;

	foreach( $scripts as $script ) {
		if( ! is_array( $script ) || ( $script['enabled'] ?? true ) === false ) {
			continue;
		}

		$has_name = trim( (string) ( $script['name'] ?? '' ) ) !== '';
		$has_category = in_array( $script['category'] ?? '', $valid_categories, true );
		$has_code = trim( (string) ( $script['inline'] ?? $script['code'] ?? '' ) ) !== '';

		if( ! $has_name || ! $has_category || ! $has_code ) {
			$incomplete_custom_scripts++;
		}
	}

	$normalize_domain = static function( $domain ): string {
		$domain = strtolower( preg_replace( '/^www\./', '', trim( (string) $domain ) ) );
		$domain = rtrim( $domain, '.' );
		return preg_replace( '/:\d+$/', '', $domain );
	};
	$stored_by_domain = [];

	foreach( $stored_services as $service ) {
		if( ! is_array( $service ) ) continue;
		$domain = $normalize_domain( $service['domain'] ?? '' );
		if( $domain ) $stored_by_domain[$domain] = $service;
	}

	$find_stored_service = static function( string $domain ) use ( $stored_by_domain ): array {
		$matched_domain = '';
		$matched_service = [];

		foreach( $stored_by_domain as $stored_domain => $stored_service ) {
			if( $domain !== $stored_domain && ! str_ends_with( $domain, '.' . $stored_domain ) ) continue;
			if( strlen( $stored_domain ) <= strlen( $matched_domain ) ) continue;
			$matched_domain = $stored_domain;
			$matched_service = $stored_service;
		}

		return $matched_service;
	};

	// NOTICE PROJECTION INVARIANT: Scanner implementations are intentionally not
	// loaded for this small header request. Read only their non-sensitive persisted
	// projection; operational normalization remains owned by the scanner routes.
	$scan_status = get_option( 'wphave_privacy_scan_status', [] );
	$scan_status = is_array( $scan_status ) ? $scan_status : [];
	$scan_results = get_option( 'wphave_privacy_scan_results', [] );
	$scan_results = is_array( $scan_results ) ? $scan_results : [];
	$scan_state = sanitize_key( $scan_status['state'] ?? 'idle' );
	$scan_total = absint( $scan_status['total'] ?? $scan_results['total'] ?? 0 );
	$scan_processed = absint( $scan_status['processed'] ?? $scan_results['processed'] ?? 0 );

	if( 'complete' === $scan_state && $scan_total > 0 && $scan_processed < $scan_total ) {
		$scan_state = 'partial';
	}

	if( 'running' === $scan_state && ! get_option( 'wphave_privacy_scan_job', [] ) ) {
		$scan_state = $scan_total > 0 && $scan_processed >= $scan_total ? 'complete' : 'partial';
	}
	$unassigned_services = 0;

	foreach( (array) ( $scan_results['services'] ?? [] ) as $service ) {
		if( ! is_array( $service ) || ( $service['resourceType'] ?? 'consent' ) !== 'consent' ) continue;
		$domain = $normalize_domain( $service['domain'] ?? '' );
		if( ! $domain || 'w3.org' === $domain || str_ends_with( $domain, '.w3.org' ) ) continue;
		$stored = $find_stored_service( $domain );
		$category = $stored['category'] ?? $service['category'] ?? '';

		if( empty( $category ) && ( $stored['blockingEnabled'] ?? true ) !== false ) {
			$unassigned_services++;
		}
	}

	$scan_errors = array_merge( (array) ( $scan_results['errors'] ?? [] ), (array) ( $scan_status['errors'] ?? [] ) );
	$scan_running = 'running' === $scan_state;
	$privacy_scan_incomplete = ! empty( $scan_results['partial'] ) || ! empty( $scan_status['partial'] ) || 'partial' === $scan_state || ( ! $scan_running && $scan_total > 0 && $scan_processed < $scan_total ) || ! empty( $scan_errors );

	$smtp_info = class_exists( 'WPHAVE_SMTP' ) ? WPHAVE_SMTP::get_public_info() : [];
	$smtp_incomplete = ! empty( $smtp_info['enabled'] ) && empty( $smtp_info['configured'] );
	$asset_cache_enabled = (bool) wphave_data_get( 'site_settings', 'advanced.performance.asset_cache', false );
	$security_scan = get_option( 'wphave_security_scan_results', [] );
	$security_scan = is_array( $security_scan ) ? $security_scan : [];
	$security_counts = is_array( $security_scan['counts'] ?? null ) ? $security_scan['counts'] : [];
	$htaccess_status = [];

	if( $asset_cache_enabled && class_exists( 'WPHAVE_Htaccess_Manager' ) ) {
		$htaccess_status = ( new WPHAVE_Htaccess_Manager() )->get_status();
	}

	// AUTHORIZATION INVARIANT: The global notice route is only a transport. Each
	// operational projection retains the capability of its owning module; login
	// alone must not reveal privacy posture, mail configuration, .htaccess state
	// or security-scan findings to a basic account.
	return [
		'privacy' => $can_view_privacy ? [
			'complianceEnabled' => (bool) ( $consent['banner']['isEnabled'] ?? false ),
			'unassignedServices' => $unassigned_services,
			'incompleteCustomScripts' => $incomplete_custom_scripts,
			'scanIncomplete' => $privacy_scan_incomplete,
		] : [
			'complianceEnabled' => false,
			'unassignedServices' => 0,
			'incompleteCustomScripts' => 0,
			'scanIncomplete' => false,
		],
		'smtp' => $can_view_mail ? [
			'enabled' => ! empty( $smtp_info['enabled'] ),
			'incomplete' => $smtp_incomplete,
		] : [
			'enabled' => false,
			'incomplete' => false,
		],
		'assetCache' => $can_view_performance ? [
			'enabled' => $asset_cache_enabled,
			'htaccess' => $htaccess_status,
		] : [
			'enabled' => false,
			'htaccess' => [],
		],
		'security' => $can_view_security ? [
			'scanState' => sanitize_key( $security_scan['state'] ?? 'idle' ),
			'findings' => absint( $security_counts['total'] ?? 0 ),
			'criticalFindings' => absint( $security_counts['critical'] ?? 0 ),
		] : [
			'scanState' => 'idle',
			'findings' => 0,
			'criticalFindings' => 0,
		],
		'generatedAt' => time(),
	];
}

/**
 * Returns a fresh notice status after a settings workflow has saved.
 */

function wphave_rest_app_notice_status() {
	// AUTHORIZATION INVARIANT: The route-level login check is only an early
	// transport gate. Direct and composed callback invocation must fail before
	// reading any persisted operational projection for an anonymous principal.
	if ( ! is_user_logged_in() ) {
		return new WP_Error(
			'wphave_app_notice_status_forbidden',
			__( 'You must be logged in to view application notices.', 'wphave' ),
			array( 'status' => 401 )
		);
	}

	return rest_ensure_response( wphave_app_notice_status() );
}

add_action( 'rest_api_init', static function() {
	register_rest_route( 'wphave/v1', '/app-notice-status', [
		'methods' => WP_REST_Server::READABLE,
		'callback' => 'wphave_rest_app_notice_status',
		'permission_callback' => static function() {
			return is_user_logged_in();
		},
	] );
} );
