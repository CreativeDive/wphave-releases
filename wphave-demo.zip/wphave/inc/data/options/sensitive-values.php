<?php

if ( ! class_exists( 'WPHAVE_Data_Sensitive_Values' ) ) :

	/**
	 * Handles REST masking and preservation of sensitive data values.
	 */

	class WPHAVE_Data_Sensitive_Values {

		/**
		 * Returns the sentinel used for sensitive values exposed to JavaScript.
		 *
		 * @return string
		 */

		public static function masked_value(): string {

			return '__wphave_sensitive_value__';

		}

		/**
		 * Checks whether a value is the sensitive-value sentinel.
		 *
		 * @param mixed $value Value to check.
		 * @return bool
		 */

		public static function is_masked_value( $value ): bool {

			return $value === self::masked_value();

		}

		/**
		 * Masks configured sensitive values for REST responses.
		 *
		 * @param array $data Resource data.
		 * @param array $config Resource config.
		 * @return array
		 */

		public static function mask_for_rest( array $data, array $config ): array {

			$unmasked_capability = $config['unmasked_sensitive_capability'] ?? '';

			if( $unmasked_capability && current_user_can( $unmasked_capability ) ) {
				return $data;
			}

			// SECURITY INVARIANT: Sensitive paths cross the REST boundary only for an
			// explicitly authorized capability. Every other caller receives a sentinel,
			// PRIVACY INVARIANT: Expose only presence state, never a reversible representation of the secret.
			foreach( $config['sensitive_paths'] ?? [] as $path => $secret ) {
				$path_capability = $config['sensitive_path_capabilities'][$path] ?? '';
				if( $path_capability && current_user_can( $path_capability ) ) continue;
				$value = WPHAVE_Data_Resources::get_path_value( $data, $path );

				if( ! empty( $value ) ) {
					$data = WPHAVE_Data_Resources::set_path_value( $data, $path, self::masked_value() );
				}
			}

			return $data;

		}

		/**
		 * Replaces masked REST values with their currently stored values.
		 *
		 * @param array $data Resource data.
		 * @param array $config Resource config.
		 * @return array
		 */

		public static function preserve_masked_values( array $data, array $config ): array {

			// SECURITY INVARIANT: The public masking sentinel means "preserve", not
			// "replace". Round-tripping a masked form cannot overwrite an existing
			// secret with the placeholder exposed to JavaScript.
			foreach( $config['sensitive_paths'] ?? [] as $path => $secret ) {
				$value = WPHAVE_Data_Resources::get_path_value( $data, $path );

				if( ! self::is_masked_value( $value ) ) {
					continue;
				}

				$stored_data = isset( $config['key'] )
					? WPHAVE_Data_Repository::get_option_key( $config['option'], $config['key'] )
					: WPHAVE_Data_Repository::get_option_data( $config['option'] );
				$stored_value = WPHAVE_Data_Resources::get_path_value( $stored_data, $path );

				if( ! empty( $stored_value ) ) {
					$data = WPHAVE_Data_Resources::set_path_value( $data, $path, $stored_value );
				}
			}

			return $data;

		}

	}

endif;
