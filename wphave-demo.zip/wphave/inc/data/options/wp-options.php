<?php

if (!class_exists('WPHAVE_WP_Options')):
	/**
	 * Exposes selected WordPress core options to the wphave settings UI.
	 *
	 * This class intentionally manages WordPress-owned options, not wphave data
	 * resources. Every writable option is explicitly registered with capability,
	 * sanitization, choices and side effects.
	 */

	class WPHAVE_WP_Options {
		/**
		 * REST namespace.
		 *
		 * @var string
		 */

		private const NAMESPACE = 'wphave/v1';

		/**
		 * Registers REST routes.
		 *
		 * @return void
		 */

		public static function register_routes(): void {
			register_rest_route(self::NAMESPACE, '/wp-options', [
				[
					'methods' => 'GET',
					'callback' => [__CLASS__, 'get_options'],
					'permission_callback' => [__CLASS__, 'can_manage_options'],
				],
				[
					'methods' => 'POST',
					'callback' => [__CLASS__, 'save_options'],
					'permission_callback' => [__CLASS__, 'can_manage_options'],
				],
				[
					'methods' => 'PATCH',
					'callback' => [__CLASS__, 'patch_option'],
					'permission_callback' => [__CLASS__, 'can_manage_options'],
				],
			]);

			register_rest_route(self::NAMESPACE, '/onboarding/basics', [
				'methods' => 'POST',
				'callback' => [__CLASS__, 'save_onboarding_basics'],
				'permission_callback' => [__CLASS__, 'can_save_onboarding_basics'],
				'args' => [
					'options' => [
						'type' => 'object',
						'required' => true,
					],
					'siteSettings' => [
						'type' => 'object',
						'required' => true,
					],
				],
			]);

			register_rest_route(self::NAMESPACE, '/settings/privacy', [
				'methods' => 'POST',
				'callback' => [__CLASS__, 'save_privacy_settings'],
				'permission_callback' => [__CLASS__, 'can_manage_privacy_settings'],
				'args' => [
					'privacy' => ['type' => 'object', 'required' => true],
					'privacyPolicyPage' => [
						'type' => 'integer',
						'minimum' => 0,
						'required' => true,
					],
					'revision' => ['type' => 'string', 'required' => true],
				],
			]);
		}

		/** Determine whether the current user may commit the combined Privacy state. */
		public static function can_manage_privacy_settings(): bool {
			$can_manage =
				current_user_can('manage_options') ||
				current_user_can('wphave_manage_settings_privacy') ||
				current_user_can('wphave_manage_settings');

			return $can_manage &&
				function_exists('wphave_privacy_has_pro_access') &&
				wphave_privacy_has_pro_access();
		}

		/**
		 * Checks whether the current user can manage WordPress options.
		 *
		 * @return bool
		 */

		public static function can_manage_options(?WP_REST_Request $request = null): bool {
			if (current_user_can('manage_options')) {
				return true;
			}

			$keys = $request ? self::requested_write_keys($request) : [];
			if (empty($keys) && $request && $request->get_method() === 'GET') {
				$keys = self::request_keys($request) ?? [];
			}
			if (empty($keys)) {
				return false;
			}

			foreach ($keys as $key) {
				$capability = self::capability_for_key((string) $key);
				if (!current_user_can($capability) && !current_user_can('wphave_manage_settings')) {
					return false;
				}
			}

			return true;
		}

		public static function can_save_onboarding_basics(WP_REST_Request $request): bool {
			if (!self::can_manage_options($request)) {
				return false;
			}

			$site_settings = $request->get_param('siteSettings');
			if (!is_array($site_settings)) {
				return false;
			}

			// AUTHORIZATION INVARIANT: Onboarding crosses two independent stores.
			// Authority over Brand-owned WordPress options never grants authority over
			// unrelated site-settings paths carried in the same request body.
			return WPHAVE_Data_Resources::current_user_can_write(
				'site_settings',
				$site_settings,
				null,
			);
		}

		private static function requested_write_keys(WP_REST_Request $request): array {
			if ($request->get_param('key')) {
				return [sanitize_key((string) $request->get_param('key'))];
			}
			$options = $request->get_param('options');
			if (!is_array($options)) {
				$options = $request->get_param('values');
			}

			return is_array($options) ? array_map('sanitize_key', array_keys($options)) : [];
		}

		private static function capability_for_key(string $key): string {
			if (in_array($key, ['site_title', 'site_tagline', 'site_icon'], true)) {
				return 'wphave_manage_settings_brand';
			}
			if ($key === 'privacy_policy_page') {
				return 'wphave_manage_settings_privacy';
			}

			return 'wphave_manage_settings_general';
		}

		/**
		 * Returns the writable WordPress option registry.
		 *
		 * @return array
		 */

		public static function registry(): array {
			return [
				'site_title' => [
					'option' => 'blogname',
					'type' => 'string',
					'sanitize' => 'sanitize_text_field',
				],
				'site_tagline' => [
					'option' => 'blogdescription',
					'type' => 'string',
					'sanitize' => 'sanitize_text_field',
				],
				'site_icon' => [
					'option' => 'site_icon',
					'type' => 'integer',
					'sanitize' => 'absint',
				],
				'language' => [
					'option' => 'WPLANG',
					'type' => 'string',
					'sanitize' => 'sanitize_text_field',
					'choices' => [__CLASS__, 'language_choices'],
					'before_save' => [__CLASS__, 'install_language'],
				],
				'timezone' => [
					'read' => [__CLASS__, 'read_timezone'],
					'write' => [__CLASS__, 'write_timezone'],
					'type' => 'string',
					'sanitize' => 'sanitize_text_field',
					'choices' => [__CLASS__, 'timezone_choices'],
				],
				'date_format' => [
					'option' => 'date_format',
					'type' => 'string',
					'sanitize' => 'sanitize_text_field',
					'choices' => [__CLASS__, 'date_format_choices'],
				],
				'time_format' => [
					'option' => 'time_format',
					'type' => 'string',
					'sanitize' => 'sanitize_text_field',
					'choices' => [__CLASS__, 'time_format_choices'],
				],
				'start_of_week' => [
					'option' => 'start_of_week',
					'type' => 'integer',
					'sanitize' => 'absint',
					'choices' => [__CLASS__, 'week_start_choices'],
				],
				'permalink_structure' => [
					'option' => 'permalink_structure',
					'type' => 'string',
					'sanitize' => 'sanitize_text_field',
					'choices' => [__CLASS__, 'permalink_choices'],
					'after_save' => [__CLASS__, 'flush_rewrites'],
				],
				'show_on_front' => [
					'option' => 'show_on_front',
					'type' => 'string',
					'sanitize' => 'sanitize_key',
					'choices' => [__CLASS__, 'show_on_front_choices'],
				],
				'page_on_front' => [
					'option' => 'page_on_front',
					'type' => 'integer',
					'sanitize' => 'absint',
					'choices' => [__CLASS__, 'page_choices'],
				],
				'page_for_posts' => [
					'option' => 'page_for_posts',
					'type' => 'integer',
					'sanitize' => 'absint',
					'choices' => [__CLASS__, 'page_choices'],
				],
				'privacy_policy_page' => [
					'option' => 'wp_page_for_privacy_policy',
					'type' => 'integer',
					'sanitize' => 'absint',
					'choices' => [__CLASS__, 'page_choices'],
				],
				'users_can_register' => [
					'option' => 'users_can_register',
					'type' => 'boolean',
					'sanitize' => [__CLASS__, 'sanitize_boolean'],
				],
				'default_role' => [
					'option' => 'default_role',
					'type' => 'string',
					'sanitize' => 'sanitize_key',
					'choices' => [__CLASS__, 'role_choices'],
				],
				'posts_per_page' => [
					'option' => 'posts_per_page',
					'type' => 'integer',
					'sanitize' => 'absint',
				],
				'default_comment_status' => [
					'option' => 'default_comment_status',
					'type' => 'string',
					'sanitize' => 'sanitize_key',
					'choices' => [__CLASS__, 'open_closed_choices'],
				],
				'default_ping_status' => [
					'option' => 'default_ping_status',
					'type' => 'string',
					'sanitize' => 'sanitize_key',
					'choices' => [__CLASS__, 'open_closed_choices'],
				],
				'default_pingback_flag' => [
					'option' => 'default_pingback_flag',
					'type' => 'boolean',
					'sanitize' => [__CLASS__, 'sanitize_boolean'],
				],
				'comment_registration' => [
					'option' => 'comment_registration',
					'type' => 'boolean',
					'sanitize' => [__CLASS__, 'sanitize_boolean'],
				],
				'comments_notify' => [
					'option' => 'comments_notify',
					'type' => 'boolean',
					'sanitize' => [__CLASS__, 'sanitize_boolean'],
				],
				'moderation_notify' => [
					'option' => 'moderation_notify',
					'type' => 'boolean',
					'sanitize' => [__CLASS__, 'sanitize_boolean'],
				],
			];
		}

		/**
		 * Returns values, choices and schema for the UI.
		 *
		 * @return array
		 */

		public static function get_options(?WP_REST_Request $request = null) {
			// AUTHORIZATION INVARIANT: Option capabilities are key-scoped. REST route
			// dispatch is only an early gate, so a direct/composed callback must prove
			// authority over the exact requested key set before reading any value.
			if (!$request || !self::can_manage_options($request)) {
				return new WP_Error(
					'wphave_wp_options_forbidden',
					__('You are not allowed to view these WordPress options.', 'wphave'),
					['status' => 403],
				);
			}

			$keys = self::request_keys($request);
			$include_choices = !in_array(
				(string) $request->get_param('include_choices'),
				['0', 'false', 'no'],
				true,
			);

			return self::options_response($keys, $include_choices);
		}

		/** Build an already-authorized options projection for internal composition. */
		private static function options_response(
			?array $keys,
			bool $include_choices = true,
		): array {
			return [
				'values' => self::values($keys),
				'choices' => $include_choices ? self::choices($keys) : [],
				'schema' => self::schema($keys),
			];
		}

		/**
		 * Parses an optional comma-separated list of option keys from a REST request.
		 *
		 * @param WP_REST_Request|null $request REST request.
		 * @return array|null
		 */

		private static function request_keys(?WP_REST_Request $request): ?array {
			if (!$request) {
				return null;
			}

			$keys = $request->get_param('keys');

			if (empty($keys)) {
				return null;
			}

			if (is_string($keys)) {
				$keys = explode(',', $keys);
			}

			$registry = self::registry();
			$keys = array_values(
				array_filter(array_map('sanitize_key', (array) $keys), function ($key) use (
					$registry,
				) {
					return isset($registry[$key]);
				}),
			);

			return !empty($keys) ? $keys : null;
		}

		/**
		 * Saves a set of registered WordPress options.
		 *
		 * @param WP_REST_Request $request REST request.
		 * @return array|WP_Error
		 */

		public static function save_options(WP_REST_Request $request) {
			// AUTHORIZATION INVARIANT: Mixed option writes are authorized as one exact
			// key set before validation or mutation; per-option sink checks remain the
			// final defense against a changed or directly invoked request.
			if (!self::can_manage_options($request)) {
				return new WP_Error(
					'wphave_wp_options_forbidden',
					__('You are not allowed to update these WordPress options.', 'wphave'),
					['status' => 403],
				);
			}

			$options = (array) $request->get_param('options');

			if (empty($options) && is_array($request->get_param('values'))) {
				$options = (array) $request->get_param('values');
			}

			$registry = self::registry();
			$prepared = [];
			foreach ($options as $key => $value) {
				$key = (string) $key;
				if (!isset($registry[$key])) {
					return new WP_Error(
						'wphave_invalid_wp_option',
						__('Invalid WordPress option.', 'wphave'),
						['status' => 400],
					);
				}
				$entry = $registry[$key];
				$value = self::sanitize_value($value, $entry);
				if (!self::is_allowed_value($value, $entry)) {
					return new WP_Error(
						'wphave_invalid_wp_option_value',
						__('Invalid WordPress option value.', 'wphave'),
						['status' => 400],
					);
				}
				$prepared[$key] = $value;
			}

			foreach ($prepared as $key => $value) {
				$result = self::save_option((string) $key, $value);

				if (is_wp_error($result)) {
					return $result;
				}
			}

			return self::get_options($request);
		}

		/**
		 * Commit the WordPress and WPHAVE values that form one onboarding step.
		 *
		 * Keeping this boundary on the server prevents a successful half-save
		 * when either resource rejects the request.
		 *
		 * @param WP_REST_Request $request REST request.
		 * @return array|WP_Error
		 */

		public static function save_onboarding_basics(WP_REST_Request $request) {
			if (!self::can_save_onboarding_basics($request)) {
				return new WP_Error(
					'wphave_onboarding_settings_forbidden',
					__('You are not allowed to save these onboarding settings.', 'wphave'),
					['status' => 403],
				);
			}

			$options = (array) $request->get_param('options');
			$site_settings = $request->get_param('siteSettings');

			if (!is_array($site_settings)) {
				return new WP_Error(
					'wphave_invalid_onboarding_settings',
					__('Invalid onboarding settings.', 'wphave'),
					['status' => 400],
				);
			}

			// SECURITY INVARIANT: WordPress options and WPHAVE site settings form one
			// logical write; any failed leg restores only values still owned by this request.
			$allowed_options = array_intersect_key(
				$options,
				array_flip(['site_title', 'site_tagline']),
			);
			$option_snapshot = self::values(array_keys($allowed_options));
			$settings_snapshot = wphave_data_get('site_settings');
			$settings_revision = WPHAVE_Data_Resources::get_revision('site_settings');
			$written_options = [];

			foreach ($allowed_options as $key => $value) {
				$result = self::save_option((string) $key, $value);

				if (is_wp_error($result)) {
					self::restore_onboarding_basics(
						$option_snapshot,
						$written_options,
						$settings_snapshot,
						$settings_revision,
					);
					return $result;
				}

				$written_options[(string) $key] =
					self::values([(string) $key])[(string) $key] ?? null;
			}

			$saved_settings = WPHAVE_Data_Resources::save(
				'site_settings',
				$site_settings,
				$settings_revision,
			);

			if (is_wp_error($saved_settings)) {
				self::restore_onboarding_basics(
					$option_snapshot,
					$written_options,
					$settings_snapshot,
					$settings_revision,
				);
				return $saved_settings;
			}

			return [
				'options' => self::options_response(null),
				'siteSettings' =>
					$saved_settings['data'] ?? WPHAVE_Data_Resources::get_for_rest('site_settings'),
				'siteSettingsRevision' =>
					$saved_settings['revision'] ??
					WPHAVE_Data_Resources::get_revision('site_settings'),
			];
		}

		public static function save_privacy_settings(WP_REST_Request $request) {
			// AUTHORIZATION INVARIANT: Privacy commits cross the WPHAVE resource and
			// WordPress privacy-page stores. The combined capability and entitlement
			// policy is repeated before validation, revision disclosure, or mutation.
			if (!self::can_manage_privacy_settings()) {
				return new WP_Error(
					'wphave_privacy_settings_forbidden',
					__('You are not allowed to update Privacy settings.', 'wphave'),
					['status' => 403],
				);
			}

			$privacy = $request->get_param('privacy');
			$privacy_policy_page = $request->get_param('privacyPolicyPage');
			$revision = $request->get_param('revision');
			if (!is_array($privacy)) {
				return new WP_Error(
					'wphave_invalid_privacy_settings',
					__('Invalid privacy settings.', 'wphave'),
					['status' => 400],
				);
			}
			if (!is_string($revision) || $revision === '') {
				return new WP_Error(
					'wphave_missing_revision',
					__('Reload the privacy settings before saving again.', 'wphave'),
					['status' => 409],
				);
			}
			$current_revision = WPHAVE_Data_Resources::get_revision('privacy_settings');
			if (!hash_equals($current_revision, $revision)) {
				return new WP_Error(
					'wphave_resource_conflict',
					__(
						'The privacy settings changed elsewhere. Reload them before saving again.',
						'wphave',
					),
					['status' => 409, 'revision' => $current_revision],
				);
			}

			// SECURITY INVARIANT: The WordPress privacy-page pointer and WPHAVE privacy
			// document advance together; rollback must not overwrite a concurrent page change.
			$old_page = self::values(['privacy_policy_page'])['privacy_policy_page'] ?? 0;
			$option_result = self::save_option('privacy_policy_page', $privacy_policy_page);
			if (is_wp_error($option_result)) {
				return $option_result;
			}

			$saved = WPHAVE_Data_Resources::save('privacy_settings', $privacy, $revision);
			if (is_wp_error($saved)) {
				if ((int) get_option('wp_page_for_privacy_policy') === (int) $privacy_policy_page) {
					self::save_option('privacy_policy_page', $old_page);
				}
				return $saved;
			}

			return [
				'privacy' => $saved,
				'options' => self::get_options_for_keys(['privacy_policy_page']),
			];
		}

		private static function get_options_for_keys(array $keys): array {
			return [
				'values' => self::values($keys),
				'choices' => self::choices($keys),
				'schema' => self::schema($keys),
			];
		}

		/**
		 * Restore both onboarding resources after a failed commit.
		 *
		 * @param array $options WordPress option snapshot.
		 * @param array $written_options Values written by this transaction.
		 * @param array $site_settings WPHAVE site-settings snapshot.
		 * @param string $settings_revision Revision captured before the transaction.
		 */

		private static function restore_onboarding_basics(
			array $options,
			array $written_options,
			array $site_settings,
			string $settings_revision,
		): void {
			foreach ($options as $key => $value) {
				$current = self::values([(string) $key]);

				if (
					array_key_exists($key, $written_options) &&
					($current[$key] ?? null) === $written_options[$key]
				) {
					self::save_option((string) $key, $value);
				}
			}

			// Never replace a concurrent settings save from another browser tab.
			if (
				hash_equals(
					WPHAVE_Data_Resources::get_revision('site_settings'),
					$settings_revision,
				)
			) {
				WPHAVE_Data_Resources::save('site_settings', $site_settings, $settings_revision);
			}
		}

		/**
		 * Saves one registered WordPress option.
		 *
		 * @param WP_REST_Request $request REST request.
		 * @return array|WP_Error
		 */

		public static function patch_option(WP_REST_Request $request) {
			// AUTHORIZATION INVARIANT: The PATCH callback repeats the exact-key route
			// policy before entering the option mutation sink.
			if (!self::can_manage_options($request)) {
				return new WP_Error(
					'wphave_wp_options_forbidden',
					__('You are not allowed to update this WordPress option.', 'wphave'),
					['status' => 403],
				);
			}

			$key = (string) $request->get_param('key');
			$result = self::save_option($key, $request->get_param('value'));

			if (is_wp_error($result)) {
				return $result;
			}

			return self::get_options($request);
		}

		/**
		 * Reads current registered option values.
		 *
		 * @return array
		 */

		private static function values(?array $keys = null): array {
			$values = [];

			foreach (self::registry() as $key => $entry) {
				if ($keys && !in_array($key, $keys, true)) {
					continue;
				}

				$values[$key] = self::read_option($entry);
			}

			return $values;
		}

		/**
		 * Reads one registered option.
		 *
		 * @param array $entry Registry entry.
		 * @return mixed
		 */

		private static function read_option(array $entry) {
			if (!empty($entry['read']) && is_callable($entry['read'])) {
				return call_user_func($entry['read']);
			}

			return get_option($entry['option'] ?? '');
		}

		/**
		 * Saves one registered option.
		 *
		 * @param string $key Public option key.
		 * @param mixed $value Raw value.
		 * @return true|WP_Error
		 */

		// Shared mutation sink for site-local settings and network administration.
		// Callers establish blog context; this sink always rechecks native authority.
		public static function save_option(string $key, $value) {
			$registry = self::registry();

			if (!isset($registry[$key])) {
				return new WP_Error(
					'wphave_invalid_wp_option',
					__('Invalid WordPress option.', 'wphave'),
					['status' => 400],
				);
			}

			$entry = $registry[$key];
			$previous_value = self::read_option($entry);
			$capability = $entry['capability'] ?? self::capability_for_key($key);

			if (
				!current_user_can('manage_options') &&
				!current_user_can($capability) &&
				!current_user_can('wphave_manage_settings')
			) {
				return new WP_Error(
					'wphave_wp_option_forbidden',
					__('You are not allowed to update this WordPress option.', 'wphave'),
					['status' => 403],
				);
			}

			$value = self::sanitize_value($value, $entry);

			if (!self::is_allowed_value($value, $entry)) {
				return new WP_Error(
					'wphave_invalid_wp_option_value',
					__('Invalid WordPress option value.', 'wphave'),
					['status' => 400],
				);
			}

			if (!empty($entry['before_save']) && is_callable($entry['before_save'])) {
				call_user_func($entry['before_save'], $value);
			}

			if (!empty($entry['write']) && is_callable($entry['write'])) {
				call_user_func($entry['write'], $value);
			} else {
				update_option($entry['option'], $value);
			}

			if (!empty($entry['after_save']) && is_callable($entry['after_save'])) {
				call_user_func($entry['after_save'], $value);
			}

			if (self::read_option($entry) !== $previous_value) {
				do_action('wphave_frontend_output_changed', ['wpOption' => $key]);
			}

			return true;
		}

		/**
		 * Sanitizes one option value.
		 *
		 * @param mixed $value Raw value.
		 * @param array $entry Registry entry.
		 * @return mixed
		 */

		private static function sanitize_value($value, array $entry) {
			if (empty($entry['sanitize']) || !is_callable($entry['sanitize'])) {
				return $value;
			}

			return call_user_func($entry['sanitize'], $value);
		}

		/**
		 * Checks a value against server-side choices when choices are finite.
		 *
		 * @param mixed $value Option value.
		 * @param array $entry Registry entry.
		 * @return bool
		 */

		private static function is_allowed_value($value, array $entry): bool {
			if (empty($entry['choices']) || !is_callable($entry['choices'])) {
				return true;
			}

			$choices = call_user_func($entry['choices']);
			$allowed = array_map('strval', wp_list_pluck($choices, 'value'));

			return in_array((string) $value, $allowed, true);
		}

		/**
		 * Returns choices for each registered option.
		 *
		 * @return array
		 */

		private static function choices(?array $keys = null): array {
			$choices = [];

			foreach (self::registry() as $key => $entry) {
				if ($keys && !in_array($key, $keys, true)) {
					continue;
				}

				if (!empty($entry['choices']) && is_callable($entry['choices'])) {
					$choices[$key] = call_user_func($entry['choices']);
				}
			}

			return $choices;
		}

		/**
		 * Returns a compact schema for UI rendering and validation.
		 *
		 * @return array
		 */

		private static function schema(?array $keys = null): array {
			$schema = [];

			foreach (self::registry() as $key => $entry) {
				if ($keys && !in_array($key, $keys, true)) {
					continue;
				}

				$schema[$key] = [
					'type' => $entry['type'] ?? 'string',
					'capability' => $entry['capability'] ?? 'manage_options',
					'hasChoices' => !empty($entry['choices']),
				];
			}

			return $schema;
		}

		/**
		 * Sanitizes checkbox-like option values.
		 *
		 * @param mixed $value Raw value.
		 * @return int
		 */

		public static function sanitize_boolean($value): int {
			return rest_sanitize_boolean($value) ? 1 : 0;
		}

		/**
		 * Reads the current timezone value.
		 *
		 * @return string
		 */

		public static function read_timezone(): string {
			return wp_timezone_string();
		}

		/**
		 * Writes timezone options.
		 *
		 * @param string $value Timezone identifier.
		 * @return void
		 */

		public static function write_timezone(string $value): void {
			if (preg_match('/^([+-])(\d{2}):(\d{2})$/', $value, $matches)) {
				$offset = (int) $matches[2] + (int) $matches[3] / 60;
				update_option('timezone_string', '');
				update_option('gmt_offset', $matches[1] === '-' ? -$offset : $offset);
				return;
			}

			update_option('timezone_string', $value);
			update_option('gmt_offset', 0);
		}

		/**
		 * Downloads a language pack before saving when needed.
		 *
		 * @param string $value Locale.
		 * @return void
		 */

		public static function install_language(string $value): void {
			if ($value === '' || in_array($value, get_available_languages(), true)) {
				return;
			}

			require_once ABSPATH . 'wp-admin/includes/translation-install.php';
			wp_download_language_pack($value);
		}

		/**
		 * Flushes rewrite rules after permalink changes.
		 *
		 * @return void
		 */

		public static function flush_rewrites(): void {
			flush_rewrite_rules();
		}

		/**
		 * Returns timezone choices.
		 *
		 * @return array
		 */

		public static function timezone_choices(): array {
			$choices = array_map(
				fn($timezone) => [
					'value' => $timezone,
					'label' => str_replace('_', ' ', $timezone),
				],
				timezone_identifiers_list(),
			);

			return self::with_current_choice($choices, self::read_timezone());
		}

		/**
		 * Returns language choices.
		 *
		 * @return array
		 */

		public static function language_choices(): array {
			require_once ABSPATH . 'wp-admin/includes/translation-install.php';

			$installed = get_available_languages();
			$translations = wp_get_available_translations();
			$choices = [
				[
					'value' => '',
					'label' => 'English (United States)',
				],
			];

			foreach ($installed as $locale) {
				$translation = $translations[$locale] ?? [];
				$choices[] = [
					'value' => $locale,
					'label' => $translation['native_name'] ?? $locale,
				];
			}

			foreach ($translations as $locale => $translation) {
				$choices[] = [
					'value' => $locale,
					'label' => $translation['native_name'] ?? $locale,
				];
			}

			$unique = [];

			foreach ($choices as $choice) {
				$unique[$choice['value']] = $choice;
			}

			return array_values($unique);
		}

		/**
		 * Returns common date format choices.
		 *
		 * @return array
		 */

		public static function date_format_choices(): array {
			return self::format_choices(
				['F j, Y', 'Y-m-d', 'm/d/Y', 'd/m/Y', 'd.m.Y'],
				'date_i18n',
				get_option('date_format'),
			);
		}

		/**
		 * Returns common time format choices.
		 *
		 * @return array
		 */

		public static function time_format_choices(): array {
			return self::format_choices(
				['g:i a', 'g:i A', 'H:i'],
				'date_i18n',
				get_option('time_format'),
			);
		}

		/**
		 * Builds date/time format choices.
		 *
		 * @param array $formats Format strings.
		 * @param callable $callback Formatter.
		 * @param string $current_value Current saved format.
		 * @return array
		 */

		private static function format_choices(
			array $formats,
			callable $callback,
			string $current_value,
		): array {
			$choices = array_map(
				fn($format) => [
					'value' => $format,
					'label' => $format . ' - ' . call_user_func($callback, $format),
				],
				$formats,
			);

			return self::with_current_choice($choices, $current_value);
		}

		/**
		 * Adds the currently saved value to finite choices when it is custom.
		 *
		 * @param array $choices Current choices.
		 * @param mixed $value Saved value.
		 * @param string $label Optional choice label.
		 * @return array
		 */

		private static function with_current_choice(
			array $choices,
			$value,
			string $label = '',
		): array {
			$value = (string) $value;

			if ($value === '') {
				return $choices;
			}

			foreach ($choices as $choice) {
				if ((string) ($choice['value'] ?? '') === $value) {
					return $choices;
				}
			}

			$choices[] = [
				'value' => $value,
				/* translators: %s: Custom option value. */

				'label' =>
					$label ?:
					sprintf(
						/* translators: %s: contextual value. */
						__('Custom: %s', 'wphave'),
						$value,
					),
			];

			return $choices;
		}

		/**
		 * Returns week start choices.
		 *
		 * @return array
		 */

		public static function week_start_choices(): array {
			$days = [
				__('Sunday', 'wphave'),
				__('Monday', 'wphave'),
				__('Tuesday', 'wphave'),
				__('Wednesday', 'wphave'),
				__('Thursday', 'wphave'),
				__('Friday', 'wphave'),
				__('Saturday', 'wphave'),
			];

			return array_map(
				fn($label, $index) => [
					'value' => (string) $index,
					'label' => $label,
				],
				$days,
				array_keys($days),
			);
		}

		/**
		 * Returns permalink preset choices.
		 *
		 * @return array
		 */

		public static function permalink_choices(): array {
			$choices = [
				[
					'value' => '',
					'label' => __('Plain', 'wphave'),
				],
				[
					'value' => '/%year%/%monthnum%/%day%/%postname%/',
					'label' => __('Day and name', 'wphave'),
				],
				[
					'value' => '/%year%/%monthnum%/%postname%/',
					'label' => __('Month and name', 'wphave'),
				],
				[
					'value' => '/archives/%post_id%',
					'label' => __('Numeric', 'wphave'),
				],
				[
					'value' => '/%postname%/',
					'label' => __('Post name', 'wphave'),
					'badge' => __('Recommended', 'wphave'),
				],
			];

			$choices = self::with_current_choice($choices, get_option('permalink_structure'));

			return array_map(
				fn($choice) => [...$choice, 'caption' => self::permalink_example($choice['value'])],
				$choices,
			);
		}

		/**
		 * Builds a readable sample URL for one permalink structure.
		 *
		 * @param string $structure Permalink structure.
		 * @return string
		 */

		private static function permalink_example(string $structure): string {
			if ($structure === '') {
				return home_url('/?p=123');
			}

			$path = strtr($structure, [
				'%year%' => '2026',
				'%monthnum%' => '05',
				'%day%' => '18',
				'%hour%' => '12',
				'%minute%' => '30',
				'%second%' => '00',
				'%post_id%' => '123',
				'%postname%' => 'sample-post',
				'%category%' => 'uncategorized',
				'%author%' => 'admin',
			]);
			$path = preg_replace('/%[^%]+%/', 'sample', $path);

			return home_url($path);
		}

		/**
		 * Returns front page mode choices.
		 *
		 * @return array
		 */

		public static function show_on_front_choices(): array {
			return [
				[
					'icon' => 'pages',
					'value' => 'page',
					'label' => __('Static page', 'wphave'),
					'description' => __('Use a selected page as the homepage.', 'wphave'),
				],
				[
					'icon' => 'blocks',
					'value' => 'posts',
					'disabled' => true,
					'label' => __('Latest posts', 'wphave'),
					'description' => __('Show your most recent posts on the homepage.', 'wphave'),
				],
			];
		}

		/**
		 * Returns public page choices.
		 *
		 * @return array
		 */

		public static function page_choices(): array {
			$pages = get_pages([
				'post_status' => ['publish', 'private'],
				'sort_column' => 'post_title',
			]);
			$choices = [
				[
					'value' => '0',
					'label' => __('Select page', 'wphave'),
				],
			];

			foreach ($pages as $page) {
				$choices[] = [
					'value' => (string) $page->ID,
					/* translators: %d: Page ID. */

					'label' =>
						$page->post_title ?:
						sprintf(
							/* translators: %d: contextual value. */
							__('#%d', 'wphave'),
							$page->ID,
						),
				];
			}

			return $choices;
		}

		/**
		 * Returns editable role choices.
		 *
		 * @return array
		 */

		public static function role_choices(): array {
			if (!function_exists('get_editable_roles')) {
				require_once ABSPATH . 'wp-admin/includes/user.php';
			}

			$selected = get_option('default_role');
			$excluded_roles = (array) apply_filters('default_role_dropdown_excluded_roles', [
				'administrator',
				'editor',
				'wphave_client',
				'wphave_client_pro',
			]);
			$roles = array_reverse(get_editable_roles());
			$choices = [];

			foreach ($roles as $role => $details) {
				if (in_array($role, $excluded_roles, true) && $role !== $selected) {
					continue;
				}

				$choices[] = [
					'value' => $role,
					'label' => translate_user_role($details['name']),
				];
			}

			return $choices;
		}

		/**
		 * Returns open/closed choices.
		 *
		 * @return array
		 */

		public static function open_closed_choices(): array {
			return [
				[
					'value' => 'open',
					'label' => __('Open', 'wphave'),
				],
				[
					'value' => 'closed',
					'label' => __('Closed', 'wphave'),
				],
			];
		}
	}
endif;

add_action('rest_api_init', ['WPHAVE_WP_Options', 'register_routes']);
