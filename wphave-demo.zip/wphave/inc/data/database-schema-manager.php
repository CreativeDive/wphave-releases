<?php

if (!defined('ABSPATH')) {
	exit();
}

require_once wphave_dir() . 'inc/features/security/boundaries/index.php';
require_once wphave_dir() . 'inc/background-jobs/lock.php';

if (!class_exists('WPHAVE_Database_Schema_Manager')):
	/**
	 * Central registry and update runner for WPHAVE custom database tables.
	 *
	 * The manager separates schema versions from feature versions and keeps
	 * potentially expensive database changes out of normal frontend requests.
	 * Modules register their schema installer here; the manager exposes status
	 * and controlled update execution for activation hooks, admin flows and REST.
	 */

	final class WPHAVE_Database_Schema_Manager {
		const OPTION_STATUS = 'wphave_database_schema_status';
		const OPTION_LAST_UPDATE_AT = 'wphave_database_schema_last_update_at';
		const OPTION_LAST_ERROR = 'wphave_database_schema_last_error';
		const OPTION_PLUGIN_VERSION = 'wphave_database_schema_plugin_version';
		const LOCK_OPTION = 'wphave_database_schema_update_lock';
		// Large ALTER TABLE operations can exceed normal request timeouts. The lease
		// is deliberately generous and refreshed between schemas so another request
		// cannot start a concurrent DDL batch while MySQL is still working.
		const LOCK_TTL = 2 * HOUR_IN_SECONDS;

		private static array $schemas = [];
		private static string $lock_token = '';

		/**
		 * Register REST routes for schema status and manual updates.
		 *
		 * @return void
		 */

		public static function init(): void {
			if (defined('WPHAVE_FILE_PATH')) {
				register_activation_hook(WPHAVE_FILE_PATH, [__CLASS__, 'activate']);
			}

			add_action('rest_api_init', [__CLASS__, 'register_routes']);
			add_action('wp_initialize_site', [__CLASS__, 'initialize_site'], 20, 1);
			add_filter('wpmu_drop_tables', [__CLASS__, 'site_drop_tables'], 10, 2);
		}

		// MIGRATION INVARIANT: Existing installations change schemas only through
		// the explicit update endpoint. Page loads never execute or retry DDL.
		// Activation and initial site provisioning remain explicit lifecycle actions.

		/**
		 * Run all registered installers during plugin activation.
		 *
		 * WordPress loads the plugin file before executing activation callbacks,
		 * so feature modules have registered their schemas by the time this runs.
		 *
		 * @return void
		 */

		public static function activate(bool $network_wide = false): void {
			// MULTISITE/LIMIT INVARIANT: Network activation may cover an
			// arbitrary number of sites; only a durable, bounded job is started here.
			if ($network_wide && is_multisite()) {
				$result = WPHAVE_Database_Schema_Network::start('network-activation');
				if (is_wp_error($result)) {
					self::record_error(
						['id' => 'network-provisioning'],
						$result->get_error_message(),
					);
				}
				return;
			}
			self::update_site(get_current_blog_id(), 'activation');
		}

		/** Initialize only sites in the network where WPHAVE is network active. */
		public static function initialize_site(WP_Site $site): void {
			$active = (array) get_network_option(
				(int) $site->site_id,
				'active_sitewide_plugins',
				[],
			);
			if (isset($active[plugin_basename(WPHAVE_FILE_PATH)])) {
				self::update_site((int) $site->blog_id, 'new-site');
			}
		}

		/**
		 * Shared site lifecycle entry point. Callers own authorization or lifecycle authority.
		 *
		 * CONTEXT INVARIANT: Registry callbacks resolve table names at execution time.
		 * A switched site is always restored, including exceptions and failed validators.
		 * The returned failure must be retained by network orchestration, never discarded.
		 */
		public static function update_site(int $site_id, string $context) {
			if ($site_id < 1 || (is_multisite() && !get_site($site_id))) {
				return new WP_Error(
					'wphave_schema_site_missing',
					self::text('The target site no longer exists.'),
				);
			}
			$switched = get_current_blog_id() !== $site_id;
			if ($switched) {
				switch_to_blog($site_id);
			}
			try {
				try {
					$result = self::update_all(['context' => $context]);
				} catch (Throwable $error) {
					self::record_error(['id' => 'lifecycle'], $error->getMessage());
					$result = new WP_Error(
						'wphave_schema_lifecycle_exception',
						self::text('Site database provisioning failed unexpectedly.'),
					);
				}
				if (!is_wp_error($result) && defined('WPHAVE_VERSION')) {
					update_option(self::OPTION_PLUGIN_VERSION, WPHAVE_VERSION, false);
				}
				update_option(
					'wphave_database_schema_provisioning',
					[
						'context' => $context,
						'state' => is_wp_error($result) ? 'failed' : 'complete',
						'errorCode' => is_wp_error($result) ? $result->get_error_code() : '',
						'updatedAt' => gmdate('c'),
					],
					false,
				);
				return $result;
			} finally {
				if ($switched) {
					restore_current_blog();
				}
			}
		}

		/**
		 * Registers one schema definition.
		 *
		 * Required args:
		 * - id
		 * - label
		 * - version
		 * - option
		 * - callback
		 *
		 * @param array $args Schema registration args.
		 * @return void
		 */

		public static function register(array $args): void {
			$id = sanitize_key($args['id'] ?? '');

			if (
				!$id ||
				empty($args['version']) ||
				empty($args['option']) ||
				empty($args['callback']) ||
				!is_callable($args['callback'])
			) {
				return;
			}

			// STORAGE SCOPE INVARIANT: This registry owns site-prefixed tables and
			// site-local version options. Reject network tables until an explicit
			// network storage contract exists; never guess a prefix from a caller.
			if (($args['scope'] ?? 'site') !== 'site') {
				throw new InvalidArgumentException('Only site-scoped schemas are supported.');
			}
			if (isset($args['enabled']) && !is_callable($args['enabled'])) {
				throw new InvalidArgumentException('Schema enabled must be a callable.');
			}
			self::$schemas[$id] = [
				'scope' => 'site',
				'enabled' => $args['enabled'] ?? null,
				'id' => $id,
				'label' => sanitize_text_field($args['label'] ?? $id),
				'version' => (string) $args['version'],
				'option' => sanitize_key($args['option']),
				'callback' => $args['callback'],
				'validator' =>
					!empty($args['validator']) && is_callable($args['validator'])
						? $args['validator']
						: null,
				'tables' => array_values(
					array_filter(array_map('sanitize_key', (array) ($args['tables'] ?? []))),
				),
			];
		}

		/**
		 * Return registered schemas.
		 *
		 * @return array Registered schema definitions.
		 */

		public static function schemas(): array {
			require_once __DIR__ . '/database-schema-runtime.php';
			WPHAVE_Database_Schema_Runtime::load();
			return array_filter(self::$schemas, [__CLASS__, 'schema_enabled']);
		}

		/** Permanent Core deletion only; archive/deactivate never enters this hook. */
		public static function site_drop_tables(array $tables, int $site_id): array {
			global $wpdb;
			$site = is_multisite() ? get_site($site_id) : null;
			// DELETION INVARIANT: Never infer ownership from a wildcard or current
			// blog context. Main-site and shared network tables are not ours to drop.
			if (!$site || is_main_site($site_id, (int) $site->site_id)) {
				return $tables;
			}
			switch_to_blog($site_id);
			try {
				require_once __DIR__ . '/database-schema-runtime.php';
				WPHAVE_Database_Schema_Runtime::load();
				// Disabled optional modules may still own historical tables. Their
				// registrations, not their current feature flags, define ownership.
				require_once wphave_dir() . 'inc/admin/features/activity/storage/log.php';
				require_once wphave_dir() . 'inc/admin/user/presence/functions.php';
				$prefix = $wpdb->get_blog_prefix($site_id);
				foreach (self::$schemas as $schema) {
					foreach ($schema['tables'] as $suffix) {
						if (
							$schema['scope'] === 'site' &&
							preg_match('/^wphave_[a-z0-9_]+$/D', $suffix)
						) {
							$tables[] = $prefix . $suffix;
						}
					}
				}
				return array_values(array_unique($tables));
			} finally {
				restore_current_blog();
			}
		}

		private static function schema_enabled(array $schema): bool {
			return !$schema['enabled'] ||
				(is_callable($schema['enabled']) && true === call_user_func($schema['enabled']));
		}

		/**
		 * Return all schema definitions that need an update.
		 *
		 * @return array Pending schema definitions.
		 */

		public static function pending_schemas(): array {
			return array_values(array_filter(self::schemas(), [__CLASS__, 'schema_needs_upgrade']));
		}

		/**
		 * Return schemas created by a newer WPHAVE runtime.
		 *
		 * DOWNGRADE INVARIANT: A newer durable version is never an upgrade target for
		 * older code. Installers and validators describe only the current runtime's
		 * forward contract; executing them during a rollback could let old code write
		 * to data it does not understand and could falsely lower the durable marker.
		 *
		 * @return array Newer, runtime-incompatible schema definitions.
		 */

		public static function incompatible_schemas(): array {
			return array_values(array_filter(self::schemas(), [__CLASS__, 'schema_is_newer']));
		}

		/** Determine whether one registered feature may safely use its tables. */

		public static function runtime_compatible(string $id): bool {
			return isset(self::$schemas[$id]) &&
				self::schema_enabled(self::$schemas[$id]) &&
				!self::schema_is_newer(self::$schemas[$id]);
		}

		/**
		 * Check whether any registered schema needs an update.
		 *
		 * @return bool True when at least one schema is pending.
		 */

		public static function update_required(): bool {
			return self::pending_schemas() !== [];
		}

		/**
		 * Run updates for every pending schema.
		 *
		 * @param array $args Update args.
		 * @return array|WP_Error Update result.
		 */

		public static function update_all(array $args = []) {
			// Pass the complete registry so run_updates() can reject a mixed batch
			// before invoking even one installer when any durable schema is newer.
			return self::run_updates(array_values(self::schemas()), $args);
		}

		/**
		 * Run one registered schema update by id.
		 *
		 * @param string $id Schema id.
		 * @param array $args Update args.
		 * @return array|WP_Error Update result.
		 */

		public static function update_schema(string $id, array $args = []) {
			$schemas = self::schemas();
			if (empty($schemas[$id])) {
				return new WP_Error(
					'wphave_schema_not_registered',
					self::text('The database schema is not registered.'),
					['status' => 404],
				);
			}

			return self::run_updates([$schemas[$id]], $args);
		}

		/**
		 * Build a compact status payload for REST, admin notices and support tools.
		 *
		 * @return array Schema status.
		 */

		public static function status(): array {
			$items = [];
			$pending = [];

			foreach (self::schemas() as $schema) {
				$current = (string) get_option($schema['option'], '');
				$missing_tables = self::missing_tables($schema);
				$is_valid = $missing_tables === [] && self::schema_is_valid($schema);
				$is_newer = self::schema_is_newer($schema);
				$needs_update =
					!$is_newer &&
					(self::version_is_older($current, $schema['version']) || !$is_valid);

				$item = [
					'id' => $schema['id'],
					'scope' => $schema['scope'],
					'label' => self::text($schema['label']),
					'currentVersion' => $current,
					'targetVersion' => $schema['version'],
					'needsUpdate' => $needs_update,
					'isNewerThanRuntime' => $is_newer,
					'isRuntimeCompatible' => !$is_newer,
					'tables' => $schema['tables'],
					'missingTables' => $missing_tables,
					'isValid' => $is_valid,
				];

				$items[] = $item;

				if ($needs_update) {
					$pending[] = $item;
				}
			}

			return [
				'updateRequired' => $pending !== [],
				'downgradeBlocked' => self::incompatible_schemas() !== [],
				'isLocked' => self::is_locked(),
				'lastUpdateAt' => (string) get_option(self::OPTION_LAST_UPDATE_AT, ''),
				'lastError' => self::last_error(),
				'provisioning' => get_option('wphave_database_schema_provisioning', null),
				'items' => $items,
				'pending' => $pending,
			];
		}

		/**
		 * Persist the current status snapshot.
		 *
		 * @return void
		 */

		public static function refresh_status(): void {
			$status = self::status();

			if (get_option(self::OPTION_STATUS) === $status) {
				return;
			}

			update_option(self::OPTION_STATUS, $status, false);
		}

		/**
		 * Register REST routes for schema status and manual update execution.
		 *
		 * @return void
		 */

		public static function register_routes(): void {
			register_rest_route('wphave/v1', '/database/schema', [
				'methods' => 'GET',
				'callback' => [__CLASS__, 'rest_status'],
				'permission_callback' => [__CLASS__, 'rest_can_view'],
			]);

			register_rest_route('wphave/v1', '/database/schema/update', [
				'methods' => 'POST',
				'callback' => [__CLASS__, 'rest_update'],
				'permission_callback' => [__CLASS__, 'rest_can_manage'],
			]);
		}

		/**
		 * Permission callback for reading database schema status.
		 *
		 * @return bool True when the current user may view Site Health.
		 */

		public static function rest_can_view(): bool {
			return is_user_logged_in() &&
				(current_user_can('wphave_view_system_status') ||
					current_user_can('manage_options'));
		}

		/**
		 * Permission callback for database schema endpoints.
		 *
		 * @return bool True when the current user may manage schema updates.
		 */

		public static function rest_can_manage(): bool {
			return is_user_logged_in() && current_user_can('manage_options');
		}

		/**
		 * REST callback for current schema status.
		 *
		 * @return array Schema status.
		 */

		public static function rest_status() {
			// AUTHORIZATION INVARIANT: Schema versions, table readiness and failure
			// state are operational diagnostics. Direct or composed dispatch repeats
			// the Site Health policy instead of trusting REST route dispatch.
			if (!self::rest_can_view()) {
				return new WP_Error(
					'wphave_schema_status_forbidden',
					self::text('You are not allowed to view database schema status.'),
					['status' => 403],
				);
			}

			return self::status();
		}

		/**
		 * REST callback for manually running pending schema updates.
		 *
		 * @return array|WP_Error Update result.
		 */

		public static function rest_update() {
			// AUTHORIZATION INVARIANT: A route permission callback is only an early
			// gate. Administrator authority is revalidated immediately before output
			// buffering and before any installer, schema marker, or table mutation.
			if (!self::rest_can_manage()) {
				return new WP_Error(
					'wphave_schema_update_forbidden',
					self::text('You are not allowed to update database schemas.'),
					['status' => 403],
				);
			}

			$buffer_level = ob_get_level();
			ob_start();

			try {
				$result = self::update_site(get_current_blog_id(), 'rest');

				if (is_wp_error($result)) {
					return $result;
				}

				$result['status'] = self::status();

				return $result;
			} finally {
				$output = '';

				while (ob_get_level() > $buffer_level) {
					$output .= (string) ob_get_clean();
				}

				if ($output !== '') {
					self::record_rest_output($output);
				}
			}
		}

		/**
		 * Check one schema definition against its stored version.
		 *
		 * @param array $schema Schema definition.
		 * @return bool True when an update is required.
		 */

		private static function schema_needs_upgrade(array $schema): bool {
			$current = (string) get_option($schema['option'], '');

			return !self::schema_is_newer($schema) &&
				(self::version_is_older($current, $schema['version']) ||
					self::missing_tables($schema) !== [] ||
					!self::schema_is_valid($schema));
		}

		/** Return whether the durable schema belongs to a newer plugin runtime. */

		private static function schema_is_newer(array $schema): bool {
			$current = (string) get_option($schema['option'], '');

			return '' !== $current && version_compare($current, $schema['version'], '>');
		}

		/** Empty versions represent fresh installations and therefore require setup. */

		private static function version_is_older(string $current, string $target): bool {
			return '' === $current || version_compare($current, $target, '<');
		}

		/**
		 * Run a schema-specific validator when one is registered.
		 *
		 * @param array $schema Schema definition.
		 * @return bool True when the schema is valid.
		 */

		private static function schema_is_valid(array $schema): bool {
			if (empty($schema['validator']) || !is_callable($schema['validator'])) {
				return true;
			}

			try {
				$result = call_user_func($schema['validator']);

				return true === $result;
			} catch (Throwable $error) {
				return false;
			}
		}

		/**
		 * Translate text only after WordPress has reached init.
		 *
		 * Schema registrations are loaded while the plugin file is included. Calling
		 * translation functions at that point triggers WordPress 6.7+ just-in-time
		 * textdomain notices, so labels and activation errors stay raw until init.
		 *
		 * @param string $text Text to translate.
		 * @return string Translated text when safe, raw text otherwise.
		 */

		private static function text(string $text): string {
			return did_action('init') ? translate($text, 'wphave') : $text;
		}

		/**
		 * Return registered tables that do not exist.
		 *
		 * @param array $schema Schema definition.
		 * @return array Missing unprefixed table names.
		 */

		private static function missing_tables(array $schema, bool $force_refresh = false): array {
			global $wpdb;

			$missing = [];

			foreach ($schema['tables'] as $table) {
				$full_table = $wpdb->prefix . $table;

				if (!WPHAVE_Database_Metadata::table_exists($full_table, $force_refresh)) {
					$missing[] = $table;
				}
			}

			return $missing;
		}

		/**
		 * Run schema callbacks with lock protection and status capture.
		 *
		 * @param array $schemas Schema definitions.
		 * @param array $args Update args.
		 * @return array|WP_Error Update result.
		 */

		private static function run_updates(array $schemas, array $args = []) {
			$incompatible = array_values(array_filter($schemas, [__CLASS__, 'schema_is_newer']));
			if ($incompatible) {
				return new WP_Error(
					'wphave_schema_newer_than_runtime',
					self::text(
						'The database was created by a newer WPHAVE version. Restore that version before changing this data.',
					),
					[
						'status' => 409,
						'schemas' => array_map(
							static fn(array $schema): string => $schema['id'],
							$incompatible,
						),
					],
				);
			}

			$schemas = array_values(array_filter($schemas, [__CLASS__, 'schema_needs_upgrade']));

			if (!$schemas) {
				self::refresh_status();

				return [
					'success' => true,
					'updated' => [],
					'status' => self::status(),
				];
			}

			if (self::$lock_token || !self::acquire_lock()) {
				return new WP_Error(
					'wphave_schema_update_locked',
					self::text('A database update is already running.'),
					['status' => 409],
				);
			}

			$updated = [];
			$validated_schemas = [];

			try {
				foreach ($schemas as $schema) {
					if (!self::refresh_lock()) {
						return new WP_Error(
							'wphave_schema_update_lock_lost',
							self::text('The database schema update lock was lost.'),
							['status' => 409],
						);
					}
					try {
						$result = call_user_func($schema['callback']);
					} catch (Throwable $error) {
						self::record_error($schema, $error->getMessage());
						return new WP_Error(
							'wphave_schema_update_exception',
							self::text('The database schema update failed unexpectedly.'),
							['status' => 500],
						);
					}

					if (is_wp_error($result)) {
						self::record_error($schema, $result->get_error_message());
						return $result;
					}

					if ($result === false) {
						self::record_error(
							$schema,
							self::text('The database schema update did not complete.'),
						);
						return new WP_Error(
							'wphave_schema_update_failed',
							self::text('The database schema update did not complete.'),
							['status' => 500],
						);
					}

					WPHAVE_Database_Metadata::invalidate();

					$missing_tables = self::missing_tables($schema, true);

					if ($missing_tables) {
						self::record_error(
							$schema,
							self::text(
								'The database schema update did not create all required tables.',
							),
						);
						return new WP_Error(
							'wphave_schema_tables_missing',
							self::text(
								'The database schema update did not create all required tables.',
							),
							['status' => 500],
						);
					}

					if (!self::schema_is_valid($schema)) {
						self::record_error(
							$schema,
							self::text('The database schema update did not pass validation.'),
						);
						return new WP_Error(
							'wphave_schema_validation_failed',
							self::text('The database schema update did not pass validation.'),
							['status' => 500],
						);
					}
					// SECURITY INVARIANT: A schema version becomes durable only after its
					// required tables and semantic validator pass while this request still
					// owns the migration lease.
					if (!self::refresh_lock()) {
						return new WP_Error(
							'wphave_schema_update_lock_lost',
							self::text('The database schema update lock was lost.'),
							['status' => 409],
						);
					}

					$validated_schemas[] = $schema;
					$updated[] = $schema['id'];
				}

				// DATA INTEGRITY INVARIANT: Commit schema version markers only after every pending schema has
				// completed and validated. Database DDL cannot be reliably rolled
				// back across hosts, but delayed version writes prevent partially
				// successful batches from being marked clean after a later failure.
				foreach ($validated_schemas as $schema) {
					update_option($schema['option'], $schema['version'], false);
				}

				$status = self::status();

				if (!empty($status['updateRequired'])) {
					$pending = (array) ($status['pending'] ?? []);
					$first_pending = is_array($pending[0] ?? null) ? $pending[0] : [];
					$pending_schema = self::$schemas[$first_pending['id'] ?? ''] ?? [
						'id' => 'unknown',
					];
					self::record_error(
						$pending_schema,
						self::text(
							'The database schema still requires an update after the migration completed.',
						),
					);

					return new WP_Error(
						'wphave_schema_postcondition_failed',
						self::text(
							'The database update finished, but at least one schema is still invalid.',
						),
						[
							'status' => 500,
							'databaseSchema' => $status,
						],
					);
				}

				delete_option(self::OPTION_LAST_ERROR);
				update_option(self::OPTION_LAST_UPDATE_AT, current_time('mysql'), false);
				self::refresh_status();

				return [
					'success' => true,
					'updated' => $updated,
					'status' => self::status(),
				];
			} finally {
				self::release_lock();
				self::refresh_status();
			}
		}

		/**
		 * Acquire a short-lived update lock.
		 *
		 * @return bool True when the lock was acquired.
		 */

		private static function acquire_lock(): bool {
			$token = WPHAVE_Background_Job_Lock::acquire(self::LOCK_OPTION, self::LOCK_TTL);

			if (!$token) {
				self::$lock_token = '';
				return false;
			}

			self::$lock_token = $token;

			return true;
		}

		/**
		 * Release the update lock.
		 *
		 * @return void
		 */

		private static function release_lock(): void {
			// SECURITY INVARIANT: A timed-out migration cannot release the lease of a
			// successor; cleanup authority remains bound to this request's token.
			if (self::$lock_token) {
				WPHAVE_Background_Job_Lock::release(self::LOCK_OPTION, self::$lock_token);
			}

			self::$lock_token = '';
		}

		/** Refresh only the lease owned by this request. */
		private static function refresh_lock(): bool {
			return self::$lock_token &&
				WPHAVE_Background_Job_Lock::refresh(self::LOCK_OPTION, self::$lock_token);
		}

		/**
		 * Check whether a non-expired lock exists.
		 *
		 * @return bool True when updates are locked.
		 */

		private static function is_locked(): bool {
			$lock = get_option(self::LOCK_OPTION);
			if (!is_array($lock)) {
				return false;
			}

			if (isset($lock['expires'])) {
				return absint($lock['expires']) >= time();
			}

			$heartbeat = absint($lock['heartbeat'] ?? ($lock['created'] ?? 0));

			return $heartbeat > 0 && $heartbeat + self::LOCK_TTL >= time();
		}

		/**
		 * Store the last schema update error.
		 *
		 * @param array $schema Schema definition.
		 * @param string $message Error message.
		 * @return void
		 */

		private static function record_error(array $schema, string $message): void {
			update_option(
				self::OPTION_LAST_ERROR,
				[
					'schema' => $schema['id'],
					'message' => WPHAVE_Security_Redactor::error_text($message),
					'time' => current_time('mysql'),
				],
				false,
			);

			self::refresh_status();
			do_action('wphave/database/schema_error', (string) $schema['id']);
		}

		/**
		 * Return the last schema update error payload.
		 *
		 * @return array|null Last error payload.
		 */

		private static function last_error(): ?array {
			$error = get_option(self::OPTION_LAST_ERROR);

			if (!is_array($error)) {
				return null;
			}

			$error['schema'] = sanitize_key((string) ($error['schema'] ?? ''));
			$error['message'] = WPHAVE_Security_Redactor::error_text($error['message'] ?? '');

			return $error;
		}

		/**
		 * Log unexpected output emitted during REST schema updates.
		 *
		 * Database installers must return structured values only. In debug mode,
		 * dbDelta / wpdb can still print warnings, which would corrupt JSON REST
		 * responses. The output is discarded from the response and logged here.
		 *
		 * @param string $output Captured output.
		 * @return void
		 */

		private static function record_rest_output(string $output): void {
			if (defined('WP_DEBUG') && WP_DEBUG) {
				error_log(
					'WPHAVE database schema REST update output was suppressed: ' .
						WPHAVE_Security_Redactor::error_text($output, 1000),
				);
			}
		}
	}
endif;

require_once __DIR__ . '/database-schema-network.php';

WPHAVE_Database_Schema_Manager::init();
WPHAVE_Database_Schema_Network::init();
