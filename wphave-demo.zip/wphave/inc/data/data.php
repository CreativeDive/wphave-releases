<?php

include_once __DIR__ . '/repository.php';
include_once __DIR__ . '/options/sensitive-values.php';
include_once __DIR__ . '/resources.php';
// Resource callbacks are data-layer contracts and must be available even when
// the optional Backup runtime is gated or omitted for the current request.
include_once wphave_dir() . 'inc/admin/features/backup/support/access.php';
include_once wphave_dir() . 'inc/admin/features/backup/support/config.php';
include_once __DIR__ . '/rest-controller.php';

// Register the resource-backed data API after its storage services are loaded.

add_action('rest_api_init', ['WPHAVE_Data_REST_Controller', 'register_routes']);

/**
 * Returns a full data resource or one nested value.
 *
 * @param string $resource Resource id.
 * @param string $path Optional dot- or pipe-separated path.
 * @param mixed $default Fallback value when the path is missing.
 * @return mixed
 */

if (!function_exists('wphave_data_get')):
	function wphave_data_get($resource, $path = '', $default = null) {
		$data = WPHAVE_Data_Resources::get((string) $resource, false);

		if ($path === '' || $path === null) {
			return $data;
		}

		return WPHAVE_Data_Resources::get_path_value($data, (string) $path, $default);
	}
endif;

/**
 * Replaces a full resource or patches one nested path.
 *
 * @param string $resource Resource id.
 * @param array|string $data_or_path Full payload or nested path.
 * @param mixed $value Path value for patch writes.
 * @return array|WP_Error
 */

if (!function_exists('wphave_data_set')):
	function wphave_data_set($resource, $data_or_path, $value = null) {
		if (func_num_args() === 2) {
			if (!is_array($data_or_path)) {
				return new WP_Error(
					'wphave_invalid_resource_payload',
					__('Resource payload must be an array.', 'wphave'),
					['status' => 400],
				);
			}

			return WPHAVE_Data_Resources::save((string) $resource, $data_or_path);
		}

		return WPHAVE_Data_Resources::patch((string) $resource, (string) $data_or_path, $value);
	}
endif;

/**
 * Build the shared data payload preloaded for WPHAVE React applications.
 *
 * Sensitive site settings use the same masking rules as REST resources so
 * inline preload data cannot expose values hidden by the data layer.
 *
 * @return array Preloaded application data grouped by consumer key.
 */

if (!function_exists('wphave_preloaded_data')):
	function wphave_preloaded_data() {
		$output = [];

		$output['user-roles'] = wphave_user_roles();
		$output['user-role-descriptions'] = [];
		foreach (array_keys($output['user-roles']) as $role_key) {
			$output['user-role-descriptions'][$role_key] = wphave_get_role_description($role_key);
		}
		$output['access'] = WPHAVE_Access_Manager::get_current_user_access_payload();
		$output['user-preferences'] = WPHAVE_User_Preferences_Manager::get_preferences();
		$output['user-preferences-revision'] = WPHAVE_User_Preferences_Manager::get_revision();
		$can_read_license_settings = WPHAVE_Data_Resources::current_user_can_read(
			'license_settings',
		);
		$output['data-revisions'] = [];
		foreach (
			['site_settings', 'license_settings', 'site_globals', 'template_parts']
			as $resource
		) {
			if ($resource === 'license_settings' && !$can_read_license_settings) {
				continue;
			}
			$output['data-revisions'][$resource] = WPHAVE_Data_Resources::get_revision($resource);
		}

		$output['blockStyles'] = WPHAVE_Block_Styles::get_styles();
		$output['globalCssClasses'] = wphave_get_css_classes();
		$output['blockDefaults'] = wphave_data_get('block_defaults', '', []);
		$output['ai-status'] = [
			'isDisabled' => (bool) wphave_data_get('ai_settings', 'isDisabled', false),
		];
		$output['privacy-status'] = [
			'consentBannerEnabled' => (bool) wphave_data_get(
				'privacy_settings',
				'consent.banner.isEnabled',
				false,
			),
		];
		$output['license-status'] = class_exists('WPHAVE_Lifecycle')
			? WPHAVE_Lifecycle::license_status_projection()
			: [
				'isPro' => false,
				'isAuthorized' => false,
				'isBeta' => false,
				'licenseClaims' => [],
			];

		$output['settings'] = wphave_data_get('site_globals');
		$output['site-globals'] = wphave_data_get('site_globals');
		$output['template-parts'] = wphave_data_get('template_parts');
		$output['settings-defaults'] = WPHAVE_Global_Data::get_defaults();
		$output['layout-post-types'] = WPHAVE_Global_Styles::layout_post_types();
		$output[
			'settings-typography-elements'
		] = WPHAVE_Global_Styles::individual_typography_elements();
		// Preloaded admin data is consumed by JavaScript, so it must follow the
		// same sensitive-value masking rules as the REST data resources.
		$output['site-settings'] = WPHAVE_Data_Resources::get_for_rest('site_settings');
		/*
		 * SECURITY/CAPABILITY INVARIANT: Inline preload data is an authorization
		 * boundary just like REST. Masking secrets is insufficient because plan,
		 * expiration and installation metadata are themselves administrator-only.
		 */
		$output['license-settings'] = $can_read_license_settings
			? WPHAVE_Data_Resources::get_for_rest('license_settings')
			: [];
		$output['database-schema'] = class_exists('WPHAVE_Database_Schema_Manager')
			? WPHAVE_Database_Schema_Manager::status()
			: [];
		$output['app-notice-status'] = function_exists('wphave_app_notice_status')
			? wphave_app_notice_status()
			: [];

		$output['palette-colors'] = wphave_color_collection();
		$output['palette-gradients'] = wphave_gradient_collection();
		$output['palette-gradients-multi'] = wphave_multi_gradient_collection();

		$output['color-schemes'] = WPHAVE_Global_Data::color_schemes();
		$output['social-colors'] = WPHAVE_Social_Profiles::networks();
		$output['social-sharing'] = WPHAVE_Social_Sharing::services();

		$output['font-registry'] = WPHAVE_Fonts::registry();
		$output['font-pairs'] = wphave_preset_web_fonts(false, ['output' => 'all']);

		$output['link-styles'] = wphave_link_style(['output' => 'all', 'outputType' => 'catalog']);
		$output['button-style'] = wphave_button_style([
			'output' => 'all',
			'selector' => '.wphave-button-group.preset-button-styles > button .after',
		]);

		$output['duotones'] = wphave_duotones(['output' => 'all']);
		$output['divider'] = wphave_svg_divider(['output' => 'catalog']);
		$output['svg-underline'] = wphave_svg_underline(['output' => 'all']);
		$output['overlay'] = wphave_overlay(['output' => 'all']);
		$output['lines'] = wphave_svg_line(['output' => 'all']);
		$output['decorations'] = wphave_svg_decoratives(['output' => 'catalog']);
		$output['svgPattern'] = wphave_pattern(['output' => 'all']);
		$output['cssPattern'] = wphave_css_pattern(['output' => 'all']);
		$output['cssPatternLabels'] = wphave_css_pattern(['output' => 'labels']);
		$output['clipPaths'] = wphave_get_clip_path_shapes(['output' => 'all']);
		$output['photo-filter'] = wphave_photo_filter(['output' => 'all']);

		return $output;
	}
endif;

/**
 * Expose preloaded application data before the shared utility script.
 *
 * React consumers access the resulting wphaveApiFetch value through the
 * usePreloadedData() hook.
 *
 * @return void
 */

if (!function_exists('wphave_enqueue_block_editor_preload_assets')):
	function wphave_enqueue_block_editor_preload_assets() {
		static $preload_added = false;

		if ($preload_added) {
			return;
		}

		// `admin_enqueue_scripts` runs on every WordPress administration page.
		// Do not build the full shared payload unless its consumer is queued. The
		// block-editor action is also a valid consumer boundary because WPHAVE
		// editor modules may pull `wphave-utils` in only as a dependency.
		$is_block_editor_enqueue = did_action('enqueue_block_editor_assets') > 0;
		if (!$is_block_editor_enqueue && !wp_script_is('wphave-utils', 'enqueued')) {
			return;
		}

		$preload_added = wp_add_inline_script(
			'wphave-utils',
			sprintf('var wphaveApiFetch = %s;', wp_json_encode(wphave_preloaded_data())),
			'before',
		);
	}
endif;

add_action('admin_enqueue_scripts', 'wphave_enqueue_block_editor_preload_assets', 100);
add_action('enqueue_block_editor_assets', 'wphave_enqueue_block_editor_preload_assets', 100);
