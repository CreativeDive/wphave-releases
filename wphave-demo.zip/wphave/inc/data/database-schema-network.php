<?php

/** Resumable network orchestration; the schema manager remains the only DDL runner. */
if (!defined('ABSPATH')) {
	exit();
}

require_once wphave_dir() . 'inc/background-jobs/functions.php';

final class WPHAVE_Database_Schema_Network {
	const OPTION = 'wphave_database_schema_network_job';
	const LOCK = 'wphave_database_schema_network_lock';
	const HOOK = 'wphave_database_schema_network_continue';

	public static function init(): void {
		add_action(self::HOOK, [__CLASS__, 'tick'], 10, 1);
		add_action('rest_api_init', [__CLASS__, 'register_routes']);
		register_deactivation_hook(WPHAVE_FILE_PATH, [__CLASS__, 'deactivate']);
		if (defined('WP_CLI') && WP_CLI) {
			require_once __DIR__ . '/database-schema-cli.php';
		}
	}

	/** Network deactivation revokes executable authority on the coordinator site. */
	public static function deactivate(bool $network_wide = false): void {
		if (!$network_wide || !is_multisite()) {
			return;
		}
		self::in_coordinator(static function (): void {
			wp_unschedule_hook(self::HOOK);
			delete_option(self::OPTION);
			delete_option(self::LOCK);
		});
	}

	/** Coordinator state and its mutex live in the network's main site options. */
	private static function in_coordinator(callable $callback) {
		$site_id = (int) get_main_site_id(get_current_network_id());
		$switched = get_current_blog_id() !== $site_id;
		if ($switched) {
			switch_to_blog($site_id);
		}
		try {
			return $callback();
		} finally {
			if ($switched) {
				restore_current_blog();
			}
		}
	}

	/** A queued authorization must not silently authorize a later runtime's migrations. */
	private static function fingerprint(): string {
		$versions = [];
		foreach (WPHAVE_Database_Schema_Manager::schemas() as $id => $schema) {
			$versions[$id] = [$schema['version'], $schema['option'], $schema['tables']];
		}
		ksort($versions);
		return hash('sha256', wp_json_encode([WPHAVE_VERSION, $versions]));
	}

	public static function status(): array {
		if (!is_multisite()) {
			return ['state' => 'unavailable'];
		}
		return self::in_coordinator(static function (): array {
			return (array) get_option(self::OPTION, ['state' => 'idle']);
		});
	}

	/** Explicit start/restart only. No plugin-version or admin-page hook starts DDL. */
	public static function start(string $context = 'manual', bool $restart = false) {
		if (!is_multisite()) {
			return new WP_Error('wphave_schema_network_unavailable', 'Multisite is required.');
		}
		$active = (array) get_network_option(
			get_current_network_id(),
			'active_sitewide_plugins',
			[],
		);
		// CORE LIFECYCLE INVARIANT: activate_plugin fires the activation hook
		// before persisting active_sitewide_plugins. Only that native entrypoint
		// may enqueue early; every worker rechecks actual network activation.
		if (
			'network-activation' !== $context &&
			!isset($active[plugin_basename(WPHAVE_FILE_PATH)])
		) {
			return new WP_Error(
				'wphave_schema_network_inactive',
				'Network updates require WPHAVE to be network active.',
			);
		}
		return self::in_coordinator(static function () use ($context, $restart) {
			global $wpdb;
			$token = WPHAVE_Background_Job_Lock::acquire(
				self::LOCK,
				WPHAVE_Database_Schema_Manager::LOCK_TTL,
			);
			if (!$token) {
				return new WP_Error(
					'wphave_schema_network_locked',
					'A network schema worker is running.',
					['status' => 409],
				);
			}
			try {
				$job = self::status();
				if (!$restart && 'running' === ($job['state'] ?? '')) {
					self::schedule($job);
					return $job;
				}
				if (!empty($job['id'])) {
					wp_clear_scheduled_hook(self::HOOK, [$job['id']]);
				}
				$network_id = get_current_network_id();
				// CURSOR INVARIANT: Fixed upper bound + monotone IDs tolerate deleted
				// sites without OFFSET skips. Later sites use wp_initialize_site.
				$upper = (int) $wpdb->get_var(
					$wpdb->prepare(
						"SELECT MAX(blog_id) FROM {$wpdb->blogs} WHERE site_id = %d",
						$network_id,
					),
				);
				if ($wpdb->last_error) {
					return new WP_Error(
						'wphave_schema_network_inventory_failed',
						'The network site inventory could not be read.',
					);
				}
				$job = [
					'id' => wp_generate_uuid4(),
					'networkId' => $network_id,
					'fingerprint' => self::fingerprint(),
					'context' => $context,
					'state' => 'running',
					'cursor' => 0,
					'upper' => $upper,
					'processed' => 0,
					'failed' => 0,
					'skipped' => 0,
					'currentSiteId' => 0,
					'attempts' => 0,
					'lastError' => '',
					'updatedAt' => gmdate('c'),
				];
				self::save($job);
				self::schedule($job);
				return $job;
			} finally {
				WPHAVE_Background_Job_Lock::release(self::LOCK, $token);
			}
		});
	}

	private static function save(array $job): void {
		update_option(self::OPTION, $job, false);
		// DURABILITY INVARIANT: No DDL follows a failed progress write.
		if (get_option(self::OPTION) !== $job) {
			throw new RuntimeException('Network schema progress could not be saved.');
		}
	}

	private static function schedule(array &$job, int $delay = 60): void {
		if (
			!WPHAVE_Background_Job_Scheduler::ensure_continuation(self::HOOK, [$job['id']], $delay)
		) {
			$job['state'] = 'paused';
			$job['lastError'] =
				'Scheduling failed. Resume explicitly after checking WordPress Cron.';
			self::save($job);
		}
	}

	/** One site per wake-up bounds tenant work; a single SQL ALTER is not preemptible. */
	public static function tick(string $job_id = '') {
		if (!is_multisite()) {
			return ['state' => 'unavailable'];
		}
		return self::in_coordinator(static function () use ($job_id) {
			global $wpdb;
			$active = (array) get_network_option(
				get_current_network_id(),
				'active_sitewide_plugins',
				[],
			);
			if (!isset($active[plugin_basename(WPHAVE_FILE_PATH)])) {
				return new WP_Error(
					'wphave_schema_network_inactive',
					'WPHAVE is no longer network active.',
				);
			}
			$job = self::status();
			if ('running' !== ($job['state'] ?? '') || ($job_id && $job_id !== $job['id'])) {
				return $job;
			}
			$token = WPHAVE_Background_Job_Lock::acquire(
				self::LOCK,
				WPHAVE_Database_Schema_Manager::LOCK_TTL,
			);
			if (!$token) {
				// A non-owner may request a wake-up, never persist a stale snapshot.
				WPHAVE_Background_Job_Scheduler::ensure_continuation(self::HOOK, [$job['id']], 60);
				return self::status();
			}
			try {
				// Re-read under the lock; an old worker cannot overwrite a restarted job.
				$job = self::status();
				if ('running' !== ($job['state'] ?? '') || ($job_id && $job_id !== $job['id'])) {
					return $job;
				}
				if ($job['fingerprint'] !== self::fingerprint()) {
					$job['state'] = 'paused';
					$job['lastError'] =
						'Runtime or schema registry changed. Review and restart the update.';
					self::save($job);
					return $job;
				}
				$site_id = (int) $wpdb->get_var(
					$wpdb->prepare(
						"SELECT blog_id FROM {$wpdb->blogs} WHERE site_id = %d AND blog_id > %d AND blog_id <= %d ORDER BY blog_id ASC LIMIT 1",
						$job['networkId'],
						$job['cursor'],
						$job['upper'],
					),
				);
				// An inventory read failure must never become a false completion.
				if ($wpdb->last_error) {
					$job['state'] = 'paused';
					$job['lastError'] = 'Network site inventory could not be read.';
					self::save($job);
					return $job;
				}
				if (!$site_id) {
					$job['state'] = $job['failed'] ? 'completed_with_errors' : 'complete';
					$job['currentSiteId'] = 0;
					self::save($job);
					return $job;
				}
				// Repeated hard crashes must not cause an endless automatic DDL loop.
				$job['attempts'] = $job['currentSiteId'] === $site_id ? $job['attempts'] + 1 : 1;
				if ($job['attempts'] > 3) {
					$job['state'] = 'paused';
					$job['lastError'] =
						'Repeated interrupted site update. Inspect the current site before restarting.';
					self::save($job);
					return $job;
				}
				$job['currentSiteId'] = $site_id;
				self::save($job);
				// RECOVERY INVARIANT: Queue the watchdog before DDL. A fatal request
				// retains its cursor and is retried only under the existing durable job.
				self::schedule($job, 120);
				if ('running' !== $job['state']) {
					return $job;
				}
				$site = get_site($site_id);
				if (!$site || $site->deleted || $site->spam || $site->archived) {
					$job['skipped']++;
				} else {
					$result = WPHAVE_Database_Schema_Manager::update_site(
						$site_id,
						'network-update',
					);
					$job['processed']++;
					if (is_wp_error($result)) {
						$job['failed']++;
						$job['lastError'] = $result->get_error_code();
					}
				}
				// FENCING INVARIANT: A worker that lost ownership never advances state.
				if (!WPHAVE_Background_Job_Lock::refresh(self::LOCK, $token)) {
					return new WP_Error(
						'wphave_schema_network_lock_lost',
						'The network schema lease was lost.',
					);
				}
				$job['cursor'] = $site_id;
				$job['currentSiteId'] = 0;
				$job['updatedAt'] = gmdate('c');
				self::save($job);
				return $job;
			} finally {
				WPHAVE_Background_Job_Lock::release(self::LOCK, $token);
			}
		});
	}

	public static function can_manage(): bool {
		return is_multisite() && is_user_logged_in() && current_user_can('manage_network_options');
	}

	public static function register_routes(): void {
		register_rest_route('wphave/v1', '/database/schema/network', [
			'methods' => 'GET',
			'permission_callback' => [__CLASS__, 'can_manage'],
			'callback' => static function () {
				return self::can_manage()
					? self::status()
					: new WP_Error(
						'wphave_schema_network_forbidden',
						'Network administration permission is required.',
						['status' => 403],
					);
			},
		]);
		register_rest_route('wphave/v1', '/database/schema/network', [
			'methods' => 'POST',
			'permission_callback' => [__CLASS__, 'can_manage'],
			'callback' => static function (WP_REST_Request $request) {
				if (!self::can_manage()) {
					return new WP_Error(
						'wphave_schema_network_forbidden',
						'Network administration permission is required.',
						['status' => 403],
					);
				}
				return self::start('rest', (bool) $request->get_param('restart'));
			},
			'args' => ['restart' => ['type' => 'boolean', 'default' => false]],
		]);
	}
}
