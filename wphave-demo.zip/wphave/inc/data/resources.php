<?php

if (!class_exists('WPHAVE_Data_Resources')):
	/**
	 * Defines and manages all REST-backed wphave data resources.
	 *
	 * A resource describes one persisted payload: where it is stored, which
	 * subkey it owns, which capability protects it, and which transformations or
	 * side effects are required.
	 */

	class WPHAVE_Data_Resources {
		/**
		 * Returns the canonical resource registry.
		 *
		 * @return array
		 */

		public static function registry(): array {
			$resources = [
				'site_settings' => [
					'option' => 'wphave_data',
					'key' => 'wphave_settings',
					'allow_empty' => false,
					'event_get' => 'Site settings via rest api.',
					'event_update' => 'Site settings via rest api.',
					'read_capability' => 'read',
					'write_capability' => 'manage_options',
					'sensitive_paths' => [
						'advanced.code.header' => 'custom-code',
						'advanced.code.bodyOpen' => 'custom-code',
						'advanced.code.footer' => 'custom-code',
						'advanced.security.login_slug' => 'security',
					],
					'sensitive_path_capabilities' => [
						'advanced.code.header' => 'wphave_manage_custom_code',
						'advanced.code.bodyOpen' => 'wphave_manage_custom_code',
						'advanced.code.footer' => 'wphave_manage_custom_code',
						'advanced.security.login_slug' => 'wphave_manage_settings_security',
					],
					'unmasked_sensitive_capability' => 'manage_options',
					'read_transform' => [__CLASS__, 'prepare_site_settings_for_read'],
					'write_capability_map' => [__CLASS__, 'get_site_settings_write_capability_map'],
					'validate_write' => [__CLASS__, 'validate_site_settings_for_write'],
					'write_transform' => [__CLASS__, 'prepare_site_settings_for_write'],
					'after_save' => [__CLASS__, 'handle_site_settings_saved'],
					'after_change' => [__CLASS__, 'dispatch_frontend_output_changed'],
				],
				'license_settings' => [
					'option' => 'wphave_license',
					'allow_empty' => true,
					'autoload' => false,
					'event_get' => 'License settings via rest api.',
					'event_update' => 'License settings via rest api.',
					'read_capability' => 'manage_options',
					'write_capability' => 'manage_options',
					'network_main_site_only' => true,
					'sensitive_paths' => [
						'key' => 'license',
						'token' => 'license',
						'accessToken' => 'license',
					],
					'unmasked_sensitive_capability' => 'manage_options',
					'write_transform' => [__CLASS__, 'preserve_masked_sensitive_values_for_write'],
				],
				'block_defaults' => [
					'option' => 'wphave_editor',
					'key' => 'blockDefaults',
					'allow_empty' => true,
					'event_get' => 'Block defaults via rest api.',
					'event_update' => 'Block defaults via rest api.',
					'read_capability' => 'wphave_manage_block_defaults',
					'write_capability' => 'wphave_manage_block_defaults',
				],
				'access_settings' => [
					'option' => 'wphave_editor',
					'key' => 'permissions',
					'allow_empty' => true,
					'event_get' => 'Feature access settings via rest api.',
					'event_update' => 'Feature access settings via rest api.',
					'read_capability' => 'manage_options',
					'write_capability' => 'manage_options',
					'authorization_action' => 'user.permissions.manage',
					'authorization_resource' => 'roles-access',
				],
				'privacy_settings' => [
					'option' => 'wphave_editor',
					'key' => 'privacy',
					'allow_empty' => true,
					'event_get' => 'Privacy settings via rest api.',
					'event_update' => 'Privacy settings via rest api.',
					'read_capability' => 'wphave_manage_settings_privacy',
					'write_capability' => 'wphave_manage_settings_privacy',
					'validate_write' => [__CLASS__, 'validate_privacy_settings_for_write'],
					'after_change' => [__CLASS__, 'dispatch_frontend_output_changed'],
				],
				'backup_settings' => [
					'option' => 'wphave_editor',
					'key' => 'backups',
					'allow_empty' => true,
					'event_get' => 'Backup settings via rest api.',
					'event_update' => 'Backup settings via rest api.',
					'read_capability' => 'wphave_manage_backups',
					'write_capability' => 'wphave_manage_backups',
					'multisite_super_admin_only' => true,
					'sensitive_paths' => [
						'encryption.passphrase' => 'backup-archive-passphrase',
						'storage.s3.secretKey' => 'backup-s3',
						'storage.sftp.password' => 'backup-sftp-password',
						'storage.sftp.passphrase' => 'backup-sftp-passphrase',
					],
					'read_transform' => ['WPHAVE_Backup_Config', 'prepare_for_read'],
					'write_transform' => ['WPHAVE_Backup_Config', 'prepare_for_write'],
					'validate_write' => [__CLASS__, 'validate_backup_settings_for_write'],
					'after_change' => ['WPHAVE_Backup_Config', 'settings_saved'],
				],
				'smtp_settings' => [
					'option' => 'wphave_editor',
					'key' => 'smtp',
					'allow_empty' => true,
					'event_get' => 'Mail settings via rest api.',
					'event_update' => 'Mail settings via rest api.',
					'read_capability' => 'wphave_manage_settings_mail',
					'write_capability' => 'wphave_manage_settings_mail',
					'sensitive_paths' => ['password' => 'smtp'],
					'read_transform' => [__CLASS__, 'prepare_sensitive_settings_for_read'],
					'write_transform' => [__CLASS__, 'prepare_sensitive_settings_for_write'],
					'validate_write' => [__CLASS__, 'validate_smtp_settings_for_write'],
				],
				'campaign_settings' => [
					'option' => 'wphave_editor',
					'key' => 'campaigns',
					'allow_empty' => true,
					'event_get' => 'Campaign settings via rest api.',
					'event_update' => 'Campaign settings via rest api.',
					'read_capability' => 'wphave_manage_audience',
					'write_capability' => 'wphave_manage_audience',
					'sensitive_paths' => [
						'providers.resend.api_key' => 'campaign-provider-resend',
						'providers.postmark.server_token' => 'campaign-provider-postmark',
					],
					'read_transform' => [__CLASS__, 'prepare_sensitive_settings_for_read'],
					'write_transform' => [__CLASS__, 'prepare_sensitive_settings_for_write'],
					'validate_write' => [__CLASS__, 'validate_campaign_settings_for_write'],
				],
				'ai_settings' => [
					'option' => 'wphave_editor',
					'key' => 'ai',
					'allow_empty' => true,
					'event_get' => 'AI settings via rest api.',
					'event_update' => 'AI settings via rest api.',
					'read_capability' => 'wphave_manage_settings_ai',
					'write_capability' => 'wphave_manage_settings_ai',
					'sensitive_paths' => ['openai.apiKey' => 'openai'],
					'read_transform' => [__CLASS__, 'prepare_sensitive_settings_for_read'],
					'write_transform' => [__CLASS__, 'prepare_sensitive_settings_for_write'],
				],
				'site_globals' => [
					'option' => 'wphave_data',
					'key' => 'wphave_site_globals',
					'allow_empty' => false,
					'event_get' => 'Site globals via rest api.',
					'event_update' => 'Site global styles via rest api.',
					'read_capability' => 'wphave_manage_global_styles',
					'write_capability' => 'manage_options',
					'write_capability_map' => [
						'' => 'wphave_manage_global_styles',
					],
					'read_transform' => [__CLASS__, 'normalize_site_globals'],
					'validate_write' => ['WPHAVE_Fonts', 'validate_site_globals_for_write'],
					'write_transform' => [__CLASS__, 'normalize_site_globals'],
					'after_save' => [__CLASS__, 'clear_global_styles_cache'],
					'after_change' => [__CLASS__, 'dispatch_frontend_output_changed'],
					'schema_version' => 2,
				],
				'template_parts' => [
					'option' => 'wphave_data',
					'key' => 'wphave_global_template_parts',
					'allow_empty' => true,
					'event_get' => 'Global template part assignments via rest api.',
					'event_update' => 'Global template part assignments via rest api.',
					'read_capability' => 'read',
					'write_capability' => 'wphave_manage_template_parts',
					'validate_write' => ['WPHAVE_Template_Parts', 'validate_global_assignments'],
					'after_change' => [__CLASS__, 'dispatch_frontend_output_changed'],
				],
			];

			// Every persisted resource is versioned independently. Add a migration in
			// migrate_schema() before increasing one of these values in the future.
			foreach ($resources as &$config) {
				$config['schema_version'] = $config['schema_version'] ?? 1;
			}
			unset($config);

			return $resources;
		}

		/**
		 * Return the separately stored schema version for one resource.
		 *
		 * Keeping this metadata outside the payload avoids leaking implementation
		 * fields into the React state while still preventing unknown future schemas
		 * from being rewritten by a downgraded runtime.
		 */

		private static function stored_schema_version(string $resource): ?int {
			$config = self::get_config($resource);
			$versions =
				!empty($config['option']) &&
				$config['option'] === 'wphave_license' &&
				is_multisite()
					? get_site_option('wphave_resource_schema_versions', [])
					: get_option('wphave_resource_schema_versions', []);
			if (!is_array($versions) || !array_key_exists($resource, $versions)) {
				return null;
			}
			return max(1, absint($versions[$resource]));
		}

		/**
		 * Return whether this resource already owns durable storage bytes.
		 *
		 * FRESH-INSTALL INVARIANT: An absent schema marker is current only while the
		 * resource itself is absent. Existing unmarked data remains legacy and must
		 * fail closed instead of acquiring authority through a new write request.
		 */
		private static function resource_storage_exists(array $config): bool {
			$is_network_resource =
				!empty($config['option']) &&
				$config['option'] === 'wphave_license' &&
				is_multisite();
			$stored = $is_network_resource
				? get_site_option($config['option'], null)
				: get_option($config['option'], null);

			if (isset($config['key'])) {
				return is_array($stored) && array_key_exists($config['key'], $stored);
			}

			return null !== $stored;
		}

		private static function set_stored_schema_version(string $resource, int $version): void {
			$config = self::get_config($resource);
			$is_network_resource =
				!empty($config['option']) &&
				$config['option'] === 'wphave_license' &&
				is_multisite();
			$versions = $is_network_resource
				? get_site_option('wphave_resource_schema_versions', [])
				: get_option('wphave_resource_schema_versions', []);
			$versions = is_array($versions) ? $versions : [];
			$versions[$resource] = $version;
			if ($is_network_resource) {
				update_site_option('wphave_resource_schema_versions', $versions);
			} else {
				update_option('wphave_resource_schema_versions', $versions, false);
			}
		}

		/**
		 * Upgrade one resource before it is returned or replaced.
		 *
		 * COMPATIBILITY INVARIANT: Never raise schema_version without adding every sequential transformation
		 * here. Unknown newer schemas fail closed so a downgrade cannot silently
		 * discard settings it does not understand.
		 *
		 * @return array|WP_Error Migrated resource data or a schema error.
		 */

		private static function migrate_schema(string $resource, array $data, array $config) {
			$version = self::stored_schema_version($resource);
			$target = absint($config['schema_version'] ?? 1);
			if (null === $version) {
				// BASELINE-SCHEMA INVARIANT: Schema 1 is the original unversioned
				// representation. Existing schema-1 bytes may therefore be adopted,
				// but an unmarked resource whose current schema is newer remains
				// ambiguous and must fail closed until an explicit migration exists.
				if (1 === $target) {
					return $data;
				}

				return self::resource_storage_exists($config)
					? new WP_Error(
						'wphave_resource_schema_migration_missing',
						__('This settings resource uses an unsupported older schema.', 'wphave'),
						['status' => 500, 'resource' => $resource],
					)
					: $data;
			}
			if ($version > $target) {
				return new WP_Error(
					'wphave_resource_schema_newer',
					__(
						'This settings resource was created by a newer WPHAVE version and cannot be changed safely.',
						'wphave',
					),
					['status' => 409, 'resource' => $resource],
				);
			}

			// VERSION INVARIANT: Runtime reads never reinterpret an older payload.
			// Unsupported schemas fail closed so validation cannot silently discard
			// fields whose historical meaning is no longer part of the product.
			if ($version < $target) {
				return new WP_Error(
					'wphave_resource_schema_migration_missing',
					__('This settings resource uses an unsupported older schema.', 'wphave'),
					['status' => 500, 'resource' => $resource],
				);
			}

			return $data;
		}

		/**
		 * Keeps persisted Global Styles on the canonical Link Styles schema.
		 *
		 * CURRENT-SCHEMA INVARIANT: Current readers and writers may fill a missing
		 * default, but historical reinterpretation belongs to an explicit migration.
		 *
		 * @param array $data Site Global Styles payload.
		 * @return array Canonical payload.
		 */

		public static function normalize_site_globals(array $data): array {
			$links = is_array($data['links'] ?? null) ? $data['links'] : [];

			if (empty($links['style'])) {
				$links['style'] = 'default';
			}

			$data['links'] = $links;

			$color_mode = is_array($data['colorMode'] ?? null) ? $data['colorMode'] : [];
			$color_mode['enabled'] = filter_var(
				$color_mode['enabled'] ?? false,
				FILTER_VALIDATE_BOOLEAN,
			);

			if (
				!in_array(
					$color_mode['preference'] ?? 'default',
					['default', 'alternate', 'system'],
					true,
				)
			) {
				$color_mode['preference'] = 'default';
			}

			$data['colorMode'] = $color_mode;
			$data['colorContexts'] = array_slice(
				is_array($data['colorContexts'] ?? null) ? $data['colorContexts'] : [],
				0,
				3,
			);

			return $data;
		}

		/**
		 * Returns one resource config.
		 *
		 * @param string $resource Resource id.
		 * @return array|null
		 */

		public static function get_config(string $resource): ?array {
			$registry = self::registry();

			return $registry[$resource] ?? null;
		}

		/** Validate network-owned storage without exposing its sensitive bytes. */
		public static function validate_storage(string $resource) {
			$config = self::get_config($resource);
			if (is_multisite() && !empty($config['network_main_site_only'])) {
				return WPHAVE_Data_Repository::validate_network_option_storage($config['option']);
			}
			return true;
		}

		/**
		 * Returns a deterministic revision for optimistic concurrency checks.
		 *
		 * @param string $resource Resource id.
		 * @return string
		 */

		public static function get_revision(string $resource): string {
			$data = self::get($resource, false);

			return hash('sha256', wp_json_encode($data));
		}

		/**
		 * Returns feature capabilities for writable `site_settings` paths.
		 *
		 * @return array
		 */

		public static function get_site_settings_write_capability_map(): array {
			return [
				'general.media' => 'wphave_manage_settings_media',
				'general' => 'wphave_manage_settings_general',
				'brand' => 'wphave_manage_settings_brand',
				'fonts' => 'wphave_manage_settings_fonts',
				'iconLibraries' => 'wphave_manage_settings_icons',
				'social' => 'wphave_manage_settings_social',
				'seo' => 'wphave_manage_settings_seo',
				'schema' => 'wphave_manage_settings_schema',
				'forms' => 'wphave_manage_settings_forms',
				'audience' => 'wphave_manage_audience',
				'advanced.performance' => 'wphave_manage_performance',
				'advanced.security' => 'wphave_manage_settings_security',
				'advanced.maintenance' => 'wphave_manage_settings_security',
				'advanced.privacy' => 'wphave_manage_settings_privacy',
				'advanced.tracking' => 'wphave_manage_settings_tracking',
				'advanced.analytics' => 'wphave_manage_settings_tracking',
				'advanced.parameter' => 'wphave_manage_settings_tracking',
				'advanced.code' => 'wphave_manage_custom_code',
				'advanced.ui' => 'manage_options',
				'editor' => 'wphave_manage_settings_editor',
			];
		}

		/**
		 * Checks whether the current user may write a full or partial resource payload.
		 *
		 * @param string $resource Resource id.
		 * @param array $data Incoming resource data.
		 * @param string|null $path Optional patch path.
		 * @return bool
		 */

		public static function current_user_can_write(
			string $resource,
			array $data,
			?string $path = null,
		): bool {
			$config = self::get_config($resource);

			if (!$config) {
				return false;
			}

			if (!self::current_user_can_access_network_resource($config)) {
				return false;
			}

			if (current_user_can('manage_options') || current_user_can('wphave_manage_options')) {
				return true;
			}

			$map = self::get_write_capability_map($config);

			if (empty($map)) {
				$capability = $config['write_capability'] ?? 'manage_options';

				return current_user_can($capability);
			}

			if (
				!$path &&
				!empty($config['write_transform']) &&
				is_callable($config['write_transform'])
			) {
				$data = call_user_func($config['write_transform'], $data, $config);
			}

			$changed_paths = $path
				? [self::normalize_path($path)]
				: self::get_changed_paths(self::get($resource, false), $data);

			if (empty($changed_paths)) {
				return true;
			}

			// SECURITY INVARIANT: Full-resource writes derive authorization from every
			// changed leaf path. Permission for one settings area cannot smuggle changes
			// into a sibling area governed by a stronger capability.
			foreach ($changed_paths as $changed_path) {
				$capability = self::get_write_capability_for_path($changed_path, $map);

				if (!$capability || !self::current_user_can_mapped_write_capability($capability)) {
					return false;
				}
			}

			return true;
		}

		/**
		 * Checks whether the current user may read a resource.
		 *
		 * @param string $resource Resource id.
		 * @return bool
		 */

		public static function current_user_can_read(string $resource): bool {
			$config = self::get_config($resource);

			// AUTHORIZATION INVARIANT: A client-provided resource name is only a
			// selector. Registration, multisite scope and the configured capability
			// must all authorize it before any stored value is projected to REST.
			if (!$config || !self::current_user_can_access_network_resource($config)) {
				return false;
			}

			if (current_user_can('manage_options') || current_user_can('wphave_manage_options')) {
				return true;
			}

			$capability = $config['read_capability'] ?? 'manage_options';

			return $capability === 'read' ? is_user_logged_in() : current_user_can($capability);
		}

		/**
		 * Enforces ownership for resources backed by network-wide storage.
		 *
		 * SECURITY/MULTISITE INVARIANT: A site administrator's `manage_options`
		 * capability authorizes only that site. It must never grant access to a
		 * Network Option shared with every site in the installation.
		 *
		 * @param array $config Resource config.
		 * @return bool
		 */

		private static function current_user_can_access_network_resource(array $config): bool {
			// SECURITY/MULTISITE INVARIANT: Resources that configure a network-wide
			// effect or contain its credentials remain Super-Admin-owned even when
			// their feature capability is intentionally delegable on Single Site.
			if (!empty($config['multisite_super_admin_only']) && is_multisite()) {
				return is_super_admin();
			}

			if (empty($config['network_main_site_only']) || !is_multisite()) {
				return true;
			}

			return is_main_site() && current_user_can('manage_network_options');
		}

		/**
		 * Checks mapped write capabilities and their intentional rollup access.
		 *
		 * @param string $capability Feature capability.
		 * @return bool
		 */

		private static function current_user_can_mapped_write_capability(string $capability): bool {
			if (current_user_can($capability)) {
				return true;
			}

			$settings_rollup_caps = ['wphave_manage_performance', 'wphave_manage_block_defaults'];

			if (
				strpos($capability, 'wphave_manage_settings_') === 0 ||
				in_array($capability, $settings_rollup_caps, true)
			) {
				return current_user_can('wphave_manage_settings');
			}

			return false;
		}

		/**
		 * Resolves the configured write capability map.
		 *
		 * @param array $config Resource config.
		 * @return array
		 */

		private static function get_write_capability_map(array $config): array {
			$map = $config['write_capability_map'] ?? [];

			if (is_callable($map)) {
				$map = call_user_func($map);
			}

			return is_array($map) ? $map : [];
		}

		/**
		 * Finds the most specific capability for a changed path.
		 *
		 * @param string $path Changed path.
		 * @param array $map Capability map.
		 * @return string
		 */

		private static function get_write_capability_for_path(string $path, array $map): string {
			$path = self::normalize_path($path);
			$matches = [];

			foreach ($map as $prefix => $capability) {
				$prefix = self::normalize_path((string) $prefix);

				if ($prefix === '' || $path === $prefix || strpos($path, $prefix . '.') === 0) {
					$matches[$prefix] = (string) $capability;
				}
			}

			if (empty($matches)) {
				return '';
			}

			uksort($matches, function ($a, $b) {
				return strlen($b) <=> strlen($a);
			});

			return reset($matches);
		}

		/**
		 * Returns changed leaf paths between two payloads.
		 *
		 * @param mixed $current Current value.
		 * @param mixed $next New value.
		 * @param string $prefix Current path prefix.
		 * @return array
		 */

		private static function get_changed_paths($current, $next, string $prefix = ''): array {
			if ($current === $next) {
				return [];
			}

			if (!is_array($current) || !is_array($next)) {
				return [self::normalize_path($prefix)];
			}

			$paths = [];
			$keys = array_unique(array_merge(array_keys($current), array_keys($next)));

			foreach ($keys as $key) {
				$next_prefix = $prefix === '' ? (string) $key : $prefix . '.' . $key;
				$paths = array_merge(
					$paths,
					self::get_changed_paths(
						$current[$key] ?? null,
						$next[$key] ?? null,
						$next_prefix,
					),
				);
			}

			return array_values(array_unique(array_filter($paths, 'strlen')));
		}

		/**
		 * Normalizes REST dot/pipe paths.
		 *
		 * @param string $path Raw path.
		 * @return string
		 */

		private static function normalize_path(string $path): string {
			return trim(str_replace('|', '.', $path), '.');
		}

		/**
		 * Reads a resource payload.
		 *
		 * @param string $resource Resource id.
		 * @return array
		 */

		public static function get(string $resource, bool $track_event = true): array {
			$config = self::get_config($resource);

			if (!$config) {
				return [];
			}

			if ($track_event && !empty($config['event_get'])) {
				wphave_events('GET', $config['event_get']);
			}

			$data = isset($config['key'])
				? WPHAVE_Data_Repository::get_option_key($config['option'], $config['key'])
				: WPHAVE_Data_Repository::get_option_data($config['option']);
			// VERSION INVARIANT: The normal reader accepts only the configured
			// schema. It may apply current-shape sanitization below, but it never
			// performs or commits a historical migration.
			$data = self::migrate_schema($resource, $data, $config);
			if (is_wp_error($data)) {
				return [];
			}

			if (!empty($config['read_transform']) && is_callable($config['read_transform'])) {
				$data = call_user_func($config['read_transform'], $data, $config);
			}

			return is_array($data) ? $data : [];
		}

		/**
		 * Reads a resource payload prepared for REST responses.
		 *
		 * Internal PHP reads may need decrypted sensitive values. REST reads must
		 * only expose whether a sensitive value exists.
		 *
		 * @param string $resource Resource id.
		 * @return array
		 */

		public static function get_for_rest(string $resource): array {
			$config = self::get_config($resource);
			$data = self::get($resource);

			if (!$config) {
				return [];
			}

			return WPHAVE_Data_Sensitive_Values::mask_for_rest($data, $config);
		}

		/**
		 * Returns one canonical resource state for domain workflow responses.
		 *
		 * @param string $resource Resource id.
		 * @return array
		 */

		public static function state_for_rest(string $resource): array {
			return [
				'data' => self::get_for_rest($resource),
				'revision' => self::get_revision($resource),
			];
		}

		/**
		 * Builds the canonical mutation response consumed by persistent clients.
		 *
		 * The persisted resource is read again after every transform and side effect.
		 * Clients must adopt this payload instead of assuming their request was stored
		 * unchanged.
		 *
		 * @param string $resource Resource id.
		 * @param bool $changed Whether persistence changed the stored value.
		 * @return array
		 */

		private static function mutation_response(string $resource, bool $changed): array {
			return array_merge(
				[
					'status' => 200,
					'changed' => $changed,
					'message' => 'Ok',
				],
				self::state_for_rest($resource),
			);
		}

		/**
		 * Saves a full resource payload.
		 *
		 * @param string $resource Resource id.
		 * @param array $data New payload.
		 * @param string|null $expected_revision Revision returned by the last successful read or write.
		 * @param bool $force Explicitly bypass the optimistic concurrency check.
		 * @param bool $lock Whether to acquire the shared storage lock.
		 * @return array|WP_Error
		 */

		public static function save(
			string $resource,
			array $data,
			?string $expected_revision = null,
			bool $force = false,
			bool $lock = true,
		) {
			$config = self::get_config($resource);

			if (!$config) {
				return new WP_Error(
					'wphave_invalid_resource',
					__('Invalid data resource.', 'wphave'),
					['status' => 404],
				);
			}

			$current_data = isset($config['key'])
				? WPHAVE_Data_Repository::get_option_key($config['option'], $config['key'])
				: WPHAVE_Data_Repository::get_option_data($config['option']);
			$schema = self::migrate_schema($resource, $current_data, $config);
			if (is_wp_error($schema)) {
				return $schema;
			}

			if ($lock && class_exists('WPHAVE_Option_Mutations')) {
				return WPHAVE_Option_Mutations::with_lock(
					WPHAVE_Data_Repository::mutation_lock_scope($config['option']),
					function () use ($resource, $data, $expected_revision, $force, $config) {
						WPHAVE_Data_Repository::clear_option_cache($config['option']);

						return self::save($resource, $data, $expected_revision, $force, false);
					},
				);
			}

			if ($data === [] && empty($config['allow_empty'])) {
				return new WP_Error(
					'wphave_empty_resource_data',
					__('Resource payload must not be empty.', 'wphave'),
					['status' => 400],
				);
			}

			$storage = self::validate_storage($resource);
			if (is_wp_error($storage)) {
				return $storage;
			}

			$current_revision = self::get_revision($resource);
			// SECURITY INVARIANT: Non-forced resource writes replace only the canonical
			// revision observed by the caller, preventing stale whole-object overwrites.
			if (
				!$force &&
				$expected_revision !== null &&
				!hash_equals($current_revision, $expected_revision)
			) {
				return new WP_Error(
					'wphave_resource_conflict',
					__(
						'This resource was changed elsewhere. Reload it before saving again.',
						'wphave',
					),
					[
						'status' => 409,
						'revision' => $current_revision,
					],
				);
			}

			if (!empty($config['validate_write']) && is_callable($config['validate_write'])) {
				$validation = call_user_func($config['validate_write'], $data, $config);

				if (is_wp_error($validation)) {
					return $validation;
				}
			}

			if (!empty($config['write_transform']) && is_callable($config['write_transform'])) {
				$data = call_user_func($config['write_transform'], $data, $config);
			}

			$current = isset($config['key'])
				? WPHAVE_Data_Repository::get_option_key($config['option'], $config['key'])
				: WPHAVE_Data_Repository::get_option_data($config['option']);

			if ($current === $data) {
				// MIGRATION COMMIT INVARIANT: A durable version marker advances only
				// at an explicit successful write boundary, including a canonical
				// no-op whose stored bytes already match the current representation.
				self::set_stored_schema_version($resource, absint($config['schema_version'] ?? 1));

				// LIFECYCLE INVARIANT: Canonical no-op writes must not dispatch save
				// side effects. Those callbacks invalidate caches, schedule work and
				// record activity, all of which require an actual persisted change.
				return self::mutation_response($resource, false);
			}

			$saved = isset($config['key'])
				? WPHAVE_Data_Repository::update_option_value(
					$config['option'],
					$config['key'],
					$data,
					$config,
				)
				: WPHAVE_Data_Repository::update_option_data($config['option'], $data, $config);

			if (!$saved) {
				return new WP_Error(
					'wphave_resource_save_failed',
					__('Could not save settings!', 'wphave'),
					['status' => 500],
				);
			}

			self::set_stored_schema_version($resource, absint($config['schema_version'] ?? 1));

			// OBSERVABILITY INVARIANT: UPDATE telemetry describes committed writes.
			// Rejected, conflicting and canonical no-op requests must never appear as
			// successful mutations in runtime diagnostics.
			if (!empty($config['event_update'])) {
				wphave_events('UPDATE', $config['event_update']);
			}

			self::run_after_save($config, $data);
			self::run_after_change($config, $data);

			return self::mutation_response($resource, true);
		}

		/**
		 * Patches one path within a resource payload.
		 *
		 * @param string $resource Resource id.
		 * @param string $path Dot- or pipe-separated path.
		 * @param mixed $value New path value.
		 * @param string|null $expected_revision Revision returned by the last successful read or write.
		 * @param bool $force Explicitly bypass the optimistic concurrency check.
		 * @param bool $lock Whether to acquire the shared storage lock.
		 * @return array|WP_Error
		 */

		public static function patch(
			string $resource,
			string $path,
			$value,
			?string $expected_revision = null,
			bool $force = false,
			bool $lock = true,
		) {
			$config = self::get_config($resource);

			if (!$config) {
				return new WP_Error(
					'wphave_invalid_resource',
					__('Invalid data resource.', 'wphave'),
					['status' => 404],
				);
			}

			if ($lock && class_exists('WPHAVE_Option_Mutations')) {
				return WPHAVE_Option_Mutations::with_lock(
					WPHAVE_Data_Repository::mutation_lock_scope($config['option']),
					function () use (
						$resource,
						$path,
						$value,
						$expected_revision,
						$force,
						$config,
					) {
						WPHAVE_Data_Repository::clear_option_cache($config['option']);

						return self::patch(
							$resource,
							$path,
							$value,
							$expected_revision,
							$force,
							false,
						);
					},
				);
			}

			$storage = self::validate_storage($resource);
			if (is_wp_error($storage)) {
				return $storage;
			}

			$current_revision = self::get_revision($resource);
			if (
				!$force &&
				$expected_revision !== null &&
				!hash_equals($current_revision, $expected_revision)
			) {
				return new WP_Error(
					'wphave_resource_conflict',
					__(
						'This resource was changed elsewhere. Reload it before saving again.',
						'wphave',
					),
					[
						'status' => 409,
						'revision' => $current_revision,
					],
				);
			}

			$data = self::get($resource, false);
			$data = self::set_path_value($data, $path, $value);

			return self::save($resource, $data, $expected_revision, $force, false);
		}

		/**
		 * Removes REST routing noise from request data.
		 *
		 * @param WP_REST_Request $request REST request.
		 * @return array
		 */

		public static function clean_rest_request_data(WP_REST_Request $request): array {
			$data = $request->get_params();

			unset($data['resource'], $data['_locale'], $data['rest_route']);

			return is_array($data) ? $data : [];
		}

		/**
		 * Decrypts sensitive resource values for trusted internal reads.
		 *
		 * @param array $data Resource data.
		 * @param array $config Resource config.
		 * @return array
		 */

		public static function prepare_sensitive_settings_for_read(
			array $data,
			array $config,
		): array {
			foreach ($config['sensitive_paths'] ?? [] as $path => $secret) {
				$value = self::get_path_value($data, $path);

				if (!empty($value)) {
					$data = self::set_path_value(
						$data,
						$path,
						WPHAVE_Crypto::decrypt((string) $value, (string) $secret),
					);
				}
			}

			return $data;
		}

		/**
		 * Encrypts sensitive resource values before storage.
		 *
		 * @param array $data Resource data.
		 * @param array $config Resource config.
		 * @return array
		 */

		public static function prepare_sensitive_settings_for_write(
			array $data,
			array $config,
		): array {
			$data = WPHAVE_Data_Sensitive_Values::preserve_masked_values($data, $config);

			foreach ($config['sensitive_paths'] ?? [] as $path => $secret) {
				$value = self::get_path_value($data, $path);

				if (!WPHAVE_Data_Sensitive_Values::is_masked_value($value) && !empty($value)) {
					$data = self::set_path_value(
						$data,
						$path,
						WPHAVE_Crypto::encrypt((string) $value, (string) $secret),
					);
				}
			}

			return $data;
		}

		/**
		 * Validates privacy settings and protects executable custom scripts.
		 *
		 * @param array $data Privacy settings.
		 * @param array $config Resource config.
		 * @return true|WP_Error
		 */

		public static function validate_privacy_settings_for_write(array $data, array $config) {
			if (
				!function_exists('wphave_privacy_has_pro_access') ||
				!wphave_privacy_has_pro_access()
			) {
				return new WP_Error(
					'wphave_privacy_pro_required',
					__('Privacy settings require WPHAVE Pro.', 'wphave'),
					['status' => 403],
				);
			}

			return self::validate_privacy_settings_payload_for_write($data, $config);
		}

		/**
		 * Validates a Privacy payload after the entitlement boundary has authorized it.
		 *
		 * SECURITY INVARIANT: This method validates data only and never persists it.
		 * Production writes must enter through validate_privacy_settings_for_write(),
		 * which verifies Pro authority before delegating to this payload contract.
		 *
		 * @param array $data Privacy settings.
		 * @param array $config Resource config.
		 * @return true|WP_Error
		 */

		public static function validate_privacy_settings_payload_for_write(
			array $data,
			array $config,
		) {
			$privacy = $data;

			if (!is_array($privacy)) {
				return new WP_Error(
					'wphave_invalid_privacy_settings',
					__('Privacy settings must be a valid object.', 'wphave'),
					['status' => 400],
				);
			}

			$consent = $privacy['consent'] ?? [];

			if (!is_array($consent)) {
				return new WP_Error(
					'wphave_invalid_consent_settings',
					__('Consent settings must be a valid object.', 'wphave'),
					['status' => 400],
				);
			}

			$banner = $consent['banner'] ?? [];
			$scan = $consent['scan'] ?? [];
			$general = $privacy['general'] ?? [];
			$advanced = $privacy['advanced'] ?? [];
			if (
				!is_array($banner) ||
				!is_array($scan) ||
				!is_array($general) ||
				!is_array($advanced)
			) {
				return new WP_Error(
					'wphave_invalid_privacy_configuration',
					__('Privacy configuration contains an invalid section.', 'wphave'),
					['status' => 400],
				);
			}
			if (
				isset($general['anonymize_commenter_ip']) &&
				!is_bool($general['anonymize_commenter_ip'])
			) {
				return new WP_Error(
					'wphave_invalid_comment_ip_anonymization',
					__('Comment IP anonymization must be enabled or disabled.', 'wphave'),
					['status' => 400],
				);
			}
			if (
				isset($banner['position']) &&
				!in_array($banner['position'], ['top', 'center', 'bottom'], true)
			) {
				return new WP_Error(
					'wphave_invalid_consent_position',
					__('Choose a valid consent banner position.', 'wphave'),
					['status' => 400],
				);
			}
			if (
				isset($scan['frequency']) &&
				!in_array($scan['frequency'], ['daily', 'weekly', 'monthly'], true)
			) {
				return new WP_Error(
					'wphave_invalid_scan_frequency',
					__('Choose a valid privacy scan frequency.', 'wphave'),
					['status' => 400],
				);
			}
			if (
				isset($scan['time_window']) &&
				!in_array($scan['time_window'], ['night', 'morning', 'afternoon', 'evening'], true)
			) {
				return new WP_Error(
					'wphave_invalid_scan_window',
					__('Choose a valid privacy scan time window.', 'wphave'),
					['status' => 400],
				);
			}
			if (!empty($scan['email']) && !is_email($scan['email'])) {
				return new WP_Error(
					'wphave_invalid_scan_email',
					__('Enter a valid privacy scan notification email.', 'wphave'),
					['status' => 400],
				);
			}
			$referrer_policies = [
				'none',
				'no-referrer',
				'no-referrer-when-downgrade',
				'same-origin',
				'origin',
				'strict-origin',
				'origin-when-cross-origin',
				'strict-origin-when-cross-origin',
				'unsafe-url',
			];
			if (
				isset($advanced['meta_referrer_policy']) &&
				!in_array($advanced['meta_referrer_policy'], $referrer_policies, true)
			) {
				return new WP_Error(
					'wphave_invalid_referrer_policy',
					__('Choose a valid referrer policy.', 'wphave'),
					['status' => 400],
				);
			}
			foreach (['title', 'accept_button', 'reject_button', 'preferences_button'] as $field) {
				if (
					isset($banner[$field]) &&
					(!is_string($banner[$field]) || strlen($banner[$field]) > 200)
				) {
					return new WP_Error(
						'wphave_invalid_consent_label',
						__('Consent banner labels must not exceed 200 characters.', 'wphave'),
						['status' => 400],
					);
				}
			}
			if (
				isset($banner['description']) &&
				(!is_string($banner['description']) || strlen($banner['description']) > 5000)
			) {
				return new WP_Error(
					'wphave_invalid_consent_description',
					__(
						'The consent banner description must not exceed 5,000 characters.',
						'wphave',
					),
					['status' => 400],
				);
			}

			$scripts = $consent['scripts'] ?? [];
			$services = $consent['services'] ?? [];
			$current_scripts = self::get_path_value(
				self::get('privacy_settings', false),
				'consent.scripts',
				[],
			);

			if (!is_array($scripts) || count($scripts) > 100) {
				return new WP_Error(
					'wphave_invalid_consent_scripts',
					__(
						'Custom scripts must be a valid list with no more than 100 entries.',
						'wphave',
					),
					['status' => 400],
				);
			}

			if ($scripts !== $current_scripts && !current_user_can('unfiltered_html')) {
				return new WP_Error(
					'wphave_custom_scripts_forbidden',
					__('You are not allowed to save executable custom scripts.', 'wphave'),
					['status' => 403],
				);
			}

			$allowed_categories = ['necessary', 'analytics', 'marketing', 'preferences'];
			$allowed_locations = ['head', 'body', 'body_open', 'footer'];
			$total_script_bytes = 0;

			foreach ($scripts as $script) {
				if (!is_array($script)) {
					return new WP_Error(
						'wphave_invalid_consent_script',
						__('Each custom script must be a valid object.', 'wphave'),
						['status' => 400],
					);
				}

				$name = is_string($script['name'] ?? null) ? trim($script['name']) : '';
				$category = sanitize_key($script['category'] ?? '');
				$location = sanitize_key($script['location'] ?? 'footer');
				$source = $script['inline'] ?? ($script['code'] ?? '');
				$source = is_string($source) ? $source : '';
				$enabled = !isset($script['enabled']) || (bool) $script['enabled'];
				$total_script_bytes += strlen($source);

				if (
					strlen($name) > 200 ||
					!in_array($location, $allowed_locations, true) ||
					strlen($source) > 1048576
				) {
					return new WP_Error(
						'wphave_invalid_consent_script',
						__(
							'A custom script contains an invalid label, location or code size.',
							'wphave',
						),
						['status' => 400],
					);
				}

				if (
					$enabled &&
					($name === '' ||
						!in_array($category, $allowed_categories, true) ||
						trim($source) === '')
				) {
					return new WP_Error(
						'wphave_incomplete_consent_script',
						__(
							'Enabled custom scripts require a label, a valid category and code.',
							'wphave',
						),
						['status' => 400],
					);
				}
			}

			if ($total_script_bytes > 2097152) {
				return new WP_Error(
					'wphave_consent_scripts_too_large',
					__('The combined custom script code must not exceed 2 MB.', 'wphave'),
					['status' => 400],
				);
			}

			if (!is_array($services) || count($services) > 1000) {
				return new WP_Error(
					'wphave_invalid_consent_services',
					__(
						'Consent services must be a valid list with no more than 1,000 entries.',
						'wphave',
					),
					['status' => 400],
				);
			}

			foreach ($services as $service) {
				$domain =
					is_array($service) && is_string($service['domain'] ?? null)
						? strtolower(trim($service['domain']))
						: '';
				$category = is_array($service) ? sanitize_key($service['category'] ?? '') : '';

				if (
					!$domain ||
					strlen($domain) > 253 ||
					preg_match('/[\s\/:]/', $domain) ||
					($category && !in_array($category, $allowed_categories, true))
				) {
					return new WP_Error(
						'wphave_invalid_consent_service',
						__('A consent service contains an invalid domain or category.', 'wphave'),
						['status' => 400],
					);
				}
			}

			return true;
		}

		/**
		 * Validates the central backup configuration resource.
		 *
		 * @param array $data Backup settings.
		 * @param array $config Resource config.
		 * @return true|WP_Error
		 */

		public static function validate_backup_settings_for_write(array $data, array $config) {
			$plan = $data['plan'] ?? [];
			$notifications = $data['notifications'] ?? [];
			$schedule = $data['schedule'] ?? [];
			$retention = $data['retention'] ?? [];
			$storage = $data['storage'] ?? [];
			$encryption = $data['encryption'] ?? [];
			if (
				!is_array($plan) ||
				!is_array($notifications) ||
				!is_array($schedule) ||
				!is_array($retention) ||
				!is_array($storage) ||
				!is_array($encryption)
			) {
				return new WP_Error(
					'wphave_invalid_backup_settings',
					__('Backup settings contain an invalid section.', 'wphave'),
					['status' => 400],
				);
			}
			$allowed_components = ['database', 'uploads', 'fonts', 'plugins', 'themes'];
			if (
				isset($plan['components']) &&
				(!is_array($plan['components']) ||
					empty($plan['components']) ||
					array_diff($plan['components'], $allowed_components))
			) {
				return new WP_Error(
					'wphave_invalid_backup_components',
					__('Choose valid backup components.', 'wphave'),
					['status' => 400],
				);
			}
			if (isset($notifications['email']) && !is_email((string) $notifications['email'])) {
				return new WP_Error(
					'wphave_invalid_backup_email',
					__('Enter a valid backup notification email address.', 'wphave'),
					['status' => 400],
				);
			}
			if (
				isset($schedule['frequency']) &&
				!in_array($schedule['frequency'], ['disabled', 'daily', 'weekly', 'monthly'], true)
			) {
				return new WP_Error(
					'wphave_invalid_backup_frequency',
					__('Choose a valid backup frequency.', 'wphave'),
					['status' => 400],
				);
			}
			// SECURITY/MULTISITE INVARIANT: WPHAVE currently creates network-wide
			// backups on Multisite. A site-level backup capability may edit disabled
			// settings, but only a Super Admin may arm Cron to read the whole network.
			if (
				is_multisite() &&
				'disabled' !== ($schedule['frequency'] ?? 'disabled') &&
				!is_super_admin()
			) {
				return new WP_Error(
					'wphave_backup_network_schedule_permission_required',
					__(
						'Only a network administrator can enable automatic multisite backups.',
						'wphave',
					),
					['status' => 403],
				);
			}
			if (
				isset($schedule['time']) &&
				!preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', (string) $schedule['time'])
			) {
				return new WP_Error(
					'wphave_invalid_backup_time',
					__('Choose a valid backup time.', 'wphave'),
					['status' => 400],
				);
			}
			if (
				isset($schedule['weekday']) &&
				(absint($schedule['weekday']) < 1 || absint($schedule['weekday']) > 7)
			) {
				return new WP_Error(
					'wphave_invalid_backup_weekday',
					__('Choose a valid backup weekday.', 'wphave'),
					['status' => 400],
				);
			}
			if (
				isset($schedule['monthDay']) &&
				(absint($schedule['monthDay']) < 1 || absint($schedule['monthDay']) > 28)
			) {
				return new WP_Error(
					'wphave_invalid_backup_month_day',
					__('Choose a valid backup month day.', 'wphave'),
					['status' => 400],
				);
			}
			if (
				isset($schedule['retention']) &&
				(absint($schedule['retention']) < 1 || absint($schedule['retention']) > 100)
			) {
				return new WP_Error(
					'wphave_invalid_backup_retention',
					__('Choose a backup retention between 1 and 100.', 'wphave'),
					['status' => 400],
				);
			}
			if (
				isset($retention['maxStorageGb']) &&
				((float) $retention['maxStorageGb'] < 1 ||
					(float) $retention['maxStorageGb'] > 10000)
			) {
				return new WP_Error(
					'wphave_invalid_backup_storage_limit',
					__('Choose a local backup storage limit between 1 and 10,000 GB.', 'wphave'),
					['status' => 400],
				);
			}
			if (isset($retention['maxAgeDays']) && absint($retention['maxAgeDays']) > 3650) {
				return new WP_Error(
					'wphave_invalid_backup_age_limit',
					__('Choose a completed-backup age limit between 0 and 3,650 days.', 'wphave'),
					['status' => 400],
				);
			}
			if (
				isset($retention['minimumBackups']) &&
				(absint($retention['minimumBackups']) < 1 ||
					absint($retention['minimumBackups']) > 100)
			) {
				return new WP_Error(
					'wphave_invalid_backup_minimum',
					__('Choose between 1 and 100 protected restore points.', 'wphave'),
					['status' => 400],
				);
			}
			if (
				isset($retention['failedRetentionDays']) &&
				(absint($retention['failedRetentionDays']) < 1 ||
					absint($retention['failedRetentionDays']) > 365)
			) {
				return new WP_Error(
					'wphave_invalid_backup_failed_retention',
					__('Choose a failed-job retention between 1 and 365 days.', 'wphave'),
					['status' => 400],
				);
			}
			if (
				isset($retention['warningThreshold']) &&
				(absint($retention['warningThreshold']) < 50 ||
					absint($retention['warningThreshold']) > 95)
			) {
				return new WP_Error(
					'wphave_invalid_backup_warning_threshold',
					__('Choose a storage warning threshold between 50 and 95 percent.', 'wphave'),
					['status' => 400],
				);
			}
			$has_encryption_passphrase =
				WPHAVE_Backup_Config::has_constant('encryption.passphrase') ||
				strlen((string) ($encryption['passphrase'] ?? '')) >= 12;
			if (!empty($encryption['enabled']) && !$has_encryption_passphrase) {
				return new WP_Error(
					'wphave_invalid_backup_encryption_passphrase',
					__(
						'Use at least 12 characters for the backup encryption passphrase.',
						'wphave',
					),
					['status' => 400],
				);
			}
			$s3 = is_array($storage['s3'] ?? null) ? $storage['s3'] : [];
			$has_s3_secret =
				WPHAVE_Backup_Config::has_constant('storage.s3.secretKey') ||
				!empty($s3['secretKey']);
			if (
				!empty($s3['enabled']) &&
				(!str_starts_with((string) ($s3['endpoint'] ?? ''), 'https://') ||
					!preg_match(
						'/^[a-z0-9][a-z0-9.-]{1,61}[a-z0-9]$/',
						(string) ($s3['bucket'] ?? ''),
					) ||
					empty($s3['accessKey']) ||
					!$has_s3_secret)
			) {
				return new WP_Error(
					'wphave_invalid_backup_s3',
					__(
						'S3 storage requires an HTTPS endpoint, bucket and access credentials.',
						'wphave',
					),
					['status' => 400],
				);
			}
			$sftp = is_array($storage['sftp'] ?? null) ? $storage['sftp'] : [];
			$fingerprint = strtolower(
				str_replace(
					['sha256:', ':', ' '],
					'',
					(string) ($sftp['hostKeyFingerprint'] ?? ''),
				),
			);
			$has_sftp_password =
				WPHAVE_Backup_Config::has_constant('storage.sftp.password') ||
				!empty($sftp['password']);
			if (
				!empty($sftp['enabled']) &&
				(!preg_match('/^[a-z0-9.-]+$/i', (string) ($sftp['host'] ?? '')) ||
					absint($sftp['port'] ?? 22) < 1 ||
					absint($sftp['port'] ?? 22) > 65535 ||
					!preg_match('/^[a-f0-9]{64}$/', $fingerprint) ||
					empty($sftp['username']) ||
					(!$has_sftp_password && empty($sftp['privateKey'])))
			) {
				return new WP_Error(
					'wphave_invalid_backup_sftp',
					__(
						'SFTP storage requires a valid host, port, SHA-256 host-key fingerprint, username and authentication method.',
						'wphave',
					),
					['status' => 400],
				);
			}
			try {
				if (!empty($s3['enabled'])) {
					WPHAVE_Backup_Security::validate_https_endpoint((string) $s3['endpoint']);
				}
				if (!empty($sftp['enabled'])) {
					WPHAVE_Backup_Security::assert_remote_host((string) $sftp['host']);
				}
			} catch (WPHAVE_Backup_Exception $error) {
				return new WP_Error($error->error_code(), $error->getMessage(), ['status' => 400]);
			}
			return true;
		}

		/**
		 * Validate SMTP values before they can reach the mail runtime.
		 */

		public static function validate_smtp_settings_for_write(array $data, array $config) {
			if (empty($data['isEnabled'])) {
				return true;
			}

			$host = trim((string) ($data['host'] ?? ''));
			$port = (int) ($data['port'] ?? 0);
			$from_email = sanitize_email((string) ($data['from_email'] ?? ''));
			$secure = sanitize_key((string) ($data['secure'] ?? 'none'));

			if (
				$host === '' ||
				strlen($host) > 253 ||
				preg_match('/[\s\/:]/', $host) ||
				$port < 1 ||
				$port > 65535 ||
				!is_email($from_email) ||
				!in_array($secure, ['none', 'ssl', 'tls'], true)
			) {
				return new WP_Error(
					'wphave_invalid_smtp_settings',
					__('The SMTP host, port, encryption or sender email is invalid.', 'wphave'),
					['status' => 400],
				);
			}

			if (!empty($data['auth'])) {
				if (trim((string) ($data['user'] ?? '')) === '') {
					return new WP_Error(
						'wphave_invalid_smtp_auth',
						__('SMTP authentication requires a username.', 'wphave'),
						['status' => 400],
					);
				}
				$has_password =
					WPHAVE_Data_Sensitive_Values::is_masked_value($data['password'] ?? '') ||
					trim((string) ($data['password'] ?? '')) !== '' ||
					(defined('WPHAVE_SMTP_PASSWORD') && WPHAVE_SMTP_PASSWORD);
				if (!$has_password) {
					return new WP_Error(
						'wphave_invalid_smtp_password',
						__('SMTP authentication requires a password.', 'wphave'),
						['status' => 400],
					);
				}
			}

			return true;
		}

		/** Validate Campaigns-owned delivery settings before persistence. */
		public static function validate_campaign_settings_for_write(array $data, array $config) {
			if (isset($data['design']) && !is_array($data['design'])) {
				return new WP_Error(
					'wphave_campaign_design_invalid',
					__('Mailing design settings must use the supported design contract.', 'wphave'),
					['status' => 400],
				);
			}
			$providers = is_array($data['providers'] ?? null) ? $data['providers'] : [];
			$default_provider = sanitize_key((string) ($data['default_provider'] ?? 'wordpress'));
			$delivery_limits = [
				'per_minute' => [1, 1000],
				'per_hour' => [1, 100000],
				'per_day' => [1, 1000000],
				'cooldown_minutes' => [1, 1440],
			];

			foreach ($providers as $provider_key => $provider) {
				if (sanitize_key($provider_key) !== $provider_key || !is_array($provider)) {
					continue;
				}
				if ($provider_key !== $default_provider) {
					continue;
				}
				$delivery = is_array($provider['delivery'] ?? null) ? $provider['delivery'] : [];
				foreach ($delivery_limits as $key => $bounds) {
					if (isset($delivery[$key])) {
						$value = filter_var($delivery[$key], FILTER_VALIDATE_INT);
						if (false === $value || $value < $bounds[0] || $value > $bounds[1]) {
							return new WP_Error(
								'wphave_invalid_campaign_delivery_limit',
								__(
									'Mailing delivery limits must be positive numbers within the supported range.',
									'wphave',
								),
								['status' => 400],
							);
						}
					}
				}

				if (
					!empty($delivery['enabled']) &&
					(absint($delivery['per_minute'] ?? 10) > absint($delivery['per_hour'] ?? 100) ||
						absint($delivery['per_hour'] ?? 100) > absint($delivery['per_day'] ?? 500))
				) {
					return new WP_Error(
						'wphave_invalid_campaign_delivery_order',
						__(
							'The mailing minute limit must not exceed the hourly limit, and the hourly limit must not exceed the daily limit.',
							'wphave',
						),
						['status' => 400],
					);
				}
			}

			$resend = is_array($providers['resend'] ?? null) ? $providers['resend'] : [];
			$resend_key = $resend['api_key'] ?? '';
			$has_resend_key =
				WPHAVE_Data_Sensitive_Values::is_masked_value($resend_key) ||
				'' !== trim((string) $resend_key) ||
				(defined('WPHAVE_RESEND_API_KEY') && WPHAVE_RESEND_API_KEY);
			if ('resend' === $default_provider && !$has_resend_key) {
				return new WP_Error(
					'wphave_campaign_resend_key_required',
					__('Enabling Resend requires an API key.', 'wphave'),
					['status' => 400],
				);
			}

			$postmark = is_array($providers['postmark'] ?? null) ? $providers['postmark'] : [];
			$postmark_token = $postmark['server_token'] ?? '';
			$has_postmark_token =
				WPHAVE_Data_Sensitive_Values::is_masked_value($postmark_token) ||
				'' !== trim((string) $postmark_token) ||
				(defined('WPHAVE_POSTMARK_SERVER_TOKEN') && WPHAVE_POSTMARK_SERVER_TOKEN);
			if ('postmark' === $default_provider && !$has_postmark_token) {
				return new WP_Error(
					'wphave_campaign_postmark_token_required',
					__('Enabling Postmark requires a server token.', 'wphave'),
					['status' => 400],
				);
			}

			$postmark_stream = trim((string) ($postmark['message_stream'] ?? 'broadcasts'));
			if (
				'postmark' === $default_provider &&
				!preg_match('/^[a-z0-9][a-z0-9_-]{0,99}$/', $postmark_stream)
			) {
				return new WP_Error(
					'wphave_campaign_postmark_stream_invalid',
					__('Enter a valid Postmark broadcast message stream ID.', 'wphave'),
					['status' => 400],
				);
			}

			$default_registered =
				!class_exists('WPHAVE_Campaigns_Provider_Registry') ||
				null !== WPHAVE_Campaigns_Provider_Registry::get($default_provider);
			if (!$default_provider || !$default_registered) {
				return new WP_Error(
					'wphave_campaign_default_provider_invalid',
					__('Choose an enabled and registered default mailing provider.', 'wphave'),
					['status' => 400],
				);
			}

			return true;
		}

		/**
		 * Prevents dedicated license data from leaving general site settings.
		 *
		 * SECURITY/RESOURCE OWNERSHIP INVARIANT: License proof belongs exclusively
		 * to the administrator-only license_settings resource. Historical nested
		 * data must not become visible through the broadly readable site_settings
		 * resource, even before that resource is saved and normalized again.
		 *
		 * @param array $data Site settings.
		 * @param array $config Resource config.
		 * @return array
		 */

		public static function prepare_site_settings_for_read(array $data, array $config): array {
			unset($data['license']);

			return $data;
		}

		/**
		 * Prevents dedicated license data from entering general site settings.
		 *
		 * @param array $data Site settings.
		 * @param array $config Resource config.
		 * @return array
		 */

		public static function prepare_site_settings_for_write(array $data, array $config): array {
			$data = WPHAVE_Data_Sensitive_Values::preserve_masked_values($data, $config);
			unset($data['license']);
			unset($data['tests']['devicePerformance']);
			if (empty($data['tests'])) {
				unset($data['tests']);
			}
			if (isset($data['advanced']['ui']['postTypes'])) {
				$data['advanced']['ui'][
					'postTypes'
				] = WPHAVE_Generic_Content_Post_Type_Policy::filter_selection(
					$data['advanced']['ui']['postTypes'],
				);
			}
			foreach (
				[
					'wp_oembed',
					'wp_rel_link',
					'wp_version_tag',
					'wp_rsd_link',
					'wp_wlwmanifest',
					'wp_shortlink',
				]
				as $legacy_key
			) {
				unset($data['advanced']['security'][$legacy_key]);
			}
			if (class_exists('WPHAVE_Fonts')) {
				$data = WPHAVE_Fonts::prepare_site_settings_for_write($data);
			}

			return apply_filters('wphave_prepare_site_settings_for_write', $data, $config);
		}

		/**
		 * Returns login paths reserved by WordPress or WPHAVE authentication flows.
		 *
		 * @return array
		 */

		public static function get_reserved_login_slugs(): array {
			$slugs = [
				'admin',
				'admin-ajax',
				'admin-post',
				'dashboard',
				'feed',
				'index',
				'index-php',
				'login',
				'logout',
				'lost-password',
				'register',
				'reset-password',
				'robots',
				'robots-txt',
				'sitemap',
				'sitemap-xml',
				'wp-admin',
				'wp-content',
				'wp-cron',
				'wp-cron-php',
				'wp-includes',
				'wp-json',
				'wp-login',
				'wp-login-php',
				'xmlrpc',
				'xmlrpc-php',
			];

			// The REST prefix can be customized by an installation. It remains a
			// processor boundary and must never be shadowed by the login route.
			if (function_exists('rest_get_url_prefix')) {
				$slugs[] = sanitize_title(rest_get_url_prefix());
			}

			return array_values(array_unique(array_filter($slugs)));
		}

		/**
		 * Determines whether a custom login path is safe to register.
		 *
		 * @param mixed $slug Login path.
		 * @return bool
		 */

		public static function is_valid_login_slug($slug): bool {
			$slug = sanitize_title((string) $slug);

			return $slug !== '' && !in_array($slug, self::get_reserved_login_slugs(), true);
		}

		/**
		 * Validates security-sensitive site settings before persistence.
		 *
		 * @param array $data Site settings.
		 * @param array $config Resource config.
		 * @return true|WP_Error
		 */

		public static function validate_site_settings_for_write(array $data, array $config) {
			if (class_exists('WPHAVE_Fonts')) {
				$font_validation = WPHAVE_Fonts::validate_site_settings_for_write($data);
				if (is_wp_error($font_validation)) {
					return $font_validation;
				}
			}

			$forms = $data['forms'] ?? [];
			if (!is_array($forms)) {
				return new WP_Error(
					'wphave_invalid_forms_settings',
					__('Forms settings must be a valid object.', 'wphave'),
					['status' => 400],
				);
			}
			$audience = $data['audience'] ?? [];
			if (!is_array($audience)) {
				return new WP_Error(
					'wphave_invalid_audience_settings',
					__('Audience settings must be a valid object.', 'wphave'),
					['status' => 400],
				);
			}
			$audience_retention = $audience['retention'] ?? [];
			if (!is_array($audience_retention)) {
				return new WP_Error(
					'wphave_invalid_audience_retention',
					__('Audience retention settings must be a valid object.', 'wphave'),
					['status' => 400],
				);
			}
			foreach (
				['leadDays', 'interactionDays', 'pendingSubscriberDays']
				as $retention_setting
			) {
				if (!isset($audience_retention[$retention_setting])) {
					continue;
				}
				$retention_days = filter_var(
					$audience_retention[$retention_setting],
					FILTER_VALIDATE_INT,
				);
				if (false === $retention_days || $retention_days < 1 || $retention_days > 3650) {
					return new WP_Error(
						'wphave_invalid_audience_retention_days',
						__('Audience retention must be between 1 and 3,650 days.', 'wphave'),
						['status' => 400],
					);
				}
			}
			$forms_delivery = $forms['delivery'] ?? [];
			if (!is_array($forms_delivery)) {
				return new WP_Error(
					'wphave_invalid_forms_delivery_settings',
					__('Forms delivery settings must be a valid object.', 'wphave'),
					['status' => 400],
				);
			}
			foreach (['recipientEmail', 'fromEmail'] as $email_setting) {
				if (
					!empty($forms_delivery[$email_setting]) &&
					!is_email((string) $forms_delivery[$email_setting])
				) {
					return new WP_Error(
						'wphave_invalid_forms_delivery_email',
						__('Enter a valid Forms delivery email address.', 'wphave'),
						['status' => 400],
					);
				}
			}
			foreach (['fromName', 'subject'] as $text_setting) {
				if (
					isset($forms_delivery[$text_setting]) &&
					!is_string($forms_delivery[$text_setting])
				) {
					return new WP_Error(
						'wphave_invalid_forms_delivery_text',
						__('Forms delivery text settings must be valid text.', 'wphave'),
						['status' => 400],
					);
				}
			}
			$forms_spam = $forms['spam'] ?? [];
			if (!is_array($forms_spam)) {
				return new WP_Error(
					'wphave_invalid_forms_spam_settings',
					__('Forms spam settings must be a valid object.', 'wphave'),
					['status' => 400],
				);
			}
			if (
				isset($forms_spam['mode']) &&
				!in_array($forms_spam['mode'], ['standard', 'strict'], true)
			) {
				return new WP_Error(
					'wphave_invalid_forms_spam_mode',
					__('Choose a valid Forms spam protection mode.', 'wphave'),
					['status' => 400],
				);
			}
			$forms_spam_ranges = [
				'minimumFillSeconds' => [1, 10],
				'maxRequests' => [5, 20],
				'rateWindowSeconds' => [60, 900],
			];
			foreach ($forms_spam_ranges as $setting => [$minimum, $maximum]) {
				if (!isset($forms_spam[$setting])) {
					continue;
				}
				$value = filter_var($forms_spam[$setting], FILTER_VALIDATE_INT);
				if (false === $value || $value < $minimum || $value > $maximum) {
					return new WP_Error(
						'wphave_invalid_forms_spam_limit',
						__(
							'Forms spam protection limits are outside the supported range.',
							'wphave',
						),
						['status' => 400],
					);
				}
			}
			$forms_uploads = $forms['uploads'] ?? [];
			if (!is_array($forms_uploads)) {
				return new WP_Error(
					'wphave_invalid_forms_upload_settings',
					__('Forms upload settings must be a valid object.', 'wphave'),
					['status' => 400],
				);
			}
			if (isset($forms_uploads['maxFileSizeBytes'])) {
				$max_file_size = filter_var(
					$forms_uploads['maxFileSizeBytes'],
					FILTER_VALIDATE_INT,
				);
				if (
					false === $max_file_size ||
					$max_file_size < MB_IN_BYTES ||
					$max_file_size > 25 * MB_IN_BYTES
				) {
					return new WP_Error(
						'wphave_invalid_forms_upload_size',
						__('Forms upload size must be between 1 and 25 MB.', 'wphave'),
						['status' => 400],
					);
				}
			}
			if (isset($forms_uploads['maxFiles'])) {
				$max_files = filter_var($forms_uploads['maxFiles'], FILTER_VALIDATE_INT);
				if (false === $max_files || $max_files < 1 || $max_files > 10) {
					return new WP_Error(
						'wphave_invalid_forms_upload_count',
						__('Forms upload count must be between 1 and 10 files.', 'wphave'),
						['status' => 400],
					);
				}
			}
			if (isset($forms_uploads['allowedFileTypes'])) {
				$allowed_upload_groups = ['images', 'pdf', 'documents', 'spreadsheets', 'text'];
				$file_types = $forms_uploads['allowedFileTypes'];
				if (
					!is_array($file_types) ||
					empty($file_types) ||
					count($file_types) > count($allowed_upload_groups) ||
					array_diff($file_types, $allowed_upload_groups)
				) {
					return new WP_Error(
						'wphave_invalid_forms_upload_types',
						__('Choose at least one supported Forms upload type.', 'wphave'),
						['status' => 400],
					);
				}
			}
			$forms_alerts = $forms['alerts'] ?? [];

			if (!is_array($forms_alerts)) {
				return new WP_Error(
					'wphave_invalid_forms_alert_settings',
					__('Forms alert settings must be a valid object.', 'wphave'),
					['status' => 400],
				);
			}

			if (isset($forms_alerts['enabled']) && !is_bool($forms_alerts['enabled'])) {
				return new WP_Error(
					'wphave_invalid_forms_alert_status',
					__('Forms operational alerts must be enabled or disabled.', 'wphave'),
					['status' => 400],
				);
			}

			if (
				!empty($forms_alerts['recipientEmail']) &&
				!is_email((string) $forms_alerts['recipientEmail'])
			) {
				return new WP_Error(
					'wphave_invalid_forms_alert_email',
					__('Enter a valid Forms operational alert email address.', 'wphave'),
					['status' => 400],
				);
			}

			if (isset($forms_alerts['cooldownMinutes'])) {
				$cooldown_minutes = filter_var(
					$forms_alerts['cooldownMinutes'],
					FILTER_VALIDATE_INT,
				);

				if (
					false === $cooldown_minutes ||
					$cooldown_minutes < 15 ||
					$cooldown_minutes > 1440
				) {
					return new WP_Error(
						'wphave_invalid_forms_alert_cooldown',
						__(
							'Forms operational alert quiet time must be between 15 and 1,440 minutes.',
							'wphave',
						),
						['status' => 400],
					);
				}
			}

			if (isset($forms_alerts['errorCodes'])) {
				$allowed_alert_codes = [
					'missing_form_context',
					'missing_form_schema',
					'audience_storage_failed',
					'mail_delivery_failed',
				];
				$alert_codes = $forms_alerts['errorCodes'];

				if (
					!is_array($alert_codes) ||
					(!empty($forms_alerts['enabled']) && empty($alert_codes)) ||
					count($alert_codes) > count($allowed_alert_codes) ||
					array_diff($alert_codes, $allowed_alert_codes)
				) {
					return new WP_Error(
						'wphave_invalid_forms_alert_codes',
						__('Choose supported Forms operational alert types.', 'wphave'),
						['status' => 400],
					);
				}
			}

			$developer_tools = $data['advanced']['ui']['features']['developerTools'] ?? [];
			if (!is_array($developer_tools)) {
				return new WP_Error(
					'wphave_invalid_developer_tools',
					__('Developer Tools settings must be a valid object.', 'wphave'),
					['status' => 400],
				);
			}
			if (isset($developer_tools['enabled']) && !is_bool($developer_tools['enabled'])) {
				return new WP_Error(
					'wphave_invalid_developer_tools_status',
					__('Developer Tools must be enabled or disabled.', 'wphave'),
					['status' => 400],
				);
			}
			$developer_tool_states = $developer_tools['tools'] ?? [];
			if (!is_array($developer_tool_states)) {
				return new WP_Error(
					'wphave_invalid_developer_tool_states',
					__('Developer tool states must be a valid object.', 'wphave'),
					['status' => 400],
				);
			}
			foreach (
				[
					'requestInspector',
					'performanceMonitor',
					'requestProfiler',
					'externalBrowserConnections',
				]
				as $developer_tool
			) {
				if (
					isset($developer_tool_states[$developer_tool]) &&
					!is_bool($developer_tool_states[$developer_tool])
				) {
					return new WP_Error(
						'wphave_invalid_developer_tool_status',
						__('Every developer tool must be enabled or disabled.', 'wphave'),
						['status' => 400],
					);
				}
			}

			$custom_code = $data['advanced']['code'] ?? [];

			if (!is_array($custom_code)) {
				return new WP_Error(
					'wphave_invalid_custom_code',
					__('Custom code settings must be a valid object.', 'wphave'),
					['status' => 400],
				);
			}

			$total_custom_code_bytes = 0;

			foreach (['header', 'bodyOpen', 'footer'] as $location) {
				if (isset($custom_code[$location]) && !is_string($custom_code[$location])) {
					return new WP_Error(
						'wphave_invalid_custom_code',
						__('Custom code must be stored as text.', 'wphave'),
						['status' => 400],
					);
				}

				$code_bytes = strlen($custom_code[$location] ?? '');
				$total_custom_code_bytes += $code_bytes;

				if ($code_bytes > 1048576) {
					return new WP_Error(
						'wphave_custom_code_too_large',
						__('Custom code must not exceed 1 MB per location.', 'wphave'),
						['status' => 400],
					);
				}

				$enabled_key = $location . 'Enabled';

				if (isset($custom_code[$enabled_key]) && !is_bool($custom_code[$enabled_key])) {
					return new WP_Error(
						'wphave_invalid_custom_code_status',
						__('Custom code status values must be boolean.', 'wphave'),
						['status' => 400],
					);
				}
			}

			if ($total_custom_code_bytes > 2097152) {
				return new WP_Error(
					'wphave_custom_code_too_large',
					__('Combined custom code must not exceed 2 MB.', 'wphave'),
					['status' => 400],
				);
			}

			$security = $data['advanced']['security'] ?? [];
			if (!is_array($security)) {
				return new WP_Error(
					'wphave_invalid_security_settings',
					__('Security settings must be a valid object.', 'wphave'),
					['status' => 400],
				);
			}
			$security_scan = $security['scan'] ?? [];
			if (!is_array($security_scan)) {
				return new WP_Error(
					'wphave_invalid_security_scan',
					__('Security scan settings must be a valid object.', 'wphave'),
					['status' => 400],
				);
			}
			foreach (
				[
					'unify_login_feedback',
					'disable_directory_listing',
					'protect_sensitive_files',
					'block_executable_uploads',
				]
				as $boolean_setting
			) {
				if (isset($security[$boolean_setting]) && !is_bool($security[$boolean_setting])) {
					return new WP_Error(
						'wphave_invalid_security_setting',
						__('Security settings must be enabled or disabled.', 'wphave'),
						['status' => 400],
					);
				}
			}
			if (isset($security_scan['auto_enabled']) && !is_bool($security_scan['auto_enabled'])) {
				return new WP_Error(
					'wphave_invalid_security_scan_status',
					__('Automatic security scans must be enabled or disabled.', 'wphave'),
					['status' => 400],
				);
			}
			if (
				isset($security_scan['frequency']) &&
				!in_array($security_scan['frequency'], ['daily', 'weekly', 'monthly'], true)
			) {
				return new WP_Error(
					'wphave_invalid_security_scan_frequency',
					__('Choose a valid security scan frequency.', 'wphave'),
					['status' => 400],
				);
			}
			if (
				isset($security_scan['time_window']) &&
				!in_array(
					$security_scan['time_window'],
					['night', 'morning', 'afternoon', 'evening'],
					true,
				)
			) {
				return new WP_Error(
					'wphave_invalid_security_scan_window',
					__('Choose a valid security scan time window.', 'wphave'),
					['status' => 400],
				);
			}
			if (!empty($security_scan['email']) && !is_email($security_scan['email'])) {
				return new WP_Error(
					'wphave_invalid_security_scan_email',
					__('Enter a valid security scan notification email.', 'wphave'),
					['status' => 400],
				);
			}

			$login_slug =
				isset($security['login_slug']) && is_string($security['login_slug'])
					? $security['login_slug']
					: '';
			$canonical_login_slug = sanitize_title($login_slug);
			$public_post_types = get_post_types(['public' => true], 'names');
			$login_slug_content =
				'' !== $canonical_login_slug
					? get_posts([
						'fields' => 'ids',
						'name' => $canonical_login_slug,
						'numberposts' => 1,
						'post_status' => 'any',
						'post_type' => array_values($public_post_types),
						'suppress_filters' => false,
					])
					: [];

			if (
				!empty($security['login_url_enabled']) &&
				(!self::is_valid_login_slug($login_slug) ||
					$login_slug !== $canonical_login_slug ||
					!empty($login_slug_content))
			) {
				return new WP_Error(
					'wphave_invalid_login_slug',
					__(
						'Choose a canonical login path without spaces, reserved WordPress names or an existing page.',
						'wphave',
					),
					['status' => 400],
				);
			}

			$media = $data['general']['media'] ?? [];
			if (array_key_exists('ai', $media)) {
				$ai_validation = WPHAVE_Media_Disclosure_Presentation::validate($media['ai']);
				if (is_wp_error($ai_validation)) {
					return $ai_validation;
				}
			}
			$current_settings = self::get('site_settings', false);
			$ai_access = WPHAVE_Media_Disclosure_Presentation::validate_appearance_write(
				$media['ai'] ?? [],
				$current_settings['general']['media']['ai'] ?? [],
			);
			if (is_wp_error($ai_access)) {
				return $ai_access;
			}
			if (
				isset($media['image_file_format']) &&
				!in_array($media['image_file_format'], ['auto', 'webp', 'avif', 'default'], true)
			) {
				return new WP_Error(
					'wphave_invalid_media_format',
					__('Choose a supported image output format.', 'wphave'),
					['status' => 400],
				);
			}
			if (
				isset($media['image_max_size']) &&
				!in_array($media['image_max_size'], ['no', 'limit'], true)
			) {
				return new WP_Error(
					'wphave_invalid_media_size_mode',
					__('Choose a valid image size limit mode.', 'wphave'),
					['status' => 400],
				);
			}
			if (($media['image_max_size'] ?? 'no') === 'limit') {
				$max_width = (int) ($media['image_max_width'] ?? 0);
				if ($max_width < 800 || $max_width > 4000) {
					return new WP_Error(
						'wphave_invalid_media_max_width',
						__('Image maximum width must be between 800 and 4,000 pixels.', 'wphave'),
						['status' => 400],
					);
				}
			}
			if (isset($media['image_compression'])) {
				$quality = (int) str_replace('%', '', (string) $media['image_compression']);
				if ($quality < 40 || $quality > 100) {
					return new WP_Error(
						'wphave_invalid_media_quality',
						__('Image quality must be between 40 and 100 percent.', 'wphave'),
						['status' => 400],
					);
				}
			}

			$parameter = $data['advanced']['parameter'] ?? [];
			if (!is_array($parameter)) {
				return new WP_Error(
					'wphave_invalid_tracking_settings',
					__('Tracking settings must be a valid object.', 'wphave'),
					['status' => 400],
				);
			}
			if (
				isset($parameter['state']) &&
				!in_array($parameter['state'], ['disabled', 'internal', 'external', 'all'], true)
			) {
				return new WP_Error(
					'wphave_invalid_tracking_state',
					__('Choose a valid URL parameter preservation mode.', 'wphave'),
					['status' => 400],
				);
			}
			if (
				isset($parameter['attribution']) &&
				!in_array($parameter['attribution'], ['first', 'last', 'hybrid'], true)
			) {
				return new WP_Error(
					'wphave_invalid_attribution_mode',
					__('Choose a valid attribution model.', 'wphave'),
					['status' => 400],
				);
			}
			if (isset($parameter['limit']) && !is_bool($parameter['limit'])) {
				return new WP_Error(
					'wphave_invalid_tracking_parameter_limit',
					__('Parameter restriction must be enabled or disabled.', 'wphave'),
					['status' => 400],
				);
			}
			if (
				isset($parameter['list']) &&
				(!is_array($parameter['list']) || count($parameter['list']) > 100)
			) {
				return new WP_Error(
					'wphave_invalid_tracking_parameters',
					__(
						'Tracking parameters must be a list with no more than 100 entries.',
						'wphave',
					),
					['status' => 400],
				);
			}

			$allowed_parameter_count = 0;
			foreach ($parameter['list'] ?? [] as $parameter_entry) {
				$parameter_name = is_array($parameter_entry)
					? $parameter_entry['params'] ?? ''
					: null;

				// SECURITY INVARIANT: Persist exactly the bounded canonical key shape used
				// by the frontend allowlist. Otherwise a crafted payload could make an
				// enabled restriction appear configured while matching different keys.
				if (
					!is_string($parameter_name) ||
					strlen($parameter_name) > 64 ||
					('' !== $parameter_name && sanitize_key($parameter_name) !== $parameter_name)
				) {
					return new WP_Error(
						'wphave_invalid_tracking_parameter',
						__(
							'Tracking parameter names must be canonical keys with no more than 64 characters.',
							'wphave',
						),
						['status' => 400],
					);
				}

				if ('' !== $parameter_name) {
					$allowed_parameter_count++;
				}
			}

			if (
				!empty($parameter['limit']) &&
				($parameter['state'] ?? 'disabled') !== 'disabled' &&
				0 === $allowed_parameter_count
			) {
				return new WP_Error(
					'wphave_empty_tracking_parameter_allowlist',
					__(
						'Add at least one URL parameter before enabling parameter restriction.',
						'wphave',
					),
					['status' => 400],
				);
			}

			$ui = $data['advanced']['ui'] ?? [];
			if (!is_array($ui)) {
				return new WP_Error(
					'wphave_invalid_ui_settings',
					__('Interface settings must be a valid object.', 'wphave'),
					['status' => 400],
				);
			}
			if (
				isset($ui['mode']['type']) &&
				!in_array($ui['mode']['type'], ['wordpress', 'wphave'], true)
			) {
				return new WP_Error(
					'wphave_invalid_ui_mode',
					__('Choose a valid interface mode.', 'wphave'),
					['status' => 400],
				);
			}
			if (isset($ui['mode']['roles']) && !is_array($ui['mode']['roles'])) {
				return new WP_Error(
					'wphave_invalid_ui_roles',
					__('Restricted roles must be provided as a list.', 'wphave'),
					['status' => 400],
				);
			}
			if (isset($ui['postTypes']) && !is_array($ui['postTypes'])) {
				return new WP_Error(
					'wphave_invalid_ui_post_types',
					__('Interface post types must be provided as a list.', 'wphave'),
					['status' => 400],
				);
			}
			$avatars = $ui['avatars'] ?? [];
			if (isset($ui['frontendAdminBar']) && !is_bool($ui['frontendAdminBar'])) {
				return new WP_Error(
					'wphave_invalid_frontend_admin_bar',
					__('The frontend admin bar setting must be a boolean.', 'wphave'),
					['status' => 400],
				);
			}
			if (!is_array($avatars)) {
				return new WP_Error(
					'wphave_invalid_ui_avatars',
					__('Interface avatar settings must be a valid object.', 'wphave'),
					['status' => 400],
				);
			}
			if (isset($avatars['gravatarEnabled']) && !is_bool($avatars['gravatarEnabled'])) {
				return new WP_Error(
					'wphave_invalid_ui_gravatar_status',
					__('Gravatar loading must be enabled or disabled.', 'wphave'),
					['status' => 400],
				);
			}
			if (
				isset($avatars['colorfulPlaceholdersEnabled']) &&
				!is_bool($avatars['colorfulPlaceholdersEnabled'])
			) {
				return new WP_Error(
					'wphave_invalid_ui_colorful_avatar_placeholders_status',
					__('Colorful avatar placeholders must be enabled or disabled.', 'wphave'),
					['status' => 400],
				);
			}
			$privacy = $data['advanced']['privacy'] ?? [];
			if (!is_array($privacy)) {
				return new WP_Error(
					'wphave_invalid_site_privacy_settings',
					__('Website privacy settings must be a valid object.', 'wphave'),
					['status' => 400],
				);
			}
			$privacy_avatars = $privacy['avatars'] ?? [];
			if (!is_array($privacy_avatars)) {
				return new WP_Error(
					'wphave_invalid_site_privacy_avatars',
					__('Website avatar privacy settings must be a valid object.', 'wphave'),
					['status' => 400],
				);
			}
			if (
				isset($privacy_avatars['gravatarEnabled']) &&
				!is_bool($privacy_avatars['gravatarEnabled'])
			) {
				return new WP_Error(
					'wphave_invalid_frontend_gravatar_status',
					__('Website Gravatar loading must be enabled or disabled.', 'wphave'),
					['status' => 400],
				);
			}
			$client_support = $ui['clientSupport'] ?? [];
			if (!empty($client_support['isEnabled'])) {
				if (empty(trim((string) ($client_support['name'] ?? '')))) {
					return new WP_Error(
						'wphave_invalid_client_support_name',
						__('Enter the support team or agency name.', 'wphave'),
						['status' => 400],
					);
				}
				if (!is_email((string) ($client_support['email'] ?? ''))) {
					return new WP_Error(
						'wphave_invalid_client_support_email',
						__('Enter a valid client support email address.', 'wphave'),
						['status' => 400],
					);
				}
				if (
					!empty($client_support['privacyUrl']) &&
					!wp_http_validate_url((string) $client_support['privacyUrl'])
				) {
					return new WP_Error(
						'wphave_invalid_client_support_privacy_url',
						__('Enter a valid HTTP or HTTPS privacy policy URL.', 'wphave'),
						['status' => 400],
					);
				}
			}

			return true;
		}

		/**
		 * Preserves stored sensitive values when REST clients send the mask.
		 *
		 * @param array $data Resource data.
		 * @param array $config Resource config.
		 * @return array
		 */

		public static function preserve_masked_sensitive_values_for_write(
			array $data,
			array $config,
		): array {
			return WPHAVE_Data_Sensitive_Values::preserve_masked_values($data, $config);
		}

		/**
		 * Dispatches the site-settings saved action.
		 *
		 * @param array $data Saved data.
		 * @return void
		 */

		public static function dispatch_site_settings_saved(array $data): void {
			do_action('wphave_site_settings_saved', $data);
		}

		/**
		 * Notify output caches after a resource changed rendered frontend HTML.
		 *
		 * @param array $data Saved resource data.
		 * @return void
		 */

		public static function dispatch_frontend_output_changed(array $data): void {
			do_action('wphave_frontend_output_changed', $data);
		}

		/**
		 * Runs side effects after site settings changed.
		 *
		 * Font settings influence cached global CSS through local @font-face
		 * output and font-display values, so settings saves must invalidate the
		 * same cache as global-style saves.
		 *
		 * @param array $data Saved data.
		 * @return void
		 */

		public static function handle_site_settings_saved(array $data): void {
			self::dispatch_site_settings_saved($data);
			self::clear_global_styles_cache();
		}

		/**
		 * Invalidates the cached global styles string.
		 *
		 * @return void
		 */

		public static function clear_global_styles_cache(): void {
			WPHAVE_Data_Repository::delete_option_key('wphave_data', 'wphave_site_global_styles');
			WPHAVE_Data_Repository::delete_option_key(
				'wphave_data',
				'wphave_site_global_styles_version',
			);
		}

		/**
		 * Reads a nested value from an array.
		 *
		 * @param array $data Data payload.
		 * @param string $path Dot- or pipe-separated path.
		 * @param mixed $default Fallback value.
		 * @return mixed
		 */

		public static function get_path_value(array $data, string $path, $default = null) {
			foreach (self::split_path($path) as $key) {
				if (!is_array($data) || !array_key_exists($key, $data)) {
					return $default;
				}

				$data = $data[$key];
			}

			return $data;
		}

		/**
		 * Writes a nested value into an array.
		 *
		 * @param array $data Data payload.
		 * @param string $path Dot- or pipe-separated path.
		 * @param mixed $value New value.
		 * @return array
		 */

		public static function set_path_value(array $data, string $path, $value): array {
			$keys = self::split_path($path);
			$ref = &$data;

			foreach ($keys as $index => $key) {
				if ($index === count($keys) - 1) {
					$ref[$key] = $value;
					break;
				}

				if (!isset($ref[$key]) || !is_array($ref[$key])) {
					$ref[$key] = [];
				}

				$ref = &$ref[$key];
			}

			return $data;
		}

		/**
		 * Splits a nested data path.
		 *
		 * @param string $path Dot- or pipe-separated path.
		 * @return array
		 */

		private static function split_path(string $path): array {
			return array_values(array_filter(preg_split('/[|.]/', $path), 'strlen'));
		}

		/**
		 * Runs a resource-specific after-save callback.
		 *
		 * @param array $config Resource config.
		 * @param array $data Saved data.
		 * @return void
		 */

		private static function run_after_save(array $config, array $data): void {
			if (!empty($config['after_save']) && is_callable($config['after_save'])) {
				call_user_func($config['after_save'], $data);
			}
		}

		/**
		 * Run side effects that must only happen after an actual data change.
		 *
		 * @param array $config Resource config.
		 * @param array $data Saved data.
		 * @return void
		 */

		private static function run_after_change(array $config, array $data): void {
			if (!empty($config['after_change']) && is_callable($config['after_change'])) {
				call_user_func($config['after_change'], $data);
			}
		}
	}
endif;
