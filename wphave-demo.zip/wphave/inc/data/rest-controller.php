<?php

if (!class_exists('WPHAVE_Data_REST_Controller')):
	/**
	 * Registers REST routes for wphave data resources.
	 */

	class WPHAVE_Data_REST_Controller {
		/**
		 * REST namespace.
		 *
		 * @var string
		 */

		private const NAMESPACE = 'wphave/v1';

		/**
		 * Registers canonical data routes.
		 *
		 * @return void
		 */

		public static function register_routes(): void {
			self::register_resource_routes();
		}

		/**
		 * Registers canonical resource endpoints for future use.
		 *
		 * @return void
		 */

		private static function register_resource_routes(): void {
			register_rest_route(self::NAMESPACE, '/data/(?P<resource>[a-z_]+)', [
				[
					'methods' => 'GET',
					'callback' => [__CLASS__, 'get_resource'],
					'permission_callback' => [__CLASS__, 'can_read_resource'],
				],
				[
					'methods' => 'POST',
					'callback' => [__CLASS__, 'save_resource'],
					'permission_callback' => [__CLASS__, 'can_write_resource'],
				],
				[
					'methods' => 'PATCH',
					'callback' => [__CLASS__, 'patch_resource'],
					'permission_callback' => [__CLASS__, 'can_write_resource'],
				],
			]);
		}

		/**
		 * Checks whether the current user can read a resource.
		 *
		 * @param WP_REST_Request $request REST request.
		 * @return bool
		 */

		public static function can_read_resource(WP_REST_Request $request): bool {
			return WPHAVE_Data_Resources::current_user_can_read((string) $request['resource']);
		}

		/**
		 * Checks whether the current user can write a resource.
		 *
		 * @param WP_REST_Request $request REST request.
		 * @return bool
		 */

		public static function can_write_resource(WP_REST_Request $request): bool {
			// AUTHORIZATION INVARIANT: A REST cookie nonce proves request intent,
			// never resource authority. Every write derives its capability from the
			// server registry and, where present, the exact requested subpath.
			if (!is_user_logged_in()) {
				return false;
			}

			$config = WPHAVE_Data_Resources::get_config((string) $request['resource']);

			if (!$config) {
				return false;
			}

			// SECURITY INVARIANT: Force bypasses optimistic concurrency and therefore
			// requires platform-wide settings authority in addition to the resource's
			// ordinary write capability.
			if (
				self::is_force_requested($request) &&
				!current_user_can('manage_options') &&
				!current_user_can('wphave_manage_options')
			) {
				return false;
			}

			$request_data = $request->get_param('data');
			$request_data = is_array($request_data)
				? $request_data
				: WPHAVE_Data_Resources::clean_rest_request_data($request);

			return WPHAVE_Data_Resources::current_user_can_write(
				(string) $request['resource'],
				$request_data,
				$request->get_param('path') ? (string) $request->get_param('path') : null,
			);
		}

		/**
		 * Returns a canonical resource.
		 *
		 * @param WP_REST_Request $request REST request.
		 * @return array
		 */

		public static function get_resource(WP_REST_Request $request) {
			$authorization = self::require_resource_read($request);
			if (is_wp_error($authorization)) {
				return $authorization;
			}

			$resource = (string) $request['resource'];
			$storage = WPHAVE_Data_Resources::validate_storage($resource);
			if (is_wp_error($storage)) {
				return $storage;
			}

			return [
				'data' => WPHAVE_Data_Resources::get_for_rest($resource),
				'revision' => WPHAVE_Data_Resources::get_revision($resource),
			];
		}

		/**
		 * Saves a canonical resource.
		 *
		 * @param WP_REST_Request $request REST request.
		 * @return array|WP_Error
		 */

		public static function save_resource(WP_REST_Request $request) {
			$authorization = self::require_resource_write($request);
			if (is_wp_error($authorization)) {
				return $authorization;
			}

			$data = $request->get_param('data');
			$revision = $request->get_param('revision');
			$force = self::is_force_requested($request);
			if (!$force && (!is_string($revision) || $revision === '')) {
				return new WP_Error(
					'wphave_missing_revision',
					__('Reload this data before saving again.', 'wphave'),
					['status' => 409],
				);
			}

			$authorization = self::authorize_resource_write($request);
			if (is_wp_error($authorization)) {
				return $authorization;
			}

			return WPHAVE_Data_Resources::save(
				(string) $request['resource'],
				is_array($data) ? $data : [],
				is_string($revision) ? $revision : null,
				$force,
			);
		}

		/**
		 * Patches one path in a canonical resource.
		 *
		 * @param WP_REST_Request $request REST request.
		 * @return array|WP_Error
		 */

		public static function patch_resource(WP_REST_Request $request) {
			$authorization = self::require_resource_write($request);
			if (is_wp_error($authorization)) {
				return $authorization;
			}

			$path = (string) $request->get_param('path');
			$revision = $request->get_param('revision');

			if (!$path) {
				return new WP_Error(
					'wphave_missing_patch_path',
					__('Missing patch path.', 'wphave'),
					['status' => 400],
				);
			}

			$force = self::is_force_requested($request);
			if (!$force && (!is_string($revision) || $revision === '')) {
				return new WP_Error(
					'wphave_missing_revision',
					__('Reload this data before saving again.', 'wphave'),
					['status' => 409],
				);
			}

			$authorization = self::authorize_resource_write($request);
			if (is_wp_error($authorization)) {
				return $authorization;
			}

			return WPHAVE_Data_Resources::patch(
				(string) $request['resource'],
				$path,
				$request->get_param('value'),
				is_string($revision) ? $revision : null,
				$force,
			);
		}

		private static function is_force_requested(WP_REST_Request $request): bool {
			return rest_sanitize_boolean($request->get_param('force'));
		}

		private static function require_resource_read(WP_REST_Request $request) {
			// AUTHORIZATION INVARIANT: The route permission is an early transport
			// gate only. A public callback must repeat the resource-specific policy
			// before resolving or returning any persisted resource data.
			if (self::can_read_resource($request)) {
				return true;
			}

			return new WP_Error(
				'wphave_data_resource_forbidden',
				__('You are not allowed to access this data resource.', 'wphave'),
				['status' => 403],
			);
		}

		private static function require_resource_write(WP_REST_Request $request) {
			// AUTHORIZATION INVARIANT: Password proofs and revision tokens never
			// replace resource authority. Re-check the exact payload/path capability
			// before validation, proof consumption, hooks, cache invalidation or writes.
			if (self::can_write_resource($request)) {
				return true;
			}

			return new WP_Error(
				'wphave_data_resource_forbidden',
				__('You are not allowed to change this data resource.', 'wphave'),
				['status' => 403],
			);
		}

		/**
		 * Consume a configured password proof immediately before a resource write.
		 *
		 * Resources without an authorization contract retain their existing write
		 * boundary. Protected resources fail closed when the proof is absent.
		 *
		 * @param WP_REST_Request $request REST request.
		 * @return true|WP_Error
		 */

		private static function authorize_resource_write(WP_REST_Request $request) {
			$config = WPHAVE_Data_Resources::get_config((string) $request['resource']);
			$action = (string) ($config['authorization_action'] ?? '');
			$resource = (string) ($config['authorization_resource'] ?? '');

			if (!$action && !$resource) {
				return true;
			}
			if (!$action || !$resource) {
				return new WP_Error(
					'wphave_action_authorization_invalid',
					__('This protected resource is not configured correctly.', 'wphave'),
					['status' => 500],
				);
			}

			try {
				WPHAVE_Action_Authorization::consume(
					$action,
					$resource,
					(string) $request->get_header('X-WPHAVE-Action-Proof'),
				);
			} catch (WPHAVE_Action_Authorization_Exception $error) {
				return new WP_Error($error->error_code(), $error->getMessage(), [
					'status' => $error->http_status(),
				]);
			}

			return true;
		}
	}
endif;
