<?php

if (!class_exists('WPHAVE_Data_Repository')):
	/**
	 * Reads and writes wphave option payloads.
	 *
	 * This class owns the storage details only. It does not know about REST
	 * routes, resource names, encryption, or cache side effects.
	 */

	class WPHAVE_Data_Repository {
		/**
		 * Request-local option cache.
		 *
		 * @var array
		 */

		private static $option_cache = [];

		/** A table swap replaces every cached resource, including network-owned options. */
		public static function invalidate_runtime_cache(): void {
			self::$option_cache = [];
		}

		/**
		 * Options intentionally shared by every site in a multisite network.
		 *
		 * Website design, privacy, mail and editor resources are site-owned. Do not
		 * add them here merely because WordPress runs in multisite mode; doing so
		 * would make subsites overwrite each other. License proof is network-owned.
		 */

		private const NETWORK_OPTIONS = ['wphave_license'];

		private static function is_network_option(string $option): bool {
			return is_multisite() && in_array($option, self::NETWORK_OPTIONS, true);
		}

		private static function cache_key(string $option): string {
			// TENANT ISOLATION INVARIANT: A request may switch between sites that
			// belong to different networks. Network-owned license state must therefore
			// be partitioned by network ID just as site-owned state is partitioned by blog.
			$scope = self::is_network_option($option)
				? 'network:' . get_current_network_id()
				: 'site:' . get_current_blog_id();
			return $scope . ':' . $option;
		}

		/**
		 * Returns the tenant-scoped lock identity for an option mutation.
		 *
		 * LOCK ISOLATION INVARIANT: Sites and networks own independent option
		 * rows. Their writes must coordinate within that storage tenant without
		 * serializing unrelated tenants that happen to use the same option name.
		 *
		 * @param string $option Option name.
		 * @return string
		 */

		public static function mutation_lock_scope(string $option): string {
			return self::cache_key($option);
		}

		/**
		 * Clears request-local and WordPress caches before a locked read.
		 *
		 * @param string $option Option name.
		 * @return void
		 */

		public static function clear_option_cache(string $option): void {
			unset(self::$option_cache[self::cache_key($option)]);

			if (self::is_network_option($option)) {
				$network_id = get_current_network_id();

				// CACHE INVARIANT: WordPress prefixes network-option cache entries with
				// the network ID and maintains a separate negative-cache collection.
				wp_cache_delete($network_id . ':' . $option, 'site-options');
				wp_cache_delete($network_id . ':notoptions', 'site-options');
				return;
			}

			WPHAVE_Option_Mutations::clear_read_cache($option);
		}

		/**
		 * Reads an option from the current site or network storage.
		 *
		 * @param string $option Option name.
		 * @return array
		 */

		public static function get_option_data(string $option): array {
			$cache_key = self::cache_key($option);

			if (array_key_exists($cache_key, self::$option_cache)) {
				return self::$option_cache[$cache_key];
			}

			if (self::is_network_option($option)) {
				$data = get_site_option($option);
			} else {
				$data = get_option($option, []);
			}

			self::$option_cache[$cache_key] = is_array($data) ? $data : [];

			return self::$option_cache[$cache_key];
		}

		/**
		 * Validate the physical representation before trusting a network option.
		 *
		 * INVARIANT: Network options have no unique database constraint. An
		 * unreadable serialized value becomes false in Core and can make
		 * update_site_option() insert another row. Never treat corruption as an
		 * absent option or pick a winner among conflicting license proofs.
		 * Call under the resource mutation lock before writes. Recovery is an
		 * explicit operation with a backup, not an automatic read-time repair.
		 *
		 * @return true|WP_Error
		 */
		public static function validate_network_option_storage(string $option) {
			global $wpdb;
			$rows = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT meta_value FROM {$wpdb->sitemeta} WHERE site_id = %d AND meta_key = %s LIMIT 2",
					get_current_network_id(),
					$option,
				),
			);
			if ($wpdb->last_error) {
				return new WP_Error(
					'wphave_network_option_read_failed',
					__('The network settings could not be read. Please try again.', 'wphave'),
					['status' => 500],
				);
			}
			if (
				count($rows) > 1 ||
				(count($rows) === 1 && !is_array(maybe_unserialize($rows[0])))
			) {
				return new WP_Error(
					'wphave_network_option_corrupt',
					__(
						'The stored network settings are damaged or duplicated. They must be repaired before saving.',
						'wphave',
					),
					['status' => 409],
				);
			}
			return true;
		}

		/**
		 * Writes an option to the active storage scope.
		 *
		 * @param string $option Option name.
		 * @param array $data Option payload.
		 * @return bool
		 */

		public static function update_option_data(
			string $option,
			array $data,
			array $args = [],
		): bool {
			self::clear_option_cache($option);

			if (self::is_network_option($option)) {
				$saved = (bool) update_site_option($option, $data);

				if ($saved) {
					return true;
				}

				self::clear_option_cache($option);

				// DATA-INTEGRITY INVARIANT: WordPress reports false for both an
				// unchanged network option and a rejected write. Only byte-equivalent
				// persisted state may be accepted as a successful no-op.
				return get_site_option($option, null) === $data;
			}

			$autoload = array_key_exists('autoload', $args) ? $args['autoload'] : 'yes';
			$saved = (bool) update_option($option, $data, $autoload);

			self::ensure_option_autoload($option, $autoload);

			if ($saved) {
				return true;
			}

			self::clear_option_cache($option);

			// update_option() shares the same ambiguous false return contract.
			// Confirm persistence before allowing callers to adopt requested state.
			return get_option($option, null) === $data;
		}

		/**
		 * Ensures the autoload flag is correct even when update_option() skips a write.
		 *
		 * WordPress does not always update the autoload flag when the option value
		 * itself did not change. PRIVACY INVARIANT: License data remains non-autoloaded because it
		 * contains admin-only proof data that is not needed on normal frontend loads.
		 *
		 * @param string $option Option name.
		 * @param bool|string $autoload Desired autoload value.
		 * @return void
		 */

		private static function ensure_option_autoload(string $option, $autoload): void {
			if (self::is_network_option($option)) {
				return;
			}

			if (function_exists('wp_set_option_autoload_values')) {
				wp_set_option_autoload_values([
					$option => $autoload,
				]);
				return;
			}

			global $wpdb;

			$autoload_value =
				$autoload === false || $autoload === 'no' || $autoload === 'off' ? 'no' : 'yes';
			$wpdb->update(
				$wpdb->options,
				['autoload' => $autoload_value],
				['option_name' => $option],
			);
		}

		/**
		 * Reads one subkey from an option payload.
		 *
		 * @param string $option Option name.
		 * @param string $key Top-level key.
		 * @return array
		 */

		public static function get_option_key(string $option, string $key): array {
			$data = self::get_option_data($option);
			return isset($data[$key]) && is_array($data[$key]) ? $data[$key] : [];
		}

		/**
		 * Replaces one owned top-level value inside an option payload.
		 *
		 * Unlike a full resource save, this method always reads the latest
		 * container and changes only the explicitly owned key.
		 *
		 * @param string $option Option name.
		 * @param string $key Top-level key.
		 * @param mixed $value New key value.
		 * @param array $args Optional write flags.
		 * @return bool
		 */

		public static function update_option_value(
			string $option,
			string $key,
			$value,
			array $args = [],
		): bool {
			if (class_exists('WPHAVE_Option_Mutations') && !self::is_network_option($option)) {
				$autoload = array_key_exists('autoload', $args) ? $args['autoload'] : 'yes';
				$saved = WPHAVE_Option_Mutations::mutate(
					$option,
					function ($data) use ($key, $value) {
						$data[$key] = $value;
						return $data;
					},
					$autoload,
					self::mutation_lock_scope($option),
				);
				unset(self::$option_cache[self::cache_key($option)]);

				return !is_wp_error($saved);
			}

			$data = self::get_option_data($option);
			$data[$key] = $value;
			return self::update_option_data($option, $data, $args);
		}

		/**
		 * Deletes one subkey from an option payload.
		 *
		 * @param string $option Option name.
		 * @param string $key Top-level key.
		 * @param array $args Optional write flags.
		 * @return bool
		 */

		public static function delete_option_key(
			string $option,
			string $key,
			array $args = [],
		): bool {
			// CONCURRENCY INVARIANT: A subkey delete must read inside the same lock as
			// its write. Reusing the request cache here could replace unrelated values
			// committed by another tab between the earlier read and this deletion.
			if (class_exists('WPHAVE_Option_Mutations') && !self::is_network_option($option)) {
				$autoload = array_key_exists('autoload', $args) ? $args['autoload'] : 'yes';
				$saved = WPHAVE_Option_Mutations::mutate(
					$option,
					static function ($data) use ($key) {
						unset($data[$key]);

						return $data;
					},
					$autoload,
					self::mutation_lock_scope($option),
				);
				unset(self::$option_cache[self::cache_key($option)]);

				return !is_wp_error($saved);
			}

			$data = self::get_option_data($option);

			if (!array_key_exists($key, $data)) {
				return true;
			}

			unset($data[$key]);

			return self::update_option_data($option, $data, $args);
		}
	}
endif;
