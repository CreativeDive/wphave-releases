<?php
/** Filesystem authority which a database restore must never roll back. */
if (!defined('ABSPATH')) {
	exit();
}
require_once __DIR__ . '/../features/security/file-mutex.php';
require_once __DIR__ . '/../features/security/file-identity.php';
require_once __DIR__ . '/../features/security/atomic-file.php';

final class WPHAVE_Operational_State {
	private const PREFIX = "<?php exit; ?>\n";
	private static array $held = [];

	public static function directory(): string {
		// PATH INVARIANT: WP-CLI may define ABSPATH with ../ segments. Storage
		// identity and its parent must both derive from the same canonical root.
		$wordpress = realpath(ABSPATH);
		if (false === $wordpress) {
			throw new RuntimeException('WordPress storage identity is unavailable.');
		}
		$root = defined('WPHAVE_OPERATIONAL_DIRECTORY')
			? WPHAVE_OPERATIONAL_DIRECTORY
			: dirname($wordpress) .
				'/wphave-operational-' .
				substr(hash('sha256', $wordpress), 0, 16);
		if (!is_string($root) || !str_starts_with($root, '/') || is_link($root)) {
			throw new RuntimeException('Invalid operational storage directory.');
		}
		if (!is_dir($root) && !wp_mkdir_p($root)) {
			throw new RuntimeException('Operational storage is unavailable.');
		}
		$real = realpath($root);
		foreach ([ABSPATH, defined('WP_CONTENT_DIR') ? WP_CONTENT_DIR : ABSPATH] as $public) {
			$public = realpath($public);
			if (
				!$real ||
				!$public ||
				$real === $public ||
				str_starts_with($real . '/', rtrim($public, '/') . '/') ||
				str_starts_with($public . '/', rtrim($real, '/') . '/')
			) {
				throw new RuntimeException(
					'Operational storage must be outside restored and public directories.'
				);
			}
		}
		if (!chmod($real, 0700)) {
			throw new RuntimeException('Operational storage permissions could not be restricted.');
		}
		return $real . '/';
	}

	/** A non-expiring OS mutex serializes effects, lifecycle changes and restore. */
	public static function run(string $name, callable $callback) {
		if (!preg_match('/^[a-z0-9-]+$/', $name)) {
			throw new InvalidArgumentException('Invalid operational namespace.');
		}
		if (isset(self::$held[$name])) {
			return $callback();
		}
		return WPHAVE_Security_File_Mutex::run(
			self::directory() . $name . '.lock',
			static function () use ($name, $callback) {
				self::$held[$name] = true;
				try {
					return $callback();
				} finally {
					unset(self::$held[$name]);
				}
			}
		);
	}

	public static function read(string $name): ?array {
		self::assert_owned($name);
		$path = self::directory() . $name . '.php';
		if (!file_exists($path) && !is_link($path)) {
			return null;
		}
		$file = WPHAVE_Security_File_Identity::read_bounded(
			$path,
			65537,
			false,
			'Operational authority is unreadable.'
		);
		$text = $file['content'];
		if (strlen($text) > 65536 || !str_starts_with($text, self::PREFIX)) {
			throw new RuntimeException('Invalid operational authority.');
		}
		$data = json_decode(substr($text, strlen(self::PREFIX)), true);
		if (!is_array($data)) {
			throw new RuntimeException('Invalid operational authority.');
		}
		return $data;
	}

	public static function write(string $name, array $data): void {
		self::assert_owned($name);
		$text = wp_json_encode($data, JSON_UNESCAPED_SLASHES);
		if (!is_string($text) || strlen($text) > 65000) {
			throw new RuntimeException('Operational authority exceeds its bounded format.');
		}
		// COMMIT INVARIANT: Authority is published before any dependent external effect.
		WPHAVE_Security_Atomic_File::write(
			self::directory() . $name . '.php',
			self::PREFIX . $text,
			'Operational authority could not be committed.'
		);
	}

	private static function assert_owned(string $name): void {
		if (!isset(self::$held[$name])) {
			throw new LogicException('Operational state requires its mutex.');
		}
	}
}
