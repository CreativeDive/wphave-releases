<?php

/** Maintenance composition shares each feature's own schema registrations. */
if (!defined('ABSPATH')) {
	exit();
}
final class WPHAVE_Database_Schema_Runtime {
	public static function load(): void {
		// REGISTRY INVARIANT: A lean Cron request must see the same storage
		// contracts as management. Never duplicate SQL, versions or validators.
		require_once wphave_dir() . 'inc/optimize/redirects/manager.php';
		require_once wphave_dir() . 'build/block-types/blocks-templates/like-button/functions.php';
		require_once wphave_dir() . 'build/block-types/blocks-templates/rating/functions.php';
		// TENANCY INVARIANT: switch_to_blog does not reload plugins or feature
		// modules. Resolve optional storage against the target site's settings.
		if (wphave_activity_feature_enabled()) {
			require_once wphave_dir() . 'inc/admin/features/activity/storage/log.php';
		}
		if (wphave_presence_feature_enabled()) {
			require_once wphave_dir() . 'inc/admin/user/presence/functions.php';
		}
		require_once wphave_dir() . 'inc/features/woocommerce/reporting/schema-registration.php';
	}
}
