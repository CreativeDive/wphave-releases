<?php

/** Operational entry points use the same runners as activation and REST. */
if (!defined('ABSPATH')) {
	exit();
}

final class WPHAVE_Database_Schema_CLI {
	/** Inspect current-site readiness, or the durable network job with --network. */
	public function status(array $args, array $assoc_args): void {
		$result = isset($assoc_args['network'])
			? WPHAVE_Database_Schema_Network::status()
			: WPHAVE_Database_Schema_Manager::status();
		WP_CLI::line(wp_json_encode($result, JSON_PRETTY_PRINT));
	}

	/**
	 * Update this site, or start/resume an explicitly requested network pass.
	 *
	 * ## OPTIONS
	 *
	 * [--network]
	 * : Process the current network's active sites.
	 * [--restart]
	 * : Start a new pass after reviewing errors or a changed runtime.
	 * [--wait]
	 * : Process the network job in this CLI process instead of waiting for Cron.
	 */
	public function update(array $args, array $assoc_args): void {
		// AUTHORITY INVARIANT: WP-CLI's host operator is the explicit caller;
		// HTTP entry points independently require native WordPress capabilities.
		if (!isset($assoc_args['network'])) {
			$result = WPHAVE_Database_Schema_Manager::update_site(get_current_blog_id(), 'cli');
		} else {
			$result = WPHAVE_Database_Schema_Network::start('cli', isset($assoc_args['restart']));
			while (
				!is_wp_error($result) &&
				isset($assoc_args['wait']) &&
				'running' === $result['state']
			) {
				$cursor = $result['cursor'];
				$result = WPHAVE_Database_Schema_Network::tick($result['id']);
				if (
					!is_wp_error($result) &&
					'running' === $result['state'] &&
					$cursor === $result['cursor']
				) {
					WP_CLI::warning('No progress: another worker may own the lease. Resume later.');
					break;
				}
			}
		}
		if (is_wp_error($result)) {
			WP_CLI::error($result->get_error_message());
		}
		WP_CLI::line(wp_json_encode($result, JSON_PRETTY_PRINT));
		if (in_array($result['state'] ?? '', ['paused', 'completed_with_errors'], true)) {
			WP_CLI::error(
				'Schema work requires attention; inspect the network job and site status.',
			);
		}
	}
}

WP_CLI::add_command('wphave database', 'WPHAVE_Database_Schema_CLI');
