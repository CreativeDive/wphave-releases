<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Creates and validates the site-scoped activity event store. */

final class WPHAVE_Activity_Schema {

	const DB_VERSION = '1.2.0';

	/** Create or migrate the activity table through WordPress dbDelta. */

	public static function install(): void {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table = $wpdb->prefix . WPHAVE_Activity_Log::TABLE;
		$charset = $wpdb->get_charset_collate();
		$sql = "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			occurred_at datetime NOT NULL,
			event_type varchar(100) NOT NULL,
			category varchar(50) NOT NULL,
			action varchar(50) NOT NULL,
			status varchar(20) NOT NULL DEFAULT 'success',
			severity varchar(20) NOT NULL DEFAULT 'info',
			actor_type varchar(30) NOT NULL DEFAULT 'user',
			actor_id bigint(20) unsigned NOT NULL DEFAULT 0,
			actor_label varchar(190) NOT NULL DEFAULT '',
			object_type varchar(50) NOT NULL DEFAULT '',
			object_id bigint(20) unsigned NOT NULL DEFAULT 0,
			object_subtype varchar(100) NOT NULL DEFAULT '',
			object_label varchar(255) NOT NULL DEFAULT '',
			source varchar(50) NOT NULL DEFAULT '',
			request_id char(36) NOT NULL DEFAULT '',
			assessment_status varchar(20) NOT NULL DEFAULT '',
			follow_up_status varchar(20) NOT NULL DEFAULT '',
			correlation_id char(36) NOT NULL DEFAULT '',
			search_text varchar(1000) NOT NULL DEFAULT '',
			context longtext DEFAULT NULL,
			PRIMARY KEY  (id),
			KEY occurred_at (occurred_at),
			KEY event_type_date (event_type,occurred_at),
			KEY category_date (category,occurred_at),
			KEY actor_date (actor_id,occurred_at),
			KEY object_date (object_type,object_id,occurred_at),
			KEY status_date (status,occurred_at),
			KEY assessment_date (assessment_status,occurred_at),
			KEY follow_up_date (follow_up_status,occurred_at),
			KEY correlation (correlation_id)
		) {$charset};";

		dbDelta( $sql );
		WPHAVE_Database_Metadata::invalidate( $table );
		WPHAVE_Activity_Log::reset_table_cache();
	}

	/** Verify that the activity table exists for the current site. */
    
	public static function validate(): bool {
		global $wpdb;
		$table = $wpdb->prefix . WPHAVE_Activity_Log::TABLE;
		return WPHAVE_Database_Metadata::table_exists( $table );
	}
}
