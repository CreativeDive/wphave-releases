<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once wphave_dir() . 'inc/background-jobs/functions.php';
require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/../capture/changes.php';

/**
 * Central write service for immutable WPHAVE activity events.
 *
 * Feature modules should record semantic events after a mutation succeeded.
 * This service owns normalization, actor attribution, context redaction,
 * request-local deduplication and persistence. User-facing text deliberately
 * remains outside the stored event so labels can evolve and be translated.
 */

final class WPHAVE_Activity_Log {

	const TABLE = 'wphave_activity_events';
	const RETENTION_OPTION = 'wphave_activity_retention_days';
	const PRIVACY_VERSION_OPTION = 'wphave_activity_privacy_version';
	const PRIVACY_CURSOR_OPTION = 'wphave_activity_privacy_cursor';
	const PRIVACY_LOCK_OPTION = 'wphave_activity_privacy_lock';
	const PRIVACY_VERSION = 1;
	const PRIVACY_HOOK = 'wphave_activity_privacy_scrub';
	const CLEANUP_HOOK = 'wphave_activity_cleanup';
	const CLEANUP_SCHEDULE_OPTION = 'wphave_activity_cleanup_schedule';
	const DEFAULT_RETENTION_DAYS = 90;
	const HEALTH_OPTION = 'wphave_activity_health';
	const MAX_CONTEXT_DEPTH = 4;
	const MAX_CONTEXT_BYTES = 32768;

	private static string $request_id = '';
	private static array $recorded = array();
	private static array $recorded_categories = array();
	private static bool $writing = false;
	private static array $table_exists = array();

	/** Register the database schema and retention lifecycle hooks. */

	public static function init(): void {
		WPHAVE_Database_Schema_Manager::register( array(
			'id' => 'activity',
            'enabled' => 'wphave_activity_feature_enabled',
			'label' => 'Activity log',
			'version' => WPHAVE_Activity_Schema::DB_VERSION,
			'option' => 'wphave_activity_db_version',
			'callback' => array( 'WPHAVE_Activity_Schema', 'install' ),
			'validator' => array( 'WPHAVE_Activity_Schema', 'validate' ),
			'tables' => array( self::TABLE ),
		) );

		if ( ! WPHAVE_Database_Schema_Manager::runtime_compatible( 'activity' ) ) {
			return;
		}

		add_action( 'init', array( __CLASS__, 'schedule_cleanup' ), 20 );
		add_action( 'init', array( __CLASS__, 'schedule_privacy_scrub' ), 25 );
		add_action( self::PRIVACY_HOOK, array( __CLASS__, 'scrub_legacy_events' ) );
		add_action( self::CLEANUP_HOOK, array( __CLASS__, 'cleanup' ) );
		add_action( self::CLEANUP_HOOK . '_continuation', array( __CLASS__, 'cleanup' ) );
	}

	/** Export one bounded page of activity events attributed to an email owner. */

	public static function privacy_export( string $email_address, int $page = 1 ): array {
		$user = get_user_by( 'email', sanitize_email( strtolower( $email_address ) ) );

		if ( ! $user instanceof WP_User || ! self::table_exists() ) {
			return array( 'data' => array(), 'done' => true );
		}

		global $wpdb;
		$limit = 100;
		$offset = max( 0, $page - 1 ) * $limit;
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT id, occurred_at, event_type, category, action, status, severity, object_type, object_id, object_label, source, context FROM ' . self::table() . ' WHERE actor_type = %s AND actor_id = %d ORDER BY id ASC LIMIT %d OFFSET %d',
				'user',
				$user->ID,
				$limit,
				$offset
			),
			ARRAY_A
		) ?: array();
		$data = array();

		foreach ( $rows as $row ) {
			$row['context'] = self::safe_context( json_decode( $row['context'] ?: '{}', true ) ?: array() );
			$data[] = array(
				'group_id' => 'wphave-activity',
				'group_label' => __( 'WPHAVE Activity Log', 'wphave' ),
				'item_id' => 'activity-' . absint( $row['id'] ),
				'data' => array_map(
					static fn( $key, $value ) => array(
						'name' => ucwords( str_replace( '_', ' ', (string) $key ) ),
						'value' => is_array( $value ) ? wp_json_encode( $value ) : (string) $value,
					),
					array_keys( $row ),
					array_values( $row )
				),
			);
		}

		return array( 'data' => $data, 'done' => count( $rows ) < $limit );
	}

	/** Anonymize one bounded page of immutable events attributed to an email owner. */

	public static function privacy_erase( string $email_address, int $page = 1 ): array {
		$user = get_user_by( 'email', sanitize_email( strtolower( $email_address ) ) );

		if ( ! $user instanceof WP_User || ! self::table_exists() ) {
			return array( 'items_removed' => false, 'items_retained' => false, 'messages' => array(), 'done' => true );
		}

		global $wpdb;
		$limit = 100;
		$ids = array_map(
			'absint',
			$wpdb->get_col(
				$wpdb->prepare(
					'SELECT id FROM ' . self::table() . ' WHERE actor_type = %s AND actor_id = %d ORDER BY id ASC LIMIT %d',
					'user',
					$user->ID,
					$limit
				)
			) ?: array()
		);

		if ( ! $ids ) {
			return array( 'items_removed' => false, 'items_retained' => false, 'messages' => array(), 'done' => true );
		}

		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		/*
		 * PRIVACY INVARIANT: Erasure preserves the audit fact but removes every
		 * actor-identifying projection in the same statement. Keeping actor_id,
		 * actor_label or the derived search_text would leave a reversible copy.
		 */
		$updated = $wpdb->query(
			$wpdb->prepare(
				'UPDATE ' . self::table() . " SET actor_id = 0, actor_label = '', search_text = LEFT(CONCAT_WS(' ', event_type, object_label), 1000) WHERE id IN ({$placeholders})",
				...$ids
			)
		);

		if ( false === $updated ) {
			return array(
				'items_removed' => false,
				'items_retained' => true,
				'messages' => array( __( 'Activity actor data could not be anonymized.', 'wphave' ) ),
				'done' => false,
			);
		}

		wp_cache_delete( 'facets', 'wphave-activity' );

		return array(
			'items_removed' => $updated > 0,
			'items_retained' => false,
			'messages' => array(),
			'done' => count( $ids ) < $limit,
		);
	}

	/**
	 * Persist one normalized activity event.
	 *
	 * Event names use the stable `domain.action` convention. Context is intended
	 * for compact diagnostic metadata only; secrets and content fields are
	 * removed recursively before persistence.
	 *
	 * Supported arguments: category, action, status, severity, actor_type,
	 * actor_id, actor_label, object_type, object_id, object_subtype,
	 * object_label, source and context.
	 *
	 * @param string $event_type Stable machine-readable event name.
	 * @param array  $args       Event attributes and sanitized context metadata.
	 * @return int Inserted event id, or zero when the event was skipped.
	 */

	public static function record( string $event_type, array $args = array() ): int {
		if( self::$writing || ! self::table_exists() ) return 0;

		$event_type = self::normalize_event_type( $event_type );
		if( ! $event_type ) return 0;

		$actor = self::actor( $args );
		$data = array(
			'occurred_at' => current_time( 'mysql', true ),
			'event_type' => $event_type,
			'category' => sanitize_key( $args['category'] ?? strtok( $event_type, '.' ) ?: 'system' ),
			'action' => sanitize_key( $args['action'] ?? self::event_action( $event_type ) ),
			'status' => self::allowed( $args['status'] ?? 'success', array( 'success', 'failure', 'warning', 'info' ), 'success' ),
			'severity' => self::allowed( $args['severity'] ?? 'info', array( 'info', 'notice', 'warning', 'error', 'critical' ), 'info' ),
			'actor_type' => $actor['type'],
			'actor_id' => $actor['id'],
			'actor_label' => $actor['label'],
			'object_type' => sanitize_key( $args['object_type'] ?? '' ),
			'object_id' => absint( $args['object_id'] ?? 0 ),
			'object_subtype' => sanitize_key( $args['object_subtype'] ?? '' ),
			'object_label' => sanitize_text_field( (string) ( $args['object_label'] ?? '' ) ),
			'source' => sanitize_key( $args['source'] ?? self::source() ),
			'request_id' => self::request_id(),
			'assessment_status' => '',
			'follow_up_status' => '',
			'correlation_id' => '',
			'search_text' => '',
			'context' => self::context_json( (array) ( $args['context'] ?? array() ) ),
		);

		/** Filters normalized event data before it is persisted. Return an empty event type to discard it. */

		$data = apply_filters( 'wphave/activity/event', $data, $args );
		if( ! is_array( $data ) || empty( $data['event_type'] ) ) return 0;
		$data = self::sanitize_event_data( $data );
		if( ! $data['event_type'] ) return 0;

		/** Filters whether a normalized activity event should be persisted. */

		if( ! apply_filters( 'wphave/activity/should_record', true, $data, $args ) ) return 0;

		$fingerprint = md5( wp_json_encode( array( $data['event_type'], $data['actor_id'], $data['object_type'], $data['object_id'], $data['status'], $data['context'] ) ) );
		if( ! empty( $args['deduplicate'] ) && isset( self::$recorded[$fingerprint] ) ) return 0;

		global $wpdb;
		self::$writing = true;
		try {
			$inserted = $wpdb->insert( self::table(), $data, array( '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' ) );
		} finally {
			self::$writing = false;
		}

		if( ! $inserted ) {
			$health = (array) get_option( self::HEALTH_OPTION, array() );
			update_option( self::HEALTH_OPTION, array( 'write_failures' => absint( $health['write_failures'] ?? 0 ) + 1, 'last_write_failure_at' => current_time( 'mysql', true ) ), false );
			return 0;
		}

		if( count( self::$recorded ) >= 1000 ) self::$recorded = array();
		self::$recorded[$fingerprint] = true;
		self::$recorded_categories[$data['category']] = true;
		$event_id = (int) $wpdb->insert_id;
		wp_cache_delete( 'facets', 'wphave-activity' );
		do_action( 'wphave/activity/recorded', $event_id, $data );
		return $event_id;
	}

	/** Return whether this request already persisted an event in a category. */

	public static function request_has_category( string $category ): bool {
		return isset( self::$recorded_categories[sanitize_key( $category )] );
	}

	/** Return the configured retention period, where zero means unlimited. */

	public static function retention_days(): int {
		$days = absint( get_option( self::RETENTION_OPTION, self::DEFAULT_RETENTION_DAYS ) );
		return min( 3650, max( 0, $days ) );
	}

	/** Update the retention period within the supported range. */

	public static function set_retention_days( int $days ): bool {
		return update_option( self::RETENTION_OPTION, min( 3650, max( 0, $days ) ), false );
	}

	/** Ensure the daily retention task is scheduled. */

	public static function schedule_cleanup(): void {
		// DATA-RETENTION INVARIANT: Audit events must have exactly one daily
		// retention owner. Reconcile interval drift and duplicate legacy events so
		// an apparently scheduled job cannot silently retain data beyond policy.
		WPHAVE_Background_Job_Scheduler::sync_recurring(
			self::CLEANUP_HOOK,
			self::CLEANUP_SCHEDULE_OPTION,
			true,
			'daily',
			time() + HOUR_IN_SECONDS,
			'activity-retention-v1'
		);
	}

	/**
	 * Delete one bounded batch of expired events.
	 *
	 * @return int|null Deleted rows, or null when the database state is unknown.
	 */

	public static function cleanup(): ?int {
		$days = self::retention_days();
		if( ! $days || ! self::table_exists() ) return 0;

		global $wpdb;
		$cutoff = gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );
		$critical_days = WPHAVE_Activity_Policy::get()['critical_retention_days'];
		$protected = "(status = 'failure' OR severity IN ('warning','error','critical') OR assessment_status IN ('warning','critical'))";
		if( $critical_days ) {
			$critical_cutoff = gmdate( 'Y-m-d H:i:s', time() - $critical_days * DAY_IN_SECONDS );
			$where = "(NOT {$protected} AND occurred_at < %s) OR ({$protected} AND occurred_at < %s)";
			$deleted = $wpdb->query( $wpdb->prepare( 'DELETE FROM ' . self::table() . " WHERE {$where} ORDER BY id ASC LIMIT 5000", $cutoff, $critical_cutoff ) );
		} else {
			$deleted = $wpdb->query( $wpdb->prepare( 'DELETE FROM ' . self::table() . " WHERE NOT {$protected} AND occurred_at < %s ORDER BY id ASC LIMIT 5000", $cutoff ) );
		}

		/*
		 * RESILIENCE INVARIANT: A failed destructive query is not an empty batch.
		 * It remains explicitly unknown and receives an earlier retry instead of
		 * waiting for the next daily retention run.
		 */
		if( false === $deleted ) {
			WPHAVE_Background_Job_Scheduler::ensure_continuation(
				self::CLEANUP_HOOK . '_continuation',
				array(),
				15 * MINUTE_IN_SECONDS
			);

			return null;
		}

		if ( 5000 === $deleted ) {
			WPHAVE_Background_Job_Scheduler::ensure_continuation(
				self::CLEANUP_HOOK . '_continuation',
				array(),
				5 * MINUTE_IN_SECONDS
			);
		}

		return (int) $deleted;
	}

	/** Queue the resumable legacy scrub without doing migration work in a page request. */

	public static function schedule_privacy_scrub(): void {
		if ( absint( get_option( self::PRIVACY_VERSION_OPTION, 0 ) ) >= self::PRIVACY_VERSION ) {
			return;
		}

		WPHAVE_Background_Job_Scheduler::ensure_continuation(
			self::PRIVACY_HOOK,
			array(),
			MINUTE_IN_SECONDS
		);
	}

	/** Permanently remove every activity event. */

	public static function clear(): int {
		if( ! self::table_exists() ) return 0;
		global $wpdb;
		$deleted = (int) $wpdb->query( 'DELETE FROM ' . self::table() );
		wp_cache_delete( 'facets', 'wphave-activity' );
		return $deleted;
	}

	/**
	 * Reapply the current privacy boundary to a bounded batch of older rows.
	 *
	 * REST output is independently redacted, so legacy data cannot be displayed
	 * while this resumable storage migration progresses across requests.
	 */

	public static function scrub_legacy_events(): int {
		if( absint( get_option( self::PRIVACY_VERSION_OPTION, 0 ) ) >= self::PRIVACY_VERSION || ! self::table_exists() ) return 0;
		$lock_token = WPHAVE_Background_Job_Lock::acquire(
			self::PRIVACY_LOCK_OPTION,
			10 * MINUTE_IN_SECONDS
		);

		if ( ! $lock_token ) {
			// AVAILABILITY INVARIANT: A one-shot migration may never disappear
			// merely because another request currently owns its processing lease.
			WPHAVE_Background_Job_Scheduler::ensure_continuation(
				self::PRIVACY_HOOK,
				array(),
				5 * MINUTE_IN_SECONDS
			);

			return 0;
		}

		try {
			global $wpdb;
			$cursor = absint( get_option( self::PRIVACY_CURSOR_OPTION, 0 ) );
			$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id > %d ORDER BY id ASC LIMIT 200', $cursor ), ARRAY_A );
			$processed = 0;
			foreach( $rows as $row ) {
				$context = self::safe_context( json_decode( $row['context'] ?: '{}', true ) ?: array() );
				$row['context'] = wp_json_encode( $context, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
				$row['actor_label'] = WPHAVE_Activity_Privacy::sanitize_text( (string) $row['actor_label'], 190 );
				$row['object_label'] = WPHAVE_Activity_Privacy::sanitize_text( (string) $row['object_label'], 190 );
				$updated = $wpdb->update( self::table(), array( 'context' => $row['context'], 'actor_label' => $row['actor_label'], 'object_label' => $row['object_label'], 'search_text' => self::search_text( $row ) ), array( 'id' => (int) $row['id'] ), array( '%s', '%s', '%s', '%s' ), array( '%d' ) );
				if( $updated === false ) break;
				$processed++;
				$cursor = (int) $row['id'];
			}
			if( $processed === count( $rows ) && count( $rows ) < 200 ) {
				update_option( self::PRIVACY_VERSION_OPTION, self::PRIVACY_VERSION, false );
				delete_option( self::PRIVACY_CURSOR_OPTION );
			} else {
				update_option( self::PRIVACY_CURSOR_OPTION, $cursor, false );
				WPHAVE_Background_Job_Scheduler::ensure_continuation(
					self::PRIVACY_HOOK,
					array(),
					5 * MINUTE_IN_SECONDS
				);
			}
			return $processed;
		} finally {
			// SECURITY INVARIANT: Scrub failures and timeout recovery may never
			// release a successor's privacy-migration lease.
			WPHAVE_Background_Job_Lock::release(
				self::PRIVACY_LOCK_OPTION,
				$lock_token
			);
		}
	}

	/** Apply the immutable privacy boundary to context before any output. */
    
	public static function safe_context( array $context ): array {
		return self::sanitize_context( $context );
	}

	/** Return the current site's fully-prefixed activity table name. */

	public static function table(): string {
		global $wpdb;
		return $wpdb->prefix . self::TABLE;
	}

	/** Check whether the activity table is available in the current site. */

	public static function table_exists(): bool {
		$table = self::table();
		if( isset( self::$table_exists[$table] ) ) return self::$table_exists[$table];
		self::$table_exists[$table] = WPHAVE_Database_Metadata::table_exists( $table );
		return self::$table_exists[$table];
	}

	/** Clear the request-local schema availability cache after migrations. */

	public static function reset_table_cache(): void {
		$table = self::table();
		unset( self::$table_exists[$table] );
		WPHAVE_Database_Metadata::invalidate( $table );
	}

	/** Resolve the explicit or current request actor snapshot. */

	private static function actor( array $args ): array {
		if( isset( $args['actor_type'] ) ) return array( 'type' => sanitize_key( $args['actor_type'] ), 'id' => absint( $args['actor_id'] ?? 0 ), 'label' => sanitize_text_field( (string) ( $args['actor_label'] ?? '' ) ) );
		$user = wp_get_current_user();
		if( $user && $user->exists() ) return array( 'type' => 'user', 'id' => (int) $user->ID, 'label' => sanitize_text_field( $user->display_name ?: $user->user_login ) );
		$type = wp_doing_cron() ? 'cron' : ( defined( 'WP_CLI' ) && WP_CLI ? 'cli' : ( self::source() === 'rest' ? 'api' : 'system' ) );
		return array( 'type' => $type, 'id' => 0, 'label' => $type === 'system' ? 'System' : strtoupper( $type ) );
	}

	/** Resolve the transport that caused the current event. */

	private static function source(): string {
		if( defined( 'WP_CLI' ) && WP_CLI ) return 'cli';
		if( wp_doing_cron() ) return 'cron';
		if( wp_doing_ajax() ) return 'ajax';
		if( defined( 'REST_REQUEST' ) && REST_REQUEST ) return 'rest';
		return is_admin() ? 'admin' : 'frontend';
	}

	/** Return one correlation id shared by all events in the current request. */

	private static function request_id(): string {
		if( ! self::$request_id ) self::$request_id = wp_generate_uuid4();
		return self::$request_id;
	}

	/** Restrict a scalar value to an allowlist. */

	private static function allowed( $value, array $allowed, string $fallback ): string {
		$value = sanitize_key( (string) $value );
		return in_array( $value, $allowed, true ) ? $value : $fallback;
	}

	/** Derive the default action from the final event-name segment. */

	private static function event_action( string $event_type ): string {
		$parts = explode( '.', $event_type );
		return (string) end( $parts );
	}

	/** Normalize event names without changing their semantic dot notation. */

	private static function normalize_event_type( string $event_type ): string {
		return trim( preg_replace( '/[^a-z0-9_.-]/', '', strtolower( $event_type ) ), '.' );
	}

	/** Re-validate filtered event data before it reaches the database boundary. */

	private static function sanitize_event_data( array $data ): array {
		$context = is_string( $data['context'] ?? null ) ? json_decode( $data['context'], true ) : ( $data['context'] ?? array() );
		$data['occurred_at'] = self::valid_datetime( (string) ( $data['occurred_at'] ?? '' ) );
		$data['event_type'] = self::normalize_event_type( (string) ( $data['event_type'] ?? '' ) );
		$data['category'] = sanitize_key( $data['category'] ?? 'system' );
		$data['action'] = sanitize_key( $data['action'] ?? self::event_action( $data['event_type'] ) );
		$data['status'] = self::allowed( $data['status'] ?? 'success', array( 'success', 'failure', 'warning', 'info' ), 'success' );
		$data['severity'] = self::allowed( $data['severity'] ?? 'info', array( 'info', 'notice', 'warning', 'error', 'critical' ), 'info' );
		$data['actor_type'] = sanitize_key( $data['actor_type'] ?? 'system' );
		$data['actor_id'] = absint( $data['actor_id'] ?? 0 );
		$data['actor_label'] = WPHAVE_Activity_Privacy::sanitize_text( (string) ( $data['actor_label'] ?? '' ), 190 );
		$data['object_type'] = sanitize_key( $data['object_type'] ?? '' );
		$data['object_id'] = absint( $data['object_id'] ?? 0 );
		$data['object_subtype'] = sanitize_key( $data['object_subtype'] ?? '' );
		$data['object_label'] = WPHAVE_Activity_Privacy::sanitize_text( (string) ( $data['object_label'] ?? '' ), 190 );
		$data['source'] = sanitize_key( $data['source'] ?? 'system' );
		$data['request_id'] = preg_match( '/^[a-f0-9-]{36}$/i', (string) ( $data['request_id'] ?? '' ) ) ? $data['request_id'] : self::request_id();
		$data['assessment_status'] = self::allowed( $data['assessment_status'] ?? '', array( '', 'good', 'info', 'warning', 'critical' ), '' );
		$data['follow_up_status'] = self::allowed( $data['follow_up_status'] ?? '', array( '', 'pending', 'completed', 'dismissed' ), '' );
		$data['correlation_id'] = preg_match( '/^[a-f0-9-]{36}$/i', (string) ( $data['correlation_id'] ?? '' ) ) ? $data['correlation_id'] : '';
		$data['context'] = self::context_json( is_array( $context ) ? $context : array() );
		$data['search_text'] = self::search_text( $data );
		return $data;
	}

	/** Accept a valid MySQL datetime or fall back to the current UTC time. */

	private static function valid_datetime( string $value ): string {
		$datetime = DateTimeImmutable::createFromFormat( 'Y-m-d H:i:s', $value, new DateTimeZone( 'UTC' ) );
		return $datetime && $datetime->format( 'Y-m-d H:i:s' ) === $value ? $value : current_time( 'mysql', true );
	}

	/** Recursively redact and bound diagnostic context before storage. */
    
	private static function sanitize_context( array $context, int $depth = 0 ): array {
		if( $depth >= self::MAX_CONTEXT_DEPTH ) return array();
		if( isset( $context['field'] ) && ! WPHAVE_Activity_Changes::may_store_value( (string) $context['field'] ) ) {
			unset( $context['from'], $context['to'] );
			$context['changed'] = true;
		}
		$clean = array();
		foreach( array_slice( $context, 0, 50, true ) as $key => $value ) {
			$key = is_int( $key ) || ctype_digit( (string) $key ) ? (int) $key : sanitize_key( (string) $key );
			// SECURITY INVARIANT: Activity context reaches durable storage only after
			// sensitive fields are omitted wholesale and remaining scalars are redacted.
			if( $key === '' || ( is_string( $key ) && ( WPHAVE_Activity_Privacy::is_sensitive_key( $key ) || in_array( $key, array( 'content', 'body' ), true ) ) ) ) continue;
			if( is_array( $value ) ) $clean[$key] = self::sanitize_context( $value, $depth + 1 );
			elseif( is_bool( $value ) || is_int( $value ) || is_float( $value ) || is_null( $value ) ) $clean[$key] = $value;
			elseif( is_scalar( $value ) ) {
				$value = WPHAVE_Activity_Privacy::sanitize_text( (string) $value );
				$clean[$key] = in_array( $key, array( 'details', 'error_summary', 'error_detail' ), true ) ? self::sanitize_diagnostic_text( $value ) : $value;
			}
		}
		return $clean;
	}

	/** Encode a bounded context while preserving the most useful diagnostic fields. */

	private static function context_json( array $context ): string {
		$context = self::sanitize_context( $context );
		$json = wp_json_encode( $context, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		if( is_string( $json ) && strlen( $json ) <= self::MAX_CONTEXT_BYTES ) return $json;
		$bounded = array( 'context_truncated' => true );
		foreach( array( 'changes', 'assessment', 'follow_up', 'relations', 'route', 'method', 'http_status', 'error_code', 'phase' ) as $key ) if( isset( $context[$key] ) ) $bounded[$key] = $context[$key];
		if( isset( $bounded['changes'] ) ) $bounded['changes'] = array_slice( (array) $bounded['changes'], 0, 10 );
		if( isset( $bounded['relations'] ) ) $bounded['relations'] = array_slice( (array) $bounded['relations'], 0, 10 );
		$json = wp_json_encode( self::sanitize_context( $bounded ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		return is_string( $json ) && strlen( $json ) <= self::MAX_CONTEXT_BYTES ? $json : '{"context_truncated":true}';
	}

	/** Redact paths, query strings, credentials and personal addresses from error text. */

	private static function sanitize_diagnostic_text( string $text ): string {
		return WPHAVE_Security_Redactor::diagnostic_text(
			$text,
			500,
			array( ABSPATH, WP_CONTENT_DIR, WP_PLUGIN_DIR )
		);
	}

	/** Build a bounded searchable projection containing only already-safe values. */

	private static function search_text( array $data ): string {
		$context = json_decode( (string) ( $data['context'] ?? '{}' ), true );
		$parts = array( $data['event_type'] ?? '', $data['actor_label'] ?? '', $data['object_label'] ?? '' );
		foreach( (array) ( $context['changes'] ?? array() ) as $change ) {
			$parts[] = $change['label'] ?? '';
			if( array_key_exists( 'from', $change ) && is_scalar( $change['from'] ) ) $parts[] = (string) $change['from'];
			if( array_key_exists( 'to', $change ) && is_scalar( $change['to'] ) ) $parts[] = (string) $change['to'];
		}
		if( ! empty( $context['assessment']['summary'] ) ) $parts[] = $context['assessment']['summary'];
		return mb_substr( sanitize_text_field( implode( ' ', array_filter( $parts, 'is_scalar' ) ) ), 0, 1000 );
	}
}

WPHAVE_Activity_Log::init();
