<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Read repository for activity events.
 *
 * All SQL used to browse the append-only event store lives here so REST, CLI,
 * exports and future dashboards can share one constrained query contract.
 */

final class WPHAVE_Activity_Query {

	/**
	 * Return a filtered and paginated event collection.
	 *
	 * @param array $args Supported activity query arguments.
	 * @return array Rows and pagination metadata.
	 */

	public static function search( array $args = array() ): array {
		if( ! WPHAVE_Activity_Log::table_exists() ) return array( 'rows' => array(), 'total' => 0, 'page' => 1, 'per_page' => 30, 'has_more' => false, 'next_cursor' => 0 );
		global $wpdb;
		$args = wp_parse_args( $args, array( 'category' => '', 'status' => '', 'event_type' => '', 'actor_type' => '', 'assessment_status' => '', 'follow_up_status' => '', 'actor_id' => 0, 'object_type' => '', 'object_id' => 0, 'search' => '', 'after' => '', 'before' => '', 'before_id' => 0, 'orderby' => 'occurred_at', 'order' => 'desc', 'page' => 1, 'per_page' => 30, 'count_total' => true ) );
		$where = array( '1=1' );
		$values = array();

		foreach( array( 'category', 'status', 'event_type', 'actor_type', 'assessment_status', 'follow_up_status' ) as $field ) {
			$value = $field === 'event_type' ? self::event_type( (string) $args[$field] ) : sanitize_key( (string) $args[$field] );
			if( $value ) { $where[] = "{$field} = %s"; $values[] = $value; }
		}

		if( $args['actor_id'] ) { $where[] = 'actor_id = %d'; $values[] = absint( $args['actor_id'] ); }
		if( $args['object_type'] ) { $where[] = 'object_type = %s'; $values[] = sanitize_key( $args['object_type'] ); }
		if( $args['object_id'] ) { $where[] = 'object_id = %d'; $values[] = absint( $args['object_id'] ); }
		if( $args['before_id'] ) { $where[] = 'id < %d'; $values[] = absint( $args['before_id'] ); }
		if( $args['after'] ) { $where[] = 'occurred_at >= %s'; $values[] = self::date( (string) $args['after'] ); }
		if( $args['before'] ) { $where[] = 'occurred_at <= %s'; $values[] = self::date( (string) $args['before'] ); }
		if( $args['search'] ) {
			$like = '%' . $wpdb->esc_like( sanitize_text_field( (string) $args['search'] ) ) . '%';
			$where[] = '(actor_label LIKE %s OR object_label LIKE %s OR event_type LIKE %s OR search_text LIKE %s OR (search_text = \'\' AND context LIKE %s))';
			array_push( $values, $like, $like, $like, $like, $like );
		}

		$limit = min( 100, max( 1, absint( $args['per_page'] ) ) );
		$page = max( 1, absint( $args['page'] ) );
		$where_sql = implode( ' AND ', $where );
		$count_sql = 'SELECT COUNT(*) FROM ' . WPHAVE_Activity_Log::table() . ' WHERE ' . $where_sql;
		$total = $args['count_total'] ? (int) ( $values ? $wpdb->get_var( $wpdb->prepare( $count_sql, $values ) ) : $wpdb->get_var( $count_sql ) ) : 0;
		$query_limit = $args['count_total'] ? $limit : $limit + 1;
		$sortable = array( 'event_type', 'category', 'occurred_at', 'status' );
		$orderby = in_array( sanitize_key( $args['orderby'] ), $sortable, true ) ? sanitize_key( $args['orderby'] ) : 'occurred_at';
		$order = strtolower( sanitize_key( $args['order'] ) ) === 'asc' ? 'ASC' : 'DESC';
		$sql = 'SELECT * FROM ' . WPHAVE_Activity_Log::table() . ' WHERE ' . $where_sql . " ORDER BY {$orderby} {$order}, id {$order} LIMIT %d OFFSET %d";
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, array_merge( $values, array( $query_limit, ( $page - 1 ) * $limit ) ) ), ARRAY_A );
		$has_more = $args['count_total'] ? $page * $limit < $total : count( $rows ) > $limit;
		if( ! $args['count_total'] && $has_more ) $rows = array_slice( $rows, 0, $limit );

		return array( 'rows' => $rows, 'total' => $total, 'page' => $page, 'per_page' => $limit, 'has_more' => $has_more, 'next_cursor' => $has_more && $rows ? (int) end( $rows )['id'] : 0 );
	}

	/** Return one immutable event row, or null when it does not exist. */

	public static function find( int $event_id ): ?array {
		if( ! WPHAVE_Activity_Log::table_exists() ) return null;

		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . WPHAVE_Activity_Log::table() . ' WHERE id = %d', absint( $event_id ) ), ARRAY_A );

		return is_array( $row ) ? $row : null;
	}

	/** Return a bounded set of event rows by immutable ids. */

	public static function find_many( array $event_ids ): array {
		$event_ids = array_values( array_unique( array_filter( array_map( 'absint', $event_ids ) ) ) );
		if( ! WPHAVE_Activity_Log::table_exists() || ! $event_ids ) return array();
		global $wpdb;
		$event_ids = array_slice( $event_ids, 0, 50 );
		$placeholders = implode( ',', array_fill( 0, count( $event_ids ), '%d' ) );
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . WPHAVE_Activity_Log::table() . " WHERE id IN ({$placeholders}) ORDER BY id DESC", $event_ids ), ARRAY_A );
	}

	/** Return aggregate values used by navigation counts and filters. */

	public static function facets(): array {
		if( ! WPHAVE_Activity_Log::table_exists() ) return array( 'categories' => array(), 'category_counts' => array(), 'total' => 0, 'actors' => array() );
		$cached = wp_cache_get( 'facets', 'wphave-activity' );
		if( is_array( $cached ) ) return $cached;

		global $wpdb;
		$table = WPHAVE_Activity_Log::table();
		$category_rows = $wpdb->get_results( "SELECT category, COUNT(*) AS total FROM {$table} GROUP BY category ORDER BY category ASC", ARRAY_A );
		$category_counts = array_map( 'intval', array_column( $category_rows, 'total', 'category' ) );
		$actors = $wpdb->get_results( "SELECT actor_id AS id, MAX(actor_label) AS label FROM {$table} WHERE actor_id > 0 GROUP BY actor_id ORDER BY label ASC", ARRAY_A );

		$facets = array( 'categories' => wp_list_pluck( $category_rows, 'category' ), 'category_counts' => $category_counts, 'total' => array_sum( $category_counts ), 'actors' => $actors );
		wp_cache_set( 'facets', $facets, 'wphave-activity', 30 );
		return $facets;
	}

	/** Return recent events for one domain object, newest first. */

	public static function recent_for_object( string $object_type, int $object_id, int $limit = 20 ): array {
		if( ! WPHAVE_Activity_Log::table_exists() || ! $object_type || ! $object_id ) return array();
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . WPHAVE_Activity_Log::table() . ' WHERE object_type = %s AND object_id = %d ORDER BY id DESC LIMIT %d', sanitize_key( $object_type ), absint( $object_id ), min( 100, max( 1, $limit ) ) ), ARRAY_A );
	}

	/** Return recent lifecycle events matching any event-name prefix. */

	public static function recent_by_prefixes( array $prefixes, int $seconds, int $limit = 20 ): array {
		if( ! WPHAVE_Activity_Log::table_exists() || ! $prefixes ) return array();
		global $wpdb;
		$where = implode( ' OR ', array_fill( 0, count( $prefixes ), 'event_type LIKE %s' ) );
		$values = array_map( static fn( $prefix ) => $wpdb->esc_like( $prefix ) . '%', $prefixes );
		$values[] = gmdate( 'Y-m-d H:i:s', time() - max( 1, $seconds ) );
		$values[] = min( 100, max( 1, $limit ) );
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . WPHAVE_Activity_Log::table() . " WHERE ({$where}) AND occurred_at >= %s ORDER BY id DESC LIMIT %d", $values ), ARRAY_A );
	}

	/** Return unresolved warnings and critical assessments for the overview. */

	public static function attention( int $limit = 50 ): array {
		if( ! WPHAVE_Activity_Log::table_exists() ) return array();
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . WPHAVE_Activity_Log::table() . " WHERE assessment_status IN ('warning','critical') OR follow_up_status = 'pending' ORDER BY id DESC LIMIT %d", min( 100, max( 1, $limit ) ) ), ARRAY_A );
	}

	/** Return exact navigation counts for assessments and pending follow-ups. */

	public static function attention_counts(): array {
		if( ! WPHAVE_Activity_Log::table_exists() ) return array( 'total' => 0, 'critical' => 0, 'warning' => 0, 'pending' => 0 );
		global $wpdb;
		$table = WPHAVE_Activity_Log::table();
		$row = $wpdb->get_row( "SELECT COUNT(CASE WHEN assessment_status IN ('critical','warning') OR follow_up_status = 'pending' THEN 1 END) AS total, COUNT(CASE WHEN assessment_status = 'critical' THEN 1 END) AS critical, COUNT(CASE WHEN assessment_status = 'warning' THEN 1 END) AS warning, COUNT(CASE WHEN follow_up_status = 'pending' THEN 1 END) AS pending FROM {$table}", ARRAY_A );
		return array_map( 'intval', is_array( $row ) ? $row : array( 'total' => 0, 'critical' => 0, 'warning' => 0, 'pending' => 0 ) );
	}

	/** Find a later event that satisfies an event's declared follow-up. */

	public static function follow_up_completion( array $row, array $follow_up ): ?array {
		$event_type = trim( preg_replace( '/[^a-z0-9_.-]/', '', strtolower( (string) ( $follow_up['expected_event'] ?? '' ) ) ), '.' );
		if( ! $event_type || ! WPHAVE_Activity_Log::table_exists() ) return null;
		global $wpdb;
		$where = 'event_type = %s AND id > %d AND status = %s';
		$values = array( $event_type, (int) $row['id'], 'success' );
		if( ! empty( $follow_up['object_type'] ) && ! empty( $follow_up['object_id'] ) ) { $where .= ' AND object_type = %s AND object_id = %d'; $values[] = sanitize_key( $follow_up['object_type'] ); $values[] = absint( $follow_up['object_id'] ); }
		$completion = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . WPHAVE_Activity_Log::table() . " WHERE {$where} ORDER BY id ASC LIMIT 1", $values ), ARRAY_A );
		return is_array( $completion ) ? $completion : null;
	}

	/** Load bounded successful candidates used to resolve a page of follow-ups in memory. */
    
	public static function follow_up_candidates( array $event_types, int $after_id ): array {
		$event_types = array_values( array_unique( array_filter( array_map( array( __CLASS__, 'event_type' ), $event_types ) ) ) );
		if( ! $event_types || ! WPHAVE_Activity_Log::table_exists() ) return array();
		global $wpdb;
		$placeholders = implode( ',', array_fill( 0, count( $event_types ), '%s' ) );
		$values = array_merge( $event_types, array( max( 0, $after_id ) ) );
		return $wpdb->get_results( $wpdb->prepare( 'SELECT id,event_type,object_type,object_id FROM ' . WPHAVE_Activity_Log::table() . " WHERE event_type IN ({$placeholders}) AND id > %d AND status = 'success' ORDER BY id ASC LIMIT 1000", $values ), ARRAY_A );
	}

	/** Normalize an event-type filter without exposing the write service internals. */

	private static function event_type( string $value ): string {
		return trim( preg_replace( '/[^a-z0-9_.-]/', '', strtolower( $value ) ), '.' );
	}

	/** Convert a date filter to a UTC MySQL datetime. */
    
	private static function date( string $value ): string {
		$timestamp = strtotime( $value );
		return gmdate( 'Y-m-d H:i:s', $timestamp ?: time() );
	}
}
