<?php

/** Bootstrap Activity jobs that must only run in worker contexts. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/policy/privacy.php';
require_once __DIR__ . '/policy/policy.php';
require_once __DIR__ . '/storage/log.php';
require_once __DIR__ . '/capture/contracts.php';
require_once __DIR__ . '/capture/changes.php';
require_once __DIR__ . '/capture/observability.php';
require_once __DIR__ . '/capture/environment-monitor.php';
