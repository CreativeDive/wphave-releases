<?php

/** Bootstrap Activity services shared by public and management requests. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/policy/privacy.php';
require_once __DIR__ . '/policy/policy.php';
require_once __DIR__ . '/storage/log.php';
require_once __DIR__ . '/capture/contracts.php';
require_once __DIR__ . '/capture/observability.php';
require_once __DIR__ . '/storage/query.php';
require_once __DIR__ . '/capture/events.php';
require_once __DIR__ . '/settings.php';
require_once __DIR__ . '/capture/content.php';
require_once __DIR__ . '/capture/intelligence.php';
require_once __DIR__ . '/capture/hooks.php';
