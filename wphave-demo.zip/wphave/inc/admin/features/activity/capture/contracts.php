<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stable persistence identifiers shared by capture and worker entrypoints.
 *
 * Keeping these identifiers free of worker side effects lets public capture
 * hooks classify operational options without loading or scheduling the hourly
 * environment monitor.
 */

final class WPHAVE_Activity_Capture_Contracts {

	const ENVIRONMENT_SNAPSHOT_OPTION = 'wphave_activity_environment_snapshot';
	const ENVIRONMENT_LOCK_OPTION = 'wphave_activity_environment_snapshot_lock';

	/**
	 * OBSERVABILITY INVARIANT: High-frequency diagnostic storage never creates Activity events.
	 *
	 * Observing these writes would add recursive work to every measurement and
	 * could make a diagnostics failure break an unrelated settings mutation.
	 */

	const DIAGNOSTIC_OPTIONS = array(
		'wphave_request_profiler_profiles',
		'wphave_request_profiler_summaries',
	);

}
