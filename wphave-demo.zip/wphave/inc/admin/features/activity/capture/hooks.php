<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WordPress lifecycle adapter for core content, identity and extension events.
 *
 * Hooks capture completed mutations and translate them into stable semantic
 * events. Operational records, secrets and high-volume internal post types are
 * excluded here before they reach the central write service.
 */

final class WPHAVE_Activity_Hooks {

	private static array $deleted_posts = array();
	private static array $comment_changes = array();
	private static array $terms_before = array();
	private static array $extension_versions = array();
	private static array $deleted_extensions = array();
	private static array $post_meta_before = array();
	private static array $registering_users = array();
	private static array $deleted_navigation = array();

	/** Register all supported WordPress mutation hooks. */

	public static function init(): void {
		add_action( 'transition_post_status', array( __CLASS__, 'post_status_changed' ), 10, 3 );
		add_action( 'post_updated', array( __CLASS__, 'post_updated' ), 10, 3 );
		add_action( 'set_object_terms', array( __CLASS__, 'post_terms_updated' ), 10, 6 );
		add_action( 'before_delete_post', array( __CLASS__, 'before_delete_post' ), 10, 2 );
		add_action( 'deleted_post', array( __CLASS__, 'post_deleted' ), 10, 2 );
		add_action( 'add_attachment', array( __CLASS__, 'attachment_created' ) );
		add_action( 'attachment_updated', array( __CLASS__, 'attachment_updated' ), 10, 3 );
		add_action( 'delete_attachment', array( __CLASS__, 'attachment_deleted' ), 10, 2 );
		add_action( 'wp_insert_comment', array( __CLASS__, 'comment_created' ), 10, 2 );
		add_filter( 'wp_update_comment_data', array( __CLASS__, 'capture_comment_changes' ), 10, 3 );
		add_action( 'edit_comment', array( __CLASS__, 'comment_updated' ), 10, 2 );
		add_action( 'transition_comment_status', array( __CLASS__, 'comment_status_changed' ), 10, 3 );
		add_action( 'deleted_comment', array( __CLASS__, 'comment_deleted' ), 10, 2 );
		add_action( 'created_term', array( __CLASS__, 'term_created' ), 10, 3 );
		add_action( 'edit_terms', array( __CLASS__, 'capture_term' ), 10, 2 );
		add_action( 'edited_term', array( __CLASS__, 'term_updated' ), 10, 3 );
		add_action( 'delete_term', array( __CLASS__, 'term_deleted' ), 10, 4 );
		add_action( 'pre_delete_term', array( __CLASS__, 'capture_navigation_deletion' ), 10, 2 );
		add_filter( 'insert_user_meta', array( __CLASS__, 'capture_new_user' ), 10, 4 );
		add_action( 'user_register', array( __CLASS__, 'user_created' ), 10, 2 );
		add_action( 'profile_update', array( __CLASS__, 'user_updated' ), 10, 3 );
		add_action( 'deleted_user', array( __CLASS__, 'user_deleted' ), 10, 3 );
		add_action( 'set_user_role', array( __CLASS__, 'user_role_changed' ), 10, 3 );
		add_action( 'add_user_role', array( __CLASS__, 'user_role_added' ), 10, 2 );
		add_action( 'remove_user_role', array( __CLASS__, 'user_role_removed' ), 10, 2 );
		add_action( 'after_password_reset', array( __CLASS__, 'password_reset' ), 10, 2 );
		add_action( 'wp_create_application_password', array( __CLASS__, 'application_password_created' ), 10, 3 );
		add_action( 'wp_update_application_password', array( __CLASS__, 'application_password_updated' ), 10, 3 );
		add_action( 'wp_delete_application_password', array( __CLASS__, 'application_password_deleted' ), 10, 2 );
		add_action( 'wp_login', array( __CLASS__, 'user_logged_in' ), 10, 2 );
		add_action( 'wp_logout', array( __CLASS__, 'user_logged_out' ), 10, 1 );
		add_action( 'wp_login_failed', array( __CLASS__, 'login_failed' ), 10, 2 );
		add_action( 'activated_plugin', array( __CLASS__, 'plugin_activated' ), 10, 2 );
		add_action( 'deactivated_plugin', array( __CLASS__, 'plugin_deactivated' ), 10, 2 );
		add_action( 'switch_theme', array( __CLASS__, 'theme_switched' ), 10, 3 );
		add_filter( 'upgrader_pre_install', array( __CLASS__, 'capture_upgrade_versions' ), 10, 2 );
		add_action( 'upgrader_process_complete', array( __CLASS__, 'upgrade_completed' ), 10, 2 );
		add_action( 'automatic_updates_complete', array( __CLASS__, 'automatic_updates_completed' ) );
		add_action( 'delete_plugin', array( __CLASS__, 'capture_plugin_deletion' ) );
		add_action( 'deleted_plugin', array( __CLASS__, 'plugin_deleted' ), 10, 2 );
		add_action( 'delete_theme', array( __CLASS__, 'capture_theme_deletion' ) );
		add_action( 'deleted_theme', array( __CLASS__, 'theme_deleted' ), 10, 2 );
		add_action( 'updated_option', array( __CLASS__, 'option_updated' ), 10, 3 );
		add_action( 'updated_site_option', array( __CLASS__, 'site_option_updated' ), 10, 4 );
		add_action( 'add_site_option', array( __CLASS__, 'site_option_added' ), 10, 3 );
		add_action( 'added_option', array( __CLASS__, 'option_added' ), 10, 2 );
		add_action( 'deleted_option', array( __CLASS__, 'option_deleted' ) );
		add_filter( 'update_post_metadata', array( __CLASS__, 'capture_post_meta' ), 10, 5 );
		add_action( 'updated_post_meta', array( __CLASS__, 'post_meta_updated' ), 10, 4 );
		add_action( 'added_post_meta', array( __CLASS__, 'post_meta_added' ), 10, 4 );
		add_action( 'deleted_post_meta', array( __CLASS__, 'post_meta_deleted' ), 10, 4 );
		add_action( 'wp_create_nav_menu', array( __CLASS__, 'navigation_created' ) );
		add_action( 'wp_update_nav_menu', array( __CLASS__, 'navigation_updated' ) );
		add_action( 'wp_update_nav_menu_item', array( __CLASS__, 'navigation_item_updated' ) );
		add_action( 'wp_delete_nav_menu', array( __CLASS__, 'navigation_deleted' ) );
		add_action( 'wphave/database/schema_error', array( __CLASS__, 'database_schema_failed' ) );
	}

	/** Record meaningful post publication-state transitions. */

	public static function post_status_changed( string $new_status, string $old_status, WP_Post $post ): void {
		if( $new_status === $old_status || self::skip_post( $post ) ) return;
		$action = in_array( $old_status, array( 'new', 'auto-draft' ), true ) ? 'created' : ( $new_status === 'publish' ? 'published' : ( $new_status === 'trash' ? 'trashed' : 'status_changed' ) );
		self::post_event( 'content.' . $action, $post, $action, array( 'changes' => WPHAVE_Activity_Changes::compare( array( 'status' => $old_status ), array( 'status' => $new_status ), array( 'status' => __( 'Status', 'wphave' ) ) ) ) );
	}

	/** Record post field changes that did not also change publication state. */

	public static function post_updated( int $post_id, WP_Post $after, WP_Post $before ): void {
		if( self::skip_post( $after ) ) return;
		if( $after->post_status === 'trash' && $before->post_status !== 'trash' ) return;
		$changes = WPHAVE_Activity_Content::changes( $before, $after );
		if( $changes ) self::post_event( 'content.updated', $after, 'updated', array( 'changes' => $changes ) );
	}

	/** Record category, tag and custom-taxonomy assignments for content. */

	public static function post_terms_updated( int $post_id, $terms, array $tt_ids, string $taxonomy, bool $append, array $old_tt_ids ): void {
		$post = get_post( $post_id );
		if( ! $post || $tt_ids === $old_tt_ids ) return;
		if( $post->post_type === 'attachment' && $taxonomy === 'wphave_media_folder' ) {
			$changes = WPHAVE_Activity_Changes::compare( array( 'media_folder' => self::term_labels_from_tt_ids( $old_tt_ids ) ), array( 'media_folder' => self::term_labels_from_tt_ids( $tt_ids ) ), array( 'media_folder' => __( 'Media folder', 'wphave' ) ) );
			if( $changes ) self::attachment_event( 'media.folder_assigned', $post_id, 'updated', $post, array( 'append' => $append, 'changes' => $changes ) );
			return;
		}
		if( self::skip_post( $post ) ) return;
		$taxonomy_object = get_taxonomy( $taxonomy );
		$old_terms = self::term_labels_from_tt_ids( $old_tt_ids );
		$new_terms = self::term_labels_from_tt_ids( $tt_ids );
		$field = 'terms_' . $taxonomy;
		$label = $taxonomy_object->labels->name ?? ucwords( str_replace( '_', ' ', $taxonomy ) );
		$changes = WPHAVE_Activity_Changes::compare( array( $field => $old_terms ), array( $field => $new_terms ), array( $field => $label ) );
		if( $changes ) self::post_event( 'content.terms_updated', $post, 'updated', array( 'taxonomy' => $taxonomy, 'append' => $append, 'changes' => $changes ) );
	}

	/** Snapshot a post before WordPress removes its data. */

	public static function before_delete_post( int $post_id, WP_Post $post ): void {
		if( ! self::skip_post( $post ) ) self::$deleted_posts[$post_id] = $post;
	}

	/** Record permanent post deletion from the request-local snapshot. */

	public static function post_deleted( int $post_id ): void {
		$post = self::$deleted_posts[$post_id] ?? null;
		if( ! $post ) return;
		self::post_event( 'content.deleted', $post, 'deleted' );
		unset( self::$deleted_posts[$post_id] );
	}

	/** Record a newly uploaded media attachment. */

	public static function attachment_created( int $attachment_id ): void {
		self::attachment_event( 'media.uploaded', $attachment_id, 'uploaded' );
	}

	/** Record attachment metadata changes. */

	public static function attachment_updated( int $attachment_id, WP_Post $after, WP_Post $before ): void {
		$fields = array( 'post_title', 'post_excerpt', 'post_content', 'post_parent' );
		$before_values = array();
		$after_values = array();
		foreach( $fields as $field ) { $before_values[$field] = $before->$field; $after_values[$field] = $after->$field; }
		$changes = WPHAVE_Activity_Changes::compare( $before_values, $after_values, array( 'post_title' => __( 'Title', 'wphave' ), 'post_excerpt' => __( 'Caption', 'wphave' ), 'post_content' => __( 'Description', 'wphave' ), 'post_parent' => __( 'Uploaded to', 'wphave' ) ) );
		if( $changes ) self::attachment_event( 'media.updated', $attachment_id, 'updated', $after, array( 'changes' => $changes ) );
	}

	/** Record attachment deletion while its post snapshot is available. */

	public static function attachment_deleted( int $attachment_id, WP_Post $post ): void {
		self::attachment_event( 'media.deleted', $attachment_id, 'deleted', $post );
	}

	/** Record creation of a WordPress comment. */

	public static function comment_created( int $comment_id, WP_Comment $comment ): void {
		self::comment_event( 'comment.created', $comment, 'created' );
	}

	/**
	 * Capture safe comment field changes before WordPress persists them.
	 *
	 * WordPress passes the existing database fields as an associative array for
	 * this filter, not as the `WP_Comment` object used by adjacent comment hooks.
	 */

	public static function capture_comment_changes( array $data, array $comment, array $commentarr ): array {
		$fields = array( 'comment_author', 'comment_author_email', 'comment_author_url', 'comment_content' );
		$before = array();
		$after = array();
		foreach( $fields as $field ) { $before[$field] = $comment[$field] ?? ''; $after[$field] = $data[$field] ?? $before[$field]; }
		$comment_id = absint( $comment['comment_ID'] ?? $commentarr['comment_ID'] ?? 0 );
		if( $comment_id ) self::$comment_changes[$comment_id] = WPHAVE_Activity_Changes::compare( $before, $after, array( 'comment_author' => __( 'Author name', 'wphave' ), 'comment_author_email' => __( 'Author email', 'wphave' ), 'comment_author_url' => __( 'Author website', 'wphave' ), 'comment_content' => __( 'Comment', 'wphave' ) ) );
		return $data;
	}

	/** Record edits to an existing comment. */

	public static function comment_updated( int $comment_id ): void {
		$comment = get_comment( $comment_id );
		$changes = self::$comment_changes[$comment_id] ?? array();
		unset( self::$comment_changes[$comment_id] );
		if( $comment && $changes ) self::comment_event( 'comment.updated', $comment, 'updated', array( 'changes' => $changes ) );
	}

	/** Record comment moderation-state transitions. */

	public static function comment_status_changed( string $new_status, string $old_status, WP_Comment $comment ): void {
		if( $new_status !== $old_status && ! in_array( $new_status, array( 'delete', 'trash' ), true ) ) self::comment_event( 'comment.status_changed', $comment, 'status_changed', array( 'changes' => WPHAVE_Activity_Changes::compare( array( 'status' => $old_status ), array( 'status' => $new_status ), array( 'status' => __( 'Status', 'wphave' ) ) ) ) );
	}

	/** Record permanent comment deletion. */

	public static function comment_deleted( string $comment_id, WP_Comment $comment ): void {
		self::comment_event( 'comment.deleted', $comment, 'deleted' );
	}

	/** Record creation of a taxonomy term. */

	public static function term_created( int $term_id, int $tt_id, string $taxonomy ): void {
		if( $taxonomy === 'nav_menu' ) return;
		self::term_event( 'taxonomy.term_created', $term_id, $taxonomy, 'created' );
	}

	/** Snapshot a term before WordPress changes its persisted fields. */

	public static function capture_term( int $term_id, string $taxonomy ): void {
		$term = get_term( $term_id, $taxonomy );
		if( $term && ! is_wp_error( $term ) ) self::$terms_before[$taxonomy . ':' . $term_id] = $term;
	}

	/** Record updates to a taxonomy term. */

	public static function term_updated( int $term_id, int $tt_id, string $taxonomy ): void {
		if( $taxonomy === 'nav_menu' ) return;
		$key = $taxonomy . ':' . $term_id;
		$before = self::$terms_before[$key] ?? null;
		unset( self::$terms_before[$key] );
		$after = get_term( $term_id, $taxonomy );
		if( ! $before || ! $after || is_wp_error( $after ) ) return;
		$changes = WPHAVE_Activity_Changes::compare( array( 'name' => $before->name, 'slug' => $before->slug, 'description' => $before->description, 'parent' => $before->parent ), array( 'name' => $after->name, 'slug' => $after->slug, 'description' => $after->description, 'parent' => $after->parent ), array( 'name' => __( 'Name', 'wphave' ), 'slug' => __( 'Slug', 'wphave' ), 'description' => __( 'Description', 'wphave' ), 'parent' => __( 'Parent', 'wphave' ) ) );
		if( $changes ) self::term_event( 'taxonomy.term_updated', $term_id, $taxonomy, 'updated', null, array( 'changes' => $changes ) );
	}

	/** Record deletion of a taxonomy term from its supplied snapshot. */

	public static function term_deleted( int $term_id, int $tt_id, string $taxonomy, $deleted_term ): void {
		if( $taxonomy === 'nav_menu' ) return;
		self::term_event( 'taxonomy.term_deleted', $term_id, $taxonomy, 'deleted', $deleted_term instanceof WP_Term ? $deleted_term : null );
	}

	/** Preserve a navigation label before WordPress deletes its taxonomy term. */

	public static function capture_navigation_deletion( int $term_id, string $taxonomy ): void {
		if( $taxonomy !== 'nav_menu' ) return;
		$menu = wp_get_nav_menu_object( $term_id );
		if( $menu ) self::$deleted_navigation[$term_id] = $menu->name;
	}

	/** Mark a user insertion so its initial role hooks do not create duplicate activity. */

	public static function capture_new_user( array $meta, WP_User $user, bool $update, array $userdata ): array {
		if( ! $update ) self::$registering_users[$user->ID] = true;
		return $meta;
	}

	/** Record creation of a WordPress user account. */

	public static function user_created( int $user_id ): void {
		$user = get_userdata( $user_id );
		unset( self::$registering_users[$user_id] );
		if( $user ) self::user_event( 'user.created', $user, 'created', array( 'role' => (string) ( $user->roles[0] ?? '' ) ) );
	}

	/** Record profile updates and actual email-address changes. */

	public static function user_updated( int $user_id, WP_User $old_user ): void {
		$user = get_userdata( $user_id );
		if( ! $user ) return;
		$before = array( 'display_name' => $old_user->display_name, 'user_email' => $old_user->user_email, 'user_url' => $old_user->user_url );
		$after = array( 'display_name' => $user->display_name, 'user_email' => $user->user_email, 'user_url' => $user->user_url );
		$changes = WPHAVE_Activity_Changes::compare( $before, $after, array( 'display_name' => __( 'Display name', 'wphave' ), 'user_email' => __( 'Email address', 'wphave' ), 'user_url' => __( 'Website', 'wphave' ) ) );
		if( $changes ) self::user_event( 'user.updated', $user, 'updated', array( 'changes' => $changes ) );
		if( $old_user->user_email !== $user->user_email ) self::user_event( 'security.email_changed', $user, 'email_changed', array(), 'security' );
	}

	/** Record deletion and optional content reassignment of a user. */

	public static function user_deleted( int $user_id, ?int $reassign, WP_User $user ): void {
		self::user_event( 'user.deleted', $user, 'deleted', array( 'reassigned_to' => absint( $reassign ) ) );
	}

	/** Record replacement of a user's primary role. */

	public static function user_role_changed( int $user_id, string $role, array $old_roles ): void {
		if( isset( self::$registering_users[$user_id] ) ) return;
		$user = get_userdata( $user_id );
		if( $user ) self::user_event( 'user.role_changed', $user, 'role_changed', array( 'changes' => WPHAVE_Activity_Changes::compare( array( 'roles' => $old_roles ), array( 'roles' => array( $role ) ), array( 'roles' => __( 'Roles', 'wphave' ) ) ) ) );
	}

	/** Record an additional role assigned to a user. */

	public static function user_role_added( int $user_id, string $role ): void {
		if( isset( self::$registering_users[$user_id] ) || self::called_from_set_role() ) return;
		$user = get_userdata( $user_id );
		if( $user ) self::user_event( 'user.role_added', $user, 'role_added', array( 'role' => $role ) );
	}

	/** Record removal of an additional user role. */

	public static function user_role_removed( int $user_id, string $role ): void {
		if( isset( self::$registering_users[$user_id] ) || self::called_from_set_role() ) return;
		$user = get_userdata( $user_id );
		if( $user ) self::user_event( 'user.role_removed', $user, 'role_removed', array( 'role' => $role ) );
	}

	/** Record completion of a password reset without storing credentials. */

	public static function password_reset( WP_User $user ): void {
		self::user_event( 'security.password_reset', $user, 'password_reset', array(), 'security' );
	}

	/** Record creation of an application password without its secret. */

	public static function application_password_created( int $user_id, array $item ): void {
		self::application_password_event( 'created', $user_id, $item );
	}

	/** Record an application-password metadata update. */

	public static function application_password_updated( int $user_id, array $item ): void {
		self::application_password_event( 'updated', $user_id, $item );
	}

	/** Record deletion of an application password. */

	public static function application_password_deleted( int $user_id ): void {
		self::application_password_event( 'deleted', $user_id );
	}

	/** Record a successful WordPress sign-in. */

	public static function user_logged_in( string $login, WP_User $user ): void {
		self::user_event( 'security.login_succeeded', $user, 'login', array(), 'security', true );
	}

	/** Record a WordPress sign-out when the user snapshot is available. */

	public static function user_logged_out( int $user_id ): void {
		$user = get_userdata( $user_id );
		if( $user ) self::user_event( 'security.logout', $user, 'logout', array(), 'security', true );
	}

	/** Record a rate-limited failed sign-in attempt. */

	public static function login_failed( string $username, $error ): void {
		$ip = class_exists( 'WPHAVE_Client_IP' ) ? WPHAVE_Client_IP::resolve() : '';
		$identity = $ip ?: sanitize_user( $username );
		$count = class_exists( 'WPHAVE_Rate_Limiter' ) ? WPHAVE_Rate_Limiter::increment( 'wphave_activity_login_' . md5( $identity . wp_salt( 'auth' ) ), 5 * MINUTE_IN_SECONDS ) : 1;
		if( ! in_array( $count, array( 1, 5 ), true ) ) return;
		$aggregated = $count === 5;
		WPHAVE_Activity_Log::record( 'security.login_failed', array(
			'category' => 'security',
			'action' => 'login_failed',
			'status' => 'failure',
			'severity' => 'warning',
			'actor_type' => 'unknown',
			'actor_label' => $aggregated ? __( 'Multiple attempts', 'wphave' ) : sanitize_user( $username ),
			'object_type' => 'user',
			'object_label' => $aggregated ? __( 'Multiple accounts', 'wphave' ) : sanitize_user( $username ),
			'context' => array( 'error_code' => is_wp_error( $error ) ? $error->get_error_code() : '', 'attempt_count' => $count, 'aggregated' => $aggregated ),
		) );
	}

	/** Record plugin activation, including network-wide activation. */

	public static function plugin_activated( string $plugin, bool $network_wide ): void {
		$details = self::extension_details( 'plugin', $plugin );
		self::extension_event( 'system.plugin_activated', 'plugin', $plugin, 'activated', array( 'network_wide' => $network_wide, 'version' => $details['version'], 'changes' => WPHAVE_Activity_Changes::compare( array( 'status' => 'inactive' ), array( 'status' => 'active' ), array( 'status' => __( 'Status', 'wphave' ) ) ) ), $details['label'] );
	}

	/** Record plugin deactivation, including network-wide deactivation. */

	public static function plugin_deactivated( string $plugin, bool $network_wide ): void {
		$details = self::extension_details( 'plugin', $plugin );
		self::extension_event( 'system.plugin_deactivated', 'plugin', $plugin, 'deactivated', array( 'network_wide' => $network_wide, 'version' => $details['version'], 'changes' => WPHAVE_Activity_Changes::compare( array( 'status' => 'active' ), array( 'status' => 'inactive' ), array( 'status' => __( 'Status', 'wphave' ) ) ) ), $details['label'] );
	}

	/** Record a WordPress theme switch. */

	public static function theme_switched( string $new_name, WP_Theme $new_theme, WP_Theme $old_theme ): void {
		self::extension_event( 'system.theme_switched', 'theme', $new_theme->get_stylesheet(), 'switched', array( 'version' => $new_theme->get( 'Version' ), 'changes' => WPHAVE_Activity_Changes::compare( array( 'active_theme' => $old_theme->get( 'Name' ) ), array( 'active_theme' => $new_name ), array( 'active_theme' => __( 'Active theme', 'wphave' ) ) ) ), $new_name );
	}

	/** Snapshot installed extension versions immediately before an upgrade. */

	public static function capture_upgrade_versions( $response, array $options ) {
		$type = sanitize_key( $options['type'] ?? '' );
		$items = array_values( array_filter( (array) ( $options['plugins'] ?? $options['themes'] ?? $options['plugin'] ?? $options['theme'] ?? array() ) ) );
		if( $type === 'core' ) {
			global $wp_version;
			self::$extension_versions['core:wordpress'] = (string) $wp_version;
		} else {
			foreach( $items as $item ) self::$extension_versions[$type . ':' . $item] = self::extension_details( $type, (string) $item )['version'];
		}
		return $response;
	}

	/** Record completed core, plugin and theme install/update operations. */

	public static function upgrade_completed( $upgrader, array $options ): void {
		$type = sanitize_key( $options['type'] ?? 'system' );
		$operation = sanitize_key( $options['action'] ?? 'updated' );
		$items = array_values( array_filter( (array) ( $options['plugins'] ?? $options['themes'] ?? $options['plugin'] ?? $options['theme'] ?? array() ) ) );
		if( $type === 'core' ) $items = array( 'wordpress' );
		$event_action = $operation === 'install' ? 'installed' : 'updated';
		$automatic = ! empty( $options['autoupdate'] ) || ( is_object( $upgrader ) && isset( $upgrader->skin ) && $upgrader->skin instanceof Automatic_Upgrader_Skin );
		foreach( $items as $item ) {
			$details = self::extension_details( $type, (string) $item );
			$old_version = self::$extension_versions[$type . ':' . $item] ?? null;
			unset( self::$extension_versions[$type . ':' . $item] );
			self::extension_event( 'system.' . $type . '_' . $event_action, $type, (string) $item, $event_action, array( 'automatic' => $automatic, 'bulk' => ! empty( $options['bulk'] ), 'version' => $details['version'], 'changes' => WPHAVE_Activity_Changes::compare( array( 'version' => $old_version ), array( 'version' => $details['version'] ), array( 'version' => __( 'Version', 'wphave' ) ) ) ), $details['label'] );
		}
	}

	/** Record failed automatic extension and core updates omitted by completion hooks. */

	public static function automatic_updates_completed( array $results ): void {
		foreach( array( 'plugin', 'theme', 'core' ) as $type ) foreach( (array) ( $results[$type] ?? array() ) as $result ) {
			$outcome = is_object( $result ) ? ( $result->result ?? null ) : null;
			if( ! is_wp_error( $outcome ) ) continue;
			$item = is_object( $result ) ? ( $result->item ?? $result->name ?? $type ) : $type;
			if( $item instanceof WP_Theme ) $item = $item->get_stylesheet();
			if( is_array( $item ) ) $item = $item['plugin'] ?? $item['theme'] ?? $type;
			$slug = sanitize_text_field( is_scalar( $item ) ? (string) $item : $type );
			self::extension_event( 'system.' . $type . '_update_failed', $type, $slug, 'failed', array( 'automatic' => true, 'error_code' => $outcome->get_error_code() ), $slug );
		}
	}

	/** Record creation of a navigation menu without persisting its items. */

	public static function navigation_created( int $menu_id ): void {
		self::navigation_event( 'content.navigation_created', $menu_id, 'created' );
	}

	/** Record menu-structure changes without persisting menu item contents. */

	public static function navigation_updated( int $menu_id ): void {
		self::navigation_event( 'content.navigation_updated', $menu_id, 'updated' );
	}

	/** Treat item creation, editing and ordering as one navigation change. */

	public static function navigation_item_updated( int $menu_id ): void {
		if( $menu_id ) self::navigation_event( 'content.navigation_updated', $menu_id, 'updated' );
	}

	/** Record deletion while WordPress can still resolve the menu label. */

	public static function navigation_deleted( int $menu_id ): void {
		$label = self::$deleted_navigation[$menu_id] ?? '';
		unset( self::$deleted_navigation[$menu_id] );
		self::navigation_event( 'content.navigation_deleted', $menu_id, 'deleted', $label );
	}

	/** Persist a normalized navigation event with request-local deduplication. */

	private static function navigation_event( string $event, int $menu_id, string $action, string $known_label = '' ): void {
		$menu = wp_get_nav_menu_object( $menu_id );
		WPHAVE_Activity_Log::record( $event, array( 'category' => 'content', 'action' => $action, 'object_type' => 'navigation', 'object_id' => $menu_id, 'object_label' => $known_label ?: ( $menu ? $menu->name : sprintf( __( 'Menu #%d', 'wphave' ), $menu_id ) ), 'context' => array( 'structure_changed' => true ), 'deduplicate' => true ) );
	}

	/** Record a schema failure without copying database error text into the log. */

	public static function database_schema_failed( string $schema ): void {
		WPHAVE_Activity_Log::record( 'system.database_migration_failed', array( 'category' => 'system', 'action' => 'failed', 'status' => 'failure', 'severity' => 'critical', 'actor_type' => 'system', 'object_type' => 'database', 'object_label' => __( 'Database schema', 'wphave' ), 'context' => array( 'schema' => sanitize_key( $schema ) ) ) );
	}

	/** Snapshot plugin identity before WordPress removes its files. */

	public static function capture_plugin_deletion( string $plugin ): void {
		self::$deleted_extensions['plugin:' . $plugin] = self::extension_details( 'plugin', $plugin );
	}

	/** Record successful plugin deletion. */

	public static function plugin_deleted( string $plugin, bool $deleted ): void {
		$details = self::$deleted_extensions['plugin:' . $plugin] ?? array( 'label' => $plugin, 'version' => '' );
		unset( self::$deleted_extensions['plugin:' . $plugin] );
		if( $deleted ) self::extension_event( 'system.plugin_deleted', 'plugin', $plugin, 'deleted', array( 'version' => $details['version'] ), $details['label'] );
	}

	/** Snapshot theme identity before WordPress removes its files. */

	public static function capture_theme_deletion( string $stylesheet ): void {
		self::$deleted_extensions['theme:' . $stylesheet] = self::extension_details( 'theme', $stylesheet );
	}

	/** Record successful theme deletion. */

	public static function theme_deleted( string $stylesheet, bool $deleted ): void {
		$details = self::$deleted_extensions['theme:' . $stylesheet] ?? array( 'label' => $stylesheet, 'version' => '' );
		unset( self::$deleted_extensions['theme:' . $stylesheet] );
		if( $deleted ) self::extension_event( 'system.theme_deleted', 'theme', $stylesheet, 'deleted', array( 'version' => $details['version'] ), $details['label'] );
	}

	/** Record an allowlisted option update outside REST requests. */

	public static function option_updated( string $option, $old_value, $value ): void {
		if( $option === 'wphave_license' ) { self::license_updated( $old_value, $value ); return; }
		if( str_starts_with( $option, 'theme_mods_' ) ) { self::theme_mods_updated( $option, $old_value, $value ); return; }
		if( ! self::should_log_option( $option ) || $old_value === $value ) return;
		self::option_event( 'updated', $option, $old_value, $value );
	}

	/** Record theme customization fields while protected or structured values remain value-free. */

	private static function theme_mods_updated( string $option, $old_value, $value ): void {
		$changes = WPHAVE_Activity_Settings::changes( $option, $old_value, $value );
		if( $changes ) WPHAVE_Activity_Log::record( 'settings.theme_customization_updated', array( 'category' => 'settings', 'action' => 'updated', 'object_type' => 'theme', 'object_label' => wp_get_theme()->get( 'Name' ), 'context' => array( 'changes' => $changes ) ) );
	}

	/** Record a network-owned license state transition without license proof data. */

	public static function site_option_updated( string $option, $value, $old_value, int $network_id ): void {
		if( $option === 'wphave_license' ) { self::license_updated( $old_value, $value, $network_id ); return; }
		if( in_array( $option, array( 'site_name', 'admin_email', 'registration', 'add_new_users', 'default_user_role' ), true ) && $old_value !== $value ) self::option_event( 'updated', $option, $old_value, $value );
	}

	/** Record creation of an allowlisted option outside REST requests. */

	public static function option_added( string $option, $value ): void {
		if( $option === 'wphave_license' ) {
			self::license_updated( array(), $value );
			return;
		}
		if( self::should_log_option( $option ) ) self::option_event( 'added', $option, null, $value );
	}

	/** Record initial network activation through the same safe status snapshot. */

	public static function site_option_added( string $option, $value, int $network_id ): void {
		if( $option === 'wphave_license' ) {
			self::license_updated( array(), $value, $network_id );
		}
	}

	/** Record deletion of an allowlisted option outside REST requests. */

	public static function option_deleted( string $option ): void {
		if( self::should_log_option( $option ) ) self::option_event( 'deleted', $option );
	}

	/** Snapshot an audited post-meta value before WordPress updates it. */

	public static function capture_post_meta( $check, int $post_id, string $meta_key, $meta_value, $prev_value ) {
		if( self::is_audited_post_meta( $meta_key ) ) self::$post_meta_before[$post_id . ':' . $meta_key] = get_post_meta( $post_id, $meta_key, true );
		return $check;
	}

	/** Record an audited post-meta update with safe before/after values. */

	public static function post_meta_updated( int $meta_id, int $post_id, string $meta_key, $meta_value ): void {
		if( ! self::is_audited_post_meta( $meta_key ) ) return;
		$key = $post_id . ':' . $meta_key;
		$before = self::$post_meta_before[$key] ?? null;
		unset( self::$post_meta_before[$key] );
		self::post_meta_event( $post_id, $meta_key, $before, $meta_value );
	}

	/** Record creation of an audited post-meta value. */

	public static function post_meta_added( int $meta_id, int $post_id, string $meta_key, $meta_value ): void {
		if( self::is_audited_post_meta( $meta_key ) ) self::post_meta_event( $post_id, $meta_key, null, $meta_value );
	}

	/** Record deletion of an audited post-meta value. */

	public static function post_meta_deleted( array $meta_ids, int $post_id, string $meta_key, $meta_value ): void {
		if( ! isset( self::$deleted_posts[$post_id] ) && self::is_audited_post_meta( $meta_key ) ) self::post_meta_event( $post_id, $meta_key, $meta_value, null );
	}

	/** Build a settings event without persisting option values. */

	private static function option_event( string $action, string $option, $old_value = null, $value = null ): void {
		$changes = WPHAVE_Activity_Settings::changes( $option, $action === 'added' ? null : $old_value, $action === 'deleted' ? null : $value );
		if( ! $changes ) return;
		WPHAVE_Activity_Log::record( 'settings.updated', array(
			'category' => 'settings',
			'action' => $action,
			'object_type' => 'option',
			'object_label' => WPHAVE_Activity_Settings::object_label( $option, $changes ),
			'context' => array( 'option' => $option, 'changes' => $changes ),
		) );
	}

	/** Record only public license-state booleans and dates, never keys or tokens. */

	private static function license_updated( $old_value, $value, int $network_id = 0 ): void {
		$before = self::license_state( $old_value );
		$after = self::license_state( $value );
		$labels = array( 'connected' => __( 'License connected', 'wphave' ), 'valid' => __( 'License valid', 'wphave' ), 'authorized' => __( 'Authorized access', 'wphave' ), 'beta' => __( 'Beta access', 'wphave' ), 'local_license_required' => __( 'Local license required', 'wphave' ), 'expiration' => __( 'Expiration', 'wphave' ) );
		$changes = WPHAVE_Activity_Changes::compare( $before, $after, $labels );
		if( ! $changes ) return;
		WPHAVE_Activity_Log::record( 'license.status_changed', array( 'category' => 'security', 'action' => 'updated', 'severity' => empty( $after['connected'] ) ? 'warning' : 'info', 'object_type' => 'license', 'object_label' => __( 'WPHAVE license', 'wphave' ), 'context' => array( 'network_id' => $network_id, 'changes' => $changes ) ) );
	}

	/** Reduce encrypted license storage to a non-sensitive status snapshot. */

	private static function license_state( $value ): array {
		/*
		 * RESOURCE OWNERSHIP INVARIANT: wphave_license stores the canonical
		 * license_settings root. Accepting a nested `license` fallback would let
		 * obsolete or malformed data drive a security audit event that does not
		 * describe the authoritative entitlement state.
		 */
		$value = is_array( $value ) ? $value : array();
		return array( 'connected' => ! empty( $value['key'] ) || ! empty( $value['token'] ) || ! empty( $value['accessToken'] ), 'valid' => ! empty( $value['valid'] ), 'authorized' => ! empty( $value['authorized'] ) || ! empty( $value['accessToken'] ), 'beta' => ! empty( $value['beta'] ), 'local_license_required' => ! empty( $value['localLicenseRequired'] ), 'expiration' => sanitize_text_field( (string) ( $value['expiration'] ?? '' ) ) );
	}

	/** Record one SEO or presentation meta change for a post. */

	private static function post_meta_event( int $post_id, string $meta_key, $before, $after ): void {
		$post = get_post( $post_id );
		if( ! $post || self::skip_post( $post ) ) return;
		$labels = array( 'wphave_seo_title' => __( 'SEO title', 'wphave' ), 'wphave_seo_description' => __( 'Meta description', 'wphave' ), 'wphave_seo_canonical_url' => __( 'Canonical URL', 'wphave' ), 'wphave_seo_robots_meta' => __( 'Search engine visibility', 'wphave' ), '_thumbnail_id' => __( 'Featured image', 'wphave' ), '_wp_page_template' => __( 'Page template', 'wphave' ) );
		$event = str_starts_with( $meta_key, 'wphave_seo_' ) ? 'seo.metadata_updated' : 'content.metadata_updated';
		self::post_event( $event, $post, 'updated', array( 'changes' => WPHAVE_Activity_Changes::compare( array( $meta_key => $before ), array( $meta_key => $after ), array( $meta_key => $labels[$meta_key] ?? $meta_key ) ) ) );
	}

	/** Return whether post meta is meaningful for activity diagnostics. */

	private static function is_audited_post_meta( string $meta_key ): bool {
		return str_starts_with( $meta_key, 'wphave_seo_' ) || in_array( $meta_key, array( '_thumbnail_id', '_wp_page_template' ), true );
	}

	/** Resolve term-taxonomy ids to bounded readable term names. */

	private static function term_labels_from_tt_ids( array $tt_ids ): array {
		$labels = array();
		foreach( array_slice( $tt_ids, 0, 10 ) as $tt_id ) {
			$term = get_term_by( 'term_taxonomy_id', (int) $tt_id );
			if( $term && ! is_wp_error( $term ) ) $labels[] = $term->name;
		}
		return $labels;
	}

	/** Build a normalized content event from a post snapshot. */

	private static function post_event( string $event, WP_Post $post, string $action, array $context = array() ): void {
		$type = get_post_type_object( $post->post_type );
		WPHAVE_Activity_Log::record( $event, array( 'category' => 'content', 'action' => $action, 'object_type' => 'post', 'object_id' => $post->ID, 'object_subtype' => $post->post_type, 'object_label' => $post->post_title ?: ( $type->labels->singular_name ?? $post->post_type ) . ' #' . $post->ID, 'context' => $context ) );
	}

	/** Build a normalized media event from an attachment snapshot. */

	private static function attachment_event( string $event, int $attachment_id, string $action, ?WP_Post $post = null, array $context = array() ): void {
		$post = $post ?: get_post( $attachment_id );
		if( ! $post ) return;
		WPHAVE_Activity_Log::record( $event, array( 'category' => 'media', 'action' => $action, 'object_type' => 'attachment', 'object_id' => $attachment_id, 'object_subtype' => get_post_mime_type( $post ) ?: '', 'object_label' => $post->post_title ?: basename( (string) get_attached_file( $attachment_id ) ), 'context' => $context ) );
	}

	/** Build a normalized comment event with its parent post label. */

	private static function comment_event( string $event, WP_Comment $comment, string $action, array $context = array() ): void {
		$post = get_post( $comment->comment_post_ID );
		WPHAVE_Activity_Log::record( $event, array( 'category' => 'comments', 'action' => $action, 'object_type' => 'comment', 'object_id' => (int) $comment->comment_ID, 'object_subtype' => sanitize_key( $comment->comment_type ?: 'comment' ), 'object_label' => $post ? $post->post_title : sprintf( 'Comment #%d', $comment->comment_ID ), 'context' => array_merge( array( 'post_id' => (int) $comment->comment_post_ID, 'author' => $comment->comment_author ), $context ) ) );
	}

	/** Build a normalized taxonomy event from a term snapshot. */

	private static function term_event( string $event, int $term_id, string $taxonomy, string $action, ?WP_Term $term = null, array $context = array() ): void {
		$term = $term ?: get_term( $term_id, $taxonomy );
		if( ! $term || is_wp_error( $term ) ) return;
		$is_media_folder = $taxonomy === 'wphave_media_folder';
		if( $is_media_folder ) $event = 'media.folder_' . ( $action === 'created' ? 'created' : ( $action === 'deleted' ? 'deleted' : 'updated' ) );
		WPHAVE_Activity_Log::record( $event, array( 'category' => $is_media_folder ? 'media' : 'taxonomy', 'action' => $action, 'object_type' => $is_media_folder ? 'media_folder' : 'term', 'object_id' => $term_id, 'object_subtype' => $taxonomy, 'object_label' => $term->name, 'context' => $context ) );
	}

	/** Build a normalized user or security event from a user snapshot. */

	private static function user_event( string $event, WP_User $user, string $action, array $context = array(), string $category = 'users', bool $user_is_actor = false ): void {
		$label = $user->display_name ?: $user->user_login;
		$args = array( 'category' => $category, 'action' => $action, 'object_type' => 'user', 'object_id' => $user->ID, 'object_label' => $label, 'context' => $context );
		if( $user_is_actor ) $args = array_merge( $args, array( 'actor_type' => 'user', 'actor_id' => $user->ID, 'actor_label' => $label ) );
		WPHAVE_Activity_Log::record( $event, $args );
	}

	/** Build an application-password event that excludes password material. */

	private static function application_password_event( string $action, int $user_id, array $item = array() ): void {
		$user = get_userdata( $user_id );
		if( ! $user ) return;
		self::user_event( 'security.application_password_' . $action, $user, 'application_password_' . $action, array( 'application_name' => sanitize_text_field( (string) ( $item['name'] ?? '' ) ) ), 'security' );
	}

	/** Build a normalized plugin or theme lifecycle event. */

	private static function extension_event( string $event, string $type, string $slug, string $action, array $context = array(), string $label = '' ): void {
		WPHAVE_Activity_Log::record( $event, array( 'category' => 'system', 'action' => $action, 'object_type' => $type, 'object_subtype' => sanitize_key( dirname( $slug ) ), 'object_label' => $label ?: $slug, 'context' => array_merge( array( 'slug' => sanitize_text_field( $slug ) ), $context ) ) );
	}

	/** Resolve a current plugin, theme or WordPress core name and version. */

	private static function extension_details( string $type, string $slug ): array {
		if( $type === 'plugin' ) {
			if( ! function_exists( 'get_plugin_data' ) ) require_once ABSPATH . 'wp-admin/includes/plugin.php';
			$data = is_file( WP_PLUGIN_DIR . '/' . $slug ) ? get_plugin_data( WP_PLUGIN_DIR . '/' . $slug, false, false ) : array();
			return array( 'label' => sanitize_text_field( (string) ( $data['Name'] ?? $slug ) ), 'version' => sanitize_text_field( (string) ( $data['Version'] ?? '' ) ) );
		}
		if( $type === 'theme' ) {
			$theme = wp_get_theme( $slug );
			return array( 'label' => $theme->exists() ? $theme->get( 'Name' ) : $slug, 'version' => $theme->exists() ? $theme->get( 'Version' ) : '' );
		}
		global $wp_version;
		return array( 'label' => __( 'WordPress', 'wphave' ), 'version' => (string) $wp_version );
	}

	/** Determine whether a post type and state is useful for human auditing. */

	private static function skip_post( WP_Post $post ): bool {
		$excluded = array( 'attachment', 'revision', 'nav_menu_item', 'user_request', 'shop_order', 'shop_order_refund', 'shop_coupon', 'scheduled-action' );
		if( wp_is_post_revision( $post ) || wp_is_post_autosave( $post ) || in_array( $post->post_type, $excluded, true ) || in_array( $post->post_status, array( 'auto-draft', 'inherit' ), true ) ) return true;
		$type = get_post_type_object( $post->post_type );
		return ! $type || ( ! $type->public && ! $type->show_ui && ! str_starts_with( $post->post_type, 'wphave-' ) );
	}

	/** Return whether a role hook is the internal side effect of `set_role()`. */
    
	private static function called_from_set_role(): bool {
		foreach( debug_backtrace( DEBUG_BACKTRACE_IGNORE_ARGS, 6 ) as $frame ) if( ($frame['function'] ?? '') === 'set_role' && ($frame['class'] ?? '') === 'WP_User' ) return true;
		return false;
	}

	/** Allow meaningful settings while excluding secrets and operational state. */

	private static function should_log_option( string $option ): bool {
		$core_options = array( 'blogname', 'blogdescription', 'site_icon', 'timezone_string', 'gmt_offset', 'date_format', 'time_format', 'start_of_week', 'permalink_structure', 'show_on_front', 'page_on_front', 'page_for_posts', 'wp_page_for_privacy_policy', 'users_can_register', 'default_role', 'default_comment_status', 'default_ping_status', 'default_pingback_flag', 'comment_registration', 'comments_notify', 'moderation_notify', 'sidebars_widgets' );
		if( in_array( $option, $core_options, true ) ) return true;
		if( ! str_starts_with( $option, 'wphave_' ) || str_starts_with( $option, 'wphave_system_info_write_test_' ) ) return false;
		$exact = array_merge(
			array(
				WPHAVE_Activity_Log::RETENTION_OPTION,
				WPHAVE_Activity_Log::PRIVACY_VERSION_OPTION,
				WPHAVE_Activity_Log::PRIVACY_CURSOR_OPTION,
				WPHAVE_Activity_Log::PRIVACY_LOCK_OPTION,
				WPHAVE_Activity_Log::HEALTH_OPTION,
				WPHAVE_Activity_Policy::OPTION,
				'wphave_activity_db_version',
				WPHAVE_Activity_Capture_Contracts::ENVIRONMENT_SNAPSHOT_OPTION,
				WPHAVE_Activity_Capture_Contracts::ENVIRONMENT_LOCK_OPTION,
				'wphave_database_schema_status',
				'wphave_database_schema_last_update_at',
				'wphave_database_schema_last_error',
				'wphave_database_schema_plugin_version',
				'wphave_database_schema_update_lock',
			),
			WPHAVE_Activity_Capture_Contracts::DIAGNOSTIC_OPTIONS
		);
		$operational = array( '_lock', '_job', '_results', '_status', '_cache', '_hash', '_version', '_queue', '_notice', '_last_', '_cleanup' );
		if( in_array( $option, $exact, true ) || WPHAVE_Sensitive_Data_Policy::is_sensitive_key( $option ) ) return false;
		return ! (bool) array_filter( $operational, static fn( $needle ) => str_contains( $option, $needle ) );
	}

}

WPHAVE_Activity_Hooks::init();
