<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Creates privacy-safe, presentation-neutral change sets for activity events.
 *
 * Change records use stable field keys and optional scalar before/after values.
 * Protected or complex values are represented as changed without persisting
 * their contents.
 */

final class WPHAVE_Activity_Changes {

	const MAX_CHANGES = 30;
	const MAX_VALUE_LENGTH = 190;

	/**
	 * Compare two field maps and return normalized change records.
	 *
	 * @param array $before Previous values keyed by stable field name.
	 * @param array $after  New values keyed by stable field name.
	 * @param array $labels Optional human-readable snapshots keyed by field name.
	 * @return array Normalized change records.
	 */

	public static function compare( array $before, array $after, array $labels = array() ): array {
		$changes = array();
		foreach( array_slice( array_values( array_unique( array_merge( array_keys( $before ), array_keys( $after ) ) ) ), 0, self::MAX_CHANGES ) as $field ) {
			$old_value = $before[$field] ?? null;
			$new_value = $after[$field] ?? null;
			if( self::equal( $old_value, $new_value ) ) continue;
			$change = array( 'field' => sanitize_key( (string) $field ), 'label' => sanitize_text_field( (string) ( $labels[$field] ?? self::label( (string) $field ) ) ), 'changed' => true );
			if( self::may_store_value( (string) $field ) ) {
				$old_summary = self::value( $old_value );
				$new_summary = self::value( $new_value );
				if( $old_summary['available'] && $new_summary['available'] ) {
					$change['from'] = $old_summary['value'];
					$change['to'] = $new_summary['value'];
				}
			}
			$changes[] = $change;
		}
		return $changes;
	}

	/**
	 * Build change records when a transport knows affected fields but not old values.
	 *
	 * @param array $fields Submitted field names.
	 * @param array $labels Optional human-readable snapshots keyed by field name.
	 * @return array Normalized field-only change records.
	 */

	public static function touched( array $fields, array $labels = array() ): array {
		$changes = array();
		foreach( array_slice( array_values( array_unique( array_map( 'sanitize_key', $fields ) ) ), 0, self::MAX_CHANGES ) as $field ) {
			if( ! $field || in_array( $field, array( 'id', 'force', 'confirm', '_locale' ), true ) ) continue;
			$changes[] = array( 'field' => $field, 'label' => sanitize_text_field( (string) ( $labels[$field] ?? self::label( $field ) ) ), 'changed' => true );
		}
		return $changes;
	}

	/** Return whether a field may contain secrets, private text or credentials. */

	public static function is_protected_field( string $field ): bool {
		$field = strtolower( $field );
		$private_content = array( 'pass', 'content', 'body', 'message', 'email', 'excerpt', 'description', 'code_header', 'code_footer', 'login_slug' );

		return WPHAVE_Sensitive_Data_Policy::is_sensitive_key( $field )
			|| (bool) array_filter( $private_content, static fn( $needle ) => str_contains( $field, $needle ) );
	}

	/** Return whether before and after values may be persisted for this field. */

	public static function may_store_value( string $field ): bool {
		return ! self::is_protected_field( $field ) || in_array( strtolower( $field ), array( 'blogdescription', 'wphave_seo_description' ), true );
	}

	/** Compare values consistently across scalar and structured settings. */

	private static function equal( $before, $after ): bool {
		return maybe_serialize( $before ) === maybe_serialize( $after );
	}

	/** Convert a stable field key into a readable fallback label. */

	private static function label( string $field ): string {
		$label = trim( str_replace( array( 'wphave_', 'post_', '_' ), array( '', '', ' ' ), $field ) );
		return ucwords( $label );
	}

	/** Return a bounded scalar/list snapshot when it is safe to persist. */
    
	private static function value( $value ): array {
		if( is_null( $value ) || is_bool( $value ) || is_int( $value ) || is_float( $value ) ) return array( 'available' => true, 'value' => $value );
		if( is_string( $value ) ) return array( 'available' => true, 'value' => WPHAVE_Activity_Privacy::sanitize_text( $value, self::MAX_VALUE_LENGTH ) );
		if( is_array( $value ) && array_is_list( $value ) && count( $value ) <= 10 && ! array_filter( $value, static fn( $item ) => ! is_scalar( $item ) && $item !== null ) ) {
			return array( 'available' => true, 'value' => array_map( static fn( $item ) => is_string( $item ) ? WPHAVE_Activity_Privacy::sanitize_text( $item, self::MAX_VALUE_LENGTH ) : $item, $value ) );
		}
		return array( 'available' => false, 'value' => null );
	}
}
