<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Creates useful content change summaries without storing editorial content.
 *
 * Text bodies remain private. Instead, this service records safe field values
 * and structural signals such as words, links, blocks and changed block types.
 */

final class WPHAVE_Activity_Content {

	/** Compare two post snapshots and return normalized diagnostic changes. */

	public static function changes( WP_Post $before, WP_Post $after ): array {
		$before_values = array( 'post_title' => $before->post_title, 'post_name' => $before->post_name, 'post_excerpt' => $before->post_excerpt, 'post_author' => self::user_label( (int) $before->post_author ), 'post_parent' => self::post_label( (int) $before->post_parent ), 'menu_order' => (int) $before->menu_order, 'comment_status' => $before->comment_status, 'ping_status' => $before->ping_status, 'post_password' => $before->post_password !== '' );
		$after_values = array( 'post_title' => $after->post_title, 'post_name' => $after->post_name, 'post_excerpt' => $after->post_excerpt, 'post_author' => self::user_label( (int) $after->post_author ), 'post_parent' => self::post_label( (int) $after->post_parent ), 'menu_order' => (int) $after->menu_order, 'comment_status' => $after->comment_status, 'ping_status' => $after->ping_status, 'post_password' => $after->post_password !== '' );
		$labels = array( 'post_title' => __( 'Title', 'wphave' ), 'post_name' => __( 'Slug', 'wphave' ), 'post_excerpt' => __( 'Excerpt', 'wphave' ), 'post_author' => __( 'Author', 'wphave' ), 'post_parent' => __( 'Parent', 'wphave' ), 'menu_order' => __( 'Order', 'wphave' ), 'comment_status' => __( 'Comments', 'wphave' ), 'ping_status' => __( 'Pingbacks', 'wphave' ), 'post_password' => __( 'Password protection', 'wphave' ) );
		$changes = WPHAVE_Activity_Changes::compare( $before_values, $after_values, $labels );
		if( $before->post_content !== $after->post_content ) $changes = array_merge( $changes, self::content_changes( $before->post_content, $after->post_content ) );
		return array_slice( $changes, 0, WPHAVE_Activity_Changes::MAX_CHANGES );
	}

	/** Describe body changes through safe metrics and block structure. */

	private static function content_changes( string $before, string $after ): array {
		$before_summary = self::content_summary( $before );
		$after_summary = self::content_summary( $after );
		$labels = array( 'post_content' => __( 'Content', 'wphave' ), 'word_count' => __( 'Word count', 'wphave' ), 'link_count' => __( 'Links', 'wphave' ), 'block_count' => __( 'Blocks', 'wphave' ), 'changed_block_count' => __( 'Changed blocks', 'wphave' ), 'heading_count' => __( 'Headings', 'wphave' ), 'image_count' => __( 'Images', 'wphave' ) );
		$before_values = array_merge( array( 'post_content' => $before, 'changed_block_count' => 0 ), $before_summary['metrics'] );
		$after_values = array_merge( array( 'post_content' => $after, 'changed_block_count' => self::changed_blocks( $before_summary['blocks'], $after_summary['blocks'] ) ), $after_summary['metrics'] );
		$changes = WPHAVE_Activity_Changes::compare( $before_values, $after_values, $labels );
		foreach( array_unique( array_merge( array_keys( $before_summary['types'] ), array_keys( $after_summary['types'] ) ) ) as $type ) {
			$old_count = (int) ( $before_summary['types'][$type] ?? 0 );
			$new_count = (int) ( $after_summary['types'][$type] ?? 0 );
			if( $old_count === $new_count ) continue;
			$field = 'block_' . str_replace( '/', '_', $type );
			$changes = array_merge( $changes, WPHAVE_Activity_Changes::compare( array( $field => $old_count ), array( $field => $new_count ), array( $field => self::block_label( $type ) ) ) );
		}
		return $changes;
	}

	/** Return content metrics and flattened block fingerprints for comparison. */

	private static function content_summary( string $content ): array {
		$text = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( strip_shortcodes( $content ) ) ) );
		$blocks = self::flatten_blocks( parse_blocks( $content ) );
		$types = array_count_values( array_column( $blocks, 'type' ) );
		return array(
			'metrics' => array( 'word_count' => $text === '' ? 0 : count( preg_split( '/\s+/u', $text ) ), 'link_count' => (int) preg_match_all( '/<a\s[^>]*href\s*=/i', $content ), 'block_count' => count( $blocks ), 'heading_count' => (int) preg_match_all( '/<h[1-6](?:\s|>)/i', $content ), 'image_count' => (int) preg_match_all( '/<img(?:\s|>)/i', $content ) ),
			'blocks' => $blocks,
			'types' => $types,
		);
	}

	/** Flatten nested blocks into type and request-local fingerprints. */

	private static function flatten_blocks( array $blocks ): array {
		$flat = array();
		foreach( $blocks as $block ) {
			$type = (string) ( $block['blockName'] ?? 'core/freeform' );
			$flat[] = array( 'type' => $type, 'hash' => md5( serialize( array( $block['attrs'] ?? array(), $block['innerHTML'] ?? '' ) ) ) );
			if( ! empty( $block['innerBlocks'] ) ) $flat = array_merge( $flat, self::flatten_blocks( $block['innerBlocks'] ) );
		}
		return $flat;
	}

	/** Count changed block positions without persisting their fingerprints. */

	private static function changed_blocks( array $before, array $after ): int {
		$changed = 0;
		for( $index = 0, $count = max( count( $before ), count( $after ) ); $index < $count; $index++ ) if( ( $before[$index]['hash'] ?? '' ) !== ( $after[$index]['hash'] ?? '' ) || ( $before[$index]['type'] ?? '' ) !== ( $after[$index]['type'] ?? '' ) ) $changed++;
		return $changed;
	}

	/** Return the translated block title with a stable fallback. */

	private static function block_label( string $type ): string {
		$block = WP_Block_Type_Registry::get_instance()->get_registered( $type );
		$title = $block ? $block->title : ucwords( str_replace( array( 'core/', '-', '_' ), array( '', ' ', ' ' ), $type ) );
		return sprintf( __( '%s blocks', 'wphave' ), $title );
	}

	/** Resolve an author id to a durable readable snapshot. */

	private static function user_label( int $user_id ): string {
		$user = $user_id ? get_userdata( $user_id ) : null;
		return $user ? ( $user->display_name ?: $user->user_login ) : ( $user_id ? sprintf( __( 'User #%d', 'wphave' ), $user_id ) : '' );
	}

	/** Resolve a parent id to its title while retaining a fallback for deleted posts. */

	private static function post_label( int $post_id ): string {
		return $post_id ? ( get_the_title( $post_id ) ?: sprintf( __( 'Post #%d', 'wphave' ), $post_id ) ) : '';
	}
}
