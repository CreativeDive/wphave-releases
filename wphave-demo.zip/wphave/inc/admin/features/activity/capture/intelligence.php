<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Extensible assessment, follow-up and correlation layer for activity events.
 *
 * Evaluators add explainable diagnostic metadata without changing the stored
 * IDEMPOTENCY INVARIANT: Event classifiers remain deterministic and side-effect free.
 */

final class WPHAVE_Activity_Intelligence {

	private static array $evaluators = array();
	private static bool $recording_error = false;

	/** Register default evaluators and runtime error correlation. */

	public static function init(): void {
		self::register( 'content.*', array( __CLASS__, 'evaluate_content' ), 10 );
		self::register( 'seo.*', array( __CLASS__, 'evaluate_content' ), 10 );
		self::register( 'settings.*', array( __CLASS__, 'evaluate_settings' ), 10 );
		self::register( 'smtp.*', array( __CLASS__, 'evaluate_smtp' ), 10 );
		self::register( 'backup.*', array( __CLASS__, 'evaluate_backup' ), 10 );
		self::register( 'redirect.*', array( __CLASS__, 'evaluate_redirect' ), 10 );
		self::register( 'user.*', array( __CLASS__, 'evaluate_access' ), 10 );
		self::register( 'system.plugin_*', array( __CLASS__, 'evaluate_plugin' ), 10 );
		self::register( 'system.theme_update_failed', array( __CLASS__, 'evaluate_system_failure' ), 10 );
		self::register( 'system.core_update_failed', array( __CLASS__, 'evaluate_system_failure' ), 10 );
		self::register( 'system.database_migration_failed', array( __CLASS__, 'evaluate_system_failure' ), 10 );
		self::register( 'remote.wphave_request_failed', array( __CLASS__, 'evaluate_system_failure' ), 10 );
		self::register( 'cron.job_failed', array( __CLASS__, 'evaluate_system_failure' ), 10 );
		self::register( 'system.domain_changed', array( __CLASS__, 'evaluate_environment' ), 10 );
		self::register( 'system.runtime_changed', array( __CLASS__, 'evaluate_environment' ), 10 );
		self::register( 'system.php_error', array( __CLASS__, 'evaluate_php_error' ), 10 );
		self::register( 'performance.*', array( __CLASS__, 'evaluate_performance' ), 10 );
		self::register( 'security_scan.completed', array( __CLASS__, 'evaluate_security_scan' ), 10 );
		add_filter( 'wphave/activity/event', array( __CLASS__, 'enrich' ), 20, 2 );
		add_action( 'shutdown', array( __CLASS__, 'capture_fatal_error' ), PHP_INT_MAX );
	}

	/** Register one evaluator for an exact event name or shell-style wildcard. */

	public static function register( string $pattern, callable $callback, int $priority = 10 ): void {
		self::$evaluators[] = array( 'pattern' => strtolower( $pattern ), 'callback' => $callback, 'priority' => $priority );
		usort( self::$evaluators, static fn( $left, $right ) => $left['priority'] <=> $right['priority'] );
	}

	/** Apply matching evaluators and attach recent object relationships. */

	public static function enrich( array $data, array $args ): array {
		$context = json_decode( (string) ( $data['context'] ?? '{}' ), true );
		$context = is_array( $context ) ? $context : array();
		foreach( self::$evaluators as $definition ) {
			if( ! fnmatch( $definition['pattern'], $data['event_type'] ) ) continue;
			$result = call_user_func( $definition['callback'], $data, $context, $args );
			if( is_array( $result ) ) $context = array_replace_recursive( $context, $result );
		}
		$relations = self::recent_object_relations( $data );
		if( $relations ) $context['relations'] = array_values( array_merge( (array) ( $context['relations'] ?? array() ), $relations ) );
		$assessment = is_array( $context['assessment'] ?? null ) ? $context['assessment'] : array();
		$follow_up = is_array( $context['follow_up'] ?? null ) ? $context['follow_up'] : array();
		$data['assessment_status'] = sanitize_key( $assessment['status'] ?? '' );
		$data['follow_up_status'] = sanitize_key( $follow_up['status'] ?? '' );
		$data['correlation_id'] = sanitize_text_field( (string) ( $context['correlation_id'] ?? '' ) );
		$data['context'] = wp_json_encode( $context, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		return $data;
	}

	/** Evaluate SEO completeness and URL follow-ups for changed content. */

	public static function evaluate_content( array $data, array $context ): array {
		$post_id = absint( $data['object_id'] ?? 0 );
		if( ! $post_id || ( $data['object_type'] ?? '' ) !== 'post' ) return array();
		if( in_array( $data['event_type'] ?? '', array( 'content.trashed', 'content.deleted' ), true ) ) return array();
		$title = trim( (string) get_post_meta( $post_id, 'wphave_seo_title', true ) );
		$description = trim( (string) get_post_meta( $post_id, 'wphave_seo_description', true ) );
		$checks = array(
			self::check( 'seo_title', $title ? 'good' : 'missing', __( 'SEO title', 'wphave' ), $title ? __( 'A custom SEO title is set.', 'wphave' ) : __( 'The page uses its generated title.', 'wphave' ) ),
			self::check( 'seo_description', $description ? 'good' : 'missing', __( 'Meta description', 'wphave' ), $description ? __( 'A meta description is set.', 'wphave' ) : __( 'No meta description is set.', 'wphave' ) ),
		);
		$slug_change = self::find_change( $context, 'post_name' );
		$slug_changed = $slug_change && ! empty( $slug_change['from'] );
		if( $title && ! $description ) return array( 'assessment' => self::assessment( 'warning', __( 'The SEO title was customized, but the meta description is still missing.', 'wphave' ), $checks, 'high' ), 'follow_up' => self::follow_up( 'complete_seo_metadata', __( 'Add a meta description and review the search preview.', 'wphave' ), 'seo.metadata_updated', $data ) );
		if( $slug_changed ) return array( 'assessment' => self::assessment( 'warning', __( 'The URL slug changed. Existing links may require a redirect.', 'wphave' ), $checks, 'medium' ), 'follow_up' => self::follow_up( 'create_redirect', __( 'Verify the old URL and create a redirect if needed.', 'wphave' ), 'redirect.created', $data ) );
		return array( 'assessment' => self::assessment( $description ? 'good' : 'info', $description ? __( 'The basic SEO metadata is complete.', 'wphave' ) : __( 'The page has no custom meta description.', 'wphave' ), $checks, 'high' ) );
	}

	/** Evaluate central settings changes that have operational follow-ups. */

	public static function evaluate_settings( array $data, array $context ): array {
		$label = strtolower( (string) ( $data['object_label'] ?? '' ) );
		if( str_contains( $label, 'smtp' ) || self::change_exists( $context, 'smtp' ) ) {
			$info = class_exists( 'WPHAVE_SMTP' ) ? WPHAVE_SMTP::get_public_info() : array();
			if( ! empty( $info['enabled'] ) && empty( $info['configured'] ) ) return array( 'assessment' => self::assessment( 'critical', __( 'SMTP is enabled but the configuration is incomplete.', 'wphave' ), array(), 'high' ), 'follow_up' => self::follow_up( 'test_smtp', __( 'Complete the SMTP settings and send a test email.', 'wphave' ), 'smtp.tested', $data ) );
			if( ! empty( $info['enabled'] ) ) return array( 'assessment' => self::assessment( 'info', __( 'SMTP settings changed and should be verified with a test email.', 'wphave' ), array(), 'high' ), 'follow_up' => self::follow_up( 'test_smtp', __( 'Send a test email.', 'wphave' ), 'smtp.tested', $data ) );
		}
		if( str_contains( $label, 'backup' ) || self::change_exists( $context, 'backups' ) ) return array( 'assessment' => self::assessment( 'info', __( 'Backup settings changed and should be verified with a successful backup.', 'wphave' ), array(), 'high' ), 'follow_up' => self::follow_up( 'verify_backup', __( 'Run a backup and verify the restore point.', 'wphave' ), 'backup.backup-completed', $data ) );
		return array();
	}

	/** Evaluate the outcome of a manual SMTP test. */

	public static function evaluate_smtp( array $data ): array {
		$failed = ( $data['status'] ?? '' ) === 'failure';
		return array( 'assessment' => self::assessment( $failed ? 'critical' : 'good', $failed ? __( 'The mail test failed. Form and system emails may not be delivered.', 'wphave' ) : __( 'The mail test completed successfully.', 'wphave' ), array(), 'high' ) );
	}

	/** Evaluate backup outcomes and expected verification runs. */

	public static function evaluate_backup( array $data ): array {
		$event = $data['event_type'];
		if( str_contains( $event, 'settings-updated' ) ) return array( 'assessment' => self::assessment( 'info', __( 'Backup settings changed and have not yet been verified by a successful backup.', 'wphave' ), array(), 'high' ), 'follow_up' => self::follow_up( 'verify_backup', __( 'Run a backup and verify the restore point.', 'wphave' ), 'backup.backup-completed', $data ) );
		if( str_contains( $event, 'restore' ) && str_contains( $event, 'failed' ) ) return array( 'assessment' => self::assessment( 'critical', __( 'The website restore failed and the site state should be checked.', 'wphave' ), array(), 'high' ) );
		if( str_contains( $event, 'restore' ) && str_contains( $event, 'completed' ) ) return array( 'assessment' => self::assessment( 'good', __( 'The website restore completed successfully.', 'wphave' ), array(), 'high' ) );
		if( str_contains( $event, 'failed' ) ) return array( 'assessment' => self::assessment( 'critical', __( 'The backup operation failed. The site may not have a current restore point.', 'wphave' ), array(), 'high' ) );
		if( str_contains( $event, 'completed' ) ) return array( 'assessment' => self::assessment( 'good', __( 'The backup completed successfully.', 'wphave' ), array(), 'high' ) );
		return array();
	}

	/** Evaluate redirect validity from the captured request summary. */

	public static function evaluate_redirect( array $data, array $context ): array {
		$source = (string) ( $context['source_path'] ?? $data['object_label'] ?? '' );
		$target = (string) ( $context['target_url'] ?? '' );
		if( $target && untrailingslashit( $source ) === untrailingslashit( $target ) ) return array( 'assessment' => self::assessment( 'critical', __( 'The redirect source and target are identical and may create a loop.', 'wphave' ), array(), 'high' ) );
		return array( 'assessment' => self::assessment( $target ? 'good' : 'info', $target ? __( 'The redirect has a target and can preserve traffic from the old URL.', 'wphave' ) : __( 'The redirect target could not be verified from this event.', 'wphave' ), array(), $target ? 'high' : 'low' ) );
	}

	/** Highlight changes that grant broad administrator access. */

	public static function evaluate_access( array $data, array $context ): array {
		if( ! in_array( $data['event_type'], array( 'user.role_changed', 'user.role_added', 'user.access_updated' ), true ) ) return array();
		$encoded = wp_json_encode( $context );
		if( str_contains( $encoded, 'administrator' ) ) return array( 'assessment' => self::assessment( 'warning', __( 'This change grants broad administrative access.', 'wphave' ), array(), 'high' ) );
		return array( 'assessment' => self::assessment( 'info', __( 'User access permissions changed.', 'wphave' ), array(), 'high' ) );
	}

	/** Evaluate plugin lifecycle events as a diagnostic baseline. */

	public static function evaluate_plugin( array $data, array $context ): array {
		$automatic = ! empty( $context['automatic'] );
		if( ( $data['status'] ?? '' ) === 'failure' ) {
			$summary = $automatic ? __( 'An automatic plugin update failed. The previously installed version may still be active.', 'wphave' ) : __( 'The plugin operation failed. Check the installed version and plugin status.', 'wphave' );
			return array( 'assessment' => self::assessment( 'warning', $summary, array(), 'high' ), 'correlation_id' => wp_generate_uuid4() );
		}
		$summary = $data['event_type'] === 'system.plugin_updated' ? ( $automatic ? __( 'An automatic plugin update changed the site runtime.', 'wphave' ) : __( 'A plugin update changed the site runtime.', 'wphave' ) ) : __( 'The active plugin set changed.', 'wphave' );
		$slug = (string) ( $context['slug'] ?? '' );
		if( $slug && is_file( WP_PLUGIN_DIR . '/' . $slug ) ) {
			if( ! function_exists( 'validate_plugin_requirements' ) ) require_once ABSPATH . 'wp-admin/includes/plugin.php';
			$requirements = validate_plugin_requirements( $slug );
			if( is_wp_error( $requirements ) ) return array( 'assessment' => self::assessment( 'critical', __( 'The plugin does not meet the current WordPress, PHP or dependency requirements.', 'wphave' ), array( self::check( 'plugin_requirements', 'failed', __( 'Compatibility', 'wphave' ), wp_strip_all_tags( $requirements->get_error_message() ) ) ), 'high' ), 'correlation_id' => wp_generate_uuid4() );
			return array( 'assessment' => self::assessment( 'info', $summary, array( self::check( 'plugin_requirements', 'good', __( 'Compatibility', 'wphave' ), __( 'No unmet runtime requirements were detected.', 'wphave' ) ) ), 'high' ), 'correlation_id' => wp_generate_uuid4() );
		}
		return array( 'assessment' => self::assessment( 'info', $summary, array(), 'high' ), 'correlation_id' => wp_generate_uuid4() );
	}

	/** Explain operational failures that directly affect updates or diagnostics. */

	public static function evaluate_system_failure( array $data ): array {
		$summaries = array(
			'system.theme_update_failed' => __( 'The theme update failed. The previous version may still be active and should be verified.', 'wphave' ),
			'system.core_update_failed' => __( 'The WordPress update failed. Check the installed version and website health before retrying.', 'wphave' ),
			'system.database_migration_failed' => __( 'The database schema update failed. Related WPHAVE features may be unavailable until the migration succeeds.', 'wphave' ),
			'remote.wphave_request_failed' => __( 'WPHAVE could not reach its server. License or update information may be temporarily outdated.', 'wphave' ),
			'cron.job_failed' => __( 'The associated maintenance or monitoring task may be delayed.', 'wphave' ),
		);
		$summary = $summaries[$data['event_type']] ?? __( 'The system operation did not complete successfully.', 'wphave' );
		$status = in_array( $data['severity'] ?? '', array( 'error', 'critical' ), true ) ? 'critical' : 'warning';
		return array( 'assessment' => self::assessment( $status, $summary, array(), 'high' ) );
	}

	/** Explain hosting and installation-address changes and their likely checks. */

	public static function evaluate_environment( array $data, array $context ): array {
		if( $data['event_type'] === 'system.domain_changed' ) {
			$checks = array(
				self::check( 'domain_urls', 'changed', __( 'Installation address', 'wphave' ), __( 'The public or internal WordPress address changed.', 'wphave' ) ),
				self::check( 'migration_review', 'missing', __( 'Migration review', 'wphave' ), __( 'Redirects, HTTPS, caches and external integrations should be checked after a move.', 'wphave' ) ),
			);
			return array( 'assessment' => self::assessment( 'warning', __( 'The installation address changed. Links, certificates, callbacks and integrations may still reference the previous address.', 'wphave' ), $checks, 'high' ) );
		}
		$fields = array_map( static fn( $change ) => (string) ( $change['field'] ?? '' ), (array) ( $context['changes'] ?? array() ) );
		$database_changed = in_array( 'database_type', $fields, true ) || in_array( 'database_version', $fields, true );
		$php_changed = in_array( 'php_version', $fields, true ) || in_array( 'php_sapi', $fields, true );
		$summary = $php_changed && $database_changed ? __( 'The PHP and database environment changed. This establishes a new diagnostic baseline.', 'wphave' ) : ( $php_changed ? __( 'The PHP runtime changed. Plugin and theme compatibility may be affected.', 'wphave' ) : ( $database_changed ? __( 'The database environment changed. Query behavior and compatibility may be affected.', 'wphave' ) : __( 'The WordPress hosting environment changed.', 'wphave' ) ) );
		return array( 'assessment' => self::assessment( 'info', $summary, array(), 'high' ), 'correlation_id' => wp_generate_uuid4() );
	}

	/** Correlate a fatal PHP error with recent plugin and theme lifecycle changes. */

	public static function evaluate_php_error( array $data ): array {
		$related = WPHAVE_Activity_Query::recent_by_prefixes( array( 'system.plugin_', 'system.theme_', 'system.core_', 'system.runtime_', 'system.domain_' ), 24 * HOUR_IN_SECONDS, 5 );
		$relations = array_map( static fn( $row ) => array( 'event_id' => (int) $row['id'], 'reason' => 'recent_runtime_change', 'confidence' => 'medium' ), $related );
		$summary = $relations ? __( 'A fatal PHP error occurred after a recent plugin, theme or WordPress change.', 'wphave' ) : __( 'A fatal PHP error was detected.', 'wphave' );
		return array( 'assessment' => self::assessment( 'critical', $summary, array(), $relations ? 'medium' : 'high' ), 'relations' => $relations );
	}

	/** Correlate slow or failed requests with recent runtime changes. */

	public static function evaluate_performance( array $data, array $context ): array {
		$related = WPHAVE_Activity_Query::recent_by_prefixes( array( 'system.plugin_', 'system.theme_', 'system.core_', 'system.runtime_', 'system.domain_' ), 24 * HOUR_IN_SECONDS, 5 );
		$relations = array_map( static fn( $row ) => array( 'event_id' => (int) $row['id'], 'reason' => 'recent_runtime_change', 'confidence' => 'low' ), $related );
		$status = absint( $context['http_status'] ?? 0 ) >= 500 ? 'critical' : 'warning';
		$summary = $relations ? __( 'A request anomaly appeared after a recent runtime change. The timing may be related.', 'wphave' ) : __( 'A slow or failed request was detected.', 'wphave' );
		return array( 'assessment' => self::assessment( $status, $summary, array(), $relations ? 'low' : 'high' ), 'relations' => $relations );
	}

	/** Evaluate completed security scans from their persisted finding counts. */

	public static function evaluate_security_scan( array $data, array $context ): array {
		$findings = absint( $context['findings'] ?? 0 );
		$errors = absint( $context['errors'] ?? 0 );
		if( $errors ) return array( 'assessment' => self::assessment( 'warning', __( 'The security scan completed with errors and may be incomplete.', 'wphave' ), array(), 'high' ) );
		if( $findings ) return array( 'assessment' => self::assessment( 'warning', sprintf( _n( 'The security scan found %d item that requires review.', 'The security scan found %d items that require review.', $findings, 'wphave' ), $findings ), array(), 'high' ) );
		return array( 'assessment' => self::assessment( 'good', __( 'The security scan completed without findings.', 'wphave' ), array(), 'high' ) );
	}

	/** Record fatal shutdown errors without exposing absolute paths or stack traces. */

	public static function capture_fatal_error(): void {
		if( self::$recording_error ) return;
		$error = error_get_last();
		if( ! $error || ! in_array( $error['type'], array( E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR, E_RECOVERABLE_ERROR ), true ) ) return;
		self::$recording_error = true;
		WPHAVE_Activity_Log::record( 'system.php_error', array( 'category' => 'system', 'action' => 'failed', 'status' => 'failure', 'severity' => 'critical', 'actor_type' => 'system', 'object_type' => 'runtime', 'object_label' => wp_basename( (string) $error['file'] ), 'context' => array( 'error_type' => (int) $error['type'], 'file' => self::relative_path( (string) $error['file'] ), 'line' => (int) $error['line'], 'error_summary' => mb_substr( sanitize_text_field( (string) $error['message'] ), 0, 300 ) ) ) );
	}

	/** Return normalized assessment metadata. */

	private static function assessment( string $status, string $summary, array $checks = array(), string $confidence = 'high' ): array {
		return array( 'status' => $status, 'summary' => $summary, 'confidence' => $confidence, 'checks' => $checks );
	}

	/** Return normalized follow-up metadata tied to a future event. */

	private static function follow_up( string $id, string $label, string $expected_event, array $data ): array {
		return array( 'id' => $id, 'status' => 'pending', 'label' => $label, 'expected_event' => $expected_event, 'object_type' => $data['object_type'] ?? '', 'object_id' => absint( $data['object_id'] ?? 0 ) );
	}

	/** Return one normalized evaluator check. */

	private static function check( string $id, string $status, string $label, string $detail ): array {
		return compact( 'id', 'status', 'label', 'detail' );
	}

	/** Check whether an event change set contains a field. */

	private static function change_exists( array $context, string $field ): bool {
		return (bool) array_filter( (array) ( $context['changes'] ?? array() ), static fn( $change ) => ( $change['field'] ?? '' ) === $field );
	}

	/** Return one changed field from diagnostic context, or null. */

	private static function find_change( array $context, string $field ): ?array {
		foreach( (array) ( $context['changes'] ?? array() ) as $change ) if( ($change['field'] ?? '') === $field ) return $change;
		return null;
	}

	/** Find recent events for the same domain object. */

	private static function recent_object_relations( array $data ): array {
		$object_type = sanitize_key( $data['object_type'] ?? '' );
		$object_id = absint( $data['object_id'] ?? 0 );
		if( ! $object_type || ! $object_id ) return array();
		return array_map( static fn( $row ) => array( 'event_id' => (int) $row['id'], 'reason' => 'same_object', 'confidence' => 'high' ), WPHAVE_Activity_Query::recent_for_object( $object_type, $object_id, 5 ) );
	}

	/** Convert an error path to a site-relative diagnostic path. */
    
	private static function relative_path( string $file ): string {
		$roots = array( ABSPATH, WP_CONTENT_DIR );
		foreach( $roots as $root ) if( str_starts_with( $file, $root ) ) return ltrim( str_replace( $root, '', $file ), '/\\' );
		return wp_basename( $file );
	}
}

WPHAVE_Activity_Intelligence::init();
