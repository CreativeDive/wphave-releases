<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once wphave_dir() . 'inc/background-jobs/functions.php';

/**
 * Detects meaningful changes to the WordPress hosting environment.
 *
 * A compact snapshot is compared by an hourly scheduled worker. This catches
 * changes made outside WordPress, including hosting upgrades and database
 * migrations, without adding work to normal frontend requests.
 */

final class WPHAVE_Activity_Environment_Monitor {

	const SNAPSHOT_OPTION = WPHAVE_Activity_Capture_Contracts::ENVIRONMENT_SNAPSHOT_OPTION;
	const LOCK_OPTION = WPHAVE_Activity_Capture_Contracts::ENVIRONMENT_LOCK_OPTION;
	const MONITOR_HOOK = 'wphave_activity_environment_monitor';
	const MONITOR_SCHEDULE_OPTION = 'wphave_activity_environment_monitor_schedule';
	const SNAPSHOT_VERSION = 4;
	const LOCK_TTL = 60;

	/** Register a low-frequency monitor outside the public request hot path. */

	public static function init(): void {
		add_action( 'init', array( __CLASS__, 'schedule' ), 20 );
		add_action( self::MONITOR_HOOK, array( __CLASS__, 'detect_changes' ) );
	}

	/** Ensure WordPress checks the environment at most once per hour. */

	public static function schedule(): void {
		// OBSERVABILITY INVARIANT: Environment drift has exactly one hourly owner.
		// Reconcile malformed or duplicate Cron state so monitoring cannot appear
		// healthy while running at an unintended cadence or not at all.
		WPHAVE_Background_Job_Scheduler::sync_recurring(
			self::MONITOR_HOOK,
			self::MONITOR_SCHEDULE_OPTION,
			true,
			'hourly',
			time() + 5 * MINUTE_IN_SECONDS,
			'activity-environment-monitor-v1'
		);
	}

	/** Compare the persisted baseline with the current environment and record deviations. */

	public static function detect_changes(): void {
		if( defined( 'WP_CLI' ) && WP_CLI ) return;
		$lock_token = self::acquire_lock();
		if( ! $lock_token ) return;
		try {
			$current = self::snapshot();
			$stored = get_option( self::SNAPSHOT_OPTION, array() );
			if( ! is_array( $stored ) || (int) ( $stored['snapshot_version'] ?? 0 ) !== self::SNAPSHOT_VERSION ) {
				update_option( self::SNAPSHOT_OPTION, $current, false );
				return;
			}

			$domain_changes = WPHAVE_Activity_Changes::compare( self::pick( $stored, self::domain_fields() ), self::pick( $current, self::domain_fields() ), self::labels() );
			$runtime_changes = WPHAVE_Activity_Changes::compare( self::pick( $stored, self::runtime_fields() ), self::pick( $current, self::runtime_fields() ), self::labels() );
			if( $domain_changes ) self::record( 'system.domain_changed', 'domain_changed', __( 'Website address', 'wphave' ), $domain_changes, 'warning' );
			if( $runtime_changes ) self::record( 'system.runtime_changed', 'runtime_changed', __( 'Hosting environment', 'wphave' ), $runtime_changes );
			if( $domain_changes || $runtime_changes || $stored !== $current ) update_option( self::SNAPSHOT_OPTION, $current, false );
		} finally {
			WPHAVE_Background_Job_Lock::release( self::LOCK_OPTION, $lock_token );
		}
	}

	/** Acquire a short database-backed lock and recover abandoned locks safely. */

	private static function acquire_lock(): string|false {
		return WPHAVE_Background_Job_Lock::acquire(
			self::LOCK_OPTION,
			self::LOCK_TTL
		);
	}

	/** Build a privacy-conscious environment snapshot with stable field keys. */

	private static function snapshot(): array {
		global $wpdb, $wp_version;
		if( ! function_exists( 'get_plugins' ) ) require_once ABSPATH . 'wp-admin/includes/plugin.php';
		$extensions = get_loaded_extensions();
		sort( $extensions, SORT_STRING );
		return array(
			'snapshot_version' => self::SNAPSHOT_VERSION,
			'home_url' => self::public_url( home_url( '/' ) ),
			'site_url' => self::public_url( site_url( '/' ) ),
			'php_version' => PHP_VERSION,
				'php_sapi' => PHP_SAPI,
				'php_extensions_hash' => hash( 'sha256', implode( ',', $extensions ) ),
				'php_memory_limit' => sanitize_text_field( (string) ini_get( 'memory_limit' ) ),
				'php_execution_limit' => absint( ini_get( 'max_execution_time' ) ),
				'php_upload_limit' => sanitize_text_field( (string) ini_get( 'upload_max_filesize' ) ),
				'php_post_limit' => sanitize_text_field( (string) ini_get( 'post_max_size' ) ),
				'wordpress_memory_limit' => defined( 'WP_MEMORY_LIMIT' ) ? sanitize_text_field( (string) WP_MEMORY_LIMIT ) : '',
				'plugin_inventory_hash' => self::inventory_hash( array_map( static fn( $plugin ) => (string) ( $plugin['Version'] ?? '' ), get_plugins() ) ),
				'mu_plugin_inventory_hash' => self::inventory_hash( array_map( static fn( $plugin ) => (string) ( $plugin['Version'] ?? '' ), get_mu_plugins() ) ),
				'theme_inventory_hash' => self::inventory_hash( array_map( static fn( WP_Theme $theme ) => (string) $theme->get( 'Version' ), wp_get_themes() ) ),
			'database_type' => self::database_type(),
			'database_version' => sanitize_text_field( (string) $wpdb->db_server_info() ),
			'wordpress_version' => sanitize_text_field( (string) $wp_version ),
			'environment_type' => function_exists( 'wp_get_environment_type' ) ? wp_get_environment_type() : 'production',
			'is_multisite' => is_multisite(),
			'locale' => self::site_locale(),
		);
	}

	/** Record one grouped system event with normalized before/after values. */

	private static function record( string $event, string $action, string $label, array $changes, string $severity = 'info' ): void {
		WPHAVE_Activity_Log::record( $event, array( 'category' => 'system', 'action' => $action, 'severity' => $severity, 'object_type' => 'environment', 'object_label' => $label, 'context' => array( 'changes' => $changes ) ) );
	}

	/** Return only requested keys while preserving absent values as null. */

	private static function pick( array $snapshot, array $fields ): array {
		$values = array();
		foreach( $fields as $field ) $values[$field] = $snapshot[$field] ?? null;
		return $values;
	}

	/** Return fields that identify the public installation location. */

	private static function domain_fields(): array {
		return array( 'home_url', 'site_url' );
	}

	/** Return fields that describe the executable hosting environment. */

	private static function runtime_fields(): array {
		return array( 'php_version', 'php_sapi', 'php_extensions_hash', 'php_memory_limit', 'php_execution_limit', 'php_upload_limit', 'php_post_limit', 'wordpress_memory_limit', 'plugin_inventory_hash', 'mu_plugin_inventory_hash', 'theme_inventory_hash', 'database_type', 'database_version', 'wordpress_version', 'environment_type', 'is_multisite', 'locale' );
	}

	/** Return translated field labels stored with diagnostic change records. */

	private static function labels(): array {
		return array( 'home_url' => __( 'Public website address', 'wphave' ), 'site_url' => __( 'WordPress address', 'wphave' ), 'php_version' => __( 'PHP version', 'wphave' ), 'php_sapi' => __( 'PHP interface', 'wphave' ), 'php_extensions_hash' => __( 'PHP extensions', 'wphave' ), 'php_memory_limit' => __( 'PHP memory limit', 'wphave' ), 'php_execution_limit' => __( 'PHP execution limit', 'wphave' ), 'php_upload_limit' => __( 'PHP upload limit', 'wphave' ), 'php_post_limit' => __( 'PHP POST limit', 'wphave' ), 'wordpress_memory_limit' => __( 'WordPress memory limit', 'wphave' ), 'plugin_inventory_hash' => __( 'Installed plugins', 'wphave' ), 'mu_plugin_inventory_hash' => __( 'Must-use plugins', 'wphave' ), 'theme_inventory_hash' => __( 'Installed themes', 'wphave' ), 'database_type' => __( 'Database system', 'wphave' ), 'database_version' => __( 'Database version', 'wphave' ), 'wordpress_version' => __( 'WordPress version', 'wphave' ), 'environment_type' => __( 'Environment type', 'wphave' ), 'is_multisite' => __( 'Multisite', 'wphave' ), 'locale' => __( 'Site language', 'wphave' ) );
	}

	/** Build a stable one-way fingerprint without retaining extension paths or names. */

	private static function inventory_hash( array $inventory ): string {
		ksort( $inventory, SORT_STRING );
		return hash( 'sha256', wp_json_encode( $inventory ) );
	}

	/** Normalize an installation URL without credentials, query parameters or fragments. */

	private static function public_url( string $url ): string {
		$parts = wp_parse_url( $url );
		if( ! is_array( $parts ) || empty( $parts['host'] ) ) return '';
		$scheme = isset( $parts['scheme'] ) ? strtolower( $parts['scheme'] ) . '://' : '';
		$port = isset( $parts['port'] ) ? ':' . absint( $parts['port'] ) : '';
		$path = isset( $parts['path'] ) ? '/' . ltrim( $parts['path'], '/' ) : '/';
		return mb_substr( $scheme . strtolower( $parts['host'] ) . $port . $path, 0, WPHAVE_Activity_Changes::MAX_VALUE_LENGTH );
	}

	/** Identify MySQL-compatible database variants without exposing connection data. */

	private static function database_type(): string {
		global $wpdb;
		$info = strtolower( (string) $wpdb->db_server_info() );
		if( str_contains( $info, 'mariadb' ) ) return 'MariaDB';
		return 'MySQL';
	}

	/** Resolve the persisted site language independently from the current user locale. */

	private static function site_locale(): string {
		$locale = sanitize_text_field( (string) get_option( 'WPLANG', '' ) );
		return $locale ?: 'en_US';
	}
}

WPHAVE_Activity_Environment_Monitor::init();
