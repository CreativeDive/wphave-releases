<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Central presentation and policy registry for stable activity event names.
 *
 * Stored event identifiers remain presentation-neutral. This registry gives
 * every exact or wildcard event family a readable action and allows features
 * to extend the catalog without coupling PHP emitters to the React screen.
 */

final class WPHAVE_Activity_Events {

	private static array $definitions = array();

	/** Register built-in event families and allow feature-owned extensions. */

	public static function init(): void {
		self::$definitions = self::defaults();
		do_action( 'wphave/activity/register_events', __CLASS__ );
	}

	/** Register or replace presentation metadata for an event or wildcard family. */

	public static function register( string $pattern, array $metadata ): void {
		$pattern = strtolower( trim( $pattern ) );
		if( $pattern ) self::$definitions[$pattern] = $metadata;
	}

	/**
	 * Return client-safe presentation metadata for one stable event name.
	 *
	 * `prefix_failure` defaults to true so generic actions become a complete
	 * failure sentence. Exact definitions that already describe failure disable
	 * it to avoid output such as "Failed: update failed".
	 */

	public static function presentation( string $event_type ): array {
		$event_type = strtolower( $event_type );
		$metadata = self::$definitions[$event_type] ?? array();
		if( ! $metadata ) foreach( self::$definitions as $pattern => $definition ) if( str_contains( $pattern, '*' ) && fnmatch( $pattern, $event_type ) ) { $metadata = $definition; break; }
		$label = (string) ( $metadata['label'] ?? '' );
		return array( 'label' => $label, 'icon' => sanitize_key( (string) ( $metadata['icon'] ?? '' ) ), 'prefixFailure' => ! isset( $metadata['prefix_failure'] ) || (bool) $metadata['prefix_failure'] );
	}

	/** Return the built-in exact and family-level event catalog. */
    
	private static function defaults(): array {
		return array(
			'content.created' => array( 'label' => __( 'Created', 'wphave' ) ),
			'content.updated' => array( 'label' => __( 'Updated', 'wphave' ) ),
			'content.published' => array( 'label' => __( 'Published', 'wphave' ) ),
			'content.trashed' => array( 'label' => __( 'Moved to trash', 'wphave' ) ),
			'content.deleted' => array( 'label' => __( 'Permanently deleted', 'wphave' ) ),
			'settings.updated' => array( 'label' => __( 'Updated', 'wphave' ) ),
			'content.terms_updated' => array( 'label' => __( 'Updated categories or tags for', 'wphave' ) ),
			'content.metadata_updated' => array( 'label' => __( 'Updated content metadata for', 'wphave' ) ),
			'seo.metadata_updated' => array( 'label' => __( 'Updated SEO metadata for', 'wphave' ) ),
			'security.application_password_created' => array( 'label' => __( 'Created an application password for', 'wphave' ) ),
			'security.application_password_updated' => array( 'label' => __( 'Updated an application password for', 'wphave' ) ),
			'security.application_password_deleted' => array( 'label' => __( 'Deleted an application password for', 'wphave' ) ),
			'media.uploaded' => array( 'label' => __( 'Uploaded media item', 'wphave' ) ),
			'media.updated' => array( 'label' => __( 'Updated media item', 'wphave' ) ),
			'media.deleted' => array( 'label' => __( 'Deleted media item', 'wphave' ) ),
			'comment.created' => array( 'label' => __( 'Added a comment to', 'wphave' ) ),
			'comment.updated' => array( 'label' => __( 'Updated a comment on', 'wphave' ) ),
			'comment.status_changed' => array( 'label' => __( 'Changed the comment status for', 'wphave' ) ),
			'comment.deleted' => array( 'label' => __( 'Deleted a comment from', 'wphave' ) ),
			'taxonomy.term_created' => array( 'label' => __( 'Created term', 'wphave' ) ),
			'taxonomy.term_updated' => array( 'label' => __( 'Updated term', 'wphave' ) ),
			'taxonomy.term_deleted' => array( 'label' => __( 'Deleted term', 'wphave' ) ),
			'user.created' => array( 'label' => __( 'Created user account', 'wphave' ) ),
			'user.updated' => array( 'label' => __( 'Updated user account', 'wphave' ) ),
			'user.deleted' => array( 'label' => __( 'Deleted user account', 'wphave' ) ),
			'user.role_changed' => array( 'label' => __( 'Changed the primary role for', 'wphave' ) ),
			'user.role_added' => array( 'label' => __( 'Added a role to', 'wphave' ) ),
			'user.role_removed' => array( 'label' => __( 'Removed a role from', 'wphave' ) ),
			'security.login_succeeded' => array( 'label' => __( 'Signed in as', 'wphave' ) ),
			'security.logout' => array( 'label' => __( 'Signed out', 'wphave' ) ),
			'system.php_error' => array( 'label' => __( 'Detected a fatal PHP error in', 'wphave' ) ),
			'system.database_migrated' => array( 'label' => __( 'Updated the database schema for', 'wphave' ) ),
			'system.domain_changed' => array( 'label' => __( 'Changed', 'wphave' ) ),
			'system.runtime_changed' => array( 'label' => __( 'Changed the hosting environment for', 'wphave' ) ),
			'activity.log_cleared' => array( 'label' => __( 'Cleared', 'wphave' ) ),
			'activity.settings_updated' => array( 'label' => __( 'Updated activity logging settings for', 'wphave' ) ),
			'remote.wphave_license_checked' => array( 'label' => __( 'Checked Pro and license status with', 'wphave' ) ),
			'remote.wphave_update_checked' => array( 'label' => __( 'Checked for', 'wphave' ) ),
			'remote.wphave_request_completed' => array( 'label' => __( 'Completed a server request to', 'wphave' ) ),
			'remote.wphave_request_failed' => array( 'label' => __( 'Could not contact', 'wphave' ), 'prefix_failure' => false ),
			'cron.job_completed' => array( 'label' => __( 'Completed scheduled job', 'wphave' ) ),
			'cron.job_failed' => array( 'label' => __( 'Scheduled job did not complete', 'wphave' ), 'prefix_failure' => false ),
			'security.login_failed' => array( 'label' => __( 'Sign-in attempt failed for', 'wphave' ), 'prefix_failure' => false ),
			'content.navigation_created' => array( 'label' => __( 'Created navigation', 'wphave' ) ),
			'content.navigation_updated' => array( 'label' => __( 'Updated navigation', 'wphave' ) ),
			'content.navigation_deleted' => array( 'label' => __( 'Deleted navigation', 'wphave' ) ),
			'settings.theme_customization_updated' => array( 'label' => __( 'Updated theme customization for', 'wphave' ) ),
			'system.database_migration_failed' => array( 'label' => __( 'Database migration failed for', 'wphave' ), 'prefix_failure' => false ),
			'system.plugin_update_failed' => array( 'label' => __( 'Plugin update failed for', 'wphave' ), 'prefix_failure' => false ),
			'system.theme_update_failed' => array( 'label' => __( 'Theme update failed for', 'wphave' ), 'prefix_failure' => false ),
			'system.core_update_failed' => array( 'label' => __( 'WordPress update failed for', 'wphave' ), 'prefix_failure' => false ),
			'system.plugin_activated' => array( 'label' => __( 'Activated plugin', 'wphave' ) ),
			'system.plugin_deactivated' => array( 'label' => __( 'Deactivated plugin', 'wphave' ) ),
			'system.plugin_installed' => array( 'label' => __( 'Installed plugin', 'wphave' ) ),
			'system.plugin_updated' => array( 'label' => __( 'Updated plugin', 'wphave' ) ),
			'system.plugin_deleted' => array( 'label' => __( 'Deleted plugin', 'wphave' ) ),
			'system.theme_switched' => array( 'label' => __( 'Switched to theme', 'wphave' ) ),
			'system.theme_installed' => array( 'label' => __( 'Installed theme', 'wphave' ) ),
			'system.theme_updated' => array( 'label' => __( 'Updated theme', 'wphave' ) ),
			'system.theme_deleted' => array( 'label' => __( 'Deleted theme', 'wphave' ) ),
			'system.core_installed' => array( 'label' => __( 'Installed', 'wphave' ) ),
			'system.core_updated' => array( 'label' => __( 'Updated', 'wphave' ) ),
			'backup.backup-created' => array( 'label' => __( 'Started backup', 'wphave' ) ),
			'backup.backup-completed' => array( 'label' => __( 'Completed backup', 'wphave' ) ),
			'backup.backup-failed' => array( 'label' => __( 'Backup failed for', 'wphave' ), 'prefix_failure' => false ),
			'backup.restore-created' => array( 'label' => __( 'Started restore from', 'wphave' ) ),
			'backup.restore-completed' => array( 'label' => __( 'Restored website from', 'wphave' ) ),
			'backup.restore-failed' => array( 'label' => __( 'Restore failed for', 'wphave' ), 'prefix_failure' => false ),
			'backup.restore-test-created' => array( 'label' => __( 'Started restore test for', 'wphave' ) ),
			'backup.restore-test-completed' => array( 'label' => __( 'Completed restore test for', 'wphave' ) ),
			'backup.restore-test-failed' => array( 'label' => __( 'Restore test failed for', 'wphave' ), 'prefix_failure' => false ),
			'backup.backup-deleted' => array( 'label' => __( 'Deleted restore point', 'wphave' ) ),
			'backup.backup-imported' => array( 'label' => __( 'Imported restore point', 'wphave' ) ),
			'backup.backup-retention-deleted' => array( 'label' => __( 'Removed expired restore point', 'wphave' ) ),
			'backup.scheduled-backup-started' => array( 'label' => __( 'Started scheduled backup', 'wphave' ) ),
			'backup.scheduled-backup-skipped' => array( 'label' => __( 'Skipped scheduled backup for', 'wphave' ) ),
			'backup.scheduled-backup-failed' => array( 'label' => __( 'Scheduled backup failed for', 'wphave' ), 'prefix_failure' => false ),
			'redirect.created' => array( 'label' => __( 'Created redirect from', 'wphave' ) ),
			'redirect.updated' => array( 'label' => __( 'Updated redirect from', 'wphave' ) ),
			'redirect.deleted' => array( 'label' => __( 'Deleted redirect from', 'wphave' ) ),
			'cache.clear-all' => array( 'label' => __( 'Cleared all entries from', 'wphave' ) ),
			'cache.clear-post' => array( 'label' => __( 'Cleared an entry from', 'wphave' ) ),
			'cache.start-warmup' => array( 'label' => __( 'Started warming', 'wphave' ) ),
			'cache.cancel-warmup' => array( 'label' => __( 'Stopped warming', 'wphave' ) ),
			'cache.warmup_completed' => array( 'label' => __( 'Finished warming', 'wphave' ) ),
			'security_scan.started' => array( 'label' => __( 'Started', 'wphave' ) ),
			'security_scan.completed' => array( 'label' => __( 'Completed', 'wphave' ) ),
			'privacy_scan.started' => array( 'label' => __( 'Started', 'wphave' ) ),
			'privacy_scan.completed' => array( 'label' => __( 'Completed', 'wphave' ) ),
			'content_audit.started' => array( 'label' => __( 'Started', 'wphave' ) ),
			'content_audit.completed' => array( 'label' => __( 'Completed', 'wphave' ) ),
			'content_type.created' => array( 'label' => __( 'Created content type', 'wphave' ) ),
			'content_type.updated' => array( 'label' => __( 'Updated content type', 'wphave' ) ),
			'content_type.duplicated' => array( 'label' => __( 'Duplicated content type', 'wphave' ) ),
			'content_type.deleted' => array( 'label' => __( 'Deleted content type', 'wphave' ) ),
			'media.folder_created' => array( 'label' => __( 'Created media folder', 'wphave' ) ),
			'media.folder_updated' => array( 'label' => __( 'Updated media folder', 'wphave' ) ),
			'media.folder_deleted' => array( 'label' => __( 'Deleted media folder', 'wphave' ) ),
			'media.folder_assigned' => array( 'label' => __( 'Changed the media folder for', 'wphave' ) ),
			'analytics.goal_created' => array( 'label' => __( 'Created analytics goal', 'wphave' ) ),
			'analytics.goal_updated' => array( 'label' => __( 'Updated analytics goal', 'wphave' ) ),
			'analytics.goal_deleted' => array( 'label' => __( 'Deleted analytics goal', 'wphave' ) ),
			'license.status_changed' => array( 'label' => __( 'Changed the license status for', 'wphave' ) ),
			'security.email_change_cancelled' => array( 'label' => __( 'Cancelled the email address change for', 'wphave' ) ),
			'media.details_updated' => array( 'label' => __( 'Updated media details for', 'wphave' ) ),
			'taxonomy.object_types_updated' => array( 'label' => __( 'Changed assigned content types for', 'wphave' ) ),
			'support.request_sent' => array( 'label' => __( 'Sent a support request for', 'wphave' ) ),
			'maintenance.configuration_updated' => array( 'label' => __( 'Updated system configuration for', 'wphave' ) ),
			'maintenance.transients_delete' => array( 'label' => __( 'Deleted transient data from', 'wphave' ) ),
			'maintenance.transients_delete_expired' => array( 'label' => __( 'Removed expired transient data from', 'wphave' ) ),
			'maintenance.transients_bulk_delete' => array( 'label' => __( 'Deleted multiple transient entries from', 'wphave' ) ),
			'maintenance.monitor_started' => array( 'label' => __( 'Started monitoring', 'wphave' ) ),
			'maintenance.monitor_stopped' => array( 'label' => __( 'Stopped monitoring', 'wphave' ) ),
			'maintenance.monitor_cleared' => array( 'label' => __( 'Cleared monitoring data for', 'wphave' ) ),
			'performance.request_anomaly' => array( 'label' => __( 'Detected an unusually slow request for', 'wphave' ) ),
			'export.*' => array( 'label' => __( 'Exported', 'wphave' ) ),
			'backup.*' => array( 'label' => __( 'Processed backup operation for', 'wphave' ) ),
			'font.*' => array( 'label' => __( 'Changed font resources for', 'wphave' ) ),
			'composition.*' => array( 'label' => __( 'Changed site composition', 'wphave' ) ),
			'note.*' => array( 'label' => __( 'Changed note', 'wphave' ) ),
			'maintenance.*' => array( 'label' => __( 'Performed maintenance for', 'wphave' ) ),
			'performance.*' => array( 'label' => __( 'Detected a performance issue for', 'wphave' ) ),
		);
	}

}

add_action( 'init', array( 'WPHAVE_Activity_Events', 'init' ), 5 );
