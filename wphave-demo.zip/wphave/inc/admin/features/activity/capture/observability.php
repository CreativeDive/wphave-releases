<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Optional observability for scheduled jobs and WPHAVE-owned remote requests.
 *
 * Only bounded operational metadata is recorded. Request bodies, query strings,
 * PRIVACY INVARIANT: Response bodies, headers and callback arguments never enter the Activity Log.
 */

final class WPHAVE_Activity_Observability {

	private static array $cron_runs = array();
	private static array $cron_metadata = array();

	/** Register low-level observers; each observer remains inert until enabled. */

	public static function init(): void {
		add_filter( 'http_request_args', array( __CLASS__, 'start_http_request' ), 10, 2 );
		add_action( 'http_api_debug', array( __CLASS__, 'finish_http_request' ), 10, 5 );
		add_action( 'wp_loaded', array( __CLASS__, 'register_cron_observers' ), 5 );
		add_action( 'shutdown', array( __CLASS__, 'record_interrupted_cron_jobs' ), 20 );
		add_action( 'wphave_cache_warmup_completed', array( __CLASS__, 'record_cache_warmup_completed' ), 10, 2 );
	}

	/** Capture a start time for one outbound request to a WPHAVE-owned host. */

	public static function start_http_request( array $args, string $url ): array {
		if( ! self::should_observe_http_request( $url ) ) return $args;
		$args['_wphave_activity_started'] = microtime( true );
		return $args;
	}

	/** Record the bounded outcome of one WPHAVE-owned server request. */

	public static function finish_http_request( $response, string $context, $transport, array $args, string $url ): void {
		if( $context !== 'response' || ! self::should_observe_http_request( $url ) ) return;
		$started = (float) ( $args['_wphave_activity_started'] ?? 0 );
		$code = is_wp_error( $response ) ? 0 : wp_remote_retrieve_response_code( $response );
		$failed = is_wp_error( $response ) || $code >= 400;
		$purpose = self::request_purpose( $url );
		$event = $failed ? 'remote.wphave_request_failed' : ( $purpose['event'] ?: 'remote.wphave_request_completed' );
		WPHAVE_Activity_Log::record( $event, array(
			'category' => 'system',
			'action' => $failed ? 'failed' : 'completed',
			'status' => $failed ? 'failure' : 'success',
			'severity' => $failed ? 'warning' : 'info',
			'actor_type' => 'system',
			'object_type' => 'remote_request',
			'object_label' => $purpose['label'] ?: self::safe_endpoint( $url ),
			'context' => array( 'purpose' => $purpose['purpose'], 'endpoint' => self::safe_endpoint( $url ), 'method' => sanitize_key( $args['method'] ?? 'get' ), 'http_status' => absint( $code ), 'duration_ms' => $started ? round( ( microtime( true ) - $started ) * 1000, 2 ) : null, 'transport' => is_object( $transport ) ? get_class( $transport ) : '', 'error_code' => is_wp_error( $response ) ? $response->get_error_code() : '' ),
		) );
	}

	/** Attach before/after observers to currently registered scheduled hooks. */

	public static function register_cron_observers(): void {
		if( ! wp_doing_cron() || ! self::enabled( 'record_cron_runs' ) || ! function_exists( '_get_cron_array' ) ) return;
		$hooks = array();
		foreach( (array) _get_cron_array() as $timestamp => $events ) foreach( (array) $events as $hook => $instances ) {
			if( ! is_string( $hook ) || $hook === '' ) continue;
			if( false === has_action( $hook ) ) continue;
			if( ! self::should_observe_cron_hook( $hook ) ) continue;
			$hooks[$hook] = true;
			foreach( $instances as $instance ) self::$cron_metadata[$hook][] = array( 'scheduled_at' => (int) $timestamp, 'schedule' => sanitize_key( $instance['schedule'] ?? '' ) );
		}
		foreach( array_keys( $hooks ) as $hook ) {
			add_action( $hook, static function() use ( $hook ) { self::start_cron_job( $hook ); }, -PHP_INT_MAX );
			add_action( $hook, static function() use ( $hook ) { self::finish_cron_job( $hook ); }, PHP_INT_MAX );
		}
	}

	/**
	 * Check whether one cron hook is included in detailed Activity capture.
	 *
	 * High-frequency hooks require a second opt-in because they would otherwise
	 * dominate the Activity timeline.
	 */

	public static function should_observe_cron_hook( string $hook ): bool {
		if( ! self::enabled( 'record_cron_runs' ) ) return false;
		if( false === has_action( $hook ) ) return false;
		if( in_array( $hook, array( 'wphave_process_warmup_queue', 'wphave_performance_monitor_cleanup' ), true ) ) return false;
		return $hook !== 'wphave_presence_cleanup' || self::enabled( 'record_high_frequency_executions' );
	}

	/** Check whether one WPHAVE request should enter detailed Activity capture. */

	public static function should_observe_http_request( string $url ): bool {
		if( ! self::enabled( 'record_wphave_requests' ) || ! self::is_wphave_url( $url ) ) return false;
		return ! self::is_update_check( $url ) || self::enabled( 'record_high_frequency_executions' );
	}

	/** Record one semantic completion event for an entire cache warmup generation. */

	public static function record_cache_warmup_completed( string $generation, int $total ): void {
		if( ! self::enabled( 'record_cron_runs' ) ) return;
		WPHAVE_Activity_Log::record( 'cache.warmup_completed', array( 'category' => 'cache', 'action' => 'completed', 'actor_type' => 'system', 'object_type' => 'page_cache', 'object_label' => __( 'Page cache', 'wphave' ), 'context' => array( 'generation' => sanitize_text_field( $generation ), 'urls_processed' => absint( $total ) ) ) );
	}

	/** Start timing one scheduled hook execution. */

	private static function start_cron_job( string $hook ): void {
		$metadata = array_shift( self::$cron_metadata[$hook] );
		if( ! $metadata ) $metadata = array( 'scheduled_at' => time(), 'schedule' => '' );
		self::$cron_runs[$hook][] = array( 'started' => microtime( true ), 'scheduled_at' => (int) $metadata['scheduled_at'], 'schedule' => $metadata['schedule'] );
	}

	/** Record one completed scheduled hook execution without its callback arguments. */

	private static function finish_cron_job( string $hook ): void {
		$run = array_pop( self::$cron_runs[$hook] );
		if( ! $run ) return;
		WPHAVE_Activity_Log::record( 'cron.job_completed', array( 'category' => 'system', 'action' => 'completed', 'actor_type' => 'cron', 'object_type' => 'cron_hook', 'object_label' => self::cron_label( $hook ), 'context' => array( 'hook' => $hook, 'schedule' => $run['schedule'], 'scheduled_at' => gmdate( 'c', $run['scheduled_at'] ), 'late_by_seconds' => max( 0, time() - $run['scheduled_at'] ), 'duration_ms' => round( ( microtime( true ) - $run['started'] ) * 1000, 2 ) ) ) );
	}

	/** Record jobs that started but never reached the final observer. */

	public static function record_interrupted_cron_jobs(): void {
		foreach( self::$cron_runs as $hook => $runs ) foreach( $runs as $run ) {
			WPHAVE_Activity_Log::record( 'cron.job_failed', array( 'category' => 'system', 'action' => 'failed', 'status' => 'failure', 'severity' => 'warning', 'actor_type' => 'cron', 'object_type' => 'cron_hook', 'object_label' => self::cron_label( $hook ), 'context' => array( 'hook' => $hook, 'schedule' => $run['schedule'], 'scheduled_at' => gmdate( 'c', $run['scheduled_at'] ), 'duration_ms' => round( ( microtime( true ) - $run['started'] ) * 1000, 2 ), 'interrupted' => true ) ) );
		}
		self::$cron_runs = array();
	}

	/** Return whether one opt-in observability feature is enabled. */

	private static function enabled( string $key ): bool {
		return ! empty( WPHAVE_Activity_Policy::get()[$key] );
	}

	/** Return whether a URL belongs to wphave.com or one of its subdomains. */

	private static function is_wphave_url( string $url ): bool {
		$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
		return $host === 'wphave.com' || str_ends_with( $host, '.wphave.com' );
	}

	/** Return whether a request is a routine WPHAVE update check. */

	private static function is_update_check( string $url ): bool {
		return str_contains( strtolower( (string) wp_parse_url( $url, PHP_URL_PATH ) ), '/server/updates/' );
	}

	/** Resolve known WPHAVE endpoints to a stable purpose and readable object. */

	private static function request_purpose( string $url ): array {
		$path = strtolower( (string) wp_parse_url( $url, PHP_URL_PATH ) );
		if( str_contains( $path, '/server/updates/' ) ) return array( 'event' => 'remote.wphave_update_checked', 'purpose' => 'plugin_update_check', 'label' => __( 'WPHAVE updates', 'wphave' ) );
		if( str_contains( $path, 'license' ) || str_contains( $path, 'status' ) ) return array( 'event' => 'remote.wphave_license_checked', 'purpose' => 'license_status_check', 'label' => __( 'WPHAVE Pro status', 'wphave' ) );
		return array( 'event' => '', 'purpose' => 'wphave_request', 'label' => '' );
	}

	/** Resolve common cron hooks to labels users can understand at a glance. */

	private static function cron_label( string $hook ): string {
		$labels = array(
			'wphave_presence_cleanup' => __( 'Clean up inactive user sessions', 'wphave' ),
			'wphave_activity_cleanup' => __( 'Clean up expired activity events', 'wphave' ),
			'wphave_activity_privacy_scrub' => __( 'Remove legacy private activity data', 'wphave' ),
			'wphave_activity_environment_monitor' => __( 'Check the hosting environment', 'wphave' ),
			'wphave_process_warmup_queue' => __( 'Warm the page cache', 'wphave' ),
			'wphave_analytics_aggregate_daily' => __( 'Aggregate analytics data', 'wphave' ),
			'wphave_analytics_cleanup_events' => __( 'Clean up analytics data', 'wphave' ),
			'do_pings' => __( 'Send post trackbacks', 'wphave' ),
			'wp_version_check' => __( 'Check for WordPress updates', 'wphave' ),
			'wp_update_plugins' => __( 'Check for plugin updates', 'wphave' ),
			'wp_update_themes' => __( 'Check for theme updates', 'wphave' ),
		);
		if( isset( $labels[$hook] ) ) return $labels[$hook];
		return ucwords( str_replace( array( 'wphave_', 'wp_', '_' ), array( 'WPHAVE ', 'WordPress ', ' ' ), $hook ) );
	}

	/** Return a query-free WPHAVE host and path label. */
    
	private static function safe_endpoint( string $url ): string {
		$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
		$path = (string) wp_parse_url( $url, PHP_URL_PATH );
		return $host . ( $path ?: '/' );
	}
}

WPHAVE_Activity_Observability::init();
