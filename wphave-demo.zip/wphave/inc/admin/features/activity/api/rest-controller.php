<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Exposes permission-checked, read-only activity queries and log settings. */

final class WPHAVE_Activity_REST_Controller {

	/** Register REST route registration on rest_api_init. */

	public static function init(): void {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
		add_filter( 'rest_pre_serve_request', array( __CLASS__, 'serve_export' ), 10, 4 );
	}

	/** Register list, detail, facets, global settings and clear endpoints. */

	public static function register_routes(): void {
		register_rest_route( 'wphave/v1', '/activity', array(
			array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( __CLASS__, 'index' ), 'permission_callback' => array( __CLASS__, 'can_view' ), 'args' => self::query_args() ),
			array( 'methods' => WP_REST_Server::DELETABLE, 'callback' => array( __CLASS__, 'clear' ), 'permission_callback' => array( __CLASS__, 'can_manage' ), 'args' => array( 'confirm' => array( 'required' => true, 'type' => 'boolean' ) ) ),
			array( 'methods' => WP_REST_Server::EDITABLE, 'callback' => array( __CLASS__, 'settings' ), 'permission_callback' => array( __CLASS__, 'can_manage_settings' ), 'args' => array( 'retentionDays' => array( 'required' => true, 'type' => 'integer', 'minimum' => 0, 'maximum' => 3650 ) ) ),
		) );
		register_rest_route( 'wphave/v1', '/activity/facets', array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( __CLASS__, 'facets' ), 'permission_callback' => array( __CLASS__, 'can_view' ) ) );
		register_rest_route( 'wphave/v1', '/activity/insights', array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( __CLASS__, 'insights' ), 'permission_callback' => array( __CLASS__, 'can_view' ) ) );
		register_rest_route( 'wphave/v1', '/activity/composition', array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( __CLASS__, 'composition' ), 'permission_callback' => array( __CLASS__, 'can_view' ), 'args' => self::query_args() ) );
		register_rest_route( 'wphave/v1', '/activity/export', array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( __CLASS__, 'export' ), 'permission_callback' => array( __CLASS__, 'can_manage' ), 'args' => self::query_args() ) );
		register_rest_route( 'wphave/v1', '/activity/settings', array(
			array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( __CLASS__, 'get_settings' ), 'permission_callback' => array( __CLASS__, 'can_manage' ) ),
			array( 'methods' => WP_REST_Server::EDITABLE, 'callback' => array( __CLASS__, 'settings' ), 'permission_callback' => array( __CLASS__, 'can_manage_settings' ), 'args' => self::settings_args() ),
		) );
		register_rest_route( 'wphave/v1', '/activity/observe', array( 'methods' => WP_REST_Server::CREATABLE, 'callback' => array( __CLASS__, 'observe' ), 'permission_callback' => array( __CLASS__, 'can_observe' ), 'args' => array( 'operation' => array( 'required' => true, 'type' => 'string', 'enum' => array( 'authorized', 'activate', 'deactivate', 'license', 'installs', 'status' ) ), 'durationMs' => array( 'type' => 'number', 'minimum' => 0, 'maximum' => 120000 ), 'httpStatus' => array( 'type' => 'integer', 'minimum' => 0, 'maximum' => 599 ), 'transportFailure' => array( 'type' => 'boolean' ) ) ) );
		register_rest_route( 'wphave/v1', '/activity/object/(?P<type>[a-z0-9_-]+)/(?P<id>\d+)', array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( __CLASS__, 'object_history' ), 'permission_callback' => array( __CLASS__, 'can_view' ) ) );
		register_rest_route( 'wphave/v1', '/activity/(?P<id>\d+)/related', array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( __CLASS__, 'related' ), 'permission_callback' => array( __CLASS__, 'can_view' ) ) );
		register_rest_route( 'wphave/v1', '/activity/(?P<id>\d+)', array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( __CLASS__, 'show' ), 'permission_callback' => array( __CLASS__, 'can_view' ) ) );
	}

	/** Check whether the current user may inspect activity events. */

	public static function can_view(): bool {
		// AUTHORIZATION INVARIANT: Activity entries may contain actor identities and
		// operational metadata. Feature enablement alone never grants disclosure;
		// the dedicated read capability remains independent from mutation authority.
		return wphave_activity_feature_enabled() && ( current_user_can( 'wphave_view_activity_log' ) || current_user_can( 'manage_options' ) );
	}

	/** Check whether the current user may change retention or clear the log. */

	public static function can_manage(): bool {
		// AUTHORIZATION INVARIANT: Clearing or exporting the activity ledger requires
		// its management capability; possession of the read capability is insufficient.
		return wphave_activity_feature_enabled() && ( current_user_can( 'wphave_manage_activity_log' ) || current_user_can( 'manage_options' ) );
	}

	/** Check whether the current user may change the Pro-only global policy. */

	public static function can_manage_settings(): bool {
		return self::can_manage() && function_exists( 'wphave_has_pro_access' ) && wphave_has_pro_access();
	}

	/** Check whether the current user may submit bounded client observability. */
	public static function can_observe(): bool {
		return wphave_activity_feature_enabled() && ( self::can_manage() || current_user_can( 'wphave_manage_license' ) );
	}

	/** Return the stable denial used by final Activity callback guards. */

	private static function forbidden() : WP_Error {
		return new WP_Error(
			'wphave_activity_forbidden',
			__( 'You are not allowed to access Activity data.', 'wphave' ),
			array( 'status' => 403 )
		);
	}

	/** Return a server-paginated and filtered activity event collection. */

	public static function index( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		// AUTHORIZATION INVARIANT: REST permission is only an early dispatch gate.
		// Every public Activity callback repeats its distinct read, manage, settings
		// or observe policy before querying, changing or streaming ledger state.
		if( ! self::can_view() ) {
			return self::forbidden();
		}
		$result = WPHAVE_Activity_Query::search( $request->get_params() );
		$response = rest_ensure_response( array( 'items' => self::prepare_collection( $result['rows'] ), 'total' => $result['total'], 'page' => $result['page'], 'perPage' => $result['per_page'], 'hasMore' => $result['has_more'], 'nextCursor' => $result['next_cursor'], 'retentionDays' => WPHAVE_Activity_Log::retention_days() ) );
		$response->header( 'Cache-Control', 'no-store' );
		return $response;
	}

	/** Return one activity event by its immutable id. */

	public static function show( WP_REST_Request $request ) {
		if( ! self::can_view() ) {
			return self::forbidden();
		}
		$row = WPHAVE_Activity_Query::find( absint( $request['id'] ) );
		return $row ? self::no_store( self::prepare( $row ) ) : new WP_Error( 'wphave_activity_not_found', __( 'Activity event not found.', 'wphave' ), array( 'status' => 404 ) );
	}

	/** Return category counts and actor/status values used by DataView filters. */

	public static function facets(): WP_REST_Response|WP_Error {
		if( ! self::can_view() ) {
			return self::forbidden();
		}
		$facets = WPHAVE_Activity_Query::facets();
		return self::no_store( array( 'categories' => $facets['categories'], 'categoryCounts' => $facets['category_counts'], 'total' => $facets['total'], 'actors' => $facets['actors'], 'statuses' => array( 'success', 'failure', 'warning', 'info' ) ) );
	}

	/** Return current warning, critical and pending-follow-up events. */

	public static function insights(): WP_REST_Response|WP_Error {
		if( ! self::can_view() ) {
			return self::forbidden();
		}
		$rows = WPHAVE_Activity_Query::attention( 50 );
		$items = array_values( array_filter( self::prepare_collection( $rows ), static fn( $item ) => in_array( $item['assessmentStatus'], array( 'warning', 'critical' ), true ) || $item['followUpStatus'] === 'pending' ) );
		return self::no_store( array_merge( array( 'items' => $items ), WPHAVE_Activity_Query::attention_counts() ) );
	}

	/** Return independently named initial Activity projections in one transport envelope. */

	public static function composition( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		if( ! self::can_view() ) {
			return self::forbidden();
		}
		return self::no_store( array(
			'list' => self::index( $request )->get_data(),
			'facets' => self::facets()->get_data(),
			'insights' => self::insights()->get_data(),
		) );
	}

	/** Return the chronological history for one domain object. */

	public static function object_history( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		if( ! self::can_view() ) {
			return self::forbidden();
		}
		$rows = WPHAVE_Activity_Query::recent_for_object( sanitize_key( $request['type'] ), absint( $request['id'] ), 100 );
		return self::no_store( array( 'items' => self::prepare_collection( $rows ), 'total' => count( $rows ) ) );
	}

	/** Return explicitly correlated and same-object events for one activity. */

	public static function related( WP_REST_Request $request ) {
		if( ! self::can_view() ) {
			return self::forbidden();
		}
		$row = WPHAVE_Activity_Query::find( absint( $request['id'] ) );
		if( ! $row ) return new WP_Error( 'wphave_activity_not_found', __( 'Activity event not found.', 'wphave' ), array( 'status' => 404 ) );
		$context = WPHAVE_Activity_Log::safe_context( json_decode( $row['context'] ?: '{}', true ) ?: array() );
		$ids = array_map( static fn( $relation ) => absint( $relation['event_id'] ?? 0 ), (array) ( $context['relations'] ?? array() ) );
		$rows = WPHAVE_Activity_Query::find_many( $ids );
		return self::no_store( array( 'items' => self::prepare_collection( $rows ), 'total' => count( $rows ) ) );
	}

	/** Return installation-wide activity settings. */

	public static function get_settings(): WP_REST_Response|WP_Error {
		if( ! self::can_manage() ) {
			return self::forbidden();
		}
		$response = rest_ensure_response( self::prepared_settings() );
		$response->header( 'Cache-Control', 'no-store' );
		return $response;
	}

	/** Mark an authorized request for streamed JSON delivery. */

	public static function export( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		if( ! self::can_manage() ) {
			return self::forbidden();
		}
		return self::no_store( array( 'wphaveActivityExport' => true, 'filters' => array_intersect_key( $request->get_params(), self::query_args() ) ) );
	}

	/** Stream a bounded export directly from database batches to the response. */

	public static function serve_export( bool $served, WP_HTTP_Response $result, WP_REST_Request $request, WP_REST_Server $server ): bool {
		if( $request->get_route() !== '/wphave/v1/activity/export' || $served ) return $served;
		$data = $result->get_data();
		if( empty( $data['wphaveActivityExport'] ) ) return $served;
		if( ! self::can_manage() ) {
			return $served;
		}
		$policy = WPHAVE_Activity_Policy::get();
		$limit = $policy['export_limit'];
		$filters = (array) ( $data['filters'] ?? array() );
		$export_filters = $filters;
		$filters['count_total'] = false;
		$filters['page'] = 1;
		$filters['per_page'] = 100;
		$before_id = 0;
		$count = 0;
		$has_more = true;
		$first = true;
		$charset = (string) get_option( 'blog_charset' );
		$site_url = home_url( '/' );
		$exported_at = gmdate( 'c' );
		// AUTHORIZATION/STREAM INVARIANT: Policy, option and URL resolution invoke
		// filters. Repeat live Activity management authority after preparation and
		// immediately before committing download headers or the first JSON byte.
		if( ! self::can_manage() ) {
			return $served;
		}
		$server->send_header( 'Content-Type', 'application/json; charset=' . $charset );
		$server->send_header( 'Content-Disposition', 'attachment; filename="wphave-activity-' . gmdate( 'Y-m-d' ) . '.json"' );
		$server->send_header( 'Cache-Control', 'no-store' );
		echo '{"schemaVersion":1,"exportedAt":' . wp_json_encode( $exported_at ) . ',"site":' . wp_json_encode( $site_url ) . ',"technicalContextIncluded":' . ( $policy['export_technical_context'] ? 'true' : 'false' ) . ',"events":[';
		while( $has_more && $count < $limit ) {
			$filters['before_id'] = $before_id;
			$batch = WPHAVE_Activity_Query::search( $filters );
			foreach( self::prepare_collection( $batch['rows'] ) as $item ) {
				if( $count >= $limit ) break;
				if( ! $policy['export_technical_context'] ) { $item['context'] = array_intersect_key( $item['context'], array_flip( array( 'changes', 'assessment', 'follow_up' ) ) ); unset( $item['correlationId'], $item['requestId'] ); }
				echo ( $first ? '' : ',' ) . wp_json_encode( $item, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
				$first = false;
				$count++;
			}
			$has_more = $batch['has_more'] && ! empty( $batch['next_cursor'] );
			$before_id = $batch['next_cursor'];
		}
		echo '],"total":' . $count . ',"truncated":' . ( $has_more ? 'true' : 'false' ) . ',"filters":' . wp_json_encode( $export_filters ) . '}';
		return true;
	}

	/** Persist the administrator-selected global activity settings. */

	public static function settings( WP_REST_Request $request ) {
		if( ! self::can_manage_settings() ) {
			return self::forbidden();
		}
		$before = self::prepared_settings();
		$previous_retention = WPHAVE_Activity_Log::retention_days();
		$previous_policy = WPHAVE_Activity_Policy::get();
		if( $request->has_param( 'retentionDays' ) ) WPHAVE_Activity_Log::set_retention_days( absint( $request['retentionDays'] ) );
		$policy = WPHAVE_Activity_Policy::get();
		$map = array( 'criticalRetentionDays' => 'critical_retention_days', 'recordSuccessfulLogins' => 'record_successful_logins', 'recordBackgroundEvents' => 'record_background_events', 'recordRuntimeEvents' => 'record_runtime_events', 'recordSystemEvents' => 'record_system_events', 'recordWphaveRequests' => 'record_wphave_requests', 'recordCronRuns' => 'record_cron_runs', 'recordHighFrequencyExecutions' => 'record_high_frequency_executions', 'exportLimit' => 'export_limit', 'exportTechnicalContext' => 'export_technical_context' );
		foreach( $map as $request_key => $policy_key ) if( $request->has_param( $request_key ) ) $policy[$policy_key] = $request[$request_key];
		if( WPHAVE_Activity_Log::retention_days() && ! empty( $policy['critical_retention_days'] ) ) $policy['critical_retention_days'] = max( WPHAVE_Activity_Log::retention_days(), absint( $policy['critical_retention_days'] ) );
		WPHAVE_Activity_Policy::update( $policy );
		$after = self::prepared_settings();
		$expected = $before;
		foreach( array_keys( self::settings_args() ) as $key ) if( $request->has_param( $key ) ) $expected[$key] = $request[$key];
		if( $after['retentionDays'] && $after['criticalRetentionDays'] ) $expected['criticalRetentionDays'] = max( $after['retentionDays'], absint( $expected['criticalRetentionDays'] ) );
		$failed_keys = array_filter( array_keys( $expected ), static fn( $key ) => array_key_exists( $key, $after ) && $expected[$key] !== $after[$key] );
		if( $failed_keys ) {
			WPHAVE_Activity_Log::set_retention_days( $previous_retention );
			WPHAVE_Activity_Policy::update( $previous_policy );
			return new WP_Error( 'wphave_activity_settings_not_saved', __( 'The activity settings could not be saved completely.', 'wphave' ), array( 'status' => 500 ) );
		}
		$labels = array( 'retentionDays' => __( 'Retention period', 'wphave' ), 'criticalRetentionDays' => __( 'Critical event retention', 'wphave' ), 'recordSuccessfulLogins' => __( 'Successful logins', 'wphave' ), 'recordBackgroundEvents' => __( 'Background activity', 'wphave' ), 'recordRuntimeEvents' => __( 'Runtime events', 'wphave' ), 'recordSystemEvents' => __( 'System activity', 'wphave' ), 'recordWphaveRequests' => __( 'WPHAVE server requests', 'wphave' ), 'recordCronRuns' => __( 'Detailed cron executions', 'wphave' ), 'recordHighFrequencyExecutions' => __( 'High-frequency executions', 'wphave' ), 'exportLimit' => __( 'Export limit', 'wphave' ), 'exportTechnicalContext' => __( 'Technical export context', 'wphave' ) );
		$changes = WPHAVE_Activity_Changes::compare( $before, $after, $labels );
		if( $changes ) WPHAVE_Activity_Log::record( 'activity.settings_updated', array( 'category' => 'system', 'action' => 'updated', 'object_type' => 'activity_log', 'object_label' => __( 'Activity log', 'wphave' ), 'context' => array( 'changes' => $changes ) ) );
		return rest_ensure_response( $after );
	}

	/** Record one bounded browser-side WPHAVE license-server request. */

	public static function observe( WP_REST_Request $request ) {
		if( ! self::can_observe() ) {
			return self::forbidden();
		}
		if( empty( WPHAVE_Activity_Policy::get()['record_wphave_requests'] ) ) return rest_ensure_response( array( 'recorded' => false ) );
		$rate_key = 'wphave_activity_observe_' . get_current_user_id();
		$count = WPHAVE_Rate_Limiter::increment( $rate_key, 5 * MINUTE_IN_SECONDS );
		if( $count > 60 ) return new WP_Error( 'wphave_activity_observe_rate_limited', __( 'Too many activity observations were submitted.', 'wphave' ), array( 'status' => 429 ) );
		$operation = sanitize_key( $request['operation'] );
		$http_status = absint( $request['httpStatus'] );
		$failed = rest_sanitize_boolean( $request['transportFailure'] ) || $http_status >= 400;
		$event_id = WPHAVE_Activity_Log::record( $failed ? 'remote.wphave_request_failed' : 'remote.wphave_license_checked', array( 'category' => 'system', 'action' => $failed ? 'failed' : 'checked', 'status' => $failed ? 'failure' : 'success', 'severity' => $failed ? 'warning' : 'info', 'actor_type' => 'system', 'object_type' => 'remote_request', 'object_label' => __( 'WPHAVE license server', 'wphave' ), 'context' => array( 'operation' => $operation, 'http_status' => $http_status, 'duration_ms' => round( (float) $request['durationMs'], 2 ), 'trigger' => 'browser' ) ) );
		return rest_ensure_response( array( 'recorded' => $event_id > 0 ) );
	}

	/** Permanently clear the log after explicit confirmation. */

	public static function clear( WP_REST_Request $request ) {
		if( ! self::can_manage() ) {
			return self::forbidden();
		}
		if( ! rest_sanitize_boolean( $request['confirm'] ) ) return new WP_Error( 'wphave_activity_confirmation_required', __( 'Log deletion must be confirmed.', 'wphave' ), array( 'status' => 400 ) );
		$count = WPHAVE_Activity_Log::clear();
		WPHAVE_Activity_Log::record( 'activity.log_cleared', array( 'category' => 'system', 'action' => 'deleted', 'severity' => 'warning', 'object_type' => 'activity_log', 'object_label' => __( 'Activity log', 'wphave' ), 'context' => array( 'deleted_events' => $count ) ) );
		return rest_ensure_response( array( 'deleted' => $count ) );
	}

	/** Define and constrain supported list-query arguments. */

	private static function query_args(): array {
		return array(
			'orderby' => array( 'type' => 'string', 'default' => 'occurred_at', 'enum' => array( 'occurred_at', 'event_type', 'category', 'status' ) ),
			'order' => array( 'type' => 'string', 'default' => 'desc', 'enum' => array( 'asc', 'desc' ) ),
			'category' => array( 'type' => 'string', 'maxLength' => 50 ),
			'status' => array( 'type' => 'string', 'enum' => array( 'success', 'failure', 'warning', 'info' ) ),
			'assessment_status' => array( 'type' => 'string', 'enum' => array( 'critical', 'warning', 'good', 'info' ) ),
			'follow_up_status' => array( 'type' => 'string', 'enum' => array( 'pending', 'completed' ) ),
			'event_type' => array( 'type' => 'string', 'maxLength' => 100 ),
			'actor_type' => array( 'type' => 'string', 'maxLength' => 30 ),
			'actor_id' => array( 'type' => 'integer', 'minimum' => 0 ),
			'object_type' => array( 'type' => 'string', 'maxLength' => 50 ),
			'object_id' => array( 'type' => 'integer', 'minimum' => 0 ),
			'search' => array( 'type' => 'string', 'maxLength' => 100 ),
			'after' => array( 'type' => 'string', 'maxLength' => 40 ),
			'before' => array( 'type' => 'string', 'maxLength' => 40 ),
			'before_id' => array( 'type' => 'integer', 'minimum' => 0 ),
			'page' => array( 'type' => 'integer', 'default' => 1, 'minimum' => 1 ),
			'per_page' => array( 'type' => 'integer', 'default' => 30, 'minimum' => 1, 'maximum' => 100 )
		);
	}

	/** Define and constrain supported global Activity Log settings. */

	private static function settings_args(): array {
		return array( 'retentionDays' => array( 'type' => 'integer', 'minimum' => 0, 'maximum' => 3650 ), 'criticalRetentionDays' => array( 'type' => 'integer', 'minimum' => 0, 'maximum' => 3650 ), 'recordSuccessfulLogins' => array( 'type' => 'boolean' ), 'recordBackgroundEvents' => array( 'type' => 'boolean' ), 'recordRuntimeEvents' => array( 'type' => 'boolean' ), 'recordSystemEvents' => array( 'type' => 'boolean' ), 'recordWphaveRequests' => array( 'type' => 'boolean' ), 'recordCronRuns' => array( 'type' => 'boolean' ), 'recordHighFrequencyExecutions' => array( 'type' => 'boolean' ), 'exportLimit' => array( 'type' => 'integer', 'enum' => array( 500, 1000, 5000, 10000 ) ), 'exportTechnicalContext' => array( 'type' => 'boolean' ) );
	}

	/** Transform stored global policy to the stable REST response shape. */

	private static function prepared_settings(): array {
		$policy = WPHAVE_Activity_Policy::get();
		$health = (array) get_option( WPHAVE_Activity_Log::HEALTH_OPTION, array() );
		return array( 'retentionDays' => WPHAVE_Activity_Log::retention_days(), 'criticalRetentionDays' => $policy['critical_retention_days'], 'recordSuccessfulLogins' => $policy['record_successful_logins'], 'recordBackgroundEvents' => $policy['record_background_events'], 'recordRuntimeEvents' => $policy['record_runtime_events'], 'recordSystemEvents' => $policy['record_system_events'], 'recordWphaveRequests' => $policy['record_wphave_requests'], 'recordCronRuns' => $policy['record_cron_runs'], 'recordHighFrequencyExecutions' => $policy['record_high_frequency_executions'], 'exportLimit' => $policy['export_limit'], 'exportTechnicalContext' => $policy['export_technical_context'], 'sensitiveValuesStored' => false, 'health' => array( 'writeFailures' => absint( $health['write_failures'] ?? 0 ), 'lastWriteFailureAt' => sanitize_text_field( (string) ( $health['last_write_failure_at'] ?? '' ) ) ) );
	}

	/** Return sensitive Activity data with an explicit no-store cache policy. */

	private static function no_store( array $data ): WP_REST_Response {
		$response = rest_ensure_response( $data );
		$response->header( 'Cache-Control', 'no-store' );
		return $response;
	}

	/** Transform one database row into the stable REST response shape. */
    
	private static function prepare( array $row, ?array $completion_candidates = null ): array {
		$actor_id = (int) $row['actor_id'];
		$context = WPHAVE_Activity_Log::safe_context( json_decode( $row['context'] ?: '{}', true ) ?: array() );
		$follow_up_status = $row['follow_up_status'] ?? '';
		if( $follow_up_status === 'pending' && ! empty( $context['follow_up'] ) ) {
			$completion = $completion_candidates === null ? WPHAVE_Activity_Query::follow_up_completion( $row, $context['follow_up'] ) : self::matching_completion( $row, $context['follow_up'], $completion_candidates );
			if( $completion ) { $follow_up_status = 'completed'; $context['follow_up']['status'] = 'completed'; $context['follow_up']['completed_event_id'] = (int) $completion['id']; }
		}
		return array( 'id' => (int) $row['id'], 'occurredAt' => gmdate( 'c', strtotime( $row['occurred_at'] . ' UTC' ) ), 'eventType' => $row['event_type'], 'presentation' => WPHAVE_Activity_Events::presentation( $row['event_type'] ), 'category' => $row['category'], 'action' => $row['action'], 'status' => $row['status'], 'severity' => $row['severity'], 'assessmentStatus' => $row['assessment_status'] ?? '', 'followUpStatus' => $follow_up_status, 'correlationId' => $row['correlation_id'] ?? '', 'actor' => array( 'type' => $row['actor_type'], 'id' => $actor_id, 'label' => WPHAVE_Activity_Privacy::sanitize_text( (string) $row['actor_label'], 190 ), 'avatarUrl' => $actor_id ? wphave_get_avatar_url( $actor_id, array( 'size' => 48 ) ) : '' ), 'object' => array( 'type' => $row['object_type'], 'id' => (int) $row['object_id'], 'subtype' => $row['object_subtype'], 'label' => WPHAVE_Activity_Privacy::sanitize_text( (string) $row['object_label'], 190 ) ), 'source' => $row['source'], 'requestId' => $row['request_id'], 'context' => $context );
	}

	/** Serialize a collection with one batched follow-up lookup instead of N queries. */

	private static function prepare_collection( array $rows ): array {
		$types = array();
		$minimum_id = PHP_INT_MAX;
		foreach( $rows as $row ) {
			if( ( $row['follow_up_status'] ?? '' ) !== 'pending' ) continue;
			$context = json_decode( $row['context'] ?: '{}', true ) ?: array();
			if( ! empty( $context['follow_up']['expected_event'] ) ) { $types[] = $context['follow_up']['expected_event']; $minimum_id = min( $minimum_id, (int) $row['id'] ); }
		}
		$candidates = $types ? WPHAVE_Activity_Query::follow_up_candidates( $types, $minimum_id ) : array();
		return array_map( static fn( $row ) => self::prepare( $row, $candidates ), $rows );
	}

	/** Match one follow-up against already loaded successful candidates. */
    
	private static function matching_completion( array $row, array $follow_up, array $candidates ): ?array {
		foreach( $candidates as $candidate ) {
			if( (int) $candidate['id'] <= (int) $row['id'] || $candidate['event_type'] !== ( $follow_up['expected_event'] ?? '' ) ) continue;
			if( ! empty( $follow_up['object_type'] ) && ( $candidate['object_type'] !== $follow_up['object_type'] || (int) $candidate['object_id'] !== absint( $follow_up['object_id'] ?? 0 ) ) ) continue;
			return $candidate;
		}
		return null;
	}

}

WPHAVE_Activity_REST_Controller::init();
