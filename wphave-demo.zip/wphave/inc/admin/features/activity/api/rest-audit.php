<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adapter that translates successful WPHAVE REST mutations into activity events.
 *
 * Feature-owned calls to WPHAVE_Activity_Log remain the preferred integration
 * because they have the richest domain context. This adapter covers centralized
 * REST mutations and records their HTTP failure state consistently.
 */

final class WPHAVE_Activity_REST_Audit {

	/** Register the post-callback REST audit filter. */

	public static function init(): void {
		add_filter( 'rest_request_after_callbacks', array( __CLASS__, 'record_mutation' ), 20, 3 );
	}

	/**
	 * Record a mapped mutation after its REST callback completed.
	 *
	 * The `wphave/activity/rest_event` filter may return or replace an event
	 * definition, allowing new modules to extend the mapper without editing it.
	 *
	 * @param mixed           $response REST callback response.
	 * @param array           $handler  Matched REST handler definition.
	 * @param WP_REST_Request $request  Completed request.
	 * @return mixed Unchanged REST callback response.
	 */

	public static function record_mutation( $response, array $handler, WP_REST_Request $request ) {
		$method = strtoupper( $request->get_method() );
		$route = $request->get_route();
		if( ! in_array( $method, array( 'GET', 'POST', 'PUT', 'PATCH', 'DELETE' ), true ) || ! str_starts_with( $route, '/wphave/v1/' ) || str_starts_with( $route, '/wphave/v1/activity' ) ) return $response;

		$event = self::event_for_request( $route, $method, $request );
		$event = apply_filters( 'wphave/activity/rest_event', $event, $route, $method, $request, $response );
		if( ! $event ) return $response;
		if( str_starts_with( $event['event'], 'settings.' ) && WPHAVE_Activity_Log::request_has_category( 'settings' ) ) return $response;

		$error = is_wp_error( $response );
		$error_data = $error ? (array) $response->get_error_data() : array();
		$status_code = $error ? (int) ( $error_data['status'] ?? 500 ) : ( $response instanceof WP_REST_Response ? $response->get_status() : 200 );
		$response_data = $response instanceof WP_REST_Response ? $response->get_data() : ( is_array( $response ) ? $response : array() );
		$failed = $error || $status_code >= 400 || ( $route === '/wphave/v1/validate-smtp' && is_array( $response_data ) && isset( $response_data['success'] ) && ! $response_data['success'] );
		// Resource no-ops are not edits. License status transitions are captured by
		// the option hooks; token/timestamp refreshes must not look like user edits.
		// Keep failed requests visible, including failed license persistence.
		if( ! $failed && preg_match( '#^/wphave/v1/data/([a-z_]+)$#', $route, $resource ) ) {
			if( $resource[1] === 'license_settings' || ( is_array( $response_data ) && ( $response_data['changed'] ?? null ) === false ) ) {
				return $response;
			}
		}

		$context = array_merge( $event['context'] ?? array(), array( 'route' => $route, 'method' => $method, 'http_status' => $status_code ) );
		if( ! in_array( $event['action'], array( 'created', 'deleted', 'started', 'completed', 'cancelled' ), true ) && empty( $context['changes'] ) ) $context['changes'] = WPHAVE_Activity_Changes::touched( array_keys( $request->get_params() ) );
		if( $error ) $context['error_code'] = $response->get_error_code();

		WPHAVE_Activity_Log::record( $event['event'], array(
			'category' => $event['category'],
			'action' => $event['action'],
			'status' => $failed ? 'failure' : 'success',
			'severity' => $failed ? 'warning' : 'info',
			'object_type' => $event['object_type'] ?? $event['category'],
			'object_id' => absint( $event['object_id'] ?? 0 ),
			'object_subtype' => sanitize_key( $event['object_subtype'] ?? '' ),
			'object_label' => sanitize_text_field( (string) ( $event['object_label'] ?? '' ) ),
			'context' => $context,
		) );

		return $response;
	}

	/** Map known WPHAVE mutation routes to stable semantic event definitions. */

	public static function event_for_request( string $route, string $method, WP_REST_Request $request ): ?array {
		if( $method === 'GET' ) {
			if( preg_match( '#^/wphave/v1/privacy/exports/(\d+)$#', $route, $matches ) ) return self::event( 'export.privacy_downloaded', 'security', 'exported', 'privacy_export', __( 'Privacy export', 'wphave' ), (int) $matches[1] );
			if( preg_match( '#^/wphave/v1/analytics/export/(goals|conversion-events)$#', $route, $matches ) ) return self::event( 'export.analytics_downloaded', 'security', 'exported', 'analytics_export', $matches[1] );
			return null;
		}
		if( preg_match( '#^/wphave/v1/data/([a-z_]+)$#', $route, $matches ) ) return self::event( 'settings.' . $matches[1] . '_updated', 'settings', 'updated', 'settings', $matches[1] );
		if( preg_match( '#^/wphave/v1/(?:wp-options|onboarding/basics|settings/privacy)$#', $route ) ) return self::event( 'settings.wordpress_updated', 'settings', 'updated', 'settings', 'WordPress' );
		if( $route === '/wphave/v1/user/change-password' ) return self::event( 'security.password_changed', 'security', 'password_changed', 'user', wp_get_current_user()->display_name, get_current_user_id() );
		if( $route === '/wphave/v1/user/change-email' ) return self::event( 'security.email_change_requested', 'security', 'email_change_requested', 'user', wp_get_current_user()->display_name, get_current_user_id() );
		if( $route === '/wphave/v1/user/change-email/cancel' ) return self::event( 'security.email_change_cancelled', 'security', 'email_change_cancelled', 'user', wp_get_current_user()->display_name, get_current_user_id() );
		if( preg_match( '#^/wphave/v1/(?:roles/caps|access/(?:features|role-map))$#', $route ) ) return self::event( 'user.access_updated', 'users', 'access_updated', 'access', 'Access rules' );
		if( preg_match( '#^/wphave/v1/redirects(?:/(\d+)|/bulk)?$#', $route, $matches ) ) {
			$action = $method === 'DELETE' ? 'deleted' : ( $request->get_param( 'id' ) ? 'updated' : ( str_ends_with( $route, '/bulk' ) ? 'bulk_updated' : 'created' ) );
			return self::event( 'redirect.' . $action, 'redirects', $action, 'redirect', (string) ( $request->get_param( 'source_path' ) ?: 'Redirect' ), absint( $matches[1] ?? $request->get_param( 'id' ) ), array( 'source_path' => sanitize_text_field( (string) $request->get_param( 'source_path' ) ), 'target_url' => esc_url_raw( (string) $request->get_param( 'target_url' ) ), 'status_code' => absint( $request->get_param( 'status_code' ) ) ) );
		}
		if( preg_match( '#^/wphave/v1/(?:cache|post-cache)/([^/]+)#', $route, $matches ) ) return self::event( 'cache.' . sanitize_key( $matches[1] ), 'cache', sanitize_key( $matches[1] ), 'cache', 'Page cache' );
		if( $route === '/wphave/v1/content-audit/cancel' ) return self::event( 'content_audit.cancelled', 'system', 'cancelled', 'scan', 'content-audit' );
		if( preg_match( '#^/wphave/v1/fonts/(google/install|local/delete|local/file|local/metadata|local/mapping)$#', $route, $matches ) ) {
			$action = str_replace( '/', '_', $matches[1] );
			return self::event( 'font.' . $action, 'settings', $action, 'font', (string) ( $request->get_param( 'family' ) ?: $request->get_param( 'file' ) ) );
		}
		if( $route === '/wphave/v1/validate-smtp' ) return self::event( 'smtp.tested', 'settings', 'tested', 'smtp', 'SMTP' );
		if( $route === '/wphave/v1/database/schema/update' ) return self::event( 'system.database_migrated', 'system', 'migrated', 'database', 'Database schema' );
		if( preg_match( '#^/wphave/v1/site-compositions(?:/(apply|capture|import|import-archive|snapshot-[0-9]+))$#', $route, $matches ) ) {
			$action = $method === 'DELETE' ? 'deleted' : sanitize_key( $matches[1] );
			return self::event( 'composition.' . $action, 'content', $action, 'site_composition', (string) ( $request->get_param( 'title' ) ?: $request->get_param( 'id' ) ?: 'Site composition' ) );
		}
		if( preg_match( '#^/wphave/v1/transients-(delete|delete-expired|bulk-delete)$#', $route, $matches ) ) return self::event( 'maintenance.transients_' . $matches[1], 'system', 'deleted', 'transient', 'Transients' );
		if( preg_match( '#^/wphave/v1/media/(\d+)/file/(rename|replace)$#', $route, $matches ) ) return self::event( 'media.file_' . $matches[2], 'media', $matches[2], 'attachment', get_the_title( (int) $matches[1] ), (int) $matches[1] );
		if( preg_match( '#^/wphave/v1/media/(\d+)/image/(edit|editor)$#', $route, $matches ) ) return self::event( 'media.image_' . $matches[2], 'media', $matches[2], 'attachment', get_the_title( (int) $matches[1] ), (int) $matches[1] );
		if( $route === '/wphave/v1/regenerate-thumbnails' ) return self::event( 'media.thumbnails_regenerated', 'media', 'regenerated', 'attachment', 'Media library' );
		if( preg_match( '#^/wphave/v1/(?:htaccess/(?:asset-cache|create)|sitemap/flush|debug-log/clear)$#', $route ) ) return self::event( 'maintenance.configuration_updated', 'system', 'updated', 'configuration', trim( str_replace( '/wphave/v1/', '', $route ), '/' ) );
		if( preg_match( '#^/wphave/v1/(?:performance-monitor|request-profiler)/(clear|start|stop)$#', $route, $matches ) ) return self::event( 'maintenance.monitor_' . $matches[1], 'system', $matches[1], 'monitor', trim( str_replace( '/wphave/v1/', '', $route ), '/' ) );
		if( $route === '/wphave/v1/performance-monitor/event' ) {
			$duration = (float) $request->get_param( 'durationMs' );
			$status = absint( $request->get_param( 'status' ) );
			if( $duration < 2000 && $status < 500 ) return null;
			return self::event( 'performance.request_anomaly', 'system', 'detected', 'request', (string) ( $request->get_param( 'label' ) ?: $request->get_param( 'screen' ) ?: 'Request' ), 0, array( 'duration_ms' => $duration, 'http_status' => $status ) );
		}
		if( $route === '/wphave/v1/theme/setup' ) return self::event( 'settings.theme_setup_updated', 'settings', 'updated', 'theme', wp_get_theme()->get( 'Name' ) );
		if( preg_match( '#^/wphave/v1/content-types/(post-types|taxonomies)(?:/(\d+))?(?:/(duplicate))?$#', $route, $matches ) ) {
			$action = $method === 'DELETE' ? 'deleted' : ( ! empty( $matches[3] ) ? 'duplicated' : ( ! empty( $matches[2] ) ? 'updated' : 'created' ) );
			$label = (string) ( $request->get_param( 'pluralName' ) ?: $request->get_param( 'slug' ) ?: ucwords( str_replace( '-', ' ', $matches[1] ) ) . ( ! empty( $matches[2] ) ? ' #' . $matches[2] : '' ) );
			$changes = WPHAVE_Activity_Changes::touched( array_keys( $request->get_params() ), array( 'pluralName' => __( 'Name', 'wphave' ), 'slug' => __( 'Slug', 'wphave' ), 'active' => __( 'Active', 'wphave' ), 'status' => __( 'Status', 'wphave' ), 'config' => __( 'Configuration', 'wphave' ) ) );
			return self::event( 'content_type.' . $action, 'content', $action, 'content_type', $label, absint( $matches[2] ?? 0 ), array( 'definition_type' => sanitize_key( $matches[1] ), 'changes' => $changes ) );
		}
		if( preg_match( '#^/wphave/v1/analytics/goals(?:/([a-zA-Z0-9_-]+))?$#', $route, $matches ) ) {
			$action = $method === 'DELETE' ? 'deleted' : ( ! empty( $request->get_param( 'id' ) ) ? 'updated' : 'created' );
			$changes = WPHAVE_Activity_Changes::touched( array_keys( $request->get_params() ), array( 'label' => __( 'Name', 'wphave' ), 'type' => __( 'Goal type', 'wphave' ), 'match' => __( 'Match rule', 'wphave' ), 'value' => __( 'Value', 'wphave' ), 'enabled' => __( 'Enabled', 'wphave' ) ) );
			return self::event( 'analytics.goal_' . $action, 'settings', $action, 'analytics_goal', (string) ( $request->get_param( 'label' ) ?: ( $matches[1] ?? __( 'Conversion goal', 'wphave' ) ) ), 0, array( 'goal_id' => sanitize_key( (string) ( $matches[1] ?? $request->get_param( 'id' ) ) ), 'changes' => $changes ) );
		}
		if( preg_match( '#^/wphave/v1/taxonomies/([\w-]+)/object-types$#', $route, $matches ) ) return self::event( 'taxonomy.object_types_updated', 'taxonomy', 'updated', 'taxonomy', $matches[1], 0, array( 'changes' => WPHAVE_Activity_Changes::touched( array( 'post_types' ), array( 'post_types' => __( 'Assigned content types', 'wphave' ) ) ) ) );
		if( preg_match( '#^/wphave/v1/media/(\d+)/details$#', $route, $matches ) ) return self::event( 'media.details_updated', 'media', 'updated', 'attachment', get_the_title( (int) $matches[1] ), (int) $matches[1], array( 'changes' => WPHAVE_Activity_Changes::touched( array_keys( $request->get_params() ), array( 'alt' => __( 'Alternative text', 'wphave' ), 'alt_text' => __( 'Alternative text', 'wphave' ), 'caption' => __( 'Caption', 'wphave' ), 'description' => __( 'Description', 'wphave' ) ) ) ) );
		if( $route === '/wphave/v1/client-support' ) return self::event( 'support.request_sent', 'system', 'sent', 'support', __( 'Website support', 'wphave' ) );
		if( preg_match( '#^/wphave/v1/privacy/requests(?:/(\d+)(?:/process)?)?$#', $route, $matches ) ) return self::event( 'privacy.request_' . ( $method === 'DELETE' ? 'deleted' : ( isset( $matches[1] ) ? 'processed' : 'created' ) ), 'security', $method === 'DELETE' ? 'deleted' : ( isset( $matches[1] ) ? 'processed' : 'created' ), 'privacy_request', 'Privacy request', absint( $matches[1] ?? 0 ) );
		if( preg_match( '#^/wphave/v1/notes(?:/(\d+))?(?:/(?:read|replies)(?:/[a-zA-Z0-9_-]+)?)?$#', $route, $matches ) ) return self::event( 'note.' . ( $method === 'DELETE' ? 'deleted' : ( isset( $matches[1] ) ? 'updated' : 'created' ) ), 'content', $method === 'DELETE' ? 'deleted' : ( isset( $matches[1] ) ? 'updated' : 'created' ), 'note', 'Note', absint( $matches[1] ?? 0 ) );
		if( preg_match( '#^/wphave/v1/website-plans(?:/(\d+))?$#', $route, $matches ) ) return self::event( 'website_plan.' . ( $method === 'DELETE' ? 'deleted' : ( isset( $matches[1] ) ? 'updated' : 'created' ) ), 'content', $method === 'DELETE' ? 'deleted' : ( isset( $matches[1] ) ? 'updated' : 'created' ), 'website_plan', (string) ( $request->get_param( 'name' ) ?: 'Website plan' ), absint( $matches[1] ?? 0 ) );
		if( preg_match( '#^/wphave/v1/(audience/(?:leads|subscribers))/(\d+)(?:/unsubscribe)?$#', $route, $matches ) ) return self::event( 'audience.record_updated', 'users', $method === 'DELETE' ? 'deleted' : 'updated', 'audience', $matches[1], (int) $matches[2] );
		if( preg_match( '#^/wphave/v1/content-types/(?:import|bulk)#', $route ) ) return self::event( 'content_type.imported', 'content', 'imported', 'content_type', 'Content types' );

		return null;
	}

	/** Build one normalized internal REST event definition. */
    
	private static function event( string $event, string $category, string $action, string $object_type, string $object_label, int $object_id = 0, array $context = array() ): array {
		return compact( 'event', 'category', 'action', 'object_type', 'object_label', 'object_id', 'context' );
	}
}

WPHAVE_Activity_REST_Audit::init();
