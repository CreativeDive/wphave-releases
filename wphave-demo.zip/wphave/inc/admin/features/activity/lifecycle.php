<?php

/**
 * Activity Log extension lifecycle helpers.
 *
 * This file is deliberately loaded even while the extension is disabled. It
 * owns only the feature boundary and removes background work without loading
 * the recorder, query layer, REST controllers or event integrations.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Load the minimal Activity data-subject handler only when WordPress requests it. */

function wphave_activity_load_privacy_handler(): void {
	require_once __DIR__ . '/policy/privacy.php';
	require_once __DIR__ . '/policy/policy.php';
	require_once __DIR__ . '/storage/log.php';
}

/** Keep stored Activity data exportable even while the optional feature is disabled. */

function wphave_activity_register_privacy_exporter( array $exporters ): array {
	wphave_activity_load_privacy_handler();
	$exporters['wphave-activity'] = array(
		'exporter_friendly_name' => __( 'WPHAVE Activity Log', 'wphave' ),
		'callback' => array( 'WPHAVE_Activity_Log', 'privacy_export' ),
	);

	return $exporters;
}

/** Keep stored Activity actor data erasable independently of its feature gate. */

function wphave_activity_register_privacy_eraser( array $erasers ): array {
	wphave_activity_load_privacy_handler();
	$erasers['wphave-activity'] = array(
		'eraser_friendly_name' => __( 'WPHAVE Activity Log', 'wphave' ),
		'callback' => array( 'WPHAVE_Activity_Log', 'privacy_erase' ),
	);

	return $erasers;
}

/*
 * PRIVACY INVARIANT: Disabling an optional producer may stop future writes but
 * can never hide its retained rows from WordPress data export or erasure.
 */
add_filter( 'wp_privacy_personal_data_exporters', 'wphave_activity_register_privacy_exporter' );
add_filter( 'wp_privacy_personal_data_erasers', 'wphave_activity_register_privacy_eraser' );

/**
 * Remove all Activity Log background work and transient monitor state.
 *
 * Stored activity rows and global Activity settings are retained. The
 * environment snapshot is removed so re-enabling establishes a fresh baseline
 * instead of reporting changes that happened while recording was disabled.
 *
 * @return void
 */

function wphave_activity_deactivate(): void {

	$hooks = array(
		'wphave_activity_cleanup',
		'wphave_activity_cleanup_continuation',
		'wphave_activity_environment_monitor',
		'wphave_activity_privacy_scrub',
	);

	foreach( $hooks as $hook ) {
		wp_clear_scheduled_hook( $hook );
	}

	delete_option( 'wphave_activity_environment_snapshot' );
	delete_option( 'wphave_activity_environment_snapshot_lock' );
	delete_option( 'wphave_activity_environment_monitor_schedule' );
	delete_option( 'wphave_activity_privacy_lock' );
	delete_option( 'wphave_activity_cleanup_schedule' );

}

/**
 * Apply the extension boundary after Experience settings are saved.
 *
 * @param array $data Complete saved site-settings resource.
 * @return void
 */

function wphave_activity_site_settings_saved( array $data ): void {

	$enabled = $data['advanced']['ui']['features']['activityLog'] ?? true;
	if( ! $enabled ) {
		wphave_activity_deactivate();
	}

}

add_action( 'wphave_site_settings_saved', 'wphave_activity_site_settings_saved' );

if( ! wphave_activity_feature_enabled() ) {
	add_action( 'init', 'wphave_activity_deactivate', 1 );
}
