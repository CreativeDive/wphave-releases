<?php

/** Bootstrap Activity management endpoints. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once wphave_dir() . 'inc/features/security/rate-limiter.php';
require_once __DIR__ . '/api/rest-controller.php';
require_once __DIR__ . '/api/rest-audit.php';
