<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Owns normalized, installation-wide Activity Log policy. */

final class WPHAVE_Activity_Policy {

	const OPTION = 'wphave_activity_policy';

	/** Register the central recording-policy filter. */

	public static function init(): void {
		add_filter( 'wphave/activity/should_record', array( __CLASS__, 'should_record' ), 10, 3 );
	}

	/** Return defaults that preserve the existing comprehensive logging behavior. */

	public static function defaults(): array {
		return array( 'critical_retention_days' => 365, 'record_successful_logins' => true, 'record_background_events' => true, 'record_runtime_events' => true, 'record_system_events' => true, 'record_wphave_requests' => false, 'record_cron_runs' => false, 'record_high_frequency_executions' => false, 'export_limit' => 5000, 'export_technical_context' => true );
	}

	/** Return the normalized global policy. */

	public static function get(): array {
		return self::normalize( (array) get_option( self::OPTION, array() ) );
	}

	/** Persist a complete normalized global policy. */

	public static function update( array $settings ): bool {
		return update_option( self::OPTION, self::normalize( $settings ), false );
	}

	/** Apply global capture preferences while preserving security-relevant events. */

	public static function should_record( bool $record, array $data, array $args = array() ): bool {
		// AUDIT INVARIANT: Capture preferences may reduce routine volume but can never
		// suppress failures, warnings, errors or critical events. Operational tuning
		// must not erase the evidence needed to investigate a security incident.
		if( ! $record ) return false;
		if( function_exists( 'wphave_activity_feature_enabled' ) && ! wphave_activity_feature_enabled() ) return false;
		$event_type = (string) ( $data['event_type'] ?? '' );
		if( $event_type === 'activity.settings_updated' ) return true;
		$settings = self::get();
		if( str_starts_with( $event_type, 'remote.wphave_' ) ) return $settings['record_wphave_requests'];
		if( str_starts_with( $event_type, 'cron.job_' ) ) return $settings['record_cron_runs'];
		if( $event_type === 'security.login_failed' || ( $data['status'] ?? '' ) === 'failure' || in_array( $data['severity'] ?? '', array( 'warning', 'error', 'critical' ), true ) ) return true;
		if( in_array( $event_type, array( 'security.login_succeeded', 'security.logout' ), true ) && ! $settings['record_successful_logins'] ) return false;
		if( ( $data['actor_type'] ?? '' ) === 'cron' || ( $data['source'] ?? '' ) === 'cron' ) return $settings['record_background_events'];
		if( $event_type === 'system.php_error' || ( $data['object_type'] ?? '' ) === 'runtime' ) return $settings['record_runtime_events'];
		if( ( $data['category'] ?? '' ) === 'system' ) return $settings['record_system_events'];
		return true;
	}

	/** Normalize all supported settings against bounded allowlists. */
    
	private static function normalize( array $settings ): array {
		$settings = wp_parse_args( $settings, self::defaults() );
		$critical_days = absint( $settings['critical_retention_days'] );
		$standard_days = min( 3650, absint( get_option( 'wphave_activity_retention_days', 90 ) ) );
		if( $standard_days && $critical_days ) $critical_days = max( $standard_days, $critical_days );
		$export_limit = absint( $settings['export_limit'] );
		return array(
			'critical_retention_days' => min( 3650, $critical_days ),
			'record_successful_logins' => rest_sanitize_boolean( $settings['record_successful_logins'] ),
			'record_background_events' => rest_sanitize_boolean( $settings['record_background_events'] ),
			'record_runtime_events' => rest_sanitize_boolean( $settings['record_runtime_events'] ),
			'record_system_events' => rest_sanitize_boolean( $settings['record_system_events'] ),
			'record_wphave_requests' => rest_sanitize_boolean( $settings['record_wphave_requests'] ),
			'record_cron_runs' => rest_sanitize_boolean( $settings['record_cron_runs'] ),
			'record_high_frequency_executions' => rest_sanitize_boolean( $settings['record_high_frequency_executions'] ),
			'export_limit' => in_array( $export_limit, array( 500, 1000, 5000, 10000 ), true ) ? $export_limit : 5000,
			'export_technical_context' => rest_sanitize_boolean( $settings['export_technical_context'] ),
		);
	}
}

WPHAVE_Activity_Policy::init();
