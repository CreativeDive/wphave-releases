<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once wphave_dir() . 'inc/features/security/boundaries/index.php';

/**
 * Enforces the non-configurable privacy boundary for Activity Log values.
 *
 * PRIVACY INVARIANT: Secrets are never valid Activity Log payloads. This service runs at the
 * final persistence boundary so feature code and third-party filters cannot
 * opt out of credential redaction.
 */

final class WPHAVE_Activity_Privacy {

	/** Return whether a key can identify credential or private request data. */

	public static function is_sensitive_key( string $key ): bool {
		return WPHAVE_Sensitive_Data_Policy::is_sensitive_key( $key );
	}

	/** Redact credential shapes from an otherwise displayable scalar value. */

	public static function sanitize_text( string $text, int $limit = 500 ): string {
		return WPHAVE_Security_Redactor::credential_text( $text, $limit );
	}
}
