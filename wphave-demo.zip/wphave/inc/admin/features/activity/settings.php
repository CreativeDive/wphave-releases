<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Converts persisted option structures into useful, privacy-safe setting changes.
 *
 * Storage containers and technical option keys are intentionally separated from
 * the activity contract. Nested values are compared at leaf level so an event
 * explains which setting changed instead of only naming the containing option.
 */

final class WPHAVE_Activity_Settings {

	/** Build normalized leaf-level changes for one WordPress option mutation. */

	public static function changes( string $option, $before, $after ): array {
		$changes = array();
		self::compare_node( self::unwrap( $option, $before ), self::unwrap( $option, $after ), array(), $changes );
		return array_slice( $changes, 0, WPHAVE_Activity_Changes::MAX_CHANGES );
	}

	/** Return a user-facing settings area inferred from the affected fields. */

	public static function object_label( string $option, array $changes ): string {
		$core = array( 'blogname' => __( 'Site identity', 'wphave' ), 'blogdescription' => __( 'Site identity', 'wphave' ), 'site_name' => __( 'Network identity', 'wphave' ), 'site_icon' => __( 'Site identity', 'wphave' ), 'timezone_string' => __( 'Date and time settings', 'wphave' ), 'gmt_offset' => __( 'Date and time settings', 'wphave' ), 'date_format' => __( 'Date and time settings', 'wphave' ), 'time_format' => __( 'Date and time settings', 'wphave' ), 'start_of_week' => __( 'Date and time settings', 'wphave' ), 'permalink_structure' => __( 'Permalink settings', 'wphave' ), 'show_on_front' => __( 'Homepage settings', 'wphave' ), 'page_on_front' => __( 'Homepage settings', 'wphave' ), 'page_for_posts' => __( 'Homepage settings', 'wphave' ), 'users_can_register' => __( 'User registration settings', 'wphave' ), 'registration' => __( 'Network registration settings', 'wphave' ), 'add_new_users' => __( 'Network registration settings', 'wphave' ), 'default_role' => __( 'User registration settings', 'wphave' ), 'default_user_role' => __( 'Network registration settings', 'wphave' ), 'default_comment_status' => __( 'Comment settings', 'wphave' ), 'default_ping_status' => __( 'Comment settings', 'wphave' ), 'default_pingback_flag' => __( 'Comment settings', 'wphave' ), 'comment_registration' => __( 'Comment settings', 'wphave' ), 'comments_notify' => __( 'Comment settings', 'wphave' ), 'moderation_notify' => __( 'Comment settings', 'wphave' ), 'sidebars_widgets' => __( 'Widget areas', 'wphave' ) );
		if( isset( $core[$option] ) ) return $core[$option];
		$field = (string) ( $changes[0]['field'] ?? '' );
		$areas = array( 'smtp' => __( 'Email delivery settings', 'wphave' ), 'backup' => __( 'Backup settings', 'wphave' ), 'backups' => __( 'Backup settings', 'wphave' ), 'seo' => __( 'SEO settings', 'wphave' ), 'security' => __( 'Security settings', 'wphave' ), 'privacy' => __( 'Privacy settings', 'wphave' ), 'performance' => __( 'Performance settings', 'wphave' ), 'media' => __( 'Media settings', 'wphave' ), 'analytics' => __( 'Analytics settings', 'wphave' ), 'fonts' => __( 'Font settings', 'wphave' ), 'editor' => __( 'Editor settings', 'wphave' ), 'ai' => __( 'AI settings', 'wphave' ), 'brand' => __( 'Brand settings', 'wphave' ), 'social' => __( 'Social settings', 'wphave' ), 'maintenance' => __( 'Maintenance settings', 'wphave' ) );
		foreach( $areas as $key => $label ) if( str_contains( $field, $key ) ) return $label;
		return __( 'WPHAVE settings', 'wphave' );
	}

	/** Recursively compare associative containers while treating lists as values. */

	private static function compare_node( $before, $after, array $path, array &$changes ): void {
		if( count( $changes ) >= WPHAVE_Activity_Changes::MAX_CHANGES || maybe_serialize( $before ) === maybe_serialize( $after ) ) return;
		if( is_array( $before ) && is_array( $after ) && ! array_is_list( $before ) && ! array_is_list( $after ) ) {
			foreach( array_unique( array_merge( array_keys( $before ), array_keys( $after ) ) ) as $key ) {
				self::compare_node( $before[$key] ?? null, $after[$key] ?? null, array_merge( $path, array( (string) $key ) ), $changes );
				if( count( $changes ) >= WPHAVE_Activity_Changes::MAX_CHANGES ) break;
			}
			return;
		}
		$field = implode( '_', $path ) ?: 'value';
		$change = WPHAVE_Activity_Changes::compare( array( $field => self::display_value( $field, $before ) ), array( $field => self::display_value( $field, $after ) ), array( $field => self::path_label( $path ) ) );
		if( $change ) $changes[] = $change[0];
	}

	/** Translate stable enum values that would otherwise be technical in the Activity drawer. */

	private static function display_value( string $field, $value ) {
		if( str_ends_with( $field, 'static_cache_warmup_strategy' ) ) {
			$labels = array( 'adaptive' => __( 'Adaptive', 'wphave' ), 'immediate' => __( 'Immediate', 'wphave' ), 'quiet_hours' => __( 'Quiet hours', 'wphave' ), 'manual' => __( 'Manual', 'wphave' ) );
			return $labels[$value] ?? $value;
		}
		return $value;
	}

	/** Remove known persistence wrappers that do not describe a user setting. */

	private static function unwrap( string $option, $value ) {
		if( ! is_array( $value ) ) return array( $option => $value );
		if( $option === 'wphave_data' && isset( $value['wphave_settings'] ) ) return $value['wphave_settings'];
		return $value;
	}

	/** Convert a nested setting path into a concise breadcrumb label. */

	private static function path_label( array $path ): string {
		$skip = array( 'wphave_settings', 'settings' );
		$labels = array( 'advanced' => __( 'Advanced', 'wphave' ), 'general' => __( 'General', 'wphave' ), 'performance' => __( 'Performance', 'wphave' ), 'security' => __( 'Security', 'wphave' ), 'maintenance' => __( 'Maintenance', 'wphave' ), 'media' => __( 'Media', 'wphave' ), 'seo' => __( 'SEO', 'wphave' ), 'smtp' => __( 'Email delivery', 'wphave' ), 'backups' => __( 'Backups', 'wphave' ), 'backup' => __( 'Backups', 'wphave' ), 'blogname' => __( 'Site title', 'wphave' ), 'blogdescription' => __( 'Tagline', 'wphave' ), 'site_icon' => __( 'Site icon', 'wphave' ), 'timezone_string' => __( 'Timezone', 'wphave' ), 'permalink_structure' => __( 'Permalink structure', 'wphave' ), 'isEnabled' => __( 'Enabled', 'wphave' ), 'enabled' => __( 'Enabled', 'wphave' ), 'host' => __( 'Server', 'wphave' ), 'port' => __( 'Port', 'wphave' ), 'encryption' => __( 'Encryption', 'wphave' ), 'fromEmail' => __( 'Sender email address', 'wphave' ), 'fromName' => __( 'Sender name', 'wphave' ), 'username' => __( 'Username', 'wphave' ), 'password' => __( 'Password', 'wphave' ), 'retention' => __( 'Retention', 'wphave' ), 'schedule' => __( 'Schedule', 'wphave' ), 'lazy_loading' => __( 'Lazy loading', 'wphave' ), 'post_cache' => __( 'Page cache', 'wphave' ), 'asset_cache' => __( 'Asset cache', 'wphave' ), 'static_cache_warmup_strategy' => __( 'Cache warmup strategy', 'wphave' ), 'static_cache_warmup_quiet_start' => __( 'Quiet hours start', 'wphave' ), 'static_cache_warmup_quiet_end' => __( 'Quiet hours end', 'wphave' ), 'static_cache_warmup_intensity' => __( 'Cache warmup intensity', 'wphave' ), 'image_compression' => __( 'Image compression', 'wphave' ), 'image_file_format' => __( 'Image file format', 'wphave' ), 'svg_upload_support' => __( 'SVG uploads', 'wphave' ), 'titlePrefix' => __( 'Title prefix', 'wphave' ), 'titleSuffix' => __( 'Title suffix', 'wphave' ), 'titleSeparator' => __( 'Title separator', 'wphave' ) );
		$parts = array();
		foreach( $path as $segment ) {
			if( in_array( $segment, $skip, true ) || ctype_digit( (string) $segment ) ) continue;
			$parts[] = $labels[$segment] ?? self::humanize( (string) $segment );
		}
		return implode( ' → ', array_slice( $parts, -3 ) );
	}

	/** Humanize snake_case and camelCase keys when no explicit label is registered. */

	private static function humanize( string $key ): string {
		$key = preg_replace( '/(?<!^)[A-Z]/', ' $0', str_replace( array( '-', '_' ), ' ', $key ) );
		return ucfirst( strtolower( trim( (string) $key ) ) );
	}
}
