<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once wphave_dir() . 'inc/features/security/boundaries/index.php';

if ( ! class_exists( 'WPHAVE_SMTP' ) ) :

	/**
	 * Handles wphave SMTP delivery, sender filters and manual mail tests.
	 *
	 * The class keeps all SMTP-specific behavior in one place:
	 * - WordPress sender filters.
	 * - PHPMailer SMTP configuration.
	 * - REST endpoint for manual test emails.
	 * - Last test persistence for health/support diagnostics.
	 */

	class WPHAVE_SMTP {

		const LAST_TEST_OPTION = 'wphave_smtp_last_test';

		/**
		 * Registers WordPress hooks.
		 *
		 * @return void
		 */

		public static function init(): void {
			add_action( 'rest_api_init', [ __CLASS__, 'register_rest_route' ] );
			add_action( 'phpmailer_init', [ __CLASS__, 'configure_mailer' ], 10 );
			add_filter( 'wp_mail_from', [ __CLASS__, 'mail_from' ] );
			add_filter( 'wp_mail_from_name', [ __CLASS__, 'mail_from_name' ] );
		}

		/**
		 * Registers the manual mail test REST endpoint.
		 *
		 * @return void
		 */

		public static function register_rest_route(): void {
			register_rest_route( 'wphave/v1', '/validate-smtp', [
				[
					'methods' => 'GET',
					'callback' => [ __CLASS__, 'status' ],
					'permission_callback' => [ __CLASS__, 'can_manage' ],
				],
				[
					'methods' => 'POST',
					'callback' => [ __CLASS__, 'validate' ],
					'permission_callback' => [ __CLASS__, 'can_manage' ],
				],
			] );
		}

		/**
		 * Returns the current mail transport and latest persisted manual test result.
		 *
		 * @return WP_REST_Response
		 */

		public static function status() {
			// AUTHORIZATION/SMTP-DIAGNOSTICS INVARIANT: Route permission is only a
			// transport gate. Host, sender and credential-presence metadata remain
			// protected when this public callback is invoked directly.
			if ( ! self::can_manage() ) {
				return self::forbidden();
			}

			return rest_ensure_response( self::get_public_info() );
		}

		/**
		 * Determines whether the current user may test the mail configuration.
		 *
		 * @return bool
		 */

		public static function can_manage(): bool {
			return current_user_can( 'manage_options' ) || current_user_can( 'wphave_manage_settings_mail' );
		}

		/** Return the stable denial shared by final SMTP callbacks. */

		private static function forbidden(): WP_Error {
			return new WP_Error(
				'wphave_smtp_forbidden',
				__( 'You are not allowed to access mail settings.', 'wphave' ),
				[ 'status' => 403 ]
			);
		}

		/**
		 * Returns SMTP/mail diagnostics safe for admins and support reports.
		 *
		 * No password or full SMTP transcript is exposed here.
		 *
		 * @return array
		 */

		public static function get_public_info(): array {
			$smtp = (array) wphave_data_get( 'smtp_settings', '', [] );
			$enabled = ! empty( $smtp['isEnabled'] );
			$auth_enabled = isset( $smtp['auth'] ) ? (bool) $smtp['auth'] : true;
			$has_password = self::has_password( $smtp );
			$from_email = sanitize_email( $smtp['from_email'] ?? '' );
			$host = sanitize_text_field( $smtp['host'] ?? '' );
			$last_test = get_option( self::LAST_TEST_OPTION, [] );

			if( ! is_array( $last_test ) ) {
				$last_test = [];
			}

			// SECURITY INVARIANT: Diagnostics expose only configuration presence and
			// transport metadata. SMTP credentials and decrypted password material never
			// cross this support-facing projection boundary.
			return [
				'enabled' => $enabled,
				'transport' => $enabled ? 'smtp' : 'wp_mail',
				'host' => $host,
				'port' => absint( $smtp['port'] ?? 0 ),
				'secure' => sanitize_key( $smtp['secure'] ?? 'none' ),
				'auth' => $auth_enabled,
				'usernameConfigured' => ! empty( $smtp['user'] ),
				'passwordConfigured' => $has_password,
				'passwordSource' => self::password_source( $smtp ),
				'fromEmail' => $from_email,
				'fromName' => sanitize_text_field( $smtp['from_name'] ?? '' ),
				'configured' => ! $enabled || ( ! empty( $host ) && ! empty( $from_email ) && ( ! $auth_enabled || ( ! empty( $smtp['user'] ) && $has_password ) ) ),
				'lastTest' => $last_test,
			];
		}

		/**
		 * Filters the sender email while wphave SMTP is enabled.
		 *
		 * @param string $original Original sender email.
		 *
		 * @return string
		 */

		public static function mail_from( string $original ): string {
			$smtp = self::settings();

			if( empty( $smtp['isEnabled'] ) ) {
				return $original;
			}

			return sanitize_email( $smtp['from_email'] ?? '' ) ?: get_option( 'admin_email' );
		}

		/**
		 * Filters the sender name while wphave SMTP is enabled.
		 *
		 * @param string $original Original sender name.
		 *
		 * @return string
		 */

		public static function mail_from_name( string $original ): string {
			$smtp = self::settings();

			if( empty( $smtp['isEnabled'] ) ) {
				return $original;
			}

			return sanitize_text_field( $smtp['from_name'] ?? '' ) ?: get_bloginfo( 'name' );
		}

		/**
		 * Sends a manual test email and stores the result for diagnostics.
		 *
		 * A successful wp_mail() call means the configured transport accepted the
		 * message for sending. Final inbox delivery still depends on DNS/provider
		 * rules and must be confirmed by the user.
		 *
		 * @param WP_REST_Request $request REST request.
		 *
		 * @return WP_REST_Response|WP_Error
		 */

		public static function validate( $request ) {
			// AUTHORIZATION INVARIANT: A manual transport test can consume saved or
			// submitted SMTP credentials and send external mail. The final callback must
			// repeat Mail Settings authority instead of inheriting REST dispatch.
			if ( ! self::can_manage() ) {
				return self::forbidden();
			}

			$data = $request->get_params();
			$test_email = sanitize_email( $data['test_email'] ?? '' );
			$from_email = sanitize_email( $data['from_email'] ?? '' );
			$smtp_disabled = isset( $data['smtp_disabled'] ) ? (bool) $data['smtp_disabled'] : true;

			$GLOBALS['wphave_smtp_test_settings'] = self::settings_from_request( $data );

			$site_name = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
			$subject = '[' . $site_name . '] ' . __( 'Testmail', 'wphave' );
			$headers = wphave_email_template_headers();
			$message = wphave_build_email_template( [
				'title' => __( 'Testmail', 'wphave' ),
				'description' => __( 'This is a test email to ensure that email sending via WordPress is working correctly.', 'wphave' ),
			] );
			$mail_to = $test_email ?: $from_email ?: get_option( 'admin_email' );

			// AUTHORIZATION INVARIANT: Request normalization and credential selection
			// are extensible trust boundaries. Repeat Mail Settings authority after
			// them and before either diagnostics persistence or external delivery.
			if ( ! self::can_manage() ) {
				self::clear_test_globals();

				return self::forbidden();
			}

			if( ! is_email( $mail_to ) ) {
				$response_message = __( 'Please enter a valid test email address.', 'wphave' );

				self::save_last_test( false, $smtp_disabled ? 'wp_mail' : 'smtp', $mail_to, $response_message );
				self::clear_test_globals();

				return new WP_Error( 'wphave_invalid_test_email', $response_message, [ 'status' => 400 ] );
			}

			$mail_error = null;
			$mail_error_capture = static function( $error ) use ( &$mail_error ) {
				if( is_wp_error( $error ) ) {
					$mail_error = $error->get_error_message();
				}
			};

			add_action( 'wp_mail_failed', $mail_error_capture );

			if( $smtp_disabled ) {
				$GLOBALS['wphave_smtp_test_disabled'] = true;

				$success = wp_mail( $mail_to, $subject, $message, $headers );
				$response_message = $success ? __( 'WordPress accepted the test email using the default mail function. Delivery cannot be verified without SMTP, so please check the inbox manually.', 'wphave' ) : ( $mail_error ?: __( 'Email sending failed. Your server might not support PHP mail().', 'wphave' ) );
				remove_action( 'wp_mail_failed', $mail_error_capture );

				// AUTHORIZATION INVARIANT: Transport callbacks may change live authority.
				// A mail accepted under fresh pre-send authority does not authorize the
				// later persistence or disclosure of operational diagnostics.
				if ( ! self::can_manage() ) {
					self::clear_test_globals();

					return self::forbidden();
				}

				$last_test = self::save_last_test( $success, 'wp_mail', $mail_to, $response_message );
				self::clear_test_globals();

				return rest_ensure_response( [
					'debug' => [],
					'success' => $success,
					'lastTest' => $last_test,
					'message' => $response_message,
				] );
			}

			$debug_output = [];

			$smtp_debug_capture = static function( $phpmailer ) use ( &$debug_output ) {
				if( ! empty( $GLOBALS['wphave_smtp_test_disabled'] ) ) {
					return;
				}

				$phpmailer->SMTPDebug = 2;
				$phpmailer->Debugoutput = static function( $line ) use ( &$debug_output ) {
					$debug_output[] = trim( (string) $line );
				};
			};
			add_action( 'phpmailer_init', $smtp_debug_capture );

			$success = wp_mail( $mail_to, $subject, $message, $headers );
			$debug_output = self::sanitize_debug_output( $debug_output );
			$response_message = $success ? __( 'The SMTP server accepted the test email. Please check the inbox to confirm delivery.', 'wphave' ) : ( $mail_error ?: __( 'Email sending failed. See debug output.', 'wphave' ) );
			remove_action( 'wp_mail_failed', $mail_error_capture );
			remove_action( 'phpmailer_init', $smtp_debug_capture );

			// AUTHORIZATION INVARIANT: SMTP transcripts remain privileged even after
			// redaction. Revalidate before persisting or returning transport results.
			if ( ! self::can_manage() ) {
				self::clear_test_globals();

				return self::forbidden();
			}

			$last_test = self::save_last_test( $success, 'smtp', $mail_to, $response_message, $debug_output );
			self::clear_test_globals();

			return rest_ensure_response( [
				'success' => $success,
				'debug' => $debug_output,
				'lastTest' => $last_test,
				'message' => $response_message,
			] );
		}

		/**
		 * Configures PHPMailer for all outgoing WordPress mails when SMTP is active.
		 *
		 * @param PHPMailer $phpmailer PHPMailer instance.
		 *
		 * @return void
		 */

		public static function configure_mailer( $phpmailer ): void {
			if( ! empty( $GLOBALS['wphave_smtp_test_disabled'] ) ) {
				return;
			}

			$smtp = self::settings();

			if( empty( $smtp ) || empty( $smtp['isEnabled'] ) ) {
				return;
			}

			$phpmailer->isSMTP();
			$phpmailer->Host = sanitize_text_field( $smtp['host'] ?? '' );
			$phpmailer->Port = intval( $smtp['port'] ?? 587 );
			$phpmailer->SMTPAuth = isset( $smtp['auth'] ) ? (bool) $smtp['auth'] : true;

			if( $phpmailer->SMTPAuth ) {
				$phpmailer->Username = sanitize_text_field( $smtp['user'] ?? '' );
				$phpmailer->Password = self::password( $smtp );
			}

			$phpmailer->SMTPSecure = sanitize_key( $smtp['secure'] ?? 'tls' );

			if( empty( $smtp['secure'] ) || 'none' === $smtp['secure'] ) {
				$phpmailer->SMTPAutoTLS = isset( $smtp['auto_tls'] ) ? (bool) $smtp['auto_tls'] : true;
			} else {
				$phpmailer->SMTPAutoTLS = false;
			}

			$phpmailer->From = sanitize_email( $smtp['from_email'] ?? '' ) ?: get_option( 'admin_email' );
			$phpmailer->FromName = sanitize_text_field( $smtp['from_name'] ?? '' ) ?: get_bloginfo( 'name' );
		}

		/**
		 * Returns saved settings or temporary REST test settings for this request.
		 *
		 * @return array
		 */

		private static function settings(): array {
			// SECRET-LIFECYCLE INVARIANT: Request-local test credentials may override
			// persisted settings only during the active mail test. They are never written
			// to options and clear_test_globals() must end that authority before returning.
			if( ! empty( $GLOBALS['wphave_smtp_test_settings'] ) && is_array( $GLOBALS['wphave_smtp_test_settings'] ) ) {
				return $GLOBALS['wphave_smtp_test_settings'];
			}

			return (array) wphave_data_get( 'smtp_settings', '', [] );
		}

		/**
		 * Normalizes REST test payload fields into the saved SMTP settings shape.
		 *
		 * @param array $data REST request parameters.
		 *
		 * @return array
		 */

		private static function settings_from_request( array $data ): array {
			$saved_smtp = (array) wphave_data_get( 'smtp_settings', '', [] );
			$password = (string) ( $data['smtp_password'] ?? '' );

			if( class_exists( 'WPHAVE_Data_Sensitive_Values' ) && WPHAVE_Data_Sensitive_Values::is_masked_value( $password ) ) {
				$password = (string) ( $saved_smtp['password'] ?? '' );
			}

			return [
				'isEnabled' => empty( $data['smtp_disabled'] ),
				'host' => sanitize_text_field( $data['smtp_host'] ?? '' ),
				'auth' => isset( $data['smtp_auth'] ) ? (bool) $data['smtp_auth'] : true,
				'port' => absint( $data['smtp_port'] ?? 587 ),
				'auto_tls' => isset( $data['smtp_auto_tls'] ) ? (bool) $data['smtp_auto_tls'] : true,
				'user' => sanitize_text_field( $data['smtp_user'] ?? '' ),
				'password' => $password,
				'secure' => sanitize_key( $data['smtp_secure'] ?? 'tls' ),
				'from_email' => sanitize_email( $data['from_email'] ?? '' ),
				'from_name' => sanitize_text_field( $data['from_name'] ?? '' ),
			];
		}

		/**
		 * Resolves the SMTP password from wp-config.php or the encrypted option.
		 *
		 * @param array $smtp SMTP settings.
		 *
		 * @return string
		 */

		private static function password( array $smtp ): string {
			if( defined( 'WPHAVE_SMTP_PASSWORD' ) && WPHAVE_SMTP_PASSWORD ) {
				return (string) WPHAVE_SMTP_PASSWORD;
			}

			if( empty( $smtp['password'] ) ) {
				return '';
			}

			$decrypted = WPHAVE_Crypto::decrypt( (string) $smtp['password'], 'smtp' );

			return $decrypted ? $decrypted : (string) $smtp['password'];
		}

		/**
		 * Returns whether a password exists without exposing the value.
		 *
		 * @param array $smtp SMTP settings.
		 *
		 * @return bool
		 */

		private static function has_password( array $smtp ): bool {
			return ( defined( 'WPHAVE_SMTP_PASSWORD' ) && WPHAVE_SMTP_PASSWORD ) || ! empty( $smtp['password'] );
		}

		/**
		 * Returns where the password is stored for diagnostics.
		 *
		 * @param array $smtp SMTP settings.
		 *
		 * @return string
		 */

		private static function password_source( array $smtp ): string {
			if( defined( 'WPHAVE_SMTP_PASSWORD' ) && WPHAVE_SMTP_PASSWORD ) {
				return 'constant';
			}

			return ! empty( $smtp['password'] ) ? 'database' : 'missing';
		}

		/**
		 * Persists the latest manual mail test result.
		 *
		 * @param bool $success Whether wp_mail reported success.
		 * @param string $transport smtp or wp_mail.
		 * @param string $recipient Test recipient.
		 * @param string $message Human-readable result.
		 * @param array $debug Sanitized debug lines.
		 *
		 * @return array Saved payload.
		 */

		private static function save_last_test( $success, string $transport, string $recipient, string $message, array $debug = [] ): array {
			/*
			 * PRIVACY INVARIANT: The durable test result is an operational outcome,
			 * not a second address book. The recipient remains request-local and in
			 * canonical mail configuration; it is never copied into diagnostics.
			 */
			$payload = [
				'success' => (bool) $success,
				'transport' => in_array( $transport, [ 'smtp', 'wp_mail' ], true ) ? $transport : 'wp_mail',
				'testedAt' => time(),
				'testedAtGmt' => gmdate( 'c' ),
				'message' => WPHAVE_Security_Redactor::error_text( $message, 300 ),
				'debug' => self::sanitize_debug_output( $debug ),
			];

			update_option( self::LAST_TEST_OPTION, $payload, false );
			self::clear_system_info_cache();

			return $payload;
		}

		/**
		 * Keeps debug output useful while reducing accidental sensitive leakage.
		 *
		 * @param array $debug_output Raw PHPMailer debug lines.
		 *
		 * @return array
		 */

		private static function sanitize_debug_output( array $debug_output ): array {
			$lines = array_slice( $debug_output, -40 );

			// SECURITY INVARIANT: SMTP transcripts are untrusted secret-bearing output.
			// Every persisted or returned line passes the central redactor, and bare
			// authentication payloads are removed even when they lack a field label.
			return array_values(
				array_map(
					static function( $line ) {
						$line = WPHAVE_Security_Redactor::error_text( $line, 500 );
						$payload = preg_replace( '/^(?:CLIENT\s*->\s*SERVER:\s*)/i', '', $line );

						if ( preg_match( '/^[A-Za-z0-9+\/]{8,}={0,2}$/', trim( (string) $payload ) ) ) {
							return '[redacted]';
						}

						return $line;
					},
					$lines
				)
			);
		}

		/**
		 * Clears temporary request globals used by the manual test.
		 *
		 * @return void
		 */

		private static function clear_test_globals(): void {
			unset( $GLOBALS['wphave_smtp_test_settings'], $GLOBALS['wphave_smtp_test_disabled'] );
		}

		/**
		 * Clears cached system diagnostics after mail test state changes.
		 *
		 * @return void
		 */

		private static function clear_system_info_cache(): void {
			if( class_exists( 'WPHAVE_System_Info' ) && defined( 'WPHAVE_System_Info::CACHE_KEY' ) ) {
				delete_transient( WPHAVE_System_Info::CACHE_KEY );
			}
		}

	}

endif;

WPHAVE_SMTP::init();
