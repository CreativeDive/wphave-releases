<?php

/** Optional, locally configured register; never trust a file inside WordPress. */
if ( ! defined( 'WPHAVE_MCP_REVIEW_REGISTER' ) ) {
	return array();
}

$path = realpath( (string) WPHAVE_MCP_REVIEW_REGISTER );
$wordpress_root = realpath( ABSPATH );
if ( ! is_string( $path ) || ! is_file( $path ) || ! is_readable( $path ) ||
	( is_string( $wordpress_root ) && str_starts_with( $path, $wordpress_root . DIRECTORY_SEPARATOR ) ) ) {
	return array();
}

$records = json_decode( (string) file_get_contents( $path ), true );
return is_array( $records ) ? $records : array();
