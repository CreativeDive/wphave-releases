<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/pattern-approval.php';

/**
 * Approved, editor-authored block patterns for AI page composition.
 *
 * A contract pins one saved wp_block revision by content hash. Updating a
 * pattern in the editor therefore requires an explicit review and new version.
 * Catalog responses never include Gutenberg markup.
 */
final class WPHAVE_Website_Plan_Pattern_Registry {
	/** @var array<string, array> */
	private static array $contracts = array();

	public static function register( array $contract ): bool {
		$raw_id = (string) ( $contract['patternId'] ?? '' );
		$id = sanitize_key( $raw_id );
		$version = $contract['version'] ?? null;
		$post_id = $contract['postId'] ?? null;
		$source_file = $contract['sourceFile'] ?? null;
		$hash = (string) ( $contract['contentHash'] ?? '' );
		$has_post = is_int( $post_id ) && $post_id > 0;
		$has_file = is_string( $source_file ) && preg_match( '/^[a-z0-9-]+\.blocks\.html$/', $source_file ) === 1;

		if (
			$id === '' ||
			$id !== $raw_id ||
			! is_int( $version ) ||
			$version < 1 ||
			$has_post === $has_file ||
			! preg_match( '/^[a-f0-9]{64}$/', $hash ) ||
			! is_array( $contract['slots'] ?? null ) ||
			! is_array( $contract['variations'] ?? null )
		) {
			return false;
		}
		foreach ( $contract['variations'] as $name => $variation ) {
			if (
				! is_string( $name ) ||
				$name === '' ||
				sanitize_key( $name ) !== $name ||
				! is_array( $variation ) ||
				! preg_match( '/^[a-f0-9]{64}$/', (string) ( $variation['contentHash'] ?? '' ) ) ||
				( isset( $variation['sourceFile'] ) === isset( $variation['postId'] ) )
			) {
				return false;
			}
		}

		$key = $id . '@' . $version;
		if ( isset( self::$contracts[ $key ] ) ) {
			return false;
		}

		$contract['patternId'] = $id;
		self::$contracts[ $key ] = $contract;
		return true;
	}

	/** Register the reviewed snapshot exported from the WPHAVE editor. */
	public static function register_bundled(): void {
		foreach ( require __DIR__ . '/pattern-contracts.php' as $contract ) {
			self::register( $contract );
		}
	}

	/** Compact first-stage data for the model; no block attributes or markup. */
	public static function catalog(): array {
		$catalog = array();
		foreach ( self::$contracts as $contract ) {
			$resolved = self::resolve( $contract['patternId'], $contract['version'] );
			if ( is_wp_error( $resolved ) ) {
				continue;
			}
			$variations = array();
			$variation_options = array();
			foreach ( array_keys( $contract['variations'] ) as $name ) {
				if ( ! is_wp_error( self::resolve( $contract['patternId'], $contract['version'], $name ) ) ) {
					$variations[] = $name;
				$variation_options[] = array(
						'name' => $name,
						'description' => sanitize_text_field( (string) ( $contract['variations'][ $name ]['description'] ?? $name ) ),
					);
				}
			}

			$catalog[] = array(
				'patternId' => $contract['patternId'],
				'version' => $contract['version'],
				'category' => sanitize_key( (string) ( $contract['category'] ?? '' ) ),
				'layoutFamily' => sanitize_key( (string) ( $contract['layoutFamily'] ?? '' ) ),
				'description' => sanitize_text_field( (string) ( $contract['description'] ?? '' ) ),
				'contentKinds' => array_values( (array) ( $contract['contentKinds'] ?? array() ) ),
				'minMedia' => (int) ( $contract['minMedia'] ?? 0 ),
				'maxMedia' => (int) ( $contract['maxMedia'] ?? 0 ),
				'variationNames' => $variations,
				'variationOptions' => $variation_options,
			);
		}

		return $catalog;
	}

	/** Full second-stage contract, only after selecting an approved version. */
	public static function resolve( string $id, int $version, string $variation = '' ) {
		if ( $id === '' || sanitize_key( $id ) !== $id || $version < 1 ) {
			return new WP_Error( 'wphave_pattern_unknown', 'Pattern version is not approved.' );
		}
		$key = $id . '@' . $version;
		$contract = self::$contracts[ $key ] ?? null;
		if ( ! is_array( $contract ) ) {
			return new WP_Error( 'wphave_pattern_unknown', 'Pattern version is not approved.' );
		}

		$source = $contract;
		if ( $variation !== '' ) {
			$source = $contract['variations'][ $variation ] ?? null;
			if ( ! is_array( $source ) || sanitize_key( $variation ) !== $variation ) {
				return new WP_Error( 'wphave_pattern_variation_unknown', 'Pattern variation is not approved.' );
			}
		}

		if ( isset( $source['sourceFile'] ) ) {
			$file = (string) $source['sourceFile'];
			if ( preg_match( '/^[a-z0-9-]+\.blocks\.html$/', $file ) !== 1 ) {
				return new WP_Error( 'wphave_pattern_variation_source', 'Pattern variation source is invalid.' );
			}
			$path = dirname( __DIR__, 3 ) . '/editor/pattern/ai-approved/' . $file;
			$content = is_file( $path ) ? file_get_contents( $path ) : false;
		} else {
			$post_id = $source['postId'] ?? null;
			if ( ! is_int( $post_id ) || $post_id < 1 ) {
				return new WP_Error( 'wphave_pattern_variation_source', 'Pattern variation source is invalid.' );
			}
			$post = get_post( $post_id );
			$content = $post && $post->post_type === 'wp_block' && $post->post_status === 'publish'
				? (string) $post->post_content
				: false;
		}
		$hash = (string) ( $source['contentHash'] ?? '' );
		if ( ! is_string( $content ) || ! preg_match( '/^[a-f0-9]{64}$/', $hash ) || ! hash_equals( $hash, hash( 'sha256', $content ) ) ) {
			return new WP_Error( 'wphave_pattern_changed', 'Approved pattern content is unavailable or changed.' );
		}

		$blocks = parse_blocks( $content );
		if ( ! self::valid_blocks( $blocks ) ) {
			return new WP_Error( 'wphave_pattern_invalid', 'Approved pattern contains unsupported blocks.' );
		}
		if ( ! self::slots_cover_blocks( $blocks, $contract['slots'] ) ) {
			return new WP_Error( 'wphave_pattern_slots_incomplete', 'Approved pattern has unmapped content blocks.' );
		}

		return array(
			'contract' => $contract,
			'blocks' => $blocks,
			'content' => $content,
			'variation' => $variation,
		);
	}

	/** External callers must pass the independent editor-review boundary. */
	public static function resolve_for_external( string $id, int $version, string $variation = '' ) {
		$resolved = self::resolve( $id, $version, $variation );
		if ( is_wp_error( $resolved ) ) {
			return $resolved;
		}

		$approval = WPHAVE_Website_Plan_Pattern_Approval::verify_external( $resolved );
		return is_wp_error( $approval ) ? $approval : $resolved;
	}

	private static function valid_blocks( array $blocks ): bool {
		if ( $blocks === array() ) {
			return false;
		}

		$has_block = false;
		foreach ( $blocks as $block ) {
			if ( ( $block['blockName'] ?? null ) === null ) {
				if ( trim( (string) ( $block['innerHTML'] ?? '' ) ) !== '' ) {
					return false;
				}
				continue;
			}

			$name = (string) ( $block['blockName'] ?? '' );
			if ( ! str_starts_with( $name, 'wphave/' ) ) {
				return false;
			}
			$attrs = is_array( $block['attrs'] ?? null ) ? $block['attrs'] : array();
			if ( $name !== 'wphave/image' && isset( $attrs['image'] ) ) {
				return false;
			}
			foreach ( (array) ( $attrs['wphave']['background']['layers'] ?? array() ) as $layer ) {
				if ( is_array( $layer ) && ! empty( $layer['media'] ) ) {
					return false;
				}
			}
			$has_block = true;

			$children = $block['innerBlocks'] ?? array();
			if ( ! is_array( $children ) || ( $children !== array() && ! self::valid_blocks( $children ) ) ) {
				return false;
			}
		}

		return $has_block;
	}

	private static function slots_cover_blocks( array $blocks, array $slots ): bool {
		$mapped = array();
		foreach ( $slots as $slot ) {
			$path = $slot['path'] ?? null;
			if ( ! is_array( $path ) || $path === array() ) {
				return false;
			}
			foreach ( $path as $index ) {
				if ( ! is_int( $index ) || $index < 0 ) {
					return false;
				}
			}
			$key = implode( '.', $path );
			if ( isset( $mapped[ $key ] ) ) {
				return false;
			}
			$mapped[ $key ] = true;
		}

		$found = array();
		$walk = static function ( array $nodes, array $base ) use ( &$walk, &$found ): void {
			foreach ( $nodes as $index => $node ) {
				$path = array_merge( $base, array( $index ) );
				if ( in_array(
					$node['blockName'] ?? '',
					array( 'wphave/heading', 'wphave/paragraph', 'wphave/button', 'wphave/image' ),
					true
				) ) {
					$found[ implode( '.', $path ) ] = true;
				}
				$walk( $node['innerBlocks'] ?? array(), $path );
			}
		};
		$walk( $blocks, array() );
		return array_diff_key( $found, $mapped ) === array() && array_diff_key( $mapped, $found ) === array();
	}
}
