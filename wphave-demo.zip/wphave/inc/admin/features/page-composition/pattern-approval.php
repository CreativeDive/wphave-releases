<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Fail-closed boundary for externally submitted, editor-reviewed Pattern versions. */
final class WPHAVE_Website_Plan_Pattern_Approval {
	public const CONTRACT_VERSION = 1;

	/**
	 * Validate the shape and current compatibility of a proposed review record.
	 * A structurally valid record is not an issued approval.
	 */
	public static function inspect_record( array $record, array $resolved ) {
		$contract = $resolved['contract'] ?? array();
		$checks = $record['checks'] ?? null;
		$expected_hash = hash( 'sha256', (string) ( $resolved['content'] ?? '' ) );
		if (
			( $record['contractVersion'] ?? null ) !== self::CONTRACT_VERSION ||
			( $record['status'] ?? null ) !== 'reviewed' ||
			( $record['patternId'] ?? null ) !== ( $contract['patternId'] ?? null ) ||
			( $record['patternVersion'] ?? null ) !== ( $contract['version'] ?? null ) ||
			( $record['variation'] ?? null ) !== ( $resolved['variation'] ?? '' ) ||
			! is_string( $record['contentHash'] ?? null ) ||
			! hash_equals( $expected_hash, $record['contentHash'] ) ||
			( $record['wphaveVersion'] ?? null ) !== WPHAVE_VERSION ||
			( $record['wordpressVersion'] ?? null ) !== get_bloginfo( 'version' ) ||
			( $record['siteId'] ?? null ) !== get_current_blog_id() ||
			! is_string( $record['issuedAt'] ?? null ) ||
			! preg_match( '/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/', $record['issuedAt'] ) ||
			! is_string( $record['reviewer'] ?? null ) ||
			! preg_match( '/^[a-zA-Z0-9._-]{3,80}$/', $record['reviewer'] ) ||
			! is_string( $record['signature'] ?? null ) ||
			! is_array( $checks ) ||
			array_keys( $checks ) !== array( 'editor', 'desktop', 'mobile', 'saveReload', 'decision' )
		) {
			return new WP_Error( 'wphave_pattern_approval_invalid', 'The Pattern review contract is missing or stale.' );
		}

		foreach ( $checks as $artifact ) {
			if ( ! is_string( $artifact ) || ! preg_match( '/^[a-f0-9]{64}$/', $artifact ) ) {
				return new WP_Error( 'wphave_pattern_approval_evidence_invalid', 'A Pattern review artifact is missing.' );
			}
		}

		return true;
	}

	/** Only a configured issuer key and complete signed evidence can grant external access. */
	public static function verify_external( array $resolved ) {
		$records = require __DIR__ . '/pattern-approval-register.php';
		$key = (string) ( $resolved['contract']['patternId'] ?? '' ) . '@' .
			(string) ( $resolved['contract']['version'] ?? '' ) . ':' .
			(string) ( $resolved['variation'] ?? '' );
		$record = $records[ $key ] ?? null;
		if ( ! is_array( $record ) || is_wp_error( self::inspect_record( $record, $resolved ) ) ) {
			return new WP_Error( 'wphave_pattern_not_editor_approved', 'This Pattern version has no valid editor review.' );
		}

		if ( ! defined( 'WPHAVE_MCP_REVIEW_PUBLIC_KEY' ) ||
			! defined( 'WPHAVE_MCP_REVIEW_EVIDENCE_DIR' ) ||
			! function_exists( 'sodium_crypto_sign_verify_detached' ) ) {
			return new WP_Error( 'wphave_pattern_issuer_unavailable', 'Pattern review verification is unavailable.' );
		}

		$public_key = base64_decode( (string) WPHAVE_MCP_REVIEW_PUBLIC_KEY, true );
		$signature = base64_decode( $record['signature'], true );
		if ( ! is_string( $public_key ) || strlen( $public_key ) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES ||
			! is_string( $signature ) || strlen( $signature ) !== SODIUM_CRYPTO_SIGN_BYTES ||
			! sodium_crypto_sign_verify_detached( $signature, self::signature_message( $record ), $public_key ) ) {
			return new WP_Error( 'wphave_pattern_signature_invalid', 'Pattern review signature is invalid.' );
		}

		$directory = realpath( (string) WPHAVE_MCP_REVIEW_EVIDENCE_DIR );
		$wordpress_root = realpath( ABSPATH );
		if ( ! is_string( $directory ) || ! is_dir( $directory ) ||
			( is_string( $wordpress_root ) && str_starts_with( $directory, $wordpress_root . DIRECTORY_SEPARATOR ) ) ) {
			return new WP_Error( 'wphave_pattern_evidence_unavailable', 'Pattern review evidence is unavailable.' );
		}
		foreach ( $record['checks'] as $hash ) {
			$file = $directory . DIRECTORY_SEPARATOR . $hash;
			if ( realpath( $file ) !== $file || ! is_file( $file ) ||
				! hash_equals( $hash, (string) hash_file( 'sha256', $file ) ) ) {
				return new WP_Error( 'wphave_pattern_evidence_invalid', 'Pattern review evidence is missing or changed.' );
			}
		}

		return true;
	}

	/** Fixed-field message shared with the offline issuer; no request controls the key. */
	public static function signature_message( array $record ): string {
		$fields = array(
			$record['contractVersion'] ?? '',
			$record['status'] ?? '',
			$record['patternId'] ?? '',
			$record['patternVersion'] ?? '',
			$record['variation'] ?? '',
			$record['contentHash'] ?? '',
			$record['wphaveVersion'] ?? '',
			$record['wordpressVersion'] ?? '',
			$record['siteId'] ?? '',
			$record['issuedAt'] ?? '',
			$record['reviewer'] ?? '',
			$record['checks']['editor'] ?? '',
			$record['checks']['desktop'] ?? '',
			$record['checks']['mobile'] ?? '',
			$record['checks']['saveReload'] ?? '',
			$record['checks']['decision'] ?? '',
		);

		return implode( "\n", array_map( 'strval', $fields ) );
	}

	/** Only contract-named content fields may differ from the pinned Pattern tree. */
	public static function inspect_slot_delta( array $resolved, array $composed ) {
		$slots = $resolved['contract']['slots'] ?? null;
		if ( ! is_array( $slots ) || ! is_array( $composed['blocks'] ?? null ) ) {
			return new WP_Error( 'wphave_pattern_delta_invalid', 'The composed Pattern is invalid.' );
		}

		$allowed = array();
		foreach ( $slots as $slot ) {
			$path = $slot['path'] ?? null;
			$kind = $slot['kind'] ?? '';
			if ( ! is_array( $path ) || $path === array() || ! in_array( $kind, array( 'text', 'image', 'action' ), true ) ) {
				return new WP_Error( 'wphave_pattern_delta_contract', 'A Pattern slot contract is invalid.' );
			}
			$key = implode( '.', $path );
			if ( isset( $allowed[ $key ] ) ) {
				return new WP_Error( 'wphave_pattern_delta_contract', 'A Pattern slot path is duplicated.' );
			}
			$allowed[ $key ] = $kind === 'action'
				? array( 'content', 'link' )
				: array( $kind === 'image' ? 'image' : 'content' );
		}

		if ( ! self::same_structure_except_slots( $resolved['blocks'] ?? array(), $composed['blocks'], $allowed ) ) {
			return new WP_Error( 'wphave_pattern_delta_disallowed', 'The Pattern structure or design was changed.' );
		}
		return true;
	}

	private static function same_structure_except_slots( array $original, array $candidate, array $allowed, array $path = array() ): bool {
		if ( count( $original ) !== count( $candidate ) ) {
			return false;
		}
		foreach ( $original as $index => $source ) {
			$target = $candidate[ $index ] ?? null;
			if ( ! is_array( $source ) || ! is_array( $target ) || ( $source['blockName'] ?? null ) !== ( $target['blockName'] ?? null ) ) {
				return false;
			}
			$node_path = array_merge( $path, array( $index ) );
			$mutable = $allowed[ implode( '.', $node_path ) ] ?? array();
			$source_attrs = is_array( $source['attrs'] ?? null ) ? $source['attrs'] : array();
			$target_attrs = is_array( $target['attrs'] ?? null ) ? $target['attrs'] : array();
			foreach ( $mutable as $attribute ) {
				unset( $source_attrs[ $attribute ], $target_attrs[ $attribute ] );
			}
			if ( $source_attrs !== $target_attrs || ( $source['innerHTML'] ?? '' ) !== ( $target['innerHTML'] ?? '' ) || ( $source['innerContent'] ?? array() ) !== ( $target['innerContent'] ?? array() ) ) {
				return false;
			}
			if ( ! self::same_structure_except_slots( (array) ( $source['innerBlocks'] ?? array() ), (array) ( $target['innerBlocks'] ?? array() ), $allowed, $node_path ) ) {
				return false;
			}
		}
		return true;
	}
}
