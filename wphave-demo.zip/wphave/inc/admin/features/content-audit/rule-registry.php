<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers and executes versioned Content Audit rule providers.
 *
 * Rules are sorted by stable ID before execution, isolated from one another and
 * normalized at the registry boundary. The deterministic ruleset hash prevents
 * unlike audit definitions from being compared as historical changes.
 *
 * Extension contract:
 * - Rule IDs are unique sanitized keys.
 * - COMPATIBILITY INVARIANT: Versions change whenever finding semantics or identity changes.
 * - Callbacks return arrays of finding arrays and may update job-local caches.
 * - Provider exceptions are contained and reported as incomplete audit errors.
 */

final class WPHAVE_Content_Audit_Rule_Registry {

	/** @var array<string,array<string,mixed>> */

	private array $rules = array();

	private static ?WPHAVE_Content_Audit_Rule_Registry $instance = null;

	/** Return the request-scoped rule registry. */

	public static function instance(): WPHAVE_Content_Audit_Rule_Registry {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Register one deterministic audit rule.
	 *
	 * @param string   $id Stable rule identifier.
	 * @param string   $version Semantic implementation version.
	 * @param string   $scope Either item or site.
	 * @param callable $callback Rule callback.
	 * @param array    $metadata Presentation and execution metadata.
	 */

	public function register( string $id, string $version, string $scope, callable $callback, array $metadata = array() ): void {
		$id = sanitize_key( $id );
		$version = sanitize_text_field( $version );
		$scope = 'site' === $scope ? 'site' : 'item';

		if ( '' === $id || '' === $version ) {
			_doing_it_wrong( __METHOD__, 'Content Audit rules require a stable ID and version.', '1.0.0' );

			return;
		}

		if ( isset( $this->rules[ $id ] ) ) {
			_doing_it_wrong( __METHOD__, 'Content Audit rule IDs must be unique.', '1.0.0' );

			return;
		}

		$this->rules[ $id ] = array(
			'id' => $id,
			'version' => $version,
			'scope' => $scope,
			'callback' => $callback,
			'metadata' => self::sanitize_metadata( $metadata ),
		);
	}

	/**
	 * Return deterministically ordered rules, optionally restricted by scope.
	 *
	 * @param string $scope Empty, item or site.
	 * @return array<int,array<string,mixed>> Registered rule definitions.
	 */

	public function rules( string $scope = '' ): array {
		$rules = array_values( $this->rules );

		if ( '' !== $scope ) {
			$rules = array_values(
				array_filter(
					$rules,
					static fn( array $rule ): bool => $scope === $rule['scope']
				)
			);
		}

		usort( $rules, static fn( array $first, array $second ): int => strcmp( $first['id'], $second['id'] ) );

		return $rules;
	}

	/**
	 * Execute all rules for one scope without allowing one provider to abort the run.
	 *
	 * @param string $scope Execution scope.
	 * @param array  $context Immutable audit context for the current scope.
	 * @param array  $job Mutable job-local caches shared across bounded batches.
	 * @return array{findings:array<int,array<string,mixed>>,errors:array<int,array<string,string>>}
	 */

	public function execute( string $scope, array $context, array &$job ): array {
		$findings = array();
		$errors = array();
		$limit_reached = false;

		foreach ( $this->rules( $scope ) as $rule ) {
			try {
				$result = call_user_func_array( $rule['callback'], array( $context, &$job ) );

				if ( is_wp_error( $result ) ) {
					throw new RuntimeException( $result->get_error_message() );
				}

				if ( ! is_array( $result ) ) {
					throw new UnexpectedValueException( 'Content Audit rule callbacks must return an array.' );
				}

				foreach ( $result as $finding ) {
					if ( count( $findings ) >= WPHAVE_Content_Audit::MAX_FINDINGS ) {
						$errors[] = array(
							'rule' => $rule['id'],
							'code' => 'provider_finding_limit',
							'message' => 'Content Audit rule output exceeded the global finding limit.',
						);
						$limit_reached = true;

						break;
					}

					if ( ! is_array( $finding ) ) {
						continue;
					}

					$finding['ruleId'] = $rule['id'];
					$finding['ruleVersion'] = $rule['version'];
					$finding['source'] = sanitize_key( $finding['source'] ?? 'content-audit' );
					$finding['category'] = sanitize_key( $finding['category'] ?? 'quality' );
					$finding['severity'] = in_array( $finding['severity'] ?? '', array( 'critical', 'warning', 'info' ), true ) ? $finding['severity'] : 'info';
					$finding['code'] = sanitize_key( $finding['code'] ?? $rule['id'] );
					$finding['title'] = sanitize_text_field( $finding['title'] ?? '' );
					$finding['description'] = sanitize_textarea_field( $finding['description'] ?? '' );
					$finding['postId'] = absint( $finding['postId'] ?? 0 );
					$finding['postType'] = sanitize_key( $finding['postType'] ?? '' );
					$finding['postTitle'] = sanitize_text_field( $finding['postTitle'] ?? '' );
					$finding['postUrl'] = esc_url_raw( $finding['postUrl'] ?? '' );
					$finding['editUrl'] = esc_url_raw( $finding['editUrl'] ?? '' );
					$finding['url'] = esc_url_raw( $finding['url'] ?? '' );
					$finding['evidence'] = self::sanitize_evidence( $finding['evidence'] ?? array() );
					$finding['fingerprint'] = WPHAVE_Content_Audit::finding_fingerprint( $finding );
					$findings[] = $finding;
				}
			} catch ( Throwable $error ) {
				$errors[] = array(
					'rule' => $rule['id'],
					'message' => WPHAVE_Security_Redactor::error_text( $error->getMessage() ),
				);
			}

			if ( $limit_reached ) {
				break;
			}
		}

		return compact( 'findings', 'errors' );
	}

	/** Return the deterministic identity of all active rule implementations. */

	public function version(): string {
		$versions = array_map(
			static fn( array $rule ): string => $rule['id'] . ':' . $rule['version'],
			$this->rules()
		);

		return hash( 'sha256', implode( '|', $versions ) );
	}

	/** Return callback-free rule metadata for snapshots and diagnostics. */

	public function manifest(): array {
		return array_map(
			static function( array $rule ): array {
				return array(
					'id' => $rule['id'],
					'version' => $rule['version'],
					'scope' => $rule['scope'],
					'metadata' => $rule['metadata'],
				);
			},
			$this->rules()
		);
	}

	/**
	 * Normalize extension metadata into a bounded JSON-safe structure.
	 *
	 * @param mixed $value Metadata value.
	 * @param int   $depth Current nesting depth.
	 * @return mixed Sanitized scalar, array or null for unsupported values.
	 */

	private static function sanitize_metadata( $value, int $depth = 0 ) {
		if ( $depth > 5 ) {
			return null;
		}

		if ( is_array( $value ) ) {
			$sanitized = array();
			foreach ( $value as $key => $item ) {
				$clean_item = self::sanitize_metadata( $item, $depth + 1 );
				if ( null !== $clean_item ) {
					$sanitized[ sanitize_key( (string) $key ) ] = $clean_item;
				}
			}

			return $sanitized;
		}

		if ( is_bool( $value ) || is_int( $value ) || is_float( $value ) ) {
			return $value;
		}

		return is_string( $value ) ? sanitize_text_field( $value ) : null;
	}

	/**
	 * Bound provider evidence before it reaches job options or immutable storage.
	 *
	 * @param mixed $value Provider-controlled evidence value.
	 * @param int   $depth Current nesting depth.
	 * @return mixed JSON-safe sanitized evidence.
	 */

	private static function sanitize_evidence( $value, int $depth = 0 ) {
		if ( $depth > 5 ) {
			return null;
		}

		if ( is_array( $value ) ) {
			$sanitized = array();
			foreach ( array_slice( $value, 0, 100, true ) as $key => $item ) {
				$clean_item = self::sanitize_evidence( $item, $depth + 1 );
				if ( null !== $clean_item ) {
					$clean_key = is_int( $key ) ? $key : sanitize_key( (string) $key );
					$sanitized[ $clean_key ] = $clean_item;
				}
			}

			return $sanitized;
		}

		if ( is_bool( $value ) || is_int( $value ) || is_float( $value ) ) {
			return $value;
		}

		if ( is_string( $value ) ) {
			return sanitize_text_field( mb_substr( $value, 0, 2000 ) );
		}

		return null;
	}
}
