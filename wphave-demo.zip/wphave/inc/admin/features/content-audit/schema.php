<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Owns the canonical database contract for Content Audit.
 *
 * The feature is unreleased, so this installer describes one clean initial
 * schema rather than a chain of compatibility migrations. Installation and
 * validation remain delegated to the shared WPHAVE schema manager. Runtime
 * consumers may rely on all four tables being present together.
 *
 * Invariants:
 * - Snapshots and their findings are immutable after commit.
 * - One fingerprint may occur only once within a snapshot.
 * - Mutable editorial state is stored separately from immutable observations.
 * - Tables use InnoDB so snapshot and workflow writes can commit atomically.
 */

final class WPHAVE_Content_Audit_Schema {

	/** Initial canonical schema version registered with the schema manager. */

	public const DB_VERSION = '1.0.0';
	public const SNAPSHOTS_TABLE = 'wphave_content_audit_snapshots';
	public const FINDINGS_TABLE = 'wphave_content_audit_findings';
	public const ISSUE_STATE_TABLE = 'wphave_content_audit_issue_state';
	public const URL_CACHE_TABLE = 'wphave_content_audit_url_cache';

	/** Request-local validation result; avoids metadata queries for every audited URL. */

	private static ?bool $validation_cache = null;

	/** Create or reconcile the complete canonical table set. */

	public static function install(): void {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();
		$snapshots = $wpdb->prefix . self::SNAPSHOTS_TABLE;
		$findings = $wpdb->prefix . self::FINDINGS_TABLE;
		$issue_state = $wpdb->prefix . self::ISSUE_STATE_TABLE;
		$url_cache = $wpdb->prefix . self::URL_CACHE_TABLE;

		dbDelta( "CREATE TABLE {$snapshots} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			job_uuid char(36) NOT NULL,
			started_at datetime NOT NULL,
			finished_at datetime NOT NULL,
			scheduled tinyint(1) unsigned NOT NULL DEFAULT 0,
			score smallint(3) unsigned NOT NULL DEFAULT 0,
			processed int(10) unsigned NOT NULL DEFAULT 0,
			total int(10) unsigned NOT NULL DEFAULT 0,
			finding_count int(10) unsigned NOT NULL DEFAULT 0,
			critical_count int(10) unsigned NOT NULL DEFAULT 0,
			warning_count int(10) unsigned NOT NULL DEFAULT 0,
			info_count int(10) unsigned NOT NULL DEFAULT 0,
			new_count int(10) unsigned NOT NULL DEFAULT 0,
			resolved_count int(10) unsigned NOT NULL DEFAULT 0,
			unchanged_count int(10) unsigned NOT NULL DEFAULT 0,
			scope_hash char(64) NOT NULL DEFAULT '',
			ruleset_version char(64) NOT NULL DEFAULT '',
			score_version smallint(5) unsigned NOT NULL DEFAULT 1,
			complete tinyint(1) unsigned NOT NULL DEFAULT 1,
			truncated tinyint(1) unsigned NOT NULL DEFAULT 0,
			truncation_reason varchar(100) NOT NULL DEFAULT '',
			error_count int(10) unsigned NOT NULL DEFAULT 0,
			coverage longtext DEFAULT NULL,
			counts longtext DEFAULT NULL,
			settings longtext DEFAULT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY job_uuid (job_uuid),
			KEY finished_at (finished_at),
			KEY score_date (score,finished_at),
			KEY compatible_history (scope_hash(16),ruleset_version(16),complete,finished_at)
		) ENGINE=InnoDB {$charset};" );

		dbDelta( "CREATE TABLE {$findings} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			snapshot_id bigint(20) unsigned NOT NULL,
			fingerprint char(64) NOT NULL,
			post_id bigint(20) unsigned NOT NULL DEFAULT 0,
			post_type varchar(50) NOT NULL DEFAULT '',
			finding_code varchar(100) NOT NULL,
			category varchar(50) NOT NULL,
			severity varchar(20) NOT NULL,
			rule_id varchar(100) NOT NULL DEFAULT '',
			rule_version varchar(30) NOT NULL DEFAULT '1',
			source varchar(50) NOT NULL DEFAULT 'content-audit',
			post_title varchar(255) NOT NULL DEFAULT '',
			title text DEFAULT NULL,
			description text DEFAULT NULL,
			post_url text DEFAULT NULL,
			edit_url text DEFAULT NULL,
			target_url text DEFAULT NULL,
			evidence longtext DEFAULT NULL,
			priority_score smallint(5) unsigned NOT NULL DEFAULT 0,
			analytics_views int(10) unsigned NOT NULL DEFAULT 0,
			analytics_conversions int(10) unsigned NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			UNIQUE KEY snapshot_fingerprint (snapshot_id,fingerprint),
			KEY snapshot_severity (snapshot_id,severity),
			KEY post_history (post_id,finding_code),
			KEY fingerprint_history (fingerprint,snapshot_id)
		) ENGINE=InnoDB {$charset};" );

		dbDelta( "CREATE TABLE {$issue_state} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			fingerprint char(64) NOT NULL,
			status varchar(20) NOT NULL DEFAULT 'open',
			first_snapshot_id bigint(20) unsigned NOT NULL DEFAULT 0,
			last_snapshot_id bigint(20) unsigned NOT NULL DEFAULT 0,
			first_seen_at datetime NOT NULL,
			last_seen_at datetime NOT NULL,
			resolved_at datetime DEFAULT NULL,
			assignee_id bigint(20) unsigned NOT NULL DEFAULT 0,
			note text DEFAULT NULL,
			snoozed_until datetime DEFAULT NULL,
			updated_by bigint(20) unsigned NOT NULL DEFAULT 0,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY fingerprint (fingerprint),
			KEY workflow_status (status,last_seen_at),
			KEY assignee_status (assignee_id,status),
			KEY last_snapshot (last_snapshot_id)
		) ENGINE=InnoDB {$charset};" );

		dbDelta( "CREATE TABLE {$url_cache} (
			url_hash char(64) NOT NULL,
			url text NOT NULL,
			state varchar(30) NOT NULL,
			status_code smallint(5) unsigned NOT NULL DEFAULT 0,
			failure_code varchar(100) NOT NULL DEFAULT '',
			checked_at datetime NOT NULL,
			expires_at datetime NOT NULL,
			failure_count smallint(5) unsigned NOT NULL DEFAULT 0,
			PRIMARY KEY  (url_hash),
			KEY expires_at (expires_at),
			KEY state_expiry (state,expires_at)
		) ENGINE=InnoDB {$charset};" );

		self::$validation_cache = null;
	}

	/**
	 * Verify the table and column postconditions required by runtime code.
	 *
	 * @param bool $force_refresh Ignore the request-local metadata cache.
	 * @return bool True when the complete storage contract is available.
	 */

	public static function validate( bool $force_refresh = false ): bool {
		global $wpdb;

		if ( ! $force_refresh && null !== self::$validation_cache ) {
			return self::$validation_cache;
		}

		$required_columns = array(
			self::SNAPSHOTS_TABLE => array(
				'id',
				'job_uuid',
				'started_at',
				'finished_at',
				'scheduled',
				'score',
				'processed',
				'total',
				'finding_count',
				'critical_count',
				'warning_count',
				'info_count',
				'new_count',
				'resolved_count',
				'unchanged_count',
				'scope_hash',
				'ruleset_version',
				'score_version',
				'complete',
				'truncated',
				'truncation_reason',
				'error_count',
				'coverage',
				'counts',
				'settings',
			),
			self::FINDINGS_TABLE => array(
				'id',
				'snapshot_id',
				'fingerprint',
				'post_id',
				'post_type',
				'finding_code',
				'category',
				'severity',
				'rule_id',
				'rule_version',
				'source',
				'post_title',
				'title',
				'description',
				'post_url',
				'edit_url',
				'target_url',
				'evidence',
				'priority_score',
				'analytics_views',
				'analytics_conversions',
			),
			self::ISSUE_STATE_TABLE => array(
				'id',
				'fingerprint',
				'status',
				'first_snapshot_id',
				'last_snapshot_id',
				'first_seen_at',
				'last_seen_at',
				'resolved_at',
				'assignee_id',
				'note',
				'snoozed_until',
				'updated_by',
				'updated_at',
			),
			self::URL_CACHE_TABLE => array(
				'url_hash',
				'url',
				'state',
				'status_code',
				'failure_code',
				'checked_at',
				'expires_at',
				'failure_count',
			),
		);

		foreach ( $required_columns as $name => $columns ) {
			$table = $wpdb->prefix . $name;
			if ( ! WPHAVE_Database_Metadata::table_exists( $table ) ) {
				self::$validation_cache = false;

				return self::$validation_cache;
			}

			$installed_columns = WPHAVE_Database_Metadata::column_names( $table );
			if ( array_diff( $columns, $installed_columns ) ) {
				self::$validation_cache = false;

				return self::$validation_cache;
			}
		}

		$fingerprint_tables = array(
			self::FINDINGS_TABLE,
			self::ISSUE_STATE_TABLE,
		);

		foreach ( $fingerprint_tables as $name ) {
			$table = $wpdb->prefix . $name;
			$column = $wpdb->get_row(
				"SHOW COLUMNS FROM `{$table}` WHERE Field = 'fingerprint'",
				ARRAY_A
			);

			if ( 'char(64)' !== strtolower( (string) ( $column['Type'] ?? '' ) ) ) {
				self::$validation_cache = false;

				return self::$validation_cache;
			}
		}

		self::$validation_cache = true;

		return self::$validation_cache;
	}
}
