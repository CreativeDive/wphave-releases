<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers the Content Audit REST surface without loading the audit engine.
 *
 * The complete workflow remains synchronous once a Content Audit request is
 * dispatched. Ordinary management requests only retain this small composition
 * boundary and therefore do not parse the scan, persistence and automation
 * implementation.
 */
require_once __DIR__ . '/schema-registration.php';

function wphave_content_audit_register_management_routes(): void {
	require_once __DIR__ . '/bootstrap.php';

	WPHAVE_Content_Audit::register_rest_routes();
}

add_action( 'rest_api_init', 'wphave_content_audit_register_management_routes' );
