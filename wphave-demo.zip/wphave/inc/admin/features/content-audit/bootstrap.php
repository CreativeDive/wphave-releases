<?php

if (!defined('ABSPATH')) {
	exit();
}

require_once wphave_dir() . 'inc/features/security/boundaries/index.php';
require_once wphave_dir() . 'inc/background-jobs/functions.php';
require_once __DIR__ . '/schema-registration.php';

if (!class_exists('WPHAVE_Content_Audit')):
	/**
	 * Coordinates the WPHAVE Content Audit workflow.
	 *
	 * The service owns inventory discovery, bounded rule execution, server-side
	 * continuation, immutable snapshots, retention, automation and the REST
	 * boundary. Rule definitions, mutable finding workflow and analytics impact
	 * enrichment are delegated to dedicated collaborators.
	 *
	 * State invariants:
	 * - At most one site-wide audit job may be running.
	 * - Mutable job/result options are scoped by one immutable job UUID.
	 * - Only complete compatible snapshots participate in change comparisons.
	 * - A snapshot, its findings and workflow synchronization commit atomically.
	 * - DATA INTEGRITY INVARIANT: Partial or provider-error runs never resolve earlier findings.
	 */

	final class WPHAVE_Content_Audit {
		const SNAPSHOTS_TABLE = WPHAVE_Content_Audit_Schema::SNAPSHOTS_TABLE;
		const FINDINGS_TABLE = WPHAVE_Content_Audit_Schema::FINDINGS_TABLE;
		const ISSUE_STATE_TABLE = WPHAVE_Content_Audit_Schema::ISSUE_STATE_TABLE;
		const URL_CACHE_TABLE = WPHAVE_Content_Audit_Schema::URL_CACHE_TABLE;
		const STATUS_OPTION = 'wphave_content_audit_status';
		const JOB_OPTION = 'wphave_content_audit_job';
		const RESULTS_OPTION = 'wphave_content_audit_results';
		const DEFAULT_LIMIT = 100;
		const MAX_LIMIT = 500;
		const BATCH_SIZE = 1;
		const REQUEST_TIMEOUT = 6;
		const MAX_LINKS_PER_ITEM = 25;
		const MAX_FINDINGS = 10000;
		const PROCESS_HOOK = 'wphave_content_audit_process';
		const PROCESS_LOCK = 'wphave_content_audit_process_lock';
		const START_LOCK = 'wphave_content_audit_start_lock';
		const PROCESS_LOCK_TIMEOUT = 360;
		const JOB_TIMEOUT = 420;
		const AUTOMATION_OPTION = 'wphave_content_audit_automation';
		const AUTOMATION_SCHEDULE_OPTION = 'wphave_content_audit_automation_schedule';
		const AUTOMATION_HOOK = 'wphave_content_audit_automatic_scan';
		const AUTOMATION_LOCK = 'wphave_content_audit_automation_lock';
		const NOTIFICATION_OPTION = 'wphave_content_audit_last_notification';
		const NOTIFIED_OPTION = 'wphave_content_audit_notified_findings';
		const LAST_AUTOMATIC_OPTION = 'wphave_content_audit_last_automatic_run';
		const CLEANUP_HOOK = 'wphave_content_audit_history_cleanup';
		const CLEANUP_SCHEDULE_OPTION = 'wphave_content_audit_cleanup_schedule';
		const CLEANUP_CONTINUATION_HOOK = 'wphave_content_audit_history_cleanup_continuation';
		const CLEANUP_BATCH_SIZE = 100;
		const RETENTION_DAYS = 90;
		const MAX_SNAPSHOTS = 30;
		const SCORE_VERSION = 2;

		private static bool $rules_registered = false;
		private static bool $routes_registered = false;

		/** Register collaborators, schema, worker hooks and schedules. */

		public static function init(): void {
			require_once __DIR__ . '/rule-registry.php';
			require_once __DIR__ . '/finding-repository.php';
			self::register_default_rules();
			if (!WPHAVE_Database_Schema_Manager::runtime_compatible('content-audit')) {
				return;
			}

			// RUNTIME INVARIANT: REST ownership belongs exclusively to
			// management.php. The audit engine is also loaded by Cron, where route
			// registration is both unreachable and an avoidable interactive surface.
			add_action(self::PROCESS_HOOK, [__CLASS__, 'run_scheduled_batch']);
			add_action(self::AUTOMATION_HOOK, [__CLASS__, 'run_automatic_audit']);
			add_action(self::CLEANUP_HOOK, [__CLASS__, 'cleanup_history']);
			add_action(self::CLEANUP_CONTINUATION_HOOK, [__CLASS__, 'cleanup_history']);
			add_action('init', [__CLASS__, 'resume_pending_job']);
			add_action('init', [__CLASS__, 'sync_automation_schedule'], 20);
		}

		/** Restore a server-owned continuation removed during plugin deactivation. */

		public static function resume_pending_job(): void {
			$status = self::get_status();

			if ('running' === $status['state'] && get_option(self::JOB_OPTION)) {
				self::schedule_next_batch();
			}
		}

		/**
		 * Register the content audit REST API.
		 *
		 * @return void
		 */

		public static function register_rest_routes(): void {
			if (self::$routes_registered) {
				return;
			}

			self::$routes_registered = true;

			register_rest_route('wphave/v1', '/content-audit/start', [
				'methods' => 'POST',
				'callback' => [__CLASS__, 'rest_start_audit'],
				'permission_callback' => [__CLASS__, 'can_manage'],
				'args' => [
					'limit' => [
						'type' => 'integer',
						'default' => self::DEFAULT_LIMIT,
						'minimum' => 1,
						'maximum' => self::MAX_LIMIT,
						'sanitize_callback' => 'absint',
					],
					'checkExternalLinks' => [
						'type' => 'boolean',
						'default' => true,
						'sanitize_callback' => 'rest_sanitize_boolean',
					],
				],
			]);

			register_rest_route('wphave/v1', '/content-audit/process', [
				'methods' => 'POST',
				'callback' => [__CLASS__, 'rest_process_audit'],
				'permission_callback' => [__CLASS__, 'can_manage'],
				'args' => [],
			]);

			register_rest_route('wphave/v1', '/content-audit/status', [
				'methods' => 'GET',
				'callback' => [__CLASS__, 'rest_get_status'],
				'permission_callback' => [__CLASS__, 'can_manage'],
			]);

			register_rest_route('wphave/v1', '/content-audit/results', [
				'methods' => 'GET',
				'callback' => [__CLASS__, 'rest_get_results'],
				'permission_callback' => [__CLASS__, 'can_manage'],
			]);

			register_rest_route('wphave/v1', '/content-audit/overview', [
				'methods' => 'GET',
				'callback' => [__CLASS__, 'rest_get_overview'],
				'permission_callback' => [__CLASS__, 'can_manage'],
				'args' => [
					'scope' => [
						'type' => 'string',
						'default' => 'full',
						'enum' => ['full', 'completed'],
						'sanitize_callback' => 'sanitize_key',
					],
				],
			]);

			register_rest_route('wphave/v1', '/content-audit/cancel', [
				'methods' => 'POST',
				'callback' => [__CLASS__, 'rest_cancel_audit'],
				'permission_callback' => [__CLASS__, 'can_manage'],
			]);

			register_rest_route('wphave/v1', '/content-audit/automation', [
				[
					'methods' => 'GET',
					'callback' => [__CLASS__, 'rest_get_automation'],
					'permission_callback' => [__CLASS__, 'can_manage'],
				],
				[
					'methods' => 'POST',
					'callback' => [__CLASS__, 'rest_update_automation'],
					'permission_callback' => [__CLASS__, 'can_manage'],
					'args' => [
						'enabled' => [
							'type' => 'boolean',
							'required' => true,
							'sanitize_callback' => 'rest_sanitize_boolean',
						],
						'frequency' => [
							'type' => 'string',
							'default' => 'weekly',
							'enum' => ['daily', 'weekly', 'monthly'],
							'sanitize_callback' => 'sanitize_key',
						],
						'timeWindow' => [
							'type' => 'string',
							'default' => 'night',
							'enum' => ['night', 'morning', 'afternoon', 'evening'],
							'sanitize_callback' => 'sanitize_key',
						],
						'email' => [
							'type' => 'string',
							'default' => '',
							'sanitize_callback' => 'sanitize_email',
							'validate_callback' => static function ($value): bool {
								return '' === (string) $value ||
									false !== is_email((string) $value);
							},
						],
						'limit' => [
							'type' => 'integer',
							'default' => self::DEFAULT_LIMIT,
							'minimum' => 1,
							'maximum' => self::MAX_LIMIT,
							'sanitize_callback' => 'absint',
						],
						'checkExternalLinks' => [
							'type' => 'boolean',
							'default' => true,
							'sanitize_callback' => 'rest_sanitize_boolean',
						],
					],
				],
			]);

			register_rest_route('wphave/v1', '/content-audit/history', [
				'methods' => 'GET',
				'callback' => [__CLASS__, 'rest_get_history'],
				'permission_callback' => [__CLASS__, 'can_manage'],
			]);

			register_rest_route(
				'wphave/v1',
				'/content-audit/findings/(?P<fingerprint>[a-f0-9]{64})/state',
				[
					'methods' => 'POST',
					'callback' => [__CLASS__, 'rest_update_finding_state'],
					'permission_callback' => [__CLASS__, 'can_manage'],
					'args' => [
						'fingerprint' => [
							'type' => 'string',
							'required' => true,
							'pattern' => '^[a-f0-9]{64}$',
						],
						'status' => [
							'type' => 'string',
							'required' => true,
							'enum' => ['open', 'accepted', 'ignored', 'resolved'],
							'sanitize_callback' => 'sanitize_key',
						],
						'note' => [
							'type' => 'string',
							'maxLength' => 5000,
							'sanitize_callback' => 'sanitize_textarea_field',
						],
						'assigneeId' => [
							'type' => 'integer',
							'minimum' => 0,
							'sanitize_callback' => 'absint',
						],
						'snoozedUntil' => [
							'type' => 'string',
							'maxLength' => 19,
							'pattern' => '^$|^\\d{4}-\\d{2}-\\d{2}( \\d{2}:\\d{2}:\\d{2})?$',
							'sanitize_callback' => 'sanitize_text_field',
						],
					],
				],
			);
		}

		/** Update the durable editorial workflow state of one finding. */

		public static function rest_update_finding_state(WP_REST_Request $request) {
			$authorized = self::require_manage_access();
			if (is_wp_error($authorized)) {
				return $authorized;
			}
			$result = WPHAVE_Content_Audit_Finding_Repository::update_state(
				(string) $request->get_param('fingerprint'),
				[
					'status' => $request->get_param('status'),
					'note' => $request->get_param('note'),
					'assigneeId' => $request->get_param('assigneeId'),
					'snoozedUntil' => $request->get_param('snoozedUntil'),
				],
				get_current_user_id(),
			);

			return is_wp_error($result) ? $result : rest_ensure_response($result);
		}

		/**
		 * Check whether the current user may run content audits.
		 *
		 * @return bool
		 */

		public static function can_manage(): bool {
			return current_user_can('wphave_manage_content_audit') ||
				current_user_can('wphave_manage_options') ||
				current_user_can('manage_options');
		}

		/** AUTHORIZATION INVARIANT: REST dispatch is only an early gate; every
		 * public Content Audit callback repeats the canonical capability before
		 * disclosing private findings or mutating jobs, workflow, schedules or state.
		 * Cron workers use separate internal methods and do not inherit HTTP authority.
		 *
		 * @return true|WP_Error
		 */
		private static function require_manage_access() {
			return self::can_manage()
				? true
				: new WP_Error(
					'wphave_content_audit_forbidden',
					__('You are not allowed to manage content audits.', 'wphave'),
					['status' => 403],
				);
		}

		/** Register built-in rules through the same extension contract as integrations. */

		private static function register_default_rules(): void {
			if (self::$rules_registered) {
				return;
			}

			self::$rules_registered = true;
			$registry = WPHAVE_Content_Audit_Rule_Registry::instance();
			$registry->register(
				'seo-basics',
				'2.0.0',
				'item',
				static function (array $context, array &$job): array {
					return self::audit_seo(
						$context['post'],
						$context['item'],
						$context['seo'],
						$context['content'],
						$context['text'],
					);
				},
				['category' => 'seo', 'cost' => 'local'],
			);
			$registry->register(
				'link-health',
				'2.0.0',
				'item',
				static function (array $context, array &$job): array {
					return self::audit_links($context['item'], $context['assets']['links'], $job);
				},
				['category' => 'links', 'cost' => 'network'],
			);
			$registry->register(
				'media-accessibility',
				'2.0.0',
				'item',
				static function (array $context, array &$job): array {
					return self::audit_media($context['item'], $context['assets']);
				},
				['category' => 'media', 'cost' => 'local'],
			);
			$registry->register(
				'content-quality',
				'2.0.0',
				'item',
				static function (array $context, array &$job): array {
					return self::audit_quality(
						$context['post'],
						$context['item'],
						$context['content'],
						$context['text'],
						$context['assets'],
					);
				},
				['category' => 'quality', 'cost' => 'local'],
			);
			$registry->register(
				'content-security',
				'2.0.0',
				'item',
				static function (array $context, array &$job): array {
					return self::audit_security($context['item'], $context['assets']);
				},
				['category' => 'security', 'cost' => 'local'],
			);
			$registry->register(
				'document-structure',
				'1.0.0',
				'item',
				static function (array $context, array &$job): array {
					return self::audit_document_structure($context['item'], $context['assets']);
				},
				['category' => 'quality', 'cost' => 'local'],
			);
			$registry->register(
				'rendered-schema',
				'1.0.0',
				'item',
				static function (array $context, array &$job): array {
					return self::audit_rendered_schema($context['post'], $context['item']);
				},
				['category' => 'schema', 'cost' => 'network'],
			);
			$registry->register(
				'site-content-graph',
				'1.0.0',
				'site',
				static function (array $context, array &$job): array {
					return self::audit_site_content_graph($context);
				},
				['category' => 'quality', 'cost' => 'aggregate'],
			);
			$registry->register(
				'privacy-alignment',
				'1.0.0',
				'site',
				static function (array $context, array &$job): array {
					return self::audit_privacy_alignment();
				},
				['category' => 'privacy', 'cost' => 'integration'],
			);

			/**
			 * Register additional Content Audit rule providers.
			 *
			 * @param WPHAVE_Content_Audit_Rule_Registry $registry Registry instance.
			 */

			do_action('wphave_content_audit_register_rules', $registry);
		}

		/**
		 * Start a new manual audit.
		 *
		 * @param WP_REST_Request $request REST request.
		 * @return WP_REST_Response
		 */

		public static function rest_start_audit(WP_REST_Request $request) {
			$authorized = self::require_manage_access();
			if (is_wp_error($authorized)) {
				return $authorized;
			}
			$limit = absint($request->get_param('limit'));
			$check_external_links = rest_sanitize_boolean(
				$request->get_param('checkExternalLinks'),
			);
			$result = self::start_audit($limit, $check_external_links);

			return is_wp_error($result) ? $result : rest_ensure_response($result);
		}

		/**
		 * Process the next audit batch.
		 *
		 * @return WP_REST_Response
		 */

		public static function rest_process_audit() {
			$authorized = self::require_manage_access();
			if (is_wp_error($authorized)) {
				return $authorized;
			}
			return rest_ensure_response(self::process_batch());
		}

		public static function rest_cancel_audit() {
			$authorized = self::require_manage_access();
			if (is_wp_error($authorized)) {
				return $authorized;
			}
			$status = self::get_status();

			if ('running' !== $status['state']) {
				return rest_ensure_response($status);
			}

			$status['state'] = 'cancelled';
			$status['finishedAt'] = current_time('mysql');
			$status['heartbeatAt'] = time();
			delete_option(self::JOB_OPTION);
			wp_clear_scheduled_hook(self::PROCESS_HOOK);

			$results_stored = self::finalize_interrupted_results(
				'cancelled',
				$status['finishedAt'],
			);
			$status_stored = self::set_status($status);

			if (!$results_stored || !$status_stored) {
				return new WP_Error(
					'wphave_content_audit_cancel_persistence_failed',
					__(
						'The audit was stopped, but its final partial state could not be stored.',
						'wphave',
					),
					['status' => 500],
				);
			}

			return rest_ensure_response($status);
		}

		/**
		 * Return the current audit status.
		 *
		 * @return WP_REST_Response
		 */

		public static function rest_get_status() {
			$authorized = self::require_manage_access();
			if (is_wp_error($authorized)) {
				return $authorized;
			}
			$status = self::get_status();

			if ('running' === $status['state']) {
				self::schedule_next_batch();
			}

			return rest_ensure_response($status);
		}

		/**
		 * Continue a running audit independently from the admin screen lifecycle.
		 */

		public static function run_scheduled_batch(): void {
			self::process_batch();
		}

		/**
		 * Return the latest audit results.
		 *
		 * @return WP_REST_Response
		 */

		public static function rest_get_results() {
			$authorized = self::require_manage_access();
			if (is_wp_error($authorized)) {
				return $authorized;
			}
			$results = self::get_results();

			if (!empty($results['_storageError'])) {
				return new WP_Error(
					'wphave_content_audit_results_unavailable',
					__('The stored Content Audit results could not be loaded.', 'wphave'),
					['status' => 503],
				);
			}

			$fingerprints = array_column((array) ($results['findings'] ?? []), 'fingerprint');
			$states = WPHAVE_Content_Audit_Finding_Repository::states_for_fingerprints(
				$fingerprints,
			);

			if (is_wp_error($states)) {
				return $states;
			}

			$results['findings'] = array_map(static function (array $finding) use ($states): array {
				$fingerprint = (string) ($finding['fingerprint'] ?? '');
				$finding['workflow'] = $states[$fingerprint] ?? [
					'status' => 'open',
				];

				return $finding;
			}, (array) ($results['findings'] ?? []));

			return rest_ensure_response($results);
		}

		/**
		 * Return the named read projections required by the Content Audit workspace.
		 *
		 * Projection failures remain isolated so optional history or automation data
		 * cannot discard an otherwise usable status and results snapshot.
		 *
		 * @param WP_REST_Request $request Current REST request.
		 * @return WP_REST_Response
		 */

		public static function rest_get_overview(WP_REST_Request $request) {
			$authorized = self::require_manage_access();
			if (is_wp_error($authorized)) {
				return $authorized;
			}
			$scope = sanitize_key($request->get_param('scope') ?: 'full');
			$callbacks =
				'completed' === $scope
					? [
						'results' => 'rest_get_results',
						'history' => 'rest_get_history',
					]
					: [
						'status' => 'rest_get_status',
						'results' => 'rest_get_results',
						'history' => 'rest_get_history',
						'automation' => 'rest_get_automation',
					];
			$projections = [];
			$errors = [];

			foreach ($callbacks as $projection => $callback) {
				$response = call_user_func([__CLASS__, $callback]);

				if (is_wp_error($response)) {
					$error_data = $response->get_error_data();
					$errors[$projection] = [
						'code' => $response->get_error_code(),
						'message' => $response->get_error_message(),
						'status' => is_array($error_data)
							? (int) ($error_data['status'] ?? 500)
							: 500,
					];
					continue;
				}

				$projections[$projection] =
					$response instanceof WP_REST_Response ? $response->get_data() : $response;
			}

			return rest_ensure_response([
				'projections' => $projections,
				'errors' => $errors,
			]);
		}

		/**
		 * Create a fresh audit job and result shell.
		 *
		 * @param int $limit Maximum number of public content items.
		 * @param bool $check_external_links Whether external URL status checks are enabled.
		 * @return array|WP_Error Current status.
		 */

		protected static function start_audit(
			int $limit = self::DEFAULT_LIMIT,
			bool $check_external_links = true,
			bool $scheduled = false,
		) {
			$token = WPHAVE_Background_Job_Lock::acquire(self::START_LOCK, 30);

			if (!$token) {
				return new WP_Error(
					'wphave_content_audit_start_locked',
					__('A content audit is currently being started.', 'wphave'),
					['status' => 409],
				);
			}

			try {
				return self::start_audit_unlocked($limit, $check_external_links, $scheduled);
			} finally {
				// SECURITY INVARIANT: A stalled audit starter cannot release a successor's
				// lock after timeout recovery; cleanup remains bound to its exact token.
				WPHAVE_Background_Job_Lock::release(self::START_LOCK, $token);
			}
		}

		private static function start_audit_unlocked(
			int $limit,
			bool $check_external_links,
			bool $scheduled = false,
		) {
			if (self::get_status()['state'] === 'running') {
				return new WP_Error(
					'wphave_content_audit_running',
					__('A content audit is already running.', 'wphave'),
					['status' => 409],
				);
			}

			$schema_ready = self::ensure_storage_schema();
			if (is_wp_error($schema_ready)) {
				return $schema_ready;
			}

			$limit = max(1, min(self::MAX_LIMIT, $limit ?: self::DEFAULT_LIMIT));
			$started_at = current_time('mysql');
			$inventory = self::discover_content_items($limit);
			$items = $inventory['items'];
			$ruleset_version = WPHAVE_Content_Audit_Rule_Registry::instance()->version();
			$scope_identity = [
				'site' => home_url('/'),
				'postTypes' => $inventory['postTypes'],
				'checkExternalLinks' => $check_external_links,
			];
			$scope_hash = hash('sha256', wp_json_encode($scope_identity));
			$coverage = [
				'discovered' => $inventory['total'],
				'selected' => count($items),
				'postTypes' => $inventory['postTypes'],
				'complete' => !$inventory['truncated'],
			];

			$job = [
				'id' => wp_generate_uuid4(),
				'startedAt' => $started_at,
				'heartbeatAt' => time(),
				'items' => $items,
				'processed' => 0,
				'checkExternalLinks' => $check_external_links,
				'scheduled' => $scheduled,
				'linkCache' => [],
				'scopeHash' => $scope_hash,
				'rulesetVersion' => $ruleset_version,
				'coverage' => $coverage,
				'errors' => [],
			];

			$results = [
				'startedAt' => $started_at,
				'finishedAt' => count($items) ? '' : $started_at,
				'processed' => 0,
				'total' => count($items),
				'score' => 0,
				'checkExternalLinks' => $check_external_links,
				'scheduled' => $scheduled,
				'counts' => self::empty_counts(),
				'findings' => [],
				'items' => [],
				'scopeHash' => $scope_hash,
				'rulesetVersion' => $ruleset_version,
				'scoreVersion' => self::SCORE_VERSION,
				'complete' => !$inventory['truncated'],
				'truncated' => $inventory['truncated'],
				'truncationReason' => $inventory['truncated'] ? 'content_limit' : '',
				'coverage' => $coverage,
				'errors' => [],
			];

			if (!self::store_option(self::JOB_OPTION, $job)) {
				return new WP_Error(
					'wphave_content_audit_job_persistence_failed',
					__('The Content Audit job could not be stored.', 'wphave'),
					['status' => 500],
				);
			}

			if (!self::store_option(self::RESULTS_OPTION, $results)) {
				delete_option(self::JOB_OPTION);
				return new WP_Error(
					'wphave_content_audit_results_persistence_failed',
					__('The Content Audit result could not be initialized.', 'wphave'),
					['status' => 500],
				);
			}

			$status = [
				'jobId' => $job['id'],
				'state' => count($items) ? 'running' : 'complete',
				'startedAt' => $started_at,
				'finishedAt' => count($items) ? '' : $started_at,
				'processed' => 0,
				'total' => count($items),
				'score' => 0,
				'counts' => self::empty_counts(),
				'heartbeatAt' => time(),
				'complete' => !$inventory['truncated'],
				'truncated' => $inventory['truncated'],
				'coverage' => $coverage,
			];

			if (!self::set_status($status)) {
				delete_option(self::JOB_OPTION);
				delete_option(self::RESULTS_OPTION);
				return new WP_Error(
					'wphave_content_audit_status_persistence_failed',
					__('The Content Audit status could not be initialized.', 'wphave'),
					['status' => 500],
				);
			}
			if (empty($items)) {
				$snapshot = self::persist_completed_snapshot($job, $results);
				if (is_wp_error($snapshot)) {
					$status['state'] = 'failed';
					$status['error'] = WPHAVE_Security_Redactor::error_text(
						$snapshot->get_error_message(),
					);
				} else {
					$results['snapshotId'] = $snapshot;
					$results['findingsStored'] = true;
					if (!self::store_option(self::RESULTS_OPTION, $results)) {
						$status['state'] = 'failed';
						$status['error'] = __(
							'The completed Content Audit result could not be stored.',
							'wphave',
						);
					} elseif ($scheduled) {
						self::complete_automatic_audit($results);
					}
				}

				delete_option(self::JOB_OPTION);
				if (!self::set_status($status)) {
					return new WP_Error(
						'wphave_content_audit_status_persistence_failed',
						__('The completed Content Audit status could not be stored.', 'wphave'),
						['status' => 500],
					);
				}
			}
			if (class_exists('WPHAVE_Activity_Log')) {
				WPHAVE_Activity_Log::record('content_audit.started', [
					'category' => 'system',
					'action' => 'started',
					'object_type' => 'scan',
					'object_label' => 'Content audit',
					'context' => [
						'total' => count($items),
						'external_links' => $check_external_links,
					],
				]);
			}

			if (
				empty($items) &&
				'complete' === $status['state'] &&
				class_exists('WPHAVE_Activity_Log')
			) {
				WPHAVE_Activity_Log::record('content_audit.completed', [
					'category' => 'system',
					'action' => 'completed',
					'object_type' => 'scan',
					'object_label' => 'Content audit',
					'context' => [
						'processed' => 0,
						'score' => 0,
						'findings' => 0,
					],
				]);
			}
			if (!empty($items)) {
				self::schedule_next_batch();
			}

			return $status;
		}

		/** Ensure an audit cannot start against a stale or incomplete storage contract. */

		private static function ensure_storage_schema() {
			if (WPHAVE_Content_Audit_Schema::validate()) {
				return true;
			}

			$result = WPHAVE_Database_Schema_Manager::update_schema('content-audit', [
				'context' => 'content-audit-preflight',
			]);

			if (!is_wp_error($result) && WPHAVE_Content_Audit_Schema::validate()) {
				return true;
			}

			return new WP_Error(
				'wphave_content_audit_schema_unavailable',
				__('The Content Audit storage schema is unavailable.', 'wphave'),
				['status' => 503],
			);
		}

		/**
		 * Process a small batch of content items.
		 *
		 * The batch size is intentionally small because the audit can perform
		 * remote HTTP checks. The React screen repeatedly calls this endpoint
		 * until the status becomes complete.
		 *
		 * @return array Current status.
		 */

		protected static function process_batch(): array {
			$lock_token = WPHAVE_Background_Job_Lock::acquire(
				self::PROCESS_LOCK,
				self::PROCESS_LOCK_TIMEOUT,
			);

			if (!$lock_token) {
				return self::get_status();
			}

			try {
				return self::process_unlocked_batch($lock_token);
			} finally {
				WPHAVE_Background_Job_Lock::release(self::PROCESS_LOCK, $lock_token);
			}
		}

		/**
		 * Process one batch while process_batch() owns the cross-request lock.
		 *
		 * @return array Current status.
		 */

		private static function process_unlocked_batch(string $lock_token): array {
			$status = self::get_status();

			if ($status['state'] !== 'running') {
				return $status;
			}

			$status['heartbeatAt'] = time();
			if (!self::set_status($status)) {
				return self::fail_running_audit_persistence($status, self::get_results());
			}

			$job = get_option(self::JOB_OPTION, []);
			$results = self::get_results();
			$items = isset($job['items']) && is_array($job['items']) ? $job['items'] : [];
			$processed = absint($job['processed'] ?? 0);
			$batch = array_slice($items, $processed, self::BATCH_SIZE);

			foreach ($batch as $item) {
				$audit = self::audit_content_item($item, $job);
				if (!self::owns_process_lock($lock_token)) {
					return self::get_status();
				}
				$results['items'][] = $audit['item'];
				$results['errors'] = array_merge($results['errors'] ?? [], $audit['errors'] ?? []);

				if (!empty($job['linkChecksTruncated'])) {
					$results['complete'] = false;
					$results['coverage']['linkChecksTruncated'] = true;

					$has_link_limit_error = array_filter(
						$results['errors'],
						static fn(array $error): bool => 'link-health' === ($error['rule'] ?? '') &&
							'link_check_limit' === ($error['code'] ?? ''),
					);

					if (!$has_link_limit_error) {
						$results['errors'][] = [
							'rule' => 'link-health',
							'code' => 'link_check_limit',
							'message' => __(
								'At least one content item exceeded the per-item link check limit.',
								'wphave',
							),
						];
					}
				}

				$merged_findings = self::normalize_findings(
					array_merge($results['findings'], $audit['findings']),
				);
				if (count($merged_findings) > self::MAX_FINDINGS) {
					$results['complete'] = false;
					$results['truncated'] = true;
					$results['truncationReason'] = 'finding_limit';
				}
				$results['findings'] = array_slice($merged_findings, 0, self::MAX_FINDINGS);
				$processed++;
				$status['heartbeatAt'] = time();
				if (!self::set_status($status)) {
					return self::fail_running_audit_persistence($status, $results);
				}
			}

			$job['processed'] = $processed;
			$results['processed'] = $processed;
			$authoritative_status = self::get_status();
			if (
				'running' !== $authoritative_status['state'] ||
				!hash_equals(
					(string) ($authoritative_status['jobId'] ?? ''),
					(string) ($job['id'] ?? ''),
				)
			) {
				return $authoritative_status;
			}

			if ($processed >= count($items)) {
				$site_result = WPHAVE_Content_Audit_Rule_Registry::instance()->execute(
					'site',
					[
						'items' => $results['items'],
						'findings' => $results['findings'],
						'coverage' => $results['coverage'] ?? [],
					],
					$job,
				);
				if (!self::worker_can_commit($lock_token, (string) ($job['id'] ?? ''))) {
					return self::get_status();
				}

				$all_findings = self::normalize_findings(
					array_merge($results['findings'], $site_result['findings']),
				);
				if (count($all_findings) > self::MAX_FINDINGS) {
					$results['complete'] = false;
					$results['truncated'] = true;
					$results['truncationReason'] = 'finding_limit';
				}
				$results['findings'] = array_slice($all_findings, 0, self::MAX_FINDINGS);
				$results['errors'] = array_merge($results['errors'] ?? [], $site_result['errors']);
				if (!empty($results['errors'])) {
					$results['complete'] = false;
				}
				$results['findings'] = self::normalize_findings(
					WPHAVE_Content_Audit_Insights::enrich($results['findings']),
				);
				if (!self::worker_can_commit($lock_token, (string) ($job['id'] ?? ''))) {
					return self::get_status();
				}

				$results['finishedAt'] = current_time('mysql');
			}

			$results['counts'] = self::count_findings($results['findings']);
			$results['score'] = self::calculate_score($results);

			$snapshot = null;
			if ($processed >= count($items)) {
				$snapshot = self::persist_completed_snapshot($job, $results);
				if (is_wp_error($snapshot)) {
					$status['state'] = 'failed';
					$status['error'] = WPHAVE_Security_Redactor::error_text(
						$snapshot->get_error_message(),
					);
					$status['finishedAt'] = $results['finishedAt'];
				} else {
					$status['state'] = 'complete';
					$status['finishedAt'] = $results['finishedAt'];
					$results['snapshotId'] = $snapshot;
				}
				delete_option(self::JOB_OPTION);
			}

			$status['processed'] = $processed;
			$status['total'] = count($items);
			$status['score'] = $results['score'];
			$status['counts'] = $results['counts'];
			$status['complete'] = !empty($results['complete']);
			$status['truncated'] = !empty($results['truncated']);
			$status['coverage'] = $results['coverage'] ?? [];
			$status['errorCount'] = count((array) ($results['errors'] ?? []));
			$status['heartbeatAt'] = time();
			$job['heartbeatAt'] = $status['heartbeatAt'];

			$stored_results = $results;
			if ('complete' === $status['state'] && !empty($results['snapshotId'])) {
				$stored_results['findingsStored'] = true;
				$stored_results['findings'] = [];
				$stored_results['items'] = [];
			}
			if ('running' === $status['state'] && !self::store_option(self::JOB_OPTION, $job)) {
				return self::fail_running_audit_persistence($status, $results);
			}

			if (
				!self::store_option(self::RESULTS_OPTION, $stored_results) ||
				!self::set_status($status)
			) {
				return self::fail_running_audit_persistence($status, $results);
			}

			if ('running' !== $status['state']) {
				if ('complete' === $status['state'] && !empty($job['scheduled'])) {
					self::complete_automatic_audit($results);
				}

				if (class_exists('WPHAVE_Activity_Log')) {
					WPHAVE_Activity_Log::record(
						is_wp_error($snapshot) ? 'content_audit.failed' : 'content_audit.completed',
						[
							'category' => 'system',
							'action' => is_wp_error($snapshot) ? 'failed' : 'completed',
							'object_type' => 'scan',
							'object_label' => 'Content audit',
							'context' => [
								'processed' => $processed,
								'score' => $results['score'],
								'findings' => count($results['findings']),
								'complete' => !empty($results['complete']),
							],
						],
					);
				}
			}

			if ('running' === $status['state']) {
				self::schedule_next_batch();
			}

			return $status;
		}

		/** Confirm that the current request still owns the process lease. */

		private static function owns_process_lock(string $lock_token): bool {
			$current_lock = get_option(self::PROCESS_LOCK, []);

			return is_array($current_lock) &&
				hash_equals((string) ($current_lock['token'] ?? ''), $lock_token);
		}

		/** Confirm that the worker still owns both its lease and the running job. */

		private static function worker_can_commit(string $lock_token, string $job_id): bool {
			if ('' === $job_id || !self::owns_process_lock($lock_token)) {
				return false;
			}

			$status = self::get_status();

			return 'running' === ($status['state'] ?? '') &&
				hash_equals((string) ($status['jobId'] ?? ''), $job_id);
		}

		/**
		 * Stop continuation after a critical audit-state write fails.
		 *
		 * The immutable snapshot transaction, when already committed, remains valid.
		 * Mutable state is sealed as partial so a retry cannot silently skip or
		 * duplicate a processed content item.
		 */

		private static function fail_running_audit_persistence(
			array $status,
			array $results,
			string $reason = 'persistence_failure',
			string $message = '',
		): array {
			delete_option(self::JOB_OPTION);
			$finished_at = current_time('mysql');
			$results['finishedAt'] = $finished_at;
			$results['complete'] = false;
			$results['truncated'] = true;
			$results['truncationReason'] = sanitize_key($reason);
			$results['counts'] = self::count_findings((array) ($results['findings'] ?? []));
			$results['score'] = self::calculate_score($results);

			$status['state'] = 'failed';
			$status['finishedAt'] = $finished_at;
			$status['complete'] = false;
			$status['truncated'] = true;
			$status['score'] = $results['score'];
			$status['counts'] = $results['counts'];
			$status['error'] = WPHAVE_Security_Redactor::error_text(
				$message ?:
				__('The Content Audit could not persist its processing state.', 'wphave'),
			);

			self::store_option(self::RESULTS_OPTION, $results);
			self::set_status($status);

			return $status;
		}

		/**
		 * Ensure one near-term server-side continuation exists.
		 */

		private static function schedule_next_batch(): bool {
			$status = get_option(self::STATUS_OPTION, []);
			$job = get_option(self::JOB_OPTION, []);
			$status_job_id = is_array($status) ? (string) ($status['jobId'] ?? '') : '';
			$job_id = is_array($job) ? (string) ($job['id'] ?? '') : '';

			if (
				'running' !== ($status['state'] ?? '') ||
				'' === $status_job_id ||
				'' === $job_id ||
				!hash_equals($status_job_id, $job_id)
			) {
				return false;
			}

			return WPHAVE_Background_Job_Scheduler::ensure_continuation(self::PROCESS_HOOK, [], 1);
		}

		/**
		 * Return default issue counters.
		 *
		 * @return array
		 */

		protected static function empty_counts(): array {
			return [
				'critical' => 0,
				'warning' => 0,
				'info' => 0,
				'links' => 0,
				'seo' => 0,
				'security' => 0,
				'media' => 0,
				'quality' => 0,
				'performance' => 0,
				'privacy' => 0,
				'schema' => 0,
			];
		}

		/**
		 * Load current audit status.
		 *
		 * @return array
		 */

		protected static function get_status(): array {
			$status = get_option(self::STATUS_OPTION, []);
			$status = wp_parse_args(is_array($status) ? $status : [], [
				'state' => 'idle',
				'jobId' => '',
				'startedAt' => '',
				'finishedAt' => '',
				'processed' => 0,
				'total' => 0,
				'score' => 0,
				'checkExternalLinks' => false,
				'counts' => self::empty_counts(),
				'heartbeatAt' => 0,
				'complete' => false,
				'truncated' => false,
				'coverage' => [],
			]);

			$heartbeat = (int) $status['heartbeatAt'];
			if (
				'running' === $status['state'] &&
				0 === $heartbeat &&
				!empty($status['startedAt'])
			) {
				$heartbeat = (int) strtotime($status['startedAt']);
			}

			if (
				'running' === $status['state'] &&
				$heartbeat > 0 &&
				$heartbeat + self::JOB_TIMEOUT < time()
			) {
				$recovery_token = WPHAVE_Background_Job_Lock::acquire(
					self::PROCESS_LOCK,
					self::PROCESS_LOCK_TIMEOUT,
				);
				if (!$recovery_token) {
					return $status;
				}

				try {
					// CONCURRENCY INVARIANT: Timeout recovery owns the process lease and
					// revalidates the heartbeat before mutating job or result state.
					$latest = get_option(self::STATUS_OPTION, []);
					$latest_heartbeat = is_array($latest) ? absint($latest['heartbeatAt'] ?? 0) : 0;
					if ($latest_heartbeat > $heartbeat) {
						return self::get_status();
					}

					$status['state'] = 'failed';
					$status['finishedAt'] = current_time('mysql');
					$status['error'] = __(
						'The content audit stopped responding and can be restarted.',
						'wphave',
					);
					$results_stored = self::finalize_interrupted_results(
						'timeout',
						$status['finishedAt'],
					);
					$status_stored = self::set_status($status);
					delete_option(self::JOB_OPTION);
					wp_clear_scheduled_hook(self::PROCESS_HOOK);

					if (!$results_stored || !$status_stored) {
						$status['error'] = __(
							'The content audit timed out and its final partial state could not be stored.',
							'wphave',
						);
					}
				} finally {
					WPHAVE_Background_Job_Lock::release(self::PROCESS_LOCK, $recovery_token);
				}
			}

			return $status;
		}

		/**
		 * Seal the latest mutable result after cancellation or timeout.
		 *
		 * Interrupted runs are intentionally not written to immutable history, but
		 * their bounded partial diagnostics remain available to the current user.
		 */

		private static function finalize_interrupted_results(
			string $reason,
			string $finished_at,
		): bool {
			$results = self::get_results();
			$results['finishedAt'] = $finished_at;
			$results['complete'] = false;
			$results['truncated'] = true;
			$results['truncationReason'] = sanitize_key($reason);
			$results['counts'] = self::count_findings((array) ($results['findings'] ?? []));
			$results['score'] = self::calculate_score($results);

			return self::store_option(self::RESULTS_OPTION, $results);
		}

		/**
		 * Persist current audit status.
		 *
		 * @param array $status Status payload.
		 * @return bool Whether the status was stored or already matched.
		 */

		protected static function set_status(array $status): bool {
			return self::store_option(self::STATUS_OPTION, $status);
		}

		/**
		 * Store a non-autoloaded option and distinguish an unchanged value from failure.
		 *
		 * WordPress returns false both for a failed update and for an identical value.
		 * Critical audit state therefore verifies the persisted value before proceeding.
		 */

		private static function store_option(string $option, $value): bool {
			if (update_option($option, $value, false)) {
				return true;
			}

			return get_option($option, null) === $value;
		}

		/**
		 * Load latest audit results.
		 *
		 * @return array
		 */

		protected static function get_results(): array {
			$results = get_option(self::RESULTS_OPTION, []);

			$results = wp_parse_args(is_array($results) ? $results : [], [
				'startedAt' => '',
				'finishedAt' => '',
				'processed' => 0,
				'total' => 0,
				'score' => 0,
				'counts' => self::empty_counts(),
				'findings' => [],
				'items' => [],
				'scopeHash' => '',
				'rulesetVersion' => '',
				'scoreVersion' => self::SCORE_VERSION,
				'complete' => false,
				'truncated' => false,
				'truncationReason' => '',
				'coverage' => [],
				'errors' => [],
			]);

			if (!empty($results['snapshotId']) && !empty($results['findingsStored'])) {
				$findings = self::load_snapshot_findings(absint($results['snapshotId']));

				if (is_wp_error($findings)) {
					$results['findings'] = [];
					$results['_storageError'] = $findings->get_error_code();
				} else {
					$results['findings'] = $findings;
				}
			}

			return $results;
		}

		/** Hydrate normalized findings for the compact latest-result cache. */

		private static function load_snapshot_findings(int $snapshot_id) {
			global $wpdb;

			if ($snapshot_id < 1) {
				return new WP_Error(
					'wphave_content_audit_invalid_snapshot',
					__('The stored Content Audit snapshot is invalid.', 'wphave'),
				);
			}

			if (!WPHAVE_Content_Audit_Schema::validate()) {
				return new WP_Error(
					'wphave_content_audit_storage_unavailable',
					__('The Content Audit storage schema is unavailable.', 'wphave'),
				);
			}

			$table = $wpdb->prefix . self::FINDINGS_TABLE;
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT * FROM {$table} WHERE snapshot_id = %d ORDER BY priority_score DESC,id ASC",
					$snapshot_id,
				),
				ARRAY_A,
			);

			if (null === $rows && '' !== (string) $wpdb->last_error) {
				return new WP_Error(
					'wphave_content_audit_findings_read_failed',
					__('The stored Content Audit findings could not be loaded.', 'wphave'),
				);
			}

			return array_map(
				static function (array $row): array {
					$evidence = json_decode((string) $row['evidence'], true) ?: [];

					return [
						'id' => (string) $row['fingerprint'],
						'fingerprint' => (string) $row['fingerprint'],
						'category' => (string) $row['category'],
						'severity' => (string) $row['severity'],
						'code' => (string) $row['finding_code'],
						'ruleId' => (string) $row['rule_id'],
						'ruleVersion' => (string) $row['rule_version'],
						'source' => (string) $row['source'],
						'title' => (string) $row['title'],
						'description' => (string) $row['description'],
						'postId' => absint($row['post_id']),
						'postType' => (string) $row['post_type'],
						'postTitle' => (string) $row['post_title'],
						'postUrl' => (string) $row['post_url'],
						'editUrl' => (string) $row['edit_url'],
						'url' => (string) $row['target_url'],
						'evidence' => $evidence,
						'occurrenceCount' => max(1, absint($evidence['occurrenceCount'] ?? 1)),
						'priorityScore' => absint($row['priority_score']),
						'analyticsViews' => absint($row['analytics_views']),
						'analyticsConversions' => absint($row['analytics_conversions']),
					];
				},
				is_array($rows) ? $rows : [],
			);
		}

		/**
		 * Discover public post-like content that should be audited.
		 *
		 * A public frontend contract is authoritative here. `show_ui` and
		 * `publicly_queryable` are deliberately not required: WordPress pages are
		 * public even though the built-in registration does not mark them as
		 * publicly queryable, while headless and externally managed post types can
		 * still publish content that visitors and search engines consume.
		 *
		 * @param int $limit Max items.
		 * @return array
		 */

		protected static function discover_content_items(int $limit): array {
			$post_types = get_post_types(
				[
					'public' => true,
				],
				'names',
			);
			unset($post_types['attachment']);

			/**
			 * Filters the public post types included in a Content Audit.
			 *
			 * Integrations may remove machine-generated public content or add a
			 * deliberately non-public type. Values are normalized against registered
			 * post types before the query is executed.
			 *
			 * @param string[] $post_types Public post type names.
			 */

			$post_types = apply_filters(
				'wphave_content_audit_post_types',
				array_values($post_types),
			);
			$post_types = array_values(
				array_unique(
					array_filter(
						array_map('sanitize_key', is_array($post_types) ? $post_types : []),
						static fn(string $post_type): bool => 'attachment' !== $post_type &&
							post_type_exists($post_type),
					),
				),
			);
			if (empty($post_types)) {
				return [
					'items' => [],
					'total' => 0,
					'postTypes' => [],
					'truncated' => false,
				];
			}

			$query = new WP_Query([
				'post_type' => $post_types,
				'post_status' => 'publish',
				'posts_per_page' => $limit,
				'orderby' => 'modified',
				'order' => 'DESC',
				'no_found_rows' => false,
				'update_post_meta_cache' => true,
				'update_post_term_cache' => false,
			]);

			$items = array_map(static function (WP_Post $post) {
				return [
					'id' => (int) $post->ID,
					'type' => $post->post_type,
					'title' => get_the_title($post),
					'url' => get_permalink($post),
					'editUrl' => get_edit_post_link($post->ID, 'raw'),
				];
			}, $query->posts);

			return [
				'items' => $items,
				'total' => absint($query->found_posts),
				'postTypes' => $post_types,
				'truncated' => absint($query->found_posts) > count($items),
			];
		}

		/**
		 * Audit one content item.
		 *
		 * @param array $item Content item descriptor.
		 * @param array $job Current audit job.
		 * @return array Audit result.
		 */

		protected static function audit_content_item(array $item, array &$job): array {
			$post = get_post(absint($item['id'] ?? 0));

			if (!($post instanceof WP_Post)) {
				return [
					'item' => $item,
					'findings' => [],
				];
			}

			$content = (string) $post->post_content;
			$text = trim(wp_strip_all_tags(strip_shortcodes($content)));
			$seo = self::seo_values($post);
			$assets = self::extract_assets($content);
			$context = [
				'post' => $post,
				'item' => $item,
				'content' => $content,
				'text' => $text,
				'seo' => $seo,
				'assets' => $assets,
			];
			$rule_result = WPHAVE_Content_Audit_Rule_Registry::instance()->execute(
				'item',
				$context,
				$job,
			);
			$findings = self::normalize_findings($rule_result['findings']);

			return [
				'item' => [
					'id' => (int) $post->ID,
					'type' => $post->post_type,
					'title' => get_the_title($post),
					'url' => get_permalink($post),
					'editUrl' => get_edit_post_link($post->ID, 'raw'),
					'wordCount' => self::count_words($text),
					'links' => count($assets['links']),
					'images' => count($assets['images']),
					'issues' => count($findings),
					'analysis' => [
						'contentHash' =>
							self::count_words($text) >= 30
								? hash('sha256', mb_strtolower(preg_replace('/\s+/u', ' ', $text)))
								: '',
						'seoTitle' => $seo['title'] ?: get_the_title($post),
						'seoDescription' => $seo['description'],
						'links' => array_values(
							array_unique(
								array_filter(
									array_map(
										static fn(string $url): string => self::resolve_url(
											$url,
											(string) $item['url'],
										),
										$assets['links'],
									),
								),
							),
						),
					],
				],
				'findings' => $findings,
				'errors' => $rule_result['errors'],
			];
		}

		/**
		 * Resolve SEO values from common WPHAVE and WordPress metadata.
		 *
		 * @param WP_Post $post Post object.
		 * @return array
		 */

		protected static function seo_values(WP_Post $post): array {
			$title_keys = [
				'wphave_seo_title',
				'_wphave_seo_title',
				'_yoast_wpseo_title',
				'rank_math_title',
				'_aioseo_title',
			];
			$description_keys = [
				'wphave_seo_description',
				'_wphave_seo_description',
				'_yoast_wpseo_metadesc',
				'rank_math_description',
				'_aioseo_description',
			];
			$noindex_keys = [
				'wphave_seo_noindex',
				'_wphave_seo_noindex',
				'_yoast_wpseo_meta-robots-noindex',
				'rank_math_robots',
			];

			return [
				'title' => self::first_meta_value($post->ID, $title_keys),
				'description' => self::first_meta_value($post->ID, $description_keys),
				'noindex' => self::has_noindex_meta($post->ID, $noindex_keys),
			];
		}

		/**
		 * Return the first non-empty post meta value.
		 *
		 * @param int $post_id Post ID.
		 * @param array $keys Meta keys.
		 * @return string
		 */

		protected static function first_meta_value(int $post_id, array $keys): string {
			foreach ($keys as $key) {
				$value = get_post_meta($post_id, $key, true);

				if (is_array($value)) {
					$value = implode(', ', array_filter(array_map('sanitize_text_field', $value)));
				}

				if (trim((string) $value) !== '') {
					return trim(wp_strip_all_tags((string) $value));
				}
			}

			return '';
		}

		/**
		 * Check whether known SEO metadata marks the post as noindex.
		 *
		 * @param int $post_id Post ID.
		 * @param array $keys Meta keys.
		 * @return bool
		 */

		protected static function has_noindex_meta(int $post_id, array $keys): bool {
			foreach ($keys as $key) {
				$value = get_post_meta($post_id, $key, true);

				if (is_array($value) && in_array('noindex', $value, true)) {
					return true;
				}

				if (in_array((string) $value, ['1', 'noindex'], true)) {
					return true;
				}
			}

			return false;
		}

		/**
		 * Extract links and media-like sources from raw post content.
		 *
		 * @param string $content Post content.
		 * @return array
		 */

		protected static function extract_assets(string $content): array {
			$assets = [
				'links' => [],
				'images' => [],
				'sources' => [],
				'iframes' => [],
				'scripts' => [],
				'headings' => [],
				'anchors' => [],
			];

			if ($content === '') {
				return $assets;
			}

			if (
				preg_match_all(
					'/<a\b[^>]*href=[\'"]([^\'"]+)[\'"][^>]*>/i',
					$content,
					$matches,
					PREG_SET_ORDER,
				)
			) {
				foreach ($matches as $match) {
					$assets['links'][] = esc_url_raw(html_entity_decode($match[1]));
				}
			}

			$assets['linkDetails'] = [];
			if (
				preg_match_all(
					'/<a\b[^>]*href=[\'"]([^\'"]+)[\'"][^>]*>(.*?)<\/a>/is',
					$content,
					$matches,
					PREG_SET_ORDER,
				)
			) {
				foreach ($matches as $match) {
					$assets['linkDetails'][] = [
						'url' => esc_url_raw(html_entity_decode($match[1])),
						'text' => trim(wp_strip_all_tags($match[2])),
					];
				}
			}

			if (
				preg_match_all(
					'/<img\b[^>]*src=[\'"]([^\'"]+)[\'"][^>]*>/i',
					$content,
					$matches,
					PREG_SET_ORDER,
				)
			) {
				foreach ($matches as $match) {
					$assets['images'][] = [
						'src' => esc_url_raw(html_entity_decode($match[1])),
						'alt' => self::extract_attribute($match[0], 'alt'),
						'hasAlt' => self::has_attribute($match[0], 'alt'),
						'loading' => self::extract_attribute($match[0], 'loading'),
						'width' => absint(self::extract_attribute($match[0], 'width')),
						'height' => absint(self::extract_attribute($match[0], 'height')),
					];
					$assets['sources'][] = esc_url_raw(html_entity_decode($match[1]));
				}
			}

			foreach (
				[
					'iframe' => 'iframes',
					'script' => 'scripts',
					'source' => 'sources',
					'video' => 'sources',
					'audio' => 'sources',
				]
				as $tag => $bucket
			) {
				if (
					preg_match_all(
						'/<' . $tag . '\b[^>]*(?:src|data-src)=[\'"]([^\'"]+)[\'"][^>]*>/i',
						$content,
						$matches,
						PREG_SET_ORDER,
					)
				) {
					foreach ($matches as $match) {
						$assets[$bucket][] = esc_url_raw(html_entity_decode($match[1]));
					}
				}
			}

			if (
				preg_match_all(
					'/<h([1-6])\b[^>]*>(.*?)<\/h\1>/is',
					$content,
					$matches,
					PREG_SET_ORDER,
				)
			) {
				foreach ($matches as $match) {
					$assets['headings'][] = [
						'level' => absint($match[1]),
						'text' => trim(wp_strip_all_tags($match[2])),
					];
				}
			}

			if (preg_match_all('/\s(?:id|name)=[\'\"]([^\'\"]+)[\'\"]/i', $content, $matches)) {
				$assets['anchors'] = array_values(
					array_filter(array_map('sanitize_title', $matches[1])),
				);
			}

			return $assets;
		}

		/**
		 * Extract one HTML attribute from a matched tag.
		 *
		 * @param string $tag HTML tag.
		 * @param string $attribute Attribute name.
		 * @return string
		 */

		protected static function extract_attribute(string $tag, string $attribute): string {
			if (
				preg_match(
					'/\s' . preg_quote($attribute, '/') . '=[\'"]([^\'"]*)[\'"]/i',
					$tag,
					$match,
				)
			) {
				return html_entity_decode($match[1]);
			}

			return '';
		}

		/**
		 * Check whether an HTML tag explicitly contains an attribute.
		 *
		 * Empty alt text is valid for decorative images, so presence and value
		 * must remain separate signals.
		 *
		 * @param string $tag HTML tag.
		 * @param string $attribute Attribute name.
		 * @return bool
		 */

		protected static function has_attribute(string $tag, string $attribute): bool {
			return (bool) preg_match(
				'/\s' . preg_quote($attribute, '/') . '(?:\s*=|\s|\/?>)/i',
				$tag,
			);
		}

		/**
		 * Count Unicode words consistently for all site languages.
		 *
		 * @param string $text Plain text.
		 * @return int
		 */

		protected static function count_words(string $text): int {
			$matches = [];
			$result = preg_match_all(
				"/[\\p{L}\\p{N}]+(?:[’'\x{2010}-\x{2015}-][\\p{L}\\p{N}]+)*/u",
				$text,
				$matches,
			);

			return $result === false ? 0 : $result;
		}

		/**
		 * Audit SEO basics.
		 *
		 * @param WP_Post $post Post object.
		 * @param array $item Content item descriptor.
		 * @param array $seo SEO values.
		 * @param string $content Raw content.
		 * @param string $text Plain text.
		 * @return array
		 */

		protected static function audit_seo(
			WP_Post $post,
			array $item,
			array $seo,
			string $content,
			string $text,
		): array {
			$findings = [];
			$title = $seo['title'] ?: get_the_title($post);
			$title_length = mb_strlen($title);
			$description_length = mb_strlen($seo['description']);
			$h1_count = preg_match_all('/<h1(?:\s|>)/i', $content);

			if ($seo['title'] === '') {
				$findings[] = self::finding(
					'seo',
					'warning',
					'missing_seo_title',
					__('Missing SEO title', 'wphave'),
					__(
						'Add a dedicated SEO title so search results can be controlled intentionally.',
						'wphave',
					),
					$item,
				);
			} elseif ($title_length < 25 || $title_length > 65) {
				$findings[] = self::finding(
					'seo',
					'info',
					'seo_title_length',
					__('SEO title length can be improved', 'wphave'),
					__(
						'Keep SEO titles descriptive without becoming too long for search result snippets.',
						'wphave',
					),
					$item,
				);
			}

			if ($seo['description'] === '') {
				$findings[] = self::finding(
					'seo',
					'warning',
					'missing_meta_description',
					__('Missing meta description', 'wphave'),
					__(
						'Add a meta description to make the page clearer in search and sharing previews.',
						'wphave',
					),
					$item,
				);
			} elseif ($description_length < 70 || $description_length > 170) {
				$findings[] = self::finding(
					'seo',
					'info',
					'meta_description_length',
					__('Meta description length can be improved', 'wphave'),
					__(
						'A useful meta description is usually concise but specific enough to describe the page.',
						'wphave',
					),
					$item,
				);
			}

			if ($h1_count === 0 && trim($text) !== '') {
				$findings[] = self::finding(
					'seo',
					'warning',
					'missing_h1',
					__('Missing H1 heading', 'wphave'),
					__(
						'A visible primary heading helps visitors and search engines understand the page.',
						'wphave',
					),
					$item,
				);
			} elseif ($h1_count > 1) {
				$findings[] = self::finding(
					'seo',
					'warning',
					'multiple_h1',
					__('Multiple H1 headings', 'wphave'),
					__(
						'Use one primary H1 and structure subsections with lower heading levels.',
						'wphave',
					),
					$item,
				);
			}

			if ($seo['noindex']) {
				$findings[] = self::finding(
					'seo',
					'info',
					'noindex_enabled',
					__('Noindex is enabled', 'wphave'),
					__(
						'Confirm that this public content should intentionally stay out of search results.',
						'wphave',
					),
					$item,
				);
			}

			return $findings;
		}

		/**
		 * Audit internal and external links.
		 *
		 * @param array $item Content item descriptor.
		 * @param array $links Link URLs.
		 * @param array $job Current job.
		 * @return array
		 */

		protected static function audit_links(array $item, array $links, array &$job): array {
			$findings = [];
			$unique_links = array_values(array_unique(array_filter($links)));

			if (count($unique_links) > self::MAX_LINKS_PER_ITEM) {
				$job['linkChecksTruncated'] = true;
				$unique_links = array_slice($unique_links, 0, self::MAX_LINKS_PER_ITEM);
			}

			foreach ($unique_links as $source_url) {
				$url = self::resolve_url($source_url, (string) ($item['url'] ?? home_url('/')));

				if (self::is_ignored_url($url)) {
					continue;
				}

				if (self::is_external_url($url) && empty($job['checkExternalLinks'])) {
					continue;
				}

				$status = self::check_url_status($url, $job);

				if ($status['state'] === 'broken') {
					$findings[] = self::finding(
						'links',
						self::is_external_url($url) ? 'warning' : 'critical',
						'broken_link' /* translators: %s or %d: contextual value; 1, 2, or 3: ordered contextual values. */,
						__('Broken link', 'wphave'),
						sprintf(
							__('The linked URL could not be reached: %s', 'wphave'),
							esc_url_raw($url),
						),
						$item,
						['url' => esc_url_raw($url), 'statusCode' => $status['code']],
					);
				} elseif ($status['state'] === 'redirect') {
					$findings[] = self::finding(
						'links',
						'info',
						'redirect_link' /* translators: %s or %d: contextual value; 1, 2, or 3: ordered contextual values. */,
						__('Link redirects', 'wphave'),
						sprintf(
							__(
								'The URL redirects before reaching its final destination: %s',
								'wphave',
							),
							esc_url_raw($url),
						),
						$item,
						['url' => esc_url_raw($url), 'statusCode' => $status['code']],
					);
				} elseif (
					in_array($status['state'], ['protected', 'temporary', 'unavailable'], true)
				) {
					$findings[] = self::finding(
						'links',
						'info',
						'link_unverified',
						__('Link could not be verified', 'wphave'),
						sprintf(
							__(
								'The URL did not return a definitive availability signal and is not treated as broken: %s',
								'wphave',
							),
							esc_url_raw($url),
						),
						$item,
						[
							'url' => esc_url_raw($url),
							'statusCode' => $status['code'],
							'failureCode' => $status['failureCode'] ?? '',
						],
					);
				}
			}

			return $findings;
		}

		/**
		 * Audit images and embeds.
		 *
		 * @param array $item Content item descriptor.
		 * @param array $assets Extracted assets.
		 * @return array
		 */

		protected static function audit_media(array $item, array $assets): array {
			$findings = [];

			foreach ($assets['images'] as $image) {
				if (empty($image['hasAlt'])) {
					$findings[] = self::finding(
						'media',
						'warning',
						'missing_image_alt',
						__('Image is missing alt text', 'wphave'),
						__(
							'Add descriptive alt text for meaningful images or mark decorative images intentionally.',
							'wphave',
						),
						$item,
						['url' => esc_url_raw($image['src'])],
					);
				} elseif (trim((string) $image['alt']) === '') {
					$findings[] = self::finding(
						'media',
						'info',
						'empty_image_alt',
						__('Image has empty alt text', 'wphave'),
						__(
							'Confirm that the image is decorative. Meaningful images need a concise text alternative.',
							'wphave',
						),
						$item,
						['url' => esc_url_raw($image['src'])],
					);
				}

				if (empty($image['width']) || empty($image['height'])) {
					$findings[] = self::finding(
						'performance',
						'info',
						'missing_image_dimensions',
						__('Image dimensions are not declared', 'wphave'),
						__(
							'Declare image width and height to reserve layout space and reduce visual shifts.',
							'wphave',
						),
						$item,
						['url' => esc_url_raw($image['src'])],
					);
				}
			}

			foreach ($assets['iframes'] as $iframe) {
				$findings[] = self::finding(
					'performance',
					'info',
					'embedded_iframe',
					__('Embedded iframe detected', 'wphave'),
					__(
						'Review embedded iframes for privacy, loading performance and fallback content.',
						'wphave',
					),
					$item,
					['url' => esc_url_raw($iframe)],
				);
			}

			return $findings;
		}

		/**
		 * Audit content quality signals.
		 *
		 * @param WP_Post $post Post object.
		 * @param array $item Content item descriptor.
		 * @param string $content Raw content.
		 * @param string $text Plain text.
		 * @param array $assets Extracted assets.
		 * @return array
		 */

		protected static function audit_quality(
			WP_Post $post,
			array $item,
			string $content,
			string $text,
			array $assets,
		): array {
			$findings = [];
			$word_count = self::count_words($text);

			if ($word_count > 0 && $word_count < 80) {
				$findings[] = self::finding(
					'quality',
					'info',
					'thin_content',
					__('Thin content', 'wphave'),
					__(
						'The page has very little readable text. Confirm that this is intentional.',
						'wphave',
					),
					$item,
				);
			}

			if (strtotime($post->post_modified_gmt) < strtotime('-18 months')) {
				$findings[] = self::finding(
					'quality',
					'info',
					'stale_content',
					__('Content has not been updated recently', 'wphave'),
					__(
						'Review older content for outdated claims, links and screenshots.',
						'wphave',
					),
					$item,
				);
			}

			if (count($assets['links']) > 35) {
				$findings[] = self::finding(
					'quality',
					'info',
					'many_links',
					__('Many links on one page', 'wphave'),
					__(
						'Pages with many links can feel unfocused and should be reviewed for clarity.',
						'wphave',
					),
					$item,
				);
			}

			if (trim($content) === '') {
				$findings[] = self::finding(
					'quality',
					'warning',
					'empty_content',
					__('Empty content', 'wphave'),
					__('This public content item has no body content.', 'wphave'),
					$item,
				);
			}

			return $findings;
		}

		/**
		 * Audit HTTPS and mixed-content risks.
		 *
		 * @param array $item Content item descriptor.
		 * @param array $assets Extracted assets.
		 * @return array
		 */

		protected static function audit_security(array $item, array $assets): array {
			$findings = [];

			if (!is_ssl()) {
				return $findings;
			}

			foreach (
				array_unique(
					array_filter(
						array_merge(
							$assets['sources'],
							$assets['iframes'],
							$assets['scripts'],
							$assets['links'],
						),
					),
				)
				as $url
			) {
				if (str_starts_with(strtolower($url), 'http://')) {
					$findings[] = self::finding(
						'security',
						'critical',
						'mixed_content_source' /* translators: %s or %d: contextual value; 1, 2, or 3: ordered contextual values. */,
						__('Unsecure source on HTTPS page', 'wphave'),
						sprintf(
							__('Replace the HTTP URL with HTTPS where possible: %s', 'wphave'),
							esc_url_raw($url),
						),
						$item,
						['url' => esc_url_raw($url)],
					);
				}
			}

			return $findings;
		}

		/** Audit structural signals shared conceptually with editor notices. */

		protected static function audit_document_structure(array $item, array $assets): array {
			$findings = [];
			$previous_level = 0;

			foreach ($assets['headings'] as $heading) {
				$level = absint($heading['level'] ?? 0);
				if ('' === trim((string) ($heading['text'] ?? ''))) {
					$findings[] = self::finding(
						'quality',
						'warning',
						'empty_heading',
						__('Empty heading', 'wphave'),
						__('Remove the empty heading or add descriptive heading text.', 'wphave'),
						$item,
					);
				}
				if ($previous_level > 0 && $level > $previous_level + 1) {
					$findings[] = self::finding(
						'quality',
						'warning',
						'heading_order',
						__('Heading level is skipped', 'wphave'),
						__(
							'Keep heading levels in a logical hierarchy so the document remains understandable.',
							'wphave',
						),
						$item,
						['evidence' => ['from' => $previous_level, 'to' => $level]],
					);
				}
				$previous_level = $level;
			}

			foreach (array_count_values($assets['anchors'] ?? []) as $anchor => $count) {
				if ($count > 1) {
					$findings[] = self::finding(
						'quality',
						'warning',
						'duplicate_anchor',
						__('Duplicate anchor', 'wphave'),
						sprintf(
							__('The anchor “%s” is used more than once on this page.', 'wphave'),
							$anchor,
						),
						$item,
						['evidence' => ['anchor' => $anchor, 'count' => $count]],
					);
				}
			}

			foreach ($assets['links'] as $url) {
				if (
					str_starts_with($url, '#') &&
					!in_array(sanitize_title(substr($url, 1)), $assets['anchors'] ?? [], true)
				) {
					$findings[] = self::finding(
						'links',
						'warning',
						'invalid_anchor_target',
						__('Anchor target is missing', 'wphave'),
						sprintf(
							__('The link target %s does not exist on this page.', 'wphave'),
							$url,
						),
						$item,
						['url' => $url],
					);
				}
			}

			$generic_link_texts = [
				'click here',
				'here',
				'more',
				'read more',
				'hier klicken',
				'hier',
				'mehr',
				'weiterlesen',
			];
			foreach ($assets['linkDetails'] ?? [] as $link) {
				if (
					in_array(
						mb_strtolower(trim((string) ($link['text'] ?? ''))),
						$generic_link_texts,
						true,
					)
				) {
					$findings[] = self::finding(
						'quality',
						'info',
						'generic_link_text',
						__('Link text lacks context', 'wphave'),
						__(
							'Use descriptive link text that explains its destination outside the surrounding paragraph.',
							'wphave',
						),
						$item,
						['url' => esc_url_raw($link['url'] ?? '')],
					);
				}
			}

			return $findings;
		}

		/** Validate real frontend Schema output through the shared Schema service. */

		protected static function audit_rendered_schema(WP_Post $post, array $item): array {
			if (!class_exists('WPHAVE_Schema') || !class_exists('WPHAVE_Schema_REST_Controller')) {
				return [];
			}

			$schema = WPHAVE_Schema::instance();
			if (
				!$schema->is_enabled() ||
				'1' === (string) get_post_meta($post->ID, 'wphave_schema_disabled', true)
			) {
				return [];
			}

			$inspection = (new WPHAVE_Schema_REST_Controller($schema))->inspect_post($post->ID);
			if (is_wp_error($inspection)) {
				return [
					self::finding(
						'schema',
						'warning',
						'schema_output_unverified',
						__('Structured data output could not be verified', 'wphave'),
						WPHAVE_Security_Redactor::error_text($inspection->get_error_message()),
						$item,
						['evidence' => ['errorCode' => $inspection->get_error_code()]],
					),
				];
			}

			$findings = [];
			foreach ((array) ($inspection['errors'] ?? []) as $error) {
				$findings[] = self::finding(
					'schema',
					'critical',
					'schema_' . sanitize_key($error['code'] ?? 'validation'),
					__('Structured data validation error', 'wphave'),
					sanitize_text_field($error['message'] ?? ''),
					$item,
					['evidence' => $error],
				);
			}
			foreach ((array) ($inspection['warnings'] ?? []) as $warning) {
				$findings[] = self::finding(
					'schema',
					'warning',
					'schema_' . sanitize_key($warning['code'] ?? 'recommendation'),
					__('Structured data recommendation', 'wphave'),
					sanitize_text_field($warning['message'] ?? ''),
					$item,
					['evidence' => $warning],
				);
			}

			return $findings;
		}

		/** Audit relationships that only become visible across a complete inventory. */

		protected static function audit_site_content_graph(array $context): array {
			if (empty($context['coverage']['complete'])) {
				return [];
			}

			$items = is_array($context['items'] ?? null) ? $context['items'] : [];
			$findings = [];
			$groups = [
				'duplicate_seo_title' => [
					'field' => 'seoTitle',
					'category' => 'seo',
					'severity' => 'warning',
					'title' => __('Duplicate SEO title', 'wphave'),
					'description' => __(
						'Use a distinct SEO title so this content can be differentiated in search results.',
						'wphave',
					),
				],
				'duplicate_meta_description' => [
					'field' => 'seoDescription',
					'category' => 'seo',
					'severity' => 'info',
					'title' => __('Duplicate meta description', 'wphave'),
					'description' => __(
						'Use a distinct description that accurately summarizes this content.',
						'wphave',
					),
				],
				'duplicate_content' => [
					'field' => 'contentHash',
					'category' => 'quality',
					'severity' => 'warning',
					'title' => __('Duplicate content', 'wphave'),
					'description' => __(
						'This readable content is identical to another published item.',
						'wphave',
					),
				],
			];

			foreach ($groups as $code => $definition) {
				$values = [];
				foreach ($items as $item) {
					$value = trim((string) ($item['analysis'][$definition['field']] ?? ''));
					if ('' !== $value) {
						$values[mb_strtolower($value)][] = $item;
					}
				}
				foreach ($values as $duplicates) {
					if (count($duplicates) < 2) {
						continue;
					}
					foreach ($duplicates as $item) {
						$findings[] = self::finding(
							$definition['category'],
							$definition['severity'],
							$code,
							$definition['title'],
							$definition['description'],
							$item,
							[
								'evidence' => [
									'matchingPostIds' => array_values(
										array_diff(array_column($duplicates, 'id'), [$item['id']]),
									),
								],
							],
						);
					}
				}
			}

			$known_urls = [];
			$incoming = [];
			foreach ($items as $item) {
				$key = self::normalize_content_url($item['url'] ?? '');
				if ('' !== $key) {
					$known_urls[$key] = $item;
					$incoming[$key] = 0;
				}
			}
			foreach ($items as $item) {
				foreach ($item['analysis']['links'] ?? [] as $url) {
					$key = self::normalize_content_url($url);
					if (
						isset($incoming[$key]) &&
						$key !== self::normalize_content_url($item['url'] ?? '')
					) {
						$incoming[$key]++;
					}
				}
			}
			$front_page_url = self::normalize_content_url(
				get_permalink(absint(get_option('page_on_front'))) ?: home_url('/'),
			);
			foreach ($incoming as $url => $count) {
				if (0 === $count && $url !== $front_page_url) {
					$findings[] = self::finding(
						'links',
						'warning',
						'orphaned_content',
						__('Content has no incoming internal links', 'wphave'),
						__(
							'Add a relevant internal link so visitors and crawlers can discover this content.',
							'wphave',
						),
						$known_urls[$url],
					);
				}
			}

			return $findings;
		}

		/** Import actionable signals from the existing Privacy Scanner workflow. */

		protected static function audit_privacy_alignment(): array {
			if (!class_exists('WPHAVE_Privacy_Scanner')) {
				return [];
			}

			$results = WPHAVE_Privacy_Scanner::get_results();
			$findings = [];
			$site_item = [
				'id' => 0,
				'type' => 'site',
				'title' => get_bloginfo('name'),
				'url' => home_url('/'),
				'editUrl' => '',
			];

			foreach ((array) ($results['services'] ?? []) as $service) {
				$resource_type = sanitize_key($service['resourceType'] ?? 'consent');
				$category = sanitize_key($service['category'] ?? '');
				if (
					'sensitive' !== $resource_type &&
					('consent' !== $resource_type || '' !== $category)
				) {
					continue;
				}

				$domain = sanitize_text_field($service['domain'] ?? '');
				$findings[] = self::finding(
					'privacy',
					'sensitive' === $resource_type ? 'critical' : 'warning',
					'sensitive' === $resource_type
						? 'sensitive_external_service'
						: 'uncategorized_consent_service',
					'sensitive' === $resource_type
						? __('Sensitive external service detected', 'wphave')
						: __('Consent service is not categorized', 'wphave'),
					sprintf(
						__(
							'Review the privacy classification and consent behavior for %s in the Privacy Scanner.',
							'wphave',
						),
						$domain,
					),
					$site_item,
					[
						'url' => isset($service['urls'][0]) ? esc_url_raw($service['urls'][0]) : '',
						'evidence' => [
							'domain' => $domain,
							'resourceType' => $resource_type,
							'pages' => array_slice((array) ($service['pages'] ?? []), 0, 10),
						],
						'remediation' => [
							'screen' => 'privacy-scan',
						],
					],
				);
			}

			return $findings;
		}

		private static function normalize_content_url(string $url): string {
			$parts = wp_parse_url($url);
			if (!is_array($parts) || empty($parts['host'])) {
				return '';
			}

			return strtolower($parts['host']) . '/' . trim((string) ($parts['path'] ?? ''), '/');
		}

		/**
		 * Check one URL and cache the result for this job.
		 *
		 * @param string $url URL to check.
		 * @param array $job Current job.
		 * @return array
		 */

		protected static function check_url_status(string $url, array &$job): array {
			$url = esc_url_raw($url);
			$cache_key = hash('sha256', $url);

			if (isset($job['linkCache'][$cache_key])) {
				return $job['linkCache'][$cache_key];
			}

			$persistent = self::get_cached_url_status($cache_key);
			if (null !== $persistent) {
				$job['linkCache'][$cache_key] = $persistent;

				return $persistent;
			}

			if (!self::is_checkable_url($url)) {
				$result = ['state' => 'ignored', 'code' => 0];
				$job['linkCache'][$cache_key] = $result;
				return $result;
			}

			$request_args = [
				'timeout' => self::REQUEST_TIMEOUT,
				'redirection' => 0,
				'reject_unsafe_urls' => true,
				'sslverify' => true,
				'limit_response_size' => 1024,
				'user-agent' =>
					'WPHAVE Content Audit/' . (defined('WPHAVE_VERSION') ? WPHAVE_VERSION : '1.0'),
			];
			$response = wp_safe_remote_head($url, $request_args);
			$head_code = is_wp_error($response)
				? 0
				: (int) wp_remote_retrieve_response_code($response);

			if (is_wp_error($response) || in_array($head_code, [403, 405, 501], true)) {
				$response = wp_safe_remote_get($url, $request_args);
			}

			if (is_wp_error($response)) {
				$result = [
					'state' => 'unavailable',
					'code' => 0,
					'failureCode' => sanitize_key($response->get_error_code()),
				];
			} else {
				$code = (int) wp_remote_retrieve_response_code($response);
				if ($code >= 200 && $code < 300) {
					$state = 'ok';
				} elseif ($code >= 300 && $code < 400) {
					$state = 'redirect';
				} elseif (in_array($code, [401, 403], true)) {
					$state = 'protected';
				} elseif (in_array($code, [408, 425, 429], true) || $code >= 500 || 0 === $code) {
					$state = 'temporary';
				} else {
					$state = 'broken';
				}

				$result = [
					'state' => $state,
					'code' => $code,
					'failureCode' => '',
				];
			}

			$job['linkCache'][$cache_key] = $result;
			self::cache_url_status($cache_key, $url, $result);

			return $result;
		}

		/** Return a non-expired persistent URL observation. */

		private static function get_cached_url_status(string $cache_key): ?array {
			global $wpdb;

			if (!WPHAVE_Content_Audit_Schema::validate()) {
				return null;
			}

			$table = $wpdb->prefix . self::URL_CACHE_TABLE;
			$row = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT state,status_code,failure_code FROM {$table} WHERE url_hash = %s AND expires_at > %s",
					$cache_key,
					current_time('mysql'),
				),
				ARRAY_A,
			);

			if (!is_array($row)) {
				return null;
			}

			return [
				'state' => sanitize_key($row['state']),
				'code' => absint($row['status_code']),
				'failureCode' => sanitize_key($row['failure_code']),
			];
		}

		/** Persist an URL observation with a state-specific retry window. */

		private static function cache_url_status(
			string $cache_key,
			string $url,
			array $result,
		): void {
			global $wpdb;

			if (!WPHAVE_Content_Audit_Schema::validate()) {
				return;
			}

			$state = sanitize_key($result['state'] ?? 'unavailable');
			$short_lived = in_array($state, ['temporary', 'unavailable'], true);
			$ttl = $short_lived ? HOUR_IN_SECONDS : DAY_IN_SECONDS;
			$table = $wpdb->prefix . self::URL_CACHE_TABLE;
			$existing_failures = absint(
				$wpdb->get_var(
					$wpdb->prepare(
						"SELECT failure_count FROM {$table} WHERE url_hash = %s",
						$cache_key,
					),
				),
			);

			$wpdb->replace($table, [
				'url_hash' => $cache_key,
				'url' => esc_url_raw($url),
				'state' => $state,
				'status_code' => absint($result['code'] ?? 0),
				'failure_code' => sanitize_key($result['failureCode'] ?? ''),
				'checked_at' => current_time('mysql'),
				'expires_at' => wp_date('Y-m-d H:i:s', time() + $ttl),
				'failure_count' => $short_lived ? min(65535, $existing_failures + 1) : 0,
			]);
		}

		/**
		 * Resolve a content URL against the audited page URL.
		 *
		 * @param string $url Extracted URL.
		 * @param string $base_url Audited page URL.
		 * @return string
		 */

		protected static function resolve_url(string $url, string $base_url): string {
			$url = trim(html_entity_decode($url));

			if (self::is_ignored_url($url)) {
				return $url;
			}

			if (str_starts_with($url, '//')) {
				$scheme = wp_parse_url($base_url, PHP_URL_SCHEME) ?: 'https';

				return esc_url_raw($scheme . ':' . $url);
			}

			if (wp_parse_url($url, PHP_URL_SCHEME)) {
				return esc_url_raw($url);
			}

			return esc_url_raw(WP_Http::make_absolute_url($url, $base_url));
		}

		/**
		 * Check if a URL should not be audited.
		 *
		 * @param string $url URL.
		 * @return bool
		 */

		protected static function is_ignored_url(string $url): bool {
			$url = trim($url);

			return $url === '' ||
				str_starts_with($url, '#') ||
				preg_match('/^(mailto|tel|sms|javascript):/i', $url);
		}

		/**
		 * Check if the URL can be requested by the audit.
		 *
		 * @param string $url URL.
		 * @return bool
		 */

		protected static function is_checkable_url(string $url): bool {
			if (!wp_http_validate_url($url)) {
				return false;
			}

			$scheme = wp_parse_url($url, PHP_URL_SCHEME);

			return in_array(strtolower((string) $scheme), ['http', 'https'], true);
		}

		/**
		 * Check if a URL points outside the current site host.
		 *
		 * @param string $url URL.
		 * @return bool
		 */

		protected static function is_external_url(string $url): bool {
			$host = wp_parse_url(home_url(), PHP_URL_HOST);
			$url_host = wp_parse_url($url, PHP_URL_HOST);

			return $url_host && strtolower((string) $url_host) !== strtolower((string) $host);
		}

		/**
		 * Build a normalized finding.
		 *
		 * @param string $category Finding category.
		 * @param string $severity Severity.
		 * @param string $code Stable finding code.
		 * @param string $title Title.
		 * @param string $description Description.
		 * @param array $item Content item.
		 * @param array $extra Extra fields.
		 * @return array
		 */

		protected static function finding(
			string $category,
			string $severity,
			string $code,
			string $title,
			string $description,
			array $item,
			array $extra = [],
		): array {
			$finding = array_merge(
				[
					'id' => hash(
						'sha256',
						implode('|', [
							$category,
							$severity,
							$code,
							$item['id'] ?? '',
							$extra['url'] ?? '',
						]),
					),
					'category' => $category,
					'severity' => $severity,
					'code' => $code,
					'title' => $title,
					'description' => $description,
					'postId' => absint($item['id'] ?? 0),
					'postType' => sanitize_key($item['type'] ?? ''),
					'postTitle' => sanitize_text_field($item['title'] ?? ''),
					'postUrl' => esc_url_raw($item['url'] ?? ''),
					'url' => esc_url_raw($item['url'] ?? ''),
					'editUrl' => esc_url_raw($item['editUrl'] ?? ''),
				],
				$extra,
			);
			$finding['evidence'] = array_merge(
				(array) ($finding['evidence'] ?? []),
				array_diff_key($extra, array_flip(['url', 'evidence'])),
			);

			return $finding;
		}

		/** Return automation configuration and delivery state. */

		public static function rest_get_automation() {
			$authorized = self::require_manage_access();
			if (is_wp_error($authorized)) {
				return $authorized;
			}
			return rest_ensure_response(self::get_automation_status());
		}

		/** Validate and persist automation configuration. */

		public static function rest_update_automation(WP_REST_Request $request) {
			$authorized = self::require_manage_access();
			if (is_wp_error($authorized)) {
				return $authorized;
			}
			$frequency = sanitize_key($request->get_param('frequency') ?: 'weekly');
			$time_window = sanitize_key($request->get_param('timeWindow') ?: 'night');
			$email = sanitize_email($request->get_param('email') ?: '');
			$settings = [
				'enabled' => rest_sanitize_boolean($request->get_param('enabled')),
				'frequency' => in_array($frequency, ['daily', 'weekly', 'monthly'], true)
					? $frequency
					: 'weekly',
				'timeWindow' => in_array(
					$time_window,
					['night', 'morning', 'afternoon', 'evening'],
					true,
				)
					? $time_window
					: 'night',
				'email' => $email,
				'limit' => max(
					1,
					min(
						self::MAX_LIMIT,
						absint($request->get_param('limit')) ?: self::DEFAULT_LIMIT,
					),
				),
				'checkExternalLinks' => rest_sanitize_boolean(
					$request->get_param('checkExternalLinks'),
				),
			];

			if ($request->get_param('email') && !$email) {
				return new WP_Error(
					'wphave_content_audit_invalid_email',
					__('Enter a valid notification email address.', 'wphave'),
					['status' => 400],
				);
			}

			if (!self::store_option(self::AUTOMATION_OPTION, $settings)) {
				return new WP_Error(
					'wphave_content_audit_automation_persistence_failed',
					__('Content Audit automation settings could not be saved.', 'wphave'),
					['status' => 500],
				);
			}

			if (!self::sync_automation_schedule()) {
				return new WP_Error(
					'wphave_content_audit_automation_schedule_failed',
					__(
						'Content Audit automation was saved, but its next run could not be scheduled.',
						'wphave',
					),
					['status' => 500],
				);
			}

			return rest_ensure_response(self::get_automation_status());
		}

		/** Return compact historical snapshots for trend UI. */

		public static function rest_get_history() {
			$authorized = self::require_manage_access();
			if (is_wp_error($authorized)) {
				return $authorized;
			}
			global $wpdb;
			$table = $wpdb->prefix . self::SNAPSHOTS_TABLE;
			if (!WPHAVE_Content_Audit_Schema::validate()) {
				return new WP_Error(
					'wphave_content_audit_schema_unavailable',
					__('The Content Audit storage schema is unavailable.', 'wphave'),
					['status' => 503],
				);
			}

			$rows = $wpdb->get_results(
				"SELECT id, started_at, finished_at, scheduled, score, processed, total, finding_count, critical_count, warning_count, info_count, new_count, resolved_count, unchanged_count, scope_hash, ruleset_version, score_version, complete, truncated, truncation_reason, error_count, coverage, counts, settings FROM {$table} ORDER BY finished_at DESC LIMIT 30",
				ARRAY_A,
			);
			if (null === $rows && '' !== $wpdb->last_error) {
				self::record_storage_error('history', $wpdb->last_error);

				return new WP_Error(
					'wphave_content_audit_history_failed',
					__('Content Audit history could not be loaded.', 'wphave'),
					['status' => 500],
				);
			}
			$rows = is_array($rows) ? $rows : [];
			$external_link_counts = array_fill_keys(
				array_map('absint', array_column($rows, 'id')),
				0,
			);
			$snapshot_ids = array_keys($external_link_counts);

			if ($snapshot_ids) {
				$findings_table = $wpdb->prefix . self::FINDINGS_TABLE;
				$placeholders = implode(', ', array_fill(0, count($snapshot_ids), '%d'));
				$link_findings = $wpdb->get_results(
					$wpdb->prepare(
						"SELECT snapshot_id, target_url FROM {$findings_table} WHERE category = 'links' AND snapshot_id IN ({$placeholders})",
						...$snapshot_ids,
					),
					ARRAY_A,
				);
				if (null === $link_findings && '' !== $wpdb->last_error) {
					self::record_storage_error('history_links', $wpdb->last_error);

					return new WP_Error(
						'wphave_content_audit_history_failed',
						__('Content Audit history could not be loaded.', 'wphave'),
						['status' => 500],
					);
				}

				foreach (is_array($link_findings) ? $link_findings : [] as $finding) {
					if (self::is_external_url((string) ($finding['target_url'] ?? ''))) {
						$snapshot_id = absint($finding['snapshot_id'] ?? 0);
						$external_link_counts[$snapshot_id] =
							($external_link_counts[$snapshot_id] ?? 0) + 1;
					}
				}
			}

			return rest_ensure_response(
				array_map(static function (array $row) use ($external_link_counts): array {
					$row['counts'] = json_decode((string) ($row['counts'] ?? ''), true) ?: [];
					$row['coverage'] = json_decode((string) ($row['coverage'] ?? ''), true) ?: [];
					$row['settings'] = json_decode((string) ($row['settings'] ?? ''), true) ?: [];
					$row['external_link_count'] =
						$external_link_counts[absint($row['id'] ?? 0)] ?? 0;
					$row['complete'] = (bool) ($row['complete'] ?? false);
					$row['truncated'] = (bool) ($row['truncated'] ?? false);
					return $row;
				}, $rows),
			);
		}

		/** Keep the timezone-aware single event synchronized with workflow settings. */

		public static function sync_automation_schedule(): bool {
			$settings = self::get_automation_settings();
			$scheduled = wp_next_scheduled(self::AUTOMATION_HOOK);
			$signature = $settings['frequency'] . ':' . $settings['timeWindow'];
			$stored_signature = get_option(self::AUTOMATION_SCHEDULE_OPTION, '');
			$cleanup_scheduled = WPHAVE_Background_Job_Scheduler::sync_recurring(
				self::CLEANUP_HOOK,
				self::CLEANUP_SCHEDULE_OPTION,
				true,
				'daily',
				time() + DAY_IN_SECONDS,
				'content-audit-history-retention-v1',
			);
			if (!$cleanup_scheduled) {
				return false;
			}

			if (!$settings['enabled']) {
				wp_clear_scheduled_hook(self::AUTOMATION_HOOK);
				delete_option(self::AUTOMATION_SCHEDULE_OPTION);
				return true;
			}

			$event = $scheduled ? wp_get_scheduled_event(self::AUTOMATION_HOOK) : false;
			if ($event && (!empty($event->schedule) || $stored_signature !== $signature)) {
				wp_clear_scheduled_hook(self::AUTOMATION_HOOK);
				$scheduled = false;
			}

			if (!$scheduled || $scheduled < time()) {
				// AVAILABILITY INVARIANT: A missed single event cannot satisfy the
				// automation contract. Central reconciliation removes stale or
				// duplicate entries and commits one future calendar-aware wake-up.
				$scheduled_result = WPHAVE_Background_Job_Scheduler::ensure_single_event(
					self::AUTOMATION_HOOK,
					[],
					self::next_time_window_timestamp(
						$settings['timeWindow'],
						$settings['frequency'],
					),
				);
				if (!$scheduled_result) {
					return false;
				}

				if (!self::store_option(self::AUTOMATION_SCHEDULE_OPTION, $signature)) {
					wp_clear_scheduled_hook(self::AUTOMATION_HOOK);

					return false;
				}
			}

			return true;
		}

		/** Start an automatic audit without competing with a manual job. */

		public static function run_automatic_audit(): void {
			$settings = self::get_automation_settings();
			if (!$settings['enabled']) {
				return;
			}
			if (self::get_status()['state'] === 'running') {
				self::sync_automation_schedule();

				return;
			}

			$token = WPHAVE_Background_Job_Lock::acquire(self::AUTOMATION_LOCK, self::JOB_TIMEOUT);

			if (!$token) {
				self::sync_automation_schedule();

				return;
			}

			try {
				self::start_audit($settings['limit'], $settings['checkExternalLinks'], true);
			} finally {
				WPHAVE_Background_Job_Lock::release(self::AUTOMATION_LOCK, $token);
				self::sync_automation_schedule();
			}
		}

		/** Persist an immutable snapshot and its normalized findings atomically. */

		private static function persist_completed_snapshot(array $job, array $results) {
			global $wpdb;
			if (!WPHAVE_Content_Audit_Schema::validate()) {
				return new WP_Error(
					'wphave_content_audit_schema_unavailable',
					__('The Content Audit storage schema is unavailable.', 'wphave'),
				);
			}

			$results['findings'] = self::normalize_findings((array) ($results['findings'] ?? []));
			$results['counts'] = self::count_findings($results['findings']);

			$snapshots = $wpdb->prefix . self::SNAPSHOTS_TABLE;
			$findings_table = $wpdb->prefix . self::FINDINGS_TABLE;
			$counts = wp_parse_args($results['counts'] ?? [], self::empty_counts());
			$job_uuid = sanitize_text_field($job['id'] ?? '');
			if ('' === $job_uuid) {
				return new WP_Error(
					'wphave_content_audit_job_identity_missing',
					__('The Content Audit job identity is missing.', 'wphave'),
				);
			}

			$existing_snapshot = absint(
				$wpdb->get_var(
					$wpdb->prepare(
						"SELECT id FROM {$snapshots} WHERE job_uuid = %s LIMIT 1",
						$job_uuid,
					),
				),
			);
			if ('' !== (string) $wpdb->last_error) {
				self::record_storage_error('snapshot_identity', $wpdb->last_error);

				return new WP_Error(
					'wphave_content_audit_snapshot_lookup_failed',
					__('The Content Audit snapshot identity could not be verified.', 'wphave'),
				);
			}

			if ($existing_snapshot > 0) {
				return $existing_snapshot;
			}

			$current_fingerprints = array_values(
				array_unique(
					array_map(
						[__CLASS__, 'finding_fingerprint'],
						(array) ($results['findings'] ?? []),
					),
				),
			);
			$scope_hash = sanitize_text_field($results['scopeHash'] ?? ($job['scopeHash'] ?? ''));
			$ruleset_version = sanitize_text_field(
				$results['rulesetVersion'] ?? ($job['rulesetVersion'] ?? ''),
			);
			$complete =
				!empty($results['complete']) &&
				empty($results['truncated']) &&
				empty($results['errors']);
			$previous_snapshot = 0;

			if ($complete && '' !== $scope_hash && '' !== $ruleset_version) {
				$previous_snapshot = absint(
					$wpdb->get_var(
						$wpdb->prepare(
							"SELECT id FROM {$snapshots} WHERE scope_hash = %s AND ruleset_version = %s AND complete = 1 ORDER BY finished_at DESC LIMIT 1",
							$scope_hash,
							$ruleset_version,
						),
					),
				);
				if ('' !== (string) $wpdb->last_error) {
					self::record_storage_error('previous_snapshot', $wpdb->last_error);

					return new WP_Error(
						'wphave_content_audit_history_lookup_failed',
						__('The previous Content Audit snapshot could not be verified.', 'wphave'),
					);
				}
			}

			$previous_fingerprints = $previous_snapshot
				? $wpdb->get_col(
					$wpdb->prepare(
						"SELECT fingerprint FROM {$findings_table} WHERE snapshot_id = %d",
						$previous_snapshot,
					),
				)
				: [];
			if ($previous_snapshot && '' !== (string) $wpdb->last_error) {
				self::record_storage_error('previous_findings', $wpdb->last_error);

				return new WP_Error(
					'wphave_content_audit_history_lookup_failed',
					__('The previous Content Audit findings could not be verified.', 'wphave'),
				);
			}
			$previous_fingerprints = is_array($previous_fingerprints) ? $previous_fingerprints : [];
			$new_count = $previous_snapshot
				? count(array_diff($current_fingerprints, $previous_fingerprints))
				: 0;
			$resolved_count = count(array_diff($previous_fingerprints, $current_fingerprints));
			$unchanged_count = count(
				array_intersect($current_fingerprints, $previous_fingerprints),
			);
			if (false === $wpdb->query('START TRANSACTION')) {
				self::record_storage_error('transaction_start', $wpdb->last_error);

				return new WP_Error(
					'wphave_content_audit_transaction_failed',
					__('The Content Audit snapshot transaction could not be started.', 'wphave'),
				);
			}
			$inserted = $wpdb->insert($snapshots, [
				'job_uuid' => $job_uuid,
				'started_at' => sanitize_text_field($results['startedAt'] ?? current_time('mysql')),
				'finished_at' => sanitize_text_field(
					$results['finishedAt'] ?? current_time('mysql'),
				),
				'scheduled' => empty($job['scheduled']) ? 0 : 1,
				'score' => absint($results['score'] ?? 0),
				'processed' => absint($results['processed'] ?? 0),
				'total' => absint($results['total'] ?? 0),
				'finding_count' => count($results['findings'] ?? []),
				'critical_count' => absint($counts['critical']),
				'warning_count' => absint($counts['warning']),
				'info_count' => absint($counts['info']),
				'new_count' => $new_count,
				'resolved_count' => $resolved_count,
				'unchanged_count' => $unchanged_count,
				'scope_hash' => $scope_hash,
				'ruleset_version' => $ruleset_version,
				'score_version' => absint($results['scoreVersion'] ?? self::SCORE_VERSION),
				'complete' => $complete ? 1 : 0,
				'truncated' => empty($results['truncated']) ? 0 : 1,
				'truncation_reason' => sanitize_key($results['truncationReason'] ?? ''),
				'error_count' => count((array) ($results['errors'] ?? [])),
				'coverage' => wp_json_encode($results['coverage'] ?? []),
				'counts' => wp_json_encode($counts),
				'settings' => wp_json_encode([
					'limit' => count($job['items'] ?? []),
					'checkExternalLinks' => !empty($job['checkExternalLinks']),
					'rules' => WPHAVE_Content_Audit_Rule_Registry::instance()->manifest(),
				]),
			]);

			if (false === $inserted) {
				$wpdb->query('ROLLBACK');
				self::record_storage_error('snapshot', $wpdb->last_error);
				return new WP_Error(
					'wphave_content_audit_snapshot_failed',
					__('The Content Audit snapshot could not be saved.', 'wphave'),
				);
			}

			$snapshot_id = (int) $wpdb->insert_id;
			foreach ((array) ($results['findings'] ?? []) as $finding) {
				$ok = $wpdb->insert($findings_table, [
					'snapshot_id' => $snapshot_id,
					'fingerprint' => self::finding_fingerprint($finding),
					'post_id' => absint($finding['postId'] ?? 0),
					'post_type' => sanitize_key($finding['postType'] ?? ''),
					'finding_code' => sanitize_key($finding['code'] ?? ''),
					'category' => sanitize_key($finding['category'] ?? ''),
					'severity' => sanitize_key($finding['severity'] ?? ''),
					'rule_id' => sanitize_key($finding['ruleId'] ?? ''),
					'rule_version' => sanitize_text_field($finding['ruleVersion'] ?? '1'),
					'source' => sanitize_key($finding['source'] ?? 'content-audit'),
					'post_title' => sanitize_text_field($finding['postTitle'] ?? ''),
					'title' => sanitize_text_field($finding['title'] ?? ''),
					'description' => sanitize_textarea_field($finding['description'] ?? ''),
					'post_url' => esc_url_raw($finding['postUrl'] ?? ''),
					'edit_url' => esc_url_raw($finding['editUrl'] ?? ''),
					'target_url' => esc_url_raw($finding['url'] ?? ''),
					'evidence' => wp_json_encode(
						array_merge((array) ($finding['evidence'] ?? []), [
							'occurrenceCount' => max(1, absint($finding['occurrenceCount'] ?? 1)),
						]),
					),
					'priority_score' => absint($finding['priorityScore'] ?? 0),
					'analytics_views' => absint($finding['analyticsViews'] ?? 0),
					'analytics_conversions' => absint($finding['analyticsConversions'] ?? 0),
				]);
				if (false === $ok) {
					$wpdb->query('ROLLBACK');
					self::record_storage_error('finding', $wpdb->last_error);
					return new WP_Error(
						'wphave_content_audit_finding_failed',
						__('A Content Audit finding could not be saved.', 'wphave'),
					);
				}
			}
			if ($complete) {
				$synchronized = WPHAVE_Content_Audit_Finding_Repository::synchronize(
					$snapshot_id,
					(array) ($results['findings'] ?? []),
					$previous_snapshot,
					true,
				);

				if (!$synchronized) {
					$wpdb->query('ROLLBACK');
					self::record_storage_error('workflow', $wpdb->last_error);

					return new WP_Error(
						'wphave_content_audit_workflow_failed',
						__('The Content Audit workflow state could not be saved.', 'wphave'),
					);
				}
			}

			if (false === $wpdb->query('COMMIT')) {
				$wpdb->query('ROLLBACK');
				self::record_storage_error('commit', $wpdb->last_error);

				return new WP_Error(
					'wphave_content_audit_commit_failed',
					__('The Content Audit snapshot could not be committed.', 'wphave'),
				);
			}
			self::cleanup_history();

			return $snapshot_id;
		}

		/** Log database diagnostics without exposing server details through REST. */

		private static function record_storage_error(
			string $operation,
			string $database_error,
		): void {
			if (!defined('WP_DEBUG') || !WP_DEBUG) {
				return;
			}

			error_log(
				sprintf(
					'[WPHAVE Content Audit] Storage operation "%s" failed: %s',
					sanitize_key($operation),
					WPHAVE_Security_Redactor::error_text($database_error, 1000),
				),
			);
		}

		/** Enforce age- and count-based retention in bounded, retryable phases. */

		public static function cleanup_history(): bool {
			global $wpdb;
			if (!WPHAVE_Content_Audit_Schema::validate()) {
				self::schedule_cleanup_continuation(15 * MINUTE_IN_SECONDS);
				return false;
			}
			$snapshots = $wpdb->prefix . self::SNAPSHOTS_TABLE;
			$findings = $wpdb->prefix . self::FINDINGS_TABLE;
			$cutoff = current_datetime()
				->modify('-' . self::RETENTION_DAYS . ' days')
				->format('Y-m-d H:i:s');
			$wpdb->last_error = '';
			$keep_ids = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT id FROM {$snapshots} WHERE finished_at >= %s ORDER BY finished_at DESC LIMIT %d",
					$cutoff,
					self::MAX_SNAPSHOTS,
				),
			);
			if ('' !== (string) $wpdb->last_error) {
				self::record_storage_error('cleanup_keep_selection', $wpdb->last_error);
				self::schedule_cleanup_continuation(15 * MINUTE_IN_SECONDS);
				return false;
			}

			$keep_ids = is_array($keep_ids) ? $keep_ids : [];
			$where = $keep_ids
				? 'id NOT IN (' . implode(',', array_map('absint', $keep_ids)) . ')'
				: '1=1';
			$wpdb->last_error = '';
			$delete_ids = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT id FROM {$snapshots} WHERE {$where} ORDER BY id ASC LIMIT %d",
					self::CLEANUP_BATCH_SIZE,
				),
			);
			if ('' !== (string) $wpdb->last_error) {
				self::record_storage_error('cleanup_delete_selection', $wpdb->last_error);
				self::schedule_cleanup_continuation(15 * MINUTE_IN_SECONDS);
				return false;
			}

			$delete_ids = is_array($delete_ids) ? $delete_ids : [];
			$needs_continuation = self::CLEANUP_BATCH_SIZE === count($delete_ids);
			if ($delete_ids) {
				$ids = implode(',', array_map('absint', $delete_ids));
				if (false === $wpdb->query('START TRANSACTION')) {
					self::record_storage_error('cleanup_transaction_start', $wpdb->last_error);
					self::schedule_cleanup_continuation(15 * MINUTE_IN_SECONDS);
					return false;
				}

				$findings_deleted = $wpdb->query(
					"DELETE FROM {$findings} WHERE snapshot_id IN ({$ids})",
				);
				$snapshots_deleted =
					false === $findings_deleted
						? false
						: $wpdb->query("DELETE FROM {$snapshots} WHERE id IN ({$ids})");

				if (false === $findings_deleted || false === $snapshots_deleted) {
					$wpdb->query('ROLLBACK');
					self::record_storage_error('cleanup', $wpdb->last_error);
					self::schedule_cleanup_continuation(15 * MINUTE_IN_SECONDS);
					return false;
				} elseif (false === $wpdb->query('COMMIT')) {
					$wpdb->query('ROLLBACK');
					self::record_storage_error('cleanup_commit', $wpdb->last_error);
					self::schedule_cleanup_continuation(15 * MINUTE_IN_SECONDS);
					return false;
				}
			}

			$url_cache = $wpdb->prefix . self::URL_CACHE_TABLE;
			$url_cache_deleted = self::cleanup_bounded_rows(
				$url_cache,
				'url_hash',
				'expires_at',
				current_datetime()->modify('-1 day')->format('Y-m-d H:i:s'),
			);
			if (null === $url_cache_deleted) {
				self::schedule_cleanup_continuation(15 * MINUTE_IN_SECONDS);
				return false;
			}
			$needs_continuation =
				$needs_continuation || self::CLEANUP_BATCH_SIZE === $url_cache_deleted;

			$issue_state = $wpdb->prefix . self::ISSUE_STATE_TABLE;
			$issue_state_deleted = self::cleanup_bounded_rows(
				$issue_state,
				'id',
				'last_seen_at',
				$cutoff,
				"status = 'resolved'",
			);
			if (null === $issue_state_deleted) {
				self::schedule_cleanup_continuation(15 * MINUTE_IN_SECONDS);
				return false;
			}
			$needs_continuation =
				$needs_continuation || self::CLEANUP_BATCH_SIZE === $issue_state_deleted;

			if ($needs_continuation) {
				self::schedule_cleanup_continuation(5 * MINUTE_IN_SECONDS);
			}

			return true;
		}

		/** Delete one bounded auxiliary-table batch without trusting stale candidates. */

		private static function cleanup_bounded_rows(
			string $table,
			string $key,
			string $date_column,
			string $cutoff,
			string $extra_where = '1=1',
		): ?int {
			global $wpdb;
			$wpdb->last_error = '';
			$ids = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT {$key} FROM {$table} WHERE {$extra_where} AND {$date_column} < %s ORDER BY {$key} ASC LIMIT %d",
					$cutoff,
					self::CLEANUP_BATCH_SIZE,
				),
			);

			// RESILIENCE INVARIANT: SQL failure and an empty candidate set are distinct.
			if (null === $ids || $wpdb->last_error) {
				self::record_storage_error('cleanup_auxiliary_selection', $wpdb->last_error);
				return null;
			}
			if (!$ids) {
				return 0;
			}

			$placeholders = implode(',', array_fill(0, count($ids), 'id' === $key ? '%d' : '%s'));
			$arguments = array_merge($ids, [$cutoff]);
			// DATA-INTEGRITY INVARIANT: The destructive statement repeats every
			// mutable eligibility predicate so stale candidates survive safely.
			$deleted = $wpdb->query(
				$wpdb->prepare(
					"DELETE FROM {$table} WHERE {$key} IN ({$placeholders}) AND {$extra_where} AND {$date_column} < %s",
					$arguments,
				),
			);

			return false === $deleted ? null : (int) $deleted;
		}

		/** Schedule one cleanup follow-up without creating a retry storm. */

		private static function schedule_cleanup_continuation(int $delay): bool {
			// AVAILABILITY INVARIANT: An overdue Cron entry is execution history,
			// not proof that retention still has a future wake-up. The shared
			// scheduler removes stale entries and reconciles one executable retry.
			return WPHAVE_Background_Job_Scheduler::ensure_continuation(
				self::CLEANUP_CONTINUATION_HOOK,
				[],
				max(MINUTE_IN_SECONDS, $delay),
			);
		}

		private static function get_automation_settings(): array {
			$settings = get_option(self::AUTOMATION_OPTION, []);
			return wp_parse_args(is_array($settings) ? $settings : [], [
				'enabled' => false,
				'frequency' => 'weekly',
				'timeWindow' => 'night',
				'email' => '',
				'limit' => self::DEFAULT_LIMIT,
				'checkExternalLinks' => true,
			]);
		}

		private static function get_automation_status(): array {
			$settings = self::get_automation_settings();
			$notification = get_option(self::NOTIFICATION_OPTION, []);
			$next = wp_next_scheduled(self::AUTOMATION_HOOK);
			return array_merge($settings, [
				'effectiveEmail' => $settings['email'] ?: sanitize_email(get_option('admin_email')),
				'nextRun' => $next ? wp_date('Y-m-d H:i:s', $next) : '',
				'timing' => $settings['enabled']
					? WPHAVE_Background_Job_Scheduler::display_timing(self::AUTOMATION_HOOK)
					: null,
				'lastAutomaticRun' => sanitize_text_field(
					get_option(self::LAST_AUTOMATIC_OPTION, ''),
				),
				'lastNotification' => sanitize_text_field($notification['sentAt'] ?? ''),
				'lastNotificationAttempt' => sanitize_text_field(
					$notification['attemptedAt'] ?? '',
				),
				'lastNotificationStatus' => sanitize_key($notification['status'] ?? ''),
			]);
		}

		private static function next_time_window_timestamp(string $window, string $frequency): int {
			$hours = ['night' => 2, 'morning' => 8, 'afternoon' => 14, 'evening' => 20];
			$now = current_datetime();
			$next = $now->setTime($hours[$window] ?? 2, 0);
			if ($next <= $now) {
				$interval = [
					'daily' => '+1 day',
					'weekly' => '+1 week',
					'monthly' => '+1 month',
				];
				$next = $next->modify($interval[$frequency] ?? '+1 week');
			}

			return $next->getTimestamp();
		}

		private static function complete_automatic_audit(array $results): void {
			update_option(
				self::LAST_AUTOMATIC_OPTION,
				$results['finishedAt'] ?? current_time('mysql'),
				false,
			);
			self::maybe_send_automatic_notification($results);
		}

		/** Build a severity-independent identity for one finding across audits. */
		public static function finding_fingerprint(array $finding): string {
			return hash(
				'sha256',
				implode('|', [
					sanitize_key($finding['postType'] ?? ''),
					absint($finding['postId'] ?? 0),
					sanitize_key($finding['ruleId'] ?? ''),
					sanitize_key($finding['code'] ?? ''),
					esc_url_raw($finding['url'] ?? ''),
				]),
			);
		}

		/**
		 * Collapse repeated occurrences into one durable issue per content and rule.
		 *
		 * A rule may encounter the same logical problem multiple times in one
		 * document. Snapshots intentionally store issue identities, not raw DOM
		 * occurrences, so repeated matches retain a count without violating the
		 * snapshot/fingerprint uniqueness invariant.
		 */

		private static function normalize_findings(array $findings): array {
			$normalized = [];

			foreach ($findings as $finding) {
				if (!is_array($finding)) {
					continue;
				}

				$fingerprint = self::finding_fingerprint($finding);
				$occurrence_count = max(1, absint($finding['occurrenceCount'] ?? 1));
				$finding['fingerprint'] = $fingerprint;
				$finding['occurrenceCount'] = $occurrence_count;

				if (!isset($normalized[$fingerprint])) {
					$normalized[$fingerprint] = $finding;
					continue;
				}

				$normalized[$fingerprint]['occurrenceCount'] += $occurrence_count;
			}

			return array_values($normalized);
		}

		private static function maybe_send_automatic_notification(array $results): void {
			$settings = self::get_automation_settings();
			$email = sanitize_email($settings['email'] ?: get_option('admin_email'));
			if (!$email) {
				return;
			}
			$previous = get_option(self::NOTIFIED_OPTION, []);
			$previous = is_array($previous) ? $previous : [];
			$ranks = ['info' => 1, 'warning' => 2, 'critical' => 3];
			$current = [];
			$changed = [];
			foreach ((array) ($results['findings'] ?? []) as $finding) {
				$id = self::finding_fingerprint($finding);
				$severity = sanitize_key($finding['severity'] ?? 'info');
				$current[$id] = $severity;
				if (
					!isset($previous[$id]) ||
					($ranks[$severity] ?? 0) > ($ranks[$previous[$id]] ?? 0)
				) {
					$changed[] = $finding;
				}
			}
			if (!$changed) {
				update_option(self::NOTIFIED_OPTION, $current, false);
				return;
			}
			$site = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);
			$content =
				'<p><strong>' .
				esc_html(
					sprintf(__('New or escalated content findings: %d', 'wphave'), count($changed)),
				) .
				'</strong></p><ul>';
			foreach (array_slice($changed, 0, 25) as $finding) {
				$content .=
					'<li><strong>[' .
					esc_html(strtoupper($finding['severity'] ?? 'info')) .
					'] ' .
					esc_html($finding['postTitle'] ?? '') .
					'</strong>: ' .
					esc_html($finding['title'] ?? '') .
					'</li>';
			}
			$content .=
				'</ul><p>' .
				esc_html__(
					'Open WPHAVE Content Audit to review and resolve the findings.',
					'wphave',
				) .
				'</p>';
			$message = function_exists('wphave_build_email_template')
				? wphave_build_email_template([
					'title' => __('Content findings need review', 'wphave'),
					'description' => sprintf(
						__('The automatic content audit for %s found changes.', 'wphave'),
						home_url('/'),
					),
					'content' => $content,
					'footer_content' => esc_html__(
						'This notification was generated automatically by WPHAVE Content Audit.',
						'wphave',
					),
				])
				: wp_strip_all_tags($content);
			$headers = function_exists('wphave_email_template_headers')
				? wphave_email_template_headers()
				: [];
			$sent = wp_mail(
				$email,
				sprintf(__('[%s] Content Audit found changes', 'wphave'), $site),
				$message,
				$headers,
			);
			$notification = [
				'attemptedAt' => current_time('mysql'),
				'status' => $sent ? 'sent' : 'failed',
				'email' => $email,
				'findings' => count($changed),
			];
			if ($sent) {
				$notification['sentAt'] = $notification['attemptedAt'];
				update_option(self::NOTIFIED_OPTION, $current, false);
			}
			update_option(self::NOTIFICATION_OPTION, $notification, false);
		}

		/**
		 * Count findings by severity and category.
		 *
		 * @param array $findings Findings.
		 * @return array
		 */

		protected static function count_findings(array $findings): array {
			$counts = self::empty_counts();

			foreach ($findings as $finding) {
				$severity = $finding['severity'] ?? '';
				$category = $finding['category'] ?? '';

				if (isset($counts[$severity])) {
					$counts[$severity]++;
				}

				if (isset($counts[$category])) {
					$counts[$category]++;
				}
			}

			return $counts;
		}

		/**
		 * Calculate a conservative content quality score.
		 *
		 * @param array $results Audit results.
		 * @return int Score from 0 to 100.
		 */

		protected static function calculate_score(array $results): int {
			$total = absint($results['processed'] ?? 0);
			if (0 === $total) {
				return 0;
			}
			$counts = wp_parse_args($results['counts'] ?? [], self::empty_counts());
			$penalty = $counts['critical'] * 9 + $counts['warning'] * 4 + $counts['info'] * 1.5;

			return max(0, min(100, (int) round(100 - $penalty / $total)));
		}
	}

	WPHAVE_Content_Audit::init();
endif;
