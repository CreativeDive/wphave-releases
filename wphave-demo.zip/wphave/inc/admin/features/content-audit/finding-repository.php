<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Persists mutable editorial workflow state for immutable audit findings.
 *
 * Finding identity is the stable fingerprint produced by the audit service.
 * OWNERSHIP INVARIANT: Snapshot observations never change; this repository owns only lifecycle
 * state such as acceptance, resolution, assignment, notes and snoozing.
 */

final class WPHAVE_Content_Audit_Finding_Repository {

	private const STATUSES = array( 'open', 'accepted', 'ignored', 'resolved' );

	/**
	 * Synchronize durable issue state inside the caller-owned snapshot transaction.
	 *
	 * @param int   $snapshot_id Current immutable snapshot ID.
	 * @param array $findings Canonical unique findings in the current snapshot.
	 * @param int   $previous_snapshot_id Previous compatible complete snapshot.
	 * @param bool  $complete Whether absence may resolve previous open findings.
	 * @return bool False when any database mutation fails.
	 */

	public static function synchronize( int $snapshot_id, array $findings, int $previous_snapshot_id = 0, bool $complete = false ): bool {
		global $wpdb;

		$table = $wpdb->prefix . WPHAVE_Content_Audit::ISSUE_STATE_TABLE;
		$now = current_time( 'mysql' );

		foreach ( $findings as $finding ) {
			$fingerprint = WPHAVE_Content_Audit::finding_fingerprint( $finding );
			$updated = $wpdb->query(
				$wpdb->prepare(
					"INSERT INTO {$table}
						(fingerprint,status,first_snapshot_id,last_snapshot_id,first_seen_at,last_seen_at,resolved_at,updated_at)
					 VALUES (%s,'open',%d,%d,%s,%s,NULL,%s)
					 ON DUPLICATE KEY UPDATE
						last_snapshot_id = VALUES(last_snapshot_id),
						last_seen_at = VALUES(last_seen_at),
						resolved_at = NULL,
						status = IF(status = 'resolved', 'open', status),
						updated_at = VALUES(updated_at)",
					$fingerprint,
					$snapshot_id,
					$snapshot_id,
					$now,
					$now,
					$now
				)
			);

			if ( false === $updated ) {
				return false;
			}
		}

		if ( $complete && $previous_snapshot_id > 0 ) {
			$resolved = $wpdb->query(
				$wpdb->prepare(
					"UPDATE {$table}
					 SET status = 'resolved', resolved_at = %s, updated_at = %s
					 WHERE last_snapshot_id = %d AND status = 'open'",
					$now,
					$now,
					$previous_snapshot_id
				)
			);

			if ( false === $resolved ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Return lifecycle states keyed by finding fingerprint.
	 *
	 * Queries are chunked to keep placeholder lists within conservative database
	 * and packet limits when an audit reaches the maximum finding count.
	 */

	public static function states_for_fingerprints( array $fingerprints ) {
		global $wpdb;

		$fingerprints = array_values(
			array_unique(
				array_filter(
					array_map(
						static fn( $fingerprint ): string => preg_replace( '/[^a-f0-9]/', '', strtolower( (string) $fingerprint ) ),
						$fingerprints
					),
					static fn( string $fingerprint ): bool => 64 === strlen( $fingerprint )
				)
			)
		);

		if ( array() === $fingerprints ) {
			return array();
		}

		$states = array();
		$table = $wpdb->prefix . WPHAVE_Content_Audit::ISSUE_STATE_TABLE;

		foreach ( array_chunk( $fingerprints, 500 ) as $fingerprint_chunk ) {
			$placeholders = implode( ',', array_fill( 0, count( $fingerprint_chunk ), '%s' ) );
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT fingerprint,status,first_seen_at,last_seen_at,resolved_at,assignee_id,note,snoozed_until,updated_at
					 FROM {$table} WHERE fingerprint IN ({$placeholders})",
					...$fingerprint_chunk
				),
				ARRAY_A
			);

			if ( null === $rows && '' !== (string) $wpdb->last_error ) {
				return new WP_Error(
					'wphave_content_audit_workflow_read_failed',
					__( 'The Content Audit workflow state could not be loaded.', 'wphave' ),
					array( 'status' => 503 )
				);
			}

			foreach ( is_array( $rows ) ? $rows : array() as $row ) {
				$states[ $row['fingerprint'] ] = $row;
			}
		}

		return $states;
	}

	/** Validate and update editorial workflow state for one stable finding. */

	public static function update_state( string $fingerprint, array $input, int $user_id ) {
		global $wpdb;

		$fingerprint = preg_replace( '/[^a-f0-9]/', '', strtolower( $fingerprint ) );
		$status = sanitize_key( $input['status'] ?? 'open' );

		if ( 64 !== strlen( $fingerprint ) || ! in_array( $status, self::STATUSES, true ) ) {
			return new WP_Error(
				'wphave_content_audit_invalid_issue_state',
				__( 'The requested finding state is invalid.', 'wphave' ),
				array( 'status' => 400 )
			);
		}

		$table = $wpdb->prefix . WPHAVE_Content_Audit::ISSUE_STATE_TABLE;
		$existing = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE fingerprint = %s", $fingerprint ),
			ARRAY_A
		);

		if ( null === $existing && '' !== (string) $wpdb->last_error ) {
			return new WP_Error(
				'wphave_content_audit_workflow_read_failed',
				__( 'The Content Audit workflow state could not be loaded.', 'wphave' ),
				array( 'status' => 503 )
			);
		}

		if ( ! $existing ) {
			return new WP_Error(
				'wphave_content_audit_issue_not_found',
				__( 'The finding could not be found.', 'wphave' ),
				array( 'status' => 404 )
			);
		}

		$assignee_id = absint( $input['assigneeId'] ?? $existing['assignee_id'] );
		if ( $assignee_id && ! get_user_by( 'id', $assignee_id ) ) {
			return new WP_Error(
				'wphave_content_audit_invalid_assignee',
				__( 'The selected assignee does not exist.', 'wphave' ),
				array( 'status' => 400 )
			);
		}

		$snoozed_until = sanitize_text_field( $input['snoozedUntil'] ?? $existing['snoozed_until'] );
		$snoozed_format = str_contains( $snoozed_until, ' ' ) ? '!Y-m-d H:i:s' : '!Y-m-d';
		$snoozed_date = '' === $snoozed_until
			? false
			: DateTimeImmutable::createFromFormat( $snoozed_format, $snoozed_until, wp_timezone() );
		$snoozed_errors = false === $snoozed_date ? false : DateTimeImmutable::getLastErrors();
		if ( '' !== $snoozed_until && false === $snoozed_date ) {
			return new WP_Error(
				'wphave_content_audit_invalid_snooze',
				__( 'Enter a valid snooze date.', 'wphave' ),
				array( 'status' => 400 )
			);
		}
		if (
			is_array( $snoozed_errors ) &&
			( $snoozed_errors['warning_count'] > 0 || $snoozed_errors['error_count'] > 0 )
		) {
			return new WP_Error(
				'wphave_content_audit_invalid_snooze',
				__( 'Enter a valid snooze date.', 'wphave' ),
				array( 'status' => 400 )
			);
		}

		$updated = $wpdb->update(
			$table,
			array(
				'status' => $status,
				'assignee_id' => $assignee_id,
				'note' => sanitize_textarea_field( $input['note'] ?? $existing['note'] ),
				'snoozed_until' => false === $snoozed_date ? null : $snoozed_date->format( 'Y-m-d H:i:s' ),
				'resolved_at' => 'resolved' === $status ? current_time( 'mysql' ) : null,
				'updated_by' => $user_id,
				'updated_at' => current_time( 'mysql' ),
			),
			array( 'fingerprint' => $fingerprint )
		);

		if ( false === $updated ) {
			return new WP_Error(
				'wphave_content_audit_issue_update_failed',
				__( 'The finding state could not be saved.', 'wphave' ),
				array( 'status' => 500 )
			);
		}

		if ( class_exists( 'WPHAVE_Activity_Log' ) ) {
			WPHAVE_Activity_Log::record(
				'content_audit.finding_state_updated',
				array(
					'category' => 'content',
					'action' => 'updated',
					'object_type' => 'content_audit_finding',
					'object_label' => $fingerprint,
					'context' => array(
						'status' => $status,
						'assignee_id' => $assignee_id,
					),
				)
			);
		}

		$states = self::states_for_fingerprints( array( $fingerprint ) );

		if ( is_wp_error( $states ) ) {
			return $states;
		}

		return $states[ $fingerprint ] ?? array();
	}
}

/**
 * Enriches findings with privacy-preserving first-party impact signals.
 *
 * Only aggregate 30-day views and conversion counts are read. No visitor or
 * lead identity enters Content Audit storage. Priority remains deterministic
 * when Analytics is unavailable by falling back to severity-only scoring.
 */

final class WPHAVE_Content_Audit_Insights {

	/** Add aggregate impact metrics and a bounded priority score to each finding. */

	public static function enrich( array $findings ): array {
		$post_ids = array_values(
			array_unique(
				array_filter( array_map( static fn( array $finding ): int => absint( $finding['postId'] ?? 0 ), $findings ) )
			)
		);

		if ( array() === $post_ids || ! class_exists( 'WPHAVE_Analytics' ) ) {
			return array_map( array( __CLASS__, 'with_default_priority' ), $findings );
		}

		global $wpdb;
		$daily = $wpdb->prefix . WPHAVE_Analytics::DAILY_TABLE;
		$events = $wpdb->prefix . WPHAVE_Analytics::EVENT_TABLE;
		$tables_exist = WPHAVE_Database_Metadata::table_exists( $daily );

		if ( ! $tables_exist ) {
			return array_map( array( __CLASS__, 'with_default_priority' ), $findings );
		}

		$ids = implode( ',', array_map( 'absint', $post_ids ) );
		$since_date = current_datetime()->modify( '-30 days' )->format( 'Y-m-d' );
		$views = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT post_id,COALESCE(SUM(views),0) AS views FROM {$daily}
				 WHERE post_id IN ({$ids}) AND view_date >= %s GROUP BY post_id",
				$since_date
			),
			OBJECT_K
		);
		$views = is_array( $views ) ? $views : array();

		$conversions = array();
		if ( WPHAVE_Database_Metadata::table_exists( $events ) ) {
			$since_time = current_datetime()->modify( '-30 days' )->format( 'Y-m-d H:i:s' );
			$conversions = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT post_id,COUNT(*) AS conversions FROM {$events}
					 WHERE post_id IN ({$ids}) AND viewed_at >= %s AND goal_id <> '' GROUP BY post_id",
					$since_time
				),
				OBJECT_K
			);
			$conversions = is_array( $conversions ) ? $conversions : array();
		}

		return array_map(
			static function( array $finding ) use ( $views, $conversions ): array {
				$post_id = absint( $finding['postId'] ?? 0 );
				$view_count = absint( $views[ $post_id ]->views ?? 0 );
				$conversion_count = absint( $conversions[ $post_id ]->conversions ?? 0 );
				$severity_score = array( 'critical' => 70, 'warning' => 45, 'info' => 20 )[ $finding['severity'] ?? 'info' ] ?? 20;
				$traffic_score = min( 20, (int) round( log( $view_count + 1, 2 ) * 2 ) );
				$conversion_score = min( 10, $conversion_count * 2 );

				$finding['analyticsViews'] = $view_count;
				$finding['analyticsConversions'] = $conversion_count;
				$finding['priorityScore'] = min( 100, $severity_score + $traffic_score + $conversion_score );

				return $finding;
			},
			$findings
		);
	}

	/** Apply deterministic severity-only priority when Analytics is unavailable. */

	private static function with_default_priority( array $finding ): array {
		$finding['analyticsViews'] = 0;
		$finding['analyticsConversions'] = 0;
		$finding['priorityScore'] = array( 'critical' => 70, 'warning' => 45, 'info' => 20 )[ $finding['severity'] ?? 'info' ] ?? 20;

		return $finding;
	}
}
