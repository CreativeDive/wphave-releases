<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Load Content Audit processing, recovery, automation and cleanup callbacks.
 *
 * WP-Cron must register every persisted hook before dispatch. Keeping this
 * entrypoint separate prevents those implementation classes from becoming part
 * of every management screen while preserving synchronous worker execution.
 */
require_once __DIR__ . '/bootstrap.php';
