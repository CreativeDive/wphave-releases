<?php

/**
 * Register the lightweight Content Audit storage contract.
 *
 * REGISTRATION ORDER INVARIANT: Schema registration must happen while the
 * management feature graph is composed, before admin_init migrations run.
 * Loading it only from the REST-dispatched audit runtime makes a fresh site
 * appear healthy during migration and pending as soon as status is requested.
 * The scanner, rule registry and worker runtime deliberately remain lazy.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/schema.php';

WPHAVE_Database_Schema_Manager::register(
	array(
		'id' => 'content-audit',
		'label' => 'Content Audit',
		'version' => WPHAVE_Content_Audit_Schema::DB_VERSION,
		'option' => 'wphave_content_audit_db_version',
		'callback' => array( 'WPHAVE_Content_Audit_Schema', 'install' ),
		'validator' => array( 'WPHAVE_Content_Audit_Schema', 'validate' ),
		'tables' => array(
			WPHAVE_Content_Audit_Schema::SNAPSHOTS_TABLE,
			WPHAVE_Content_Audit_Schema::FINDINGS_TABLE,
			WPHAVE_Content_Audit_Schema::ISSUE_STATE_TABLE,
			WPHAVE_Content_Audit_Schema::URL_CACHE_TABLE,
		),
	)
);
