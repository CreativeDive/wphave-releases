<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once wphave_dir() . 'inc/features/security/rate-limiter.php';

if( ! class_exists( 'WPHAVE_Client_Support' ) ) :

	/**
	 * Delivers client support requests to the support provider configured for
	 * this installation. Requests use the site's normal wp_mail transport.
	 */

	class WPHAVE_Client_Support {

		const RATE_LIMIT = 5;

		public static function init(): void {
			add_action( 'rest_api_init', [ __CLASS__, 'register_rest_route' ] );
		}

		public static function register_rest_route(): void {
			register_rest_route( 'wphave/v1', '/client-support', [
				'methods' => 'POST',
				'callback' => [ __CLASS__, 'submit' ],
				'permission_callback' => static function() {
					return current_user_can( 'manage_options' ) || current_user_can( 'wphave_create_support_ticket' );
				},
				'args' => [
					'mail' => [ 'type' => 'string', 'format' => 'email', 'maxLength' => 254, 'required' => true ],
					'category' => [ 'type' => 'string', 'enum' => [ 'technical_issue', 'question', 'feature_request', 'billing_license' ], 'required' => true ],
					'feedback' => [ 'type' => 'string', 'minLength' => 1, 'maxLength' => 10000, 'required' => true ],
					'dataConsent' => [ 'type' => 'array', 'items' => [ 'type' => 'string' ], 'required' => true ],
					'debug' => [ 'type' => 'object', 'required' => true ],
				],
			] );
		}

		public static function submit( WP_REST_Request $request ) {
			// AUTHORIZATION INVARIANT: The REST permission callback is only an early
			// dispatch gate. Repeat support-ticket authority before reading provider
			// configuration, processing caller-supplied diagnostics or sending mail;
			// a nonce and a direct PHP call never grant this external side effect.
			if( ! self::can_submit() ) {
				return self::forbidden();
			}

			$settings = (array) wphave_data_get( 'site_settings', 'advanced.ui.clientSupport', [] );
			$recipient = sanitize_email( $settings['email'] ?? '' );
			$provider = sanitize_text_field( $settings['name'] ?? '' );

			if( empty( $settings['isEnabled'] ) || ! $recipient || ! $provider ) {
				return new WP_Error( 'wphave_client_support_unavailable', __( 'Client support is not configured completely.', 'wphave' ), [ 'status' => 409 ] );
			}

			$user_id = get_current_user_id();
			$rate_key = 'wphave_client_support_' . $user_id;

			$data = (array) $request->get_json_params();
			$mail = sanitize_email( $data['mail'] ?? '' );
			$message = sanitize_textarea_field( $data['feedback'] ?? '' );
			$category = sanitize_key( $data['category'] ?? '' );
			$categories = [
				'technical_issue' => __( 'Technical issue', 'wphave' ),
				'question' => __( 'Question', 'wphave' ),
				'feature_request' => __( 'Feature request', 'wphave' ),
				'billing_license' => __( 'Billing and license', 'wphave' ),
			];
			$consent = in_array( 'optin', (array) ( $data['dataConsent'] ?? [] ), true );
			$diagnostics = isset( $data['debug'] ) && is_array( $data['debug'] ) ? $data['debug'] : [];

			if( ! is_email( $mail ) || ! $message || strlen( $message ) > 10000 || ! isset( $categories[$category] ) ) {
				return new WP_Error( 'wphave_client_support_invalid_request', __( 'A valid email address, request category and message are required.', 'wphave' ), [ 'status' => 422 ] );
			}

			if( ! $consent || ! $diagnostics ) {
				return new WP_Error( 'wphave_client_support_diagnostics_required', __( 'Installation data and consent are required for support requests.', 'wphave' ), [ 'status' => 422 ] );
			}

			// SECURITY INVARIANT: Installation diagnostics leave the site only with an
			// explicit request-scoped opt-in and within a bounded serialized payload.
			// Feature access by itself never implies consent to transmit support data.
			$diagnostics_json = wp_json_encode( $diagnostics, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
			if( ! is_string( $diagnostics_json ) || strlen( $diagnostics_json ) > 1048576 ) {
				return new WP_Error( 'wphave_client_support_diagnostics_too_large', __( 'Installation data exceeds the support request size limit.', 'wphave' ), [ 'status' => 413 ] );
			}

			$case_id = 'CLIENT-' . gmdate( 'Ymd-His' ) . '-' . strtoupper( wp_generate_password( 4, false, false ) );
			$subject = sprintf( '[%1$s] %2$s — %3$s', $case_id, $categories[$category], wp_parse_url( home_url(), PHP_URL_HOST ) );
			$body = implode( "\n", [
				sprintf( 'Case ID: %s', $case_id ),
				sprintf( 'Support provider: %s', $provider ),
				sprintf( 'Website: %s', home_url() ),
				sprintf( 'Requester: %s', $mail ),
				sprintf( 'Category: %s', $categories[$category] ),
				'',
				'Message:',
				$message,
				'',
				'Installation diagnostics:',
				$diagnostics_json,
			] );
			$headers = [ 'Reply-To: ' . $mail ];

			// AUTHORIZATION INVARIANT: Provider lookup, request normalization and
			// diagnostics serialization are extensible trust boundaries. Repeat the
			// established ticket capability before consuming abuse budget or sending.
			if( ! self::can_submit() ) {
				return self::forbidden();
			}

			// Count attempts before delivery so a failing or deliberately invalid mail
			// transport cannot be used to bypass the per-user abuse limit.
			$rate = WPHAVE_Rate_Limiter::increment( $rate_key, HOUR_IN_SECONDS );
			if( $rate > self::RATE_LIMIT ) {
				return new WP_Error( 'wphave_client_support_rate_limit', __( 'Too many support requests were submitted. Please try again later.', 'wphave' ), [ 'status' => 429 ] );
			}

			// AUTHORIZATION INVARIANT: Rate-limit storage cannot carry caller authority
			// across its own hooks. Revalidate immediately before the external mail sink.
			if( ! self::can_submit() ) {
				return self::forbidden();
			}

			$sent = wp_mail( $recipient, $subject, $body, $headers );

			// AUTHORIZATION INVARIANT: Successful delivery under fresh pre-send
			// authority does not authorize releasing the case identifier after a
			// transport callback changes the caller's live ticket capability.
			if( ! self::can_submit() ) {
				return self::forbidden();
			}

			if( ! $sent ) {
				return new WP_Error( 'wphave_client_support_delivery_failed', __( 'The website mail service could not deliver the support request.', 'wphave' ), [ 'status' => 502 ] );
			}

			return rest_ensure_response( [
				'success' => true,
				'caseId' => $case_id,
			] );
		}

		/** Determine whether the current user may submit one support request. */
		private static function can_submit(): bool {
			return current_user_can( 'manage_options' )
				|| current_user_can( 'wphave_create_support_ticket' );
		}

		/** Return the stable support submission denial. */
		private static function forbidden(): WP_Error {
			return new WP_Error(
				'wphave_client_support_forbidden',
				__( 'You are not allowed to submit support requests.', 'wphave' ),
				[ 'status' => 403 ]
			);
		}
	}

	WPHAVE_Client_Support::init();

endif;
