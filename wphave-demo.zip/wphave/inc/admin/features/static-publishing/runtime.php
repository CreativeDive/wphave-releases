<?php

if (!defined('ABSPATH')) {
	exit();
}

// LOADING INVARIANT: Public entrypoints authorize before loading storage/export services.
/** Load domain implementation only for an authorized publishing operation. */
require_once wphave_dir() . 'inc/features/security/file-mutex.php';
require_once wphave_dir() . 'inc/features/security/file-identity.php';
require_once wphave_dir() . 'inc/features/security/atomic-file.php';
require_once wphave_dir() . 'inc/features/security/owned-tree.php';
require_once __DIR__ . '/domain/url-policy.php';
require_once __DIR__ . '/domain/manifest.php';
require_once __DIR__ . '/domain/state-validator.php';
require_once __DIR__ . '/domain/compatibility-error.php';
require_once __DIR__ . '/domain/redirect-response.php';
require_once __DIR__ . '/application/redirects.php';
require_once __DIR__ . '/rendering/resource-diagnostic.php';
require_once __DIR__ . '/rendering/compatibility-inspector.php';
require_once __DIR__ . '/rendering/password-protection-inspector.php';
require_once __DIR__ . '/rendering/admin-chrome-filter.php';
require_once __DIR__ . '/rendering/comment-filter.php';
require_once __DIR__ . '/rendering/adapters/consent.php';
require_once __DIR__ . '/storage/local-storage.php';
require_once __DIR__ . '/rendering/http-renderer.php';
require_once __DIR__ . '/rendering/css-transformer.php';
require_once __DIR__ . '/rendering/document-transformer.php';
require_once __DIR__ . '/application/page-inventory.php';
require_once __DIR__ . '/application/planner.php';
require_once __DIR__ . '/application/archive.php';
require_once __DIR__ . '/application/runner.php';
