<?php

if (!defined('ABSPATH')) {
	exit;
}

require_once __DIR__ . '/read-abilities.php';
require_once dirname(__DIR__) . '/ai/transport/site-context.php';
require_once dirname( __DIR__ ) . '/ai-mcp/server-factory.php';

add_action(
	'wp_abilities_api_categories_init',
	array('WPHAVE_AI_MCP_Read_Abilities', 'register_category')
);
add_action(
	'wp_abilities_api_init',
	array('WPHAVE_AI_MCP_Read_Abilities', 'register')
);
add_action( 'mcp_adapter_init', static function ( $adapter ): void {
	wphave_ai_mcp_register_server(
		$adapter,
		'wphave-read-server',
		'WPHAVE Read',
		array( 'wphave/site-info', 'wphave/list-pages', 'wphave/inspect-page' )
	);
} );
