<?php

if (!defined('ABSPATH')) {
	exit;
}

/** Read-only Abilities for the optional official WordPress MCP Adapter. */
final class WPHAVE_AI_MCP_Read_Abilities {
	private const MAX_PAGE = 100;
	private const PAGE_SIZE = 20;
	private const MAX_NODES = 80;
	private const MAX_DEPTH = 5;
	private const MAX_TEXT = 300;
	private const TEXT_BLOCKS = array('wphave/heading', 'wphave/paragraph', 'wphave/button');

	public static function register_category(): void {
		if (!self::available() || !function_exists('wp_register_ability_category')) {
			return;
		}

		wp_register_ability_category('wphave-editor-read', array(
			'label' => __('WPHAVE Editor Read', 'wphave'),
			'description' => __('Permission-filtered, saved editor information.', 'wphave'),
		));
	}

	public static function register(): void {
		if (!self::available() || !function_exists('wp_register_ability')) {
			return;
		}

		$common = array(
			'category' => 'wphave-editor-read',
			'meta' => array(
				'public' => false,
				'show_in_rest' => false,
				'mcp' => array('public' => true),
				'annotations' => array('readonly' => true, 'idempotent' => true),
			),
		);

		wp_register_ability('wphave/site-info', array_merge($common, array(
			'label' => __('Inspect WPHAVE site', 'wphave'),
			'description' => __('Read the WPHAVE version and read-only MCP feature state.', 'wphave'),
			'execute_callback' => array(__CLASS__, 'site_info'),
			'permission_callback' => array(__CLASS__, 'can_read_site'),
			'output_schema' => self::site_info_schema(),
		)));

		wp_register_ability('wphave/list-pages', array_merge($common, array(
			'label' => __('List WPHAVE pages', 'wphave'),
			'description' => __('List saved pages visible to this user, twenty at a time.', 'wphave'),
			'input_schema' => self::page_input_schema(),
			'output_schema' => self::list_output_schema(),
			'execute_callback' => array(__CLASS__, 'list_pages'),
			'permission_callback' => array(__CLASS__, 'can_list_pages'),
		)));

		wp_register_ability('wphave/inspect-page', array_merge($common, array(
			'label' => __('Inspect WPHAVE page', 'wphave'),
			'description' => __('Read a bounded native block outline and saved-content fingerprint for one editable page.', 'wphave'),
			'input_schema' => self::inspect_input_schema(),
			'output_schema' => self::inspect_output_schema(),
			'execute_callback' => array(__CLASS__, 'inspect_page'),
			'permission_callback' => array(__CLASS__, 'can_inspect_page'),
		)));
	}

	private static function available(): bool {
		return function_exists('wphave_release_feature_ready') &&
			wphave_release_feature_ready('aiMcpRead') &&
			function_exists('wp_register_ability');
	}

	public static function can_read_site(): bool {
		return self::available() && current_user_can('edit_pages');
	}

	public static function can_list_pages($input = null): bool {
		return self::can_read_site() && self::valid_page_input($input);
	}

	public static function can_inspect_page($input = null): bool {
		$id = is_array($input) ? ($input['pageId'] ?? null) : null;
		$post = is_int($id) && $id > 0 ? get_post($id) : null;

		return self::available() &&
			$post instanceof WP_Post &&
			'page' === $post->post_type &&
			current_user_can('read_post', $id) &&
			current_user_can('edit_post', $id);
	}

	public static function site_info(): array|WP_Error {
		if (!self::can_read_site()) {
			return self::forbidden();
		}

		return array(
			'siteId' => get_current_blog_id(),
			'pluginVersion' => WPHAVE_VERSION,
			'abilities' => array('wphave/site-info', 'wphave/list-pages', 'wphave/inspect-page'),
			'writeAvailable' => false,
		);
	}

	public static function list_pages($input = null): array|WP_Error {
		if (!self::can_list_pages($input)) {
			return self::forbidden();
		}

		$page = $input['page'] ?? 1;
		$records = WPHAVE_AI_Site_Context::page_records(array(
			'page' => $page,
			'pageSize' => self::PAGE_SIZE,
		));
		if (is_wp_error($records)) {
			return $records;
		}
		$items = array();
		foreach ($records['items'] as $record) {
			$id = $record['resource']['id'];
			if (!current_user_can('edit_post', $id)) {
				continue;
			}
			$items[] = array(
				'resource' => $record['resource'],
				'title' => $record['title'],
				'status' => $record['status'],
				'revision' => $record['revision'],
			);
		}

		return array(
			'items' => $items,
			'page' => $page,
			'hasMore' => $page < self::MAX_PAGE && $records['hasMore'],
			'visibility' => 'authorized_editable_pages_only',
		);
	}

	public static function inspect_page($input = null): array|WP_Error {
		if (!self::can_inspect_page($input)) {
			return self::forbidden();
		}

		$post = get_post($input['pageId']);
		$remaining = self::MAX_NODES;
		$truncated = false;
		$outline = self::outline(parse_blocks($post->post_content), $remaining, $truncated);

		return array(
			'resource' => self::resource($post),
			'title' => get_the_title($post),
			'status' => $post->post_status,
			'revision' => $post->post_modified_gmt,
			'contentFingerprint' => hash('sha256', $post->post_content),
			'blocks' => $outline,
			'truncated' => $truncated,
			'unsavedEditorStateIncluded' => false,
		);
	}

	private static function outline(array $blocks, int &$remaining, bool &$truncated, int $depth = 0): array {
		$result = array();
		foreach ($blocks as $block) {
			if ($remaining <= 0) {
				$truncated = true;
				break;
			}
			--$remaining;
			$name = $block['blockName'] ?? null;
			if (!is_string($name) || '' === $name) {
				continue;
			}
			$text = in_array($name, self::TEXT_BLOCKS, true)
				? trim(wp_strip_all_tags((string) ($block['innerHTML'] ?? '')))
				: '';
			$children = $block['innerBlocks'] ?? array();
			if ($depth >= self::MAX_DEPTH && $children) {
				$truncated = true;
			}
			$result[] = array(
				'name' => $name,
				'text' => wphave_substr($text, 0, self::MAX_TEXT),
				'children' => $depth < self::MAX_DEPTH
					? self::outline($children, $remaining, $truncated, $depth + 1)
					: array(),
			);
		}

		return $result;
	}

	private static function resource(WP_Post $post): array {
		return array(
			'siteId' => get_current_blog_id(),
			'type' => 'page',
			'id' => (int) $post->ID,
		);
	}

	private static function valid_page_input($input): bool {
		if (null === $input) {
			return true;
		}
		if (!is_array($input)) {
			return false;
		}
		$page = $input['page'] ?? 1;
		return is_int($page) && $page >= 1 && $page <= self::MAX_PAGE;
	}

	private static function forbidden(): WP_Error {
		return new WP_Error('wphave_mcp_read_forbidden', __('This resource is not available.', 'wphave'), array('status' => 403));
	}

	private static function resource_schema(): array {
		return array('type' => 'object', 'properties' => array(
			'siteId' => array('type' => 'integer'),
			'type' => array('type' => 'string', 'enum' => array('page')),
			'id' => array('type' => 'integer'),
		), 'required' => array('siteId', 'type', 'id'), 'additionalProperties' => false);
	}

	private static function page_input_schema(): array {
		return array('type' => 'object', 'properties' => array(
			'page' => array('type' => 'integer', 'minimum' => 1, 'maximum' => self::MAX_PAGE),
		), 'additionalProperties' => false);
	}

	private static function inspect_input_schema(): array {
		return array('type' => 'object', 'properties' => array(
			'pageId' => array('type' => 'integer', 'minimum' => 1),
		), 'required' => array('pageId'), 'additionalProperties' => false);
	}

	private static function site_info_schema(): array {
		return array('type' => 'object', 'properties' => array(
			'siteId' => array('type' => 'integer'),
			'pluginVersion' => array('type' => 'string'),
			'abilities' => array('type' => 'array', 'items' => array('type' => 'string')),
			'writeAvailable' => array('type' => 'boolean'),
		), 'required' => array('siteId', 'pluginVersion', 'abilities', 'writeAvailable'), 'additionalProperties' => false);
	}

	private static function list_output_schema(): array {
		return array('type' => 'object', 'properties' => array(
			'items' => array('type' => 'array', 'items' => array('type' => 'object', 'properties' => array(
				'resource' => self::resource_schema(),
				'title' => array('type' => 'string'),
				'status' => array('type' => 'string'),
				'revision' => array('type' => 'string'),
			), 'required' => array('resource', 'title', 'status', 'revision'), 'additionalProperties' => false)),
			'page' => array('type' => 'integer'),
			'hasMore' => array('type' => 'boolean'),
			'visibility' => array('type' => 'string'),
		), 'required' => array('items', 'page', 'hasMore', 'visibility'), 'additionalProperties' => false);
	}

	private static function inspect_output_schema(): array {
		return array('type' => 'object', 'properties' => array(
			'resource' => self::resource_schema(),
			'title' => array('type' => 'string'),
			'status' => array('type' => 'string'),
			'revision' => array('type' => 'string'),
			'contentFingerprint' => array('type' => 'string'),
			'blocks' => array('type' => 'array', 'items' => array('type' => 'object')),
			'truncated' => array('type' => 'boolean'),
			'unsavedEditorStateIncluded' => array('type' => 'boolean'),
		), 'required' => array('resource', 'title', 'status', 'revision', 'contentFingerprint', 'blocks', 'truncated', 'unsavedEditorStateIncluded'), 'additionalProperties' => false);
	}
}
