<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Exposes built-in website starters as Website Plan payloads.
 *
 * Bundled JSON packages are projected into read-only Website Plans so the
 * planner and Site Composition screens consume the same canonical content
 * without maintaining PHP-only starter definitions.
 */

class WPHAVE_Website_Plan_Builtins {

	/**
	 * Return the available website plan builtins entries.
	 *
	 * @return array Return the available website plan builtins entries.
	 */

	public static function all(): array {
		$compositions = WPHAVE_Site_Composition_Defaults::all();
		$plans = array();

		foreach( $compositions as $composition ) {
			if( ! is_array( $composition ) || empty( $composition['id'] ) ) {
				continue;
			}

			$plans[] = self::from_composition( $composition );
		}

		return $plans;
	}

	/**
	 * Return the requested website plan builtins entry.
	 *
	 * @param string $id Id.
	 * @return ?array Return the requested website plan builtins entry.
	 */

	public static function get( string $id ): ?array {
		foreach( self::all() as $plan ) {
			if( (string) ( $plan['id'] ?? '' ) === $id ) {
				return $plan;
			}
		}

		return null;
	}

	/**
	 * From composition.
	 *
	 * @param array $composition Composition.
	 * @return array From composition.
	 */

	protected static function from_composition( array $composition ): array {
		$id = 'builtin-' . sanitize_key( $composition['id'] ?? '' );
		$title = sanitize_text_field( (string) ( $composition['title'] ?? __( 'Built-in Website Plan', 'wphave' ) ) );

		return array(
			'id' => $id,
			'title' => $title,
			'status' => 'builtin',
			'isBuiltin' => true,
			'payload' => WPHAVE_Website_Plan_Schema::builtin_payload( $composition ),
			'createdAt' => null,
			'modifiedAt' => null,
			'author' => 0,
		);
	}

}
