<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Central Website Plan schema normalization.
 *
 * OWNERSHIP INVARIANT: Website Plans are the source of truth for planner projects and starters
 * and AI generated website plans. Other planner layers consume this shape.
 */

class WPHAVE_Website_Plan_Schema {

	public const VERSION = 1;

	/**
	 * Upgrade a persisted Planner document before its allowlisted shape is built.
	 * Add every sequential transformation here before increasing VERSION. Newer
	 * COMPATIBILITY INVARIANT: Newer schemas are never normalized by an older runtime because that can erase
	 * planning data the older version does not understand.
	 *
	 * @return array|WP_Error Migrated payload or an unsupported-schema error.
	 */

	public static function migrate( $payload ) {
		if( ! is_array( $payload ) ) return new WP_Error( 'wphave_website_plan_invalid', __( 'The website plan is invalid.', 'wphave' ) );
		$version = max( 1, absint( $payload['version'] ?? 1 ) );
		if( $version > self::VERSION ) return new WP_Error( 'wphave_website_plan_schema_newer', __( 'This website plan was created by a newer WPHAVE version and cannot be changed safely.', 'wphave' ), array( 'status' => 409 ) );

		while( $version < self::VERSION ) {
			switch( $version ) {
				// Add the v1-to-v2 Planner transformation before raising VERSION.
				default:
					return new WP_Error( 'wphave_website_plan_migration_missing', __( 'This website plan cannot be migrated safely.', 'wphave' ) );
			}
			$version++;
			$payload['version'] = $version;
		}

		return $payload;
	}

	/**
	 * Normalize the payload value.
	 *
	 * @param mixed $payload Payload.
	 * @return array Normalize the payload value.
	 */

	public static function payload( $payload ): array {
		$payload = self::migrate( is_array( $payload ) ? $payload : array() );
		if( is_wp_error( $payload ) ) return array();

		return array(
			'version' => self::VERSION,
			'source' => self::source( $payload['source'] ?? array(), 'manual' ),
			'brief' => self::array_recursive( $payload['brief'] ?? array() ),
			'sitemap' => self::array_recursive( $payload['sitemap'] ?? array() ),
			'wireframes' => self::array_recursive( $payload['wireframes'] ?? array() ),
			'style' => self::array_recursive( $payload['style'] ?? array() ),
			'fonts' => self::array_recursive( $payload['fonts'] ?? array() ),
			'generation' => self::array_recursive( $payload['generation'] ?? array() ),
			'status' => self::status( $payload['status'] ?? 'planning' ),
		);
	}

	/**
	 * Normalize the status value.
	 *
	 * @param string $status Status.
	 * @return string Normalize the status value.
	 */

	public static function status( $status ): string {
		$status = sanitize_key( (string) $status );
		$allowed = array( 'planning', 'sitemap_ready', 'wireframes_ready', 'style_ready', 'builtin' );

		return in_array( $status, $allowed, true ) ? $status : 'planning';
	}

	/**
	 * Normalize the title value.
	 *
	 * @param string $title Title.
	 * @return string Normalize the title value.
	 */

	public static function title( $title ): string {
		$title = trim( mb_substr( sanitize_text_field( (string) $title ), 0, 160 ) );

		return $title ?: __( 'Untitled website plan', 'wphave' );
	}

	/**
	 * Normalize the template parts value.
	 *
	 * @param mixed $parts Parts.
	 * @return array Normalize the template parts value.
	 */

	public static function template_parts( $parts ): array {
		$parts = is_array( $parts ) ? $parts : array();

		return array(
			'header' => self::template_part( $parts['header'] ?? array(), 'Header' ),
			'footer' => self::template_part( $parts['footer'] ?? array(), 'Footer' ),
		);
	}

	/**
	 * Normalize the pages value.
	 *
	 * @param array $wireframe_pages Wireframe pages.
	 * @param array $sitemap_pages Sitemap pages.
	 * @return array Normalize the pages value.
	 */

	public static function pages( $wireframe_pages, $sitemap_pages = array() ): array {
		$wireframe_pages = is_array( $wireframe_pages ) ? $wireframe_pages : array();
		$sitemap_pages = is_array( $sitemap_pages ) ? $sitemap_pages : array();
		$pages = array();

		foreach( $wireframe_pages as $index => $page ) {
			if( ! is_array( $page ) || trim( (string) ( $page['content'] ?? '' ) ) === '' ) {
				continue;
			}

			$sitemap_page = is_array( $sitemap_pages[$index] ?? null ) ? $sitemap_pages[$index] : array();
			$title = sanitize_text_field( (string) ( $page['title'] ?? $sitemap_page['title'] ?? sprintf( __( 'Page %d', 'wphave' ), $index + 1 ) ) );
			$slug = sanitize_title( (string) ( $page['slug'] ?? $sitemap_page['slug'] ?? $title ) );

			$pages[] = array(
				'title' => $title,
				'slug' => $slug ?: 'page-' . ( $index + 1 ),
				'intent' => sanitize_textarea_field( (string) ( $page['intent'] ?? $sitemap_page['intent'] ?? '' ) ),
				'description' => sanitize_textarea_field( (string) ( $page['description'] ?? $sitemap_page['description'] ?? '' ) ),
				'source' => self::source( $page['source'] ?? array(), 'manual' ),
				'content' => (string) ( $page['content'] ?? '' ),
				'plan' => is_array( $page['plan'] ?? null ) ? $page['plan'] : array(),
				'sectionsContent' => is_array( $page['sectionsContent'] ?? null ) ? self::sections_content( $page['sectionsContent'] ) : array(),
			);
		}

		return $pages;
	}

	/**
	 * Builtin payload.
	 *
	 * @param array $composition Composition.
	 * @return array Builtin payload.
	 */

	public static function builtin_payload( array $composition ): array {
		$title = sanitize_text_field( (string) ( $composition['title'] ?? __( 'Built-in Website Plan', 'wphave' ) ) );
		$template_parts = is_array( $composition['templateParts'] ?? null ) ? $composition['templateParts'] : array();
		$content = is_array( $composition['content'] ?? null ) ? $composition['content'] : array();
		$composition_pages = is_array( $composition['pages'] ?? null ) ? $composition['pages'] : array();
		$homepage = array(
			'title' => sanitize_text_field( (string) ( $content['title'] ?? sprintf( __( '%s Homepage', 'wphave' ), $title ) ) ),
			'slug' => 'home',
			'intent' => sanitize_textarea_field( (string) ( $composition['description'] ?? '' ) ),
			'description' => sanitize_textarea_field( (string) ( $composition['description'] ?? '' ) ),
			'content' => (string) ( $content['content'] ?? '' ),
		);
		$pages = array();

		if( ! empty( $composition_pages ) ) {
			foreach( $composition_pages as $index => $page ) {
				if( ! is_array( $page ) || trim( (string) ( $page['content'] ?? '' ) ) === '' ) {
					continue;
				}

				$page_title = sanitize_text_field( (string) ( $page['title'] ?? sprintf( __( 'Page %d', 'wphave' ), $index + 1 ) ) );
				$pages[] = array(
					'title' => $page_title,
					'slug' => sanitize_title( (string) ( $page['slug'] ?? $page_title ) ) ?: 'page-' . ( $index + 1 ),
					'intent' => sanitize_textarea_field( (string) ( $page['intent'] ?? $composition['description'] ?? '' ) ),
					'description' => sanitize_textarea_field( (string) ( $page['description'] ?? $page['intent'] ?? $composition['description'] ?? '' ) ),
					'source' => array(
						'type' => 'builtin',
					),
					'content' => (string) ( $page['content'] ?? '' ),
					'plan' => is_array( $page['plan'] ?? null ) ? $page['plan'] : array(),
					'sectionsContent' => is_array( $page['sectionsContent'] ?? null ) ? self::sections_content( $page['sectionsContent'] ) : array(),
				);
			}
		}

		if( empty( $pages ) ) {
			$pages = array( $homepage );
		}

		return self::payload( array(
			'version' => 1,
			'source' => array(
				'type' => 'builtin',
				'compositionId' => sanitize_key( $composition['id'] ?? '' ),
			),
			'brief' => array(
				'projectName' => $title,
				'goal' => sanitize_textarea_field( (string) ( $composition['description'] ?? '' ) ),
			),
			'sitemap' => array(
				'projectName' => $title,
				'summary' => sanitize_textarea_field( (string) ( $composition['description'] ?? '' ) ),
				'templateParts' => $template_parts,
				'pages' => array_map( function( $page ) {
					return array(
						'title' => $page['title'],
						'slug' => $page['slug'],
						'intent' => $page['intent'],
						'description' => $page['description'],
						'sections' => array(),
					);
				}, $pages ),
			),
			'wireframes' => array(
				'templateParts' => $template_parts,
				'pages' => $pages,
			),
			'style' => is_array( $composition['siteGlobals'] ?? null ) ? $composition['siteGlobals'] : array(),
			'fonts' => is_array( $composition['fonts'] ?? null ) ? $composition['fonts'] : array(),
			'generation' => array(
				'type' => 'builtin',
			),
			'status' => 'builtin',
		) );
	}

	/**
	 * Normalize the template part value.
	 *
	 * @param mixed $part Part.
	 * @param string $fallback_title Fallback title.
	 * @return array Normalize the template part value.
	 */

	protected static function template_part( $part, string $fallback_title ): array {
		$part = is_array( $part ) ? $part : array();

		return array(
			'title' => sanitize_text_field( (string) ( $part['title'] ?? $fallback_title ) ),
			'source' => self::source( $part['source'] ?? array(), 'manual' ),
			'content' => (string) ( $part['content'] ?? '' ),
			'plan' => is_array( $part['plan'] ?? null ) ? $part['plan'] : array(),
			'intent' => sanitize_textarea_field( (string) ( $part['intent'] ?? '' ) ),
			'sections' => is_array( $part['sections'] ?? null ) ? $part['sections'] : array(),
		);
	}

	/**
	 * Sections content.
	 *
	 * @param array $sections Sections.
	 * @return array Sections content.
	 */

	protected static function sections_content( array $sections ): array {
		$result = array();

		foreach( $sections as $section ) {
			if( ! is_array( $section ) ) {
				continue;
			}

			$result[] = array(
				'id' => sanitize_key( (string) ( $section['id'] ?? '' ) ),
				'title' => sanitize_text_field( (string) ( $section['title'] ?? '' ) ),
				'type' => sanitize_key( (string) ( $section['type'] ?? '' ) ),
				'archetype' => sanitize_key( (string) ( $section['archetype'] ?? '' ) ),
				'layout' => sanitize_key( (string) ( $section['layout'] ?? '' ) ),
				'treatment' => sanitize_key( (string) ( $section['treatment'] ?? '' ) ),
				'source' => self::source( $section['source'] ?? array(), 'manual' ),
				'content' => (string) ( $section['content'] ?? '' ),
			);
		}

		return $result;
	}

	/**
	 * Normalize the source value.
	 *
	 * @param mixed $source Source.
	 * @param string $fallback Fallback.
	 * @return array Normalize the source value.
	 */

	public static function source( $source, string $fallback = 'manual' ): array {
		$source = is_array( $source ) ? $source : array();
		$type = sanitize_key( (string) ( $source['type'] ?? $fallback ) );
		$allowed = array( 'manual', 'ai', 'builtin', 'import', 'system' );

		if( ! in_array( $type, $allowed, true ) ) {
			$type = $fallback;
		}

		$result = array(
			'type' => $type,
		);

		if( ! empty( $source['action'] ) ) {
			$result['action'] = sanitize_key( (string) $source['action'] );
		}

		if( ! empty( $source['createdAt'] ) ) {
			$result['createdAt'] = sanitize_text_field( (string) $source['createdAt'] );
		}

		if( ! empty( $source['updatedAt'] ) ) {
			$result['updatedAt'] = sanitize_text_field( (string) $source['updatedAt'] );
		}

		return $result;
	}

	/**
	 * Normalize the array recursive value.
	 *
	 * @param mixed $value Value.
	 */

	protected static function array_recursive( $value ) {
		if( is_array( $value ) ) {
			$clean = array();

			foreach( $value as $key => $item ) {
				$clean_key = is_int( $key ) ? $key : preg_replace( '/[^A-Za-z0-9_-]/', '', (string) $key );
				$clean[$clean_key] = self::array_recursive( $item );
			}

			return $clean;
		}

		if( is_bool( $value ) || is_int( $value ) || is_float( $value ) || $value === null ) {
			return $value;
		}

		return mb_substr( wp_check_invalid_utf8( (string) $value ), 0, 500000 );
	}

}
