<?php

/**
 * Load Website Planner schema, adapters, patterns, and persistence services.
 *
 * Site Compositions are an independent domain. Planner only consumes their
 * builder and registry APIs and contributes saved projects through a provider.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

include_once ( wphave_dir() . 'inc/admin/features/planner/schema.php' );
include_once ( wphave_dir() . 'inc/admin/features/planner/page-evidence.php' );
include_once ( wphave_dir() . 'inc/admin/features/planner/generation/pattern-registry.php' );
WPHAVE_Website_Plan_Pattern_Registry::register_bundled();
include_once ( wphave_dir() . 'inc/admin/features/planner/generation/pattern-composer.php' );
include_once ( wphave_dir() . 'inc/admin/features/planner/generation/pattern-page-composer.php' );
include_once ( wphave_dir() . 'inc/admin/features/planner/composition-adapter.php' );
include_once ( wphave_dir() . 'inc/editor/pattern/text-variants.php' );
include_once ( wphave_dir() . 'inc/editor/pattern/slots.php' );
include_once ( wphave_dir() . 'inc/admin/features/planner/section-library.php' );
include_once ( wphave_dir() . 'inc/admin/features/planner/plans.php' );
