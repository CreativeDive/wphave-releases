<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Website Planner section registry backed by existing WPHAVE block patterns.
 *
 * The Planner should select curated section layouts and fill their content
 * slots instead of asking AI to invent arbitrary block structures.
 */

class WPHAVE_Website_Planner_Section_Library {

	/**
	 * Return the available website planner section library entries.
	 *
	 * @param int $limit Limit.
	 * @return array Return the available website planner section library entries.
	 */

	public static function catalog( int $limit = 120 ): array {
		if( ! function_exists( 'wphave_ai_block_pattern_collection' ) ) {
			return array();
		}

		$patterns = wphave_ai_block_pattern_collection();
		$catalog = array();

		foreach( $patterns as $pattern ) {
			if( ! is_array( $pattern ) ) {
				continue;
			}

			$ai = is_array( $pattern['ai'] ?? null ) ? $pattern['ai'] : array();
			$roles = is_array( $ai['roles'] ?? null ) ? $ai['roles'] : array();
			if( empty( array_intersect( $roles, array( 'hero', 'section', 'content', 'cta', 'feature-grid', 'steps', 'faq', 'pricing', 'form', 'wide-card' ) ) ) ) {
				continue;
			}

			$key = sanitize_key( (string) ( $pattern['key'] ?? '' ) );
			if( $key === '' ) {
				continue;
			}

			$catalog[] = array(
				'key' => $key,
				'title' => sanitize_text_field( (string) ( $pattern['title'] ?? $key ) ),
				'roles' => array_values( array_filter( array_map( 'sanitize_key', $roles ) ) ),
				'layout' => array_values( array_filter( array_map( 'sanitize_key', (array) ( $ai['layout'] ?? array() ) ) ) ),
				'visual' => array_values( array_filter( array_map( 'sanitize_key', (array) ( $ai['visual'] ?? array() ) ) ) ),
				'intent' => array_values( array_filter( array_map( 'sanitize_key', (array) ( $ai['intent'] ?? array() ) ) ) ),
				'treatment' => array_values( array_filter( array_map( 'sanitize_key', (array) ( $ai['treatment'] ?? array() ) ) ) ),
				'description' => sanitize_text_field( (string) ( $ai['description'] ?? '' ) ),
			);

			if( count( $catalog ) >= $limit ) {
				break;
			}
		}

		return $catalog;
	}

	/**
	 * Prompt catalog.
	 *
	 * @param int $limit Limit.
	 * @return array Prompt catalog.
	 */

	public static function prompt_catalog( int $limit = 80 ): array {
		return array_map( function( $section ) {
			return array(
				'key' => $section['key'],
				'roles' => $section['roles'],
				'layout' => $section['layout'],
				'visual' => $section['visual'],
				'intent' => $section['intent'],
				'treatment' => $section['treatment'],
				'description' => $section['description'],
			);
		}, array_slice( self::catalog( $limit ), 0, $limit ) );
	}

	/**
	 * Render page.
	 *
	 * @param array $generated Generated.
	 * @param array $sitemap_page Sitemap page.
	 * @param int $page_index Page index.
	 * @return array Render page.
	 */

	public static function render_page( array $generated, array $sitemap_page, int $page_index ): array {
		$plan = is_array( $generated['plan'] ?? null ) ? $generated['plan'] : $generated;
		$sections = self::sections_from_plan( $plan, $sitemap_page, $page_index );
		$content = '';
		$sections_content = array();
		$diagnostics = array( 'pattern_section_renderer_used' );

		foreach( $sections as $index => $section ) {
			$rendered = self::render_section( $section, $index );
			if( trim( $rendered['content'] ) === '' ) {
				continue;
			}

			$content .= $rendered['content'] . "\n\n";
			$sections_content[] = $rendered;
			if( ! empty( $rendered['fallback'] ) ) {
				$diagnostics[] = 'pattern_section_fallback_used';
			}
		}

		return array(
			'plan' => array(
				'version' => 1,
				'intent' => sanitize_textarea_field( (string) ( $plan['intent'] ?? $sitemap_page['intent'] ?? '' ) ),
				'summary' => sanitize_textarea_field( (string) ( $plan['summary'] ?? $sitemap_page['description'] ?? '' ) ),
				'patternSections' => $sections,
			),
			'content' => trim( $content ),
			'sectionsContent' => $sections_content,
			'diagnostics' => array_values( array_unique( $diagnostics ) ),
		);
	}

	/**
	 * Determine whether pattern sections.
	 *
	 * @param array $generated Generated.
	 * @return bool Determine whether pattern sections.
	 */

	public static function has_pattern_sections( array $generated ): bool {
		$plan = is_array( $generated['plan'] ?? null ) ? $generated['plan'] : $generated;

		return is_array( $plan['patternSections'] ?? null ) || is_array( $plan['sections'] ?? null );
	}

	/**
	 * Sections from plan.
	 *
	 * @param array $plan Plan.
	 * @param array $sitemap_page Sitemap page.
	 * @param int $page_index Page index.
	 * @return array Sections from plan.
	 */

	protected static function sections_from_plan( array $plan, array $sitemap_page, int $page_index ): array {
		$raw_sections = is_array( $plan['patternSections'] ?? null ) ? $plan['patternSections'] : array();
		if( empty( $raw_sections ) && is_array( $plan['sections'] ?? null ) ) {
			$raw_sections = $plan['sections'];
		}

		$sections = array();
		foreach( array_slice( $raw_sections, 0, 8 ) as $index => $section ) {
			if( ! is_array( $section ) ) {
				continue;
			}

			$sections[] = self::sanitize_section( $section, $sitemap_page, $page_index, $index );
		}

		if( empty( $sections ) ) {
			$sections = self::fallback_sections( $sitemap_page, $page_index );
		}

		return $sections;
	}

	/**
	 * Sanitize section.
	 *
	 * @param array $section Section.
	 * @param array $sitemap_page Sitemap page.
	 * @param int $page_index Page index.
	 * @param int $section_index Section index.
	 * @return array Sanitize section.
	 */

	protected static function sanitize_section( array $section, array $sitemap_page, int $page_index, int $section_index ): array {
		$type = sanitize_key( (string) ( $section['type'] ?? $section['role'] ?? ( $section_index === 0 ? 'hero' : 'content' ) ) );
		$slots = is_array( $section['slots'] ?? null ) ? $section['slots'] : $section;
		$items = array();

		foreach( array_slice( (array) ( $slots['items'] ?? $section['items'] ?? array() ), 0, 8 ) as $item ) {
			if( ! is_array( $item ) ) {
				continue;
			}

			$items[] = array(
				'title' => sanitize_text_field( (string) ( $item['title'] ?? '' ) ),
				'text' => sanitize_textarea_field( (string) ( $item['text'] ?? $item['description'] ?? '' ) ),
			);
		}

		$actions = array();
		foreach( array_slice( (array) ( $slots['actions'] ?? $section['actions'] ?? array() ), 0, 3 ) as $action ) {
			if( ! is_array( $action ) ) {
				continue;
			}

			$actions[] = array(
				'label' => sanitize_text_field( (string) ( $action['label'] ?? '' ) ),
				'url' => esc_url_raw( (string) ( $action['url'] ?? '#' ) ),
			);
		}

		return array(
			'id' => sanitize_key( (string) ( $section['id'] ?? 'pattern-section-' . ( $section_index + 1 ) ) ),
			'patternKey' => sanitize_key( (string) ( $section['patternKey'] ?? $section['pattern'] ?? '' ) ),
			'type' => $type ?: ( $section_index === 0 ? 'hero' : 'content' ),
			'title' => sanitize_text_field( (string) ( $section['title'] ?? $slots['heading'] ?? $sitemap_page['title'] ?? sprintf( __( 'Section %d', 'wphave' ), $section_index + 1 ) ) ),
			'purpose' => sanitize_textarea_field( (string) ( $section['purpose'] ?? $section['intent'] ?? '' ) ),
			'slots' => array(
				'eyebrow' => sanitize_text_field( (string) ( $slots['eyebrow'] ?? ( $section_index === 0 ? $sitemap_page['title'] ?? '' : '' ) ) ),
				'heading' => sanitize_text_field( (string) ( $slots['heading'] ?? $section['heading'] ?? $section['title'] ?? $sitemap_page['title'] ?? '' ) ),
				'body' => sanitize_textarea_field( (string) ( $slots['body'] ?? $section['body'] ?? $section['description'] ?? $sitemap_page['description'] ?? '' ) ),
				'items' => $items,
				'actions' => $actions,
			),
		);
	}

	/**
	 * Fallback sections.
	 *
	 * @param array $sitemap_page Sitemap page.
	 * @param int $page_index Page index.
	 * @return array Fallback sections.
	 */

	protected static function fallback_sections( array $sitemap_page, int $page_index ): array {
		$title = sanitize_text_field( (string) ( $sitemap_page['title'] ?? 'Page' ) );
		$intent = sanitize_textarea_field( (string) ( $sitemap_page['intent'] ?? $sitemap_page['description'] ?? '' ) );
		$sections = array(
			self::sanitize_section( array(
				'type' => 'hero',
				'title' => $title,
				'slots' => array(
					'eyebrow' => $page_index === 0 ? __( 'Welcome', 'wphave' ) : $title,
					'heading' => $title,
					'body' => $intent,
					'actions' => array( array( 'label' => __( 'Mehr erfahren', 'wphave' ), 'url' => '#' ) ),
				),
			), $sitemap_page, $page_index, 0 ),
		);

		foreach( array_slice( (array) ( $sitemap_page['sections'] ?? array() ), 0, 4 ) as $index => $section ) {
			$sections[] = self::sanitize_section( array(
				'type' => $index === 3 ? 'cta' : 'content',
				'title' => $section['title'] ?? sprintf( __( 'Section %d', 'wphave' ), $index + 2 ),
				'slots' => array(
					'heading' => $section['title'] ?? '',
					'body' => $section['description'] ?? '',
					'items' => array(),
					'actions' => $index === 3 ? array( array( 'label' => __( 'Kontakt aufnehmen', 'wphave' ), 'url' => '#' ) ) : array(),
				),
			), $sitemap_page, $page_index, $index + 1 );
		}

		return $sections;
	}

	/**
	 * Render section.
	 *
	 * @param array $section Section.
	 * @param int $index Index.
	 * @return array Render section.
	 */

	protected static function render_section( array $section, int $index ): array {
		$pattern = self::pattern_for_section( $section );
		$content = trim( (string) ( $pattern['content'] ?? '' ) );
		$fallback = false;

		if( $content === '' ) {
			$pattern = self::pattern_for_role( $section['type'] === 'hero' ? 'section' : 'content' );
			$content = trim( (string) ( $pattern['content'] ?? '' ) );
			$fallback = true;
		}

		$content = self::render_pattern_content( $pattern, $section['slots'] ?? array(), $content );
		$content = self::wrap_planner_section( $content, $section, $index );

		return array(
			'id' => $section['id'] ?: 'pattern-section-' . ( $index + 1 ),
			'title' => $section['title'],
			'type' => $section['type'],
			'archetype' => sanitize_key( (string) ( $pattern['key'] ?? $pattern['ai']['roles'][0] ?? 'pattern' ) ),
			'layout' => sanitize_key( (string) ( $pattern['ai']['layout'][0] ?? 'pattern' ) ),
			'treatment' => sanitize_key( (string) ( $pattern['ai']['treatment'][0] ?? 'pattern' ) ),
			'patternKey' => sanitize_key( (string) ( $pattern['key'] ?? '' ) ),
			'source' => is_array( $section['source'] ?? null ) ? $section['source'] : array(
				'type' => 'ai',
				'action' => 'wireframe_section',
			),
			'content' => $content,
			'fallback' => $fallback,
		);
	}

	/**
	 * Pattern for section.
	 *
	 * @param array $section Section.
	 * @return array Pattern for section.
	 */

	protected static function pattern_for_section( array $section ): array {
		$key = sanitize_key( (string) ( $section['patternKey'] ?? '' ) );
		foreach( self::patterns() as $pattern ) {
			if( $key && sanitize_key( (string) ( $pattern['key'] ?? '' ) ) === $key ) {
				return $pattern;
			}
		}

		return self::pattern_for_role( $section['type'] ?? 'content' );
	}

	/**
	 * Pattern for role.
	 *
	 * @param string $role Role.
	 * @return array Pattern for role.
	 */

	protected static function pattern_for_role( string $role ): array {
		$role = sanitize_key( $role );
		$role_map = array(
			'hero' => array( 'hero', 'section', 'content' ),
			'features' => array( 'feature-grid', 'section', 'content' ),
			'content' => array( 'content', 'section' ),
			'cta' => array( 'cta', 'section' ),
			'contact' => array( 'form', 'cta', 'section' ),
		);
		$roles = $role_map[$role] ?? array( $role, 'section', 'content' );

		foreach( self::patterns() as $pattern ) {
			$pattern_roles = is_array( $pattern['ai']['roles'] ?? null ) ? $pattern['ai']['roles'] : array();
			if( ! empty( array_intersect( $roles, $pattern_roles ) ) ) {
				return $pattern;
			}
		}

		return array();
	}

	/**
	 * Return the available website planner section library entries.
	 *
	 * @return array Return the available website planner section library entries.
	 */

	protected static function patterns(): array {
		static $patterns = null;

		if( $patterns !== null ) {
			return $patterns;
		}

		$patterns = function_exists( 'wphave_ai_block_pattern_collection' ) ? wphave_ai_block_pattern_collection() : array();

		return is_array( $patterns ) ? $patterns : array();
	}

	/**
	 * Render pattern content.
	 *
	 * @param array $pattern Pattern.
	 * @param array $slots Slots.
	 * @param string $fallback Fallback.
	 * @return string Render pattern content.
	 */

	protected static function render_pattern_content( array $pattern, array $slots, string $fallback = '' ): string {
		$key = sanitize_key( (string) ( $pattern['key'] ?? '' ) );
		$tags = array_values( array_filter( array_map( 'sanitize_key', (array) ( $pattern['tags'] ?? array() ) ) ) );

		if( $key && in_array( 'hero', $tags, true ) && function_exists( 'wphave_block_pattern_collection_hero' ) ) {
			foreach( wphave_block_pattern_collection_hero( array( 'slots' => $slots ) ) as $hero_pattern ) {
				if( sanitize_key( (string) ( $hero_pattern['key'] ?? '' ) ) === $key ) {
					return trim( (string) ( $hero_pattern['content'] ?? '' ) );
				}
			}
		}

		return $fallback;
	}

	/**
	 * Wrap planner section.
	 *
	 * @param string $content Content to process.
	 * @param array $section Section.
	 * @param int $index Index.
	 * @return string Wrap planner section.
	 */

	protected static function wrap_planner_section( string $content, array $section, int $index ): string {
		$attributes = array(
			'wphave' => array(
				'planner' => array(
					'sectionId' => $section['id'] ?: 'pattern-section-' . ( $index + 1 ),
					'sectionType' => $section['type'] ?? 'content',
					'sectionIndex' => $index,
					'patternKey' => $section['patternKey'] ?? '',
				),
			),
		);

		return '<!-- wp:wphave/group ' . wp_json_encode( $attributes, JSON_UNESCAPED_UNICODE ) . ' -->' . "\n" . $content . "\n" . '<!-- /wp:wphave/group -->';
	}

}
