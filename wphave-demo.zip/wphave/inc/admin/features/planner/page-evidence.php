<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Scope confirmed Planner facts to one sitemap page.
 * Editorial sitemap descriptions never become evidence.
 */
class WPHAVE_Website_Plan_Page_Evidence {

	public static function sanitize_page_facts( $page_facts ): array {
		$result = array();
		foreach( (array) $page_facts as $slug => $facts ) {
			if( ! is_string( $slug ) || ! is_string( $facts ) || count( $result ) >= 30 ) {
				continue;
			}
			$normalized_slug = sanitize_title( $slug );
			$normalized_facts = trim(
				mb_substr(
					sanitize_textarea_field( $facts ),
					0,
					2400
				)
			);
			if( $normalized_slug !== $slug || $normalized_facts === '' ) {
				continue;
			}
			$result[$slug] = $normalized_facts;
		}

		return $result;
	}

	public static function for_page( array $brief, string $slug, array $sitemap_pages ): array {
		$page_facts = self::sanitize_page_facts( $brief['pageFactsBySlug'] ?? array() );
		unset( $brief['pageFactsBySlug'], $brief['priorPageFacts'] );
		$global_facts = is_string( $brief['facts'] ?? null ) ? $brief['facts'] : '';
		$brief['facts'] = trim(
			mb_substr(
				sanitize_textarea_field( $global_facts ),
				0,
				2400
			)
		);

		if( ! in_array( $slug, array_column( $sitemap_pages, 'slug' ), true ) || ! isset( $page_facts[$slug] ) ) {
			return $brief;
		}

		$brief['facts'] = trim(
			implode(
				"\n",
				array_filter( array( $brief['facts'], $page_facts[$slug] ) )
			)
		);
		return $brief;
	}
}
