<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stores Website Planner projects as private WordPress documents.
 */

class WPHAVE_Website_Plans {

	public const POST_TYPE = 'wphave-website-plan';
	public const REST_NAMESPACE = 'wphave/v1';
	public const META_PAYLOAD = '_wphave_website_plan_payload';
	public const META_STATUS = '_wphave_website_plan_status';
	private const META_CREATE_TRANSACTION = '_wphave_website_plan_create_transaction';

	/**
	 * Initialize the website plans feature.
	 *
	 * @return void
	 */

	public static function init(): void {
		add_action( 'init', array( __CLASS__, 'register_post_type' ), 8 );
		add_action( 'rest_api_init', array( __CLASS__, 'register_rest_routes' ) );
		add_filter( 'wphave_site_composition_items', array( __CLASS__, 'add_composition_items' ) );
	}

	/**
	 * Register post type.
	 *
	 * @return void
	 */

	public static function register_post_type(): void {
		register_post_type( self::POST_TYPE, array(
			'labels' => array(
				'name' => __( 'Website Plans', 'wphave' ),
				'singular_name' => __( 'Website Plan', 'wphave' ),
			),
			'public' => false,
			'publicly_queryable' => false,
			'exclude_from_search' => true,
			'show_ui' => false,
			'show_in_menu' => false,
			'show_in_rest' => false,
			'hierarchical' => false,
			'supports' => array( 'title', 'author', 'revisions' ),
			'capability_type' => 'post',
			'map_meta_cap' => true,
			'rewrite' => false,
			'query_var' => false,
		) );

		register_post_meta( self::POST_TYPE, self::META_PAYLOAD, array(
			'type' => 'object',
			'single' => true,
			'default' => array(),
			'sanitize_callback' => array( 'WPHAVE_Website_Plan_Schema', 'payload' ),
			'auth_callback' => '__return_false',
		) );

		register_post_meta( self::POST_TYPE, self::META_STATUS, array(
			'type' => 'string',
			'single' => true,
			'default' => 'planning',
			'sanitize_callback' => array( 'WPHAVE_Website_Plan_Schema', 'status' ),
			'auth_callback' => '__return_false',
		) );
	}

	/**
	 * Register the website plans REST routes.
	 *
	 * @return void
	 */

	public static function register_rest_routes(): void {
		register_rest_route( self::REST_NAMESPACE, '/website-plans', array(
			'methods' => 'GET',
			'callback' => array( __CLASS__, 'rest_list' ),
			'permission_callback' => array( __CLASS__, 'can_read' ),
		) );

		register_rest_route( self::REST_NAMESPACE, '/website-plans', array(
			'methods' => 'POST',
			'callback' => array( __CLASS__, 'rest_create' ),
			'permission_callback' => array( __CLASS__, 'can_write' ),
		) );

		register_rest_route( self::REST_NAMESPACE, '/website-plans/(?P<id>\d+)', array(
			'methods' => 'GET',
			'callback' => array( __CLASS__, 'rest_get' ),
			'permission_callback' => array( __CLASS__, 'can_read' ),
		) );

		register_rest_route( self::REST_NAMESPACE, '/website-plans/(?P<id>\d+)', array(
			'methods' => 'PUT',
			'callback' => array( __CLASS__, 'rest_update' ),
			'permission_callback' => array( __CLASS__, 'can_write' ),
		) );

		register_rest_route( self::REST_NAMESPACE, '/website-plans/(?P<id>\d+)', array(
			'methods' => 'DELETE',
			'callback' => array( __CLASS__, 'rest_delete' ),
			'permission_callback' => array( __CLASS__, 'can_write' ),
		) );

	}

	/**
	 * Determine whether the current user can read.
	 *
	 * @return bool Determine whether the current user can read.
	 */

	public static function can_read(): bool {
		return current_user_can( 'wphave_manage_website_planner' ) || current_user_can( 'wphave_manage_options' ) || current_user_can( 'manage_options' );
	}

	/**
	 * Determine whether the current user can write.
	 *
	 * @return bool Determine whether the current user can write.
	 */

	public static function can_write(): bool {
		// AUTHORIZATION INVARIANT: Website Plans are a shared planning domain rather
		// than author-owned posts. Their dedicated management capability intentionally
		// governs every plan write and cannot be inferred from generic post editing.
		return current_user_can( 'wphave_manage_website_planner' ) || current_user_can( 'wphave_manage_options' ) || current_user_can( 'manage_options' );
	}

	private static function require_read() {
		// AUTHORIZATION INVARIANT: Planner callbacks expose shared private project
		// data. REST permissions are an early dispatch gate, so every public read
		// repeats the canonical Planner capability before querying stored plans.
		if ( ! self::can_read() ) {
			return new WP_Error(
				'wphave_website_plans_read_forbidden',
				__( 'You are not allowed to view website plans.', 'wphave' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	private static function require_write() {
		// AUTHORIZATION INVARIANT: Shared Plan creation, update and deletion never
		// inherit authority from a REST route or generic post editing. Repeat the
		// dedicated site-wide Planner policy immediately before the operation.
		if ( ! self::can_write() ) {
			return new WP_Error(
				'wphave_website_plans_write_forbidden',
				__( 'You are not allowed to manage website plans.', 'wphave' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Handle the list REST request.
	 *
	 * @param WP_REST_Request $request REST request.
	 */

	public static function rest_list( WP_REST_Request $request ) {
		$authorization = self::require_read();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		return rest_ensure_response( array(
			'items' => self::all_plans( min( 100, max( 1, absint( $request->get_param( 'per_page' ) ) ?: 50 ) ) ),
		) );
	}

	/**
	 * Handle the create REST request.
	 *
	 * @param WP_REST_Request $request REST request.
	 */

	public static function rest_create( WP_REST_Request $request ) {
		$authorization = self::require_write();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$params = self::request_params( $request );
		$payload = WPHAVE_Website_Plan_Schema::migrate( $params['payload'] ?? array() );
		if( is_wp_error( $payload ) ) return $payload;
		$payload = WPHAVE_Website_Plan_Schema::payload( $payload );
		$title = WPHAVE_Website_Plan_Schema::title( $params['title'] ?? $payload['brief']['projectName'] ?? __( 'Untitled website plan', 'wphave' ) );
		$status = WPHAVE_Website_Plan_Schema::status( $params['status'] ?? $payload['status'] ?? 'planning' );
		// CREATE AUTHORIZATION INVARIANT: Schema migration and title/status
		// normalization are extensible. Recheck authority before the insert.
		$authorization = self::require_write();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}
		$plan = self::create_plan( $title, $payload, $status );

		if( is_wp_error( $plan ) ) {
			return $plan;
		}

		return rest_ensure_response( array(
			'item' => $plan,
		) );
	}

	/**
	 * Handle the get REST request.
	 *
	 * @param WP_REST_Request $request REST request.
	 */

	public static function rest_get( WP_REST_Request $request ) {
		$authorization = self::require_read();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$post = self::get_plan_post( absint( $request['id'] ) );

		if( is_wp_error( $post ) ) {
			return $post;
		}

		return rest_ensure_response( array(
			'item' => self::prepare_plan( $post ),
		) );
	}

	/**
	 * Handle the update REST request.
	 *
	 * @param WP_REST_Request $request REST request.
	 */

	public static function rest_update( WP_REST_Request $request ) {
		$authorization = self::require_write();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$post = self::get_plan_post( absint( $request['id'] ) );

		if( is_wp_error( $post ) ) {
			return $post;
		}

		$params = self::request_params( $request );
		$current_payload = self::plan_payload( $post->ID );
		if( is_wp_error( $current_payload ) ) return $current_payload;
		$current_title = $post->post_title;
		$current_status = self::plan_status( $post->ID );
		$payload = array_key_exists( 'payload', $params ) ? WPHAVE_Website_Plan_Schema::migrate( $params['payload'] ) : $current_payload;
		if( is_wp_error( $payload ) ) return $payload;
		$payload = WPHAVE_Website_Plan_Schema::payload( $payload );
		$title = array_key_exists( 'title', $params ) ? WPHAVE_Website_Plan_Schema::title( $params['title'] ) : $post->post_title;
		$status = WPHAVE_Website_Plan_Schema::status( $params['status'] ?? $payload['status'] ?? self::plan_status( $post->ID ) );
		// UPDATE AUTHORIZATION INVARIANT: A plan may be changed only while
		// write authority still holds after filterable schema normalization.
		$authorization = self::require_write();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}
		$updated = wp_update_post( array(
			'ID' => $post->ID,
			'post_title' => $title,
		), true );

		if( is_wp_error( $updated ) ) {
			return $updated;
		}

		$payload_saved = self::store_meta_exact( $post->ID, self::META_PAYLOAD, $payload );
		$status_saved = self::store_meta_exact( $post->ID, self::META_STATUS, $status );

		// DATA/ROLLBACK INVARIANT: Title, payload and status form one Plan update.
		// If any store rejects the requested state, restore all previously confirmed
		// values before returning failure so shared consumers never see a torn Plan.
		if (
			(int) $updated !== (int) $post->ID
			|| $title !== get_post_field( 'post_title', $post->ID )
			|| ! $payload_saved
			|| ! $status_saved
		) {
			wp_update_post( array( 'ID' => $post->ID, 'post_title' => $current_title ) );
			self::store_meta_exact( $post->ID, self::META_PAYLOAD, $current_payload );
			self::store_meta_exact( $post->ID, self::META_STATUS, $current_status );

			return new WP_Error(
				'wphave_website_plan_write_failed',
				__( 'Website plan could not be saved.', 'wphave' ),
				array( 'status' => 500 )
			);
		}

		return rest_ensure_response( array(
			'item' => self::prepare_plan( get_post( $post->ID ) ),
		) );
	}

	/**
	 * Handle the delete REST request.
	 *
	 * @param WP_REST_Request $request REST request.
	 */

	public static function rest_delete( WP_REST_Request $request ) {
		$authorization = self::require_write();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}

		$post = self::get_plan_post( absint( $request['id'] ) );

		if( is_wp_error( $post ) ) {
			return $post;
		}

		// DELETE AUTHORIZATION INVARIANT: Resolve the exact plan before the
		// final capability check immediately preceding the trash mutation.
		$authorization = self::require_write();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}
		$deleted = wp_trash_post( $post->ID );

		if( ! $deleted ) {
			return new WP_Error( 'wphave_website_plan_delete_failed', __( 'Website plan could not be deleted.', 'wphave' ), array( 'status' => 500 ) );
		}

		return rest_ensure_response( array(
			'deleted' => true,
			'id' => $post->ID,
		) );
	}

	/**
	 * Prepare plan.
	 *
	 * @param mixed $post Post.
	 * @return array Prepare plan.
	 */

	public static function prepare_plan( $post ): array {
		$post = $post instanceof WP_Post ? $post : get_post( $post );

		if( ! $post ) {
			return array();
		}

		$payload = self::plan_payload( $post->ID );
		if( is_wp_error( $payload ) ) $payload = array();
		$status = self::plan_status( $post->ID );

		return array(
			'id' => $post->ID,
			'title' => get_the_title( $post ),
			'status' => $status,
			'payload' => $payload,
			'createdAt' => mysql_to_rfc3339( $post->post_date_gmt ?: $post->post_date ),
			'modifiedAt' => mysql_to_rfc3339( $post->post_modified_gmt ?: $post->post_modified ),
			'author' => absint( $post->post_author ),
		);
	}

	/**
	 * All plans.
	 *
	 * @param int $limit Limit.
	 * @return array All plans.
	 */

	public static function all_plans( int $limit = 50 ): array {
		return array_merge(
			self::saved_plans( $limit ),
			WPHAVE_Website_Plan_Builtins::all()
		);
	}

	/**
	 * Saved plans.
	 *
	 * @param int $limit Limit.
	 * @return array Saved plans.
	 */

	public static function saved_plans( int $limit = 50 ): array {
		$posts = get_posts( array(
			'post_type' => self::POST_TYPE,
			'post_status' => array( 'draft', 'publish', 'private' ),
			'posts_per_page' => min( 100, max( 1, $limit ) ),
			'orderby' => 'modified',
			'order' => 'DESC',
		) );

		return array_map( array( __CLASS__, 'prepare_plan' ), $posts );
	}

	/**
	 * Composition items.
	 *
	 * @return array Composition items.
	 */

	public static function composition_items(): array {
		$items = array();

		foreach( self::saved_plans( 100 ) as $plan ) {
			$composition = WPHAVE_Website_Plan_Composition_Adapter::from_plan( $plan );

			if( $composition ) {
				$items[$composition['id']] = $composition;
			}
		}

		return $items;
	}

	/**
	 * Add saved Planner projects as an optional Site Composition source.
	 *
	 * Bundled and captured compositions remain owned by the composition domain.
	 * This one-way provider keeps Planner removable without affecting them.
	 *
	 * @param array $items Registered composition items.
	 * @return array Composition items with saved Planner projects.
	 */

	public static function add_composition_items( array $items ): array {
		return array_merge( $items, self::composition_items() );
	}

	/**
	 * Create plan.
	 *
	 * @param string $title Title.
	 * @param array $payload Payload.
	 * @param string $status Status.
	 */

	public static function create_plan( string $title, array $payload, string $status = 'planning' ) {
		$payload = WPHAVE_Website_Plan_Schema::migrate( $payload );
		if( is_wp_error( $payload ) ) return $payload;
		$payload = WPHAVE_Website_Plan_Schema::payload( $payload );
		$status = WPHAVE_Website_Plan_Schema::status( $status ?: ( $payload['status'] ?? 'planning' ) );
		$author_id = get_current_user_id();
		$create_token = wp_generate_uuid4();
		$post_title = WPHAVE_Website_Plan_Schema::title( $title );
		// CREATE AUTHORIZATION INVARIANT: The repository normalizes the title
		// once more before insertion. That final filterable step cannot outlive
		// the caller's Planner write authority.
		$authorization = self::require_write();
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}
		$post_id = wp_insert_post( array(
			'post_type' => self::POST_TYPE,
			'post_status' => 'draft',
			'post_title' => $post_title,
			'post_author' => $author_id,
			'meta_input' => array( self::META_CREATE_TRANSACTION => $create_token ),
		), true );

		if( is_wp_error( $post_id ) ) {
			return $post_id;
		}
		if ( ! hash_equals( $create_token, (string) get_post_meta( $post_id, self::META_CREATE_TRANSACTION, true ) ) ) {
			// No persisted owner marker means this ID cannot authorize rollback.
			return new WP_Error( 'wphave_website_plan_write_failed', __( 'Website plan could not be saved.', 'wphave' ), array( 'status' => 500 ) );
		}
		$created_post = get_post( $post_id );
		$created_post = $created_post instanceof WP_Post ? clone $created_post : null;

		$payload_saved = self::store_meta_exact( $post_id, self::META_PAYLOAD, $payload );
		$status_saved = self::store_meta_exact( $post_id, self::META_STATUS, $status );

		// DATA/COMMIT INVARIANT: A new Plan exists only when its canonical payload
		// and lifecycle status both persist and read back exactly. A partial create
		// never enters shared Planner lists or Site Composition discovery.
		if (
			! $payload_saved
			|| ! $status_saved
		) {
			self::rollback_created_plan( (int) $post_id, $create_token, $created_post );

			return new WP_Error(
				'wphave_website_plan_write_failed',
				__( 'Website plan could not be saved.', 'wphave' ),
				array( 'status' => 500 )
			);
		}
		delete_post_meta( $post_id, self::META_CREATE_TRANSACTION );

		return self::prepare_plan( get_post( $post_id ) );
	}

	/** Roll back only the unchanged draft created by this Plan transaction. */
	private static function rollback_created_plan( int $post_id, string $token, ?WP_Post $expected ): void {
		$post = get_post( $post_id );
		// ROLLBACK INVARIANT: Failed metadata persistence does not grant deletion
		// authority over a repurposed, published or concurrently edited post.
		if (
			! $post instanceof WP_Post
			|| ! $expected instanceof WP_Post
			|| self::POST_TYPE !== $post->post_type
			|| 'draft' !== $post->post_status
			|| $expected->post_author !== $post->post_author
			|| $expected->post_title !== $post->post_title
			|| $expected->post_content !== $post->post_content
			|| $expected->post_name !== $post->post_name
			|| ! hash_equals( $token, (string) get_post_meta( $post_id, self::META_CREATE_TRANSACTION, true ) )
		) {
			return;
		}

		wp_delete_post( $post_id, true );
	}

	/** Persist one canonical Plan meta value and verify its exact stored state. */

	private static function store_meta_exact( int $post_id, string $meta_key, $value ): bool {
		update_post_meta( $post_id, $meta_key, $value );

		return $value === get_post_meta( $post_id, $meta_key, true );
	}

	/**
	 * Request params.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @return array Request params.
	 */

	protected static function request_params( WP_REST_Request $request ): array {
		$params = $request->get_json_params();

		return is_array( $params ) ? $params : array();
	}

	/**
	 * Return plan post.
	 *
	 * @param int $id Id.
	 */

	protected static function get_plan_post( int $id ) {
		$post = get_post( $id );

		if( ! $post || $post->post_type !== self::POST_TYPE || $post->post_status === 'trash' ) {
			return new WP_Error( 'wphave_website_plan_not_found', __( 'Website plan not found.', 'wphave' ), array( 'status' => 404 ) );
		}

		return $post;
	}

	/**
	 * Plan payload.
	 *
	 * @param int $post_id Post ID.
	 * @return array|WP_Error Plan payload or an unsupported-schema error.
	 */

	protected static function plan_payload( int $post_id ) {
		$payload = get_post_meta( $post_id, self::META_PAYLOAD, true );
		$payload = WPHAVE_Website_Plan_Schema::migrate( is_array( $payload ) ? $payload : array() );

		return is_wp_error( $payload ) ? $payload : WPHAVE_Website_Plan_Schema::payload( $payload );
	}

	/**
	 * Plan status.
	 *
	 * @param int $post_id Post ID.
	 * @return string Plan status.
	 */

	protected static function plan_status( int $post_id ): string {
		return WPHAVE_Website_Plan_Schema::status( get_post_meta( $post_id, self::META_STATUS, true ) ?: 'planning' );
	}

}

WPHAVE_Website_Plans::init();
