<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Resolve one selected WordPress image into design-only planning context.
 * Attachment text is intentionally excluded: media metadata is not business evidence.
 */
final class WPHAVE_Website_Plan_Page_Media_Context {
	public static function resolve( $raw_id ): array|WP_Error {
		if( $raw_id === null || $raw_id === 0 || $raw_id === '0' ) {
			return array();
		}

		$id = filter_var( $raw_id, FILTER_VALIDATE_INT, array( 'options' => array( 'min_range' => 1 ) ) );
		if( $id === false ) {
			return self::invalid_media();
		}

		$attachment = get_post( $id );
		if( ! $attachment || $attachment->post_type !== 'attachment' || ! wp_attachment_is_image( $id ) || ! current_user_can( 'read_post', $id ) ) {
			return self::invalid_media();
		}

		$metadata = wp_get_attachment_metadata( $id );
		$width = is_array( $metadata ) ? (int) ( $metadata['width'] ?? 0 ) : 0;
		$height = is_array( $metadata ) ? (int) ( $metadata['height'] ?? 0 ) : 0;
		if( $width < 1 || $height < 1 ) {
			return self::invalid_media();
		}

		return array(
			'attachmentId' => $id,
			'width' => $width,
			'height' => $height,
			'aspectRatio' => round( $width / $height, 3 ),
		);
	}

	private static function invalid_media(): WP_Error {
		return new WP_Error(
			'ai_website_target_media_invalid',
			__( 'The selected page image is unavailable. Choose another image for this page.', 'wphave' ),
			array( 'status' => 400 )
		);
	}
}
