<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Website_Plan_AI_AST {

/**
	 * Ensure page plan ast.
	 *
	 * @param array $plan Plan.
	 * @param array $sitemap_page Sitemap page.
	 * @param int $index Index.
	 * @return array Ensure page plan ast.
	 */

	protected static function ensure_page_plan_ast( array $plan, array $sitemap_page, int $index ): array {
		$sections = is_array( $plan['sections'] ?? null ) ? $plan['sections'] : array();
		if( empty( $sections ) ) {
			$sections = is_array( $sitemap_page['sections'] ?? null ) ? $sitemap_page['sections'] : array();
		}

		$block_tree = self::extract_block_tree_from_plan( $plan );
		if( ! empty( $block_tree ) ) {
			$plan['blockTree'] = $block_tree;

			return $plan;
		}

		if( empty( $plan['ast']['nodes'] ) || ! is_array( $plan['ast']['nodes'] ) ) {
			$plan['ast'] = self::sections_to_ast( $sections, $sitemap_page, $plan, $index );
			$plan['plannerDiagnostics'][] = 'ast_built_from_sections';
		}

		if( self::ast_needs_normalization( $plan['ast'], $plan ) ) {
			$plan['ast'] = self::composed_page_ast( $sections, $sitemap_page, $plan, $index );
			$plan['plannerDiagnostics'][] = 'ast_normalized';
		}

		return $plan;
	}

/**
	 * Sections to ast.
	 *
	 * @param array $sections Sections.
	 * @param array $page Page.
	 * @param array $plan Plan.
	 * @param int $page_index Page index.
	 * @return array Sections to ast.
	 */

	protected static function sections_to_ast( array $sections, array $page, array $plan, int $page_index ): array {
		return self::composed_page_ast( $sections, $page, $plan, $page_index );
	}

/**
	 * Ast needs normalization.
	 *
	 * @param array $ast Ast.
	 * @param array $plan Plan.
	 * @return bool Ast needs normalization.
	 */

	protected static function ast_needs_normalization( array $ast, array $plan ): bool {
		$nodes = is_array( $ast['nodes'] ?? null ) ? array_values( array_filter( $ast['nodes'], 'is_array' ) ) : array();
		if( count( $nodes ) < 3 ) {
			return true;
		}

		$layout_types = array();
		$kinds = array();
		$headings = array();
		$nested_count = 0;
		$generic_count = 0;

		foreach( $nodes as $node ) {
			$kind = sanitize_key( $node['kind'] ?? '' );
			$layout = sanitize_key( $node['layout']['type'] ?? '' );
			$heading = strtolower( trim( sanitize_text_field( (string) ( $node['slots']['heading'] ?? $node['heading'] ?? '' ) ) ) );
			$kinds[$kind] = true;
			$layout_types[$layout ?: $kind] = true;
			$nested_count += is_array( $node['nodes'] ?? null ) ? count( $node['nodes'] ) : 0;

			if( $heading !== '' ) {
				$headings[] = $heading;
			}

			if( preg_match( '/^(hero header section|content|section|clarity|trust|action|context|perspective|evidence|point \d+)$/i', $heading ) ) {
				$generic_count++;
			}
		}

		if( count( $layout_types ) < 3 || ( $nested_count === 0 && ! isset( $kinds['notification'] ) && ! isset( $kinds['stats'] ) && ! isset( $kinds['tabs'] ) ) ) {
			return true;
		}

		if( $generic_count > 0 ) {
			return true;
		}

		$unique_headings = array_unique( $headings );
		if( count( $headings ) > 3 && count( $unique_headings ) < count( $headings ) ) {
			return true;
		}

		$sections = is_array( $plan['sections'] ?? null ) ? $plan['sections'] : array();
		return ! empty( $sections ) && count( $unique_headings ) < min( 3, count( $sections ) );
	}

/**
	 * Composed page ast.
	 *
	 * @param array $sections Sections.
	 * @param array $page Page.
	 * @param array $plan Plan.
	 * @param int $page_index Page index.
	 * @return array Composed page ast.
	 */

	protected static function composed_page_ast( array $sections, array $page, array $plan, int $page_index ): array {
		$title = self::clean_ast_text( $page['title'] ?? $plan['summary'] ?? 'Page', 'Page' );
		$intent = self::clean_ast_text( $plan['intent'] ?? $page['intent'] ?? $page['description'] ?? '', '' );
		$source_sections = self::ast_source_sections( $sections, $page, $plan );
		$page_type = self::page_type_from_context( $title, $page['slug'] ?? '', $intent );
		$hero = self::ast_hero_node( $title, $intent, $source_sections, $page_type, $page_index );
		$nodes = array( $hero );
		$body_sections = array_slice( $source_sections, 0, $page_index === 0 ? 5 : 4 );

		if( $page_type === 'contact' ) {
			$nodes[] = self::ast_notification_node(
				self::clean_ast_text( $body_sections[0]['title'] ?? __( 'Fast response', 'wphave' ), __( 'Fast response', 'wphave' ) ),
				self::clean_ast_text( $body_sections[0]['description'] ?? __( 'Give visitors a clear way to contact the team and understand what happens next.', 'wphave' ), '' ),
				'primary'
			);
			$nodes[] = self::ast_split_node( $body_sections[1] ?? null, __( 'Contact options', 'wphave' ), __( 'Show the most useful ways to get in touch, ask questions or plan the next step.', 'wphave' ), 'paper', 2 );
			$nodes[] = self::ast_grid_node( __( 'Before you reach out', 'wphave' ), __( 'Help visitors prepare with the details that make the conversation easier.', 'wphave' ), array_slice( $body_sections, 2, 3 ), 'neutral', 2 );
		} elseif( $page_type === 'admissions' || $page_type === 'process' ) {
			$nodes[] = self::ast_grid_node( __( 'How it works', 'wphave' ), $intent, array_slice( $body_sections, 0, 4 ), 'paper', 3 );
			$nodes[] = self::ast_notification_node( __( 'Helpful to know', 'wphave' ), self::clean_ast_text( $body_sections[1]['description'] ?? $intent, __( 'Make expectations clear before visitors take the next step.', 'wphave' ) ), 'success' );
			$nodes[] = self::ast_split_node( $body_sections[2] ?? null, __( 'What happens next', 'wphave' ), __( 'Turn the process into a clear, confident next action.', 'wphave' ), 'primary', 3 );
		} elseif( $page_type === 'programs' || $page_type === 'services' ) {
			$nodes[] = self::ast_grid_node( __( 'What is included', 'wphave' ), $intent, array_slice( $body_sections, 0, 4 ), 'paper', 3 );
			$nodes[] = self::ast_split_node( $body_sections[1] ?? null, __( 'The right fit', 'wphave' ), __( 'Give visitors enough detail to compare options and understand which path makes sense for them.', 'wphave' ), 'neutral', 2 );
			$nodes[] = self::ast_grid_node( __( 'Details that matter', 'wphave' ), __( 'Add practical context without repeating the page introduction.', 'wphave' ), array_slice( $body_sections, 2, 3 ), 'accent', 2 );
		} elseif( $page_type === 'about' ) {
			$nodes[] = self::ast_split_node( $body_sections[0] ?? null, __( 'The story behind the work', 'wphave' ), $intent, 'paper', 2 );
			$nodes[] = self::ast_grid_node( __( 'What shapes the experience', 'wphave' ), __( 'Show the values, standards and details visitors can expect.', 'wphave' ), array_slice( $body_sections, 1, 3 ), 'neutral', 3 );
			$nodes[] = self::ast_split_node( $body_sections[3] ?? null, __( 'People and standards', 'wphave' ), __( 'Make the organization feel tangible and trustworthy.', 'wphave' ), 'primary', 3 );
		} else {
			$nodes[] = self::ast_grid_node( __( 'Explore the essentials', 'wphave' ), $intent, array_slice( $body_sections, 0, 4 ), 'paper', 3 );
			$nodes[] = self::ast_split_node( $body_sections[1] ?? null, __( 'Why it matters', 'wphave' ), __( 'Connect the offer to the visitor’s real situation and next decision.', 'wphave' ), 'neutral', 2 );
			$nodes[] = self::ast_grid_node( __( 'More reasons to continue', 'wphave' ), __( 'Give visitors supporting proof and useful detail without repeating the hero.', 'wphave' ), array_slice( $body_sections, 2, 3 ), 'accent', 2 );
		}

		if( $page_index === 0 ) {
			$nodes[] = self::ast_split_node( $body_sections[4] ?? null, __( 'Ready for the next step', 'wphave' ), __( 'Guide visitors from interest into a clear action.', 'wphave' ), 'dark', 4, __( 'Start the conversation', 'wphave' ) );
		}

		return array(
			'kind' => 'page',
			'intent' => $intent,
			'nodes' => array_values( array_filter( $nodes ) ),
		);
	}

/**
	 * Ast source sections.
	 *
	 * @param array $sections Sections.
	 * @param array $page Page.
	 * @param array $plan Plan.
	 * @return array Ast source sections.
	 */

	protected static function ast_source_sections( array $sections, array $page, array $plan ): array {
		$candidates = ! empty( $sections ) ? $sections : ( is_array( $page['sections'] ?? null ) ? $page['sections'] : array() );
		$output = array();
		$seen = array();

		foreach( $candidates as $section ) {
			if( ! is_array( $section ) ) {
				continue;
			}

			$title = self::clean_ast_text( $section['heading'] ?? $section['title'] ?? '', '' );
			$description = self::clean_ast_text( $section['body'] ?? $section['description'] ?? '', '' );
			if( $title === '' || preg_match( '/^(navbar|footer|hero header section)$/i', $title ) ) {
				continue;
			}

			$key = strtolower( $title . '|' . mb_substr( $description, 0, 80 ) );
			if( isset( $seen[$key] ) ) {
				continue;
			}

			$seen[$key] = true;
			$output[] = array(
				'title' => $title,
				'description' => $description,
				'items' => self::section_items_to_ast_items( $section['items'] ?? array() ),
			);
		}

		if( empty( $output ) ) {
			$output[] = array(
				'title' => self::clean_ast_text( $page['title'] ?? __( 'Overview', 'wphave' ), __( 'Overview', 'wphave' ) ),
				'description' => self::clean_ast_text( $plan['intent'] ?? $page['description'] ?? '', __( 'Introduce the most important information for this page.', 'wphave' ) ),
				'items' => array(),
			);
		}

		return $output;
	}

/**
	 * Ast hero node.
	 *
	 * @param string $title Title.
	 * @param string $intent Intent.
	 * @param array $sections Sections.
	 * @param string $page_type Page type.
	 * @param int $page_index Page index.
	 * @return array Ast hero node.
	 */

	protected static function ast_hero_node( string $title, string $intent, array $sections, string $page_type, int $page_index ): array {
		$lead = $intent ?: self::clean_ast_text( $sections[0]['description'] ?? '', __( 'Give visitors a clear first impression and a reason to continue.', 'wphave' ) );
		$heading = $title;
		if( $page_index === 0 && preg_match( '/^(home|start|startseite)$/i', $title ) ) {
			$heading = self::clean_ast_text( $sections[0]['title'] ?? '', $title );
		}

		$action = $page_type === 'contact' ? __( 'Get in touch', 'wphave' ) : ( $page_type === 'admissions' ? __( 'Start application', 'wphave' ) : __( 'Get started', 'wphave' ) );

		return array(
			'kind' => 'hero',
			'id' => 'hero',
			'tone' => $page_index === 0 ? 'primary' : 'neutral',
			'emphasis' => 'high',
			'layout' => array(
				'type' => $page_index === 0 || in_array( $page_type, array( 'services', 'programs' ), true ) ? 'split' : 'centered',
				'gap' => '3xl',
			),
			'slots' => array(
				'eyebrow' => $page_index === 0 ? __( 'Welcome', 'wphave' ) : $title,
				'heading' => $heading,
				'lead' => $lead,
				'actions' => array(
					array(
						'label' => $action,
						'variant' => 'primary',
					),
				),
			),
		);
	}

/**
	 * Ast grid node.
	 *
	 * @param string $heading Heading.
	 * @param string $lead Lead.
	 * @param array $sections Sections.
	 * @param string $tone Tone.
	 * @param int $columns Columns.
	 * @return array Ast grid node.
	 */

	protected static function ast_grid_node( string $heading, string $lead, array $sections, string $tone, int $columns ): array {
		$items = self::ast_items_from_sections( $sections, $columns + 1 );

		return array(
			'kind' => 'section',
			'id' => sanitize_key( $heading ),
			'tone' => $tone,
			'emphasis' => $tone === 'accent' ? 'high' : 'medium',
			'layout' => array(
				'type' => 'grid',
				'columns' => $columns,
				'gap' => 'l',
			),
			'slots' => array(
				'eyebrow' => __( 'Section', 'wphave' ),
				'heading' => $heading,
				'lead' => $lead,
				'items' => $items,
			),
		);
	}

/**
	 * Ast split node.
	 *
	 * @param mixed $section Section.
	 * @param string $heading Heading.
	 * @param string $lead Lead.
	 * @param string $tone Tone.
	 * @param int $index Index.
	 * @param string $button Button.
	 * @return array Ast split node.
	 */

	protected static function ast_split_node( $section, string $heading, string $lead, string $tone, int $index, string $button = '' ): array {
		$section = is_array( $section ) ? $section : array();
		$section_heading = self::clean_ast_text( $section['title'] ?? '', $heading );
		$section_text = self::clean_ast_text( $section['description'] ?? '', $lead );

		return array(
			'kind' => 'section',
			'id' => sanitize_key( $section_heading . '-' . $index ),
			'tone' => $tone,
			'emphasis' => $tone === 'dark' ? 'high' : 'medium',
			'layout' => array(
				'type' => 'split',
				'gap' => '3xl',
			),
			'slots' => array_filter( array(
				'eyebrow' => $section_heading,
				'heading' => $heading,
				'lead' => $section_text,
				'button' => $button,
			) ),
		);
	}

/**
	 * Ast notification node.
	 *
	 * @param string $heading Heading.
	 * @param string $text Text.
	 * @param string $tone Tone.
	 * @return array Ast notification node.
	 */

	protected static function ast_notification_node( string $heading, string $text, string $tone ): array {
		return array(
			'kind' => 'section',
			'id' => sanitize_key( $heading ),
			'tone' => 'neutral',
			'emphasis' => 'low',
			'layout' => array(
				'type' => 'stack',
				'gap' => 'm',
			),
			'nodes' => array(
				array(
					'kind' => 'notification',
					'tone' => $tone,
					'slots' => array(
						'heading' => $heading,
						'text' => $text,
					),
				),
			),
		);
	}

/**
	 * Ast items from sections.
	 *
	 * @param array $sections Sections.
	 * @param int $count Count.
	 * @return array Ast items from sections.
	 */

	protected static function ast_items_from_sections( array $sections, int $count ): array {
		$items = array();

		foreach( array_slice( $sections, 0, max( 2, $count ) ) as $index => $section ) {
			if( ! is_array( $section ) ) {
				continue;
			}

			$items[] = array_filter( array(
				'heading' => self::clean_ast_text( $section['title'] ?? '', sprintf( __( 'Detail %d', 'wphave' ), $index + 1 ) ),
				'text' => self::clean_ast_text( $section['description'] ?? '', __( 'Add a focused detail that helps visitors understand this page.', 'wphave' ) ),
				'tone' => $index % 3 === 1 ? 'paper' : 'neutral',
			) );
		}

		return $items;
	}

/**
	 * Page type from context.
	 *
	 * @param string $title Title.
	 * @param string $slug Slug.
	 * @param string $intent Intent.
	 * @return string Page type from context.
	 */

	protected static function page_type_from_context( string $title, $slug, string $intent ): string {
		$value = strtolower( $title . ' ' . (string) $slug . ' ' . $intent );

		if( preg_match( '/contact|kontakt|touch|visit|besuch/', $value ) ) {
			return 'contact';
		}

		if( preg_match( '/admission|enrol|apply|anmeldung|bewerb|aufnahme/', $value ) ) {
			return 'admissions';
		}

		if( preg_match( '/program|service|leistung|angebot|kurs/', $value ) ) {
			return preg_match( '/program|kurs/', $value ) ? 'programs' : 'services';
		}

		if( preg_match( '/about|über|story|team|philosoph/', $value ) ) {
			return 'about';
		}

		if( preg_match( '/process|how|ablauf|schritte/', $value ) ) {
			return 'process';
		}

		return 'default';
	}

/**
	 * Clean ast text.
	 *
	 * @param mixed $value Value.
	 * @param string $fallback Fallback.
	 * @return string Clean ast text.
	 */

	protected static function clean_ast_text( $value, string $fallback ): string {
		$text = trim( sanitize_textarea_field( (string) $value ) );
		$text = preg_replace( '/\s+/', ' ', $text );

		if( $text === '' || preg_match( '/^(content|section|hero header section|point \d+|clarity|trust|action|context|perspective|evidence)$/i', $text ) ) {
			return $fallback;
		}

		return $text;
	}

/**
	 * Section to ast node.
	 *
	 * @param array $section Section.
	 * @param int $section_index Section index.
	 * @param int $page_index Page index.
	 * @return array Section to ast node.
	 */

	protected static function section_to_ast_node( array $section, int $section_index, int $page_index ): array {
		$type = sanitize_key( $section['type'] ?? 'content' );
		$archetype = sanitize_key( $section['archetype'] ?? '' );
		$layout = sanitize_key( $section['layout'] ?? '' );
		$treatment = sanitize_key( $section['treatment'] ?? '' );
		$heading = trim( sanitize_text_field( (string) ( $section['heading'] ?? $section['title'] ?? '' ) ) );
		$body = trim( sanitize_textarea_field( (string) ( $section['body'] ?? $section['description'] ?? '' ) ) );
		$eyebrow = trim( sanitize_text_field( (string) ( $section['eyebrow'] ?? $type ?: __( 'Section', 'wphave' ) ) ) );
		$items = self::section_items_to_ast_items( $section['items'] ?? array() );
		$actions = self::section_actions_to_ast_actions( $section['actions'] ?? array() );

		if( $type === 'hero' || $section_index === 0 ) {
			return array(
				'kind' => 'hero',
				'id' => sanitize_key( (string) ( $section['id'] ?? 'hero-' . ( $section_index + 1 ) ) ),
				'tone' => in_array( $treatment, array( 'dark', 'bold', 'glow' ), true ) ? 'dark' : ( $page_index === 0 ? 'primary' : 'neutral' ),
				'emphasis' => 'high',
				'layout' => array(
					'type' => $layout === 'centered' ? 'centered' : 'split',
					'gap' => '3xl',
				),
				'slots' => array_filter( array(
					'eyebrow' => $eyebrow,
					'heading' => $heading,
					'lead' => $body,
					'actions' => $actions,
					'button' => empty( $actions ) ? __( 'Get started', 'wphave' ) : '',
				) ),
			);
		}

		if( in_array( $type, array( 'features', 'offers' ), true ) || in_array( $layout, array( 'grid', 'bento', 'cards', 'masonry' ), true ) ) {
			return array(
				'kind' => 'section',
				'id' => sanitize_key( (string) ( $section['id'] ?? 'section-' . ( $section_index + 1 ) ) ),
				'tone' => $section_index % 2 ? 'neutral' : 'paper',
				'emphasis' => $archetype === 'bento-showcase' ? 'high' : 'medium',
				'layout' => array(
					'type' => 'grid',
					'columns' => min( 3, max( 2, count( $items ) ?: 3 ) ),
					'gap' => 'l',
				),
				'slots' => array_filter( array(
					'eyebrow' => $eyebrow,
					'heading' => $heading,
					'lead' => $body,
					'items' => $items,
					'actions' => $actions,
				) ),
			);
		}

		if( $type === 'steps' || in_array( $layout, array( 'alternating', 'timeline' ), true ) ) {
			return array(
				'kind' => 'section',
				'id' => sanitize_key( (string) ( $section['id'] ?? 'section-' . ( $section_index + 1 ) ) ),
				'tone' => 'neutral',
				'emphasis' => 'medium',
				'layout' => array(
					'type' => 'grid',
					'columns' => 3,
					'gap' => 'l',
				),
				'slots' => array_filter( array(
					'eyebrow' => $eyebrow,
					'heading' => $heading,
					'lead' => $body,
					'items' => $items,
				) ),
			);
		}

		if( $type === 'stats' ) {
			return array(
				'kind' => 'stats',
				'id' => sanitize_key( (string) ( $section['id'] ?? 'stats-' . ( $section_index + 1 ) ) ),
				'tone' => in_array( $treatment, array( 'dark', 'bold', 'glow' ), true ) ? 'dark' : 'primary',
				'emphasis' => 'high',
				'layout' => array(
					'type' => 'grid',
					'columns' => min( 4, max( 2, count( $items ) ?: 3 ) ),
					'gap' => 'l',
				),
				'slots' => array_filter( array(
					'eyebrow' => $eyebrow,
					'heading' => $heading,
					'lead' => $body,
					'items' => $items,
				) ),
			);
		}

		if( $type === 'faq' ) {
			return array(
				'kind' => 'section',
				'id' => sanitize_key( (string) ( $section['id'] ?? 'faq-' . ( $section_index + 1 ) ) ),
				'tone' => 'neutral',
				'emphasis' => 'medium',
				'layout' => array(
					'type' => 'stack',
					'gap' => 'xl',
				),
				'slots' => array_filter( array(
					'eyebrow' => $eyebrow,
					'heading' => $heading,
					'lead' => $body,
				) ),
				'nodes' => array(
					array(
						'kind' => 'tabs',
						'slots' => array(
							'items' => $items,
						),
					),
				),
			);
		}

		if( $type === 'cta' ) {
			return array(
				'kind' => 'section',
				'id' => sanitize_key( (string) ( $section['id'] ?? 'cta-' . ( $section_index + 1 ) ) ),
				'tone' => in_array( $treatment, array( 'dark', 'bold', 'glow' ), true ) ? 'dark' : 'primary',
				'emphasis' => 'high',
				'layout' => array(
					'type' => 'split',
					'gap' => '3xl',
				),
				'slots' => array_filter( array(
					'eyebrow' => $eyebrow,
					'heading' => $heading,
					'lead' => $body,
					'actions' => $actions,
					'button' => empty( $actions ) ? __( 'Learn more', 'wphave' ) : '',
				) ),
			);
		}

		return array(
			'kind' => 'section',
			'id' => sanitize_key( (string) ( $section['id'] ?? 'section-' . ( $section_index + 1 ) ) ),
			'tone' => $layout === 'editorial' || $treatment === 'editorial' ? 'paper' : 'neutral',
			'emphasis' => $layout === 'split' ? 'medium' : 'low',
			'layout' => array(
				'type' => $layout === 'split' ? 'split' : 'stack',
				'gap' => $layout === 'split' ? '3xl' : 'l',
			),
			'slots' => array_filter( array(
				'eyebrow' => $eyebrow,
				'heading' => $heading,
				'lead' => $body,
				'items' => $items,
				'actions' => $actions,
			) ),
		);
	}

/**
	 * Section items to ast items.
	 *
	 * @param array $items Items.
	 * @return array Section items to ast items.
	 */

	protected static function section_items_to_ast_items( $items ): array {
		$output = array();

		foreach( array_slice( (array) $items, 0, 8 ) as $item ) {
			if( ! is_array( $item ) ) {
				continue;
			}

			$heading = trim( sanitize_text_field( (string) ( $item['heading'] ?? $item['title'] ?? '' ) ) );
			$text = trim( sanitize_textarea_field( (string) ( $item['text'] ?? '' ) ) );
			if( $heading === '' && $text === '' ) {
				continue;
			}

			$output[] = array_filter( array(
				'heading' => $heading,
				'text' => $text,
				'value' => trim( sanitize_text_field( (string) ( $item['value'] ?? $item['number'] ?? '' ) ) ),
				'tone' => sanitize_key( (string) ( $item['tone'] ?? '' ) ),
			) );
		}

		return $output;
	}

/**
	 * Section actions to ast actions.
	 *
	 * @param mixed $actions Actions.
	 * @return array Section actions to ast actions.
	 */

	protected static function section_actions_to_ast_actions( $actions ): array {
		$output = array();

		foreach( array_slice( (array) $actions, 0, 3 ) as $action ) {
			if( ! is_array( $action ) || empty( $action['label'] ) ) {
				continue;
			}

			$variant = sanitize_key( (string) ( $action['variant'] ?? 'primary' ) );
			$output[] = array(
				'label' => trim( sanitize_text_field( (string) $action['label'] ) ),
				'variant' => in_array( $variant, array( 'primary', 'secondary', 'tertiary' ), true ) ? $variant : 'primary',
			);
		}

		return $output;
	}

/**
	 * Section to page plan section.
	 *
	 * @param string $heading Heading.
	 * @param string $body Body.
	 * @param int $index Index.
	 * @return array Section to page plan section.
	 */

	protected static function section_to_page_plan_section( string $heading, string $body, int $index ): array {
		$key = strtolower( $heading . ' ' . $body );
		$type = 'content';
		$archetype = 'split-story';
		$layout = $index % 2 ? 'split' : 'stacked';
		$treatment = $index % 2 ? 'blank' : 'soft';

		if( str_contains( $key, 'feature' ) || str_contains( $key, 'benefit' ) || str_contains( $key, 'list' ) ) {
			$type = 'features';
			$archetype = 'bento-showcase';
			$layout = 'bento';
			$treatment = 'outlined';
		} elseif( str_contains( $key, 'step' ) || str_contains( $key, 'process' ) || str_contains( $key, 'workflow' ) ) {
			$type = 'steps';
			$archetype = 'process-alternating';
			$layout = 'alternating';
			$treatment = 'soft';
		} elseif( str_contains( $key, 'pricing' ) || str_contains( $key, 'offer' ) || str_contains( $key, 'package' ) ) {
			$type = 'offers';
			$archetype = 'offer-cards';
			$layout = 'cards';
			$treatment = 'outlined';
		} elseif( str_contains( $key, 'testimonial' ) || str_contains( $key, 'proof' ) || str_contains( $key, 'case' ) ) {
			$type = 'testimonials';
			$archetype = 'testimonial-band';
			$layout = 'band';
			$treatment = 'bold';
		} elseif( str_contains( $key, 'faq' ) || str_contains( $key, 'question' ) ) {
			$type = 'faq';
			$archetype = 'editorial-note';
			$layout = 'stacked';
			$treatment = 'outlined';
		} elseif( str_contains( $key, 'cta' ) || str_contains( $key, 'contact' ) || str_contains( $key, 'book' ) ) {
			$type = 'cta';
			$archetype = 'framed-cta';
			$layout = 'panel';
			$treatment = 'framed';
		}

		return array(
			'type' => $type,
			'archetype' => $archetype,
			'layout' => $layout,
			'treatment' => $treatment,
			'emphasis' => $type === 'cta' ? 'high' : 'medium',
			'eyebrow' => 'Section',
			'heading' => $heading,
			'body' => $body ?: 'This section expands the page narrative with focused, visitor-facing content.',
			'items' => in_array( $type, array( 'features', 'steps', 'offers', 'faq' ), true ) ? self::items_from_text( $body ?: $heading ) : array(),
			'actions' => $type === 'cta' ? array(
				array(
					'label' => 'Learn more',
					'variant' => 'primary',
					'url' => '#',
				),
			) : array(),
		);
	}

/**
	 * Items from sections.
	 *
	 * @param array $sections Sections.
	 * @return array Items from sections.
	 */

	protected static function items_from_sections( array $sections ): array {
		$items = array();

		foreach( $sections as $section ) {
			$title = trim( sanitize_text_field( (string) ( $section['title'] ?? '' ) ) );

			if( $title === '' || in_array( strtolower( $title ), array( 'navbar', 'footer' ), true ) ) {
				continue;
			}

			$items[] = array(
				'title' => $title,
				'text' => trim( sanitize_textarea_field( (string) ( $section['description'] ?? '' ) ) ) ?: 'Relevant content for this part of the page.',
			);

			if( count( $items ) >= 4 ) {
				break;
			}
		}

		return $items ?: self::items_from_text( 'Planning detail' );
	}

/**
	 * Items from text.
	 *
	 * @param string $text Text.
	 * @return array Items from text.
	 */

	protected static function items_from_text( string $text ): array {
		$text = trim( sanitize_textarea_field( $text ) );

		return array(
			array(
				'title' => 'Clarity',
				'text' => $text ?: 'Make the offer easy to understand.',
			),
			array(
				'title' => 'Trust',
				'text' => 'Support the message with concrete context and proof.',
			),
			array(
				'title' => 'Action',
				'text' => 'Guide visitors toward the next relevant step.',
			),
		);
	}

}
