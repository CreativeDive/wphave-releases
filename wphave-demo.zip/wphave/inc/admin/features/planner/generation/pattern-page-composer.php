<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Assemble a whole page from independently validated, approved patterns. */
final class WPHAVE_Website_Plan_Pattern_Page_Composer {
	public static function compose( array $sections, array $sources, array $approved_media_ids = array() ) {
		if ( count( $sections ) < 1 || count( $sections ) > 24 ) {
			return new WP_Error( 'wphave_pattern_page_sections', 'The page needs an approved section plan.' );
		}

		$blocks = array();
		$section_ids = array();
		$manifest = array();
		$anchor_targets = array();
		foreach ( $sections as $section ) {
			if ( ! is_array( $section ) ) {
				return new WP_Error( 'wphave_pattern_page_section', 'Invalid page section.' );
			}

			$section_id = (string) ( $section['sectionId'] ?? '' );
			if (
				$section_id === '' ||
				sanitize_key( $section_id ) !== $section_id ||
				isset( $section_ids[ $section_id ] )
			) {
				return new WP_Error( 'wphave_pattern_page_section_id', 'Section IDs must be unique and stable.' );
			}
			$section_ids[ $section_id ] = true;
			foreach ( (array) ( $section['bindings'] ?? array() ) as $binding ) {
				$source_id = is_array( $binding ) ? (string) ( $binding['sourceId'] ?? '' ) : '';
				$value = $sources[ $source_id ] ?? null;
				if ( is_array( $value ) && ( $value['link']['type'] ?? '' ) === 'anchor' ) {
					$anchor_targets[] = (string) ( $value['link']['anchor'] ?? '' );
				}
			}

			$composed = WPHAVE_Website_Plan_Pattern_Composer::compose(
				(string) ( $section['patternId'] ?? '' ),
				(int) ( $section['version'] ?? 0 ),
				(array) ( $section['bindings'] ?? array() ),
				$sources,
				$approved_media_ids,
				(string) ( $section['variation'] ?? '' )
			);
			if ( is_wp_error( $composed ) ) {
				return $composed;
			}

			$section_blocks = $composed['blocks'];
			if ( count( $section_blocks ) !== 1 || ( $section_blocks[0]['blockName'] ?? '' ) !== 'wphave/group' ) {
				return new WP_Error( 'wphave_pattern_page_root', 'Each approved pattern must have one group root.' );
			}

			$root = $section_blocks[0];
			$root['attrs']['wphave'] = is_array( $root['attrs']['wphave'] ?? null )
				? $root['attrs']['wphave']
				: array();
			$root['attrs']['wphave']['planner'] = is_array( $root['attrs']['wphave']['planner'] ?? null )
				? $root['attrs']['wphave']['planner']
				: array();
			$root['attrs']['wphave']['planner']['sectionId'] = $section_id;
			$root['attrs']['anchor'] = $section_id;
			$blocks[] = $root;
			$manifest[] = array(
				'sectionId' => $section_id,
				'patternId' => $composed['patternId'],
				'version' => $composed['version'],
			);
		}
		if ( array_diff( $anchor_targets, array_keys( $section_ids ) ) !== array() ) {
			return new WP_Error( 'wphave_pattern_page_anchor', 'An approved action points outside the composed page.' );
		}

		return array(
			'blocks' => $blocks,
			'content' => wphave_serialize_blocks_canonical( $blocks ),
			'sections' => $manifest,
		);
	}
}
