<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Derive one editable media composition from the leading section of a validated tree.
 * The model never controls the attachment ID or the responsive geometry.
 */
final class WPHAVE_Website_Plan_Media_Composition {
	public static function enabled(): bool {
		return false;
	}

	public static function derive( array $tree, array $media, string $placement = 'after-content' ): ?array {
		$id = (int) ( $media['attachmentId'] ?? 0 );
		if( ! self::enabled() || $id < 1 || ! wp_attachment_is_image( $id ) || ! current_user_can( 'read_post', $id ) ) {
			return null;
		}

		$sections = $tree['nodes'] ?? null;
		if( ( $tree['kind'] ?? '' ) !== 'page' || ! is_array( $sections ) || count( $sections ) < 1 ) {
			return null;
		}

		$section = $sections[0];
		$children = $section['nodes'] ?? null;
		if( ( $section['kind'] ?? '' ) === 'section' && is_array( $children ) && count( $children ) === 1 && ( $children[0]['kind'] ?? '' ) === 'gridareas' ) {
			$areas = $children[0]['nodes'] ?? null;
			if( is_array( $areas ) && isset( $areas[0]['nodes'] ) && in_array( $areas[0]['kind'] ?? '', array( 'stack', 'surface' ), true ) ) {
				$areas[0]['nodes'][] = array( 'kind' => 'image', 'imageId' => $id );
				$section['nodes'][0]['nodes'] = $areas;
				$tree['nodes'][0] = $section;
				return $tree;
			}
		}
		if( ( $section['kind'] ?? '' ) !== 'section' || ! is_array( $children ) || count( $children ) < 1 || count( $children ) > 2 ) {
			return null;
		}

		$text = $children[0];
		if( ( $text['kind'] ?? '' ) !== 'stack' || empty( $text['nodes'] ) ) {
			return null;
		}
		foreach( $text['nodes'] as $child ) {
			if( ! is_array( $child ) || ! in_array( $child['kind'] ?? '', array( 'heading', 'paragraph', 'actions', 'button' ), true ) ) {
				return null;
			}
		}
		if( count( $children ) === 2 ) {
			$trailing_action = $children[1];
			if( ! is_array( $trailing_action ) || ! in_array( $trailing_action['kind'] ?? '', array( 'actions', 'button' ), true ) ) {
				return null;
			}
			$text['nodes'][] = $trailing_action;
		}

		if( $placement === 'before-content' ) {
			$text['style']['width'] = 'narrow';
			$section['nodes'] = array( array(
				'kind' => 'stack',
				'id' => 'media-image-led',
				'style' => array( 'gap' => 'l' ),
				'nodes' => array(
					array( 'kind' => 'image', 'imageId' => $id, 'style' => array( 'width' => '768px' ) ),
					$text,
				),
			) );
		} else {
			unset( $text['style']['width'] );
			$section['nodes'] = array( array(
				'kind' => 'grid',
				'id' => 'media-grid',
				'layout' => array( 'columns' => 2, 'mobileColumns' => 1 ),
				'style' => array( 'gap' => 'l' ),
				'nodes' => array(
					$text,
					array( 'kind' => 'image', 'imageId' => $id ),
				),
			) );
		}
		$tree['nodes'][0] = $section;

		return $tree;
	}
}
