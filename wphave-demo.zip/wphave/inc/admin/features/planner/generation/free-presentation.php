<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Resolve validated editorial intent into bounded, editable WPHAVE section styles.
 * This runs only after the generated tree and copy have passed their existing gates.
 */
final class WPHAVE_Website_Plan_Free_Presentation {
	public static function apply( array $pages, array $content_plans ): array {
		if( ! WPHAVE_AI_Block_Design_Compiler::pro_layout_enabled() ) {
			return $pages;
		}

		foreach( $pages as &$page ) {
			$slug = (string) ( $page['slug'] ?? '' );
			$plan = $content_plans[$slug] ?? null;
			$tree = $page['plan']['blockTree'] ?? null;
			if( ! is_array( $plan ) || ! is_array( $tree ) ) {
				continue;
			}
			$page['plan']['blockTree'] = self::apply_tree( $tree, $plan );
		}
		unset( $page );

		return $pages;
	}

	public static function apply_tree( array $tree, array $plan ): array {
		$planned = array();
		foreach( (array) ( $plan['sections'] ?? array() ) as $section ) {
			if( ( $section['decision'] ?? '' ) === 'keep' ) {
				$planned[(string) ( $section['id'] ?? '' )] = $section;
			}
		}
		$sections = $tree['nodes'] ?? null;
		if( ! is_array( $sections ) || count( $sections ) !== count( $planned ) ) {
			return $tree;
		}

		$band_index = self::contrast_band_index( $sections, $planned );
		foreach( $sections as $index => &$section ) {
			$id = (string) ( $section['id'] ?? '' );
			$design = $planned[$id]['design'] ?? null;
			if( ! is_array( $design ) ) {
				return $tree;
			}

			$emphasis = (string) ( $design['emphasis'] ?? 'supporting' );
			$density = (string) ( $design['density'] ?? 'comfortable' );
			$composition = (string) ( $design['composition'] ?? 'open' );
			$action_only = ( $planned[$id]['contentMode'] ?? 'full' ) === 'action-only';
			$style = is_array( $section['style'] ?? null ) ? $section['style'] : array();
			$style['background'] = $index === $band_index ? 'subtle' : 'transparent';
			$style['padding'] = $index === 0 ? 'xl' : ( $action_only ? 's' : self::padding_for_density( $density ) );
			$style['paddingBottom'] = $style['padding'];
			$style['width'] = self::width_for_section( $index, $composition );
			$in_action_sequence = self::in_action_sequence( $sections, $planned, $index );
			$style['align'] = $in_action_sequence
				? ( $index % 2 === 0 ? 'end' : 'start' )
				: self::align_for_section( $index, $composition );
			if( $action_only ) {
				$style['radius'] = 'none';
				$style['border'] = 'none';
			}
			$section['style'] = $style;
			self::normalize_unpaired_surface_colors( $section );
			if( $action_only ) {
				self::neutralize_action_containers( $section );
			}

			$size = $index === 0 ? 'title-l' : ( $emphasis === 'dominant' ? 'title-m' : ( $emphasis === 'quiet' ? 'title-xs' : 'title-s' ) );
			self::set_first_heading_size( $section, $size );
		}
		unset( $section );
		$tree['nodes'] = $sections;

		return $tree;
	}

	private static function contrast_band_index( array $sections, array $planned ): int {
		if( count( $sections ) < 3 ) {
			return -1;
		}
		foreach( $sections as $index => $section ) {
			if( $index > 0 && ( $planned[(string) ( $section['id'] ?? '' )]['design']['emphasis'] ?? '' ) === 'dominant' ) {
				return $index;
			}
		}

		return (int) floor( count( $sections ) / 2 );
	}

	/** Generated inner surfaces have no validated foreground pair. */
	private static function normalize_unpaired_surface_colors( array &$node ): void {
		if( ( $node['kind'] ?? '' ) !== 'section' && is_array( $node['style'] ?? null ) ) {
			$background = (string) ( $node['style']['background'] ?? '' );
			if( $background !== '' && ! in_array( $background, array( 'transparent', 'background', 'paper' ), true ) ) {
				$node['style']['background'] = 'background';
			}
		}
		foreach( (array) ( $node['nodes'] ?? array() ) as $index => $child ) {
			if( is_array( $child ) ) {
				self::normalize_unpaired_surface_colors( $node['nodes'][$index] );
			}
		}
	}

	private static function padding_for_density( string $density ): string {
		return array(
			'compact' => 'm',
			'comfortable' => 'l',
			'spacious' => 'xl',
		)[$density] ?? 'l';
	}

	private static function width_for_section( int $index, string $composition ): string {
		if( $index === 0 ) {
			return 'wide';
		}

		return $composition === 'asymmetric' ? 'default' : 'narrow';
	}

	private static function align_for_section( int $index, string $composition ): string {
		if( $index === 0 || $composition === 'asymmetric' ) {
			return 'start';
		}

		return $index % 2 === 0 ? 'end' : 'center';
	}

	private static function in_action_sequence( array $sections, array $planned, int $index ): bool {
		if( $index === 0 || ( $planned[(string) ( $sections[$index]['id'] ?? '' )]['contentMode'] ?? 'full' ) !== 'action-only' ) {
			return false;
		}
		foreach( array( $index - 1, $index + 1 ) as $neighbor ) {
			if( isset( $sections[$neighbor] ) && ( $planned[(string) ( $sections[$neighbor]['id'] ?? '' )]['contentMode'] ?? 'full' ) === 'action-only' ) {
				return true;
			}
		}
		return false;
	}

	private static function neutralize_action_containers( array &$node ): void {
		if( in_array( (string) ( $node['kind'] ?? '' ), array( 'surface', 'stack', 'flex', 'grid' ), true ) && self::simple_action_group( $node ) ) {
			$node['style'] = is_array( $node['style'] ?? null ) ? $node['style'] : array();
			$node['style']['background'] = 'transparent';
			$node['style']['padding'] = 'xs';
			$node['style']['radius'] = 'none';
			$node['style']['border'] = 'none';
		}
		foreach( (array) ( $node['nodes'] ?? array() ) as $index => $child ) {
			if( is_array( $child ) ) {
				self::neutralize_action_containers( $node['nodes'][$index] );
			}
		}
	}

	private static function simple_action_group( array $node ): bool {
		$counts = array( 'heading' => 0, 'actions' => 0, 'other' => 0 );
		self::count_action_group_nodes( $node, $counts );
		return $counts['heading'] === 1 && $counts['actions'] >= 1 && $counts['other'] === 0;
	}

	private static function count_action_group_nodes( array $node, array &$counts ): void {
		$kind = (string) ( $node['kind'] ?? '' );
		if( $kind === 'heading' ) {
			$counts['heading']++;
		} elseif( in_array( $kind, array( 'button', 'actions' ), true ) ) {
			$counts['actions']++;
		} elseif( ! in_array( $kind, array( 'section', 'surface', 'stack', 'flex', 'grid' ), true ) ) {
			$counts['other']++;
		}
		foreach( (array) ( $node['nodes'] ?? array() ) as $child ) {
			if( is_array( $child ) ) {
				self::count_action_group_nodes( $child, $counts );
			}
		}
	}

	private static function set_first_heading_size( array &$node, string $size ): bool {
		if( ( $node['kind'] ?? '' ) === 'heading' ) {
			$node['text'] = is_array( $node['text'] ?? null ) ? $node['text'] : array();
			$node['text']['size'] = $size;
			return true;
		}
		foreach( (array) ( $node['nodes'] ?? array() ) as $index => $child ) {
			if( is_array( $child ) && self::set_first_heading_size( $node['nodes'][$index], $size ) ) {
				return true;
			}
		}

		return false;
	}
}
