<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Reviews copy without granting the reviewer control over blocks, styles or links.
 */
trait WPHAVE_Website_Plan_AI_Copy_Grounding {

	protected static function review_free_copy( array $pages, array $brief, array $site_pages, callable $generate_text, array $options, array $content_plans = array() ): array|WP_Error {
		foreach( $pages as &$page ) {
			$slug = (string) ( $page['slug'] ?? '' );
			if( ( $content_plans[$slug]['copyPolicy'] ?? '' ) === 'locked' ) {
				continue;
			}
			$tree = $page['plan']['blockTree'] ?? null;
			if( ! is_array( $tree ) || ! WPHAVE_AI_Block_Design_Compiler::validate_tree( $tree ) ) {
				continue;
			}

			$entries = array();
			self::collect_copy_entries( $tree, '', $entries );
			if( $entries === array() ) {
				continue;
			}

			$messages = array(
				array(
					'role' => 'system',
					'content' => self::copy_review_system_prompt(),
				),
				array(
					'role' => 'user',
					'content' => wp_json_encode( array( 'brief' => $brief, 'entries' => $entries ), JSON_UNESCAPED_UNICODE ),
				),
			);
			$review_options = array_replace( $options, array(
				'maxTokens' => 5500,
				'temperature' => 0.2,
			) );
			$response = $generate_text( $messages, $review_options );
			if( is_wp_error( $response ) ) {
				return new WP_Error(
					'ai_website_copy_review_failed',
					__( 'The generated copy could not be verified. Please try this page again.', 'wphave' ),
					array( 'status' => 502 )
				);
			}

			$data = json_decode( self::extract_json_object( (string) ( $response['result'] ?? '' ) ), true );
			$edits = $data['edits'] ?? null;
			if( ! is_array( $edits ) || count( $edits ) > count( $entries ) ) {
				return new WP_Error(
					'ai_website_copy_review_invalid',
					__( 'The generated copy review was incomplete. Please try this page again.', 'wphave' ),
					array( 'status' => 502 )
				);
			}

			$allowed_paths = array_column( $entries, 'kind', 'path' );
			$entries_by_path = array_column( $entries, null, 'path' );
			$seen = array();
			$reviewed = $tree;
			$remove_paths = array();
			foreach( $edits as $edit ) {
				if( ! is_array( $edit ) ) {
					continue;
				}
				$path = (string) ( $edit['path'] ?? '' );
				$text = trim( sanitize_text_field( (string) ( $edit['text'] ?? '' ) ) );
				if( ! isset( $allowed_paths[$path] ) || isset( $seen[$path] ) ) {
					continue;
				}
				$required_h1 = (string) ( $content_plans[$slug]['requiredH1'] ?? '' );
				if( ( $entries_by_path[$path]['level'] ?? '' ) === 'h1' && $required_h1 !== '' && $text !== $required_h1 ) {
					continue;
				}
				if( WPHAVE_AI_Block_Design_Compiler::pro_layout_enabled() && ( $edit['remove'] ?? false ) === true && $allowed_paths[$path] === 'paragraph' ) {
					$seen[$path] = true;
					$remove_paths[] = $path;
					continue;
				}
				if( $text === '' ) {
					continue;
				}
				$seen[$path] = true;
				self::replace_copy_at_path( $reviewed, $path, $text );
			}
			rsort( $remove_paths, SORT_NATURAL );
			foreach( $remove_paths as $path ) {
				self::remove_paragraph_at_path( $reviewed, $path );
			}
			if( WPHAVE_AI_Block_Design_Compiler::quality_issues( $reviewed, $site_pages, $brief ) === array() ) {
				$page['plan']['blockTree'] = $reviewed;
			}
		}
		unset( $page );
		return $pages;
	}

	protected static function copy_review_system_prompt(): string {
		$removal_rule = WPHAVE_AI_Block_Design_Compiler::pro_layout_enabled()
			? 'For a paragraph that only repeats its section heading, the existence of the offer, or an adjacent planned action without adding any independent confirmed information, return {"path":"...","remove":true}. Remove only paragraph blocks, never headings. If a paragraph contains any useful confirmed detail, keep or rewrite it. Removing a paragraph must not change section IDs, actions, URLs or layout.'
			: 'Do not change node structure.';
		return <<<'PROMPT'
You are an adversarial factual editor for website copy. Return one JSON object {"edits":[{"path":"0.1","text":"replacement text"}]}.
Only brief.offer and the confirmed facts in brief.facts authorize business claims. Project name, industry, audience, goal, notes and sitemap topics provide context or editorial direction, never proof that a capability or item exists.
Examine every heading and paragraph for implied specifics: products, materials, styles, techniques, variants, events, tours, processes, results, inventory, availability and specifications. Replace the entire sentence if any such detail is absent from offer or facts, even when the wording is hedged. A page about ceramics cannot assume sculptural pieces, named series, glazing techniques or guided tours; a software page cannot assume integrations or automation.
Treat operational promises as factual claims too: appointments, booking methods, current schedules, opening times, arrival instructions, response times and what visitors will experience during a visit require explicit support in offer or facts. A route to a contact page proves only that a visitor can navigate there; it does not prove that appointments are offered or that current dates are published. Rewrite unsupported claims to the narrower confirmed offer instead of moving them to another page.
Keep sections distinct and expressive with truthful, subject-specific editorial language. State each verified fact once in the section where it matters most; do not repeat the same sentence or restate the brief in every section. Use the remaining sections to explain visitor relevance without adding unverified details. Do not turn the page into questions, inquiry instructions or repeated calls to action. At most one paragraph may direct readers to contact the business.
Write finished visitor-facing copy in the language of the brief, without placeholders or meta instructions. Return only changed entries by exact path. Do not change URLs or layout.
Do not mention the content plan, evidence status, omitted topics or what this page does not include. Avoid phrases about "this page" or "confirmed facts" that describe the editorial process instead of speaking to visitors.
PROMPT . "\n" . $removal_rule;
	}

	protected static function collect_copy_entries( array $node, string $path, array &$entries ): void {
		$kind = $node['kind'] ?? '';
		if( in_array( $kind, array( 'heading', 'paragraph' ), true ) ) {
			$entries[] = array(
				'path' => $path,
				'kind' => $kind,
				'level' => $kind === 'heading' ? (string) ( $node['text']['level'] ?? 'h2' ) : '',
				'text' => (string) ( $node['text']['content'] ?? '' ),
			);
		}
		foreach( $node['nodes'] ?? array() as $index => $child ) {
			if( is_array( $child ) ) {
				self::collect_copy_entries( $child, $path === '' ? (string) $index : $path . '.' . $index, $entries );
			}
		}
	}

	protected static function replace_copy_at_path( array &$tree, string $path, string $text ): void {
		$node = &$tree;
		foreach( explode( '.', $path ) as $index ) {
			if( ! ctype_digit( $index ) || ! isset( $node['nodes'][(int) $index] ) ) {
				return;
			}
			$node = &$node['nodes'][(int) $index];
		}
		if( ! in_array( $node['kind'] ?? '', array( 'heading', 'paragraph' ), true ) ) {
			return;
		}
		$limit = ( $node['kind'] ?? '' ) === 'heading' ? 220 : 1200;
		$node['text']['content'] = mb_substr( $text, 0, $limit );
	}

	protected static function remove_paragraph_at_path( array &$tree, string $path ): void {
		$parts = explode( '.', $path );
		$last = array_pop( $parts );
		$parent = &$tree;
		foreach( $parts as $part ) {
			if( ! ctype_digit( $part ) || ! isset( $parent['nodes'][(int) $part] ) ) {
				return;
			}
			$parent = &$parent['nodes'][(int) $part];
		}
		if(
			! ctype_digit( $last ) ||
			( $parent['nodes'][(int) $last]['kind'] ?? '' ) !== 'paragraph' ||
			count( (array) ( $parent['nodes'] ?? array() ) ) <= 1
		) {
			return;
		}
		array_splice( $parent['nodes'], (int) $last, 1 );
	}
}
