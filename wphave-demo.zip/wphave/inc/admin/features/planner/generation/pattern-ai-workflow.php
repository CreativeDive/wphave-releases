<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Plan a complete page, then fill only approved Gutenberg pattern slots.
 * Generated copy remains a proposal until the user reviews the page.
 */
final class WPHAVE_Website_Plan_Pattern_AI_Workflow {
	public static function generate(
		array $brief,
		array $page,
		array $site_pages,
		array $approved_media_ids,
		callable $generate_text,
		array $options
	) {
		$catalog = array_values( array_filter(
			WPHAVE_Website_Plan_Pattern_Registry::catalog(),
			static fn( array $pattern ): bool => (int) $pattern['minMedia'] <= count( $approved_media_ids )
		) );
		if ( count( $catalog ) < 3 ) {
			return self::error( 'catalog_incomplete' );
		}

		$options['responseFormat'] = 'json_object';
		$options['maxTokens'] = max( 7000, (int) ( $options['maxTokens'] ?? 0 ) );
		$context = array(
			'brief' => $brief,
			'page' => array(
				'slug' => $page['slug'],
				'title' => $page['title'],
			),
			'sitePages' => array_map(
				static fn( array $item ): array => array(
					'slug' => $item['slug'],
					'title' => $item['title'],
				),
				$site_pages
			),
			'approvedMediaIds' => $approved_media_ids,
			'previousPatternOrders' => self::normalise_previous_orders( $options['previousPatternOrders'] ?? array(), $catalog ),
		);
		$visual_reference = is_array( $options['visualReference'] ?? null ) ? $options['visualReference'] : null;
		if ( $visual_reference !== null ) {
			$context['visualReference'] = $visual_reference;
		}
		$outline_messages = array(
			array(
				'role' => 'system',
				'content' => 'Plan one complete website page from approved WPHAVE Patterns. Return JSON only: {"sections":[{"sectionId":"intro","patternId":"...","version":1,"variation":"","purpose":"..."}]}. Choose 4 to 6 sections with a hero first, a closing action last, and at least three distinct layout families. If visualReference is present, follow its top-to-bottom section sequence, proportions, typography, image placement and spatial rhythm as closely as the catalog and approved media permit. Do not treat its text as verified content. Do not repeat a patternId within the page while enough suitable catalog patterns exist. PreviousPatternOrders are earlier drafts: your selected patternId/variation sequence MUST differ from every previous sequence, including the order of middle sections. Read each pattern description and variationOptions. Use only listed variation names; an empty variation selects the base pattern. Use the brief as direction even when sparse. Do not invent block markup, attributes, media, links or factual business details. A page title or route is not proof of an offering. Select only catalog entries that fit the available media.',
			),
			array( 'role' => 'user', 'content' => wp_json_encode( array( 'context' => array_diff_key( $context, array( 'sitePages' => true ) ), 'catalog' => $catalog ), JSON_UNESCAPED_UNICODE ) ),
		);
		for ( $attempt = 0; $attempt < 3; ++$attempt ) {
			$outline_response = $generate_text( $outline_messages, $options );
			if ( is_wp_error( $outline_response ) ) {
				return $outline_response;
			}
			$outline = self::decode_json_object( (string) ( $outline_response['result'] ?? '' ) );
			$sections = self::validate_outline( $outline['sections'] ?? null, $catalog, $context['previousPatternOrders'] );
			if ( ! is_wp_error( $sections ) ) {
				break;
			}
			$outline_messages[] = array(
				'role' => 'user',
				'content' => 'The last outline failed with ' . $sections->get_error_code() . '. Return a new JSON object with 4 to 6 unique section IDs, exact catalog patternId/version pairs, a hero first, a closing action last, at least three layout families, no repeated patternId if enough patterns exist, only listed variation names, and a pattern order different from every previousPatternOrder. No explanation.',
			);
		}
		if ( is_wp_error( $sections ) && $visual_reference !== null ) {
			return $sections;
		}
		if ( is_wp_error( $sections ) ) {
			$sections = self::fallback_outline( $catalog, $context['previousPatternOrders'] );
			if ( is_wp_error( $sections ) ) {
				return $sections;
			}
		}

		$details = array();
		foreach ( $sections as $section ) {
			$resolved = WPHAVE_Website_Plan_Pattern_Registry::resolve(
				$section['patternId'],
				$section['version'],
				$section['variation']
			);
			if ( is_wp_error( $resolved ) ) {
				return $resolved;
			}
			$details[] = array(
				'sectionId' => $section['sectionId'],
				'patternId' => $section['patternId'],
				'slots' => array_map(
					static fn( array $slot ): array => array(
						'kind' => $slot['kind'],
						'required' => $slot['required'] ?? true,
						'maxLength' => $slot['maxLength'] ?? null,
					),
					$resolved['contract']['slots']
				),
			);
		}

		$copy_messages = array(
			array(
				'role' => 'system',
				'content' => 'Fill the selected WPHAVE Pattern slots for one editable page. Return JSON only: {"sections":[{"sectionId":"...","slots":{"heading":"...","body":"...","primaryAction":{"label":"...","targetSlug":"..."},"image":123}}]}. Match every selected sectionId exactly and provide every required slot. Optional slots may be omitted. Text is a provisional editorial proposal, not a confirmed business fact. Use the brief language. Create a useful first draft from a rough concept, but do not claim specific products, events, dates, prices, locations, people, awards, services or promises absent from confirmed offer/facts. Avoid generic filler and repeated sections. Every action targetSlug must be a listed site page. An image slot is a bare integer from approvedMediaIds, never a URL or invented ID. Do not output HTML, CSS, block markup or layout attributes.',
			),
			array( 'role' => 'user', 'content' => wp_json_encode( array( 'context' => $context, 'selected' => $details ), JSON_UNESCAPED_UNICODE ) ),
		);
		for ( $attempt = 0; $attempt < 3; ++$attempt ) {
			$copy_response = $generate_text( $copy_messages, $options );
			if ( is_wp_error( $copy_response ) ) {
				return $copy_response;
			}
			$copy = self::decode_json_object( (string) ( $copy_response['result'] ?? '' ) );
			$filled = self::bind_proposals( $sections, $details, $copy['sections'] ?? null, $site_pages, $approved_media_ids );
			if ( ! is_wp_error( $filled ) ) {
				break;
			}
			$copy_messages[] = array(
				'role' => 'user',
				'content' => 'The last slot response failed with ' . $filled->get_error_code() . '. Return a new JSON object with exactly the selected section IDs, every required slot, text within maxLength, actions targeting only these site page slugs: ' . implode( ', ', array_column( $site_pages, 'slug' ) ) . '. Use only approved media IDs. No explanation.',
			);
		}
		if ( is_wp_error( $filled ) ) {
			return $filled;
		}

		$composed = WPHAVE_Website_Plan_Pattern_Page_Composer::compose(
			$filled['sections'],
			$filled['sources'],
			$approved_media_ids
		);
		if ( is_wp_error( $composed ) ) {
			return $composed;
		}
		$section_content = array();
		foreach ( $composed['blocks'] as $index => $block ) {
			$section_content[] = array(
				'id' => $sections[ $index ]['sectionId'],
				'title' => $sections[ $index ]['purpose'],
				'type' => $index === 0 ? 'hero' : 'content',
				'content' => wphave_serialize_blocks_canonical( array( $block ) ),
		);
		}
		$composition_plan = array(
			'version' => 1,
			'sections' => $composed['sections'],
			'copyStatus' => 'proposal',
		);
		if ( $visual_reference !== null ) {
			$composition_plan['visualReference'] = $visual_reference;
		}

		return array(
			'page' => array(
				'title' => $page['title'],
				'slug' => $page['slug'],
				'source' => array( 'type' => 'ai' ),
				'plan' => array(
					'patternComposition' => $composition_plan,
				),
				'content' => $composed['content'],
				'sectionsContent' => $section_content,
				'diagnostics' => array( 'approved_pattern_renderer_used', 'copy_requires_review' ),
			),
			'provider' => $copy_response['provider'] ?? '',
			'meta' => $copy_response['meta'] ?? null,
		);
	}

	private static function validate_outline( $raw, array $catalog, array $previous_orders = array() ) {
		if ( ! is_array( $raw ) || ! array_is_list( $raw ) || count( $raw ) < 4 || count( $raw ) > 6 ) {
			return self::error( 'outline_invalid' );
		}
		$known = array();
		foreach ( $catalog as $item ) {
			$known[ $item['patternId'] . '@' . $item['version'] ] = $item;
		}
		$sections = array();
		$ids = array();
		$families = array();
		$pattern_ids = array();
		foreach ( $raw as $index => $item ) {
			if ( ! is_array( $item ) ) {
				return self::error( 'outline_invalid' );
			}
			$id = (string) ( $item['sectionId'] ?? '' );
			$pattern_id = (string) ( $item['patternId'] ?? '' );
			$version = $item['version'] ?? null;
			$variation = (string) ( $item['variation'] ?? '' );
			$known_pattern = $known[ $pattern_id . '@' . $version ] ?? null;
			if (
				$id === '' || sanitize_key( $id ) !== $id || isset( $ids[ $id ] ) ||
				! is_int( $version ) || ! is_array( $known_pattern ) ||
				( $variation !== '' && ! in_array( $variation, $known_pattern['variationNames'], true ) ) ||
				( $index === 0 && $known_pattern['category'] !== 'hero' ) ||
				( $index === count( $raw ) - 1 && $known_pattern['category'] !== 'cta' ) ||
				( count( $raw ) <= count( $catalog ) && isset( $pattern_ids[ $pattern_id ] ) )
			) {
				return self::error( 'outline_invalid' );
			}
			$ids[ $id ] = true;
			$families[ $known_pattern['layoutFamily'] ] = true;
			$pattern_ids[ $pattern_id ] = true;
			$sections[] = array(
				'sectionId' => $id,
				'patternId' => $pattern_id,
				'version' => $version,
				'variation' => $variation,
				'purpose' => sanitize_text_field( (string) ( $item['purpose'] ?? '' ) ),
			);
		}
		if ( count( $families ) < 3 ) {
			return self::error( 'outline_repetitive' );
		}
		$order = array_map(
			static fn( array $section ): string => $section['patternId'] . '@' . $section['version'] . ':' . $section['variation'],
			$sections
		);
		foreach ( $previous_orders as $previous_order ) {
			if ( $order === $previous_order ) {
				return self::error( 'outline_duplicate' );
			}
		}
		return $sections;
	}

	/** Recover from a malformed model outline using only the same reviewed catalog. */
	private static function fallback_outline( array $catalog, array $previous_orders ) {
		$heroes = array_values( array_filter( $catalog, static fn( array $item ): bool => $item['category'] === 'hero' ) );
		$closings = array_values( array_filter( $catalog, static fn( array $item ): bool => $item['category'] === 'cta' ) );
		$middles = array_values( array_filter( $catalog, static fn( array $item ): bool => ! in_array( $item['category'], array( 'hero', 'cta' ), true ) ) );
		foreach ( $heroes as $hero ) {
			foreach ( $middles as $first ) {
				foreach ( $middles as $second ) {
					if ( $first['patternId'] === $second['patternId'] ) {
						continue;
					}
					foreach ( $closings as $closing ) {
						$items = array( $hero, $first, $second, $closing );
						$outline = array();
						foreach ( $items as $index => $item ) {
							$outline[] = array(
								'sectionId' => array( 'intro', 'details', 'benefits', 'next' )[ $index ],
								'patternId' => $item['patternId'],
								'version' => (int) $item['version'],
								'variation' => '',
								'purpose' => array( 'Introduction', 'Main topic', 'Further detail', 'Next step' )[ $index ],
							);
						}
						$validated = self::validate_outline( $outline, $catalog, $previous_orders );
						if ( ! is_wp_error( $validated ) ) {
							return $validated;
						}
					}
				}
			}
		}
		return self::error( 'outline_invalid' );
	}

	/** Some WordPress AI providers wrap valid JSON in a code fence or prose. */
	private static function decode_json_object( string $response ): array {
		$decoded = json_decode( trim( $response ), true );
		if ( is_array( $decoded ) && ! array_is_list( $decoded ) ) {
			return $decoded;
		}
		$start = strpos( $response, '{' );
		$end = strrpos( $response, '}' );
		if ( $start === false || $end === false || $end <= $start ) {
			return array();
		}
		$decoded = json_decode( substr( $response, $start, $end - $start + 1 ), true );
		return is_array( $decoded ) && ! array_is_list( $decoded ) ? $decoded : array();
	}

	private static function normalise_previous_orders( $raw, array $catalog ): array {
		if ( ! is_array( $raw ) ) {
			return array();
		}
		$allowed = array();
		foreach ( $catalog as $item ) {
			$allowed[ $item['patternId'] . '@' . $item['version'] ] = $item;
		}
		$orders = array();
		foreach ( array_slice( $raw, -8 ) as $raw_order ) {
			if ( ! is_array( $raw_order ) || ! array_is_list( $raw_order ) || count( $raw_order ) < 4 || count( $raw_order ) > 6 ) {
				continue;
			}
			$order = array();
			foreach ( $raw_order as $section ) {
				if ( ! is_array( $section ) ) {
					continue 2;
				}
				$key = (string) ( $section['patternId'] ?? '' ) . '@' . (string) ( $section['version'] ?? '' );
				$variation = (string) ( $section['variation'] ?? '' );
				if ( ! isset( $allowed[ $key ] ) || ( $variation !== '' && ! in_array( $variation, $allowed[ $key ]['variationNames'], true ) ) ) {
					continue 2;
				}
				$order[] = $key . ':' . $variation;
			}
			$orders[] = $order;
		}
		return $orders;
	}

	private static function bind_proposals( array $sections, array $details, $raw, array $site_pages, array $approved_media_ids ) {
		if ( ! is_array( $raw ) || ! array_is_list( $raw ) || count( $raw ) !== count( $sections ) ) {
			return self::error( 'slots_invalid' );
		}
		$routes = array_column( $site_pages, null, 'slug' );
		$by_id = array();
		foreach ( $raw as $item ) {
			$id = is_array( $item ) ? (string) ( $item['sectionId'] ?? '' ) : '';
			if ( $id === '' || isset( $by_id[ $id ] ) ) {
				return self::error( 'slots_invalid' );
			}
			$by_id[ $id ] = $item['slots'] ?? null;
		}
		$sources = array();
		foreach ( $sections as $index => &$section ) {
			$id = $section['sectionId'];
			$values = $by_id[ $id ] ?? null;
			if ( ! is_array( $values ) || array_diff( array_keys( $values ), array_keys( $details[ $index ]['slots'] ) ) !== array() ) {
				return self::error( 'slots_invalid' );
			}
			$bindings = array();
			foreach ( $details[ $index ]['slots'] as $slot_name => $slot ) {
				$value = $values[ $slot_name ] ?? null;
				if ( $value === null ) {
					if ( $slot['required'] ) {
						return self::error( 'required_slot_missing' );
					}
					continue;
				}
				$source_id = $id . '-' . $slot_name;
				if ( $slot['kind'] === 'action' ) {
					$target = is_array( $value ) ? (string) ( $value['targetSlug'] ?? '' ) : '';
					$label = is_array( $value ) ? (string) ( $value['label'] ?? '' ) : '';
					if ( ! isset( $routes[ $target ] ) || trim( $label ) === '' || mb_strlen( $label ) > 80 ) {
						return self::error( 'action_invalid' );
					}
					$target_url = $routes[ $target ]['url'] ?? home_url( $target === 'home' ? '/' : '/' . $target . '/' );
					$sources[ $source_id ] = array(
						'label' => $label,
						'link' => array(
							'type' => 'external',
							'external' => array( 'url' => $target_url ),
						),
					);
				} elseif ( $slot['kind'] === 'image' ) {
					if ( is_array( $value ) && array_keys( $value ) === array( 'approvedMediaId' ) ) {
						$value = $value['approvedMediaId'];
					}
					if ( ! is_int( $value ) || ! in_array( $value, $approved_media_ids, true ) ) {
						return self::error( 'media_invalid' );
					}
					$sources[ $source_id ] = $value;
				} elseif (
					is_string( $value ) &&
					trim( $value ) !== '' &&
					mb_strlen( $value ) <= (int) ( $slot['maxLength'] ?? 0 )
				) {
					$sources[ $source_id ] = $value;
				} else {
					return self::error( 'text_invalid' );
				}
				$bindings[ $slot_name ] = array( 'sourceId' => $source_id );
			}
			$section['bindings'] = $bindings;
		}
		unset( $section );
		return array( 'sections' => $sections, 'sources' => $sources );
	}

	private static function error( string $reason ): WP_Error {
		return new WP_Error(
			'ai_website_pattern_' . $reason,
			__( 'The pattern page could not be composed safely. The previous draft remains available.', 'wphave' ),
			array( 'status' => 502 )
		);
	}
}
