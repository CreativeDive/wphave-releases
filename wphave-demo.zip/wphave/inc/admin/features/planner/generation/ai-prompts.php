<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Website_Plan_AI_Prompts {

/**
	 * Sitemap messages.
	 *
	 * @param array $brief Brief.
	 * @return array Sitemap messages.
	 */

	protected static function sitemap_messages( array $brief, string $composition_mode = 'patterns' ): array {
		$page_limit = self::page_limit( $brief['scope'] ?? 'standard' );
		if( $composition_mode === 'pattern-workspace' ) {
			return array(
				array(
					'role' => 'system',
					'content' => implode( "\n", array(
						'You plan the page structure of one website. Return one valid JSON object only.',
						'Create a page list only. Do not generate sections, template parts, features, copy, imagery, products or events. Each page will be developed separately after the sitemap is accepted.',
						'Only brief.offer and brief.facts verify business capabilities. Notes, goals and audience guide editorial priorities but do not prove a capability exists.',
						'Use the brief language. Keep page titles concise and avoid speculative pages. Home must be first.',
						'Keep page count between 3 and ' . $page_limit . '.',
						'Return {"projectName":"...","pages":[{"title":"Home","slug":"home"}]}.',
					) ),
				),
				array(
					'role' => 'user',
					'content' => wp_json_encode( array( 'brief' => $brief, 'pageLimit' => $page_limit ), JSON_UNESCAPED_UNICODE ),
				),
			);
		}

		return array(
			array(
				'role' => 'system',
				'content' => implode( "\n", array(
					'You are the Website Planner for a WordPress design workflow.',
					'Return valid JSON only. Do not output markdown, HTML, CSS, JavaScript, PHP, Gutenberg block markup, comments, explanations, or trailing text.',
					'Create the first sitemap from the brief. Decide which pages are useful, not just generic placeholders.',
					'Use the same language as the brief. Write concrete user-facing planning content. Never use lorem ipsum.',
					'Treat the brief.offer and brief.facts fields as the only source of product and business facts. Do not invent named products, events, dates, prices, testimonials, contact details, policies or service promises.',
					'Describe useful page sections at the level supported by the brief. Do not prescribe unsupported product detail pages, filters, booking, payments, RSVP, newsletters or forms with specific fields. Mention these only when the brief explicitly requires them.',
					'Do not specify a count or name for products, events, people or testimonials when the brief gives none. Plan a category overview or process explanation instead of a fictional catalog.',
					'When imagery or factual details are missing, describe the role of the content to be supplied later rather than asserting that specific assets or facts already exist.',
					'The JSON shape must be: {"projectName":"...","summary":"...","templateParts":{"header":{"title":"Header","intent":"...","sections":[{"title":"Logo and navigation","description":"..."}]},"footer":{"title":"Footer","intent":"...","sections":[{"title":"Footer navigation","description":"..."}]}},"pages":[{"title":"Home","slug":"home","intent":"...","description":"...","sections":[{"title":"Hero Header Section","description":"..."}]}]}.',
					'Home must be the first page. Include About and Contact when they fit the brief. Add other pages only when they support the goal.',
					'Header and Footer are global template parts. Do not include Navbar or Footer sections inside individual pages.',
					'Each page needs 3 to 6 sections. Section descriptions must explain actual content for that business.',
					'Keep page count between 3 and ' . $page_limit . '.',
					'The sitemap will later become real WordPress pages, so avoid vague section titles and duplicated page intents.',
				) ),
			),
			array(
				'role' => 'user',
				'content' => wp_json_encode( array(
					'brief' => $brief,
					'pageLimit' => $page_limit,
				), JSON_UNESCAPED_UNICODE ),
			),
		);
	}

/**
	 * Wireframe messages.
	 *
	 * @param array $brief Brief.
	 * @param array $sitemap Sitemap.
	 * @return array Wireframe messages.
	 */

	protected static function wireframe_messages( array $brief, array $sitemap ): array {
		$pages = array_slice( $sitemap['pages'] ?? array(), 0, self::page_limit( $brief['scope'] ?? 'standard' ) );
		$section_catalog = class_exists( 'WPHAVE_Website_Planner_Section_Library' ) ? WPHAVE_Website_Planner_Section_Library::prompt_catalog( 90 ) : array();

		return array(
			array(
				'role' => 'system',
				'content' => implode( "\n", array(
					'You are the Website Planner wireframe generator for a WordPress design workflow.',
					'Return valid JSON only. Do not output markdown, HTML, CSS, JavaScript, PHP, Gutenberg block markup, comments, explanations, or trailing text.',
					'Convert every sitemap page into a Website Planner wireframe by selecting section layouts from the provided sectionCatalog.',
					'Do not invent raw blocks, blockTree, AST, HTML, CSS, or pattern markup. Select known patternKey values and fill their content slots.',
					'For each page, plan.patternSections is the primary render source. Every page must include 3 to 7 patternSections.',
					'Use a hero-like section first when available, then page-specific content sections, and only use CTA sections where a real next step is useful.',
					'Choose different section keys and rhythms across pages. Do not use the same sequence for every page.',
					'Do not create visual style guides, colors, fonts, or global design identity. This is still the wireframe/content step.',
					'Use final user-facing copy in the same language as the brief and sitemap. Never use lorem ipsum.',
					'Each generated page must keep the original title and slug from the sitemap.',
					'Create strong page-specific content from the sitemap intent and section descriptions. Do not repeat the same content across pages.',
					'Slot rules: heading is required, body should be concrete, items are for cards/lists, actions are buttons. Keep copy concise enough for wireframes.',
					'Also convert the global header and footer into concise template part plans. They are shared across all pages.',
					'Return this JSON shape: {"templateParts":{"header":{"title":"Header","plan":{"logo":"...","navigation":[{"label":"...","url":"#..."}],"actions":[{"label":"...","url":"#"}]}},"footer":{"title":"Footer","plan":{"summary":"...","columns":[{"title":"...","items":[{"label":"...","url":"#..."}]}]}}},"pages":[{"title":"...","slug":"...","plan":{"version":1,"intent":"...","summary":"...","patternSections":[{"id":"hero","patternKey":"...","type":"hero|content|features|cta|contact","title":"...","purpose":"...","slots":{"eyebrow":"...","heading":"...","body":"...","items":[{"title":"...","text":"..."}],"actions":[{"label":"...","url":"#"}]}}]}}]}.',
					'Allowed sectionCatalog JSON:',
					wp_json_encode( $section_catalog, JSON_UNESCAPED_UNICODE ),
				) ),
			),
			array(
				'role' => 'user',
				'content' => wp_json_encode( array(
					'brief' => $brief,
					'sitemapSummary' => $sitemap['summary'] ?? '',
					'templateParts' => $sitemap['templateParts'] ?? array(),
					'pages' => $pages,
				), JSON_UNESCAPED_UNICODE ),
			),
		);
	}

	/**
	 * Ask for editable, free block compositions through the small design contract.
	 */
	protected static function free_wireframe_messages( array $brief, array $sitemap, array $site_pages = array(), array $content_plans = array() ): array {
		$pages = array_slice( $sitemap['pages'] ?? array(), 0, self::page_limit( $brief['scope'] ?? 'standard' ) );
		$site_pages = $site_pages ?: $pages;
		$pages = array_map( static function( $page ) {
			if( ! is_array( $page ) ) {
				return $page;
			}
			if( ( $page['source']['type'] ?? '' ) === 'ai' ) {
				unset( $page['description'] );
			}
			if( is_array( $page['sections'] ?? null ) ) {
				$page['sections'] = array_map( static function( $section ) {
					if( is_array( $section ) && ( $section['source']['type'] ?? '' ) === 'ai' ) {
						unset( $section['description'] );
					}
					return $section;
				}, $page['sections'] );
			}
			return $page;
		}, $pages );
		$contract = WPHAVE_AI_Block_Design_Compiler::contract_payload();
		$allowed_paths = array_values( array_map( static function( $page ) {
			$slug = sanitize_title( (string) ( $page['slug'] ?? '' ) );
			return $slug === 'home' ? '/' : '/' . $slug . '/';
		}, $site_pages ) );
		$site_page_map = array_values( array_map( static function( $page ) {
			return array(
				'title' => (string) ( $page['title'] ?? '' ),
				'slug' => (string) ( $page['slug'] ?? '' ),
			);
		}, $site_pages ) );

		return array(
			array(
				'role' => 'system',
				'content' => implode( "\n", array(
					'You design editable WPHAVE website wireframes from the brief and sitemap.',
					'Follow brief.designDirection as a presentation preference when it is set. Calm means generous quiet spacing, editorial means typographic hierarchy and varied reading widths, image-led means compose around an actually bound image, and expressive means stronger contrast and asymmetry. It never authorizes invented facts, images or empty decorative regions.',
					'brief.layoutVariantSeed, when present, varies spatial hierarchy among focused/open, editorial, asymmetric and compact contrast. It does not justify changing verified facts, adding filler sections or ignoring the contentPlan.',
					'Return one valid JSON object only. Never return HTML, CSS, PHP, JavaScript, block markup, or pattern keys.',
					'For every requested page, return its exact title and slug and a plan.blockTree using the provided contract. sitePages is context, not additional output.',
					$content_plans === array() ? '' : 'contentPlans provide editorial structure and, when present, validated design intent; they are not verified facts or visitor copy. For each requested page, output exactly one root section per keep decision, in plan order, with section.id exactly equal to the planned section id. Merge marked content into the stated kept target; never create a separate root section for it. Each planned action must be in its owning root section. Put planActionId, planActionKind (navigate or convert), and planGoalRef (goal or empty) on every rendered button or actions entry, matching the planned action; its URL must match targetSlug (home => /, otherwise /slug/). These metadata fields do not affect the compiled button style. Do not add unplanned actions or nested section nodes. Do not expand limited topics into invented item grids. A validated single-section plan needs exactly one root section; every other page follows its kept section count.',
					WPHAVE_AI_Block_Design_Compiler::pro_layout_enabled() ? 'For each non-Home page, contentPlan.requiredH1 is the exact, sole h1 heading text. Place it in the opening section. The page title identifies this page topic; do not replace it with a generic project or location heading. All other headings must be h2 or lower.' : '',
					WPHAVE_AI_Block_Design_Compiler::pro_layout_enabled() ? 'brief.availableMedia describes an image already selected for this exact page. Its width, height and aspect ratio may guide spatial choices; they do not verify business facts or image subject. Do not invent a visual node or image description in the tree: the selected editable image block is inserted by the Planner after validation.' : '',
					WPHAVE_AI_Block_Design_Compiler::pro_layout_enabled() ? 'If contentPlan.copyPolicy is locked, render exactly one paragraph in the sole section, with text.content exactly contentPlan.lockedCopy. Never paraphrase or extend it. The server enforces this verified text after generation and excludes it from AI copy revision. Headings and planned actions still follow the normal contract.' : '',
					WPHAVE_AI_Block_Design_Compiler::pro_layout_enabled() ? 'Translate each kept section’s design.emphasis, density and composition into spatial hierarchy using section width, padding, style.align (start|center|end), background and typography. When design.composition is open, do not create asymmetric or gridareas nodes in that section; keep the message in one focused text cluster. Images may be added later without inventing a second text cluster. When design.composition is editorial-lead, editorial-top or editorial-rail, you MUST render a gridareas node with the matching layout.presetKey in that section; a plain stack is rejected. A gridareas node is legal only when that exact planned section has at least as many independently supported contentItems as grid areas (three or four). Each direct child must be a stack or surface containing at least two meaningful heading/paragraph text blocks; an action may accompany that copy. Never put a heading, paragraph and action into three separate grid areas. If a section has only one or two planned contentItems, keep its message and action together in a focused stack or surface. Vary the width and alignment of such sections: a wide dominant hero, a narrower offset information section, a compact closing surface. Do not repeat identical full-width white sections. A dominant section should have a stronger heading and generous space; a quiet section should be compact. Do not fabricate more copy to fill a grid. On mobile the regions form one column in DOM order.' : '',
					WPHAVE_AI_Block_Design_Compiler::pro_layout_enabled() ? 'For a kept section with contentMode=action-only, render one clear heading and exactly its planned actions, with no paragraph or other explanatory text anywhere inside that section. For contentMode=full, paragraphs remain optional but must add verified information. Never turn a valuable verified detail into an action-only section.' : '',
					'Brief.offer and brief.facts are the source of business facts. Sitemap titles and descriptions describe page structure only; they do not verify products, features, integrations, events or results. Put any verified detail into brief.facts before generating.',
					'Brief notes about desired presentation (such as an integration overview or image-led layout) do not prove that a named integration, asset or product feature exists. If uncertain, write truthful editorial copy about the verified offer and the visitor decision instead of asserting a capability.',
					WPHAVE_AI_Block_Design_Compiler::pro_layout_enabled() ? 'Each blockTree root must be a page with 1 to 8 section nodes, exactly matching its validated kept contentPlan sections. A single-section plan is intentional: do not add a filler section. Keep short contact pages concise, and give substantive pages enough sections to cover their purpose. Use only documented node kinds.' : 'Each blockTree root must be a page with 2 to 8 section nodes. Keep short contact pages concise, and give substantive pages enough sections to cover their purpose. Use only documented node kinds.',
					'Give each page a different hierarchy and composition suited to its purpose. Avoid repeating card grids.',
					'For substantive pages with four or more sections, make the opening a spacious editorial hero with padding xl or larger and use at least one flex or grid composition elsewhere only where that section’s planned composition permits it. The planned composition takes priority over this general rhythm suggestion. Vary the section widths and backgrounds deliberately. A stack of headings and paragraphs with identical padding is not a finished composition.',
					'Plan page rhythm before choosing blocks: identify the dominant opening, a compact information moment, a contrasting focal section, and a clear ending. Translate those relationships into the block tree without repeating the same layout in adjacent sections.',
					'Use asymmetric where two content regions have unequal importance, choosing wide-start, wide-end, strong-start, or strong-end. Its two children may contain nested stacks, surfaces, and typography. Use narrow section widths for focused reading and wide widths for spatial compositions. Do not force every section into two columns.',
					'Compose for both desktop and mobile using meaningful text surfaces, clear spacing and short columns. No decorative empty visual panels or large spacer blocks.',
					'Write concrete final copy in the language of the brief. Do not invent facts, prices, metrics, testimonials, named products, exhibitions, dates, awards or services absent from the brief. If evidence is thin, describe the offering without fictional specifics.',
					'State each verified fact once in the most relevant section. Do not restate the offer in every paragraph or fill sections with repeated contact instructions.',
					'A paragraph is optional. If a heading and its planned action already communicate every verified point for that section, omit the paragraph entirely. Never add a sentence merely saying that the heading topic belongs to the offer, and never repeat the section heading in different words. Keep every planned action and section ID.',
					'Do not create examples that read as real inventory: no named works, product cards with invented attributes, exact measurements, quantities, schedules or response times unless the brief provides them. Use editorial sections about the craft, offer and visitor decision instead.',
					'Any number in visitor-facing copy must come verbatim from the brief. Do not turn layout counts or sitemap suggestions into factual claims.',
					'Do not write content-production instructions or placeholders to visitors, such as “add date here”, “details follow”, “image will be added”, or “reserved for”. The page copy must read naturally as a finished page.',
					'Do not explain the editorial plan, missing evidence, or omitted sections to visitors. A merge decision means the unsupported topic should simply not become visitor-facing copy.',
					'Every button URL must be exactly one of the allowedPaths. Do not use section anchors, nested paths, query strings or external destinations. Omit a button if no allowed path fits its action.',
					'Use the existing design tokens and semantic styles. Do not define a new brand identity in this wireframe step.',
					'Return pages as [{"title":"...","slug":"...","plan":{"blockTree":{"kind":"page","nodes":[{"kind":"section","nodes":[]}]}}}].',
					'Block design contract JSON:',
					wp_json_encode( $contract, JSON_UNESCAPED_UNICODE ),
					'allowedPaths JSON:',
					wp_json_encode( $allowed_paths, JSON_UNESCAPED_UNICODE ),
				) ),
			),
			array(
				'role' => 'user',
				'content' => wp_json_encode( array(
					'brief' => $brief,
					'pages' => $pages,
					'sitePages' => $site_page_map,
					'contentPlans' => $content_plans,
					'templateParts' => $sitemap['templateParts'] ?? array(),
				), JSON_UNESCAPED_UNICODE ),
			),
		);
	}

	/**
	 * Change one free section while keeping the other page sections intact.
	 */
	protected static function free_section_messages( array $brief, array $page, array $tree, int $section_index, string $instruction ): array {
		$neighbor_sections = array();
		foreach( $tree['nodes'] as $index => $node ) {
			if( $index !== $section_index ) {
				$neighbor_sections[] = array( 'index' => $index, 'kind' => $node['kind'] ?? '', 'id' => $node['id'] ?? '' );
			}
		}

		return array(
			array(
				'role' => 'system',
				'content' => implode( "\n", array(
					'You edit exactly one section of an editable WPHAVE block design tree.',
					'Return one JSON object in the shape {"section":{"kind":"section","nodes":[]}}. Do not return a whole page.',
					'Use only the block design contract. Never return HTML, CSS, PHP, JavaScript, raw block markup or pattern keys.',
					'Keep the section role and factual content unless the instruction explicitly changes them.',
					'Write concrete copy in the language of the brief. Do not invent facts or metrics.',
					'Block design contract JSON:',
					wp_json_encode( WPHAVE_AI_Block_Design_Compiler::contract_payload(), JSON_UNESCAPED_UNICODE ),
				) ),
			),
			array(
				'role' => 'user',
				'content' => wp_json_encode( array(
					'brief' => $brief,
					'page' => array( 'title' => $page['title'] ?? '', 'intent' => $page['intent'] ?? '' ),
					'neighborSections' => $neighbor_sections,
					'currentSection' => $tree['nodes'][$section_index],
					'instruction' => $instruction,
				), JSON_UNESCAPED_UNICODE ),
			),
		);
	}

/**
	 * Pattern section messages.
	 *
	 * @param array $brief Brief.
	 * @param array $sitemap Sitemap.
	 * @param array $page Page.
	 * @param array $page_plan Page plan.
	 * @param int $section_index Section index.
	 * @param string $instruction Instruction.
	 * @param mixed $style Style.
	 * @return array Pattern section messages.
	 */

	protected static function pattern_section_messages( array $brief, array $sitemap, array $page, array $page_plan, int $section_index, string $instruction, $style ): array {
		$sections = is_array( $page_plan['patternSections'] ?? null ) ? array_values( $page_plan['patternSections'] ) : array();
		$current_section = $sections[$section_index] ?? array();
		$section_catalog = class_exists( 'WPHAVE_Website_Planner_Section_Library' ) ? WPHAVE_Website_Planner_Section_Library::prompt_catalog( 90 ) : array();

		return array(
			array(
				'role' => 'system',
				'content' => implode( "\n", array(
					'You are the Website Planner section generator for a WordPress pattern-section workflow.',
					'Return valid JSON only. Do not output markdown, HTML, CSS, JavaScript, PHP, Gutenberg block markup, comments, explanations, or trailing text.',
					'Regenerate exactly one patternSection. Do not regenerate the whole page.',
					'Select a patternKey from the provided sectionCatalog and fill content slots. Do not invent raw blocks, AST, blockTree, HTML, CSS, or pattern markup.',
					'Keep the section useful within the surrounding page flow. Avoid duplicating adjacent sections.',
					'You may keep the current patternKey when the instruction is mostly copy/content focused. Choose a different patternKey when the requested change needs a different layout.',
					'Use final user-facing copy in the same language as the brief and page. Never use lorem ipsum.',
					'Respect the existing Style Guide context. Do not invent a new visual identity.',
					'Return this JSON shape: {"patternSection":{"id":"...","patternKey":"...","type":"hero|content|features|cta|contact","title":"...","purpose":"...","slots":{"eyebrow":"...","heading":"...","body":"...","items":[{"title":"...","text":"..."}],"actions":[{"label":"...","url":"#"}]}}}.',
					'Allowed sectionCatalog JSON:',
					wp_json_encode( $section_catalog, JSON_UNESCAPED_UNICODE ),
				) ),
			),
			array(
				'role' => 'user',
				'content' => wp_json_encode( array(
					'brief' => $brief,
					'sitemapSummary' => $sitemap['summary'] ?? '',
					'templateParts' => $sitemap['templateParts'] ?? array(),
					'page' => array(
						'title' => $page['title'] ?? '',
						'slug' => $page['slug'] ?? '',
						'intent' => $page['intent'] ?? '',
						'description' => $page['description'] ?? '',
					),
					'pagePatternSections' => $sections,
					'sectionIndex' => $section_index,
					'currentSection' => $current_section,
					'previousSection' => $sections[$section_index - 1] ?? null,
					'nextSection' => $sections[$section_index + 1] ?? null,
					'instruction' => $instruction ?: 'Create a stronger alternative for this section while preserving its role in the page.',
					'styleGuide' => is_array( $style ) ? $style : array(),
				), JSON_UNESCAPED_UNICODE ),
			),
		);
	}

/**
	 * Section messages.
	 *
	 * @param array $brief Brief.
	 * @param array $sitemap Sitemap.
	 * @param array $page Page.
	 * @param array $page_plan Page plan.
	 * @param int $section_index Section index.
	 * @param string $instruction Instruction.
	 * @param mixed $style Style.
	 * @return array Section messages.
	 */

	protected static function section_messages( array $brief, array $sitemap, array $page, array $page_plan, int $section_index, string $instruction, $style ): array {
		$contract = class_exists( 'WPHAVE_AI_Page_Composition_Plan' ) ? WPHAVE_AI_Page_Composition_Plan::contract_payload() : array();
		$knowledge = class_exists( 'WPHAVE_AI_Composition_Knowledge' ) ? WPHAVE_AI_Composition_Knowledge::bundle() : '';
		$sections = is_array( $page_plan['sections'] ?? null ) ? $page_plan['sections'] : array();
		$current_section = $sections[$section_index] ?? array();

		return array(
			array(
				'role' => 'system',
				'content' => implode( "\n", array(
					'You are the Website Planner section generator for a WordPress design workflow.',
					'Return valid JSON only. Do not output markdown, HTML, CSS, JavaScript, PHP, Gutenberg block markup, comments, explanations, or trailing text.',
					'Regenerate exactly one section plan. Do not regenerate the whole page.',
					'Keep the section useful within the surrounding page flow. Avoid duplicating adjacent sections.',
					'Use final user-facing copy in the same language as the brief and page.',
					'Respect the existing Style Guide context. Do not invent a new visual identity.',
					'Return this JSON shape: {"section":{"type":"...","archetype":"...","layout":"...","treatment":"...","emphasis":"...","eyebrow":"...","heading":"...","body":"...","items":[{"title":"...","text":"..."}],"actions":[{"label":"...","variant":"primary","url":"#"}],"imageBrief":"..."}}.',
					'Use the WPHAVE AI Composition Language quality rules when deciding whether the regenerated section is strong enough.',
					'WPHAVE AI Composition Language and quality contract:',
					$knowledge,
					'Allowed section contract:',
					wp_json_encode( $contract['planShape']['sections'][0] ?? array(), JSON_UNESCAPED_UNICODE ),
				) ),
			),
			array(
				'role' => 'user',
				'content' => wp_json_encode( array(
					'brief' => $brief,
					'sitemapSummary' => $sitemap['summary'] ?? '',
					'templateParts' => $sitemap['templateParts'] ?? array(),
					'page' => array(
						'title' => $page['title'] ?? '',
						'slug' => $page['slug'] ?? '',
						'intent' => $page['intent'] ?? '',
						'description' => $page['description'] ?? '',
					),
					'pageComposition' => $page_plan['composition'] ?? array(),
					'sectionIndex' => $section_index,
					'currentSection' => $current_section,
					'previousSection' => $sections[$section_index - 1] ?? null,
					'nextSection' => $sections[$section_index + 1] ?? null,
					'instruction' => $instruction ?: 'Create a stronger alternative for this section while preserving its role in the page.',
					'styleGuide' => is_array( $style ) ? $style : array(),
				), JSON_UNESCAPED_UNICODE ),
			),
		);
	}

/**
	 * Style guide prompt.
	 *
	 * @param array $brief Brief.
	 * @param array $sitemap Sitemap.
	 * @param array $wireframes Wireframes.
	 * @param mixed $current_style Current style.
	 * @param bool $regenerate Regenerate.
	 * @param int $variant_seed Variant seed.
	 * @return string Style guide prompt.
	 */

	protected static function style_guide_prompt( array $brief, array $sitemap, array $wireframes, $current_style, bool $regenerate = false, int $variant_seed = 0 ): string {
		$current_style = is_array( $current_style ) ? $current_style : array();
		$variant = $variant_seed > 0 ? $variant_seed % 6 : 0;
		$regenerate_instruction = $regenerate ? implode( ' ', array(
			'This is a Regenerate Style Guide request.',
			'Do not return the same visual direction as the current planner style draft.',
			'Choose a noticeably different recipe and palette when possible, while still fitting the website.',
			'Use this variant seed to bias the alternative direction: ' . $variant . '.',
			self::style_variant_instruction( $variant ),
		) ) : 'This is the first Style Guide request. Choose the best matching visual direction.';

		return implode( "\n\n", array(
			'Create the Website Planner Style Guide for this planned WordPress website.',
			'Choose a controlled global style recipe that fits the actual project, audience, offer, sitemap and generated page content.',
			'Do not describe implementation details. Pick a visually meaningful direction with enough contrast and a clear brand feeling.',
			'Prefer a distinct but usable visual direction over neutral defaults. Avoid monochrome unless the brief asks for it.',
			$regenerate_instruction,
			'The response must follow the Global Styles recipe JSON contract exactly.',
			'Website brief JSON:' . "\n" . wp_json_encode( $brief, JSON_UNESCAPED_UNICODE ),
			'Sitemap JSON:' . "\n" . wp_json_encode( array(
				'projectName' => $sitemap['projectName'] ?? '',
				'summary' => $sitemap['summary'] ?? '',
				'templateParts' => $sitemap['templateParts'] ?? array(),
				'pages' => $sitemap['pages'] ?? array(),
			), JSON_UNESCAPED_UNICODE ),
			'Generated wireframe content summary JSON:' . "\n" . wp_json_encode( $wireframes, JSON_UNESCAPED_UNICODE ),
			'Current planner style draft JSON:' . "\n" . wp_json_encode( $current_style, JSON_UNESCAPED_UNICODE ),
		) );
	}

/**
	 * Normalize the source value.
	 *
	 * @param string $action Action.
	 * @return array Normalize the source value.
	 */

	protected static function source( string $action ): array {
		return array(
			'type' => 'ai',
			'action' => sanitize_key( $action ),
			'createdAt' => gmdate( 'c' ),
		);
	}

/**
	 * Extract json object.
	 *
	 * @param string $response Response.
	 * @return string Extract json object.
	 */

	protected static function extract_json_object( string $response ): string {
		$response = trim( preg_replace( '/^```(?:json)?|```$/m', '', $response ) );
		$start = strpos( $response, '{' );
		$end = strrpos( $response, '}' );

		if( $start === false || $end === false || $end <= $start ) {
			return $response;
		}

		return substr( $response, $start, $end - $start + 1 );
	}

}
