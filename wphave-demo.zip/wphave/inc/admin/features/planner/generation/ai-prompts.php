<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Website_Plan_AI_Prompts {

/**
	 * Sitemap messages.
	 *
	 * @param array $brief Brief.
	 * @return array Sitemap messages.
	 */

	protected static function sitemap_messages( array $brief ): array {
		$page_limit = self::page_limit( $brief['scope'] ?? 'standard' );

		return array(
			array(
				'role' => 'system',
				'content' => implode( "\n", array(
					'You are the Website Planner for a WordPress design workflow.',
					'Return valid JSON only. Do not output markdown, HTML, CSS, JavaScript, PHP, Gutenberg block markup, comments, explanations, or trailing text.',
					'Create the first sitemap from the brief. Decide which pages are useful, not just generic placeholders.',
					'Use the same language as the brief. Write concrete user-facing planning content. Never use lorem ipsum.',
					'The JSON shape must be: {"projectName":"...","summary":"...","templateParts":{"header":{"title":"Header","intent":"...","sections":[{"title":"Logo and navigation","description":"..."}]},"footer":{"title":"Footer","intent":"...","sections":[{"title":"Footer navigation","description":"..."}]}},"pages":[{"title":"Home","slug":"home","intent":"...","description":"...","sections":[{"title":"Hero Header Section","description":"..."}]}]}.',
					'Home must be the first page. Include About and Contact when they fit the brief. Add other pages only when they support the goal.',
					'Header and Footer are global template parts. Do not include Navbar or Footer sections inside individual pages.',
					'Each page needs 3 to 6 sections. Section descriptions must explain actual content for that business.',
					'Keep page count between 3 and ' . $page_limit . '.',
					'The sitemap will later become real WordPress pages, so avoid vague section titles and duplicated page intents.',
				) ),
			),
			array(
				'role' => 'user',
				'content' => wp_json_encode( array(
					'brief' => $brief,
					'pageLimit' => $page_limit,
				), JSON_UNESCAPED_UNICODE ),
			),
		);
	}

/**
	 * Wireframe messages.
	 *
	 * @param array $brief Brief.
	 * @param array $sitemap Sitemap.
	 * @return array Wireframe messages.
	 */

	protected static function wireframe_messages( array $brief, array $sitemap ): array {
		$pages = array_slice( $sitemap['pages'] ?? array(), 0, self::page_limit( $brief['scope'] ?? 'standard' ) );
		$section_catalog = class_exists( 'WPHAVE_Website_Planner_Section_Library' ) ? WPHAVE_Website_Planner_Section_Library::prompt_catalog( 90 ) : array();

		return array(
			array(
				'role' => 'system',
				'content' => implode( "\n", array(
					'You are the Website Planner wireframe generator for a WordPress design workflow.',
					'Return valid JSON only. Do not output markdown, HTML, CSS, JavaScript, PHP, Gutenberg block markup, comments, explanations, or trailing text.',
					'Convert every sitemap page into a Website Planner wireframe by selecting section layouts from the provided sectionCatalog.',
					'Do not invent raw blocks, blockTree, AST, HTML, CSS, or pattern markup. Select known patternKey values and fill their content slots.',
					'For each page, plan.patternSections is the primary render source. Every page must include 3 to 7 patternSections.',
					'Use a hero-like section first when available, then page-specific content sections, and only use CTA sections where a real next step is useful.',
					'Choose different section keys and rhythms across pages. Do not use the same sequence for every page.',
					'Do not create visual style guides, colors, fonts, or global design identity. This is still the wireframe/content step.',
					'Use final user-facing copy in the same language as the brief and sitemap. Never use lorem ipsum.',
					'Each generated page must keep the original title and slug from the sitemap.',
					'Create strong page-specific content from the sitemap intent and section descriptions. Do not repeat the same content across pages.',
					'Slot rules: heading is required, body should be concrete, items are for cards/lists, actions are buttons. Keep copy concise enough for wireframes.',
					'Also convert the global header and footer into concise template part plans. They are shared across all pages.',
					'Return this JSON shape: {"templateParts":{"header":{"title":"Header","plan":{"logo":"...","navigation":[{"label":"...","url":"#..."}],"actions":[{"label":"...","url":"#"}]}},"footer":{"title":"Footer","plan":{"summary":"...","columns":[{"title":"...","items":[{"label":"...","url":"#..."}]}]}}},"pages":[{"title":"...","slug":"...","plan":{"version":1,"intent":"...","summary":"...","patternSections":[{"id":"hero","patternKey":"...","type":"hero|content|features|cta|contact","title":"...","purpose":"...","slots":{"eyebrow":"...","heading":"...","body":"...","items":[{"title":"...","text":"..."}],"actions":[{"label":"...","url":"#"}]}}]}}]}.',
					'Allowed sectionCatalog JSON:',
					wp_json_encode( $section_catalog, JSON_UNESCAPED_UNICODE ),
				) ),
			),
			array(
				'role' => 'user',
				'content' => wp_json_encode( array(
					'brief' => $brief,
					'sitemapSummary' => $sitemap['summary'] ?? '',
					'templateParts' => $sitemap['templateParts'] ?? array(),
					'pages' => $pages,
				), JSON_UNESCAPED_UNICODE ),
			),
		);
	}

/**
	 * Pattern section messages.
	 *
	 * @param array $brief Brief.
	 * @param array $sitemap Sitemap.
	 * @param array $page Page.
	 * @param array $page_plan Page plan.
	 * @param int $section_index Section index.
	 * @param string $instruction Instruction.
	 * @param mixed $style Style.
	 * @return array Pattern section messages.
	 */

	protected static function pattern_section_messages( array $brief, array $sitemap, array $page, array $page_plan, int $section_index, string $instruction, $style ): array {
		$sections = is_array( $page_plan['patternSections'] ?? null ) ? array_values( $page_plan['patternSections'] ) : array();
		$current_section = $sections[$section_index] ?? array();
		$section_catalog = class_exists( 'WPHAVE_Website_Planner_Section_Library' ) ? WPHAVE_Website_Planner_Section_Library::prompt_catalog( 90 ) : array();

		return array(
			array(
				'role' => 'system',
				'content' => implode( "\n", array(
					'You are the Website Planner section generator for a WordPress pattern-section workflow.',
					'Return valid JSON only. Do not output markdown, HTML, CSS, JavaScript, PHP, Gutenberg block markup, comments, explanations, or trailing text.',
					'Regenerate exactly one patternSection. Do not regenerate the whole page.',
					'Select a patternKey from the provided sectionCatalog and fill content slots. Do not invent raw blocks, AST, blockTree, HTML, CSS, or pattern markup.',
					'Keep the section useful within the surrounding page flow. Avoid duplicating adjacent sections.',
					'You may keep the current patternKey when the instruction is mostly copy/content focused. Choose a different patternKey when the requested change needs a different layout.',
					'Use final user-facing copy in the same language as the brief and page. Never use lorem ipsum.',
					'Respect the existing Style Guide context. Do not invent a new visual identity.',
					'Return this JSON shape: {"patternSection":{"id":"...","patternKey":"...","type":"hero|content|features|cta|contact","title":"...","purpose":"...","slots":{"eyebrow":"...","heading":"...","body":"...","items":[{"title":"...","text":"..."}],"actions":[{"label":"...","url":"#"}]}}}.',
					'Allowed sectionCatalog JSON:',
					wp_json_encode( $section_catalog, JSON_UNESCAPED_UNICODE ),
				) ),
			),
			array(
				'role' => 'user',
				'content' => wp_json_encode( array(
					'brief' => $brief,
					'sitemapSummary' => $sitemap['summary'] ?? '',
					'templateParts' => $sitemap['templateParts'] ?? array(),
					'page' => array(
						'title' => $page['title'] ?? '',
						'slug' => $page['slug'] ?? '',
						'intent' => $page['intent'] ?? '',
						'description' => $page['description'] ?? '',
					),
					'pagePatternSections' => $sections,
					'sectionIndex' => $section_index,
					'currentSection' => $current_section,
					'previousSection' => $sections[$section_index - 1] ?? null,
					'nextSection' => $sections[$section_index + 1] ?? null,
					'instruction' => $instruction ?: 'Create a stronger alternative for this section while preserving its role in the page.',
					'styleGuide' => is_array( $style ) ? $style : array(),
				), JSON_UNESCAPED_UNICODE ),
			),
		);
	}

/**
	 * Section messages.
	 *
	 * @param array $brief Brief.
	 * @param array $sitemap Sitemap.
	 * @param array $page Page.
	 * @param array $page_plan Page plan.
	 * @param int $section_index Section index.
	 * @param string $instruction Instruction.
	 * @param mixed $style Style.
	 * @return array Section messages.
	 */

	protected static function section_messages( array $brief, array $sitemap, array $page, array $page_plan, int $section_index, string $instruction, $style ): array {
		$contract = class_exists( 'WPHAVE_AI_Page_Composition_Plan' ) ? WPHAVE_AI_Page_Composition_Plan::contract_payload() : array();
		$knowledge = class_exists( 'WPHAVE_AI_Composition_Knowledge' ) ? WPHAVE_AI_Composition_Knowledge::bundle() : '';
		$sections = is_array( $page_plan['sections'] ?? null ) ? $page_plan['sections'] : array();
		$current_section = $sections[$section_index] ?? array();

		return array(
			array(
				'role' => 'system',
				'content' => implode( "\n", array(
					'You are the Website Planner section generator for a WordPress design workflow.',
					'Return valid JSON only. Do not output markdown, HTML, CSS, JavaScript, PHP, Gutenberg block markup, comments, explanations, or trailing text.',
					'Regenerate exactly one section plan. Do not regenerate the whole page.',
					'Keep the section useful within the surrounding page flow. Avoid duplicating adjacent sections.',
					'Use final user-facing copy in the same language as the brief and page.',
					'Respect the existing Style Guide context. Do not invent a new visual identity.',
					'Return this JSON shape: {"section":{"type":"...","archetype":"...","layout":"...","treatment":"...","emphasis":"...","eyebrow":"...","heading":"...","body":"...","items":[{"title":"...","text":"..."}],"actions":[{"label":"...","variant":"primary","url":"#"}],"imageBrief":"..."}}.',
					'Use the WPHAVE AI Composition Language quality rules when deciding whether the regenerated section is strong enough.',
					'WPHAVE AI Composition Language and quality contract:',
					$knowledge,
					'Allowed section contract:',
					wp_json_encode( $contract['planShape']['sections'][0] ?? array(), JSON_UNESCAPED_UNICODE ),
				) ),
			),
			array(
				'role' => 'user',
				'content' => wp_json_encode( array(
					'brief' => $brief,
					'sitemapSummary' => $sitemap['summary'] ?? '',
					'templateParts' => $sitemap['templateParts'] ?? array(),
					'page' => array(
						'title' => $page['title'] ?? '',
						'slug' => $page['slug'] ?? '',
						'intent' => $page['intent'] ?? '',
						'description' => $page['description'] ?? '',
					),
					'pageComposition' => $page_plan['composition'] ?? array(),
					'sectionIndex' => $section_index,
					'currentSection' => $current_section,
					'previousSection' => $sections[$section_index - 1] ?? null,
					'nextSection' => $sections[$section_index + 1] ?? null,
					'instruction' => $instruction ?: 'Create a stronger alternative for this section while preserving its role in the page.',
					'styleGuide' => is_array( $style ) ? $style : array(),
				), JSON_UNESCAPED_UNICODE ),
			),
		);
	}

/**
	 * Style guide prompt.
	 *
	 * @param array $brief Brief.
	 * @param array $sitemap Sitemap.
	 * @param array $wireframes Wireframes.
	 * @param mixed $current_style Current style.
	 * @param bool $regenerate Regenerate.
	 * @param int $variant_seed Variant seed.
	 * @return string Style guide prompt.
	 */

	protected static function style_guide_prompt( array $brief, array $sitemap, array $wireframes, $current_style, bool $regenerate = false, int $variant_seed = 0 ): string {
		$current_style = is_array( $current_style ) ? $current_style : array();
		$variant = $variant_seed > 0 ? $variant_seed % 6 : 0;
		$regenerate_instruction = $regenerate ? implode( ' ', array(
			'This is a Regenerate Style Guide request.',
			'Do not return the same visual direction as the current planner style draft.',
			'Choose a noticeably different recipe and palette when possible, while still fitting the website.',
			'Use this variant seed to bias the alternative direction: ' . $variant . '.',
			self::style_variant_instruction( $variant ),
		) ) : 'This is the first Style Guide request. Choose the best matching visual direction.';

		return implode( "\n\n", array(
			'Create the Website Planner Style Guide for this planned WordPress website.',
			'Choose a controlled global style recipe that fits the actual project, audience, offer, sitemap and generated page content.',
			'Do not describe implementation details. Pick a visually meaningful direction with enough contrast and a clear brand feeling.',
			'Prefer a distinct but usable visual direction over neutral defaults. Avoid monochrome unless the brief asks for it.',
			$regenerate_instruction,
			'The response must follow the Global Styles recipe JSON contract exactly.',
			'Website brief JSON:' . "\n" . wp_json_encode( $brief, JSON_UNESCAPED_UNICODE ),
			'Sitemap JSON:' . "\n" . wp_json_encode( array(
				'projectName' => $sitemap['projectName'] ?? '',
				'summary' => $sitemap['summary'] ?? '',
				'templateParts' => $sitemap['templateParts'] ?? array(),
				'pages' => $sitemap['pages'] ?? array(),
			), JSON_UNESCAPED_UNICODE ),
			'Generated wireframe content summary JSON:' . "\n" . wp_json_encode( $wireframes, JSON_UNESCAPED_UNICODE ),
			'Current planner style draft JSON:' . "\n" . wp_json_encode( $current_style, JSON_UNESCAPED_UNICODE ),
		) );
	}

/**
	 * Normalize the source value.
	 *
	 * @param string $action Action.
	 * @return array Normalize the source value.
	 */

	protected static function source( string $action ): array {
		return array(
			'type' => 'ai',
			'action' => sanitize_key( $action ),
			'createdAt' => gmdate( 'c' ),
		);
	}

/**
	 * Extract json object.
	 *
	 * @param string $response Response.
	 * @return string Extract json object.
	 */

	protected static function extract_json_object( string $response ): string {
		$response = trim( preg_replace( '/^```(?:json)?|```$/m', '', $response ) );
		$start = strpos( $response, '{' );
		$end = strrpos( $response, '}' );

		if( $start === false || $end === false || $end <= $start ) {
			return $response;
		}

		return substr( $response, $start, $end - $start + 1 );
	}

}
