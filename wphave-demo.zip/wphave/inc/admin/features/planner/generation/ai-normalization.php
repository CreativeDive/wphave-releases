<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Website_Plan_AI_Normalization {

/**
	 * Sanitize brief.
	 *
	 * @param mixed $brief Brief.
	 * @return array Sanitize brief.
	 */

	protected static function sanitize_brief( $brief ): array {
		$brief = is_array( $brief ) ? $brief : array();
		$scope = sanitize_key( $brief['scope'] ?? 'standard' );
		$scope = in_array( $scope, array( 'compact', 'standard', 'expanded' ), true ) ? $scope : 'standard';
		$tone = sanitize_key( $brief['tone'] ?? 'premium' );
		$tone = in_array( $tone, array( 'premium', 'editorial', 'friendly', 'technical' ), true ) ? $tone : 'premium';

		return array(
			'projectName' => trim( mb_substr( sanitize_text_field( (string) ( $brief['projectName'] ?? '' ) ), 0, 120 ) ),
			'industry' => trim( mb_substr( sanitize_text_field( (string) ( $brief['industry'] ?? '' ) ), 0, 160 ) ),
			'audience' => trim( mb_substr( sanitize_text_field( (string) ( $brief['audience'] ?? '' ) ), 0, 220 ) ),
			'offer' => trim( mb_substr( sanitize_text_field( (string) ( $brief['offer'] ?? '' ) ), 0, 260 ) ),
			'goal' => trim( mb_substr( sanitize_text_field( (string) ( $brief['goal'] ?? '' ) ), 0, 180 ) ),
			'notes' => trim( mb_substr( sanitize_textarea_field( (string) ( $brief['notes'] ?? '' ) ), 0, 1800 ) ),
			'tone' => $tone,
			'scope' => $scope,
		);
	}

/**
	 * Sanitize pattern items.
	 *
	 * @param array $items Items.
	 * @return array Sanitize pattern items.
	 */

	protected static function sanitize_pattern_items( $items ): array {
		$result = array();

		foreach( array_slice( (array) $items, 0, 8 ) as $item ) {
			if( ! is_array( $item ) ) {
				continue;
			}

			$result[] = array(
				'title' => sanitize_text_field( (string) ( $item['title'] ?? '' ) ),
				'text' => sanitize_textarea_field( (string) ( $item['text'] ?? $item['description'] ?? '' ) ),
			);
		}

		return $result;
	}

/**
	 * Sanitize pattern actions.
	 *
	 * @param mixed $actions Actions.
	 * @return array Sanitize pattern actions.
	 */

	protected static function sanitize_pattern_actions( $actions ): array {
		$result = array();

		foreach( array_slice( (array) $actions, 0, 3 ) as $action ) {
			if( ! is_array( $action ) ) {
				continue;
			}

			$result[] = array(
				'label' => sanitize_text_field( (string) ( $action['label'] ?? '' ) ),
				'url' => esc_url_raw( (string) ( $action['url'] ?? '#' ) ),
			);
		}

		return $result;
	}

/**
	 * Style guides match.
	 *
	 * @param mixed $first First.
	 * @param mixed $second Second.
	 * @return bool Style guides match.
	 */

	protected static function style_guides_match( $first, $second ): bool {
		if( ! is_array( $first ) || ! is_array( $second ) || empty( $first ) || empty( $second ) ) {
			return false;
		}

		return wp_json_encode( self::sort_array_recursive( $first ) ) === wp_json_encode( self::sort_array_recursive( $second ) );
	}

/**
	 * Sort array recursive.
	 *
	 * @param array $value Value.
	 * @return array Sort array recursive.
	 */

	protected static function sort_array_recursive( array $value ): array {
		foreach( $value as $key => $item ) {
			if( is_array( $item ) ) {
				$value[$key] = self::sort_array_recursive( $item );
			}
		}

		ksort( $value );

		return $value;
	}

/**
	 * Sanitize wireframe context.
	 *
	 * @param mixed $wireframes Wireframes.
	 * @param array $sitemap_pages Sitemap pages.
	 * @return array Sanitize wireframe context.
	 */

	protected static function sanitize_wireframe_context( $wireframes, array $sitemap_pages ): array {
		$wireframes = is_array( $wireframes ) ? $wireframes : array();
		$result = array();

		foreach( $wireframes as $index => $page ) {
			if( ! is_array( $page ) ) {
				continue;
			}

			$sitemap_page = is_array( $sitemap_pages[$index] ?? null ) ? $sitemap_pages[$index] : array();
			$plan = is_array( $page['plan'] ?? null ) ? $page['plan'] : array();
			$sections = is_array( $plan['sections'] ?? null ) ? array_slice( $plan['sections'], 0, 6 ) : array();
			$pattern_sections = is_array( $plan['patternSections'] ?? null ) ? array_slice( $plan['patternSections'], 0, 8 ) : array();
			$summary_sections = array();

			foreach( ! empty( $pattern_sections ) ? $pattern_sections : $sections as $section ) {
				if( ! is_array( $section ) ) {
					continue;
				}

				$summary_sections[] = array(
					'type' => sanitize_key( (string) ( $section['type'] ?? '' ) ),
					'archetype' => sanitize_key( (string) ( $section['archetype'] ?? '' ) ),
					'layout' => sanitize_key( (string) ( $section['layout'] ?? '' ) ),
					'treatment' => sanitize_key( (string) ( $section['treatment'] ?? '' ) ),
					'patternKey' => sanitize_key( (string) ( $section['patternKey'] ?? '' ) ),
					'heading' => trim( mb_substr( sanitize_text_field( (string) ( $section['heading'] ?? $section['slots']['heading'] ?? '' ) ), 0, 160 ) ),
					'body' => trim( mb_substr( sanitize_textarea_field( (string) ( $section['body'] ?? $section['slots']['body'] ?? '' ) ), 0, 260 ) ),
				);
			}

			$content_excerpt = trim( mb_substr( sanitize_textarea_field( wp_strip_all_tags( (string) ( $page['content'] ?? '' ) ) ), 0, 600 ) );

			$result[] = array(
				'title' => trim( mb_substr( sanitize_text_field( (string) ( $page['title'] ?? $sitemap_page['title'] ?? '' ) ), 0, 120 ) ),
				'slug' => self::slug( $page['slug'] ?? $sitemap_page['slug'] ?? '', $page['title'] ?? $sitemap_page['title'] ?? '', $index ),
				'intent' => trim( mb_substr( sanitize_textarea_field( (string) ( $page['intent'] ?? $sitemap_page['intent'] ?? '' ) ), 0, 260 ) ),
				'description' => trim( mb_substr( sanitize_textarea_field( (string) ( $page['description'] ?? $sitemap_page['description'] ?? '' ) ), 0, 320 ) ),
				'composition' => is_array( $plan['composition'] ?? null ) ? $plan['composition'] : array(),
				'sections' => $summary_sections,
				'contentExcerpt' => $content_excerpt,
			);
		}

		return $result;
	}

/**
	 * Fallback page plan.
	 *
	 * @param array $page Page.
	 * @param int $index Index.
	 * @return array Fallback page plan.
	 */

	protected static function fallback_page_plan( array $page, int $index ): array {
		$title = sanitize_text_field( (string) ( $page['title'] ?? 'Page' ) );
		$intent = trim( sanitize_textarea_field( (string) ( $page['intent'] ?? $page['description'] ?? '' ) ) );
		$sections = array_values( array_filter( array_map( function( $section ) {
			return is_array( $section ) ? $section : array();
		}, is_array( $page['sections'] ?? null ) ? $page['sections'] : array() ) ) );
		$plan_sections = array();

		$plan_sections[] = array(
			'type' => 'hero',
			'archetype' => $index === 0 ? 'hero-showcase' : 'hero-editorial',
			'layout' => $index === 0 ? 'centered' : 'split',
			'treatment' => $index === 0 ? 'bold' : 'soft',
			'emphasis' => 'high',
			'eyebrow' => $index === 0 ? 'Website' : $title,
			'heading' => $title,
			'body' => $intent ?: sanitize_textarea_field( (string) ( $page['description'] ?? '' ) ),
			'actions' => array(
				array(
					'label' => 'Get started',
					'variant' => 'primary',
					'url' => '#',
				),
			),
		);

		foreach( $sections as $section ) {
			$heading = trim( sanitize_text_field( (string) ( $section['title'] ?? '' ) ) );
			$body = trim( sanitize_textarea_field( (string) ( $section['description'] ?? '' ) ) );

			if( $heading === '' || in_array( strtolower( $heading ), array( 'navbar', 'footer' ), true ) ) {
				continue;
			}

			$plan_sections[] = self::section_to_page_plan_section( $heading, $body, count( $plan_sections ) );

			if( count( $plan_sections ) >= 5 ) {
				break;
			}
		}

		if( count( $plan_sections ) < 3 ) {
			$plan_sections[] = array(
				'type' => 'features',
				'archetype' => 'bento-showcase',
				'layout' => 'bento',
				'treatment' => 'outlined',
				'emphasis' => 'medium',
				'eyebrow' => 'Highlights',
				'heading' => 'What visitors should understand',
				'body' => $intent ?: 'This page gives visitors the core information they need before taking the next step.',
				'items' => self::items_from_sections( $sections ),
			);
		}

		$plan_sections[] = array(
			'type' => 'cta',
			'archetype' => 'framed-cta',
			'layout' => 'panel',
			'treatment' => 'framed',
			'emphasis' => 'high',
			'eyebrow' => 'Next step',
			'heading' => 'Ready to move forward?',
			'body' => 'Use this page to guide visitors toward the clearest next action.',
			'actions' => array(
				array(
					'label' => 'Contact us',
					'variant' => 'primary',
					'url' => '#',
				),
			),
		);

		$plan = array(
			'version' => 1,
			'intent' => $intent,
			'summary' => sanitize_textarea_field( (string) ( $page['description'] ?? $intent ) ),
			'composition' => array(
				'density' => $index === 0 ? 'balanced' : 'compact',
				'rhythm' => 'varied',
				'surface' => 'soft',
				'contrast' => 'medium',
				'flow' => $index === 0 ? 'showcase' : 'conversion',
				'layoutRecipe' => $index === 0 ? 'poster-lead' : 'compact-service',
			),
			'sections' => $plan_sections,
		);
		$plan['ast'] = self::sections_to_ast( $plan_sections, $page, $plan, $index );

		return $plan;
	}

/**
	 * Normalize sitemap.
	 *
	 * @param mixed $data Data.
	 * @param array $brief Brief.
	 * @return array Normalize sitemap.
	 */

	protected static function normalize_sitemap( $data, array $brief ): array {
		$data = is_array( $data ) ? $data : array();
		$pages = array();
		$raw_pages = is_array( $data['pages'] ?? null ) ? $data['pages'] : array();
		$page_limit = self::page_limit( $brief['scope'] ?? 'standard' );

		foreach( $raw_pages as $index => $page ) {
			$normalized = self::sanitize_page( $page, $index );

			if( $normalized ) {
				$pages[] = $normalized;
			}

			if( count( $pages ) >= $page_limit ) {
				break;
			}
		}

		if( empty( $pages ) ) {
			return array(
				'projectName' => $brief['projectName'],
				'summary' => '',
				'templateParts' => self::fallback_template_parts( array(), $brief ),
				'pages' => array(),
			);
		}

		$home_index = 0;

		foreach( $pages as $index => $page ) {
			if( $page['slug'] === 'home' || strtolower( $page['title'] ) === 'home' || strtolower( $page['title'] ) === 'homepage' ) {
				$home_index = $index;
				break;
			}
		}

		if( $home_index !== 0 ) {
			$home = $pages[$home_index];
			unset( $pages[$home_index] );
			array_unshift( $pages, $home );
			$pages = array_values( $pages );
		}

		$pages[0]['title'] = $pages[0]['title'] ?: 'Home';
		$pages[0]['slug'] = 'home';

		return array(
			'projectName' => trim( mb_substr( sanitize_text_field( (string) ( $data['projectName'] ?? $brief['projectName'] ) ), 0, 120 ) ),
			'summary' => trim( mb_substr( sanitize_textarea_field( (string) ( $data['summary'] ?? '' ) ), 0, 700 ) ),
			'templateParts' => self::sanitize_template_parts( $data['templateParts'] ?? array(), $pages, $brief ),
			'pages' => $pages,
		);
	}

/**
	 * Sanitize page.
	 *
	 * @param int $page Page.
	 * @param int $index Index.
	 * @return array Sanitize page.
	 */

	protected static function sanitize_page( $page, int $index ): array {
		if( ! is_array( $page ) ) {
			return array();
		}

		$title = trim( mb_substr( sanitize_text_field( (string) ( $page['title'] ?? '' ) ), 0, 100 ) );

		if( $title === '' ) {
			return array();
		}

		$sections = self::sanitize_sections( $page['sections'] ?? array() );

		if( empty( $sections ) ) {
			$sections = array(
				array(
					'title' => 'Hero Header Section',
					'description' => trim( mb_substr( sanitize_textarea_field( (string) ( $page['description'] ?? $page['intent'] ?? '' ) ), 0, 220 ) ),
				),
			);
		}

		return array(
			'title' => $title,
			'slug' => self::slug( $page['slug'] ?? '', $title, $index ),
			'intent' => trim( mb_substr( sanitize_textarea_field( (string) ( $page['intent'] ?? '' ) ), 0, 260 ) ),
			'description' => trim( mb_substr( sanitize_textarea_field( (string) ( $page['description'] ?? '' ) ), 0, 360 ) ),
			'source' => self::source( 'sitemap' ),
			'sections' => $sections,
		);
	}

/**
	 * Sanitize sections.
	 *
	 * @param array $sections Sections.
	 * @return array Sanitize sections.
	 */

	protected static function sanitize_sections( $sections ): array {
		if( ! is_array( $sections ) ) {
			return array();
		}

		$normalized = array();

		foreach( $sections as $section ) {
			if( ! is_array( $section ) ) {
				continue;
			}

			$title = trim( mb_substr( sanitize_text_field( (string) ( $section['title'] ?? '' ) ), 0, 100 ) );

			if( $title === '' ) {
				continue;
			}

			$normalized[] = array(
				'title' => $title,
				'description' => trim( mb_substr( sanitize_textarea_field( (string) ( $section['description'] ?? '' ) ), 0, 300 ) ),
				'source' => self::source( 'sitemap_section' ),
			);

			if( count( $normalized ) >= 6 ) {
				break;
			}
		}

		return $normalized;
	}

/**
	 * Page limit.
	 *
	 * @param string $scope Scope.
	 * @return int Page limit.
	 */

	protected static function page_limit( string $scope ): int {
		if( $scope === 'compact' ) {
			return 4;
		}

		if( $scope === 'expanded' ) {
			return 8;
		}

		return 6;
	}

/**
	 * Slug.
	 *
	 * @param string $slug Slug.
	 * @param string $title Title.
	 * @param int $index Index.
	 * @return string Slug.
	 */

	protected static function slug( $slug, string $title, int $index ): string {
		$slug = sanitize_title( (string) $slug );

		if( $slug === '' ) {
			$slug = sanitize_title( $title );
		}

		if( $slug === '' ) {
			$slug = 'page-' . ( $index + 1 );
		}

		return $slug;
	}

}
