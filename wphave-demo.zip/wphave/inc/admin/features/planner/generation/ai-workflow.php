<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Website_Plan_AI_Workflow {

/**
	 * Create sitemap.
	 *
	 * @param array $params Params.
	 * @param callable $generate_text Generate text.
	 */

	public static function create_sitemap( array $params, callable $generate_text ) {
		$brief = self::sanitize_brief( $params['brief'] ?? array() );
		unset( $brief['pageFactsBySlug'] );
		$composition_mode = 'pattern-workspace';

		$brief_values = array(
			$brief['projectName'],
			$brief['industry'],
			$brief['audience'],
			$brief['offer'],
			$brief['goal'],
			$brief['facts'],
			$brief['notes'],
		);
		if( trim( implode( '', $brief_values ) ) === '' ) {
			return new WP_Error( 'ai_website_brief_missing', __( 'A website brief is required.', 'wphave' ), array( 'status' => 400 ) );
		}

		$options = WPHAVE_AI_Schema::sanitize_options( $params['options'] ?? array() );
		$options['responseFormat'] = 'json_object';
		$options['maxTokens'] = max( 6500, (int) ( $options['maxTokens'] ?? 0 ) );

		$response = $generate_text( self::sitemap_messages( $brief, $composition_mode ), $options );

		if( is_wp_error( $response ) ) {
			return $response;
		}

		$data = json_decode( self::extract_json_object( (string) ( $response['result'] ?? '' ) ), true );

		if( ! is_array( $data ) ) {
			return new WP_Error( 'ai_website_sitemap_invalid_json', __( 'The AI response could not be converted into a sitemap.', 'wphave' ), array( 'status' => 502 ) );
		}

		$sitemap = self::normalize_sitemap( $data['sitemap'] ?? $data, $brief );
		if( $composition_mode === 'pattern-workspace' ) {
			foreach( $sitemap['pages'] as &$page ) {
				$page['intent'] = '';
				$page['description'] = '';
				$page['sections'] = array();
			}
			unset( $page );
			$sitemap['summary'] = $brief['goal'] ?: $brief['offer'];
			$sitemap['templateParts'] = self::fallback_template_parts( $sitemap['pages'], $brief );
		}

		if( empty( $sitemap['pages'] ) ) {
			return new WP_Error( 'ai_website_sitemap_empty', __( 'The AI response did not contain valid website pages.', 'wphave' ), array( 'status' => 502 ) );
		}

		return array(
			'sitemap' => $sitemap,
			'provider' => $response['provider'] ?? '',
			'meta' => $response['meta'] ?? null,
		);
	}

/**
	 * Create wireframes.
	 *
	 * @param array $params Params.
	 * @param callable $generate_text Generate text.
	 */

	public static function create_wireframes( array $params, callable $generate_text ) {
		if( ! self::pattern_composition_enabled() ) {
			return new WP_Error( 'ai_website_patterns_unavailable', __( 'Pattern composition is not available.', 'wphave' ), array( 'status' => 403 ) );
		}

		$brief = self::sanitize_brief( $params['brief'] ?? array() );
		$sitemap = self::normalize_sitemap( $params['sitemap'] ?? array(), $brief );
		if( empty( $sitemap['pages'] ) ) {
			return new WP_Error( 'ai_website_sitemap_empty', __( 'A generated sitemap is required before wireframes can be created.', 'wphave' ), array( 'status' => 400 ) );
		}

		$target_slug = sanitize_title( (string) ( $params['targetPageSlug'] ?? '' ) );
		$pages_to_generate = $sitemap['pages'];
		if( $target_slug !== '' ) {
			$pages_to_generate = array_values( array_filter( $pages_to_generate, static function( $page ) use ( $target_slug ) {
				return ( $page['slug'] ?? '' ) === $target_slug;
			} ) );
			if( count( $pages_to_generate ) !== 1 ) {
				return new WP_Error( 'ai_website_target_page_invalid', __( 'The requested page is not in the sitemap.', 'wphave' ), array( 'status' => 400 ) );
			}
		}

		$media = WPHAVE_Website_Plan_Page_Media_Context::resolve( $params['targetMediaId'] ?? null );
		if( is_wp_error( $media ) ) {
			return $media;
		}
		$approved_media_ids = $media === array() ? array() : array( absint( $media['id'] ?? $media['attachmentId'] ?? 0 ) );
		$options = WPHAVE_AI_Schema::sanitize_options( $params['options'] ?? array() );
		$pages = array();
		$provider = '';
		$meta = null;
		foreach( $pages_to_generate as $page ) {
			$page_brief = self::brief_for_page( $brief, $page['slug'], $sitemap['pages'] );
			$result = WPHAVE_Website_Plan_Pattern_AI_Workflow::generate(
				$page_brief,
				$page,
				$sitemap['pages'],
				$approved_media_ids,
				$generate_text,
				$options
			);
			if( is_wp_error( $result ) ) {
				return $result;
			}
			$pages[] = $result['page'];
			$provider = $result['provider'];
			$meta = $result['meta'];
		}

		return array(
			'pages' => $pages,
			'templateParts' => $sitemap['templateParts'],
			'compositionMode' => 'pattern-workspace',
			'provider' => $provider,
			'meta' => $meta,
		);
	}

	private static function pattern_composition_enabled(): bool {
		return ( function_exists( 'wphave_release_feature_ready' ) && wphave_release_feature_ready( 'aiPatternComposition' ) )
			|| ( defined( 'WPHAVE_DISPOSABLE_TEST_SITE' ) && WPHAVE_DISPOSABLE_TEST_SITE
				&& defined( 'WPHAVE_TEST_AI_PATTERN_COMPOSITION' ) && WPHAVE_TEST_AI_PATTERN_COMPOSITION );
	}

	protected static function apply_locked_free_copy( array $pages, array $content_plans ): array {
		foreach( $pages as &$page ) {
			$slug = (string) ( $page['slug'] ?? '' );
			if( ! isset( $content_plans[$slug] ) || ! is_array( $page['plan']['blockTree'] ?? null ) ) {
				continue;
			}
			$page['plan']['blockTree'] = WPHAVE_Website_Plan_Free_Content_Plan::apply_locked_copy(
				$page['plan']['blockTree'],
				$content_plans[$slug]
			);
		}
		unset( $page );
		return $pages;
	}

	/**
	 * Retry malformed free trees once with only the affected page in context.
	 * The validation boundary still rejects any invalid replacement.
	 */
	protected static function retry_invalid_free_pages( array $generated_pages, array $sitemap_pages, array $brief, array $options, callable $generate_text, array $site_pages = array(), array $content_plans = array() ): array {
		$by_slug = array();
		foreach( $generated_pages as $index => $page ) {
			if( is_array( $page ) ) {
				$by_slug[self::slug( $page['slug'] ?? '', $page['title'] ?? '', $index )] = $index;
			}
		}

		foreach( $sitemap_pages as $index => $sitemap_page ) {
			$slug = self::slug( $sitemap_page['slug'] ?? '', $sitemap_page['title'] ?? '', $index );
			$page_index = $by_slug[$slug] ?? null;
			$tree = $page_index === null ? null : ( $generated_pages[$page_index]['plan']['blockTree'] ?? null );
			$issues = WPHAVE_AI_Block_Design_Compiler::quality_issues( $tree, $site_pages ?: $sitemap_pages, $brief );
			if( isset( $content_plans[$slug] ) ) {
				$issues = array_values( array_unique( array_merge(
					$issues,
					WPHAVE_Website_Plan_Free_Content_Plan::tree_issues( $tree, $content_plans[$slug] )
				) ) );
			}
			$design_audit = WPHAVE_Website_Plan_Free_Design_Audit::inspect( $tree );
			$single_section_plan = ( $content_plans[$slug]['pageStructure'] ?? '' ) === 'single-section';
			if( $issues === array() && ( $single_section_plan || $design_audit['score'] >= 80 ) ) {
				continue;
			}

			$retry_sitemap = array( 'pages' => array( $sitemap_page ) );
			$messages = self::free_wireframe_messages( $brief, $retry_sitemap, $site_pages ?: $sitemap_pages, $content_plans );
			$copy_only = is_array( $tree ) && $issues !== array()
				&& array_diff( $issues, array( 'placeholder_copy', 'unfinished_copy' ) ) === array();
			$plan_repair_only = is_array( $tree ) && $issues !== array()
				&& array_diff( $issues, array( 'content_plan_open_composition_split', 'content_plan_action_only_has_extra_copy' ) ) === array();
			if( $copy_only ) {
				$retry_instruction = 'Repair only the generic or unfinished visitor copy in the following blockTree. Preserve every section id, node kind, layout, style, node order, action id, target and owning section exactly. Return a complete replacement JSON object with exactly one page and its full plan.blockTree. Do not add factual claims. Technical issues: ' . implode( ', ', $issues ) . '. Original blockTree JSON: ' . wp_json_encode( $tree, JSON_UNESCAPED_UNICODE );
			} elseif( $plan_repair_only ) {
				$retry_instruction = 'Repair only the named content-plan violations in this existing blockTree. The original blockTree is a rejected structure draft, never a source of verified facts; only the brief offer and confirmed facts verify business claims. Return a complete replacement JSON object with exactly one page and its full plan.blockTree. Preserve the order and IDs of all root sections and all planned action IDs, labels, destinations, types and owning sections. Preserve unaffected sections. For content_plan_open_composition_split, replace the unplanned asymmetric or gridareas split with one focused stack; retain any independently verified fact once, but do not keep a second text surface that repeats the heading. For content_plan_action_only_has_extra_copy, retain exactly one heading and the planned actions in that section; omit explanatory paragraphs and empty wrappers. Do not invent facts or links. Technical issues: ' . implode( ', ', $issues ) . '. Original blockTree JSON: ' . wp_json_encode( $tree, JSON_UNESCAPED_UNICODE );
			} else {
				$retry_instruction = 'Regenerate this page. Technical issues: ' . implode( ', ', $issues ) . '. Layout feedback: ' . implode( ' ', $design_audit['feedback'] ) . ' Return a complete replacement JSON object with exactly one page and exactly the validated number of kept root sections (one for a single-section plan, otherwise 2 to 8). When a contentPlan exists, preserve every kept root section id and every planned action id, target and owning section exactly. A planned editorial-lead, editorial-top or editorial-rail section requires a gridareas node with that exact presetKey and independently meaningful content clusters; a plain stack does not implement the plan. If a planned section has design.composition=open, it must have no asymmetric or gridareas node at any depth; keep its text in one focused stack, without a second repeated-text surface. A section with contentMode=action-only needs exactly one heading, its planned actions and no paragraph anywhere in its nodes. Every section must contain a heading or paragraph; use only the documented node kinds, at most 18 children per node and 120 nodes total. Improve the page rhythm without inventing missing facts or links.';
			}
			$messages[] = array(
				'role' => 'user',
				'content' => $retry_instruction,
			);
			$retry_options = array_replace( $options, array( 'temperature' => 0.35 ) );
			$response = $generate_text( $messages, $retry_options );
			if( is_wp_error( $response ) ) {
				continue;
			}

			$data = json_decode( self::extract_json_object( (string) ( $response['result'] ?? '' ) ), true );
			$retry_pages = self::wireframe_pages_from_response( is_array( $data ) ? $data : array(), array( $sitemap_page ) );
			$retry_page = $retry_pages[0] ?? null;
			if( is_array( $retry_page ) && is_array( $retry_page['plan'] ?? null ) ) {
				$retry_page['plan']['blockTree'] = WPHAVE_Website_Plan_Free_Tree_Normalizer::normalize(
					$retry_page['plan']['blockTree'] ?? null,
					$content_plans[$slug] ?? array()
				);
			}
			if( ! is_array( $retry_page ) || self::slug( $retry_page['slug'] ?? '', $retry_page['title'] ?? '', 0 ) !== $slug || WPHAVE_AI_Block_Design_Compiler::quality_issues( $retry_page['plan']['blockTree'] ?? null, $site_pages ?: $sitemap_pages, $brief ) !== array() ) {
				continue;
			}
			if( isset( $content_plans[$slug] ) && WPHAVE_Website_Plan_Free_Content_Plan::tree_issues( $retry_page['plan']['blockTree'], $content_plans[$slug] ) !== array() ) {
				continue;
			}
			if( $copy_only && self::copy_retry_structure( $retry_page['plan']['blockTree'] ) != self::copy_retry_structure( $tree ) ) {
				continue;
			}
			$retry_audit = WPHAVE_Website_Plan_Free_Design_Audit::inspect( $retry_page['plan']['blockTree'] );
			if( $issues === array() && $retry_audit['score'] <= $design_audit['score'] ) {
				continue;
			}

			if( $page_index === null ) {
				$generated_pages[] = $retry_page;
			} else {
				$generated_pages[$page_index] = $retry_page;
			}
		}

		return $generated_pages;
	}

	private static function normalize_generated_free_pages( array $pages, array $content_plans ): array {
		foreach( $pages as &$page ) {
			if( ! is_array( $page ) || ! is_array( $page['plan'] ?? null ) ) {
				continue;
			}
			$slug = (string) ( $page['slug'] ?? '' );
			$page['plan']['blockTree'] = WPHAVE_Website_Plan_Free_Tree_Normalizer::normalize(
				$page['plan']['blockTree'] ?? null,
				$content_plans[$slug] ?? array()
			);
		}
		unset( $page );

		return $pages;
	}

	private static function copy_retry_structure( array $node ): array {
		$actions = array_map( static function( $action ) {
			return is_array( $action ) ? array(
				'url' => $action['url'] ?? '',
				'variant' => $action['variant'] ?? '',
				'planActionId' => $action['planActionId'] ?? '',
				'planActionKind' => $action['planActionKind'] ?? '',
				'planGoalRef' => $action['planGoalRef'] ?? '',
			) : array();
		}, (array) ( $node['actions'] ?? array() ) );
		return array(
			'kind' => $node['kind'] ?? '',
			'id' => $node['id'] ?? '',
			'style' => $node['style'] ?? array(),
			'layout' => $node['layout'] ?? array(),
			'variant' => $node['variant'] ?? '',
			'url' => $node['url'] ?? '',
			'planActionId' => $node['planActionId'] ?? '',
			'planActionKind' => $node['planActionKind'] ?? '',
			'planGoalRef' => $node['planGoalRef'] ?? '',
			'actions' => $actions,
			'nodes' => array_map( static function( $child ) {
				return is_array( $child ) ? self::copy_retry_structure( $child ) : array();
			}, (array) ( $node['nodes'] ?? array() ) ),
		);
	}

	/**
	 * Render explicit free compositions without changing to pattern or recipe output.
	 */
	protected static function render_free_wireframes( $generated_pages, array $sitemap_pages, array $site_pages = array(), array $brief = array(), array $content_plans = array() ) {
		$generated_pages = is_array( $generated_pages ) ? $generated_pages : array();
		$by_slug = array();
		$wireframes = array();
		foreach( $generated_pages as $page ) {
			if( is_array( $page ) ) {
				$by_slug[self::slug( $page['slug'] ?? '', $page['title'] ?? '', 0 )] = $page;
			}
		}

		foreach( $sitemap_pages as $index => $sitemap_page ) {
			$slug = self::slug( $sitemap_page['slug'] ?? '', $sitemap_page['title'] ?? '', $index );
			$generated = $by_slug[$slug] ?? null;
			$raw_plan = is_array( $generated['plan'] ?? null ) ? $generated['plan'] : array();
			$tree = $raw_plan['blockTree'] ?? null;
			$page = self::compile_free_page( $tree, $sitemap_page, $index, $site_pages ?: $sitemap_pages, $brief, $content_plans[$slug] ?? array() );
			if( is_wp_error( $page ) ) {
				return $page;
			}
			$wireframes[] = $page;
		}

		return $wireframes;
	}

	/**
	 * Compile a complete free page through one validation and rendering boundary.
	 */
	protected static function compile_free_page( $tree, array $sitemap_page, int $index, array $site_pages = array(), array $brief = array(), array $content_plan = array() ) {
		$issues = WPHAVE_AI_Block_Design_Compiler::quality_issues( $tree, $site_pages, $brief );
		if( $issues !== array() ) {
			return new WP_Error( 'ai_website_free_plan_invalid', __( 'The AI response did not contain a valid free composition for this page.', 'wphave' ), array( 'status' => 502, 'issues' => $issues ) );
		}
		$original_tree = $tree;
		$media_composition = WPHAVE_Website_Plan_Media_Composition::derive(
			$tree,
			is_array( $brief['availableMedia'][0] ?? null ) ? $brief['availableMedia'][0] : array(),
			( $content_plan['heroMediaPlacement'] ?? '' ) === 'before-content' ? 'before-content' : 'after-content'
		);
		if( $media_composition !== null ) {
			$media_issues = WPHAVE_AI_Block_Design_Compiler::quality_issues( $media_composition, $site_pages, $brief );
			if( $media_issues !== array() ) {
				return new WP_Error( 'ai_website_media_composition_invalid', __( 'The page image could not be composed safely.', 'wphave' ), array( 'status' => 502, 'issues' => $media_issues ) );
			}
			$tree = $media_composition;
		}


		$plan = WPHAVE_AI_Page_Composition_Plan::sanitize( array( 'blockTree' => $tree ) );
		if( $media_composition !== null ) {
			$plan['originalBlockTree'] = $original_tree;
			$plan['mediaComposition'] = array(
				'variant' => ( $original_tree['nodes'][0]['nodes'][0]['kind'] ?? '' ) === 'gridareas'
					? 'editorial-area'
					: ( ( $content_plan['heroMediaPlacement'] ?? '' ) === 'before-content' ? 'image-led' : 'text-left-image-right' ),
				'attachmentId' => (int) ( $brief['availableMedia'][0]['attachmentId'] ?? 0 ),
			);
		}
		$content = WPHAVE_AI_Block_Design_Compiler::compile( $tree );
		$sections_content = WPHAVE_AI_Block_Design_Compiler::compile_sections( $tree );
		if( is_wp_error( $content ) || trim( (string) $content ) === '' || count( $sections_content ) !== count( $tree['nodes'] ) ) {
			return new WP_Error( 'ai_website_free_render_failed', __( 'The free composition could not be rendered.', 'wphave' ), array( 'status' => 502 ) );
		}

		return array(
			'title' => $sitemap_page['title'] ?? '',
			'slug' => self::slug( $sitemap_page['slug'] ?? '', $sitemap_page['title'] ?? '', $index ),
			'intent' => $sitemap_page['intent'] ?? '',
			'description' => $sitemap_page['description'] ?? '',
			'source' => self::source( 'wireframe' ),
			'plan' => $plan,
			'content' => $content,
			'sectionsContent' => $sections_content,
			'diagnostics' => array( 'block_tree_renderer_used' ),
		);
	}

/**
	 * Create style guide.
	 *
	 * @param array $params Params.
	 * @param callable $generate_text Generate text.
	 */

	public static function create_style_guide( array $params, callable $generate_text ) {
		$brief = self::sanitize_brief( $params['brief'] ?? array() );
		unset( $brief['pageFactsBySlug'] );
		$sitemap = self::normalize_sitemap( $params['sitemap'] ?? array(), $brief );
		$wireframes = self::sanitize_wireframe_context( $params['wireframes'] ?? array(), $sitemap['pages'] ?? array() );

		if( empty( $sitemap['pages'] ) || empty( $wireframes ) ) {
			return new WP_Error( 'ai_website_style_context_missing', __( 'Generated sitemap and wireframes are required before the Style Guide can be created.', 'wphave' ), array( 'status' => 400 ) );
		}

		$options = WPHAVE_AI_Schema::sanitize_options( $params['options'] ?? array() );
		$options['responseFormat'] = 'json_object';
		$options['maxTokens'] = max( 3500, (int) ( $options['maxTokens'] ?? 0 ) );
		$regenerate = ! empty( $params['regenerate'] );
		$variant_seed = absint( $params['variantSeed'] ?? 0 );
		$current_style = is_array( $params['style'] ?? null ) ? $params['style'] : array();
		$prompt = self::style_guide_prompt( $brief, $sitemap, $wireframes, $current_style, $regenerate, $variant_seed );
		$messages = WPHAVE_AI_Global_Styles::build_messages( $prompt, $options );
		$response = $generate_text( $messages, $options );

		if( is_wp_error( $response ) ) {
			return $response;
		}

		$proposal = WPHAVE_AI_Global_Styles::validate_response( $response['result'] ?? '', $prompt );

		if( is_wp_error( $proposal ) ) {
			return $proposal;
		}

		if( $regenerate && self::style_guides_match( $proposal['globals'] ?? array(), $current_style ) ) {
			$messages[] = array(
				'role' => 'assistant',
				'content' => $response['result'] ?? '',
			);
			$messages[] = array(
				'role' => 'user',
				'content' => implode( ' ', array(
					'The generated Style Guide is effectively identical to the current one.',
					'Generate a visibly different alternative now.',
					'Change at least recipe or palette, and also adjust intensity, density or shape.',
					self::style_variant_instruction( ( $variant_seed + 1 ) % 6 ),
					) ),
			);
			$response = $generate_text( $messages, $options );

			if( is_wp_error( $response ) ) {
				return $response;
			}

			$next_proposal = WPHAVE_AI_Global_Styles::validate_response( $response['result'] ?? '', $prompt );

			if( ! is_wp_error( $next_proposal ) ) {
				$proposal = $next_proposal;
			}
		}

		return array(
			'styleGuide' => $proposal['globals'] ?? array(),
			'proposal' => $proposal,
			'result' => $response['result'] ?? '',
			'provider' => $response['provider'] ?? '',
			'meta' => $response['meta'] ?? null,
		);
	}

/**
	 * Regenerate section.
	 *
	 * @param array $params Params.
	 * @param callable $generate_text Generate text.
	 */

	public static function regenerate_section( array $params, callable $generate_text ) {
		$brief = self::sanitize_brief( $params['brief'] ?? array() );
		$sitemap = self::normalize_sitemap( $params['sitemap'] ?? array(), $brief );
		$page = is_array( $params['page'] ?? null ) ? $params['page'] : array();
		$page_index = absint( $params['pageIndex'] ?? 0 );
		$section_index = absint( $params['sectionIndex'] ?? 0 );
		$instruction = trim( mb_substr( sanitize_textarea_field( (string) ( $params['instruction'] ?? '' ) ), 0, 500 ) );
		$raw_plan = is_array( $page['plan'] ?? null ) ? $page['plan'] : array();
		if( isset( $raw_plan['blockTree'] ) || isset( $raw_plan['patternComposition'] ) ) {
			return new WP_Error( 'ai_website_section_regeneration_unavailable', __( 'Regenerate the complete page with approved patterns.', 'wphave' ), array( 'status' => 400 ) );
		}

		unset( $brief['pageFactsBySlug'] );

		if( class_exists( 'WPHAVE_Website_Planner_Section_Library' ) && is_array( $raw_plan['patternSections'] ?? null ) ) {
			return self::regenerate_pattern_section( $params, $generate_text, $brief, $sitemap, $page, $page_index, $section_index, $instruction, $raw_plan );
		}

		$current_plan = WPHAVE_AI_Page_Composition_Plan::sanitize( $raw_plan );
		$sections = is_array( $current_plan['sections'] ?? null ) ? $current_plan['sections'] : array();

		if( empty( $sections ) || empty( $sections[$section_index] ) ) {
			return new WP_Error( 'ai_website_section_missing', __( 'The selected section could not be found.', 'wphave' ), array( 'status' => 400 ) );
		}

		$options = WPHAVE_AI_Schema::sanitize_options( $params['options'] ?? array() );
		$options['responseFormat'] = 'json_object';
		$options['maxTokens'] = max( 5500, (int) ( $options['maxTokens'] ?? 0 ) );
		$messages = self::section_messages( $brief, $sitemap, $page, $current_plan, $section_index, $instruction, $params['style'] ?? array() );
		$response = $generate_text( $messages, $options );

		if( is_wp_error( $response ) ) {
			return $response;
		}

		$data = json_decode( self::extract_json_object( (string) ( $response['result'] ?? '' ) ), true );
		$data = is_array( $data ) ? $data : array();
		$section = self::section_from_response( $data );

		if( empty( $section ) ) {
			return new WP_Error( 'ai_website_section_invalid', __( 'The AI response did not contain a valid section.', 'wphave' ), array( 'status' => 502 ) );
		}

		$section['id'] = $sections[$section_index]['id'] ?? ( 'section-' . ( $section_index + 1 ) );
		$test_plan = $current_plan;
		$test_plan['sections'] = array( $section );
		$sanitized_section_plan = WPHAVE_AI_Page_Composition_Plan::sanitize( $test_plan );
		$next_section = $sanitized_section_plan['sections'][0] ?? array();

		if( empty( $next_section ) ) {
			return new WP_Error( 'ai_website_section_invalid', __( 'The generated section could not be rendered.', 'wphave' ), array( 'status' => 502 ) );
		}

		$sitemap_page = is_array( $sitemap['pages'][$page_index] ?? null ) ? $sitemap['pages'][$page_index] : array();
		$current_plan['sections'][$section_index] = $next_section;
		$current_plan['ast'] = self::sections_to_ast( $current_plan['sections'], $sitemap_page, $current_plan, $page_index );
		$content = WPHAVE_AI_Page_Composition_Plan::render( $current_plan );

		if( is_wp_error( $content ) || trim( (string) $content ) === '' ) {
			return new WP_Error( 'ai_website_section_render_failed', __( 'The updated page could not be rendered.', 'wphave' ), array( 'status' => 502 ) );
		}

		$sections_content = WPHAVE_AI_Page_Composition_Plan::render_sections( $current_plan );
		$sections_content = is_wp_error( $sections_content ) ? array() : $sections_content;
		$diagnostics = WPHAVE_AI_Page_Composition_Plan::diagnostics( $current_plan );
		$diagnostics[] = ! empty( $current_plan['ast']['nodes'] ) ? 'ast_renderer_used' : 'legacy_renderer_used';
		$diagnostics[] = 'ast_migrated_from_sections';
		$updated_page = array(
			'title' => sanitize_text_field( (string) ( $page['title'] ?? $sitemap_page['title'] ?? 'Page' ) ),
			'slug' => self::slug( $page['slug'] ?? $sitemap_page['slug'] ?? '', $page['title'] ?? $sitemap_page['title'] ?? '', $page_index ),
			'intent' => sanitize_textarea_field( (string) ( $page['intent'] ?? $sitemap_page['intent'] ?? '' ) ),
			'description' => sanitize_textarea_field( (string) ( $page['description'] ?? $sitemap_page['description'] ?? '' ) ),
			'plan' => $current_plan,
			'content' => $content,
			'sectionsContent' => $sections_content,
			'diagnostics' => array_values( array_unique( array_filter( $diagnostics ) ) ),
		);

		return array(
			'page' => $updated_page,
			'section' => $next_section,
			'sectionIndex' => $section_index,
			'provider' => $response['provider'] ?? '',
			'meta' => $response['meta'] ?? null,
		);
	}

/**
	 * Regenerate pattern section.
	 *
	 * @param array $params Params.
	 * @param callable $generate_text Generate text.
	 * @param array $brief Brief.
	 * @param array $sitemap Sitemap.
	 * @param array $page Page.
	 * @param int $page_index Page index.
	 * @param int $section_index Section index.
	 * @param string $instruction Instruction.
	 * @param array $current_plan Current plan.
	 */

	protected static function regenerate_free_section( array $params, callable $generate_text, array $brief, array $sitemap, array $page, int $page_index, int $section_index, string $instruction, $tree ) {
		if( ! WPHAVE_AI_Block_Design_Compiler::validate_tree( $tree ) || ! isset( $tree['nodes'][$section_index] ) ) {
			return new WP_Error( 'ai_website_section_missing', __( 'The selected section could not be found.', 'wphave' ), array( 'status' => 400 ) );
		}

		$options = WPHAVE_AI_Schema::sanitize_options( $params['options'] ?? array() );
		$options['responseFormat'] = 'json_object';
		$options['maxTokens'] = max( 5500, (int) ( $options['maxTokens'] ?? 0 ) );
		$response = $generate_text( self::free_section_messages( $brief, $page, $tree, $section_index, $instruction ), $options );
		if( is_wp_error( $response ) ) {
			return $response;
		}

		$data = json_decode( self::extract_json_object( (string) ( $response['result'] ?? '' ) ), true );
		$section = is_array( $data['section'] ?? null ) ? $data['section'] : null;
		if( ! $section || ( $section['kind'] ?? null ) !== 'section' ) {
			return new WP_Error( 'ai_website_section_invalid', __( 'The AI response did not contain a valid section.', 'wphave' ), array( 'status' => 502 ) );
		}

		$section['id'] = $tree['nodes'][$section_index]['id'] ?? ( 'block-tree-section-' . ( $section_index + 1 ) );
		$next_tree = $tree;
		$next_tree['nodes'][$section_index] = $section;
		$sitemap_page = is_array( $sitemap['pages'][$page_index] ?? null ) ? $sitemap['pages'][$page_index] : $page;
		$updated_page = self::compile_free_page( $next_tree, $sitemap_page, $page_index, $sitemap['pages'] ?? array(), $brief, is_array( $page['plan']['contentPlan'] ?? null ) ? $page['plan']['contentPlan'] : array() );
		if( is_wp_error( $updated_page ) ) {
			return $updated_page;
		}

		return array(
			'page' => $updated_page,
			'section' => $updated_page['plan']['blockTree']['nodes'][$section_index],
			'sectionContent' => $updated_page['sectionsContent'][$section_index],
			'sectionIndex' => $section_index,
			'provider' => $response['provider'] ?? '',
			'meta' => $response['meta'] ?? null,
		);
	}

	protected static function regenerate_pattern_section( array $params, callable $generate_text, array $brief, array $sitemap, array $page, int $page_index, int $section_index, string $instruction, array $current_plan ) {
		$sections = is_array( $current_plan['patternSections'] ?? null ) ? array_values( $current_plan['patternSections'] ) : array();

		if( empty( $sections ) || empty( $sections[$section_index] ) ) {
			return new WP_Error( 'ai_website_section_missing', __( 'The selected section could not be found.', 'wphave' ), array( 'status' => 400 ) );
		}

		$options = WPHAVE_AI_Schema::sanitize_options( $params['options'] ?? array() );
		$options['responseFormat'] = 'json_object';
		$options['maxTokens'] = max( 4500, (int) ( $options['maxTokens'] ?? 0 ) );
		$messages = self::pattern_section_messages( $brief, $sitemap, $page, $current_plan, $section_index, $instruction, $params['style'] ?? array() );
		$response = $generate_text( $messages, $options );

		if( is_wp_error( $response ) ) {
			return $response;
		}

		$data = json_decode( self::extract_json_object( (string) ( $response['result'] ?? '' ) ), true );
		$data = is_array( $data ) ? $data : array();
		$section = self::pattern_section_from_response( $data, $sections[$section_index] );

		if( empty( $section ) ) {
			return new WP_Error( 'ai_website_section_invalid', __( 'The AI response did not contain a valid section.', 'wphave' ), array( 'status' => 502 ) );
		}

		$sections[$section_index] = $section;
		$current_plan['patternSections'] = $sections;
		$sitemap_page = is_array( $sitemap['pages'][$page_index] ?? null ) ? $sitemap['pages'][$page_index] : array();
		$generated = array(
			'title' => sanitize_text_field( (string) ( $page['title'] ?? $sitemap_page['title'] ?? 'Page' ) ),
			'slug' => self::slug( $page['slug'] ?? $sitemap_page['slug'] ?? '', $page['title'] ?? $sitemap_page['title'] ?? '', $page_index ),
			'plan' => $current_plan,
		);
		$pattern_page = WPHAVE_Website_Planner_Section_Library::render_page( $generated, $sitemap_page, $page_index );

		if( trim( (string) ( $pattern_page['content'] ?? '' ) ) === '' ) {
			return new WP_Error( 'ai_website_section_render_failed', __( 'The updated page could not be rendered.', 'wphave' ), array( 'status' => 502 ) );
		}

		$updated_page = array(
			'title' => $generated['title'],
			'slug' => $generated['slug'],
			'intent' => sanitize_textarea_field( (string) ( $page['intent'] ?? $sitemap_page['intent'] ?? '' ) ),
			'description' => sanitize_textarea_field( (string) ( $page['description'] ?? $sitemap_page['description'] ?? '' ) ),
			'plan' => $pattern_page['plan'],
			'content' => $pattern_page['content'],
			'sectionsContent' => $pattern_page['sectionsContent'],
			'diagnostics' => array_values( array_unique( array_filter( $pattern_page['diagnostics'] ) ) ),
		);
		$rendered_sections = is_array( $pattern_page['sectionsContent'] ?? null ) ? $pattern_page['sectionsContent'] : array();

		return array(
			'page' => $updated_page,
			'section' => $pattern_page['plan']['patternSections'][$section_index] ?? $section,
			'sectionContent' => $rendered_sections[$section_index] ?? array(),
			'sectionIndex' => $section_index,
			'provider' => $response['provider'] ?? '',
			'meta' => $response['meta'] ?? null,
		);
	}

/**
	 * Extract block tree from plan.
	 *
	 * @param array $plan Plan.
	 * @return array Extract block tree from plan.
	 */

	protected static function extract_block_tree_from_plan( array $plan ): array {
		foreach( array( 'blockTree', 'block_tree', 'blockDesignTree', 'block_design_tree', 'designTree', 'design_tree', 'tree' ) as $key ) {
			if( is_array( $plan[$key] ?? null ) && ! empty( $plan[$key]['nodes'] ) ) {
				$tree = $plan[$key];
				$tree['kind'] = sanitize_key( $tree['kind'] ?? 'page' ) ?: 'page';

				return $tree;
			}
		}

		return array();
	}

/**
	 * Pattern section from response.
	 *
	 * @param array $data Data.
	 * @param array $current_section Current section.
	 * @return array Pattern section from response.
	 */

	protected static function pattern_section_from_response( array $data, array $current_section ): array {
		$section = array();

		foreach( array( 'patternSection', 'section', 'sectionPlan', 'plan' ) as $key ) {
			if( is_array( $data[$key] ?? null ) ) {
				$section = $data[$key];
				break;
			}
		}

		if( empty( $section ) && is_array( $data['patternSections'][0] ?? null ) ) {
			$section = $data['patternSections'][0];
		}

		if( empty( $section ) && is_array( $data['sections'][0] ?? null ) ) {
			$section = $data['sections'][0];
		}

		if( empty( $section ) && ( isset( $data['patternKey'] ) || isset( $data['slots'] ) ) ) {
			$section = $data;
		}

		if( empty( $section ) ) {
			return array();
		}

		$slots = is_array( $section['slots'] ?? null ) ? $section['slots'] : array();
		$current_slots = is_array( $current_section['slots'] ?? null ) ? $current_section['slots'] : array();

		return array(
			'id' => sanitize_key( (string) ( $current_section['id'] ?? $section['id'] ?? 'pattern-section' ) ),
			'patternKey' => sanitize_key( (string) ( $section['patternKey'] ?? $section['pattern'] ?? $current_section['patternKey'] ?? '' ) ),
			'type' => sanitize_key( (string) ( $section['type'] ?? $current_section['type'] ?? 'content' ) ),
			'title' => sanitize_text_field( (string) ( $section['title'] ?? $slots['heading'] ?? $current_section['title'] ?? '' ) ),
			'purpose' => sanitize_textarea_field( (string) ( $section['purpose'] ?? $section['intent'] ?? $current_section['purpose'] ?? '' ) ),
			'source' => self::source( 'regenerate_section' ),
			'slots' => array(
				'eyebrow' => sanitize_text_field( (string) ( $slots['eyebrow'] ?? $section['eyebrow'] ?? $current_slots['eyebrow'] ?? '' ) ),
				'heading' => sanitize_text_field( (string) ( $slots['heading'] ?? $section['heading'] ?? $section['title'] ?? $current_slots['heading'] ?? '' ) ),
				'body' => sanitize_textarea_field( (string) ( $slots['body'] ?? $section['body'] ?? $current_slots['body'] ?? '' ) ),
				'items' => self::sanitize_pattern_items( $slots['items'] ?? $section['items'] ?? $current_slots['items'] ?? array() ),
				'actions' => self::sanitize_pattern_actions( $slots['actions'] ?? $section['actions'] ?? $current_slots['actions'] ?? array() ),
			),
		);
	}

/**
	 * Section from response.
	 *
	 * @param array $data Data.
	 * @return array Section from response.
	 */

	protected static function section_from_response( array $data ): array {
		foreach( array( 'section', 'sectionPlan', 'plan' ) as $key ) {
			if( is_array( $data[$key] ?? null ) ) {
				return $data[$key];
			}
		}

		if( is_array( $data['sections'][0] ?? null ) ) {
			return $data['sections'][0];
		}

		return is_array( $data['type'] ?? null ) ? $data : ( isset( $data['type'] ) ? $data : array() );
	}

/**
	 * Style variant instruction.
	 *
	 * @param int $variant Variant.
	 * @return string Style variant instruction.
	 */

	protected static function style_variant_instruction( int $variant ): string {
		$instructions = array(
			'Explore a crisp product-led direction with clear CTAs and confident contrast if it fits.',
			'Explore a warmer, softer and more approachable direction if it fits.',
			'Explore a more editorial, typography-led direction if it fits.',
			'Explore a darker premium direction only if the content can support it.',
			'Explore a more playful and bolder direction if it fits the audience.',
			'Explore a restrained corporate direction with structured spacing if it fits.',
		);

		return $instructions[$variant] ?? $instructions[0];
	}

/**
	 * Wireframe pages from response.
	 *
	 * @param array $data Data.
	 * @param array $sitemap_pages Sitemap pages.
	 * @return array Wireframe pages from response.
	 */

	protected static function wireframe_pages_from_response( array $data, array $sitemap_pages ): array {
		$pages = null;
		foreach( array( 'pages', 'pageCompositionPlans', 'plans' ) as $key ) {
			if( is_array( $data[$key] ?? null ) ) {
				$pages = $data[$key];
				break;
			}
		}

		if( $pages === null && is_array( $data['wireframes']['pages'] ?? null ) ) {
			$pages = $data['wireframes']['pages'];
		}
		if( $pages === null && is_array( $data['page'] ?? null ) ) {
			$pages = array( $data['page'] );
		}
		if( $pages === null && is_array( $data['plan'] ?? null ) ) {
			$pages = array( $data );
		}
		if( $pages === null && is_array( $data['blockTree'] ?? null ) ) {
			$pages = array( array( 'blockTree' => $data['blockTree'] ) );
		}
		if( is_array( $pages ) ) {
			if( ! array_is_list( $pages ) && ( isset( $pages['plan'] ) || isset( $pages['blockTree'] ) ) ) {
				$pages = array( $pages );
			}
			foreach( $pages as $index => &$page ) {
				if( ! is_array( $page ) ) {
					continue;
				}
				$source_page = $sitemap_pages[$index] ?? array();
				$page['title'] = $page['title'] ?? $source_page['title'] ?? '';
				$page['slug'] = $page['slug'] ?? $source_page['slug'] ?? '';
				if( ! isset( $page['plan'] ) && is_array( $page['blockTree'] ?? null ) ) {
					$page['plan'] = array( 'blockTree' => $page['blockTree'] );
				}
			}
			unset( $page );
			return $pages;
		}

		if( is_array( $data['pageCompositionPlan'] ?? null ) || is_array( $data['sections'] ?? null ) ) {
			$first = $sitemap_pages[0] ?? array();

			return array(
				array(
					'title' => $first['title'] ?? 'Home',
					'slug' => $first['slug'] ?? 'home',
					'plan' => is_array( $data['pageCompositionPlan'] ?? null ) ? $data['pageCompositionPlan'] : $data,
				),
			);
		}

		return array();
	}

/**
	 * Planner block.
	 *
	 * @param string $name Name.
	 * @param array $attributes Attributes.
	 * @param string $content Content to process.
	 * @return string Planner block.
	 */

	protected static function planner_block( string $name, array $attributes = array(), string $content = '' ): string {
		$serialized_attributes = ! empty( $attributes ) ? ' ' . wphave_encode_block_attributes_canonical( $attributes, JSON_UNESCAPED_UNICODE ) : '';

		if( $content === '' ) {
			return '<!-- wp:wphave/' . $name . $serialized_attributes . ' /-->';
		}

		return '<!-- wp:wphave/' . $name . $serialized_attributes . ' -->' . "\n" . $content . "\n" . '<!-- /wp:wphave/' . $name . ' -->';
	}

/**
	 * Planner group.
	 *
	 * @param string $content Content to process.
	 * @param array $wphave WPHAVE.
	 * @return string Planner group.
	 */

	protected static function planner_group( string $content, array $wphave = array() ): string {
		return self::planner_block( 'group', array( 'wphave' => $wphave ), $content );
	}

/**
	 * Render wireframes.
	 *
	 * @param array $generated_pages Generated pages.
	 * @param array $sitemap_pages Sitemap pages.
	 * @return array Render wireframes.
	 */

	protected static function render_wireframes( $generated_pages, array $sitemap_pages ): array {
		$generated_pages = is_array( $generated_pages ) ? $generated_pages : array();
		$by_slug = array();
		$result = array();

		foreach( $generated_pages as $page ) {
			if( ! is_array( $page ) ) {
				continue;
			}

			$slug = self::slug( $page['slug'] ?? '', $page['title'] ?? '', 0 );
			$by_slug[$slug] = $page;
		}

		foreach( $sitemap_pages as $index => $sitemap_page ) {
			$slug = self::slug( $sitemap_page['slug'] ?? '', $sitemap_page['title'] ?? '', $index );
			$generated = $by_slug[$slug] ?? ( is_array( $generated_pages[$index] ?? null ) ? $generated_pages[$index] : array() );

			if( class_exists( 'WPHAVE_Website_Planner_Section_Library' ) ) {
				$pattern_page = WPHAVE_Website_Planner_Section_Library::render_page( $generated, $sitemap_page, $index );
				if( trim( (string) ( $pattern_page['content'] ?? '' ) ) !== '' ) {
					$result[] = array(
						'title' => $sitemap_page['title'] ?? sanitize_text_field( (string) ( $generated['title'] ?? '' ) ),
						'slug' => $slug,
						'intent' => $sitemap_page['intent'] ?? '',
						'description' => $sitemap_page['description'] ?? '',
						'source' => self::source( 'wireframe' ),
						'plan' => $pattern_page['plan'],
						'content' => $pattern_page['content'],
						'sectionsContent' => $pattern_page['sectionsContent'],
						'diagnostics' => array_values( array_unique( array_filter( $pattern_page['diagnostics'] ) ) ),
					);
					continue;
				}
			}

			$plan = self::page_plan_from_response( $generated, $sitemap_page, $index );
			$plan_had_ast = ! empty( $plan['ast']['nodes'] ) && is_array( $plan['ast']['nodes'] );
			$content = WPHAVE_AI_Page_Composition_Plan::render( $plan );
			$used_fallback = false;

			if( is_wp_error( $content ) || trim( (string) $content ) === '' ) {
				$plan = self::fallback_page_plan( $sitemap_page, $index );
				$content = WPHAVE_AI_Page_Composition_Plan::render( $plan );
				$used_fallback = true;
			}

			if( is_wp_error( $content ) || trim( (string) $content ) === '' ) {
				continue;
			}

			$sanitized_plan = WPHAVE_AI_Page_Composition_Plan::sanitize( $plan );
			$diagnostics = array_merge(
				WPHAVE_AI_Page_Composition_Plan::diagnostics( $sanitized_plan ),
				is_array( $plan['plannerDiagnostics'] ?? null ) ? $plan['plannerDiagnostics'] : array()
			);
			$sections_content = WPHAVE_AI_Page_Composition_Plan::render_sections( $sanitized_plan );
			$sections_content = is_wp_error( $sections_content ) ? array() : $sections_content;

			if( ! empty( $sanitized_plan['blockTree']['nodes'] ) ) {
				$diagnostics[] = 'block_tree_renderer_used';
			} elseif( ! empty( $sanitized_plan['ast']['nodes'] ) ) {
				$diagnostics[] = 'ast_renderer_used';
			} else {
				$diagnostics[] = 'legacy_renderer_used';
			}

			if( ! $plan_had_ast && ! empty( $sanitized_plan['ast']['nodes'] ) ) {
				$diagnostics[] = 'ast_migrated_from_sections';
			}

			if( $used_fallback ) {
				$diagnostics[] = 'fallback_from_sitemap';
			}

			$result[] = array(
				'title' => $sitemap_page['title'] ?? sanitize_text_field( (string) ( $generated['title'] ?? '' ) ),
				'slug' => $slug,
				'intent' => $sitemap_page['intent'] ?? '',
				'description' => $sitemap_page['description'] ?? '',
				'source' => self::source( 'wireframe' ),
				'plan' => $sanitized_plan,
				'content' => $content,
				'sectionsContent' => $sections_content,
				'diagnostics' => array_values( array_unique( array_filter( $diagnostics ) ) ),
			);
		}

		return $result;
	}

/**
	 * Page plan from response.
	 *
	 * @param array $generated Generated.
	 * @param array $sitemap_page Sitemap page.
	 * @param int $index Index.
	 * @return array Page plan from response.
	 */

	protected static function page_plan_from_response( array $generated, array $sitemap_page, int $index ): array {
		foreach( array( 'plan', 'pageCompositionPlan', 'compositionPlan', 'contentPlan' ) as $key ) {
			if( is_array( $generated[$key] ?? null ) ) {
				return self::ensure_page_plan_ast( $generated[$key], $sitemap_page, $index );
			}
		}

		if( ! empty( self::extract_block_tree_from_plan( $generated ) ) ) {
			return self::ensure_page_plan_ast( $generated, $sitemap_page, $index );
		}

		if( is_array( $generated['sections'] ?? null ) ) {
			return self::ensure_page_plan_ast( $generated, $sitemap_page, $index );
		}

		return self::fallback_page_plan( $sitemap_page, $index );
	}

}
