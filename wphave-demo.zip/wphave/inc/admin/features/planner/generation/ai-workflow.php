<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Website_Plan_AI_Workflow {

/**
	 * Create sitemap.
	 *
	 * @param array $params Params.
	 * @param callable $generate_text Generate text.
	 */

	public static function create_sitemap( array $params, callable $generate_text ) {
		$brief = self::sanitize_brief( $params['brief'] ?? array() );

		if( trim( implode( '', array( $brief['projectName'], $brief['industry'], $brief['audience'], $brief['offer'], $brief['goal'], $brief['notes'] ) ) ) === '' ) {
			return new WP_Error( 'ai_website_brief_missing', __( 'A website brief is required.', 'wphave' ), array( 'status' => 400 ) );
		}

		$options = WPHAVE_AI_Schema::sanitize_options( $params['options'] ?? array() );
		$options['responseFormat'] = 'json_object';
		$options['maxTokens'] = max( 6500, (int) ( $options['maxTokens'] ?? 0 ) );

		$response = $generate_text( self::sitemap_messages( $brief ), $options );

		if( is_wp_error( $response ) ) {
			return $response;
		}

		$data = json_decode( self::extract_json_object( (string) ( $response['result'] ?? '' ) ), true );

		if( ! is_array( $data ) ) {
			return new WP_Error( 'ai_website_sitemap_invalid_json', __( 'The AI response could not be converted into a sitemap.', 'wphave' ), array( 'status' => 502 ) );
		}

		$sitemap = self::normalize_sitemap( $data['sitemap'] ?? $data, $brief );

		if( empty( $sitemap['pages'] ) ) {
			return new WP_Error( 'ai_website_sitemap_empty', __( 'The AI response did not contain valid website pages.', 'wphave' ), array( 'status' => 502 ) );
		}

		return array(
			'sitemap' => $sitemap,
			'provider' => $response['provider'] ?? '',
			'meta' => $response['meta'] ?? null,
		);
	}

/**
	 * Create wireframes.
	 *
	 * @param array $params Params.
	 * @param callable $generate_text Generate text.
	 */

	public static function create_wireframes( array $params, callable $generate_text ) {
		$brief = self::sanitize_brief( $params['brief'] ?? array() );
		$sitemap = self::normalize_sitemap( $params['sitemap'] ?? array(), $brief );

		if( empty( $sitemap['pages'] ) ) {
			return new WP_Error( 'ai_website_sitemap_empty', __( 'A generated sitemap is required before wireframes can be created.', 'wphave' ), array( 'status' => 400 ) );
		}

		$options = WPHAVE_AI_Schema::sanitize_options( $params['options'] ?? array() );
		$options['responseFormat'] = 'json_object';
		$options['maxTokens'] = max( 16000, (int) ( $options['maxTokens'] ?? 0 ) );

		$response = $generate_text( self::wireframe_messages( $brief, $sitemap ), $options );

		if( is_wp_error( $response ) ) {
			return $response;
		}

		$data = json_decode( self::extract_json_object( (string) ( $response['result'] ?? '' ) ), true );
		$data = is_array( $data ) ? $data : array();
		$template_parts = self::render_template_parts( self::template_parts_from_response( $data ), $sitemap, $brief );
		$generated_pages = self::wireframe_pages_from_response( $data, $sitemap['pages'] );
		$wireframes = self::render_wireframes( $generated_pages, $sitemap['pages'] );

		if( empty( $wireframes ) ) {
			return new WP_Error( 'ai_website_wireframes_empty', __( 'The AI response did not contain valid page content.', 'wphave' ), array( 'status' => 502 ) );
		}

		return array(
			'pages' => $wireframes,
			'templateParts' => $template_parts,
			'provider' => $response['provider'] ?? '',
			'meta' => $response['meta'] ?? null,
		);
	}

/**
	 * Create style guide.
	 *
	 * @param array $params Params.
	 * @param callable $generate_text Generate text.
	 */

	public static function create_style_guide( array $params, callable $generate_text ) {
		$brief = self::sanitize_brief( $params['brief'] ?? array() );
		$sitemap = self::normalize_sitemap( $params['sitemap'] ?? array(), $brief );
		$wireframes = self::sanitize_wireframe_context( $params['wireframes'] ?? array(), $sitemap['pages'] ?? array() );

		if( empty( $sitemap['pages'] ) || empty( $wireframes ) ) {
			return new WP_Error( 'ai_website_style_context_missing', __( 'Generated sitemap and wireframes are required before the Style Guide can be created.', 'wphave' ), array( 'status' => 400 ) );
		}

		$options = WPHAVE_AI_Schema::sanitize_options( $params['options'] ?? array() );
		$options['responseFormat'] = 'json_object';
		$options['maxTokens'] = max( 3500, (int) ( $options['maxTokens'] ?? 0 ) );
		$regenerate = ! empty( $params['regenerate'] );
		$variant_seed = absint( $params['variantSeed'] ?? 0 );
		$current_style = is_array( $params['style'] ?? null ) ? $params['style'] : array();
		$prompt = self::style_guide_prompt( $brief, $sitemap, $wireframes, $current_style, $regenerate, $variant_seed );
		$messages = WPHAVE_AI_Global_Styles::build_messages( $prompt, $options );
		$response = $generate_text( $messages, $options );

		if( is_wp_error( $response ) ) {
			return $response;
		}

		$proposal = WPHAVE_AI_Global_Styles::validate_response( $response['result'] ?? '', $prompt );

		if( is_wp_error( $proposal ) ) {
			return $proposal;
		}

		if( $regenerate && self::style_guides_match( $proposal['globals'] ?? array(), $current_style ) ) {
			$messages[] = array(
				'role' => 'assistant',
				'content' => $response['result'] ?? '',
			);
			$messages[] = array(
				'role' => 'user',
				'content' => implode( ' ', array(
					'The generated Style Guide is effectively identical to the current one.',
					'Generate a visibly different alternative now.',
					'Change at least recipe or palette, and also adjust intensity, density or shape.',
					self::style_variant_instruction( ( $variant_seed + 1 ) % 6 ),
					) ),
			);
			$response = $generate_text( $messages, $options );

			if( is_wp_error( $response ) ) {
				return $response;
			}

			$next_proposal = WPHAVE_AI_Global_Styles::validate_response( $response['result'] ?? '', $prompt );

			if( ! is_wp_error( $next_proposal ) ) {
				$proposal = $next_proposal;
			}
		}

		return array(
			'styleGuide' => $proposal['globals'] ?? array(),
			'proposal' => $proposal,
			'result' => $response['result'] ?? '',
			'provider' => $response['provider'] ?? '',
			'meta' => $response['meta'] ?? null,
		);
	}

/**
	 * Regenerate section.
	 *
	 * @param array $params Params.
	 * @param callable $generate_text Generate text.
	 */

	public static function regenerate_section( array $params, callable $generate_text ) {
		$brief = self::sanitize_brief( $params['brief'] ?? array() );
		$sitemap = self::normalize_sitemap( $params['sitemap'] ?? array(), $brief );
		$page = is_array( $params['page'] ?? null ) ? $params['page'] : array();
		$page_index = absint( $params['pageIndex'] ?? 0 );
		$section_index = absint( $params['sectionIndex'] ?? 0 );
		$instruction = trim( mb_substr( sanitize_textarea_field( (string) ( $params['instruction'] ?? '' ) ), 0, 500 ) );
		$raw_plan = is_array( $page['plan'] ?? null ) ? $page['plan'] : array();

		if( class_exists( 'WPHAVE_Website_Planner_Section_Library' ) && is_array( $raw_plan['patternSections'] ?? null ) ) {
			return self::regenerate_pattern_section( $params, $generate_text, $brief, $sitemap, $page, $page_index, $section_index, $instruction, $raw_plan );
		}

		$current_plan = WPHAVE_AI_Page_Composition_Plan::sanitize( $raw_plan );
		$sections = is_array( $current_plan['sections'] ?? null ) ? $current_plan['sections'] : array();

		if( empty( $sections ) || empty( $sections[$section_index] ) ) {
			return new WP_Error( 'ai_website_section_missing', __( 'The selected section could not be found.', 'wphave' ), array( 'status' => 400 ) );
		}

		$options = WPHAVE_AI_Schema::sanitize_options( $params['options'] ?? array() );
		$options['responseFormat'] = 'json_object';
		$options['maxTokens'] = max( 5500, (int) ( $options['maxTokens'] ?? 0 ) );
		$messages = self::section_messages( $brief, $sitemap, $page, $current_plan, $section_index, $instruction, $params['style'] ?? array() );
		$response = $generate_text( $messages, $options );

		if( is_wp_error( $response ) ) {
			return $response;
		}

		$data = json_decode( self::extract_json_object( (string) ( $response['result'] ?? '' ) ), true );
		$data = is_array( $data ) ? $data : array();
		$section = self::section_from_response( $data );

		if( empty( $section ) ) {
			return new WP_Error( 'ai_website_section_invalid', __( 'The AI response did not contain a valid section.', 'wphave' ), array( 'status' => 502 ) );
		}

		$section['id'] = $sections[$section_index]['id'] ?? ( 'section-' . ( $section_index + 1 ) );
		$test_plan = $current_plan;
		$test_plan['sections'] = array( $section );
		$sanitized_section_plan = WPHAVE_AI_Page_Composition_Plan::sanitize( $test_plan );
		$next_section = $sanitized_section_plan['sections'][0] ?? array();

		if( empty( $next_section ) ) {
			return new WP_Error( 'ai_website_section_invalid', __( 'The generated section could not be rendered.', 'wphave' ), array( 'status' => 502 ) );
		}

		$sitemap_page = is_array( $sitemap['pages'][$page_index] ?? null ) ? $sitemap['pages'][$page_index] : array();
		$current_plan['sections'][$section_index] = $next_section;
		$current_plan['ast'] = self::sections_to_ast( $current_plan['sections'], $sitemap_page, $current_plan, $page_index );
		$content = WPHAVE_AI_Page_Composition_Plan::render( $current_plan );

		if( is_wp_error( $content ) || trim( (string) $content ) === '' ) {
			return new WP_Error( 'ai_website_section_render_failed', __( 'The updated page could not be rendered.', 'wphave' ), array( 'status' => 502 ) );
		}

		$sections_content = WPHAVE_AI_Page_Composition_Plan::render_sections( $current_plan );
		$sections_content = is_wp_error( $sections_content ) ? array() : $sections_content;
		$diagnostics = WPHAVE_AI_Page_Composition_Plan::diagnostics( $current_plan );
		$diagnostics[] = ! empty( $current_plan['ast']['nodes'] ) ? 'ast_renderer_used' : 'legacy_renderer_used';
		$diagnostics[] = 'ast_migrated_from_sections';
		$updated_page = array(
			'title' => sanitize_text_field( (string) ( $page['title'] ?? $sitemap_page['title'] ?? 'Page' ) ),
			'slug' => self::slug( $page['slug'] ?? $sitemap_page['slug'] ?? '', $page['title'] ?? $sitemap_page['title'] ?? '', $page_index ),
			'intent' => sanitize_textarea_field( (string) ( $page['intent'] ?? $sitemap_page['intent'] ?? '' ) ),
			'description' => sanitize_textarea_field( (string) ( $page['description'] ?? $sitemap_page['description'] ?? '' ) ),
			'plan' => $current_plan,
			'content' => $content,
			'sectionsContent' => $sections_content,
			'diagnostics' => array_values( array_unique( array_filter( $diagnostics ) ) ),
		);

		return array(
			'page' => $updated_page,
			'section' => $next_section,
			'sectionIndex' => $section_index,
			'provider' => $response['provider'] ?? '',
			'meta' => $response['meta'] ?? null,
		);
	}

/**
	 * Regenerate pattern section.
	 *
	 * @param array $params Params.
	 * @param callable $generate_text Generate text.
	 * @param array $brief Brief.
	 * @param array $sitemap Sitemap.
	 * @param array $page Page.
	 * @param int $page_index Page index.
	 * @param int $section_index Section index.
	 * @param string $instruction Instruction.
	 * @param array $current_plan Current plan.
	 */

	protected static function regenerate_pattern_section( array $params, callable $generate_text, array $brief, array $sitemap, array $page, int $page_index, int $section_index, string $instruction, array $current_plan ) {
		$sections = is_array( $current_plan['patternSections'] ?? null ) ? array_values( $current_plan['patternSections'] ) : array();

		if( empty( $sections ) || empty( $sections[$section_index] ) ) {
			return new WP_Error( 'ai_website_section_missing', __( 'The selected section could not be found.', 'wphave' ), array( 'status' => 400 ) );
		}

		$options = WPHAVE_AI_Schema::sanitize_options( $params['options'] ?? array() );
		$options['responseFormat'] = 'json_object';
		$options['maxTokens'] = max( 4500, (int) ( $options['maxTokens'] ?? 0 ) );
		$messages = self::pattern_section_messages( $brief, $sitemap, $page, $current_plan, $section_index, $instruction, $params['style'] ?? array() );
		$response = $generate_text( $messages, $options );

		if( is_wp_error( $response ) ) {
			return $response;
		}

		$data = json_decode( self::extract_json_object( (string) ( $response['result'] ?? '' ) ), true );
		$data = is_array( $data ) ? $data : array();
		$section = self::pattern_section_from_response( $data, $sections[$section_index] );

		if( empty( $section ) ) {
			return new WP_Error( 'ai_website_section_invalid', __( 'The AI response did not contain a valid section.', 'wphave' ), array( 'status' => 502 ) );
		}

		$sections[$section_index] = $section;
		$current_plan['patternSections'] = $sections;
		$sitemap_page = is_array( $sitemap['pages'][$page_index] ?? null ) ? $sitemap['pages'][$page_index] : array();
		$generated = array(
			'title' => sanitize_text_field( (string) ( $page['title'] ?? $sitemap_page['title'] ?? 'Page' ) ),
			'slug' => self::slug( $page['slug'] ?? $sitemap_page['slug'] ?? '', $page['title'] ?? $sitemap_page['title'] ?? '', $page_index ),
			'plan' => $current_plan,
		);
		$pattern_page = WPHAVE_Website_Planner_Section_Library::render_page( $generated, $sitemap_page, $page_index );

		if( trim( (string) ( $pattern_page['content'] ?? '' ) ) === '' ) {
			return new WP_Error( 'ai_website_section_render_failed', __( 'The updated page could not be rendered.', 'wphave' ), array( 'status' => 502 ) );
		}

		$updated_page = array(
			'title' => $generated['title'],
			'slug' => $generated['slug'],
			'intent' => sanitize_textarea_field( (string) ( $page['intent'] ?? $sitemap_page['intent'] ?? '' ) ),
			'description' => sanitize_textarea_field( (string) ( $page['description'] ?? $sitemap_page['description'] ?? '' ) ),
			'plan' => $pattern_page['plan'],
			'content' => $pattern_page['content'],
			'sectionsContent' => $pattern_page['sectionsContent'],
			'diagnostics' => array_values( array_unique( array_filter( $pattern_page['diagnostics'] ) ) ),
		);
		$rendered_sections = is_array( $pattern_page['sectionsContent'] ?? null ) ? $pattern_page['sectionsContent'] : array();

		return array(
			'page' => $updated_page,
			'section' => $pattern_page['plan']['patternSections'][$section_index] ?? $section,
			'sectionContent' => $rendered_sections[$section_index] ?? array(),
			'sectionIndex' => $section_index,
			'provider' => $response['provider'] ?? '',
			'meta' => $response['meta'] ?? null,
		);
	}

/**
	 * Extract block tree from plan.
	 *
	 * @param array $plan Plan.
	 * @return array Extract block tree from plan.
	 */

	protected static function extract_block_tree_from_plan( array $plan ): array {
		foreach( array( 'blockTree', 'block_tree', 'blockDesignTree', 'block_design_tree', 'designTree', 'design_tree', 'tree' ) as $key ) {
			if( is_array( $plan[$key] ?? null ) && ! empty( $plan[$key]['nodes'] ) ) {
				$tree = $plan[$key];
				$tree['kind'] = sanitize_key( $tree['kind'] ?? 'page' ) ?: 'page';

				return $tree;
			}
		}

		return array();
	}

/**
	 * Pattern section from response.
	 *
	 * @param array $data Data.
	 * @param array $current_section Current section.
	 * @return array Pattern section from response.
	 */

	protected static function pattern_section_from_response( array $data, array $current_section ): array {
		$section = array();

		foreach( array( 'patternSection', 'section', 'sectionPlan', 'plan' ) as $key ) {
			if( is_array( $data[$key] ?? null ) ) {
				$section = $data[$key];
				break;
			}
		}

		if( empty( $section ) && is_array( $data['patternSections'][0] ?? null ) ) {
			$section = $data['patternSections'][0];
		}

		if( empty( $section ) && is_array( $data['sections'][0] ?? null ) ) {
			$section = $data['sections'][0];
		}

		if( empty( $section ) && ( isset( $data['patternKey'] ) || isset( $data['slots'] ) ) ) {
			$section = $data;
		}

		if( empty( $section ) ) {
			return array();
		}

		$slots = is_array( $section['slots'] ?? null ) ? $section['slots'] : array();
		$current_slots = is_array( $current_section['slots'] ?? null ) ? $current_section['slots'] : array();

		return array(
			'id' => sanitize_key( (string) ( $current_section['id'] ?? $section['id'] ?? 'pattern-section' ) ),
			'patternKey' => sanitize_key( (string) ( $section['patternKey'] ?? $section['pattern'] ?? $current_section['patternKey'] ?? '' ) ),
			'type' => sanitize_key( (string) ( $section['type'] ?? $current_section['type'] ?? 'content' ) ),
			'title' => sanitize_text_field( (string) ( $section['title'] ?? $slots['heading'] ?? $current_section['title'] ?? '' ) ),
			'purpose' => sanitize_textarea_field( (string) ( $section['purpose'] ?? $section['intent'] ?? $current_section['purpose'] ?? '' ) ),
			'source' => self::source( 'regenerate_section' ),
			'slots' => array(
				'eyebrow' => sanitize_text_field( (string) ( $slots['eyebrow'] ?? $section['eyebrow'] ?? $current_slots['eyebrow'] ?? '' ) ),
				'heading' => sanitize_text_field( (string) ( $slots['heading'] ?? $section['heading'] ?? $section['title'] ?? $current_slots['heading'] ?? '' ) ),
				'body' => sanitize_textarea_field( (string) ( $slots['body'] ?? $section['body'] ?? $current_slots['body'] ?? '' ) ),
				'items' => self::sanitize_pattern_items( $slots['items'] ?? $section['items'] ?? $current_slots['items'] ?? array() ),
				'actions' => self::sanitize_pattern_actions( $slots['actions'] ?? $section['actions'] ?? $current_slots['actions'] ?? array() ),
			),
		);
	}

/**
	 * Section from response.
	 *
	 * @param array $data Data.
	 * @return array Section from response.
	 */

	protected static function section_from_response( array $data ): array {
		foreach( array( 'section', 'sectionPlan', 'plan' ) as $key ) {
			if( is_array( $data[$key] ?? null ) ) {
				return $data[$key];
			}
		}

		if( is_array( $data['sections'][0] ?? null ) ) {
			return $data['sections'][0];
		}

		return is_array( $data['type'] ?? null ) ? $data : ( isset( $data['type'] ) ? $data : array() );
	}

/**
	 * Style variant instruction.
	 *
	 * @param int $variant Variant.
	 * @return string Style variant instruction.
	 */

	protected static function style_variant_instruction( int $variant ): string {
		$instructions = array(
			'Explore a crisp product-led direction with clear CTAs and confident contrast if it fits.',
			'Explore a warmer, softer and more approachable direction if it fits.',
			'Explore a more editorial, typography-led direction if it fits.',
			'Explore a darker premium direction only if the content can support it.',
			'Explore a more playful and bolder direction if it fits the audience.',
			'Explore a restrained corporate direction with structured spacing if it fits.',
		);

		return $instructions[$variant] ?? $instructions[0];
	}

/**
	 * Wireframe pages from response.
	 *
	 * @param array $data Data.
	 * @param array $sitemap_pages Sitemap pages.
	 * @return array Wireframe pages from response.
	 */

	protected static function wireframe_pages_from_response( array $data, array $sitemap_pages ): array {
		foreach( array( 'pages', 'pageCompositionPlans', 'plans' ) as $key ) {
			if( is_array( $data[$key] ?? null ) ) {
				return $data[$key];
			}
		}

		if( is_array( $data['wireframes']['pages'] ?? null ) ) {
			return $data['wireframes']['pages'];
		}

		if( is_array( $data['pageCompositionPlan'] ?? null ) || is_array( $data['sections'] ?? null ) ) {
			$first = $sitemap_pages[0] ?? array();

			return array(
				array(
					'title' => $first['title'] ?? 'Home',
					'slug' => $first['slug'] ?? 'home',
					'plan' => is_array( $data['pageCompositionPlan'] ?? null ) ? $data['pageCompositionPlan'] : $data,
				),
			);
		}

		return array();
	}

/**
	 * Planner block.
	 *
	 * @param string $name Name.
	 * @param array $attributes Attributes.
	 * @param string $content Content to process.
	 * @return string Planner block.
	 */

	protected static function planner_block( string $name, array $attributes = array(), string $content = '' ): string {
		$serialized_attributes = ! empty( $attributes ) ? ' ' . wp_json_encode( $attributes, JSON_UNESCAPED_UNICODE ) : '';

		if( $content === '' ) {
			return '<!-- wp:wphave/' . $name . $serialized_attributes . ' /-->';
		}

		return '<!-- wp:wphave/' . $name . $serialized_attributes . ' -->' . "\n" . $content . "\n" . '<!-- /wp:wphave/' . $name . ' -->';
	}

/**
	 * Planner group.
	 *
	 * @param string $content Content to process.
	 * @param array $wphave WPHAVE.
	 * @return string Planner group.
	 */

	protected static function planner_group( string $content, array $wphave = array() ): string {
		return self::planner_block( 'group', array( 'wphave' => $wphave ), $content );
	}

/**
	 * Render wireframes.
	 *
	 * @param array $generated_pages Generated pages.
	 * @param array $sitemap_pages Sitemap pages.
	 * @return array Render wireframes.
	 */

	protected static function render_wireframes( $generated_pages, array $sitemap_pages ): array {
		$generated_pages = is_array( $generated_pages ) ? $generated_pages : array();
		$by_slug = array();
		$result = array();

		foreach( $generated_pages as $page ) {
			if( ! is_array( $page ) ) {
				continue;
			}

			$slug = self::slug( $page['slug'] ?? '', $page['title'] ?? '', 0 );
			$by_slug[$slug] = $page;
		}

		foreach( $sitemap_pages as $index => $sitemap_page ) {
			$slug = self::slug( $sitemap_page['slug'] ?? '', $sitemap_page['title'] ?? '', $index );
			$generated = $by_slug[$slug] ?? ( is_array( $generated_pages[$index] ?? null ) ? $generated_pages[$index] : array() );

			if( class_exists( 'WPHAVE_Website_Planner_Section_Library' ) ) {
				$pattern_page = WPHAVE_Website_Planner_Section_Library::render_page( $generated, $sitemap_page, $index );
				if( trim( (string) ( $pattern_page['content'] ?? '' ) ) !== '' ) {
					$result[] = array(
						'title' => $sitemap_page['title'] ?? sanitize_text_field( (string) ( $generated['title'] ?? '' ) ),
						'slug' => $slug,
						'intent' => $sitemap_page['intent'] ?? '',
						'description' => $sitemap_page['description'] ?? '',
						'source' => self::source( 'wireframe' ),
						'plan' => $pattern_page['plan'],
						'content' => $pattern_page['content'],
						'sectionsContent' => $pattern_page['sectionsContent'],
						'diagnostics' => array_values( array_unique( array_filter( $pattern_page['diagnostics'] ) ) ),
					);
					continue;
				}
			}

			$plan = self::page_plan_from_response( $generated, $sitemap_page, $index );
			$plan_had_ast = ! empty( $plan['ast']['nodes'] ) && is_array( $plan['ast']['nodes'] );
			$content = WPHAVE_AI_Page_Composition_Plan::render( $plan );
			$used_fallback = false;

			if( is_wp_error( $content ) || trim( (string) $content ) === '' ) {
				$plan = self::fallback_page_plan( $sitemap_page, $index );
				$content = WPHAVE_AI_Page_Composition_Plan::render( $plan );
				$used_fallback = true;
			}

			if( is_wp_error( $content ) || trim( (string) $content ) === '' ) {
				continue;
			}

			$sanitized_plan = WPHAVE_AI_Page_Composition_Plan::sanitize( $plan );
			$diagnostics = array_merge(
				WPHAVE_AI_Page_Composition_Plan::diagnostics( $sanitized_plan ),
				is_array( $plan['plannerDiagnostics'] ?? null ) ? $plan['plannerDiagnostics'] : array()
			);
			$sections_content = WPHAVE_AI_Page_Composition_Plan::render_sections( $sanitized_plan );
			$sections_content = is_wp_error( $sections_content ) ? array() : $sections_content;

			if( ! empty( $sanitized_plan['blockTree']['nodes'] ) ) {
				$diagnostics[] = 'block_tree_renderer_used';
			} elseif( ! empty( $sanitized_plan['ast']['nodes'] ) ) {
				$diagnostics[] = 'ast_renderer_used';
			} else {
				$diagnostics[] = 'legacy_renderer_used';
			}

			if( ! $plan_had_ast && ! empty( $sanitized_plan['ast']['nodes'] ) ) {
				$diagnostics[] = 'ast_migrated_from_sections';
			}

			if( $used_fallback ) {
				$diagnostics[] = 'fallback_from_sitemap';
			}

			$result[] = array(
				'title' => $sitemap_page['title'] ?? sanitize_text_field( (string) ( $generated['title'] ?? '' ) ),
				'slug' => $slug,
				'intent' => $sitemap_page['intent'] ?? '',
				'description' => $sitemap_page['description'] ?? '',
				'source' => self::source( 'wireframe' ),
				'plan' => $sanitized_plan,
				'content' => $content,
				'sectionsContent' => $sections_content,
				'diagnostics' => array_values( array_unique( array_filter( $diagnostics ) ) ),
			);
		}

		return $result;
	}

/**
	 * Page plan from response.
	 *
	 * @param array $generated Generated.
	 * @param array $sitemap_page Sitemap page.
	 * @param int $index Index.
	 * @return array Page plan from response.
	 */

	protected static function page_plan_from_response( array $generated, array $sitemap_page, int $index ): array {
		foreach( array( 'plan', 'pageCompositionPlan', 'compositionPlan', 'contentPlan' ) as $key ) {
			if( is_array( $generated[$key] ?? null ) ) {
				return self::ensure_page_plan_ast( $generated[$key], $sitemap_page, $index );
			}
		}

		if( ! empty( self::extract_block_tree_from_plan( $generated ) ) ) {
			return self::ensure_page_plan_ast( $generated, $sitemap_page, $index );
		}

		if( is_array( $generated['sections'] ?? null ) ) {
			return self::ensure_page_plan_ast( $generated, $sitemap_page, $index );
		}

		return self::fallback_page_plan( $sitemap_page, $index );
	}

}
