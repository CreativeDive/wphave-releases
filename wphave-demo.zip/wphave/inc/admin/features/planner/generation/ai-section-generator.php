<?php

if( ! defined('ABSPATH') ) {
	exit;
}

/**
 * AI-backed single-section regeneration for Website Plans.
 */

class WPHAVE_Website_Plan_AI_Section_Generator extends WPHAVE_Website_Plan_AI_Generator {

	/**
	 * Regenerate.
	 *
	 * @param array $params Params.
	 * @param callable $generate_text Generate text.
	 */

	public static function regenerate( array $params, callable $generate_text ) {
		return parent::regenerate_section( $params, $generate_text );
	}

}
