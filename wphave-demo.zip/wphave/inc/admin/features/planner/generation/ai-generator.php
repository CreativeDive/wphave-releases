<?php

require_once __DIR__ . '/ai-workflow.php';
require_once __DIR__ . '/ai-normalization.php';
require_once __DIR__ . '/ai-prompts.php';
require_once __DIR__ . '/ai-template-parts.php';
require_once __DIR__ . '/ai-ast.php';


if( ! defined('ABSPATH') ) {
	exit;
}

/**
 * Manage the website plan ai generator feature.
 */

class WPHAVE_Website_Plan_AI_Generator {

	use WPHAVE_Website_Plan_AI_Workflow,
		WPHAVE_Website_Plan_AI_Normalization,
		WPHAVE_Website_Plan_AI_Prompts,
		WPHAVE_Website_Plan_AI_Template_Parts,
		WPHAVE_Website_Plan_AI_AST;

}
