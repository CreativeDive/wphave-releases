<?php

require_once __DIR__ . '/../page-evidence.php';
require_once __DIR__ . '/ai-workflow.php';
require_once __DIR__ . '/ai-normalization.php';
require_once __DIR__ . '/ai-prompts.php';
require_once __DIR__ . '/ai-template-parts.php';
require_once __DIR__ . '/ai-ast.php';
require_once __DIR__ . '/ai-copy-grounding.php';
require_once __DIR__ . '/free-design-audit.php';
require_once __DIR__ . '/free-composition-resolver.php';
require_once __DIR__ . '/free-content-plan.php';
require_once __DIR__ . '/free-presentation.php';
require_once __DIR__ . '/free-tree-normalizer.php';
require_once __DIR__ . '/page-media-context.php';
require_once __DIR__ . '/media-composition.php';
require_once __DIR__ . '/pattern-ai-workflow.php';

if( ! defined('ABSPATH') ) {
	exit;
}

/**
 * Manage the website plan ai generator feature.
 */

class WPHAVE_Website_Plan_AI_Generator {

	use WPHAVE_Website_Plan_AI_Workflow,
		WPHAVE_Website_Plan_AI_Normalization,
		WPHAVE_Website_Plan_AI_Prompts,
		WPHAVE_Website_Plan_AI_Template_Parts,
		WPHAVE_Website_Plan_AI_AST,
		WPHAVE_Website_Plan_AI_Copy_Grounding;

}
