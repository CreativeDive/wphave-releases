<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Reviewed snapshots of existing WPHAVE Gutenberg block patterns. */
$text_slot = static function ( array $path, string $block, int $max_length ): array {
	return array(
		'path' => $path,
		'blockName' => $block,
		'kind' => 'text',
		'maxLength' => $max_length,
	);
};
$action_slot = static fn( array $path ): array => array(
	'path' => $path,
	'kind' => 'action',
);
$image_slot = static fn( array $path ): array => array(
	'path' => $path,
	'kind' => 'image',
);

return array(
	array(
		'patternId' => 'hero-editorial-02',
		'version' => 1,
		'sourceFile' => 'hero-editorial-02.blocks.html',
		'contentHash' => '6bbd0403d4145e9ddf3be48a1ba733bbfd16768f1f9b88588d9eca05eb1c693f',
		'category' => 'hero',
		'layoutFamily' => 'editorial-proof',
		'description' => 'Layered editorial hero with eyebrow, dominant heading, supporting copy and two next steps.',
		'contentKinds' => array( 'eyebrow', 'heading', 'body', 'actions' ),
		'minMedia' => 0,
		'maxMedia' => 0,
		'slots' => array(
			'eyebrow' => $text_slot( array( 0, 0, 0, 0 ), 'wphave/paragraph', 40 ),
			'heading' => $text_slot( array( 0, 0, 1 ), 'wphave/heading', 100 ),
			'body' => $text_slot( array( 0, 0, 2 ), 'wphave/paragraph', 220 ),
			'primaryAction' => $action_slot( array( 0, 0, 3, 0 ) ),
			'secondaryAction' => array_merge(
				$action_slot( array( 0, 0, 3, 1 ) ),
				array( 'required' => false )
			),
		),
		'variations' => array(),
	),
	array(
		'patternId' => 'hero-contrast-01',
		'version' => 1,
		'sourceFile' => 'hero-contrast-01.blocks.html',
		'contentHash' => '03014e90caf00717db2827ee064126d1399fd777198e892a5c9045c54bd77677',
		'category' => 'hero',
		'layoutFamily' => 'centered-contrast',
		'description' => 'Text-led, high-contrast hero with an eyebrow, clear hierarchy and up to two next steps.',
		'contentKinds' => array( 'eyebrow', 'heading', 'body', 'actions' ),
		'minMedia' => 0,
		'maxMedia' => 0,
		'slots' => array(
			'eyebrow' => $text_slot( array( 0, 0, 0, 0 ), 'wphave/paragraph', 40 ),
			'heading' => $text_slot( array( 0, 0, 1 ), 'wphave/heading', 100 ),
			'body' => $text_slot( array( 0, 0, 2 ), 'wphave/paragraph', 220 ),
			'primaryAction' => $action_slot( array( 0, 0, 3, 0 ) ),
			'secondaryAction' => array_merge(
				$action_slot( array( 0, 0, 3, 1 ) ),
				array( 'required' => false )
			),
		),
		'variations' => array(),
	),
	array(
		'patternId' => 'hero-image-01',
		'version' => 1,
		'sourceFile' => 'hero-image-01.blocks.html',
		'contentHash' => '4bc335a9d05e6f88001426e71b530ef8b8c84bccd48a99acaf7981af2f7b0f6e',
		'category' => 'hero',
		'layoutFamily' => 'asymmetric-image',
		'description' => 'Image-led split introduction with large copy and two distinct next steps.',
		'contentKinds' => array( 'heading', 'body', 'actions', 'image' ),
		'minMedia' => 1,
		'maxMedia' => 1,
		'slots' => array(
			'heading' => $text_slot( array( 0, 0, 0 ), 'wphave/heading', 90 ),
			'body' => $text_slot( array( 0, 0, 1 ), 'wphave/paragraph', 220 ),
			'primaryAction' => $action_slot( array( 0, 0, 2, 0 ) ),
			'secondaryAction' => $action_slot( array( 0, 0, 2, 1 ) ),
			'image' => $image_slot( array( 0, 1 ) ),
		),
		'variations' => array(),
	),
	array(
		'patternId' => 'features-grid-01',
		'version' => 1,
		'sourceFile' => 'features-grid-01.blocks.html',
		'contentHash' => 'a1f819d1cf7de0194a405dc41f096f245d99465a8ebcc5f4c69a5db81d06f041',
		'category' => 'features',
		'layoutFamily' => 'editorial-grid',
		'description' => 'Introduction with four independent information groups in a spacious grid.',
		'contentKinds' => array( 'heading', 'body', 'actions', 'items' ),
		'minMedia' => 0,
		'maxMedia' => 0,
		'slots' => array(
			'heading' => $text_slot( array( 0, 0, 0 ), 'wphave/heading', 80 ),
			'body' => $text_slot( array( 0, 0, 1 ), 'wphave/paragraph', 180 ),
			'primaryAction' => $action_slot( array( 0, 0, 2, 0 ) ),
			'secondaryAction' => $action_slot( array( 0, 0, 2, 1 ) ),
			'item1Heading' => $text_slot( array( 0, 1, 0, 1 ), 'wphave/heading', 60 ),
			'item1Body' => $text_slot( array( 0, 1, 0, 2 ), 'wphave/paragraph', 130 ),
			'item2Heading' => $text_slot( array( 0, 1, 1, 1 ), 'wphave/heading', 60 ),
			'item2Body' => $text_slot( array( 0, 1, 1, 2 ), 'wphave/paragraph', 130 ),
			'item3Heading' => $text_slot( array( 0, 1, 2, 1 ), 'wphave/heading', 60 ),
			'item3Body' => $text_slot( array( 0, 1, 2, 2 ), 'wphave/paragraph', 130 ),
			'item4Heading' => $text_slot( array( 0, 1, 3, 1 ), 'wphave/heading', 60 ),
			'item4Body' => $text_slot( array( 0, 1, 3, 2 ), 'wphave/paragraph', 130 ),
		),
		'variations' => array(),
	),
	array(
		'patternId' => 'content-duo-02',
		'version' => 1,
		'sourceFile' => 'content-cards-02.blocks.html',
		'contentHash' => '452220f8d97669764478a6dfff51bdac4d6003db24746ee84d2b2fd00f13ad7a',
		'category' => 'features',
		'layoutFamily' => 'asymmetric-duo',
		'description' => 'Two contrasting editorial panels, each with its own heading, explanation and route.',
		'contentKinds' => array( 'items', 'actions' ),
		'minMedia' => 0,
		'maxMedia' => 0,
		'slots' => array(
			'firstHeading' => $text_slot( array( 0, 0, 0, 0 ), 'wphave/heading', 70 ),
			'firstBody' => $text_slot( array( 0, 0, 0, 1 ), 'wphave/paragraph', 160 ),
			'firstAction' => $action_slot( array( 0, 0, 0, 2 ) ),
			'secondHeading' => $text_slot( array( 0, 1, 0, 0 ), 'wphave/heading', 70 ),
			'secondBody' => $text_slot( array( 0, 1, 0, 1 ), 'wphave/paragraph', 160 ),
			'secondAction' => $action_slot( array( 0, 1, 0, 2 ) ),
		),
		'variations' => array(),
	),
	array(
		'patternId' => 'gallery-featured-01',
		'version' => 1,
		'sourceFile' => 'gallery-featured-01.blocks.html',
		'contentHash' => '0dcb0b5d38e695c688d42a99b9f211d940441f8def01af1a714119fe5e369b08',
		'category' => 'gallery',
		'layoutFamily' => 'featured-mosaic',
		'description' => 'Three-image featured gallery with concise editorial framing.',
		'contentKinds' => array( 'heading', 'body', 'images' ),
		'minMedia' => 3,
		'maxMedia' => 3,
		'slots' => array(
			'heading' => $text_slot( array( 0, 0, 0 ), 'wphave/heading', 80 ),
			'body' => $text_slot( array( 0, 0, 1 ), 'wphave/paragraph', 160 ),
			'featuredImage' => $image_slot( array( 0, 1, 0 ) ),
			'secondImage' => $image_slot( array( 0, 1, 1 ) ),
			'thirdImage' => $image_slot( array( 0, 1, 2 ) ),
		),
		'variations' => array(),
	),
	array(
		'patternId' => 'editorial-split-01',
		'version' => 1,
		'sourceFile' => 'editorial-split-01.blocks.html',
		'contentHash' => '8400eef3d2de76fa45bad776f84520b70b1d8c3cf22f50c3394d539250c5e4d5',
		'category' => 'editorial',
		'layoutFamily' => 'flex-split',
		'description' => 'A colored Flex split with an editorial statement on one side and up to two clear routes on the other.',
		'contentKinds' => array( 'heading', 'body', 'actions' ),
		'minMedia' => 0,
		'maxMedia' => 0,
		'slots' => array(
			'heading' => $text_slot( array( 0, 0, 0 ), 'wphave/heading', 90 ),
			'body' => $text_slot( array( 0, 0, 1 ), 'wphave/paragraph', 180 ),
			'primaryAction' => $action_slot( array( 0, 1, 0 ) ),
			'secondaryAction' => array_merge(
				$action_slot( array( 0, 1, 1 ) ),
				array( 'required' => false )
			),
		),
		'variations' => array(),
	),
	array(
		'patternId' => 'cta-editorial-01',
		'version' => 1,
		'sourceFile' => 'cta-01.blocks.html',
		'contentHash' => '9f6b9b549574e83f6a51dad6273aea46efc402ccbade7faf2114550ba1cc6e1a',
		'category' => 'cta',
		'layoutFamily' => 'quiet-closing',
		'description' => 'Compact closing action with heading, supporting copy, and one button.',
		'contentKinds' => array( 'heading', 'body', 'action' ),
		'minMedia' => 0,
		'maxMedia' => 0,
		'slots' => array(
			'heading' => $text_slot( array( 0, 0 ), 'wphave/heading', 80 ),
			'body' => $text_slot( array( 0, 1 ), 'wphave/paragraph', 180 ),
			'action' => $action_slot( array( 0, 2 ) ),
		),
		'variations' => array(),
	),
	array(
		'patternId' => 'cta-spacious-02',
		'version' => 1,
		'sourceFile' => 'cta-spacious-02.blocks.html',
		'contentHash' => '2a5dd8a796fcc2cbaccb580e9a38e92f9d7780c1470a5955bbc35953238f31c8',
		'category' => 'cta',
		'layoutFamily' => 'spacious-color-close',
		'description' => 'Wide colored closing panel with centered copy and two next steps.',
		'contentKinds' => array( 'heading', 'body', 'actions' ),
		'minMedia' => 0,
		'maxMedia' => 0,
		'slots' => array(
			'heading' => $text_slot( array( 0, 1, 0 ), 'wphave/heading', 80 ),
			'body' => $text_slot( array( 0, 1, 1 ), 'wphave/paragraph', 180 ),
			'primaryAction' => $action_slot( array( 0, 2, 0 ) ),
			'secondaryAction' => array_merge(
				$action_slot( array( 0, 2, 1 ) ),
				array( 'required' => false )
			),
		),
		'variations' => array(),
	),
);
