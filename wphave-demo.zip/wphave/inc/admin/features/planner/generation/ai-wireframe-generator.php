<?php

if( ! defined('ABSPATH') ) {
	exit;
}

/**
 * AI-backed wireframe generation for Website Plans.
 */

class WPHAVE_Website_Plan_AI_Wireframe_Generator extends WPHAVE_Website_Plan_AI_Generator {

	/**
	 * Generate.
	 *
	 * @param array $params Params.
	 * @param callable $generate_text Generate text.
	 */

	public static function generate( array $params, callable $generate_text ) {
		return parent::create_wireframes( $params, $generate_text );
	}

}
