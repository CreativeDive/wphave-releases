<?php

if( ! defined('ABSPATH') ) {
	exit;
}

/**
 * AI-backed sitemap generation for Website Plans.
 */

class WPHAVE_Website_Plan_AI_Sitemap_Generator extends WPHAVE_Website_Plan_AI_Generator {

	/**
	 * Generate.
	 *
	 * @param array $params Params.
	 * @param callable $generate_text Generate text.
	 */

	public static function generate( array $params, callable $generate_text ) {
		return parent::create_sitemap( $params, $generate_text );
	}

}
