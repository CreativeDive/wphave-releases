<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Plans the substance of one Free page before any layout or visitor copy.
 * Its output is editorial context, never a source of verified business facts.
 */
class WPHAVE_Website_Plan_Free_Content_Plan {
	private const PURPOSES = array( 'introduce', 'explain', 'showcase', 'navigate', 'reassure', 'convert' );
	private const STATUSES = array( 'supported', 'limited', 'insufficient' );
	private const DECISIONS = array( 'keep', 'merge' );
	private const ACTION_KINDS = array( 'navigate', 'convert' );
	private const PLACEMENT_ROLES = array( 'primary', 'contextual', 'closing', 'unspecified' );
	private const DESIGN_EMPHASES = array( 'dominant', 'supporting', 'quiet' );
	private const DESIGN_DENSITIES = array( 'compact', 'comfortable', 'spacious' );
	private const DESIGN_COMPOSITIONS = array( 'open', 'asymmetric', 'editorial-lead', 'editorial-top', 'editorial-rail' );
	private const CONTENT_MODES = array( 'full', 'action-only' );

	public static function generate( array $brief, array $page, array $site_pages, callable $generate_text, array $options ): array|WP_Error {
		$options = array_replace( $options, array(
			'responseFormat' => 'json_object',
			'maxTokens' => max( 12000, (int) ( $options['maxTokens'] ?? 0 ) ),
			'temperature' => 0.2,
		) );
		$messages = self::messages( $brief, $page, $site_pages );
		$response = $generate_text( $messages, $options );
		if( is_wp_error( $response ) ) {
			return $response;
		}

		$raw = json_decode( (string) ( $response['result'] ?? '' ), true );
		$plan = self::sanitize( $raw, $page, $site_pages, $brief );
		if( $plan === array() && ( $raw['pageStructure'] ?? '' ) === 'single-section' && self::has_rich_page_facts( $brief ) ) {
			$messages[] = array(
				'role' => 'user',
				'content' => 'The confirmed facts contain several substantial, independent visitor topics. A single-section plan is rejected for this page. Return a new multi-section plan that covers only the independently supported topics, with no invented facts or filler sections.',
			);
			$response = $generate_text( $messages, $options );
			if( is_wp_error( $response ) ) {
				return $response;
			}
			$raw = json_decode( (string) ( $response['result'] ?? '' ), true );
			$plan = self::sanitize( $raw, $page, $site_pages, $brief );
		}
		if( $plan === array() ) {
			return new WP_Error( 'ai_website_content_plan_invalid', __( 'The page content plan was incomplete. Please try this page again.', 'wphave' ), array( 'status' => 502 ) );
		}

		return $plan;
	}

	public static function messages( array $brief, array $page, array $site_pages ): array {
		$paths = array_values( array_map( static function( $site_page ) {
			return array(
				'slug' => (string) ( $site_page['slug'] ?? '' ),
				'title' => (string) ( $site_page['title'] ?? '' ),
			);
		}, $site_pages ) );

		return array(
			array(
				'role' => 'system',
				'content' => implode( "\n", array(
					'Plan the content of exactly one website page before choosing any layout or writing visitor copy. Return one JSON object only.',
					'brief.designDirection is a presentation preference, never factual evidence. It may guide design emphasis and composition only: calm favors spacious focused sections; editorial favors strong typography and varied reading widths; image-led favors a bound image when one exists; expressive favors bolder but readable contrast. Never add content or images merely to satisfy the direction.',
					'brief.layoutVariantSeed, when present, asks for a different spatial plan using the same verified facts. Treat 0 as focused/open, 1 as editorial hierarchy, 2 as asymmetric emphasis, and 3 as compact contrast. Use only compositions that the independent content regions can support; never add filler to satisfy the seed.',
					'Only brief.offer and brief.facts verify business claims. Routes verify destinations only; the goal expresses a desired user action only. Neither routes nor goals support a factual business claim.',
					WPHAVE_AI_Block_Design_Compiler::pro_layout_enabled() ? 'brief.availableMedia, when nonempty, is a validated image selected for this exact page before planning. Its dimensions and aspect ratio may guide mediaIntent and spatial design only. The image ID and geometry do not verify the image subject, the business, products, people or visitor experience. Never derive factual copy or contentItems from media metadata.' : '',
					WPHAVE_AI_Block_Design_Compiler::pro_layout_enabled() ? 'When brief.availableMedia is nonempty, choose heroMediaPlacement as before-content or after-content. Before-content is permitted for an image with aspectRatio at least 2.2, or for a single-section page with a short verified introduction and aspectRatio at least 1.5. The latter becomes a bounded 768px-wide, 16:9 image-led stack with the image before the complete text cluster. Prefer it when the page task is visual exploration of the offer, such as viewing a collection, exhibition or portfolio; the selected image provides atmosphere, never unverified facts. Choose after-content for a text-led media grid when the task is understanding a service, visit or practical next step. Use the sitePages and page title to vary the spatial rhythm of neighboring pages instead of making every detail page the same grid. Do not infer the subject of an image from its dimensions. With no suitable image choose after-content.' : '',
					WPHAVE_AI_Block_Design_Compiler::pro_layout_enabled() ? 'Return 1 to 8 ordered sections. Normally keep at least 2. Only when the confirmed information supplies no independent secondary topic, choose pageStructure=single-section and structureReason=no-independent-secondary-content with exactly one keep section. A thin identity/location/offer brief plus route actions can be one focused image-led introduction; do not invent a second section to satisfy a count. Never collapse a separately verified topic or independent visitor task into one section. Every section needs a unique id, purpose, primaryMessage, distinctContribution, sources, contentItems, actions, mediaIntent, status and decision.' : 'Return 2 to 8 ordered sections with at least 2 keep decisions. Each needs a unique id, purpose, primaryMessage, distinctContribution, sources, contentItems, actions, mediaIntent, status and decision.',
					'Allowed purposes: introduce, explain, showcase, navigate, reassure, convert. Allowed statuses: supported, limited, insufficient. Allowed decisions: keep, merge.',
					'Sources have facts, routes, goals arrays. Facts may reference offer or facts only when nonempty in the brief. Routes may reference exact sitePages slugs only. Goals may reference goal only when nonempty in the brief.',
					'Every content item needs an id, subject and sources. Use contentItems only for independently supported topics; never split one general fact into several generic categories. A generic mention of works does not verify specific works or justify a works showcase: mark it limited or merge it.',
					'Actions are actual planned visitor links, not evidence references. Each action needs id, kind (navigate or convert), targetSlug (exact sitePages slug) and goalRef (goal for a conversion action, empty for navigation). Do not use convert when brief.goal is empty.',
					'Optional placementRole is primary, contextual or closing; it describes editorial purpose, not button styling. Include only links that the section will really render.',
					'If a later kept topic section already links to its destination, do not repeat that navigate action in the intro merely to create a navigation index. A genuinely primary conversion may still appear in the intro.',
					'The server derives route and goal provenance from valid actions, so these do not need to be repeated in sources.',
					'DistinctContribution must say what new information or independent visitor task this section contributes compared with other sections. If sections repeat the same facts and user task, merge one into a kept section. A sparse but distinct visitor task may stay concise.',
					'A location fact proves location only, not trust, quality or reputation. Do not create a separate reassurance section from a location or paraphrase of the offer unless another verified fact or independent visitor task supports it.',
					'A section supported only by routes or goals cannot have supported status. Do not claim that navigation targets or desired conversions are confirmed business facts.',
					'MediaIntent is none or preferred. No image is assumed to exist. Never output layout nodes, grids, surfaces, CSS, finished marketing copy or fabricated facts.',
					WPHAVE_AI_Block_Design_Compiler::pro_layout_enabled() ? 'For each kept section also provide a small design intent: design.emphasis dominant|supporting|quiet, design.density compact|comfortable|spacious, design.composition open|asymmetric|editorial-lead|editorial-top|editorial-rail. Choose editorial presets only when the section truly has three or four distinct content regions. Vary composition across the page; do not turn every section into cards. This intent does not verify facts.' : '',
					WPHAVE_AI_Block_Design_Compiler::pro_layout_enabled() ? 'For each kept section set contentMode to full or action-only. Use action-only for an orientation, offering or action section with a planned action when its heading and action already communicate everything verified for that section; then no explanatory paragraph is allowed. A verified offering name by itself does not justify a paragraph saying that the offering exists. For example, a section headed "Ausstellung" with an exhibition link and no confirmed exhibition detail is action-only, even if the offer is verified. A confirmed date or other independent detail makes the section full. A single contentItem can contain such a valuable detail, so item count alone never justifies action-only. If uncertain whether a verified detail would be lost, choose full. Never discard a verified detail to shorten the page.' : '',
					'JSON shape: {"pageSlug":"...","pageStructure":"multi-section","structureReason":"","heroMediaPlacement":"after-content","sections":[{"id":"...","purpose":"introduce","primaryMessage":"...","distinctContribution":"...","sources":{"facts":["offer"],"routes":[],"goals":[]},"contentItems":[{"id":"...","subject":"...","sources":{"facts":["facts"],"routes":[],"goals":[]}}],"actions":[{"id":"...","kind":"navigate","targetSlug":"...","goalRef":"","placementRole":"primary"}],"mediaIntent":"none","status":"limited","decision":"keep","reason":"...","targetSectionId":"...","design":{"emphasis":"dominant","density":"spacious","composition":"open"},"contentMode":"full"}]}.',
				) ),
			),
			array(
				'role' => 'user',
				'content' => wp_json_encode( array(
					'brief' => $brief,
					'page' => array( 'slug' => $page['slug'] ?? '', 'title' => $page['title'] ?? '', 'sections' => $page['sections'] ?? array() ),
					'sitePages' => $paths,
				), JSON_UNESCAPED_UNICODE ),
			),
		);
	}

	public static function sanitize( $raw, array $page, array $site_pages, array $brief = array() ): array {
		if( ! is_array( $raw ) || ! is_string( $raw['pageSlug'] ?? null ) || $raw['pageSlug'] !== (string) ( $page['slug'] ?? '' ) || ! is_array( $raw['sections'] ?? null ) ) {
			return array();
		}
		$pro_layout = WPHAVE_AI_Block_Design_Compiler::pro_layout_enabled();
		$media_ratio = (float) ( $brief['availableMedia'][0]['aspectRatio'] ?? 0 );
		$can_lead_with_media = $media_ratio >= 2.2 || ( ( $raw['pageStructure'] ?? '' ) === 'single-section' && $media_ratio >= 1.5 );
		$media_placement = $can_lead_with_media && ( $raw['heroMediaPlacement'] ?? '' ) === 'before-content'
			? 'before-content'
			: 'after-content';
		$single_section = $pro_layout && ( $raw['pageStructure'] ?? '' ) === 'single-section';
		$minimum_sections = $single_section ? 1 : 2;
		if( ! array_is_list( $raw['sections'] ) || count( $raw['sections'] ) < $minimum_sections || count( $raw['sections'] ) > 8 ) {
			return array();
		}
		if( $single_section && ( $raw['structureReason'] ?? '' ) !== 'no-independent-secondary-content' ) {
			return array();
		}
		if( $single_section && self::has_rich_page_facts( $brief ) ) {
			return array();
		}

		$sections = array();
		$ids = array();
		foreach( $raw['sections'] as $section ) {
			if( ! is_array( $section ) || isset( $section['layout'] ) || isset( $section['blockTree'] ) ) {
				return array();
			}
			foreach( array( 'id', 'purpose', 'status', 'decision', 'primaryMessage', 'distinctContribution' ) as $required_text ) {
				if( ! is_string( $section[$required_text] ?? null ) ) {
					return array();
				}
			}
			foreach( array( 'reason', 'targetSectionId' ) as $optional_text ) {
				if( isset( $section[$optional_text] ) && ! is_string( $section[$optional_text] ) ) {
					return array();
				}
			}
			$id = sanitize_key( (string) ( $section['id'] ?? '' ) );
			$purpose = sanitize_key( (string) ( $section['purpose'] ?? '' ) );
			$status = sanitize_key( (string) ( $section['status'] ?? '' ) );
			$decision = sanitize_key( (string) ( $section['decision'] ?? '' ) );
			$message = trim( sanitize_text_field( (string) ( $section['primaryMessage'] ?? '' ) ) );
			$contribution = trim( sanitize_text_field( (string) ( $section['distinctContribution'] ?? '' ) ) );
			if( $id === '' || isset( $ids[$id] ) || $message === '' || $contribution === '' || ! in_array( $purpose, self::PURPOSES, true ) || ! in_array( $status, self::STATUSES, true ) || ! in_array( $decision, self::DECISIONS, true ) ) {
				return array();
			}
			$ids[$id] = true;
			if( ! is_array( $section['contentItems'] ?? null ) || ! array_is_list( $section['contentItems'] ) ) {
				return array();
			}
			$sources = self::sources( $section['sources'] ?? null, $brief, $site_pages );
			if( $sources === null ) {
				return array();
			}
			$items = array();
			$item_ids = array();
			foreach( $section['contentItems'] ?? array() as $item ) {
				if( ! is_array( $item ) || isset( $item['layout'] ) ) {
					return array();
				}
				if( ! is_string( $item['id'] ?? null ) || ! is_string( $item['subject'] ?? null ) ) {
					return array();
				}
				$subject = trim( sanitize_text_field( (string) ( $item['subject'] ?? '' ) ) );
				$item_id = sanitize_key( (string) ( $item['id'] ?? '' ) );
				$item_sources = self::sources( $item['sources'] ?? null, $brief, $site_pages );
				if( $subject === '' || $item_id === '' || isset( $item_ids[$item_id] ) || $item_sources === null || count( $items ) >= 6 ) {
					return array();
				}
				$item_ids[$item_id] = true;
				$items[] = array(
					'id' => $item_id,
					'subject' => mb_substr( $subject, 0, 140 ),
					'sources' => $item_sources,
				);
			}
			$actions = self::actions( $section['actions'] ?? null, $site_pages, $brief );
			if( $actions === null ) {
				return array();
			}
			foreach( $actions as $action ) {
				$sources['routes'][] = $action['targetSlug'];
				if( $action['goalRef'] !== '' ) {
					$sources['goals'][] = $action['goalRef'];
				}
			}
			$sources['routes'] = array_values( array_unique( $sources['routes'] ) );
			$sources['goals'] = array_values( array_unique( $sources['goals'] ) );
			$design = $decision === 'keep'
				? self::design_intent( $section['design'] ?? null )
				: array();
			if( $design === null ) {
				return array();
			}
			if( $decision === 'keep' && $design !== array() ) {
				$minimum_items = match( $design['composition'] ) {
					'editorial-rail' => 4,
					'editorial-lead', 'editorial-top' => 3,
					'asymmetric' => 2,
					default => 1,
				};
				if( count( $items ) < $minimum_items ) {
					$design['composition'] = 'open';
				}
			}
			$content_mode = 'full';
			if( WPHAVE_AI_Block_Design_Compiler::pro_layout_enabled() && $decision === 'keep' ) {
				$content_mode = (string) ( $section['contentMode'] ?? 'full' );
				if( ! in_array( $content_mode, self::CONTENT_MODES, true ) || ( $content_mode === 'action-only' && $actions === array() ) ) {
					return array();
				}
			}
			if( $status === 'supported' && $sources['facts'] === array() ) {
				if( $purpose !== 'navigate' || $content_mode !== 'action-only' || $actions === array() ) {
					return array();
				}
				$status = 'limited';
			}
			$sections[] = array(
				'id' => $id,
				'purpose' => $purpose,
				'primaryMessage' => mb_substr( $message, 0, 240 ),
				'distinctContribution' => mb_substr( $contribution, 0, 240 ),
				'sources' => $sources,
				'contentItems' => $items,
				'actions' => $actions,
				'mediaIntent' => ( $section['mediaIntent'] ?? '' ) === 'preferred' ? 'preferred' : 'none',
				'status' => $status,
				'decision' => $decision,
				'reason' => mb_substr( sanitize_text_field( (string) ( $section['reason'] ?? '' ) ), 0, 240 ),
				'targetSectionId' => sanitize_key( (string) ( $section['targetSectionId'] ?? '' ) ),
				'design' => $design,
				'contentMode' => $content_mode,
			);
		}

		$decisions = array_column( $sections, 'decision', 'id' );
		foreach( $sections as $section ) {
			if( $section['decision'] === 'merge' && ( $section['targetSectionId'] === $section['id'] || ( $decisions[$section['targetSectionId']] ?? '' ) !== 'keep' ) ) {
				return array();
			}
		}
		$kept_count = count( array_filter( $sections, static function( $section ) {
			return $section['decision'] === 'keep';
		} ) );
		if( $kept_count < $minimum_sections || ( $single_section && ( $kept_count !== 1 || count( $sections ) !== 1 || count( $sections[0]['contentItems'] ) > 2 || $sections[0]['actions'] === array() ) ) ) {
			return array();
		}
		if( $pro_layout && ! $single_section ) {
			$sections = self::ensure_rich_page_composition( $sections );
		}
		$copy_source = (string) ( $brief['confirmedPageFacts'] ?? '' ) !== ''
			? $brief['confirmedPageFacts']
			: ( $brief['facts'] ?? '' );
		$locked_copy = $single_section && count( $sections[0]['contentItems'] ) <= 1 && $sections[0]['contentMode'] === 'full' && mb_strlen( (string) $copy_source ) <= 1000
			? trim( (string) $copy_source )
			: '';

		return array(
			'version' => WPHAVE_AI_Block_Design_Compiler::pro_layout_enabled() ? 3 : 2,
			'pageSlug' => (string) $page['slug'],
			'heroMediaPlacement' => $media_placement,
			'copyPolicy' => $locked_copy !== '' ? 'locked' : 'reviewed',
			'lockedCopy' => $locked_copy,
			'requiredH1' => WPHAVE_AI_Block_Design_Compiler::pro_layout_enabled() && (string) $page['slug'] !== 'home'
				? trim( sanitize_text_field( (string) ( $page['title'] ?? '' ) ) )
				: '',
			'pageStructure' => $single_section ? 'single-section' : 'multi-section',
			'sections' => $sections,
			'diagnostics' => self::diagnostics( $sections ),
		);
	}

	/**
	 * Reserve one editorial layout for a genuinely multi-topic page when the model
	 * leaves every section open. The content items are validated before this step.
	 */
	private static function ensure_rich_page_composition( array $sections ): array {
		foreach( $sections as $section ) {
			if( ( $section['decision'] ?? '' ) === 'keep' && ( $section['design']['composition'] ?? 'open' ) !== 'open' ) {
				return $sections;
			}
		}

		foreach( $sections as $index => $section ) {
			if( ( $section['decision'] ?? '' ) !== 'keep' || ( $section['status'] ?? '' ) !== 'supported' || ! in_array( $section['purpose'] ?? '', array( 'showcase', 'explain' ), true ) ) {
				continue;
			}
			$subjects = array_map( static function( $item ) {
				return mb_strtolower( (string) ( $item['subject'] ?? '' ) );
			}, $section['contentItems'] ?? array() );
			if( count( array_unique( $subjects ) ) >= 3 ) {
				$sections[$index]['design']['composition'] = 'editorial-lead';
				break;
			}
		}

		return $sections;
	}

	private static function has_rich_page_facts( array $brief ): bool {
		$facts = trim( (string) ( $brief['confirmedPageFacts'] ?? '' ) );
		if( mb_strlen( $facts ) < 180 ) {
			return false;
		}
		$sentences = preg_split( '/(?<=[.!?])\s+/u', $facts ) ?: array();
		$substantial = array_filter( $sentences, static function( $sentence ) {
			return mb_strlen( trim( $sentence ) ) >= 20;
		} );
		return count( $substantial ) >= 3;
	}

	private static function design_intent( $raw ): ?array {
		if( ! WPHAVE_AI_Block_Design_Compiler::pro_layout_enabled() ) {
			return array();
		}
		if( ! is_array( $raw ) ) {
			return null;
		}
		$emphasis = (string) ( $raw['emphasis'] ?? '' );
		$density = (string) ( $raw['density'] ?? '' );
		$composition = (string) ( $raw['composition'] ?? '' );
		if( ! in_array( $emphasis, self::DESIGN_EMPHASES, true ) || ! in_array( $density, self::DESIGN_DENSITIES, true ) || ! in_array( $composition, self::DESIGN_COMPOSITIONS, true ) ) {
			return null;
		}

		return array(
			'emphasis' => $emphasis,
			'density' => $density,
			'composition' => $composition,
		);
	}

	private static function actions( $raw, array $site_pages, array $brief ): ?array {
		if( ! is_array( $raw ) || ! array_is_list( $raw ) || count( $raw ) > 6 ) {
			return null;
		}
		$known_routes = array_column( $site_pages, 'slug' );
		$actions = array();
		$ids = array();
		foreach( $raw as $action ) {
			if( ! is_array( $action ) ) {
				return null;
			}
			foreach( array( 'id', 'kind', 'targetSlug', 'goalRef' ) as $required_text ) {
				if( ! is_string( $action[$required_text] ?? null ) ) {
					return null;
				}
			}
			if( isset( $action['placementRole'] ) && ! is_string( $action['placementRole'] ) ) {
				return null;
			}
			$id = sanitize_key( (string) ( $action['id'] ?? '' ) );
			$kind = sanitize_key( (string) ( $action['kind'] ?? '' ) );
			$target = (string) ( $action['targetSlug'] ?? '' );
			$goal = sanitize_key( self::goal_reference( (string) ( $action['goalRef'] ?? '' ), $brief ) );
			$role = sanitize_key( (string) ( $action['placementRole'] ?? 'unspecified' ) );
			if( $id === '' || isset( $ids[$id] ) || ! in_array( $kind, self::ACTION_KINDS, true ) || ! in_array( $target, $known_routes, true ) ) {
				return null;
			}
			if( ! in_array( $role, self::PLACEMENT_ROLES, true ) ) {
				return null;
			}
			if( ( $kind === 'convert' && ( $goal !== 'goal' || trim( (string) ( $brief['goal'] ?? '' ) ) === '' ) ) || ( $kind === 'navigate' && $goal !== '' ) ) {
				return null;
			}
			$ids[$id] = true;
			$actions[] = array(
				'id' => $id,
				'kind' => $kind,
				'targetSlug' => $target,
				'goalRef' => $goal,
				'placementRole' => $role,
			);
		}
		return $actions;
	}

	private static function goal_reference( string $reference, array $brief ): string {
		$goal = trim( (string) ( $brief['goal'] ?? '' ) );
		if( $goal !== '' && trim( $reference ) === $goal ) {
			return 'goal';
		}

		return $reference;
	}

	private static function diagnostics( array $sections ): array {
		$diagnostics = array();
		foreach( $sections as $section_index => $section ) {
			if( $section['decision'] !== 'keep' ) {
				continue;
			}
			if( $section['purpose'] === 'reassure' && $section['actions'] === array() && $section['sources']['facts'] !== array() && $section['sources']['routes'] === array() && $section['sources']['goals'] === array() ) {
				$overlaps = array();
				foreach( array_slice( $sections, 0, $section_index ) as $earlier ) {
					if( $earlier['decision'] === 'keep' && array_diff( $section['sources']['facts'], $earlier['sources']['facts'] ) === array() ) {
						$overlaps[] = $earlier['id'];
					}
				}
				if( $overlaps !== array() ) {
					$diagnostics[] = array(
						'sectionId' => $section['id'],
						'kind' => 'editorial_review',
						'reason' => 'unverifiable_distinct_fact_only_section',
						'overlapsWith' => $overlaps,
					);
				}
			}
			if( $section['purpose'] === 'showcase' && $section['status'] === 'supported' && count( $section['contentItems'] ) <= 1 ) {
				$diagnostics[] = array(
					'sectionId' => $section['id'],
					'kind' => 'editorial_review',
					'reason' => 'insufficient_distinct_evidence',
				);
			}
			if( ! in_array( $section['purpose'], array( 'navigate', 'convert' ), true ) || $section['sources']['facts'] !== array() || $section['actions'] === array() ) {
				continue;
			}
			$covered_by = array();
			foreach( $section['actions'] as $action ) {
				$covering_section = '';
				foreach( $sections as $other ) {
					if( $other['id'] === $section['id'] || $other['decision'] !== 'keep' ) {
						continue;
					}
					foreach( $other['actions'] as $other_action ) {
						if( $other_action['targetSlug'] === $action['targetSlug'] && $other_action['goalRef'] === $action['goalRef'] && $other_action['kind'] === $action['kind'] ) {
							$covering_section = $other['id'];
							break 2;
						}
					}
				}
				if( $covering_section === '' ) {
					$covered_by = array();
					break;
				}
				$covered_by[] = $covering_section;
			}
			if( $covered_by !== array() ) {
				$diagnostics[] = array(
					'sectionId' => $section['id'],
					'kind' => 'merge_required',
					'reason' => 'duplicate_planned_actions',
					'coveredBy' => array_values( array_unique( $covered_by ) ),
				);
			}
		}
		$exposure = array();
		foreach( $sections as $section ) {
			if( $section['decision'] !== 'keep' ) {
				continue;
			}
			foreach( $section['actions'] as $action ) {
				$key = implode( '|', array( $action['targetSlug'], $action['kind'], $action['goalRef'] ) );
				$exposure[$key][] = array(
					'sectionId' => $section['id'],
					'actionId' => $action['id'],
					'placementRole' => $action['placementRole'],
				);
			}
		}
		foreach( $exposure as $instances ) {
			if( count( array_unique( array_column( $instances, 'sectionId' ) ) ) < 2 ) {
				continue;
			}
			$roles = array_unique( array_column( $instances, 'placementRole' ) );
			if( count( $roles ) === count( $instances ) && ! in_array( 'unspecified', $roles, true ) ) {
				continue;
			}
			$diagnostics[] = array(
				'kind' => 'editorial_review',
				'reason' => 'redundant_action_exposure',
				'actions' => $instances,
			);
		}
		return $diagnostics;
	}

	/**
	 * Check that a block tree actually implements the kept editorial sections and
	 * their planned links. This does not attempt to judge the meaning of copy.
	 */
	public static function tree_issues( $tree, array $plan ): array {
		if( ! is_array( $tree ) || ! is_array( $tree['nodes'] ?? null ) ) {
			return array( 'content_plan_tree_missing' );
		}
		$kept = array_values( array_filter( $plan['sections'] ?? array(), static function( $section ) {
			return ( $section['decision'] ?? '' ) === 'keep';
		} ) );
		$sections = $tree['nodes'];
		$issues = array();
		if( count( $sections ) !== count( $kept ) ) {
			$issues[] = 'content_plan_section_count';
		}
		$expected_ids = array_column( $kept, 'id' );
		$actual_ids = array_map( static function( $section ) {
			return is_array( $section ) ? (string) ( $section['id'] ?? '' ) : '';
		}, $sections );
		if( $actual_ids !== $expected_ids ) {
			$issues[] = 'content_plan_section_ids';
		}
		if( ( $plan['copyPolicy'] ?? '' ) === 'locked' && self::paragraph_texts( $tree ) !== array( (string) ( $plan['lockedCopy'] ?? '' ) ) ) {
			$issues[] = 'content_plan_locked_copy_changed';
		}
		$required_h1 = trim( (string) ( $plan['requiredH1'] ?? '' ) );
		if( $required_h1 !== '' && self::h1_texts( $tree ) !== array( $required_h1 ) ) {
			$issues[] = 'content_plan_page_h1';
		}

		foreach( $kept as $index => $planned_section ) {
			$actual_section = $sections[$index] ?? null;
			if( ! is_array( $actual_section ) || (string) ( $actual_section['id'] ?? '' ) !== $planned_section['id'] ) {
				continue;
			}
			if( WPHAVE_AI_Block_Design_Compiler::pro_layout_enabled() && ( $planned_section['design']['composition'] ?? '' ) === 'open' && self::contains_spatial_split( $actual_section ) ) {
				$issues[] = 'content_plan_open_composition_split';
			}
			$composition = (string) ( $planned_section['design']['composition'] ?? 'open' );
			if( WPHAVE_AI_Block_Design_Compiler::pro_layout_enabled()
				&& in_array( $composition, array( 'editorial-lead', 'editorial-top', 'editorial-rail' ), true )
				&& ! self::contains_editorial_preset( $actual_section, $composition ) ) {
				$issues[] = 'content_plan_editorial_composition_missing';
			}
			if( self::largest_grid_area_region_count( $actual_section ) > count( $planned_section['contentItems'] ?? array() ) ) {
				$issues[] = 'content_plan_grid_areas_unsupported';
			}
			if( ( $planned_section['contentMode'] ?? 'full' ) === 'action-only' ) {
				$text_nodes = self::section_text_nodes( $actual_section );
				if( $text_nodes['heading'] !== 1 || $text_nodes['paragraph'] !== 0 ) {
					$issues[] = 'content_plan_action_only_has_extra_copy';
				}
			}
			$actual_actions = array();
			self::collect_tree_actions( $actual_section, $actual_actions, $issues, true );
			$planned_actions = array_column( $planned_section['actions'], null, 'id' );
			foreach( $planned_actions as $action_id => $planned_action ) {
				$matching = $actual_actions[$action_id] ?? array();
				$expected_url = $planned_action['targetSlug'] === 'home' ? '/' : '/' . $planned_action['targetSlug'] . '/';
				if( count( $matching ) !== 1 || $matching[0]['url'] !== $expected_url || $matching[0]['kind'] !== $planned_action['kind'] || $matching[0]['goalRef'] !== $planned_action['goalRef'] ) {
					$issues[] = 'content_plan_action_missing_or_changed';
				}
			}
			foreach( array_keys( $actual_actions ) as $action_id ) {
				if( ! isset( $planned_actions[$action_id] ) ) {
					$issues[] = 'content_plan_unplanned_action';
				}
			}
		}
		return array_values( array_unique( $issues ) );
	}

	public static function apply_locked_copy( $tree, array $plan ) {
		if( ( $plan['copyPolicy'] ?? '' ) !== 'locked' || ! is_array( $tree ) || count( self::paragraph_texts( $tree ) ) !== 1 ) {
			return $tree;
		}
		self::replace_first_paragraph( $tree, (string) $plan['lockedCopy'] );
		return $tree;
	}

	private static function paragraph_texts( array $node ): array {
		$texts = array();
		if( ( $node['kind'] ?? '' ) === 'paragraph' ) {
			$texts[] = trim( (string) ( $node['text']['content'] ?? $node['content'] ?? '' ) );
		}
		foreach( (array) ( $node['nodes'] ?? array() ) as $child ) {
			if( is_array( $child ) ) {
				$texts = array_merge( $texts, self::paragraph_texts( $child ) );
			}
		}
		return $texts;
	}

	private static function replace_first_paragraph( array &$node, string $text ): bool {
		if( ( $node['kind'] ?? '' ) === 'paragraph' ) {
			$node['text'] = is_array( $node['text'] ?? null ) ? $node['text'] : array();
			$node['text']['content'] = $text;
			unset( $node['content'] );
			return true;
		}
		foreach( (array) ( $node['nodes'] ?? array() ) as $index => $child ) {
			if( is_array( $child ) && self::replace_first_paragraph( $node['nodes'][$index], $text ) ) {
				return true;
			}
		}
		return false;
	}

	private static function h1_texts( array $node ): array {
		$texts = array();
		if( ( $node['kind'] ?? '' ) === 'heading' && ( $node['text']['level'] ?? 'h2' ) === 'h1' ) {
			$texts[] = trim( sanitize_text_field( (string) ( $node['text']['content'] ?? $node['content'] ?? '' ) ) );
		}
		foreach( (array) ( $node['nodes'] ?? array() ) as $child ) {
			if( is_array( $child ) ) {
				$texts = array_merge( $texts, self::h1_texts( $child ) );
			}
		}
		return $texts;
	}

	private static function contains_spatial_split( array $node ): bool {
		if( in_array( (string) ( $node['kind'] ?? '' ), array( 'asymmetric', 'gridareas' ), true ) ) {
			return true;
		}
		foreach( (array) ( $node['nodes'] ?? array() ) as $child ) {
			if( is_array( $child ) && self::contains_spatial_split( $child ) ) {
				return true;
			}
		}
		return false;
	}

	private static function contains_editorial_preset( array $node, string $preset ): bool {
		if( ( $node['kind'] ?? '' ) === 'gridareas' && ( $node['layout']['presetKey'] ?? '' ) === $preset ) {
			return true;
		}
		foreach( (array) ( $node['nodes'] ?? array() ) as $child ) {
			if( is_array( $child ) && self::contains_editorial_preset( $child, $preset ) ) {
				return true;
			}
		}
		return false;
	}

	private static function section_text_nodes( array $node ): array {
		$counts = array( 'heading' => 0, 'paragraph' => 0 );
		$kind = (string) ( $node['kind'] ?? '' );
		if( isset( $counts[$kind] ) ) {
			$counts[$kind]++;
		}
		foreach( (array) ( $node['nodes'] ?? array() ) as $child ) {
			if( ! is_array( $child ) ) {
				continue;
			}
			$child_counts = self::section_text_nodes( $child );
			$counts['heading'] += $child_counts['heading'];
			$counts['paragraph'] += $child_counts['paragraph'];
		}
		return $counts;
	}

	private static function largest_grid_area_region_count( array $node ): int {
		$largest = ( $node['kind'] ?? '' ) === 'gridareas' && is_array( $node['nodes'] ?? null )
			? count( $node['nodes'] )
			: 0;
		foreach( (array) ( $node['nodes'] ?? array() ) as $child ) {
			if( is_array( $child ) ) {
				$largest = max( $largest, self::largest_grid_area_region_count( $child ) );
			}
		}

		return $largest;
	}

	private static function collect_tree_actions( array $node, array &$actions, array &$issues, bool $is_root = false ): void {
		$kind = (string) ( $node['kind'] ?? '' );
		if( ! $is_root && $kind === 'section' ) {
			$issues[] = 'content_plan_nested_section';
		}
		$entries = $kind === 'button'
			? array( $node )
			: ( $kind === 'actions' ? (array) ( $node['actions'] ?? array() ) : array() );
		foreach( $entries as $entry ) {
			if( ! is_array( $entry ) ) {
				$issues[] = 'content_plan_action_malformed';
				continue;
			}
			foreach( array( 'planActionId', 'planActionKind', 'planGoalRef', 'url' ) as $required_text ) {
				if( ! is_string( $entry[$required_text] ?? null ) ) {
					$issues[] = 'content_plan_action_malformed';
					continue 2;
				}
			}
			$id = sanitize_key( (string) ( $entry['planActionId'] ?? '' ) );
			if( $id === '' ) {
				$issues[] = 'content_plan_action_id_missing';
				continue;
			}
			$url = (string) ( $entry['url'] ?? '' );
			$actions[$id][] = array(
				'url' => rtrim( $url, '/' ) === '' ? '/' : rtrim( $url, '/' ) . '/',
				'kind' => sanitize_key( (string) ( $entry['planActionKind'] ?? '' ) ),
				'goalRef' => sanitize_key( (string) ( $entry['planGoalRef'] ?? '' ) ),
			);
		}
		$children = $node['nodes'] ?? array();
		if( ! is_array( $children ) ) {
			$issues[] = 'content_plan_tree_malformed';
			return;
		}
		foreach( $children as $child ) {
			if( is_array( $child ) ) {
				self::collect_tree_actions( $child, $actions, $issues );
			} else {
				$issues[] = 'content_plan_tree_malformed';
			}
		}
	}

	private static function sources( $raw, array $brief, array $site_pages ): ?array {
		if( ! is_array( $raw ) || array_diff( array_keys( $raw ), array( 'facts', 'routes', 'goals' ) ) !== array() ) {
			return null;
		}
		$routes = array_column( $site_pages, 'slug' );
		$allowed = array(
			'facts' => array( 'offer', 'facts' ),
			'routes' => $routes,
			'goals' => array( 'goal' ),
		);
		$result = array();
		foreach( $allowed as $type => $catalog ) {
			$refs = $raw[$type] ?? array();
			if( ! is_array( $refs ) || ! array_is_list( $refs ) ) {
				return null;
			}
			$normalized_refs = array();
			foreach( $refs as $ref ) {
				if( $type === 'goals' && is_string( $ref ) ) {
					$ref = self::goal_reference( $ref, $brief );
				}
				if( ! is_string( $ref ) || ! in_array( $ref, $catalog, true ) ) {
					return null;
				}
				if( $type !== 'routes' && $brief !== array() && trim( (string) ( $brief[$ref] ?? '' ) ) === '' ) {
					return null;
				}
				$normalized_refs[] = $ref;
			}
			$result[$type] = array_values( array_unique( $normalized_refs ) );
		}
		return $result;
	}
}
