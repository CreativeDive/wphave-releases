<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Canonicalize equivalent model syntax before the strict Free tree boundary.
 * It may restore plan-owned identifiers, but never invent content or links.
 */
final class WPHAVE_Website_Plan_Free_Tree_Normalizer {
	public static function normalize( $tree, array $content_plan = array() ) {
		if( ! is_array( $tree ) || ( $tree['kind'] ?? '' ) !== 'page' ) {
			return $tree;
		}

		$sections = $tree['nodes'] ?? null;
		if( is_array( $sections ) && $content_plan !== array() ) {
			$kept_sections = array_values( array_filter( (array) ( $content_plan['sections'] ?? array() ), static function( $section ) {
				return ( $section['decision'] ?? '' ) === 'keep';
			} ) );
			$kept_ids = array_values( array_map( static function( $section ) {
				return (string) ( $section['id'] ?? '' );
			}, $kept_sections ) );
			$all_missing = count( $sections ) === count( $kept_ids ) && $kept_ids !== array();
			foreach( $sections as $section ) {
				if( ! is_array( $section ) || ( $section['kind'] ?? '' ) !== 'section' || trim( (string) ( $section['id'] ?? '' ) ) !== '' ) {
					$all_missing = false;
					break;
				}
			}
			if( $all_missing ) {
				foreach( $sections as $index => &$section ) {
					$section['id'] = $kept_ids[$index];
				}
				unset( $section );
				$tree['nodes'] = $sections;
			}
			foreach( $tree['nodes'] as $index => &$section ) {
				if( ! is_array( $section ) || ( $section['id'] ?? '' ) !== ( $kept_sections[$index]['id'] ?? '' ) ) {
					continue;
				}
				$section = self::normalize_node( $section, array_column( $kept_sections[$index]['actions'] ?? array(), null, 'id' ) );
			}
			unset( $section );
			return $tree;
		}

		return self::normalize_node( $tree );
	}

	private static function normalize_node( array $node, array $planned_actions = array() ): array {
		if( ( $node['kind'] ?? '' ) === 'actions' && ! isset( $node['actions'] ) ) {
			$children = $node['nodes'] ?? null;
			if( is_array( $children ) && count( $children ) >= 1 && count( $children ) <= 3 ) {
				$buttons = array();
				foreach( $children as $child ) {
					if( ! is_array( $child ) || ( $child['kind'] ?? '' ) !== 'button' || ! is_string( $child['label'] ?? null ) || ! is_string( $child['url'] ?? null ) || trim( $child['label'] ) === '' ) {
						$buttons = array();
						break;
					}
					$buttons[] = array_diff_key( $child, array_flip( array( 'kind', 'nodes', 'style', 'layout' ) ) );
				}
				if( count( $buttons ) === count( $children ) ) {
					$node['actions'] = $buttons;
					$node['nodes'] = array();
				}
			}
		}
		if( ( $node['kind'] ?? '' ) === 'button' ) {
			$node = self::normalize_action_goal( $node, $planned_actions );
		}
		if( ( $node['kind'] ?? '' ) === 'actions' && is_array( $node['actions'] ?? null ) ) {
			foreach( $node['actions'] as $index => $action ) {
				if( is_array( $action ) ) {
					$node['actions'][$index] = self::normalize_action_goal( $action, $planned_actions );
				}
			}
		}

		if( is_array( $node['nodes'] ?? null ) ) {
			foreach( $node['nodes'] as $index => $child ) {
				if( is_array( $child ) ) {
					$node['nodes'][$index] = self::normalize_node( $child, $planned_actions );
				}
			}
		}

		return $node;
	}

	private static function normalize_action_goal( array $action, array $planned_actions ): array {
		$id = (string) ( $action['planActionId'] ?? '' );
		$planned = $planned_actions[$id] ?? null;
		if( ! is_array( $planned ) ) {
			return $action;
		}
		$expected_url = ( $planned['targetSlug'] ?? '' ) === 'home' ? '/' : '/' . ( $planned['targetSlug'] ?? '' ) . '/';
		if( ( $action['url'] ?? '' ) !== $expected_url || ( $action['planActionKind'] ?? '' ) !== ( $planned['kind'] ?? '' ) ) {
			return $action;
		}
		$action['planGoalRef'] = (string) ( $planned['goalRef'] ?? '' );
		return $action;
	}
}
