<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Scores the visible structure of a new Free page before it is saved.
 * This is a candidate selector, not a migration rule for existing plans.
 */
class WPHAVE_Website_Plan_Free_Design_Audit {

	public static function inspect( $tree ): array {
		$sections = is_array( $tree['nodes'] ?? null ) ? $tree['nodes'] : array();
		$minimum_sections = WPHAVE_AI_Block_Design_Compiler::pro_layout_enabled() ? 3 : 4;
		if( count( $sections ) < $minimum_sections ) {
			return array( 'score' => 100, 'feedback' => array() );
		}

		$score = 40;
		$feedback = array();
		$backgrounds = array();
		$widths = array();
		$layout_kinds = array();
		$section_signatures = array();
		$boxed_bands = 0;
		$uniform_card_grids = 0;
		foreach( $sections as $section ) {
			if( ! is_array( $section ) ) {
				continue;
			}
			$backgrounds[] = (string) ( $section['style']['background'] ?? 'transparent' );
			$widths[] = (string) ( $section['style']['width'] ?? 'default' );
			self::collect_layout_kinds( $section, $layout_kinds );
			if( self::is_boxed_band( $section ) ) {
				$boxed_bands++;
			}
			if( self::contains_uniform_card_grid( $section ) ) {
				$uniform_card_grids++;
			}
			$section_signatures[] = implode( '|', array(
				end( $backgrounds ),
				end( $widths ),
				self::first_layout_kind( $section ),
			) );
		}
		if( array_intersect( array( 'flex', 'grid', 'gridareas', 'asymmetric' ), $layout_kinds ) !== array() ) {
			$score += 20;
		} else {
			$feedback[] = 'The page is a stack of text bands. Introduce one meaningful spatial relationship.';
		}
		if( count( array_unique( $widths ) ) >= 2 ) {
			$score += 12;
		} else {
			$feedback[] = 'Vary the section widths to create focus and breathing room.';
		}
		if( count( array_unique( $backgrounds ) ) >= 2 ) {
			$score += 12;
		} else {
			$feedback[] = 'Use a deliberate background transition where the content changes role.';
		}
		$opening_padding = (string) ( $sections[0]['style']['padding'] ?? '' );
		if( in_array( $opening_padding, array( 'xl', '2xl', '3xl', '4xl', '5xl' ), true ) ) {
			$score += 16;
		} else {
			$feedback[] = 'Give the opening section more breathing room.';
		}
		$repeated_neighbors = 0;
		foreach( $section_signatures as $index => $signature ) {
			if( $index > 0 && $signature === $section_signatures[$index - 1] ) {
				$repeated_neighbors++;
			}
		}
		if( $repeated_neighbors > 0 ) {
			$score -= min( 20, $repeated_neighbors * 8 );
			$feedback[] = 'Adjacent sections repeat the same width, background and layout. Change their hierarchy or combine them.';
		}
		if( $boxed_bands >= 2 ) {
			$score -= min( 24, $boxed_bands * 8 );
			$feedback[] = 'Several sections are only boxed text. Use a clear editorial hierarchy instead of repeating the same surface treatment.';
		}
		if( $uniform_card_grids > 0 ) {
			$score -= min( 24, $uniform_card_grids * 24 );
			$feedback[] = 'A uniform text-card grid dominates the page. Use cards only when the brief supports distinct items; otherwise choose an editorial layout.';
		}

		return array( 'score' => max( 0, min( 100, $score ) ), 'feedback' => $feedback );
	}

	protected static function is_boxed_band( array $section ): bool {
		$children = $section['nodes'] ?? array();
		return count( $children ) === 1 && ( $children[0]['kind'] ?? '' ) === 'surface';
	}

	protected static function contains_uniform_card_grid( array $node ): bool {
		$children = $node['nodes'] ?? array();
		if( ( $node['kind'] ?? '' ) === 'grid' && count( $children ) >= 3 ) {
			$kinds = array_map( static function( $child ) {
				return is_array( $child ) ? ( $child['kind'] ?? '' ) : '';
			}, $children );
			if( count( array_unique( $kinds ) ) === 1 && $kinds[0] === 'surface' ) {
				return true;
			}
		}
		foreach( $children as $child ) {
			if( is_array( $child ) && self::contains_uniform_card_grid( $child ) ) {
				return true;
			}
		}
		return false;
	}

	protected static function first_layout_kind( array $node ): string {
		foreach( $node['nodes'] ?? array() as $child ) {
			if( ! is_array( $child ) ) {
				continue;
			}
			$kind = (string) ( $child['kind'] ?? '' );
			if( in_array( $kind, array( 'stack', 'flex', 'grid', 'gridareas', 'asymmetric' ), true ) ) {
				return $kind;
			}
		}
		return 'plain';
	}

	protected static function collect_layout_kinds( array $node, array &$kinds ): void {
		$kind = (string) ( $node['kind'] ?? '' );
		if( in_array( $kind, array( 'flex', 'grid', 'gridareas', 'asymmetric' ), true ) ) {
			$kinds[$kind] = $kind;
		}
		foreach( $node['nodes'] ?? array() as $child ) {
			if( is_array( $child ) ) {
				self::collect_layout_kinds( $child, $kinds );
			}
		}
	}
}
