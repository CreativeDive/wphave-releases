<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Website_Plan_AI_Template_Parts {

    /**
	 * Template parts from response.
	 *
	 * @param array $data Data.
	 * @return array Template parts from response.
	 */

	protected static function template_parts_from_response( array $data ): array {
		if( is_array( $data['templateParts'] ?? null ) ) {
			return $data['templateParts'];
		}

		if( is_array( $data['wireframes']['templateParts'] ?? null ) ) {
			return $data['wireframes']['templateParts'];
		}

		return array();
	}

    /**
	 * Render template parts.
	 *
	 * @param array $generated_parts Generated parts.
	 * @param array $sitemap Sitemap.
	 * @param array $brief Brief.
	 * @return array Render template parts.
	 */

	protected static function render_template_parts( array $generated_parts, array $sitemap, array $brief ): array {
		$sitemap_parts = self::sanitize_template_parts( $sitemap['templateParts'] ?? array(), $sitemap['pages'] ?? array(), $brief );

		return array(
			'header' => self::render_header_part( is_array( $generated_parts['header'] ?? null ) ? $generated_parts['header'] : array(), $sitemap_parts['header'], $sitemap['pages'] ?? array(), $brief ),
			'footer' => self::render_footer_part( is_array( $generated_parts['footer'] ?? null ) ? $generated_parts['footer'] : array(), $sitemap_parts['footer'], $sitemap['pages'] ?? array(), $brief ),
		);
	}

    /**
	 * Render header part.
	 *
	 * @param array $generated Generated.
	 * @param array $planned Planned.
	 * @param array $pages Pages.
	 * @param array $brief Brief.
	 * @return array Render header part.
	 */

	protected static function render_header_part( array $generated, array $planned, array $pages, array $brief ): array {
		$plan = is_array( $generated['plan'] ?? null ) ? $generated['plan'] : $generated;
		$title = sanitize_text_field( (string) ( $generated['title'] ?? $planned['title'] ?? 'Header' ) );
		$logo = trim( sanitize_text_field( (string) ( $plan['logo'] ?? $brief['projectName'] ?? $planned['title'] ?? 'Logo' ) ) );
		$navigation = self::navigation_items_from_plan( $plan['navigation'] ?? array(), $pages );
		$actions = self::action_items_from_plan( $plan['actions'] ?? array(), $brief );
		$nav_links = '';
		$button_links = '';

		foreach( $navigation as $item ) {
			$nav_links .= self::planner_block( 'paragraph', array(
				'wphave' => array(
					'text' => array(
						'typeface' => array( 'size' => array( 'type' => 'text-s' ) ),
						'colors' => array( 'text' => 'var(--wphave-site-color-text)' ),
					),
				),
				'content' => $item['label'],
			) );
		}

		foreach( $actions as $item ) {
			$button_links .= self::planner_block( 'button', array(
				'wphave' => array(
					'settings' => array( 'variant' => 'primary' ),
				),
				'content' => $item['label'],
				'link' => array(
					'url' => $item['url'],
				),
			) );
		}

		$content = self::planner_group(
			self::planner_block( 'paragraph', array(
				'wphave' => array(
					'text' => array(
						'typeface' => array( 'size' => array( 'type' => 'text-s' ) ),
						'colors' => array( 'text' => 'var(--wphave-site-color-heading)' ),
					),
				),
				'content' => $logo ?: $title,
			) ) .
			self::planner_group( $nav_links, array(
				'layout' => array(
					'type' => 'flex',
					'flex' => array(
						'gapX' => '16px',
						'gapY' => '8px',
						'flexWrap' => 'wrap',
						'flexDirection' => 'row',
						'flexItemSizing' => 'auto',
						'alignVertical' => 'center',
						'alignHorizontal' => 'center',
					),
				),
			) ) .
			self::planner_group( $button_links, array(
				'layout' => array(
					'type' => 'flex',
					'flex' => array(
						'gapX' => '8px',
						'gapY' => '8px',
						'flexWrap' => 'wrap',
						'flexDirection' => 'row',
						'flexItemSizing' => 'auto',
						'alignVertical' => 'center',
						'alignHorizontal' => 'end',
					),
				),
			) ),
			array(
				'features' => array( 'size' => 'full' ),
				'dimensions' => array( 'spacing' => array( 'padding' => '18px var(--wphave-site-spacing) 18px var(--wphave-site-spacing)' ) ),
				'layout' => array(
					'type' => 'flex',
					'flex' => array(
						'gapX' => '24px',
						'gapY' => '12px',
						'flexWrap' => 'wrap',
						'flexDirection' => 'row',
						'flexItemSizing' => 'auto',
						'alignVertical' => 'center',
						'alignHorizontal' => 'space-between',
					),
				),
			)
		);

			return array(
				'title' => $title ?: 'Header',
				'intent' => $planned['intent'] ?? '',
				'sections' => $planned['sections'] ?? array(),
				'source' => self::source( 'wireframe_template_part' ),
				'plan' => array(
					'logo' => $logo,
					'navigation' => $navigation,
				'actions' => $actions,
			),
			'content' => $content,
		);
	}

    /**
	 * Render footer part.
	 *
	 * @param array $generated Generated.
	 * @param array $planned Planned.
	 * @param array $pages Pages.
	 * @param array $brief Brief.
	 * @return array Render footer part.
	 */

	protected static function render_footer_part( array $generated, array $planned, array $pages, array $brief ): array {
		$plan = is_array( $generated['plan'] ?? null ) ? $generated['plan'] : $generated;
		$title = sanitize_text_field( (string) ( $generated['title'] ?? $planned['title'] ?? 'Footer' ) );
		$summary = trim( sanitize_textarea_field( (string) ( $plan['summary'] ?? $planned['intent'] ?? $brief['offer'] ?? '' ) ) );
		$columns = self::footer_columns_from_plan( $plan['columns'] ?? array(), $pages, $brief );
		$column_markup = '';

		foreach( $columns as $column ) {
			$item_markup = '';

			foreach( $column['items'] as $item ) {
				$item_markup .= '<!-- wp:list-item --><li><a href="' . esc_url( $item['url'] ) . '">' . esc_html( $item['label'] ) . '</a></li><!-- /wp:list-item -->';
			}

			$column_markup .= '<!-- wp:group {"layout":{"type":"constrained"}} --><div class="wp-block-group"><!-- wp:heading {"level":3} --><h3 class="wp-block-heading">' . esc_html( $column['title'] ) . '</h3><!-- /wp:heading --><!-- wp:list --> <ul>' . $item_markup . '</ul><!-- /wp:list --></div><!-- /wp:group -->';
		}

		$content = '<!-- wp:group {"tagName":"footer","align":"full","layout":{"type":"constrained"}} --><footer class="wp-block-group alignfull"><!-- wp:columns --><div class="wp-block-columns"><!-- wp:column {"width":"38%"} --><div class="wp-block-column" style="flex-basis:38%"><!-- wp:site-title {"level":0} /--><!-- wp:paragraph --><p>' . esc_html( $summary ?: 'Useful links and next steps for visitors.' ) . '</p><!-- /wp:paragraph --></div><!-- /wp:column --><!-- wp:column {"width":"62%"} --><div class="wp-block-column" style="flex-basis:62%"><!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"12rem"}} --><div class="wp-block-group">' . $column_markup . '</div><!-- /wp:group --></div><!-- /wp:column --></div><!-- /wp:columns --></footer><!-- /wp:group -->';

			return array(
				'title' => $title ?: 'Footer',
				'intent' => $planned['intent'] ?? '',
				'sections' => $planned['sections'] ?? array(),
				'source' => self::source( 'wireframe_template_part' ),
				'plan' => array(
					'summary' => $summary,
					'columns' => $columns,
			),
			'content' => $content,
		);
	}

    /**
	 * Sanitize template parts.
	 *
	 * @param mixed $parts Parts.
	 * @param array $pages Pages.
	 * @param array $brief Brief.
	 * @return array Sanitize template parts.
	 */

	protected static function sanitize_template_parts( $parts, array $pages, array $brief ): array {
		$parts = is_array( $parts ) ? $parts : array();
		$fallback = self::fallback_template_parts( $pages, $brief );

		return array(
			'header' => self::sanitize_template_part( $parts['header'] ?? array(), $fallback['header'], 'Header' ),
			'footer' => self::sanitize_template_part( $parts['footer'] ?? array(), $fallback['footer'], 'Footer' ),
		);
	}

    /**
	 * Sanitize template part.
	 *
	 * @param mixed $part Part.
	 * @param array $fallback Fallback.
	 * @param string $fallback_title Fallback title.
	 * @return array Sanitize template part.
	 */

	protected static function sanitize_template_part( $part, array $fallback, string $fallback_title ): array {
		$part = is_array( $part ) ? $part : array();

		return array(
			'title' => trim( mb_substr( sanitize_text_field( (string) ( $part['title'] ?? $fallback['title'] ?? $fallback_title ) ), 0, 100 ) ),
			'intent' => trim( mb_substr( sanitize_textarea_field( (string) ( $part['intent'] ?? $fallback['intent'] ?? '' ) ), 0, 320 ) ),
			'sections' => self::sanitize_sections( $part['sections'] ?? ( $fallback['sections'] ?? array() ) ),
		);
	}

    /**
	 * Fallback template parts.
	 *
	 * @param array $pages Pages.
	 * @param array $brief Brief.
	 * @return array Fallback template parts.
	 */

	protected static function fallback_template_parts( array $pages, array $brief ): array {
		$page_sections = array_values( array_filter( array_map( function( $page ) {
			return is_array( $page ) ? array(
				'label' => $page['title'] ?? '',
				'url' => '#' . ( $page['slug'] ?? sanitize_title( (string) ( $page['title'] ?? '' ) ) ),
			) : array();
		}, array_slice( $pages, 0, 5 ) ) ) );
		$page_labels = array_values( array_filter( array_map( function( $item ) {
			return $item['label'] ?? '';
		}, $page_sections ) ) );

		return array(
			'header' => array(
				'title' => 'Header',
				'intent' => 'Global website header with brand, primary navigation and one clear action.',
				'sections' => array(
					array(
						'title' => 'Brand',
						'description' => $brief['projectName'] ?: 'Show the website brand clearly.',
					),
					array(
						'title' => 'Primary navigation',
						'description' => $page_labels ? implode( ', ', $page_labels ) : 'Navigate to the most important pages.',
					),
					array(
						'title' => 'Primary action',
						'description' => $brief['goal'] ?: 'Guide visitors to the next step.',
					),
				),
			),
			'footer' => array(
				'title' => 'Footer',
				'intent' => 'Global website footer with secondary navigation, trust context and legal links.',
				'sections' => array(
					array(
						'title' => 'Footer summary',
						'description' => $brief['offer'] ?: 'Summarize what visitors can expect from the website.',
					),
					array(
						'title' => 'Footer navigation',
						'description' => $page_labels ? implode( ', ', $page_labels ) : 'Repeat important page links.',
					),
					array(
						'title' => 'Legal and contact',
						'description' => 'Include contact and legal links where they fit the website.',
					),
				),
			),
		);
	}

    /**
	 * Navigation items from plan.
	 *
	 * @param array $items Items.
	 * @param array $pages Pages.
	 * @return array Navigation items from plan.
	 */

	protected static function navigation_items_from_plan( $items, array $pages ): array {
		$normalized = array();
		$items = is_array( $items ) ? $items : array();

		foreach( $items as $item ) {
			if( ! is_array( $item ) ) {
				continue;
			}

			$label = trim( sanitize_text_field( (string) ( $item['label'] ?? $item['title'] ?? '' ) ) );

			if( $label === '' ) {
				continue;
			}

			$normalized[] = array(
				'label' => $label,
				'url' => self::link_url( $item['url'] ?? '', $label ),
			);

			if( count( $normalized ) >= 6 ) {
				break;
			}
		}

		if( $normalized ) {
			return $normalized;
		}

		foreach( array_slice( $pages, 0, 5 ) as $page ) {
			if( ! is_array( $page ) ) {
				continue;
			}

			$label = trim( sanitize_text_field( (string) ( $page['title'] ?? '' ) ) );

			if( $label === '' ) {
				continue;
			}

			$normalized[] = array(
				'label' => $label,
				'url' => '#' . self::slug( $page['slug'] ?? '', $label, count( $normalized ) ),
			);
		}

		return $normalized;
	}

    /**
	 * Action items from plan.
	 *
	 * @param array $items Items.
	 * @param array $brief Brief.
	 * @return array Action items from plan.
	 */

	protected static function action_items_from_plan( $items, array $brief ): array {
		$normalized = array();
		$items = is_array( $items ) ? $items : array();

		foreach( $items as $item ) {
			if( ! is_array( $item ) ) {
				continue;
			}

			$label = trim( sanitize_text_field( (string) ( $item['label'] ?? $item['title'] ?? '' ) ) );

			if( $label === '' ) {
				continue;
			}

			$normalized[] = array(
				'label' => $label,
				'url' => self::link_url( $item['url'] ?? '', $label ),
			);

			if( count( $normalized ) >= 2 ) {
				break;
			}
		}

		return $normalized ?: array(
			array(
				'label' => $brief['goal'] ? mb_substr( $brief['goal'], 0, 32 ) : 'Start now',
				'url' => '#contact',
			),
		);
	}

    /**
	 * Footer columns from plan.
	 *
	 * @param mixed $columns Columns.
	 * @param array $pages Pages.
	 * @param array $brief Brief.
	 * @return array Footer columns from plan.
	 */

	protected static function footer_columns_from_plan( $columns, array $pages, array $brief ): array {
		$normalized = array();
		$columns = is_array( $columns ) ? $columns : array();

		foreach( $columns as $column ) {
			if( ! is_array( $column ) ) {
				continue;
			}

			$title = trim( sanitize_text_field( (string) ( $column['title'] ?? '' ) ) );
			$items = self::navigation_items_from_plan( $column['items'] ?? array(), array() );

			if( $title === '' || empty( $items ) ) {
				continue;
			}

			$normalized[] = array(
				'title' => $title,
				'items' => array_slice( $items, 0, 5 ),
			);

			if( count( $normalized ) >= 3 ) {
				break;
			}
		}

		if( $normalized ) {
			return $normalized;
		}

		return array(
			array(
				'title' => 'Pages',
				'items' => self::navigation_items_from_plan( array(), $pages ),
			),
			array(
				'title' => 'Contact',
				'items' => array(
					array(
						'label' => $brief['goal'] ?: 'Get in touch',
						'url' => '#contact',
					),
					array(
						'label' => 'Privacy',
						'url' => '#privacy',
					),
				),
			),
		);
	}

    /**
	 * Link url.
	 *
	 * @param string $url Resource URL.
	 * @param string $label Label.
	 * @return string Link url.
	 */

	protected static function link_url( $url, string $label ): string {
		$url = trim( sanitize_text_field( (string) $url ) );

		if( $url === '' || $url === '#' ) {
			return '#' . sanitize_title( $label );
		}

		if( str_starts_with( $url, '#' ) || str_starts_with( $url, '/' ) || wp_http_validate_url( $url ) ) {
			return $url;
		}

		return '#' . sanitize_title( $url );
	}

}
