<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Bounded Free composition search over existing, verified content nodes.
 * It only rearranges flat sections. Complex authored sections are left intact.
 */
class WPHAVE_Website_Plan_Free_Composition_Resolver {
	private const MAX_CANDIDATES = 12;

	public static function resolve( array $tree ): array {
		if( ( $tree['kind'] ?? '' ) !== 'page' || ! is_array( $tree['nodes'] ?? null ) ) {
			return $tree;
		}

		$previous_signature = '';
		foreach( $tree['nodes'] as $index => $section ) {
			if( ! self::is_eligible( $section ) ) {
				$previous_signature = self::signature( $section );
				continue;
			}

			$ranked = self::ranked_candidates( $section, $index, $previous_signature );
			$best = $ranked[0]['tree'] ?? $section;
			$tree['nodes'][$index] = $best;
			$previous_signature = self::signature( $best );
		}

		return $tree;
	}

	/**
	 * Read-only comparison data. Callers render these trees through the normal
	 * compiler and materializer; this method never changes a saved plan.
	 */
	public static function inspect( array $tree ): array {
		$sections = is_array( $tree['nodes'] ?? null ) ? $tree['nodes'] : array();
		$result = array();
		$previous_signature = '';
		foreach( $sections as $index => $section ) {
			if( ! self::is_eligible( $section ) ) {
				$result[] = array( 'sectionIndex' => $index, 'eligible' => false, 'candidates' => array() );
				$previous_signature = self::signature( $section );
				continue;
			}
			$candidates = self::ranked_candidates( $section, $index, $previous_signature );
			$result[] = array(
				'sectionIndex' => $index,
				'eligible' => true,
				'original' => $section,
				'candidates' => $candidates,
				'winnerId' => $candidates[0]['id'] ?? null,
			);
			$previous_signature = self::signature( $candidates[0]['tree'] ?? $section );
		}
		return $result;
	}

	private static function ranked_candidates( array $section, int $index, string $previous_signature ): array {
		$ranked = array();
		foreach( self::candidates( $section ) as $candidate_index => $candidate ) {
			if( ! WPHAVE_AI_Block_Design_Compiler::validate_tree( array( 'kind' => 'page', 'nodes' => array( $candidate, $candidate ) ) ) ) {
				continue;
			}
			$ranked[] = array(
				'id' => 'candidate-' . $candidate_index,
				'signature' => self::signature( $candidate ),
				'score' => self::score( $candidate, $index, $previous_signature ),
				'tree' => $candidate,
			);
		}
		usort( $ranked, static function( $left, $right ) {
			return $right['score'] <=> $left['score'];
		} );
		return $ranked;
	}

	private static function is_eligible( $section ): bool {
		if( ! is_array( $section ) || ( $section['kind'] ?? '' ) !== 'section' ) {
			return false;
		}
		return self::simple_content_nodes( $section ) !== null;
	}

	private static function candidates( array $section ): array {
		$children = self::simple_content_nodes( $section );
		if( $children === null ) {
			return array( $section );
		}
		$candidates = array( $section );
		$candidates[] = self::with_nodes( $section, array( self::node( 'stack', $children, array( 'width' => 'narrow', 'gap' => 'm', 'align' => 'center' ) ) ) );
		$candidates[] = self::with_nodes( $section, array( self::node( 'surface', $children, array( 'background' => 'paper', 'padding' => 'l', 'width' => 'wide' ) ) ) );

		if( count( $children ) >= 3 && ( $children[0]['kind'] ?? '' ) === 'heading' ) {
			$rest = array_slice( $children, 1 );
			$candidates[] = self::with_nodes( $section, array( self::node( 'asymmetric', array( $children[0], self::node( 'stack', $rest, array( 'gap' => 'm' ) ) ), array( 'gap' => 'l' ), array( 'balance' => 'wide-start' ) ) ) );
			$candidates[] = self::with_nodes( $section, array( self::node( 'asymmetric', array( $children[0], self::node( 'stack', $rest, array( 'gap' => 'm' ) ) ), array( 'gap' => 'l' ), array( 'balance' => 'wide-end' ) ) ) );
			$candidates[] = self::with_nodes( $section, array( self::node( 'stack', array( self::node( 'surface', array( $children[0], $children[1] ), array( 'background' => 'paper', 'padding' => 'l' ) ), self::node( 'stack', array_slice( $children, 2 ), array( 'gap' => 's', 'align' => 'end' ) ) ), array( 'gap' => 'm' ) ) ) );
		}

		return array_slice( $candidates, 0, self::MAX_CANDIDATES );
	}

	/** A simple wrapper is safe to recompose; authored grids and surfaces are not. */
	private static function simple_content_nodes( array $section ): ?array {
		$children = $section['nodes'] ?? null;
		if( ! is_array( $children ) ) {
			return null;
		}
		if( count( $children ) === 1 && ( $children[0]['kind'] ?? '' ) === 'stack' ) {
			$wrapper = $children[0];
			$style = is_array( $wrapper['style'] ?? null ) ? $wrapper['style'] : array();
			if( ! empty( $wrapper['layout'] ) || array_diff( array_keys( $style ), array( 'gap', 'width', 'align' ) ) ) {
				return null;
			}
			$children = $wrapper['nodes'] ?? null;
		}
		if( ! is_array( $children ) || count( $children ) < 2 || count( $children ) > 6 ) {
			return null;
		}
		foreach( $children as $child ) {
			if( ! is_array( $child ) || ! in_array( $child['kind'] ?? '', array( 'heading', 'paragraph', 'button', 'actions' ), true ) ) {
				return null;
			}
		}
		return $children;
	}

	private static function node( string $kind, array $children, array $style = array(), array $layout = array() ): array {
		return array( 'kind' => $kind, 'nodes' => $children, 'style' => $style, 'layout' => $layout );
	}

	private static function with_nodes( array $section, array $nodes ): array {
		$section['nodes'] = $nodes;
		return $section;
	}

	private static function score( array $section, int $index, string $previous_signature ): int {
		$signature = self::signature( $section );
		$score = $signature === $previous_signature ? -20 : 10;
		$score += $index === 0 && str_contains( $signature, 'stack' ) ? 5 : 0;
		$score += $index > 0 && str_contains( $signature, 'asymmetric' ) ? 5 : 0;
		$score -= substr_count( $signature, 'surface' ) * 4;
		return $score;
	}

	private static function signature( $section ): string {
		$nodes = is_array( $section['nodes'] ?? null ) ? $section['nodes'] : array();
		return implode( '-', array_map( static function( $node ) {
			return is_array( $node ) ? (string) ( $node['kind'] ?? '' ) : '';
		}, $nodes ) );
	}
}
