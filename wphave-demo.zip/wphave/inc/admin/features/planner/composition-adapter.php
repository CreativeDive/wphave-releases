<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Converts Website Plans into Site Composition DTOs.
 *
 * Site Compositions stays the preview/apply surface. Website Plans are the
 * canonical source and may contain multiple pages.
 */

class WPHAVE_Website_Plan_Composition_Adapter {

	/**
	 * From plan.
	 *
	 * @param array $plan Plan.
	 */

	public static function from_plan( array $plan ) {
		$payload = is_array( $plan['payload'] ?? null ) ? $plan['payload'] : array();
		$wireframes = is_array( $payload['wireframes'] ?? null ) ? $payload['wireframes'] : array();
		$sitemap = is_array( $payload['sitemap'] ?? null ) ? $payload['sitemap'] : array();
		$pages = WPHAVE_Website_Plan_Schema::pages( $wireframes['pages'] ?? array(), $sitemap['pages'] ?? array() );
		$expected_pages = is_array( $sitemap['pages'] ?? null ) ? $sitemap['pages'] : array();
		$page_media = is_array( $payload['generation']['pageMediaBySlug'] ?? null ) ? $payload['generation']['pageMediaBySlug'] : array();
		if( in_array( ( $payload['generation']['compositionMode'] ?? '' ), array( 'free', 'pattern-workspace' ), true ) ) {
			if( ! empty( $payload['generation']['stalePageSlugs'] ) ) {
				return null;
			}
			if( ! class_exists( 'WPHAVE_AI_Block_Design_Compiler', false ) && class_exists( 'WPHAVE_Site_Composition_Builder', false ) ) {
				require_once wphave_dir() . 'inc/admin/features/ai/layout/block-design-compiler.php';
			}
			if( count( $pages ) !== count( $expected_pages ) || ! class_exists( 'WPHAVE_AI_Block_Design_Compiler', false ) ) {
				return null;
			}
			foreach( $pages as $index => $page ) {
				$expected_slug = sanitize_title( (string) ( $expected_pages[$index]['slug'] ?? '' ) );
				if( ( $page['slug'] ?? '' ) !== $expected_slug ) {
					return null;
				}
				if( isset( $page['plan']['patternComposition'] ) ) {
					$approved_slugs = (array) ( $payload['generation']['readyPageSlugs'] ?? array() );
					if( ! in_array( $page['slug'], $approved_slugs, true ) || empty( $page['content'] ) ) {
						return null;
					}
					continue;
				}
				$page_brief = WPHAVE_Website_Plan_Page_Evidence::for_page(
					is_array( $payload['brief'] ?? null ) ? $payload['brief'] : array(),
					$page['slug'],
					$expected_pages
				);
				$page_brief['boundMediaId'] = (int) ( $page_media[$page['slug']] ?? 0 );
				$issues = WPHAVE_AI_Block_Design_Compiler::quality_issues(
					$page['plan']['blockTree'] ?? null,
					$expected_pages,
					$page_brief
				);
				if( $issues !== array() ) {
					return null;
				}
			}
		}
		foreach( $pages as &$page ) {
			if( isset( $page['plan']['patternComposition'] ) ) {
				continue;
			}
			if( ! array_key_exists( $page['slug'], $page_media ) ) {
				continue;
			}
			$raw_media_id = $page_media[$page['slug']];
			if( ! is_numeric( $raw_media_id ) || (string) (int) $raw_media_id !== (string) $raw_media_id || (int) $raw_media_id <= 0 ) {
				return null;
			}
			$media_id = (int) $raw_media_id;
			if( ! wp_attachment_is_image( $media_id ) || ! current_user_can( 'read_post', $media_id ) ) {
				return null;
			}
			$bound_media = (int) ( $page['plan']['mediaComposition']['attachmentId'] ?? 0 );
			if( $bound_media > 0 ) {
				if( $bound_media !== $media_id ) {
					return null;
				}
				continue;
			}
			$page['content'] = self::with_media_content(
				(string) $page['content'],
				$media_id,
				(string) ( $page['plan']['contentPlan']['heroMediaPlacement'] ?? 'after-content' )
			);
		}
		unset( $page );

		if( empty( $pages ) ) {
			return null;
		}

		$template_parts = WPHAVE_Website_Plan_Schema::template_parts( $wireframes['templateParts'] ?? ( $sitemap['templateParts'] ?? array() ) );
		$site_globals = is_array( $payload['style'] ?? null ) ? $payload['style'] : array();
		$fonts = is_array( $payload['fonts'] ?? null ) && ! empty( $payload['fonts'] )
			? $payload['fonts']
			: WPHAVE_Site_Composition_Preview::typography_google_fonts( $site_globals['typography'] ?? array() );
		$title = sanitize_text_field( (string) ( $plan['title'] ?? $payload['brief']['projectName'] ?? __( 'Website Plan', 'wphave' ) ) );
		$id = self::composition_id( $plan );
		$homepage = $pages[0];
		$composition = array(
			'id' => $id,
			'source' => 'website-plan',
			'planId' => $plan['id'] ?? null,
			'title' => $title,
			'description' => sanitize_textarea_field( (string) ( $sitemap['summary'] ?? $payload['brief']['goal'] ?? '' ) ),
			'category' => __( 'Website Plan', 'wphave' ),
			'tags' => array( 'website-plan' ),
			'fonts' => $fonts,
			'siteGlobals' => $site_globals,
			'templateParts' => $template_parts,
			'content' => array(
				'title' => $homepage['title'],
				'content' => $homepage['content'],
				'slug' => $homepage['slug'],
			),
			'pages' => $pages,
			'preview' => array(
				'content' => (string) ( $template_parts['header']['content'] ?? '' ) . (string) ( $homepage['content'] ?? '' ) . (string) ( $template_parts['footer']['content'] ?? '' ),
			),
		);

		$composition['preview'] = WPHAVE_Site_Composition_Preview::prepare( $composition, $site_globals, $fonts );

		return $composition;
	}

	/**
	 * Place one selected image before or after the first section's text cluster.
	 */
	public static function with_media_content( string $content, int $media_id, string $placement = 'after-content' ): string {
		$image_block = '<!-- wp:wphave/image ' . wphave_encode_block_attributes_canonical( array(
			'image' => $media_id,
			'wphave' => array(
				'dimensions' => array( 'aspectRatio' => array( 'ratio' => '16/9' ) ),
				'classNames' => 'asrt',
				'styles' => '--asrt: 16/9',
			),
		), JSON_UNESCAPED_UNICODE ) . ' /-->';
		$first_group = strpos( $content, '<!-- wp:wphave/group ' );
		$inner_group = $first_group === false ? false : strpos( $content, '<!-- wp:wphave/group ', $first_group + 1 );
		$insertion_point = false;
		if( $inner_group !== false && preg_match_all( '/<!-- \/?wp:wphave\/group(?:\s[^>]*?)? -->/', $content, $tokens, PREG_OFFSET_CAPTURE, $inner_group ) ) {
			$depth = 0;
			foreach( $tokens[0] as $token ) {
				$depth += str_starts_with( $token[0], '<!-- /' ) ? -1 : 1;
				if( $depth === 0 ) {
					$insertion_point = $token[1];
					break;
				}
			}
		}
		if( $placement === 'before-content' && $inner_group !== false && $insertion_point !== false ) {
			$insertion_point = $inner_group;
		}
		return $insertion_point === false
			? $content . "\n\n" . $image_block
			: substr( $content, 0, $insertion_point ) . "\n" . $image_block . "\n" . substr( $content, $insertion_point );
	}

	/**
	 * Composition ID.
	 *
	 * @param array $plan Plan.
	 * @return string Composition ID.
	 */

	protected static function composition_id( array $plan ): string {
		return 'plan-' . absint( $plan['id'] ?? 0 );
	}

}
