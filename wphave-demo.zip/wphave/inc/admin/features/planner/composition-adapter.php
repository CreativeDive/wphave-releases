<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Converts Website Plans into Site Composition DTOs.
 *
 * Site Compositions stays the preview/apply surface. Website Plans are the
 * canonical source and may contain multiple pages.
 */

class WPHAVE_Website_Plan_Composition_Adapter {

	/**
	 * From plan.
	 *
	 * @param array $plan Plan.
	 */

	public static function from_plan( array $plan ) {
		$payload = is_array( $plan['payload'] ?? null ) ? $plan['payload'] : array();
		$wireframes = is_array( $payload['wireframes'] ?? null ) ? $payload['wireframes'] : array();
		$sitemap = is_array( $payload['sitemap'] ?? null ) ? $payload['sitemap'] : array();
		$pages = WPHAVE_Website_Plan_Schema::pages( $wireframes['pages'] ?? array(), $sitemap['pages'] ?? array() );

		if( empty( $pages ) ) {
			return null;
		}

		$template_parts = WPHAVE_Website_Plan_Schema::template_parts( $wireframes['templateParts'] ?? ( $sitemap['templateParts'] ?? array() ) );
		$site_globals = is_array( $payload['style'] ?? null ) ? $payload['style'] : array();
		$fonts = is_array( $payload['fonts'] ?? null ) && ! empty( $payload['fonts'] )
			? $payload['fonts']
			: WPHAVE_Site_Composition_Preview::typography_google_fonts( $site_globals['typography'] ?? array() );
		$title = sanitize_text_field( (string) ( $plan['title'] ?? $payload['brief']['projectName'] ?? __( 'Website Plan', 'wphave' ) ) );
		$id = self::composition_id( $plan );
		$homepage = $pages[0];
		$composition = array(
			'id' => $id,
			'source' => ! empty( $plan['isBuiltin'] ) ? 'builtin-plan' : 'website-plan',
			'planId' => $plan['id'] ?? null,
			'title' => $title,
			'description' => sanitize_textarea_field( (string) ( $sitemap['summary'] ?? $payload['brief']['goal'] ?? '' ) ),
			'category' => ! empty( $plan['isBuiltin'] ) ? __( 'Built-in Plan', 'wphave' ) : __( 'Website Plan', 'wphave' ),
			'tags' => array_filter( array( ! empty( $plan['isBuiltin'] ) ? 'builtin' : 'website-plan' ) ),
			'fonts' => $fonts,
			'siteGlobals' => $site_globals,
			'templateParts' => $template_parts,
			'content' => array(
				'title' => $homepage['title'],
				'content' => $homepage['content'],
				'slug' => $homepage['slug'],
			),
			'pages' => $pages,
			'preview' => array(
				'content' => (string) ( $template_parts['header']['content'] ?? '' ) . (string) ( $homepage['content'] ?? '' ) . (string) ( $template_parts['footer']['content'] ?? '' ),
			),
		);

		$composition['preview'] = WPHAVE_Site_Composition_Preview::prepare( $composition, $site_globals, $fonts );

		return $composition;
	}

	/**
	 * Composition ID.
	 *
	 * @param array $plan Plan.
	 * @return string Composition ID.
	 */

	protected static function composition_id( array $plan ): string {
		$id = (string) ( $plan['id'] ?? '' );

		if( ! empty( $plan['isBuiltin'] ) ) {
			return sanitize_key( $id );
		}

		return 'plan-' . absint( $id );
	}

}
