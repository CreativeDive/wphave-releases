<?php

if( ! defined('ABSPATH') ) {
	exit;
}

/**
 * Manage the ai app action notes create feature.
 */

class WPHAVE_AI_App_Action_Notes_Create {

	/**
	 * Return the action contract used by the app-action planner and client preview.
	 */

	public static function contract(): array {
		return array(
			'id' => 'notes.create',
			'contexts' => array( 'app' ),
			'capability' => 'wphave_manage_notes',
			'label' => __( 'Create note', 'wphave' ),
			'description' => __( 'Create an internal website note and open it in the Notes screen.', 'wphave' ),
			'confirmLabel' => __( 'Create note', 'wphave' ),
			'requiresConfirmation' => true,
			'intentExamples' => array(
				'Create a note about pruning roses',
				'Erstelle eine Notiz zu Launch-Ideen',
				'Merke mir die wichtigsten Schritte zur Bildoptimierung',
			),
			'schema' => array(
				'title' => array(
					'type' => 'string',
					'label' => __( 'Title', 'wphave' ),
					'required' => true,
					'maxLength' => 90,
				),
				'content' => array(
					'type' => 'markdown',
					'label' => __( 'Content', 'wphave' ),
					'required' => true,
					'maxLength' => 5000,
				),
			),
			'draftInstruction' => 'Create a helpful, self-contained note. If the user only gives a topic or question, write concise useful note content with practical details. Do not return placeholders such as "Topic:" or repeat the prompt as content. Preserve exact user-provided note content when they clearly provide it.',
		);
	}

}
