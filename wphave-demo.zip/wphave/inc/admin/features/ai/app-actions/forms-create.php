<?php

if( ! defined('ABSPATH') ) {
	exit;
}

/**
 * Manage the ai app action forms create feature.
 */

class WPHAVE_AI_App_Action_Forms_Create {

	/**
	 * Return the action contract used by the app-action planner and client preview.
	 */

	public static function contract(): array {
		return array(
			'id' => 'forms.create',
			'contexts' => array( 'app' ),
			'capability' => 'edit_posts',
			'label' => __( 'Create form', 'wphave' ),
			'description' => __( 'Create a global form draft and open it in the Forms screen.', 'wphave' ),
			'confirmLabel' => __( 'Create form', 'wphave' ),
			'requiresConfirmation' => true,
			'intentExamples' => array(
				'Create a contact form with name, email, message and privacy checkbox',
				'Erstelle ein Bewerbungsformular mit Name, E-Mail, Telefonnummer und Nachricht',
				'Create a newsletter signup form with email and consent',
			),
			'schema' => array(
				'title' => array(
					'type' => 'string',
					'label' => __( 'Title', 'wphave' ),
					'required' => true,
					'maxLength' => 120,
				),
				'fields' => array(
					'type' => 'formFields',
					'label' => __( 'Fields', 'wphave' ),
					'required' => true,
					'maxItems' => 20,
				),
				'submitLabel' => array(
					'type' => 'string',
					'label' => __( 'Submit button', 'wphave' ),
					'required' => true,
					'maxLength' => 80,
				),
				'successMessage' => array(
					'type' => 'string',
					'label' => __( 'Success message', 'wphave' ),
					'required' => false,
					'maxLength' => 240,
				),
			),
			'draftInstruction' => 'Create a safe form DSL only. Supported field types are text, email, tel, url, number, textarea, select, radio, checkbox, checkbox_group. Every field must include type, name, label, required, placeholder when useful, help when useful, and options only for select/radio/checkbox_group. Use lowercase snake_case names. Always include an email field for contact, application, quote, or lead forms unless the user explicitly says not to. Add a required privacy/consent checkbox for contact, newsletter, lead, application, or upload forms when appropriate. Do not create block JSON, HTML, CSS, JavaScript, PHP, recipients, legal guarantees, or integrations.',
		);
	}

	/**
	 * Sanitize planner generated form fields into the limited DSL the client can turn into form blocks.
	 */

	public static function sanitize_fields( $fields, int $limit = 20 ): array {
		if( ! is_array( $fields ) ) {
			return array();
		}

		$supported_types = array( 'text', 'email', 'tel', 'url', 'number', 'textarea', 'select', 'radio', 'checkbox', 'checkbox_group' );
		$clean = array();

		foreach( array_slice( $fields, 0, max( 1, $limit ) ) as $field ) {
			if( ! is_array( $field ) ) {
				continue;
			}

			$type = sanitize_key( $field['type'] ?? 'text' );
			if( ! in_array( $type, $supported_types, true ) ) {
				$type = 'text';
			}

			$label = trim( mb_substr( sanitize_text_field( (string) ( $field['label'] ?? '' ) ), 0, 120 ) );
			if( $label === '' ) {
				continue;
			}

			$name = sanitize_key( $field['name'] ?? sanitize_title( $label ) );
			$name = preg_replace( '/[^a-z0-9_]/', '_', strtolower( $name ) );
			$name = trim( preg_replace( '/_+/', '_', $name ), '_' );

			$item = array(
				'type' => $type,
				'name' => $name ?: sanitize_key( sanitize_title( $label ) ),
				'label' => $label,
				'required' => ! empty( $field['required'] ),
				'placeholder' => trim( mb_substr( sanitize_text_field( (string) ( $field['placeholder'] ?? '' ) ), 0, 160 ) ),
				'help' => trim( mb_substr( sanitize_text_field( (string) ( $field['help'] ?? '' ) ), 0, 220 ) ),
			);

			if( in_array( $type, array( 'select', 'radio', 'checkbox_group' ), true ) ) {
				$item['options'] = self::sanitize_options( $field['options'] ?? array() );
			}

			$clean[] = $item;
		}

		return $clean;
	}

	/**
	 * Sanitize option labels and values for choice-based form fields.
	 */

	protected static function sanitize_options( $options ): array {
		if( ! is_array( $options ) ) {
			return array();
		}

		$clean = array();

		foreach( array_slice( $options, 0, 20 ) as $option ) {
			$label = is_array( $option ) ? (string) ( $option['label'] ?? '' ) : (string) $option;
			$label = trim( mb_substr( sanitize_text_field( $label ), 0, 100 ) );

			if( $label === '' ) {
				continue;
			}

			$value = is_array( $option ) ? (string) ( $option['value'] ?? '' ) : '';
			$value = sanitize_key( $value ?: sanitize_title( $label ) );

			$clean[] = array(
				'label' => $label,
				'value' => $value,
			);
		}

		return $clean;
	}

}
