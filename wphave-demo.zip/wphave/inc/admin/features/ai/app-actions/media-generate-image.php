<?php

if( ! defined('ABSPATH') ) {
	exit;
}

/**
 * Manage the ai app action media generate image feature.
 */

class WPHAVE_AI_App_Action_Media_Generate_Image {

	/**
	 * Return the action contract used by the app-action planner and client preview.
	 */

	public static function contract(): array {
		return array(
			'id' => 'media.generate_image',
			'contexts' => array( 'app', 'editor' ),
			'capability' => 'upload_files',
			'label' => __( 'Create media image', 'wphave' ),
			'description' => __( 'Generate an image, upload it to the media library, and open the Media screen.', 'wphave' ),
			'confirmLabel' => __( 'Create image', 'wphave' ),
			'requiresConfirmation' => true,
			'intentExamples' => array(
				'Create a photo for the media library showing a modern office desk',
				'Erstelle ein Bild für die Mediathek mit einem grünen SaaS Dashboard',
				'Generate a square hero illustration for a newsletter signup',
			),
			'schema' => array(
				'prompt' => array(
					'type' => 'string',
					'label' => __( 'Image prompt', 'wphave' ),
					'required' => true,
					'maxLength' => 3000,
				),
				'title' => array(
					'type' => 'string',
					'label' => __( 'Media title', 'wphave' ),
					'required' => true,
					'maxLength' => 120,
				),
				'alt' => array(
					'type' => 'string',
					'label' => __( 'Alt text', 'wphave' ),
					'required' => true,
					'maxLength' => 220,
				),
				'filename' => array(
					'type' => 'filename',
					'label' => __( 'Filename', 'wphave' ),
					'required' => true,
					'maxLength' => 90,
				),
				'size' => array(
					'type' => 'imageSize',
					'label' => __( 'Image size', 'wphave' ),
					'required' => false,
					'maxLength' => 20,
				),
				'style' => array(
					'type' => 'string',
					'label' => __( 'Image style', 'wphave' ),
					'required' => false,
					'maxLength' => 80,
				),
			),
			'draftInstruction' => 'Create one production-ready image request for the WordPress media library. The prompt must be specific, visual, and directly usable by an image model. Include subject, composition, lighting, style, and avoid text inside the image unless explicitly requested. Create a concise human media title, descriptive accessibility-focused alt text, and one lowercase SEO-friendly filename without file extension. Allowed size values are square, landscape, portrait, or empty when the user does not specify an aspect ratio. Do not mention upload mechanics, APIs, provider names, or unsupported edits.',
		);
	}

}
