<?php

if( ! defined('ABSPATH') ) {
	exit;
}

/**
 * Manage the ai app action CSS classes create feature.
 */

class WPHAVE_AI_App_Action_CSS_Classes_Create {

	/**
	 * Return the action contract used by the app-action planner and client preview.
	 */

	public static function contract(): array {
		return array(
			'id' => 'css_classes.create',
			'contexts' => array( 'app' ),
			'capability' => 'wphave_manage_css_classes',
			'label' => __( 'Create global CSS class', 'wphave' ),
			'description' => __( 'Create a reusable global CSS class and open it in the CSS Classes screen.', 'wphave' ),
			'confirmLabel' => __( 'Create CSS class', 'wphave' ),
			'requiresConfirmation' => true,
			'intentExamples' => array(
				'Create a global CSS class that adds a thick red border',
				'Erstelle eine CSS Klasse für einen weichen Schatten',
				'Make a reusable class for cards with rounded corners and hover lift',
			),
			'schema' => array(
				'suffix' => array(
					'type' => 'className',
					'label' => __( 'Class suffix', 'wphave' ),
					'required' => true,
					'maxLength' => 80,
				),
				'css' => array(
					'type' => 'css',
					'label' => __( 'CSS rules', 'wphave' ),
					'required' => true,
					'maxLength' => 5000,
				),
			),
			'draftInstruction' => 'Create one reusable CSS class. Return a short lowercase kebab-case suffix without dot and without the wph-css- prefix. Return safe CSS source only. The CSS must use the $class placeholder as root selector. Use this structure: "$class {\n  ...\n}". For hover states use "$class:hover {\n  ...\n}". For active variants use "$class.is-active {\n  ...\n}". For child selectors use "$class .child {\n  ...\n}" or "$class > .child {\n  ...\n}". For responsive rules use "@media (max-width: 780px) {\n  $class {\n    ...\n  }\n}". Do not include <style>, @import, javascript URLs, broad global selectors, explanations, or markdown inside css.',
		);
	}

}
