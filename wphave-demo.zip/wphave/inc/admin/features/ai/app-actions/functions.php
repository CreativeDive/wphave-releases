<?php

if( ! defined('ABSPATH') ) {
	exit;
}

include_once __DIR__ . '/notes-create.php';
include_once __DIR__ . '/css-classes-create.php';
include_once __DIR__ . '/forms-create.php';
include_once __DIR__ . '/media-generate-image.php';
include_once __DIR__ . '/media-generate-image-set.php';
