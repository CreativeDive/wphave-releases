<?php

if( ! defined('ABSPATH') ) {
	exit;
}

/**
 * Manage the ai app action media generate image set feature.
 */

class WPHAVE_AI_App_Action_Media_Generate_Image_Set {

	/**
	 * Return the action contract used by the app-action planner and client preview.
	 */

	public static function contract(): array {
		return array(
			'id' => 'media.generate_image_set',
			'contexts' => array( 'app' ),
			'capability' => 'upload_files',
			'label' => __( 'Create image set', 'wphave' ),
			'description' => __( 'Generate several similar images with one cohesive visual direction.', 'wphave' ),
			'confirmLabel' => __( 'Create image set', 'wphave' ),
			'requiresConfirmation' => true,
			'intentExamples' => array(
				'Create four similar product images for a modern chair collection',
				'Erstelle ein Set aus vier ähnlichen Bildern für eine Wellness Landingpage',
				'Generate a cohesive image series for a restaurant campaign',
			),
			'schema' => array(
				'prompt' => array(
					'type' => 'string',
					'label' => __( 'Image set prompt', 'wphave' ),
					'required' => true,
					'maxLength' => 3000,
				),
				'title' => array(
					'type' => 'string',
					'label' => __( 'Set title', 'wphave' ),
					'required' => true,
					'maxLength' => 120,
				),
				'alt' => array(
					'type' => 'string',
					'label' => __( 'Alt text base', 'wphave' ),
					'required' => true,
					'maxLength' => 220,
				),
				'filename' => array(
					'type' => 'filename',
					'label' => __( 'Filename base', 'wphave' ),
					'required' => true,
					'maxLength' => 90,
				),
				'count' => array(
					'type' => 'number',
					'label' => __( 'Image count', 'wphave' ),
					'required' => false,
					'maxLength' => 1,
				),
				'size' => array(
					'type' => 'imageSize',
					'label' => __( 'Image size', 'wphave' ),
					'required' => false,
					'maxLength' => 20,
				),
				'style' => array(
					'type' => 'string',
					'label' => __( 'Shared style', 'wphave' ),
					'required' => false,
					'maxLength' => 160,
				),
			),
			'draftInstruction' => 'Create one production-ready request for a cohesive image set. The prompt must describe subject, shared mood, lighting, composition language, color direction and image usage. The images should feel like one campaign or content series, not unrelated images. Return a count between 2 and 4, default 4 when unclear. Include a concise set title, accessibility-focused alt text base, lowercase SEO-friendly filename base without file extension, optional shared style, and size square, landscape, portrait, or empty. Avoid text inside images unless explicitly requested. Do not mention upload mechanics, APIs, provider names, or unsupported edits.',
		);
	}

}
