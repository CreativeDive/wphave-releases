<?php

if( ! defined('ABSPATH') ) {
	exit;
}

/**
 * Manage the ai provider router feature.
 */

class WPHAVE_AI_Provider_Router {

	/**
	 * Send a text/chat-style request to the selected provider and return a normalized provider response.
	 * The response includes the generated result plus internal provider metadata for diagnostics.
	 */

	public static function generate_text( array $messages, array $options = array(), array $capabilities = array( 'text' ) ) {
		if( ( $options['responseFormat'] ?? '' ) === 'json_schema' ) {
			return WPHAVE_AI_Provider_OpenAI::instance()->generate_text( $messages, $options );
		}

		if( in_array( 'vision', $capabilities, true ) ) {
			return WPHAVE_AI_Provider_OpenAI::instance()->generate_text( $messages, $options );
		}

		$wp_provider = WPHAVE_AI_Provider_WordPress::instance();

		if( $wp_provider->is_available() ) {
			$response = $wp_provider->generate_text( $messages, $options );
			if( ! is_wp_error( $response ) && ! empty( $response['result'] ) ) {
				return $response;
			}
		}

		return WPHAVE_AI_Provider_OpenAI::instance()->generate_text( $messages, $options );
	}

}
