<?php

if( ! defined('ABSPATH') ) {
	exit;
}

require_once wphave_dir() . 'inc/features/security/boundaries/index.php';
require_once wphave_dir() . 'inc/admin/features/ai/transport/schema.php';

/**
 * Manage the ai provider openai feature.
 */

class WPHAVE_AI_Provider_OpenAI {
	private const MAX_JSON_RESPONSE_BYTES = 67108864;
	private const MAX_AUDIO_RESPONSE_BYTES = 33554432;
	private const MAX_STREAM_BUFFER_BYTES = 1048576;
	private const MAX_INPUT_IMAGE_BYTES = WPHAVE_AI_Schema::MAX_IMAGE_BINARY_BYTES;
	private const MAX_INPUT_IMAGE_BASE64_BYTES = WPHAVE_AI_Schema::MAX_IMAGE_BASE64_BYTES;

	protected static $instance = null;

	/**
	 * Return the singleton instance for this AI service.
	 * Keeps route callbacks and provider calls using a shared stateless service instance.
	 */

	public static function instance(): self {
		if( ! self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Report whether this provider can currently be used.
	 * Availability is based on the provider-specific runtime requirements.
	 */

	public function is_available(): bool {
		return WPHAVE_AI_Config::openai_api_key() !== '';
	}

	/**
	 * Send a text/chat-style request to the selected provider and return a normalized provider response.
	 * The response includes the generated result plus internal provider metadata for diagnostics.
	 */

	public function generate_text( array $messages, array $options = array() ) {
		$key = WPHAVE_AI_Config::openai_api_key();
		$started = microtime( true );

		if( ! $key ) {
			return new WP_Error( 'ai_no_key', __( 'OpenAI API key missing', 'wphave' ), array( 'status' => 400 ) );
		}

		$model = WPHAVE_AI_Config::model();
		$body = array(
			'model' => $model,
			'max_completion_tokens' => WPHAVE_AI_Config::max_tokens( $options ),
			'messages' => $messages,
		);

		if( ( $options['responseFormat'] ?? '' ) === 'json_schema' && ! empty( $options['jsonSchema'] ) && is_array( $options['jsonSchema'] ) ) {
			$body['response_format'] = array(
				'type' => 'json_schema',
				'json_schema' => array(
					'name' => sanitize_key( $options['jsonSchemaName'] ?? 'wphave_ai_response' ),
					'strict' => ! empty( $options['jsonSchemaStrict'] ),
					'schema' => $options['jsonSchema'],
				),
			);
		} elseif( ( $options['responseFormat'] ?? '' ) === 'json_object' ) {
			$body['response_format'] = array(
				'type' => 'json_object',
			);
		}

		$response = wp_remote_post( 'https://api.openai.com/v1/chat/completions', array(
			'headers' => array(
				'Authorization' => 'Bearer ' . $key,
				'Content-Type' => 'application/json',
			),
			'body' => wp_json_encode( $body ),
			'timeout' => 120,
			'redirection' => 0,
			'sslverify' => true,
			'limit_response_size' => self::MAX_JSON_RESPONSE_BYTES + 1,
		) );

		if( is_wp_error( $response ) ) {
			return new WP_Error( 'openai_request_failed', $this->safe_error_message( $response->get_error_message() ), array( 'status' => 502 ) );
		}

		$status = (int) wp_remote_retrieve_response_code( $response );
		$body = (string) wp_remote_retrieve_body( $response );
		$json = json_decode( $body, true );

		if( $status < 200 || $status >= 300 ) {
			return $this->error_from_response( $json, $status, 'OpenAI request failed' );
		}

		return array(
			'result' => trim( (string) ( $json['choices'][0]['message']['content'] ?? '' ) ),
			'provider' => 'openai',
			'meta' => array(
				'provider' => 'openai',
				'model' => $model,
				'durationMs' => (int) round( ( microtime( true ) - $started ) * 1000 ),
				'usage' => $json['usage'] ?? null,
			),
		);
	}

	/**
	 * Send a multimodal text request with an inline image data URL.
	 *
	 * Used for screenshot-to-page planning. The provider still returns text so
	 * callers can validate the JSON with the same plan sanitizers as normal page
	 * creation.
	 */

	public function generate_vision_text( string $prompt, string $image_data_url, array $options = array() ) {
		$key = WPHAVE_AI_Config::openai_api_key();
		$started = microtime( true );

		if( ! $key ) {
			return new WP_Error( 'ai_no_key', __( 'OpenAI API key missing', 'wphave' ), array( 'status' => 400 ) );
		}

		if( $prompt === '' || $image_data_url === '' ) {
			return new WP_Error( 'ai_vision_missing_data', __( 'Prompt and image are required.', 'wphave' ), array( 'status' => 400 ) );
		}

		$model = WPHAVE_AI_Config::model();
		$body = array(
			'model' => $model,
			'max_completion_tokens' => WPHAVE_AI_Config::max_tokens( $options ),
			'messages' => array(
				array(
					'role' => 'user',
					'content' => array(
						array(
							'type' => 'text',
							'text' => $prompt,
						),
						array(
							'type' => 'image_url',
							'image_url' => array(
								'url' => $image_data_url,
								'detail' => sanitize_key( $options['imageDetail'] ?? 'high' ),
							),
						),
					),
				),
			),
		);

		if( ( $options['responseFormat'] ?? '' ) === 'json_object' ) {
			$body['response_format'] = array(
				'type' => 'json_object',
			);
		}

		$response = wp_remote_post( 'https://api.openai.com/v1/chat/completions', array(
			'headers' => array(
				'Authorization' => 'Bearer ' . $key,
				'Content-Type' => 'application/json',
			),
			'body' => wp_json_encode( $body ),
			'timeout' => 120,
			'redirection' => 0,
			'sslverify' => true,
			'limit_response_size' => self::MAX_JSON_RESPONSE_BYTES + 1,
		) );

		if( is_wp_error( $response ) ) {
			return new WP_Error( 'openai_request_failed', $this->safe_error_message( $response->get_error_message() ), array( 'status' => 502 ) );
		}

		$status = (int) wp_remote_retrieve_response_code( $response );
		$body = (string) wp_remote_retrieve_body( $response );
		$json = json_decode( $body, true );

		if( $status < 200 || $status >= 300 ) {
			return $this->error_from_response( $json, $status, 'OpenAI vision request failed' );
		}

		return array(
			'result' => trim( (string) ( $json['choices'][0]['message']['content'] ?? '' ) ),
			'provider' => 'openai',
			'meta' => array(
				'provider' => 'openai',
				'model' => $model,
				'durationMs' => (int) round( ( microtime( true ) - $started ) * 1000 ),
				'usage' => $json['usage'] ?? null,
			),
		);
	}

	/**
	 * Stream a text response from OpenAI as server-sent events.
	 * Used for chat and streaming text actions where incremental UI updates are needed.
	 */

	public function stream_text( array $messages, array $options = array() ) {
		$key = WPHAVE_AI_Config::openai_api_key();

		if( ! $key ) {
			$this->send_sse_error( 'ai_no_key', __( 'OpenAI API key missing', 'wphave' ) );
			return;
		}

		$this->send_sse_headers();

		$ch = curl_init( 'https://api.openai.com/v1/chat/completions' );
		if( ! $ch ) {
			$this->send_sse_error( 'curl_error', __( 'OpenAI stream could not be initialized.', 'wphave' ) );
			return;
		}
		$stream_buffer = '';

		curl_setopt_array( $ch, array(
			CURLOPT_POST => true,
			CURLOPT_FOLLOWLOCATION => false,
			CURLOPT_PROTOCOLS => CURLPROTO_HTTPS,
			CURLOPT_SSL_VERIFYPEER => true,
			CURLOPT_SSL_VERIFYHOST => 2,
			CURLOPT_HTTPHEADER => array(
				'Authorization: Bearer ' . $key,
				'Content-Type: application/json',
			),
			CURLOPT_POSTFIELDS => wp_json_encode( array(
				'model' => WPHAVE_AI_Config::model(),
				'max_completion_tokens' => WPHAVE_AI_Config::max_tokens( $options ),
				'messages' => $messages,
				'stream' => true,
			) ),
			CURLOPT_WRITEFUNCTION => function( $ch, $data ) use ( &$stream_buffer ) {
				if( connection_aborted() ) {
					return 0;
				}

				$stream_buffer .= $data;
				// TRANSPORT INVARIANT: An upstream stream must regularly terminate SSE
				// frames. A delimiter-free response cannot grow request memory without bound.
				if( strlen( $stream_buffer ) > self::MAX_STREAM_BUFFER_BYTES ) {
					$this->send_sse_error( 'openai_stream_too_large', __( 'OpenAI stream frame exceeded the allowed size.', 'wphave' ) );
					return 0;
				}
				$events = preg_split( "/\r?\n\r?\n/", $stream_buffer );
				$stream_buffer = array_pop( $events );

				foreach( $events as $event ) {
					$lines = preg_split( "/\r?\n/", $event );

					foreach( $lines as $line ) {
						if( ! str_starts_with( $line, 'data:' ) ) {
							continue;
						}

						$json = trim( substr( $line, 5 ) );

						if( $json === '[DONE]' ) {
							echo "event: done\ndata: \"END\"\n\n";
							flush();
							return strlen( $data );
						}

						$payload = json_decode( $json, true );
						if( ! is_array( $payload ) ) {
							continue;
						}

						if( isset( $payload['error'] ) ) {
							$this->send_sse_error( $payload['error']['code'] ?? 'openai_error', $payload['error']['message'] ?? 'OpenAI stream failed' );
							return 0;
						}

						$token = $payload['choices'][0]['delta']['content'] ?? '';

						if( $token !== '' ) {
							echo 'data: ' . wp_json_encode( $token ) . "\n\n";
							flush();
						}
					}
				}

				return strlen( $data );
			},
			// STREAM LIFETIME INVARIANT: A stalled upstream must release the PHP
			// worker. The 2-second per-user request throttle is not a concurrency
			// bound while an existing SSE request can hang indefinitely.
			CURLOPT_CONNECTTIMEOUT => 15,
			CURLOPT_LOW_SPEED_LIMIT => 1,
			CURLOPT_LOW_SPEED_TIME => 30,
			CURLOPT_TIMEOUT => 180,
		) );

		curl_exec( $ch );

		if( curl_errno( $ch ) ) {
			$this->send_sse_error( 'curl_error', curl_error( $ch ) );
		}

		curl_close( $ch );
	}

	/**
	 * Generate one or more images from a prompt through OpenAI image APIs.
	 * The method applies image options, normalizes the provider response, and returns base64 image payloads.
	 */

	public function generate_image( array $payload, array $options = array() ) {
		$key = WPHAVE_AI_Config::openai_api_key();
		$timeout = $this->image_request_timeout();
		$this->extend_time_limit( $timeout );

		if( ! $key ) {
			return new WP_Error( 'ai_no_key', __( 'OpenAI API key missing', 'wphave' ), array( 'status' => 400 ) );
		}

		$prompt = trim( (string) ( $payload['prompt'] ?? '' ) );
		if( $prompt === '' ) {
			return new WP_Error( 'missing_prompt', __( 'Image prompt missing', 'wphave' ), array( 'status' => 400 ) );
		}

		$messages = WPHAVE_AI_Prompts::build_messages( array(
			'mode' => 'image',
			'input' => $prompt,
			'options' => $options,
		) );

		if( is_wp_error( $messages ) ) {
			return $messages;
		}

		$sizes = array(
			'square' => '1024x1024',
			'landscape' => '1536x1024',
			'portrait' => '1024x1536',
		);

		$size = $options['size'] ?? '';
		$size = $sizes[$size] ?? 'auto';
		$output_format = sanitize_key( $options['fileFormat'] ?? 'png' );
		$output_format = in_array( $output_format, array( 'png', 'jpeg', 'webp' ), true ) ? $output_format : 'png';

		$response = wp_remote_post( 'https://api.openai.com/v1/images/generations', array(
			'headers' => array(
				'Authorization' => 'Bearer ' . $key,
				'Content-Type' => 'application/json',
			),
				'body' => wp_json_encode( array(
					'model' => WPHAVE_AI_Config::image_model( $options ),
					'prompt' => WPHAVE_AI_Prompts::image_prompt_from_messages( $messages ),
				'size' => sanitize_text_field( $size ),
				'quality' => sanitize_text_field( $options['quality'] ?? 'low' ),
				'background' => sanitize_text_field( $options['background'] ?? 'opaque' ),
				'output_format' => $output_format,
					'n' => max( 1, min( 4, absint( $options['variations'] ?? 1 ) ) ),
				) ),
				'timeout' => $timeout,
				'redirection' => 0,
				'sslverify' => true,
				'limit_response_size' => self::MAX_JSON_RESPONSE_BYTES + 1,
			) );

		if( is_wp_error( $response ) ) {
			return new WP_Error( 'openai_image_request_failed', $this->safe_error_message( $response->get_error_message() ), array( 'status' => 502 ) );
		}

		$status = (int) wp_remote_retrieve_response_code( $response );
		$body = (string) wp_remote_retrieve_body( $response );
		$json = json_decode( $body, true );

		if( $status < 200 || $status >= 300 ) {
			return $this->error_from_response( $json, $status, 'OpenAI image request failed' );
		}

		return $this->normalize_image_response( $json, $output_format );
	}

	/**
	 * Edit one or more source images with an OpenAI image-edit request.
	 * Base64 images are converted to temporary files and always cleaned up after the request.
	 */

	public function edit_image( array $payload, array $options = array() ) {
		$key = WPHAVE_AI_Config::openai_api_key();
		$timeout = $this->image_request_timeout();
		$this->extend_time_limit( $timeout );

		if( ! $key ) {
			return new WP_Error( 'ai_no_key', __( 'OpenAI API key missing', 'wphave' ), array( 'status' => 400 ) );
		}

		if( empty( $payload['prompt'] ) || empty( $payload['images'] ) || ! is_array( $payload['images'] ) ) {
			return new WP_Error( 'missing_data', __( 'Image(s) and edit prompt required', 'wphave' ), array( 'status' => 400 ) );
		}

		$image_files = $this->normalize_images_to_files( $payload['images'] );
		if( is_wp_error( $image_files ) ) {
			return $image_files;
		}

		$post_fields = array(
			'model' => WPHAVE_AI_Config::image_model( $options ),
			'prompt' => mb_substr( wp_strip_all_tags( (string) $payload['prompt'] ), 0, 8000 ),
		);

		foreach( $image_files as $i => $file ) {
			$post_fields["image[$i]"] = new CURLFile( $file['path'], $file['mime'], $file['name'] ?? "image{$i}.png" );
		}

		$ch = curl_init( 'https://api.openai.com/v1/images/edits' );
		if( ! $ch ) {
			$this->cleanup_temporary_images( $image_files );

			return new WP_Error( 'curl_error', __( 'OpenAI image edit could not be initialized.', 'wphave' ), array( 'status' => 502 ) );
		}
		$response_body = '';
		$within_limit = true;

		curl_setopt_array( $ch, array(
			CURLOPT_POST => true,
			CURLOPT_FOLLOWLOCATION => false,
			CURLOPT_PROTOCOLS => CURLPROTO_HTTPS,
			CURLOPT_SSL_VERIFYPEER => true,
			CURLOPT_SSL_VERIFYHOST => 2,
			CURLOPT_WRITEFUNCTION => $this->bounded_response_writer( $response_body, $within_limit, self::MAX_JSON_RESPONSE_BYTES ),
			CURLOPT_HTTPHEADER => array(
				'Authorization: Bearer ' . $key,
				),
				CURLOPT_POSTFIELDS => $post_fields,
				CURLOPT_CONNECTTIMEOUT => 20,
				CURLOPT_TIMEOUT => $timeout,
			) );

		$response = curl_exec( $ch );
		$status = (int) curl_getinfo( $ch, CURLINFO_HTTP_CODE );
		$error = curl_error( $ch );
		curl_close( $ch );

		$this->cleanup_temporary_images( $image_files );

		if( $response === false || ! $within_limit ) {
			return new WP_Error( 'curl_error', $this->safe_error_message( $error ?: __( 'Unknown cURL error', 'wphave' ) ), array( 'status' => 502 ) );
		}

		$json = json_decode( $response_body, true );

		if( $status < 200 || $status >= 300 ) {
			return $this->error_from_response( $json, $status, 'Image edit failed' );
		}

		return $this->normalize_image_response( $json, sanitize_key( $options['fileFormat'] ?? 'png' ) );
	}

	/**
	 * Transcribe an uploaded browser recording through OpenAI audio transcription.
	 * Accepts the WordPress upload array and returns only the normalized text plus provider metadata.
	 */

	public function transcribe_audio( array $file, array $options = array() ) {
		$key = WPHAVE_AI_Config::openai_api_key();
		$started = microtime( true );

		if( ! $key ) {
			return new WP_Error( 'ai_no_key', __( 'OpenAI API key missing', 'wphave' ), array( 'status' => 400 ) );
		}

		if( empty( $file['tmp_name'] ) || ! file_exists( $file['tmp_name'] ) ) {
			return new WP_Error( 'ai_audio_file_missing', __( 'Audio file missing.', 'wphave' ), array( 'status' => 400 ) );
		}

		$mime = sanitize_mime_type( $file['type'] ?? 'audio/webm' );
		$name = sanitize_file_name( $file['name'] ?? 'voice-prompt.webm' );

		$ch = curl_init( 'https://api.openai.com/v1/audio/transcriptions' );
		if( ! $ch ) {
			return new WP_Error( 'curl_error', __( 'OpenAI transcription could not be initialized.', 'wphave' ), array( 'status' => 502 ) );
		}
		$response_body = '';
		$within_limit = true;

		curl_setopt_array( $ch, array(
			CURLOPT_POST => true,
			CURLOPT_FOLLOWLOCATION => false,
			CURLOPT_PROTOCOLS => CURLPROTO_HTTPS,
			CURLOPT_SSL_VERIFYPEER => true,
			CURLOPT_SSL_VERIFYHOST => 2,
			CURLOPT_WRITEFUNCTION => $this->bounded_response_writer( $response_body, $within_limit, self::MAX_JSON_RESPONSE_BYTES ),
			CURLOPT_HTTPHEADER => array(
				'Authorization: Bearer ' . $key,
			),
			CURLOPT_POSTFIELDS => array(
				'model' => WPHAVE_AI_Config::transcription_model( $options ),
				'file' => new CURLFile( $file['tmp_name'], $mime, $name ),
				'response_format' => 'json',
			),
			CURLOPT_CONNECTTIMEOUT => 20,
			CURLOPT_TIMEOUT => 120,
		) );

		$response = curl_exec( $ch );
		$status = (int) curl_getinfo( $ch, CURLINFO_HTTP_CODE );
		$error = curl_error( $ch );
		curl_close( $ch );

		if( $response === false || ! $within_limit ) {
			return new WP_Error( 'curl_error', $this->safe_error_message( $error ?: __( 'Unknown cURL error', 'wphave' ) ), array( 'status' => 502 ) );
		}

		$json = json_decode( $response_body, true );

		if( $status < 200 || $status >= 300 ) {
			return $this->error_from_response( $json, $status, 'Audio transcription failed' );
		}

		return array(
			'text' => trim( (string) ( $json['text'] ?? '' ) ),
			'provider' => 'openai',
			'meta' => array(
				'provider' => 'openai',
				'model' => WPHAVE_AI_Config::transcription_model( $options ),
				'durationMs' => (int) round( ( microtime( true ) - $started ) * 1000 ),
			),
		);
	}

	/**
	 * Generate short-lived speech audio for an AI answer.
	 * The audio is returned as base64 so the UI can play it without creating media-library files.
	 */

	public function create_speech( string $text, array $options = array() ) {
		$key = WPHAVE_AI_Config::openai_api_key();
		$started = microtime( true );

		if( ! $key ) {
			return new WP_Error( 'ai_no_key', __( 'OpenAI API key missing', 'wphave' ), array( 'status' => 400 ) );
		}

		$text = $this->prepare_speech_text( $text );
		if( $text === '' ) {
			return new WP_Error( 'ai_speech_empty_text', __( 'No text provided for speech.', 'wphave' ), array( 'status' => 400 ) );
		}

		$model = WPHAVE_AI_Config::speech_model( $options );
		$voice = WPHAVE_AI_Config::speech_voice( $options );
		$instructions = WPHAVE_AI_Config::speech_instructions( $options );
		$voices = array( 'alloy', 'ash', 'ballad', 'coral', 'echo', 'fable', 'nova', 'onyx', 'sage', 'shimmer', 'verse', 'marin', 'cedar' );
		$legacy_voices = array( 'alloy', 'ash', 'coral', 'echo', 'fable', 'onyx', 'nova', 'sage', 'shimmer' );

		if( ! in_array( $voice, $voices, true ) || in_array( $model, array( 'tts-1' ), true ) && ! in_array( $voice, $legacy_voices, true ) ) {
			$voice = 'coral';
		}

		$body = array(
			'model' => $model,
			'voice' => $voice,
			'input' => mb_substr( $text, 0, 8000 ),
		);

		if( $instructions !== '' && str_starts_with( $model, 'gpt-4o-mini-tts' ) ) {
			$body['instructions'] = mb_substr( $instructions, 0, 500 );
		}

		$response = wp_remote_post( 'https://api.openai.com/v1/audio/speech', array(
			'headers' => array(
				'Authorization' => 'Bearer ' . $key,
				'Content-Type' => 'application/json',
			),
			'body' => wp_json_encode( $body ),
			'timeout' => 120,
			'redirection' => 0,
			'sslverify' => true,
			'limit_response_size' => self::MAX_AUDIO_RESPONSE_BYTES + 1,
		) );

		if( is_wp_error( $response ) ) {
			return new WP_Error( 'openai_speech_request_failed', $this->safe_error_message( $response->get_error_message() ), array( 'status' => 502 ) );
		}

		$status = (int) wp_remote_retrieve_response_code( $response );
		$body = (string) wp_remote_retrieve_body( $response );

		if( $status < 200 || $status >= 300 ) {
			return $this->error_from_response( json_decode( $body, true ), $status, 'Speech generation failed' );
		}

		return array(
			'audio' => base64_encode( $body ),
			'mime' => 'audio/mpeg',
			'provider' => 'openai',
			'meta' => array(
				'provider' => 'openai',
				'model' => $model,
				'voice' => $voice,
				'durationMs' => (int) round( ( microtime( true ) - $started ) * 1000 ),
			),
		);
	}

	/**
	 * Convert assistant text into speech-friendly plain text before TTS.
	 * Written answers often contain Markdown, bullets, URLs, and code markers that make voices sound like they are reading a document.
	 */

	protected function prepare_speech_text( string $text ): string {
		$text = html_entity_decode( wp_strip_all_tags( $text ), ENT_QUOTES, get_bloginfo( 'charset' ) ?: 'UTF-8' );
		$text = preg_replace( '/```[\s\S]*?```/', ' ', $text );
		$text = preg_replace( '/`([^`]+)`/', '$1', $text );
		$text = preg_replace( '/!\[[^\]]*\]\([^)]+\)/', ' ', $text );
		$text = preg_replace( '/\[([^\]]+)\]\([^)]+\)/', '$1', $text );
		$text = preg_replace( '/https?:\/\/\S+/', ' ', $text );
		$text = preg_replace( '/^\s{0,3}#{1,6}\s+/m', '', $text );
		$text = preg_replace( '/^\s*[-*+]\s+/m', '. ', $text );
		$text = preg_replace( '/^\s*\d+[\.)]\s+/m', '. ', $text );
		$text = preg_replace( '/[*_~>#|]/', '', $text );
		$text = preg_replace( '/\s*[\r\n]+\s*/', '. ', $text );
		$text = preg_replace( '/\.{2,}/', '.', $text );
		$text = preg_replace( '/\s+/', ' ', $text );

		return trim( mb_substr( $text, 0, 8000 ) );
	}

	/**
	 * Return the timeout budget for image generation and edit requests.
	 * Image requests can take multiple minutes, especially edits with larger source files or several variations.
	 */

	protected function image_request_timeout(): int {
		$timeout = (int) apply_filters( 'wphave_ai_image_request_timeout', 300 );

		return max( 120, min( 600, $timeout ) );
	}

	/**
	 * Extend PHP's execution time for long-running image requests when the environment allows it.
	 * Hosting limits may still apply, but this prevents avoidable local PHP timeouts.
	 */

	protected function extend_time_limit( int $timeout ): void {
		if( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( $timeout + 30 );
		}
	}

	/** Build the shared in-stream response limiter for direct provider requests. */
	private function bounded_response_writer( string &$response_body, bool &$within_limit, int $max_bytes ): callable {
		return static function( $handle, string $chunk ) use ( &$response_body, &$within_limit, $max_bytes ): int {
			if( strlen( $response_body ) + strlen( $chunk ) > $max_bytes ) {
				$within_limit = false;
				return 0;
			}

			$response_body .= $chunk;
			return strlen( $chunk );
		};
	}

	/**
	 * Normalize OpenAI image data into the app image message shape.
	 * Only valid base64 image items are returned.
	 */

	protected function normalize_image_response( array $json, string $output_format ): array {
		$items = $json['data'] ?? array();

		if( ! $items ) {
			return array( 'images' => array() );
		}

		$images = array();
		$output_format = in_array( $output_format, array( 'png', 'jpeg', 'webp' ), true ) ? $output_format : 'png';

		foreach( $items as $item ) {
			if( empty( $item['b64_json'] ) ) {
				continue;
			}

			$images[] = array(
				'type' => 'image',
				'mime' => 'image/' . $output_format,
				'base64' => $item['b64_json'],
			);
		}

		return array( 'images' => $images );
	}

	/**
	 * Convert uploaded image payloads into temporary files for cURL multipart upload.
	 * Returns a WP_Error if any image cannot be decoded or written.
	 */

	protected function normalize_images_to_files( array $images ) {
		$files = array();

		foreach( array_slice( $images, 0, 4 ) as $image ) {
			if( empty( $image['base64'] ) ) {
				$this->cleanup_temporary_images( $files );
				return new WP_Error( 'unsupported_image_format', __( 'Only base64 images are supported for editing.', 'wphave' ), array( 'status' => 400 ) );
			}

			$file = $this->base64_to_temp_image( (string) $image['base64'] );
			if( is_wp_error( $file ) ) {
				// TEMPORARY-FILE INVARIANT: A batch is all-or-nothing. A malformed
				// later image cannot leave earlier decoded files in the PHP temp area.
				$this->cleanup_temporary_images( $files );
				return $file;
			}

			$files[] = $file;
		}

		return $files;
	}

	/** Release only temporary image files returned by this provider's decoder. */
	private function cleanup_temporary_images( array $files ): void {
		foreach( $files as $file ) {
			if( is_string( $file['path'] ?? null ) ) {
				@unlink( $file['path'] );
			}
		}
	}

	/**
	 * Decode a data URL image into a temporary local file.
	 * The returned file descriptor is later passed to cURL and must be deleted by the caller.
	 */

	protected function base64_to_temp_image( string $base64 ) {
		// IMAGE MEMORY INVARIANT: Bound the encoded request before decoding
		// allocates a second, attacker-sized binary string in the PHP worker.
		if( strlen( $base64 ) > self::MAX_INPUT_IMAGE_BASE64_BYTES ) {
			return new WP_Error( 'image_too_large', __( 'Image is too large.', 'wphave' ), array( 'status' => 413 ) );
		}

		if( str_starts_with( $base64, 'data:' ) ) {
			$base64 = preg_replace( '#^data:image/[^;]+;base64,#i', '', $base64 );
		}

		if( str_contains( $base64, ',' ) ) {
			$base64 = substr( $base64, strpos( $base64, ',' ) + 1 );
		}

		$binary = base64_decode( $base64, true );
		if( $binary === false ) {
			return new WP_Error( 'invalid_base64', __( 'Base64 decode failed.', 'wphave' ), array( 'status' => 400 ) );
		}

		if( strlen( $binary ) > self::MAX_INPUT_IMAGE_BYTES ) {
			return new WP_Error( 'image_too_large', __( 'Image is too large.', 'wphave' ), array( 'status' => 413 ) );
		}

		$tmp = tempnam( get_temp_dir(), 'wphave-ai-image-' );
		if( ! is_string( $tmp ) || file_put_contents( $tmp, $binary ) !== strlen( $binary ) ) {
			if( is_string( $tmp ) ) {
				@unlink( $tmp );
			}
			return new WP_Error( 'image_write_failed', __( 'Image could not be prepared.', 'wphave' ), array( 'status' => 500 ) );
		}

		$info = @getimagesize( $tmp );
		if( $info === false ) {
			@unlink( $tmp );
			return new WP_Error( 'invalid_image', __( 'Decoded file is not a valid image.', 'wphave' ), array( 'status' => 400 ) );
		}

		return array(
			'path' => $tmp,
			'mime' => $info['mime'],
			'name' => 'image.png',
		);
	}

	/**
	 * Convert a provider error response into a WP_Error.
	 * Preserves the HTTP status and provider message when available.
	 */

	protected function error_from_response( $json, int $status, string $fallback ): WP_Error {
		$message = is_array( $json ) ? ( $json['error']['message'] ?? $fallback ) : $fallback;
		$code = is_array( $json ) ? ( $json['error']['code'] ?? 'openai_error' ) : 'openai_error';
		// SECURITY INVARIANT: Provider-controlled failures cross into UI and logs only
		// after the central credential, identity and path redaction boundary.
		$message = $this->safe_error_message( $message );

		return new WP_Error( sanitize_key( $code ), $message, array( 'status' => $status ?: 502 ) );
	}

	protected function safe_error_message( $message ): string {
		// SECURITY INVARIANT: Every provider and transport failure shares one final
		// redaction boundary before it can reach REST, SSE, diagnostics or logs.
		return WPHAVE_Security_Redactor::error_text( $message, 1000 );
	}

	/**
	 * Send HTTP headers required for server-sent AI streams.
	 * Also disables buffering where possible so tokens reach the browser promptly.
	 */

	protected function send_sse_headers(): void {
		header( 'Content-Type: text/event-stream' );
		header( 'Cache-Control: no-cache' );
		header( 'Connection: keep-alive' );
		header( 'X-Accel-Buffering: no' );

		@ini_set( 'zlib.output_compression', 0 );
		@ini_set( 'output_buffering', 'off' );
		@ini_set( 'implicit_flush', 1 );

		while( ob_get_level() > 0 ) {
			ob_end_flush();
		}

		ob_implicit_flush( true );
	}

	/**
	 * Emit a structured SSE error event to the client.
	 * Used when a streaming request fails after headers have already been sent.
	 */

	protected function send_sse_error( string $code, string $message ): void {
		// STREAM ERROR INVARIANT: Provider error frames cross the same
		// credential/path redaction boundary as non-streaming WP_Error replies.
		// JSON encoding alone prevents script syntax, not secret disclosure.
		$code = sanitize_key( $code );
		$message = $this->safe_error_message( $message );
		echo "event: error\n";
		echo 'data: ' . wp_json_encode( array(
			'code' => $code,
			'message' => $message,
		) ) . "\n\n";
		flush();
	}

}
