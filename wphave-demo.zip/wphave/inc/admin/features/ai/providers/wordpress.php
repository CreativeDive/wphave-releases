<?php

if( ! defined('ABSPATH') ) {
	exit;
}

/**
 * Manage the ai provider wordpress feature.
 */

class WPHAVE_AI_Provider_WordPress {

	protected static $instance = null;

	/**
	 * Return the singleton instance for this AI service.
	 * Keeps route callbacks and provider calls using a shared stateless service instance.
	 */

	public static function instance(): self {
		if( ! self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Report whether this provider can currently be used.
	 * Availability is based on the provider-specific runtime requirements.
	 */

	public function is_available(): bool {
		return function_exists( 'wp_ai_client_prompt' );
	}

	/**
	 * Send a text/chat-style request to the selected provider and return a normalized provider response.
	 * The response includes the generated result plus internal provider metadata for diagnostics.
	 */

	public function generate_text( array $messages, array $options = array() ) {
		if( ! $this->is_available() ) {
			return new WP_Error( 'wp_ai_unavailable', __( 'WordPress AI Client is not available.', 'wphave' ), array( 'status' => 400 ) );
		}

		$started = microtime( true );
		$prompt = $this->messages_to_prompt( $messages );

		if( $prompt === '' ) {
			return new WP_Error( 'ai_empty_prompt', __( 'No prompt provided.', 'wphave' ), array( 'status' => 400 ) );
		}

		try {
			$builder = wp_ai_client_prompt( $prompt );

			if( method_exists( $builder, 'using_model_preference' ) ) {
				$builder = $builder->using_model_preference( WPHAVE_AI_Config::model() );
			}

			if( method_exists( $builder, 'using_max_tokens' ) ) {
				$builder = $builder->using_max_tokens( WPHAVE_AI_Config::max_tokens( $options ) );
			}

			$result = $builder->generate_text();
		} catch( Throwable $e ) {
			return new WP_Error( 'wp_ai_request_failed', $e->getMessage(), array( 'status' => 502 ) );
		}

		if( is_wp_error( $result ) ) {
			return $result;
		}

		return array(
			'result' => trim( (string) $result ),
			'provider' => 'wordpress',
			'meta' => array(
				'provider' => 'wordpress',
				'model' => WPHAVE_AI_Config::model(),
				'durationMs' => (int) round( ( microtime( true ) - $started ) * 1000 ),
				'usage' => null,
			),
		);
	}

	/**
	 * Convert chat-style messages into a single WordPress AI prompt string.
	 * The WordPress AI client currently accepts prompt text, so roles are folded into readable sections.
	 */

	protected function messages_to_prompt( array $messages ): string {
		$parts = array();

		foreach( $messages as $message ) {
			$role = strtoupper( sanitize_key( $message['role'] ?? 'user' ) );
			$content = trim( (string) ( $message['content'] ?? '' ) );

			if( $content !== '' ) {
				$parts[] = $role . ":\n" . $content;
			}
		}

		return trim( implode( "\n\n", $parts ) );
	}

}
