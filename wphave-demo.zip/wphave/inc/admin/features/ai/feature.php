<?php

if( ! defined('ABSPATH') ) {
	exit;
}

/**
 * Manage the ai feature feature.
 */

class WPHAVE_AI_Feature {

	/**
	 * Register AI feature integrations with WordPress.
	 * Currently this wires the REST routes during rest_api_init.
	 */

	public static function init(): void {
		add_action( 'rest_api_init', array( WPHAVE_AI_REST_Controller::instance(), 'register_routes' ) );
	}

}
