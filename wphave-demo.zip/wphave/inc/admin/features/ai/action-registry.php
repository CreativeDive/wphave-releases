<?php

if( ! defined('ABSPATH') ) {
	exit;
}

/**
 * Manage the ai action registry feature.
 */

class WPHAVE_AI_Action_Registry {

	/**
	 * Return the canonical list of AI actions supported by the backend.
	 * The returned definitions are the server-side contract used for routing, provider selection, streaming support, and output metadata.
	 */

	public static function actions(): array {
		return array(
			'chat' => self::definition( 'chat', true, array( 'text' ) ),
			'text.restyle' => self::definition( 'text', true, array( 'text' ) ),
			'text.translate' => self::definition( 'text', true, array( 'text' ) ),
			'text.shorten' => self::definition( 'text', true, array( 'text' ) ),
			'text.lengthen' => self::definition( 'text', true, array( 'text' ) ),
			'text.grammar' => self::definition( 'text', true, array( 'text' ) ),
			'text.clarity' => self::definition( 'text', true, array( 'text' ) ),
			'text.active' => self::definition( 'text', true, array( 'text' ) ),
			'text.simplify' => self::definition( 'text', true, array( 'text' ) ),
			'text.expand_examples' => self::definition( 'text', true, array( 'text' ) ),
			'text.seo' => self::definition( 'text', true, array( 'text' ) ),
			'text.headline' => self::definition( 'text', true, array( 'text' ) ),
			'text.summary' => self::definition( 'text', true, array( 'text' ) ),
			'text.continue' => self::definition( 'text', true, array( 'text' ) ),
			'image.generate' => self::definition( 'image', false, array( 'image' ) ),
			'image.edit' => self::definition( 'image', false, array( 'image' ) ),
			'global_styles.generate' => self::definition( 'global_styles', false, array( 'text' ), array( 'responseFormat' => 'json_object' ) ),
			'seo.generate_title' => self::definition( 'context', false, array( 'text' ), array( 'output' => 'seo_title', 'maxLength' => 60 ) ),
			'seo.improve_title' => self::definition( 'context', false, array( 'text' ), array( 'output' => 'seo_title', 'maxLength' => 60 ) ),
			'seo.generate_description' => self::definition( 'context', false, array( 'text' ), array( 'output' => 'seo_description', 'maxLength' => 155 ) ),
			'seo.improve_description' => self::definition( 'context', false, array( 'text' ), array( 'output' => 'seo_description', 'maxLength' => 155 ) ),
			'seo.shorten_title' => self::definition( 'context', false, array( 'text' ), array( 'output' => 'seo_title', 'maxLength' => 60 ) ),
			'seo.shorten_description' => self::definition( 'context', false, array( 'text' ), array( 'output' => 'seo_description', 'maxLength' => 155 ) ),
			'seo.generate_slug' => self::definition( 'context', false, array( 'text' ), array( 'output' => 'slug', 'maxLength' => 80 ) ),
			'seo.suggest_keywords' => self::definition( 'context', false, array( 'text' ), array( 'output' => 'keywords' ) ),
			'media.generate_alt_text' => self::definition( 'context', false, array( 'vision' ), array( 'output' => 'alt_text' ) ),
			'media.improve_alt_text' => self::definition( 'context', false, array( 'vision' ), array( 'output' => 'alt_text' ) ),
			'media.generate_caption' => self::definition( 'context', false, array( 'vision' ), array( 'output' => 'caption' ) ),
			'media.generate_title' => self::definition( 'context', false, array( 'vision' ), array( 'output' => 'media_title' ) ),
			'media.suggest_filename' => self::definition( 'context', false, array( 'vision' ), array( 'output' => 'filename' ) ),
			'media.mark_decorative' => self::definition( 'context', false, array( 'vision' ), array( 'output' => 'alt_text' ) ),
			'editor.button_cta' => self::definition( 'context', false, array( 'text' ), array( 'output' => 'button_label' ) ),
			'editor.heading_from_context' => self::definition( 'context', false, array( 'text' ), array( 'output' => 'heading' ) ),
			'editor.paragraph_from_context' => self::definition( 'context', false, array( 'text' ), array( 'output' => 'paragraph' ) ),
			'editor.improve_field_label' => self::definition( 'context', false, array( 'text' ), array( 'output' => 'field_label' ) ),
		);
	}

	/**
	 * Return the action definition for a single AI action id.
	 * Returns null when the action is not registered, allowing callers to fail closed.
	 */

	public static function get( string $action ): ?array {
		$actions = self::actions();

		return $actions[$action] ?? null;
	}

	/**
	 * Build a normalized action definition used by the registry.
	 * This keeps action metadata consistent while letting individual actions add output-specific metadata.
	 */

	protected static function definition( string $domain, bool $stream, array $capabilities = array( 'text' ), array $extra = array() ): array {
		return array_merge( array(
			'domain' => $domain,
			'stream' => $stream,
			'capabilities' => $capabilities,
		), $extra );
	}

}
