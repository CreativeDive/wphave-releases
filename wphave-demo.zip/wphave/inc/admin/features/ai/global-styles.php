<?php

if( ! defined('ABSPATH') ) {
	exit;
}

require_once wphave_dir() . 'inc/features/security/boundaries/index.php';

/**
 * Manage the ai global styles feature.
 */

class WPHAVE_AI_Global_Styles {

	protected static $recipes = array(
		'modern_saas',
		'clean_corporate',
		'premium_dark',
		'warm_minimal',
		'editorial',
		'playful_bold',
	);

	protected static $palettes = array(
		'blue_teal',
		'indigo_sky',
		'graphite_lime',
		'warm_clay',
		'mono_ink',
		'rose_berry',
	);

	protected static $intensities = array(
		'subtle',
		'balanced',
		'bold',
	);

	protected static $densities = array(
		'compact',
		'comfortable',
		'spacious',
	);

	protected static $shapes = array(
		'sharp',
		'soft',
		'pill',
	);

	/**
	 * Build provider messages for the requested AI mode or action.
	 * The method combines system rules, formatting rules, global site prompts, action-specific rules, and user input.
	 */

	public static function build_messages( string $prompt, array $options = array() ) {
		$current = wphave_data_get( 'site_globals' ) ?? array();
		$current_context = array(
			'preset' => $current['preset']['colors']['name'] ?? 'default',
			'colors' => $current['colors'] ?? array(),
			'layout' => $current['layout'] ?? array(),
			'typography' => $current['typography'] ?? array(),
			'buttons' => $current['buttons'] ?? array(),
		);

		$system = trim(<<<PROMPT
			You are a design-system strategist for a WordPress site builder.

			TASK:
			Choose a controlled style recipe for the user's global website design.
			Do not generate raw site_globals tokens. The application will create the final token patch deterministically from your recipe choices.

			OUTPUT FORMAT:
			- Output ONLY valid JSON.
			- Do NOT wrap the response in Markdown.
			- Use this exact object shape:
			  {
			    "recipe": "modern_saas",
			    "palette": "blue_teal",
			    "intensity": "balanced",
			    "density": "comfortable",
			    "shape": "soft",
			    "summary": "Short visual direction summary",
			    "changes": ["Short change 1", "Short change 2"]
			  }

			ALLOWED VALUES:
			- recipe: modern_saas, clean_corporate, premium_dark, warm_minimal, editorial, playful_bold
			- palette: blue_teal, indigo_sky, graphite_lime, warm_clay, mono_ink, rose_berry
			- intensity: subtle, balanced, bold
			- density: compact, comfortable, spacious
			- shape: sharp, soft, pill

			RECIPE MEANING:
			- modern_saas: crisp, trustworthy, product-focused, clear CTAs.
			- clean_corporate: restrained, neutral, professional, broad B2B fit.
			- premium_dark: high-contrast, dark, polished, dramatic but usable.
			- warm_minimal: calm, warm, approachable, reduced visual noise.
			- editorial: typography-led, readable, content-first, refined spacing.
			- playful_bold: colorful, confident, energetic, rounded controls.

			SELECTION RULES:
			- Pick the closest recipe to the user's requested mood and website type.
			- Pick a palette that supports the recipe and requested mood.
			- Use balanced unless the user clearly asks for subtle or bold.
			- Use comfortable unless the user clearly asks for compact or spacious.
			- Use soft for modern SaaS and warm minimal, sharp for editorial/corporate if appropriate, pill for playful or very rounded UI.
			- The final patch will always reset preset.colors.name to default and write palette values into colors.
			- Summarize what the user will see, not implementation details.
		PROMPT);

		return array(
			array(
				'role' => 'system',
				'content' => $system,
			),
			array(
				'role' => 'system',
				'content' => 'Current style context JSON:' . "\n" . wp_json_encode( $current_context ),
			),
			array(
				'role' => 'user',
				'content' => $prompt,
			),
		);
	}

	/**
	 * Validate and normalize the AI global style recipe response.
	 * Falls back to deterministic defaults when optional fields are missing and returns WP_Error for unusable output.
	 */

	public static function validate_response( string $json, string $prompt = '' ) {
		$json = self::extract_json_object( $json );
		$data = json_decode( $json, true );

		if( json_last_error() !== JSON_ERROR_NONE || ! is_array( $data ) ) {
			if( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				error_log( '[wphave AI] Invalid global styles recipe response: ' . WPHAVE_Security_Redactor::error_text( $json, 1200 ) );
			}

			return new WP_Error( 'ai_global_styles_invalid_json', __( 'The generated global style response is not valid JSON.', 'wphave' ), array( 'status' => 502 ) );
		}

		$recipe = self::sanitize_choice( $data['recipe'] ?? '', self::$recipes, self::guess_recipe_from_prompt( $prompt ) );
		$palette = self::sanitize_choice( $data['palette'] ?? '', self::$palettes, self::default_palette_for_recipe( $recipe ) );
		$intensity = self::sanitize_choice( $data['intensity'] ?? '', self::$intensities, 'balanced' );
		$density = self::sanitize_choice( $data['density'] ?? '', self::$densities, 'comfortable' );
		$shape = self::sanitize_choice( $data['shape'] ?? '', self::$shapes, self::default_shape_for_recipe( $recipe ) );

		$selection = array(
			'recipe' => $recipe,
			'palette' => $palette,
			'intensity' => $intensity,
			'density' => $density,
			'shape' => $shape,
		);

		return array(
			'summary' => sanitize_text_field( (string) ( $data['summary'] ?? self::default_summary( $recipe ) ) ),
			'changes' => self::sanitize_changes( $data['changes'] ?? self::default_changes( $recipe ) ),
			'recipe' => $selection,
			'globals' => self::build_recipe_patch( $selection ),
		);
	}

	/**
	 * Extract the first JSON object from a model response.
	 * Handles responses that accidentally include prose around the JSON payload.
	 */

	protected static function extract_json_object( string $response ): string {
		$response = trim( $response );

		if( preg_match( '/```(?:json)?\s*(.*?)```/is', $response, $matches ) ) {
			$response = trim( $matches[1] );
		}

		if( str_starts_with( $response, '{' ) && str_ends_with( $response, '}' ) ) {
			return $response;
		}

		$start = strpos( $response, '{' );
		if( $start === false ) {
			return $response;
		}

		$depth = 0;
		$in_string = false;
		$is_escaped = false;
		$length = strlen( $response );

		for( $index = $start; $index < $length; $index++ ) {
			$char = $response[$index];

			if( $in_string ) {
				if( $is_escaped ) {
					$is_escaped = false;
					continue;
				}

				if( $char === '\\' ) {
					$is_escaped = true;
					continue;
				}

				if( $char === '"' ) {
					$in_string = false;
				}

				continue;
			}

			if( $char === '"' ) {
				$in_string = true;
				continue;
			}

			if( $char === '{' ) {
				$depth++;
			} elseif( $char === '}' ) {
				$depth--;
				if( $depth === 0 ) {
					return substr( $response, $start, $index - $start + 1 );
				}
			}
		}

		return $response;
	}

	/**
	 * Sanitize a model-selected enum value against allowed choices.
	 * Falls back to a safe default when the model returns an unsupported value.
	 */

	protected static function sanitize_choice( $value, array $allowed, string $fallback ): string {
		$value = sanitize_key( (string) $value );

		return in_array( $value, $allowed, true ) ? $value : $fallback;
	}

	/**
	 * Normalize the human-readable list of global style changes.
	 * Limits the result to concise strings suitable for UI display.
	 */

	protected static function sanitize_changes( $changes ): array {
		if( ! is_array( $changes ) ) {
			return array();
		}

		return array_values( array_filter( array_map( function( $change ) {
			return sanitize_text_field( (string) $change );
		}, array_slice( $changes, 0, 8 ) ) ) );
	}

	/**
	 * Infer a global style recipe from a free-form user prompt.
	 * Used as a fallback when AI output is missing or invalid.
	 */

	protected static function guess_recipe_from_prompt( string $prompt ): string {
		$prompt = strtolower( $prompt );

		if( str_contains( $prompt, 'dark' ) || str_contains( $prompt, 'luxury' ) || str_contains( $prompt, 'premium' ) ) {
			return 'premium_dark';
		}

		if( str_contains( $prompt, 'editorial' ) || str_contains( $prompt, 'magazin' ) || str_contains( $prompt, 'content' ) ) {
			return 'editorial';
		}

		if( str_contains( $prompt, 'warm' ) || str_contains( $prompt, 'calm' ) || str_contains( $prompt, 'minimal' ) ) {
			return 'warm_minimal';
		}

		if( str_contains( $prompt, 'playful' ) || str_contains( $prompt, 'bold' ) || str_contains( $prompt, 'bunt' ) ) {
			return 'playful_bold';
		}

		if( str_contains( $prompt, 'corporate' ) || str_contains( $prompt, 'business' ) || str_contains( $prompt, 'b2b' ) ) {
			return 'clean_corporate';
		}

		return 'modern_saas';
	}

	/**
	 * Return the default palette associated with a style recipe.
	 * Provides deterministic visual direction when AI does not choose a palette.
	 */

	protected static function default_palette_for_recipe( string $recipe ): string {
		$map = array(
			'modern_saas' => 'blue_teal',
			'clean_corporate' => 'indigo_sky',
			'premium_dark' => 'graphite_lime',
			'warm_minimal' => 'warm_clay',
			'editorial' => 'mono_ink',
			'playful_bold' => 'rose_berry',
		);

		return $map[$recipe] ?? 'blue_teal';
	}

	/**
	 * Return the default corner/shape style for a recipe.
	 * Keeps button, form, and frame styling coherent across generated patches.
	 */

	protected static function default_shape_for_recipe( string $recipe ): string {
		if( $recipe === 'editorial' || $recipe === 'clean_corporate' ) {
			return 'sharp';
		}

		if( $recipe === 'playful_bold' ) {
			return 'pill';
		}

		return 'soft';
	}

	/**
	 * Create a fallback summary for a global style proposal.
	 * Used when the model omits a usable summary.
	 */

	protected static function default_summary( string $recipe ): string {
		$labels = array(
			'modern_saas' => __( 'Modern SaaS styling with clear contrast and focused actions.', 'wphave' ),
			'clean_corporate' => __( 'Clean corporate styling with restrained colors and structured spacing.', 'wphave' ),
			'premium_dark' => __( 'Premium dark styling with high contrast and polished controls.', 'wphave' ),
			'warm_minimal' => __( 'Warm minimal styling with calm colors and soft spacing.', 'wphave' ),
			'editorial' => __( 'Editorial styling with stronger typography and content-focused rhythm.', 'wphave' ),
			'playful_bold' => __( 'Bold playful styling with expressive colors and rounded controls.', 'wphave' ),
		);

		return $labels[$recipe] ?? $labels['modern_saas'];
	}

	/**
	 * Create fallback change notes for a global style proposal.
	 * Ensures the UI can explain what the draft is expected to change.
	 */

	protected static function default_changes( string $recipe ): array {
		return array(
			__( 'Updated the global color palette.', 'wphave' ),
			__( 'Adjusted typography rhythm.', 'wphave' ),
			__( 'Restyled buttons, links, and forms.', 'wphave' ),
			__( 'Applied matching layout spacing and corners.', 'wphave' ),
		);
	}

	/**
	 * Build the complete deterministic global style patch for a recipe selection.
	 * Combines colors, typography, spacing, buttons, forms, and layout settings.
	 */

	protected static function build_recipe_patch( array $selection ): array {
		$recipe = $selection['recipe'] ?? 'modern_saas';
		$palette = self::palette( $selection['palette'] ?? self::default_palette_for_recipe( $recipe ), $recipe );
		$shape = $selection['shape'] ?? self::default_shape_for_recipe( $recipe );
		$density = $selection['density'] ?? 'comfortable';
		$intensity = $selection['intensity'] ?? 'balanced';

		$radius = self::radius_value( $shape, $recipe );
		$spacing = self::spacing_values( $density );
		$type = self::typography_values( $recipe, $intensity );
		$button = self::button_values( $palette, $radius, $shape );
		$form = self::form_values( $palette, $radius );

		return array(
			'preset' => array(
				'colors' => array(
					'name' => 'default',
				),
			),
			'colors' => self::colors_patch( $palette ),
			'layout' => array(
				'width' => $spacing['width'],
				'spacing' => $spacing['spacing'],
				'padding' => $spacing['padding'],
				'paddingTop' => $spacing['paddingTop'],
				'paddingRight' => $spacing['paddingRight'],
				'paddingBottom' => $spacing['paddingBottom'],
				'paddingLeft' => $spacing['paddingLeft'],
				'margin' => $spacing['margin'],
				'layoutGap' => $spacing['layoutGap'],
				'corners' => $radius,
			),
			'typography' => $type,
			'buttons' => $button,
			'links' => array(
				'colors' => array(
					'text' => $palette['primary'],
					'textHover' => $palette['accent'],
				),
			),
			'forms' => $form,
			'colorMode' => array(
				'preference' => 'default',
			),
		);
	}

	/**
	 * Resolve concrete color values for a named palette and recipe.
	 * Returns base and contrast colors used to generate site-global color patches.
	 */

	protected static function palette( string $palette, string $recipe ): array {
		$palettes = array(
			'blue_teal' => array(
				'primary' => '#2563eb',
				'secondary' => '#64748b',
				'tertiary' => '#dbeafe',
				'accent' => '#14b8a6',
				'background' => '#f8fafc',
				'text' => '#334155',
				'heading' => '#0f172a',
				'darkPrimary' => '#60a5fa',
				'darkAccent' => '#2dd4bf',
				'darkBackground' => '#0f172a',
				'darkText' => '#dbeafe',
				'darkHeading' => '#f8fafc',
			),
			'indigo_sky' => array(
				'primary' => '#4f46e5',
				'secondary' => '#475569',
				'tertiary' => '#e0e7ff',
				'accent' => '#0284c7',
				'background' => '#f8fafc',
				'text' => '#334155',
				'heading' => '#111827',
				'darkPrimary' => '#818cf8',
				'darkAccent' => '#38bdf8',
				'darkBackground' => '#111827',
				'darkText' => '#e5e7eb',
				'darkHeading' => '#ffffff',
			),
			'graphite_lime' => array(
				'primary' => '#84cc16',
				'secondary' => '#475569',
				'tertiary' => '#1f2937',
				'accent' => '#22c55e',
				'background' => '#111827',
				'text' => '#d1d5db',
				'heading' => '#f9fafb',
				'darkPrimary' => '#a3e635',
				'darkAccent' => '#4ade80',
				'darkBackground' => '#030712',
				'darkText' => '#e5e7eb',
				'darkHeading' => '#ffffff',
			),
			'warm_clay' => array(
				'primary' => '#b45309',
				'secondary' => '#a8a29e',
				'tertiary' => '#fed7aa',
				'accent' => '#0f766e',
				'background' => '#fffbf5',
				'text' => '#57534e',
				'heading' => '#292524',
				'darkPrimary' => '#f59e0b',
				'darkAccent' => '#2dd4bf',
				'darkBackground' => '#1c1917',
				'darkText' => '#e7e5e4',
				'darkHeading' => '#fff7ed',
			),
			'mono_ink' => array(
				'primary' => '#111827',
				'secondary' => '#6b7280',
				'tertiary' => '#e5e7eb',
				'accent' => '#b91c1c',
				'background' => '#ffffff',
				'text' => '#374151',
				'heading' => '#111827',
				'darkPrimary' => '#f9fafb',
				'darkAccent' => '#f87171',
				'darkBackground' => '#111827',
				'darkText' => '#d1d5db',
				'darkHeading' => '#ffffff',
			),
			'rose_berry' => array(
				'primary' => '#db2777',
				'secondary' => '#7c3aed',
				'tertiary' => '#fce7f3',
				'accent' => '#f97316',
				'background' => '#fff7fb',
				'text' => '#4a044e',
				'heading' => '#831843',
				'darkPrimary' => '#f472b6',
				'darkAccent' => '#fb923c',
				'darkBackground' => '#2e1065',
				'darkText' => '#fae8ff',
				'darkHeading' => '#ffffff',
			),
		);

		$selected = $palettes[$palette] ?? $palettes[self::default_palette_for_recipe( $recipe )] ?? $palettes['blue_teal'];

		if( $recipe === 'premium_dark' ) {
			$selected['background'] = $selected['darkBackground'];
			$selected['text'] = $selected['darkText'];
			$selected['heading'] = $selected['darkHeading'];
		}

		return $selected;
	}

	/**
	 * Convert palette colors into the site_globals color patch shape.
	 * The patch resets preset color selection so custom generated colors are visible.
	 */

	protected static function colors_patch( array $palette ): array {
		return array(
			'primary' => self::color_token( $palette['primary'], $palette['darkPrimary'] ),
			'secondary' => self::color_token( $palette['secondary'], $palette['secondary'] ),
			'tertiary' => self::color_token( $palette['tertiary'], $palette['tertiary'] ),
			'accent' => self::color_token( $palette['accent'], $palette['darkAccent'] ),
			'background' => self::color_token( $palette['background'], $palette['darkBackground'] ),
			'text' => self::color_token( $palette['text'], $palette['darkText'] ),
			'heading' => self::color_token( $palette['heading'], $palette['darkHeading'] ),
			'icon' => array(
				'base' => $palette['accent'],
			),
			'tooltip' => array(
				'base' => $palette['heading'],
			),
			'tooltipText' => array(
				'base' => $palette['background'],
			),
			'overlay' => array(
				'base' => '#000000',
			),
			'price' => array(
				'base' => $palette['accent'],
			),
		);
	}

	/**
	 * Build a site color token including default and alternate mode values.
	 * Used by generated global style patches to keep color modes paired.
	 */

	protected static function color_token( string $base, string $dark_base ): array {
		return array(
			'base' => $base,
			'colorMode' => array(
				'base' => $dark_base,
			),
		);
	}

	/**
	 * Resolve the global radius value for a shape recipe.
	 * Returns a CSS length string suitable for site global settings.
	 */

	protected static function radius_value( string $shape, string $recipe ): string {
		if( $shape === 'sharp' ) {
			return $recipe === 'editorial' ? '0.15rem' : '0.25rem';
		}

		if( $shape === 'pill' ) {
			return '1.5rem';
		}

		return $recipe === 'warm_minimal' ? '0.85rem' : '0.65rem';
	}

	/**
	 * Resolve spacing scale values for a density choice.
	 * Maps compact/comfortable/spacious recipes to controlled spacing tokens.
	 */

	protected static function spacing_values( string $density ): array {
		$values = array(
			'compact' => array( 'width' => '1180', 'spacing' => '1.5rem', 'padding' => '1.5rem 1.5rem 1.5rem 1.5rem', 'section' => '2.5rem', 'margin' => '1.25rem', 'gap' => '1rem' ),
			'comfortable' => array( 'width' => '1280', 'spacing' => '2rem', 'padding' => '2rem 2rem 2rem 2rem', 'section' => '3.25rem', 'margin' => '2rem', 'gap' => '1.25rem' ),
			'spacious' => array( 'width' => '1360', 'spacing' => '2.75rem', 'padding' => '2.5rem 2.5rem 2.5rem 2.5rem', 'section' => '4.25rem', 'margin' => '2.5rem', 'gap' => '1.75rem' ),
		);

		$selected = $values[$density] ?? $values['comfortable'];

		return array(
			'width' => $selected['width'],
			'spacing' => $selected['spacing'],
			'padding' => $selected['padding'],
			'paddingTop' => $selected['section'],
			'paddingRight' => $selected['spacing'],
			'paddingBottom' => $selected['section'],
			'paddingLeft' => $selected['spacing'],
			'margin' => $selected['margin'],
			'layoutGap' => $selected['gap'],
		);
	}

	/**
	 * Resolve typography settings for a recipe and intensity.
	 * Returns deterministic font-weight and scale choices for generated global styles.
	 */

	protected static function typography_values( string $recipe, string $intensity ): array {
		$heading_weight = $recipe === 'editorial' ? 700 : 760;
		$text_line_height = $recipe === 'editorial' ? '1.65' : '1.55';
		$heading_line_height = $recipe === 'editorial' ? '1.08' : '1.12';

		if( $intensity === 'subtle' ) {
			$heading_weight = max( 600, $heading_weight - 60 );
		} elseif( $intensity === 'bold' ) {
			$heading_weight = min( 900, $heading_weight + 60 );
		}

		return array(
			'text' => array(
				'weight' => 400,
				'lineHeight' => $text_line_height,
				'letterSpacing' => 'normal',
				'size' => array(
					'custom' => array(
						'min' => '16px',
						'max' => $recipe === 'editorial' ? '0.95rem' : '0.9rem',
					),
				),
			),
			'headings' => array(
				'weight' => $heading_weight,
				'lineHeight' => $heading_line_height,
				'letterSpacing' => 'normal',
				'size' => array(
					'custom' => array(
						'min' => $recipe === 'editorial' ? '22px' : '20px',
						'max' => $recipe === 'editorial' ? '2.3rem' : '2.05rem',
					),
				),
			),
		);
	}

	/**
	 * Build global button styling from palette and shape choices.
	 * Keeps generated button colors, radius, and contrast aligned with the selected recipe.
	 */

	protected static function button_values( array $palette, string $radius, string $shape ): array {
		$primary = array(
			'size' => '0',
			'padding' => $shape === 'pill' ? '0.85rem 1.35rem' : '0.8rem 1.1rem',
			'borderWidth' => '1px',
			'borderRadius' => $radius,
			'colors' => array(
				'text' => '#ffffff',
				'textHover' => '#ffffff',
				'border' => $palette['primary'],
				'borderHover' => $palette['accent'],
				'background' => $palette['primary'],
				'backgroundHover' => $palette['accent'],
			),
		);

		return array(
			'primary' => $primary,
			'secondary' => array(
				'size' => $primary['size'],
				'padding' => $primary['padding'],
				'borderWidth' => $primary['borderWidth'],
				'borderRadius' => $primary['borderRadius'],
				'colors' => array(
					'text' => $palette['heading'],
					'textHover' => '#ffffff',
					'border' => $palette['tertiary'],
					'borderHover' => $palette['secondary'],
					'background' => $palette['tertiary'],
					'backgroundHover' => $palette['secondary'],
				),
			),
			'tertiary' => array(
				'size' => $primary['size'],
				'padding' => $primary['padding'],
				'borderWidth' => $primary['borderWidth'],
				'borderRadius' => $primary['borderRadius'],
				'colors' => array(
					'text' => $palette['primary'],
					'textHover' => $palette['accent'],
					'border' => $palette['primary'],
					'borderHover' => $palette['accent'],
					'background' => 'rgba(0,0,0,0)',
					'backgroundHover' => 'rgba(0,0,0,0)',
				),
			),
			'ghost' => array(
				'size' => $primary['size'],
				'padding' => $primary['padding'],
				'borderWidth' => $primary['borderWidth'],
				'borderRadius' => $primary['borderRadius'],
				'colors' => array(
					'text' => $palette['text'],
					'textHover' => $palette['primary'],
					'border' => 'rgba(0,0,0,0)',
					'borderHover' => $palette['tertiary'],
					'background' => 'rgba(0,0,0,0)',
					'backgroundHover' => $palette['tertiary'],
				),
			),
		);
	}

	/**
	 * Build global form styling from palette and radius choices.
	 * Keeps inputs visually consistent with generated buttons and site colors.
	 */

	protected static function form_values( array $palette, string $radius ): array {
		return array(
			'size' => '0',
			'borderWidth' => '1px',
			'borderRadius' => $radius,
			'colors' => array(
				'text' => $palette['text'],
				'textHover' => $palette['heading'],
				'placeholder' => $palette['secondary'],
				'border' => $palette['tertiary'],
				'borderHover' => $palette['primary'],
				'background' => $palette['background'],
				'backgroundHover' => $palette['background'],
			),
		);
	}

}
