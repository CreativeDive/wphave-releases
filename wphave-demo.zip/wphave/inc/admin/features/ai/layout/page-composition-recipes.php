<?php

if( ! defined('ABSPATH') ) {
	exit;
}

/**
 * Renders semantic AI page plans through reusable layout recipes.
 *
 * Recipes are intentionally design-neutral: they only use existing global style
 * tokens and the Site Composition builder primitives. This gives generated
 * pages stronger layout variety without creating a new visual identity.
 */

class WPHAVE_AI_Page_Composition_Recipes extends WPHAVE_Site_Composition_Builder {

	/**
	 * Returns the supported abstract layout recipes.
	 *
	 * @return array
	 */

	public static function keys(): array {
		return array( 'poster-lead', 'catalog-index', 'dense-bento', 'editorial-stack', 'proof-first', 'alternating-story', 'campaign-flow', 'compact-service' );
	}

	/**
	 * Renders a sanitized page plan into serialized wphave block content.
	 *
	 * @param array $plan Sanitized page composition plan.
	 * @return string|WP_Error
	 */

	public static function render( array $plan ) {
		$sections = self::render_sections( $plan );

		if( is_wp_error( $sections ) ) {
			return $sections;
		}

		$content = array_filter( array_map( function( $section ) {
			return trim( (string) ( $section['content'] ?? '' ) );
		}, $sections ) );

		if( empty( $content ) ) {
			return new WP_Error( 'ai_page_composition_render_failed', __( 'The page content could not be rendered.', 'wphave' ), array( 'status' => 500 ) );
		}

		return implode( "\n\n", $content );
	}

	/**
	 * Renders every recipe section separately for interactive planner previews.
	 *
	 * @param array $plan Sanitized page composition plan.
	 * @return array|WP_Error
	 */

	public static function render_sections( array $plan ) {
		$sections = is_array( $plan['sections'] ?? null ) ? $plan['sections'] : array();
		if( empty( $sections ) ) {
			return new WP_Error( 'ai_page_composition_plan_empty', __( 'The generated page plan is empty.', 'wphave' ), array( 'status' => 400 ) );
		}

		$recipe = sanitize_key( $plan['composition']['layoutRecipe'] ?? '' );
		if( ! in_array( $recipe, self::keys(), true ) ) {
			$recipe = self::infer_recipe( $plan );
		}

		$sections = self::prepare_sections_for_rendering( $sections, $recipe );
		$content = array();
		if( $recipe === 'proof-first' ) {
			foreach( self::render_proof_first( $sections ) as $index => $rendered ) {
				if( trim( $rendered ) !== '' ) {
					$section = $sections[$index] ?? $sections[0];
					$content[] = WPHAVE_AI_Page_Composition_Plan::section_preview_item( $section, $index, trim( $rendered ) );
				}
			}
		} else {
			foreach( $sections as $index => $section ) {
				$rendered = $index === 0
					? self::render_lead( $section, $sections, $recipe )
					: self::render_body_section( $section, $index, $recipe );

				if( trim( $rendered ) !== '' ) {
					$content[] = WPHAVE_AI_Page_Composition_Plan::section_preview_item( $section, $index, trim( $rendered ) );
				}

				if( $index === 0 && count( $sections ) >= 4 && $recipe !== 'catalog-index' ) {
					$marquee = self::render_auto_marquee( $sections );
					if( trim( $marquee ) !== '' ) {
						$content[] = WPHAVE_AI_Page_Composition_Plan::section_preview_item( array(
							'id' => 'section-auto-marquee',
							'type' => 'features',
							'archetype' => 'marquee-strip',
							'layout' => 'band',
							'treatment' => 'strip',
							'heading' => __( 'Highlights', 'wphave' ),
						), 1, trim( $marquee ) );
					}
				}
			}
		}

		$content = array_filter( $content, function( $block ) {
			return trim( (string) ( $block['content'] ?? '' ) ) !== '';
		} );

		if( empty( $content ) ) {
			return new WP_Error( 'ai_page_composition_render_failed', __( 'The page content could not be rendered.', 'wphave' ), array( 'status' => 500 ) );
		}

		return array_values( $content );
	}

	/**
	 * Infers a layout recipe when the model did not choose one.
	 *
	 * @param array $plan Sanitized page composition plan.
	 * @return string
	 */

	protected static function infer_recipe( array $plan ): string {
		$composition = is_array( $plan['composition'] ?? null ) ? $plan['composition'] : array();
		$flow = sanitize_key( $composition['flow'] ?? '' );
		$rhythm = sanitize_key( $composition['rhythm'] ?? '' );
		$surface = sanitize_key( $composition['surface'] ?? '' );
		$sections = is_array( $plan['sections'] ?? null ) ? $plan['sections'] : array();
		$types = array_map( function( $section ) {
			return sanitize_key( $section['type'] ?? 'content' );
		}, $sections );

		if( in_array( 'stats', $types, true ) && array_search( 'stats', $types, true ) <= 2 ) {
			return 'proof-first';
		}

		if( $flow === 'editorial' || $surface === 'editorial' ) {
			return 'catalog-index';
		}

		if( $flow === 'conversion' ) {
			return 'campaign-flow';
		}

		if( $flow === 'compact' || count( $sections ) <= 3 ) {
			return 'compact-service';
		}

		if( $flow === 'narrative' ) {
			return 'alternating-story';
		}

		if( $rhythm === 'bold' ) {
			return 'dense-bento';
		}

		return 'poster-lead';
	}

	/**
	 * Renders the opening section according to the selected recipe.
	 *
	 * @param array $section First section.
	 * @param array $sections All sections.
	 * @param string $recipe Layout recipe key.
	 * @return string
	 */

	protected static function render_lead( array $section, array $sections, string $recipe ): string {
		$archetype = sanitize_key( $section['archetype'] ?? '' );
		$layout = sanitize_key( $section['layout'] ?? '' );
		$treatment = sanitize_key( $section['treatment'] ?? '' );

		if( in_array( $archetype, array( 'hero-editorial', 'editorial-note' ), true ) || $layout === 'editorial' || $treatment === 'editorial' ) {
			return self::lead_editorial_stack( $section );
		}

		if( $archetype === 'visual-showcase' || in_array( $treatment, array( 'dark', 'bold', 'glow' ), true ) ) {
			return self::lead_campaign( $section, $sections );
		}

		if( $layout === 'bento' || $archetype === 'bento-showcase' ) {
			return self::lead_dense_bento( $section, $sections );
		}

		if( $layout === 'split' || self::has_image( $section ) ) {
			return self::lead_poster( $section, $sections );
		}

		$lead_variant = self::lead_variant( $section, $recipe );
		if( $lead_variant === 'editorial-stack' ) {
			return self::lead_editorial_stack( $section );
		}
		if( $lead_variant === 'catalog-index' ) {
			return self::lead_catalog_index( $section, $sections );
		}
		if( $lead_variant === 'dense-bento' ) {
			return self::lead_dense_bento( $section, $sections );
		}
		if( $lead_variant === 'campaign-flow' ) {
			return self::lead_campaign( $section, $sections );
		}
		if( $lead_variant === 'poster-lead' ) {
			return self::lead_poster( $section, $sections );
		}

		switch( $recipe ) {
			case 'catalog-index':
				return self::lead_catalog_index( $section, $sections );

			case 'dense-bento':
				return self::lead_dense_bento( $section, $sections );

			case 'editorial-stack':
				return self::lead_editorial_stack( $section );

			case 'alternating-story':
				return self::lead_story( $section );

			case 'campaign-flow':
				return self::lead_campaign( $section, $sections );

			case 'compact-service':
				return self::lead_compact_service( $section, $sections );
		}

		return self::lead_poster( $section, $sections );
	}

	/**
	 * Lead variant.
	 *
	 * @param array $section Section.
	 * @param string $recipe Recipe.
	 * @return string Lead variant.
	 */

	protected static function lead_variant( array $section, string $recipe ): string {
		if( ! in_array( $recipe, array( 'poster-lead', 'compact-service' ), true ) ) {
			return '';
		}

		$title = strtolower( trim( self::heading_text( $section ) . ' ' . self::eyebrow( $section ) ) );
		if( $title === '' ) {
			return '';
		}

		$variants = array( 'poster-lead', 'editorial-stack', 'catalog-index', 'dense-bento', 'campaign-flow' );

		return $variants[abs( crc32( $title ) ) % count( $variants )];
	}

	/**
	 * Renders non-opening sections through recipe-aware section patterns.
	 *
	 * @param array $section Section data.
	 * @param int $index Section index.
	 * @param string $recipe Layout recipe key.
	 * @return string
	 */

	protected static function render_body_section( array $section, int $index, string $recipe ): string {
		$type = sanitize_key( $section['type'] ?? 'content' );
		$pattern = self::section_pattern( $section, $index, $recipe );

		switch( $pattern ) {
			case 'marquee-strip':
				return self::render_single_marquee_section( $section );

			case 'light-band':
				return self::render_light_band_section( $section, $index );

			case 'editorial-note':
				return self::render_editorial_note_section( $section, $index, $recipe );

			case 'split-story':
				return self::render_split_story_section( $section, $index, $recipe );

			case 'compact-list':
				return self::render_compact_list_section( $section, $index );

			case 'tabbed-content':
				return self::render_tabs_section( $section, $index );

			case 'visual-showcase':
				return self::render_visual_showcase_section( $section, $index );
		}

		if( $type === 'features' ) {
			return $recipe === 'catalog-index' || ( $section['layout'] ?? '' ) === 'masonry'
				? self::render_masonry_section( $section, $index )
				: self::render_bento_section( $section, $index, $recipe );
		}

		if( $type === 'steps' ) {
			return self::render_steps_section( $section, $index, $recipe );
		}

		if( $type === 'stats' ) {
			return self::render_stats_section( $section, $index, $recipe );
		}

		if( $type === 'testimonials' ) {
			return self::render_testimonial_section( $section, $index, $recipe );
		}

		if( $type === 'offers' ) {
			return self::render_offer_section( $section, $index, $recipe );
		}

		if( $type === 'faq' ) {
			return self::render_faq_section( $section, $index );
		}

		if( $type === 'cta' ) {
			return self::render_cta_section( $section, $index, $recipe );
		}

		return $recipe === 'alternating-story'
			? self::render_alternating_content( $section, $index )
			: self::render_story_panel( $section, $index, $recipe );
	}

	/**
	 * Normalizes section rhythm before rendering so AI output does not collapse
	 * into repeated card grids when adjacent sections choose similar options.
	 *
	 * @param array $sections Sanitized sections.
	 * @param string $recipe Active layout recipe.
	 * @return array
	 */

	protected static function prepare_sections_for_rendering( array $sections, string $recipe ): array {
		$previous_pattern = null;
		$previous_treatment = '';

		foreach( $sections as $index => &$section ) {
			if( $index === 0 ) {
				continue;
			}

			$pattern = self::section_pattern( $section, $index, $recipe );
			$treatment = sanitize_key( $section['treatment'] ?? '' );

			if( $previous_pattern !== null && $pattern === $previous_pattern ) {
				$section = self::section_with_pattern_offset( $section, $index, $recipe );
				$pattern = self::section_pattern( $section, $index, $recipe );
			}

			if( $treatment && $treatment === $previous_treatment ) {
				$section['treatment'] = self::alternate_treatment( $treatment, $index );
			}

			$previous_pattern = $pattern;
			$previous_treatment = sanitize_key( $section['treatment'] ?? '' );
		}
		unset( $section );

		return $sections;
	}

	/**
	 * Section with pattern offset.
	 *
	 * @param array $section Section.
	 * @param int $index Index.
	 * @param string $recipe Recipe.
	 * @return array Section with pattern offset.
	 */

	protected static function section_with_pattern_offset( array $section, int $index, string $recipe ): array {
		$type = sanitize_key( $section['type'] ?? 'content' );
		$layout_sets = array(
			'features' => array( 'bento', 'masonry', 'compact', 'grid' ),
			'content' => array( 'split', 'editorial', 'compact', 'panel', 'stacked', 'alternating' ),
			'steps' => array( 'alternating', 'timeline', 'compact', 'grid' ),
			'stats' => array( 'band', 'grid', 'panel', 'bento' ),
			'testimonials' => array( 'band', 'panel', 'grid' ),
			'offers' => array( 'cards', 'panel', 'compact' ),
			'faq' => array( 'split', 'stacked', 'panel' ),
			'cta' => array( 'band', 'panel', 'split' ),
		);
		$layouts = $layout_sets[$type] ?? $layout_sets['content'];
		$section['layout'] = $layouts[$index % count( $layouts )];

		if( $type === 'content' && $recipe === 'editorial-stack' ) {
			$section['archetype'] = $index % 2 ? 'editorial-note' : 'split-story';
		}

		return $section;
	}

	/**
	 * Alternate treatment.
	 *
	 * @param string $treatment Treatment.
	 * @param int $index Index.
	 * @return string Alternate treatment.
	 */

	protected static function alternate_treatment( string $treatment, int $index ): string {
		$options = array( 'blank', 'soft', 'outlined', 'editorial', 'elevated' );
		$filtered = array_values( array_filter( $options, function( $option ) use ( $treatment ) {
			return $option !== $treatment;
		} ) );

		return $filtered[$index % count( $filtered )];
	}

	/**
	 * Section pattern.
	 *
	 * @param array $section Section.
	 * @param int $index Index.
	 * @param string $recipe Recipe.
	 * @return string Section pattern.
	 */

	protected static function section_pattern( array $section, int $index, string $recipe ): string {
		$type = sanitize_key( $section['type'] ?? 'content' );
		$archetype = sanitize_key( $section['archetype'] ?? '' );
		$layout = sanitize_key( $section['layout'] ?? '' );
		$treatment = sanitize_key( $section['treatment'] ?? '' );

		if( $archetype === 'marquee-strip' || $layout === 'band' && $treatment === 'strip' ) {
			return 'marquee-strip';
		}

		if( $archetype === 'editorial-note' || $layout === 'editorial' ) {
			return 'editorial-note';
		}

		if( $archetype === 'split-story' || $layout === 'split' ) {
			return 'split-story';
		}

		if( $archetype === 'light-band' ) {
			return 'light-band';
		}

		if( $archetype === 'tabbed-content' ) {
			return 'tabbed-content';
		}

		if( $archetype === 'visual-showcase' ) {
			return 'visual-showcase';
		}

		if( $layout === 'compact' && in_array( $type, array( 'content', 'features', 'steps' ), true ) ) {
			return 'compact-list';
		}

		if( $layout === 'panel' && $type === 'content' && count( self::items( $section, 3 ) ) >= 3 ) {
			return 'tabbed-content';
		}

		if( in_array( $layout, array( 'stacked', 'band' ), true ) && in_array( $treatment, array( 'blank', 'soft' ), true ) && $index % 3 === 0 ) {
			return 'light-band';
		}

		if( $type === 'hero' || $archetype === 'hero-showcase' ) {
			return 'visual-showcase';
		}

		if( $type === 'content' && $recipe === 'catalog-index' && $index % 2 === 0 ) {
			return 'editorial-note';
		}

		return '';
	}

	/**
	 * Render single marquee section.
	 *
	 * @param array $section Section.
	 * @return string Render single marquee section.
	 */

	protected static function render_single_marquee_section( array $section ): string {
		$labels = array();
		foreach( self::items( $section, 4 ) as $item ) {
			if( ! empty( $item['title'] ) ) {
				$labels[] = $item['title'];
			}
		}

		if( empty( $labels ) ) {
			$labels = array_filter( array( self::eyebrow( $section ), self::heading_text( $section ), self::body( $section ) ) );
		}

		return empty( $labels ) ? '' : self::marquee( implode( ' / ', $labels ), array(
			'background' => self::dark_background(),
			'color' => self::dark_heading(),
			'padding' => 'var(--wphave-site-padding-xs) 0 var(--wphave-site-padding-xs) 0',
		) );
	}

	/**
	 * Render light band section.
	 *
	 * @param array $section Section.
	 * @param int $index Index.
	 * @return string Render light band section.
	 */

	protected static function render_light_band_section( array $section, int $index ): string {
		$content = self::flex(
			self::stack(
				( self::eyebrow( $section ) ? self::badge( self::eyebrow( $section ) ) : '' ) .
				self::heading( self::heading_text( $section ), 'h2', 'title-m' ),
				'var(--wphave-site-gap-size-m)'
			) .
			self::stack(
				( self::body( $section ) ? self::paragraph( self::body( $section ), 'text-l' ) : '' ) .
				self::actions( $section ),
				'var(--wphave-site-gap-size-m)'
			),
			self::gap_token( '3xl' ),
			'start',
			'space-between',
			'fill'
		);

		return self::section( $content, array(
			'background' => $index % 2 ? 'transparent' : self::section_background( $index ),
			'padding' => self::section_padding( '2xl', '2xl' ),
		) );
	}

	/**
	 * Render editorial note section.
	 *
	 * @param array $section Section.
	 * @param int $index Index.
	 * @param string $recipe Recipe.
	 * @return string Render editorial note section.
	 */

	protected static function render_editorial_note_section( array $section, int $index, string $recipe ): string {
		$items = self::section_items( $section );
		$note_items = '';
		foreach( array_slice( $items, 0, 3 ) as $item_index => $item ) {
			$note_items .= self::stack(
				self::paragraph( str_pad( (string) ( $item_index + 1 ), 2, '0', STR_PAD_LEFT ), 'text-xs', self::light_text(), 'none', [
					'formats' => [ 'bold', 'uppercase' ],
					'letterSpacing' => '0.12em',
				] ) .
				self::heading( $item['title'] ?? '', 'h3', 'title-xs', self::light_heading() ) .
				self::paragraph( $item['text'] ?? '', 'text-s', self::light_text() ),
				'0.35rem'
			);
		}

		$note = self::surface(
			self::stack(
				self::paragraph( self::eyebrow( $section, __( 'Note', 'wphave' ) ), 'text-xs', self::light_text(), 'none', [
					'formats' => [ 'bold', 'uppercase' ],
					'letterSpacing' => '0.12em',
				] ) .
				self::heading( self::heading_text( $section ), 'h2', $recipe === 'catalog-index' ? 'title-l' : 'title-m', self::light_heading() ) .
				( self::body( $section ) ? self::paragraph( self::body( $section ), 'text-l', self::light_text() ) : '' ),
				'var(--wphave-site-gap-size-m)'
			),
			array(
				'treatment' => 'editorial-paper',
				'padding' => self::inset( 'xl' ),
				'radius' => '0px',
			)
		);

		return self::section(
			self::grid_areas(
				$note .
				self::stack( $note_items . self::actions( $section ), 'var(--wphave-site-gap-size-l)' ),
				array(
					'columns' => 7,
					'rows' => 3,
					'rowHeight' => 'auto',
					'areas' => array(
						array( 'id' => 'c1', 'label' => '1', 'x' => 1, 'y' => 1, 'w' => 4, 'h' => 3 ),
						array( 'id' => 'c2', 'label' => '2', 'x' => 5, 'y' => 1, 'w' => 3, 'h' => 3 ),
					),
				),
				self::gap_token( '3xl' ),
				array( 'mobile' => [ 'layout' => [ 'gridAreas' => [ 'areas' => self::linear_areas( 2 ) ] ] ] )
			),
			array(
				'background' => self::section_background( $index ),
				'padding' => self::section_padding( '3xl', '3xl' ),
			)
		);
	}

	/**
	 * Render split story section.
	 *
	 * @param array $section Section.
	 * @param int $index Index.
	 * @param string $recipe Recipe.
	 * @return string Render split story section.
	 */

	protected static function render_split_story_section( array $section, int $index, string $recipe ): string {
		$items = self::section_items( $section );
		$side = count( $items ) > 1 && ! self::has_image( $section )
			? self::surface(
				self::stack(
					self::badge( self::eyebrow( $section, __( 'Focus', 'wphave' ) ) ) .
					self::grid( self::story_mini_cards( $items ), 1, '12px' ),
					'var(--wphave-site-gap-size-m)'
				),
				array(
					'background' => 'var(--wphave-site-color-background)',
					'padding' => self::inset( 'l' ),
					'treatment' => $recipe === 'campaign-flow' ? 'gradient-border' : 'soft-card',
				)
			)
			: self::visual_panel_from_section( $section, '360px', 'patterned-section' );

		return self::section(
			self::flex(
				self::stack(
					( self::eyebrow( $section ) ? self::badge( self::eyebrow( $section ) ) : '' ) .
					self::heading( self::heading_text( $section ), 'h2', $index % 2 ? 'title-l' : 'title-m' ) .
					( self::body( $section ) ? self::paragraph( self::body( $section ), 'text-l' ) : '' ) .
					self::actions( $section ),
					'var(--wphave-site-gap-size-l)'
				) .
				$side,
				self::gap_token( '3xl' ),
				'center',
				'space-between',
				'fill'
			),
			array(
				'background' => self::section_background( $index ),
				'padding' => self::section_padding( '3xl', '3xl' ),
			)
		);
	}

	/**
	 * Render compact list section.
	 *
	 * @param array $section Section.
	 * @param int $index Index.
	 * @return string Render compact list section.
	 */

	protected static function render_compact_list_section( array $section, int $index ): string {
		$items = self::section_items( $section );
		if( empty( $items ) ) {
			return self::render_light_band_section( $section, $index );
		}

		$rows = '';
		foreach( array_slice( $items, 0, 5 ) as $item_index => $item ) {
			$rows .= self::flex(
				self::paragraph( str_pad( (string) ( $item_index + 1 ), 2, '0', STR_PAD_LEFT ), 'text-s', 'var(--wphave-site-color-heading)', 'none', [
					'formats' => [ 'bold' ],
				] ) .
				self::stack(
					self::heading( $item['title'] ?? '', 'h3', 'title-xs' ) .
					self::paragraph( $item['text'] ?? '', 'text-s' ),
					'0.25rem'
				),
				'var(--wphave-site-gap-size-m)',
				'start',
				'start',
				'auto',
				array(
					'dimensions' => [ 'spacing' => [ 'padding' => '0px 0px 18px 0px' ] ],
				)
			);
		}

		return self::section(
			self::grid_areas(
				self::section_intro( $section ) .
				self::stack( $rows . self::actions( $section ), 'var(--wphave-site-gap-size-m)' ),
				array(
					'columns' => 6,
					'rows' => 1,
					'rowHeight' => 'auto',
					'areas' => array(
						array( 'id' => 'c1', 'label' => '1', 'x' => 1, 'y' => 1, 'w' => 2, 'h' => 1 ),
						array( 'id' => 'c2', 'label' => '2', 'x' => 3, 'y' => 1, 'w' => 4, 'h' => 1 ),
					),
				),
				self::gap_token( '3xl' ),
				array( 'mobile' => [ 'layout' => [ 'gridAreas' => [ 'areas' => self::linear_areas( 2 ) ] ] ] )
			),
			array(
				'background' => $index % 2 ? 'transparent' : self::section_background( $index ),
				'padding' => self::section_padding( '2xl', '2xl' ),
			)
		);
	}

	/**
	 * Render tabs section.
	 *
	 * @param array $section Section.
	 * @param int $index Index.
	 * @return string Render tabs section.
	 */

	protected static function render_tabs_section( array $section, int $index ): string {
		$tab_items = array();
		foreach( array_slice( self::section_items( $section ), 0, 4 ) as $item ) {
			$tab_items[] = array(
				'title' => $item['title'] ?? '',
				'content' => self::paragraph( $item['text'] ?? '' ),
			);
		}

		if( empty( $tab_items ) ) {
			return self::render_light_band_section( $section, $index );
		}

		return self::section(
			self::surface(
				self::flex(
					self::section_intro( $section ) .
					self::tabs( $tab_items ),
					self::gap_token( '3xl' ),
					'start',
					'space-between',
					'fill'
				),
				array(
					'background' => 'var(--wphave-site-color-background)',
					'padding' => self::inset( 'xl' ),
					'treatment' => 'soft-card',
				)
			),
			array(
				'background' => self::section_background( $index ),
				'padding' => self::section_padding( '3xl', '3xl' ),
			)
		);
	}

	/**
	 * Render visual showcase section.
	 *
	 * @param array $section Section.
	 * @param int $index Index.
	 * @return string Render visual showcase section.
	 */

	protected static function render_visual_showcase_section( array $section, int $index ): string {
		return self::section(
			self::surface(
				self::grid_areas(
					self::stack(
						( self::eyebrow( $section ) ? self::badge( self::eyebrow( $section ), self::dark_badge_args() ) : '' ) .
						self::heading( self::heading_text( $section ), 'h2', 'title-l', self::dark_heading() ) .
						( self::body( $section ) ? self::paragraph( self::body( $section ), 'text-l', self::dark_text() ) : '' ) .
						self::actions( $section ),
						'var(--wphave-site-gap-size-l)'
					) .
					self::visual_panel_from_section( $section, '360px', 'patterned-section' ),
					array(
						'columns' => 7,
						'rows' => 3,
						'rowHeight' => 'auto',
						'areas' => array(
							array( 'id' => 'c1', 'label' => '1', 'x' => 1, 'y' => 1, 'w' => 4, 'h' => 3 ),
							array( 'id' => 'c2', 'label' => '2', 'x' => 5, 'y' => 1, 'w' => 3, 'h' => 3 ),
						),
					),
					self::gap_token( '3xl' ),
					array( 'mobile' => [ 'layout' => [ 'gridAreas' => [ 'areas' => self::linear_areas( 2 ) ] ] ] )
				),
				self::dark_surface_args( array(
					'padding' => self::inset( 'xl' ),
				) )
			),
			array(
				'background' => 'transparent',
				'padding' => self::section_padding( '3xl', '3xl' ),
			)
		);
	}

	/**
	 * Renders a poster-like lead without forcing a split hero.
	 *
	 * @param array $section Lead section.
	 * @param array $sections All sections.
	 * @return string
	 */

	protected static function lead_poster( array $section, array $sections ): string {
		$side = self::has_image( $section )
			? self::visual_panel_from_section( $section, '420px' )
			: self::surface(
				self::stack(
					self::badge( self::eyebrow( $section, __( 'Selected', 'wphave' ) ) ) .
					self::heading( self::heading_text( $section ), 'h3', 'title-s' ) .
					( self::body( $section ) ? self::paragraph( self::body( $section ) ) : '' ) .
					self::grid( self::metric_cards_from_sections( $sections ), 2, '14px' ),
					'var(--wphave-site-gap-size-m)'
				),
				array(
					'treatment' => 'gradient-border',
					'background' => 'var(--wphave-site-color-background)',
					'padding' => self::inset( 'l' ),
				)
			);

		return self::section(
			self::grid_areas(
				self::stack(
					( ! empty( $section['eyebrow'] ) ? self::badge( $section['eyebrow'] ) : '' ) .
					self::heading( self::heading_text( $section ), 'h1', 'title-xl', 'var(--wphave-site-color-heading)', 'none', array( 'lineHeight' => '0.96' ) ) .
					( self::body( $section ) ? self::paragraph( self::body( $section ), 'text-l' ) : '' ) .
					self::actions( $section ),
					'var(--wphave-site-gap-size-l)'
				) .
				$side,
				array(
					'columns' => 7,
					'rows' => 3,
					'rowHeight' => 'auto',
					'areas' => array(
						array( 'id' => 'c1', 'label' => '1', 'x' => 1, 'y' => 1, 'w' => 4, 'h' => 3 ),
						array( 'id' => 'c2', 'label' => '2', 'x' => 5, 'y' => 1, 'w' => 3, 'h' => 3 ),
					),
				),
				self::gap_token( '3xl' ),
				array( 'mobile' => [ 'layout' => [ 'gridAreas' => [ 'areas' => self::linear_areas( 2 ) ] ] ] )
			),
			array(
				'padding' => self::section_padding( '4xl', '3xl' ),
				'wphave' => self::treatment( 'patterned-section', array(
					'text' => mb_strtoupper( mb_substr( self::heading_text( $section ), 0, 8 ) ),
					'textColor' => 'rgba(0,0,0,0.05)',
				) ),
			)
		);
	}

	/**
	 * Renders a catalog/index lead with stacked side notes.
	 *
	 * @param array $section Lead section.
	 * @param array $sections All sections.
	 * @return string
	 */

	protected static function lead_catalog_index( array $section, array $sections ): string {
		$note = self::surface(
			self::stack(
				self::heading( self::eyebrow( $section, __( 'Note', 'wphave' ) ), 'h3', 'title-s', self::dark_heading() ) .
				self::paragraph( self::body( $section ) ?: self::heading_text( $section ), 'default', self::dark_text() ),
				'var(--wphave-site-gap-size-m)'
			),
			array(
				'background' => self::dark_background(),
				'padding' => self::inset( 'm' ),
				'radius' => '0px',
			)
		);
		$index = self::has_image( $section )
			? self::visual_panel_from_section( $section, '430px', 'editorial-paper' )
			: self::surface(
				self::stack(
					self::badge( __( 'Index', 'wphave' ), array(
						'background' => 'var(--wphave-site-color-tertiary)',
						'color' => self::surface_colors( 'tertiary-contrast' )['badgeText'],
						'radius' => '0px',
					) ) .
					self::heading( self::heading_text( $section ), 'h3', 'title-m', self::light_heading() ) .
					( self::body( $section ) ? self::paragraph( self::body( $section ), 'default', self::light_text() ) : '' ) .
					self::grid( self::metric_cards_from_sections( $sections ), 2, '14px' ),
					'var(--wphave-site-gap-size-m)'
				),
				array(
					'treatment' => 'editorial-paper',
					'padding' => self::inset( 'l' ),
					'radius' => '0px',
				)
			);

		return self::section(
			self::grid_areas(
				self::stack(
					( ! empty( $section['eyebrow'] ) ? self::badge( $section['eyebrow'], array( 'radius' => '0px' ) ) : '' ) .
					self::heading( self::heading_text( $section ), 'h1', 'title-xl', 'var(--wphave-site-color-heading)', 'none', array( 'lineHeight' => '0.98' ) ) .
					( self::body( $section ) ? self::paragraph( self::body( $section ), 'text-l' ) : '' ) .
					self::actions( $section ),
					'var(--wphave-site-gap-size-l)'
				) .
				$note .
				$index,
				array(
					'columns' => 7,
					'rows' => 4,
					'rowHeight' => 'auto',
					'areas' => array(
						array( 'id' => 'c1', 'label' => '1', 'x' => 1, 'y' => 1, 'w' => 4, 'h' => 4 ),
						array( 'id' => 'c2', 'label' => '2', 'x' => 5, 'y' => 1, 'w' => 3, 'h' => 1 ),
						array( 'id' => 'c3', 'label' => '3', 'x' => 5, 'y' => 2, 'w' => 3, 'h' => 3 ),
					),
				),
				self::gap_token( '2xl' ),
				array( 'mobile' => [ 'layout' => [ 'gridAreas' => [ 'areas' => self::linear_areas( 3 ) ] ] ] )
			),
			array(
				'padding' => self::section_padding( '4xl', '3xl' ),
				'wphave' => self::treatment( 'patterned-section', array(
					'text' => __( 'INDEX', 'wphave' ),
					'textColor' => 'rgba(0,0,0,0.05)',
				) ),
			)
		);
	}

	/**
	 * Renders a dense bento lead where the hero lives inside an asymmetric grid.
	 *
	 * @param array $section Lead section.
	 * @param array $sections All sections.
	 * @return string
	 */

	protected static function lead_dense_bento( array $section, array $sections ): string {
		$items = self::items_from_sections( $sections, 4 );
		$cards = array(
			self::surface(
				self::stack(
					( ! empty( $section['eyebrow'] ) ? self::badge( $section['eyebrow'], self::dark_badge_args() ) : '' ) .
					self::heading( self::heading_text( $section ), 'h1', 'title-xl', self::dark_heading(), 'none', array( 'lineHeight' => '0.94' ) ) .
					( self::body( $section ) ? self::paragraph( self::body( $section ), 'text-l', self::dark_text() ) : '' ) .
					self::actions( $section ),
					'var(--wphave-site-gap-size-l)'
				),
				self::dark_surface_args( array(
					'padding' => self::inset( 'xl' ),
				) )
			),
		);

		foreach( array_slice( $items, 0, 4 ) as $index => $item ) {
			$primary_colors = self::surface_colors( 'primary-contrast' );
			$is_primary_card = $index === 0;
			$cards[] = self::surface(
				self::stack(
					self::heading( $item['title'] ?? '', 'h3', 'title-s', $is_primary_card ? $primary_colors['heading'] : 'var(--wphave-site-color-heading)' ) .
					self::paragraph( $item['text'] ?? '', 'default', $is_primary_card ? $primary_colors['text'] : 'var(--wphave-site-color-text)' ),
					'var(--wphave-site-gap-size-m)'
				),
				array(
					'background' => $is_primary_card ? $primary_colors['background'] : self::card_background( $index ),
					'padding' => $index === 0 ? self::inset( 'l' ) : self::inset( 'm' ),
				)
			);
		}

		return self::section(
			self::bento_grid( $cards, array(), '18px' ),
			array(
				'padding' => self::section_padding( '4xl' ),
			)
		);
	}

	/**
	 * Renders a quiet editorial lead with no forced visual side.
	 *
	 * @param array $section Lead section.
	 * @return string
	 */

	protected static function lead_editorial_stack( array $section ): string {
		return self::section(
			self::stack(
				( ! empty( $section['eyebrow'] ) ? self::badge( $section['eyebrow'] ) : '' ) .
				self::heading( self::heading_text( $section ), 'h1', 'title-xl', 'var(--wphave-site-color-heading)', 'none', array( 'lineHeight' => '0.98' ) ) .
				( self::body( $section ) ? self::paragraph( self::body( $section ), 'text-l' ) : '' ) .
				self::actions( $section ),
				'var(--wphave-site-gap-size-l)',
				array( 'dimensions' => [ 'width' => [ 'limit' => 'max', 'custom' => '840px' ] ] )
			),
			array(
				'padding' => self::section_padding( '4xl', '3xl' ),
			)
		);
	}

	/**
	 * Renders a narrative lead with the first note offset from the headline.
	 *
	 * @param array $section Lead section.
	 * @return string
	 */

	protected static function lead_story( array $section ): string {
		$paper_colors = self::surface_colors( 'paper' );
		$note = self::surface(
			self::paragraph( self::body( $section ) ?: self::heading_text( $section ), 'text-l', $paper_colors['text'] ),
			array(
				'treatment' => 'editorial-paper',
				'treatmentArgs' => [ 'background' => $paper_colors['background'] ],
				'padding' => self::inset( 'm' ),
			)
		);

		return self::section(
			self::alternately(
				self::stack(
					( ! empty( $section['eyebrow'] ) ? self::badge( $section['eyebrow'] ) : '' ) .
					self::heading( self::heading_text( $section ), 'h1', 'title-xl', 'var(--wphave-site-color-heading)', 'none', array( 'lineHeight' => '0.98' ) ) .
					self::actions( $section ),
					'var(--wphave-site-gap-size-l)'
				) .
				$note,
				'76%',
				self::gap_token( '2xl' )
			),
			array(
				'padding' => self::section_padding( '4xl', '3xl' ),
			)
		);
	}

	/**
	 * Renders a campaign lead with a strong panel and side proof.
	 *
	 * @param array $section Lead section.
	 * @param array $sections All sections.
	 * @return string
	 */

	protected static function lead_campaign( array $section, array $sections ): string {
		$side = self::has_image( $section )
			? self::visual_panel_from_section( $section, '380px', 'dark' )
			: self::grid( self::metric_cards_from_sections( $sections, true ), 2, '14px' );

		return self::section(
			self::surface(
				self::flex(
					self::stack(
						( ! empty( $section['eyebrow'] ) ? self::badge( $section['eyebrow'], self::dark_badge_args() ) : '' ) .
						self::heading( self::heading_text( $section ), 'h1', 'title-xl', self::dark_heading(), 'none', array( 'lineHeight' => '0.94' ) ) .
						( self::body( $section ) ? self::paragraph( self::body( $section ), 'text-l', self::dark_text() ) : '' ) .
						self::actions( $section ),
						'var(--wphave-site-gap-size-l)'
					) .
					$side,
					self::gap_token( '3xl' ),
					'center',
					'space-between',
					'fill'
				),
				self::dark_surface_args( array(
					'padding' => self::inset( 'xl' ),
				) )
			),
			array(
				'padding' => self::section_padding( '3xl' ),
			)
		);
	}

	/**
	 * Renders a compact service lead with immediate navigation cards.
	 *
	 * @param array $section Lead section.
	 * @param array $sections All sections.
	 * @return string
	 */

	protected static function lead_compact_service( array $section, array $sections ): string {
		$items = self::section_summaries_from_sections( $sections, 3 );
		$cards = '';
		foreach( array_slice( $items, 0, 3 ) as $index => $item ) {
			$colors = self::intentional_card_colors( $index, $index === 1 ? 'secondary-contrast' : '' );
			$cards .= self::surface(
				self::stack(
					self::heading( $item['title'] ?? '', 'h3', 'title-s', $colors['heading'] ) .
					self::paragraph( $item['text'] ?? '', 'default', $colors['text'] ),
					'var(--wphave-site-gap-size-m)'
				),
				array(
					'background' => $colors['background'],
					'border' => [ 'color' => $colors['border'] ],
					'padding' => self::inset( 'm' ),
				)
			);
		}

		return self::section(
			self::stack(
				self::stack(
					( ! empty( $section['eyebrow'] ) ? self::badge( $section['eyebrow'] ) : '' ) .
					self::heading( self::heading_text( $section ), 'h1', 'title-l' ) .
					( self::body( $section ) ? self::paragraph( self::body( $section ), 'text-l' ) : '' ) .
					self::actions( $section ),
					'var(--wphave-site-gap-size-l)',
					array( 'dimensions' => [ 'width' => [ 'limit' => 'max', 'custom' => '760px' ] ] )
				) .
				self::grid( $cards, min( 3, max( 1, count( $items ) ) ), '18px' ),
				'var(--wphave-site-gap-size-xl)'
			),
			array(
				'padding' => self::section_padding( '3xl' ),
			)
		);
	}

	/**
	 * Renders a proof-first flow by moving metrics before the lead when available.
	 *
	 * @param array $sections Plan sections.
	 * @return array
	 */

	protected static function render_proof_first( array $sections ): array {
		$content = array();
		$stats_index = null;

		foreach( $sections as $index => $section ) {
			if( sanitize_key( $section['type'] ?? '' ) === 'stats' ) {
				$stats_index = $index;
				break;
			}
		}

		if( $stats_index !== null ) {
			$content[] = self::render_stats_section( $sections[$stats_index], 0, 'proof-first' );
		}

		foreach( $sections as $index => $section ) {
			if( $index === $stats_index ) {
				continue;
			}

			$content[] = $index === 0
				? self::lead_compact_service( $section, $sections )
				: self::render_body_section( $section, $index, 'proof-first' );
		}

		return $content;
	}

	/**
	 * Render bento section.
	 *
	 * @param array $section Section.
	 * @param int $index Index.
	 * @param string $recipe Recipe.
	 * @return string Render bento section.
	 */

	protected static function render_bento_section( array $section, int $index, string $recipe ): string {
		$items = self::items( $section, 4 );
		$cards = array();

		foreach( $items as $item_index => $item ) {
			$is_primary_card = $item_index === 0 && $recipe === 'dense-bento';
			$is_accent_card = ! $is_primary_card && $item_index === 1;
			$colors = self::intentional_card_colors( $item_index, $is_primary_card ? 'primary-contrast' : ( $is_accent_card ? 'accent-contrast' : '' ) );
			$cards[] = self::surface(
				self::stack(
					self::heading( $item['title'] ?? '', 'h3', 'title-s', $colors['heading'] ) .
					self::paragraph( $item['text'] ?? '', 'default', $colors['text'] ),
					'var(--wphave-site-gap-size-m)'
				),
				array(
					'background' => $colors['background'],
					'border' => [ 'color' => $colors['border'] ],
					'padding' => $item_index === 0 ? self::inset( 'l' ) : self::inset( 'm' ),
				)
			);
		}

		return self::bento_section( self::section_header( $section ), $cards, array(
			'background' => self::section_background( $index ),
			'contentGap' => 'var(--wphave-site-gap-size-xl)',
		) );
	}

	/**
	 * Render masonry section.
	 *
	 * @param array $section Section.
	 * @param int $index Index.
	 * @return string Render masonry section.
	 */

	protected static function render_masonry_section( array $section, int $index): string {
		$cards = '';
		foreach( self::items( $section, 4 ) as $item_index => $item ) {
			$is_tertiary_card = $item_index === 1;
			$colors = self::intentional_card_colors( $item_index, $is_tertiary_card ? 'tertiary-contrast' : '' );
			$cards .= self::surface(
				self::stack(
					self::heading( $item['title'] ?? '', 'h3', 'title-s', $colors['heading'] ) .
					self::paragraph( $item['text'] ?? '', 'default', $colors['text'] ),
					'var(--wphave-site-gap-size-m)'
				),
				array(
					'background' => $colors['background'],
					'padding' => $item_index % 2 ? self::inset( 'xl' ) : self::inset( 'l' ),
					'radius' => '0px',
					'border' => [ 'color' => $colors['border'] ],
				)
			);
		}

		return self::section(
			self::stack(
				self::section_intro( $section ) .
				self::masonry( $cards, 3, '18px' ),
				'var(--wphave-site-gap-size-xl)'
			),
			array(
				'background' => self::section_background( $index ),
			)
		);
	}

	/**
	 * Render steps section.
	 *
	 * @param array $section Section.
	 * @param int $index Index.
	 * @param string $recipe Recipe.
	 * @return string Render steps section.
	 */

	protected static function render_steps_section( array $section, int $index, string $recipe ): string {
		$steps = array();
		foreach( self::items( $section, 3 ) as $step_index => $step ) {
			$colors = self::intentional_card_colors( $step_index, $step_index === 1 ? 'accent-contrast' : '' );
			$steps[] = array_replace( $step, array(
				'titleColor' => $colors['heading'],
				'textColor' => $colors['text'],
				'surface' => array(
					'treatment' => '',
					'background' => $colors['background'],
					'border' => [ 'color' => $colors['border'] ],
					'padding' => self::inset( 'm' ),
					'radius' => '18px',
				),
			) );
		}
		$badge_colors = self::surface_colors( 'accent-contrast' );

		return self::process_section( $steps, array(
			'background' => self::section_background( $index ),
			'itemWidth' => $recipe === 'alternating-story' ? '66%' : '72%',
			'badgeBackground' => $badge_colors['badgeBackground'],
			'badgeColor' => $badge_colors['badgeText'],
		) );
	}

	/**
	 * Render stats section.
	 *
	 * @param array $section Section.
	 * @param int $index Index.
	 * @param string $recipe Recipe.
	 * @return string Render stats section.
	 */

	protected static function render_stats_section( array $section, int $index, string $recipe ): string {
		if( ! self::has_section_items( $section ) ) {
			return self::render_light_band_section( $section, $index );
		}

		$dark = in_array( $recipe, array( 'campaign-flow', 'proof-first' ), true );
		$cards = '';
		foreach( self::items( $section, 3 ) as $item_index => $item ) {
			$accent_colors = self::intentional_card_colors( $item_index, $item_index === 2 ? 'tertiary-contrast' : '' );
			$cards .= self::metric_card( self::metric_number( $item, $item_index ), $item['title'] ?? '', $item['text'] ?? '', $dark ? array(
				'background' => self::dark_card_background(),
				'numberColor' => self::dark_heading(),
				'labelColor' => self::dark_heading(),
				'detailColor' => self::dark_text(),
			) : array(
				'background' => $accent_colors['background'],
				'numberColor' => $accent_colors['heading'],
				'labelColor' => $accent_colors['heading'],
				'detailColor' => $accent_colors['text'],
			) );
		}

		$content = self::stack(
			( $dark ? self::section_intro_dark( $section ) : self::section_intro( $section ) ) .
			self::grid( $cards, min( 4, max( 1, count( self::items( $section, 3 ) ) ) ), '18px' ),
			'var(--wphave-site-gap-size-xl)'
		);

		return self::section(
			$dark ? self::surface( $content, self::dark_surface_args( array(
				'padding' => self::inset( 'xl' ),
			) ) ) : $content,
			array(
				'background' => $dark ? 'transparent' : self::section_background( $index ),
			)
		);
	}

	/**
	 * Render testimonial section.
	 *
	 * @param array $section Section.
	 * @param int $index Index.
	 * @param string $recipe Recipe.
	 * @return string Render testimonial section.
	 */

	protected static function render_testimonial_section( array $section, int $index, string $recipe ): string {
		$dark = in_array( $recipe, array( 'campaign-flow', 'proof-first' ), true );
		$cards = '';
		foreach( self::items( $section, 2 ) as $item_index => $item ) {
			$cards .= self::testimonial_card( $item['text'] ?? '', $item['title'] ?? __( 'Customer', 'wphave' ), self::eyebrow( $section ), $dark ? array(
				'background' => self::dark_card_background(),
				'quoteColor' => self::dark_heading(),
				'nameColor' => self::dark_heading(),
				'metaColor' => self::dark_text(),
			) : array(
				'background' => self::card_background( $item_index ),
			) );
		}

		return self::section(
			self::stack(
				( $dark ? self::section_intro_dark( $section ) : self::section_intro( $section ) ) .
				self::swiper( $cards, 2, '20px' ),
				'var(--wphave-site-gap-size-xl)'
			),
			array(
				'background' => $dark ? self::dark_background() : self::section_background( $index ),
				'wphave' => $dark ? self::dark_section_background() : array(),
			)
		);
	}

	/**
	 * Render offer section.
	 *
	 * @param array $section Section.
	 * @param int $index Index.
	 * @param string $recipe Recipe.
	 * @return string Render offer section.
	 */

	protected static function render_offer_section( array $section, int $index, string $recipe ): string {
		$cards = '';
		foreach( array_slice( self::items( $section, 3 ), 0, 3 ) as $item_index => $item ) {
			$features = array_filter( array_map( 'trim', preg_split( '/[.;]\s*/', (string) ( $item['text'] ?? '' ) ) ) );
			$features = ! empty( $features ) ? array_slice( $features, 0, 4 ) : array( $item['text'] ?? '' );

			$dark = in_array( $recipe, array( 'campaign-flow', 'proof-first' ), true );
			$featured_colors = self::surface_colors( 'primary-contrast' );
			$is_featured = $item_index === 1;
			$cards .= self::pricing_card( $item['title'] ?? '', (string) self::metric_number( $item, $item_index ), $features, array(
				'featured' => $is_featured,
				'badge' => $is_featured ? __( 'Recommended', 'wphave' ) : '',
				'badgeArgs' => $is_featured ? array(
					'background' => $featured_colors['badgeBackground'],
					'color' => $featured_colors['badgeText'],
				) : array(),
				'text' => self::body( $section ),
				'button' => ! empty( $section['actions'][0]['label'] ) ? $section['actions'][0]['label'] : __( 'Learn more', 'wphave' ),
				'buttonVariant' => $item_index === 2 ? 'secondary' : 'primary',
				'background' => $dark ? self::dark_card_background() : 'var(--wphave-site-color-background)',
				'titleColor' => $dark ? self::dark_heading() : 'var(--wphave-site-color-heading)',
				'priceColor' => $dark ? self::dark_heading() : 'var(--wphave-site-color-heading)',
				'textColor' => $dark ? self::dark_text() : 'var(--wphave-site-color-text)',
				'border' => $is_featured && ! $dark ? [ 'color' => $featured_colors['border'] ] : [],
			) );
		}

		return self::section(
			self::stack(
				self::section_intro( $section ) .
				self::grid( $cards, 3, '20px' ),
				'var(--wphave-site-gap-size-xl)'
			),
			array( 'background' => self::section_background( $index ) )
		);
	}

	/**
	 * Render faq section.
	 *
	 * @param array $section Section.
	 * @param int $index Index.
	 * @return string Render faq section.
	 */

	protected static function render_faq_section( array $section, int $index ): string {
		$items = array_map( function( $item ) {
			return array(
				'title' => $item['title'] ?? '',
				'content' => self::paragraph( $item['text'] ?? '' ),
			);
		}, self::items( $section, 4 ) );

		return self::section(
			self::flex(
				self::section_intro( $section ) .
				self::accordion( $items ),
				self::gap_token( '3xl' ),
				'start',
				'space-between',
				'fill'
			),
			array( 'background' => self::section_background( $index ) )
		);
	}

	/**
	 * Render cta section.
	 *
	 * @param array $section Section.
	 * @param int $index Index.
	 * @param string $recipe Recipe.
	 * @return string Render cta section.
	 */

	protected static function render_cta_section( array $section, int $index, string $recipe ): string {
		$split = in_array( $recipe, array( 'campaign-flow', 'alternating-story' ), true ) || self::has_image( $section );
		$content = self::stack(
			self::section_intro( $section, $split ? 'none' : 'center' ) .
			self::actions( $section, $split ? 'start' : 'center' ),
			'var(--wphave-site-gap-size-l)',
			$split ? array() : array( 'text' => [ 'align' => 'center' ] )
		);

		if( $split ) {
			$content = self::flex(
				$content .
				self::visual_panel_from_section( $section, '260px' ),
				self::gap_token( '3xl' ),
				'center',
				'space-between',
				'fill'
			);
		}

		return self::section(
			self::surface( $content, array(
				'treatment' => 'gradient-border',
				'background' => 'var(--wphave-site-color-background)',
				'padding' => self::inset( 'xl' ),
			) ),
			array( 'background' => self::section_background( $index ) )
		);
	}

	/**
	 * Render alternating content.
	 *
	 * @param array $section Section.
	 * @param int $index Index.
	 * @return string Render alternating content.
	 */

	protected static function render_alternating_content( array $section, int $index ): string {
		$items = self::items( $section, 3 );
		$cards = '';
		foreach( $items as $item_index => $item ) {
			$colors = self::intentional_card_colors( $item_index, $item_index === 0 ? 'secondary-contrast' : '' );
			$cards .= self::surface(
				self::stack(
					self::badge( str_pad( (string) ( $item_index + 1 ), 2, '0', STR_PAD_LEFT ), array(
						'background' => $colors['badgeBackground'],
						'color' => $colors['badgeText'],
					) ) .
					self::heading( $item['title'] ?? '', 'h3', 'title-s', $colors['heading'] ) .
					self::paragraph( $item['text'] ?? '', 'default', $colors['text'] ),
					'var(--wphave-site-gap-size-m)'
				),
				array(
					'background' => $colors['background'],
					'border' => [ 'color' => $colors['border'] ],
					'padding' => self::inset( 'm' ),
				)
			);
		}

		return self::section(
			self::stack(
				self::section_intro( $section ) .
				self::alternately( $cards, '68%' ),
				'var(--wphave-site-gap-size-xl)'
			),
			array( 'background' => self::section_background( $index ) )
		);
	}

	/**
	 * Render story panel.
	 *
	 * @param array $section Section.
	 * @param int $index Index.
	 * @param string $recipe Recipe.
	 * @return string Render story panel.
	 */

	protected static function render_story_panel( array $section, int $index, string $recipe ): string {
		$items = self::items( $section, 3 );
		$cards = '';
		foreach( $items as $item_index => $item ) {
			$colors = self::intentional_card_colors( $item_index, $item_index === 1 ? 'tertiary-contrast' : '' );
			$cards .= self::surface(
				self::stack(
					self::heading( $item['title'] ?? '', 'h3', 'title-s', $colors['heading'] ) .
					self::paragraph( $item['text'] ?? '', 'default', $colors['text'] ),
					'var(--wphave-site-gap-size-m)'
				),
				array(
					'background' => $colors['background'],
					'border' => [ 'color' => $colors['border'] ],
					'padding' => $recipe === 'editorial-stack' ? self::inset( 'm' ) : self::inset( 'l' ),
				)
			);
		}

		$content = self::stack(
			self::section_intro( $section ) .
			( count( $items ) > 0 ? self::grid( $cards, min( 3, count( $items ) ), '20px' ) : '' ) .
			self::actions( $section ),
			'var(--wphave-site-gap-size-xl)'
		);

		if( self::has_image( $section ) ) {
			$content = self::flex(
				$content .
				self::visual_panel_from_section( $section, '340px' ),
				self::gap_token( '3xl' ),
				'center',
				'space-between',
				'fill'
			);
		}

		return self::section(
			$content,
			array( 'background' => self::section_background( $index ) )
		);
	}

	/**
	 * Determine whether the section contains an image.
	 *
	 * @param array $section Section.
	 * @return bool Determine whether image.
	 */

	protected static function has_image( array $section ): bool {
		return ! empty( $section['imageId'] );
	}

	/**
	 * Visual panel from section.
	 *
	 * @param array $section Section.
	 * @param string $height Height.
	 * @param string $fallback_treatment Fallback treatment.
	 * @return string Visual panel from section.
	 */

	protected static function visual_panel_from_section( array $section, string $height = '320px', string $fallback_treatment = 'patterned-section' ): string {
		if( self::has_image( $section ) ) {
			return self::surface( self::spacer( $height ), array(
				'treatment' => 'soft-card',
				'wphave' => [
					'background' => [
						'layers' => [
							self::background_media_layer( absint( $section['imageId'] ), [ 'fit' => 'cover' ] ),
							self::background_overlay_layer( '#000000', 0.08 ),
						],
					],
				],
			) );
		}

		return self::surface( self::spacer( $height ), array(
			'treatment' => $fallback_treatment,
			'treatmentArgs' => [
				'text' => mb_substr( self::heading_text( $section ), 0, 16 ),
			],
		) );
	}

	/**
	 * Render auto marquee.
	 *
	 * @param array $sections Sections.
	 * @return string Render auto marquee.
	 */

	protected static function render_auto_marquee( array $sections ): string {
		$labels = array();
		foreach( array_slice( $sections, 1, 5 ) as $section ) {
			$label = self::eyebrow( $section ) ?: self::heading_text( $section );
			if( $label ) {
				$labels[] = $label;
			}
		}

		if( empty( $labels ) ) {
			return '';
		}

		return self::marquee( implode( ' / ', $labels ), array(
			'background' => self::dark_background(),
			'color' => self::dark_heading(),
			'padding' => 'var(--wphave-site-padding-xs) 0 var(--wphave-site-padding-xs) 0',
		) );
	}

	/**
	 * Section intro.
	 *
	 * @param array $section Section.
	 * @param string $align Align.
	 * @return string Section intro.
	 */

	protected static function section_intro( array $section, string $align = 'none' ): string {
		return self::stack(
			( ! empty( $section['eyebrow'] ) ? self::badge( $section['eyebrow'] ) : '' ) .
			( self::heading_text( $section ) ? self::heading( self::heading_text( $section ), 'h2', 'title-l', 'var(--wphave-site-color-heading)', $align ) : '' ) .
			( self::body( $section ) ? self::paragraph( self::body( $section ), 'text-l', 'var(--wphave-site-color-text)', $align ) : '' ),
			'var(--wphave-site-gap-size-m)',
			array( 'dimensions' => [ 'width' => [ 'limit' => 'max', 'custom' => '780px' ] ] )
		);
	}

	/**
	 * Section intro dark.
	 *
	 * @param array $section Section.
	 * @param string $align Align.
	 * @return string Section intro dark.
	 */

	protected static function section_intro_dark( array $section, string $align = 'none' ): string {
		return self::stack(
			( ! empty( $section['eyebrow'] ) ? self::badge( $section['eyebrow'], self::dark_badge_args() ) : '' ) .
			( self::heading_text( $section ) ? self::heading( self::heading_text( $section ), 'h2', 'title-l', self::dark_heading(), $align ) : '' ) .
			( self::body( $section ) ? self::paragraph( self::body( $section ), 'text-l', self::dark_text(), $align ) : '' ),
			'var(--wphave-site-gap-size-m)',
			array( 'dimensions' => [ 'width' => [ 'limit' => 'max', 'custom' => '780px' ] ] )
		);
	}

	/**
	 * Section header.
	 *
	 * @param array $section Section.
	 * @return array Section header.
	 */

	protected static function section_header( array $section ): array {
		return array(
			'badge' => self::eyebrow( $section ),
			'title' => self::heading_text( $section ),
			'text' => self::body( $section ),
		);
	}

	/**
	 * Items.
	 *
	 * @param array $section Section.
	 * @param int $count Count.
	 * @return array Items.
	 */

	protected static function items( array $section, int $count ): array {
		$items = self::section_items( $section );
		if( ! empty( $items ) ) {
			return $items;
		}

		$output = array();
		$labels = self::fallback_item_labels( $section, $count );
		for( $index = 0; $index < $count; $index++ ) {
			$output[] = array(
				'title' => $labels[$index] ?? sprintf( __( 'Detail %d', 'wphave' ), $index + 1 ),
				'text' => self::body( $section ),
			);
		}

		return $output;
	}

	/**
	 * Section items.
	 *
	 * @param array $section Section.
	 * @return array Section items.
	 */

	protected static function section_items( array $section ): array {
		$items = is_array( $section['items'] ?? null ) ? $section['items'] : array();

		return array_values( array_filter( $items, function( $item ) {
			return is_array( $item ) && ( trim( (string) ( $item['title'] ?? '' ) ) !== '' || trim( (string) ( $item['text'] ?? '' ) ) !== '' );
		} ) );
	}

	/**
	 * Determine whether section items.
	 *
	 * @param array $section Section.
	 * @return bool Determine whether section items.
	 */

	protected static function has_section_items( array $section ): bool {
		return ! empty( self::section_items( $section ) );
	}

	/**
	 * Fallback item labels.
	 *
	 * @param array $section Section.
	 * @param int $count Count.
	 * @return array Fallback item labels.
	 */

	protected static function fallback_item_labels( array $section, int $count ): array {
		$type = sanitize_key( $section['type'] ?? 'content' );
		$sets = array(
			'features' => array( __( 'Core value', 'wphave' ), __( 'Useful detail', 'wphave' ), __( 'Visitor benefit', 'wphave' ), __( 'Next proof', 'wphave' ) ),
			'steps' => array( __( 'Discover', 'wphave' ), __( 'Structure', 'wphave' ), __( 'Decide', 'wphave' ), __( 'Start', 'wphave' ) ),
			'stats' => array( __( 'Reach', 'wphave' ), __( 'Trust', 'wphave' ), __( 'Momentum', 'wphave' ), __( 'Outcome', 'wphave' ) ),
			'testimonials' => array( __( 'Customer signal', 'wphave' ), __( 'Proof point', 'wphave' ), __( 'Result', 'wphave' ) ),
			'offers' => array( __( 'Essential', 'wphave' ), __( 'Recommended', 'wphave' ), __( 'Advanced', 'wphave' ) ),
			'faq' => array( __( 'What matters first?', 'wphave' ), __( 'How does it work?', 'wphave' ), __( 'What happens next?', 'wphave' ), __( 'Who is it for?', 'wphave' ) ),
			'cta' => array( __( 'Clear next step', 'wphave' ), __( 'Low-friction contact', 'wphave' ) ),
			'content' => array( __( 'Context', 'wphave' ), __( 'Perspective', 'wphave' ), __( 'Evidence', 'wphave' ), __( 'Next step', 'wphave' ) ),
		);
		$labels = $sets[$type] ?? $sets['content'];

		return array_slice( $labels, 0, $count );
	}

	/**
	 * Items from sections.
	 *
	 * @param array $sections Sections.
	 * @param int $count Count.
	 * @return array Items from sections.
	 */

	protected static function items_from_sections( array $sections, int $count ): array {
		$items = array();
		foreach( array_slice( $sections, 1 ) as $section ) {
			if( ! empty( $section['items'] ) && is_array( $section['items'] ) ) {
				foreach( $section['items'] as $item ) {
					$items[] = $item;
				}
			} elseif( ! empty( $section['heading'] ) ) {
				$items[] = array(
					'title' => $section['heading'],
					'text' => $section['body'] ?? '',
				);
			}

			if( count( $items ) >= $count ) {
				break;
			}
		}

		if( empty( $items ) && ! empty( $sections[0] ) ) {
			$items[] = array(
				'title' => self::eyebrow( $sections[0], __( 'Overview', 'wphave' ) ),
				'text' => self::body( $sections[0] ) ?: self::heading_text( $sections[0] ),
			);
			$items[] = array(
				'title' => __( 'Next step', 'wphave' ),
				'text' => self::heading_text( $sections[0] ),
			);
		}

		return array_slice( $items, 0, $count );
	}

	/**
	 * Section summaries from sections.
	 *
	 * @param array $sections Sections.
	 * @param int $count Count.
	 * @return array Section summaries from sections.
	 */

	protected static function section_summaries_from_sections( array $sections, int $count ): array {
		$items = array();

		foreach( array_slice( $sections, 1 ) as $section ) {
			if( ! empty( $section['heading'] ) ) {
				$items[] = array(
					'title' => $section['heading'],
					'text' => $section['body'] ?? '',
				);
			}

			if( count( $items ) >= $count ) {
				break;
			}
		}

		if( empty( $items ) ) {
			return self::items_from_sections( $sections, $count );
		}

		return array_slice( $items, 0, $count );
	}

	/**
	 * Story mini cards.
	 *
	 * @param array $items Items.
	 * @return string Story mini cards.
	 */

	protected static function story_mini_cards( array $items ): string {
		$cards = '';
		foreach( array_slice( $items, 0, 3 ) as $index => $item ) {
			$colors = self::intentional_card_colors( $index, $index === 1 ? 'secondary-contrast' : '' );
			$cards .= self::surface(
				self::stack(
					self::heading( $item['title'] ?? '', 'h3', 'title-xs', $colors['heading'] ) .
					self::paragraph( $item['text'] ?? '', 'text-s', $colors['text'] ),
					'0.35rem'
				),
				array(
					'background' => $colors['background'],
					'border' => [ 'color' => $colors['border'] ],
					'padding' => self::inset( 's' ),
					'radius' => '14px',
				)
			);
		}

		return $cards;
	}

	/**
	 * Metric cards from sections.
	 *
	 * @param array $sections Sections.
	 * @param bool $dark Dark.
	 * @return string Metric cards from sections.
	 */

	protected static function metric_cards_from_sections( array $sections, bool $dark = false ): string {
		$cards = '';
		foreach( self::items_from_sections( $sections, 4 ) as $index => $item ) {
			$colors = self::intentional_card_colors( $index, $index === 1 ? 'accent-contrast' : '' );
			$cards .= self::metric_card( self::metric_number( $item, $index ), $item['title'] ?? '', $item['text'] ?? '', $dark ? array(
				'background' => self::dark_card_background(),
				'numberColor' => self::dark_heading(),
				'labelColor' => self::dark_heading(),
				'detailColor' => self::dark_text(),
				'padding' => self::inset( 's' ),
			) : array(
				'background' => $colors['background'],
				'numberColor' => $colors['heading'],
				'labelColor' => $colors['heading'],
				'detailColor' => $colors['text'],
				'padding' => self::inset( 's' ),
			) );
		}

		return $cards;
	}

	/**
	 * Actions.
	 *
	 * @param array $section Section.
	 * @param string $align Align.
	 * @return string Actions.
	 */

	protected static function actions( array $section, string $align = 'start' ): string {
		if( empty( $section['actions'] ) || ! is_array( $section['actions'] ) ) {
			return '';
		}

		return self::button_row( $section['actions'], '0.75rem', array(
			'layout' => [ 'flex' => [ 'alignHorizontal' => $align ] ],
		) );
	}

	/**
	 * Heading text.
	 *
	 * @param array $section Section.
	 * @return string Heading text.
	 */

	protected static function heading_text( array $section ): string {
		return (string) ( $section['heading'] ?? '' );
	}

	/**
	 * Body.
	 *
	 * @param array $section Section.
	 * @return string Body.
	 */

	protected static function body( array $section ): string {
		return (string) ( $section['body'] ?? '' );
	}

	/**
	 * Eyebrow.
	 *
	 * @param array $section Section.
	 * @param string $fallback Fallback.
	 * @return string Eyebrow.
	 */

	protected static function eyebrow( array $section, string $fallback = '' ): string {
		return (string) ( $section['eyebrow'] ?? $fallback );
	}

	/**
	 * Metric number.
	 *
	 * @param array $item Item.
	 * @param int $index Index.
	 * @return int Metric number.
	 */

	protected static function metric_number( array $item, int $index ): int {
		$number = (int) preg_replace( '/\D+/', '', (string) ( $item['title'] ?? '' ) );

		return max( 1, $number ?: ( $index + 1 ) * 10 );
	}

	/**
	 * Section background.
	 *
	 * @param int $index Index.
	 * @return string Section background.
	 */

	protected static function section_background( int $index ): string {
		if( $index % 3 === 1 ) {
			return 'var(--wphave-site-color-background-subtle-2)';
		}

		return 'transparent';
	}

	/**
	 * Card background.
	 *
	 * @param int $index Index.
	 * @return string Card background.
	 */

	protected static function card_background( int $index ): string {
		$colors = array(
			'var(--wphave-site-color-background-subtle-2)',
			'var(--wphave-site-color-background-contrast-2)',
			'var(--wphave-site-color-background-subtle-3)',
		);

		return $colors[$index % count( $colors )];
	}

	/**
	 * Intentional card colors.
	 *
	 * @param int $index Index.
	 * @param string $surface Surface.
	 * @return array Intentional card colors.
	 */

	protected static function intentional_card_colors( int $index, string $surface = '' ): array {
		$colors = self::surface_colors( 'default' );
		$accent = $surface ? self::surface_colors( $surface ) : $colors;

		return array(
			'background' => self::card_background( $index ),
			'heading' => $colors['heading'],
			'text' => $colors['text'],
			'badgeBackground' => $accent['badgeBackground'],
			'badgeText' => $accent['badgeText'],
			'border' => $surface ? $accent['border'] : $colors['border'],
		);
	}

	/**
	 * Dark background.
	 *
	 * @return string Dark background.
	 */

	protected static function dark_background(): string {
		$colors = self::surface_colors( 'background-contrast' );

		return $colors['background'];
	}

	/**
	 * Dark card background.
	 *
	 * @return string Dark card background.
	 */

	protected static function dark_card_background(): string {
		$colors = self::surface_colors( 'background-contrast' );

		return $colors['cardBackground'];
	}

	/**
	 * Dark heading.
	 *
	 * @return string Dark heading.
	 */

	protected static function dark_heading(): string {
		$colors = self::surface_colors( 'background-contrast' );

		return $colors['heading'];
	}

	/**
	 * Dark text.
	 *
	 * @return string Dark text.
	 */

	protected static function dark_text(): string {
		$colors = self::surface_colors( 'background-contrast' );

		return $colors['text'];
	}

	/**
	 * Light heading.
	 *
	 * @return string Light heading.
	 */

	protected static function light_heading(): string {
		$colors = self::surface_colors( 'paper' );

		return $colors['heading'];
	}

	/**
	 * Light text.
	 *
	 * @return string Light text.
	 */

	protected static function light_text(): string {
		$colors = self::surface_colors( 'paper' );

		return $colors['text'];
	}

	/**
	 * Dark badge args.
	 *
	 * @return array Dark badge args.
	 */

	protected static function dark_badge_args(): array {
		$colors = self::surface_colors( 'background-contrast' );

		return array(
			'background' => $colors['badgeBackground'],
			'color' => $colors['badgeText'],
		);
	}

	/**
	 * Dark section background.
	 *
	 * @return array Dark section background.
	 */

	protected static function dark_section_background(): array {
		return self::background( self::dark_background(), array(
			self::background_gradient_layer( self::gradient( 'rgba(255,255,255,0.08)', 'rgba(255,255,255,0.02)', 135 ) ),
		) );
	}

	/**
	 * Dark surface args.
	 *
	 * @param array $args Function arguments.
	 * @return array Dark surface args.
	 */

	protected static function dark_surface_args( array $args = array() ): array {
		return array_replace_recursive( array(
			'background' => self::dark_background(),
			'wphave' => self::dark_section_background(),
		), $args );
	}

}
