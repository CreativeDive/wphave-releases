<?php

if( ! defined('ABSPATH') ) {
	exit;
}

/**
 * Renders AI page plans through the Site Composition builder grammar.
 *
 * AI only supplies semantic page structure and copy. This renderer owns the
 * actual wphave block markup so generated pages stay aligned with the current
 * global styles and the same block-building primitives used by Site Compositions.
 */

class WPHAVE_AI_Page_Composition_Plan extends WPHAVE_Site_Composition_Builder {

	protected const SECTION_TYPES = [ 'hero', 'features', 'content', 'steps', 'stats', 'testimonials', 'offers', 'faq', 'cta' ];

	/**
	 * Returns the AI-facing contract for page content generation.
	 *
	 * @return array
	 */

	public static function contract_payload(): array {
		return array(
			'planShape' => array(
				'version' => 1,
				'intent' => 'short page intent',
				'summary' => 'short layout summary',
				'composition' => array(
					'density' => 'compact|balanced|spacious',
					'rhythm' => 'calm|varied|bold',
					'surface' => 'blank|soft|outlined|elevated|bold|dark|editorial|glass|glow|framed',
					'contrast' => 'low|medium|high',
					'flow' => 'showcase|editorial|modular|conversion|narrative|compact',
					'layoutRecipe' => 'poster-lead|catalog-index|dense-bento|editorial-stack|proof-first|alternating-story|campaign-flow|compact-service',
				),
				'sections' => array(
					array(
						'type' => 'hero|features|content|steps|stats|testimonials|offers|faq|cta',
						'archetype' => 'hero-showcase|hero-editorial|visual-showcase|marquee-strip|light-band|bento-showcase|split-story|tabbed-content|process-alternating|proof-band|testimonial-band|offer-cards|compact-metrics|framed-cta|editorial-note',
						'layout' => 'centered|split|grid|bento|stacked|panel|masonry|alternating|timeline|cards|compact|band|editorial',
						'treatment' => 'blank|soft|outlined|elevated|bold|dark|editorial|glass|glow|framed|strip',
						'emphasis' => 'low|medium|high',
						'eyebrow' => 'optional short label',
						'heading' => 'required section heading',
						'body' => 'optional section body',
						'items' => array(
							array(
								'title' => 'item title',
								'text' => 'item text',
							),
						),
						'actions' => array(
							array(
								'label' => 'button label',
								'variant' => 'primary|secondary|tertiary',
								'url' => '',
							),
						),
						'imageBrief' => 'optional image generation brief',
					),
				),
				'blockTree' => class_exists( 'WPHAVE_AI_Block_Design_Compiler' ) ? WPHAVE_AI_Block_Design_Compiler::contract_payload()['rootShape'] : array(),
				'ast' => class_exists( 'WPHAVE_AI_Composition_Compiler' ) ? WPHAVE_AI_Composition_Compiler::contract_payload()['rootShape'] : array(),
			),
			'blockDesignTreeContract' => class_exists( 'WPHAVE_AI_Block_Design_Compiler' ) ? WPHAVE_AI_Block_Design_Compiler::contract_payload() : array(),
			'compositionAstContract' => class_exists( 'WPHAVE_AI_Composition_Compiler' ) ? WPHAVE_AI_Composition_Compiler::contract_payload() : array(),
			'currentStyleContext' => self::current_style_context(),
			'rules' => array(
				'Return semantic page structure only, never block markup, CSS, HTML, JavaScript, PHP, Gutenberg comments, or wphave attributes.',
				'Respect currentStyleContext. Do not invent a new visual identity for page content planning.',
				'Use final user-facing copy in the same language as the user prompt.',
				'Prefer blockTree for Website Planner wireframes when a custom design is needed. blockTree is a safe design language that maps spacing, background, width, radius, border, grid, flex and typography to WPHAVE attributes.',
				'Use blockTree like HTML/CSS thinking without raw CSS: section, stack, flex, grid, surface, heading, paragraph, visual, actions. Choose padding, background, width, gap, radius and alignment deliberately.',
				'Prefer ast for custom layouts. The AST is the WPHAVE composition language and supports new combinations without needing a fixed pattern.',
				'Use ast.kind page with root-level section or hero nodes. Use section nodes with grid, split, stack, card, notification, stats, tabs, visual and action children where useful.',
				'Use the legacy sections array as a planning summary and fallback; ast is the preferred render source when you can express the layout there.',
				'Use composition and section treatment as abstract design direction. Do not use industry presets like SaaS, fitness, restaurant, studio, campaign or commerce as design categories.',
				'Use composition.flow to control the whole page dramaturgy: showcase, editorial, modular, conversion, narrative, or compact.',
				'Use composition.layoutRecipe to choose an abstract page architecture. This controls layout only, not colors, fonts, or a new brand identity.',
				'Use section archetype for the actual composition pattern. Prefer archetypes over generic type/layout when a designed section is possible.',
				'Layout recipes mean: poster-lead starts with a typographic poster and side proof, catalog-index starts with an index-like asymmetric grid, dense-bento starts inside a bento composition, editorial-stack starts text-first, proof-first starts with metrics, alternating-story uses staggered narrative sections, campaign-flow uses a strong panel and conversion rhythm, compact-service starts with a concise service overview.',
				'Strong flows can include hero-showcase, visual-showcase, marquee-strip, light-band, bento-showcase, split-story, tabbed-content, process-alternating, proof-band, testimonial-band, offer-cards and framed-cta. Use these to create the kind of varied page composition a human designer would build.',
				'Use light-band for quiet breathing room, tabbed-content for grouped explanations, visual-showcase when a page needs a large visual/proof moment, and editorial-note for typography-led content.',
				'Choose treatments by visual need: blank means no visible surface, soft is a subtle background, outlined is border-led, elevated is card-like, bold/dark/glow are high-contrast moments, editorial is paper-like, framed is a large contained composition.',
				'Do not duplicate the same headings and item set across the hero/lead and the next body section. Lead cards should summarize or navigate the page, while body sections should add new detail.',
				'Choose the amount of content from the user intent instead of normalizing every page to the same length. Use 3 to 4 sections only for very simple focused pages, 5 to 7 for standard pages, and 6 to 9 only for broad landing or service pages.',
				'Vary item density by section purpose. Some sections may have no items, compact proof sections may have 2 to 4 items, rich feature sections may have 4 to 8 items, and FAQ sections should only appear when questions are useful.',
				'Vary the page rhythm. Do not repeat the same layout and treatment pattern in consecutive sections. Use split, bento, masonry, alternating, panel, compact, band, or editorial layouts where they fit the content.',
				'Use concise headings and place longer explanation in body or items.',
				'Use actions only where a visitor would naturally need a next step.',
				'Use imageBrief only when planningOptions.generateImages is true or a visual section clearly benefits from generated imagery.',
			),
		);
	}

	/**
	 * Sanitizes an AI page composition plan.
	 *
	 * @param mixed $plan Raw model plan.
	 * @return array
	 */

	public static function sanitize( $plan ): array {
		if( ! is_array( $plan ) ) {
			return array();
		}

		$composition = self::sanitize_composition( $plan['composition'] ?? array() );
		$sections = array();
		foreach( array_slice( $plan['sections'] ?? array(), 0, 8 ) as $section ) {
			if( ! is_array( $section ) ) {
				continue;
			}

			$type = sanitize_key( $section['type'] ?? $section['role'] ?? 'content' );
			if( ! in_array( $type, self::SECTION_TYPES, true ) ) {
				$type = 'content';
			}

			$clean = array(
				'id' => self::section_id( $section['id'] ?? '', count( $sections ), $section ),
				'type' => $type,
				'archetype' => self::sanitize_archetype( $section['archetype'] ?? '' ),
				'layout' => self::sanitize_layout( $section['layout'] ?? $section['variant'] ?? self::default_variant( $type ), $type ),
				'treatment' => self::sanitize_treatment( $section['treatment'] ?? '' ),
				'emphasis' => self::sanitize_choice( $section['emphasis'] ?? '', array( 'low', 'medium', 'high' ), '' ),
				'eyebrow' => self::text( $section['eyebrow'] ?? $section['slots']['eyebrow'] ?? '', 90 ),
				'heading' => self::text( $section['heading'] ?? $section['slots']['heading'] ?? '', 180 ),
				'body' => self::textarea( $section['body'] ?? $section['slots']['body'] ?? '', 800 ),
				'items' => self::sanitize_items( $section['items'] ?? array() ),
				'actions' => self::sanitize_actions( $section['actions'] ?? array() ),
				'imageBrief' => self::textarea( $section['imageBrief'] ?? '', 260 ),
				'imageId' => absint( $section['imageId'] ?? 0 ),
			);

			if( $clean['heading'] === '' && empty( $clean['items'] ) ) {
				continue;
			}

			$sections[] = array_filter( $clean, function( $value ) {
				return $value !== '' && $value !== array() && $value !== null;
			} );
		}

		$block_tree = self::normalize_block_tree( $plan );
		$has_block_tree = class_exists( 'WPHAVE_AI_Block_Design_Compiler' ) && ! empty( $block_tree['nodes'] );
		$has_ast = class_exists( 'WPHAVE_AI_Composition_Compiler' ) && is_array( $plan['ast'] ?? null ) && ! empty( $plan['ast']['nodes'] );

		if( empty( $sections ) && ! $has_ast && ! $has_block_tree ) {
			return array();
		}

		if( ! empty( $sections ) ) {
			$sections = self::balance_section_variants( $sections, $composition );
			$sections = self::balance_section_archetypes( $sections, $composition );
		}

		$result = array(
			'version' => 1,
			'intent' => self::textarea( $plan['intent'] ?? '', 180 ),
			'summary' => self::textarea( $plan['summary'] ?? '', 260 ),
			'composition' => $composition,
			'sections' => $sections,
		);

		if( $has_ast ) {
			$result['ast'] = $plan['ast'];
		}

		if( $has_block_tree ) {
			$result['blockTree'] = $block_tree;
		}

		return $result;
	}

	/**
	 * Renders a sanitized page composition plan to serialized wphave block content.
	 *
	 * @param mixed $plan Raw or sanitized plan.
	 * @return string|WP_Error
	 */

	public static function render( $plan ) {
		$plan = self::sanitize( $plan );
		if( empty( $plan['sections'] ) && empty( $plan['ast']['nodes'] ) && empty( $plan['blockTree']['nodes'] ) ) {
			return new WP_Error( 'ai_page_composition_plan_empty', __( 'The generated page plan is empty.', 'wphave' ), array( 'status' => 400 ) );
		}

		if( class_exists( 'WPHAVE_AI_Block_Design_Compiler' ) && is_array( $plan['blockTree'] ?? null ) && ! empty( $plan['blockTree']['nodes'] ) ) {
			$compiled = WPHAVE_AI_Block_Design_Compiler::compile( $plan['blockTree'] );
			if( ! is_wp_error( $compiled ) && trim( (string) $compiled ) !== '' ) {
				return $compiled;
			}
		}

		if( class_exists( 'WPHAVE_AI_Composition_Compiler' ) && is_array( $plan['ast'] ?? null ) && ! empty( $plan['ast']['nodes'] ) ) {
			$compiled = WPHAVE_AI_Composition_Compiler::compile( $plan['ast'] );
			if( ! is_wp_error( $compiled ) && trim( (string) $compiled ) !== '' ) {
				return $compiled;
			}
		}

		if( class_exists( 'WPHAVE_AI_Page_Composition_Recipes' ) ) {
			return WPHAVE_AI_Page_Composition_Recipes::render( $plan );
		}

		$content = array();
		foreach( $plan['sections'] as $index => $section ) {
			$rendered = self::render_section( $section, $index );
			if( trim( $rendered ) !== '' ) {
				$content[] = trim( $rendered );
			}

			if( $index === 0 && count( $plan['sections'] ) >= 4 ) {
				$marquee = self::has_archetype( $plan['sections'], 'marquee-strip' ) ? '' : self::render_marquee( $plan['sections'] );
				if( trim( $marquee ) !== '' ) {
					$content[] = $marquee;
				}
			}
		}

		if( empty( $content ) ) {
			return new WP_Error( 'ai_page_composition_render_failed', __( 'The page content could not be rendered.', 'wphave' ), array( 'status' => 500 ) );
		}

		return implode( "\n\n", $content );
	}

	/**
	 * Renders every plan section separately for interactive Website Planner previews.
	 *
	 * @param mixed $plan Raw or sanitized plan.
	 * @return array|WP_Error
	 */

	public static function render_sections( $plan ) {
		$plan = self::sanitize( $plan );
		if( empty( $plan['sections'] ) && empty( $plan['ast']['nodes'] ) && empty( $plan['blockTree']['nodes'] ) ) {
			return new WP_Error( 'ai_page_composition_plan_empty', __( 'The generated page plan is empty.', 'wphave' ), array( 'status' => 400 ) );
		}

		if( class_exists( 'WPHAVE_AI_Block_Design_Compiler' ) && is_array( $plan['blockTree'] ?? null ) && ! empty( $plan['blockTree']['nodes'] ) ) {
			$compiled = WPHAVE_AI_Block_Design_Compiler::compile_sections( $plan['blockTree'] );
			if( ! empty( $compiled ) ) {
				return $compiled;
			}
		}

		if( class_exists( 'WPHAVE_AI_Composition_Compiler' ) && is_array( $plan['ast'] ?? null ) && ! empty( $plan['ast']['nodes'] ) ) {
			$compiled = WPHAVE_AI_Composition_Compiler::compile_sections( $plan['ast'] );
			if( ! empty( $compiled ) ) {
				return $compiled;
			}
		}

		if( class_exists( 'WPHAVE_AI_Page_Composition_Recipes' ) ) {
			return WPHAVE_AI_Page_Composition_Recipes::render_sections( $plan );
		}

		$sections = array();
		foreach( $plan['sections'] as $index => $section ) {
			$rendered = self::render_section( $section, $index );
			if( trim( $rendered ) === '' ) {
				continue;
			}

			$sections[] = self::section_preview_item( $section, $index, $rendered );
		}

		return $sections;
	}

	/**
	 * Returns non-blocking quality diagnostics for a sanitized page plan.
	 *
	 * Diagnostics are intentionally advisory. Rendering remains tolerant because
	 * AI output can be useful even when it is imperfect, but these checks give
	 * tests and future review tools one small place to inspect plan quality.
	 *
	 * @param mixed $plan Raw or sanitized page composition plan.
	 * @return array
	 */

	public static function diagnostics( $plan ): array {
		$plan = self::sanitize( $plan );
		$sections = is_array( $plan['sections'] ?? null ) ? $plan['sections'] : array();
		$warnings = array();

		if( count( $sections ) < 3 ) {
			$warnings[] = 'too_few_sections';
		}

		$seen_headings = array();
		foreach( $sections as $index => $section ) {
			$heading_key = sanitize_title( $section['heading'] ?? '' );
			if( $heading_key && isset( $seen_headings[$heading_key] ) ) {
				$warnings[] = 'duplicate_heading:' . $heading_key;
			}
			if( $heading_key ) {
				$seen_headings[$heading_key] = $index;
			}

			if( $index > 0 && ( $section['layout'] ?? '' ) === ( $sections[$index - 1]['layout'] ?? '' ) ) {
				$warnings[] = 'repeated_layout:' . sanitize_key( $section['layout'] ?? '' );
			}

			if( $index > 0 && ( $section['treatment'] ?? '' ) === ( $sections[$index - 1]['treatment'] ?? '' ) ) {
				$warnings[] = 'repeated_treatment:' . sanitize_key( $section['treatment'] ?? '' );
			}
		}

		return array_values( array_unique( array_filter( $warnings ) ) );
	}

	/**
	 * Render section.
	 *
	 * @param array $section Section.
	 * @param int $index Index.
	 * @return string Render section.
	 */

	protected static function render_section( array $section, int $index ): string {
		$type = $section['type'] ?? 'content';
		$archetype = $section['archetype'] ?? '';

		if( $archetype ) {
			$rendered = self::render_archetype( $section, $index, $archetype );
			if( trim( $rendered ) !== '' ) {
				return $rendered;
			}
		}

		if( $type === 'hero' ) {
			return self::render_hero( $section, $index );
		}

		if( $type === 'features' || $type === 'steps' ) {
			return self::render_feature_grid( $section, $type === 'steps', $index );
		}

		if( $type === 'stats' ) {
			return self::render_stats( $section, $index );
		}

		if( $type === 'testimonials' ) {
			return self::render_testimonials( $section, $index );
		}

		if( $type === 'offers' ) {
			return self::render_offer_cards( $section, self::fallback_items( $section, 3 ), $index );
		}

		if( $type === 'faq' ) {
			return self::render_faq( $section, $index );
		}

		if( $type === 'cta' ) {
			return self::render_cta( $section, $index );
		}

		return self::render_content_section( $section, $index );
	}

	/**
	 * Section preview item.
	 *
	 * @param array $section Section.
	 * @param int $index Index.
	 * @param string $content Content to process.
	 * @return array Section preview item.
	 */

	public static function section_preview_item( array $section, int $index, string $content ): array {
		$id = self::section_id( $section['id'] ?? '', $index, $section );

		return array(
			'id' => $id,
			'title' => self::text( $section['heading'] ?? sprintf( __( 'Section %d', 'wphave' ), $index + 1 ), 120 ),
			'type' => sanitize_key( (string) ( $section['type'] ?? 'content' ) ),
			'archetype' => sanitize_key( (string) ( $section['archetype'] ?? '' ) ),
			'layout' => sanitize_key( (string) ( $section['layout'] ?? '' ) ),
			'treatment' => sanitize_key( (string) ( $section['treatment'] ?? '' ) ),
			'content' => self::group( $content, array(
				'planner' => array(
					'sectionId' => $id,
					'sectionType' => sanitize_key( (string) ( $section['type'] ?? 'content' ) ),
					'sectionIndex' => $index,
				),
			) ),
		);
	}

	/**
	 * Section ID.
	 *
	 * @param mixed $id Id.
	 * @param int $index Index.
	 * @param array $section Section.
	 * @return string Section ID.
	 */

	protected static function section_id( $id, int $index, array $section = array() ): string {
		$id = sanitize_key( (string) $id );

		if( $id ) {
			return $id;
		}

		$base = sanitize_title( (string) ( $section['heading'] ?? $section['type'] ?? 'section' ) );

		return 'section-' . ( $index + 1 ) . '-' . ( $base ?: 'content' );
	}

	/**
	 * Render hero.
	 *
	 * @param array $section Section.
	 * @param int $index Index.
	 * @return string Render hero.
	 */

	protected static function render_hero( array $section, int $index = 0 ): string {
		$variant = self::variant( $section, $index % 2 ? 'split' : 'centered' );
		$treatment = self::section_treatment( $section );
		$visual = self::hero_visual( $section, $variant );

		if( $variant === 'panel' || $variant === 'editorial' ) {
			return self::section(
				self::surface(
					self::flex(
						self::stack(
							( ! empty( $section['eyebrow'] ) ? self::badge( $section['eyebrow'] ) : '' ) .
							self::heading( $section['heading'] ?? '', 'h1', 'title-xl' ) .
							( ! empty( $section['body'] ) ? self::paragraph( $section['body'], 'text-l' ) : '' ) .
							( ! empty( $section['actions'] ) ? self::button_row( $section['actions'] ) : '' ),
							'var(--wphave-site-gap-size-l)'
						) .
						$visual,
						'clamp(32px,6vw,84px)',
						'center',
						'space-between',
						'fill'
					),
					array(
						'treatment' => self::surface_treatment( $treatment, $variant === 'editorial' ? 'editorial-paper' : 'soft-card' ),
						'padding' => 'clamp(34px, 7vw, 84px) clamp(28px, 6vw, 78px) clamp(34px, 7vw, 84px) clamp(28px, 6vw, 78px)',
					)
				),
				array(
					'padding' => 'clamp(42px, 8vw, 110px) var(--wphave-site-spacing) clamp(42px, 8vw, 110px) var(--wphave-site-spacing)',
				)
			);
		}

		if( $variant === 'split' || ! empty( $section['imageBrief'] ) || ! empty( $section['imageId'] ) ) {
			return self::split_hero( array(
				'badge' => $section['eyebrow'] ?? '',
				'title' => $section['heading'] ?? '',
				'text' => $section['body'] ?? '',
				'buttons' => $section['actions'] ?? array(),
			), $visual, array(
				'padding' => 'clamp(72px, 10vw, 150px) var(--wphave-site-spacing) clamp(56px, 8vw, 110px) var(--wphave-site-spacing)',
			) );
		}

		return self::centered_hero( array(
			'badge' => $section['eyebrow'] ?? '',
			'title' => $section['heading'] ?? '',
			'text' => $section['body'] ?? '',
			'buttons' => $section['actions'] ?? array(),
		), array(
			'padding' => 'clamp(72px, 10vw, 150px) var(--wphave-site-spacing) clamp(56px, 8vw, 110px) var(--wphave-site-spacing)',
		) );
	}

	/**
	 * Render feature grid.
	 *
	 * @param array $section Section.
	 * @param bool $is_steps Is steps.
	 * @param int $index Index.
	 * @return string Render feature grid.
	 */

	protected static function render_feature_grid( array $section, bool $is_steps = false, int $index = 0 ): string {
		$variant = self::variant( $section, $is_steps ? 'alternating' : 'bento' );
		$treatment = self::section_treatment( $section );
		$items = self::fallback_items( $section, $is_steps ? 4 : 3 );

		if( $is_steps && ( $variant === 'alternating' || $variant === 'timeline' ) ) {
			return self::section(
				self::stack(
					self::section_intro( $section ) .
					self::alternately( self::step_cards( $items ), $variant === 'timeline' ? '62%' : '72%' ),
					'var(--wphave-site-gap-size-xl)'
				),
				array( 'background' => self::section_background( $index ) )
			);
		}

		$cards = array();

		foreach( $items as $item_index => $item ) {
			$title = $is_steps ? sprintf( '%02d. %s', $item_index + 1, $item['title'] ?? '' ) : ( $item['title'] ?? '' );
			$cards[] = self::designed_card( $title, $item['text'] ?? '', $item_index, $variant === 'compact', $treatment );
		}

		if( $variant === 'cards' ) {
			return self::render_offer_cards( $section, $items, $index );
		}

		if( $variant === 'bento' ) {
			return self::bento_section( self::section_header( $section ), $cards, array(
				'background' => self::section_background( $index ),
			) );
		}

		if( $variant === 'masonry' ) {
			return self::section(
				self::stack(
					self::section_intro( $section ) .
					self::masonry( implode( '', $cards ), min( 3, max( 1, count( $items ) ) ) ),
					'var(--wphave-site-gap-size-xl)'
				),
				array( 'background' => self::section_background( $index ) )
			);
		}

		if( $variant === 'alternating' || $variant === 'timeline' ) {
			return self::section(
				self::stack(
					self::section_intro( $section ) .
					self::alternately( self::step_cards( $items ), $variant === 'timeline' ? '62%' : '72%' ),
					'var(--wphave-site-gap-size-xl)'
				),
				array( 'background' => self::section_background( $index ) )
			);
		}

		return self::section(
			self::stack(
				self::section_intro( $section ) .
				self::grid( implode( '', $cards ), self::grid_columns( $items, $variant === 'compact' ? 4 : 3 ) ),
				'var(--wphave-site-gap-size-xl)'
			),
			array( 'background' => self::section_background( $index ) )
		);
	}

	/**
	 * Render stats.
	 *
	 * @param array $section Section.
	 * @param int $index Index.
	 * @return string Render stats.
	 */

	protected static function render_stats( array $section, int $index = 0 ): string {
		$variant = self::variant( $section, $index % 2 ? 'panel' : 'grid' );
		$treatment = self::section_treatment( $section );
		$items = self::fallback_items( $section, 3 );
		$cards = array();

		foreach( $items as $item_index => $item ) {
			$cards[] = self::designed_metric_card( $item, $item_index, $variant === 'panel' || $treatment === 'dark' || $treatment === 'bold' || $treatment === 'glow' );
		}

		$content = self::stack(
			( $variant === 'panel' || in_array( $treatment, array( 'dark', 'bold', 'glow' ), true ) ? self::section_intro_dark( $section ) : self::section_intro( $section ) ) .
			( $variant === 'bento' ? self::bento_grid( $cards ) : self::grid( implode( '', $cards ), min( 4, max( 1, count( $items ) ) ) ) ),
			'var(--wphave-site-gap-size-xl)'
		);

		if( $variant === 'panel' || $treatment === 'dark' || $treatment === 'bold' || $treatment === 'glow' ) {
			$content = self::surface( $content, array(
				'treatment' => self::surface_treatment( $treatment, 'dark-glow' ),
				'treatmentArgs' => [ 'background' => 'var(--wphave-site-color-heading)' ],
				'padding' => 'clamp(30px, 5vw, 64px) clamp(28px, 5vw, 64px) clamp(30px, 5vw, 64px) clamp(28px, 5vw, 64px)',
			) );
		}

		return self::section(
			$content,
			array( 'background' => $variant === 'panel' ? 'transparent' : 'var(--wphave-site-color-background-subtle-1)' )
		);
	}

	/**
	 * Render faq.
	 *
	 * @param array $section Section.
	 * @param int $index Index.
	 * @return string Render faq.
	 */

	protected static function render_faq( array $section, int $index = 0 ): string {
		$variant = self::variant( $section, $index % 2 ? 'split' : 'stacked' );
		$treatment = self::section_treatment( $section );
		$items = self::fallback_items( $section, 4 );
		$accordion_items = array_map( function( $item ) {
			return array(
				'title' => $item['title'] ?? '',
				'content' => self::paragraph( $item['text'] ?? '' ),
			);
		}, $items );

		$accordion = self::accordion( $accordion_items );
		$content = self::stack(
			self::section_intro( $section ) .
			$accordion,
			'var(--wphave-site-gap-size-xl)'
		);

		if( $variant === 'split' ) {
			$content = self::flex(
				self::section_intro( $section ) . $accordion,
				'clamp(32px,6vw,84px)',
				'start',
				'space-between',
				'fill'
			);
		}

		if( $variant === 'panel' || in_array( $treatment, array( 'editorial', 'elevated', 'framed' ), true ) ) {
			$content = self::surface( $content, array(
				'treatment' => self::surface_treatment( $treatment, 'editorial-paper' ),
				'padding' => 'clamp(30px, 5vw, 64px) clamp(28px, 5vw, 64px) clamp(30px, 5vw, 64px) clamp(28px, 5vw, 64px)',
			) );
		}

		return self::section( $content, array(
			'background' => self::section_background( $index ),
		) );
	}

	/**
	 * Render cta.
	 *
	 * @param array $section Section.
	 * @param int $index Index.
	 * @return string Render cta.
	 */

	protected static function render_cta( array $section, int $index = 0 ): string {
		$variant = self::variant( $section, $index % 2 ? 'band' : 'panel' );
		$treatment = self::section_treatment( $section );
		$intro = self::section_intro( $section, $variant === 'split' ? 'none' : 'center' );
		$actions = ! empty( $section['actions'] ) ? self::button_row( $section['actions'], '0.75rem', [
			'layout' => [ 'flex' => [ 'alignHorizontal' => $variant === 'split' ? 'start' : 'center' ] ],
		] ) : '';

		if( $variant === 'split' ) {
			return self::section(
				self::surface(
					self::flex(
						self::stack( $intro . $actions, 'var(--wphave-site-gap-size-l)' ) .
						self::visual_panel( $section, '260px', 'patterned-section' ),
						'clamp(32px,6vw,84px)',
						'center',
						'space-between',
						'fill'
					),
					array( 'treatment' => self::surface_treatment( $treatment, 'gradient-border' ) )
				)
			);
		}

		if( $variant === 'band' ) {
			return self::section(
				self::stack(
					$intro . $actions,
					'var(--wphave-site-gap-size-l)',
					[ 'text' => [ 'align' => 'center' ] ]
				),
				array(
					'background' => 'var(--wphave-site-color-background-subtle-1)',
					'padding' => 'clamp(54px, 8vw, 105px) var(--wphave-site-spacing) clamp(54px, 8vw, 105px) var(--wphave-site-spacing)',
				)
			);
		}

		return self::section(
			self::surface(
				self::stack(
					$intro . $actions,
					'var(--wphave-site-gap-size-l)',
					[ 'text' => [ 'align' => 'center' ] ]
				),
				array(
					'treatment' => 'gradient-border',
					'padding' => 'clamp(36px, 6vw, 76px) clamp(28px, 5vw, 72px) clamp(36px, 6vw, 76px) clamp(28px, 5vw, 72px)',
				)
			)
		);
	}

	/**
	 * Render content section.
	 *
	 * @param array $section Section.
	 * @param int $index Index.
	 * @return string Render content section.
	 */

	protected static function render_content_section( array $section, int $index ): string {
		$variant = self::variant( $section, $index % 2 ? 'split' : 'stacked' );
		$treatment = self::section_treatment( $section );
		$items = self::sanitize_items( $section['items'] ?? array() );
		$cards = array();

		if( ! empty( $items ) ) {
			foreach( $items as $item_index => $item ) {
				$cards[] = self::designed_card( $item['title'] ?? '', $item['text'] ?? '', $item_index, false, $treatment );
			}
		}

		if( $variant === 'cards' && ! empty( $items ) ) {
			return self::render_offer_cards( $section, $items, $index );
		}

		if( $variant === 'bento' && ! empty( $cards ) ) {
			return self::bento_section( self::section_header( $section ), $cards, array(
				'background' => self::section_background( $index ),
			) );
		}

		if( $variant === 'masonry' && ! empty( $cards ) ) {
			return self::section(
				self::stack(
					self::section_intro( $section ) .
					self::masonry( implode( '', $cards ), min( 3, max( 1, count( $items ) ) ) ) .
					( ! empty( $section['actions'] ) ? self::button_row( $section['actions'] ) : '' ),
					'var(--wphave-site-gap-size-l)'
				),
				array( 'background' => self::section_background( $index ) )
			);
		}

		if( $variant === 'alternating' && ! empty( $cards ) ) {
			return self::section(
				self::stack(
					self::section_intro( $section ) .
					self::alternately( implode( '', $cards ), '72%' ) .
					( ! empty( $section['actions'] ) ? self::button_row( $section['actions'] ) : '' ),
					'var(--wphave-site-gap-size-l)'
				),
				array( 'background' => self::section_background( $index ) )
			);
		}

		$list = ! empty( $cards ) ? self::grid( implode( '', $cards ), self::grid_columns( $items ) ) : '';
		$body = self::stack(
			self::section_intro( $section ) .
			$list .
			( ! empty( $section['actions'] ) ? self::button_row( $section['actions'] ) : '' ),
			'var(--wphave-site-gap-size-l)'
		);

		if( $variant === 'panel' || in_array( $treatment, array( 'elevated', 'outlined', 'editorial', 'framed', 'glass' ), true ) ) {
			$body = self::surface( $body, array(
				'treatment' => self::surface_treatment( $treatment, 'soft-card' ),
				'padding' => 'clamp(30px, 5vw, 64px) clamp(28px, 5vw, 64px) clamp(30px, 5vw, 64px) clamp(28px, 5vw, 64px)',
			) );
		}

		if( $variant === 'split' || ! empty( $section['imageBrief'] ) || ! empty( $section['imageId'] ) ) {
			$body = self::flex(
				$body . self::visual_panel( $section ),
				'clamp(32px,6vw,84px)',
				'center',
				'space-between',
				'fill'
			);
		}

		return self::section( $body, array(
			'background' => self::section_background( $index ),
		) );
	}

	/**
	 * Render archetype.
	 *
	 * @param array $section Section.
	 * @param int $index Index.
	 * @param string $archetype Archetype.
	 * @return string Render archetype.
	 */

	protected static function render_archetype( array $section, int $index, string $archetype ): string {
		switch( $archetype ) {
			case 'hero-showcase':
			case 'visual-showcase':
				return self::render_hero( self::section_with( $section, [
					'layout' => 'panel',
					'treatment' => $section['treatment'] ?? 'glow',
				] ), $index );

			case 'hero-editorial':
				return self::render_hero( self::section_with( $section, [
					'layout' => 'editorial',
					'treatment' => $section['treatment'] ?? 'editorial',
				] ), $index );

			case 'marquee-strip':
				return self::render_single_marquee( $section );

			case 'light-band':
				return self::render_content_section( self::section_with( $section, [
					'type' => 'content',
					'layout' => 'stacked',
					'treatment' => 'blank',
				] ), $index );

			case 'bento-showcase':
				return self::render_feature_grid( self::section_with( $section, [
					'type' => 'features',
					'layout' => 'bento',
					'treatment' => $section['treatment'] ?? 'soft',
				] ), false, $index );

			case 'split-story':
				return self::render_content_section( self::section_with( $section, [
					'type' => 'content',
					'layout' => 'split',
				] ), $index );

			case 'tabbed-content':
				return self::render_content_section( self::section_with( $section, [
					'type' => 'content',
					'layout' => 'panel',
					'treatment' => $section['treatment'] ?? 'soft',
				] ), $index );

			case 'process-alternating':
				return self::render_feature_grid( self::section_with( $section, [
					'type' => 'steps',
					'layout' => 'alternating',
					'treatment' => $section['treatment'] ?? 'elevated',
				] ), true, $index );

			case 'proof-band':
				return self::render_stats( self::section_with( $section, [
					'type' => 'stats',
					'layout' => 'panel',
					'treatment' => $section['treatment'] ?? 'dark',
				] ), $index );

			case 'testimonial-band':
				return self::render_testimonials( self::section_with( $section, [
					'type' => 'testimonials',
					'treatment' => $section['treatment'] ?? 'dark',
				] ), $index );

			case 'offer-cards':
				return self::render_offer_cards( self::section_with( $section, [
					'type' => 'offers',
					'layout' => 'cards',
					'treatment' => $section['treatment'] ?? 'elevated',
				] ), self::fallback_items( $section, 3 ), $index );

			case 'compact-metrics':
				return self::render_stats( self::section_with( $section, [
					'type' => 'stats',
					'layout' => 'grid',
					'treatment' => $section['treatment'] ?? 'blank',
				] ), $index );

			case 'framed-cta':
				return self::render_cta( self::section_with( $section, [
					'type' => 'cta',
					'layout' => 'panel',
					'treatment' => $section['treatment'] ?? 'framed',
				] ), $index );

			case 'editorial-note':
				return self::render_content_section( self::section_with( $section, [
					'type' => 'content',
					'layout' => 'panel',
					'treatment' => $section['treatment'] ?? 'editorial',
				] ), $index );
		}

		return '';
	}

	/**
	 * Render testimonials.
	 *
	 * @param array $section Section.
	 * @param int $index Index.
	 * @return string Render testimonials.
	 */

	protected static function render_testimonials( array $section, int $index ): string {
		$treatment = self::section_treatment( $section );
		$items = self::fallback_items( $section, 3 );
		$cards = '';

		foreach( $items as $item ) {
			$cards .= self::testimonial_card(
				$item['text'] ?? '',
				$item['title'] ?? __( 'Customer', 'wphave' ),
				$section['eyebrow'] ?? '',
				in_array( $treatment, array( 'dark', 'bold', 'glow' ), true ) ? array(
					'quoteColor' => 'var(--wphave-site-color-heading)',
					'nameColor' => 'var(--wphave-site-color-heading)',
					'metaColor' => 'var(--wphave-site-color-text)',
				) : array()
			);
		}

		$content = self::stack(
			( in_array( $treatment, array( 'dark', 'bold', 'glow' ), true ) ? self::section_intro_dark( $section ) : self::section_intro( $section ) ) .
			self::swiper( $cards, 2, '20px' ),
			'var(--wphave-site-gap-size-l)'
		);

		if( in_array( $treatment, array( 'dark', 'bold', 'glow' ), true ) ) {
			return self::section( $content, array(
				'background' => 'var(--wphave-site-color-heading)',
				'wphave' => self::treatment( 'dark-glow', [ 'background' => 'var(--wphave-site-color-heading)' ] ),
			) );
		}

		return self::section( $content, array(
			'background' => self::section_background( $index ),
		) );
	}

	/**
	 * Section intro.
	 *
	 * @param array $section Section.
	 * @param string $align Align.
	 * @return string Section intro.
	 */

	protected static function section_intro( array $section, string $align = 'none' ): string {
		return self::stack(
			( ! empty( $section['eyebrow'] ) ? self::badge( $section['eyebrow'] ) : '' ) .
			( ! empty( $section['heading'] ) ? self::heading( $section['heading'], 'h2', 'title-l', 'var(--wphave-site-color-heading)', $align ) : '' ) .
			( ! empty( $section['body'] ) ? self::paragraph( $section['body'], 'text-l', 'var(--wphave-site-color-text)', $align ) : '' ),
			'var(--wphave-site-gap-size-m)',
			array( 'dimensions' => [ 'width' => [ 'limit' => 'max', 'custom' => '780px' ] ] )
		);
	}

	/**
	 * Section intro dark.
	 *
	 * @param array $section Section.
	 * @param string $align Align.
	 * @return string Section intro dark.
	 */

	protected static function section_intro_dark( array $section, string $align = 'none' ): string {
		return self::stack(
			( ! empty( $section['eyebrow'] ) ? self::badge( $section['eyebrow'], [
				'background' => 'var(--wphave-site-color-background)',
				'color' => 'var(--wphave-site-color-heading)',
			] ) : '' ) .
			( ! empty( $section['heading'] ) ? self::heading( $section['heading'], 'h2', 'title-l', 'var(--wphave-site-color-background)', $align ) : '' ) .
			( ! empty( $section['body'] ) ? self::paragraph( $section['body'], 'text-l', 'var(--wphave-site-color-background)', $align ) : '' ),
			'var(--wphave-site-gap-size-m)',
			array( 'dimensions' => [ 'width' => [ 'limit' => 'max', 'custom' => '780px' ] ] )
		);
	}

	/**
	 * Render marquee.
	 *
	 * @param array $sections Sections.
	 * @return string Render marquee.
	 */

	protected static function render_marquee( array $sections ): string {
		$labels = array();

		foreach( array_slice( $sections, 1, 5 ) as $section ) {
			$label = $section['eyebrow'] ?? $section['heading'] ?? '';
			if( $label ) {
				$labels[] = $label;
			}
		}

		if( empty( $labels ) ) {
			return '';
		}

		return self::marquee( implode( ' / ', $labels ), array(
			'background' => 'var(--wphave-site-color-heading)',
			'color' => 'var(--wphave-site-color-background)',
			'padding' => '14px 0px 14px 0px',
		) );
	}

	/**
	 * Render single marquee.
	 *
	 * @param array $section Section.
	 * @return string Render single marquee.
	 */

	protected static function render_single_marquee( array $section ): string {
		$items = self::sanitize_items( $section['items'] ?? array() );
		$labels = array();

		foreach( $items as $item ) {
			if( ! empty( $item['title'] ) ) {
				$labels[] = $item['title'];
			}
		}

		if( empty( $labels ) ) {
			$labels = array_filter( array( $section['eyebrow'] ?? '', $section['heading'] ?? '', $section['body'] ?? '' ) );
		}

		if( empty( $labels ) ) {
			return '';
		}

		return self::marquee( implode( ' / ', $labels ), array(
			'background' => self::section_treatment( $section ) === 'strip' ? 'var(--wphave-site-color-heading)' : 'var(--wphave-site-color-heading)',
			'color' => 'var(--wphave-site-color-background)',
			'padding' => '14px 0px 14px 0px',
		) );
	}

	/**
	 * Hero visual.
	 *
	 * @param array $section Section.
	 * @param string $variant Variant.
	 * @return string Hero visual.
	 */

	protected static function hero_visual( array $section, string $variant ): string {
		if( ! empty( $section['imageId'] ) ) {
			return self::visual_panel( $section, 'min(420px, 80vw)', $variant === 'editorial' ? 'editorial-paper' : 'patterned-section' );
		}

		$items = self::sanitize_items( $section['items'] ?? array() );
		if( empty( $items ) ) {
			$items = array(
				array(
					'title' => $section['eyebrow'] ?? __( 'Selected', 'wphave' ),
					'text' => $section['body'] ?? '',
				),
				array(
					'title' => __( '01', 'wphave' ),
					'text' => $section['heading'] ?? '',
				),
			);
		}

		$metrics = '';
		foreach( array_slice( $items, 0, 2 ) as $index => $item ) {
			$metrics .= self::metric_card( self::metric_number( $item, $index ), $item['title'] ?? '', $item['text'] ?? '', array(
				'background' => 'rgba(0,0,0,0.22)',
				'numberColor' => 'var(--wphave-site-color-background)',
				'labelColor' => 'var(--wphave-site-color-background)',
				'detailColor' => 'var(--wphave-site-color-background)',
				'padding' => '18px 18px 18px 18px',
				'radius' => '14px',
			) );
		}

		return self::surface(
			self::stack(
				self::badge( $section['eyebrow'] ?? __( 'Preview', 'wphave' ), [
					'background' => 'var(--wphave-site-color-background)',
					'color' => 'var(--wphave-site-color-heading)',
				] ) .
				self::heading( $section['summary'] ?? $section['heading'] ?? '', 'h3', 'title-s', 'var(--wphave-site-color-background)' ) .
				( ! empty( $section['body'] ) ? self::paragraph( $section['body'], 'default', 'var(--wphave-site-color-background)' ) : '' ) .
				self::grid( $metrics, 2, '14px' ),
				'var(--wphave-site-gap-size-m)'
			),
			array(
				'treatment' => 'dark-glow',
				'treatmentArgs' => [ 'background' => 'var(--wphave-site-color-heading)' ],
				'padding' => '32px 32px 32px 32px',
				'radius' => '22px',
			)
		);
	}

	/**
	 * Designed card.
	 *
	 * @param string $title Title.
	 * @param string $text Text.
	 * @param int $index Index.
	 * @param bool $compact Compact.
	 * @param string $treatment Treatment.
	 * @return string Designed card.
	 */

	protected static function designed_card( string $title, string $text, int $index, bool $compact = false, string $treatment = '' ): string {
		$treatments = array(
			array(
				'treatment' => 'editorial-paper',
				'padding' => $compact ? '22px 22px 22px 22px' : '34px 34px 34px 34px',
			),
			array(
				'treatment' => 'soft-card',
				'background' => 'var(--wphave-site-color-background)',
				'padding' => $compact ? '22px 22px 22px 22px' : '30px 30px 30px 30px',
			),
			array(
				'background' => 'var(--wphave-site-color-background-contrast-1)',
				'padding' => $compact ? '22px 22px 22px 22px' : '30px 30px 30px 30px',
			),
			array(
				'background' => 'var(--wphave-site-color-background-subtle-1)',
				'padding' => $compact ? '22px 22px 22px 22px' : '30px 30px 30px 30px',
			),
		);
		$args = $treatments[$index % count( $treatments )];

		if( $treatment ) {
			$args = self::card_treatment_args( $treatment, $args );
		}

		return self::surface(
			self::stack(
				self::heading( $title, 'h3', 'title-s' ) .
				self::paragraph( $text ),
				'var(--wphave-site-gap-size-m)'
			),
			array_replace_recursive( array(
				'radius' => '18px',
			), $args )
		);
	}

	/**
	 * Designed metric card.
	 *
	 * @param array $item Item.
	 * @param int $index Index.
	 * @param bool $dark Dark.
	 * @return string Designed metric card.
	 */

	protected static function designed_metric_card( array $item, int $index, bool $dark = false ): string {
		return self::metric_card(
			self::metric_number( $item, $index ),
			$item['title'] ?? '',
			$item['text'] ?? '',
			$dark ? array(
				'background' => 'rgba(0,0,0,0.18)',
				'numberColor' => 'var(--wphave-site-color-background)',
				'labelColor' => 'var(--wphave-site-color-background)',
				'detailColor' => 'var(--wphave-site-color-background)',
			) : array(
				'background' => self::card_background( $index ),
			)
		);
	}

	/**
	 * Surface treatment.
	 *
	 * @param string $treatment Treatment.
	 * @param string $fallback Fallback.
	 * @return string Surface treatment.
	 */

	protected static function surface_treatment( string $treatment, string $fallback = 'soft-card' ): string {
		$map = array(
			'blank' => '',
			'soft' => 'soft-card',
			'outlined' => 'gradient-border',
			'elevated' => 'soft-card',
			'bold' => 'gradient-border',
			'dark' => 'dark-glow',
			'editorial' => 'editorial-paper',
			'glass' => 'glass',
			'glow' => 'dark-glow',
			'framed' => 'gradient-border',
			'strip' => '',
		);

		return $map[$treatment] ?? $fallback;
	}

	/**
	 * Card treatment args.
	 *
	 * @param string $treatment Treatment.
	 * @param array $fallback Fallback.
	 * @return array Card treatment args.
	 */

	protected static function card_treatment_args( string $treatment, array $fallback = array() ): array {
		$base = array(
			'treatment' => self::surface_treatment( $treatment, $fallback['treatment'] ?? 'soft-card' ),
			'padding' => $fallback['padding'] ?? '30px 30px 30px 30px',
		);

		if( $treatment === 'blank' ) {
			return array(
				'background' => 'transparent',
				'padding' => $fallback['padding'] ?? '0px 0px 0px 0px',
			);
		}

		if( $treatment === 'soft' ) {
			$base['background'] = 'var(--wphave-site-color-background-subtle-1)';
		}

		if( $treatment === 'outlined' ) {
			$base['background'] = 'transparent';
		}

		if( $treatment === 'bold' ) {
			$base['background'] = 'var(--wphave-site-color-background)';
		}

		if( $treatment === 'dark' || $treatment === 'glow' ) {
			$base['treatmentArgs'] = [ 'background' => 'var(--wphave-site-color-heading)' ];
		}

		return array_replace_recursive( $fallback, $base );
	}

	/**
	 * Step cards.
	 *
	 * @param array $items Items.
	 * @return string Step cards.
	 */

	protected static function step_cards( array $items ): string {
		$content = '';

		foreach( $items as $index => $item ) {
			$content .= self::surface(
				self::stack(
					self::badge( str_pad( (string) ( $index + 1 ), 2, '0', STR_PAD_LEFT ), [
						'background' => 'var(--wphave-site-color-heading)',
						'color' => 'var(--wphave-site-color-background)',
					] ) .
					self::heading( $item['title'] ?? '', 'h3', 'title-s' ) .
					self::paragraph( $item['text'] ?? '' ),
					'var(--wphave-site-gap-size-m)'
				),
				array(
					'treatment' => 'soft-card',
					'padding' => '26px 26px 26px 26px',
					'radius' => '18px',
				)
			);
		}

		return $content;
	}

	/**
	 * Render offer cards.
	 *
	 * @param array $section Section.
	 * @param array $items Items.
	 * @param int $index Index.
	 * @return string Render offer cards.
	 */

	protected static function render_offer_cards( array $section, array $items, int $index ): string {
		$cards = '';

		foreach( array_slice( $items, 0, 3 ) as $item_index => $item ) {
			$features = array_filter( array_map( 'trim', preg_split( '/[.;]\s*/', (string) ( $item['text'] ?? '' ) ) ) );
			$features = ! empty( $features ) ? array_slice( $features, 0, 4 ) : array( $item['text'] ?? '' );

			$cards .= self::pricing_card( $item['title'] ?? '', (string) self::metric_number( $item, $item_index ), $features, array(
				'featured' => $item_index === 1,
				'badge' => $item_index === 1 ? __( 'Recommended', 'wphave' ) : '',
				'text' => $section['body'] ?? '',
				'button' => ! empty( $section['actions'][0]['label'] ) ? $section['actions'][0]['label'] : __( 'Learn more', 'wphave' ),
				'buttonVariant' => $item_index === 2 ? 'secondary' : 'primary',
			) );
		}

		return self::section(
			self::stack(
				self::section_intro( $section ) .
				self::grid( $cards, min( 3, max( 1, count( $items ) ) ), '20px' ),
				'var(--wphave-site-gap-size-xl)'
			),
			array( 'background' => self::section_background( $index ) )
		);
	}

	/**
	 * Section header.
	 *
	 * @param array $section Section.
	 * @return array Section header.
	 */

	protected static function section_header( array $section ): array {
		return array(
			'badge' => $section['eyebrow'] ?? '',
			'title' => $section['heading'] ?? '',
			'text' => $section['body'] ?? '',
		);
	}

	/**
	 * Section with.
	 *
	 * @param array $section Section.
	 * @param array $overrides Overrides.
	 * @return array Section with.
	 */

	protected static function section_with( array $section, array $overrides ): array {
		return array_replace( $section, $overrides );
	}

	/**
	 * Determine whether any section uses the requested archetype.
	 *
	 * @param array $sections Sections.
	 * @param string $archetype Archetype.
	 * @return bool Determine whether archetype.
	 */

	protected static function has_archetype( array $sections, string $archetype ): bool {
		foreach( $sections as $section ) {
			if( ( $section['archetype'] ?? '' ) === $archetype ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Variant.
	 *
	 * @param array $section Section.
	 * @param string $fallback Fallback.
	 * @return string Variant.
	 */

	protected static function variant( array $section, string $fallback ): string {
		$variant = sanitize_key( $section['layout'] ?? $section['variant'] ?? '' );
		$allowed = array( 'centered', 'split', 'grid', 'bento', 'stacked', 'panel', 'masonry', 'alternating', 'timeline', 'cards', 'compact', 'band', 'editorial' );

		return in_array( $variant, $allowed, true ) ? $variant : $fallback;
	}

	/**
	 * Section treatment.
	 *
	 * @param array $section Section.
	 * @param array $composition Composition.
	 * @return string Section treatment.
	 */

	protected static function section_treatment( array $section, array $composition = array() ): string {
		$treatment = self::sanitize_treatment( $section['treatment'] ?? '' );

		return $treatment ?: ( $composition['surface'] ?? 'soft' );
	}

	/**
	 * Section background.
	 *
	 * @param int $index Index.
	 * @return string Section background.
	 */

	protected static function section_background( int $index ): string {
		if( $index % 3 === 1 ) {
			return 'var(--wphave-site-color-background-subtle-1)';
		}

		return 'transparent';
	}

	/**
	 * Card background.
	 *
	 * @param int $index Index.
	 * @return string Card background.
	 */

	protected static function card_background( int $index ): string {
		return $index % 2 ? 'var(--wphave-site-color-background)' : 'var(--wphave-site-color-background-subtle-1)';
	}

	/**
	 * Grid columns.
	 *
	 * @param array $items Items.
	 * @param int $max Max.
	 * @return int Grid columns.
	 */

	protected static function grid_columns( array $items, int $max = 3 ): int {
		return min( $max, max( 1, count( $items ) ) );
	}

	/**
	 * Metric number.
	 *
	 * @param array $item Item.
	 * @param int $index Index.
	 * @return int Metric number.
	 */

	protected static function metric_number( array $item, int $index ): int {
		$number = (int) preg_replace( '/\D+/', '', (string) ( $item['title'] ?? '' ) );

		return max( 1, $number ?: ( $index + 1 ) * 10 );
	}

	/**
	 * Sanitize composition.
	 *
	 * @param mixed $composition Composition.
	 * @return array Sanitize composition.
	 */

	protected static function sanitize_composition( $composition ): array {
		$composition = is_array( $composition ) ? $composition : array();

		return array(
			'density' => self::sanitize_choice( $composition['density'] ?? '', array( 'compact', 'balanced', 'spacious' ), 'balanced' ),
			'rhythm' => self::sanitize_choice( $composition['rhythm'] ?? '', array( 'calm', 'varied', 'bold' ), 'varied' ),
			'surface' => self::sanitize_treatment( $composition['surface'] ?? 'soft' ) ?: 'soft',
			'contrast' => self::sanitize_choice( $composition['contrast'] ?? '', array( 'low', 'medium', 'high' ), 'medium' ),
			'flow' => self::sanitize_choice( $composition['flow'] ?? '', array( 'showcase', 'editorial', 'modular', 'conversion', 'narrative', 'compact' ), 'showcase' ),
			'layoutRecipe' => self::sanitize_layout_recipe( $composition['layoutRecipe'] ?? '' ),
		);
	}

	/**
	 * Sanitize layout recipe.
	 *
	 * @param mixed $recipe Recipe.
	 * @return string Sanitize layout recipe.
	 */

	protected static function sanitize_layout_recipe( $recipe ): string {
		$allowed = class_exists( 'WPHAVE_AI_Page_Composition_Recipes' )
			? WPHAVE_AI_Page_Composition_Recipes::keys()
			: array( 'poster-lead', 'catalog-index', 'dense-bento', 'editorial-stack', 'proof-first', 'alternating-story', 'campaign-flow', 'compact-service' );

		return self::sanitize_choice( $recipe, $allowed, '' );
	}

	/**
	 * Sanitize layout.
	 *
	 * @param mixed $layout Layout.
	 * @param string $type Type.
	 * @return string Sanitize layout.
	 */

	protected static function sanitize_layout( $layout, string $type ): string {
		$layout = sanitize_key( (string) $layout );
		$allowed = array( 'centered', 'split', 'grid', 'bento', 'stacked', 'panel', 'masonry', 'alternating', 'timeline', 'cards', 'compact', 'band', 'editorial' );

		return in_array( $layout, $allowed, true ) ? $layout : self::default_variant( $type );
	}

	/**
	 * Sanitize treatment.
	 *
	 * @param mixed $treatment Treatment.
	 * @return string Sanitize treatment.
	 */

	protected static function sanitize_treatment( $treatment ): string {
		return self::sanitize_choice( $treatment, array( 'blank', 'soft', 'outlined', 'elevated', 'bold', 'dark', 'editorial', 'glass', 'glow', 'framed', 'strip' ), '' );
	}

	/**
	 * Sanitize archetype.
	 *
	 * @param mixed $archetype Archetype.
	 * @return string Sanitize archetype.
	 */

	protected static function sanitize_archetype( $archetype ): string {
		return self::sanitize_choice( $archetype, self::allowed_archetypes(), '' );
	}

	/**
	 * Allowed archetypes.
	 *
	 * @return array Allowed archetypes.
	 */

	protected static function allowed_archetypes(): array {
		return array( 'hero-showcase', 'hero-editorial', 'visual-showcase', 'marquee-strip', 'light-band', 'bento-showcase', 'split-story', 'tabbed-content', 'process-alternating', 'proof-band', 'testimonial-band', 'offer-cards', 'compact-metrics', 'framed-cta', 'editorial-note' );
	}

	/**
	 * Sanitize choice.
	 *
	 * @param mixed $value Value.
	 * @param array $allowed Allowed.
	 * @param string $fallback Fallback.
	 * @return string Sanitize choice.
	 */

	protected static function sanitize_choice( $value, array $allowed, string $fallback ): string {
		$value = sanitize_key( (string) $value );

		return in_array( $value, $allowed, true ) ? $value : $fallback;
	}

	/**
	 * Balance section variants.
	 *
	 * @param array $sections Sections.
	 * @param array $composition Composition.
	 * @return array Balance section variants.
	 */

	protected static function balance_section_variants( array $sections, array $composition = array() ): array {
		foreach( $sections as $index => &$section ) {
			$type = $section['type'] ?? 'content';
			$variant = sanitize_key( $section['layout'] ?? '' );
			$treatment = self::sanitize_treatment( $section['treatment'] ?? '' );

			if( $variant === '' || $variant === self::default_variant( $type ) || ( $index > 0 && $variant === ( $sections[$index - 1]['layout'] ?? '' ) ) ) {
				$section['layout'] = self::rhythm_variant( $type, $index, $composition );
			}

			if( $treatment === '' || ( $index > 0 && $treatment === ( $sections[$index - 1]['treatment'] ?? '' ) ) ) {
				$section['treatment'] = self::rhythm_treatment( $type, $index, $composition );
			}
		}
		unset( $section );

		return $sections;
	}

	/**
	 * Balance section archetypes.
	 *
	 * @param array $sections Sections.
	 * @param array $composition Composition.
	 * @return array Balance section archetypes.
	 */

	protected static function balance_section_archetypes( array $sections, array $composition = array() ): array {
		foreach( $sections as $index => &$section ) {
			if( ! empty( $section['archetype'] ) ) {
				continue;
			}

			$section['archetype'] = self::rhythm_archetype( $section['type'] ?? 'content', $index, $composition );
		}
		unset( $section );

		return $sections;
	}

	/**
	 * Rhythm archetype.
	 *
	 * @param string $type Type.
	 * @param int $index Index.
	 * @param array $composition Composition.
	 * @return string Rhythm archetype.
	 */

	protected static function rhythm_archetype( string $type, int $index, array $composition = array() ): string {
		$flow = $composition['flow'] ?? 'showcase';
		$flows = array(
			'showcase' => array( 'hero-showcase', 'visual-showcase', 'bento-showcase', 'light-band', 'process-alternating', 'proof-band', 'framed-cta' ),
			'editorial' => array( 'hero-editorial', 'marquee-strip', 'editorial-note', 'light-band', 'split-story', 'testimonial-band', 'framed-cta' ),
			'modular' => array( 'hero-showcase', 'bento-showcase', 'tabbed-content', 'compact-metrics', 'light-band', 'offer-cards', 'framed-cta' ),
			'conversion' => array( 'hero-showcase', 'marquee-strip', 'offer-cards', 'proof-band', 'light-band', 'testimonial-band', 'framed-cta' ),
			'narrative' => array( 'hero-editorial', 'split-story', 'editorial-note', 'process-alternating', 'light-band', 'testimonial-band', 'framed-cta' ),
			'compact' => array( 'hero-showcase', 'compact-metrics', 'light-band', 'tabbed-content', 'framed-cta' ),
		);
		$preferred = $flows[$flow] ?? $flows['showcase'];

		if( $type === 'hero' ) {
			return in_array( $preferred[0], array( 'hero-showcase', 'hero-editorial' ), true ) ? $preferred[0] : 'hero-showcase';
		}

		if( $type === 'steps' ) {
			return 'process-alternating';
		}

		if( $type === 'stats' ) {
			return ( $composition['rhythm'] ?? '' ) === 'bold' ? 'proof-band' : 'compact-metrics';
		}

		if( $type === 'testimonials' ) {
			return 'testimonial-band';
		}

		if( $type === 'offers' ) {
			return 'offer-cards';
		}

		if( $type === 'cta' ) {
			return 'framed-cta';
		}

		if( $type === 'features' ) {
			return $index % 2 ? 'bento-showcase' : 'offer-cards';
		}

		if( $type === 'content' ) {
			$options = array( 'split-story', 'light-band', 'editorial-note', 'tabbed-content' );

			return $options[$index % count( $options )];
		}

		return $preferred[$index % count( $preferred )];
	}

	/**
	 * Rhythm variant.
	 *
	 * @param string $type Type.
	 * @param int $index Index.
	 * @param array $composition Composition.
	 * @return string Rhythm variant.
	 */

	protected static function rhythm_variant( string $type, int $index, array $composition = array() ): string {
		$rhythm = $composition['rhythm'] ?? 'varied';
		$variants = array(
			'calm' => array(
				'hero' => array( 'split', 'centered', 'panel' ),
				'features' => array( 'grid', 'bento', 'compact' ),
				'content' => array( 'stacked', 'split', 'panel' ),
				'steps' => array( 'grid', 'alternating', 'compact' ),
				'stats' => array( 'grid', 'bento', 'panel' ),
				'faq' => array( 'stacked', 'panel', 'split' ),
				'cta' => array( 'panel', 'band', 'split' ),
			),
			'varied' => array(
				'hero' => array( 'split', 'panel', 'editorial', 'centered' ),
				'features' => array( 'bento', 'masonry', 'cards', 'compact' ),
				'content' => array( 'split', 'panel', 'bento', 'cards', 'alternating', 'stacked' ),
				'steps' => array( 'alternating', 'timeline', 'grid', 'compact' ),
				'stats' => array( 'bento', 'grid', 'panel' ),
				'faq' => array( 'split', 'panel', 'stacked' ),
				'cta' => array( 'band', 'panel', 'split' ),
			),
			'bold' => array(
				'hero' => array( 'panel', 'split', 'editorial' ),
				'features' => array( 'bento', 'cards', 'masonry' ),
				'content' => array( 'panel', 'bento', 'split', 'alternating' ),
				'steps' => array( 'timeline', 'alternating', 'compact' ),
				'stats' => array( 'panel', 'bento', 'grid' ),
				'faq' => array( 'panel', 'split', 'stacked' ),
				'cta' => array( 'band', 'split', 'panel' ),
			),
		);

		$set = $variants[$rhythm] ?? $variants['varied'];
		$options = $set[$type] ?? $set['content'];

		return $options[$index % count( $options )];
	}

	/**
	 * Rhythm treatment.
	 *
	 * @param string $type Type.
	 * @param int $index Index.
	 * @param array $composition Composition.
	 * @return string Rhythm treatment.
	 */

	protected static function rhythm_treatment( string $type, int $index, array $composition = array() ): string {
		$surface = $composition['surface'] ?? 'soft';
		$rhythm = $composition['rhythm'] ?? 'varied';

		if( $type === 'hero' ) {
			return in_array( $surface, array( 'dark', 'bold', 'glow', 'framed' ), true ) ? $surface : 'blank';
		}

		if( $type === 'cta' ) {
			return $rhythm === 'bold' ? 'bold' : 'elevated';
		}

		if( $type === 'stats' && ( $rhythm === 'bold' || ( $composition['contrast'] ?? '' ) === 'high' ) ) {
			return 'dark';
		}

		$options = $rhythm === 'calm'
			? array( 'blank', 'soft', 'outlined', 'blank' )
			: array( 'soft', 'elevated', 'editorial', 'blank', 'outlined' );

		if( $rhythm === 'bold' ) {
			$options = array( 'elevated', 'bold', 'editorial', 'soft', 'dark' );
		}

		return $options[$index % count( $options )];
	}

	/**
	 * Visual panel.
	 *
	 * @param array $section Section.
	 * @param string $height Height.
	 * @param string $treatment Treatment.
	 * @return string Visual panel.
	 */

	protected static function visual_panel( array $section, string $height = '320px', string $treatment = 'patterned-section' ): string {
		if( ! empty( $section['imageId'] ) ) {
			return self::surface( self::spacer( $height ), array(
				'treatment' => 'soft-card',
				'wphave' => [
					'background' => [
						'layers' => [
							self::background_media_layer( absint( $section['imageId'] ), [ 'fit' => 'cover' ] ),
							self::background_overlay_layer( '#000000', 0.08 ),
						],
					],
				],
			) );
		}

		return self::surface( self::spacer( $height ), array(
			'treatment' => $treatment,
			'treatmentArgs' => [
				'text' => mb_substr( $section['heading'] ?? 'WPHAVE', 0, 18 ),
			],
		) );
	}

	/**
	 * Fallback items.
	 *
	 * @param array $section Section.
	 * @param int $count Count.
	 * @return array Fallback items.
	 */

	protected static function fallback_items( array $section, int $count ): array {
		$items = self::sanitize_items( $section['items'] ?? array() );
		if( ! empty( $items ) ) {
			return $items;
		}

		$output = array();
		$labels = self::fallback_item_labels( $section, $count );
		for( $index = 0; $index < $count; $index++ ) {
			$output[] = array(
				'title' => $labels[$index] ?? sprintf( /* translators: %d: contextual value. */
				__( 'Detail %d', 'wphave' ), $index + 1 ),
				'text' => $section['body'] ?? '',
			);
		}

		return $output;
	}

	/**
	 * Fallback item labels.
	 *
	 * @param array $section Section.
	 * @param int $count Count.
	 * @return array Fallback item labels.
	 */

	protected static function fallback_item_labels( array $section, int $count ): array {
		$type = sanitize_key( $section['type'] ?? 'content' );
		$sets = array(
			'features' => array( __( 'Core value', 'wphave' ), __( 'Useful detail', 'wphave' ), __( 'Visitor benefit', 'wphave' ), __( 'Next proof', 'wphave' ) ),
			'steps' => array( __( 'Discover', 'wphave' ), __( 'Structure', 'wphave' ), __( 'Decide', 'wphave' ), __( 'Start', 'wphave' ) ),
			'stats' => array( __( 'Reach', 'wphave' ), __( 'Trust', 'wphave' ), __( 'Momentum', 'wphave' ), __( 'Outcome', 'wphave' ) ),
			'testimonials' => array( __( 'Customer signal', 'wphave' ), __( 'Proof point', 'wphave' ), __( 'Result', 'wphave' ) ),
			'offers' => array( __( 'Essential', 'wphave' ), __( 'Recommended', 'wphave' ), __( 'Advanced', 'wphave' ) ),
			'faq' => array( __( 'What matters first?', 'wphave' ), __( 'How does it work?', 'wphave' ), __( 'What happens next?', 'wphave' ), __( 'Who is it for?', 'wphave' ) ),
			'cta' => array( __( 'Clear next step', 'wphave' ), __( 'Low-friction contact', 'wphave' ) ),
			'content' => array( __( 'Context', 'wphave' ), __( 'Perspective', 'wphave' ), __( 'Evidence', 'wphave' ), __( 'Next step', 'wphave' ) ),
		);
		$labels = $sets[$type] ?? $sets['content'];

		return array_slice( $labels, 0, $count );
	}

	/**
	 * Sanitize items.
	 *
	 * @param array $items Items.
	 * @return array Sanitize items.
	 */

	protected static function sanitize_items( $items ): array {
		$clean = array();

		foreach( array_slice( (array) $items, 0, 12 ) as $item ) {
			if( ! is_array( $item ) ) {
				continue;
			}

			$title = self::text( $item['title'] ?? '', 140 );
			$text = self::textarea( $item['text'] ?? '', 520 );
			if( $title === '' && $text === '' ) {
				continue;
			}

			$clean[] = array_filter( array(
				'title' => $title,
				'text' => $text,
			) );
		}

		return $clean;
	}

	/**
	 * Sanitize actions.
	 *
	 * @param mixed $actions Actions.
	 * @return array Sanitize actions.
	 */

	protected static function sanitize_actions( $actions ): array {
		$clean = array();

		foreach( array_slice( (array) $actions, 0, 4 ) as $action ) {
			if( ! is_array( $action ) ) {
				continue;
			}

			$label = self::text( $action['label'] ?? $action['content'] ?? '', 80 );
			if( $label === '' ) {
				continue;
			}

			$variant = sanitize_key( $action['variant'] ?? 'primary' );
			$clean[] = array(
				'label' => $label,
				'variant' => in_array( $variant, array( 'primary', 'secondary', 'tertiary' ), true ) ? $variant : 'primary',
				'url' => esc_url_raw( (string) ( $action['url'] ?? '' ) ),
			);
		}

		return $clean;
	}

	/**
	 * Default variant.
	 *
	 * @param string $type Type.
	 * @return string Default variant.
	 */

	protected static function default_variant( string $type ): string {
		if( $type === 'hero' ) {
			return 'centered';
		}

		if( in_array( $type, array( 'features', 'steps', 'stats' ), true ) ) {
			return 'grid';
		}

		return 'stacked';
	}

	/**
	 * Normalize block tree.
	 *
	 * @param array $plan Plan.
	 * @return array Normalize block tree.
	 */

	protected static function normalize_block_tree( array $plan ): array {
		foreach( array( 'blockTree', 'block_tree', 'blockDesignTree', 'block_design_tree', 'designTree', 'design_tree', 'tree' ) as $key ) {
			if( is_array( $plan[$key] ?? null ) && ! empty( $plan[$key]['nodes'] ) ) {
				$tree = $plan[$key];
				$tree['kind'] = sanitize_key( $tree['kind'] ?? 'page' ) ?: 'page';

				return $tree;
			}
		}

		if( is_array( $plan['page']['blockTree'] ?? null ) && ! empty( $plan['page']['blockTree']['nodes'] ) ) {
			$tree = $plan['page']['blockTree'];
			$tree['kind'] = sanitize_key( $tree['kind'] ?? 'page' ) ?: 'page';

			return $tree;
		}

		return array();
	}

	/**
	 * Current style context.
	 *
	 * @return array Current style context.
	 */

	protected static function current_style_context(): array {
		$current = wphave_data_get( 'site_globals' );
		$current = is_array( $current ) ? $current : array();

		return array(
			'designGroup' => $current['preset']['designGroup']['name'] ?? '',
			'colorPreset' => $current['preset']['colors']['name'] ?? '',
			'layout' => $current['layout'] ?? array(),
			'colors' => $current['colors'] ?? array(),
			'typography' => $current['typography'] ?? array(),
			'buttons' => $current['buttons'] ?? array(),
		);
	}

	/**
	 * Text.
	 *
	 * @param mixed $value Value.
	 * @param int $length Length.
	 * @return string Text.
	 */

	protected static function text( $value, int $length ): string {
		return trim( mb_substr( sanitize_text_field( (string) $value ), 0, $length ) );
	}

	/**
	 * Textarea.
	 *
	 * @param mixed $value Value.
	 * @param int $length Length.
	 * @return string Textarea.
	 */

	protected static function textarea( $value, int $length ): string {
		return trim( mb_substr( wp_strip_all_tags( (string) $value ), 0, $length ) );
	}

}
