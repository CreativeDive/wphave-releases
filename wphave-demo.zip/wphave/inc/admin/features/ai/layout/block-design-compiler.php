<?php

if( ! defined('ABSPATH') ) {
	exit;
}

/**
 * Experimental compiler for AI generated design block trees.
 *
 * This is intentionally closer to HTML/CSS composition thinking than the
 * semantic AST compiler. AI describes layout and design intent with a safe
 * JSON language. The compiler maps it to valid WPHAVE block attributes.
 */

class WPHAVE_AI_Block_Design_Compiler extends WPHAVE_Site_Composition_Builder {

	protected const NODE_KINDS = [ 'page', 'section', 'stack', 'flex', 'grid', 'surface', 'heading', 'paragraph', 'button', 'actions', 'spacer', 'line', 'visual' ];

	/**
	 * Contract payload.
	 *
	 * @return array Contract payload.
	 */

	public static function contract_payload(): array {
		return array(
			'description' => 'Experimental WPHAVE block design tree. Use this for freeform layout design. Think in spacing, surfaces, grid, flex, typography and hierarchy. Never output raw block markup, HTML or CSS.',
			'rootShape' => array(
				'kind' => 'page',
				'nodes' => array(
					array(
						'kind' => 'section|stack|flex|grid|surface|heading|paragraph|button|actions|spacer|line|visual',
						'style' => array(
							'background' => 'transparent|background|paper|dark|primary|secondary|accent|#hex',
							'padding' => 'none|xs|s|m|l|xl|2xl|3xl|4xl|5xl',
							'gap' => 'none|xs|s|m|l|xl|2xl|3xl',
							'width' => 'narrow|default|wide|full|640px|860px|1180px',
							'radius' => 'none|s|m|l|xl|pill',
							'border' => 'none|subtle|strong',
							'align' => 'start|center|end',
							'justify' => 'start|center|between|end',
						),
						'layout' => array(
							'columns' => 1,
						),
						'text' => array(
							'content' => 'text content',
							'level' => 'h1|h2|h3|h4',
							'size' => 'text-s|default|text-l|title-xs|title-s|title-m|title-l|title-xl',
							'color' => 'text|heading|muted|background|primary|secondary|accent|#hex',
							'align' => 'none|left|center|right',
						),
						'actions' => array(
							array(
								'label' => 'button label',
								'variant' => 'primary|secondary|tertiary',
							),
						),
						'nodes' => array(),
					),
				),
			),
			'rules' => array(
				'Use section for root-level page bands.',
				'Use stack, flex and grid for real layout decisions instead of asking for named templates.',
				'Use surface when something needs its own padding, background, radius or border.',
				'Use heading and paragraph for typography. Use text.size and text.align deliberately.',
				'Use style.padding, style.background, style.gap, style.radius, style.border and style.width as design language. The compiler maps those to WPHAVE attributes.',
				'Do not make every section a card grid. Vary section width, padding, background, alignment and layout.',
			),
		);
	}

	/**
	 * Compile.
	 *
	 * @param mixed $tree Tree.
	 */

	public static function compile( $tree ) {
		$tree = self::sanitize_node( $tree, 'page' );
		if( empty( $tree ) ) {
			return new WP_Error( 'ai_block_design_tree_empty', __( 'The block design tree is empty.', 'wphave' ), array( 'status' => 400 ) );
		}

		$content = self::compile_node( $tree, array( 'index' => 0 ) );
		if( trim( $content ) === '' ) {
			return new WP_Error( 'ai_block_design_tree_render_failed', __( 'The block design tree could not be rendered.', 'wphave' ), array( 'status' => 500 ) );
		}

		return $content;
	}

	/**
	 * Compile sections.
	 *
	 * @param mixed $tree Tree.
	 * @return array Compile sections.
	 */

	public static function compile_sections( $tree ): array {
		$tree = self::sanitize_node( $tree, 'page' );
		$nodes = is_array( $tree['nodes'] ?? null ) ? $tree['nodes'] : array();
		$sections = array();

		foreach( $nodes as $index => $node ) {
			$rendered = self::compile_node( $node, array( 'index' => $index ) );
			if( trim( $rendered ) === '' ) {
				continue;
			}

			$title = self::first_text( $node ) ?: sprintf( /* translators: %d: contextual value. */
			__( 'Section %d', 'wphave' ), $index + 1 );
			$sections[] = array(
				'id' => sanitize_key( (string) ( $node['id'] ?? 'block-tree-section-' . ( $index + 1 ) ) ),
				'title' => trim( mb_substr( sanitize_text_field( $title ), 0, 120 ) ),
				'type' => $index === 0 ? 'hero' : 'content',
				'archetype' => 'block-tree-' . sanitize_key( $node['kind'] ?? 'section' ),
				'layout' => sanitize_key( $node['kind'] ?? 'section' ),
				'treatment' => sanitize_key( $node['style']['background'] ?? 'neutral' ),
				'content' => self::group( $rendered, array(
					'planner' => array(
						'sectionId' => sanitize_key( (string) ( $node['id'] ?? 'block-tree-section-' . ( $index + 1 ) ) ),
						'sectionType' => $index === 0 ? 'hero' : 'content',
						'sectionIndex' => $index,
					),
				) ),
			);
		}

		return $sections;
	}

	/**
	 * Compile node.
	 *
	 * @param array $node Node.
	 * @param array $context Request or rendering context.
	 * @return string Compile node.
	 */

	protected static function compile_node( array $node, array $context = array() ): string {
		$kind = sanitize_key( $node['kind'] ?? 'stack' );
		$style = is_array( $node['style'] ?? null ) ? $node['style'] : array();
		$children = self::compile_children( $node );

		if( $kind === 'page' ) {
			return $children;
		}

		if( $kind === 'section' ) {
			return self::section( $children, array(
				'width' => self::width_value( $style['width'] ?? 'default' ),
				'gap' => self::gap_value( $style['gap'] ?? 'l' ),
				'padding' => self::section_padding( self::padding_token( $style['padding'] ?? '3xl' ), self::padding_token( $style['paddingBottom'] ?? $style['padding'] ?? '3xl' ) ),
				'background' => self::color_value( $style['background'] ?? 'transparent', 'transparent' ),
			) );
		}

		if( $kind === 'stack' ) {
			return self::stack( $children, self::gap_value( $style['gap'] ?? 'm' ), self::style_wphave( $style ) );
		}

		if( $kind === 'flex' ) {
			return self::flex( $children, self::gap_value( $style['gap'] ?? 'l' ), self::align_value( $style['align'] ?? 'center' ), self::justify_value( $style['justify'] ?? 'between' ), 'fill', self::style_wphave( $style ) );
		}

		if( $kind === 'grid' ) {
			$columns = max( 1, min( 6, absint( $node['layout']['columns'] ?? 3 ) ) );
			return self::grid( $children, $columns, self::gap_value( $style['gap'] ?? 'l' ), self::style_wphave( $style ) );
		}

		if( $kind === 'surface' ) {
			return self::surface( $children, array(
				'background' => self::color_value( $style['background'] ?? 'background', 'var(--wphave-site-color-background)' ),
				'padding' => self::inset( self::padding_token( $style['padding'] ?? 'l' ) ),
				'radius' => self::radius_value( $style['radius'] ?? 'm' ),
				'border' => self::border_value( $style['border'] ?? '' ),
				'gap' => self::gap_value( $style['gap'] ?? 'm' ),
			) );
		}

		if( $kind === 'heading' ) {
			$text = is_array( $node['text'] ?? null ) ? $node['text'] : array();
			return self::heading(
				self::text_value( $text['content'] ?? $node['content'] ?? '', 220 ),
				self::heading_level( $text['level'] ?? 'h2' ),
				self::text_size( $text['size'] ?? 'title-m' ),
				self::text_color( $text['color'] ?? 'heading' ),
				self::text_align( $text['align'] ?? 'none' ),
				self::typeface_value( $text )
			);
		}

		if( $kind === 'paragraph' ) {
			$text = is_array( $node['text'] ?? null ) ? $node['text'] : array();
			return self::paragraph(
				self::text_value( $text['content'] ?? $node['content'] ?? '', 1200 ),
				self::text_size( $text['size'] ?? 'default' ),
				self::text_color( $text['color'] ?? 'text' ),
				self::text_align( $text['align'] ?? 'none' )
			);
		}

		if( $kind === 'button' ) {
			return self::button( self::text_value( $node['label'] ?? $node['text']['content'] ?? '', 90 ), self::button_variant( $node['variant'] ?? 'primary' ) );
		}

		if( $kind === 'actions' ) {
			return self::button_row( self::actions( $node['actions'] ?? array() ), self::gap_value( $style['gap'] ?? 's' ) );
		}

		if( $kind === 'spacer' ) {
			return self::spacer( self::gap_value( $style['height'] ?? $style['size'] ?? 'l' ) );
		}

		if( $kind === 'line' ) {
			return self::line( self::color_value( $style['color'] ?? 'border', 'var(--wphave-site-color-background-contrast-3)' ) );
		}

		if( $kind === 'visual' ) {
			return self::surface(
				self::spacer( self::visual_height( $style['height'] ?? 'm' ) ),
				array(
					'background' => self::color_value( $style['background'] ?? 'secondary', 'var(--wphave-site-color-background-contrast-2)' ),
					'padding' => self::inset( self::padding_token( $style['padding'] ?? 'm' ) ),
					'radius' => self::radius_value( $style['radius'] ?? 'l' ),
					'border' => self::border_value( $style['border'] ?? '' ),
				)
			);
		}

		return $children;
	}

	/**
	 * Compile children.
	 *
	 * @param array $node Node.
	 * @return string Compile children.
	 */

	protected static function compile_children( array $node ): string {
		$content = '';
		foreach( (array) ( $node['nodes'] ?? array() ) as $child ) {
			if( is_array( $child ) ) {
				$content .= self::compile_node( $child );
			}
		}

		return $content;
	}

	/**
	 * Sanitize node.
	 *
	 * @param mixed $node Node.
	 * @param string $fallback_kind Fallback kind.
	 * @return array Sanitize node.
	 */

	protected static function sanitize_node( $node, string $fallback_kind = 'stack' ): array {
		if( ! is_array( $node ) ) {
			return array();
		}

		$kind = sanitize_key( $node['kind'] ?? $fallback_kind );
		if( ! in_array( $kind, self::NODE_KINDS, true ) ) {
			$kind = $fallback_kind;
		}

		$clean = array(
			'kind' => $kind,
			'id' => sanitize_key( (string) ( $node['id'] ?? '' ) ),
			'style' => is_array( $node['style'] ?? null ) ? $node['style'] : array(),
			'layout' => is_array( $node['layout'] ?? null ) ? $node['layout'] : array(),
			'text' => is_array( $node['text'] ?? null ) ? $node['text'] : array(),
			'content' => self::text_value( $node['content'] ?? '', 1200 ),
			'label' => self::text_value( $node['label'] ?? '', 120 ),
			'variant' => sanitize_key( (string) ( $node['variant'] ?? '' ) ),
			'actions' => is_array( $node['actions'] ?? null ) ? $node['actions'] : array(),
			'nodes' => array(),
		);

		foreach( array_slice( (array) ( $node['nodes'] ?? array() ), 0, 18 ) as $child ) {
			$child = self::sanitize_node( $child, 'stack' );
			if( ! empty( $child ) ) {
				$clean['nodes'][] = $child;
			}
		}

		return $clean;
	}

	/**
	 * Style wphave.
	 *
	 * @param array $style Style.
	 * @return array Style wphave.
	 */

	protected static function style_wphave( array $style ): array {
		$wphave = array();
		if( ! empty( $style['padding'] ) ) {
			$wphave['dimensions']['spacing']['padding'] = self::inset( self::padding_token( $style['padding'] ) );
		}

		if( ! empty( $style['background'] ) ) {
			$wphave['background']['color']['base'] = self::color_value( $style['background'], 'transparent' );
		}

		if( ! empty( $style['radius'] ) ) {
			$wphave['frame']['corners'] = self::radius_value( $style['radius'] );
		}

		if( ! empty( $style['border'] ) && self::border_value( $style['border'] ) ) {
			$wphave = array_replace_recursive( $wphave, self::border( self::border_value( $style['border'] )['color'], self::border_value( $style['border'] )['width'] ) );
		}

		return $wphave;
	}

	/**
	 * Padding token.
	 *
	 * @param mixed $value Value.
	 * @return string Padding token.
	 */

	protected static function padding_token( $value ): string {
		$value = sanitize_key( (string) $value );
		return in_array( $value, array( 'xs', 's', 'm', 'l', 'xl', '2xl', '3xl', '4xl', '5xl' ), true ) ? $value : ( $value === 'none' ? 'none' : 'm' );
	}

	/**
	 * Gap value.
	 *
	 * @param mixed $value Value.
	 * @return string Gap value.
	 */

	protected static function gap_value( $value ): string {
		$value = sanitize_key( (string) $value );
		if( $value === 'none' ) {
			return '0rem';
		}

		return self::gap_token( in_array( $value, array( 'xs', 's', 'm', 'l', 'xl', '2xl', '3xl' ), true ) ? $value : 'm' );
	}

	/**
	 * Width value.
	 *
	 * @param mixed $value Value.
	 * @return string Width value.
	 */

	protected static function width_value( $value ): string {
		$value = trim( (string) $value );
		$map = array(
			'narrow' => '760px',
			'default' => 'var(--wphave-site-layout-width)',
			'wide' => '1380px',
			'full' => '100%',
		);

		if( isset( $map[$value] ) ) {
			return $map[$value];
		}

		return preg_match( '/^\d{2,4}px$/', $value ) ? $value : 'var(--wphave-site-layout-width)';
	}

	/**
	 * Color value.
	 *
	 * @param mixed $value Value.
	 * @param string $fallback Fallback.
	 * @return string Color value.
	 */

	protected static function color_value( $value, string $fallback ): string {
		$value = trim( (string) $value );
		$map = array(
			'transparent' => 'transparent',
			'background' => 'var(--wphave-site-color-background)',
			'paper' => 'var(--wphave-site-color-background-subtle-1)',
			'dark' => 'var(--wphave-site-color-heading)',
			'primary' => 'var(--wphave-site-color-primary)',
			'secondary' => 'var(--wphave-site-color-secondary)',
			'accent' => 'var(--wphave-site-color-accent)',
			'border' => 'var(--wphave-site-color-background-contrast-3)',
		);

		if( isset( $map[$value] ) ) {
			return $map[$value];
		}

		return preg_match( '/^#([a-f0-9]{3}|[a-f0-9]{6})$/i', $value ) ? $value : $fallback;
	}

	/**
	 * Text color.
	 *
	 * @param mixed $value Value.
	 * @return string Text color.
	 */

	protected static function text_color( $value ): string {
		$value = trim( (string) $value );
		$map = array(
			'text' => 'var(--wphave-site-color-text)',
			'heading' => 'var(--wphave-site-color-heading)',
			'muted' => 'color-mix(in srgb, var(--wphave-site-color-text) 68%, transparent)',
			'background' => 'var(--wphave-site-color-background)',
			'primary' => 'var(--wphave-site-color-primary)',
			'secondary' => 'var(--wphave-site-color-secondary)',
			'accent' => 'var(--wphave-site-color-accent)',
		);

		if( isset( $map[$value] ) ) {
			return $map[$value];
		}

		return preg_match( '/^#([a-f0-9]{3}|[a-f0-9]{6})$/i', $value ) ? $value : $map['text'];
	}

	/**
	 * Radius value.
	 *
	 * @param mixed $value Value.
	 * @return string Radius value.
	 */

	protected static function radius_value( $value ): string {
		$value = sanitize_key( (string) $value );
		$map = array(
			'none' => '0px',
			's' => '6px',
			'm' => 'var(--wphave-site-corners)',
			'l' => 'calc(var(--wphave-site-corners) * 1.6)',
			'xl' => 'calc(var(--wphave-site-corners) * 2.4)',
			'pill' => '999px',
		);

		return $map[$value] ?? $map['m'];
	}

	/**
	 * Border value.
	 *
	 * @param mixed $value Value.
	 */

	protected static function border_value( $value ) {
		$value = sanitize_key( (string) $value );
		if( $value === 'subtle' ) {
			return array( 'color' => 'var(--wphave-site-color-background-contrast-3)', 'width' => '1px' );
		}

		if( $value === 'strong' ) {
			return array( 'color' => 'var(--wphave-site-color-heading)', 'width' => '1px' );
		}

		return false;
	}

	/**
	 * Align value.
	 *
	 * @param mixed $value Value.
	 * @return string Align value.
	 */

	protected static function align_value( $value ): string {
		$value = sanitize_key( (string) $value );
		return in_array( $value, array( 'start', 'center', 'end', 'stretch', 'flex-start' ), true ) ? $value : 'center';
	}

	/**
	 * Justify value.
	 *
	 * @param mixed $value Value.
	 * @return string Justify value.
	 */

	protected static function justify_value( $value ): string {
		$value = sanitize_key( (string) $value );
		$map = array(
			'start' => 'start',
			'center' => 'center',
			'between' => 'space-between',
			'end' => 'end',
		);

		return $map[$value] ?? 'space-between';
	}

	/**
	 * Heading level.
	 *
	 * @param mixed $value Value.
	 * @return string Heading level.
	 */

	protected static function heading_level( $value ): string {
		$value = strtolower( (string) $value );
		return in_array( $value, array( 'h1', 'h2', 'h3', 'h4' ), true ) ? $value : 'h2';
	}

	/**
	 * Text size.
	 *
	 * @param mixed $value Value.
	 * @return string Text size.
	 */

	protected static function text_size( $value ): string {
		$value = sanitize_key( (string) $value );
		return in_array( $value, array( 'text-s', 'default', 'text-l', 'title-xs', 'title-s', 'title-m', 'title-l', 'title-xl' ), true ) ? $value : 'default';
	}

	/**
	 * Text align.
	 *
	 * @param mixed $value Value.
	 * @return string Text align.
	 */

	protected static function text_align( $value ): string {
		$value = sanitize_key( (string) $value );
		return in_array( $value, array( 'none', 'left', 'center', 'right' ), true ) ? $value : 'none';
	}

	/**
	 * Typeface value.
	 *
	 * @param array $text Text.
	 * @return array Typeface value.
	 */

	protected static function typeface_value( array $text ): array {
		$output = array();
		if( ! empty( $text['lineHeight'] ) && preg_match( '/^(0\.[7-9]|1(\.\d{1,2})?|2)$/', (string) $text['lineHeight'] ) ) {
			$output['lineHeight'] = (string) $text['lineHeight'];
		}

		return $output;
	}

	/**
	 * Button variant.
	 *
	 * @param mixed $value Value.
	 * @return string Button variant.
	 */

	protected static function button_variant( $value ): string {
		$value = sanitize_key( (string) $value );
		return in_array( $value, array( 'primary', 'secondary', 'tertiary' ), true ) ? $value : 'primary';
	}

	/**
	 * Actions.
	 *
	 * @param mixed $actions Actions.
	 * @return array Actions.
	 */

	protected static function actions( $actions ): array {
		$output = array();
		foreach( array_slice( (array) $actions, 0, 3 ) as $action ) {
			if( ! is_array( $action ) || empty( $action['label'] ) ) {
				continue;
			}

			$output[] = array(
				'label' => self::text_value( $action['label'], 90 ),
				'variant' => self::button_variant( $action['variant'] ?? 'primary' ),
			);
		}

		return $output;
	}

	/**
	 * Visual height.
	 *
	 * @param mixed $value Value.
	 * @return string Visual height.
	 */

	protected static function visual_height( $value ): string {
		$value = sanitize_key( (string) $value );
		$map = array(
			's' => '120px',
			'm' => '220px',
			'l' => '340px',
			'xl' => '460px',
		);

		return $map[$value] ?? $map['m'];
	}

	/**
	 * First text.
	 *
	 * @param array $node Node.
	 * @return string First text.
	 */

	protected static function first_text( array $node ): string {
		if( ! empty( $node['text']['content'] ) ) {
			return self::text_value( $node['text']['content'], 160 );
		}

		foreach( (array) ( $node['nodes'] ?? array() ) as $child ) {
			if( is_array( $child ) ) {
				$text = self::first_text( $child );
				if( $text !== '' ) {
					return $text;
				}
			}
		}

		return '';
	}

	/**
	 * Text value.
	 *
	 * @param mixed $value Value.
	 * @param int $length Length.
	 * @return string Text value.
	 */

	protected static function text_value( $value, int $length ): string {
		return trim( mb_substr( sanitize_textarea_field( (string) $value ), 0, $length ) );
	}

}
