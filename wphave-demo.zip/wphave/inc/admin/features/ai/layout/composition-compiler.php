<?php

if( ! defined('ABSPATH') ) {
	exit;
}

/**
 * Compiles a small WPHAVE composition AST into serialized WPHAVE blocks.
 *
 * The AST is intentionally not raw block markup. AI may choose semantic nodes,
 * layout intent and slots, while this compiler owns valid block structure and
 * conservative design defaults.
 */

class WPHAVE_AI_Composition_Compiler extends WPHAVE_Site_Composition_Builder {

	protected const NODE_KINDS = [ 'page', 'section', 'hero', 'statement', 'showcase', 'cluster', 'rail', 'sidebar', 'band', 'stack', 'split', 'grid', 'card', 'notification', 'heading', 'paragraph', 'button', 'actions', 'list', 'stat', 'stats', 'tabs', 'divider', 'spacer', 'visual' ];

	/**
	 * Contract payload.
	 *
	 * @return array Contract payload.
	 */

	public static function contract_payload(): array {
		return array(
			'description' => 'WPHAVE Composition AST. Use this when the desired layout is not a fixed pattern. Return semantic nodes, never Gutenberg comments or raw wphave attributes.',
			'rootShape' => array(
				'kind' => 'page',
				'intent' => 'short page intent',
				'design' => array(
					'system' => 'premium|editorial|catalog|playful|institutional|minimal|bold|magazine|product|service|community',
					'motif' => 'poster|split-panels|dense-bento|story-rail|comparison|catalog|dashboard|brochure|lookbook|index',
					'sectionRhythm' => 'long-scroll|short-pages|alternating|editorial|modular|catalog',
					'surfaceStyle' => 'flat|soft|outlined|glass|dark|paper|minimal',
					'heroStyle' => 'poster|split-proof|centered-editorial|catalog-lead|image-card|statement',
					'cardStyle' => 'flat|bordered|soft|compact|editorial|media',
				),
				'nodes' => array(
					array(
						'kind' => 'section|hero|statement|showcase|cluster|rail|sidebar|band|grid|split|stack|card|notification|stats|tabs|visual',
						'id' => 'optional stable id',
						'tone' => 'neutral|primary|secondary|accent|success|warning|danger|dark|paper',
						'emphasis' => 'low|medium|high',
						'layout' => array(
							'type' => 'stack|split|grid|bento|centered|band',
							'columns' => 1,
							'gap' => 's|m|l|xl|2xl|3xl',
							'width' => 'narrow|default|wide|full',
						),
						'slots' => array(
							'eyebrow' => 'optional label',
							'heading' => 'required when useful',
							'lead' => 'supporting paragraph',
							'text' => 'body text',
							'button' => 'primary action label',
							'items' => array(
								array(
									'heading' => 'item heading',
									'text' => 'item text',
									'button' => 'optional action',
								),
							),
						),
						'nodes' => array(),
					),
				),
			),
			'rules' => array(
				'Prefer this AST for custom requests like notifications, three-column layouts, comparison sections, proof bands, cards, tabs, CTA bands and custom content groups.',
				'Use section or hero as root-level page nodes. Put layout nodes inside sections.',
				'Use grid with columns 2, 3 or 4 for multi-column layouts. Use split for asymmetric text plus visual/proof.',
				'Use statement, showcase, cluster, rail, sidebar and band when the page needs a stronger composition than normal sections.',
				'Use notification for success/warning/danger/info messages. Use tone success for positive confirmations.',
				'Choose a design object before nodes. Different industries should produce different design systems, motifs and hero styles.',
				'Do not repeat the same text in every item. If items are not meaningful, omit items and use a text-focused section.',
				'Use emphasis high only once or twice per page.',
			),
		);
	}

	/**
	 * Compile.
	 *
	 * @param mixed $ast Ast.
	 */

	public static function compile( $ast ) {
		$ast = self::sanitize_node( $ast, 'page' );
		if( empty( $ast ) ) {
			return new WP_Error( 'ai_composition_ast_empty', __( 'The composition AST is empty.', 'wphave' ), array( 'status' => 400 ) );
		}

		$content = self::compile_node( $ast, array( 'root' => true, 'index' => 0 ) );
		if( trim( $content ) === '' ) {
			return new WP_Error( 'ai_composition_ast_render_failed', __( 'The composition AST could not be rendered.', 'wphave' ), array( 'status' => 500 ) );
		}

		return $content;
	}

	/**
	 * Compile sections.
	 *
	 * @param mixed $ast Ast.
	 * @return array Compile sections.
	 */

	public static function compile_sections( $ast ): array {
		$ast = self::sanitize_node( $ast, 'page' );
		$nodes = is_array( $ast['nodes'] ?? null ) ? $ast['nodes'] : array();
		$design = self::design_context( $ast );
		$sections = array();

		foreach( $nodes as $index => $node ) {
			$kind = sanitize_key( $node['kind'] ?? 'section' );
			$rendered = self::compile_node( $node, array( 'root' => false, 'index' => $index, 'design' => $design ) );
			if( trim( $rendered ) === '' ) {
				continue;
			}

			$heading = self::slot( $node, 'heading' ) ?: self::slot( $node, 'eyebrow' ) ?: sprintf( __( 'Section %d', 'wphave' ), $index + 1 );
			$sections[] = array(
				'id' => sanitize_key( (string) ( $node['id'] ?? 'ast-section-' . ( $index + 1 ) ) ),
				'title' => trim( mb_substr( sanitize_text_field( $heading ), 0, 120 ) ),
				'type' => $kind === 'hero' ? 'hero' : 'content',
				'archetype' => 'ast-' . $kind,
				'layout' => sanitize_key( $node['layout']['type'] ?? $kind ),
				'treatment' => sanitize_key( $node['tone'] ?? 'neutral' ),
				'content' => self::group( $rendered, array(
					'planner' => array(
						'sectionId' => sanitize_key( (string) ( $node['id'] ?? 'ast-section-' . ( $index + 1 ) ) ),
						'sectionType' => $kind === 'hero' ? 'hero' : 'content',
						'sectionIndex' => $index,
					),
				) ),
			);
		}

		return $sections;
	}

	/**
	 * Compile node.
	 *
	 * @param array $node Node.
	 * @param array $context Request or rendering context.
	 * @return string Compile node.
	 */

	protected static function compile_node( array $node, array $context = array() ): string {
		$kind = sanitize_key( $node['kind'] ?? 'section' );
		$index = absint( $context['index'] ?? 0 );
		$design = self::design_context( $node, $context );

		if( $kind === 'page' ) {
			$content = '';
			foreach( (array) ( $node['nodes'] ?? array() ) as $child_index => $child ) {
				if( is_array( $child ) ) {
					$content .= self::compile_node( $child, array( 'index' => $child_index, 'design' => $design ) );
				}
			}

			return $content;
		}

		if( $kind === 'hero' ) {
			return self::compile_hero( $node, $index, $design );
		}

		if( $kind === 'statement' ) {
			return self::compile_statement( $node, $index, $design );
		}

		if( $kind === 'showcase' ) {
			return self::compile_showcase( $node, $index, $design );
		}

		if( $kind === 'cluster' ) {
			return self::compile_cluster( $node, $index, $design );
		}

		if( $kind === 'rail' ) {
			return self::compile_rail( $node, $index, $design );
		}

		if( $kind === 'sidebar' ) {
			return self::compile_sidebar( $node, $index, $design );
		}

		if( $kind === 'band' ) {
			return self::compile_band( $node, $index, $design );
		}

		if( $kind === 'section' ) {
			return self::compile_section( $node, $index, $design );
		}

		if( $kind === 'grid' ) {
			return self::compile_grid( $node, $index, $design );
		}

		if( $kind === 'split' ) {
			return self::compile_split( $node, $index, $design );
		}

		if( $kind === 'stack' ) {
			return self::stack( self::compile_children( $node, $index, $design ), self::gap( $node, 'm' ) );
		}

		if( $kind === 'card' ) {
			return self::compile_card( $node, $index, $design );
		}

		if( $kind === 'notification' ) {
			return self::compile_notification( $node );
		}

		if( $kind === 'heading' ) {
			return self::heading( self::slot( $node, 'heading' ) ?: self::slot( $node, 'text' ), 'h3', self::heading_size( $node ) );
		}

		if( $kind === 'paragraph' ) {
			return self::paragraph( self::slot( $node, 'text' ) ?: self::slot( $node, 'lead' ) );
		}

		if( $kind === 'button' ) {
			return self::button( self::slot( $node, 'button' ) ?: self::slot( $node, 'text' ) ?: __( 'Learn more', 'wphave' ), self::button_variant( $node ) );
		}

		if( $kind === 'actions' ) {
			return self::compile_actions( $node );
		}

		if( $kind === 'list' ) {
			return self::compile_list( $node );
		}

		if( $kind === 'stat' ) {
			return self::compile_stat( $node, $index );
		}

		if( $kind === 'stats' ) {
			return self::compile_stats( $node, $index, $design );
		}

		if( $kind === 'tabs' ) {
			return self::compile_tabs( $node );
		}

		if( $kind === 'divider' ) {
			return self::line();
		}

		if( $kind === 'spacer' ) {
			return self::spacer( self::gap( $node, 'l' ) );
		}

		if( $kind === 'visual' ) {
			return self::compile_visual( $node, $design );
		}

		return '';
	}

	/**
	 * Compile hero.
	 *
	 * @param array $node Node.
	 * @param int $index Index.
	 * @param array $design Design.
	 * @return string Compile hero.
	 */

	protected static function compile_hero( array $node, int $index, array $design = array() ): string {
		$emphasis = sanitize_key( $node['emphasis'] ?? 'medium' );
		$hero_style = sanitize_key( $design['heroStyle'] ?? '' );
		$layout = sanitize_key( $node['layout']['type'] ?? '' );
		if( $layout === '' ) {
			$layout = in_array( $hero_style, array( 'centered-editorial', 'statement' ), true ) ? 'centered' : 'split';
		}
		$heading_size = in_array( $hero_style, array( 'poster', 'statement' ), true ) || $emphasis === 'high' ? 'title-xl' : 'title-l';
		$is_centered = $layout === 'centered';
		$text = self::stack(
			self::eyebrow_label( self::slot( $node, 'eyebrow' ), self::tone_text_color( $node, 'muted' ) ) .
			( self::slot( $node, 'heading' ) ? self::heading( self::slot( $node, 'heading' ), 'h1', $heading_size, self::tone_text_color( $node, 'heading' ), $is_centered ? 'center' : 'none', array( 'lineHeight' => in_array( $hero_style, array( 'poster', 'statement' ), true ) ? '0.92' : '1.04' ) ) : '' ) .
			( self::slot( $node, 'lead' ) || self::slot( $node, 'text' ) ? self::paragraph( self::slot( $node, 'lead' ) ?: self::slot( $node, 'text' ), 'text-l', self::tone_text_color( $node, 'text' ), $is_centered ? 'center' : 'none' ) : '' ) .
			self::actions_markup_from_node( $node ),
			self::gap( $node, in_array( $hero_style, array( 'poster', 'statement' ), true ) ? 'xl' : 'l' ),
			array( 'dimensions' => [ 'width' => [ 'limit' => 'max', 'custom' => $is_centered ? '920px' : '660px' ] ] )
		);
		$visual = in_array( $hero_style, array( 'centered-editorial', 'statement' ), true ) ? '' : self::compile_visual( array(
			'kind' => 'visual',
			'tone' => $node['tone'] ?? 'primary',
			'slots' => array(
				'heading' => self::slot( $node, 'heading' ),
				'text' => self::slot( $node, 'lead' ),
			),
		), $design );
		$args = array(
			'background' => self::section_background_for( $node, $index, $design ),
			'padding' => self::section_padding( in_array( $hero_style, array( 'poster', 'statement' ), true ) ? '5xl' : ( $emphasis === 'high' ? '4xl' : '3xl' ), '3xl' ),
		);

		return self::section(
			$is_centered
				? self::stack( $text, self::gap( $node, 'l' ), array( 'layout' => [ 'stacked' => [ 'contentPosition' => 'center' ] ] ) )
				: self::flex( $text . $visual, self::gap( $node, '3xl' ), 'center', 'space-between', 'fill' ),
			$args
		);
	}

	/**
	 * Compile statement.
	 *
	 * @param array $node Node.
	 * @param int $index Index.
	 * @param array $design Design.
	 * @return string Compile statement.
	 */

	protected static function compile_statement( array $node, int $index, array $design = array() ): string {
		$align = sanitize_key( $node['layout']['align'] ?? '' ) === 'center' || in_array( sanitize_key( $design['system'] ?? '' ), array( 'editorial', 'magazine', 'institutional' ), true ) ? 'center' : 'none';
		$content = self::stack(
			self::eyebrow_label( self::slot( $node, 'eyebrow' ) ) .
			( self::slot( $node, 'heading' ) ? self::heading( self::slot( $node, 'heading' ), 'h2', sanitize_key( $node['emphasis'] ?? '' ) === 'high' ? 'title-xl' : 'title-l', 'var(--wphave-site-color-heading)', $align, array( 'lineHeight' => '0.98' ) ) : '' ) .
			( self::slot( $node, 'lead' ) || self::slot( $node, 'text' ) ? self::paragraph( self::slot( $node, 'lead' ) ?: self::slot( $node, 'text' ), 'text-l', 'var(--wphave-site-color-text)', $align ) : '' ) .
			self::actions_markup_from_node( $node ),
			self::gap( $node, 'xl' ),
			array( 'dimensions' => [ 'width' => [ 'limit' => 'max', 'custom' => $align === 'center' ? '980px' : '760px' ] ] )
		);

		return self::section(
			$content,
			array(
				'background' => self::section_background_for( $node, $index, $design ),
				'padding' => self::section_padding( '5xl', '5xl' ),
			)
		);
	}

	/**
	 * Compile showcase.
	 *
	 * @param array $node Node.
	 * @param int $index Index.
	 * @param array $design Design.
	 * @return string Compile showcase.
	 */

	protected static function compile_showcase( array $node, int $index, array $design = array() ): string {
		$items = self::slot_items( $node );
		$cards = '';
		foreach( array_slice( $items, 0, 4 ) as $item_index => $item ) {
			$cards .= self::compile_card( array(
				'kind' => 'card',
				'tone' => $item['tone'] ?? ( $item_index === 0 ? 'primary' : 'neutral' ),
				'emphasis' => $item_index === 0 ? 'high' : 'medium',
				'slots' => array(
					'eyebrow' => $item['value'] ?? '',
					'heading' => $item['heading'] ?? $item['title'] ?? '',
					'text' => $item['text'] ?? '',
					'button' => $item['button'] ?? '',
				),
			), $item_index, $design );
		}
		$left = self::stack(
			self::intro_from_node( $node, $design ) .
			self::actions_markup_from_node( $node ),
			self::gap( $node, 'xl' ),
			array( 'dimensions' => [ 'width' => [ 'limit' => 'max', 'custom' => '520px' ] ] )
		);
		$right = $cards ? self::bento_grid( array_map( 'strval', self::split_blocks( $cards ) ), array(), self::gap( $node, 'l' ) ) : self::compile_visual( $node, $design );

		return self::section(
			self::flex( $left . $right, self::gap( $node, '3xl' ), 'stretch', 'space-between', 'fill' ),
			array(
				'background' => self::section_background_for( $node, $index, $design ),
				'padding' => self::section_padding( self::emphasis_padding( $node ), self::emphasis_padding( $node ) ),
			)
		);
	}

	/**
	 * Compile cluster.
	 *
	 * @param array $node Node.
	 * @param int $index Index.
	 * @param array $design Design.
	 * @return string Compile cluster.
	 */

	protected static function compile_cluster( array $node, int $index, array $design = array() ): string {
		$items = self::slot_items( $node );
		$cards = '';
		foreach( $items as $item_index => $item ) {
			$cards .= self::compile_card( array(
				'kind' => 'card',
				'tone' => $item['tone'] ?? ( $item_index % 3 === 1 ? 'secondary' : 'neutral' ),
				'emphasis' => $item_index === 0 ? 'high' : 'medium',
				'slots' => array(
					'heading' => $item['heading'] ?? $item['title'] ?? '',
					'text' => $item['text'] ?? '',
					'button' => $item['button'] ?? '',
				),
			), $item_index, $design );
		}

		return self::section(
			self::stack(
				self::intro_from_node( $node, $design ) .
				( $cards ? self::bento_grid( array_map( 'strval', self::split_blocks( $cards ) ), array(), self::gap( $node, 'l' ) ) : self::content_from_slots( $node ) ),
				self::gap( $node, '2xl' )
			),
			array(
				'background' => self::section_background_for( $node, $index, $design ),
				'padding' => self::section_padding( self::emphasis_padding( $node ), self::emphasis_padding( $node ) ),
			)
		);
	}

	/**
	 * Compile rail.
	 *
	 * @param array $node Node.
	 * @param int $index Index.
	 * @param array $design Design.
	 * @return string Compile rail.
	 */

	protected static function compile_rail( array $node, int $index, array $design = array() ): string {
		$items = self::slot_items( $node );
		$steps = '';
		foreach( array_slice( $items, 0, 6 ) as $item_index => $item ) {
			$steps .= self::surface(
				self::stack(
					self::eyebrow_label( str_pad( (string) ( $item_index + 1 ), 2, '0', STR_PAD_LEFT ) ) .
					self::heading( $item['heading'] ?? $item['title'] ?? '', 'h3', 'title-xs' ) .
					self::paragraph( $item['text'] ?? '', 'text-s' ),
					self::gap( $node, 's' )
				),
				array(
					'background' => $item_index % 2 ? self::tone_colors( 'secondary', $item_index )['background'] : 'transparent',
					'border' => [ 'color' => 'var(--wphave-site-color-background-contrast-3)' ],
					'padding' => self::inset( 'm' ),
					'radius' => 'var(--wphave-site-corners)',
				)
			);
		}

		return self::section(
			self::stack(
				self::intro_from_node( $node, $design ) .
				self::flex( $steps, self::gap( $node, 'm' ), 'stretch', 'space-between', 'fill' ),
				self::gap( $node, 'xl' )
			),
			array(
				'background' => self::section_background_for( $node, $index, $design ),
				'padding' => self::section_padding( self::emphasis_padding( $node ), self::emphasis_padding( $node ) ),
			)
		);
	}

	/**
	 * Compile sidebar.
	 *
	 * @param array $node Node.
	 * @param int $index Index.
	 * @param array $design Design.
	 * @return string Compile sidebar.
	 */

	protected static function compile_sidebar( array $node, int $index, array $design = array() ): string {
		$items = self::slot_items( $node );
		$cards = '';
		foreach( $items as $item_index => $item ) {
			$cards .= self::compile_card( array(
				'kind' => 'card',
				'tone' => $item['tone'] ?? 'neutral',
				'style' => 'compact',
				'slots' => array(
					'heading' => $item['heading'] ?? $item['title'] ?? '',
					'text' => $item['text'] ?? '',
				),
			), $item_index, $design );
		}
		$sidebar = self::stack(
			self::intro_from_node( $node, $design ) .
			self::actions_markup_from_node( $node ),
			self::gap( $node, 'l' ),
			array( 'dimensions' => [ 'width' => [ 'limit' => 'max', 'custom' => '420px' ] ] )
		);
		$main = $cards ? self::grid( $cards, max( 2, min( 3, absint( $node['layout']['columns'] ?? 2 ) ) ), self::gap( $node, 'm' ) ) : self::compile_visual( $node, $design );

		return self::section(
			self::flex( $sidebar . $main, self::gap( $node, '3xl' ), 'flex-start', 'space-between', 'fill' ),
			array(
				'background' => self::section_background_for( $node, $index, $design ),
				'padding' => self::section_padding( self::emphasis_padding( $node ), self::emphasis_padding( $node ) ),
			)
		);
	}

	/**
	 * Compile band.
	 *
	 * @param array $node Node.
	 * @param int $index Index.
	 * @param array $design Design.
	 * @return string Compile band.
	 */

	protected static function compile_band( array $node, int $index, array $design = array() ): string {
		$colors = self::tone_colors( sanitize_key( $node['tone'] ?? 'dark' ), $index );
		$content = self::flex(
			self::stack(
				self::eyebrow_label( self::slot( $node, 'eyebrow' ), $colors['text'] ) .
				( self::slot( $node, 'heading' ) ? self::heading( self::slot( $node, 'heading' ), 'h2', 'title-l', $colors['heading'] ) : '' ) .
				( self::slot( $node, 'lead' ) || self::slot( $node, 'text' ) ? self::paragraph( self::slot( $node, 'lead' ) ?: self::slot( $node, 'text' ), 'text-l', $colors['text'] ) : '' ),
				self::gap( $node, 'm' )
			) .
			self::actions_markup_from_node( $node ),
			self::gap( $node, '2xl' ),
			'center',
			'space-between',
			'fill'
		);

		return self::section(
			$content,
			array(
				'background' => $colors['background'],
				'padding' => self::section_padding( '3xl', '3xl' ),
			)
		);
	}

	/**
	 * Compile section.
	 *
	 * @param array $node Node.
	 * @param int $index Index.
	 * @param array $design Design.
	 * @return string Compile section.
	 */

	protected static function compile_section( array $node, int $index, array $design = array() ): string {
		$children = self::compile_children( $node, $index, $design );
		$intro = self::intro_from_node( $node, $design );
		$layout = sanitize_key( $node['layout']['type'] ?? '' );
		$content = $children ?: self::content_from_slots( $node );

		if( $layout === 'grid' || ! empty( $node['slots']['items'] ) ) {
			return self::compile_grid( array_replace_recursive( $node, array( 'kind' => 'grid' ) ), $index, $design );
		}

		if( $layout === 'split' ) {
			return self::compile_split( array_replace_recursive( $node, array( 'kind' => 'split' ) ), $index, $design );
		}

		return self::section(
			$intro . $content,
			array(
				'background' => self::section_background_for( $node, $index, $design ),
				'padding' => self::section_padding( self::emphasis_padding( $node ), self::emphasis_padding( $node ) ),
			)
		);
	}

	/**
	 * Compile grid.
	 *
	 * @param array $node Node.
	 * @param int $index Index.
	 * @param array $design Design.
	 * @return string Compile grid.
	 */

	protected static function compile_grid( array $node, int $index, array $design = array() ): string {
		$items = self::slot_items( $node );
		$content = self::compile_children( $node, $index, $design );

		if( empty( $content ) && ! empty( $items ) ) {
			foreach( $items as $item_index => $item ) {
				$content .= self::compile_card( array(
					'kind' => 'card',
					'tone' => $item['tone'] ?? ( $item_index === 1 ? 'secondary' : 'neutral' ),
					'slots' => array(
						'heading' => $item['heading'] ?? $item['title'] ?? '',
						'text' => $item['text'] ?? '',
						'button' => $item['button'] ?? '',
					),
				), $item_index, $design );
			}
		}

		if( trim( $content ) === '' ) {
			$content = self::content_from_slots( $node );
		}

		$columns = max( 1, min( 4, absint( $node['layout']['columns'] ?? ( count( $items ) ?: 3 ) ) ) );
		$grid_type = sanitize_key( $node['layout']['type'] ?? '' );
		$should_bento = ( $grid_type === 'bento' || sanitize_key( $design['motif'] ?? '' ) === 'dense-bento' ) && count( $items ) > 2;
		$grid = $should_bento
			? self::bento_grid( array_map( 'strval', self::split_blocks( $content ) ), array(), self::gap( $node, 'l' ) )
			: self::grid( $content, $columns, self::gap( $node, 'l' ) );

		return self::section(
			self::stack(
				self::intro_from_node( $node, $design ) .
				$grid,
				self::gap( $node, 'xl' )
			),
			array(
				'background' => self::section_background_for( $node, $index, $design ),
				'padding' => self::section_padding( self::emphasis_padding( $node ), self::emphasis_padding( $node ) ),
			)
		);
	}

	/**
	 * Compile split.
	 *
	 * @param array $node Node.
	 * @param int $index Index.
	 * @param array $design Design.
	 * @return string Compile split.
	 */

	protected static function compile_split( array $node, int $index, array $design = array() ): string {
		$children = array_values( array_filter( (array) ( $node['nodes'] ?? array() ), 'is_array' ) );
		if( count( $children ) >= 2 ) {
			$left = self::compile_node( $children[0], array( 'index' => 0, 'design' => $design ) );
			$right = self::compile_node( $children[1], array( 'index' => 1, 'design' => $design ) );
		} else {
			$left = self::stack(
				self::intro_from_node( $node, $design ) .
				self::actions_markup_from_node( $node ),
				self::gap( $node, 'l' )
			);
			$right = self::compile_visual( $node, $design );
		}

		return self::section(
			self::flex( $left . $right, self::gap( $node, '3xl' ), 'center', 'space-between', 'fill' ),
			array(
				'background' => self::section_background_for( $node, $index, $design ),
				'padding' => self::section_padding( self::emphasis_padding( $node ), self::emphasis_padding( $node ) ),
			)
		);
	}

	/**
	 * Compile card.
	 *
	 * @param array $node Node.
	 * @param int $index Index.
	 * @param array $design Design.
	 * @return string Compile card.
	 */

	protected static function compile_card( array $node, int $index, array $design = array() ): string {
		$colors = self::tone_colors( sanitize_key( $node['tone'] ?? 'neutral' ), $index );
		$heading_size = sanitize_key( $node['emphasis'] ?? '' ) === 'high' ? 'title-s' : 'title-xs';
		$card_style = sanitize_key( $node['style'] ?? $design['cardStyle'] ?? '' );
		$content = self::stack(
			self::eyebrow_label( self::slot( $node, 'eyebrow' ), $colors['text'] ) .
			( self::slot( $node, 'heading' ) ? self::heading( self::slot( $node, 'heading' ), 'h3', $heading_size, $colors['heading'] ) : '' ) .
			( self::slot( $node, 'text' ) || self::slot( $node, 'lead' ) ? self::paragraph( self::slot( $node, 'text' ) ?: self::slot( $node, 'lead' ), 'default', $colors['text'] ) : '' ) .
			self::actions_markup_from_node( $node ),
			self::gap( $node, 'm' )
		);
		$background = $card_style === 'flat' || $card_style === 'editorial' ? 'transparent' : $colors['background'];
		$border = $card_style === 'flat' || $card_style === 'editorial' ? 'transparent' : $colors['border'];
		$padding = in_array( $card_style, array( 'compact', 'editorial' ), true ) ? 's' : ( sanitize_key( $node['emphasis'] ?? '' ) === 'high' ? 'xl' : 'm' );

		return self::surface( $content, array(
			'background' => $background,
			'border' => [ 'color' => $border ],
			'padding' => self::inset( $padding ),
			'radius' => in_array( $card_style, array( 'editorial', 'flat' ), true ) || sanitize_key( $node['tone'] ?? '' ) === 'paper' ? '0px' : 'var(--wphave-site-corners)',
		) );
	}

	/**
	 * Compile notification.
	 *
	 * @param array $node Node.
	 * @return string Compile notification.
	 */

	protected static function compile_notification( array $node ): string {
		$tone = sanitize_key( $node['tone'] ?? 'primary' );
		$colors = self::tone_colors( $tone, 0 );
		$icon_label = self::notification_icon_label( $tone );

		return self::surface(
			self::flex(
				self::badge( $icon_label, array(
					'background' => $colors['badgeBackground'],
					'color' => $colors['badgeText'],
					'padding' => '0.45rem 0.65rem 0.45rem 0.65rem',
				) ) .
				self::stack(
					( self::slot( $node, 'heading' ) ? self::heading( self::slot( $node, 'heading' ), 'h3', 'title-xs', $colors['heading'] ) : '' ) .
					( self::slot( $node, 'text' ) || self::slot( $node, 'lead' ) ? self::paragraph( self::slot( $node, 'text' ) ?: self::slot( $node, 'lead' ), 'text-s', $colors['text'] ) : '' ),
					'0.25rem'
				) .
				self::actions_markup_from_node( $node ),
				self::gap( $node, 'm' ),
				'center',
				'space-between',
				'fill'
			),
			array(
				'background' => $colors['background'],
				'border' => [ 'color' => $colors['border'] ],
				'padding' => self::inset( 'm' ),
				'radius' => 'var(--wphave-site-corners)',
			)
		);
	}

	/**
	 * Compile stats.
	 *
	 * @param array $node Node.
	 * @param int $index Index.
	 * @param array $design Design.
	 * @return string Compile stats.
	 */

	protected static function compile_stats( array $node, int $index, array $design = array() ): string {
		$items = self::slot_items( $node );
		$content = '';

		foreach( array_slice( $items, 0, 4 ) as $item_index => $item ) {
			$content .= self::compile_stat( array(
				'kind' => 'stat',
				'tone' => $item['tone'] ?? $node['tone'] ?? 'neutral',
				'slots' => array(
					'heading' => $item['heading'] ?? $item['title'] ?? '',
					'text' => $item['text'] ?? '',
					'value' => $item['value'] ?? $item['number'] ?? '',
				),
			), $item_index );
		}

		return self::section(
			self::stack(
				self::intro_from_node( $node, $design ) .
				self::grid( $content, min( 4, max( 1, count( $items ) ) ), self::gap( $node, 'l' ) ),
				self::gap( $node, 'xl' )
			),
			array( 'background' => self::section_background_for( $node, $index, $design ) )
		);
	}

	/**
	 * Compile stat.
	 *
	 * @param array $node Node.
	 * @param int $index Index.
	 * @return string Compile stat.
	 */

	protected static function compile_stat( array $node, int $index ): string {
		$value = self::slot( $node, 'value' );
		$number = (int) preg_replace( '/\D+/', '', $value ?: self::slot( $node, 'heading' ) );

		return self::metric_card(
			max( 1, $number ?: ( $index + 1 ) * 10 ),
			self::slot( $node, 'heading' ),
			self::slot( $node, 'text' ),
			array( 'background' => self::tone_colors( sanitize_key( $node['tone'] ?? 'neutral' ), $index )['background'] )
		);
	}

	/**
	 * Compile tabs.
	 *
	 * @param array $node Node.
	 * @return string Compile tabs.
	 */

	protected static function compile_tabs( array $node ): string {
		$items = array();
		foreach( self::slot_items( $node ) as $item ) {
			$items[] = array(
				'title' => $item['heading'] ?? $item['title'] ?? '',
				'content' => self::paragraph( $item['text'] ?? '' ),
			);
		}

		return empty( $items ) ? '' : self::tabs( $items );
	}

	/**
	 * Compile visual.
	 *
	 * @param array $node Node.
	 * @param array $design Design.
	 * @return string Compile visual.
	 */

	protected static function compile_visual( array $node, array $design = array() ): string {
		$tone = sanitize_key( $node['tone'] ?? 'primary' );
		$colors = self::tone_colors( $tone, 0 );
		$text = self::slot( $node, 'heading' ) ?: self::slot( $node, 'eyebrow' ) ?: __( 'Visual', 'wphave' );
		$is_dark = $tone === 'dark';
		$surface_style = sanitize_key( $design['surfaceStyle'] ?? '' );
		$label_background = $is_dark ? 'rgba(255,255,255,0.16)' : 'rgba(255,255,255,0.62)';
		$label_color = $is_dark ? 'var(--wphave-site-color-background)' : $colors['heading'];
		$height = in_array( sanitize_key( $design['motif'] ?? '' ), array( 'poster', 'lookbook' ), true ) ? '320px' : '220px';

		return self::surface(
			self::stack(
				self::eyebrow_label( mb_substr( $text, 0, 22 ), $label_color ) .
				self::spacer( $height ) .
				self::group( '', array(
					'dimensions' => array(
						'width' => array( 'limit' => 'custom', 'custom' => '42%' ),
						'height' => array( 'min' => '10px' ),
					),
					'background' => array( 'color' => array( 'base' => $label_background ) ),
					'frame' => array( 'corners' => '999px' ),
				) ),
				self::gap( $node, 'm' )
			),
			array(
				'treatment' => $is_dark || $surface_style === 'dark' ? 'dark-glow' : ( $surface_style === 'flat' || $surface_style === 'minimal' ? 'default' : 'glass' ),
				'treatmentArgs' => array(
					'background' => $is_dark ? 'var(--wphave-site-color-heading)' : $colors['background'],
					'border' => $colors['border'],
				),
				'padding' => self::inset( 'm' ),
				'radius' => 'calc(var(--wphave-site-corners) * 1.4)',
			)
		);
	}

	/**
	 * Split blocks.
	 *
	 * @param string $content Content to process.
	 * @return array Split blocks.
	 */

	protected static function split_blocks( string $content ): array {
		$parts = preg_split( '/(?=<!-- wp:wphave\\/group\\b)/', $content, -1, PREG_SPLIT_NO_EMPTY );
		$parts = array_values( array_filter( array_map( 'trim', is_array( $parts ) ? $parts : array() ) ) );

		return empty( $parts ) ? array( $content ) : $parts;
	}

	/**
	 * Compile list.
	 *
	 * @param array $node Node.
	 * @return string Compile list.
	 */

	protected static function compile_list( array $node ): string {
		$labels = array();
		foreach( self::slot_items( $node ) as $item ) {
			$labels[] = $item['heading'] ?? $item['title'] ?? $item['text'] ?? '';
		}

		return self::list( array_values( array_filter( $labels ) ) );
	}

	/**
	 * Compile actions.
	 *
	 * @param array $node Node.
	 * @return string Compile actions.
	 */

	protected static function compile_actions( array $node ): string {
		return self::button_row( self::actions_from_node( $node ) );
	}

	/**
	 * Compile children.
	 *
	 * @param array $node Node.
	 * @param int $index Index.
	 * @param array $design Design.
	 * @return string Compile children.
	 */

	protected static function compile_children( array $node, int $index, array $design = array() ): string {
		$content = '';
		foreach( (array) ( $node['nodes'] ?? array() ) as $child_index => $child ) {
			if( is_array( $child ) ) {
				$content .= self::compile_node( $child, array( 'index' => $child_index, 'design' => $design ) );
			}
		}

		return $content;
	}

	/**
	 * Content from slots.
	 *
	 * @param array $node Node.
	 * @return string Content from slots.
	 */

	protected static function content_from_slots( array $node ): string {
		return self::stack(
			self::eyebrow_label( self::slot( $node, 'eyebrow' ) ) .
			( self::slot( $node, 'heading' ) ? self::heading( self::slot( $node, 'heading' ), 'h2', self::heading_size( $node ) ) : '' ) .
			( self::slot( $node, 'lead' ) ? self::paragraph( self::slot( $node, 'lead' ), 'text-l' ) : '' ) .
			( self::slot( $node, 'text' ) ? self::paragraph( self::slot( $node, 'text' ) ) : '' ) .
			self::actions_markup_from_node( $node ),
			self::gap( $node, 'm' )
		);
	}

	/**
	 * Intro from node.
	 *
	 * @param array $node Node.
	 * @param array $design Design.
	 * @return string Intro from node.
	 */

	protected static function intro_from_node( array $node, array $design = array() ): string {
		if( ! self::slot( $node, 'eyebrow' ) && ! self::slot( $node, 'heading' ) && ! self::slot( $node, 'lead' ) ) {
			return '';
		}
		$system = sanitize_key( $design['system'] ?? '' );
		$align = in_array( $system, array( 'editorial', 'magazine' ), true ) && sanitize_key( $node['layout']['type'] ?? '' ) !== 'split' ? 'center' : 'none';

		return self::stack(
			self::eyebrow_label( self::slot( $node, 'eyebrow' ) ) .
			( self::slot( $node, 'heading' ) ? self::heading( self::slot( $node, 'heading' ), 'h2', self::heading_size( $node ), 'var(--wphave-site-color-heading)', $align ) : '' ) .
			( self::slot( $node, 'lead' ) ? self::paragraph( self::slot( $node, 'lead' ), 'text-l', 'var(--wphave-site-color-text)', $align ) : '' ),
			self::gap( $node, 'm' ),
			array( 'dimensions' => [ 'width' => [ 'limit' => 'max', 'custom' => $align === 'center' ? '920px' : '780px' ] ] )
		);
	}

	/**
	 * Eyebrow label.
	 *
	 * @param string $text Text.
	 * @param string $color Color.
	 * @return string Eyebrow label.
	 */

	protected static function eyebrow_label( string $text, string $color = 'var(--wphave-site-color-text)' ): string {
		if( trim( $text ) === '' ) {
			return '';
		}

		return self::paragraph( $text, 'text-xs', $color, 'none', array(
			'formats' => [ 'bold', 'uppercase' ],
			'letterSpacing' => '0.12em',
		) );
	}

	/**
	 * Tone text color.
	 *
	 * @param array $node Node.
	 * @param string $role Role.
	 * @return string Tone text color.
	 */

	protected static function tone_text_color( array $node, string $role ): string {
		$tone = sanitize_key( $node['tone'] ?? '' );
		if( $tone === 'dark' ) {
			if( $role === 'heading' ) {
				return 'var(--wphave-site-color-background)';
			}

			return 'color-mix(in srgb, var(--wphave-site-color-background) 72%, transparent)';
		}

		return $role === 'heading' ? 'var(--wphave-site-color-heading)' : 'var(--wphave-site-color-text)';
	}

	/**
	 * Actions markup from node.
	 *
	 * @param array $node Node.
	 * @return string Actions markup from node.
	 */

	protected static function actions_markup_from_node( array $node ): string {
		$actions = self::actions_from_node( $node );

		return empty( $actions ) ? '' : self::button_row( $actions );
	}

	/**
	 * Actions from node.
	 *
	 * @param array $node Node.
	 * @return array Actions from node.
	 */

	protected static function actions_from_node( array $node ): array {
		$actions = array();
		$slots = is_array( $node['slots'] ?? null ) ? $node['slots'] : array();

		if( ! empty( $slots['button'] ) ) {
			$actions[] = array(
				'label' => self::text( $slots['button'], 80 ),
				'variant' => self::button_variant( $node ),
			);
		}

		foreach( array_slice( (array) ( $slots['actions'] ?? array() ), 0, 3 ) as $action ) {
			if( ! is_array( $action ) || empty( $action['label'] ) ) {
				continue;
			}

			$actions[] = array(
				'label' => self::text( $action['label'], 80 ),
				'variant' => in_array( sanitize_key( $action['variant'] ?? '' ), array( 'primary', 'secondary', 'tertiary' ), true ) ? sanitize_key( $action['variant'] ) : 'secondary',
			);
		}

		return $actions;
	}

	/**
	 * Section background for.
	 *
	 * @param array $node Node.
	 * @param int $index Index.
	 * @param array $design Design.
	 * @return string Section background for.
	 */

	protected static function section_background_for( array $node, int $index, array $design = array() ): string {
		$tone = sanitize_key( $node['tone'] ?? 'neutral' );
		$surface_style = sanitize_key( $design['surfaceStyle'] ?? '' );
		if( $tone === 'dark' ) {
			return self::surface_colors( 'background-contrast' )['background'];
		}

		if( in_array( $surface_style, array( 'flat', 'minimal' ), true ) && $tone === 'neutral' ) {
			return 'transparent';
		}

		if( $surface_style === 'paper' && $tone === 'neutral' ) {
			return self::surface_colors( 'paper' )['background'];
		}

		if( in_array( $tone, array( 'paper', 'secondary', 'accent' ), true ) ) {
			return self::tone_colors( $tone, $index )['background'];
		}

		return $index % 2 ? 'var(--wphave-site-color-background-subtle-1)' : 'transparent';
	}

	/**
	 * Tone colors.
	 *
	 * @param string $tone Tone.
	 * @param int $index Index.
	 * @return array Tone colors.
	 */

	protected static function tone_colors( string $tone, int $index = 0 ): array {
		$mode = 'default';
		if( $tone === 'primary' || $tone === 'success' ) {
			$mode = 'primary-contrast';
		} elseif( $tone === 'secondary' || $tone === 'warning' ) {
			$mode = 'secondary-contrast';
		} elseif( $tone === 'accent' || $tone === 'danger' ) {
			$mode = 'accent-contrast';
		} elseif( $tone === 'dark' ) {
			$mode = 'background-contrast';
		} elseif( $tone === 'paper' ) {
			$mode = 'paper';
		}

		$colors = self::surface_colors( $mode );
		if( $tone === 'neutral' ) {
			$colors['background'] = $index % 2 ? 'var(--wphave-site-color-background)' : 'var(--wphave-site-color-background-subtle-1)';
		}

		return $colors;
	}

	/**
	 * Notification icon label.
	 *
	 * @param string $tone Tone.
	 * @return string Notification icon label.
	 */

	protected static function notification_icon_label( string $tone ): string {
		$labels = array(
			'success' => __( 'Success', 'wphave' ),
			'warning' => __( 'Notice', 'wphave' ),
			'danger' => __( 'Alert', 'wphave' ),
			'primary' => __( 'Info', 'wphave' ),
		);

		return $labels[$tone] ?? __( 'Info', 'wphave' );
	}

	/**
	 * Heading size.
	 *
	 * @param array $node Node.
	 * @return string Heading size.
	 */

	protected static function heading_size( array $node ): string {
		$emphasis = sanitize_key( $node['emphasis'] ?? 'medium' );

		return $emphasis === 'high' ? 'title-l' : ( $emphasis === 'low' ? 'title-s' : 'title-m' );
	}

	/**
	 * Emphasis padding.
	 *
	 * @param array $node Node.
	 * @return string Emphasis padding.
	 */

	protected static function emphasis_padding( array $node ): string {
		$emphasis = sanitize_key( $node['emphasis'] ?? 'medium' );

		return $emphasis === 'high' ? '4xl' : ( $emphasis === 'low' ? '2xl' : '3xl' );
	}

	/**
	 * Button variant.
	 *
	 * @param array $node Node.
	 * @return string Button variant.
	 */

	protected static function button_variant( array $node ): string {
		$variant = sanitize_key( $node['buttonVariant'] ?? $node['slots']['buttonVariant'] ?? 'primary' );

		return in_array( $variant, array( 'primary', 'secondary', 'tertiary' ), true ) ? $variant : 'primary';
	}

	/**
	 * Gap.
	 *
	 * @param array $node Node.
	 * @param string $fallback Fallback.
	 * @return string Gap.
	 */

	protected static function gap( array $node, string $fallback = 'm' ): string {
		$size = sanitize_key( $node['layout']['gap'] ?? $node['gap'] ?? $fallback );

		return self::gap_token( $size ?: $fallback );
	}

	/**
	 * Design context.
	 *
	 * @param array $node Node.
	 * @param array $context Request or rendering context.
	 * @return array Design context.
	 */

	protected static function design_context( array $node, array $context = array() ): array {
		$design = is_array( $context['design'] ?? null ) ? $context['design'] : array();
		if( is_array( $node['design'] ?? null ) ) {
			$design = array_merge( $design, self::sanitize_design( $node['design'] ) );
		}

		return array_filter( $design );
	}

	/**
	 * Sanitize design.
	 *
	 * @param array $design Design.
	 * @return array Sanitize design.
	 */

	protected static function sanitize_design( array $design ): array {
		$allowed = array(
			'system' => array( 'premium', 'editorial', 'catalog', 'playful', 'institutional', 'minimal', 'bold', 'magazine', 'product', 'service', 'community' ),
			'motif' => array( 'poster', 'split-panels', 'dense-bento', 'story-rail', 'comparison', 'catalog', 'dashboard', 'brochure', 'lookbook', 'index' ),
			'sectionRhythm' => array( 'long-scroll', 'short-pages', 'alternating', 'editorial', 'modular', 'catalog' ),
			'surfaceStyle' => array( 'flat', 'soft', 'outlined', 'glass', 'dark', 'paper', 'minimal' ),
			'heroStyle' => array( 'poster', 'split-proof', 'centered-editorial', 'catalog-lead', 'image-card', 'statement' ),
			'cardStyle' => array( 'flat', 'bordered', 'soft', 'compact', 'editorial', 'media' ),
		);
		$clean = array();

		foreach( $allowed as $key => $values ) {
			$value = sanitize_key( (string) ( $design[$key] ?? '' ) );
			if( in_array( $value, $values, true ) ) {
				$clean[$key] = $value;
			}
		}

		return $clean;
	}

	/**
	 * Slot.
	 *
	 * @param array $node Node.
	 * @param string $key Key.
	 * @return string Slot.
	 */

	protected static function slot( array $node, string $key ): string {
		$slots = is_array( $node['slots'] ?? null ) ? $node['slots'] : array();

		return self::text( $slots[$key] ?? $node[$key] ?? '', $key === 'heading' ? 180 : 800 );
	}

	/**
	 * Slot items.
	 *
	 * @param array $node Node.
	 * @return array Slot items.
	 */

	protected static function slot_items( array $node ): array {
		$slots = is_array( $node['slots'] ?? null ) ? $node['slots'] : array();
		$items = is_array( $slots['items'] ?? null ) ? $slots['items'] : array();
		$output = array();

		foreach( array_slice( $items, 0, 8 ) as $item ) {
			if( ! is_array( $item ) ) {
				continue;
			}

			$output[] = array_filter( array(
				'heading' => self::text( $item['heading'] ?? $item['title'] ?? '', 140 ),
				'title' => self::text( $item['title'] ?? $item['heading'] ?? '', 140 ),
				'text' => self::text( $item['text'] ?? '', 500 ),
				'button' => self::text( $item['button'] ?? '', 80 ),
				'value' => self::text( $item['value'] ?? $item['number'] ?? '', 40 ),
				'tone' => sanitize_key( $item['tone'] ?? '' ),
			) );
		}

		return $output;
	}

	/**
	 * Sanitize node.
	 *
	 * @param mixed $node Node.
	 * @param string $fallback_kind Fallback kind.
	 * @return array Sanitize node.
	 */

	protected static function sanitize_node( $node, string $fallback_kind = 'section' ): array {
		if( ! is_array( $node ) ) {
			return array();
		}

		$kind = sanitize_key( $node['kind'] ?? $fallback_kind );
		if( ! in_array( $kind, self::NODE_KINDS, true ) ) {
			$kind = $fallback_kind;
		}

		$clean = array(
			'kind' => $kind,
			'id' => sanitize_key( (string) ( $node['id'] ?? '' ) ),
			'tone' => sanitize_key( (string) ( $node['tone'] ?? 'neutral' ) ),
			'emphasis' => sanitize_key( (string) ( $node['emphasis'] ?? 'medium' ) ),
			'style' => sanitize_key( (string) ( $node['style'] ?? '' ) ),
			'design' => is_array( $node['design'] ?? null ) ? self::sanitize_design( $node['design'] ) : array(),
			'layout' => is_array( $node['layout'] ?? null ) ? $node['layout'] : array(),
			'slots' => is_array( $node['slots'] ?? null ) ? $node['slots'] : array(),
			'nodes' => array(),
		);

		foreach( array_slice( (array) ( $node['nodes'] ?? array() ), 0, 12 ) as $child ) {
			$child = self::sanitize_node( $child, 'section' );
			if( ! empty( $child ) ) {
				$clean['nodes'][] = $child;
			}
		}

		return $clean;
	}

	/**
	 * Text.
	 *
	 * @param mixed $value Value.
	 * @param int $length Length.
	 * @return string Text.
	 */

	protected static function text( $value, int $length ): string {
		return trim( mb_substr( sanitize_textarea_field( (string) $value ), 0, $length ) );
	}

}
