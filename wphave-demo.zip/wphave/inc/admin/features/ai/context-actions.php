<?php

if( ! defined('ABSPATH') ) {
	exit;
}

/**
 * Manage the ai context actions feature.
 */

class WPHAVE_AI_Context_Actions {

	/**
	 * Execute a whitelisted context action and return a normalized draft response.
	 * The method sanitizes payload/options, builds action-specific messages, routes to a provider with the required capability, and preserves output metadata.
	 */

	public static function run( string $action, array $payload = array(), array $options = array() ) {
		$definition = WPHAVE_AI_Action_Registry::get( $action );

		if( ! $definition || ( $definition['domain'] ?? '' ) !== 'context' ) {
			return new WP_Error( 'unknown_action', __( 'Unknown AI context action', 'wphave' ), array( 'status' => 400 ) );
		}

		$payload = WPHAVE_AI_Schema::sanitize_context_payload( $payload );
		$options = WPHAVE_AI_Schema::sanitize_options( $options );
		$messages = self::build_messages( $action, $payload );

		if( is_wp_error( $messages ) ) {
			return $messages;
		}

		$response = WPHAVE_AI_Provider_Router::generate_text( $messages, $options, $definition['capabilities'] ?? array( 'text' ) );
		if( is_wp_error( $response ) ) {
			return $response;
		}

		$response['result'] = trim( wp_strip_all_tags( (string) ( $response['result'] ?? '' ) ) );
		$response['action'] = $action;
		$response['type'] = 'context';
		$response['meta'] = array_merge( $response['meta'] ?? array(), array(
			'output' => $definition['output'] ?? 'text',
			'maxLength' => $definition['maxLength'] ?? null,
		) );

		return WPHAVE_AI_Response::normalize( $response, $action, 'context' );
	}

	/**
	 * Build provider messages for the requested AI mode or action.
	 * The method combines system rules, formatting rules, global site prompts, action-specific rules, and user input.
	 */

	public static function build_messages( string $action, array $payload ) {
		$content = trim( (string) ( $payload['content'] ?? '' ) );
		$current = trim( (string) ( $payload['current'] ?? '' ) );
		$keywords = ! empty( $payload['focusKeywords'] ) ? implode( ', ', $payload['focusKeywords'] ) : '';
		$rule = self::rule( $action );

		if( $rule === '' ) {
			return new WP_Error( 'unknown_action', __( 'Unknown AI context action', 'wphave' ), array( 'status' => 400 ) );
		}

		if( str_starts_with( $action, 'seo.' ) && $content === '' ) {
			return new WP_Error( 'ai_missing_context', __( 'Page content is required for this AI action.', 'wphave' ), array( 'status' => 400 ) );
		}

		if( str_starts_with( $action, 'media.' ) && empty( $payload['image'] ) ) {
			return new WP_Error( 'ai_missing_image', __( 'Image data is required for this AI action.', 'wphave' ), array( 'status' => 400 ) );
		}

		if( str_starts_with( $action, 'editor.' ) && $content === '' && $current === '' ) {
			return new WP_Error( 'ai_missing_context', __( 'Editor context is required for this AI action.', 'wphave' ), array( 'status' => 400 ) );
		}

		$system = array(
			'You are a production website assistant for WordPress and wphave.',
			'Return only the requested field value. No Markdown, no quotes, no explanation.',
			'Never invent facts, prices, dates, credentials, or claims that are not visible in the context.',
			$rule,
		);

		if( $keywords ) {
			$system[] = 'Focus keywords, if naturally useful: ' . $keywords;
		}

		$user_text = self::user_context( $payload, $content, $current );
		$messages = array(
			array(
				'role' => 'system',
				'content' => implode( "\n", $system ),
			),
		);

		if( str_starts_with( $action, 'media.' ) ) {
			$messages[] = array(
				'role' => 'user',
				'content' => array(
					array(
						'type' => 'text',
						'text' => $user_text ?: 'Analyze this image.',
					),
					array(
						'type' => 'image_url',
						'image_url' => array(
							'url' => $payload['image'],
						),
					),
				),
			);
		} else {
			$messages[] = array(
				'role' => 'user',
				'content' => $user_text,
			);
		}

		return $messages;
	}

	/**
	 * Convert structured context payload fields into a compact user prompt.
	 * Only known fields are included so unrelated editor or post data is not leaked into the request.
	 */

	protected static function user_context( array $payload, string $content, string $current ): string {
		$user_text = array();

		if( $current ) {
			$user_text[] = 'Current value: ' . $current;
		}
		if( $content ) {
			$user_text[] = 'Page content: ' . mb_substr( $content, 0, 20000 );
		}

		foreach( array(
			'alt' => 'Current alt text',
			'caption' => 'Current caption',
			'title' => 'Title',
			'description' => 'Description',
		) as $key => $label ) {
			if( ! empty( $payload[$key] ) ) {
				$user_text[] = $label . ': ' . $payload[$key];
			}
		}

		return implode( "\n\n", $user_text );
	}

	/**
	 * Return the action-specific instruction used by context actions.
	 * Unknown actions return an empty string so callers can reject the request before provider execution.
	 */

	protected static function rule( string $action ): string {
		$rules = array(
			'seo.generate_title' => 'Generate one SEO title from the provided page content. Keep it under 60 characters when possible. Make it specific, readable, and search-result ready.',
			'seo.improve_title' => 'Improve the current SEO title using the provided page content. Keep it under 60 characters when possible. Preserve accuracy and do not invent claims.',
			'seo.generate_description' => 'Generate one SEO meta description from the provided page content. Keep it under 155 characters when possible. Make it useful and click-worthy without hype.',
			'seo.improve_description' => 'Improve the current SEO meta description using the provided page content. Keep it under 155 characters when possible. Preserve accuracy and avoid keyword stuffing.',
			'seo.shorten_title' => 'Shorten the current SEO title to under 60 characters when possible. Preserve the meaning and main search intent.',
			'seo.shorten_description' => 'Shorten the current SEO meta description to under 155 characters when possible. Preserve accuracy and usefulness.',
			'seo.generate_slug' => 'Generate one clean URL slug from the provided page content or title. Use lowercase words separated by hyphens. Do not include a domain, protocol, punctuation, or quotes.',
			'seo.suggest_keywords' => 'Suggest 3 to 6 focus keywords from the provided page content. Return only a comma-separated list. Use concise natural search terms.',
			'media.generate_alt_text' => 'Generate concise accessibility-focused alt text for the provided image. Describe visible content and purpose. Do not start with "Image of" or "Picture of".',
			'media.improve_alt_text' => 'Improve the current alt text for the provided image. Make it concise, descriptive, and accessibility-focused. Do not start with "Image of" or "Picture of".',
			'media.generate_caption' => 'Generate a concise caption for the provided image. Make it useful for website visitors and do not invent unavailable facts.',
			'media.generate_title' => 'Generate a concise media title for the provided image. Use title case only if natural. Do not invent unavailable facts.',
			'media.suggest_filename' => 'Suggest one SEO-friendly image filename based on the provided image. Use lowercase words separated by hyphens and include no file extension.',
			'media.mark_decorative' => 'Decide whether this image appears decorative. Return exactly "decorative" if the image should likely have empty alt text, otherwise return concise alt text.',
			'editor.button_cta' => 'Generate one short call-to-action button label. Use 1 to 4 words. Make it specific and action-oriented.',
			'editor.heading_from_context' => 'Generate one clear heading from the provided context. Keep it concise and useful for a website section.',
			'editor.paragraph_from_context' => 'Generate one useful paragraph from the provided context. Keep it concise and suitable for website copy.',
			'editor.improve_field_label' => 'Improve the current form field label or helper text. Make it clear, concise, and user-friendly.',
		);

		return $rules[$action] ?? '';
	}

}
