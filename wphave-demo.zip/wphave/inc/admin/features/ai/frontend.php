<?php

/** Bootstrap the frontend AI disclosure adapter. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// AI-specific frontend behavior belongs here. Media disclosure is loaded by the
// media composition root because image rendering must also work with AI disabled.
