<?php

if( ! defined('ABSPATH') ) {
	exit;
}

/**
 * Manage the ai config feature.
 */

class WPHAVE_AI_Config {

	const DEFAULT_TEXT_MODEL = 'gpt-5-mini';
	const DEFAULT_IMAGE_MODEL = 'gpt-image-1.5';
	const DEFAULT_TRANSCRIPTION_MODEL = 'gpt-4o-mini-transcribe';
	const DEFAULT_SPEECH_MODEL = 'gpt-4o-mini-tts';
	const DEFAULT_AUDIO_QUALITY = 'standard';

	/**
	 * Read the persisted AI settings from the wphave data store.
	 * Always returns an array so downstream config helpers can safely access keys.
	 */

	public static function data(): array {
		$data = wphave_data_get( 'ai_settings' ) ?? array();

		return is_array( $data ) ? $data : array();
	}

	/**
	 * Report whether the AI feature is disabled in site settings.
	 * Used as an early feature-level guard before any provider request is attempted.
	 */

	public static function is_disabled(): bool {
		$data = self::data();

		return ! empty( $data['isDisabled'] );
	}

	/**
	 * Return the configured OpenAI API key.
	 * The value is trimmed and intentionally not transformed so provider authentication uses the exact stored secret.
	 */

	public static function openai_api_key(): string {
		// DATA INTEGRITY INVARIANT: Provider authentication receives the exact
		// configured secret; this accessor may trim surrounding whitespace only.
		if( defined( 'WPHAVE_OPENAI_KEY' ) && WPHAVE_OPENAI_KEY ) {
			return (string) WPHAVE_OPENAI_KEY;
		}

		$data = self::data();
		$key = $data['openai']['apiKey'] ?? '';

		return is_string( $key ) ? trim( $key ) : '';
	}

	/**
	 * Return the configured text model with a production-safe fallback.
	 * This controls text, chat, context, layout, and global style generation unless a provider overrides it.
	 */

	public static function model(): string {
		$data = self::data();
		$model = $data['openai']['model'] ?? self::DEFAULT_TEXT_MODEL;

		return sanitize_text_field( $model ?: self::DEFAULT_TEXT_MODEL );
	}

	/**
	 * Return the image model for generation/edit requests.
	 * A request-level model can override the default when it is passed through sanitized options.
	 */

	public static function image_model( array $options = array() ): string {
		$model = $options['model'] ?? self::DEFAULT_IMAGE_MODEL;

		return sanitize_text_field( $model ?: self::DEFAULT_IMAGE_MODEL );
	}

	/**
	 * Return the speech-to-text model for browser microphone uploads.
	 * Kept separate from the text model because transcription has a dedicated OpenAI model family.
	 */

	public static function transcription_model( array $options = array() ): string {
		$model = $options['model'] ?? self::DEFAULT_TRANSCRIPTION_MODEL;

		return sanitize_text_field( $model ?: self::DEFAULT_TRANSCRIPTION_MODEL );
	}

	/**
	 * Return the text-to-speech model for reading AI answers aloud.
	 * A request can override it later if settings expose multiple affordable speech models.
	 */

	public static function speech_model( array $options = array() ): string {
		$data = self::data();
		$model = $options['model'] ?? $data['openai']['speech']['model'] ?? self::DEFAULT_SPEECH_MODEL;

		return sanitize_text_field( $model ?: self::DEFAULT_SPEECH_MODEL );
	}

	/**
	 * Return the selected audio quality tier.
	 * Standard uses the current transcription plus TTS chain; the second tier keeps the existing value for saved settings.
	 */

	public static function audio_quality(): string {
		$data = self::data();
		$quality = sanitize_key( $data['openai']['audio']['quality'] ?? self::DEFAULT_AUDIO_QUALITY );

		return in_array( $quality, array( 'standard', 'realtime' ), true ) ? $quality : self::DEFAULT_AUDIO_QUALITY;
	}

	/**
	 * Report whether the higher-quality realtime audio engine should be used.
	 * The current audio flow does not use the realtime API yet.
	 */

	public static function use_realtime_audio(): bool {
		return false;
	}

	/**
	 * Return the configured text-to-speech voice.
	 * The voice changes character and energy without affecting the text model used for writing.
	 */

	public static function speech_voice( array $options = array() ): string {
		$data = self::data();
		$voice = $options['voice'] ?? $data['openai']['speech']['voice'] ?? 'coral';

		return sanitize_key( $voice ?: 'coral' );
	}

	/**
	 * Return optional speech style instructions for steerable TTS models.
	 * This is intentionally short so users can influence tone without turning settings into prompt engineering.
	 */

	public static function speech_instructions( array $options = array() ): string {
		$data = self::data();
		$instructions = $options['instructions'] ?? $data['openai']['speech']['instructions'] ?? 'Answer like a live assistant in a short voice conversation. Use 1-3 concise sentences unless detail is needed. Sound warm, clear, and natural, with light pauses and emphasis. Avoid reading markdown, lists, URLs, code, or visual formatting aloud unless the user asks.';

		return trim( sanitize_textarea_field( (string) $instructions ) );
	}

	/**
	 * Resolve the maximum token budget for a request.
	 * The value is clamped to a practical upper bound to prevent accidental oversized completions.
	 */

	public static function max_tokens( array $options = array(), int $fallback = 1200 ): int {
		$length_target = max( absint( $options['minLength'] ?? 0 ), absint( $options['maxLength'] ?? 0 ) );
		if( $length_target > 0 ) {
			$fallback = max( $fallback, (int) ceil( $length_target * 2.4 ) + 500 );
		}

		$value = absint( $options['maxTokens'] ?? $fallback );

		if( ! empty( $options['minLength'] ) ) {
			$minimum_tokens = (int) ceil( absint( $options['minLength'] ) * 2.4 ) + 500;
			$value = max( $value, $minimum_tokens );
		}

		return max( 100, min( 16000, $value ) );
	}

	/**
	 * Check whether any AI provider is available for text generation.
	 * This covers both the configured OpenAI key and WordPress AI client availability.
	 */

	public static function has_provider(): bool {
		return self::has_wordpress_ai_provider() || self::openai_api_key() !== '';
	}

	/**
	 * Check whether WordPress core AI client APIs are available.
	 * This does not guarantee every capability, such as vision, is supported.
	 */

	public static function has_wordpress_ai_provider(): bool {
		return function_exists( 'wp_ai_client_prompt' );
	}

}
