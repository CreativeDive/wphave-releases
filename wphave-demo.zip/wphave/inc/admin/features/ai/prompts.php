<?php

if( ! defined('ABSPATH') ) {
	exit;
}

/**
 * Manage the ai prompts feature.
 */

class WPHAVE_AI_Prompts {

	/**
	 * Build provider messages for the requested AI mode or action.
	 * The method combines system rules, formatting rules, global site prompts, action-specific rules, and user input.
	 */

	public static function build_messages( array $args = array() ) {
		$mode = sanitize_key( $args['mode'] ?? 'text' );
		$action = sanitize_text_field( $args['action'] ?? '' );
		$input = trim( (string) ( $args['input'] ?? '' ) );
		$messages = WPHAVE_AI_Schema::sanitize_messages( $args['messages'] ?? array() );
		$options = WPHAVE_AI_Schema::sanitize_options( $args['options'] ?? array() );
		$regenerate = ! empty( $args['regenerate'] );

		if( $mode === 'chat' && ! $messages && ! $input ) {
			return new WP_Error( 'ai_missing_messages', __( 'Chat mode requires messages.', 'wphave' ) );
		}

			$final = array(
				array(
					'role' => 'system',
					'content' => self::system_prompt( $mode ),
				),
			);

		$formatting = self::formatting_rules();
		if( $formatting ) {
			$final[] = array(
				'role' => 'system',
				'content' => implode( "\n", $formatting ),
			);
		}

		if( $mode === 'text' ) {
			$final[] = array(
				'role' => 'system',
				'content' => 'Context rule: Generate final website content. Output only the content itself.',
			);
			}

			if( empty( $options['ignoreGlobalRules'] ) ) {
				$global_rules = self::global_site_prompt( $options );
			if( $global_rules ) {
				$final[] = array(
					'role' => 'system',
					'content' => $global_rules,
				);
			}
		}

			if( $mode === 'image' ) {
				$constraints = self::image_action_options( $options );
			if( $constraints ) {
				$final[] = array(
					'role' => 'system',
					'content' => implode( "\n", $constraints ),
				);
			}
		}

		if( $action ) {
			$action_rule = self::action_rule( $action, $options, $regenerate );
			if( $action_rule ) {
				$final[] = array(
					'role' => 'system',
					'content' => $action_rule,
				);
			}
		}

		foreach( $messages as $message ) {
			$final[] = $message;
		}

		if( $input ) {
			$final[] = array(
				'role' => 'user',
				'content' => mb_substr( wp_strip_all_tags( $input ), 0, 20000 ),
			);
		}

		return $final;
	}

	/**
	 * Flatten image-generation messages into a single image prompt.
	 * Only system and user content is included so assistant history does not pollute the generated image request.
	 */

	public static function image_prompt_from_messages( array $messages ): string {
		$parts = array();

		foreach( $messages as $message ) {
			$role = $message['role'] ?? '';
			$content = trim( (string) ( $message['content'] ?? '' ) );

			if( $content === '' ) {
				continue;
			}

			if( in_array( $role, array( 'system', 'user' ), true ) ) {
				$parts[] = $content;
			}
		}

		return trim( implode( "\n\n", $parts ) );
	}

	/**
	 * Build the instruction block for one text action.
	 * Includes action-specific rules, regeneration guidance, user options, and strict final-output constraints.
	 */

	protected static function action_rule( string $action, array $options, bool $regenerate ): string {
		$instructions = self::action_instructions();

		if( ! isset( $instructions[$action] ) ) {
			return '';
		}

		$rule = $instructions[$action] . ' Respond with the text only.';

		if( $regenerate ) {
			$rule .= ' Generate a slightly different variation than before.';
		}

		$constraints = self::text_action_options( $options );
		if( $constraints ) {
			$rule .= "\n" . implode( "\n", $constraints );
		}

		$rule .= "\n\nFINAL OUTPUT GOAL:\nThe response must fully achieve the intended purpose of this action.";
		$rule .= "\n\nFollow all rules strictly.";

		return $rule;
	}

	/**
	 * Return the base system prompt for the selected generation mode.
	 * These prompts define the model role, output format, and strict structural rules before action-specific context is added.
	 */

	protected static function system_prompt( string $mode = 'default' ): string {
		$prompts = array(
			'chat' => trim(<<<PROMPT
				You are a helpful assistant.

				RULES:
				- Always respond in clean, valid Markdown.
				- Use Markdown lists for lists
				- Use fenced code blocks for code
				- Use inline code for identifiers
				- Do NOT use HTML
				- Do NOT wrap the entire response in a code block
			PROMPT),
			'text' => trim(<<<PROMPT
				You are a text editing assistant.

				RULES:
				- Always respond in clean, valid Markdown.
				- Preserve meaning and tone.
				- Use Markdown only when structure is needed.
				- Do NOT use HTML.
			PROMPT),
		);

		return $prompts[$mode] ?? 'You are a helpful assistant.';
	}

	/**
	 * Return global formatting constraints for text-like AI modes.
	 * These rules prevent unwanted wrappers and keep output suitable for direct insertion into editor fields.
	 */

	protected static function formatting_rules(): array {
		return array(
			'Formatting rules:',
			'- Use code blocks (``` ) only for multi-line code examples.',
			'- Do NOT use inline <code> formatting for single words, file names, component names, or short identifiers.',
			'- <kbd> is reserved for keyboard input only. Do not use it for file names, commands, or technical terms.',
			'- Use **bold** for short technical terms, file names, or identifiers (e.g. MyComponent.jsx, useEffect, npm).',
			'- Use *italic* for soft emphasis or explanations.',
			'- Inline code formatting is only allowed if the content spans multiple lines.',
		);
	}

	/**
	 * Convert user-selected text options into explicit prompt constraints.
	 * Tone, language, and length options are written as model-facing requirements rather than UI labels.
	 */

	protected static function text_action_options( array $options = array() ): array {
		$constraints = array();

		if( ! empty( $options['tone'] ) ) {
			$tone_rule = $options['tone'] ?? '';
			$tones_desc = array(
				'neutral' => 'Balanced, objective and factual without emotional emphasis.',
				'professional' => 'Formal, structured and suitable for business or professional contexts.',
				'friendly' => 'Warm, approachable and natural, without being overly casual.',
				'creative' => 'More expressive and varied language with creative wording.',
				'precise' => 'Short, clear and focused on the essential information.',
				'emotional' => 'Expressive and emotionally engaging language with a warmer tone.',
				'direct' => 'Straightforward and to the point, without unnecessary explanations.',
				'technical' => 'Technical language with precise terminology and minimal simplification.',
				'playful' => 'Light, playful and entertaining language with a relaxed tone.',
				'premium' => 'High-quality, refined and confident language with an elegant tone.',
			);

			$constraints[] = sprintf( /* translators: %s or %d: contextual value; 1, 2, or 3: ordered contextual values. */
			__( 'Tone rule: Use a %s tone consistently.', 'wphave' ), $tone_rule );

			if( isset( $tones_desc[$tone_rule] ) ) {
				$constraints[] = 'Tone rule description: ' . $tones_desc[$tone_rule];
			}
		}

		if( ! empty( $options['minLength'] ) && ! empty( $options['maxLength'] ) ) {
			$constraints[] = "REQUIRED OUTPUT LENGTH: Write between {$options['minLength']} and {$options['maxLength']} words.";
			$constraints[] = "The final answer is invalid if it has fewer than {$options['minLength']} words or more than {$options['maxLength']} words.";
		} else {
			if( ! empty( $options['minLength'] ) ) {
				$constraints[] = "REQUIRED OUTPUT LENGTH: Write at least {$options['minLength']} words.";
				$constraints[] = "Expand the content with relevant, useful detail until the output reaches at least {$options['minLength']} words.";
				$constraints[] = "The final answer is invalid if it has fewer than {$options['minLength']} words.";
			}

			if( ! empty( $options['maxLength'] ) ) {
				$constraints[] = "REQUIRED OUTPUT LENGTH: Write no more than {$options['maxLength']} words.";
				$constraints[] = "The final answer is invalid if it has more than {$options['maxLength']} words.";
			}
		}

		if( ! empty( $options['language'] ) && $options['language'] !== 'auto' ) {
			$constraints[] = 'TARGET LANGUAGE: Write the result in the language and regional spelling conventions of ' . self::language_label( $options['language'] ) . '.';
		}

		return $constraints;
	}

	/**
	 * Convert a stored WordPress locale or language value into a readable prompt label.
	 * AI text options reuse the WordPress language choices, whose values are locale codes such as de_DE or en_US.
	 */

	protected static function language_label( string $language ): string {
		$language = sanitize_text_field( $language );
		$labels = array(
			'en_US' => 'English (United States)',
			'en_GB' => 'English (United Kingdom)',
			'de_DE' => 'German (Germany)',
			'de_AT' => 'German (Austria)',
			'de_CH' => 'German (Switzerland)',
		);

		if( isset( $labels[$language] ) ) {
			return $labels[$language];
		}

		return str_replace( '_', '-', $language );
	}

	/**
	 * Convert image generation options into prompt constraints.
	 * Only options that influence the visual output are included, keeping transport-level settings out of the prompt text.
	 */

	protected static function image_action_options( array $options = array() ): array {
		$constraints = array();

		if( ! empty( $options['style'] ) ) {
			$constraints[] = 'Image Style: ' . str_replace( '_', ' ', $options['style'] );
		}

		if( ! empty( $options['mood'] ) ) {
			$constraints[] = 'Image Mood: ' . implode( ', ', (array) $options['mood'] );
		}

		$constraints[] = "\n\nFollow all rules strictly.";

		return $constraints;
	}

	/**
	 * Add configured global image language rules to an image prompt.
	 * This keeps visual generation aligned with site-wide AI settings without leaking text-writing rules into image prompts.
	 */

	public static function enrich_image_prompt( string $prompt, array $options = array() ): string {
		if( ! empty( $options['ignoreGlobalImageRules'] ) ) {
			return $prompt;
		}

		$global_rules = self::global_image_prompt();
		if( ! $global_rules ) {
			return $prompt;
		}

		return trim( $prompt . "\n\n" . $global_rules );
	}

	/**
	 * Build optional global image-language rules from AI settings.
	 * The rule block is only returned when global image language is explicitly enabled and at least one visual preference exists.
	 */

	protected static function global_image_prompt(): string {
		$ai_settings = wphave_data_get( 'ai_settings' );
		$visual = $ai_settings['specifications']['visual'] ?? array();

		if( empty( $visual ) || ! is_array( $visual ) || empty( $visual['enabled'] ) ) {
			return '';
		}

		$labels = array(
			'style' => array(
				'photographic' => 'Photographic',
				'editorial' => 'Editorial',
				'clean_product' => 'Clean product',
				'documentary' => 'Documentary',
				'illustrative' => 'Illustrative',
				'abstract' => 'Abstract',
			),
			'mood' => array(
				'warm' => 'Warm',
				'calm' => 'Calm',
				'premium' => 'Premium',
				'playful' => 'Playful',
				'technical' => 'Technical',
				'energetic' => 'Energetic',
				'minimal' => 'Minimal',
			),
			'lighting' => array(
				'natural_light' => 'Natural light',
				'soft_studio' => 'Soft studio light',
				'bright_even' => 'Bright and even',
				'high_contrast' => 'High contrast',
				'atmospheric' => 'Atmospheric',
			),
			'composition' => array(
				'spacious' => 'Spacious',
				'close_up' => 'Close-up',
				'wide_scene' => 'Wide scene',
				'detail_focused' => 'Detail-focused',
				'layered_editorial' => 'Layered editorial',
			),
			'subject' => array(
				'authentic_people' => 'Authentic people',
				'no_people' => 'No people',
				'product_first' => 'Product first',
				'environment_first' => 'Environment first',
				'hands_and_details' => 'Hands and details',
			),
			'color' => array(
				'brand_aligned' => 'Brand aligned',
				'neutral' => 'Neutral',
				'warm' => 'Warm',
				'muted' => 'Muted',
				'high_contrast' => 'High contrast',
			),
		);

		$rules = array();

		if( ! empty( $visual['style'] ) ) {
			$rules[] = 'Image style: ' . self::visual_label( $visual['style'], $labels['style'] ) . '.';
		}

		if( ! empty( $visual['mood'] ) ) {
			$moods = array_map( function( $value ) use ( $labels ) {
				return self::visual_label( $value, $labels['mood'] );
			}, (array) $visual['mood'] );

			$rules[] = 'Image mood: ' . implode( ', ', array_filter( $moods ) ) . '.';
		}

		if( ! empty( $visual['lighting'] ) ) {
			$rules[] = 'Lighting: ' . self::visual_label( $visual['lighting'], $labels['lighting'] ) . '.';
		}

		if( ! empty( $visual['composition'] ) ) {
			$rules[] = 'Composition: ' . self::visual_label( $visual['composition'], $labels['composition'] ) . '.';
		}

		if( ! empty( $visual['subject'] ) ) {
			$rules[] = 'Subject treatment: ' . self::visual_label( $visual['subject'], $labels['subject'] ) . '.';
		}

		if( ! empty( $visual['color'] ) ) {
			$rules[] = 'Color direction: ' . self::visual_label( $visual['color'], $labels['color'] ) . '.';
		}

		if( ! empty( $visual['avoid'] ) ) {
			$rules[] = 'Avoid in images: ' . trim( sanitize_textarea_field( (string) $visual['avoid'] ) );
		}

		if( ! empty( $visual['guidance'] ) ) {
			$rules[] = 'Additional visual guidance: ' . trim( sanitize_textarea_field( (string) $visual['guidance'] ) );
		}

		$rules = array_filter( $rules );
		if( empty( $rules ) ) {
			return '';
		}

		array_unshift( $rules, 'Global site image language:' );

		return implode( "\n", $rules );
	}

	/**
	 * Convert stored image-language option values into readable prompt labels.
	 */

	protected static function visual_label( $value, array $labels ): string {
		$value = sanitize_text_field( (string) $value );

		return $labels[$value] ?? str_replace( '_', ' ', $value );
	}

	/**
	 * Return action-specific editing instructions for supported text actions.
	 * The action registry validates availability; this map defines what each action should actually do.
	 */

	protected static function action_instructions(): array {
		return array(
			'text.restyle' => 'Adjust the tone and writing style of the existing text without changing its meaning, content or structure.',
			'text.translate' => 'Translate the text into the requested target language. Preserve the meaning, structure, tone, formatting, and intent as closely as possible.',
			'text.shorten' => 'Shorten the text by removing unnecessary parts without losing the core message.',
			'text.lengthen' => 'Extend the text by adding useful details while preserving the original meaning.',
			'text.grammar' => 'Correct grammar, spelling, and punctuation. Do not change tone or meaning.',
			'text.clarity' => 'Rewrite the text to improve clarity and readability while keeping the meaning.',
			'text.active' => 'Rewrite the text using active voice where possible.',
			'text.rewrite' => 'Rewrite the text while fully respecting all global rules.',
			'text.make_specific' => 'Replace vague statements with concrete, specific language where possible.',
			'text.align_brand' => 'Align the text more closely with the brand voice and positioning.',
			'text.reduce_marketing' => 'Remove marketing fluff, exaggerations, and vague claims.',
			'text.expand_examples' => 'Extend the text by adding concrete examples where helpful.',
			'text.seo' => 'Optimize the text for SEO without keyword stuffing. Keep it natural.',
			'text.headline' => 'Generate a concise and compelling headline based on the text.',
			'text.summary' => 'Summarize the text concisely.',
			'text.continue' => 'Continue writing the text naturally from where it ends. Do not repeat existing content. Match the tone, style, and perspective.',
		);
	}

	/**
	 * Build optional global writing rules from configured site and brand context.
	 * These rules let generated content respect audience, tone, terminology, and claims policy without requiring the user to repeat them.
	 */

	protected static function global_site_prompt( array $options = array() ): string {
		$ai_settings = wphave_data_get( 'ai_settings' );
		$spec = $ai_settings['specifications'] ?? array();
		$ignore_tone = $options['tone'] ?? false;

		if( empty( $spec ) || ! is_array( $spec ) ) {
			return '';
		}

		$rules = array();

		if( ! empty( $spec['website']['type'] ) ) {
			$rules[] = sprintf( /* translators: %s or %d: contextual value; 1, 2, or 3: ordered contextual values. */
			__( 'Website context: This is a %s website.', 'wphave' ), ucfirst( $spec['website']['type'] ) );
		}

		if( ! empty( $spec['website']['purpose'] ) ) {
			$rules[] = __( 'The primary goal of this website is', 'wphave' ) . ': ' . str_replace( '_', ' ', $spec['website']['purpose'] ) . '.';
		}

		if( ! empty( $spec['website']['description'] ) ) {
			$rules[] = __( 'Website description', 'wphave' ) . ': ' . trim( $spec['website']['description'] ) . '.';
		}

		if( ! $ignore_tone && ! empty( $spec['brand']['tone'] ) ) {
			$tone_rule = $spec['brand']['tone'] ?? '';
			$tones_desc = array(
				'neutral' => 'Balanced, objective and factual without emotional emphasis.',
				'professional' => 'Formal, structured and suitable for business or professional contexts.',
				'friendly' => 'Warm, approachable and natural, without being overly casual.',
				'creative' => 'More expressive and varied language with creative wording.',
				'precise' => 'Short, clear and focused on the essential information.',
			);

			$rules[] = sprintf( __( 'Tone rule: Use a %s tone consistently.', 'wphave' ), $tone_rule );

			if( isset( $tones_desc[$tone_rule] ) ) {
				$rules[] = 'Tone rule description: ' . $tones_desc[$tone_rule];
			}
		}

		if( ! empty( $spec['brand']['addressing'] ) ) {
			$rules[] = __( 'Addressing', 'wphave' ) . ': ' . match( $spec['brand']['addressing'] ) {
				'you' => __( 'Address the reader directly using second-person pronouns.', 'wphave' ),
				'you_formal' => __( 'Address the reader using formal second-person pronouns.', 'wphave' ),
				'neutral' => __( 'Use neutral and impersonal language.', 'wphave' ),
				default => null,
			};
		}

		if( ! empty( $spec['brand']['sentenceLength'] ) ) {
			$rules[] = /* translators: %s or %d: contextual value; 1, 2, or 3: ordered contextual values. */
			__( 'Sentence Length', 'wphave' ) . ': ' . sprintf( __( 'Prefer mostly %s sentences.', 'wphave' ), $spec['brand']['sentenceLength'] );
		}

		if( ! empty( $spec['brand']['readingLevel'] ) ) {
			$rules[] = sprintf( /* translators: %s or %d: contextual value; 1, 2, or 3: ordered contextual values. */
			__( 'Write at a %s reading level suitable for a broad audience.', 'wphave' ), $spec['brand']['readingLevel'] );
		}

		if( ! empty( $spec['brand']['personalityTraits'] ) ) {
			$traits = array_map( 'trim', (array) $spec['brand']['personalityTraits'] );
			$rules[] = __( 'Use the following personality traits consistently in wording and structure:', 'wphave' ) . ' ' . implode( ', ', $traits ) . '.';
		}

		if( ! empty( $spec['brand']['do'] ) ) {
			$rules[] = __( 'Follow these guidelines strictly', 'wphave' ) . ': ' . trim( $spec['brand']['do'] );
		}

		if( ! empty( $spec['brand']['dont'] ) ) {
			$rules[] = __( 'Never use the following', 'wphave' ) . ': ' . trim( $spec['brand']['dont'] );
		}

		if( ! empty( $spec['audience']['market'] ) ) {
			$rules[] = __( 'Target market', 'wphave' ) . ': ' . strtoupper( $spec['audience']['market'] ) . '.';
		}

		if( ! empty( $spec['audience']['role'] ) ) {
			$rules[] = __( 'Primary audience role', 'wphave' ) . ': ' . trim( $spec['audience']['role'] ) . '.';
		}

		if( ! empty( $spec['audience']['knowledgeLevel'] ) ) {
			$rules[] = __( 'Audience knowledge level', 'wphave' ) . ': ' . $spec['audience']['knowledgeLevel'] . '.';
		}

		if( ! empty( $spec['audience']['desiredFeeling'] ) ) {
			$rules[] = __( 'Desired reader feeling', 'wphave' ) . ': ' . trim( $spec['audience']['desiredFeeling'] ) . '.';
		}

		if( ! empty( $spec['audience']['keyProblems'] ) ) {
			$rules[] = __( 'Address these audience problems', 'wphave' ) . ': ' . implode( ', ', (array) $spec['audience']['keyProblems'] ) . '.';
		}

		if( ! empty( $spec['audience']['keyObjections'] ) ) {
			$rules[] = __( 'Anticipate these objections', 'wphave' ) . ': ' . implode( ', ', (array) $spec['audience']['keyObjections'] ) . '.';
		}

		if( ! empty( $spec['themes']['coreTopics'] ) ) {
			$rules[] = __( 'Core topics to focus on', 'wphave' ) . ': ' . implode( ', ', (array) $spec['themes']['coreTopics'] ) . '.';
		}

		if( ! empty( $spec['themes']['avoidTopics'] ) ) {
			$rules[] = __( 'Do not cover these topics', 'wphave' ) . ': ' . implode( ', ', (array) $spec['themes']['avoidTopics'] ) . '.';
		}

		if( ! empty( $spec['themes']['avoidPhrases'] ) ) {
			$rules[] = __( 'Avoid using these phrases', 'wphave' ) . ': ' . implode( ', ', (array) $spec['themes']['avoidPhrases'] ) . '.';
		}

		if( ! empty( $spec['themes']['preferredTerms'] ) ) {
			foreach( $spec['themes']['preferredTerms'] as $map ) {
				if( ! empty( $map['term'] ) && ! empty( $map['replace'] ) ) {
					/* translators: 1: original term, 2: required replacement term. */
					$rules[] = sprintf( __( 'Terminology rule: The term "%1$s" must always be replaced with "%2$s". Use the replacement exactly as written.', 'wphave' ), trim( $map['term'] ), trim( $map['replace'] ) );
				}
			}
		}

		if( ! empty( $spec['values']['brandValues'] ) ) {
			$rules[] = __( 'Brand values', 'wphave' ) . ': ' . implode( ', ', (array) $spec['values']['brandValues'] ) . '.';
		}

		if( ! empty( $spec['values']['positioning'] ) ) {
			$rules[] = __( 'Brand positioning', 'wphave' ) . ': ' . trim( $spec['values']['positioning'] ) . '.';
		}

		if( ! empty( $spec['values']['claimsPolicy'] ) ) {
			$rules[] = __( 'Claims policy - Follow these rules when making claims:', 'wphave' ) . ' ' . trim( $spec['values']['claimsPolicy'] );
		}

		$rules[] = __( 'Meta language is forbidden. Never introduce, summarize, announce, or comment on the text itself. Do not explain what the text is about. Start immediately with the actual content.', 'wphave' );

		return implode( "\n", array_filter( $rules ) );
	}

}
