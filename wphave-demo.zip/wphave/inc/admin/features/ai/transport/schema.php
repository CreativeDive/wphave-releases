<?php

if( ! defined('ABSPATH') ) {
	exit;
}

/**
 * Manage the ai schema feature.
 */

class WPHAVE_AI_Schema {
	public const MAX_IMAGE_BINARY_BYTES = 12 * 1024 * 1024;
	public const MAX_IMAGE_BASE64_BYTES = 16 * 1024 * 1024 + 1024;
	private const MAX_MESSAGE_COUNT = 10;
	private const MAX_TEXT_INPUT_BYTES = 128 * 1024;
	private const MAX_OPTION_BYTES = 1024;

	/**
	 * Return the canonical list of AI actions supported by the backend.
	 * The returned definitions are the server-side contract used for routing, provider selection, streaming support, and output metadata.
	 */

	public static function actions(): array {
		return WPHAVE_AI_Action_Registry::actions();
	}

	/**
	 * Action.
	 */

	public static function action( string $action ): ?array {
		$actions = self::actions();

		return $actions[$action] ?? null;
	}

	/**
	 * Action domain.
	 */

	public static function action_domain( string $action ): string {
		$schema = self::action( $action );

		return $schema['domain'] ?? 'text';
	}

	/**
	 * Sanitize options.
	 */

	public static function sanitize_options( $options ): array {
		if( ! is_array( $options ) ) {
			return array();
		}

		$allowed = array(
			'tone',
			'language',
			'minLength',
			'maxLength',
			'maxTokens',
			'ignoreGlobalRules',
			'ignoreGlobalImageRules',
			'style',
			'mood',
			'size',
			'quality',
			'background',
			'variations',
			'fileFormat',
			'model',
			'generateImages',
		);

		$clean = array();

		foreach( $allowed as $key ) {
			if( ! array_key_exists( $key, $options ) ) {
				continue;
			}

			$value = $options[$key];
			if( in_array( $key, array( 'ignoreGlobalRules', 'ignoreGlobalImageRules', 'generateImages' ), true ) ) {
				// BOOLEAN AUTHORITY INVARIANT: A textual "false" must not become a
				// truthy request to skip site rules or generate billable images.
				$clean[$key] = is_scalar( $value )
					? (bool) filter_var( self::bounded_text( $value, 32 ), FILTER_VALIDATE_BOOLEAN )
					: false;
				continue;
			}

			if( is_array( $value ) ) {
				// OPTION SHAPE INVARIANT: Only mood is a list. A nested or oversized
				// option must not fan out into sanitizer work or provider configuration.
				if( $key !== 'mood' ) {
					continue;
				}
				$clean[$key] = array_values( array_map(
					static fn( $item ) => sanitize_text_field( self::bounded_text( $item, self::MAX_OPTION_BYTES ) ),
					array_filter( array_slice( $value, 0, 12 ), 'is_string' )
				) );
			} elseif( is_bool( $value ) ) {
				$clean[$key] = $value;
			} elseif( is_scalar( $value ) && in_array( $key, array( 'minLength', 'maxLength', 'maxTokens', 'variations' ), true ) ) {
				$clean[$key] = absint( self::bounded_text( $value, 32 ) );
			} elseif( is_scalar( $value ) ) {
				$clean[$key] = sanitize_textarea_field( self::bounded_text( $value, self::MAX_OPTION_BYTES ) );
			}
		}

		return $clean;
	}

	/**
	 * Sanitize messages.
	 */

	public static function sanitize_messages( $messages, int $limit = 10 ): array {
		if( ! is_array( $messages ) ) {
			return array();
		}

		$clean = array();

		// MESSAGE COUNT INVARIANT: Only the last submitted conversation turns can
		// reach the provider; discarded turns must not consume sanitizer work.
		$limit = min( self::MAX_MESSAGE_COUNT, max( 0, $limit ) );
		if( 0 === $limit ) {
			return array();
		}
		foreach( array_slice( $messages, -$limit ) as $message ) {
			if( ! is_array( $message ) ) {
				continue;
			}

			$role = $message['role'] ?? 'user';
			if( ! is_scalar( $message['content'] ?? null ) ) {
				continue;
			}
			// MESSAGE BYTE INVARIANT: Bound raw text before tag stripping, which
			// otherwise scans and allocates around a caller-sized document.
			$content = self::bounded_text( $message['content'], self::MAX_TEXT_INPUT_BYTES );
			$content = trim( mb_substr( wp_strip_all_tags( $content ), 0, 8000 ) );

			if( $content === '' ) {
				continue;
			}

			$clean[] = array(
				'role' => in_array( $role, array( 'user', 'assistant' ), true ) ? $role : 'user',
				'content' => $content,
			);
		}

		return $clean;
	}

	/**
	 * Sanitize payload.
	 */

	public static function sanitize_payload( $payload ): array {
		if( ! is_array( $payload ) ) {
			return array();
		}

		// PAYLOAD PROJECTION INVARIANT: Unknown client keys and ignored images do
		// not cross into action handlers or multiply per-request memory use.
		$clean = array();

		foreach( array( 'text', 'prompt' ) as $key ) {
			if( is_scalar( $payload[$key] ?? null ) ) {
				$clean[$key] = trim( mb_substr(
					wp_kses_post( self::bounded_text( $payload[$key], self::MAX_TEXT_INPUT_BYTES ) ),
					0,
					20000
				) );
			}
		}
		if( is_scalar( $payload['_regenerate'] ?? null ) ) {
			$clean['_regenerate'] = (bool) filter_var(
				self::bounded_text( $payload['_regenerate'], 32 ),
				FILTER_VALIDATE_BOOLEAN
			);
		}
		if( is_array( $payload['images'] ?? null ) ) {
			$clean['images'] = array();
			foreach( array_slice( $payload['images'], 0, 4 ) as $image ) {
				if( is_array( $image ) && is_string( $image['base64'] ?? null ) ) {
					$clean['images'][] = array( 'base64' => $image['base64'] );
				}
			}
		}

		return $clean;
	}

	/**
	 * Sanitize context payload.
	 */

	public static function sanitize_context_payload( $payload ): array {
		if( ! is_array( $payload ) ) {
			return array();
		}

		$clean = array();

		foreach( array( 'content', 'current', 'title', 'description', 'excerpt', 'url', 'mime', 'alt', 'caption' ) as $key ) {
			if( is_scalar( $payload[$key] ?? null ) ) {
				$clean[$key] = trim( mb_substr(
					wp_strip_all_tags( self::bounded_text( $payload[$key], self::MAX_TEXT_INPUT_BYTES ) ),
					0,
					30000
				) );
			}
		}

		if( isset( $payload['focusKeywords'] ) && is_array( $payload['focusKeywords'] ) ) {
			// KEYWORD BUDGET INVARIANT: Context keywords enter a system prompt;
			// cardinality and each source string are bounded before normalization.
			$clean['focusKeywords'] = array_values( array_filter( array_map(
				static fn( $value ) => is_string( $value )
					? trim( sanitize_text_field( self::bounded_text( $value, 255 ) ) )
					: '',
				array_slice( $payload['focusKeywords'], 0, 20 )
			) ) );
		}

		// IMAGE CONTEXT INVARIANT: A media action may pass a data URL to the AI
		// provider only within the same encoded size budget as image edits.
		if( isset( $payload['image'] ) && is_string( $payload['image'] ) && strlen( $payload['image'] ) <= self::MAX_IMAGE_BASE64_BYTES && str_starts_with( $payload['image'], 'data:image/' ) ) {
			$clean['image'] = $payload['image'];
		}

		return $clean;
	}

	/** Bound raw input before any sanitizer scans it, preserving UTF-8 when available. */
	private static function bounded_text( $value, int $max_bytes ): string {
		$value = (string) $value;
		return function_exists( 'mb_strcut' )
			? mb_strcut( $value, 0, $max_bytes, 'UTF-8' )
			: substr( $value, 0, $max_bytes );
	}

}
