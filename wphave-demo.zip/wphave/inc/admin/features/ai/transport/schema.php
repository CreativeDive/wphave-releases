<?php

if( ! defined('ABSPATH') ) {
	exit;
}

/**
 * Manage the ai schema feature.
 */

class WPHAVE_AI_Schema {

	/**
	 * Return the canonical list of AI actions supported by the backend.
	 * The returned definitions are the server-side contract used for routing, provider selection, streaming support, and output metadata.
	 */

	public static function actions(): array {
		return WPHAVE_AI_Action_Registry::actions();
	}

	/**
	 * Action.
	 */

	public static function action( string $action ): ?array {
		$actions = self::actions();

		return $actions[$action] ?? null;
	}

	/**
	 * Action domain.
	 */

	public static function action_domain( string $action ): string {
		$schema = self::action( $action );

		return $schema['domain'] ?? 'text';
	}

	/**
	 * Sanitize options.
	 */

	public static function sanitize_options( $options ): array {
		if( ! is_array( $options ) ) {
			return array();
		}

		$allowed = array(
			'tone',
			'language',
			'minLength',
			'maxLength',
			'maxTokens',
			'ignoreGlobalRules',
			'ignoreGlobalImageRules',
			'style',
			'mood',
			'size',
			'quality',
			'background',
			'variations',
			'fileFormat',
			'model',
			'generateImages',
		);

		$clean = array();

		foreach( $allowed as $key ) {
			if( ! array_key_exists( $key, $options ) ) {
				continue;
			}

			$value = $options[$key];

			if( is_array( $value ) ) {
				$clean[$key] = array_values( array_map( 'sanitize_text_field', $value ) );
			} elseif( is_bool( $value ) ) {
				$clean[$key] = $value;
			} elseif( in_array( $key, array( 'minLength', 'maxLength', 'maxTokens', 'variations' ), true ) ) {
				$clean[$key] = absint( $value );
			} else {
				$clean[$key] = sanitize_textarea_field( (string) $value );
			}
		}

		return $clean;
	}

	/**
	 * Sanitize messages.
	 */

	public static function sanitize_messages( $messages, int $limit = 10 ): array {
		if( ! is_array( $messages ) ) {
			return array();
		}

		$clean = array();

		foreach( $messages as $message ) {
			if( ! is_array( $message ) ) {
				continue;
			}

			$role = $message['role'] ?? 'user';
			$content = (string) ( $message['content'] ?? '' );
			$content = trim( mb_substr( wp_strip_all_tags( $content ), 0, 8000 ) );

			if( $content === '' ) {
				continue;
			}

			$clean[] = array(
				'role' => in_array( $role, array( 'user', 'assistant' ), true ) ? $role : 'user',
				'content' => $content,
			);
		}

		return array_slice( $clean, -1 * absint( $limit ) );
	}

	/**
	 * Sanitize payload.
	 */

	public static function sanitize_payload( $payload ): array {
		if( ! is_array( $payload ) ) {
			return array();
		}

		$clean = $payload;

		foreach( array( 'text', 'prompt' ) as $key ) {
			if( isset( $clean[$key] ) ) {
				$clean[$key] = trim( mb_substr( wp_kses_post( (string) $clean[$key] ), 0, 20000 ) );
			}
		}

		return $clean;
	}

	/**
	 * Sanitize context payload.
	 */

	public static function sanitize_context_payload( $payload ): array {
		if( ! is_array( $payload ) ) {
			return array();
		}

		$clean = array();

		foreach( array( 'content', 'current', 'title', 'description', 'excerpt', 'url', 'mime', 'alt', 'caption' ) as $key ) {
			if( isset( $payload[$key] ) ) {
				$clean[$key] = trim( mb_substr( wp_strip_all_tags( (string) $payload[$key] ), 0, 30000 ) );
			}
		}

		if( isset( $payload['focusKeywords'] ) && is_array( $payload['focusKeywords'] ) ) {
			$clean['focusKeywords'] = array_values( array_filter( array_map( function( $value ) {
				return trim( sanitize_text_field( (string) $value ) );
			}, $payload['focusKeywords'] ) ) );
		}

		if( isset( $payload['image'] ) && is_string( $payload['image'] ) && str_starts_with( $payload['image'], 'data:image/' ) ) {
			$clean['image'] = $payload['image'];
		}

		return $clean;
	}

}
