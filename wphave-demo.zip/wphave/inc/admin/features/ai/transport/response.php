<?php

if( ! defined('ABSPATH') ) {
	exit;
}

/**
 * Manage the ai response feature.
 */

class WPHAVE_AI_Response {

	/**
	 * Normalize an AI response into the shared app response shape.
	 * Keeps the provider result contract while adding action, type, draft, and diagnostic metadata.
	 */

	public static function normalize( array $response, string $action = '', string $type = 'text' ): array {
		$result = trim( (string) ( $response['result'] ?? '' ) );

		return array_merge( $response, array(
			'ok' => true,
			'action' => $action,
			'type' => $type,
			'result' => $result,
			'draft' => $response['draft'] ?? $result,
			'meta' => array_merge( array(
				'provider' => $response['provider'] ?? '',
			), $response['meta'] ?? array() ),
		) );
	}

}
