<?php

if( ! defined('ABSPATH') ) {
	exit;
}

require_once wphave_dir() . 'inc/features/security/rate-limiter.php';
require_once wphave_dir() . 'inc/features/security/rest-body-budget.php';

/**
 * Manage the ai guard feature.
 */

class WPHAVE_AI_Guard {

	const RATE_LIMIT_SECONDS = 2;
	const MAX_JSON_BYTES = MB_IN_BYTES;
	const MAX_IMAGE_JSON_BYTES = 20 * MB_IN_BYTES;

	/**
	 * REST permission callback for all AI endpoints.
	 * Delegates to the shared guard so route registration stays declarative.
	 */

	public static function permission_callback( $request ) {
		$result = self::check( $request );

		return is_wp_error( $result ) ? $result : true;
	}

	/**
	 * Validate whether an AI request may run.
	 * The guard checks global feature availability, user capabilities, known actions, provider availability, and rate limits.
	 */

	public static function check( $request, array $options = array() ) {
		if( ! is_user_logged_in() ) {
			return new WP_Error( 'ai_not_logged_in', __( 'User not authenticated', 'wphave' ), array( 'status' => 401 ) );
		}

		if( WPHAVE_AI_Config::is_disabled() ) {
			return new WP_Error( 'ai_disabled', __( 'AI features are disabled.', 'wphave' ), array( 'status' => 403 ) );
		}

		if( ! current_user_can( 'edit_posts' ) ) {
			return new WP_Error( 'ai_forbidden', __( 'User role not allowed', 'wphave' ), array( 'status' => 403 ) );
		}

		// REQUEST-BUDGET INVARIANT: Even a permitted editor cannot make REST
		// decoding or downstream sanitizers process an unbounded JSON document.
		// Image edits alone need the larger encoded-image envelope.
		$max_bytes = $request->get_route() === '/wphave/v1/ai/image'
			? self::MAX_IMAGE_JSON_BYTES
			: self::MAX_JSON_BYTES;
		$body_error = WPHAVE_REST_Body_Budget::check( $request, $max_bytes );
		if ( $body_error ) {
			return $body_error;
		}

		if( ! WPHAVE_AI_Config::has_provider() ) {
			return new WP_Error( 'ai_no_provider', __( 'No AI provider is configured.', 'wphave' ), array( 'status' => 400 ) );
		}

		if ( ( $options['rate_limit'] ?? true ) === true ) {
			$rate_limit = self::rate_limit();
			if( is_wp_error( $rate_limit ) ) {
				return $rate_limit;
			}
		}

		if( ( $options['authorize_action'] ?? true ) === true ) {
			$action = self::request_action( $request );

			// SECURITY INVARIANT: An authenticated editor and configured provider do
			// not authorize arbitrary model operations. Every named action must resolve
			// through the central schema allowlist before provider credentials are used.
			if( $action && ! WPHAVE_AI_Schema::action( $action ) ) {
				return new WP_Error( 'ai_action_forbidden', __( 'AI action not allowed', 'wphave' ), array( 'status' => 403 ) );
			}

			if( $action && WPHAVE_AI_Schema::action_domain( $action ) === 'image' && ! WPHAVE_AI_Config::openai_api_key() ) {
				return new WP_Error( 'ai_image_provider_missing', __( 'Image generation currently requires an OpenAI API key.', 'wphave' ), array( 'status' => 400 ) );
			}
		}

		return array(
			'user_id' => get_current_user_id(),
		);
	}

	/**
	 * Extract the requested AI action from a REST request.
	 * Supports JSON payloads and falls back to an empty string when no action is present.
	 */

	protected static function request_action( $request ): string {
		$action = $request->get_param( 'action' );

		if( ! $action && method_exists( $request, 'get_json_params' ) ) {
			$params = $request->get_json_params();
			$action = is_array( $params ) ? ( $params['action'] ?? '' ) : '';
		}

		return sanitize_text_field( (string) $action );
	}

	/**
	 * Apply a lightweight per-user AI request rate limit.
	 * Returns a WP_Error when the user exceeds the configured rolling request window.
	 */

	protected static function rate_limit() {
		$user_id = get_current_user_id();

		if( ! $user_id || current_user_can( 'manage_options' ) ) {
			return true;
		}

		$key = 'wphave_ai_rate_' . $user_id;
		if( WPHAVE_Rate_Limiter::increment( $key, self::RATE_LIMIT_SECONDS ) > 1 ) {
			return new WP_Error( 'ai_rate_limited', __( 'Please wait before sending another AI request.', 'wphave' ), array( 'status' => 429 ) );
		}

		return true;
	}

}
