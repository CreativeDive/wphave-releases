<?php

if( ! defined('ABSPATH') ) {
	exit;
}

/**
 * Manage the ai REST feature.
 */

class WPHAVE_AI_REST_Controller {

	const REST_NAMESPACE = 'wphave/v1';

	protected static $instance = null;

	/**
	 * Return the singleton instance for this AI service.
	 * Keeps route callbacks and provider calls using a shared stateless service instance.
	 */

	public static function instance(): self {
		if( ! self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Register all AI REST endpoints.
	 * Every route shares the same guard callback and delegates execution to domain-specific handlers.
	 */

	public function register_routes(): void {
		$permission = array( 'WPHAVE_AI_Guard', 'permission_callback' );

		register_rest_route( self::REST_NAMESPACE, '/ai/text', array(
			'methods' => 'POST',
			'callback' => array( $this, 'handle_text' ),
			'permission_callback' => $permission,
		) );

		register_rest_route( self::REST_NAMESPACE, '/ai/chat', array(
			'methods' => 'POST',
			'callback' => array( $this, 'handle_chat' ),
			'permission_callback' => $permission,
		) );

		register_rest_route( self::REST_NAMESPACE, '/ai/image', array(
			'methods' => 'POST',
			'callback' => array( $this, 'handle_image' ),
			'permission_callback' => $permission,
		) );

		register_rest_route( self::REST_NAMESPACE, '/ai/global-styles', array(
			'methods' => 'POST',
			'callback' => array( $this, 'handle_global_styles' ),
			'permission_callback' => $permission,
		) );

		register_rest_route( self::REST_NAMESPACE, '/ai/context', array(
			'methods' => 'POST',
			'callback' => array( $this, 'handle_context' ),
			'permission_callback' => $permission,
		) );

		register_rest_route( self::REST_NAMESPACE, '/ai/plan-action', array(
			'methods' => 'POST',
			'callback' => array( $this, 'handle_plan_action' ),
			'permission_callback' => $permission,
		) );

		register_rest_route( self::REST_NAMESPACE, '/ai/website-planner/sitemap', array(
			'methods' => 'POST',
			'callback' => array( $this, 'handle_website_planner_sitemap' ),
			'permission_callback' => $permission,
		) );

		register_rest_route( self::REST_NAMESPACE, '/ai/website-planner/wireframes', array(
			'methods' => 'POST',
			'callback' => array( $this, 'handle_website_planner_wireframes' ),
			'permission_callback' => $permission,
		) );

		register_rest_route( self::REST_NAMESPACE, '/ai/website-planner/style-guide', array(
			'methods' => 'POST',
			'callback' => array( $this, 'handle_website_planner_style_guide' ),
			'permission_callback' => $permission,
		) );

		register_rest_route( self::REST_NAMESPACE, '/ai/website-planner/section', array(
			'methods' => 'POST',
			'callback' => array( $this, 'handle_website_planner_section' ),
			'permission_callback' => $permission,
		) );

		register_rest_route( self::REST_NAMESPACE, '/ai/audio/transcribe', array(
			'methods' => 'POST',
			'callback' => array( $this, 'handle_audio_transcription' ),
			'permission_callback' => $permission,
		) );

		register_rest_route( self::REST_NAMESPACE, '/ai/audio/speech', array(
			'methods' => 'POST',
			'callback' => array( $this, 'handle_audio_speech' ),
			'permission_callback' => $permission,
		) );

		register_rest_route( self::REST_NAMESPACE, '/ai/stream', array(
			'methods' => 'POST',
			'callback' => array( $this, 'handle_stream' ),
			'permission_callback' => $permission,
		) );
	}

	/** Repeat the shared AI authorization policy at a final handler boundary. */
	protected function authorize_request( WP_REST_Request $request ) {
		// AUTHORIZATION INVARIANT: AI handlers can consume provider credentials and
		// paid quota, so they never inherit authority from REST dispatch. The final
		// check repeats identity, capability, feature, provider and action policy but
		// does not charge the route's per-user rate-limit counter a second time.
		return WPHAVE_AI_Guard::check( $request, array( 'rate_limit' => false ) );
	}

	/**
	 * Handle non-streaming text action requests.
	 * Reads the requested action and delegates to the text action runner.
	 */

	public function handle_text( WP_REST_Request $request ) {
		$authorization = $this->authorize_request( $request );
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}
		$params = $this->request_params( $request );
		$action = sanitize_text_field( $params['action'] ?? 'text.restyle' );

		return $this->run_text_action( $action, $params['payload'] ?? array(), $params['options'] ?? array() );
	}

	/**
	 * Handle non-streaming chat requests.
	 * Builds chat messages and returns a normalized chat response.
	 */

	public function handle_chat( WP_REST_Request $request ) {
		$authorization = $this->authorize_request( $request );
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}
		$params = $this->request_params( $request );
		$messages = WPHAVE_AI_Schema::sanitize_messages( $params['messages'] ?? array() );
		$options = WPHAVE_AI_Schema::sanitize_options( $params['options'] ?? array() );

		$built = WPHAVE_AI_Prompts::build_messages( array(
			'mode' => 'chat',
			'action' => 'chat',
			'messages' => $messages,
			'options' => $options,
		) );

		if( is_wp_error( $built ) ) {
			return $built;
		}

		$response = $this->generate_text( $built, $options );

		return is_wp_error( $response ) ? $response : WPHAVE_AI_Response::normalize( $response, 'chat', 'chat' );
	}

	/**
	 * Handle image generation and edit requests.
	 * Dispatches to the OpenAI image generation or edit provider based on the requested action.
	 */

	public function handle_image( WP_REST_Request $request ) {
		$authorization = $this->authorize_request( $request );
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}
		$params = $this->request_params( $request );
		$action = sanitize_text_field( $params['action'] ?? 'image.generate' );
		$payload = WPHAVE_AI_Schema::sanitize_payload( $params['payload'] ?? array() );
		$options = WPHAVE_AI_Schema::sanitize_options( $params['options'] ?? array() );

		if( ! empty( $payload['prompt'] ) ) {
			$payload['prompt'] = WPHAVE_AI_Prompts::enrich_image_prompt( (string) $payload['prompt'], $options );
		}

		if( $action === 'image.edit' ) {
			return WPHAVE_AI_Provider_OpenAI::instance()->edit_image( $payload, $options );
		}

		return WPHAVE_AI_Provider_OpenAI::instance()->generate_image( $payload, $options );
	}

	/**
	 * Handle controlled global style recipe generation.
	 * Requests a JSON recipe response, validates it, and retries once when the generated patch is too weak.
	 */

	public function handle_global_styles( WP_REST_Request $request ) {
		$authorization = $this->authorize_request( $request );
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}
		$params = $this->request_params( $request );
		$payload = WPHAVE_AI_Schema::sanitize_payload( $params['payload'] ?? array() );
		$options = WPHAVE_AI_Schema::sanitize_options( $params['options'] ?? array() );
		$options['maxTokens'] = max( 3500, (int) ( $options['maxTokens'] ?? 0 ) );
		$options['responseFormat'] = 'json_object';
		$prompt = trim( (string) ( $payload['prompt'] ?? '' ) );

		if( $prompt === '' ) {
			return new WP_Error( 'ai_empty_prompt', __( 'No global style prompt provided.', 'wphave' ), array( 'status' => 400 ) );
		}

		$messages = WPHAVE_AI_Global_Styles::build_messages( $prompt, $options );
		$response = WPHAVE_AI_Config::openai_api_key() !== ''
			? WPHAVE_AI_Provider_OpenAI::instance()->generate_text( $messages, $options )
			: $this->generate_text( $messages, $options );

		if( is_wp_error( $response ) ) {
			return $response;
		}

		$proposal = WPHAVE_AI_Global_Styles::validate_response( $response['result'] ?? '', $prompt );
		if( is_wp_error( $proposal ) && $proposal->get_error_code() === 'ai_global_styles_too_weak' ) {
			$messages[] = array(
				'role' => 'assistant',
				'content' => $response['result'] ?? '',
			);
			$messages[] = array(
				'role' => 'user',
				'content' => 'This patch is too weak. Generate a visibly meaningful global style patch that changes at least colors, typography, buttons, links/forms, and layout. Do not only round existing numbers.',
			);

			$response = WPHAVE_AI_Config::openai_api_key() !== ''
				? WPHAVE_AI_Provider_OpenAI::instance()->generate_text( $messages, $options )
				: $this->generate_text( $messages, $options );
			if( is_wp_error( $response ) ) {
				return $response;
			}

			$proposal = WPHAVE_AI_Global_Styles::validate_response( $response['result'] ?? '', $prompt );
		}

		if( is_wp_error( $proposal ) ) {
			return $proposal;
		}

		return array(
			'proposal' => $proposal,
			'result' => $response['result'] ?? '',
			'provider' => $response['provider'] ?? '',
		);
	}

	/**
	 * Handle field/block-specific context action requests.
	 * Delegates to the context action service so the controller remains route-focused.
	 */

	public function handle_context( WP_REST_Request $request ) {
		$authorization = $this->authorize_request( $request );
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}
		$params = $this->request_params( $request );
		$action = sanitize_text_field( $params['action'] ?? '' );

		return WPHAVE_AI_Context_Actions::run( $action, $params['payload'] ?? array(), $params['options'] ?? array() );
	}

	/**
	 * Plan a controlled app action from natural language.
	 * Returns a validated draft only; execution still requires explicit client-side confirmation.
	 */

	public function handle_plan_action( WP_REST_Request $request ) {
		$authorization = $this->authorize_request( $request );
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}
		return WPHAVE_AI_App_Actions::plan( $this->request_params( $request ) );
	}

	/**
	 * Generate the first AI sitemap for the Website Planner flow.
	 */

	public function handle_website_planner_sitemap( WP_REST_Request $request ) {
		$authorization = $this->authorize_request( $request );
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}
		if( ! current_user_can( 'wphave_manage_global_styles' ) && ! current_user_can( 'edit_pages' ) && ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'ai_forbidden', __( 'User role not allowed', 'wphave' ), array( 'status' => 403 ) );
		}

		$params = $this->request_params( $request );

		return WPHAVE_Website_Plan_AI_Sitemap_Generator::generate( $params, function( array $messages, array $options = array() ) {
			return $this->generate_text( $messages, $options );
		} );
	}

	/**
	 * Generate rich page content from the Website Planner sitemap and render it as block markup.
	 */

	public function handle_website_planner_wireframes( WP_REST_Request $request ) {
		$authorization = $this->authorize_request( $request );
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}
		if( ! current_user_can( 'wphave_manage_global_styles' ) && ! current_user_can( 'edit_pages' ) && ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'ai_forbidden', __( 'User role not allowed', 'wphave' ), array( 'status' => 403 ) );
		}

		$params = $this->request_params( $request );

		return WPHAVE_Website_Plan_AI_Wireframe_Generator::generate( $params, function( array $messages, array $options = array() ) {
			return $this->generate_text( $messages, $options );
		} );
	}

	/**
	 * Generate a controlled global Style Guide for the Website Planner flow.
	 */

	public function handle_website_planner_style_guide( WP_REST_Request $request ) {
		$authorization = $this->authorize_request( $request );
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}
		if( ! current_user_can( 'wphave_manage_global_styles' ) && ! current_user_can( 'edit_pages' ) && ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'ai_forbidden', __( 'User role not allowed', 'wphave' ), array( 'status' => 403 ) );
		}

		$params = $this->request_params( $request );

		return WPHAVE_Website_Plan_AI_Style_Generator::generate( $params, function( array $messages, array $options = array() ) {
			return $this->generate_text( $messages, $options );
		} );
	}

	/**
	 * Regenerate one Website Planner wireframe section.
	 */

	public function handle_website_planner_section( WP_REST_Request $request ) {
		$authorization = $this->authorize_request( $request );
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}
		if( ! current_user_can( 'wphave_manage_global_styles' ) && ! current_user_can( 'edit_pages' ) && ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'ai_forbidden', __( 'User role not allowed', 'wphave' ), array( 'status' => 403 ) );
		}

		$params = $this->request_params( $request );

		return WPHAVE_Website_Plan_AI_Section_Generator::regenerate( $params, function( array $messages, array $options = array() ) {
			return $this->generate_text( $messages, $options );
		} );
	}

	/**
	 * Transcribe a browser microphone upload into text.
	 * The resulting text is intended to fill the prompt field so users can verify it before sending an AI request.
	 */

	public function handle_audio_transcription( WP_REST_Request $request ) {
		$authorization = $this->authorize_request( $request );
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}
		$files = $request->get_file_params();
		$file = $files['audio'] ?? null;
		$validation = $this->validate_audio_upload( $file );

		if( is_wp_error( $validation ) ) {
			return $validation;
		}

		return WPHAVE_AI_Provider_OpenAI::instance()->transcribe_audio( $file );
	}

	/**
	 * Validate an audio upload before it crosses the external provider boundary.
	 *
	 * @param mixed $file Uploaded audio structure.
	 * @return true|WP_Error Validation result.
	 */

	protected function validate_audio_upload( $file ) {
		if( empty( $file ) || ! is_array( $file ) ) {
			return new WP_Error( 'ai_audio_missing', __( 'No audio file provided.', 'wphave' ), array( 'status' => 400 ) );
		}

		if( ! empty( $file['error'] ) ) {
			return new WP_Error( 'ai_audio_upload_failed', __( 'Audio upload failed.', 'wphave' ), array( 'status' => 400 ) );
		}

		$temp_name = (string) ( $file['tmp_name'] ?? '' );

		if( ! $temp_name || ! $this->is_valid_audio_upload_path( $temp_name ) ) {
			return new WP_Error( 'ai_audio_invalid_upload', __( 'Invalid audio upload.', 'wphave' ), array( 'status' => 400 ) );
		}

		// SECURITY INVARIANT: The provider limit applies to the actual temporary
		// file that will leave WPHAVE, not to attacker-influenced request metadata.
		$bytes = filesize( $temp_name );

		if( false === $bytes || $bytes < 1 || $bytes > 24 * MB_IN_BYTES ) {
			return new WP_Error( 'ai_audio_too_large', __( 'Audio file is too large.', 'wphave' ), array( 'status' => 413 ) );
		}

		return true;
	}

	/**
	 * Verify that an audio path originates from PHP's HTTP upload handling.
	 *
	 * @param string $path Temporary upload path.
	 * @return bool Whether the path is a verified upload.
	 */

	protected function is_valid_audio_upload_path( $path ) {
		return is_uploaded_file( $path );
	}

	/**
	 * Convert generated text into short browser-playable speech audio.
	 * Returns base64 audio so the client can play it without storing media in WordPress.
	 */

	public function handle_audio_speech( WP_REST_Request $request ) {
		$authorization = $this->authorize_request( $request );
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}
		$params = $this->request_params( $request );
		$text = trim( wp_strip_all_tags( (string) ( $params['text'] ?? '' ) ) );

		if( $text === '' ) {
			return new WP_Error( 'ai_speech_empty_text', __( 'No text provided for speech.', 'wphave' ), array( 'status' => 400 ) );
		}

		return WPHAVE_AI_Provider_OpenAI::instance()->create_speech( $text, $params['options'] ?? array() );
	}

	/**
	 * Handle streaming chat/text/layout requests through SSE.
	 * Builds messages for the action domain and streams tokens directly to the client.
	 */

	public function handle_stream( WP_REST_Request $request ) {
		$authorization = $this->authorize_request( $request );
		if ( is_wp_error( $authorization ) ) {
			return $authorization;
		}
		$params = $this->request_params( $request );
		$action = sanitize_text_field( $params['action'] ?? 'chat' );
		$options = WPHAVE_AI_Schema::sanitize_options( $params['options'] ?? array() );
		$domain = WPHAVE_AI_Schema::action_domain( $action );
		$mode = $domain === 'layout' ? 'layout' : ( $domain === 'chat' ? 'chat' : 'text' );
		$messages = WPHAVE_AI_Schema::sanitize_messages( $params['messages'] ?? array() );

		if( empty( $messages ) && ! empty( $params['payload']['prompt'] ) ) {
			$messages = array(
				array(
					'role' => 'user',
					'content' => sanitize_textarea_field( $params['payload']['prompt'] ),
				),
			);
		}

		$built = WPHAVE_AI_Prompts::build_messages( array(
			'mode' => $mode,
			'action' => $action,
			'messages' => $messages,
			'options' => $options,
		) );

		if( is_wp_error( $built ) ) {
			$this->send_sse_wp_error( $built );
			exit;
		}

		WPHAVE_AI_Provider_OpenAI::instance()->stream_text( $built, $options );
		exit;
	}

	/**
	 * Execute one whitelisted text action.
	 * Sanitizes input, builds action-specific messages, and returns a normalized text response.
	 */

	public function run_text_action( string $action = '', array $payload = array(), array $options = array() ) {
		if( ! WPHAVE_AI_Schema::action( $action ) || WPHAVE_AI_Schema::action_domain( $action ) !== 'text' ) {
			return new WP_Error( 'unknown_action', __( 'Unknown AI action', 'wphave' ), array( 'status' => 400 ) );
		}

		$payload = WPHAVE_AI_Schema::sanitize_payload( $payload );
		$options = WPHAVE_AI_Schema::sanitize_options( $options );
		$text = trim( (string) ( $payload['text'] ?? '' ) );
		$prompt = trim( (string) ( $payload['prompt'] ?? '' ) );
		$input = $text ?: $prompt;

		if( $input === '' ) {
			return new WP_Error( 'ai_empty_text', __( 'No text provided.', 'wphave' ), array( 'status' => 400 ) );
		}

		$built = WPHAVE_AI_Prompts::build_messages( array(
			'mode' => 'text',
			'action' => $action,
			'input' => $input,
			'options' => $options,
			'regenerate' => ! empty( $payload['_regenerate'] ),
		) );

		if( is_wp_error( $built ) ) {
			return $built;
		}

		$response = $this->generate_text( $built, $options );

		return $response;
	}

	/**
	 * Send a text/chat-style request to the selected provider and return a normalized provider response.
	 * The response includes the generated result plus internal provider metadata for diagnostics.
	 */

	protected function generate_text( array $messages, array $options = array() ) {
		return WPHAVE_AI_Provider_Router::generate_text( $messages, $options );
	}

	/**
	 * Return JSON request parameters as an array.
	 * Invalid or missing JSON bodies resolve to an empty array.
	 */

	protected function request_params( WP_REST_Request $request ): array {
		$params = $request->get_json_params();

		return is_array( $params ) ? $params : array();
	}

	/**
	 * Send a WP_Error through the SSE error event format.
	 * Used when a streaming request fails before provider streaming begins.
	 */

	protected function send_sse_wp_error( WP_Error $error ): void {
		header( 'Content-Type: text/event-stream' );
		header( 'Cache-Control: no-cache' );

		echo "event: error\n";
		echo 'data: ' . wp_json_encode( array(
			'code' => $error->get_error_code(),
			'message' => $error->get_error_message(),
		) ) . "\n\n";
		flush();
	}

}
