<?php

if( ! defined('ABSPATH') ) {
	exit;
}

/**
 * Manage the ai app actions feature.
 */

class WPHAVE_AI_App_Actions {

	/**
	 * Return app-level action contracts the current user may request through AI.
	 * Contracts are the source of truth for planning, preview rendering, confirmation requirements, and later execution.
	 */

	public static function contracts( string $context = 'app' ): array {
		$contracts = self::all_contracts();

		return array_values( array_filter( $contracts, function( $contract ) use ( $context ) {
			if( ! in_array( $context, $contract['contexts'] ?? array( 'app' ), true ) ) {
				return false;
			}

			$capability = (string) ( $contract['capability'] ?? '' );
			// SECURITY INVARIANT: Discovery exposes only task contracts executable in
			// the requested context and by the current user's capability set. Hidden
			// contracts cannot become model-selectable operations.
			if( $capability && ! current_user_can( $capability ) && ! current_user_can( 'manage_options' ) ) {
				return false;
			}

			return true;
		} ) );
	}

	/**
	 * Return the app-action classes that expose task contracts.
	 */

	protected static function action_classes(): array {
		$classes = array(
			'WPHAVE_AI_App_Action_CSS_Classes_Create',
			'WPHAVE_AI_App_Action_Forms_Create',
			'WPHAVE_AI_App_Action_Media_Generate_Image',
			'WPHAVE_AI_App_Action_Media_Generate_Image_Set',
		);

		if( function_exists( 'wphave_notes_feature_enabled' ) && wphave_notes_feature_enabled() ) {
			array_unshift( $classes, 'WPHAVE_AI_App_Action_Notes_Create' );
		}

		return $classes;
	}

	/**
	 * Collect contracts from registered action classes.
	 */

	protected static function all_contracts(): array {
		$contracts = array();

		foreach( self::action_classes() as $class_name ) {
			if( ! class_exists( $class_name ) || ! is_callable( array( $class_name, 'contract' ) ) ) {
				continue;
			}

			$contract = $class_name::contract();
			if( ! empty( $contract['id'] ) ) {
				$contracts[$contract['id']] = $contract;
			}
		}

		return $contracts;
	}

	/**
	 * Plan one app action from a free-form user prompt.
	 * The AI may only choose from server-side contracts and must return strict JSON for validation.
	 */

	public static function plan( array $params = array() ) {
		$prompt = trim( mb_substr( wp_strip_all_tags( (string) ( $params['prompt'] ?? '' ) ), 0, 6000 ) );
		$context = sanitize_key( $params['context'] ?? 'app' );
		$context = $context ?: 'app';
		$requested_action_id = isset( $params['actionId'] ) ? preg_replace( '/[^a-z0-9._-]/', '', strtolower( (string) $params['actionId'] ) ) : '';
		$current_values = is_array( $params['currentValues'] ?? null ) ? $params['currentValues'] : array();

		if( $prompt === '' ) {
			return new WP_Error( 'ai_action_empty_prompt', __( 'No action prompt provided.', 'wphave' ), array( 'status' => 400 ) );
		}

		$contracts = self::contracts( $context );
		if( $requested_action_id ) {
			$contracts = array_values( array_filter( $contracts, function( $contract ) use ( $requested_action_id ) {
				return ( $contract['id'] ?? '' ) === $requested_action_id;
			} ) );
		}
		if( empty( $contracts ) ) {
			return array(
				'plan' => self::empty_plan(),
				'contracts' => array(),
			);
		}

		$options = WPHAVE_AI_Schema::sanitize_options( $params['options'] ?? array() );
		$options['responseFormat'] = 'json_object';
		$options['maxTokens'] = max( self::planner_token_budget( $contracts ), (int) ( $options['maxTokens'] ?? 0 ) );

		$messages = self::planner_messages( $prompt, $context, $contracts, $current_values, $requested_action_id, $options );
		$response = WPHAVE_AI_Provider_Router::generate_text( $messages, $options );

		if( is_wp_error( $response ) ) {
			return $response;
		}

		$plan = self::validate_plan( (string) ( $response['result'] ?? '' ), $contracts );
		if( is_wp_error( $plan ) && $plan->get_error_code() === 'ai_action_plan_invalid_json' && ( $response['provider'] ?? '' ) === 'wordpress' && WPHAVE_AI_Config::openai_api_key() !== '' ) {
			$response = WPHAVE_AI_Provider_OpenAI::instance()->generate_text( $messages, $options );
			if( is_wp_error( $response ) ) {
				return $response;
			}
			$plan = self::validate_plan( (string) ( $response['result'] ?? '' ), $contracts );
		}
		if( is_wp_error( $plan ) && $plan->get_error_code() === 'ai_action_plan_invalid_json' && WPHAVE_AI_Config::openai_api_key() !== '' ) {
			$repair_messages = $messages;
			$repair_messages[] = array(
				'role' => 'assistant',
				'content' => (string) ( $response['result'] ?? '' ),
			);
			$repair_messages[] = array(
				'role' => 'user',
				'content' => 'Your previous response was not parseable JSON. Return the same action plan again as one compact valid JSON object only. No markdown, no comments, no code fence, no prose. Keep the values object complete but concise.',
			);
			$options['maxTokens'] = max( $options['maxTokens'], 12000 );
			$response = WPHAVE_AI_Provider_OpenAI::instance()->generate_text( $repair_messages, $options );
			if( is_wp_error( $response ) ) {
				return $response;
			}
			$plan = self::validate_plan( (string) ( $response['result'] ?? '' ), $contracts );
		}

		if( is_wp_error( $plan ) ) {
			return $plan;
		}

		return array(
			'plan' => $plan,
			'contracts' => self::public_contracts( $contracts ),
			'provider' => $response['provider'] ?? '',
			'meta' => $response['meta'] ?? null,
		);
	}

	/**
	 * Resolve a planner token budget large enough for the selected contract schemas.
	 * Layout variant planning needs substantially more room because it returns several complete blueprints.
	 */

	protected static function planner_token_budget( array $contracts ): int {
		return 1600;
	}

	/**
	 * Build the planner prompt with only public contract details.
	 * The model chooses intent and drafts values; execution still stays server/client controlled.
	 */

	protected static function planner_messages( string $prompt, string $context, array $contracts, array $current_values = array(), string $requested_action_id = '', array $options = array() ): array {
		return array(
			array(
				'role' => 'system',
				'content' => implode( "\n", array(
					'You are an action planner for a WordPress admin AI assistant.',
					'Choose at most one action from the provided contracts.',
					'Return valid JSON only. No markdown, no code fence.',
					'If no contract matches confidently, return {"actionId":null,"confidence":0,"requiresConfirmation":false,"values":{},"message":"","missingFields":[]}.',
					'If requestedActionId is provided but the user prompt is unrelated to that action contract, do not force a draft. Return actionId null with confidence 0.',
					'For matched actions, draft all useful required values from the user prompt and contract instruction.',
					'If currentValues are provided, treat the user prompt as a requested change to that existing draft. Preserve useful existing values unless the user asks to change them.',
					'Never invent actions, capabilities, routes, or execution side effects.',
				) ),
			),
			array(
				'role' => 'user',
				'content' => wp_json_encode( array(
					'context' => $context,
					'prompt' => $prompt,
					'requestedActionId' => $requested_action_id ?: null,
					'currentValues' => $current_values,
					'contracts' => self::public_contracts( $contracts ),
					'patternCatalog' => null,
					'planningOptions' => array(
						'generateImages' => ! empty( $options['generateImages'] ),
					),
					'expectedJsonShape' => array(
						'actionId' => 'string|null',
						'confidence' => 'number between 0 and 1',
						'requiresConfirmation' => 'boolean',
						'values' => 'object with contract schema keys',
						'message' => 'short preview sentence for the user',
						'missingFields' => 'array of missing required field keys',
					),
				), JSON_UNESCAPED_UNICODE ),
			),
		);
	}

	/**
	 * Strip private/runtime-only contract details before sending them to the model or client.
	 */

	protected static function public_contracts( array $contracts ): array {
		return array_values( array_map( function( $contract ) {
			return array(
				'id' => $contract['id'] ?? '',
				'label' => $contract['label'] ?? '',
				'description' => $contract['description'] ?? '',
				'confirmLabel' => $contract['confirmLabel'] ?? '',
				'requiresConfirmation' => ! empty( $contract['requiresConfirmation'] ),
				'intentExamples' => $contract['intentExamples'] ?? array(),
				'schema' => $contract['schema'] ?? array(),
				'draftInstruction' => $contract['draftInstruction'] ?? '',
			);
		}, $contracts ) );
	}

	/**
	 * Decode and validate the planner response against the available contracts.
	 * Unknown actions, malformed values, and missing required fields are rejected before they reach execution.
	 */

	protected static function validate_plan( string $raw, array $contracts ) {
		$data = json_decode( self::extract_json_object( $raw ), true );
		if( ! is_array( $data ) ) {
			return new WP_Error( 'ai_action_plan_invalid_json', __( 'The generated action plan is not valid JSON.', 'wphave' ), array( 'status' => 502 ) );
		}

		$action_id = isset( $data['actionId'] ) ? preg_replace( '/[^a-z0-9._-]/', '', strtolower( (string) $data['actionId'] ) ) : '';
		if( $action_id === '' ) {
			return self::empty_plan();
		}

		$contract = null;
		foreach( $contracts as $item ) {
			if( ( $item['id'] ?? '' ) === $action_id ) {
				$contract = $item;
				break;
			}
		}

		if( ! $contract ) {
			return self::empty_plan();
		}

		$values = self::sanitize_values( $data['values'] ?? array(), $contract['schema'] ?? array() );
		$missing = self::missing_required_fields( $values, $contract['schema'] ?? array() );

		return array(
			'actionId' => $action_id,
			'confidence' => min( 1, max( 0, (float) ( $data['confidence'] ?? 0 ) ) ),
			'requiresConfirmation' => ! empty( $contract['requiresConfirmation'] ),
			'values' => $values,
			'message' => trim( mb_substr( wp_strip_all_tags( (string) ( $data['message'] ?? '' ) ), 0, 260 ) ),
			'missingFields' => $missing,
		);
	}

	/**
	 * Sanitize planner values according to the contract schema.
	 * Markdown fields keep safe formatting; plain strings are reduced to single-line text.
	 */

	protected static function sanitize_values( $values, array $schema ): array {
		if( ! is_array( $values ) ) {
			return array();
		}

		$clean = array();

		foreach( $schema as $key => $field ) {
			if( ! array_key_exists( $key, $values ) ) {
				continue;
			}

			$max_length = absint( $field['maxLength'] ?? 5000 );
			$max_length = $max_length > 0 ? $max_length : 5000;

			if( ( $field['type'] ?? '' ) === 'formFields' ) {
				$clean[$key] = WPHAVE_AI_App_Action_Forms_Create::sanitize_fields( $values[$key], absint( $field['maxItems'] ?? 20 ) );
				continue;
			}

			$value = (string) $values[$key];

			if( ( $field['type'] ?? '' ) === 'markdown' ) {
				$clean[$key] = trim( mb_substr( wp_kses_post( $value ), 0, $max_length ) );
			} elseif( ( $field['type'] ?? '' ) === 'css' ) {
				$value = class_exists( 'WPHAVE_CSS_Class_Manager' )
					? WPHAVE_CSS_Compiler::sanitize_source( $value )
					: trim( wp_strip_all_tags( $value ) );
				if( $value !== '' && ! str_contains( $value, '$class' ) && ! str_contains( $value, '{' ) ) {
					$value = '$class {' . "\n  " . trim( $value ) . "\n" . '}';
				}
				$clean[$key] = trim( mb_substr( $value, 0, $max_length ) );
			} elseif( ( $field['type'] ?? '' ) === 'className' ) {
				$value = sanitize_title( $value );
				$value = preg_replace( '/[^a-z0-9_-]/', '-', strtolower( $value ) );
				$value = preg_replace( '/-+/', '-', $value );
				$clean[$key] = trim( mb_substr( trim( $value, '-' ), 0, $max_length ) );
			} elseif( ( $field['type'] ?? '' ) === 'slug' ) {
				$value = sanitize_title( $value );
				$clean[$key] = trim( mb_substr( trim( $value, '-' ), 0, $max_length ) );
			} elseif( ( $field['type'] ?? '' ) === 'filename' ) {
				$value = sanitize_file_name( remove_accents( $value ) );
				$value = preg_replace( '/\.[a-z0-9]{2,5}$/i', '', $value );
				$value = preg_replace( '/[^a-z0-9_-]/', '-', strtolower( $value ) );
				$value = preg_replace( '/-+/', '-', $value );
				$clean[$key] = trim( mb_substr( trim( $value, '-' ), 0, $max_length ) );
			} elseif( ( $field['type'] ?? '' ) === 'imageSize' ) {
				$value = sanitize_key( $value );
				$clean[$key] = in_array( $value, array( 'square', 'landscape', 'portrait' ), true ) ? $value : '';
			} else {
				$clean[$key] = trim( mb_substr( sanitize_text_field( $value ), 0, $max_length ) );
			}
		}

		return $clean;
	}

	/**
	 * Return missing required schema keys after sanitization.
	 */

	protected static function missing_required_fields( array $values, array $schema ): array {
		$missing = array();

		foreach( $schema as $key => $field ) {
			if( empty( $field['required'] ) ) {
				continue;
			}

			if( is_array( $values[$key] ?? null ) ) {
				if( empty( $values[$key] ) ) {
					$missing[] = $key;
				}

				continue;
			}

			if( trim( (string) ( $values[$key] ?? '' ) ) === '' ) {
				$missing[] = $key;
			}
		}

		return $missing;
	}

	/**
	 * Extract the first JSON object from provider output.
	 * This keeps strict planning tolerant of providers that wrap JSON in prose or code fences.
	 */

	protected static function extract_json_object( string $response ): string {
		$response = trim( preg_replace( '/^```(?:json)?|```$/m', '', $response ) );
		$start = strpos( $response, '{' );
		$end = strrpos( $response, '}' );

		if( $start === false || $end === false || $end <= $start ) {
			return $response;
		}

		return substr( $response, $start, $end - $start + 1 );
	}

	/**
	 * Return a normalized no-action plan.
	 */

	protected static function empty_plan(): array {
		return array(
			'actionId' => null,
			'confidence' => 0,
			'requiresConfirmation' => false,
			'values' => array(),
			'message' => '',
			'missingFields' => array(),
		);
	}

}
