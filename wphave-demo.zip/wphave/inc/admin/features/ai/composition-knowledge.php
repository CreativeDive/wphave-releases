<?php

if( ! defined('ABSPATH') ) {
	exit;
}

/**
 * Loads markdown knowledge files used as the AI composition contract.
 */

class WPHAVE_AI_Composition_Knowledge {

	protected const FILES = array(
		'ai-wphave-block-design-language.md',
		'ai-wphave-composition-language.md',
		'ai-wphave-block-capabilities.md',
		'ai-website-quality-rubric.md',
	);

	/**
	 * Bundle.
	 *
	 * @return string Bundle.
	 */

	public static function bundle(): string {
		$parts = array();

		foreach( self::FILES as $file ) {
			$content = self::read_doc( $file );
			if( $content !== '' ) {
				$parts[] = $content;
			}
		}

		return implode( "\n\n---\n\n", $parts );
	}

	/**
	 * Read doc.
	 *
	 * @param string $file File.
	 * @return string Read doc.
	 */

	protected static function read_doc( string $file ): string {
		$path = trailingslashit( wphave_dir() ) . 'docs/' . $file;
		if( ! is_readable( $path ) ) {
			return '';
		}

		$content = file_get_contents( $path );
		if( ! is_string( $content ) || trim( $content ) === '' ) {
			return '';
		}

		$content = str_replace( "\r\n", "\n", $content );
		$content = trim( wp_strip_all_tags( $content, true ) );

		return mb_substr( $content, 0, 16000 );
	}

}
