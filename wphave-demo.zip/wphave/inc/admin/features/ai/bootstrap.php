<?php

if( ! defined('ABSPATH') ) {
	exit;
}

include_once __DIR__ . '/config.php';
include_once __DIR__ . '/action-registry.php';
include_once __DIR__ . '/transport/response.php';
include_once __DIR__ . '/transport/schema.php';
include_once __DIR__ . '/transport/guard.php';
include_once __DIR__ . '/prompts.php';
include_once __DIR__ . '/composition-knowledge.php';
include_once wphave_dir() . 'inc/editor/pattern/text-variants.php';
include_once wphave_dir() . 'inc/editor/pattern/slots.php';
include_once __DIR__ . '/layout/block-design-compiler.php';
include_once __DIR__ . '/layout/composition-compiler.php';
include_once __DIR__ . '/layout/page-composition-recipes.php';
include_once __DIR__ . '/layout/page-composition-plan.php';
include_once __DIR__ . '/global-styles.php';
include_once __DIR__ . '/providers/openai.php';
include_once __DIR__ . '/providers/wordpress.php';
include_once __DIR__ . '/providers/router.php';
include_once __DIR__ . '/context-actions.php';
include_once __DIR__ . '/app-actions/functions.php';
include_once __DIR__ . '/app-actions.php';
include_once __DIR__ . '/transport/rest-controller.php';
include_once __DIR__ . '/feature.php';

WPHAVE_AI_Feature::init();
