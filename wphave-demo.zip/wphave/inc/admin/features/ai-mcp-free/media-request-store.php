<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Indexed, permanent request identities for direct MCP image writes. */
final class WPHAVE_AI_MCP_Media_Request_Store {
	private const SCHEMA_VERSION = 2;
	private const REQUIRED_COLUMNS = array(
		'request_key', 'site_id', 'actor_id', 'operation', 'input_hash', 'state',
		'created_at', 'updated_at', 'expected_hash', 'expected_mime',
		'expected_filename', 'expected_title', 'expected_alt', 'attachment_id',
		'result_json', 'error_code',
	);
	private static array $ready = array();

	private static function table(): string {
		global $wpdb;
		return $wpdb->prefix . 'wphave_ai_mcp_image_requests';
	}

	private static function version_option(): string {
		return 'wphave_ai_mcp_image_schema_version';
	}

	public static function install(): void {
		global $wpdb;
		$table = self::table();
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$collate = $wpdb->get_charset_collate();
		dbDelta( "CREATE TABLE {$table} (
				request_key varchar(84) NOT NULL,
				site_id bigint(20) unsigned NOT NULL,
				actor_id bigint(20) unsigned NOT NULL,
				operation varchar(12) NOT NULL,
				input_hash char(64) NOT NULL,
				state varchar(20) NOT NULL,
				created_at bigint(20) unsigned NOT NULL,
				updated_at bigint(20) unsigned NOT NULL,
				expected_hash char(64) NOT NULL DEFAULT '',
				expected_mime varchar(80) NOT NULL DEFAULT '',
				expected_filename varchar(160) NOT NULL DEFAULT '',
				expected_title varchar(160) NOT NULL DEFAULT '',
				expected_alt varchar(500) NOT NULL DEFAULT '',
				attachment_id bigint(20) unsigned NOT NULL DEFAULT 0,
				result_json longtext NULL,
				error_code varchar(100) NOT NULL DEFAULT '',
				PRIMARY KEY  (request_key),
				KEY actor_created (site_id,actor_id,created_at),
				KEY state_updated (state,updated_at)
			) ENGINE=InnoDB {$collate};" );
		unset( self::$ready[ $table ] );
	}

	public static function validate(): bool {
		global $wpdb;
		$table = self::table();
		$status = $wpdb->get_row( $wpdb->prepare( 'SHOW TABLE STATUS WHERE Name = %s', $table ), ARRAY_A );
		$index = $wpdb->get_row( $wpdb->prepare(
			'SHOW INDEX FROM ' . $table . ' WHERE Key_name = %s AND Non_unique = 0',
			'PRIMARY'
		), ARRAY_A );
		$recent_index = $wpdb->get_row( $wpdb->prepare(
			'SHOW INDEX FROM ' . $table . ' WHERE Key_name = %s',
			'actor_created'
		), ARRAY_A );
		$state_index = $wpdb->get_row( $wpdb->prepare(
			'SHOW INDEX FROM ' . $table . ' WHERE Key_name = %s',
			'state_updated'
		), ARRAY_A );
		$columns = $wpdb->get_col( 'SHOW COLUMNS FROM ' . $table, 0 );
		return is_array( $status ) &&
			0 === strcasecmp( (string) ( $status['Engine'] ?? '' ), 'InnoDB' ) &&
			is_array( $index ) && is_array( $recent_index ) && is_array( $state_index ) &&
			is_array( $columns ) && ! array_diff( self::REQUIRED_COLUMNS, $columns );
	}

	public static function ready(): bool {
		$table = self::table();
		if ( ! array_key_exists( $table, self::$ready ) ) {
			self::$ready[ $table ] = self::SCHEMA_VERSION === (int) get_option( self::version_option(), 0 ) &&
				self::validate();
		}
		return self::$ready[ $table ];
	}

	/** Operational summary without exposing request payloads or actor identities. */
	public static function diagnostics(): array {
		if ( ! self::ready() ) {
			return array( 'status' => 'unavailable', 'schemaVersion' => (int) get_option( self::version_option(), 0 ) );
		}
		global $wpdb;
		$table = self::table();
		$status = $wpdb->get_row( $wpdb->prepare( 'SHOW TABLE STATUS WHERE Name = %s', $table ), ARRAY_A );
		$cutoff = time() - 30 * DAY_IN_SECONDS;
		$unresolved = $wpdb->get_var( $wpdb->prepare(
			'SELECT COUNT(*) FROM ' . $table . ' WHERE state IN (%s, %s) AND updated_at >= %d',
			'running', 'recovering', $cutoff
		) );
		$stale = $wpdb->get_var( $wpdb->prepare(
			'SELECT COUNT(*) FROM ' . $table . ' WHERE state IN (%s, %s) AND updated_at < %d',
			'running', 'recovering', $cutoff
		) );
		$failed = $wpdb->get_var( $wpdb->prepare(
			'SELECT COUNT(*) FROM ' . $table . ' WHERE state = %s AND updated_at >= %d',
			'failed', $cutoff
		) );
		return array(
			'status' => is_array( $status ) && null !== $unresolved && null !== $stale && null !== $failed ? 'ready' : 'unavailable',
			'schemaVersion' => (int) get_option( self::version_option(), 0 ),
			'estimatedTotal' => (int) ( $status['Rows'] ?? 0 ),
			'recentUnresolved' => (int) $unresolved,
			'staleUnresolved' => (int) $stale,
			'recentFailed' => (int) $failed,
		);
	}

	public static function site_health( array $info ): array {
		if ( ! current_user_can( 'manage_options' ) ) {
			return $info;
		}
		$values = array();
		foreach ( self::diagnostics() as $key => $value ) {
			$values[ $key ] = array( 'label' => $key, 'value' => (string) $value );
		}
		$info['wphave-ai-image-requests'] = array(
			'label' => 'WPHAVE AI image requests',
			'fields' => $values,
		);
		return $info;
	}

	public static function read( string $key ) {
		if ( ! self::ready() ) {
			return new WP_Error( 'wphave_mcp_image_store_unavailable', 'The image request store is unavailable.' );
		}
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM ' . self::table() . ' WHERE request_key = %s',
			$key
		), ARRAY_A );
		return is_array( $row ) ? self::decode( $row ) : null;
	}

	public static function claim( string $key, string $operation, string $hash ) {
		$existing = self::read( $key );
		if ( is_wp_error( $existing ) || null !== $existing ) {
			return $existing;
		}
		global $wpdb;
		$now = time();
		$inserted = $wpdb->insert( self::table(), array(
			'request_key' => $key,
			'site_id' => get_current_blog_id(),
			'actor_id' => get_current_user_id(),
			'operation' => $operation,
			'input_hash' => $hash,
			'state' => 'running',
			'created_at' => $now,
			'updated_at' => $now,
		) );
		$record = self::read( $key );
		if ( is_wp_error( $record ) || ! is_array( $record ) ) {
			return new WP_Error( 'wphave_mcp_image_store_unavailable', 'The image request claim could not be verified.' );
		}
		$record['new'] = 1 === $inserted;
		return $record;
	}

	public static function change( string $key, string $expected_state, array $fields ): bool {
		if ( ! self::ready() ) {
			return false;
		}
		global $wpdb;
		$fields['updated_at'] = time();
		return 1 === $wpdb->update(
			self::table(),
			$fields,
			array( 'request_key' => $key, 'state' => $expected_state )
		);
	}

	private static function decode( array $row ): array {
		$result = is_string( $row['result_json'] ?? null ) ? json_decode( $row['result_json'], true ) : null;
		return array(
			'operation' => (string) $row['operation'],
			'hash' => (string) $row['input_hash'],
			'state' => (string) $row['state'],
			'created' => (int) $row['created_at'],
			'actorId' => (int) $row['actor_id'],
			'siteId' => (int) $row['site_id'],
			'result' => is_array( $result ) ? $result : null,
			'error' => (string) $row['error_code'],
			'attachmentId' => (int) $row['attachment_id'],
			'expectedHash' => (string) $row['expected_hash'],
			'expectedMime' => (string) $row['expected_mime'],
			'expectedFilename' => (string) $row['expected_filename'],
			'expectedTitle' => (string) $row['expected_title'],
			'expectedAlt' => (string) $row['expected_alt'],
		);
	}
}

add_filter( 'debug_information', array( WPHAVE_AI_MCP_Media_Request_Store::class, 'site_health' ) );
