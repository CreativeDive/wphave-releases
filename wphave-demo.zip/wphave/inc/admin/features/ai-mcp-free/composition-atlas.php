<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Read-only summary of the native design language in bundled site compositions. */
final class WPHAVE_AI_MCP_Free_Composition_Atlas {
	public static function collect( array $supported_paths, ?string $only_id = null ): array {
		$root = dirname( __DIR__ ) . '/site-compositions/compositions';
		$directories = glob( $root . '/*', GLOB_ONLYDIR );
		if ( ! is_array( $directories ) ) {
			return array();
		}
		$atlas = array();
		foreach ( $directories as $directory ) {
			$id = basename( $directory );
			if ( null !== $only_id && $only_id !== $id ) {
				continue;
			}
			if ( ! preg_match( '/^[a-z0-9-]+$/', $id ) || ! is_file( $directory . '/composition.json' ) ) {
				continue;
			}
			$manifest = json_decode( (string) file_get_contents( $directory . '/composition.json' ), true );
			$files = glob( $directory . '/pages/*.html' ) ?: array();
			foreach ( array( 'header.html', 'footer.html' ) as $shell ) {
				if ( is_file( $directory . '/' . $shell ) ) {
					$files[] = $directory . '/' . $shell;
				}
			}
			$blocks = array();
			$layouts = array();
			$paths = array();
			$sections = array();
			foreach ( $files as $file ) {
				if ( filesize( $file ) > 1048576 ) {
					continue;
				}
				$parsed = parse_blocks( (string) file_get_contents( $file ) );
				self::count_blocks( $parsed, $blocks, $layouts, $paths );
				if ( str_contains( $file, '/pages/' ) ) {
					self::count_sections( $parsed, $sections );
				}
			}
			arsort( $blocks );
			arsort( $layouts );
			arsort( $paths );
			$usable = array();
			$other = array();
			foreach ( $paths as $path => $count ) {
				if ( in_array( $path, $supported_paths, true ) ) {
					$usable[ $path ] = $count;
				} elseif ( null !== $only_id || count( $other ) < 12 ) {
					$other[ $path ] = $count;
				}
			}
			$atlas[] = array(
				'id' => $id,
				'title' => sanitize_text_field( $manifest['title'] ?? $id ),
				'description' => sanitize_text_field( $manifest['manifest']['description'] ?? '' ),
				'fileCount' => count( $files ),
				'blockTypes' => null === $only_id ? array_slice( $blocks, 0, 10, true ) : $blocks,
				'layouts' => $layouts,
				'sectionPatterns' => array_slice( array_values( $sections ), 0, null === $only_id ? 6 : 18 ),
				'availableMcpPathsUsed' => null === $only_id ? array_slice( $usable, 0, 12, true ) : $usable,
				'otherNativePathsUsed' => $other,
			);
		}
		return $atlas;
	}

	private static function count_sections( array $nodes, array &$sections ): void {
		foreach ( $nodes as $node ) {
			if ( 'wphave/group' !== ( $node['blockName'] ?? null ) ) {
				continue;
			}
			$children = $node['innerBlocks'] ?? array();
			$types = array();
			foreach ( $children as $child ) {
				$name = $child['blockName'] ?? null;
				if ( is_string( $name ) && str_starts_with( $name, 'wphave/' ) ) {
					$types[] = substr( $name, 7 );
				}
			}
			if ( array() === $types ) {
				continue;
			}
			$pattern = array(
				'layout' => $node['attrs']['wphave']['layout']['type'] ?? 'stacked',
				'children' => array_slice( $types, 0, 10 ),
			);
			$key = wp_json_encode( $pattern );
			if ( is_string( $key ) && ! isset( $sections[ $key ] ) ) {
				$sections[ $key ] = $pattern;
			}
		}
	}

	private static function count_blocks( array $nodes, array &$blocks, array &$layouts, array &$paths ): void {
		foreach ( $nodes as $node ) {
			$name = $node['blockName'] ?? null;
			if ( is_string( $name ) && str_starts_with( $name, 'wphave/' ) ) {
				$blocks[ $name ] = ( $blocks[ $name ] ?? 0 ) + 1;
			}
			$design = $node['attrs']['wphave'] ?? array();
			if ( is_array( $design ) ) {
				$type = $design['layout']['type'] ?? null;
				if ( is_string( $type ) ) {
					$layouts[ $type ] = ( $layouts[ $type ] ?? 0 ) + 1;
				}
				self::count_paths( $design, '', $paths );
			}
			self::count_blocks( $node['innerBlocks'] ?? array(), $blocks, $layouts, $paths );
		}
	}

	private static function count_paths( array $value, string $prefix, array &$paths ): void {
		foreach ( $value as $key => $child ) {
			if ( ! is_string( $key ) || in_array( $key, array( 'styles', 'stylesLayout', 'stylesChild', 'classNames', 'stylesBackgrounds', 'classNamesBackground' ), true ) ) {
				continue;
			}
			$path = '' === $prefix ? $key : $prefix . '.' . $key;
			if ( is_array( $child ) && ! array_is_list( $child ) ) {
				self::count_paths( $child, $path, $paths );
			} elseif ( ! is_array( $child ) ) {
				$normalized = preg_replace( '/^(mobile|tablet)\./', '', $path );
				if ( 'text.typeface.size.type' === $normalized ) {
					$normalized = 'text.typeface.size';
				}
				$paths[ $normalized ] = ( $paths[ $normalized ] ?? 0 ) + 1;
			}
		}
	}
}
