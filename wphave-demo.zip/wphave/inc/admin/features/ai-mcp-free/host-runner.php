<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/custom-css.php';

/** Runs pinned local Node hosts with bounded input, output and execution time. */
final class WPHAVE_AI_MCP_Free_Host_Runner {
	private static function node_binary(): ?string {
		if ( defined( 'WPHAVE_MCP_NODE_BINARY' ) ) {
			$binary = WPHAVE_MCP_NODE_BINARY;
			return is_string( $binary ) && is_executable( $binary ) ? $binary : null;
		}
		foreach ( array( '/opt/homebrew/bin/node', '/usr/local/bin/node', '/usr/bin/node' ) as $binary ) {
			if ( is_executable( $binary ) ) {
				return $binary;
			}
		}
		return null;
	}

	public static function render( array $nodes, array $host_context, array $resolved_links = array() ) {
		$input = array(
			'context' => $host_context['context'] ?? null,
			'fingerprint' => $host_context['fingerprint'] ?? null,
			'nodes' => $nodes,
		);
		if ( $resolved_links ) {
			$input['resolvedLinks'] = $resolved_links;
		}
		$result = self::execute_json( $host_context['runner'] ?? null, $input, 65536, 150000, 5 );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		if ( array_keys( $result ) !== array( 'markup' ) ||
			! is_string( $result['markup'] ) || '' === $result['markup'] ||
			strlen( $result['markup'] ) > 120000 ) {
			return new WP_Error( 'wphave_mcp_host_rejected', 'The native design host returned an invalid page.' );
		}
		$has_css = array_filter( $nodes, static function ( $node ): bool {
			return is_array( $node ) && array_key_exists( 'css', $node );
		} );
		return $has_css ? WPHAVE_AI_MCP_Free_Custom_CSS::apply_markup( $result['markup'], $nodes ) : $result['markup'];
	}

	/** Execute only a trusted built script; callers pin its path and validate its schema. */
	public static function execute_json( $runner, array $input, int $max_input, int $max_output, int $seconds ) {
		$binary = self::node_binary();
		$payload = wp_json_encode( $input );
		if ( null === $binary || ! function_exists( 'proc_open' ) ||
			! is_string( $runner ) || ! is_readable( $runner ) ||
			! is_string( $payload ) || strlen( $payload ) > $max_input ) {
			return new WP_Error( 'wphave_mcp_host_unavailable', 'The local design host is unavailable.' );
		}
		$process = proc_open(
			array( $binary, $runner ),
			array(
				0 => array( 'pipe', 'r' ),
				1 => array( 'pipe', 'w' ),
				2 => array( 'pipe', 'w' ),
			),
			$pipes,
			null,
			array( 'NODE_ENV' => 'production', 'PATH' => getenv( 'PATH' ) ?: '' ),
			array( 'bypass_shell' => true )
		);
		if ( ! is_resource( $process ) ) {
			return new WP_Error( 'wphave_mcp_host_unavailable', 'The local design host is unavailable.' );
		}
		$written = 0;
		while ( $written < strlen( $payload ) ) {
			$step = fwrite( $pipes[0], substr( $payload, $written ) );
			if ( false === $step || 0 === $step ) {
				break;
			}
			$written += $step;
		}
		fclose( $pipes[0] );
		stream_set_blocking( $pipes[1], false );
		stream_set_blocking( $pipes[2], false );
		$output = '';
		$error = '';
		$deadline = microtime( true ) + $seconds;
		$exit_code = null;
		while ( microtime( true ) < $deadline ) {
			$output .= stream_get_contents( $pipes[1] );
			$error .= stream_get_contents( $pipes[2] );
			if ( strlen( $output ) > $max_output || strlen( $error ) > 4096 ) {
				break;
			}
			$status = proc_get_status( $process );
			if ( ! $status['running'] ) {
				$exit_code = $status['exitcode'];
				$output .= stream_get_contents( $pipes[1] );
				$error .= stream_get_contents( $pipes[2] );
				break;
			}
			usleep( 10000 );
		}
		if ( null === $exit_code ) {
			proc_terminate( $process );
		}
		fclose( $pipes[1] );
		fclose( $pipes[2] );
		proc_close( $process );
		if ( $written !== strlen( $payload ) || 0 !== $exit_code || '' !== $error ||
			strlen( $output ) > $max_output ) {
			return new WP_Error( 'wphave_mcp_host_rejected', 'The local design host rejected the request.' );
		}
		$result = json_decode( $output, true );
		return is_array( $result ) ?
			$result :
			new WP_Error( 'wphave_mcp_host_rejected', 'The local design host returned invalid data.' );
	}
}
