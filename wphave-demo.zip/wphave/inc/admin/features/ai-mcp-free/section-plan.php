<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/creation-config.php';
require_once __DIR__ . '/section-catalog.php';

/** Binds semantic page sections to the native root Group layout decision. */
final class WPHAVE_AI_MCP_Free_Section_Plan {
	public static function valid( array $batch, ?array $config = null ): bool {
		$config = $config ?? WPHAVE_AI_MCP_Free_Creation_Config::get();
		if ( null === $config ) {
			return false;
		}
		if ( ! array_key_exists( 'sections', $batch ) ) {
			foreach ( $batch['nodes'] ?? array() as $node ) {
				if ( 'wphave/spacer' === ( $node['name'] ?? null ) && null === ( $node['parentKey'] ?? null ) ) {
					return false;
				}
			}
			return 'required' !== $config['catalog']['mode'];
		}
		$sections = $batch['sections'];
		if ( 2 !== ( $batch['version'] ?? null ) || ! is_array( $sections ) ||
			count( $sections ) < 1 || count( $sections ) > 8 ||
			array_keys( $sections ) !== range( 0, count( $sections ) - 1 ) ) {
			return false;
		}
		$all_roots = array_values( array_filter( $batch['nodes'] ?? array(), static function ( $node ): bool {
			return is_array( $node ) && null === ( $node['parentKey'] ?? null );
		} ) );
		$roots = array_values( array_filter( $all_roots, static function ( $node ): bool {
			return 'wphave/spacer' !== ( $node['name'] ?? null );
		} ) );
		if ( count( $roots ) !== count( $sections ) ) {
			return false;
		}
		foreach ( $all_roots as $index => $root ) {
			if ( 'wphave/spacer' === ( $root['name'] ?? null ) &&
				( 0 === $index || count( $all_roots ) - 1 === $index ||
				'wphave/group' !== ( $all_roots[ $index - 1 ]['name'] ?? null ) ||
				'wphave/group' !== ( $all_roots[ $index + 1 ]['name'] ?? null ) ) ) {
				return false;
			}
		}
		foreach ( $sections as $index => $section ) {
			$root = $roots[ $index ];
			$typed = is_array( $section ) && array_key_exists( 'type', $section );
			if ( ! is_array( $section ) ||
				! in_array( count( $section ), array( 3, 5 ), true ) ||
				array_diff( array_keys( $section ), array( 'key', 'layout', 'purpose', 'type', 'variant' ) ) ||
				( $typed !== array_key_exists( 'variant', $section ) ) ||
				( 5 === count( $section ) ) !== $typed ||
				! is_string( $section['key'] ) ||
				! is_string( $section['layout'] ) ||
				! is_string( $section['purpose'] ) ||
				'' === trim( $section['purpose'] ) ||
				mb_strlen( $section['purpose'] ) > 160 ||
				$section['purpose'] !== sanitize_text_field( $section['purpose'] ) ||
				'wphave/group' !== ( $root['name'] ?? null ) ||
				$section['key'] !== ( $root['key'] ?? null ) ||
				! in_array( $section['layout'], array( 'stacked', 'grid', 'flex' ), true ) ||
				( $root['design'][0] ?? null ) !== array(
					'device' => 'Desktop',
					'path' => 'layout.type',
					'value' => $section['layout'],
				) ) {
				return false;
			}
			if ( $typed && ( 'off' === $config['catalog']['mode'] ||
				! WPHAVE_AI_MCP_Free_Section_Catalog::valid( $section, $root, $batch['nodes'] ) ) ) {
				return false;
			}
			if ( ! $typed && 'required' === $config['catalog']['mode'] ) {
				return false;
			}
		}
		return true;
	}
}
