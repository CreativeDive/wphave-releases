<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/design-grammar.php';
require_once __DIR__ . '/composition-atlas.php';
require_once __DIR__ . '/section-plan.php';
require_once __DIR__ . '/section-catalog.php';
require_once __DIR__ . '/button-recipes.php';
require_once __DIR__ . '/line-recipes.php';
require_once __DIR__ . '/spacer-recipes.php';
require_once __DIR__ . '/heading-recipes.php';
require_once __DIR__ . '/creation-config.php';
require_once __DIR__ . '/creation-workflow.php';
require_once __DIR__ . '/contrast.php';
require_once __DIR__ . '/media.php';
require_once __DIR__ . '/job-store.php';
require_once __DIR__ . '/site-project-store.php';
require_once __DIR__ . '/site-shell-proposal.php';
require_once __DIR__ . '/site-shell-activation.php';
require_once __DIR__ . '/abilities.php';
require_once dirname( __DIR__ ) . '/ai/task-catalog.php';
require_once __DIR__ . '/empty-draft-abilities.php';
require_once __DIR__ . '/worker-routes.php';
require_once dirname( __DIR__ ) . '/ai-mcp/server-factory.php';

add_action( 'wp_abilities_api_categories_init', array( 'WPHAVE_AI_MCP_Free_Abilities', 'register_category' ) );
add_action( 'wp_abilities_api_init', array( 'WPHAVE_AI_MCP_Free_Abilities', 'register' ) );
add_action( 'wp_abilities_api_init', array( 'WPHAVE_AI_MCP_Free_Empty_Draft_Abilities', 'register' ) );
add_action( 'rest_api_init', array( 'WPHAVE_AI_MCP_Free_Worker_Routes', 'register' ) );
add_action( 'mcp_adapter_init', static function ( $adapter ): void {
	wphave_ai_mcp_register_server(
		$adapter,
		'wphave-free-design-server',
		'WPHAVE Private Free Design',
		WPHAVE_AI_MCP_Exposure_Contract::server_abilities(
			'wphave-free-design-server',
			wphave_mcp_free_create_feature_enabled()
		)
	);
} );
