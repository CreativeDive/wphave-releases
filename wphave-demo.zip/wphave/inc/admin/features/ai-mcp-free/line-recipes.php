<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Bounded solid Line presentations backed by native block settings. */
final class WPHAVE_AI_MCP_Free_Line_Recipes {
	public static function specification(): ?array {
		$path = __DIR__ . '/line-recipes.json';
		$spec = is_readable( $path ) ? json_decode( (string) file_get_contents( $path ), true ) : null;
		return is_array( $spec ) && 1 === ( $spec['version'] ?? null ) ? $spec : null;
	}

	public static function colors(): ?array {
		$globals = WPHAVE_Global_Data::get_base();
		$colors = $globals['colors'] ?? null;
		if ( ! is_array( $colors ) ) {
			return null;
		}
		$values = array();
		foreach ( array_keys( $colors ) as $key ) {
			if ( ! is_string( $key ) || ! preg_match( '/^[A-Za-z0-9-]+$/', $key ) ) {
				return null;
			}
			$values[] = 'var(--wphave-site-color-' . $key . ')';
		}
		return $values;
	}

	public static function options(): ?array {
		$spec = self::specification();
		$colors = self::colors();
		return null === $spec || null === $colors ? null : array(
			'sizes' => $spec['sizes'],
			'colors' => $colors,
			'colorOptional' => true,
		);
	}

	public static function valid( $recipe ): bool {
		$spec = self::specification();
		$colors = self::colors();
		if ( null === $spec || null === $colors || ! is_array( $recipe ) ) {
			return false;
		}
		$keys = array_keys( $recipe );
		$expected = array_key_exists( 'color', $recipe ) ? array( 'size', 'color' ) : array( 'size' );
		sort( $keys );
		sort( $expected );
		return $keys === $expected &&
			is_string( $recipe['size'] ) && isset( $spec['sizes'][ $recipe['size'] ] ) &&
			( ! array_key_exists( 'color', $recipe ) || ( is_string( $recipe['color'] ) && in_array( $recipe['color'], $colors, true ) ) );
	}

	public static function expected_attributes( array $recipe ): ?array {
		if ( ! self::valid( $recipe ) ) {
			return null;
		}
		$size = self::specification()['sizes'][ $recipe['size'] ];
		$color = $recipe['color'] ?? null;
		return array( 'wphave' => array(
			'settings' => array(
				'style' => 'solid',
				'size' => $size,
				...( $color ? array( 'colors' => array( 'line' => $color ) ) : array() ),
			),
			'styles' => '--line-size: ' . $size . ( $color ? ';--line-color: ' . $color : '' ),
		) );
	}
}
