<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** One Pro-only native image overlap, expressed through existing design paths. */
final class WPHAVE_AI_MCP_Overlap_Recipe {
	public static function allowed(): bool {
		return function_exists( 'wphave_has_pro_access' ) && wphave_has_pro_access();
	}

	public static function operations(): array {
		return array(
			array( 'device' => 'Desktop', 'path' => 'dimensions.width.custom', 'value' => '40%' ),
			array( 'device' => 'Desktop', 'path' => 'dimensions.position.type', 'value' => 'relative' ),
			array( 'device' => 'Desktop', 'path' => 'dimensions.transform.translate', 'value' => array( 'x' => '0%', 'y' => '-25%' ) ),
			array( 'device' => 'Desktop', 'path' => 'dimensions.stackLevel.level', 'value' => 2 ),
			array( 'device' => 'Mobile', 'path' => 'dimensions.width.custom', 'value' => '100%' ),
			array( 'device' => 'Mobile', 'path' => 'dimensions.position.type', 'value' => 'static' ),
			array( 'device' => 'Mobile', 'path' => 'dimensions.transform.translate', 'value' => array( 'x' => '0%', 'y' => '0%' ) ),
			array( 'device' => 'Mobile', 'path' => 'dimensions.stackLevel.level', 'value' => 0 ),
		);
	}

	public static function matches_operations( array $operations ): bool {
		return self::allowed() && $operations === self::operations();
	}

	/** Exact native serializer output; keeps PHP verification independent of the host. */
	public static function expected_attributes(): array {
		return array(
			'dimensions' => array(
				'width' => array( 'custom' => '40%' ),
				'position' => array( 'type' => 'relative' ),
				'transform' => array( 'translate' => array( 'x' => '0%', 'y' => '-25%' ) ),
				'stackLevel' => array( 'level' => 2 ),
			),
			'mobile' => array( 'dimensions' => array(
				'width' => array( 'custom' => '100%' ),
				'position' => array( 'type' => 'static' ),
				'transform' => array( 'translate' => array( 'x' => '0%', 'y' => '0%' ) ),
				'stackLevel' => array( 'level' => 0 ),
			) ),
			'styles' => '--wi: 40%;--skl: 2;--pos-translate: none;--pos: relative;--tfm-tlx: 0%;--tfm-tly: -25%;--wi-m: 100%;--skl-m: 0;--pos-translate-m: none;--pos-m: static;--tfm-m-tlx: 0%;--tfm-m-tly: 0%;--object-position: center',
			'classNames' => 'wi skl pos tfm wi-m skl-m pos-m tfm-m',
		);
	}

	/** The recipe is confined to two direct Images in one stacked Group. */
	public static function valid_structure( array $nodes ): bool {
		$groups = array();
		$children = array();
		$recipes = array();
		foreach ( $nodes as $node ) {
			$key = $node['key'] ?? null;
			$parent = $node['parentKey'] ?? null;
			if ( 'wphave/group' === ( $node['name'] ?? null ) ) {
				$groups[ $key ] = $node;
			}
			if ( null !== $parent ) {
				$children[ $parent ][] = $node;
			}
			if ( 'wphave/image' === ( $node['name'] ?? null ) &&
				( $node['design'] ?? null ) === self::operations() ) {
				$recipes[] = $node;
			}
		}
		if ( count( $recipes ) > 1 || ( $recipes && ! self::allowed() ) ) {
			return false;
		}
		foreach ( $recipes as $recipe ) {
			$parent = $recipe['parentKey'];
			$siblings = $children[ $parent ] ?? array();
			if ( ! isset( $groups[ $parent ] ) ||
				( $groups[ $parent ]['design'][0] ?? null ) !== array( 'device' => 'Desktop', 'path' => 'layout.type', 'value' => 'stacked' ) ||
				2 !== count( $siblings ) ||
				'wphave/image' !== ( $siblings[0]['name'] ?? null ) ||
				( $siblings[1]['key'] ?? null ) !== $recipe['key'] ) {
				return false;
			}
		}
		return true;
	}
}
