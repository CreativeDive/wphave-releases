<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Deterministic, signed sitewide rules; visual review claims remain descriptive. */
final class WPHAVE_AI_MCP_Free_Site_Design_Contract {
	private const PRINCIPLES = array(
		'editorial-image-text',
		'alternating-section-rhythm',
		'responsive-offer-grid',
		'immersive-opening-and-cta',
	);

	private static function exact_keys( array $value, array $expected ): bool {
		$keys = array_keys( $value );
		sort( $keys );
		sort( $expected );
		return $keys === $expected;
	}

	private static function unique_strings( array $values, int $minimum, int $maximum ): bool {
		if ( count( $values ) < $minimum || count( $values ) > $maximum ||
			array_keys( $values ) !== range( 0, count( $values ) - 1 ) ) {
			return false;
		}
		foreach ( $values as $value ) {
			if ( ! is_string( $value ) ) {
				return false;
			}
		}
		return count( array_unique( $values ) ) === count( $values );
	}

	public static function same( array $first, array $second ): bool {
		return wp_json_encode( self::canonical( $first ) ) ===
			wp_json_encode( self::canonical( $second ) );
	}

	private static function canonical( array $value ): array {
		if ( ! array_is_list( $value ) ) {
			ksort( $value );
		}
		foreach ( $value as &$item ) {
			if ( is_array( $item ) ) {
				$item = self::canonical( $item );
			}
		}
		unset( $item );
		return $value;
	}

	public static function valid( $contract, array $page_keys ): bool {
		$identity = WPHAVE_AI_MCP_Free_Site_Design_Identity::snapshot();
		$catalog = WPHAVE_AI_MCP_Free_Design_Grammar::catalog();
		if ( is_wp_error( $identity ) || is_wp_error( $catalog ) ||
			! is_array( $contract ) ||
			! self::exact_keys( $contract, array( 'version', 'siteDesignFingerprint', 'colorRoles', 'headingSizes', 'button', 'mainHeadings', 'reviewClaims' ) ) ||
			1 !== $contract['version'] ||
			! is_string( $contract['siteDesignFingerprint'] ) ||
			! hash_equals( $identity['fingerprint'], $contract['siteDesignFingerprint'] ) ||
			! is_array( $contract['colorRoles'] ) ||
			! is_array( $contract['headingSizes'] ) ||
			! is_array( $contract['button'] ) ||
			! is_array( $contract['mainHeadings'] ) ||
			! is_array( $contract['reviewClaims'] ) ) {
			return false;
		}

		$known_roles = array_keys( $identity['identity']['colors'] );
		if ( ! self::unique_strings( $contract['colorRoles'], 2, 8 ) ||
			array_diff( $contract['colorRoles'], $known_roles ) ) {
			return false;
		}
		$known_sizes = $identity['identity']['typography']['headingSizes'];
		if ( ! self::unique_strings( $contract['headingSizes'], 1, 8 ) ||
			array_diff( $contract['headingSizes'], $known_sizes ) ) {
			return false;
		}
		if ( ! self::exact_keys( $contract['button'], array( 'kind', 'size', 'variant' ) ) ||
			! WPHAVE_AI_MCP_Free_Button_Recipes::valid( $contract['button'] ) ) {
			return false;
		}
		if ( count( $contract['mainHeadings'] ) !== count( $page_keys ) ||
			array_keys( $contract['mainHeadings'] ) !== $page_keys ) {
			return false;
		}
		foreach ( $contract['mainHeadings'] as $key ) {
			if ( ! is_string( $key ) || ! preg_match( '/^[a-z][a-z0-9_-]{0,31}$/D', $key ) ) {
				return false;
			}
		}
		if ( ! self::exact_keys( $contract['reviewClaims'], array( 'layoutPrinciples', 'responsiveReadingOrder' ) ) ||
			! is_array( $contract['reviewClaims']['layoutPrinciples'] ) ||
			! self::unique_strings( $contract['reviewClaims']['layoutPrinciples'], 1, 4 ) ||
			array_diff( $contract['reviewClaims']['layoutPrinciples'], self::PRINCIPLES ) ||
			! is_string( $contract['reviewClaims']['responsiveReadingOrder'] ) ||
			mb_strlen( trim( $contract['reviewClaims']['responsiveReadingOrder'] ) ) < 12 ||
			mb_strlen( $contract['reviewClaims']['responsiveReadingOrder'] ) > 240 ||
			sanitize_text_field( $contract['reviewClaims']['responsiveReadingOrder'] ) !== $contract['reviewClaims']['responsiveReadingOrder'] ) {
			return false;
		}
		return true;
	}

	public static function matches_pages( array $contract, array $pages ): bool {
		$page_keys = array_column( $pages, 'pageKey' );
		if ( ! self::valid( $contract, $page_keys ) ) {
			return false;
		}
		foreach ( $pages as $page ) {
			$main_key = $contract['mainHeadings'][ $page['pageKey'] ];
			$main_count = 0;
			foreach ( $page['batch']['nodes'] ?? array() as $node ) {
				if ( 'wphave/heading' === ( $node['name'] ?? null ) ) {
					$level = $node['heading']['level'] ?? 'h2';
					if ( 'h1' === $level ) {
						++$main_count;
						if ( $node['key'] !== $main_key ) {
							return false;
						}
					}
					if ( $node['key'] === $main_key && 'h1' !== $level ) {
						return false;
					}
				}
				if ( 'wphave/button' === ( $node['name'] ?? null ) &&
					( $node['button'] ?? null ) !== $contract['button'] ) {
					return false;
				}
				foreach ( $node['design'] ?? array() as $operation ) {
					if ( in_array( $operation['path'] ?? null, array( 'colors.text', 'background.color.base' ), true ) ) {
						$role = self::role_from_token( $operation['value'] ?? null );
						if ( null === $role || ! in_array( $role, $contract['colorRoles'], true ) ) {
							return false;
						}
					}
					if ( 'wphave/heading' === ( $node['name'] ?? null ) &&
						'text.typeface.size' === ( $operation['path'] ?? null ) &&
						! in_array( $operation['value']['type'] ?? null, $contract['headingSizes'], true ) ) {
						return false;
					}
				}
			}
			if ( 1 !== $main_count ) {
				return false;
			}
		}
		return true;
	}

	/** Shell nodes share the page contract's current color roles. */
	public static function matches_shell_colors( array $contract, array $nodes ): bool {
		foreach ( $nodes as $node ) {
			foreach ( $node['design'] ?? array() as $operation ) {
				if ( ! in_array( $operation['path'] ?? null, array( 'colors.text', 'background.color.base' ), true ) ) {
					continue;
				}
				$role = self::role_from_token( $operation['value'] ?? null );
				if ( null === $role || ! in_array( $role, $contract['colorRoles'] ?? array(), true ) ) {
					return false;
				}
			}
		}
		return true;
	}

	private static function role_from_token( $token ): ?string {
		if ( ! is_string( $token ) ||
			! preg_match( '/^var\(--wphave-site-color-([A-Za-z][A-Za-z0-9]*)\)$/D', $token, $matches ) ) {
			return null;
		}
		return $matches[1];
	}
}
