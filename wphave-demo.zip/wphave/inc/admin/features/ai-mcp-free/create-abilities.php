<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/draft-qualification.php';
require_once dirname( __DIR__ ) . '/ai-mcp-write/create-service.php';

/** Creates one native draft from a fully qualified private design job. */
final class WPHAVE_AI_MCP_Free_Create_Abilities {
	public static function register_category(): void {
		if ( self::available() && function_exists( 'wp_register_ability_category' ) ) {
			wp_register_ability_category( 'wphave-free-create', array(
				'label' => __( 'WPHAVE Free Draft Creation', 'wphave' ),
				'description' => __( 'Create a native draft from a qualified private design job.', 'wphave' ),
			) );
		}
	}

	public static function register(): void {
		if ( ! self::available() || ! function_exists( 'wp_register_ability' ) ) {
			return;
		}
		$config = WPHAVE_AI_MCP_Free_Creation_Config::get();
		$workflow_required = true === ( $config['workflow']['required'] ?? false );
		wp_register_ability( 'wphave/free-page-create-draft', array(
			'category' => 'wphave-free-create',
			'label' => __( 'Create native WPHAVE draft', 'wphave' ),
			'description' => __( 'Create one unpublished draft from a server-qualified design job.', 'wphave' ),
			'input_schema' => array(
				'type' => 'object',
				'properties' => array(
					'jobId' => array( 'type' => 'string' ),
					'requestId' => array( 'type' => 'string' ),
					'expectedResultHash' => array( 'type' => 'string' ),
				),
				'required' => array( 'jobId', 'requestId' ),
				'additionalProperties' => false,
			),
			'permission_callback' => array( __CLASS__, 'can_create' ),
			'execute_callback' => array( __CLASS__, 'create' ),
			'meta' => array(
				'public' => false,
				'show_in_rest' => false,
				'mcp' => array( 'public' => true ),
				'annotations' => array( 'readonly' => false, 'destructive' => false, 'idempotent' => true ),
			),
		) );
		wp_register_ability( WPHAVE_AI_Task_Catalog::mcp_ability_id( 'page.create_free' ), array(
			'category' => 'wphave-free-create',
			'label' => __( 'Create complete native WPHAVE draft', 'wphave' ),
			'description' => __( 'Step 4: Save one complete native draft after plan-content, design-options and plan-layout. Use pageKey "page" in the planning calls and pass their layoutToken. The batch sections must match the section plan.', 'wphave' ),
			'input_schema' => array(
				'type' => 'object',
				'properties' => array(
					'requestId' => array( 'type' => 'string' ),
					'title' => array( 'type' => 'string' ),
					'batch' => array( 'type' => 'object' ),
					'layoutToken' => array( 'type' => 'string' ),
				),
				'required' => $workflow_required ?
					array( 'requestId', 'title', 'batch', 'layoutToken' ) :
					array( 'requestId', 'title', 'batch' ),
				'additionalProperties' => false,
			),
			'permission_callback' => array( __CLASS__, 'can_create' ),
			'execute_callback' => array( __CLASS__, 'create_complete' ),
			'meta' => array(
				'public' => false,
				'show_in_rest' => false,
				'mcp' => array( 'public' => true ),
				'annotations' => array( 'readonly' => false, 'destructive' => false, 'idempotent' => true ),
			),
		) );
		wp_register_ability( WPHAVE_AI_Task_Catalog::mcp_ability_id( 'website.create_free' ), array(
			'category' => 'wphave-free-create',
			'label' => __( 'Create native website drafts', 'wphave' ),
			'description' => __( 'Step 4: Create one to twelve private native website drafts after plan-content, design-options and plan-layout. Pass their layoutToken; page keys and sections must match. Include a home page and use designPlan version 2. Retries with the same request ID resume incomplete work.', 'wphave' ),
			'input_schema' => array(
				'type' => 'object',
				'properties' => array(
					'requestId' => array( 'type' => 'string' ),
					'brand' => array( 'type' => 'string' ),
					'description' => array( 'type' => 'string' ),
					'layoutToken' => array( 'type' => 'string' ),
					'designPlan' => array(
						'type' => 'object',
						'properties' => array(
						'version' => array( 'type' => 'integer', 'enum' => array( 1, 2 ) ),
							'direction' => array( 'type' => 'string' ),
							'audience' => array( 'type' => 'string' ),
							'pages' => array(
								'type' => 'array',
								'items' => array(
									'type' => 'object',
									'properties' => array(
										'pageKey' => array( 'type' => 'string' ),
										'purpose' => array( 'type' => 'string' ),
										'mediaIds' => array( 'type' => 'array', 'items' => array( 'type' => 'integer' ) ),
										'sections' => array(
											'type' => 'array',
											'items' => array(
												'type' => 'object',
												'properties' => array(
													'role' => array( 'type' => 'string' ),
													'groupKey' => array( 'type' => 'string' ),
													'layout' => array( 'type' => 'string', 'enum' => array( 'stacked', 'grid', 'flex' ) ),
													'type' => array( 'type' => 'string' ),
													'variant' => array( 'type' => 'string' ),
													'principle' => array( 'type' => 'string' ),
													'responsiveIntent' => array( 'type' => 'string' ),
												),
												'required' => array( 'role', 'principle', 'responsiveIntent' ),
												'additionalProperties' => false,
											),
										),
									),
									'required' => array( 'pageKey', 'purpose', 'mediaIds', 'sections' ),
									'additionalProperties' => false,
								),
							),
						),
						'required' => array( 'version', 'direction', 'audience', 'pages' ),
						'additionalProperties' => false,
					),
					'pages' => array(
						'type' => 'array',
						'minItems' => 1,
						'maxItems' => 12,
						'items' => array(
							'type' => 'object',
							'properties' => array(
								'pageKey' => array( 'type' => 'string' ),
								'title' => array( 'type' => 'string' ),
								'batch' => array(
									'type' => 'object',
									'properties' => array(
										'version' => array( 'type' => 'integer', 'enum' => array( 2 ) ),
										'designFingerprint' => array( 'type' => 'string' ),
										'sections' => array(
											'type' => 'array',
											'items' => array(
												'type' => 'object',
												'properties' => array(
													'key' => array( 'type' => 'string' ),
													'layout' => array( 'type' => 'string', 'enum' => array( 'stacked', 'grid', 'flex' ) ),
													'purpose' => array( 'type' => 'string' ),
													'type' => array( 'type' => 'string' ),
													'variant' => array( 'type' => 'string' ),
												),
												'required' => array( 'key', 'layout', 'purpose' ),
												'additionalProperties' => false,
											),
										),
										'nodes' => array( 'type' => 'array', 'items' => array( 'type' => 'object' ) ),
									),
									'required' => array( 'version', 'designFingerprint', 'nodes' ),
									'additionalProperties' => false,
								),
							),
							'required' => array( 'pageKey', 'title', 'batch' ),
							'additionalProperties' => false,
						),
					),
				),
				'required' => $workflow_required ?
					array( 'requestId', 'brand', 'description', 'pages', 'layoutToken' ) :
					array( 'requestId', 'brand', 'description', 'pages' ),
				'additionalProperties' => false,
			),
			'permission_callback' => array( __CLASS__, 'can_create' ),
			'execute_callback' => array( 'WPHAVE_AI_MCP_Free_Website_Draft_Project', 'create' ),
			'meta' => array(
				'public' => false,
				'show_in_rest' => false,
				'mcp' => array( 'public' => true ),
				'annotations' => array( 'readonly' => false, 'destructive' => false, 'idempotent' => true ),
			),
		) );
		wp_register_ability( 'wphave/website-drafts-status', array(
			'category' => 'wphave-free-create',
			'label' => __( 'Read native website draft project', 'wphave' ),
			'description' => __( 'Read private project page bindings and detect changed drafts.', 'wphave' ),
			'input_schema' => array(
				'type' => 'object',
				'properties' => array( 'projectId' => array( 'type' => 'string' ) ),
				'required' => array( 'projectId' ),
				'additionalProperties' => false,
			),
			'permission_callback' => array( __CLASS__, 'can_create' ),
			'execute_callback' => array( 'WPHAVE_AI_MCP_Free_Website_Draft_Project', 'status' ),
			'meta' => array(
				'public' => false,
				'show_in_rest' => false,
				'mcp' => array( 'public' => true ),
				'annotations' => array( 'readonly' => true, 'destructive' => false, 'idempotent' => true ),
			),
		) );
	}

	private static function available(): bool {
		return function_exists( 'wphave_mcp_free_create_feature_enabled' ) &&
			wphave_mcp_free_create_feature_enabled();
	}

	public static function can_create(): bool {
		return self::available() &&
			current_user_can( 'wphave_access' ) && current_user_can( 'edit_pages' ) &&
			function_exists( 'wphave_get_block_editor_mode_by_role' ) &&
			'design' === wphave_get_block_editor_mode_by_role();
	}

	private static function title_from_job( array $job ): string {
		$batch = json_decode( (string) $job['batch_json'], true );
		foreach ( $batch['nodes'] ?? array() as $node ) {
			if ( ( $node['name'] ?? null ) === 'wphave/heading' ) {
				$title = trim( sanitize_text_field( $node['attributes']['content'] ?? '' ) );
				if ( $title !== '' ) {
					return mb_substr( $title, 0, 120 );
				}
			}
		}
		return __( 'Untitled WPHAVE draft', 'wphave' );
	}

	public static function create( $input ) {
		if ( ! self::can_create() || ! is_array( $input ) ||
			array_diff( array_keys( $input ), array( 'jobId', 'requestId', 'expectedResultHash' ) ) ||
			! is_string( $input['jobId'] ?? null ) || ! is_string( $input['requestId'] ?? null ) ||
			( isset( $input['expectedResultHash'] ) && ! is_string( $input['expectedResultHash'] ) ) ) {
			return new WP_Error( 'wphave_mcp_free_create_invalid', 'The draft creation request is invalid.' );
		}
		$qualified = WPHAVE_AI_MCP_Free_Draft_Qualification::qualify_job_id( $input['jobId'] );
		if ( is_wp_error( $qualified ) ) {
			return $qualified;
		}
		$markup_hash = $qualified['qualification']['markupHash'];
		if ( isset( $input['expectedResultHash'] ) && ! hash_equals( $markup_hash, $input['expectedResultHash'] ) ) {
			return new WP_Error( 'wphave_mcp_free_create_conflict', 'The expected result fingerprint differs.' );
		}
		$plan = array(
			'title' => self::title_from_job( $qualified['job'] ),
			'content' => $qualified['result']['markup'],
		);
		$transaction_input = array(
			'requestId' => $input['requestId'],
			'jobId' => $input['jobId'],
			'resultHash' => $markup_hash,
			'sourceIdentity' => $input['jobId'],
		);
		$revalidate = static function () use ( $input, $markup_hash, $plan ) {
			if ( ! self::can_create() ) {
				return new WP_Error( 'wphave_mcp_free_create_forbidden', 'Draft creation is no longer permitted.' );
			}
			$fresh = WPHAVE_AI_MCP_Free_Draft_Qualification::qualify_job_id( $input['jobId'] );
			if ( is_wp_error( $fresh ) ) {
				return $fresh;
			}
			if ( ! hash_equals( $markup_hash, $fresh['qualification']['markupHash'] ) ||
				$fresh['result']['markup'] !== $plan['content'] ||
				self::title_from_job( $fresh['job'] ) !== $plan['title'] ) {
				return new WP_Error( 'wphave_mcp_free_create_stale', 'The qualified proposal changed before creation.' );
			}
			return true;
		};
		return WPHAVE_AI_MCP_Create_Service::create_validated_draft( $transaction_input, $plan, $revalidate );
	}

	/** One request yields a fully populated native draft or no new page. */
	public static function create_complete( $input ) {
		if ( ! self::can_create() ) {
			return new WP_Error(
				'wphave_mcp_complete_forbidden',
				'Direct draft creation is unavailable for this connection. Use the WPHAVE design MCP server with an account allowed to edit pages in design mode and enable direct creation in MCP Setup.',
				array( 'status' => 403 )
			);
		}
		if ( ! is_array( $input ) ||
			array_diff( array_keys( $input ), array( 'requestId', 'title', 'batch', 'layoutToken' ) ) ||
			! is_string( $input['requestId'] ?? null ) ||
			! preg_match( '/^[A-Za-z0-9_-]{16,80}$/', $input['requestId'] ) ||
			! is_string( $input['title'] ?? null ) ||
			! is_array( $input['batch'] ?? null ) ||
			( isset( $input['layoutToken'] ) && ! is_string( $input['layoutToken'] ) ) ) {
			return new WP_Error( 'wphave_mcp_complete_invalid', 'The complete page request is invalid.' );
		}
		$config = WPHAVE_AI_MCP_Free_Creation_Config::get();
		if ( null === $config || ( $config['workflow']['required'] &&
			! WPHAVE_AI_MCP_Free_Creation_Workflow::matches_drafts( $input['layoutToken'] ?? null, array(
				array( 'pageKey' => 'page', 'batch' => $input['batch'] ),
			) ) ) ) {
			return new WP_Error( 'wphave_mcp_workflow_invalid', 'Complete the content, design-options and section-layout planning steps before creation.' );
		}
		if ( ! WPHAVE_AI_MCP_Free_Job_Store::valid_standalone_batch( $input['batch'] ) ) {
			return WPHAVE_AI_MCP_Free_Job_Store::invalid_batch_error(
				$input['batch'],
				'wphave_mcp_complete_invalid',
				'The complete page request is invalid.'
			);
		}
		$title = trim( $input['title'] );
		if ( '' === $title || mb_strlen( $title ) > 120 ||
			preg_match( '/[<>\x00-\x1F]/', $title ) ||
			sanitize_text_field( $title ) !== $title ) {
			return new WP_Error( 'wphave_mcp_complete_title', 'The page title is invalid.' );
		}
		$batch = $input['batch'];
		$host_context = WPHAVE_AI_MCP_Free_Host_Context::build( $batch );
		if ( is_wp_error( $host_context ) ) {
			return $host_context;
		}
		$markup = WPHAVE_AI_MCP_Free_Host_Runner::render( self::host_nodes( $batch ), $host_context );
		if ( is_wp_error( $markup ) ) {
			return $markup;
		}
		$verified = self::validate_complete_markup( $batch, $markup, $host_context['fingerprint'] );
		if ( is_wp_error( $verified ) ) {
			return $verified;
		}
		$plan = array( 'title' => $title, 'content' => $markup );
		$batch_json = wp_json_encode( $batch );
		if ( ! is_string( $batch_json ) ) {
			return new WP_Error( 'wphave_mcp_complete_invalid', 'The complete page request is invalid.' );
		}
		$transaction_input = array(
			'requestId' => $input['requestId'],
			'sourceIdentity' => $input['requestId'],
			'batchHash' => hash( 'sha256', $batch_json ),
			'contextHash' => $host_context['fingerprint'],
			'markupHash' => hash( 'sha256', $markup ),
		);
		$layout_token = $input['layoutToken'] ?? null;
		$revalidate = static function () use ( $batch, $host_context, $markup, $layout_token ) {
			$fresh_config = WPHAVE_AI_MCP_Free_Creation_Config::get();
			if ( ! self::can_create() || null === $fresh_config ||
				( $fresh_config['workflow']['required'] &&
					! WPHAVE_AI_MCP_Free_Creation_Workflow::matches_drafts( $layout_token, array(
						array( 'pageKey' => 'page', 'batch' => $batch ),
					) ) ) ||
				! WPHAVE_AI_MCP_Free_Job_Store::valid_standalone_batch( $batch ) ) {
				return new WP_Error( 'wphave_mcp_complete_stale', 'The page context changed before creation.' );
			}
			$fresh = WPHAVE_AI_MCP_Free_Host_Context::build( $batch );
			if ( is_wp_error( $fresh ) ||
				! hash_equals( $host_context['fingerprint'], $fresh['fingerprint'] ) ) {
				return new WP_Error( 'wphave_mcp_complete_stale', 'The page context changed before creation.' );
			}
			$rerendered = WPHAVE_AI_MCP_Free_Host_Runner::render( self::host_nodes( $batch ), $fresh );
			if ( is_wp_error( $rerendered ) || ! hash_equals( $markup, $rerendered ) ) {
				return new WP_Error( 'wphave_mcp_complete_stale', 'The native page changed before creation.' );
			}
			return self::validate_complete_markup( $batch, $rerendered, $fresh['fingerprint'] );
		};
		$result = WPHAVE_AI_MCP_Create_Service::create_validated_draft( $transaction_input, $plan, $revalidate );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		$result['editorUrl'] = get_edit_post_link( $result['postId'], 'raw' );
		$result['previewUrl'] = get_preview_post_link( $result['postId'] );
		$result['markupHash'] = hash( 'sha256', $markup );
		return $result;
	}

	/** Render only server-resolved website links through the productive updateLink path. */
	public static function render_linked_website_batch( array $batch, array $resolved_links ) {
		if ( ! self::can_create() || ! $resolved_links ) {
			return new WP_Error( 'wphave_mcp_website_link_invalid', 'The website links are unavailable.' );
		}
		$host_context = WPHAVE_AI_MCP_Free_Host_Context::build( $batch );
		if ( is_wp_error( $host_context ) ) {
			return $host_context;
		}
		$markup = WPHAVE_AI_MCP_Free_Host_Runner::render(
			self::host_nodes( $batch ),
			$host_context,
			$resolved_links
		);
		if ( is_wp_error( $markup ) ) {
			return $markup;
		}
		$valid = WPHAVE_AI_MCP_Free_Result_Validator::validate_website_links(
			$batch,
			$markup,
			$resolved_links
		);
		return is_wp_error( $valid ) ? $valid : $markup;
	}

	private static function host_nodes( array $batch ): array {
		$nodes = $batch['nodes'];
		foreach ( $nodes as &$node ) {
			if ( array() === $node['attributes'] ) {
				$node['attributes'] = new stdClass();
			}
		}
		unset( $node );
		return $nodes;
	}

	private static function validate_complete_markup( array $batch, string $markup, string $context_hash ) {
		$batch_json = wp_json_encode( $batch );
		if ( ! is_string( $batch_json ) ) {
			return new WP_Error( 'wphave_mcp_complete_invalid', 'The complete page request is invalid.' );
		}
		$job = array(
			'job_id' => 'server-owned-direct-create',
			'request_id' => 'server-owned-direct-create',
			'revision_hash' => hash( 'sha256', 'new-page' ),
			'context_hash' => $context_hash,
			'batch_json' => $batch_json,
			'target_post_id' => 0,
		);
		$result = array(
			'jobId' => $job['job_id'],
			'requestId' => $job['request_id'],
			'revisionHash' => $job['revision_hash'],
			'contextHash' => $job['context_hash'],
			'batchHash' => hash( 'sha256', $batch_json ),
			'markup' => $markup,
		);
		return WPHAVE_AI_MCP_Free_Result_Validator::validate( $result, $job );
	}
}
