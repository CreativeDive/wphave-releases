<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** The MCP CSS field uses the same source, entitlement and compiler as the block Inspector. */
final class WPHAVE_AI_MCP_Free_Custom_CSS {
	private const BLOCKS = array(
		'wphave/group',
		'wphave/heading',
		'wphave/paragraph',
		'wphave/image',
		'wphave/line',
	);

	public static function available(): bool {
		$config = WPHAVE_AI_MCP_Free_Creation_Config::get();
		return true === ( $config['capabilities']['customCss'] ?? false ) &&
			class_exists( 'WPHAVE_CSS_Compiler' ) &&
			function_exists( 'wphave_has_pro_access' ) && wphave_has_pro_access() &&
			( current_user_can( WPHAVE_CSS_Compiler::CAPABILITY ) || current_user_can( 'manage_options' ) );
	}

	public static function valid_node( array $node ): bool {
		if ( ! array_key_exists( 'css', $node ) ) {
			return true;
		}
		$css = $node['css'];
		return self::available() &&
			in_array( $node['name'] ?? null, self::BLOCKS, true ) &&
			is_string( $css ) &&
			$css === trim( $css ) &&
			strlen( $css ) >= 4 && strlen( $css ) <= 2048 &&
			$css === WPHAVE_CSS_Compiler::sanitize_source( $css ) &&
			'' !== WPHAVE_CSS_Compiler::scope_source( $css, '#wphave-mcp-scope' );
	}

	public static function contract(): array {
		return array(
			'enabled' => self::available(),
			'field' => 'node.css',
			'allowedNames' => self::BLOCKS,
			'maxBytesPerBlock' => 2048,
			'syntax' => 'Use $block for the current block. Plain declarations, scoped selectors and nested @media, @supports or @container are compiled by the WPHAVE block CSS compiler.',
			'example' => '$block { background: #f1e9dc; color: #26231f; }',
		);
	}

	public static function contract_id( array $node ): string {
		$hash = hash( 'sha256', $node['key'] . "\n" . $node['css'] );
		return substr( $hash, 0, 8 ) . '-' . substr( $hash, 8, 4 ) . '-4' .
			substr( $hash, 13, 3 ) . '-a' . substr( $hash, 17, 3 ) . '-' . substr( $hash, 20, 12 );
	}

	/** Add CSS only after native block generation; preserve all generated design data. */
	public static function apply_markup( string $markup, array $nodes ) {
		$blocks = parse_blocks( $markup );
		$seen = 0;
		if ( ! self::apply_level( $blocks, $nodes, $seen ) || $seen !== count( $nodes ) ) {
			return new WP_Error( 'wphave_mcp_css_tree_invalid', 'The generated block tree does not match the CSS nodes.' );
		}
		return serialize_blocks( $blocks );
	}

	private static function apply_level( array &$blocks, array $nodes, int &$seen, ?string $parent = null ): bool {
		$siblings = array_values( array_filter( $nodes, static function ( $node ) use ( $parent ): bool {
			return is_array( $node ) && ( $node['parentKey'] ?? null ) === $parent;
		} ) );
		$position = 0;
		foreach ( $blocks as &$block ) {
			if ( null === ( $block['blockName'] ?? null ) ) {
				continue;
			}
			$node = $siblings[ $position ] ?? null;
			if ( ! is_array( $node ) ||
				( $node['name'] ?? null ) !== $block['blockName'] || ! self::valid_node( $node ) ) {
				return false;
			}
			$position++;
			$seen++;
			if ( isset( $node['css'] ) ) {
				$block['attrs']['wphave']['features']['css'] = $node['css'];
				$block['attrs']['wphave']['features'][ WPHAVE_CSS_Compiler::CONTRACT_KEY ] = self::contract_id( $node );
			}
			if ( ! self::apply_level( $block['innerBlocks'], $nodes, $seen, $node['key'] ) ) {
				return false;
			}
		}
		return $position === count( $siblings );
	}
}
