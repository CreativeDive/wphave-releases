<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Imports bounded image bytes into the ordinary WordPress media library. */
final class WPHAVE_AI_MCP_Free_Media_Import {
	private const MAX_BYTES = 8388608;
	private const MIME_TYPES = array( 'image/jpeg', 'image/png', 'image/webp', 'image/avif' );

	public static function register(): void {
		if ( ! function_exists( 'wphave_mcp_free_create_feature_enabled' ) ||
			! wphave_mcp_free_create_feature_enabled() ||
			! function_exists( 'wp_register_ability' ) ) {
			return;
		}
		wp_register_ability( 'wphave/site-image-import', array(
			'category' => 'wphave-free-create',
			'label' => __( 'Import website image', 'wphave' ),
			'description' => __( 'Import one licensed image from a public HTTPS URL or base64 bytes into the WordPress Media Library. Return an image ID and exact alt text for native WPHAVE page batches. Use this before creating an image-led website when existing media is unsuitable.', 'wphave' ),
			'input_schema' => array(
				'type' => 'object',
				'properties' => array(
					'sourceUrl' => array( 'type' => 'string' ),
					'base64' => array( 'type' => 'string' ),
					'filename' => array( 'type' => 'string' ),
					'alt' => array( 'type' => 'string' ),
					'title' => array( 'type' => 'string' ),
				),
				'required' => array( 'filename', 'alt' ),
				'additionalProperties' => false,
			),
			'permission_callback' => array( __CLASS__, 'can_import' ),
			'execute_callback' => array( __CLASS__, 'import' ),
			'meta' => array(
				'public' => false,
				'show_in_rest' => false,
				'mcp' => array( 'public' => true ),
				'annotations' => array( 'readonly' => false, 'destructive' => false, 'idempotent' => false ),
			),
		) );
		wp_register_ability( 'wphave/site-image-generate', array(
			'category' => 'wphave-free-create',
			'label' => __( 'Generate website image', 'wphave' ),
			'description' => __( 'Create an original image for the website with the configured WPHAVE image provider, save it in the Media Library, and return its ID and alt text. Choose the subject, composition and aspect ratio for the page brief.', 'wphave' ),
			'input_schema' => array(
				'type' => 'object',
				'properties' => array(
					'prompt' => array( 'type' => 'string' ),
					'filename' => array( 'type' => 'string' ),
					'alt' => array( 'type' => 'string' ),
					'title' => array( 'type' => 'string' ),
					'size' => array( 'type' => 'string', 'enum' => array( 'square', 'landscape', 'portrait' ) ),
				),
				'required' => array( 'prompt', 'filename', 'alt' ),
				'additionalProperties' => false,
			),
			'permission_callback' => array( __CLASS__, 'can_generate' ),
			'execute_callback' => array( __CLASS__, 'generate' ),
			'meta' => array(
				'public' => false,
				'show_in_rest' => false,
				'mcp' => array( 'public' => true ),
				'annotations' => array( 'readonly' => false, 'destructive' => false, 'idempotent' => false ),
			),
		) );
	}

	public static function can_generate(): bool {
		$config = WPHAVE_AI_MCP_Free_Creation_Config::get();
		return self::can_import() &&
			true === ( $config['guidance']['mediaGeneration'] ?? false ) &&
			class_exists( 'WPHAVE_AI_Config' ) &&
			class_exists( 'WPHAVE_AI_Provider_OpenAI' ) &&
			! WPHAVE_AI_Config::is_disabled() &&
			'' !== WPHAVE_AI_Config::openai_api_key();
	}

	public static function generate( $input ) {
		if ( ! self::can_generate() || ! is_array( $input ) ||
			array_diff( array_keys( $input ), array( 'prompt', 'filename', 'alt', 'title', 'size' ) ) ||
			! is_string( $input['prompt'] ?? null ) ||
			! is_string( $input['filename'] ?? null ) ||
			! is_string( $input['alt'] ?? null ) ||
			( isset( $input['title'] ) && ! is_string( $input['title'] ) ) ||
			! in_array( $input['size'] ?? 'landscape', array( 'square', 'landscape', 'portrait' ), true ) ) {
			return new WP_Error( 'wphave_mcp_image_invalid', 'The image generation request is invalid.' );
		}
		$prompt = trim( $input['prompt'] );
		if ( '' === $prompt || mb_strlen( $prompt ) > 3000 ) {
			return new WP_Error( 'wphave_mcp_image_invalid', 'The image prompt is invalid.' );
		}
		$generated = WPHAVE_AI_Provider_OpenAI::instance()->generate_image(
			array( 'prompt' => $prompt ),
			array(
				'size' => $input['size'] ?? 'landscape',
				'fileFormat' => 'webp',
				'variations' => 1,
			)
		);
		if ( is_wp_error( $generated ) ) {
			return $generated;
		}
		$images = $generated['images'] ?? null;
		$image = is_array( $images ) ? ( $images[0] ?? null ) : null;
		if ( ! is_array( $image ) || 'image/webp' !== ( $image['mime'] ?? null ) ||
			! is_string( $image['base64'] ?? null ) || count( $images ) !== 1 ) {
			return new WP_Error( 'wphave_mcp_image_failed', 'The image provider returned no usable image.' );
		}
		$filename = preg_replace( '/\.[^.]+$/', '', $input['filename'] ) . '.webp';
		return self::import( array(
			'base64' => $image['base64'],
			'filename' => $filename,
			'alt' => $input['alt'],
			'title' => $input['title'] ?? $filename,
		) );
	}

	public static function can_import(): bool {
		return WPHAVE_AI_MCP_Free_Create_Abilities::can_create() && current_user_can( 'upload_files' );
	}

	public static function import( $input ) {
		if ( ! self::can_import() || ! is_array( $input ) ||
			array_diff( array_keys( $input ), array( 'sourceUrl', 'base64', 'filename', 'alt', 'title' ) ) ||
			( isset( $input['sourceUrl'] ) === isset( $input['base64'] ) ) ||
			! is_string( $input['filename'] ?? null ) ||
			! is_string( $input['alt'] ?? null ) ||
			( isset( $input['title'] ) && ! is_string( $input['title'] ) ) ) {
			return new WP_Error( 'wphave_mcp_image_invalid', 'The image import request is invalid.' );
		}
		$filename = sanitize_file_name( $input['filename'] );
		$alt = trim( $input['alt'] );
		if ( '' === $filename || strlen( $filename ) > 120 ||
			( isset( $input['title'] ) && strlen( $input['title'] ) > 120 ) ||
			'' === $alt || strlen( $alt ) > 500 || $alt !== wp_strip_all_tags( $alt ) ) {
			return new WP_Error( 'wphave_mcp_image_invalid', 'The image metadata is invalid.' );
		}
		$extension = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );
		$expected_mime = array(
			'jpg' => 'image/jpeg',
			'jpeg' => 'image/jpeg',
			'png' => 'image/png',
			'webp' => 'image/webp',
			'avif' => 'image/avif',
		)[ $extension ] ?? null;
		if ( null === $expected_mime ) {
			return new WP_Error( 'wphave_mcp_image_invalid', 'The image format is unsupported.' );
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		$temporary = wp_tempnam( $filename );
		if ( ! is_string( $temporary ) ) {
			return new WP_Error( 'wphave_mcp_image_failed', 'A temporary image file could not be created.' );
		}
		try {
			$loaded = isset( $input['sourceUrl'] ) ?
				self::download( $input['sourceUrl'], $temporary ) :
				self::decode( $input['base64'], $temporary );
			if ( is_wp_error( $loaded ) ) {
				return $loaded;
			}
			$size = filesize( $temporary );
			$image = wp_get_image_mime( $temporary );
			$dimensions = getimagesize( $temporary );
			$checked = wp_check_filetype_and_ext( $temporary, $filename );
			if ( false === $size || $size < 1 || $size > self::MAX_BYTES ||
				! in_array( $image, self::MIME_TYPES, true ) ||
				! is_array( $dimensions ) || $dimensions[0] < 1 || $dimensions[1] < 1 ||
				$dimensions[0] > 10000 || $dimensions[1] > 10000 ||
				( $dimensions[0] * $dimensions[1] ) > 40000000 ||
				$image !== $expected_mime ||
				( $checked['type'] ?? null ) !== $image ||
				! empty( $checked['proper_filename'] ) ) {
				return new WP_Error( 'wphave_mcp_image_invalid', 'The image bytes do not match a supported image file.' );
			}
			require_once ABSPATH . 'wp-admin/includes/media.php';
			require_once ABSPATH . 'wp-admin/includes/image.php';
			$attachment_id = media_handle_sideload( array(
				'name' => $filename,
				'tmp_name' => $temporary,
			), 0, null, array(
				'post_title' => sanitize_text_field( $input['title'] ?? pathinfo( $filename, PATHINFO_FILENAME ) ),
			) );
			if ( is_wp_error( $attachment_id ) ) {
				return $attachment_id;
			}
			update_post_meta( $attachment_id, '_wp_attachment_image_alt', $alt );
			$verified = WPHAVE_AI_MCP_Free_Media::verified_ids( array(
				'nodes' => array( array(
					'name' => 'wphave/image',
					'attributes' => array( 'image' => $attachment_id, 'alt' => $alt ),
				) ),
			) );
			if ( is_wp_error( $verified ) ) {
				wp_delete_attachment( $attachment_id, true );
				return new WP_Error( 'wphave_mcp_image_failed', 'The imported image could not be verified.' );
			}
			return array(
				'id' => $attachment_id,
				'alt' => $alt,
				'title' => get_the_title( $attachment_id ),
				'mimeType' => $image,
				'width' => $dimensions[0],
				'height' => $dimensions[1],
			);
		} finally {
			wp_delete_file( $temporary );
		}
	}

	private static function download( $url, string $temporary ) {
		if ( ! is_string( $url ) || strlen( $url ) > 2048 ||
			'https' !== wp_parse_url( $url, PHP_URL_SCHEME ) || ! wp_http_validate_url( $url ) ) {
			return new WP_Error( 'wphave_mcp_image_invalid', 'The image URL is invalid.' );
		}
		$response = wp_safe_remote_get( $url, array(
			'timeout' => 20,
			'redirection' => 0,
			'sslverify' => true,
			'stream' => true,
			'filename' => $temporary,
			'limit_response_size' => self::MAX_BYTES + 1,
		) );
		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			return new WP_Error( 'wphave_mcp_image_download_failed', 'The public image could not be downloaded.' );
		}
		return true;
	}

	private static function decode( $base64, string $temporary ) {
		if ( ! is_string( $base64 ) || strlen( $base64 ) > 11184812 ||
			! preg_match( '/^[A-Za-z0-9+\/]+={0,2}$/D', $base64 ) ) {
			return new WP_Error( 'wphave_mcp_image_invalid', 'The encoded image is invalid.' );
		}
		$bytes = base64_decode( $base64, true );
		if ( ! is_string( $bytes ) || strlen( $bytes ) > self::MAX_BYTES ||
			strlen( $bytes ) < 1 || file_put_contents( $temporary, $bytes, LOCK_EX ) !== strlen( $bytes ) ) {
			return new WP_Error( 'wphave_mcp_image_invalid', 'The encoded image could not be stored.' );
		}
		return true;
	}
}
