<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Imports bounded image bytes into the ordinary WordPress media library. */
final class WPHAVE_AI_MCP_Free_Media_Import {

	public static function register(): void {
		if ( ! function_exists( 'wphave_mcp_free_create_feature_enabled' ) ||
			! wphave_mcp_free_create_feature_enabled() ||
			! function_exists( 'wp_register_ability' ) ) {
			return;
		}
		wp_register_ability( 'wphave/site-image-import', array(
			'category' => 'wphave-free-create',
			'label' => __( 'Import website image', 'wphave' ),
			'description' => __( 'Import one licensed image from a public HTTPS URL or base64 bytes into the WordPress Media Library. Return an image ID and exact alt text for native WPHAVE page batches. Use this before creating an image-led website when existing media is unsuitable. Supply a stable requestId and reuse it after a lost response; query site-image-request-status for uncertain outcomes.', 'wphave' ),
			'input_schema' => array(
				'type' => 'object',
				'properties' => array(
					'sourceUrl' => array( 'type' => 'string' ),
					'base64' => array( 'type' => 'string' ),
					'filename' => array( 'type' => 'string' ),
					'alt' => array( 'type' => 'string' ),
					'title' => array( 'type' => 'string' ),
					'requestId' => array( 'type' => 'string' ),
				),
				'required' => array( 'filename', 'alt', 'requestId' ),
				'additionalProperties' => false,
			),
			'permission_callback' => array( __CLASS__, 'can_import' ),
			'execute_callback' => array( __CLASS__, 'import' ),
			'meta' => array(
				'public' => false,
				'show_in_rest' => false,
				'mcp' => array( 'public' => true ),
				'annotations' => array( 'readonly' => false, 'destructive' => false, 'idempotent' => true ),
			),
		) );
		wp_register_ability( 'wphave/site-image-request-status', array(
			'category' => 'wphave-free-create',
			'label' => __( 'Image request status', 'wphave' ),
			'description' => __( 'Inspect the outcome of an image import or generation by its original requestId.', 'wphave' ),
			'input_schema' => array(
				'type' => 'object',
				'properties' => array(
					'operation' => array( 'type' => 'string', 'enum' => array( 'import', 'generate' ) ),
					'requestId' => array( 'type' => 'string' ),
				),
				'required' => array( 'operation', 'requestId' ),
				'additionalProperties' => false,
			),
			'permission_callback' => array( __CLASS__, 'can_import' ),
			'execute_callback' => array( 'WPHAVE_AI_MCP_Media_Request', 'status' ),
			'meta' => array(
				'public' => false,
				'show_in_rest' => false,
				'mcp' => array( 'public' => true ),
				'annotations' => array( 'readonly' => true, 'destructive' => false, 'idempotent' => true ),
			),
		) );
		wp_register_ability( 'wphave/site-image-request-recover', array(
			'category' => 'wphave-free-create',
			'label' => __( 'Recover website image request', 'wphave' ),
			'description' => __( 'After inspecting the Media Library, bind one uniquely verified attachment to an uncertain image request. Reuses the original requestId and never invokes the image provider.', 'wphave' ),
			'input_schema' => array(
				'type' => 'object',
				'properties' => array(
					'operation' => array( 'type' => 'string', 'enum' => array( 'import', 'generate' ) ),
					'requestId' => array( 'type' => 'string' ),
					'attachmentId' => array( 'type' => 'integer' ),
				),
				'required' => array( 'operation', 'requestId', 'attachmentId' ),
				'additionalProperties' => false,
			),
			'permission_callback' => array( __CLASS__, 'can_import' ),
			'execute_callback' => array( 'WPHAVE_AI_MCP_Media_Request', 'recover_unmarked' ),
			'meta' => array(
				'public' => false,
				'show_in_rest' => false,
				'mcp' => array( 'public' => true ),
				'annotations' => array( 'readonly' => false, 'destructive' => false, 'idempotent' => true ),
			),
		) );
		wp_register_ability( WPHAVE_AI_Task_Catalog::mcp_ability_id( 'image.generate' ), array(
			'category' => 'wphave-free-create',
			'label' => __( 'Generate website image', 'wphave' ),
			'description' => __( 'Create an original image for the website with the configured WPHAVE image provider, save it in the Media Library, and return its ID and alt text. Choose the subject, composition and aspect ratio for the page brief. Supply a stable requestId and reuse it after a lost response; query site-image-request-status for uncertain outcomes.', 'wphave' ),
			'input_schema' => array(
				'type' => 'object',
				'properties' => array(
					'prompt' => array( 'type' => 'string' ),
					'filename' => array( 'type' => 'string' ),
					'alt' => array( 'type' => 'string' ),
					'title' => array( 'type' => 'string' ),
					'requestId' => array( 'type' => 'string' ),
					'size' => array( 'type' => 'string', 'enum' => array( 'square', 'landscape', 'portrait' ) ),
				),
				'required' => array( 'prompt', 'filename', 'alt', 'requestId' ),
				'additionalProperties' => false,
			),
			'permission_callback' => array( __CLASS__, 'can_generate' ),
			'execute_callback' => array( __CLASS__, 'generate' ),
			'meta' => array(
				'public' => false,
				'show_in_rest' => false,
				'mcp' => array( 'public' => true ),
				'annotations' => array( 'readonly' => false, 'destructive' => false, 'idempotent' => true ),
			),
		) );
	}

	public static function can_generate(): bool {
		$config = WPHAVE_AI_MCP_Free_Creation_Config::get();
		return self::can_import() &&
			true === ( $config['guidance']['mediaGeneration'] ?? false ) &&
			class_exists( 'WPHAVE_AI_Config' ) &&
			class_exists( 'WPHAVE_AI_Image_Generation_Service' ) &&
			class_exists( 'WPHAVE_AI_Provider_OpenAI' ) &&
			! WPHAVE_AI_Config::is_disabled() &&
			'' !== WPHAVE_AI_Config::openai_api_key();
	}

	public static function generate( $input ) {
		if ( ! self::can_generate() || ! is_array( $input ) ||
			array_diff( array_keys( $input ), array( 'prompt', 'filename', 'alt', 'title', 'size', 'requestId' ) ) ||
			! is_string( $input['prompt'] ?? null ) ||
			! is_string( $input['filename'] ?? null ) ||
			! is_string( $input['alt'] ?? null ) ||
			( isset( $input['title'] ) && ! is_string( $input['title'] ) ) ||
			! in_array( $input['size'] ?? 'landscape', array( 'square', 'landscape', 'portrait' ), true ) ) {
			return new WP_Error( 'wphave_mcp_image_invalid', 'The image generation request is invalid.' );
		}
		$prompt = trim( $input['prompt'] );
		if ( '' === $prompt || mb_strlen( $prompt ) > 3000 ) {
			return new WP_Error( 'wphave_mcp_image_invalid', 'The image prompt is invalid.' );
		}
		$claim = WPHAVE_AI_MCP_Media_Request::begin( 'generate', $input );
		if ( is_wp_error( $claim ) ) {
			return $claim;
		}
		if ( ! $claim['new'] ) {
			return WPHAVE_AI_MCP_Media_Request::result( $claim );
		}
		$generated = WPHAVE_AI_Image_Generation_Service::generate(
			array( 'prompt' => $prompt ),
			array(
				'size' => $input['size'] ?? 'landscape',
				'fileFormat' => 'webp',
				'variations' => 1,
			)
		);
		if ( is_wp_error( $generated ) ) {
			return WPHAVE_AI_MCP_Media_Request::finish( $claim['key'], $generated );
		}
		$images = $generated['images'] ?? null;
		$image = is_array( $images ) ? ( $images[0] ?? null ) : null;
		if ( ! is_array( $image ) || 'image/webp' !== ( $image['mime'] ?? null ) ||
			! is_string( $image['base64'] ?? null ) || count( $images ) !== 1 ) {
			return WPHAVE_AI_MCP_Media_Request::finish( $claim['key'], new WP_Error( 'wphave_mcp_image_failed', 'The image provider returned no usable image.' ) );
		}
		$filename = preg_replace( '/\.[^.]+$/', '', $input['filename'] ) . '.webp';
		$imported = self::import_untracked( array(
			'base64' => $image['base64'],
			'filename' => $filename,
			'alt' => $input['alt'],
			'title' => $input['title'] ?? $filename,
		), $claim['key'] );
		if ( is_wp_error( $imported ) ) {
			return WPHAVE_AI_MCP_Media_Request::finish( $claim['key'], $imported );
		}
		if ( ! WPHAVE_AI_Media_Import_Service::mark_ai_origin( $imported['id'], 'generated' ) ) {
			wp_delete_attachment( $imported['id'], true );
			return WPHAVE_AI_MCP_Media_Request::finish( $claim['key'], new WP_Error( 'wphave_mcp_image_failed', 'The generated image metadata could not be verified.' ) );
		}
		return WPHAVE_AI_MCP_Media_Request::finish( $claim['key'], $imported );
	}

	public static function can_import(): bool {
		return WPHAVE_AI_MCP_Free_Create_Abilities::can_create() && current_user_can( 'upload_files' );
	}

	public static function import( $input ) {
		if ( ! is_array( $input ) || ! isset( $input['requestId'] ) ) {
			return new WP_Error( 'wphave_mcp_image_invalid', 'A requestId is required.' );
		}
		$payload = $input;
		unset( $payload['requestId'] );
		if ( ! self::can_import() || array_diff( array_keys( $payload ), array( 'sourceUrl', 'base64', 'filename', 'alt', 'title' ) ) ) {
			return new WP_Error( 'wphave_mcp_image_invalid', 'The image import request is invalid.' );
		}
		$claim = WPHAVE_AI_MCP_Media_Request::begin( 'import', $input );
		if ( is_wp_error( $claim ) ) {
			return $claim;
		}
		if ( ! $claim['new'] ) {
			return WPHAVE_AI_MCP_Media_Request::result( $claim );
		}
		return WPHAVE_AI_MCP_Media_Request::finish( $claim['key'], self::import_untracked( $payload, $claim['key'] ) );
	}

	private static function import_untracked( $input, string $request_key ) {
		if ( ! self::can_import() || ! is_array( $input ) ||
			array_diff( array_keys( $input ), array( 'sourceUrl', 'base64', 'filename', 'alt', 'title' ) ) ||
			( isset( $input['sourceUrl'] ) === isset( $input['base64'] ) ) ||
			! is_string( $input['filename'] ?? null ) ||
			! is_string( $input['alt'] ?? null ) ||
			( isset( $input['title'] ) && ! is_string( $input['title'] ) ) ) {
			return new WP_Error( 'wphave_mcp_image_invalid', 'The image import request is invalid.' );
		}
		$filename = sanitize_file_name( $input['filename'] );
		$alt = trim( $input['alt'] );
		if ( '' === $filename || strlen( $filename ) > 120 ||
			( isset( $input['title'] ) && strlen( $input['title'] ) > 120 ) ||
			'' === $alt || strlen( $alt ) > 500 || $alt !== wp_strip_all_tags( $alt ) ) {
			return new WP_Error( 'wphave_mcp_image_invalid', 'The image metadata is invalid.' );
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		$temporary = wp_tempnam( $filename );
		if ( ! is_string( $temporary ) ) {
			return new WP_Error( 'wphave_mcp_image_failed', 'A temporary image file could not be created.' );
		}
		try {
			$loaded = isset( $input['sourceUrl'] ) ?
				self::download( $input['sourceUrl'], $temporary ) :
				self::decode( $input['base64'], $temporary );
			if ( is_wp_error( $loaded ) ) {
				return $loaded;
			}
			$inspected = WPHAVE_AI_Media_Import_Service::inspect_file( $temporary, $filename );
			if ( is_wp_error( $inspected ) ) {
				return new WP_Error( 'wphave_mcp_image_invalid', 'The image bytes do not match a supported image file.' );
			}
			$title = sanitize_text_field( $input['title'] ?? pathinfo( $filename, PATHINFO_FILENAME ) );
			$expected = WPHAVE_AI_MCP_Media_Request::expect(
				$request_key,
				$temporary,
				$filename,
				$alt,
				$title,
				$inspected['mime']
			);
			if ( is_wp_error( $expected ) ) {
				return $expected;
			}
			require_once ABSPATH . 'wp-admin/includes/media.php';
			require_once ABSPATH . 'wp-admin/includes/image.php';
			$early_attachment_error = null;
			$mark_attachment = static function ( int $id ) use ( $request_key, &$early_attachment_error ): void {
				$marked = WPHAVE_AI_MCP_Media_Request::attachment_created( $request_key, $id );
				if ( is_wp_error( $marked ) ) {
					$early_attachment_error = $marked;
				}
			};
			add_action( 'add_attachment', $mark_attachment, -1000 );
			try {
				$attachment_id = media_handle_sideload( array(
					'name' => $filename,
					'tmp_name' => $temporary,
				), 0, null, array(
					'post_title' => $title,
				) );
			} finally {
				remove_action( 'add_attachment', $mark_attachment, -1000 );
			}
			if ( is_wp_error( $attachment_id ) ) {
				return $attachment_id;
			}
			if ( is_wp_error( $early_attachment_error ) ) {
				return $early_attachment_error;
			}
			$attached = WPHAVE_AI_MCP_Media_Request::attachment_created( $request_key, (int) $attachment_id );
			if ( is_wp_error( $attached ) ) {
				return $attached;
			}
			update_post_meta( $attachment_id, '_wp_attachment_image_alt', $alt );
			$verified = WPHAVE_AI_MCP_Free_Media::verified_ids( array(
				'nodes' => array( array(
					'name' => 'wphave/image',
					'attributes' => array( 'image' => $attachment_id, 'alt' => $alt ),
				) ),
			) );
			if ( is_wp_error( $verified ) ) {
				wp_delete_attachment( $attachment_id, true );
				return new WP_Error( 'wphave_mcp_image_failed', 'The imported image could not be verified.' );
			}
			return array(
				'id' => $attachment_id,
				'alt' => $alt,
				'title' => get_the_title( $attachment_id ),
				'mimeType' => $inspected['mime'],
				'width' => $inspected['width'],
				'height' => $inspected['height'],
			);
		} finally {
			wp_delete_file( $temporary );
		}
	}

	private static function download( $url, string $temporary ) {
		if ( ! is_string( $url ) || strlen( $url ) > 2048 ||
			'https' !== wp_parse_url( $url, PHP_URL_SCHEME ) || ! wp_http_validate_url( $url ) ) {
			return new WP_Error( 'wphave_mcp_image_invalid', 'The image URL is invalid.' );
		}
		$response = wp_safe_remote_get( $url, array(
			'timeout' => 20,
			'redirection' => 0,
			'sslverify' => true,
			'stream' => true,
			'filename' => $temporary,
			'limit_response_size' => WPHAVE_AI_Media_Import_Service::MAX_BYTES + 1,
		) );
		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			return new WP_Error( 'wphave_mcp_image_download_failed', 'The public image could not be downloaded.' );
		}
		return true;
	}

	private static function decode( $base64, string $temporary ) {
		if ( ! is_string( $base64 ) || strlen( $base64 ) > (int) ceil( WPHAVE_AI_Media_Import_Service::MAX_BYTES / 3 ) * 4 ||
			! preg_match( '/^[A-Za-z0-9+\/]+={0,2}$/D', $base64 ) ) {
			return new WP_Error( 'wphave_mcp_image_invalid', 'The encoded image is invalid.' );
		}
		$bytes = base64_decode( $base64, true );
		if ( ! is_string( $bytes ) || strlen( $bytes ) > WPHAVE_AI_Media_Import_Service::MAX_BYTES ||
			strlen( $bytes ) < 1 || file_put_contents( $temporary, $bytes, LOCK_EX ) !== strlen( $bytes ) ) {
			return new WP_Error( 'wphave_mcp_image_invalid', 'The encoded image could not be stored.' );
		}
		return true;
	}
}
