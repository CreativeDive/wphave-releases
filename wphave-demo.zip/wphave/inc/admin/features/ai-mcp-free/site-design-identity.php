<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Read-only projection of the productive global design data for Free MCP agents. */
final class WPHAVE_AI_MCP_Free_Site_Design_Identity {
	private static function safe_color( $value ): ?string {
		if ( ! is_string( $value ) || strlen( $value ) > 80 ) {
			return null;
		}
		$value = trim( $value );
		return preg_match( '/^#[0-9a-fA-F]{3,8}$/D', $value ) ||
			preg_match( '/^(?:rgb|rgba|hsl|hsla)\([0-9.,%\s\/+-]+\)$/D', $value ) ||
			preg_match( '/^var\(--wphave-site-color-[A-Za-z0-9_-]+\)$/D', $value ) ||
			in_array( $value, array( 'transparent', 'currentColor' ), true ) ? $value : null;
	}

	private static function resolve_color( string $role, array $colors, int $depth = 0 ): ?string {
		if ( $depth > 3 || ! isset( $colors[ $role ]['base'] ) ) {
			return null;
		}
		$value = $colors[ $role ]['base'];
		if ( is_string( $value ) && preg_match( '/^var\(--wphave-site-color-([A-Za-z0-9_-]+)\)$/D', $value, $matches ) ) {
			return $matches[1] === $role ? null : self::resolve_color( $matches[1], $colors, $depth + 1 );
		}
		return self::safe_color( $value );
	}

	private static function safe_length( $value ): ?string {
		if ( ! is_string( $value ) && ! is_numeric( $value ) ) {
			return null;
		}
		$value = (string) $value;
		return preg_match( '/^\d{1,4}(?:\.\d{1,2})?(?:px|rem|em|%|vw|vh)?$/D', $value ) ? $value : null;
	}

	private static function safe_font( $value ): ?string {
		return is_string( $value ) && strlen( $value ) <= 80 &&
			preg_match( '/^[\p{L}\p{N} .,_-]+$/uD', $value ) ? $value : null;
	}

	public static function snapshot() {
		$catalog = WPHAVE_AI_MCP_Free_Design_Grammar::catalog();
		$globals = class_exists( 'WPHAVE_Global_Data' ) ? WPHAVE_Global_Data::get_base() : null;
		if ( is_wp_error( $catalog ) || ! is_array( $globals ) ) {
			return new WP_Error( 'wphave_mcp_identity_unavailable', 'Site design identity is unavailable.' );
		}

		$colors = array();
		foreach ( array_keys( $globals['colors'] ?? array() ) as $role ) {
			if ( ! is_string( $role ) || ! preg_match( '/^[A-Za-z][A-Za-z0-9]*$/D', $role ) ) {
				continue;
			}
			if ( ! in_array( 'var(--wphave-site-color-' . $role . ')', $catalog['textColorOperation']['values'] ?? array(), true ) ) {
				continue;
			}
			$colors[ $role ] = self::resolve_color( $role, $globals['colors'] );
		}

		$typography = array();
		foreach ( array( 'text', 'headings' ) as $role ) {
			$data = $globals['typography'][ $role ] ?? null;
			if ( ! is_array( $data ) ) {
				continue;
			}
			$weight = $data['weight'] ?? null;
			$typography[ $role ] = array(
				'family' => self::safe_font( $data['family']['name'] ?? null ),
				'weight' => is_numeric( $weight ) && (int) $weight >= 100 && (int) $weight <= 900 ? (int) $weight : null,
				'size' => array(
					'min' => self::safe_length( $data['size']['custom']['min'] ?? null ),
					'max' => self::safe_length( $data['size']['custom']['max'] ?? null ),
				),
			);
		}

		$buttons = array();
		foreach ( $catalog['buttonCatalog']['variants'] ?? array() as $variant ) {
			if ( ! is_string( $variant ) || ! preg_match( '/^[a-z]+$/D', $variant ) ) {
				continue;
			}
			$button_colors = $globals['buttons'][ $variant ]['colors'] ?? array();
			$buttons[ $variant ] = array(
				'background' => self::safe_color( $button_colors['background'] ?? null ),
				'text' => self::safe_color( $button_colors['text'] ?? null ),
			);
		}

		$spacing = array();
		foreach ( array( 'gapSizes', 'paddingSizes', 'marginSizes' ) as $group ) {
			$spacing[ $group ] = array();
			foreach ( $globals['tokens'][ $group ] ?? array() as $key => $token ) {
				if ( is_string( $key ) && preg_match( '/^[a-z0-9-]+$/D', $key ) ) {
					$spacing[ $group ][ $key ] = self::safe_length( $token['value'] ?? null );
				}
			}
		}

		$identity = array(
			'colors' => $colors,
			'typography' => array(
				'base' => $typography,
				'headingSizes' => array_column( $catalog['textOperations']['wphave/heading']['values'], 'type' ),
				'textSizes' => array_column( $catalog['textOperations']['wphave/paragraph']['values'], 'type' ),
			),
			'buttons' => array(
				'variants' => $buttons,
				'sizes' => $catalog['buttonCatalog']['sizes'],
			),
			'layout' => array(
				'widths' => array(
					'content' => self::safe_length( $globals['layout']['width'] ?? null ),
					'wide' => self::safe_length( $globals['layout']['wideWidth'] ?? null ),
					'medium' => self::safe_length( $globals['layout']['mediumWidth'] ?? null ),
					'narrow' => self::safe_length( $globals['layout']['narrowWidth'] ?? null ),
				),
				'spacing' => $spacing,
			),
			'responsive' => array(
				'mobileBelow' => defined( 'WPHAVE_BREAKPOINT_MOBILE' ) ? WPHAVE_BREAKPOINT_MOBILE : null,
				'tabletBelow' => defined( 'WPHAVE_BREAKPOINT_TABLET' ) ? WPHAVE_BREAKPOINT_TABLET : null,
				'mcpDevices' => array( 'Desktop', 'Mobile' ),
				'inheritance' => 'Mobile uses Desktop unless a Mobile operation overrides the same path.',
			),
		);
		$json = wp_json_encode( $identity );
		if ( ! is_string( $json ) ) {
			return new WP_Error( 'wphave_mcp_identity_unavailable', 'Site design identity is unavailable.' );
		}
		return array(
			'fingerprint' => hash( 'sha256', get_current_blog_id() . ':' . $json ),
			'identity' => $identity,
		);
	}
}
