<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** MCP only creates and reads private jobs; worker execution uses REST. */
final class WPHAVE_AI_MCP_Free_Abilities {
	private static function required_action_schema(): array {
		return array(
			'type' => 'object',
			'properties' => array(
				'actionId' => array( 'type' => 'string' ),
				'kind' => array( 'type' => 'string', 'enum' => array( 'native-button' ) ),
				'linkTarget' => array( 'type' => 'object' ),
			),
			'required' => array( 'actionId', 'kind' ),
			'additionalProperties' => false,
		);
	}

	public static function register_category(): void {
		if ( function_exists( 'wp_register_ability_category' ) ) {
			wp_register_ability_category( 'wphave-free-design', array(
				'label' => __( 'WPHAVE Free Design', 'wphave' ),
				'description' => __( 'Private native design proposals.', 'wphave' ),
			) );
		}
	}

	public static function register(): void {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}
		$meta = array(
			'public' => false,
			'show_in_rest' => false,
			'mcp' => array( 'public' => true ),
		);
		wp_register_ability( 'wphave/free-page-prepare', array(
			'category' => 'wphave-free-design',
			'label' => __( 'Prepare WPHAVE free page proposal', 'wphave' ),
			'description' => __( 'Create a bounded private design job without editing a page.', 'wphave' ),
			'input_schema' => array(
				'type' => 'object',
				'properties' => array(
					'requestId' => array( 'type' => 'string' ),
					'targetPostId' => array( 'type' => 'integer' ),
					'batch' => array( 'type' => 'object' ),
					'projectId' => array( 'type' => 'string' ),
					'pageKey' => array( 'type' => 'string', 'enum' => array( 'home', 'services' ) ),
					'expectedProjectRevision' => array( 'type' => 'integer' ),
				),
				'required' => array( 'requestId', 'targetPostId', 'batch' ),
				'additionalProperties' => false,
			),
			'permission_callback' => array( __CLASS__, 'can_use' ),
			'execute_callback' => array( __CLASS__, 'prepare' ),
			'meta' => array_merge( $meta, array(
				'annotations' => array( 'readonly' => false, 'destructive' => false, 'idempotent' => true ),
			) ),
		) );
		wp_register_ability( 'wphave/free-page-status', array(
			'category' => 'wphave-free-design',
			'label' => __( 'Read WPHAVE free page job', 'wphave' ),
			'description' => __( 'Read a private design job and its untrusted proposal.', 'wphave' ),
			'input_schema' => array(
				'type' => 'object',
				'properties' => array( 'jobId' => array( 'type' => 'string' ) ),
				'required' => array( 'jobId' ),
				'additionalProperties' => false,
			),
			'permission_callback' => array( __CLASS__, 'can_use' ),
			'execute_callback' => array( __CLASS__, 'status' ),
			'meta' => array_merge( $meta, array(
				'annotations' => array( 'readonly' => true, 'idempotent' => true ),
			) ),
		) );
		wp_register_ability( 'wphave/free-page-revise', array(
			'category' => 'wphave-free-design',
			'label' => __( 'Revise WPHAVE free page proposal', 'wphave' ),
			'description' => __( 'Create a private text-only successor job from an intact proposal.', 'wphave' ),
			'input_schema' => array(
				'type' => 'object',
				'properties' => array(
					'requestId' => array( 'type' => 'string' ),
					'parentJobId' => array( 'type' => 'string' ),
					'parentResultHash' => array( 'type' => 'string' ),
					'changes' => array( 'type' => 'array' ),
				),
				'required' => array( 'requestId', 'parentJobId', 'parentResultHash', 'changes' ),
				'additionalProperties' => false,
			),
			'permission_callback' => array( __CLASS__, 'can_use' ),
			'execute_callback' => array( __CLASS__, 'revise' ),
			'meta' => array_merge( $meta, array(
				'annotations' => array( 'readonly' => false, 'destructive' => false, 'idempotent' => true ),
			) ),
		) );
		wp_register_ability( 'wphave/free-page-plan-content', array(
			'category' => 'wphave-free-design',
			'label' => __( 'Plan website content', 'wphave' ),
			'description' => __( 'Step 1: Plan the content, audience goal and section purposes before reading design tools. Returns a user-bound content token.', 'wphave' ),
			'input_schema' => array(
				'type' => 'object',
				'properties' => array( 'pages' => array(
					'type' => 'array',
					'items' => array(
						'type' => 'object',
						'properties' => array(
							'pageKey' => array( 'type' => 'string' ),
							'goal' => array( 'type' => 'string' ),
							'requiredActions' => array(
								'type' => 'array',
								'items' => self::required_action_schema(),
							),
							'sections' => array( 'type' => 'array', 'items' => array(
								'type' => 'object',
								'properties' => array(
									'key' => array( 'type' => 'string' ),
									'purpose' => array( 'type' => 'string' ),
								),
								'required' => array( 'key', 'purpose' ),
								'additionalProperties' => false,
							) ),
						),
						'required' => array( 'pageKey', 'goal', 'sections' ),
						'additionalProperties' => false,
					),
				) ),
				'required' => array( 'pages' ),
				'additionalProperties' => false,
			),
			'permission_callback' => array( __CLASS__, 'can_use' ),
			'execute_callback' => array( __CLASS__, 'plan_content' ),
			'meta' => array_merge( $meta, array(
				'annotations' => array( 'readonly' => true, 'idempotent' => true ),
			) ),
		) );
		wp_register_ability( 'wphave/free-page-plan-layout', array(
			'category' => 'wphave-free-design',
			'label' => __( 'Plan website section layouts', 'wphave' ),
			'description' => __( 'Step 3: After reading design options, specify native structure, layout and responsive intent for every planned section. Returns the token required for draft creation.', 'wphave' ),
			'input_schema' => array(
				'type' => 'object',
				'properties' => array(
					'designToken' => array( 'type' => 'string' ),
					'siteDesignContract' => array( 'type' => 'object', 'additionalProperties' => true ),
					'shellComposition' => array( 'type' => 'object', 'additionalProperties' => true ),
					'pages' => array(
						'type' => 'array',
						'items' => array(
							'type' => 'object',
							'properties' => array(
								'pageKey' => array( 'type' => 'string' ),
								'goal' => array( 'type' => 'string' ),
								'requiredActions' => array(
									'type' => 'array',
									'items' => self::required_action_schema(),
								),
								'sections' => array( 'type' => 'array', 'items' => array(
									'type' => 'object',
									'properties' => array(
										'key' => array( 'type' => 'string' ),
										'purpose' => array( 'type' => 'string' ),
										'layout' => array( 'type' => 'string', 'enum' => array( 'stacked', 'grid', 'flex' ) ),
										'structure' => array( 'type' => 'string' ),
										'responsiveIntent' => array( 'type' => 'string' ),
									),
									'required' => array( 'key', 'purpose', 'layout', 'structure', 'responsiveIntent' ),
									'additionalProperties' => false,
								) ),
							),
							'required' => array( 'pageKey', 'goal', 'sections' ),
							'additionalProperties' => false,
						),
					),
				),
				'required' => array( 'designToken', 'pages' ),
				'additionalProperties' => false,
			),
			'permission_callback' => array( __CLASS__, 'can_use' ),
			'execute_callback' => array( __CLASS__, 'plan_layout' ),
			'meta' => array_merge( $meta, array(
				'annotations' => array( 'readonly' => true, 'idempotent' => true ),
			) ),
		) );
		$config = WPHAVE_AI_MCP_Free_Creation_Config::get();
		$workflow_required = true === ( $config['workflow']['required'] ?? false );
		wp_register_ability( 'wphave/free-page-design-options', array(
			'category' => 'wphave-free-design',
			'label' => __( 'Read WPHAVE free design options', 'wphave' ),
			'description' => __( 'Step 2: After planning content, read the bounded native MCP design grammar, current fingerprint and available composition tools. Pass the content token from free-page-plan-content.', 'wphave' ),
			'input_schema' => array(
				'type' => 'object',
				'properties' => array( 'contentToken' => array( 'type' => 'string' ) ),
				'required' => $workflow_required ? array( 'contentToken' ) : array(),
				'additionalProperties' => false,
			),
			'permission_callback' => array( __CLASS__, 'can_use' ),
			'execute_callback' => array( __CLASS__, 'design_options' ),
			'meta' => array_merge( $meta, array(
				'annotations' => array( 'readonly' => true, 'idempotent' => true ),
			) ),
		) );
		wp_register_ability( 'wphave/site-design-identity', array(
			'category' => 'wphave-free-design',
			'label' => __( 'Read WPHAVE site design identity', 'wphave' ),
			'description' => __( 'Read a compact snapshot of existing global design values without changing the site.', 'wphave' ),
			'input_schema' => array(
				'type' => 'object',
				'properties' => array(),
				'additionalProperties' => false,
			),
			'permission_callback' => array( __CLASS__, 'can_use' ),
			'execute_callback' => array( __CLASS__, 'site_design_identity' ),
			'meta' => array_merge( $meta, array(
				'annotations' => array( 'readonly' => true, 'idempotent' => true ),
			) ),
		) );
		wp_register_ability( 'wphave/site-composition-inspect', array(
			'category' => 'wphave-free-design',
			'label' => __( 'Inspect site composition design', 'wphave' ),
			'description' => __( 'Read every native block type and design path used by one bundled site composition. The response distinguishes executable MCP operations from native reference paths.', 'wphave' ),
			'input_schema' => array(
				'type' => 'object',
				'properties' => array( 'id' => array( 'type' => 'string' ) ),
				'required' => array( 'id' ),
				'additionalProperties' => false,
			),
			'permission_callback' => array( __CLASS__, 'can_use' ),
			'execute_callback' => array( __CLASS__, 'inspect_composition' ),
			'meta' => array_merge( $meta, array(
				'annotations' => array( 'readonly' => true, 'idempotent' => true ),
			) ),
		) );
		wp_register_ability( 'wphave/site-project-create', array(
			'category' => 'wphave-free-design',
			'label' => __( 'Create WPHAVE website project', 'wphave' ),
			'description' => __( 'Coordinate two existing private draft pages under one immutable design reference.', 'wphave' ),
			'input_schema' => array(
				'type' => 'object',
				'properties' => array(
					'requestId' => array( 'type' => 'string' ),
					'homePostId' => array( 'type' => 'integer' ),
					'servicesPostId' => array( 'type' => 'integer' ),
				),
				'required' => array( 'requestId', 'homePostId', 'servicesPostId' ),
				'additionalProperties' => false,
			),
			'permission_callback' => array( __CLASS__, 'can_use' ),
			'execute_callback' => array( __CLASS__, 'create_site_project' ),
			'meta' => array_merge( $meta, array(
				'annotations' => array( 'readonly' => false, 'destructive' => false, 'idempotent' => true ),
			) ),
		) );
		wp_register_ability( 'wphave/site-project-status', array(
			'category' => 'wphave-free-design',
			'label' => __( 'Read WPHAVE website project', 'wphave' ),
			'description' => __( 'Read private two-page project slots and their bound job references.', 'wphave' ),
			'input_schema' => array(
				'type' => 'object',
				'properties' => array( 'projectId' => array( 'type' => 'string' ) ),
				'required' => array( 'projectId' ),
				'additionalProperties' => false,
			),
			'permission_callback' => array( __CLASS__, 'can_use' ),
			'execute_callback' => array( __CLASS__, 'site_project_status' ),
			'meta' => array_merge( $meta, array(
				'annotations' => array( 'readonly' => true, 'idempotent' => true ),
			) ),
		) );
		wp_register_ability( 'wphave/site-shell-header-prepare', array(
			'category' => 'wphave-free-design',
			'label' => __( 'Prepare WPHAVE website header proposal', 'wphave' ),
			'description' => __( 'Create a private native header preview for a two-page project without changing the live site shell.', 'wphave' ),
			'input_schema' => array(
				'type' => 'object',
				'properties' => array(
					'requestId' => array( 'type' => 'string' ),
					'projectId' => array( 'type' => 'string' ),
					'expectedProjectRevision' => array( 'type' => 'integer' ),
					'brand' => array( 'type' => 'string' ),
				),
				'required' => array( 'requestId', 'projectId', 'expectedProjectRevision', 'brand' ),
				'additionalProperties' => false,
			),
			'permission_callback' => array( __CLASS__, 'can_manage_shell' ),
			'execute_callback' => array( __CLASS__, 'prepare_site_header' ),
			'meta' => array_merge( $meta, array(
				'annotations' => array( 'readonly' => false, 'destructive' => false, 'idempotent' => true ),
			) ),
		) );
		wp_register_ability( 'wphave/site-shell-header-status', array(
			'category' => 'wphave-free-design',
			'label' => __( 'Read WPHAVE website header proposal', 'wphave' ),
			'description' => __( 'Read a current private header proposal and its exact page references.', 'wphave' ),
			'input_schema' => array(
				'type' => 'object',
				'properties' => array( 'jobId' => array( 'type' => 'string' ) ),
				'required' => array( 'jobId' ),
				'additionalProperties' => false,
			),
			'permission_callback' => array( __CLASS__, 'can_manage_shell' ),
			'execute_callback' => array( __CLASS__, 'site_header_status' ),
			'meta' => array_merge( $meta, array(
				'annotations' => array( 'readonly' => true, 'idempotent' => true ),
			) ),
		) );
		wp_register_ability( 'wphave/site-shell-footer-prepare', array(
			'category' => 'wphave-free-design',
			'label' => __( 'Prepare WPHAVE website footer proposal', 'wphave' ),
			'description' => __( 'Create a private native footer preview without changing the live site shell.', 'wphave' ),
			'input_schema' => array(
				'type' => 'object',
				'properties' => array(
					'requestId' => array( 'type' => 'string' ),
					'projectId' => array( 'type' => 'string' ),
					'expectedProjectRevision' => array( 'type' => 'integer' ),
					'brand' => array( 'type' => 'string' ),
					'description' => array( 'type' => 'string' ),
					'copyright' => array( 'type' => 'string' ),
				),
				'required' => array( 'requestId', 'projectId', 'expectedProjectRevision', 'brand', 'description', 'copyright' ),
				'additionalProperties' => false,
			),
			'permission_callback' => array( __CLASS__, 'can_manage_shell' ),
			'execute_callback' => array( __CLASS__, 'prepare_site_footer' ),
			'meta' => array_merge( $meta, array(
				'annotations' => array( 'readonly' => false, 'destructive' => false, 'idempotent' => true ),
			) ),
		) );
		wp_register_ability( 'wphave/site-shell-footer-status', array(
			'category' => 'wphave-free-design',
			'label' => __( 'Read WPHAVE website footer proposal', 'wphave' ),
			'description' => __( 'Read a current private footer proposal and its exact page references.', 'wphave' ),
			'input_schema' => array(
				'type' => 'object',
				'properties' => array( 'jobId' => array( 'type' => 'string' ) ),
				'required' => array( 'jobId' ),
				'additionalProperties' => false,
			),
			'permission_callback' => array( __CLASS__, 'can_manage_shell' ),
			'execute_callback' => array( __CLASS__, 'site_footer_status' ),
			'meta' => array_merge( $meta, array(
				'annotations' => array( 'readonly' => true, 'idempotent' => true ),
			) ),
		) );
	}

	public static function can_use(): bool {
		return wphave_mcp_free_design_feature_enabled() && current_user_can( 'wphave_access' );
	}

	public static function can_manage_shell(): bool {
		return self::can_use() &&
			current_user_can( 'wphave_manage_template_parts' ) &&
			! wphave_use_fse();
	}

	public static function design_options( $input ) {
		$config = WPHAVE_AI_MCP_Free_Creation_Config::get();
		if ( ! self::can_use() || ! is_array( $input ) || null === $config ) {
			return new WP_Error( 'wphave_mcp_free_invalid', 'Design options are unavailable.' );
		}
		if ( $config['workflow']['required'] ) {
			if ( array_keys( $input ) !== array( 'contentToken' ) ) {
				return new WP_Error( 'wphave_mcp_workflow_invalid', 'Plan content before reading design options.' );
			}
			return WPHAVE_AI_MCP_Free_Creation_Workflow::options( $input['contentToken'] );
		}
		if ( array() !== $input ) {
			return new WP_Error( 'wphave_mcp_free_invalid', 'Design options are unavailable.' );
		}
		return WPHAVE_AI_MCP_Free_Design_Grammar::discovery();
	}

	public static function site_design_identity( $input ) {
		if ( ! self::can_use() || ! is_array( $input ) || array() !== $input ) {
			return new WP_Error( 'wphave_mcp_identity_unavailable', 'Site design identity is unavailable.' );
		}
		return WPHAVE_AI_MCP_Free_Site_Design_Identity::snapshot();
	}

	public static function plan_content( $input ) {
		if ( ! self::can_use() || ! is_array( $input ) || array_keys( $input ) !== array( 'pages' ) ) {
			return new WP_Error( 'wphave_mcp_workflow_invalid', 'The content plan is invalid.' );
		}
		return WPHAVE_AI_MCP_Free_Creation_Workflow::content( $input['pages'] );
	}

	public static function plan_layout( $input ) {
		if ( ! self::can_use() || ! is_array( $input ) ||
			array_diff( array_keys( $input ), array( 'designToken', 'pages', 'siteDesignContract', 'shellComposition' ) ) ||
			! isset( $input['designToken'], $input['pages'] ) ) {
			return new WP_Error( 'wphave_mcp_workflow_invalid', 'The layout plan is invalid.' );
		}
		return WPHAVE_AI_MCP_Free_Creation_Workflow::layout(
			$input['designToken'],
			$input['pages'],
			$input['siteDesignContract'] ?? null,
			$input['shellComposition'] ?? null
		);
	}

	public static function inspect_composition( $input ) {
		if ( ! self::can_use() || ! is_array( $input ) ||
			array_keys( $input ) !== array( 'id' ) ||
			! is_string( $input['id'] ) ||
			! preg_match( '/^[a-z0-9-]{1,64}$/', $input['id'] ) ) {
			return new WP_Error( 'wphave_mcp_composition_invalid', 'The site composition request is invalid.' );
		}
		return WPHAVE_AI_MCP_Free_Design_Grammar::composition_detail( $input['id'] );
	}

	public static function prepare( $input ) {
		if ( ! self::can_use() || ! is_array( $input ) ||
			! is_string( $input['requestId'] ?? null ) ||
			! is_int( $input['targetPostId'] ?? null ) ||
			! is_array( $input['batch'] ?? null ) ) {
			return new WP_Error( 'wphave_mcp_free_invalid', 'The job request is invalid.' );
		}
		$binding_fields = array( 'projectId', 'pageKey', 'expectedProjectRevision' );
		$bound_fields = array_filter( $binding_fields, static function ( $field ) use ( $input ) {
			return array_key_exists( $field, $input );
		} );
		if ( count( $bound_fields ) !== 0 &&
			( count( $bound_fields ) !== 3 ||
			! is_string( $input['projectId'] ) ||
			! is_string( $input['pageKey'] ) ||
			! is_int( $input['expectedProjectRevision'] ) ) ) {
			return new WP_Error( 'wphave_mcp_project_invalid', 'The project binding is invalid.' );
		}
		$has_links = isset( $input['batch']['projectId'] );
		if ( $has_links ) {
			$source_post = get_post( $input['targetPostId'] );
			$project = 3 === count( $bound_fields ) ?
				WPHAVE_AI_MCP_Free_Site_Project_Store::status( $input['projectId'] ) :
				new WP_Error( 'wphave_mcp_project_invalid', 'Project binding is required for links.' );
			$source_matches = false;
			if ( ! is_wp_error( $project ) ) {
				foreach ( $project['pages'] as $page ) {
					$source_matches = $source_matches ||
						( $page['pageKey'] === $input['pageKey'] &&
						$page['targetPostId'] === $input['targetPostId'] );
				}
			}
			if ( is_wp_error( $project ) || $input['batch']['projectId'] !== $input['projectId'] ||
				! $source_post instanceof WP_Post || 'draft' !== $source_post->post_status ||
				'' !== trim( $source_post->post_content ) ||
				$project['revision'] !== $input['expectedProjectRevision'] ||
				! $source_matches ) {
				return new WP_Error( 'wphave_mcp_project_invalid', 'The project link binding is unavailable.' );
			}
		}
		$prepared = WPHAVE_AI_MCP_Free_Job_Store::prepare(
			$input['requestId'],
			$input['targetPostId'],
			$input['batch']
		);
		if ( is_wp_error( $prepared ) || 0 === count( $bound_fields ) ) {
			return $prepared;
		}
		$project = WPHAVE_AI_MCP_Free_Site_Project_Store::bind_job(
			$input['projectId'],
			$input['expectedProjectRevision'],
			$input['pageKey'],
			$prepared['jobId']
		);
		if ( is_wp_error( $project ) ) {
			return $project;
		}
		$prepared['project'] = $project;
		return $prepared;
	}

	public static function status( $input ) {
		if ( ! self::can_use() || ! is_array( $input ) || ! is_string( $input['jobId'] ?? null ) ) {
			return new WP_Error( 'wphave_mcp_free_forbidden', 'The job is unavailable.' );
		}
		return WPHAVE_AI_MCP_Free_Job_Store::status( $input['jobId'] );
	}

	public static function revise( $input ) {
		if ( ! self::can_use() || ! is_array( $input ) ||
			! is_string( $input['requestId'] ?? null ) ||
			! is_string( $input['parentJobId'] ?? null ) ||
			! is_string( $input['parentResultHash'] ?? null ) ||
			! is_array( $input['changes'] ?? null ) ) {
			return new WP_Error( 'wphave_mcp_free_revision_invalid', 'The revision request is invalid.' );
		}
		return WPHAVE_AI_MCP_Free_Job_Store::prepare_revision(
			$input['requestId'],
			$input['parentJobId'],
			$input['parentResultHash'],
			$input['changes']
		);
	}

	public static function create_site_project( $input ) {
		if ( ! self::can_use() || ! is_array( $input ) ||
			! is_string( $input['requestId'] ?? null ) ||
			! is_int( $input['homePostId'] ?? null ) ||
			! is_int( $input['servicesPostId'] ?? null ) ) {
			return new WP_Error( 'wphave_mcp_project_invalid', 'The project request is invalid.' );
		}
		return WPHAVE_AI_MCP_Free_Site_Project_Store::create(
			$input['requestId'],
			$input['homePostId'],
			$input['servicesPostId']
		);
	}

	public static function site_project_status( $input ) {
		if ( ! self::can_use() || ! is_array( $input ) ||
			! is_string( $input['projectId'] ?? null ) ) {
			return new WP_Error( 'wphave_mcp_project_forbidden', 'The project is unavailable.' );
		}
		return WPHAVE_AI_MCP_Free_Site_Project_Store::status( $input['projectId'] );
	}

	public static function prepare_site_header( $input ) {
		if ( ! self::can_manage_shell() || ! is_array( $input ) ||
			! is_string( $input['requestId'] ?? null ) ||
			! is_string( $input['projectId'] ?? null ) ||
			! is_int( $input['expectedProjectRevision'] ?? null ) ||
			! is_string( $input['brand'] ?? null ) ) {
			return new WP_Error( 'wphave_mcp_shell_invalid', 'The header request is invalid.' );
		}
		return WPHAVE_AI_MCP_Free_Site_Shell_Proposal::prepare(
			$input['requestId'],
			$input['projectId'],
			$input['expectedProjectRevision'],
			$input['brand']
		);
	}

	public static function site_header_status( $input ) {
		if ( ! self::can_manage_shell() || ! is_array( $input ) ||
			! is_string( $input['jobId'] ?? null ) ) {
			return new WP_Error( 'wphave_mcp_shell_forbidden', 'The header proposal is unavailable.' );
		}
		return WPHAVE_AI_MCP_Free_Site_Shell_Proposal::status( $input['jobId'] );
	}

	public static function prepare_site_footer( $input ) {
		if ( ! self::can_manage_shell() || ! is_array( $input ) ||
			! is_string( $input['requestId'] ?? null ) ||
			! is_string( $input['projectId'] ?? null ) ||
			! is_int( $input['expectedProjectRevision'] ?? null ) ||
			! is_string( $input['brand'] ?? null ) ||
			! is_string( $input['description'] ?? null ) ||
			! is_string( $input['copyright'] ?? null ) ) {
			return new WP_Error( 'wphave_mcp_shell_invalid', 'The footer request is invalid.' );
		}
		return WPHAVE_AI_MCP_Free_Site_Shell_Proposal::prepare_footer(
			$input['requestId'],
			$input['projectId'],
			$input['expectedProjectRevision'],
			$input['brand'],
			$input['description'],
			$input['copyright']
		);
	}

	public static function site_footer_status( $input ) {
		if ( ! self::can_manage_shell() || ! is_array( $input ) ||
			! is_string( $input['jobId'] ?? null ) ) {
			return new WP_Error( 'wphave_mcp_shell_forbidden', 'The footer proposal is unavailable.' );
		}
		return WPHAVE_AI_MCP_Free_Site_Shell_Proposal::status( $input['jobId'], 'footer' );
	}
}
