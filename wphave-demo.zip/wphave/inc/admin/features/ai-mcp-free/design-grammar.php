<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/creation-config.php';
require_once __DIR__ . '/section-catalog.php';
require_once __DIR__ . '/button-recipes.php';
require_once __DIR__ . '/line-recipes.php';
require_once __DIR__ . '/spacer-recipes.php';
require_once __DIR__ . '/heading-recipes.php';
require_once __DIR__ . '/custom-css.php';
require_once __DIR__ . '/background-image-layer.php';
require_once __DIR__ . '/overlap-recipe.php';
require_once __DIR__ . '/spatial-callout-recipe.php';

/** Versioned MCP subset; the product Inspector and editing engine remain authoritative. */
final class WPHAVE_AI_MCP_Free_Design_Grammar {
	private static function specification(): ?array {
		$path = __DIR__ . '/design-grammar-v2.json';
		if ( ! is_readable( $path ) ) {
			return null;
		}
		$json = file_get_contents( $path );
		$spec = is_string( $json ) ? json_decode( $json, true ) : null;
		return is_array( $spec ) && ( $spec['schemaVersion'] ?? null ) === 2 ? $spec : null;
	}

	public static function catalog() {
		$spec = self::specification();
		$creation_config = WPHAVE_AI_MCP_Free_Creation_Config::get();
		$button_recipes = WPHAVE_AI_MCP_Free_Button_Recipes::specification();
		$line_recipes = WPHAVE_AI_MCP_Free_Line_Recipes::specification();
		$spacer_recipes = WPHAVE_AI_MCP_Free_Spacer_Recipes::specification();
		$heading_recipes = WPHAVE_AI_MCP_Free_Heading_Recipes::specification();
		if ( null === $spec || null === $creation_config || null === $button_recipes || null === $line_recipes || null === $spacer_recipes || null === $heading_recipes || ! class_exists( 'WPHAVE_Global_Data' ) ) {
			return new WP_Error( 'wphave_mcp_free_design_unavailable', 'Design options are unavailable.' );
		}
		$globals = WPHAVE_Global_Data::get_base();
		$line_options = WPHAVE_AI_MCP_Free_Line_Recipes::options();
		if ( ! is_array( $globals ) || null === $line_options ) {
			return new WP_Error( 'wphave_mcp_free_design_unavailable', 'Design options are unavailable.' );
		}
		$size_path = __DIR__ . '/typography-size-keys.json';
		$sizes = is_readable( $size_path ) ? json_decode( file_get_contents( $size_path ), true ) : null;
		if ( ! is_array( $sizes ) || ! is_array( $sizes['heading'] ?? null ) ||
			! is_array( $sizes['text'] ?? null ) ) {
			return new WP_Error( 'wphave_mcp_free_design_unavailable', 'Design options are unavailable.' );
		}
		$reference = array(
			'grammar' => $spec,
			'advancedEffectsAllowed' => WPHAVE_AI_MCP_Free_Background_Image_Layer::allowed(),
			'creationConfig' => $creation_config,
			'sectionCatalog' => WPHAVE_AI_MCP_Free_Section_Catalog::definitions(),
			'buttonRecipes' => $button_recipes,
			'lineRecipes' => $line_recipes,
			'spacerRecipes' => $spacer_recipes,
			'headingRecipes' => $heading_recipes,
			'typographySizes' => $sizes,
			'blockAlignment' => array( 'none', 'left', 'center', 'right' ),
			'colors' => $globals['colors'] ?? array(),
			'gapSizes' => $globals['tokens']['gapSizes'] ?? array(),
			'paddingSizes' => $globals['tokens']['paddingSizes'] ?? array(),
			'marginSizes' => $globals['tokens']['marginSizes'] ?? array(),
		);
		if ( WPHAVE_AI_MCP_Overlap_Recipe::allowed() ) {
			$reference['overlapRecipeAllowed'] = true;
		}
		if ( WPHAVE_AI_MCP_Spatial_Callout_Recipe::allowed() ) {
			$reference['spatialCalloutRecipeAllowed'] = true;
		}
		$json = wp_json_encode( $reference );
		if ( ! is_string( $json ) ) {
			return new WP_Error( 'wphave_mcp_free_design_unavailable', 'Design options are unavailable.' );
		}
		$operations = array();
		foreach ( $spec['groupOperations'] as $rule ) {
			if ( 'background.layers' === $rule['path'] && ! WPHAVE_AI_MCP_Free_Background_Image_Layer::allowed() ) {
				continue;
			}
			$values = $rule['values'] ?? null;
			if ( isset( $rule['tokenGroup'], $rule['cssVariablePrefix'] ) ) {
				$tokens = $rule['tokenGroup'] === 'colors' ?
					( $globals['colors'] ?? null ) :
					( $globals['tokens'][ $rule['tokenGroup'] ] ?? null );
				if ( ! is_array( $tokens ) ) {
					return new WP_Error( 'wphave_mcp_free_design_unavailable', 'Design options are unavailable.' );
				}
				$values = ! empty( $rule['includeZero'] ) ? array( '0' ) : array();
				foreach ( array_keys( $tokens ) as $key ) {
					if ( ! is_string( $key ) || ! preg_match( '/^[A-Za-z0-9-]+$/', $key ) ) {
						return new WP_Error( 'wphave_mcp_free_design_unavailable', 'Design options are unavailable.' );
					}
					$value = 'var(' . $rule['cssVariablePrefix'] . $key . ')';
					$values[] = ! empty( $rule['topOnly'] ) ? $value . ' 0 0 0' : $value;
				}
			}
			if ( ! is_array( $values ) ) {
				return new WP_Error( 'wphave_mcp_free_design_unavailable', 'Design options are unavailable.' );
			}
			$operations[] = array(
				'path' => $rule['path'],
				'devices' => $rule['devices'],
				'values' => $values,
			);
		}
		$catalog = array(
			'schemaVersion' => 2,
			'fingerprint' => hash( 'sha256', $json ),
			'creationConfig' => $creation_config,
			'buttonCatalog' => WPHAVE_AI_MCP_Free_Button_Recipes::options(),
			'lineCatalog' => $line_options,
			'spacerCatalog' => WPHAVE_AI_MCP_Free_Spacer_Recipes::options(),
			'headingCatalog' => WPHAVE_AI_MCP_Free_Heading_Recipes::options(),
			'groupOperations' => $operations,
			'imageOperations' => $spec['imageOperations'] ?? array(),
			'overlapRecipe' => WPHAVE_AI_MCP_Overlap_Recipe::allowed() ? array(
				'description' => 'Two direct Images in one stacked Group; apply these exact operations to the second Image.',
				'operations' => WPHAVE_AI_MCP_Overlap_Recipe::operations(),
			) : null,
			'spatialCalloutRecipe' => WPHAVE_AI_MCP_Spatial_Callout_Recipe::allowed() ? array(
				'description' => 'One text Group beside a positioned Image Group with one circular label; Tablet and Mobile reset to linear flow.',
				'textOperations' => WPHAVE_AI_MCP_Spatial_Callout_Recipe::text_operations(),
				'mediaOperations' => WPHAVE_AI_MCP_Spatial_Callout_Recipe::media_operations(),
				'badgeOperations' => WPHAVE_AI_MCP_Spatial_Callout_Recipe::badge_operations(),
			) : null,
			'textOperations' => array(
				'wphave/heading' => self::text_size_options( $sizes['heading'] ),
				'wphave/paragraph' => self::text_size_options( $sizes['text'] ),
			),
			'textColorOperation' => array(
				'path' => 'colors.text',
				'devices' => array( 'Desktop' ),
				'values' => array_map( static function ( $key ) {
					return 'var(--wphave-site-color-' . $key . ')';
				}, array_keys( $globals['colors'] ?? array() ) ),
			),
		);
		if ( ! WPHAVE_AI_MCP_Overlap_Recipe::allowed() ) {
			unset( $catalog['overlapRecipe'] );
		}
		if ( ! WPHAVE_AI_MCP_Spatial_Callout_Recipe::allowed() ) {
			unset( $catalog['spatialCalloutRecipe'] );
		}
		return $catalog;
	}

	public static function discovery() {
		$catalog = self::catalog();
		if ( is_wp_error( $catalog ) ) {
			return $catalog;
		}
		$media_options = WPHAVE_AI_MCP_Free_Media::options();
		$catalog['batchContract'] = self::batch_contract( $catalog['fingerprint'], $media_options, $catalog['creationConfig'] );
		$catalog['siteDesignContractV1'] = array(
			'when' => 'Optional for legacy plans; required with designPlan version 3 or 4.',
			'planningField' => 'free-page-plan-layout.siteDesignContract',
			'creationField' => 'website-create-drafts.designPlan.siteDesignContract',
			'fields' => array(
				'version' => 1,
				'siteDesignFingerprint' => 'Current site-design-identity fingerprint.',
				'colorRoles' => 'List of two to eight role names from site-design-identity.colors, allowed for explicit text and Group background operations.',
				'headingSizes' => 'List of one to eight size names from site-design-identity.typography.headingSizes.',
				'button' => array( 'kind' => 'buttonCatalog kind', 'size' => 'buttonCatalog size', 'variant' => 'buttonCatalog variant' ),
				'mainHeadings' => 'Map every pageKey to exactly one native Heading node key with heading.level=h1.',
				'reviewClaims' => array(
					'layoutPrinciples' => 'One to four supported design principles for browser review.',
					'responsiveReadingOrder' => 'Short description of the intended mobile reading order.',
				),
			),
		);
		$catalog['siteShellCompositionV1'] = array(
			'when' => 'Optional; use designPlan version 4 when a private composed shell is required.',
			'planningField' => 'free-page-plan-layout.shellComposition',
			'creationField' => 'website-create-drafts.designPlan.shellComposition',
			'prepareAbility' => 'wphave/website-shell-composition-prepare',
			'previewAbility' => 'wphave/website-shell-composition-preview',
			'shape' => array(
				'version' => 1,
				'header' => array( 'nodes' => 'flat ordered native shell nodes' ),
				'footer' => array( 'nodes' => 'flat ordered native shell nodes' ),
			),
			'nodeNames' => array( 'wphave/group', 'wphave/paragraph', 'wphave/navigation' ),
			'nodeRule' => 'One root Group and exactly one Navigation per part. Group and Paragraph use the listed native design operations. No css, HTML, arbitrary block attributes or Pro positioning.',
			'navigationRule' => 'Navigation links name every project page exactly once; optional external links require public https URLs. Settings specify collapseBehavior, collapseBreakpoint, panelType, toggleStyle and orientation.',
		);
		$catalog['blockAlignment'] = array(
			'field' => 'node.alignment',
			'values' => array( 'none', 'left', 'center', 'right' ),
			'allowedNames' => array( 'wphave/group', 'wphave/heading', 'wphave/paragraph', 'wphave/button', 'wphave/image', 'wphave/line' ),
			'rule' => 'Optional native Block Alignment on Desktop. Omit the field or use none for the default. Spacer does not support alignment.',
		);
		$catalog['customCss'] = WPHAVE_AI_MCP_Free_Custom_CSS::contract();
		$catalog['mediaOptions'] = $media_options;
		$catalog['compositionAtlas'] = $catalog['creationConfig']['guidance']['compositionAtlas'] ?
			WPHAVE_AI_MCP_Free_Composition_Atlas::collect( array_values( array_unique( array_merge(
				array_column( $catalog['groupOperations'], 'path' ),
				array_column( $catalog['imageOperations'], 'path' ),
				array( 'text.typeface.size', 'colors.text' )
			) ) ) ) : array();
		$catalog['sectionCatalog'] = 'off' === $catalog['creationConfig']['catalog']['mode'] ?
			array() : WPHAVE_AI_MCP_Free_Section_Catalog::definitions();
		$catalog['sectionCatalogExample'] = 'off' === $catalog['creationConfig']['catalog']['mode'] ?
			null : WPHAVE_AI_MCP_Free_Section_Catalog::example();
		$catalog['websiteProjectLink'] = array(
			'nodeName' => 'wphave/button',
			'nodeField' => 'linkTarget',
			'kind' => 'projectPage',
			'pageKeySource' => 'website-create-drafts.pages[].pageKey',
			'maxPerPage' => 8,
			'urlsAccepted' => false,
		);
		$catalog['compositionPrinciples'] = $catalog['creationConfig']['guidance']['designHints'] ? array(
			array(
				'id' => 'editorial-image-text',
				'source' => 'mason-atelier, wellness',
				'guidance' => 'Pair an image and a copy group in a responsive two-column Grid; establish a clear headline scale and mobile reading order.',
			),
			array(
				'id' => 'alternating-section-rhythm',
				'source' => 'signal-studio',
				'guidance' => 'Alternate light and accent surfaces deliberately. Apply background.color.base and section padding to the outer Group; let the inner Grid and copy Group use gaps and alignment without duplicate padding.',
			),
			array(
				'id' => 'responsive-offer-grid',
				'source' => 'mason-atelier, wellness',
				'guidance' => 'Use nested groups as distinct cards in a Grid that becomes one column on mobile.',
			),
			array(
				'id' => 'immersive-opening-and-cta',
				'source' => 'ember-coffee, signal-studio',
				'guidance' => 'Give the opening a dominant image or statement and close with a contrasting, focused next action.',
			),
		) : array();
		$catalog['designPlanGuidance'] = array(
			'For a new coordinated website, call site-design-identity and provide Site Design Contract v1 in free-page-plan-layout and designPlan version 3. Bind its fingerprint, approved color roles, heading sizes, common Button recipe, and one native h1 Heading key per page. Legacy version 1 and 2 plans remain valid.',
			'For website-create-drafts, a Button may link to another page in the same project by node.linkTarget={kind:"projectPage",pageKey:"target-key"}. The server resolves actual post IDs and finalizes native links; do not supply a URL.',
		);
		if ( $catalog['creationConfig']['guidance']['selfPlanning'] ) {
			$catalog['designPlanGuidance'][] = 'For a short website brief, independently infer the audience, site goal, visual direction and likely visitor action. Plan the page hierarchy, section sequence, image subjects, typography scale, spacing rhythm and responsive reading order before composing native blocks. Make these design decisions yourself; do not require the user to specify a layout or follow a fixed template.';
		}
		if ( $catalog['creationConfig']['guidance']['designHints'] ) {
			$catalog['designPlanGuidance'][] = 'Before creating a website, record brand direction, target audience, chosen media IDs, each page purpose and action, and a section-by-section layout with responsive intent.';
			$catalog['designPlanGuidance'][] = 'For each section, decide separately whether its outer Group needs a colored background and section padding. Do not apply padding automatically to every nested copy Group.';
		}
		if ( 'off' !== $catalog['creationConfig']['catalog']['mode'] ) {
			$catalog['designPlanGuidance'][] = 'Choose section types and variants from sectionCatalog, then add type and variant to each batch.sections item. The server validates the chosen recipe against the native block tree.';
		}
		if ( $catalog['creationConfig']['checks']['distinctSectionPrinciples'] ) {
			$catalog['designPlanGuidance'][] = 'Use at least two distinct composition principles per page. Principles are references, not fixed markup.';
		}
		if ( $catalog['creationConfig']['checks']['distinctPageRhythm'] ) {
			$catalog['designPlanGuidance'][] = 'Vary the order of section principles across pages.';
		}
		if ( $catalog['creationConfig']['checks']['compositionVariety'] ) {
			$catalog['designPlanGuidance'][] = 'Give every page a deliberate visual treatment beyond a basic text stack.';
		}
		if ( $catalog['creationConfig']['guidance']['compositionAtlas'] ) {
			$catalog['designPlanGuidance'][] = 'Use compositionAtlas to study bundled native section patterns. availableMcpPathsUsed are executable; otherNativePathsUsed are reference-only.';
		}
		if ( $catalog['creationConfig']['guidance']['mediaImport'] ) {
			$catalog['designPlanGuidance'][] = 'When suitable images are missing, import licensed images with site-image-import and refresh the design options.';
		}
		if ( $catalog['creationConfig']['guidance']['mediaGeneration'] ) {
			$catalog['designPlanGuidance'][] = 'When the page benefits from original imagery, generate it with site-image-generate and refresh the design options before composing. Choose the imagery for the actual brief.';
		}
		if ( $catalog['creationConfig']['guidance']['visualReview'] ) {
			$catalog['designPlanGuidance'][] = 'After saving, inspect wide desktop, desktop, tablet and mobile screenshots. A passing geometry report is not a design acceptance.';
		}
		if ( WPHAVE_AI_MCP_Free_Custom_CSS::available() ) {
			$catalog['designPlanGuidance'][] = 'Optional node.css can refine supported blocks with scoped, responsive CSS. Use $block as the local selector and @media for mobile adjustments. Keep the native Group hierarchy and content attributes authoritative; use CSS for visual treatment where the listed design operations do not express the intended result.';
		}
		if ( WPHAVE_AI_MCP_Free_Button_Recipes::icon_allowed() ) {
			$catalog['designPlanGuidance'][] = 'Icon Buttons are available on this Pro site. If buttonCatalog.kinds contains icon, you may choose an icon recipe from buttonCatalog; do not infer that Pro access is missing.';
		}
		if ( ! $catalog['creationConfig']['checks']['textContrast'] ) {
			$catalog['designPlanGuidance'][] = 'The automated text contrast check is disabled for this creation configuration. Inspect text legibility in the rendered previews.';
		} else {
			$catalog['designPlanGuidance'][] = 'The automated text contrast check requires at least a 4.5 ratio for Heading and Paragraph colors against their nearest section background.';
		}
		return $catalog;
	}

	public static function composition_detail( string $id ) {
		$catalog = self::catalog();
		if ( is_wp_error( $catalog ) ) {
			return $catalog;
		}
		$paths = array_values( array_unique( array_merge(
			array_column( $catalog['groupOperations'], 'path' ),
			array_column( $catalog['imageOperations'], 'path' ),
			array( 'text.typeface.size', 'colors.text' )
		) ) );
		$composition = WPHAVE_AI_MCP_Free_Composition_Atlas::collect( $paths, $id );
		return $composition[0] ?? new WP_Error( 'wphave_mcp_composition_unknown', 'The site composition is unavailable.' );
	}

	private static function batch_contract( string $fingerprint, array $media_options, array $config ): array {
		$example = array(
			'version' => 2,
			'designFingerprint' => $fingerprint,
			'sections' => array( array(
				'key' => 'intro',
				'layout' => isset( $media_options[0] ) ? 'grid' : 'flex',
				'purpose' => 'Introduce the page and its main message',
			) ),
			'nodes' => array(
				array(
					'key' => 'intro',
					'parentKey' => null,
					'name' => 'wphave/group',
					'attributes' => new stdClass(),
					'design' => isset( $media_options[0] ) ? array(
						array( 'device' => 'Desktop', 'path' => 'layout.type', 'value' => 'grid' ),
						array( 'device' => 'Desktop', 'path' => 'layout.grid.columns', 'value' => 2 ),
						array( 'device' => 'Mobile', 'path' => 'layout.grid.columns', 'value' => 1 ),
					) : array(
						array( 'device' => 'Desktop', 'path' => 'layout.type', 'value' => 'flex' ),
						array( 'device' => 'Desktop', 'path' => 'layout.flex.flexDirection', 'value' => 'column' ),
					),
				),
				array(
					'key' => 'intro_copy',
					'parentKey' => 'intro',
					'name' => 'wphave/group',
					'attributes' => new stdClass(),
					'design' => array(
						array( 'device' => 'Desktop', 'path' => 'layout.type', 'value' => 'flex' ),
						array( 'device' => 'Desktop', 'path' => 'layout.flex.flexDirection', 'value' => 'column' ),
					),
				),
				array(
					'key' => 'intro_title',
					'parentKey' => 'intro_copy',
					'name' => 'wphave/heading',
					'attributes' => array( 'content' => 'A clear page heading' ),
				),
			),
		);
		if ( isset( $media_options[0] ) ) {
			$example['nodes'][] = array(
				'key' => 'intro_image',
				'parentKey' => 'intro',
				'name' => 'wphave/image',
				'attributes' => array(
					'image' => $media_options[0]['id'],
					'alt' => $media_options[0]['alt'],
				),
			);
		}
		if ( 'required' === $config['catalog']['mode'] ) {
			$recipe = WPHAVE_AI_MCP_Free_Section_Catalog::example();
			$example['sections'] = array( $recipe['section'] );
			$example['nodes'] = $recipe['nodes'];
		}
		$composition_guidance = $config['guidance']['designHints'] ? array(
			'Plan the page as semantic sections before creating nodes. Choose a distinct visual hierarchy and spacing rhythm for the actual brief; the example is illustrative, not a template.',
			'Reserve display-size headings for a wide Hero or full-width statement. In a two- or three-column layout, choose a smaller heading size that fits its actual column width; shorten or deliberately break long copy before saving.',
			'Give adjacent plain sections a visible vertical rhythm. Place a fluid Spacer root block between section Groups when neither section background nor section padding creates sufficient separation. Do not use inner copy Group padding to simulate section spacing.',
			'Before saving a section with a colored background, choose a readable foreground token for every Heading and Paragraph inside it. Even when the automated text contrast check is disabled, inspect the actual rendered colors in both previews and correct weak contrast.',
			'Use parentKey to place a text Group and an Image as siblings in a two-column Grid; put Heading, Paragraph and Button inside the text Group. Other compositions may use nested Flex or Grid Groups.',
			'Use the outer Group for section-level background.color.base and padding only when the section needs an inset surface. Use the Grid Group for columns and gaps. Use the copy Group for text order and gap; omit its padding operation unless it is an intentional colored card or inset panel.',
			'background.color.base accepts only a listed active site color token. A plain copy Group on the page background normally needs neither a background operation nor padding.',
			'Omit dimensions.spacing.padding when no inset is intended. The string "0" is an explicit zero-padding reset, not a default operation; JSON null is invalid.',
			'Keep parent Groups before their children in the flat list. A child Group creates a new layout context; a Heading, Paragraph, Button or Image belongs to its direct parent Group.',
			'For each multi-column section, set Desktop layout.grid.columns and Mobile layout.grid.columns=1. Inspect the rendered desktop and mobile result before judging the composition.',
		) : array();
		if ( $config['guidance']['selfPlanning'] ) {
			$composition_guidance[] = 'For a brief that names only a topic, first make your own concise design plan: audience and goal; visual direction; section order and purpose; suitable original images; hierarchy of headings and copy; CTA choice; vertical spacing; desktop and mobile arrangement. Then select the native blocks and operations that realize that plan. Treat the catalog example as syntax only, not as a page design.';
		}
		if ( $config['guidance']['mediaGeneration'] ) {
			$composition_guidance[] = 'Original images can be created with site-image-generate, then selected from refreshed mediaOptions. Choose whether and where imagery helps the page.';
		}
		if ( $config['guidance']['mediaImport'] ) {
			$composition_guidance[] = 'Use only mediaOptions images. If no suitable image is available, import a licensed image with site-image-import and refresh this catalog before composing. Do this before the complete-draft call. If the brief requires images, do not present a text-only draft as complete.';
		}
		return array(
			'format' => 'flat ordered node list; a parent group must precede its children',
			'maxNodes' => 80,
			'maxEncodedBytes' => 32768,
			'nodeKeys' => array( 'key', 'parentKey', 'name', 'attributes', 'design', 'linkTarget', 'button', 'line', 'spacer', 'heading', 'css', 'alignment' ),
			'sectionPlan' => array(
				'field' => 'batch.sections',
				'catalogMode' => $config['catalog']['mode'],
				'item' => array( 'key' => 'root Group key', 'layout' => 'stacked|grid|flex', 'purpose' => 'short section goal', 'type' => 'optional sectionCatalog ID', 'variant' => 'required with type' ),
				'rule' => 'One ordered item per root Group; semantic page content belongs to these Groups. Optional root Spacer blocks may appear between Groups but do not count as sections. Layout must match the first design operation of the corresponding Group.',
			),
			'allowedNames' => array( 'wphave/group', 'wphave/heading', 'wphave/paragraph', 'wphave/button', 'wphave/image', 'wphave/line', 'wphave/spacer' ),
			'attributeShapes' => array(
				'wphave/group' => new stdClass(),
				'wphave/heading' => array( 'content' => 'string' ),
				'wphave/paragraph' => array( 'content' => 'string' ),
				'wphave/button' => array( 'content' => 'string' ),
				'wphave/image' => array( 'image' => 'integer mediaOptions.id', 'alt' => 'exact mediaOptions.alt' ),
				'wphave/line' => new stdClass(),
				'wphave/spacer' => new stdClass(),
			),
			'projectButtonLink' => array(
				'batchProjectId' => 'UUID from site-project-status; requires matching projectId, pageKey and expectedProjectRevision in prepare',
				'buttonLinkTarget' => array( 'kind' => 'projectPage', 'pageKey' => 'home or services' ),
				'rule' => 'Only a different page in the same project; server resolves the native internal Button link.',
			),
			'buttonRecipe' => array(
				'field' => 'node.button',
				'nodeName' => 'wphave/button',
				'rule' => 'Use a kind, size and variant listed in buttonCatalog. If buttonCatalog.kinds includes icon, the current site already permits Icon Buttons. Keep attributes.content as the accessible name even when hidden visually.',
			),
			'lineRecipe' => array(
				'field' => 'node.line',
				'nodeName' => 'wphave/line',
				'rule' => 'Choose a size from lineCatalog and optionally one of its current site color tokens. A Line has empty attributes and no design operations.',
			),
			'spacerRecipe' => array(
				'field' => 'node.spacer',
				'nodeName' => 'wphave/spacer',
				'rule' => 'Choose one fluid aspect-ratio size from spacerCatalog. A Spacer has empty attributes and no design operations. Put it as a root block between section Groups; it is not itself a semantic section.',
			),
			'headingRecipe' => array(
				'field' => 'node.heading',
				'nodeName' => 'wphave/heading',
				'rule' => 'Use heading={kind:"semantic",level:"h1".."h6"} for an ordinary native Heading whose HTML level is independent of text.typeface.size. Existing text-stretch recipe remains available with two to four lines; attributes.content must join those lines and no font-size design operation is allowed with text-stretch.',
			),
			'backgroundImageLayer' => WPHAVE_AI_MCP_Free_Background_Image_Layer::allowed() ? array(
				'path' => 'background.layers',
				'device' => 'Desktop',
				'rule' => 'One new Group layer only: media.image.type=custom, data.id from mediaOptions, data.focal={top:50,left:50}, fit=cover; overlay={mode:controlled,type:cover,axis:0%,color:var(--wphave-site-color-overlay),opacity:string from 0.30 to 0.70}. No URL, filters, extra keys or Mobile override.',
			) : null,
			'layoutGuidance' => array(
				'For a native vertical image offset, set Group Desktop dimensions.spacing.margin to one catalog top-only token and pair it with Mobile dimensions.spacing.margin=0 on the same Group. This shifts flow content; it does not overlap layers.',
				'Auto Grid columns may reduce with container width; keepColumns=nowrap retains the configured count.',
				'A Grid nested in a Flex column whose items align to start needs Desktop dimensions.width.custom=100% to avoid intrinsic-width collapse.',
				'Give responsive Grids a Mobile layout.grid.columns override and inspect the rendered result at both widths.',
				'Four-column Grids and reverse Flex directions are available, but inspect reading order and heading width at wide, desktop, tablet and mobile sizes.',
			),
			'compositionGuidance' => $composition_guidance,
			'rules' => array(
				'Use version=2 and copy designFingerprint from this response.',
				'Each key is unique, lowercase, 1–32 characters; parentKey is null or an earlier group key.',
				'Groups have empty attributes and 1–8 design operations, starting with Desktop layout.type; the licensed spatialCalloutRecipe badge is the sole exact-operation exception. Use batch.sections to bind each outer Group to its section purpose and layout. If type and variant are set, match the sectionCatalog recipe exactly.',
				'For extra fluid spacing between sections, place one root Spacer between two root Groups and include batch.sections. Do not put a Spacer before the first or after the last section.',
				'Choose stacked for a vertical sequence, equal-column Grid for balanced peers, or Flex for a row with intentionally varied item widths. If Flex uses Desktop no-wrap and no-shrink, set a Mobile column direction and inspect overflow.',
				'Image attributes must use the exact keys image and alt; image is a mediaOptions id, never id or mediaId.',
				'Design operations are ordered objects with device, path, value; Mobile baselines follow Desktop.',
				'Use only operation paths and values listed in this response. Do not send nested blocks. Optional node.css is available only when customCss.enabled is true; it is scoped and compiled by the native WPHAVE block CSS compiler.',
				'Optional node.alignment uses the existing Block Alignment control: none, left, center or right. It is available on every listed block except Spacer.',
				'For a Button link, add batch.projectId and node.linkTarget, using the project status pageKey; never send a URL.',
				'Omit batch.projectId when the batch has no Button linkTarget; a project-bound page without a link still uses projectId, pageKey and expectedProjectRevision in the prepare arguments.',
			),
			'example' => $example,
		);
	}

	private static function text_size_options( array $keys ): array {
		return array(
			'path' => 'text.typeface.size',
			'devices' => array( 'Desktop', 'Mobile' ),
			'values' => array_map( static function ( $key ) {
				return array( 'type' => $key );
			}, array_values( array_filter( $keys, static function ( $key ) {
				return is_string( $key ) && 'custom' !== $key;
			} ) ) ),
		);
	}

	public static function valid_text_operations( string $name, array $operations ): bool {
		$catalog = self::catalog();
		$rule = is_wp_error( $catalog ) ? null : ( $catalog['textOperations'][ $name ] ?? null );
		$color_rule = is_wp_error( $catalog ) ? null : ( $catalog['textColorOperation'] ?? null );
		if ( ! is_array( $rule ) || count( $operations ) < 1 || count( $operations ) > 3 ) {
			return false;
		}
		$seen = array();
		foreach ( $operations as $operation ) {
			if ( ! is_array( $operation ) || array_keys( $operation ) !== array( 'device', 'path', 'value' ) ||
				! is_string( $operation['device'] ) || ! is_string( $operation['path'] ) ||
				isset( $seen[ $operation['device'] . ':' . $operation['path'] ] ) ) {
				return false;
			}
			if ( $operation['path'] === $rule['path'] ) {
				if ( ! in_array( $operation['device'], $rule['devices'], true ) ||
					! is_array( $operation['value'] ) || ! in_array( $operation['value'], $rule['values'], true ) ||
					( $operation['device'] === 'Mobile' && ! isset( $seen['Desktop:' . $rule['path']] ) ) ) {
					return false;
				}
			} elseif ( in_array( $name, array( 'wphave/heading', 'wphave/paragraph' ), true ) &&
				$operation['path'] === 'colors.text' ) {
				if ( ! is_array( $color_rule ) || $operation['device'] !== 'Desktop' ||
					! is_string( $operation['value'] ) || ! in_array( $operation['value'], $color_rule['values'], true ) ) {
					return false;
				}
			} else {
				return false;
			}
			$seen[ $operation['device'] . ':' . $operation['path'] ] = true;
		}
		return true;
	}

	public static function valid_group_operations( array $operations ): bool {
		if ( WPHAVE_AI_MCP_Spatial_Callout_Recipe::is_media_operations( $operations ) ||
			WPHAVE_AI_MCP_Spatial_Callout_Recipe::is_badge_operations( $operations ) ) {
			return true;
		}
		$catalog = self::catalog();
		if ( is_wp_error( $catalog ) || count( $operations ) < 1 || count( $operations ) > 8 ||
			! in_array( $operations[0], array(
				array( 'device' => 'Desktop', 'path' => 'layout.type', 'value' => 'stacked' ),
				array( 'device' => 'Desktop', 'path' => 'layout.type', 'value' => 'flex' ),
				array( 'device' => 'Desktop', 'path' => 'layout.type', 'value' => 'grid' ),
			), true ) ) {
			return false;
		}
		$layout_type = $operations[0]['value'];
		$seen = array();
		foreach ( $operations as $operation ) {
			if ( ! is_array( $operation ) || array_keys( $operation ) !== array( 'device', 'path', 'value' ) ||
				! is_string( $operation['device'] ) || ! is_string( $operation['path'] ) ||
				! ( is_string( $operation['value'] ) || is_int( $operation['value'] ) ||
					( 'background.layers' === $operation['path'] && is_array( $operation['value'] ) ) ) ||
				( str_starts_with( $operation['path'], 'layout.flex.' ) && 'flex' !== $layout_type ) ||
				( str_starts_with( $operation['path'], 'layout.grid.' ) && 'grid' !== $layout_type ) ||
				( str_starts_with( $operation['path'], 'layout.stacked.' ) && 'stacked' !== $layout_type ) ) {
				return false;
			}
			$identity = $operation['device'] . ':' . $operation['path'];
			if ( isset( $seen[ $identity ] ) ) {
				return false;
			}
			if ( $operation['device'] === 'Mobile' && $operation['path'] === 'dimensions.spacing.padding' &&
				! isset( $seen['Desktop:dimensions.spacing.padding'] ) ) {
				return false;
			}
			if ( $operation['device'] === 'Mobile' && $operation['path'] === 'dimensions.spacing.margin' &&
				( ! isset( $seen['Desktop:dimensions.spacing.margin'] ) || '0' !== $operation['value'] ) ) {
				return false;
			}
			if ( $operation['device'] === 'Mobile' && $operation['path'] === 'dimensions.width.custom' &&
				! isset( $seen['Desktop:dimensions.width.custom'] ) ) {
				return false;
			}
			if ( $operation['device'] === 'Mobile' && $operation['path'] === 'layout.grid.columns' &&
				! isset( $seen['Desktop:layout.grid.columns'] ) ) {
				return false;
			}
			$allowed = false;
			foreach ( $catalog['groupOperations'] as $rule ) {
				if ( $operation['path'] === $rule['path'] &&
					in_array( $operation['device'], $rule['devices'], true ) &&
					( 'background.layers' === $operation['path'] ?
						WPHAVE_AI_MCP_Free_Background_Image_Layer::valid(
							$operation['value'],
							array_column( $catalog['groupOperations'], null, 'path' )['background.color.base']['values'] ?? array()
						) :
						in_array( $operation['value'], $rule['values'], true ) ) ) {
					$allowed = true;
					break;
				}
			}
			if ( ! $allowed ) {
				return false;
			}
			$seen[ $identity ] = true;
		}
		if ( isset( $seen['Desktop:dimensions.spacing.margin'] ) &&
			! isset( $seen['Mobile:dimensions.spacing.margin'] ) ) {
			return false;
		}
		if ( 'flex' === $layout_type &&
			isset( $seen['Desktop:layout.flex.flexWrap'] ) ) {
			$desktop_wrap = null;
			$mobile_wrap = null;
			$mobile_direction = null;
			foreach ( $operations as $operation ) {
				if ( 'Desktop' === $operation['device'] && 'layout.flex.flexWrap' === $operation['path'] ) {
					$desktop_wrap = $operation['value'];
				}
				if ( 'Mobile' === $operation['device'] && 'layout.flex.flexWrap' === $operation['path'] ) {
					$mobile_wrap = $operation['value'];
				}
				if ( 'Mobile' === $operation['device'] && 'layout.flex.flexDirection' === $operation['path'] ) {
					$mobile_direction = $operation['value'];
				}
			}
			if ( 'no-wrap' === $desktop_wrap &&
				( 'wrap' !== $mobile_wrap || ! in_array( $mobile_direction, array( 'column', 'column-reverse' ), true ) ) ) {
				return false;
			}
		}
		return true;
	}

	public static function valid_image_operations( array $operations ): bool {
		if ( WPHAVE_AI_MCP_Overlap_Recipe::matches_operations( $operations ) ) {
			return true;
		}
		$catalog = self::catalog();
		$rules = is_wp_error( $catalog ) ? array() : array_column( $catalog['imageOperations'], null, 'path' );
		if ( ! isset( $rules['dimensions.width.custom'], $rules['dimensions.aspectRatio.ratio'] ) ||
			count( $operations ) < 1 || count( $operations ) > 4 ) {
			return false;
		}
		$seen = array();
		foreach ( $operations as $operation ) {
			$path = $operation['path'] ?? null;
			$rule = is_string( $path ) ? ( $rules[ $path ] ?? null ) : null;
			$identity = ( $operation['device'] ?? '' ) . ':' . $path;
			if ( ! is_array( $operation ) || array_keys( $operation ) !== array( 'device', 'path', 'value' ) ||
				! is_array( $rule ) ||
				! in_array( $operation['device'], $rule['devices'], true ) ||
				( 'settings.objectPosition' === $path ?
					! self::valid_image_position( $operation['value'], $rule['values'] ) :
					! in_array( $operation['value'], $rule['values'], true ) ) ||
				isset( $seen[ $identity ] ) ||
				( $operation['device'] === 'Mobile' && ! isset( $seen[ 'Desktop:' . $path ] ) ) ) {
				return false;
			}
			$seen[ $identity ] = true;
		}
		return true;
	}

	public static function valid_image_position( $value, array $presets ): bool {
		return is_string( $value ) &&
			( in_array( $value, $presets, true ) ||
				1 === preg_match( '/^(?:100|[1-9]?\d)% (?:100|[1-9]?\d)%$/', $value ) );
	}
}
