<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Read-only, signed view of a deliberately prepared publication sequence. */
final class WPHAVE_AI_MCP_Free_Website_Publication_Status {
	private const ACK = 'controlled-publication-status-v1';

	public static function prepare( string $project_id, int $header_id, int $footer_id ) {
		if ( ! current_user_can( 'manage_options' ) ||
			! current_user_can( 'wphave_manage_template_parts' ) ||
			! current_user_can( 'publish_pages' ) || wphave_use_fse() ) {
			return self::invalid();
		}
		$project = WPHAVE_AI_MCP_Free_Website_Draft_Project::contract_snapshot( $project_id );
		$records = WPHAVE_AI_MCP_Free_Website_Draft_Project::publication_records( $project_id );
		if ( is_wp_error( $project ) || is_wp_error( $records ) ||
			count( $project['pages'] ) !== count( $records['pages'] ) ) {
			return self::invalid();
		}
		$parts = array( 'header' => $header_id, 'footer' => $footer_id );
		foreach ( $parts as $type => $id ) {
			$post = get_post( $id );
			$expected = 'header' === $type ? $project['headerHash'] : $project['footerHash'];
			if ( ! $post instanceof WP_Post ||
				WPHAVE_Template_Parts::POST_TYPE !== $post->post_type ||
				'draft' !== $post->post_status ||
				! current_user_can( 'edit_post', $id ) ||
				$type !== get_post_meta( $id, WPHAVE_Template_Parts::META_PART_TYPE, true ) ||
				! hash_equals( $expected, hash( 'sha256', $post->post_content ) ) ) {
				return self::invalid();
			}
		}
		$assignments = WPHAVE_Data_Resources::get( 'template_parts', false );
		$revision = WPHAVE_Data_Resources::get_revision( 'template_parts' );
		$identity = WPHAVE_AI_MCP_Free_Site_Design_Identity::snapshot();
		$home_ids = array_column( $project['pages'], 'postId', 'pageKey' );
		if ( 'page' === get_option( 'show_on_front' ) &&
			(int) get_option( 'page_on_front' ) === ( $home_ids['home'] ?? 0 ) ) {
			return self::invalid();
		}
		if ( ! is_array( $assignments ) || ! is_string( $revision ) ||
			is_wp_error( $identity ) ||
			! hash_equals( $project['siteDesignFingerprint'], $identity['fingerprint'] ) ) {
			return self::invalid();
		}
		$snapshot = array(
			'publicationVersion' => 1,
			'project' => $project,
			'projectRecordHash' => $records['projectHash'],
			'projectRows' => $records['pages'],
			'parts' => $parts,
			'assignmentBefore' => $assignments,
			'assignmentRevisionBefore' => $revision,
			'frontBefore' => array(
				'show_on_front' => get_option( 'show_on_front' ),
				'page_on_front' => (int) get_option( 'page_on_front' ),
				'page_for_posts' => (int) get_option( 'page_for_posts' ),
			),
		);
		return array(
			'snapshot' => $snapshot,
			'statusToken' => WPHAVE_AI_MCP_Free_Creation_Workflow::site_plan_token( $snapshot, self::ACK ),
		);
	}

	public static function status( $snapshot, $token ) {
		if ( ! is_array( $snapshot ) || 1 !== ( $snapshot['publicationVersion'] ?? null ) ||
			! WPHAVE_AI_MCP_Free_Creation_Workflow::matches_site_plan_token( $token, $snapshot, self::ACK ) ||
			( $snapshot['project']['siteId'] ?? null ) !== get_current_blog_id() ||
			( $snapshot['project']['actorId'] ?? null ) !== get_current_user_id() ) {
			return self::invalid();
		}
		$observed = self::observe( $snapshot );
		return self::evaluate( $snapshot, $observed );
	}

	/** Pure evaluator for isolated fixture tests; it never authorizes a write. */
	public static function evaluate( array $snapshot, array $observed ): array {
		$conflicts = $observed['conflicts'] ?? array();
		$expected_rows = $snapshot['projectRows'] ?? array();
		if ( ( $observed['projectHash'] ?? null ) !== ( $snapshot['projectRecordHash'] ?? null ) ||
			( $observed['projectRows'] ?? null ) !== $expected_rows ) {
			$conflicts[] = 'project';
		}
		$pages = $observed['pages'] ?? array();
		$published = 0;
		foreach ( $snapshot['project']['pages'] ?? array() as $page ) {
			$key = $page['pageKey'];
			$current = $pages[ $key ] ?? null;
			if ( ! is_array( $current ) ||
				( $current['postId'] ?? null ) !== $page['postId'] ||
				( $current['contentHash'] ?? null ) !== $page['contentHash'] ||
				( $current['linkTargets'] ?? null ) !== $page['linkTargets'] ||
				! in_array( $current['status'] ?? null, array( 'draft', 'publish' ), true ) ) {
				$conflicts[] = 'page:' . $key;
			} elseif ( 'publish' === $current['status'] ) {
				++$published;
			}
		}
		$parts = $observed['parts'] ?? array();
		foreach ( array( 'header', 'footer' ) as $type ) {
			$part = $parts[ $type ] ?? null;
			$expected_hash = $snapshot['project'][ $type . 'Hash' ] ?? null;
			if ( ! is_array( $part ) ||
				( $part['postId'] ?? null ) !== ( $snapshot['parts'][ $type ] ?? null ) ||
				( $part['contentHash'] ?? null ) !== $expected_hash ||
				( $part['type'] ?? null ) !== $type ||
				! in_array( $part['status'] ?? null, array( 'draft', 'publish' ), true ) ) {
				$conflicts[] = 'part:' . $type;
			}
		}
		if ( ( $observed['designFingerprint'] ?? null ) !==
			( $snapshot['project']['siteDesignFingerprint'] ?? null ) ) {
			$conflicts[] = 'siteDesign';
		}
		$before = $snapshot['assignmentBefore'] ?? array();
		$after = array_merge( $before, $snapshot['parts'] ?? array() );
		$actual = $observed['assignments'] ?? null;
		$assignment_phase = $actual === $after ? 'after' : ( $actual === $before ? 'before' : 'conflict' );
		$expected_revision = 'after' === $assignment_phase ?
			hash( 'sha256', wp_json_encode( $after ) ) :
			( $snapshot['assignmentRevisionBefore'] ?? null );
		if ( 'conflict' === $assignment_phase ||
			( $observed['assignmentRevision'] ?? null ) !== $expected_revision ) {
			$conflicts[] = 'templateParts';
		}
		$front = $observed['front'] ?? null;
		$front_before = $snapshot['frontBefore'] ?? array();
		$home = null;
		foreach ( $snapshot['project']['pages'] ?? array() as $page ) {
			if ( 'home' === $page['pageKey'] ) {
				$home = $page['postId'];
			}
		}
		$front_after = array_merge( $front_before, array( 'show_on_front' => 'page', 'page_on_front' => $home ) );
		$front_phase = $front === $front_after ? 'after' : ( $front === $front_before ? 'before' : 'conflict' );
		if ( 'conflict' === $front_phase || null === $home ) {
			$conflicts[] = 'frontPage';
		}
		if ( 'after' === $front_phase && ( 'after' !== $assignment_phase ||
			$published !== count( $snapshot['project']['pages'] ?? array() ) ) ) {
			$conflicts[] = 'frontPage';
		}
		if ( 'after' === $assignment_phase && ( $published !== count( $snapshot['project']['pages'] ?? array() ) ||
			'draft' === ( $parts['header']['status'] ?? null ) ||
			'draft' === ( $parts['footer']['status'] ?? null ) ) ) {
			$conflicts[] = 'templateParts';
		}
		if ( $conflicts ) {
			return array( 'phase' => 'conflict', 'resources' => array_values( array_unique( $conflicts ) ), 'next' => null );
		}
		$phase = 'prepared';
		if ( $published > 0 ) {
			$phase = $published === count( $snapshot['project']['pages'] ) ? 'pages-published' : 'publishing';
		}
		if ( 'after' === $assignment_phase ) {
			$phase = 'shell-assigned';
		}
		if ( 'after' === $front_phase ) {
			$phase = 'frontpage-assigned';
		}
		return array( 'phase' => $phase, 'resources' => array(), 'next' => null );
	}

	/** Anonymous HTTP is the only route from data-complete to verified. */
	public static function verify_anonymous( $snapshot, $token ) {
		$status = self::status( $snapshot, $token );
		if ( is_wp_error( $status ) || 'frontpage-assigned' !== $status['phase'] ) {
			return $status;
		}
		$expected_ids = array();
		foreach ( $snapshot['project']['pages'] as $page ) {
			$expected_ids[] = $page['postId'];
		}
		foreach ( $snapshot['project']['pages'] as $page ) {
			$url = get_permalink( $page['postId'] );
			$home_url = home_url( '/' );
			$allowed = is_string( $url ) &&
				wp_parse_url( $url, PHP_URL_HOST ) === wp_parse_url( $home_url, PHP_URL_HOST ) &&
				wp_parse_url( $url, PHP_URL_SCHEME ) === wp_parse_url( $home_url, PHP_URL_SCHEME ) &&
				wp_parse_url( $url, PHP_URL_PORT ) === wp_parse_url( $home_url, PHP_URL_PORT );
			$response = $allowed ? wp_remote_get( $url, array(
				'timeout' => 8,
				'redirection' => 0,
				'cookies' => array(),
			) ) : new WP_Error( 'wphave_mcp_publication_http', 'The public URL is unavailable.' );
			$body = is_wp_error( $response ) ? '' : wp_remote_retrieve_body( $response );
			if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ||
				! self::anonymous_page_matches( $body, $expected_ids ) ) {
				return array( 'phase' => 'frontpage-assigned', 'resources' => array( 'anonymous:' . $page['pageKey'] ), 'next' => null );
			}
		}
		return array( 'phase' => 'verified', 'resources' => array(), 'next' => null );
	}

	private static function anonymous_page_matches( string $body, array $expected_ids ): bool {
		if ( '' === trim( $body ) || ! class_exists( 'DOMDocument' ) ) {
			return false;
		}
		$document = new DOMDocument();
		$prior = libxml_use_internal_errors( true );
		try {
			if ( ! $document->loadHTML( $body ) ) {
				return false;
			}
		} finally {
			libxml_clear_errors();
			libxml_use_internal_errors( $prior );
		}
		$links = array();
		foreach ( $document->getElementsByTagName( 'a' ) as $anchor ) {
			$url = html_entity_decode( $anchor->getAttribute( 'href' ), ENT_QUOTES, 'UTF-8' );
			$links[] = url_to_postid( $url );
		}
		foreach ( $expected_ids as $id ) {
			if ( ! in_array( $id, $links, true ) ) {
				return false;
			}
		}
		return true;
	}

	private static function observe( array $snapshot ): array {
		$records = WPHAVE_AI_MCP_Free_Website_Draft_Project::publication_records(
			$snapshot['project']['projectId']
		);
		$observation = array(
			'projectHash' => is_wp_error( $records ) ? null : $records['projectHash'],
			'projectRows' => is_wp_error( $records ) ? null : $records['pages'],
			'pages' => array(),
			'parts' => array(),
			'conflicts' => array(),
		);
		foreach ( $snapshot['project']['pages'] as $page ) {
			$post = get_post( $page['postId'] );
			if ( ! $post instanceof WP_Post ||
				! WPHAVE_AI_MCP_Create_Service::owns_created_page( $page['postId'] ) ) {
				$observation['conflicts'][] = 'page:' . $page['pageKey'];
				continue;
			}
			$targets = WPHAVE_AI_MCP_Free_Website_Draft_Project::button_targets(
				parse_blocks( $post->post_content )
			);
			$ids = array_column( $snapshot['project']['pages'], 'postId', 'pageKey' );
			$expected_targets = array();
			foreach ( $page['linkTargets'] as $target_key ) {
				$expected_targets[] = $ids[ $target_key ] ?? null;
			}
			sort( $targets );
			sort( $expected_targets );
			$observation['pages'][ $page['pageKey'] ] = array(
				'postId' => $post->ID,
				'contentHash' => hash( 'sha256', $post->post_content ),
				'linkTargets' => $targets === $expected_targets ? $page['linkTargets'] : null,
				'status' => $post->post_status,
			);
		}
		foreach ( $snapshot['parts'] as $type => $id ) {
			$post = get_post( $id );
			$observation['parts'][ $type ] = $post instanceof WP_Post ? array(
				'postId' => $post->ID,
				'contentHash' => hash( 'sha256', $post->post_content ),
				'type' => get_post_meta( $id, WPHAVE_Template_Parts::META_PART_TYPE, true ),
				'status' => $post->post_status,
			) : null;
			if ( $post instanceof WP_Post &&
				( WPHAVE_Template_Parts::POST_TYPE !== $post->post_type ||
					! current_user_can( 'edit_post', $id ) ) ) {
				$observation['conflicts'][] = 'part:' . $type;
			}
		}
		$identity = WPHAVE_AI_MCP_Free_Site_Design_Identity::snapshot();
		$observation['designFingerprint'] = is_wp_error( $identity ) ? null : $identity['fingerprint'];
		$observation['assignments'] = WPHAVE_Data_Resources::get( 'template_parts', false );
		$observation['assignmentRevision'] = WPHAVE_Data_Resources::get_revision( 'template_parts' );
		$observation['front'] = array(
			'show_on_front' => get_option( 'show_on_front' ),
			'page_on_front' => (int) get_option( 'page_on_front' ),
			'page_for_posts' => (int) get_option( 'page_for_posts' ),
		);
		return $observation;
	}

	private static function invalid(): WP_Error {
		return new WP_Error( 'wphave_mcp_publication_invalid', 'The versioned publication status is unavailable.' );
	}
}
