<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** One licensed native label-over-image relationship, with a linear small-screen reset. */
final class WPHAVE_AI_MCP_Spatial_Callout_Recipe {
	public static function allowed(): bool {
		return function_exists( 'wphave_has_pro_access' ) && wphave_has_pro_access();
	}

	public static function media_operations(): array {
		return array(
			array( 'device' => 'Desktop', 'path' => 'layout.type', 'value' => 'stacked' ),
			array( 'device' => 'Desktop', 'path' => 'dimensions.width.custom', 'value' => '50%' ),
			array( 'device' => 'Desktop', 'path' => 'dimensions.position.type', 'value' => 'relative' ),
			array( 'device' => 'Mobile', 'path' => 'dimensions.width.custom', 'value' => '100%' ),
		);
	}

	public static function text_operations(): array {
		return array(
			array( 'device' => 'Desktop', 'path' => 'layout.type', 'value' => 'stacked' ),
			array( 'device' => 'Desktop', 'path' => 'dimensions.width.custom', 'value' => '45%' ),
			array( 'device' => 'Mobile', 'path' => 'dimensions.width.custom', 'value' => '100%' ),
		);
	}

	public static function badge_operations(): array {
		$edge = array( 'top' => '0px', 'right' => '0px', 'bottom' => 'auto', 'left' => 'auto' );
		$reset = array( 'top' => 'auto', 'right' => 'auto', 'bottom' => 'auto', 'left' => 'auto' );
		$zero_rotation = array( 'x' => '0deg', 'y' => '0deg', 'z' => '0deg' );
		$zero_translation = array( 'x' => '0%', 'y' => '0%' );
		return array(
			array( 'device' => 'Desktop', 'path' => 'layout.type', 'value' => 'stacked' ),
			array( 'device' => 'Desktop', 'path' => 'dimensions.width.custom', 'value' => '176px' ),
			array( 'device' => 'Desktop', 'path' => 'dimensions.aspectRatio.ratio', 'value' => '1/1' ),
			array( 'device' => 'Desktop', 'path' => 'background.color.base', 'value' => 'var(--wphave-site-color-background)' ),
			array( 'device' => 'Desktop', 'path' => 'frame.corners', 'value' => '50% 50% 50% 50%' ),
			array( 'device' => 'Desktop', 'path' => 'dimensions.position.type', 'value' => 'absolute' ),
			array( 'device' => 'Desktop', 'path' => 'dimensions.position.inset', 'value' => $edge ),
			array( 'device' => 'Desktop', 'path' => 'dimensions.transform.translate', 'value' => array( 'x' => '45%', 'y' => '-30%' ) ),
			array( 'device' => 'Desktop', 'path' => 'dimensions.transform.rotate', 'value' => array( 'x' => '0deg', 'y' => '0deg', 'z' => '18deg' ) ),
			array( 'device' => 'Desktop', 'path' => 'dimensions.stackLevel.level', 'value' => 2 ),
			array( 'device' => 'Tablet', 'path' => 'dimensions.position.type', 'value' => 'static' ),
			array( 'device' => 'Tablet', 'path' => 'dimensions.position.inset', 'value' => $reset ),
			array( 'device' => 'Tablet', 'path' => 'dimensions.transform.translate', 'value' => $zero_translation ),
			array( 'device' => 'Tablet', 'path' => 'dimensions.transform.rotate', 'value' => $zero_rotation ),
			array( 'device' => 'Tablet', 'path' => 'dimensions.stackLevel.level', 'value' => 0 ),
			array( 'device' => 'Mobile', 'path' => 'dimensions.position.type', 'value' => 'static' ),
			array( 'device' => 'Mobile', 'path' => 'dimensions.position.inset', 'value' => $reset ),
			array( 'device' => 'Mobile', 'path' => 'dimensions.transform.translate', 'value' => $zero_translation ),
			array( 'device' => 'Mobile', 'path' => 'dimensions.transform.rotate', 'value' => $zero_rotation ),
			array( 'device' => 'Mobile', 'path' => 'dimensions.stackLevel.level', 'value' => 0 ),
		);
	}

	public static function is_media_operations( array $operations ): bool {
		return self::allowed() && $operations === self::media_operations();
	}

	public static function is_badge_operations( array $operations ): bool {
		return self::allowed() && $operations === self::badge_operations();
	}

	/** Pinned productive serializer output, independently verified after the host runs. */
	public static function expected_media_attributes(): array {
		return array(
			'layout' => array( 'type' => 'stacked' ),
			'dimensions' => array(
				'width' => array( 'custom' => '50%' ),
				'position' => array( 'type' => 'relative' ),
			),
			'mobile' => array( 'dimensions' => array( 'width' => array( 'custom' => '100%' ) ) ),
			'styles' => '--wi: 50%;--pos-translate: none;--pos: relative;--wi-m: 100%',
			'classNames' => 'wi pos ly ly-stk wi-m',
		);
	}

	public static function expected_badge_attributes(): array {
		$padding = 'var(--wphave-site-padding-top) var(--wphave-site-padding-right) var(--wphave-site-padding-bottom) var(--wphave-site-padding-left)';
		$reset = array( 'top' => 'auto', 'right' => 'auto', 'bottom' => 'auto', 'left' => 'auto' );
		$reset_dimensions = array(
			'position' => array( 'type' => 'static', 'inset' => $reset ),
			'transform' => array(
				'translate' => array( 'x' => '0%', 'y' => '0%' ),
				'rotate' => array( 'x' => '0deg', 'y' => '0deg', 'z' => '0deg' ),
			),
			'stackLevel' => array( 'level' => 0 ),
		);
		$styles = array(
			'--wi: 176px',
			'--pa: ' . $padding,
			'--pa-top: var(--wphave-site-padding-top)',
			'--pa-right: var(--wphave-site-padding-right)',
			'--pa-bottom: var(--wphave-site-padding-bottom)',
			'--pa-left: var(--wphave-site-padding-left)',
			'--asrt: 1/1',
			'--ofw: clip',
			'--skl: 2',
			'--pos-translate: none',
			'--pos: absolute',
			'--pos-ins: 0px 0px auto auto',
			'--tfm-rtx: 0deg',
			'--tfm-rty: 0deg',
			'--tfm-rtz: 18deg',
			'--tfm-tlx: 45%',
			'--tfm-tly: -30%',
			'--bg-co: var(--wphave-site-color-background)',
			'--br: 50% 50% 50% 50%',
		);
		foreach ( array( 't', 'm' ) as $device ) {
			$styles = array_merge( $styles, array(
				'--skl-' . $device . ': 0',
				'--pos-translate-' . $device . ': none',
				'--pos-' . $device . ': static',
				'--pos-ins-' . $device . ': auto auto auto auto',
				'--tfm-' . $device . '-rtx: 0deg',
				'--tfm-' . $device . '-rty: 0deg',
				'--tfm-' . $device . '-rtz: 0deg',
				'--tfm-' . $device . '-tlx: 0%',
				'--tfm-' . $device . '-tly: 0%',
			) );
		}
		return array(
			'layout' => array( 'type' => 'stacked' ),
			'dimensions' => array(
				'width' => array( 'custom' => '176px' ),
				'aspectRatio' => array( 'ratio' => '1/1' ),
				'spacing' => array( 'padding' => $padding ),
				'overflow' => 'clip',
				'position' => array(
					'type' => 'absolute',
					'inset' => array( 'top' => '0px', 'right' => '0px', 'bottom' => 'auto', 'left' => 'auto' ),
				),
				'transform' => array(
					'translate' => array( 'x' => '45%', 'y' => '-30%' ),
					'rotate' => array( 'x' => '0deg', 'y' => '0deg', 'z' => '18deg' ),
				),
				'stackLevel' => array( 'level' => 2 ),
			),
			'background' => array( 'color' => array( 'base' => 'var(--wphave-site-color-background)' ) ),
			'frame' => array( 'corners' => '50% 50% 50% 50%' ),
			'tablet' => array( 'dimensions' => $reset_dimensions ),
			'mobile' => array( 'dimensions' => $reset_dimensions ),
			'styles' => implode( ';', $styles ),
			'stylesChild' => '--left-spacing-inherit: var(--wphave-site-padding-left);--right-spacing-inherit: var(--wphave-site-padding-right)',
			'classNames' => 'wi pa asrt ofw skl pos tfm ly ly-stk bg-co bg br skl-t pos-t tfm-t skl-m pos-m tfm-m',
		);
	}

	public static function valid_structure( array $nodes ): bool {
		$by_key = array();
		$children = array();
		$badges = array();
		$media_groups = array();
		foreach ( $nodes as $node ) {
			$key = $node['key'] ?? null;
			$by_key[ $key ] = $node;
			$children[ $node['parentKey'] ?? '' ][] = $node;
			if ( ( $node['design'] ?? null ) === self::badge_operations() ) {
				$badges[] = $node;
			}
			if ( ( $node['design'] ?? null ) === self::media_operations() ) {
				$media_groups[] = $node;
			}
		}
		if ( count( $badges ) > 1 || count( $media_groups ) > 1 ||
			( ( $badges || $media_groups ) && ! self::allowed() ) ) {
			return false;
		}
		if ( ! $badges ) {
			return ! $media_groups;
		}
		$badge = $badges[0];
		$media = $by_key[ $badge['parentKey'] ?? '' ] ?? null;
		$scene = $by_key[ $media['parentKey'] ?? '' ] ?? null;
		$media_children = $children[ $media['key'] ?? '' ] ?? array();
		$scene_children = $children[ $scene['key'] ?? '' ] ?? array();
		if ( 'wphave/group' !== ( $badge['name'] ?? null ) ||
			'wphave/group' !== ( $media['name'] ?? null ) ||
			( $media['design'] ?? null ) !== self::media_operations() ||
			2 !== count( $media_children ) ||
			'wphave/image' !== ( $media_children[0]['name'] ?? null ) ||
			( $media_children[1]['key'] ?? null ) !== $badge['key'] ||
			1 !== count( $children[ $badge['key'] ] ?? array() ) ||
			'wphave/paragraph' !== ( $children[ $badge['key'] ][0]['name'] ?? null ) ||
			'wphave/group' !== ( $scene['name'] ?? null ) ||
			2 !== count( $scene_children ) ||
			'wphave/group' !== ( $scene_children[0]['name'] ?? null ) ||
			( $scene_children[0]['design'] ?? null ) !== self::text_operations() ||
			( $scene_children[1]['key'] ?? null ) !== $media['key'] ||
			! is_string( $children[ $badge['key'] ][0]['attributes']['content'] ?? null ) ||
			strlen( $children[ $badge['key'] ][0]['attributes']['content'] ) > 160 ||
			! in_array( array( 'device' => 'Desktop', 'path' => 'layout.flex.flexWrap', 'value' => 'wrap' ), $scene['design'] ?? array(), true ) ||
			! in_array( array( 'device' => 'Mobile', 'path' => 'layout.flex.flexDirection', 'value' => 'column' ), $scene['design'] ?? array(), true ) ) {
			return false;
		}
		$text_children = $children[ $scene_children[0]['key'] ] ?? array();
		return 2 === count( $text_children ) &&
			'wphave/heading' === ( $text_children[0]['name'] ?? null ) &&
			'wphave/paragraph' === ( $text_children[1]['name'] ?? null );
	}
}
