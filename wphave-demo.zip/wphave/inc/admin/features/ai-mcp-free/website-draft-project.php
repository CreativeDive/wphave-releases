<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/creation-config.php';

/** Coordinates native page drafts; the shared Create Service remains the only post writer. */
final class WPHAVE_AI_MCP_Free_Website_Draft_Project {
	private const SCHEMA_VERSION = 4;
	private const MAX_PAGES = 12;

	private static function table(): string {
		global $wpdb;
		return $wpdb->prefix . 'wphave_mcp_website_drafts';
	}

	private static function pages_table(): string {
		global $wpdb;
		return $wpdb->prefix . 'wphave_mcp_website_draft_pages';
	}

	private static function table_ready( string $table, string $unique_index ): bool {
		global $wpdb;
		$status = $wpdb->get_row( $wpdb->prepare( 'SHOW TABLE STATUS WHERE Name = %s', $table ), ARRAY_A );
		if ( ! is_array( $status ) ||
			0 !== strcasecmp( (string) ( $status['Engine'] ?? '' ), 'InnoDB' ) ) {
			return false;
		}
		$index = $wpdb->get_var( $wpdb->prepare(
			'SHOW INDEX FROM ' . $table . ' WHERE Key_name = %s AND Non_unique = 0',
			$unique_index
		) );
		return null !== $index;
	}

	private static function has_column( string $table, string $column ): bool {
		global $wpdb;
		return null !== $wpdb->get_var( $wpdb->prepare(
			'SHOW COLUMNS FROM ' . $table . ' LIKE %s',
			$column
		) );
	}

	private static function ensure_schema(): bool {
		global $wpdb;
		if ( ! self::table_ready( $wpdb->posts, 'PRIMARY' ) ||
			! self::table_ready( $wpdb->postmeta, 'PRIMARY' ) ) {
			return false;
		}
		$projects = self::table();
		$pages = self::pages_table();
		if ( ! self::table_ready( $projects, 'request_identity' ) ||
			( self::table_ready( $projects, 'request_identity' ) &&
				( ! self::has_column( $projects, 'brand' ) ||
					! self::has_column( $projects, 'description' ) ||
					! self::has_column( $projects, 'design_plan_json' ) ||
					! self::has_column( $projects, 'link_targets_json' ) ) ) ||
			! self::table_ready( $pages, 'PRIMARY' ) ) {
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			$collate = $wpdb->get_charset_collate();
			dbDelta( "CREATE TABLE {$projects} (
				project_id char(36) NOT NULL,
				site_id bigint(20) unsigned NOT NULL,
				actor_id bigint(20) unsigned NOT NULL,
				request_id varchar(80) NOT NULL,
				payload_hash char(64) NOT NULL,
				design_fingerprint char(64) NOT NULL,
				brand varchar(80) NOT NULL DEFAULT '',
				description varchar(240) NOT NULL DEFAULT '',
				design_plan_json longtext NULL,
				link_targets_json longtext NULL,
				page_count smallint(5) unsigned NOT NULL,
				created_at datetime NOT NULL,
				PRIMARY KEY  (project_id),
				UNIQUE KEY request_identity (site_id,actor_id,request_id)
			) ENGINE=InnoDB {$collate};" );
			dbDelta( "CREATE TABLE {$pages} (
				project_id char(36) NOT NULL,
				page_key varchar(32) NOT NULL,
				post_id bigint(20) unsigned NOT NULL,
				markup_hash char(64) NOT NULL,
				created_at datetime NOT NULL,
				PRIMARY KEY  (project_id,page_key),
				UNIQUE KEY unique_post (post_id)
			) ENGINE=InnoDB {$collate};" );
		}
		return self::table_ready( $projects, 'request_identity' ) &&
			self::has_column( $projects, 'brand' ) &&
			self::has_column( $projects, 'description' ) &&
			self::has_column( $projects, 'design_plan_json' ) &&
			self::has_column( $projects, 'link_targets_json' ) &&
			self::table_ready( $pages, 'unique_post' );
	}

	private static function valid_request( $input ): bool {
		if ( ! is_array( $input ) ||
			array_diff( array_keys( $input ), array( 'requestId', 'brand', 'description', 'designPlan', 'pages', 'layoutToken' ) ) ||
			! is_string( $input['requestId'] ?? null ) ||
			! preg_match( '/^[A-Za-z0-9_-]{16,80}$/', $input['requestId'] ) ||
			! is_string( $input['brand'] ?? null ) ||
			'' === trim( $input['brand'] ) || mb_strlen( $input['brand'] ) > 80 ||
			sanitize_text_field( $input['brand'] ) !== $input['brand'] ||
			! is_string( $input['description'] ?? null ) ||
			mb_strlen( $input['description'] ) > 240 ||
			sanitize_text_field( $input['description'] ) !== $input['description'] ||
			! is_array( $input['pages'] ?? null ) ||
			count( $input['pages'] ) < 1 || count( $input['pages'] ) > self::MAX_PAGES ||
			array_keys( $input['pages'] ) !== range( 0, count( $input['pages'] ) - 1 ) ) {
			return false;
		}
		$keys = array();
		$fingerprint = null;
		foreach ( $input['pages'] as $page ) {
			if ( ! is_array( $page ) ||
				array_diff( array_keys( $page ), array( 'pageKey', 'title', 'batch' ) ) ||
				! is_string( $page['pageKey'] ?? null ) ||
				! preg_match( '/^[a-z][a-z0-9_-]{0,31}$/', $page['pageKey'] ) ||
				isset( $keys[ $page['pageKey'] ] ) ||
				! is_string( $page['title'] ?? null ) ||
				'' === trim( $page['title'] ) || mb_strlen( $page['title'] ) > 120 ||
				preg_match( '/[<>\x00-\x1F]/', $page['title'] ) ||
				sanitize_text_field( $page['title'] ) !== $page['title'] ||
				! is_array( $page['batch'] ?? null ) ) {
				return false;
			}
			$keys[ $page['pageKey'] ] = true;
			$current = $page['batch']['designFingerprint'];
			if ( null !== $fingerprint && ! hash_equals( $fingerprint, $current ) ) {
				return false;
			}
			$fingerprint = $current;
		}
		if ( ! isset( $keys['home'] ) ) {
			return false;
		}
		foreach ( $input['pages'] as $page ) {
			if ( ! WPHAVE_AI_MCP_Free_Job_Store::valid_website_batch( $page['batch'], array_keys( $keys ) ) ) {
				return false;
			}
			foreach ( $page['batch']['nodes'] as $node ) {
				if ( ( $node['linkTarget']['pageKey'] ?? null ) === $page['pageKey'] ) {
					return false;
				}
			}
		}
		return true;
	}

	private static function unlinked_batch( array $batch ): array {
		foreach ( $batch['nodes'] as &$node ) {
			unset( $node['linkTarget'] );
		}
		unset( $node );
		return $batch;
	}

	private static function link_targets( array $pages ): array {
		$targets = array();
		foreach ( $pages as $page ) {
			foreach ( $page['batch']['nodes'] as $node ) {
				if ( isset( $node['linkTarget'] ) ) {
					$targets[ $page['pageKey'] ][] = $node['linkTarget']['pageKey'];
				}
			}
		}
		return $targets;
	}

	private static function button_targets( array $blocks ): array {
		$targets = array();
		foreach ( $blocks as $block ) {
			if ( 'wphave/button' === ( $block['blockName'] ?? null ) &&
				'internal' === ( $block['attrs']['link']['type'] ?? null ) ) {
				$targets[] = $block['attrs']['link']['internal']['id'] ?? null;
			}
			$targets = array_merge( $targets, self::button_targets( $block['innerBlocks'] ?? array() ) );
		}
		return $targets;
	}

	private static function valid_design_plan( $plan, array $pages, ?array $config = null ): bool {
		$config = $config ?? WPHAVE_AI_MCP_Free_Creation_Config::get();
		if ( null === $config || ! is_array( $plan ) ||
			! self::has_exact_keys( $plan, array( 'version', 'direction', 'audience', 'pages' ) ) ||
			! in_array( $plan['version'], array( 1, 2 ), true ) ||
			! is_string( $plan['direction'] ) || mb_strlen( trim( $plan['direction'] ) ) < 12 ||
			mb_strlen( $plan['direction'] ) > 240 || sanitize_text_field( $plan['direction'] ) !== $plan['direction'] ||
			! is_string( $plan['audience'] ) || mb_strlen( trim( $plan['audience'] ) ) < 8 ||
			mb_strlen( $plan['audience'] ) > 160 || sanitize_text_field( $plan['audience'] ) !== $plan['audience'] ||
			! is_array( $plan['pages'] ) || count( $plan['pages'] ) !== count( $pages ) ) {
			return false;
		}
		$sequences = array();
		foreach ( $pages as $index => $page ) {
			$planned = $plan['pages'][ $index ] ?? null;
			if ( ! is_array( $planned ) ||
				! self::has_exact_keys( $planned, array( 'pageKey', 'purpose', 'mediaIds', 'sections' ) ) ||
				$planned['pageKey'] !== $page['pageKey'] ||
				! is_string( $planned['purpose'] ) || mb_strlen( trim( $planned['purpose'] ) ) < 8 ||
				mb_strlen( $planned['purpose'] ) > 240 || sanitize_text_field( $planned['purpose'] ) !== $planned['purpose'] ||
				! is_array( $planned['mediaIds'] ) ||
				! is_array( $planned['sections'] ) ||
				count( $planned['sections'] ) < $config['limits']['minimumSectionsPerPage'] ||
				count( $planned['sections'] ) > 8 ) {
				return false;
			}
			$actual_media = array();
			$section_count = 0;
			foreach ( $page['batch']['nodes'] as $node ) {
				if ( 'wphave/image' === $node['name'] ) {
					$actual_media[] = $node['attributes']['image'] ?? null;
				}
				if ( null === $node['parentKey'] && 'wphave/group' === $node['name'] ) {
					++$section_count;
				}
			}
			$actual_media = array_values( array_unique( $actual_media ) );
			$planned_media = $planned['mediaIds'];
			if ( count( $planned_media ) !== count( array_unique( $planned_media ) ) ||
				array_filter( $planned_media, 'is_int' ) !== $planned_media ||
				$section_count < count( $planned['sections'] ) ) {
				return false;
			}
			sort( $actual_media );
			sort( $planned_media );
			if ( $actual_media !== $planned_media ) {
				return false;
			}
			$principles = array();
			$sequence = array();
			foreach ( $planned['sections'] as $section ) {
				$section_index = count( $sequence );
				$required_keys = 2 === $plan['version'] ?
					array( 'role', 'principle', 'responsiveIntent', 'groupKey', 'layout' ) :
					array( 'role', 'principle', 'responsiveIntent' );
				if ( ! is_array( $section ) ||
					! self::has_exact_keys( $section, $required_keys ) ||
					( 2 === $plan['version'] && (
						! isset( $page['batch']['sections'][ $section_index ] ) ||
						$section['groupKey'] !== $page['batch']['sections'][ $section_index ]['key'] ||
						$section['layout'] !== $page['batch']['sections'][ $section_index ]['layout']
					) ) ||
					! is_string( $section['role'] ) || mb_strlen( trim( $section['role'] ) ) < 3 ||
					mb_strlen( $section['role'] ) > 80 || sanitize_text_field( $section['role'] ) !== $section['role'] ||
					! in_array( $section['principle'], array(
						'editorial-image-text',
						'alternating-section-rhythm',
						'responsive-offer-grid',
						'immersive-opening-and-cta',
					), true ) ||
					! is_string( $section['responsiveIntent'] ) ||
					mb_strlen( trim( $section['responsiveIntent'] ) ) < 8 ||
					mb_strlen( $section['responsiveIntent'] ) > 160 ||
					sanitize_text_field( $section['responsiveIntent'] ) !== $section['responsiveIntent'] ) {
					return false;
				}
				$principles[ $section['principle'] ] = true;
				$sequence[] = $section['principle'];
			}
			if ( $config['checks']['distinctSectionPrinciples'] && count( $principles ) < 2 ) {
				return false;
			}
			$signature = implode( '|', $sequence );
			if ( $config['checks']['distinctPageRhythm'] && isset( $sequences[ $signature ] ) ) {
				return false;
			}
			$sequences[ $signature ] = true;
			if ( 2 === $plan['version'] &&
				count( $page['batch']['sections'] ?? array() ) !== count( $planned['sections'] ) ) {
				return false;
			}
		}
		return true;
	}

	private static function has_exact_keys( array $value, array $expected ): bool {
		$keys = array_keys( $value );
		sort( $keys );
		sort( $expected );
		return $keys === $expected;
	}

	private static function page_request_id( string $request_id, string $page_key ): string {
		return 'website_' . substr( hash( 'sha256', $request_id . "\n" . $page_key ), 0, 56 );
	}

	/** Reject repeated text stacks before a new website project writes any posts. */
	private static function composition_issue( array $pages, ?array $config = null ): ?string {
		$config = $config ?? WPHAVE_AI_MCP_Free_Creation_Config::get();
		if ( null === $config ) {
			return $pages[0]['pageKey'] ?? 'home';
		}
		foreach ( $pages as $page ) {
			$sections = 0;
			$has_visual_intent = false;
			foreach ( $page['batch']['nodes'] as $node ) {
				if ( null === $node['parentKey'] && 'wphave/group' === $node['name'] ) {
					++$sections;
				}
				if ( in_array( $node['name'], array( 'wphave/image', 'wphave/button' ), true ) ) {
					$has_visual_intent = true;
				}
				foreach ( $node['design'] ?? array() as $operation ) {
					if ( in_array( $operation['path'] ?? '', array(
						'background.color.base',
						'colors.text',
						'text.typeface.size',
					), true ) ||
						( 'layout.type' === ( $operation['path'] ?? '' ) && 'grid' === ( $operation['value'] ?? null ) ) ) {
						$has_visual_intent = true;
					}
				}
			}
			if ( $sections < $config['limits']['minimumSectionsPerPage'] ||
				( $config['checks']['compositionVariety'] && ! $has_visual_intent ) ) {
				return $page['pageKey'];
			}
		}
		return null;
	}

	private static function response( array $project ): array {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare(
			'SELECT page_key,post_id,markup_hash FROM ' . self::pages_table() . ' WHERE project_id=%s ORDER BY post_id ASC',
			$project['project_id']
		), ARRAY_A );
		$pages = array();
		foreach ( $rows as $row ) {
			$post = get_post( (int) $row['post_id'] );
			$valid = $post instanceof WP_Post && 'page' === $post->post_type &&
				'draft' === $post->post_status &&
				current_user_can( 'edit_post', $post->ID ) &&
				hash_equals( $row['markup_hash'], hash( 'sha256', $post->post_content ) );
			$pages[] = array(
				'pageKey' => $row['page_key'],
				'postId' => (int) $row['post_id'],
				'status' => $valid ? 'draft' : 'changed',
				'markupHash' => $row['markup_hash'],
				'editorUrl' => $valid ? get_edit_post_link( $post->ID, 'raw' ) : null,
				'previewUrl' => $valid ? get_preview_post_link( $post->ID ) : null,
			);
		}
		$all_current = count( $pages ) === (int) $project['page_count'];
		foreach ( $pages as $page ) {
			if ( 'draft' !== $page['status'] ) {
				$all_current = false;
			}
		}
		$stored_link_targets = (string) ( $project['link_targets_json'] ?? '' );
		$link_targets = json_decode( $stored_link_targets, true );
		$links_valid = '' === $stored_link_targets ||
			( JSON_ERROR_NONE === json_last_error() && is_array( $link_targets ) );
		$link_targets = is_array( $link_targets ) ? $link_targets : array();
		$links_complete = $all_current && array() !== $link_targets;
		if ( $links_complete ) {
			$page_ids = array_column( $pages, 'postId', 'pageKey' );
			foreach ( $link_targets as $source_key => $target_keys ) {
				if ( ! is_string( $source_key ) || ! isset( $page_ids[ $source_key ] ) ||
					! is_array( $target_keys ) ) {
					$links_valid = false;
					$links_complete = false;
					break;
				}
				$expected = array();
				foreach ( $target_keys as $target_key ) {
					if ( ! is_string( $target_key ) || ! isset( $page_ids[ $target_key ] ) ) {
						$links_valid = false;
						$links_complete = false;
						break;
					}
					$expected[] = $page_ids[ $target_key ] ?? null;
				}
				if ( ! $links_complete ) {
					break;
				}
				$source = get_post( $page_ids[ $source_key ] ?? 0 );
				$actual = $source instanceof WP_Post ? self::button_targets( parse_blocks( $source->post_content ) ) : array();
				sort( $expected );
				sort( $actual );
				if ( $expected !== $actual ) {
					$links_complete = false;
					break;
				}
			}
		}
		$shell = null;
		if ( $all_current && class_exists( 'WPHAVE_AI_MCP_Free_Site_Shell_Proposal' ) &&
			current_user_can( 'wphave_manage_template_parts' ) && ! wphave_use_fse() ) {
			$links = array();
			foreach ( $pages as $page ) {
				$label = get_the_title( $page['postId'] );
				if ( preg_match( '/^(.+?)\s+[–—-]\s+(.+)$/u', $label, $parts ) &&
					false !== mb_stripos( $project['brand'] ?? '', trim( $parts[1] ) ) ) {
					$label = $parts[2];
				}
				$links[] = array(
					'label' => 'home' === $page['pageKey'] ? 'Startseite' : $label,
					'postId' => $page['postId'],
				);
			}
			$brand = ( $project['brand'] ?? '' ) ?: sanitize_text_field( get_option( 'blogname', '' ) );
			$description = ( $project['description'] ?? '' ) ?: sanitize_text_field( get_option( 'blogdescription', '' ) );
			$header = WPHAVE_AI_MCP_Free_Site_Shell_Proposal::native_markup_from_links(
				'header', $brand, '', '', $links, true
			);
			$footer = WPHAVE_AI_MCP_Free_Site_Shell_Proposal::native_markup_from_links(
				'footer', $brand, $description, '© ' . gmdate( 'Y' ) . ' ' . $brand, $links, true
			);
			if ( is_string( $header ) && is_string( $footer ) ) {
				$shell = array(
					'headerMarkup' => $header,
					'footerMarkup' => $footer,
					'links' => $links,
					'globalAssignmentChanged' => false,
				);
			}
		}
		return array(
			'schemaVersion' => self::SCHEMA_VERSION,
			'projectId' => $project['project_id'],
			'siteId' => (int) $project['site_id'],
			'actorId' => (int) $project['actor_id'],
			'designFingerprint' => $project['design_fingerprint'],
			'brand' => $project['brand'] ?? '',
			'description' => $project['description'] ?? '',
			'designPlan' => isset( $project['design_plan_json'] ) ?
				json_decode( $project['design_plan_json'], true ) : null,
			'pageCount' => (int) $project['page_count'],
			'status' => ! $links_valid ? 'incomplete' : ( $all_current ? ( $links_complete ? 'links-complete' :
				( $link_targets ? 'links-pending' : 'drafts-created' ) ) : 'incomplete' ),
			'pages' => $pages,
			'siteShell' => $shell,
			'globalAssignmentChanged' => false,
		);
	}

	private static function finalize_links( array $input, array $project ) {
		global $wpdb;
		$targets = self::link_targets( $input['pages'] );
		if ( ! $targets ) {
			return true;
		}
		$rows = $wpdb->get_results( $wpdb->prepare(
			'SELECT page_key,post_id,markup_hash FROM ' . self::pages_table() . ' WHERE project_id=%s',
			$project['project_id']
		), ARRAY_A );
		if ( count( $rows ) !== count( $input['pages'] ) ) {
			return new WP_Error( 'wphave_mcp_website_links_pending', 'Not all project pages exist.' );
		}
		$bindings = array();
		$page_ids = array();
		foreach ( $rows as $row ) {
			$bindings[ $row['page_key'] ] = $row;
			$page_ids[ $row['page_key'] ] = (int) $row['post_id'];
		}
		foreach ( $input['pages'] as $page ) {
			$key = $page['pageKey'];
			if ( ! isset( $targets[ $key ], $bindings[ $key ] ) ) {
				continue;
			}
			$post_id = $page_ids[ $key ];
			$resolved = WPHAVE_AI_MCP_Free_Project_Link::resolve_website(
				$page['batch']['nodes'],
				$post_id,
				$page_ids
			);
			if ( is_wp_error( $resolved ) ) {
				return $resolved;
			}
			$markup = WPHAVE_AI_MCP_Free_Create_Abilities::render_linked_website_batch(
				$page['batch'],
				$resolved
			);
			if ( is_wp_error( $markup ) ) {
				return $markup;
			}
			$expected_hash = $bindings[ $key ]['markup_hash'];
			$revalidate = static function () use ( $input, $page, $project, $page_ids, $resolved, $markup ) {
				global $wpdb;
				if ( ! WPHAVE_AI_MCP_Free_Create_Abilities::can_create() ||
					! self::valid_request( $input ) ) {
					return new WP_Error( 'wphave_mcp_website_link_stale', 'The website context changed.' );
				}
				foreach ( $page_ids as $page_key => $bound_post_id ) {
					$row = $wpdb->get_row( $wpdb->prepare(
						'SELECT post_id,markup_hash FROM ' . self::pages_table() . ' WHERE project_id=%s AND page_key=%s',
						$project['project_id'],
						$page_key
					), ARRAY_A );
					$target = get_post( $bound_post_id );
					if ( ! is_array( $row ) || (int) $row['post_id'] !== $bound_post_id ||
						! $target instanceof WP_Post || 'draft' !== $target->post_status ||
						! WPHAVE_AI_MCP_Create_Service::owns_created_draft( $bound_post_id ) ||
						! hash_equals( $row['markup_hash'], hash( 'sha256', $target->post_content ) ) ) {
						return new WP_Error( 'wphave_mcp_website_link_stale', 'A project target changed.' );
					}
				}
				$fresh_links = WPHAVE_AI_MCP_Free_Project_Link::resolve_website(
					$page['batch']['nodes'],
					$page_ids[ $page['pageKey'] ],
					$page_ids
				);
				if ( is_wp_error( $fresh_links ) || $fresh_links !== $resolved ) {
					return new WP_Error( 'wphave_mcp_website_link_stale', 'A project link changed.' );
				}
				$fresh_markup = WPHAVE_AI_MCP_Free_Create_Abilities::render_linked_website_batch(
					$page['batch'],
					$fresh_links
				);
				return is_string( $fresh_markup ) && hash_equals( $markup, $fresh_markup ) ? true :
					new WP_Error( 'wphave_mcp_website_link_stale', 'The native linked page changed.' );
			};
			$result = WPHAVE_AI_MCP_Create_Service::finalize_owned_draft(
				$post_id,
				$expected_hash,
				$markup,
				$revalidate
			);
			if ( is_wp_error( $result ) ) {
				return $result;
			}
			$new_hash = $result['markupHash'];
			if ( ! hash_equals( $expected_hash, $new_hash ) ) {
				$wpdb->update(
					self::pages_table(),
					array( 'markup_hash' => $new_hash ),
					array(
						'project_id' => $project['project_id'],
						'page_key' => $key,
						'post_id' => $post_id,
						'markup_hash' => $expected_hash,
					)
				);
				$bound = $wpdb->get_var( $wpdb->prepare(
					'SELECT markup_hash FROM ' . self::pages_table() . ' WHERE project_id=%s AND page_key=%s AND post_id=%d',
					$project['project_id'],
					$key,
					$post_id
				) );
				if ( ! is_string( $bound ) || ! hash_equals( $new_hash, $bound ) ) {
					return new WP_Error( 'wphave_mcp_website_links_pending', 'The project link state is uncertain.' );
				}
				$bindings[ $key ]['markup_hash'] = $new_hash;
			}
		}
		return true;
	}

	public static function create( $input ) {
		global $wpdb;
		$config = WPHAVE_AI_MCP_Free_Creation_Config::get();
		if ( ! WPHAVE_AI_MCP_Free_Create_Abilities::can_create() ||
			! self::valid_request( $input ) || null === $config ||
			( $config['workflow']['required'] &&
				! WPHAVE_AI_MCP_Free_Creation_Workflow::matches_drafts( $input['layoutToken'] ?? null, $input['pages'] ) ) ||
			! self::ensure_schema() ) {
			return new WP_Error( 'wphave_mcp_website_invalid', 'The website draft request is unavailable.' );
		}
		foreach ( $input['pages'] as $page ) {
			$context = WPHAVE_AI_MCP_Free_Host_Context::build( self::unlinked_batch( $page['batch'] ) );
			if ( is_wp_error( $context ) ) {
				return $context;
			}
		}
		$payload = array(
			'brand' => $input['brand'],
			'description' => $input['description'],
			'pages' => $input['pages'],
		);
		if ( isset( $input['designPlan'] ) ) {
			$payload['designPlan'] = $input['designPlan'];
		}
		$json = wp_json_encode( $payload );
		if ( ! is_string( $json ) ) {
			return new WP_Error( 'wphave_mcp_website_invalid', 'The website draft request is invalid.' );
		}
		$payload_hash = hash( 'sha256', $json );
		$site_id = get_current_blog_id();
		$actor_id = get_current_user_id();
		$table = self::table();
		$existing = $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM ' . $table . ' WHERE site_id=%d AND actor_id=%d AND request_id=%s',
			$site_id,
			$actor_id,
			$input['requestId']
		), ARRAY_A );
		if ( ! is_array( $existing ) ) {
			if ( ! self::valid_design_plan( $input['designPlan'] ?? null, $input['pages'] ) ) {
				return new WP_Error(
					'wphave_mcp_website_unplanned',
					'The website design plan does not satisfy the active creation configuration or its page and media bindings.'
				);
			}
			$design_plan_json = wp_json_encode( $input['designPlan'] );
			if ( ! is_string( $design_plan_json ) || strlen( $design_plan_json ) > 16384 ) {
				return new WP_Error( 'wphave_mcp_website_unplanned', 'The website design plan is too large.' );
			}
			$uncomposed_page = self::composition_issue( $input['pages'] );
			if ( null !== $uncomposed_page ) {
				return new WP_Error(
					'wphave_mcp_website_uncomposed',
					'Page ' . $uncomposed_page . ' does not satisfy the active section count or composition-variety check.'
				);
			}
			$previous_suppression = $wpdb->suppress_errors( true );
			$wpdb->insert( $table, array(
				'project_id' => wp_generate_uuid4(),
				'site_id' => $site_id,
				'actor_id' => $actor_id,
				'request_id' => $input['requestId'],
				'payload_hash' => $payload_hash,
				'design_fingerprint' => $input['pages'][0]['batch']['designFingerprint'],
				'brand' => $input['brand'],
				'description' => $input['description'],
				'design_plan_json' => $design_plan_json,
				'link_targets_json' => wp_json_encode( self::link_targets( $input['pages'] ) ),
				'page_count' => count( $input['pages'] ),
				'created_at' => current_time( 'mysql', true ),
			) );
			$wpdb->suppress_errors( $previous_suppression );
			$existing = $wpdb->get_row( $wpdb->prepare(
				'SELECT * FROM ' . $table . ' WHERE site_id=%d AND actor_id=%d AND request_id=%s',
				$site_id,
				$actor_id,
				$input['requestId']
			), ARRAY_A );
		}
		if ( ! is_array( $existing ) ) {
			return new WP_Error( 'wphave_mcp_website_uncertain', 'The project state is uncertain.' );
		}
		if ( ! hash_equals( $existing['payload_hash'], $payload_hash ) ) {
			return new WP_Error( 'wphave_mcp_website_conflict', 'The request ID belongs to a different website.' );
		}
		foreach ( $input['pages'] as $page ) {
			$pages_table = self::pages_table();
			$bound = $wpdb->get_row( $wpdb->prepare(
				'SELECT post_id,markup_hash FROM ' . $pages_table . ' WHERE project_id=%s AND page_key=%s',
				$existing['project_id'],
				$page['pageKey']
			), ARRAY_A );
			if ( is_array( $bound ) ) {
				if ( ! WPHAVE_AI_MCP_Create_Service::owns_created_draft( (int) $bound['post_id'] ) ) {
					return new WP_Error( 'wphave_mcp_website_changed', 'An existing project draft changed.' );
				}
				continue;
			}
			$result = WPHAVE_AI_MCP_Free_Create_Abilities::create_complete( array(
				'requestId' => self::page_request_id( $input['requestId'], $page['pageKey'] ),
				'title' => $page['title'],
				'batch' => self::unlinked_batch( $page['batch'] ),
			) );
			if ( is_wp_error( $result ) ) {
				return $result;
			}
			$previous_suppression = $wpdb->suppress_errors( true );
			$wpdb->insert( $pages_table, array(
				'project_id' => $existing['project_id'],
				'page_key' => $page['pageKey'],
				'post_id' => $result['postId'],
				'markup_hash' => $result['markupHash'],
				'created_at' => current_time( 'mysql', true ),
			) );
			$wpdb->suppress_errors( $previous_suppression );
			$bound = $wpdb->get_row( $wpdb->prepare(
				'SELECT post_id,markup_hash FROM ' . $pages_table . ' WHERE project_id=%s AND page_key=%s',
				$existing['project_id'],
				$page['pageKey']
			), ARRAY_A );
			if ( ! is_array( $bound ) || (int) $bound['post_id'] !== $result['postId'] ||
				! hash_equals( $bound['markup_hash'], $result['markupHash'] ) ) {
				return new WP_Error( 'wphave_mcp_website_uncertain', 'The page binding is uncertain.' );
			}
		}
		$finalized = self::finalize_links( $input, $existing );
		return is_wp_error( $finalized ) ? $finalized : self::response( $existing );
	}

	public static function status( $input ) {
		global $wpdb;
		if ( ! function_exists( 'wphave_mcp_free_create_feature_enabled' ) ||
			! wphave_mcp_free_create_feature_enabled() ||
			! current_user_can( 'wphave_access' ) || ! current_user_can( 'edit_pages' ) ||
			! is_array( $input ) || array_keys( $input ) !== array( 'projectId' ) ||
			! is_string( $input['projectId'] ) || ! wp_is_uuid( $input['projectId'] ) ||
			! self::table_ready( self::table(), 'request_identity' ) ||
			! self::table_ready( self::pages_table(), 'unique_post' ) ) {
			return new WP_Error( 'wphave_mcp_website_forbidden', 'The website draft project is unavailable.' );
		}
		$project = $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM ' . self::table() . ' WHERE project_id=%s AND site_id=%d AND actor_id=%d',
			$input['projectId'],
			get_current_blog_id(),
			get_current_user_id()
		), ARRAY_A );
		return is_array( $project ) ?
			self::response( $project ) :
			new WP_Error( 'wphave_mcp_website_forbidden', 'The website draft project is unavailable.' );
	}

	/** Resolve only an owned, intact project page to its private native shell. */
	public static function shell_for_post( string $project_id, int $post_id ): ?array {
		$status = self::status( array( 'projectId' => $project_id ) );
		if ( is_wp_error( $status ) ||
			! in_array( $status['status'], array( 'drafts-created', 'links-complete' ), true ) ||
			! is_array( $status['siteShell'] ) ) {
			return null;
		}
		foreach ( $status['pages'] as $page ) {
			if ( $page['postId'] === $post_id && 'draft' === $page['status'] ) {
				return $status['siteShell'];
			}
		}
		return null;
	}

	/** Lightweight membership check usable before theme template-part classes load. */
	public static function contains_post( string $project_id, int $post_id ): bool {
		global $wpdb;
		if ( ! wp_is_uuid( $project_id ) || $post_id < 1 ||
			! current_user_can( 'edit_post', $post_id ) ||
			! self::table_ready( self::table(), 'request_identity' ) ||
			! self::table_ready( self::pages_table(), 'unique_post' ) ) {
			return false;
		}
		$found = $wpdb->get_var( $wpdb->prepare(
			'SELECT d.post_id FROM ' . self::pages_table() . ' d INNER JOIN ' . self::table() .
			' p ON p.project_id=d.project_id WHERE p.project_id=%s AND p.site_id=%d AND p.actor_id=%d AND d.post_id=%d',
			$project_id,
			get_current_blog_id(),
			get_current_user_id(),
			$post_id
		) );
		return (int) $found === $post_id;
	}
}
