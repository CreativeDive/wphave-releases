<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once dirname( __DIR__ ) . '/ai-mcp-write/create-service.php';
require_once __DIR__ . '/visual-preview.php';
if ( isset( $_GET['wphave_mcp_visual'] ) || isset( $_GET['wphave_mcp_interactive'] ) ) {
	if ( isset( $_GET['wphave_mcp_shell'] ) ) {
		require_once __DIR__ . '/design-grammar.php';
		require_once __DIR__ . '/site-design-identity.php';
		require_once __DIR__ . '/site-design-contract.php';
	}
	require_once __DIR__ . '/site-shell-proposal.php';
	require_once __DIR__ . '/website-draft-project.php';
	require_once __DIR__ . '/shell-composition.php';
	require_once __DIR__ . '/website-shell-composition-proposal.php';
}

add_action( 'init', array( 'WPHAVE_AI_MCP_Free_Visual_Preview', 'authenticate' ), 20 );
add_action( 'pre_get_posts', array( 'WPHAVE_AI_MCP_Free_Visual_Preview', 'include_private_draft' ) );
add_filter( 'posts_pre_query', array( 'WPHAVE_AI_MCP_Free_Visual_Preview', 'resolve_private_draft' ), 10, 2 );
add_action( 'wp', array( 'WPHAVE_AI_MCP_Free_Visual_Preview', 'establish_page_context' ), 1 );
add_action( 'wp', array( 'WPHAVE_AI_MCP_Free_Visual_Preview', 'hide_authoring_chrome' ), 2 );
add_action( 'wp_head', array( 'WPHAVE_AI_MCP_Free_Visual_Preview', 'print_marker' ) );
add_filter( 'wphave_template_content', array( 'WPHAVE_AI_MCP_Free_Visual_Preview', 'override_content' ), 10, 1 );
add_filter( 'wphave_render_after_header_section', array( 'WPHAVE_AI_MCP_Free_Visual_Preview', 'override_header' ) );
add_filter( 'wphave_render_after_announcement_section', array( 'WPHAVE_AI_MCP_Free_Visual_Preview', 'override_announcement' ) );
add_filter( 'wphave_render_after_footer_section', array( 'WPHAVE_AI_MCP_Free_Visual_Preview', 'override_footer' ) );
add_filter( 'render_block_data', array( 'WPHAVE_AI_MCP_Free_Visual_Preview', 'interactive_navigation_link' ) );
