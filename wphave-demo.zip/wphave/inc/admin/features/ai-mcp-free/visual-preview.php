<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Short-lived, one-page preview identity for the isolated local renderer. */
final class WPHAVE_AI_MCP_Free_Visual_Preview {
	private const MAX_AGE = 30;
	private static ?string $authenticated_hash = null;
	private static ?int $authenticated_post_id = null;
	private static ?array $private_shell = null;
	private static ?string $project_id = null;

	private static function signature( int $actor_id, int $post_id, string $markup_hash, int $expires, string $project_id ): string {
		$message = implode( '|', array(
			get_current_blog_id(),
			$actor_id,
			$post_id,
			$markup_hash,
			$expires,
			$project_id,
		) );
		return hash_hmac( 'sha256', $message, wp_salt( 'auth' ) );
	}

	public static function url( int $post_id, string $markup_hash, string $project_id = '' ): ?string {
		if ( ! WPHAVE_AI_MCP_Create_Service::owns_created_draft( $post_id ) ||
			! preg_match( '/^[a-f0-9]{64}$/', $markup_hash ) ) {
			return null;
		}
		$post = get_post( $post_id );
		if ( ! hash_equals( $markup_hash, hash( 'sha256', $post->post_content ) ) ) {
			return null;
		}
		if ( '' !== $project_id && ( ! wp_is_uuid( $project_id ) ||
			null === WPHAVE_AI_MCP_Free_Website_Draft_Project::shell_for_post( $project_id, $post_id ) ) ) {
			return null;
		}
		$actor_id = get_current_user_id();
		$expires = time() + self::MAX_AGE;
		$token = implode( '.', array(
			$actor_id,
			$expires,
			$markup_hash,
			self::signature( $actor_id, $post_id, $markup_hash, $expires, $project_id ),
		) );
		$query = array(
			'page_id' => $post_id,
			'preview' => 'true',
			'wphave_mcp_visual' => $token,
		);
		if ( '' !== $project_id ) {
			$query['wphave_mcp_project'] = $project_id;
		}
		return add_query_arg( $query, home_url( '/' ) );
	}

	/** Authentication is scoped to this exact front-end page request only. */
	public static function authenticate(): void {
		if ( ! isset( $_GET['wphave_mcp_visual'] ) ||
			! function_exists( 'wphave_mcp_free_create_feature_enabled' ) ||
			! wphave_mcp_free_create_feature_enabled() ||
			is_admin() ||
			array_diff( array_keys( $_GET ), array( 'page_id', 'preview', 'wphave_mcp_visual', 'wphave_mcp_project' ) ) ||
			'true' !== ( $_GET['preview'] ?? null ) ) {
			return;
		}
		$home_path = wp_parse_url( home_url( '/' ), PHP_URL_PATH ) ?: '/';
		$request_path = wp_parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH );
		if ( $request_path !== $home_path ) {
			return;
		}
		$post_id = filter_var( $_GET['page_id'] ?? null, FILTER_VALIDATE_INT );
		$token = $_GET['wphave_mcp_visual'];
		if ( ! is_int( $post_id ) || $post_id < 1 || ! is_string( $token ) ||
			! preg_match( '/^([1-9][0-9]*)\.([1-9][0-9]*)\.([a-f0-9]{64})\.([a-f0-9]{64})$/', $token, $parts ) ) {
			return;
		}
		$actor_id = (int) $parts[1];
		$expires = (int) $parts[2];
		$project_id = $_GET['wphave_mcp_project'] ?? '';
		if ( ! is_string( $project_id ) || ( '' !== $project_id && ! wp_is_uuid( $project_id ) ) ) {
			return;
		}
		if ( $expires < time() || $expires > time() + self::MAX_AGE ||
			! hash_equals( self::signature( $actor_id, $post_id, $parts[3], $expires, $project_id ), $parts[4] ) ) {
			return;
		}
		$post = get_post( $post_id );
		if ( ! $post instanceof WP_Post || 'page' !== $post->post_type ||
			'draft' !== $post->post_status ||
			! hash_equals( $parts[3], hash( 'sha256', $post->post_content ) ) ) {
			return;
		}
		wp_set_current_user( $actor_id );
		if ( ! WPHAVE_AI_MCP_Create_Service::owns_created_draft( $post_id ) ) {
			wp_set_current_user( 0 );
			return;
		}
		if ( '' !== $project_id ) {
			if ( ! WPHAVE_AI_MCP_Free_Website_Draft_Project::contains_post( $project_id, $post_id ) ) {
				wp_set_current_user( 0 );
				return;
			}
			self::$project_id = $project_id;
		}
		self::$authenticated_hash = $parts[3];
		self::$authenticated_post_id = $post_id;
		show_admin_bar( false );
		header( 'Cache-Control: private, no-store' );
		header( 'Referrer-Policy: no-referrer' );
		header( 'X-Robots-Tag: noindex, nofollow' );
	}

	public static function include_private_draft( $query ): void {
		if ( self::$authenticated_post_id !== null && $query instanceof WP_Query &&
			$query->is_main_query() &&
			(int) $query->get( 'page_id' ) === self::$authenticated_post_id ) {
			$query->set( 'post_status', 'draft' );
		}
	}

	public static function resolve_private_draft( $posts, $query ) {
		if ( self::$authenticated_post_id === null ||
			! $query instanceof WP_Query || ! $query->is_main_query() ||
			(int) $query->get( 'page_id' ) !== self::$authenticated_post_id ) {
			return $posts;
		}
		$post = get_post( self::$authenticated_post_id );
		if ( ! $post instanceof WP_Post || 'draft' !== $post->post_status ||
			! hash_equals( self::$authenticated_hash, hash( 'sha256', $post->post_content ) ) ) {
			return $posts;
		}
		$query->found_posts = 1;
		$query->post_count = 1;
		$query->is_404 = false;
		$query->is_page = true;
		return array( $post );
	}

	public static function establish_page_context(): void {
		if ( null === self::$authenticated_post_id || null === self::$authenticated_hash ) {
			return;
		}
		global $wp_query;
		$post = get_post( self::$authenticated_post_id );
		if ( ! $wp_query instanceof WP_Query || ! $post instanceof WP_Post ||
			! hash_equals( self::$authenticated_hash, hash( 'sha256', $post->post_content ) ) ) {
			return;
		}
		$wp_query->is_404 = false;
		$wp_query->is_page = true;
		$wp_query->is_singular = true;
		$wp_query->is_home = false;
		$wp_query->queried_object = $post;
		$wp_query->queried_object_id = $post->ID;
		$wp_query->post = $post;
		$wp_query->posts = array( $post );
		$wp_query->post_count = 1;
		status_header( 200 );
	}

	public static function hide_authoring_chrome(): void {
		if ( null === self::$authenticated_post_id ) {
			return;
		}
		show_admin_bar( false );
		if ( class_exists( 'WPHAVE_Frontend_Admin_Bar' ) ) {
			remove_action( 'wp_body_open', array( 'WPHAVE_Frontend_Admin_Bar', 'render_restricted_admin_bar' ), 0 );
			remove_action( 'wp_footer', array( 'WPHAVE_Frontend_Admin_Bar', 'render_restricted_admin_bar' ), 0 );
		}
	}

	public static function print_marker(): void {
		if ( null !== self::$authenticated_hash ) {
			echo '<meta name="wphave-mcp-visual" content="' . esc_attr( self::$authenticated_hash ) . '">';
		}
	}

	public static function override_content( $content ) {
		if ( null === self::$authenticated_hash || null === self::$authenticated_post_id ) {
			return $content;
		}
		$post = get_post( self::$authenticated_post_id );
		if ( ! $post instanceof WP_Post ||
			! hash_equals( self::$authenticated_hash, hash( 'sha256', $post->post_content ) ) ) {
			return $content;
		}
		$marker = '<!-- wp:html --><span data-wphave-mcp-visual-body="' .
			esc_attr( self::$authenticated_hash ) .
			'" hidden></span><!-- /wp:html -->';
		return $marker . "\n" . $post->post_content;
	}

	public static function override_header( $header ) {
		if ( null === self::$project_id || null === self::$authenticated_post_id ) {
			return $header;
		}
		self::$private_shell = WPHAVE_AI_MCP_Free_Website_Draft_Project::shell_for_post(
			self::$project_id,
			self::$authenticated_post_id
		);
		if ( null === self::$private_shell ) {
			return $header;
		}
		return '<span data-wphave-mcp-project-shell="' . esc_attr( self::$project_id ) .
			'" hidden></span>' . self::$private_shell['headerMarkup'];
	}

	public static function override_announcement( $announcement ) {
		return null !== self::$private_shell ? '' : $announcement;
	}

	public static function override_footer( $footer ) {
		return self::$private_shell['footerMarkup'] ?? $footer;
	}

}
