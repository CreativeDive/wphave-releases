<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Short-lived, one-page preview identity for the isolated local renderer. */
final class WPHAVE_AI_MCP_Free_Visual_Preview {
	private const MAX_AGE = 30;
	private static ?string $authenticated_hash = null;
	private static ?int $authenticated_post_id = null;
	private static ?array $private_shell = null;
	private static ?string $project_id = null;
	private static ?array $shell_proposal = null;
	private static bool $interactive = false;
	private static array $interactive_targets = array();

	private static function signature( int $actor_id, int $post_id, string $markup_hash, int $expires, string $project_id, bool $interactive = false, ?array $shell_proposal = null ): string {
		$message = implode( '|', array(
			get_current_blog_id(),
			$actor_id,
			$post_id,
			$markup_hash,
			$expires,
			$project_id,
		) );
		if ( null !== $shell_proposal ) {
			$message .= '|shell|' . $shell_proposal['proposalId'] . '|' .
				$shell_proposal['headerHash'] . '|' . $shell_proposal['footerHash'];
		}
		return hash_hmac( 'sha256', $message . ( $interactive ? '|interactive' : '' ), wp_salt( 'auth' ) );
	}

	/** A browser preview requires the current WordPress session as well as the signed snapshot. */
	public static function interactive_url( string $project_id, int $post_id, string $proposal_id = '' ): ?string {
		if ( ! is_user_logged_in() || ! current_user_can( 'wphave_access' ) ||
			! current_user_can( 'wphave_manage_template_parts' ) ||
			! current_user_can( 'edit_post', $post_id ) ||
			! wp_is_uuid( $project_id ) ||
			null === WPHAVE_AI_MCP_Free_Website_Draft_Project::shell_for_post( $project_id, $post_id ) ) {
			return null;
		}
		$post = get_post( $post_id );
		if ( ! $post instanceof WP_Post || 'draft' !== $post->post_status ) {
			return null;
		}
		$shell_proposal = null;
		if ( '' !== $proposal_id ) {
			$shell_proposal = WPHAVE_AI_MCP_Free_Website_Shell_Composition_Proposal::status(
				array( 'proposalId' => $proposal_id )
			);
			if ( is_wp_error( $shell_proposal ) || $shell_proposal['projectId'] !== $project_id ||
				! in_array( $post_id, $shell_proposal['pageIds'], true ) ) {
				return null;
			}
		}
		$hash = hash( 'sha256', $post->post_content );
		return self::signed_interactive_url( $project_id, $post_id, $hash, $shell_proposal );
	}

	private static function signed_interactive_url( string $project_id, int $post_id, string $hash, ?array $shell_proposal = null ): string {
		$actor_id = get_current_user_id();
		$expires = time() + 600;
		$token = implode( '.', array(
			$actor_id,
			$expires,
			$hash,
			self::signature( $actor_id, $post_id, $hash, $expires, $project_id, true, $shell_proposal ),
		) );
		$query = array(
			'page_id' => $post_id,
			'preview' => 'true',
			'wphave_mcp_interactive' => $token,
			'wphave_mcp_project' => $project_id,
		);
		if ( null !== $shell_proposal ) {
			$query['wphave_mcp_shell'] = $shell_proposal['proposalId'];
		}
		return add_query_arg( $query, home_url( '/' ) );
	}

	public static function url( int $post_id, string $markup_hash, string $project_id = '' ): ?string {
		if ( ! WPHAVE_AI_MCP_Create_Service::owns_created_draft( $post_id ) ||
			! preg_match( '/^[a-f0-9]{64}$/', $markup_hash ) ) {
			return null;
		}
		$post = get_post( $post_id );
		if ( ! hash_equals( $markup_hash, hash( 'sha256', $post->post_content ) ) ) {
			return null;
		}
		if ( '' !== $project_id && ( ! wp_is_uuid( $project_id ) ||
			null === WPHAVE_AI_MCP_Free_Website_Draft_Project::shell_for_post( $project_id, $post_id ) ) ) {
			return null;
		}
		$actor_id = get_current_user_id();
		$expires = time() + self::MAX_AGE;
		$token = implode( '.', array(
			$actor_id,
			$expires,
			$markup_hash,
			self::signature( $actor_id, $post_id, $markup_hash, $expires, $project_id ),
		) );
		$query = array(
			'page_id' => $post_id,
			'preview' => 'true',
			'wphave_mcp_visual' => $token,
		);
		if ( '' !== $project_id ) {
			$query['wphave_mcp_project'] = $project_id;
		}
		return add_query_arg( $query, home_url( '/' ) );
	}

	/** Authentication is scoped to this exact front-end page request only. */
	public static function authenticate(): void {
		$interactive = isset( $_GET['wphave_mcp_interactive'] );
		$visual = isset( $_GET['wphave_mcp_visual'] );
		if ( $interactive === $visual ||
			! function_exists( 'wphave_mcp_free_create_feature_enabled' ) ||
			! wphave_mcp_free_create_feature_enabled() ||
			is_admin() ||
			array_diff( array_keys( $_GET ), array( 'page_id', 'preview', $interactive ? 'wphave_mcp_interactive' : 'wphave_mcp_visual', 'wphave_mcp_project', $interactive ? 'wphave_mcp_shell' : '' ) ) ||
			'true' !== ( $_GET['preview'] ?? null ) ) {
			return;
		}
		$home_path = wp_parse_url( home_url( '/' ), PHP_URL_PATH ) ?: '/';
		$request_path = wp_parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH );
		if ( $request_path !== $home_path ) {
			return;
		}
		$post_id = filter_var( $_GET['page_id'] ?? null, FILTER_VALIDATE_INT );
		$token = $_GET[ $interactive ? 'wphave_mcp_interactive' : 'wphave_mcp_visual' ];
		if ( ! is_int( $post_id ) || $post_id < 1 || ! is_string( $token ) ||
			! preg_match( '/^([1-9][0-9]*)\.([1-9][0-9]*)\.([a-f0-9]{64})\.([a-f0-9]{64})$/', $token, $parts ) ) {
			return;
		}
		$actor_id = (int) $parts[1];
		$expires = (int) $parts[2];
		$project_id = $_GET['wphave_mcp_project'] ?? '';
		if ( ! is_string( $project_id ) || ( '' !== $project_id && ! wp_is_uuid( $project_id ) ) ) {
			return;
		}
		$proposal_id = $_GET['wphave_mcp_shell'] ?? '';
		$shell_proposal = null;
		if ( ! is_string( $proposal_id ) ||
			( '' !== $proposal_id && ( ! $interactive || ! wp_is_uuid( $proposal_id ) ) ) ) {
			return;
		}
		if ( '' !== $proposal_id ) {
			$shell_proposal = WPHAVE_AI_MCP_Free_Website_Shell_Composition_Proposal::status(
				array( 'proposalId' => $proposal_id )
			);
			if ( is_wp_error( $shell_proposal ) || $shell_proposal['projectId'] !== $project_id ||
				! in_array( $post_id, $shell_proposal['pageIds'], true ) ) {
				return;
			}
		}
		$max_age = $interactive ? 600 : self::MAX_AGE;
		if ( $expires < time() || $expires > time() + $max_age ||
			! hash_equals( self::signature( $actor_id, $post_id, $parts[3], $expires, $project_id, $interactive, $shell_proposal ), $parts[4] ) ||
			( $interactive && ( '' === $project_id || ! is_user_logged_in() ||
				get_current_user_id() !== $actor_id ||
				! current_user_can( 'wphave_access' ) ||
				! current_user_can( 'wphave_manage_template_parts' ) ||
				! current_user_can( 'edit_post', $post_id ) ) ) ) {
			return;
		}
		$post = get_post( $post_id );
		if ( ! $post instanceof WP_Post || 'page' !== $post->post_type ||
			'draft' !== $post->post_status ||
			! hash_equals( $parts[3], hash( 'sha256', $post->post_content ) ) ) {
			return;
		}
		if ( ! $interactive ) {
			wp_set_current_user( $actor_id );
		}
		if ( ! WPHAVE_AI_MCP_Create_Service::owns_created_draft( $post_id ) ) {
			if ( ! $interactive ) {
				wp_set_current_user( 0 );
			}
			return;
		}
		if ( '' !== $project_id ) {
			if ( ! WPHAVE_AI_MCP_Free_Website_Draft_Project::contains_post( $project_id, $post_id ) ||
				( $interactive && null === WPHAVE_AI_MCP_Free_Website_Draft_Project::shell_for_post( $project_id, $post_id ) ) ) {
				if ( ! $interactive ) {
					wp_set_current_user( 0 );
				}
				return;
			}
			self::$project_id = $project_id;
		}
		if ( $interactive ) {
			$status = WPHAVE_AI_MCP_Free_Website_Draft_Project::status( array( 'projectId' => $project_id ) );
			if ( is_wp_error( $status ) || ! is_array( $status['siteShell'] ?? null ) ) {
				self::$project_id = null;
				return;
			}
			foreach ( $status['pages'] as $page ) {
				if ( 'draft' !== $page['status'] || ! current_user_can( 'edit_post', $page['postId'] ) ) {
					self::$project_id = null;
					return;
				}
				self::$interactive_targets[ $page['postId'] ] = $page['markupHash'];
			}
			self::$interactive = true;
			self::$shell_proposal = $shell_proposal;
		}
		self::$authenticated_hash = $parts[3];
		self::$authenticated_post_id = $post_id;
		show_admin_bar( false );
		header( 'Cache-Control: private, no-store' );
		header( 'Referrer-Policy: no-referrer' );
		header( 'X-Robots-Tag: noindex, nofollow' );
	}

	public static function include_private_draft( $query ): void {
		if ( self::$authenticated_post_id !== null && $query instanceof WP_Query &&
			$query->is_main_query() &&
			(int) $query->get( 'page_id' ) === self::$authenticated_post_id ) {
			$query->set( 'post_status', 'draft' );
		}
	}

	public static function resolve_private_draft( $posts, $query ) {
		if ( self::$authenticated_post_id === null ||
			! $query instanceof WP_Query || ! $query->is_main_query() ||
			(int) $query->get( 'page_id' ) !== self::$authenticated_post_id ) {
			return $posts;
		}
		$post = get_post( self::$authenticated_post_id );
		if ( ! $post instanceof WP_Post || 'draft' !== $post->post_status ||
			! hash_equals( self::$authenticated_hash, hash( 'sha256', $post->post_content ) ) ) {
			return $posts;
		}
		$query->found_posts = 1;
		$query->post_count = 1;
		$query->is_404 = false;
		$query->is_page = true;
		return array( $post );
	}

	public static function establish_page_context(): void {
		if ( null === self::$authenticated_post_id || null === self::$authenticated_hash ) {
			return;
		}
		global $wp_query;
		$post = get_post( self::$authenticated_post_id );
		if ( ! $wp_query instanceof WP_Query || ! $post instanceof WP_Post ||
			! hash_equals( self::$authenticated_hash, hash( 'sha256', $post->post_content ) ) ) {
			return;
		}
		$wp_query->is_404 = false;
		$wp_query->is_page = true;
		$wp_query->is_singular = true;
		$wp_query->is_home = false;
		$wp_query->queried_object = $post;
		$wp_query->queried_object_id = $post->ID;
		$wp_query->post = $post;
		$wp_query->posts = array( $post );
		$wp_query->post_count = 1;
		status_header( 200 );
	}

	public static function hide_authoring_chrome(): void {
		if ( null === self::$authenticated_post_id ) {
			return;
		}
		show_admin_bar( false );
		if ( class_exists( 'WPHAVE_Frontend_Admin_Bar' ) ) {
			remove_action( 'wp_body_open', array( 'WPHAVE_Frontend_Admin_Bar', 'render_restricted_admin_bar' ), 0 );
			remove_action( 'wp_footer', array( 'WPHAVE_Frontend_Admin_Bar', 'render_restricted_admin_bar' ), 0 );
		}
	}

	public static function print_marker(): void {
		if ( null !== self::$authenticated_hash ) {
			echo '<meta name="wphave-mcp-visual" content="' . esc_attr( self::$authenticated_hash ) . '">';
		}
	}

	public static function override_content( $content ) {
		if ( null === self::$authenticated_hash || null === self::$authenticated_post_id ) {
			return $content;
		}
		$post = get_post( self::$authenticated_post_id );
		if ( ! $post instanceof WP_Post ||
			! hash_equals( self::$authenticated_hash, hash( 'sha256', $post->post_content ) ) ) {
			return $content;
		}
		$marker = '<!-- wp:html --><span data-wphave-mcp-visual-body="' .
			esc_attr( self::$authenticated_hash ) .
			'" hidden></span><!-- /wp:html -->';
		return $marker . "\n" . $post->post_content;
	}

	public static function override_header( $header ) {
		if ( null === self::$project_id || null === self::$authenticated_post_id ) {
			return $header;
		}
		self::$private_shell = self::$shell_proposal ??
			WPHAVE_AI_MCP_Free_Website_Draft_Project::shell_for_post(
				self::$project_id,
				self::$authenticated_post_id
			);
		if ( null === self::$private_shell ) {
			return $header;
		}
		return '<span data-wphave-mcp-project-shell="' . esc_attr( self::$project_id ) .
			'" hidden></span>' . self::$private_shell['headerMarkup'];
	}

	public static function override_announcement( $announcement ) {
		return null !== self::$private_shell ? '' : $announcement;
	}

	public static function override_footer( $footer ) {
		return self::$private_shell['footerMarkup'] ?? $footer;
	}

	/** Resolve only this project's draft navigation during interactive rendering. */
	public static function interactive_navigation_link( $block ) {
		if ( ! self::$interactive || null === self::$project_id ||
			'wphave/navigation-link' !== ( $block['blockName'] ?? null ) ||
			'internal' !== ( $block['attrs']['link']['type'] ?? null ) ) {
			return $block;
		}
		$post_id = (int) ( $block['attrs']['link']['internal']['id'] ?? 0 );
		$url = isset( self::$interactive_targets[ $post_id ] ) ?
			self::signed_interactive_url(
				self::$project_id,
				$post_id,
				self::$interactive_targets[ $post_id ],
				self::$shell_proposal
			) : null;
		$block['attrs']['link'] = is_string( $url ) ?
			array( 'type' => 'external', 'external' => array( 'url' => $url ) ) :
			array( 'type' => 'none' );
		return $block;
	}

}
