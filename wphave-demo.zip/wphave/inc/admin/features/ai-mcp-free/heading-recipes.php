<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Bounded multi-line Stretch presentations for native Heading blocks. */
final class WPHAVE_AI_MCP_Free_Heading_Recipes {
	public static function specification(): ?array {
		$path = __DIR__ . '/heading-recipes.json';
		$spec = is_readable( $path ) ? json_decode( (string) file_get_contents( $path ), true ) : null;
		return is_array( $spec ) && 1 === ( $spec['version'] ?? null ) ? $spec : null;
	}

	public static function options(): ?array {
		return self::specification();
	}

	public static function valid( $recipe, $content ): bool {
		$spec = self::specification();
		$keys = is_array( $recipe ) ? array_keys( $recipe ) : array();
		sort( $keys );
		if ( null === $spec || ! is_array( $recipe ) || ! is_string( $content ) ||
			$keys !== array( 'kind', 'level', 'lines' ) ||
			$recipe['kind'] !== $spec['kind'] ||
			! in_array( $recipe['level'], $spec['levels'], true ) ||
			! is_array( $recipe['lines'] ) ||
			array_keys( $recipe['lines'] ) !== range( 0, count( $recipe['lines'] ) - 1 ) ||
			count( $recipe['lines'] ) < $spec['minLines'] || count( $recipe['lines'] ) > $spec['maxLines'] ) {
			return false;
		}
		$total = 0;
		foreach ( $recipe['lines'] as $line ) {
			if ( ! is_string( $line ) || $line !== trim( $line ) ||
				preg_match( '/[<>\r\n\x00-\x1f]/u', $line ) ||
				mb_strlen( $line ) < $spec['minCharactersPerLine'] ||
				mb_strlen( $line ) > $spec['maxCharactersPerLine'] ) {
				return false;
			}
			$total += mb_strlen( $line );
		}
		return $total <= $spec['maxCharactersTotal'] &&
			$content === implode( ' ', $recipe['lines'] );
	}

	public static function expected_attributes( array $recipe, string $content ): ?array {
		if ( ! self::valid( $recipe, $content ) ) {
			return null;
		}
		return array(
			'content' => $content,
			'wphave' => array(
				'settings' => array( 'headingLevel' => $recipe['level'], 'stretchLines' => $recipe['lines'] ),
				'features' => array( 'textStretch' => true ),
				'classNames' => 'txt-str txt-str-true',
			),
		);
	}
}
