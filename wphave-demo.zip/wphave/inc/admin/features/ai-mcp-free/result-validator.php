<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/button-recipes.php';
require_once __DIR__ . '/line-recipes.php';
require_once __DIR__ . '/spacer-recipes.php';
require_once __DIR__ . '/heading-recipes.php';
require_once __DIR__ . '/background-image-layer.php';
require_once __DIR__ . '/overlap-recipe.php';

/** Checks a browser proposal against the exact bounded F1 batch, without saving it. */
final class WPHAVE_AI_MCP_Free_Result_Validator {
	/** A successor may change only its named content attributes, never native design data. */
	public static function validate_revision( string $parent_markup, string $markup, array $parent_nodes, array $changes ) {
		$before = parse_blocks( $parent_markup );
		$after = parse_blocks( $markup );
		$paths = array();
		$siblings = array();
		foreach ( $parent_nodes as $node ) {
			$parent_key = $node['parentKey'] ?? null;
			$counter_key = $parent_key ?? '';
			$index = $siblings[ $counter_key ] ?? 0;
			$siblings[ $counter_key ] = $index + 1;
			$paths[ $node['key'] ] = null === $parent_key ? array( $index ) : array_merge( $paths[ $parent_key ], array( $index ) );
		}
		$expected = array();
		foreach ( $changes as $change ) {
			$expected[ implode( '.', $paths[ $change['key'] ] ?? array() ) ] = $change;
		}
		if ( count( $expected ) !== count( $changes ) ||
			! self::same_except_content( $before, $after, $expected ) ) {
			return new WP_Error( 'wphave_mcp_free_revision_invalid', 'The revision changed unrequested blocks or design data.' );
		}
		return true;
	}

	private static function same_except_content( array $before, array $after, array $expected, array $path = array() ): bool {
		$before = self::without_empty_separators( $before );
		$after = self::without_empty_separators( $after );
		if ( count( $before ) !== count( $after ) ) {
			return false;
		}
		foreach ( $before as $index => $old ) {
			$new = $after[ $index ];
			$block_path = array_merge( $path, array( $index ) );
			$key = implode( '.', $block_path );
			$change = $expected[ $key ] ?? null;
			$old_attrs = $old['attrs'] ?? array();
			$new_attrs = $new['attrs'] ?? array();
			$old_content = $old_attrs['content'] ?? null;
			$new_content = $new_attrs['content'] ?? null;
			unset( $old_attrs['content'], $new_attrs['content'] );
			if ( $old['blockName'] !== $new['blockName'] || $old_attrs !== $new_attrs ||
				( $old['innerHTML'] ?? '' ) !== ( $new['innerHTML'] ?? '' ) ||
				( null === $change && $old_content !== $new_content ) ||
				( null !== $change && ( $old_content !== $change['expected'] || $new_content !== $change['value'] ) ) ||
				! self::same_except_content( $old['innerBlocks'] ?? array(), $new['innerBlocks'] ?? array(), $expected, $block_path ) ) {
				return false;
			}
		}
		return true;
	}

	public static function validate( array $result, array $job ) {
		$required = array( 'jobId', 'requestId', 'revisionHash', 'contextHash', 'batchHash', 'markup' );
		if ( count( $result ) !== count( $required ) || array_diff( $required, array_keys( $result ) ) ) {
			return new WP_Error( 'wphave_mcp_free_result_invalid', 'The proposal envelope is invalid.' );
		}
		$expected = array(
			'jobId' => $job['job_id'],
			'requestId' => $job['request_id'],
			'revisionHash' => $job['revision_hash'],
			'contextHash' => $job['context_hash'],
			'batchHash' => hash( 'sha256', $job['batch_json'] ),
		);
		foreach ( $expected as $key => $value ) {
			if ( ! is_string( $result[ $key ] ) || ! hash_equals( $value, $result[ $key ] ) ) {
				return new WP_Error( 'wphave_mcp_free_result_mismatch', 'The proposal does not match this job.' );
			}
		}
		$markup = $result['markup'];
		if ( ! is_string( $markup ) || $markup === '' || strlen( $markup ) > 120000 ) {
			return new WP_Error( 'wphave_mcp_free_result_invalid', 'The proposal markup is invalid.' );
		}
		$blocks = parse_blocks( $markup );
		$batch = json_decode( $job['batch_json'], true );
		$resolved_links = is_array( $batch ) ?
			WPHAVE_AI_MCP_Free_Project_Link::resolve( $batch, (int) ( $job['target_post_id'] ?? 0 ) ) :
			new WP_Error( 'wphave_mcp_free_link_invalid', 'The project link is invalid.' );
		if ( ! is_array( $blocks ) || ! is_array( $batch ) || is_wp_error( $resolved_links ) ) {
			return new WP_Error( 'wphave_mcp_free_result_invalid', 'The proposal or its project links are invalid.' );
		}
		if ( serialize_blocks( $blocks ) !== $markup ) {
			return new WP_Error( 'wphave_mcp_free_result_invalid', 'The proposal markup is not canonical.' );
		}
		$issue = null;
		if ( ! self::matches_nodes( $blocks, $batch['nodes'] ?? array(), (int) ( $batch['version'] ?? 0 ), $resolved_links, $issue ) ) {
			return self::mismatch_error( 'wphave_mcp_free_result_invalid', $issue );
		}
		return true;
	}

	/** Check a server-resolved website batch against the same native block grammar. */
	public static function validate_website_links( array $batch, string $markup, array $resolved_links ) {
		$blocks = parse_blocks( $markup );
		if ( ! is_array( $blocks ) || serialize_blocks( $blocks ) !== $markup ) {
			return new WP_Error( 'wphave_mcp_website_link_invalid', 'The linked page markup is not canonical.' );
		}
		$issue = null;
		if ( ! self::matches_nodes( $blocks, $batch['nodes'] ?? array(), 2, $resolved_links, $issue ) ) {
			return self::mismatch_error( 'wphave_mcp_website_link_invalid', $issue );
		}
		return true;
	}

	private static function matches_nodes( array $blocks, array $nodes, int $version, array $resolved_links = array(), ?array &$issue = null ): bool {
		$expected = array();
		foreach ( $nodes as $node ) {
			$parent = $node['parentKey'];
			if ( null === $parent ) {
				$expected[] = $node;
			} else {
				self::append_child( $expected, $parent, $node );
			}
		}
		return self::matches_level( $blocks, $expected, $version, $resolved_links, $issue );
	}

	private static function mismatch_error( string $code, ?array $issue ): WP_Error {
		$key = $issue['key'] ?? 'root';
		$reason = $issue['reason'] ?? 'unknown_mismatch';
		return new WP_Error(
			$code,
			'The proposal differs from the requested block tree at ' . $key . ' (' . $reason . ').',
			array( 'nodeKey' => $key, 'reason' => $reason )
		);
	}

	private static function mismatch( ?array &$issue, string $key, string $reason ): bool {
		$issue = array( 'key' => $key, 'reason' => $reason );
		return false;
	}

	private static function append_child( array &$level, string $parent, array $node ): bool {
		foreach ( $level as &$candidate ) {
			if ( $candidate['key'] === $parent ) {
				$candidate['children'][] = $node;
				return true;
			}
			if ( isset( $candidate['children'] ) && self::append_child( $candidate['children'], $parent, $node ) ) {
				return true;
			}
		}
		return false;
	}

	private static function matches_level( array $blocks, array $expected, int $version, array $resolved_links = array(), ?array &$issue = null, string $parent_key = 'root' ): bool {
		$blocks = self::without_empty_separators( $blocks );
		if ( count( $blocks ) !== count( $expected ) ) {
			return self::mismatch( $issue, $parent_key, 'child_count' );
		}
		foreach ( $blocks as $index => $block ) {
			$node = $expected[ $index ];
			if ( trim( (string) ( $block['innerHTML'] ?? '' ) ) !== '' ) {
				return self::mismatch( $issue, $node['key'], 'unexpected_html' );
			}
			if ( ( $block['blockName'] ?? null ) !== $node['name'] ) {
				return self::mismatch( $issue, $node['key'], 'block_name' );
			}
			$attrs = $block['attrs'] ?? array();
			$actual_css = $attrs['wphave']['features']['css'] ?? null;
			$expected_css = $node['css'] ?? null;
			if ( $actual_css !== $expected_css ) {
				return self::mismatch( $issue, $node['key'], 'custom_css' );
			}
			if ( null !== $actual_css ) {
				if ( ( $attrs['wphave']['features'][ WPHAVE_CSS_Compiler::CONTRACT_KEY ] ?? null ) !==
					WPHAVE_AI_MCP_Free_Custom_CSS::contract_id( $node ) ) {
					return self::mismatch( $issue, $node['key'], 'custom_css_contract' );
				}
				unset( $attrs['wphave']['features']['css'] );
				unset( $attrs['wphave']['features'][ WPHAVE_CSS_Compiler::CONTRACT_KEY ] );
				if ( empty( $attrs['wphave']['features'] ) ) {
					unset( $attrs['wphave']['features'] );
				}
				if ( empty( $attrs['wphave'] ) ) {
					unset( $attrs['wphave'] );
				}
			}
			if ( ! self::matches_alignment( $attrs, $node ) ) {
				return self::mismatch( $issue, $node['key'], 'alignment' );
			}
			if ( ! is_array( $attrs ) || ! self::valid_registered_attributes( $node['name'], $attrs ) ) {
				return self::mismatch( $issue, $node['key'], 'registered_attributes' );
			}
			if ( $node['name'] === 'wphave/group' ) {
				if ( array_diff( array_keys( $attrs ), array( 'wphave' ) ) ||
					! self::valid_group_design( $attrs['wphave'] ?? null, $version, $node ) ) {
					return self::mismatch( $issue, $node['key'], 'group_attributes' );
				}
			} elseif ( $node['name'] === 'wphave/image' ) {
				if ( 2 !== $version || array_diff( array_keys( $attrs ), array( 'image', 'alt', 'wphave' ) ) ||
					( $attrs['image'] ?? null ) !== $node['attributes']['image'] ||
					( $attrs['alt'] ?? null ) !== $node['attributes']['alt'] ||
					( isset( $attrs['wphave'] ) && ! self::valid_image_design( $attrs['wphave'] ) ) ) {
					return self::mismatch( $issue, $node['key'], 'image_attributes' );
				}
			} elseif ( isset( $node['button'] ) ) {
				if ( ! self::matches_button_recipe( $node, $attrs, $resolved_links ) ) {
					return self::mismatch( $issue, $node['key'], 'button_recipe' );
				}
			} elseif ( isset( $node['line'] ) ) {
				$expected_line = WPHAVE_AI_MCP_Free_Line_Recipes::expected_attributes( $node['line'] );
				if ( 'wphave/line' !== $node['name'] || null === $expected_line || ! self::same_attributes( $attrs, $expected_line ) ) {
					return self::mismatch( $issue, $node['key'], 'line_recipe' );
				}
			} elseif ( isset( $node['spacer'] ) ) {
				$expected_spacer = WPHAVE_AI_MCP_Free_Spacer_Recipes::expected_attributes( $node['spacer'] );
				if ( 'wphave/spacer' !== $node['name'] || null === $expected_spacer || ! self::same_attributes( $attrs, $expected_spacer ) ) {
					return self::mismatch( $issue, $node['key'], 'spacer_recipe' );
				}
			} elseif ( isset( $node['heading'] ) ) {
				if ( ! self::matches_heading_recipe( $node, $attrs ) ) {
					return self::mismatch( $issue, $node['key'], 'heading_recipe' );
				}
			} elseif ( array_diff( array_keys( $attrs ), 2 === $version ?
				array( 'content', 'wphave', 'link' ) : array( 'content' ) ) ||
				( $node['name'] === 'wphave/button' && ( isset( $node['linkTarget'] ) ?
					( $attrs['link'] ?? null ) !== ( $resolved_links[ $node['key'] ] ?? null ) :
					isset( $attrs['link'] ) ) ) ||
				( $node['name'] !== 'wphave/button' && isset( $attrs['link'] ) ) ||
				( isset( $attrs['wphave'] ) && ! self::valid_text_design( $node['name'], $attrs['wphave'], $version ) ) ) {
				return self::mismatch( $issue, $node['key'], 'text_attributes' );
			}
			if ( ! in_array( $node['name'], array( 'wphave/group', 'wphave/image', 'wphave/line', 'wphave/spacer' ), true ) ) {
				$content = $attrs['content'] ?? html_entity_decode( wp_strip_all_tags( $block['innerHTML'] ?? '' ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
				if ( ! is_string( $content ) ) {
					return self::mismatch( $issue, $node['key'], 'content_type' );
				}
				if ( trim( $content ) !== trim( $node['attributes']['content'] ?? '' ) ) {
					return self::mismatch( $issue, $node['key'], 'content' );
				}
			}
			foreach ( $node['design'] ?? array() as $design ) {
				$device_attributes = $design['device'] === 'Mobile' ? ( $attrs['wphave']['mobile'] ?? array() ) : ( $attrs['wphave'] ?? array() );
				$parts = explode( '.', $design['path'] );
				foreach ( $parts as $part ) {
					$device_attributes = is_array( $device_attributes ) ? ( $device_attributes[ $part ] ?? null ) : null;
				}
				if ( 'background.layers' === $design['path'] ?
					! ( is_array( $device_attributes ) && is_array( $design['value'] ) &&
						self::same_attributes( $device_attributes, $design['value'] ) ) :
					$device_attributes !== $design['value'] ) {
					return self::mismatch( $issue, $node['key'], 'design_value' );
				}
			}
			if ( ! self::matches_level( $block['innerBlocks'] ?? array(), $node['children'] ?? array(), $version, $resolved_links, $issue, $node['key'] ) ) {
				return false;
			}
		}
		return true;
	}

	private static function matches_heading_recipe( array $node, array $attrs ): bool {
		$expected = WPHAVE_AI_MCP_Free_Heading_Recipes::expected_attributes(
			$node['heading'],
			$node['attributes']['content'] ?? ''
		);
		if ( 'wphave/heading' !== $node['name'] || null === $expected ) {
			return false;
		}
		if ( 'semantic' !== ( $node['heading']['kind'] ?? null ) ) {
			return self::same_attributes( $attrs, $expected );
		}
		if ( array_diff( array_keys( $attrs ), array( 'content', 'wphave' ) ) ||
			( $attrs['wphave']['settings'] ?? null ) !== $expected['wphave']['settings'] ||
			( $attrs['content'] ?? null ) !== $expected['content'] ) {
			return false;
		}
		$design_attrs = $attrs['wphave'];
		unset( $design_attrs['settings'] );
		if ( ! isset( $node['design'] ) ) {
			return empty( $design_attrs );
		}
		return self::valid_text_design( 'wphave/heading', $design_attrs, 2 );
	}

	/** Verify the native Block Alignment emission, then compare the remaining design as before. */
	private static function matches_alignment( array &$attrs, array $node ): bool {
		$alignment = $node['alignment'] ?? 'none';
		$actual = $attrs['wphave']['features']['horizontalDirection'] ?? 'none';
		if ( $actual !== $alignment ) {
			return false;
		}
		$classes = $attrs['wphave']['classNames'] ?? '';
		$expected_class = 'none' === $alignment ? '' : 'hd-' . $alignment;
		$parts = is_string( $classes ) && '' !== $classes ? explode( ' ', $classes ) : array();
		$alignment_classes = array_values( array_filter( $parts, static function ( $part ): bool {
			return str_starts_with( $part, 'hd-' );
		} ) );
		if ( $alignment_classes !== ( $expected_class ? array( $expected_class ) : array() ) ) {
			return false;
		}
		if ( 'none' !== $alignment ) {
			unset( $attrs['wphave']['features']['horizontalDirection'] );
			if ( empty( $attrs['wphave']['features'] ) ) {
				unset( $attrs['wphave']['features'] );
			}
			$remaining = array_values( array_filter( $parts, static function ( $part ): bool {
				return ! str_starts_with( $part, 'hd-' );
			} ) );
			if ( $remaining ) {
				$attrs['wphave']['classNames'] = implode( ' ', $remaining );
			} else {
				unset( $attrs['wphave']['classNames'] );
			}
			if ( empty( $attrs['wphave'] ) ) {
				unset( $attrs['wphave'] );
			}
			if ( 'wphave/heading' === $node['name'] &&
				( $attrs['wphave']['settings'] ?? null ) === array( 'headingLevel' => 'h2' ) &&
				! isset( $attrs['wphave']['text'] ) && ! isset( $attrs['wphave']['colors'] ) ) {
				unset( $attrs['wphave']['settings'] );
				if ( empty( $attrs['wphave'] ) ) {
					unset( $attrs['wphave'] );
				}
			}
		}
		return true;
	}

	/** JSON object key order is not part of the native block attribute contract. */
	private static function same_attributes( array $actual, array $expected ): bool {
		if ( count( $actual ) !== count( $expected ) ||
			array_diff( array_keys( $actual ), array_keys( $expected ) ) ) {
			return false;
		}
		foreach ( $expected as $key => $value ) {
			if ( ! array_key_exists( $key, $actual ) ) {
				return false;
			}
			if ( is_array( $value ) && is_array( $actual[ $key ] ) ) {
				if ( ! self::same_attributes( $actual[ $key ], $value ) ) {
					return false;
				}
			} elseif ( $actual[ $key ] !== $value ) {
				return false;
			}
		}
		return true;
	}

	private static function matches_button_recipe( array $node, array $attrs, array $resolved_links ): bool {
		$expected = WPHAVE_AI_MCP_Free_Button_Recipes::expected_attributes( $node['button'] );
		return 'wphave/button' === $node['name'] && null !== $expected &&
			! array_diff( array_keys( $attrs ), array( 'content', 'wphave', 'icon', 'link' ) ) &&
			( $attrs['wphave'] ?? null ) === $expected['wphave'] &&
			( $attrs['icon'] ?? null ) === ( $expected['icon'] ?? null ) &&
			( isset( $node['linkTarget'] ) ?
				( $attrs['link'] ?? null ) === ( $resolved_links[ $node['key'] ] ?? null ) :
				! isset( $attrs['link'] ) );
	}

	private static function without_empty_separators( array $blocks ): array {
		return array_values( array_filter( $blocks, static function ( $block ): bool {
			return ! ( null === ( $block['blockName'] ?? null ) &&
				'' === trim( (string) ( $block['innerHTML'] ?? '' ) ) &&
				empty( $block['attrs'] ) && empty( $block['innerBlocks'] ) );
		} ) );
	}

	private static function valid_group_design( $value, int $version, array $node = array() ): bool {
		if ( WPHAVE_AI_MCP_Spatial_Callout_Recipe::is_media_operations( $node['design'] ?? array() ) ) {
			return is_array( $value ) && self::same_attributes(
				$value,
				WPHAVE_AI_MCP_Spatial_Callout_Recipe::expected_media_attributes()
			);
		}
		if ( WPHAVE_AI_MCP_Spatial_Callout_Recipe::is_badge_operations( $node['design'] ?? array() ) ) {
			return is_array( $value ) && self::same_attributes(
				$value,
				WPHAVE_AI_MCP_Spatial_Callout_Recipe::expected_badge_attributes()
			);
		}
		$allowed_keys = 2 === $version ?
			array( 'layout', 'stylesLayout', 'classNames', 'mobile', 'dimensions', 'styles', 'stylesChild', 'background', 'stylesBackgrounds', 'classNamesBackground' ) :
			array( 'layout', 'stylesLayout', 'classNames', 'mobile' );
		if ( ! is_array( $value ) || array_diff( array_keys( $value ), $allowed_keys ) ||
			strlen( wp_json_encode( $value ) ?: '' ) > 8192 ||
			! is_array( $value['layout'] ?? null ) || array_diff( array_keys( $value['layout'] ), array( 'type', 'stacked', 'flex', 'grid' ) ) ||
			! in_array( $value['layout']['type'] ?? null, 2 === $version ? array( 'stacked', 'flex', 'grid' ) : array( 'flex' ), true ) ||
			( 'stacked' === $value['layout']['type'] && ( isset( $value['layout']['flex'] ) || isset( $value['layout']['grid'] ) || isset( $value['layout']['stacked'] ) ) ) ||
			( 'flex' === $value['layout']['type'] && ( isset( $value['layout']['grid'] ) || ! self::valid_flex( $value['layout']['flex'] ?? array(), false, $version ) ) ) ||
			( 'grid' === $value['layout']['type'] && ( isset( $value['layout']['flex'] ) || ! self::valid_grid( $value['layout']['grid'] ?? array(), false ) ) ) ||
			! self::valid_mobile( $value['mobile'] ?? array(), $version, $value['layout']['type'] ) ||
			( 'stacked' === $value['layout']['type'] ? isset( $value['stylesLayout'] ) :
				( ! is_string( $value['stylesLayout'] ?? null ) || strlen( $value['stylesLayout'] ) > 4096 ||
				! preg_match( '/^(?:--ly-[a-z0-9-]+: [a-z0-9()#, .%_-]+)(?:;--ly-[a-z0-9-]+: [a-z0-9()#, .%_-]+)*$/', $value['stylesLayout'] ) ||
				preg_match( '/(?:url|expression|undefined|javascript|!important)/i', $value['stylesLayout'] ) ) ) ||
			! is_string( $value['classNames'] ?? null ) ||
			! preg_match( '/^[a-z0-9_ -]{1,160}$/', $value['classNames'] ) ||
			( 'stacked' === $value['layout']['type'] && ! preg_match( '/(?:^| )ly ly-stk(?: |$)/', $value['classNames'] ) ) ) {
			return false;
		}
		if ( 2 === $version && isset( $value['background'] ) ) {
			$background = $value['background'];
			$has_color = isset( $background['color'] );
			$has_layers = isset( $background['layers'] );
			if ( ! is_array( $background ) || array_diff( array_keys( $background ), array( 'color', 'layers' ) ) ||
				( $has_color && ( ! is_array( $background['color'] ) || array_keys( $background['color'] ) !== array( 'base' ) ||
					! self::valid_catalog_value( 'background.color.base', $background['color']['base'] ) ||
					! str_contains( $value['classNames'], 'bg-co bg' ) ) ) ||
				( $has_layers && ! self::valid_group_background_layer( $value, $node ) ) ||
				( ! $has_color && ! $has_layers ) ) {
				return false;
			}
		}
		if ( ! isset( $value['background']['layers'] ) &&
			( isset( $value['stylesBackgrounds'] ) || isset( $value['classNamesBackground'] ) ) ) {
			return false;
		}
		if ( 2 === $version && ! self::valid_group_dimensions( $value ) ) {
			return false;
		}
		if ( 2 === $version && 'flex' === $value['layout']['type'] &&
			! self::valid_flex_emission( $value ) ) {
			return false;
		}
		return true;
	}

	private static function valid_group_background_layer( array $value, array $node ): bool {
		$catalog = WPHAVE_AI_MCP_Free_Design_Grammar::catalog();
		$rules = is_wp_error( $catalog ) ? array() : array_column( $catalog['groupOperations'], null, 'path' );
		$layers = $value['background']['layers'] ?? null;
		$operation = null;
		foreach ( $node['design'] ?? array() as $candidate ) {
			if ( 'background.layers' === ( $candidate['path'] ?? null ) ) {
				$operation = $candidate;
				break;
			}
		}
		if ( null === $operation || is_wp_error( $catalog ) ||
			! WPHAVE_AI_MCP_Free_Background_Image_Layer::valid(
				$layers,
				$rules['background.color.base']['values'] ?? array()
		) || ! self::same_attributes( $layers, $operation['value'] ) ) {
			return false;
		}
		$overlay = $layers[0]['overlay'];
		$expected_css = '--bg-mda-img-fit: cover;--bg-mda-img-pos: 50% 50%;--ov-ax: 0%;--ov-co: ' .
			$overlay['color'] . ';--ov-op: ' . $overlay['opacity'] . ';--ov-bg: var(--ov-co)';
		return ( $value['stylesBackgrounds'] ?? null ) === array( $expected_css ) &&
			( $value['classNamesBackground'] ?? null ) === array( '' );
	}

	private static function valid_flex_emission( array $value ): bool {
		$declarations = explode( ';', $value['stylesLayout'] );
		foreach ( array(
			array( $value['layout']['flex'] ?? array(), '--ly-fl-wrap: ', 'flexWrap', array( 'wrap' => 'wrap', 'no-wrap' => 'nowrap' ) ),
			array( $value['mobile']['layout']['flex'] ?? array(), '--ly-m-fl-wrap: ', 'flexWrap', array( 'wrap' => 'wrap', 'no-wrap' => 'nowrap' ) ),
			array( $value['layout']['flex'] ?? array(), '--ly-fl-itm: ', 'flexItemSizing', array( 'no-shrink' => '1 0 auto' ) ),
		) as $rule ) {
			list( $attributes, $prefix, $key, $values ) = $rule;
			if ( isset( $attributes[ $key ] ) &&
				! in_array( $prefix . ( $values[ $attributes[ $key ] ] ?? '' ), $declarations, true ) ) {
				return false;
			}
		}
		return true;
	}

	private static function valid_text_design( string $name, $value, int $version ): bool {
		$has_size = isset( $value['text'] );
		$has_color = isset( $value['colors'] ) || isset( $value['styles'] );
		if ( 2 !== $version || ! in_array( $name, array( 'wphave/heading', 'wphave/paragraph' ), true ) ||
			! is_array( $value ) || array_diff( array_keys( $value ), array( 'settings', 'text', 'classNames', 'mobile', 'colors', 'styles' ) ) ||
			( ! $has_size && ! $has_color ) ||
			( $has_size && ( ! is_array( $value['text'] ) || array_keys( $value['text'] ) !== array( 'typeface' ) ||
				! is_array( $value['text']['typeface'] ) || array_keys( $value['text']['typeface'] ) !== array( 'size' ) ||
				! self::valid_text_size( $name, $value['text']['typeface']['size'] ) ) ) ||
			! is_string( $value['classNames'] ?? null ) ||
			! preg_match( $has_size ? '/^(?:tx-co )?tf-fs tf-fs-(?:title|text)-[a-z0-9-]+(?: tf-fs-m(?: tf-fs-(?:title|text)-[a-z0-9-]+-m)?)?$/' : '/^tx-co$/', $value['classNames'] ) ) {
			return false;
		}
		if ( $name === 'wphave/heading' ) {
			if ( isset( $value['settings'] ) && $value['settings'] !== array( 'headingLevel' => 'h2' ) ) {
				return false;
			}
		} elseif ( isset( $value['settings'] ) ) {
			return false;
		}
		if ( isset( $value['mobile'] ) ) {
			$mobile = $value['mobile'];
			if ( ! $has_size || ! str_contains( $value['classNames'], ' tf-fs-m' ) ||
				! is_array( $mobile ) || array_keys( $mobile ) !== array( 'text' ) ||
				! is_array( $mobile['text'] ) || array_keys( $mobile['text'] ) !== array( 'typeface' ) ||
				! is_array( $mobile['text']['typeface'] ) || array_keys( $mobile['text']['typeface'] ) !== array( 'size' ) ||
				! self::valid_text_size( $name, $mobile['text']['typeface']['size'] ) ) {
				return false;
			}
		} elseif ( str_contains( $value['classNames'], ' tf-fs-m' ) ) {
			return false;
		}
		if ( isset( $value['colors'] ) || isset( $value['styles'] ) ) {
			$catalog = WPHAVE_AI_MCP_Free_Design_Grammar::catalog();
			$colors = $value['colors'] ?? null;
			$token = is_array( $colors ) ? ( $colors['text'] ?? null ) : null;
			if ( is_wp_error( $catalog ) ||
				! is_array( $colors ) || array_keys( $colors ) !== array( 'text' ) ||
				! in_array( $token, $catalog['textColorOperation']['values'], true ) ||
				( $value['styles'] ?? null ) !== '--tx-co: ' . $token ||
				! str_starts_with( $value['classNames'], $has_size ? 'tx-co ' : 'tx-co' ) ) {
				return false;
			}
		} elseif ( str_starts_with( $value['classNames'], 'tx-co ' ) ) {
			return false;
		}
		return true;
	}

	private static function valid_text_size( string $name, $value ): bool {
		$catalog = WPHAVE_AI_MCP_Free_Design_Grammar::catalog();
		$rule = is_wp_error( $catalog ) ? null : ( $catalog['textOperations'][ $name ] ?? null );
		return is_array( $rule ) && is_array( $value ) &&
			array_keys( $value ) === array( 'type' ) && in_array( $value, $rule['values'], true );
	}

	private static function valid_image_design( $value ): bool {
		if ( is_array( $value ) && isset( $value['dimensions']['position'] ) ) {
			return WPHAVE_AI_MCP_Overlap_Recipe::allowed() &&
				self::same_attributes( $value, WPHAVE_AI_MCP_Overlap_Recipe::expected_attributes() );
		}
		$catalog = WPHAVE_AI_MCP_Free_Design_Grammar::catalog();
		$rules = is_wp_error( $catalog ) ? array() : array_column( $catalog['imageOperations'], null, 'path' );
		if ( ! isset( $rules['dimensions.width.custom'], $rules['dimensions.aspectRatio.ratio'], $rules['settings.objectPosition'] ) ||
			! is_array( $value ) || array_diff( array_keys( $value ), array( 'dimensions', 'settings', 'styles', 'classNames', 'mobile' ) ) ||
			! is_array( $value['dimensions'] ?? null ) || ! is_string( $value['classNames'] ?? null ) ) {
			return false;
		}
		$mobile = $value['mobile'] ?? array();
		if ( ! is_array( $mobile ) || array_diff( array_keys( $mobile ), array( 'dimensions' ) ) ||
			( isset( $mobile['dimensions'] ) && ! is_array( $mobile['dimensions'] ) ) ) {
			return false;
		}
		$position = $value['settings']['objectPosition'] ?? null;
		if ( isset( $value['settings'] ) &&
			( ! is_array( $value['settings'] ) || array_keys( $value['settings'] ) !== array( 'objectPosition' ) ||
				! WPHAVE_AI_MCP_Free_Design_Grammar::valid_image_position(
					$position,
					$rules['settings.objectPosition']['values']
				) ) ) {
			return false;
		}
		$styles = array( '--object-position' => null === $position ? 'center' : str_replace( '-', ' ', $position ) );
		$classes = array();
		foreach ( array( '' => $value['dimensions'], '-m' => $mobile['dimensions'] ?? array() ) as $suffix => $dimensions ) {
			if ( ! is_array( $dimensions ) || array_diff( array_keys( $dimensions ), array( 'width', 'aspectRatio' ) ) ) {
				return false;
			}
			foreach ( array( 'width' => array( 'custom', 'dimensions.width.custom', '--wi', 'wi' ),
				'aspectRatio' => array( 'ratio', 'dimensions.aspectRatio.ratio', '--asrt', 'asrt' ) ) as $key => $definition ) {
				if ( ! isset( $dimensions[ $key ] ) ) {
					continue;
				}
				list( $field, $path, $variable, $class ) = $definition;
				if ( ! is_array( $dimensions[ $key ] ) || array_keys( $dimensions[ $key ] ) !== array( $field ) ||
					! in_array( $dimensions[ $key ][ $field ], $rules[ $path ]['values'], true ) ||
					( '-m' === $suffix && ! isset( $value['dimensions'][ $key ] ) ) ) {
					return false;
				}
				$styles[ $variable . $suffix ] = $dimensions[ $key ][ $field ];
				$classes[] = $class . $suffix;
			}
		}
		if ( array() === $classes || ( isset( $value['mobile'] ) && empty( $mobile['dimensions'] ) ) ) {
			return false;
		}
		$actual_classes = explode( ' ', $value['classNames'] );
		sort( $actual_classes );
		sort( $classes );
		return $actual_classes === $classes &&
			self::valid_css_declarations( $value['styles'] ?? null, $styles );
	}

	private static function valid_group_dimensions( array $value ): bool {
		$desktop = $value['dimensions'] ?? array();
		$mobile = $value['mobile']['dimensions'] ?? array();
		if ( ! is_array( $desktop ) || ! is_array( $mobile ) ||
			array_diff( array_keys( $desktop ), array( 'spacing', 'width' ) ) ||
			array_diff( array_keys( $mobile ), array( 'spacing', 'width' ) ) ) {
			return false;
		}
		$styles = array();
		$child_styles = array();
		foreach ( array( '' => $desktop, '-m' => $mobile ) as $suffix => $dimensions ) {
			if ( isset( $dimensions['spacing'] ) ) {
				$spacing = $dimensions['spacing'];
				if ( ! is_array( $spacing ) || array() === $spacing ||
					array_diff( array_keys( $spacing ), array( 'padding', 'margin' ) ) ) {
					return false;
				}
				if ( isset( $spacing['padding'] ) ) {
					if ( ! self::valid_catalog_value( 'dimensions.spacing.padding', $spacing['padding'] ) ||
						( '-m' === $suffix && ! isset( $desktop['spacing']['padding'] ) ) ) {
						return false;
					}
					foreach ( array( '', '-top', '-right', '-bottom', '-left' ) as $side ) {
						$styles['--pa' . $suffix . $side] = $spacing['padding'];
					}
					foreach ( array( 'left', 'right' ) as $side ) {
						$child_styles['--' . $side . '-spacing-inherit' . $suffix] = $spacing['padding'];
					}
				}
				if ( isset( $spacing['margin'] ) ) {
					$margin = $spacing['margin'];
					if ( ! self::valid_catalog_value( 'dimensions.spacing.margin', $margin ) ||
						( '-m' === $suffix && ( ! isset( $desktop['spacing']['margin'] ) || '0' !== $margin ) ) ) {
						return false;
					}
					$sides = '0' === $margin ? array( '0', '0', '0', '0' ) : explode( ' ', $margin );
					if ( 4 !== count( $sides ) ) {
						return false;
					}
					$styles['--ma' . $suffix] = $margin;
					foreach ( array( 'top', 'right', 'bottom', 'left' ) as $index => $side ) {
						$styles['--ma' . $suffix . '-' . $side] = '0' === $sides[ $index ] ? '0px' : $sides[ $index ];
					}
				}
			}
			if ( isset( $dimensions['width'] ) ) {
				$width = $dimensions['width'];
				if ( ! is_array( $width ) || array_keys( $width ) !== array( 'custom' ) ||
					! self::valid_catalog_value( 'dimensions.width.custom', $width['custom'] ) ||
					( '-m' === $suffix && ! isset( $desktop['width'] ) ) ) {
					return false;
				}
				$styles['--wi' . $suffix] = $width['custom'];
			}
		}
		if ( isset( $value['background']['color'] ) ) {
			$styles['--bg-co'] = $value['background']['color']['base'];
		}
		if ( 'grid' === ( $value['layout']['type'] ?? null ) ) {
			$container = ( $value['layout']['grid']['keepColumns'] ?? 'auto' ) === 'nowrap' ? 'normal' : 'inline-size';
			foreach ( array( '', '-t', '-m' ) as $suffix ) {
				$styles['--ly-grid-container' . $suffix] = $container;
			}
		}
		if ( isset( $desktop['spacing']['padding'] ) && ! str_contains( $value['classNames'], 'pa' ) ||
			isset( $desktop['spacing']['margin'] ) && ! str_contains( $value['classNames'], 'ma' ) ||
			isset( $desktop['width'] ) && ! str_contains( $value['classNames'], 'wi' ) ) {
			return false;
		}
		return self::valid_css_declarations( $value['styles'] ?? null, $styles ) &&
			self::valid_css_declarations( $value['stylesChild'] ?? null, $child_styles );
	}

	private static function valid_css_declarations( $css, array $allowed ): bool {
		if ( array() === $allowed ) {
			return null === $css;
		}
		if ( ! is_string( $css ) || strlen( $css ) > 4096 ) {
			return false;
		}
		$seen = array();
		foreach ( explode( ';', $css ) as $declaration ) {
			if ( ! preg_match( '/^(--[a-z-]+): (.+)$/', $declaration, $matches ) ||
				! isset( $allowed[ $matches[1] ] ) ||
				! hash_equals( $allowed[ $matches[1] ], $matches[2] ) ||
				isset( $seen[ $matches[1] ] ) ) {
				return false;
			}
			$seen[ $matches[1] ] = true;
		}
		return count( $seen ) === count( $allowed );
	}

	private static function valid_flex( $flex, bool $mobile, int $version ): bool {
		$allowed_keys = 2 === $version ? array( 'flexDirection', 'flexWrap', 'flexItemSizing', 'alignVertical', 'gapX', 'gapY' ) : array( 'flexDirection', 'alignVertical' );
		if ( ! is_array( $flex ) || array_diff( array_keys( $flex ), $allowed_keys ) ) {
			return false;
		}
		$directions = 2 === $version ? array( 'row', 'column', 'row-reverse', 'column-reverse' ) : ( $mobile ? array( 'row' ) : array( 'column' ) );
		if ( isset( $flex['flexDirection'] ) && ! in_array( $flex['flexDirection'], $directions, true ) ) {
			return false;
		}
		if ( isset( $flex['flexWrap'] ) && ! in_array( $flex['flexWrap'], array( 'wrap', 'no-wrap' ), true ) ||
			isset( $flex['flexItemSizing'] ) && ( $mobile || 'no-shrink' !== $flex['flexItemSizing'] ) ) {
			return false;
		}
		foreach ( array( 'gapX', 'gapY' ) as $gap ) {
			if ( isset( $flex[ $gap ] ) && ! self::valid_catalog_value( 'layout.flex.' . $gap, $flex[ $gap ] ) ) {
				return false;
			}
		}
		return ! isset( $flex['alignVertical'] ) || ( $mobile && $flex['alignVertical'] === 'start' );
	}

	private static function valid_grid( $grid, bool $mobile ): bool {
		if ( ! is_array( $grid ) || array_diff( array_keys( $grid ), array( 'columns', 'keepColumns', 'gridColumnLayout', 'gapX', 'gapY' ) ) ||
			( isset( $grid['keepColumns'] ) && ( $mobile || ! in_array( $grid['keepColumns'], array( 'auto', 'nowrap' ), true ) ) ) ||
			( isset( $grid['gridColumnLayout'] ) && ( $mobile || 'equal' !== $grid['gridColumnLayout'] ) ) ) {
			return false;
		}
		if ( isset( $grid['columns'] ) && ! in_array( $grid['columns'], array( 1, 2, 3, 4 ), true ) ) {
			return false;
		}
		foreach ( array( 'gapX', 'gapY' ) as $gap ) {
			if ( isset( $grid[ $gap ] ) && ! self::valid_catalog_value( 'layout.grid.' . $gap, $grid[ $gap ] ) ) {
				return false;
			}
		}
		return true;
	}

	private static function valid_catalog_value( string $path, $value ): bool {
		$catalog = WPHAVE_AI_MCP_Free_Design_Grammar::catalog();
		if ( is_wp_error( $catalog ) || ! is_string( $value ) ) {
			return false;
		}
		foreach ( $catalog['groupOperations'] as $rule ) {
			if ( $rule['path'] === $path ) {
				return in_array( $value, $rule['values'], true );
			}
		}
		return false;
	}

	private static function valid_mobile( $mobile, int $version, string $layout_type = 'flex' ): bool {
		return is_array( $mobile ) && ( $mobile === array() ||
			( ! array_diff( array_keys( $mobile ), 2 === $version ? array( 'layout', 'dimensions' ) : array( 'layout' ) ) &&
				( ! isset( $mobile['layout'] ) || ( is_array( $mobile['layout'] ) &&
					array_keys( $mobile['layout'] ) === array( $layout_type ) &&
					( 'grid' === $layout_type ?
						self::valid_grid( $mobile['layout']['grid'], true ) :
						self::valid_flex( $mobile['layout']['flex'], true, $version ) ) ) ) &&
				( ! isset( $mobile['dimensions'] ) || ( 2 === $version && is_array( $mobile['dimensions'] ) ) ) ) );
	}

	private static function valid_registered_attributes( string $name, array $attrs ): bool {
		$type = WP_Block_Type_Registry::get_instance()->get_registered( $name );
		if ( ! $type instanceof WP_Block_Type || ! is_array( $type->attributes ) ) {
			return false;
		}
		foreach ( $attrs as $key => $value ) {
			if ( ! is_string( $key ) || ! array_key_exists( $key, $type->attributes ) ||
				is_wp_error( rest_validate_value_from_schema( $value, $type->attributes[ $key ], $key ) ) ) {
				return false;
			}
		}
		return true;
	}
}
