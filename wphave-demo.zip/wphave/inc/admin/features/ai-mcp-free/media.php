<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/background-image-layer.php';

/** Checks that a batch only uses readable, local WordPress image attachments. */
final class WPHAVE_AI_MCP_Free_Media {
	/** Return bounded, readable local images usable by the batch contract. */
	public static function options(): array {
		$attachments = get_posts( array(
			'post_type' => 'attachment',
			'post_status' => 'inherit',
			'post_mime_type' => array( 'image/png', 'image/jpeg', 'image/webp', 'image/avif' ),
			'posts_per_page' => 24,
			'orderby' => 'date',
			'order' => 'DESC',
		) );
		$options = array();
		foreach ( $attachments as $attachment ) {
			$alt = (string) get_post_meta( $attachment->ID, '_wp_attachment_image_alt', true );
			$batch = array( 'nodes' => array( array(
				'name' => 'wphave/image',
				'attributes' => array( 'image' => (int) $attachment->ID, 'alt' => $alt ),
			) ) );
			if ( is_wp_error( self::verified_ids( $batch ) ) ) {
				continue;
			}
			$options[] = array(
				'id' => (int) $attachment->ID,
				'alt' => $alt,
				'title' => get_the_title( $attachment->ID ),
			);
		}
		return $options;
	}

	public static function verified_ids( array $batch ) {
		$ids = array();
		foreach ( $batch['nodes'] ?? array() as $node ) {
			$references = array();
			if ( ( $node['name'] ?? null ) === 'wphave/image' ) {
				$attributes = $node['attributes'] ?? array();
				$alt = $attributes['alt'] ?? null;
				if ( ! is_string( $alt ) || trim( $alt ) === '' || strlen( $alt ) > 500 ||
					preg_match( '/<[^>]*>/', $alt ) || count( $attributes ) !== 2 ||
					array_diff( array_keys( $attributes ), array( 'image', 'alt' ) ) ) {
					return new WP_Error( 'wphave_mcp_free_media_invalid', 'The image attachment is unavailable.' );
				}
				$references[] = array( 'id' => $attributes['image'] ?? null, 'alt' => $alt );
			}
			foreach ( $node['design'] ?? array() as $operation ) {
				if ( ( $operation['path'] ?? null ) === 'background.layers' ) {
					$references[] = array(
						'id' => WPHAVE_AI_MCP_Free_Background_Image_Layer::image_id( $operation['value'] ?? null ),
						'alt' => null,
					);
				}
			}
			foreach ( $references as $reference ) {
				$id = $reference['id'];
				$alt = $reference['alt'];
				if ( ! is_int( $id ) || $id < 1 || count( $ids ) >= 8 ) {
					return new WP_Error( 'wphave_mcp_free_media_invalid', 'The image attachment is unavailable.' );
				}
			$post = get_post( $id );
			$path = get_attached_file( $id );
			$uploads = wp_get_upload_dir();
			$file = is_string( $path ) ? realpath( $path ) : false;
			$base = realpath( $uploads['basedir'] ?? '' );
			if ( ! $post instanceof WP_Post || $post->post_type !== 'attachment' ||
				$post->post_status !== 'inherit' || ! current_user_can( 'read_post', $id ) ||
				! in_array( $post->post_mime_type, array( 'image/png', 'image/jpeg', 'image/webp', 'image/avif' ), true ) ||
				! is_string( $file ) || ! is_string( $base ) ||
				! str_starts_with( $file, $base . DIRECTORY_SEPARATOR ) ||
				! is_readable( $file ) || filesize( $file ) > 15728640 ||
				( null !== $alt && ! hash_equals( (string) get_post_meta( $id, '_wp_attachment_image_alt', true ), $alt ) ) ) {
				return new WP_Error( 'wphave_mcp_free_media_invalid', 'The image attachment is unavailable.' );
			}
			$ids[] = $id;
			}
		}
		return array_values( array_unique( $ids ) );
	}
}
