<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'page.create_free' => array(
		'family' => 'page',
		'familySummary' => 'Plan and create individual website page drafts.',
		'intentId' => 'page.create',
		'statusAbilityId' => 'wphave/free-page-status',
		'completionMode' => 'status_ability',
		'statusReference' => 'jobId',
		'statusMap' => array(
			'pending' => 'running',
			'claimed' => 'running',
			'completed' => 'completed',
			'failed' => 'failed',
			'expired' => 'failed',
			'stale' => 'failed',
		),
		'resultContract' => array(
			'kind' => 'page_proposal',
			'description' => 'A private page proposal is ready for review; it has not been saved as a page.',
		),
		'id' => 'wphave/free-page-create-complete-draft',
		'effect' => 'private_page_draft',
		'stages' => array( 'plan', 'qualify', 'create', 'review' ),
		'steps' => array(
			'wphave/free-page-plan-content',
			'wphave/free-page-design-options',
			'wphave/free-page-plan-layout',
			'wphave/free-page-create-complete-draft',
		),
	),
	'website.create_free' => array(
		'family' => 'website',
		'familySummary' => 'Plan and create a coordinated set of website page drafts.',
		'intentId' => 'website.create',
		'statusAbilityId' => 'wphave/website-drafts-status',
		'completionMode' => 'status_ability',
		'statusReference' => 'projectId',
		'statusMap' => array(
			'pending' => 'running',
			'links-pending' => 'running',
			'drafts-created' => 'completed',
			'links-complete' => 'completed',
			'incomplete' => 'partial',
			'failed' => 'failed',
		),
		'resultContract' => array(
			'kind' => 'private_website_drafts',
			'description' => 'Private website page drafts were saved; they were not published.',
		),
		'id' => 'wphave/website-create-drafts',
		'effect' => 'private_website_drafts',
		'stages' => array( 'plan', 'qualify', 'create', 'review' ),
		'steps' => array(
			'wphave/site-project-create',
			'wphave/free-page-plan-content',
			'wphave/free-page-design-options',
			'wphave/free-page-plan-layout',
			'wphave/website-create-drafts',
			'wphave/website-drafts-status',
		),
	),
);
