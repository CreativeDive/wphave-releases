<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Durable, actor-scoped claim for direct MCP image writes. */
final class WPHAVE_AI_MCP_Media_Request {
	private const PREFIX = 'wphave_ai_mcp_image_';
	private const ATTACHMENT_KEY = '_wphave_ai_mcp_image_request';
	private const RESULT_KEY = '_wphave_ai_mcp_image_result';

	public static function begin( string $operation, array $input ) {
		$request_id = $input['requestId'] ?? null;
		if ( ! in_array( $operation, array( 'import', 'generate' ), true ) ||
			! is_string( $request_id ) || ! preg_match( '/^[A-Za-z0-9_-]{16,80}$/D', $request_id ) ) {
			return new WP_Error( 'wphave_mcp_image_invalid', 'A valid requestId is required.' );
		}
		unset( $input['requestId'] );
		ksort( $input );
		$key = self::PREFIX . hash( 'sha256', get_current_blog_id() . ':' . get_current_user_id() . ':' . $operation . ':' . $request_id );
		$hash = hash( 'sha256', wp_json_encode( $input ) );
		$record = WPHAVE_AI_MCP_Media_Request_Store::claim( $key, $operation, $hash );
		if ( is_wp_error( $record ) ) {
			return $record;
		}
		if ( ! is_array( $record ) || ! hash_equals( $record['hash'], $hash ) ||
			$record['actorId'] !== get_current_user_id() ||
			$record['siteId'] !== get_current_blog_id() ) {
			return new WP_Error( 'wphave_mcp_image_conflict', 'The requestId was already used with different input.' );
		}
		return array( 'key' => $key, 'new' => true === ( $record['new'] ?? false ), 'record' => $record );
	}

	/** Persist a byte witness before WordPress can create an attachment. */
	public static function expect( string $key, string $path, string $filename, string $alt, string $title, string $mime ) {
		$hash = hash_file( 'sha256', $path );
		if ( ! is_string( $hash ) || ! WPHAVE_AI_MCP_Media_Request_Store::change( $key, 'running', array(
			'expected_hash' => $hash,
			'expected_mime' => $mime,
			'expected_filename' => $filename,
			'expected_title' => $title,
			'expected_alt' => $alt,
		) ) ) {
			return new WP_Error( 'wphave_mcp_image_store_unavailable', 'The image upload witness could not be stored.' );
		}
		return true;
	}

	public static function attachment_created( string $key, int $id ) {
		$record = WPHAVE_AI_MCP_Media_Request_Store::read( $key );
		$path = $id > 0 ? get_attached_file( $id ) : false;
		$actual_hash = is_string( $path ) && is_file( $path ) ? hash_file( 'sha256', $path ) : false;
		if ( ! is_array( $record ) || 'running' !== $record['state'] ||
			! in_array( $record['attachmentId'], array( 0, $id ), true ) ||
			(int) get_post_field( 'post_author', $id ) !== $record['actorId'] ||
			$record['expectedMime'] !== get_post_mime_type( $id ) ||
			$record['expectedTitle'] !== get_the_title( $id ) ||
			! is_string( $actual_hash ) ||
			! hash_equals( $record['expectedHash'], $actual_hash ) ) {
			return new WP_Error( 'wphave_mcp_image_pending', 'The new attachment does not match the image request.' );
		}
		$stored = $id > 0 && WPHAVE_AI_MCP_Media_Request_Store::change( $key, 'running', array(
			'attachment_id' => $id,
		) );
		if ( ! $stored ) {
			$record = WPHAVE_AI_MCP_Media_Request_Store::read( $key );
			$stored = is_array( $record ) && 'running' === $record['state'] &&
				$id === $record['attachmentId'];
		}
		if ( ! $stored ||
			( ! update_post_meta( $id, self::ATTACHMENT_KEY, $key ) &&
				$key !== get_post_meta( $id, self::ATTACHMENT_KEY, true ) ) ) {
			return new WP_Error( 'wphave_mcp_image_pending', 'The attachment identity could not be committed.' );
		}
		return true;
	}

	public static function result( array $claim ) {
		$record = $claim['record'];
		if ( 'completed' === ( $record['state'] ?? '' ) && self::valid_attachment( $claim['key'], $record ) ) {
			return $record['result'];
		}
		$recovered = self::recover( $claim['key'], $record );
		if ( null !== $recovered ) {
			return $recovered;
		}
		if ( 'failed' === ( $record['state'] ?? '' ) ) {
			return new WP_Error( $record['error'] ?? 'wphave_mcp_image_failed', 'The original image request failed. Use a new requestId for a deliberate retry.' );
		}
		return new WP_Error( 'wphave_mcp_image_pending', 'The original request may still be running. Query site-image-request-status before any new request.' );
	}

	public static function finish( string $key, $result, bool $recovery = false ) {
		$record = WPHAVE_AI_MCP_Media_Request_Store::read( $key );
		$expected_state = $recovery ? 'recovering' : 'running';
		if ( ! is_array( $record ) || $expected_state !== $record['state'] ) {
			return new WP_Error( 'wphave_mcp_image_failed', 'The image request claim was lost.' );
		}
		if ( is_wp_error( $result ) ) {
			if ( 'wphave_mcp_image_pending' === $result->get_error_code() ) {
				return $result;
			}
			WPHAVE_AI_MCP_Media_Request_Store::change( $key, $expected_state, array(
				'state' => 'failed',
				'error_code' => $result->get_error_code(),
			) );
			return $result;
		}
		$id = (int) ( $result['id'] ?? 0 );
		if ( ! $id ||
			( ! update_post_meta( $id, self::ATTACHMENT_KEY, $key ) &&
				$key !== get_post_meta( $id, self::ATTACHMENT_KEY, true ) ) ||
			$key !== get_post_meta( $id, self::ATTACHMENT_KEY, true ) ||
			( ! update_post_meta( $id, self::RESULT_KEY, $result ) &&
				$result !== get_post_meta( $id, self::RESULT_KEY, true ) ) ||
			! self::valid_result( $id, $result ) ) {
			return new WP_Error( 'wphave_mcp_image_pending', 'The image result could not be committed. Inspect request status.' );
		}
		if ( ! WPHAVE_AI_MCP_Media_Request_Store::change( $key, $expected_state, array(
			'state' => 'completed',
			'attachment_id' => $id,
			'result_json' => wp_json_encode( $result ),
		) ) ) {
			return new WP_Error( 'wphave_mcp_image_pending', 'The image result could not be committed. Inspect request status.' );
		}
		return $result;
	}

	public static function status( $input ) {
		if ( ! WPHAVE_AI_MCP_Free_Media_Import::can_import() || ! is_array( $input ) ||
			array_diff( array_keys( $input ), array( 'operation', 'requestId' ) ) ||
			! is_string( $input['operation'] ?? null ) ) {
			return new WP_Error( 'wphave_mcp_image_invalid', 'The status request is invalid.' );
		}
		$request_id = $input['requestId'] ?? null;
		if ( ! is_string( $request_id ) || ! preg_match( '/^[A-Za-z0-9_-]{16,80}$/D', $request_id ) ||
			! in_array( $input['operation'], array( 'import', 'generate' ), true ) ) {
			return new WP_Error( 'wphave_mcp_image_invalid', 'The status request is invalid.' );
		}
		$key = self::PREFIX . hash( 'sha256', get_current_blog_id() . ':' . get_current_user_id() . ':' . $input['operation'] . ':' . $request_id );
		$record = WPHAVE_AI_MCP_Media_Request_Store::read( $key );
		if ( is_wp_error( $record ) ) {
			return $record;
		}
		if ( ! is_array( $record ) ) {
			return array( 'state' => 'unknown' );
		}
		// Status does not know the original payload; the claim hash is intentionally ignored.
		if ( 'completed' === ( $record['state'] ?? '' ) ) {
			return self::valid_attachment( $key, $record ) ?
				array( 'state' => 'completed', 'result' => $record['result'] ) :
				self::recovery_status( 'attachment_unverified', $record, $key );
		}
		$recovered = self::recover( $key, $record );
		if ( null !== $recovered ) {
			return array( 'state' => 'completed', 'result' => $recovered, 'recovered' => true );
		}
		if ( 'failed' === ( $record['state'] ?? '' ) ) {
			return array( 'state' => 'failed', 'error' => $record['error'] ?? 'wphave_mcp_image_failed' );
		}
		return time() - ( $record['created'] ?? 0 ) < 60 ?
			array( 'state' => 'running' ) :
			self::recovery_status( 'request_unresolved', $record, $key );
	}

	private static function recovery_status( string $reason, array $record, string $key ): array {
		$candidates = self::unmarked_candidates( $key, $record );
		$status = array(
			'state' => 'needs_recovery',
			'reason' => $reason,
			'createdAt' => (int) ( $record['created'] ?? 0 ),
			'instruction' => 'Inspect the Media Library. If the candidate image is the intended result, use site-image-request-recover with its attachment ID. Otherwise investigate before starting a deliberate new requestId.',
		);
		if ( 1 === count( $candidates ) ) {
			$status['candidateAttachmentId'] = $candidates[0];
		}
		return $status;
	}

	/** Explicit recovery is a write; the status ability only identifies a candidate. */
	public static function recover_unmarked( $input ) {
		if ( ! WPHAVE_AI_MCP_Free_Media_Import::can_import() || ! is_array( $input ) ||
			array_diff( array_keys( $input ), array( 'operation', 'requestId', 'attachmentId' ) ) ||
			! in_array( $input['operation'] ?? null, array( 'import', 'generate' ), true ) ||
			! is_string( $input['requestId'] ?? null ) ||
			! preg_match( '/^[A-Za-z0-9_-]{16,80}$/D', $input['requestId'] ) ||
			! is_int( $input['attachmentId'] ?? null ) || $input['attachmentId'] < 1 ) {
			return new WP_Error( 'wphave_mcp_image_invalid', 'The recovery request is invalid.' );
		}
		$key = self::PREFIX . hash( 'sha256', get_current_blog_id() . ':' . get_current_user_id() . ':' . $input['operation'] . ':' . $input['requestId'] );
		$record = WPHAVE_AI_MCP_Media_Request_Store::read( $key );
		if ( is_wp_error( $record ) ) {
			return $record;
		}
		if ( ! is_array( $record ) ||
			! in_array( $record['state'], array( 'running', 'recovering' ), true ) ||
			$record['operation'] !== $input['operation'] ||
			$record['actorId'] !== get_current_user_id() ||
			$record['siteId'] !== get_current_blog_id() ||
			time() - $record['created'] < 60 ||
			self::unmarked_candidates( $key, $record ) !== array( $input['attachmentId'] ) ) {
			return new WP_Error( 'wphave_mcp_image_recovery_unavailable', 'The attachment cannot be attributed to this request.' );
		}
		if ( 'running' === $record['state'] &&
			! WPHAVE_AI_MCP_Media_Request_Store::change( $key, 'running', array( 'state' => 'recovering' ) ) ) {
			return new WP_Error( 'wphave_mcp_image_pending', 'The recovery claim could not be obtained.' );
		}
		$id = $input['attachmentId'];
		if ( ! current_user_can( 'edit_post', $id ) ||
			(int) get_post_field( 'post_author', $id ) !== get_current_user_id() ) {
			return new WP_Error( 'wphave_mcp_image_recovery_unavailable', 'The attachment cannot be edited by the request actor.' );
		}
		$path = get_attached_file( $id );
		$inspected = is_string( $path ) ?
			WPHAVE_AI_Media_Import_Service::inspect_file( $path, $record['expectedFilename'] ) :
			new WP_Error( 'wphave_mcp_image_recovery_unavailable', 'The image file is missing.' );
		if ( is_wp_error( $inspected ) || $inspected['mime'] !== $record['expectedMime'] ) {
			return new WP_Error( 'wphave_mcp_image_recovery_unavailable', 'The image file could not be verified.' );
		}
		if ( ! wp_get_attachment_metadata( $id ) ) {
			require_once ABSPATH . 'wp-admin/includes/image.php';
			$metadata = wp_generate_attachment_metadata( $id, $path );
			if ( ! is_array( $metadata ) ||
				( $metadata && ! wp_update_attachment_metadata( $id, $metadata ) &&
					$metadata !== wp_get_attachment_metadata( $id ) ) ) {
				return new WP_Error( 'wphave_mcp_image_recovery_unavailable', 'The image metadata could not be restored.' );
			}
		}
		update_post_meta( $id, '_wp_attachment_image_alt', $record['expectedAlt'] );
		if ( 'generate' === $record['operation'] &&
			! WPHAVE_AI_Media_Import_Service::mark_ai_origin( $id, 'generated' ) ) {
			return new WP_Error( 'wphave_mcp_image_recovery_unavailable', 'The generated-image origin could not be verified.' );
		}
		$result = array(
			'id' => $id,
			'alt' => $record['expectedAlt'],
			'title' => get_the_title( $id ),
			'mimeType' => $inspected['mime'],
			'width' => $inspected['width'],
			'height' => $inspected['height'],
		);
		return self::finish( $key, $result, true );
	}

	/** Bounded post query plus byte hash; ambiguity always blocks adoption. */
	private static function unmarked_candidates( string $key, array $record ): array {
		if ( ! is_string( $record['expectedHash'] ?? null ) ||
			! preg_match( '/^[a-f0-9]{64}$/D', $record['expectedHash'] ) ) {
			return array();
		}
		$ids = $record['attachmentId'] > 0 ? array( $record['attachmentId'] ) : get_posts( array(
			'post_type' => 'attachment',
			'post_status' => 'inherit',
			'author' => $record['actorId'],
			'posts_per_page' => 201,
			'fields' => 'ids',
			'date_query' => array( array(
				'column' => 'post_date_gmt',
				'after' => gmdate( 'Y-m-d H:i:s', max( 0, $record['created'] - 60 ) ),
				'before' => gmdate( 'Y-m-d H:i:s', $record['created'] + 3600 ),
				'inclusive' => true,
			) ),
		) );
		if ( ! is_array( $ids ) || count( $ids ) > 200 ) {
			return array();
		}
		$candidates = array();
		foreach ( $ids as $id ) {
			$id = (int) $id;
			$marker = get_post_meta( $id, self::ATTACHMENT_KEY, true );
			$alt = get_post_meta( $id, '_wp_attachment_image_alt', true );
			$path = get_attached_file( $id );
			$actual_hash = is_string( $path ) && is_file( $path ) ? hash_file( 'sha256', $path ) : false;
			if ( ( '' !== $marker && $key !== $marker ) ||
				( '' !== $alt && $record['expectedAlt'] !== $alt ) ||
				$record['expectedMime'] !== get_post_mime_type( $id ) ||
				$record['expectedTitle'] !== get_the_title( $id ) ||
				! is_string( $actual_hash ) ||
				! hash_equals( $record['expectedHash'], $actual_hash ) ) {
				continue;
			}
			$candidates[] = $id;
		}
		return $candidates;
	}

	private static function valid_attachment( string $key, array $record ): bool {
		$id = (int) ( $record['result']['id'] ?? 0 );
		return $id > 0 && 'attachment' === get_post_type( $id ) &&
			$key === get_post_meta( $id, self::ATTACHMENT_KEY, true ) &&
			self::valid_result( $id, $record['result'] );
	}

	/** A committed attachment witness can resolve a lost ledger completion without another write. */
	private static function recover( string $key, array $record ): ?array {
		if ( 'running' !== ( $record['state'] ?? '' ) ) {
			return null;
		}
		$ids = get_posts( array(
			'post_type' => 'attachment',
			'post_status' => 'inherit',
			'posts_per_page' => 2,
			'fields' => 'ids',
			'meta_key' => self::ATTACHMENT_KEY,
			'meta_value' => $key,
		) );
		if ( ! is_array( $ids ) || 1 !== count( $ids ) ) {
			return null;
		}
		$id = (int) $ids[0];
		$result = get_post_meta( $id, self::RESULT_KEY, true );
		return is_array( $result ) && self::valid_result( $id, $result ) ? $result : null;
	}

	private static function valid_result( int $id, array $result ): bool {
		if ( $id < 1 || $id !== (int) ( $result['id'] ?? 0 ) ||
			'attachment' !== get_post_type( $id ) ||
			get_post_mime_type( $id ) !== ( $result['mimeType'] ?? null ) ||
			get_post_meta( $id, '_wp_attachment_image_alt', true ) !== ( $result['alt'] ?? null ) ||
			get_the_title( $id ) !== ( $result['title'] ?? null ) ) {
			return false;
		}
		$verified = WPHAVE_AI_MCP_Free_Media::verified_ids( array(
			'nodes' => array( array(
				'name' => 'wphave/image',
				'attributes' => array( 'image' => $id, 'alt' => $result['alt'] ),
			) ),
		) );
		return ! is_wp_error( $verified ) && $verified === array( $id );
	}
}
