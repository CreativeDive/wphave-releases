<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/job-store.php';

/** Fail-closed storage qualification for the single captured F1.5 Group/Flex contract. */
final class WPHAVE_AI_MCP_Free_Draft_Qualification {
	private static function contract(): ?array {
		$path = __DIR__ . '/flex-design-contract-v1.json';
		if ( ! is_file( $path ) ) {
			return null;
		}
		$decoded = json_decode( (string) file_get_contents( $path ), true );
		return is_array( $decoded ) && ( $decoded['version'] ?? null ) === 1 ? $decoded : null;
	}

	private static function same_file( string $path, string $expected ): bool {
		return is_file( $path ) && preg_match( '/^[a-f0-9]{64}$/', $expected ) &&
			hash_equals( $expected, hash_file( 'sha256', $path ) );
	}

	private static function runtime_matches( array $contract ): bool {
		$root = dirname( __DIR__, 4 );
		$provenance = $contract['provenance'] ?? array();
		if ( ( $provenance['wphaveVersion'] ?? null ) !== ( defined( 'WPHAVE_VERSION' ) ? WPHAVE_VERSION : null ) ||
			( $provenance['wordpressVersion'] ?? null ) !== get_bloginfo( 'version' ) ||
			! self::same_file( $root . '/build/ai/bundle.js', $provenance['aiBuildSha256'] ?? '' ) ||
			! self::same_file( $root . '/build/block-runtime/bundle.js', $provenance['blockRuntimeBuildSha256'] ?? '' ) ) {
			return false;
		}
		$paths = array(
			'wphave/group' => 'group',
			'wphave/heading' => 'heading',
			'wphave/paragraph' => 'paragraph',
			'wphave/button' => 'button',
		);
		foreach ( $paths as $name => $directory ) {
			if ( ! self::same_file(
				$root . '/build/block-types/blocks/' . $directory . '/block.json',
				$provenance['blockDefinitionSha256'][ $name ] ?? ''
			) ) {
				return false;
			}
		}
		return true;
	}

	private static function has_only_whitespace_html( array $blocks ): bool {
		foreach ( $blocks as $block ) {
			if ( trim( (string) ( $block['innerHTML'] ?? '' ) ) !== '' ||
				! self::has_only_whitespace_html( $block['innerBlocks'] ?? array() ) ) {
				return false;
			}
		}
		return true;
	}

	private static function design_matches( array $blocks, array $expected ): bool {
		foreach ( $blocks as $block ) {
			if ( ( $block['blockName'] ?? null ) === 'wphave/group' &&
				( $block['attrs']['wphave'] ?? null ) !== $expected ) {
				return false;
			}
			if ( ! self::design_matches( $block['innerBlocks'] ?? array(), $expected ) ) {
				return false;
			}
		}
		return true;
	}

	public static function qualify( array $job, array $result ) {
		$contract = self::contract();
		if ( null === $contract || ! self::runtime_matches( $contract ) ) {
			return new WP_Error( 'wphave_mcp_free_contract_stale', 'The captured design contract is unavailable.' );
		}
		$batch = json_decode( (string) ( $job['batch_json'] ?? '' ), true );
		if ( ! is_array( $batch ) || ( $batch['version'] ?? null ) !== $contract['batchVersion'] ||
			! is_array( $batch['nodes'] ?? null ) || count( $batch['nodes'] ) !== 4 ) {
			return new WP_Error( 'wphave_mcp_free_contract_batch', 'The batch is outside the design contract.' );
		}
		$names = array_column( $batch['nodes'], 'name' );
		$group_key = $batch['nodes'][0]['key'] ?? null;
		if ( $names !== array( 'wphave/group', 'wphave/heading', 'wphave/paragraph', 'wphave/button' ) ||
			! is_string( $group_key ) || ! array_key_exists( 'parentKey', $batch['nodes'][0] ) ||
			$batch['nodes'][0]['parentKey'] !== null ) {
			return new WP_Error( 'wphave_mcp_free_contract_batch', 'The block sequence differs from the captured contract.' );
		}
		foreach ( array_slice( $batch['nodes'], 1 ) as $node ) {
			if ( ( $node['parentKey'] ?? null ) !== $group_key ) {
				return new WP_Error( 'wphave_mcp_free_contract_batch', 'The block nesting differs from the captured contract.' );
			}
		}
		foreach ( $batch['nodes'] as $node ) {
			if ( ( $node['name'] ?? null ) === 'wphave/group' &&
				( $node['design'] ?? null ) !== array( $contract['supportedOperation'] ) ) {
				return new WP_Error( 'wphave_mcp_free_contract_batch', 'The design operation differs from the captured contract.' );
			}
			if ( ( $node['name'] ?? null ) !== 'wphave/group' ) {
				$content = $node['attributes']['content'] ?? null;
				if ( ! is_string( $content ) || preg_match( '/[<>\x00-\x08\x0B\x0C\x0E-\x1F]/', $content ) ) {
					return new WP_Error( 'wphave_mcp_free_contract_content', 'The draft requires plain text content.' );
				}
			}
		}
		$structural = WPHAVE_AI_MCP_Free_Result_Validator::validate( $result, $job );
		if ( is_wp_error( $structural ) ) {
			return $structural;
		}
		$markup = $result['markup'];
		$blocks = parse_blocks( $markup );
		$children = $blocks[0]['innerBlocks'] ?? array();
		foreach ( array_slice( $batch['nodes'], 1 ) as $index => $node ) {
			if ( ( $children[ $index ]['attrs']['content'] ?? null ) !== $node['attributes']['content'] ) {
				return new WP_Error( 'wphave_mcp_free_contract_content', 'The native content differs from the requested text.' );
			}
		}
		if ( serialize_blocks( $blocks ) !== $markup ||
			! self::has_only_whitespace_html( $blocks ) ||
			! self::design_matches( $blocks, $contract['designAttributes'] ) ) {
			return new WP_Error( 'wphave_mcp_free_contract_result', 'The native proposal differs from the captured design contract.' );
		}
		return array(
			'status' => 'qualified',
			'contractVersion' => 1,
			'markupHash' => hash( 'sha256', $markup ),
		);
	}

	public static function qualify_job_id( string $job_id ) {
		$snapshot = WPHAVE_AI_MCP_Free_Job_Store::qualification_snapshot( $job_id );
		if ( is_wp_error( $snapshot ) ) {
			return $snapshot;
		}
		$qualified = self::qualify( $snapshot['job'], $snapshot['result'] );
		if ( is_wp_error( $qualified ) ) {
			return $qualified;
		}
		return array(
			'job' => $snapshot['job'],
			'result' => $snapshot['result'],
			'qualification' => $qualified,
		);
	}
}
