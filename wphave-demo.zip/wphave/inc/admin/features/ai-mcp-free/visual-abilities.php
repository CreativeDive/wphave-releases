<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Read-only rendered screenshots and geometry of ledger-owned private drafts. */
final class WPHAVE_AI_MCP_Free_Visual_Abilities {
	private static function browser_binary(): ?string {
		if ( defined( 'WPHAVE_MCP_CHROME_BINARY' ) ) {
			$binary = WPHAVE_MCP_CHROME_BINARY;
			return is_string( $binary ) && is_executable( $binary ) ? $binary : null;
		}
		foreach ( array(
			'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
			'/usr/bin/google-chrome',
			'/usr/bin/chromium',
			'/usr/bin/chromium-browser',
		) as $binary ) {
			if ( is_executable( $binary ) ) {
				return $binary;
			}
		}
		return null;
	}

	public static function register(): void {
		if ( ! function_exists( 'wphave_mcp_free_create_feature_enabled' ) ||
			! wphave_mcp_free_create_feature_enabled() ||
			! function_exists( 'wp_register_ability' ) ) {
			return;
		}
		$input_schema = array(
			'type' => 'object',
			'properties' => array(
				'postId' => array( 'type' => 'integer' ),
				'expectedMarkupHash' => array( 'type' => 'string' ),
				'viewport' => array( 'type' => 'string', 'enum' => array( 'wide', 'desktop', 'tablet', 'mobile' ) ),
				'projectId' => array( 'type' => 'string' ),
			),
			'required' => array( 'postId', 'expectedMarkupHash', 'viewport' ),
			'additionalProperties' => false,
		);
		wp_register_ability( 'wphave/site-visual-screenshot', array(
			'category' => 'wphave-free-create',
			'label' => __( 'Inspect private page visually', 'wphave' ),
			'description' => __( 'Render a ledger-owned private draft at a fixed wide, desktop, tablet or mobile viewport and return its screenshot.', 'wphave' ),
			'input_schema' => $input_schema,
			'permission_callback' => array( __CLASS__, 'can_inspect' ),
			'execute_callback' => array( __CLASS__, 'screenshot' ),
			'meta' => array(
				'public' => false,
				'show_in_rest' => false,
				'mcp' => array( 'public' => true ),
				'annotations' => array( 'readonly' => true, 'destructive' => false, 'idempotent' => true ),
			),
		) );
		wp_register_ability( 'wphave/site-visual-report', array(
			'category' => 'wphave-free-create',
			'label' => __( 'Check private page layout', 'wphave' ),
			'description' => __( 'Measure real wide, desktop, tablet and mobile geometry of a ledger-owned private draft, including words split across heading lines. Inspect the report and screenshots before claiming visual completion.', 'wphave' ),
			'input_schema' => array(
				'type' => 'object',
				'properties' => array(
					'postId' => array( 'type' => 'integer' ),
					'expectedMarkupHash' => array( 'type' => 'string' ),
					'projectId' => array( 'type' => 'string' ),
				),
				'required' => array( 'postId', 'expectedMarkupHash' ),
				'additionalProperties' => false,
			),
			'permission_callback' => array( __CLASS__, 'can_inspect' ),
			'execute_callback' => array( __CLASS__, 'report' ),
			'meta' => array(
				'public' => false,
				'show_in_rest' => false,
				'mcp' => array( 'public' => true ),
				'annotations' => array( 'readonly' => true, 'destructive' => false, 'idempotent' => true ),
			),
		) );
	}

	public static function can_inspect(): bool {
		return WPHAVE_AI_MCP_Free_Create_Abilities::can_create();
	}

	private static function render_view( $input, string $viewport ) {
		if ( ! self::can_inspect() || ! is_array( $input ) ||
			! is_int( $input['postId'] ?? null ) ||
			! is_string( $input['expectedMarkupHash'] ?? null ) ||
			! preg_match( '/^[a-f0-9]{64}$/', $input['expectedMarkupHash'] ) ||
			( isset( $input['projectId'] ) &&
				( ! is_string( $input['projectId'] ) || ! wp_is_uuid( $input['projectId'] ) ) ) ) {
			return new WP_Error( 'wphave_mcp_visual_forbidden', 'The private visual check is unavailable.' );
		}
		$post_id = $input['postId'];
		$hash = $input['expectedMarkupHash'];
		$url = WPHAVE_AI_MCP_Free_Visual_Preview::url(
			$post_id,
			$hash,
			$input['projectId'] ?? ''
		);
		$browser = self::browser_binary();
		$runner = realpath( dirname( __DIR__, 4 ) . '/build/ai-mcp-visual-check/runner.cjs' );
		if ( ! is_string( $url ) || null === $browser || false === $runner ) {
			return new WP_Error( 'wphave_mcp_visual_unavailable', 'The private visual renderer is unavailable.' );
		}
		$width = array( 'wide' => 1440, 'desktop' => 1024, 'tablet' => 716, 'mobile' => 479 )[ $viewport ];
		$result = WPHAVE_AI_MCP_Free_Host_Runner::execute_json( $runner, array(
			'url' => $url,
			'width' => $width,
			'expectedHash' => $hash,
			'expectedProjectId' => $input['projectId'] ?? null,
			'browser' => $browser,
		), 4096, 9000000, 20 );
		if ( is_wp_error( $result ) || ! is_array( $result['metrics'] ?? null ) ||
			! is_string( $result['png'] ?? null ) ) {
			return new WP_Error( 'wphave_mcp_visual_failed', 'The private visual render failed.' );
		}
		$png = base64_decode( $result['png'], true );
		$image_info = is_string( $png ) ? getimagesizefromstring( $png ) : false;
		if ( ! is_array( $image_info ) || 'image/png' !== ( $image_info['mime'] ?? null ) ||
			(int) $image_info[0] !== $width || strlen( $png ) > 6000000 ||
			(int) ( $result['metrics']['viewportWidth'] ?? 0 ) !== $width ||
			! is_int( $result['metrics']['documentWidth'] ?? null ) ||
			! is_int( $result['metrics']['documentHeight'] ?? null ) ||
			! is_int( $result['metrics']['brokenImages'] ?? null ) ||
			! is_int( $result['metrics']['outsideText'] ?? null ) ||
			! is_int( $result['metrics']['brokenHeadingWords'] ?? null ) ||
			! is_array( $result['metrics']['headingIssues'] ?? null ) ||
			! is_array( $result['metrics']['headings'] ?? null ) ) {
			return new WP_Error( 'wphave_mcp_visual_failed', 'The visual evidence is invalid.' );
		}
		$post = get_post( $post_id );
		if ( ! WPHAVE_AI_MCP_Create_Service::owns_created_draft( $post_id ) ||
			! $post instanceof WP_Post ||
			! hash_equals( $hash, hash( 'sha256', $post->post_content ) ) ) {
			return new WP_Error( 'wphave_mcp_visual_stale', 'The draft changed during visual inspection.' );
		}
		return array(
			'png' => $png,
			'metrics' => $result['metrics'],
			'viewport' => $viewport,
			'postId' => $post_id,
			'markupHash' => $hash,
			'runnerHash' => hash_file( 'sha256', $runner ),
		);
	}

	public static function screenshot( $input ) {
		if ( ! is_array( $input ) ||
			array_diff( array_keys( $input ), array( 'postId', 'expectedMarkupHash', 'viewport', 'projectId' ) ) ||
			! in_array( $input['viewport'] ?? null, array( 'wide', 'desktop', 'tablet', 'mobile' ), true ) ) {
			return new WP_Error( 'wphave_mcp_visual_invalid', 'The visual request is invalid.' );
		}
		$result = self::render_view( $input, $input['viewport'] );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return array(
			'type' => 'image',
			'results' => $result['png'],
			'mimeType' => 'image/png',
			'_meta' => array(
				'postId' => $result['postId'],
				'projectId' => $input['projectId'] ?? null,
				'previewContext' => isset( $input['projectId'] ) ? 'projectProposal' : 'activeSite',
				'viewport' => $result['viewport'],
				'markupHash' => $result['markupHash'],
				'runnerHash' => $result['runnerHash'],
				'metrics' => $result['metrics'],
			),
		);
	}

	public static function report( $input ) {
		if ( ! is_array( $input ) ||
			array_diff( array_keys( $input ), array( 'postId', 'expectedMarkupHash', 'projectId' ) ) ) {
			return new WP_Error( 'wphave_mcp_visual_invalid', 'The visual request is invalid.' );
		}
		$views = array();
		foreach ( array( 'wide', 'desktop', 'tablet', 'mobile' ) as $viewport ) {
			$view = self::render_view( $input, $viewport );
			if ( is_wp_error( $view ) ) {
				return $view;
			}
			$metrics = $view['metrics'];
			$views[ $viewport ] = array(
				'viewportWidth' => $metrics['viewportWidth'],
				'documentWidth' => $metrics['documentWidth'],
				'documentHeight' => $metrics['documentHeight'],
				'brokenImages' => $metrics['brokenImages'],
				'outsideText' => $metrics['outsideText'],
				'brokenHeadingWords' => $metrics['brokenHeadingWords'],
				'headingIssues' => $metrics['headingIssues'],
				'headings' => $metrics['headings'],
				'pass' => $metrics['documentWidth'] <= $metrics['viewportWidth'] &&
					0 === $metrics['brokenImages'] && 0 === $metrics['outsideText'] &&
					0 === $metrics['brokenHeadingWords'],
			);
		}
		return array(
			'postId' => $input['postId'],
			'projectId' => $input['projectId'] ?? null,
			'previewContext' => isset( $input['projectId'] ) ? 'projectProposal' : 'activeSite',
			'markupHash' => $input['expectedMarkupHash'],
			'views' => $views,
			'pass' => $views['wide']['pass'] && $views['desktop']['pass'] &&
				$views['tablet']['pass'] && $views['mobile']['pass'],
		);
	}
}
