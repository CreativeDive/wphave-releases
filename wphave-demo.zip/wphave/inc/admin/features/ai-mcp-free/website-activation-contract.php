<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Pure state model used by the existing activation service; it performs no WP writes. */
final class WPHAVE_AI_MCP_Website_Activation_Contract {
	public static function initial( array $plan, string $request_id ): array {
		$pages = array();
		$steps = array( 'stage-header', 'stage-footer' );
		foreach ( $plan['pages'] as $page ) {
			$pages[ (string) $page['postId'] ] = array(
				'status' => 'draft',
				'contentHash' => $page['contentHash'],
			);
			$steps[] = 'publish-page:' . $page['postId'];
		}
		$steps = array_merge( $steps, array(
			'publish-header',
			'publish-footer',
			'assign-parts',
			'set-page-on-front',
			'set-show-on-front',
		) );
		$before = array(
			'pages' => $pages,
			'parts' => array( 'header' => null, 'footer' => null ),
			'assignments' => $plan['assignmentBefore'],
			'front' => $plan['frontPageBefore'],
		);
		return array(
			'ledgerVersion' => 1,
			'requestId' => $request_id,
			'planHash' => $plan['planHash'],
			'planContentHash' => hash( 'sha256', wp_json_encode( $plan ) ),
			'snapshotHash' => hash( 'sha256', wp_json_encode( $plan['projectSnapshot'] ) ),
			'projectRevision' => $plan['projectSnapshot']['projectRevision'],
			'siteId' => $plan['projectSnapshot']['siteId'],
			'actorId' => $plan['projectSnapshot']['actorId'],
			'designFingerprint' => $plan['designFingerprint'],
			'assignmentRevision' => $plan['assignmentRevision'],
			'frontPageRevision' => $plan['frontPageRevision'],
			'headerHash' => $plan['header']['hash'],
			'footerHash' => $plan['footer']['hash'],
			'homePostId' => $plan['frontPageProposed']['page_on_front'],
			'impactAcknowledgment' => $plan['impactAcknowledgment'],
			'steps' => $steps,
			'phase' => 0,
			'beforeState' => $before,
			'expectedState' => $before,
			'history' => array(),
			'status' => 'prepared',
		);
	}

	public static function advance( array $ledger, array $observed, array $effect = array() ) {
		if ( $observed !== ( $ledger['expectedState'] ?? null ) ||
			! is_int( $ledger['phase'] ?? null ) ||
			! isset( $ledger['steps'][ $ledger['phase'] ] ) ||
			! in_array( $ledger['status'] ?? null, array( 'prepared', 'running' ), true ) ) {
			return new WP_Error( 'wphave_mcp_website_activation_conflict', 'The observed state differs from the ledger.' );
		}
		$step = $ledger['steps'][ $ledger['phase'] ];
		$next = $observed;
		if ( in_array( $step, array( 'stage-header', 'stage-footer' ), true ) ) {
			$type = substr( $step, 6 );
			$id = $effect['partId'] ?? null;
			if ( count( $effect ) !== 1 || ! is_int( $id ) || $id < 1 ||
				$id === ( $next['parts']['header']['postId'] ?? null ) ||
				$id === ( $next['parts']['footer']['postId'] ?? null ) ) {
				return new WP_Error( 'wphave_mcp_website_activation_invalid', 'The staged part identity is invalid.' );
			}
			$next['parts'][ $type ] = array(
				'postId' => $id,
				'contentHash' => $type === 'header' ? $ledger['headerHash'] : $ledger['footerHash'],
				'status' => 'draft',
			);
		} elseif ( array() !== $effect ) {
			return new WP_Error( 'wphave_mcp_website_activation_invalid', 'Unexpected phase effect.' );
		} elseif ( str_starts_with( $step, 'publish-page:' ) ) {
			$id = substr( $step, 13 );
			if ( ! isset( $next['pages'][ $id ] ) || 'draft' !== $next['pages'][ $id ]['status'] ) {
				return new WP_Error( 'wphave_mcp_website_activation_conflict', 'A page changed before publication.' );
			}
			$next['pages'][ $id ]['status'] = 'publish';
		} elseif ( in_array( $step, array( 'publish-header', 'publish-footer' ), true ) ) {
			$type = substr( $step, 8 );
			if ( 'draft' !== ( $next['parts'][ $type ]['status'] ?? null ) ) {
				return new WP_Error( 'wphave_mcp_website_activation_conflict', 'A staged part changed.' );
			}
			$next['parts'][ $type ]['status'] = 'publish';
		} elseif ( 'assign-parts' === $step ) {
			foreach ( array( 'header', 'footer' ) as $type ) {
				if ( 'publish' !== ( $next['parts'][ $type ]['status'] ?? null ) ) {
					return new WP_Error( 'wphave_mcp_website_activation_conflict', 'A part is not ready.' );
				}
				$next['assignments'][ $type ] = $next['parts'][ $type ]['postId'];
			}
		} elseif ( 'set-page-on-front' === $step ) {
			$next['front']['page_on_front'] = $ledger['homePostId'];
		} elseif ( 'set-show-on-front' === $step ) {
			$next['front']['show_on_front'] = 'page';
		} else {
			return new WP_Error( 'wphave_mcp_website_activation_invalid', 'Unknown phase.' );
		}
		$ledger['history'][] = array( 'step' => $step, 'before' => $observed, 'after' => $next );
		$ledger['expectedState'] = $next;
		++$ledger['phase'];
		$ledger['status'] = count( $ledger['steps'] ) === $ledger['phase'] ? 'completed' : 'running';
		return $ledger;
	}

	public static function recovery( array $ledger, array $observed ): array {
		if ( $observed !== ( $ledger['expectedState'] ?? null ) ||
			! is_int( $ledger['phase'] ?? null ) ||
			$ledger['phase'] !== count( $ledger['history'] ?? array() ) ||
			$ledger['phase'] > count( $ledger['steps'] ?? array() ) ) {
			return array( 'status' => 'manual-conflict', 'restoreState' => null );
		}
		return array(
			'status' => 'automatic-rollback-eligible',
			'reverseSteps' => array_reverse( array_column( $ledger['history'], 'step' ) ),
			'restoreState' => $ledger['beforeState'],
		);
	}
}
