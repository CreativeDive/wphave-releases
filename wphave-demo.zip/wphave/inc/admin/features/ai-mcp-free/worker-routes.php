<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Same-origin browser worker endpoints; never exposed as MCP abilities. */
final class WPHAVE_AI_MCP_Free_Worker_Routes {
	public static function register(): void {
		register_rest_route( 'wphave/v1', '/mcp/website-workspace/projects', array(
			'methods' => WP_REST_Server::READABLE,
			'permission_callback' => array( __CLASS__, 'can_view_website_projects' ),
			'callback' => array( __CLASS__, 'website_projects' ),
		) );
		register_rest_route( 'wphave/v1', '/mcp/free-shell/site-preview', array(
			'methods' => WP_REST_Server::READABLE,
			'permission_callback' => array( __CLASS__, 'can_manage_shell' ),
			'callback' => array( __CLASS__, 'site_preview' ),
			'args' => array(
				'projectId' => array( 'required' => true, 'type' => 'string' ),
				'headerJobId' => array( 'required' => true, 'type' => 'string' ),
				'footerJobId' => array( 'required' => true, 'type' => 'string' ),
				'pageKey' => array( 'required' => true, 'type' => 'string', 'enum' => array( 'home', 'services' ) ),
			),
		) );
		register_rest_route( 'wphave/v1', '/mcp/free-shell/footer/(?P<jobId>[a-f0-9-]{36})', array(
			'methods' => WP_REST_Server::READABLE,
			'permission_callback' => array( __CLASS__, 'can_manage_shell' ),
			'callback' => array( __CLASS__, 'footer_review' ),
		) );
		register_rest_route( 'wphave/v1', '/mcp/free-shell/header/(?P<jobId>[a-f0-9-]{36})', array(
			'methods' => WP_REST_Server::READABLE,
			'permission_callback' => array( __CLASS__, 'can_manage_shell' ),
			'callback' => array( __CLASS__, 'header_review' ),
		) );
		register_rest_route( 'wphave/v1', '/mcp/free-page/review/(?P<jobId>[a-f0-9-]{36})/editor-gate', array(
			'methods' => WP_REST_Server::READABLE,
			'permission_callback' => array( __CLASS__, 'can_use' ),
			'callback' => array( __CLASS__, 'editor_gate' ),
		) );
		register_rest_route( 'wphave/v1', '/mcp/free-page/review/(?P<jobId>[a-f0-9-]{36})/replay', array(
			'methods' => WP_REST_Server::READABLE,
			'permission_callback' => array( __CLASS__, 'can_use' ),
			'callback' => array( __CLASS__, 'replay' ),
		) );
		register_rest_route( 'wphave/v1', '/mcp/free-page/review/(?P<jobId>[a-f0-9-]{36})', array(
			'methods' => WP_REST_Server::READABLE,
			'permission_callback' => array( __CLASS__, 'can_use' ),
			'callback' => array( __CLASS__, 'review' ),
		) );
		register_rest_route( 'wphave/v1', '/mcp/free-page/claim', array(
			'methods' => WP_REST_Server::CREATABLE,
			'permission_callback' => array( __CLASS__, 'can_use' ),
			'callback' => array( __CLASS__, 'claim' ),
			'args' => array( 'jobId' => array( 'required' => true, 'type' => 'string' ) ),
		) );
		register_rest_route( 'wphave/v1', '/mcp/free-page/finish', array(
			'methods' => WP_REST_Server::CREATABLE,
			'permission_callback' => array( __CLASS__, 'can_use' ),
			'callback' => array( __CLASS__, 'finish' ),
			'args' => array(
				'jobId' => array( 'required' => true, 'type' => 'string' ),
				'claimToken' => array( 'required' => true, 'type' => 'string' ),
				'claimGeneration' => array( 'required' => true, 'type' => 'integer' ),
				'status' => array( 'required' => true, 'type' => 'string' ),
				'result' => array( 'type' => 'object' ),
			),
		) );
	}

	public static function can_view_website_projects(): bool {
		return is_user_logged_in() &&
			function_exists( 'wphave_mcp_free_create_feature_enabled' ) &&
			wphave_mcp_free_create_feature_enabled() &&
			current_user_can( 'wphave_access' ) && current_user_can( 'edit_pages' );
	}

	public static function website_projects() {
		return WPHAVE_AI_MCP_Free_Website_Draft_Project::workspace_projects();
	}

	public static function can_use(): bool {
		return is_user_logged_in() &&
			wphave_mcp_free_design_feature_enabled() &&
			current_user_can( 'wphave_access' );
	}

	public static function can_manage_shell(): bool {
		return self::can_use() &&
			current_user_can( 'wphave_manage_template_parts' ) &&
			! wphave_use_fse();
	}

	public static function header_review( WP_REST_Request $request ) {
		$result = WPHAVE_AI_MCP_Free_Site_Shell_Proposal::status( (string) $request['jobId'] );
		return is_wp_error( $result ) ?
			new WP_Error( 'wphave_mcp_shell_unavailable', 'The header proposal is unavailable.', array( 'status' => 404 ) ) :
			$result;
	}

	public static function footer_review( WP_REST_Request $request ) {
		$result = WPHAVE_AI_MCP_Free_Site_Shell_Proposal::status( (string) $request['jobId'], 'footer' );
		return is_wp_error( $result ) ?
			new WP_Error( 'wphave_mcp_shell_unavailable', 'The footer proposal is unavailable.', array( 'status' => 404 ) ) :
			$result;
	}

	public static function site_preview( WP_REST_Request $request ) {
		$result = WPHAVE_AI_MCP_Free_Site_Shell_Proposal::site_preview(
			(string) $request['projectId'],
			(string) $request['headerJobId'],
			(string) $request['footerJobId'],
			(string) $request['pageKey']
		);
		return is_wp_error( $result ) ?
			new WP_Error( 'wphave_mcp_shell_unavailable', 'The site preview is unavailable.', array( 'status' => 404 ) ) :
			$result;
	}

	public static function claim( WP_REST_Request $request ) {
		return WPHAVE_AI_MCP_Free_Job_Store::claim( (string) $request['jobId'] );
	}

	/** Read only an intact, current, actor-bound proposal for the isolated preview. */
	public static function review( WP_REST_Request $request ) {
		$snapshot = WPHAVE_AI_MCP_Free_Job_Store::qualification_snapshot( (string) $request['jobId'] );
		if ( is_wp_error( $snapshot ) ) {
			return new WP_Error( 'wphave_mcp_free_review_unavailable', 'The proposal is unavailable.', array( 'status' => 404 ) );
		}
		$job = $snapshot['job'];
		$result = $snapshot['result'];
		$batch = json_decode( $job['batch_json'], true );
		if ( ! current_user_can( 'edit_post', (int) $job['target_post_id'] ) ||
			! is_string( $result['markup'] ?? null ) || ! is_array( $batch['nodes'] ?? null ) ) {
			return new WP_Error( 'wphave_mcp_free_review_unavailable', 'The proposal is unavailable.', array( 'status' => 404 ) );
		}
		$editable_text = array();
		foreach ( $batch['nodes'] as $node ) {
			if ( in_array( $node['name'], array( 'wphave/heading', 'wphave/paragraph', 'wphave/button' ), true ) ) {
				$editable_text[] = array( 'key' => $node['key'], 'content' => $node['attributes']['content'] );
			}
		}
		return array(
			'jobId' => $job['job_id'],
			'targetPostId' => (int) $job['target_post_id'],
			'markup' => $result['markup'],
			'resultHash' => $job['result_hash'],
			'editableText' => $editable_text,
			'validationLevel' => 'structural_proposal_only',
			'draftEligible' => false,
		);
	}

	/** The caller receives only a current private job contract, never a trust upgrade. */
	public static function replay( WP_REST_Request $request ) {
		$contract = WPHAVE_AI_MCP_Free_Job_Store::replay_contract( (string) $request['jobId'] );
		return is_wp_error( $contract ) ?
			new WP_Error( 'wphave_mcp_free_replay_unavailable', 'The replay is unavailable.', array( 'status' => 404 ) ) :
			$contract;
	}

	public static function editor_gate( WP_REST_Request $request ) {
		$contract = WPHAVE_AI_MCP_Free_Job_Store::editor_review_contract( (string) $request['jobId'] );
		return is_wp_error( $contract ) ?
			new WP_Error( 'wphave_mcp_free_editor_ineligible', 'The proposal is unavailable for editor review.', array( 'status' => 404 ) ) :
			$contract;
	}

	public static function finish( WP_REST_Request $request ) {
		$result = $request['result'];
		return WPHAVE_AI_MCP_Free_Job_Store::finish(
			(string) $request['jobId'],
			(string) $request['claimToken'],
			(int) $request['claimGeneration'],
			(string) $request['status'],
			is_array( $result ) ? $result : null
		);
	}
}
