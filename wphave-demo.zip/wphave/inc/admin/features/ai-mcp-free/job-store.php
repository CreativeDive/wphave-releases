<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/result-validator.php';
require_once __DIR__ . '/project-link.php';
require_once __DIR__ . '/custom-css.php';

/** Private, site-scoped execution jobs. No method in this store writes a post. */
final class WPHAVE_AI_MCP_Free_Job_Store {
	private const LEASE_SECONDS = 120;
	private const JOB_SECONDS = 900;
	private const RETENTION_SECONDS = 86400;

	private static function table(): string {
		global $wpdb;
		return $wpdb->prefix . 'wphave_mcp_free_jobs';
	}

	private static function engine_is_innodb( string $table ): bool {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SHOW TABLE STATUS WHERE Name = %s', $table ), ARRAY_A );
		return is_array( $row ) && strcasecmp( (string) ( $row['Engine'] ?? '' ), 'InnoDB' ) === 0;
	}

	private static function has_result_hash_column( string $table ): bool {
		global $wpdb;
		return null !== $wpdb->get_var( $wpdb->prepare( 'SHOW COLUMNS FROM ' . $table . ' LIKE %s', 'result_hash' ) );
	}

	public static function ensure_schema(): bool {
		global $wpdb;
		if ( ! self::engine_is_innodb( $wpdb->posts ) ) {
			return false;
		}
		$table = self::table();
		if ( ! self::engine_is_innodb( $table ) || ! self::has_result_hash_column( $table ) ) {
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			$collate = $wpdb->get_charset_collate();
			dbDelta( "CREATE TABLE {$table} (
				job_id char(36) NOT NULL,
				site_id bigint(20) unsigned NOT NULL,
				actor_id bigint(20) unsigned NOT NULL,
				request_id varchar(80) NOT NULL,
				payload_hash char(64) NOT NULL,
				target_post_id bigint(20) unsigned NOT NULL,
				revision_hash char(64) NOT NULL,
				context_hash char(64) NOT NULL,
				batch_json longtext NOT NULL,
				status varchar(16) NOT NULL,
				claim_hash char(64) NOT NULL DEFAULT '',
				claim_generation int(10) unsigned NOT NULL DEFAULT 0,
				lease_expires_at datetime DEFAULT NULL,
				expires_at datetime NOT NULL,
				result_json longtext DEFAULT NULL,
				result_hash char(64) NOT NULL DEFAULT '',
				error_code varchar(64) NOT NULL DEFAULT '',
				created_at datetime NOT NULL,
				updated_at datetime NOT NULL,
				PRIMARY KEY  (job_id),
				UNIQUE KEY request_identity (site_id,actor_id,request_id),
				KEY actor_status (site_id,actor_id,status)
			) ENGINE=InnoDB {$collate};" );
		}
		return self::engine_is_innodb( $table ) && self::has_result_hash_column( $table );
	}

	private static function now(): string {
		return gmdate( 'Y-m-d H:i:s' );
	}

	private static function after( int $seconds ): string {
		return gmdate( 'Y-m-d H:i:s', time() + $seconds );
	}

	private static function current_revision( int $post_id ): ?string {
		$post = get_post( $post_id );
		if ( ! $post instanceof WP_Post || 'page' !== $post->post_type ) {
			return null;
		}
		return hash( 'sha256', $post->post_content );
	}

	private static function current_context(): ?string {
		$plugin_root = dirname( __DIR__, 4 );
		$ai_bundle = $plugin_root . '/build/ai/bundle.js';
		$block_bundle = $plugin_root . '/build/block-runtime/bundle.js';
		if ( ! is_file( $ai_bundle ) || ! is_file( $block_bundle ) ) {
			return null;
		}
		$ai_hash = hash_file( 'sha256', $ai_bundle );
		$block_hash = hash_file( 'sha256', $block_bundle );
		if ( false === $ai_hash || false === $block_hash ) {
			return null;
		}
		$context = wp_json_encode( array(
			'wphaveVersion' => defined( 'WPHAVE_VERSION' ) ? WPHAVE_VERSION : null,
			'wordpressVersion' => get_bloginfo( 'version' ),
			'theme' => get_stylesheet(),
			'siteGlobals' => function_exists( 'wphave_data_get' ) ? wphave_data_get( 'site_globals' ) : null,
			'accessSettings' => function_exists( 'wphave_data_get' ) ? wphave_data_get( 'access_settings' ) : null,
			'aiBundleHash' => $ai_hash,
			'blockRuntimeHash' => $block_hash,
		) );
		return is_string( $context ) ? hash( 'sha256', $context ) : null;
	}

	/** The same runtime/site fingerprint used by bounded page jobs. */
	public static function context_fingerprint(): ?string {
		return self::current_context();
	}

	private static function authorized( array $row ): bool {
		return (int) $row['site_id'] === get_current_blog_id() &&
			(int) $row['actor_id'] === get_current_user_id() &&
			current_user_can( 'wphave_access' ) &&
			current_user_can( 'edit_post', (int) $row['target_post_id'] ) &&
			function_exists( 'wphave_get_block_editor_mode_by_role' ) &&
			'design' === wphave_get_block_editor_mode_by_role();
	}

	private static function fetch( string $job_id ): ?array {
		global $wpdb;
		if ( ! wp_is_uuid( $job_id ) || ! self::ensure_schema() ) {
			return null;
		}
		$row = $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM ' . self::table() . ' WHERE job_id=%s AND site_id=%d',
			$job_id,
			get_current_blog_id()
		), ARRAY_A );
		return is_array( $row ) ? $row : null;
	}

	/** Read-only identity for a project binding; never exposes proposal markup. */
	public static function binding_snapshot( string $job_id ): ?array {
		$row = self::fetch( $job_id );
		if ( null === $row || ! self::authorized( $row ) ) {
			return null;
		}
		$row = self::expire( $row );
		$batch = self::intact_batch( $row );
		if ( null === $batch || 2 !== ( $batch['version'] ?? null ) ||
			! in_array( $row['status'], array( 'pending', 'claimed', 'completed' ), true ) ) {
			return null;
		}
		return array(
			'jobId' => $row['job_id'],
			'siteId' => (int) $row['site_id'],
			'actorId' => (int) $row['actor_id'],
			'targetPostId' => (int) $row['target_post_id'],
			'revisionHash' => $row['revision_hash'],
			'contextHash' => $row['context_hash'],
			'designFingerprint' => $batch['designFingerprint'],
			'status' => $row['status'],
		);
	}

	private static function intact_batch( array $row ): ?array {
		$batch = json_decode( (string) $row['batch_json'], true );
		$expected_hash = hash( 'sha256', $row['target_post_id'] . "\n" . $row['revision_hash'] . "\n" . $row['context_hash'] . "\n" . $row['batch_json'] );
		return is_array( $batch ) && self::valid_batch( $batch ) &&
			! is_wp_error( WPHAVE_AI_MCP_Free_Project_Link::resolve( $batch, (int) $row['target_post_id'] ) ) &&
			hash_equals( (string) $row['payload_hash'], $expected_hash ) ? $batch : null;
	}

	private static function expire( array $row ): array {
		global $wpdb;
		$now = self::now();
		if ( $row['status'] === 'pending' && $row['expires_at'] <= $now ) {
			$wpdb->query( $wpdb->prepare(
				'UPDATE ' . self::table() . " SET status='expired',updated_at=%s WHERE job_id=%s AND status='pending' AND expires_at<=%s",
				$now,
				$row['job_id'],
				$now
			) );
		} elseif ( $row['status'] === 'claimed' && $row['lease_expires_at'] <= $now ) {
			$wpdb->query( $wpdb->prepare(
				'UPDATE ' . self::table() . " SET status='expired',updated_at=%s WHERE job_id=%s AND status='claimed' AND claim_generation=%d AND lease_expires_at<=%s",
				$now,
				$row['job_id'],
				(int) $row['claim_generation'],
				$now
			) );
		}
		return self::fetch( $row['job_id'] ) ?? $row;
	}

	public static function prepare( string $request_id, int $target_post_id, array $batch, bool $internal_revision = false ) {
		global $wpdb;
		if ( ! preg_match( '/^[A-Za-z0-9_-]{16,80}$/', $request_id ) ||
			$target_post_id < 1 ||
			! current_user_can( 'wphave_access' ) ||
			! current_user_can( 'edit_post', $target_post_id ) ||
			! function_exists( 'wphave_get_block_editor_mode_by_role' ) ||
			'design' !== wphave_get_block_editor_mode_by_role() ) {
			return new WP_Error( 'wphave_mcp_free_forbidden', 'Free page preparation is not permitted.' );
		}
		$revision = self::current_revision( $target_post_id );
		$context = self::current_context();
		if ( ! self::valid_batch( $batch ) ) {
			return self::invalid_batch_error( $batch, 'wphave_mcp_free_invalid', 'The bounded page request is invalid.' );
		}
		if ( is_wp_error( WPHAVE_AI_MCP_Free_Project_Link::resolve( $batch, $target_post_id ) ) ||
			( isset( $batch['parent'] ) && ! $internal_revision ) ) {
			return new WP_Error( 'wphave_mcp_free_invalid', 'The bounded page request is invalid.' );
		}
		foreach ( $batch['nodes'] as &$node ) {
			if ( $node['attributes'] === array() ) {
				$node['attributes'] = new stdClass();
			}
		}
		unset( $node );
		$batch_json = wp_json_encode( $batch );
		if ( null === $revision || null === $context || ! is_string( $batch_json ) ||
			strlen( $batch_json ) > 32768 || ! self::ensure_schema() ) {
			return new WP_Error( 'wphave_mcp_free_invalid', 'The bounded page request is invalid.' );
		}
		$fingerprint = hash( 'sha256', $target_post_id . "\n" . $revision . "\n" . $context . "\n" . $batch_json );
		$job_id = wp_generate_uuid4();
		$now = self::now();
		$table = self::table();
		$previous_suppression = $wpdb->suppress_errors( true );
		$inserted = $wpdb->insert( $table, array(
			'job_id' => $job_id,
			'site_id' => get_current_blog_id(),
			'actor_id' => get_current_user_id(),
			'request_id' => $request_id,
			'payload_hash' => $fingerprint,
			'target_post_id' => $target_post_id,
			'revision_hash' => $revision,
			'context_hash' => $context,
			'batch_json' => $batch_json,
			'status' => 'pending',
			'expires_at' => self::after( self::JOB_SECONDS ),
			'created_at' => $now,
			'updated_at' => $now,
		) );
		$wpdb->suppress_errors( $previous_suppression );
		if ( 1 === $inserted ) {
			self::prune();
			return array( 'jobId' => $job_id, 'status' => 'pending', 'replayed' => false );
		}
		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT job_id,payload_hash,status FROM {$table} WHERE site_id=%d AND actor_id=%d AND request_id=%s",
			get_current_blog_id(),
			get_current_user_id(),
			$request_id
		), ARRAY_A );
		if ( ! is_array( $row ) ) {
			return new WP_Error( 'wphave_mcp_free_uncertain', 'The job state is uncertain.' );
		}
		if ( ! hash_equals( $row['payload_hash'], $fingerprint ) ) {
			return new WP_Error( 'wphave_mcp_free_conflict', 'The request ID belongs to another payload.' );
		}
		return array( 'jobId' => $row['job_id'], 'status' => $row['status'], 'replayed' => true );
	}

	/** A text-only successor of an intact private proposal. The parent is immutable. */
	public static function prepare_revision( string $request_id, string $parent_job_id, string $parent_result_hash, array $changes ) {
		$snapshot = self::qualification_snapshot( $parent_job_id );
		if ( is_wp_error( $snapshot ) ||
			! preg_match( '/^[a-f0-9]{64}$/', $parent_result_hash ) ||
			! hash_equals( $snapshot['job']['result_hash'], $parent_result_hash ) ||
			count( $changes ) < 1 || count( $changes ) > 8 ||
			array_keys( $changes ) !== range( 0, count( $changes ) - 1 ) ) {
			return new WP_Error( 'wphave_mcp_free_revision_invalid', 'The revision request is unavailable.' );
		}
		$batch = json_decode( $snapshot['job']['batch_json'], true );
		if ( ! is_array( $batch ) || ! self::valid_batch( $batch ) ) {
			return new WP_Error( 'wphave_mcp_free_revision_invalid', 'The parent batch is invalid.' );
		}
		unset( $batch['parent'] );
		$positions = array();
		foreach ( $batch['nodes'] as $index => $node ) {
			$positions[ $node['key'] ] = $index;
		}
		$seen = array();
		foreach ( $changes as $change ) {
			if ( ! is_array( $change ) || array_keys( $change ) !== array( 'key', 'expected', 'value' ) ||
				! is_string( $change['key'] ) || isset( $seen[ $change['key'] ] ) ||
				! isset( $positions[ $change['key'] ] ) ||
				! is_string( $change['expected'] ) || ! is_string( $change['value'] ) ||
				trim( $change['value'] ) === '' || strlen( $change['value'] ) > 4000 ||
				preg_match( '/<[^>]*>/', $change['value'] ) ) {
				return new WP_Error( 'wphave_mcp_free_revision_invalid', 'The text change is invalid.' );
			}
			$index = $positions[ $change['key'] ];
			$node = $batch['nodes'][ $index ];
			if ( ! in_array( $node['name'], array( 'wphave/heading', 'wphave/paragraph', 'wphave/button' ), true ) ||
				isset( $node['heading'] ) ||
				! hash_equals( (string) ( $node['attributes']['content'] ?? '' ), $change['expected'] ) ||
				$change['expected'] === $change['value'] ) {
				return new WP_Error( 'wphave_mcp_free_revision_conflict', 'The expected text changed.' );
			}
			$seen[ $change['key'] ] = true;
			$batch['nodes'][ $index ]['attributes']['content'] = $change['value'];
		}
		$batch['parent'] = array(
			'jobId' => $parent_job_id,
			'resultHash' => $parent_result_hash,
			'changes' => $changes,
		);
		if ( ! self::valid_batch( $batch ) ) {
			return new WP_Error( 'wphave_mcp_free_revision_invalid', 'The revision batch is invalid.' );
		}
		return self::prepare( $request_id, (int) $snapshot['job']['target_post_id'], $batch, true );
	}

	/** Reuse the private job grammar for direct, unlinked native page creation. */
	public static function valid_standalone_batch( array $batch ): bool {
		if ( ( $batch['version'] ?? null ) !== 2 || ! is_array( $batch['nodes'] ?? null ) ||
			isset( $batch['parent'] ) || isset( $batch['projectId'] ) ) {
			return false;
		}
		foreach ( $batch['nodes'] ?? array() as $node ) {
			if ( ! is_array( $node ) || array_key_exists( 'linkTarget', $node ) ) {
				return false;
			}
		}
		return self::valid_batch( $batch );
	}

	/** Report a safe, bounded location without replacing the authoritative batch validator. */
	public static function invalid_batch_error( array $batch, string $code, string $message ): WP_Error {
		$catalog = WPHAVE_AI_MCP_Free_Design_Grammar::catalog();
		if ( 2 === ( $batch['version'] ?? null ) && ! is_wp_error( $catalog ) &&
			( $batch['designFingerprint'] ?? null ) !== $catalog['fingerprint'] ) {
			return new WP_Error( $code, $message . ' Refresh free-page-design-options and use its current designFingerprint.', array( 'reason' => 'design_fingerprint' ) );
		}
		foreach ( $batch['nodes'] ?? array() as $node ) {
			if ( ! is_array( $node ) || ! is_string( $node['key'] ?? null ) ||
				! preg_match( '/^[a-z][a-z0-9_-]{0,31}$/', $node['key'] ) ) {
				continue;
			}
			if ( ! WPHAVE_AI_MCP_Free_Custom_CSS::valid_node( $node ) ) {
				return new WP_Error( $code, $message . ' Custom CSS is unavailable or invalid at node ' . $node['key'] . '.', array( 'reason' => 'custom_css', 'nodeKey' => $node['key'] ) );
			}
			$name = $node['name'] ?? null;
			$design = $node['design'] ?? null;
			$valid = match ( $name ) {
				'wphave/group' => is_array( $design ) && WPHAVE_AI_MCP_Free_Design_Grammar::valid_group_operations( $design ),
				'wphave/image' => null === $design || ( is_array( $design ) && WPHAVE_AI_MCP_Free_Design_Grammar::valid_image_operations( $design ) ),
				'wphave/heading', 'wphave/paragraph', 'wphave/button' => null === $design || ( is_array( $design ) && WPHAVE_AI_MCP_Free_Design_Grammar::valid_text_operations( $name, $design ) ),
				default => true,
			};
			if ( ! $valid ) {
				return new WP_Error( $code, $message . ' Invalid design operations at node ' . $node['key'] . '.', array( 'reason' => 'design_operations', 'nodeKey' => $node['key'] ) );
			}
		}
		if ( ! WPHAVE_AI_MCP_Free_Section_Plan::valid( $batch ) ) {
			return new WP_Error( $code, $message . ' Section keys, layouts or purposes do not match the root Groups.', array( 'reason' => 'section_plan' ) );
		}
		return new WP_Error( $code, $message );
	}

	/** Validate semantic website targets without granting the caller URL authority. */
	public static function valid_website_batch( array $batch, array $page_keys ): bool {
		if ( ! is_array( $batch['nodes'] ?? null ) ) {
			return false;
		}
		$unlinked = $batch;
		$links = 0;
		foreach ( $unlinked['nodes'] as &$node ) {
			if ( ! isset( $node['linkTarget'] ) ) {
				continue;
			}
			$target = $node['linkTarget'];
			if ( 'wphave/button' !== ( $node['name'] ?? null ) ||
				! is_array( $target ) || array_keys( $target ) !== array( 'kind', 'pageKey' ) ||
				'projectPage' !== $target['kind'] ||
				! is_string( $target['pageKey'] ) ||
				! in_array( $target['pageKey'], $page_keys, true ) || ++$links > 8 ) {
				return false;
			}
			unset( $node['linkTarget'] );
		}
		unset( $node );
		return self::valid_standalone_batch( $unlinked );
	}

	private static function valid_batch( array $batch ): bool {
		$encoded = wp_json_encode( $batch );
		if ( array_diff( array_keys( $batch ), array( 'version', 'nodes', 'parent', 'designFingerprint', 'projectId', 'sections' ) ) ||
			! is_string( $encoded ) || strlen( $encoded ) > 32768 ||
			! in_array( $batch['version'] ?? null, array( 1, 2 ), true ) || ! is_array( $batch['nodes'] ?? null ) ||
			count( $batch['nodes'] ) < 1 || count( $batch['nodes'] ) > 80 ||
			array_keys( $batch['nodes'] ) !== range( 0, count( $batch['nodes'] ) - 1 ) ) {
			return false;
		}
		$catalog = 2 === $batch['version'] ? WPHAVE_AI_MCP_Free_Design_Grammar::catalog() : null;
		if ( ( 1 === $batch['version'] && array_key_exists( 'designFingerprint', $batch ) ) ||
			( 2 === $batch['version'] && ( is_wp_error( $catalog ) ||
				! is_string( $batch['designFingerprint'] ?? null ) ||
				! hash_equals( $catalog['fingerprint'], $batch['designFingerprint'] ) ) ) ) {
			return false;
		}
		if ( isset( $batch['parent'] ) && (
			! is_array( $batch['parent'] ) ||
			array_keys( $batch['parent'] ) !== array( 'jobId', 'resultHash', 'changes' ) ||
			! wp_is_uuid( $batch['parent']['jobId'] ) ||
			! is_string( $batch['parent']['resultHash'] ) ||
			! preg_match( '/^[a-f0-9]{64}$/', $batch['parent']['resultHash'] ) ||
			! is_array( $batch['parent']['changes'] ) ||
			count( $batch['parent']['changes'] ) < 1 || count( $batch['parent']['changes'] ) > 8
		) ) {
			return false;
		}
		$keys = array();
		foreach ( $batch['nodes'] as $node ) {
		if ( ! is_array( $node ) || array_diff( array_keys( $node ), array( 'key', 'parentKey', 'name', 'attributes', 'design', 'linkTarget', 'button', 'line', 'spacer', 'heading', 'css', 'alignment' ) ) ||
			( array_key_exists( 'alignment', $node ) &&
				( 2 !== $batch['version'] || 'wphave/spacer' === ( $node['name'] ?? null ) ||
					! in_array( $node['alignment'], array( 'none', 'left', 'center', 'right' ), true ) ) ) ||
			! WPHAVE_AI_MCP_Free_Custom_CSS::valid_node( $node ) ||
			! is_string( $node['key'] ?? null ) || ! preg_match( '/^[a-z][a-z0-9_-]{0,31}$/', $node['key'] ) ||
			isset( $keys[ $node['key'] ] ) ||
			! array_key_exists( 'parentKey', $node ) ||
			( null !== $node['parentKey'] && ( ! is_string( $node['parentKey'] ) || ( $keys[ $node['parentKey'] ] ?? null ) !== 'wphave/group' ) ) ||
			! in_array( $node['name'] ?? null, 2 === $batch['version'] ?
				array( 'wphave/group', 'wphave/heading', 'wphave/paragraph', 'wphave/button', 'wphave/image', 'wphave/line', 'wphave/spacer' ) :
				array( 'wphave/group', 'wphave/heading', 'wphave/paragraph', 'wphave/button' ), true ) ||
			! is_array( $node['attributes'] ?? null ) ||
			array_diff( array_keys( $node['attributes'] ), $node['name'] === 'wphave/image' ? array( 'image', 'alt' ) : array( 'content' ) ) ||
			( isset( $node['attributes']['content'] ) && ( ! is_string( $node['attributes']['content'] ) || strlen( $node['attributes']['content'] ) > 4096 ) ) ||
			( array_key_exists( 'linkTarget', $node ) && ( 2 !== $batch['version'] || $node['name'] !== 'wphave/button' ||
				! is_array( $node['linkTarget'] ) || array_keys( $node['linkTarget'] ) !== array( 'kind', 'pageKey' ) ||
				$node['linkTarget']['kind'] !== 'projectPage' ||
					! in_array( $node['linkTarget']['pageKey'], array( 'home', 'services' ), true ) ) ) ||
				( array_key_exists( 'button', $node ) &&
					( 2 !== $batch['version'] || 'wphave/button' !== $node['name'] ||
					! WPHAVE_AI_MCP_Free_Button_Recipes::valid( $node['button'] ) ||
					isset( $node['design'] ) ||
					! is_string( $node['attributes']['content'] ?? null ) ||
					'' === trim( $node['attributes']['content'] ) ) ) ||
			( array_key_exists( 'line', $node ) &&
				( 2 !== $batch['version'] || 'wphave/line' !== $node['name'] ||
				! WPHAVE_AI_MCP_Free_Line_Recipes::valid( $node['line'] ) ||
				! empty( $node['attributes'] ) || isset( $node['design'] ) ) ) ||
			( array_key_exists( 'spacer', $node ) &&
				( 2 !== $batch['version'] || 'wphave/spacer' !== $node['name'] ||
				! WPHAVE_AI_MCP_Free_Spacer_Recipes::valid( $node['spacer'] ) ||
				! empty( $node['attributes'] ) || isset( $node['design'] ) ) ) ||
			( array_key_exists( 'heading', $node ) &&
				( 2 !== $batch['version'] || 'wphave/heading' !== $node['name'] ||
				! WPHAVE_AI_MCP_Free_Heading_Recipes::valid( $node['heading'], $node['attributes']['content'] ?? null ) ||
				isset( $node['design'] ) ) ) ||
			( isset( $node['design'] ) && ( ! is_array( $node['design'] ) || count( $node['design'] ) > 8 ||
				array_keys( $node['design'] ) !== range( 0, count( $node['design'] ) - 1 ) ) ) ) {
				return false;
			}
			if ( ( 1 === $batch['version'] &&
				$node['name'] !== 'wphave/group' && isset( $node['design'] ) ) ||
				( $node['name'] === 'wphave/group' && ( count( $node['design'] ?? array() ) < 1 ||
					array_key_exists( 'content', $node['attributes'] ) ) ) ||
			( ! in_array( $node['name'], array( 'wphave/group', 'wphave/image', 'wphave/line', 'wphave/spacer' ), true ) &&
					! array_key_exists( 'content', $node['attributes'] ) ) ) {
				return false;
			}
			if ( 2 === $batch['version'] ) {
				if ( ( 'wphave/line' === $node['name'] && ! isset( $node['line'] ) ) ||
					( 'wphave/spacer' === $node['name'] && ! isset( $node['spacer'] ) ) ) {
					return false;
				}
				if ( $node['name'] === 'wphave/group' &&
					! WPHAVE_AI_MCP_Free_Design_Grammar::valid_group_operations( $node['design'] ) ) {
					return false;
				}
				if ( $node['name'] === 'wphave/image' && isset( $node['design'] ) &&
					! WPHAVE_AI_MCP_Free_Design_Grammar::valid_image_operations( $node['design'] ) ) {
					return false;
				}
				if ( ! in_array( $node['name'], array( 'wphave/group', 'wphave/image', 'wphave/line', 'wphave/spacer' ), true ) &&
					isset( $node['design'] ) &&
					! WPHAVE_AI_MCP_Free_Design_Grammar::valid_text_operations( $node['name'], $node['design'] ) ) {
					return false;
				}
				$keys[ $node['key'] ] = $node['name'];
				continue;
			}
			$seen_design = array();
			foreach ( $node['design'] ?? array() as $index => $design ) {
				if ( ! is_array( $design ) || array_keys( $design ) !== array( 'device', 'path', 'value' ) ||
					! is_string( $design['device'] ) || ! is_string( $design['path'] ) || ! is_string( $design['value'] ) ) {
					return false;
				}
				$identity = $design['device'] . ':' . $design['path'];
				$allowed = ( $index === 0 && $design === array( 'device' => 'Desktop', 'path' => 'layout.type', 'value' => 'flex' ) ) ||
					( $index > 0 && in_array( $identity . ':' . $design['value'], array(
						'Desktop:layout.flex.flexDirection:column',
						'Mobile:layout.flex.alignVertical:start',
						'Mobile:layout.flex.flexDirection:row',
					), true ) );
				if ( ! $allowed || isset( $seen_design[ $identity ] ) ||
					( $design['device'] === 'Mobile' && ! isset( $seen_design['Desktop:layout.flex.flexDirection'] ) ) ||
					( $index > 1 && $design['device'] === 'Desktop' ) ) {
					return false;
				}
				$seen_design[ $identity ] = true;
			}
			$keys[ $node['key'] ] = $node['name'];
		}
		$creation_config = WPHAVE_AI_MCP_Free_Creation_Config::get();
		return null !== $creation_config &&
			WPHAVE_AI_MCP_Free_Section_Plan::valid( $batch ) &&
			self::valid_configured_text_contrast( $batch['nodes'], $creation_config ) &&
			! is_wp_error( WPHAVE_AI_MCP_Free_Media::verified_ids( $batch ) );
	}

	private static function valid_configured_text_contrast( array $nodes, array $config ): bool {
		return ! $config['checks']['textContrast'] || self::valid_text_contrast( $nodes );
	}

	private static function valid_text_contrast( array $nodes ): bool {
		$by_key = array();
		foreach ( $nodes as $node ) {
			$by_key[ $node['key'] ] = $node;
		}
		foreach ( $nodes as $node ) {
			if ( ! in_array( $node['name'], array( 'wphave/heading', 'wphave/paragraph' ), true ) ) {
				continue;
			}
			$foreground = $node['name'] === 'wphave/heading' ?
				'var(--wphave-site-color-heading)' :
				'var(--wphave-site-color-text)';
			foreach ( $node['design'] ?? array() as $operation ) {
				if ( $operation['path'] === 'colors.text' ) {
					$foreground = $operation['value'];
				}
			}
			$parent = $node['parentKey'];
			$background = 'var(--wphave-site-color-background)';
			$found_background = false;
			while ( null !== $parent ) {
				$group = $by_key[ $parent ];
				foreach ( $group['design'] ?? array() as $operation ) {
					if ( $operation['path'] === 'background.color.base' ) {
						$background = $operation['value'];
						$found_background = true;
						break;
					}
				}
				if ( $found_background ) {
					break;
				}
				$parent = $group['parentKey'];
			}
			$ratio = WPHAVE_AI_MCP_Free_Contrast::ratio( $background, $foreground );
			if ( null === $ratio || $ratio < 4.5 ) {
				return false;
			}
		}
		return true;
	}

	public static function status( string $job_id ) {
		$row = self::fetch( $job_id );
		if ( null === $row || ! self::authorized( $row ) ) {
			return new WP_Error( 'wphave_mcp_free_forbidden', 'The job is unavailable.' );
		}
		$row = self::expire( $row );
		$context_stale = ! hash_equals( $row['revision_hash'], self::current_revision( (int) $row['target_post_id'] ) ?? '' ) ||
			! hash_equals( $row['context_hash'], self::current_context() ?? '' ) ||
			( $row['status'] === 'completed' && null === self::intact_batch( $row ) );
		return array(
			'jobId' => $row['job_id'],
			'status' => $context_stale ? 'stale' : $row['status'],
			'reviewUrl' => ! $context_stale && $row['status'] === 'completed' ?
				admin_url( 'admin.php?page=workspace&screen=edit&postId=' . (int) $row['target_post_id'] . '&postType=page#wphaveFreeReview=' . rawurlencode( $row['job_id'] ) ) : null,
			'expiresAt' => $row['expires_at'],
			'result' => ! $context_stale && $row['status'] === 'completed' ? json_decode( (string) $row['result_json'], true ) : null,
			'resultHash' => ! $context_stale && $row['status'] === 'completed' ? $row['result_hash'] : null,
			'validationLevel' => ! $context_stale && $row['status'] === 'completed' ? 'structural_proposal_only' : null,
			'validationReport' => ! $context_stale && $row['status'] === 'completed' ? array(
				'version' => 1,
				'status' => 'structural_proposal_only',
				'independentlyChecked' => array( 'job_binding', 'block_tree', 'registered_attributes', 'content', 'canonical_markup', 'bounded_design_namespace' ),
				'workerDependent' => array( 'design_policy_execution', 'design_css_correctness' ),
				'draftEligible' => false,
			) : null,
			'errorCode' => $row['status'] === 'failed' ? $row['error_code'] : null,
		);
	}

	/** Returns a fresh, authorized ledger snapshot for a later storage qualification. */
	public static function qualification_snapshot( string $job_id ) {
		$row = self::fetch( $job_id );
		if ( null === $row || ! self::authorized( $row ) || $row['status'] !== 'completed' ||
			(int) $row['claim_generation'] !== 1 ||
			! preg_match( '/^[a-f0-9]{64}$/', (string) $row['claim_hash'] ) ||
			$row['expires_at'] <= self::now() ||
			! is_string( $row['lease_expires_at'] ) || $row['updated_at'] >= $row['lease_expires_at'] ||
			! hash_equals( $row['revision_hash'], self::current_revision( (int) $row['target_post_id'] ) ?? '' ) ||
			! hash_equals( $row['context_hash'], self::current_context() ?? '' ) ) {
			return new WP_Error( 'wphave_mcp_free_unqualified', 'The proposal is unavailable for draft qualification.' );
		}
		$payload_hash = hash( 'sha256', $row['target_post_id'] . "\n" . $row['revision_hash'] . "\n" . $row['context_hash'] . "\n" . $row['batch_json'] );
		$result_json = (string) $row['result_json'];
		if ( ! hash_equals( (string) $row['payload_hash'], $payload_hash ) ||
			! preg_match( '/^[a-f0-9]{64}$/', (string) $row['result_hash'] ) ||
			! hash_equals( $row['result_hash'], hash( 'sha256', $result_json ) ) ) {
			return new WP_Error( 'wphave_mcp_free_unqualified', 'The proposal integrity check failed.' );
		}
		$result = json_decode( $result_json, true );
		if ( ! is_array( $result ) || null === self::intact_batch( $row ) ) {
			return new WP_Error( 'wphave_mcp_free_unqualified', 'The proposal result is invalid.' );
		}
		return array( 'job' => $row, 'result' => $result );
	}

	/** Read-only, server-bound input for an isolated browser consistency replay. */
	public static function replay_contract( string $job_id ) {
		$snapshot = self::qualification_snapshot( $job_id );
		if ( is_wp_error( $snapshot ) ) {
			return $snapshot;
		}
		$job = $snapshot['job'];
		$batch = self::intact_batch( $job );
		$parent = self::parent_snapshot( $batch, $job );
		if ( null === $batch || is_wp_error( $parent ) || ! is_string( $snapshot['result']['markup'] ?? null ) ) {
			return new WP_Error( 'wphave_mcp_free_replay_unavailable', 'The replay contract is unavailable.' );
		}
		$media_ids = WPHAVE_AI_MCP_Free_Media::verified_ids( $batch );
		$resolved_links = WPHAVE_AI_MCP_Free_Project_Link::resolve( $batch, (int) $job['target_post_id'] );
		if ( is_wp_error( $media_ids ) || is_wp_error( $resolved_links ) ) {
			return new WP_Error( 'wphave_mcp_free_replay_unavailable', 'The replay contract is unavailable.' );
		}
		return array(
			'jobId' => $job['job_id'],
			'targetPostId' => (int) $job['target_post_id'],
			'batch' => json_decode( $job['batch_json'] ),
			'verifiedMediaIds' => $media_ids,
			'allowIconButtons' => WPHAVE_AI_MCP_Free_Button_Recipes::icon_allowed(),
			'lineColorValues' => WPHAVE_AI_MCP_Free_Line_Recipes::colors(),
			'parentMarkup' => is_array( $parent ) ? $parent['result']['markup'] : null,
			'parentNodes' => is_array( $parent ) ? json_decode( $parent['job']['batch_json'], true )['nodes'] : null,
			'resolvedLinks' => $resolved_links,
			'expectedMarkup' => $snapshot['result']['markup'],
			'validationLevel' => 'structural_proposal_only',
			'draftEligible' => false,
		);
	}

	/** A read-only gate for explicit editor review; it never qualifies server-side storage. */
	public static function editor_review_contract( string $job_id ) {
		$contract = self::replay_contract( $job_id );
		if ( is_wp_error( $contract ) ) {
			return $contract;
		}
		$post = get_post( (int) $contract['targetPostId'] );
		if ( ! $post instanceof WP_Post || 'page' !== $post->post_type || 'draft' !== $post->post_status ||
			'' !== $post->post_content || ! self::validate_review_chain( $job_id ) ) {
			return new WP_Error( 'wphave_mcp_free_editor_ineligible', 'The proposal is unavailable for editor review.' );
		}
		$snapshot = self::qualification_snapshot( $job_id );
		if ( is_wp_error( $snapshot ) ) {
			return $snapshot;
		}
		$contract['resultHash'] = $snapshot['job']['result_hash'];
		$contract['eligibility'] = 'eligible_for_editor_review';
		return $contract;
	}

	/** Revalidate every persisted result in a bounded successor chain. */
	private static function validate_review_chain( string $job_id ): bool {
		$seen = array();
		$current = $job_id;
		while ( count( $seen ) < 8 && ! isset( $seen[ $current ] ) ) {
			$seen[ $current ] = true;
			$snapshot = self::qualification_snapshot( $current );
			if ( is_wp_error( $snapshot ) ) {
				return false;
			}
			$batch = self::intact_batch( $snapshot['job'] );
			if ( null === $batch || is_wp_error( WPHAVE_AI_MCP_Free_Result_Validator::validate( $snapshot['result'], $snapshot['job'] ) ) ) {
				return false;
			}
			if ( ! isset( $batch['parent'] ) ) {
				return true;
			}
			$parent = self::parent_snapshot( $batch, $snapshot['job'] );
			if ( is_wp_error( $parent ) ||
				is_wp_error( WPHAVE_AI_MCP_Free_Result_Validator::validate_revision(
					$parent['result']['markup'],
					$snapshot['result']['markup'],
					json_decode( $parent['job']['batch_json'], true )['nodes'],
					$batch['parent']['changes']
				) ) ) {
				return false;
			}
			$current = $batch['parent']['jobId'];
		}
		return false;
	}

	public static function claim( string $job_id ) {
		global $wpdb;
		$row = self::fetch( $job_id );
		if ( null === $row || ! self::authorized( $row ) ) {
			return new WP_Error( 'wphave_mcp_free_forbidden', 'The job is unavailable.' );
		}
		$row = self::expire( $row );
		if ( $row['status'] !== 'pending' ||
			! hash_equals( $row['revision_hash'], self::current_revision( (int) $row['target_post_id'] ) ?? '' ) ||
			! hash_equals( $row['context_hash'], self::current_context() ?? '' ) ) {
			return new WP_Error( 'wphave_mcp_free_stale', 'The job is no longer claimable.' );
		}
		$batch = self::intact_batch( $row );
		if ( null === $batch ) {
			return new WP_Error( 'wphave_mcp_free_invalid', 'The job batch is invalid.' );
		}
		$media_ids = WPHAVE_AI_MCP_Free_Media::verified_ids( $batch );
		$resolved_links = WPHAVE_AI_MCP_Free_Project_Link::resolve( $batch, (int) $row['target_post_id'] );
		if ( is_wp_error( $media_ids ) || is_wp_error( $resolved_links ) ) {
			return new WP_Error( 'wphave_mcp_free_stale', 'The job references changed.' );
		}
		$parent = self::parent_snapshot( $batch, $row );
		if ( is_wp_error( $parent ) ) {
			return $parent;
		}
		$token = bin2hex( random_bytes( 32 ) );
		$now = self::now();
		$lease_until = self::after( self::LEASE_SECONDS );
		$changed = $wpdb->query( $wpdb->prepare(
			'UPDATE ' . self::table() . " SET status='claimed',claim_hash=%s,claim_generation=claim_generation+1,lease_expires_at=%s,updated_at=%s WHERE job_id=%s AND site_id=%d AND actor_id=%d AND status='pending' AND claim_generation=0 AND expires_at>%s",
			hash( 'sha256', $token ),
			$lease_until,
			$now,
			$job_id,
			get_current_blog_id(),
			get_current_user_id(),
			$now
		) );
		if ( 1 !== $changed ) {
			return new WP_Error( 'wphave_mcp_free_claimed', 'The job was claimed by another worker.' );
		}
		return array(
			'jobId' => $job_id,
			'requestId' => $row['request_id'],
			'targetPostId' => (int) $row['target_post_id'],
			'revisionHash' => $row['revision_hash'],
			'contextHash' => $row['context_hash'],
			'batchHash' => hash( 'sha256', $row['batch_json'] ),
			'batch' => json_decode( $row['batch_json'] ),
			'verifiedMediaIds' => $media_ids,
			'allowIconButtons' => WPHAVE_AI_MCP_Free_Button_Recipes::icon_allowed(),
			'lineColorValues' => WPHAVE_AI_MCP_Free_Line_Recipes::colors(),
			'resolvedLinks' => $resolved_links,
			'parentMarkup' => is_array( $parent ) ? $parent['result']['markup'] : null,
			'parentNodes' => is_array( $parent ) ? json_decode( $parent['job']['batch_json'], true )['nodes'] : null,
			'claimToken' => $token,
			'claimGeneration' => 1,
			'leaseExpiresAt' => $lease_until,
		);
	}

	public static function finish( string $job_id, string $token, int $generation, string $status, ?array $result = null ) {
		global $wpdb;
		$row = self::fetch( $job_id );
		if ( null === $row || ! self::authorized( $row ) ) {
			return new WP_Error( 'wphave_mcp_free_forbidden', 'The job is unavailable.' );
		}
		$row = self::expire( $row );
		if ( $row['status'] !== 'claimed' || $generation !== (int) $row['claim_generation'] ||
			! hash_equals( $row['claim_hash'], hash( 'sha256', $token ) ) ||
			! hash_equals( $row['revision_hash'], self::current_revision( (int) $row['target_post_id'] ) ?? '' ) ||
			! hash_equals( $row['context_hash'], self::current_context() ?? '' ) ) {
			return new WP_Error( 'wphave_mcp_free_stale', 'The claim is no longer valid.' );
		}
		$batch = self::intact_batch( $row );
		if ( null === $batch ) {
			return new WP_Error( 'wphave_mcp_free_invalid', 'The job batch is invalid.' );
		}
		if ( ! in_array( $status, array( 'completed', 'failed' ), true ) ) {
			return new WP_Error( 'wphave_mcp_free_invalid', 'The result status is invalid.' );
		}
		$result_json = null;
		$result_hash = '';
		if ( $status === 'completed' ) {
			if ( ! is_array( $result ) ) {
				return new WP_Error( 'wphave_mcp_free_result_invalid', 'The proposal is invalid.' );
			}
			$validation = WPHAVE_AI_MCP_Free_Result_Validator::validate( $result, $row );
			if ( is_wp_error( $validation ) ) {
				return $validation;
			}
			$parent = self::parent_snapshot( $batch, $row );
			if ( is_wp_error( $parent ) ) {
				return $parent;
			}
			if ( is_array( $parent ) ) {
				$revision_validation = WPHAVE_AI_MCP_Free_Result_Validator::validate_revision(
					$parent['result']['markup'],
					$result['markup'],
					json_decode( $parent['job']['batch_json'], true )['nodes'],
					$batch['parent']['changes']
				);
				if ( is_wp_error( $revision_validation ) ) {
					return $revision_validation;
				}
			}
			$result_json = wp_json_encode( $result );
			if ( ! is_string( $result_json ) || strlen( $result_json ) > 131072 ) {
				return new WP_Error( 'wphave_mcp_free_invalid', 'The result is too large.' );
			}
			$result_hash = hash( 'sha256', $result_json );
		}
		$now = self::now();
		$changed = $wpdb->query( $wpdb->prepare(
			'UPDATE ' . self::table() . ' SET status=%s,result_json=%s,result_hash=%s,error_code=%s,updated_at=%s WHERE job_id=%s AND site_id=%d AND actor_id=%d AND status=%s AND claim_hash=%s AND claim_generation=%d AND lease_expires_at>%s',
			$status,
			$result_json,
			$result_hash,
			$status === 'failed' ? 'worker_failed' : '',
			$now,
			$job_id,
			get_current_blog_id(),
			get_current_user_id(),
			'claimed',
			$row['claim_hash'],
			$generation,
			$now
		) );
		return 1 === $changed ? array( 'jobId' => $job_id, 'status' => $status ) : new WP_Error( 'wphave_mcp_free_stale', 'The claim could not be completed.' );
	}

	private static function parent_snapshot( $batch, array $row ) {
		if ( ! is_array( $batch ) ) {
			return new WP_Error( 'wphave_mcp_free_revision_invalid', 'The revision batch is invalid.' );
		}
		if ( ! isset( $batch['parent'] ) ) {
			return null;
		}
		$parent = self::qualification_snapshot( (string) $batch['parent']['jobId'] );
		if ( is_wp_error( $parent ) ||
			! hash_equals( (string) $batch['parent']['resultHash'], (string) ( $parent['job']['result_hash'] ?? '' ) ) ||
			(int) ( $parent['job']['target_post_id'] ?? 0 ) !== (int) $row['target_post_id'] ||
			! hash_equals( (string) ( $parent['job']['revision_hash'] ?? '' ), (string) $row['revision_hash'] ) ||
			! hash_equals( (string) ( $parent['job']['context_hash'] ?? '' ), (string) $row['context_hash'] ) ) {
			return new WP_Error( 'wphave_mcp_free_revision_stale', 'The parent proposal is unavailable.' );
		}
		return $parent;
	}

	private static function prune(): void {
		global $wpdb;
		$now = self::now();
		$wpdb->query( $wpdb->prepare(
			'UPDATE ' . self::table() . " SET status='expired',updated_at=%s WHERE status='pending' AND expires_at<=%s",
			$now,
			$now
		) );
		$wpdb->query( $wpdb->prepare(
			'UPDATE ' . self::table() . " SET status='expired',updated_at=%s WHERE status='claimed' AND lease_expires_at<=%s",
			$now,
			$now
		) );
		$cutoff = gmdate( 'Y-m-d H:i:s', time() - self::RETENTION_SECONDS );
		$wpdb->query( $wpdb->prepare(
			'DELETE FROM ' . self::table() . ' WHERE expires_at<%s AND status IN (%s,%s,%s)',
			$cutoff,
			'completed',
			'failed',
			'expired'
		) );
	}
}
