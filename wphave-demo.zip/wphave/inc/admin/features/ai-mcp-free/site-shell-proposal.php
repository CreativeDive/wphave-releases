<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Private native site-shell proposals for a two-page project; no global writes. */
final class WPHAVE_AI_MCP_Free_Site_Shell_Proposal {
	private static function table(): string {
		global $wpdb;
		return $wpdb->prefix . 'wphave_mcp_free_shell';
	}

	private static function can_manage(): bool {
		return current_user_can( 'wphave_access' ) &&
			current_user_can( 'wphave_manage_template_parts' ) &&
			! wphave_use_fse();
	}

	private static function assignments_hash(): ?string {
		$assignments = wphave_data_get( 'template_parts', '', array() );
		$json = is_array( $assignments ) ? wp_json_encode( $assignments ) : false;
		return is_string( $json ) ? hash( 'sha256', $json ) : null;
	}

	private static function base_part( string $type ): ?array {
		if ( ! class_exists( 'WPHAVE_Template_Parts_Base' ) ) {
			return null;
		}
		$blocks = parse_blocks( WPHAVE_Template_Parts_Base::get_template_part( $type ) );
		$roots = array_values( array_filter( $blocks, static function ( $block ) {
			return ( $block['blockName'] ?? null ) !== null;
		} ) );
		return 1 === count( $roots ) && 'wphave/group' === $roots[0]['blockName'] ? $roots[0] : null;
	}

	private static function markup( string $type, string $brand, string $description, string $copyright, int $home_id, int $services_id ): ?string {
		return self::native_markup_from_links( $type, $brand, $description, $copyright, array(
			array( 'label' => 'Home', 'postId' => $home_id ),
			array( 'label' => 'Leistungen', 'postId' => $services_id ),
		) );
	}

	/** Reuse the native private shell composition for variable-length projects. */
	public static function native_markup_from_links( string $type, string $brand, string $description, string $copyright, array $links, bool $layout_fallback = false ): ?string {
		if ( ! in_array( $type, array( 'header', 'footer' ), true ) ||
			count( $links ) < 1 || count( $links ) > 12 ) {
			return null;
		}
		$base = self::base_part( $type );
		if ( null === $base ) {
			return null;
		}
		if ( $layout_fallback ) {
			$wphave = $base['attrs']['wphave'] ?? array();
			foreach ( array( 'styles', 'stylesLayout' ) as $style_key ) {
				if ( is_string( $wphave[ $style_key ] ?? null ) ) {
					$wphave[ $style_key ] = str_replace(
						'var(--wphave-site-layout-margin)',
						'var(--wphave-site-layout-margin, 1rem)',
						$wphave[ $style_key ]
					);
				}
			}
			if ( isset( $wphave['dimensions']['spacing']['padding'] ) ) {
				$wphave['dimensions']['spacing']['padding'] = str_replace(
					'var(--wphave-site-layout-margin)',
					'var(--wphave-site-layout-margin, 1rem)',
					$wphave['dimensions']['spacing']['padding']
				);
			}
			$base['attrs']['wphave'] = $wphave;
		}
		$link = static function ( string $label, int $post_id ): array {
			return array(
				'blockName' => 'wphave/navigation-link',
				'attrs' => array(
					'content' => $label,
					'link' => array( 'type' => 'internal', 'internal' => array( 'id' => $post_id ) ),
				),
				'innerBlocks' => array(),
				'innerHTML' => '',
				'innerContent' => array(),
			);
		};
		$brand_block = array(
			'blockName' => 'wphave/paragraph',
			'attrs' => array( 'content' => $brand ),
			'innerBlocks' => array(),
			'innerHTML' => '',
			'innerContent' => array(),
		);
		$native_links = array();
		foreach ( $links as $entry ) {
			if ( ! is_array( $entry ) || ! is_string( $entry['label'] ?? null ) ||
				'' === trim( $entry['label'] ) ||
				! is_int( $entry['postId'] ?? null ) || $entry['postId'] < 1 ) {
				return null;
			}
			$native_links[] = $link( $entry['label'], $entry['postId'] );
		}
		$navigation = array(
			'blockName' => 'wphave/navigation',
			'attrs' => array( 'wphave' => array( 'settings' => array(
				'collapseBehavior' => 'header' === $type ? 'auto' : 'never',
				'collapseBreakpoint' => 768,
				'accessibleLabel' => 'header' === $type ? 'Primary navigation' : 'Footer navigation',
			) ) ),
			'innerBlocks' => $native_links,
			'innerHTML' => '',
			'innerContent' => array_fill( 0, count( $native_links ), null ),
		);
		$base['innerBlocks'] = 'header' === $type ?
			array( $brand_block, $navigation ) :
			array(
				$brand_block,
				array( 'blockName' => 'wphave/paragraph', 'attrs' => array( 'content' => $description ), 'innerBlocks' => array(), 'innerHTML' => '', 'innerContent' => array() ),
				$navigation,
				array( 'blockName' => 'wphave/paragraph', 'attrs' => array( 'content' => $copyright ), 'innerBlocks' => array(), 'innerHTML' => '', 'innerContent' => array() ),
			);
		$base['innerHTML'] = '';
		$base['innerContent'] = array_fill( 0, count( $base['innerBlocks'] ), null );
		$markup = serialize_blocks( array( $base ) );
		return is_string( $markup ) && serialize_blocks( parse_blocks( $markup ) ) === $markup ?
			$markup : null;
	}

	public static function ensure_schema(): bool {
		global $wpdb;
		$table = self::table();
		$row = $wpdb->get_row( $wpdb->prepare( 'SHOW TABLE STATUS WHERE Name = %s', $table ), ARRAY_A );
		if ( ! is_array( $row ) ) {
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			$collate = $wpdb->get_charset_collate();
			dbDelta( "CREATE TABLE {$table} (
				job_id char(36) NOT NULL,
				site_id bigint(20) unsigned NOT NULL,
				actor_id bigint(20) unsigned NOT NULL,
				request_id varchar(80) NOT NULL,
				payload_hash char(64) NOT NULL,
				project_id char(36) NOT NULL,
				part_type varchar(8) NOT NULL,
				project_revision bigint(20) unsigned NOT NULL,
				design_fingerprint char(64) NOT NULL,
				context_hash char(64) NOT NULL,
				assignments_hash char(64) NOT NULL,
				base_hash char(64) NOT NULL,
				brand varchar(80) NOT NULL,
				description varchar(240) NOT NULL,
				copyright varchar(120) NOT NULL,
				home_post_id bigint(20) unsigned NOT NULL,
				services_post_id bigint(20) unsigned NOT NULL,
				markup longtext NOT NULL,
				result_hash char(64) NOT NULL,
				created_at datetime NOT NULL,
				PRIMARY KEY  (job_id),
				UNIQUE KEY request_identity (site_id,actor_id,request_id)
			) ENGINE=InnoDB {$collate};" );
			$row = $wpdb->get_row( $wpdb->prepare( 'SHOW TABLE STATUS WHERE Name = %s', $table ), ARRAY_A );
		}
		$index = $wpdb->get_row( $wpdb->prepare(
			'SHOW INDEX FROM ' . $table . ' WHERE Key_name = %s AND Non_unique = 0',
			'request_identity'
		), ARRAY_A );
		return is_array( $row ) &&
			0 === strcasecmp( (string) ( $row['Engine'] ?? '' ), 'InnoDB' ) &&
			is_array( $index );
	}

	private static function read_row( string $job_id ): ?array {
		global $wpdb;
		if ( ! wp_is_uuid( $job_id ) || ! self::ensure_schema() ) {
			return null;
		}
		$row = $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM ' . self::table() . ' WHERE job_id=%s AND site_id=%d AND actor_id=%d',
			$job_id,
			get_current_blog_id(),
			get_current_user_id()
		), ARRAY_A );
		return is_array( $row ) ? $row : null;
	}

	private static function response( array $row, bool $replayed ) {
		if ( ! self::can_manage() ) {
			return new WP_Error( 'wphave_mcp_shell_forbidden', 'The header proposal is unavailable.' );
		}
		$project = WPHAVE_AI_MCP_Free_Site_Project_Store::status( $row['project_id'] );
		$reference = is_wp_error( $project ) ? null : $project['designReference'];
		$catalog = WPHAVE_AI_MCP_Free_Design_Grammar::catalog();
		$type = $row['part_type'];
		$base = in_array( $type, array( 'header', 'footer' ), true ) ? self::base_part( $type ) : null;
		$assignments = wphave_data_get( 'template_parts', '', array() );
		$expected_hash = hash( 'sha256', $type . "\n" . $row['project_id'] . "\n" . $row['project_revision'] . "\n" . $row['markup'] );
		if ( null === $reference || is_wp_error( $catalog ) || null === $base ||
			! is_array( $assignments ) || ! empty( $assignments[ $type ] ) ||
			(int) $project['revision'] !== (int) $row['project_revision'] ||
			$project['pages'][0]['targetPostId'] !== (int) $row['home_post_id'] ||
			$project['pages'][1]['targetPostId'] !== (int) $row['services_post_id'] ||
			! hash_equals( $reference['fingerprint'], $row['design_fingerprint'] ) ||
			! hash_equals( $reference['contextHash'], $row['context_hash'] ) ||
			! hash_equals( $catalog['fingerprint'], $row['design_fingerprint'] ) ||
			! hash_equals( WPHAVE_AI_MCP_Free_Job_Store::context_fingerprint() ?? '', $row['context_hash'] ) ||
			! hash_equals( self::assignments_hash() ?? '', $row['assignments_hash'] ) ||
			! hash_equals( hash( 'sha256', serialize_blocks( array( $base ) ) ), $row['base_hash'] ) ||
			! hash_equals( $expected_hash, $row['result_hash'] ) ||
			! hash_equals( self::markup( $type, $row['brand'], $row['description'], $row['copyright'], (int) $row['home_post_id'], (int) $row['services_post_id'] ) ?? '', $row['markup'] ) ) {
			return new WP_Error( 'wphave_mcp_shell_stale', 'The header proposal is stale.' );
		}
		return array(
			'jobId' => $row['job_id'],
			'projectId' => $row['project_id'],
			'projectRevision' => (int) $row['project_revision'],
			'partType' => $type,
			'partId' => null,
			'designFingerprint' => $row['design_fingerprint'],
			'resultHash' => $row['result_hash'],
			'markup' => $row['markup'],
			'links' => array(
				array( 'label' => 'Home', 'targetPostId' => (int) $row['home_post_id'], 'title' => get_the_title( (int) $row['home_post_id'] ) ),
				array( 'label' => 'Leistungen', 'targetPostId' => (int) $row['services_post_id'], 'title' => get_the_title( (int) $row['services_post_id'] ) ),
			),
			'globalAssignmentChanged' => false,
			'replayed' => $replayed,
		);
	}

	public static function prepare( string $request_id, string $project_id, int $project_revision, string $brand ) {
		return self::prepare_part( 'header', $request_id, $project_id, $project_revision, $brand, '', '' );
	}

	public static function prepare_footer( string $request_id, string $project_id, int $project_revision, string $brand, string $description, string $copyright ) {
		return self::prepare_part( 'footer', $request_id, $project_id, $project_revision, $brand, $description, $copyright );
	}

	private static function prepare_part( string $type, string $request_id, string $project_id, int $project_revision, string $brand, string $description, string $copyright ) {
		global $wpdb;
		if ( ! self::can_manage() ||
			! in_array( $type, array( 'header', 'footer' ), true ) ||
			! preg_match( '/^[A-Za-z0-9_-]{16,80}$/', $request_id ) ||
			! wp_is_uuid( $project_id ) || $project_revision < 1 ||
			'' === trim( $brand ) || strlen( $brand ) > 80 ||
			$brand !== wp_strip_all_tags( $brand ) ||
			( 'footer' === $type && ( '' === trim( $description ) || '' === trim( $copyright ) ) ) ||
			strlen( $description ) > 240 || strlen( $copyright ) > 120 ||
			$description !== wp_strip_all_tags( $description ) ||
			$copyright !== wp_strip_all_tags( $copyright ) ||
			! self::ensure_schema() ) {
			return new WP_Error( 'wphave_mcp_shell_invalid', 'The shell request is invalid.' );
		}
		$existing = $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM ' . self::table() . ' WHERE site_id=%d AND actor_id=%d AND request_id=%s',
			get_current_blog_id(),
			get_current_user_id(),
			$request_id
		), ARRAY_A );
		if ( is_array( $existing ) ) {
			return $existing['project_id'] === $project_id &&
				$existing['part_type'] === $type &&
				(int) $existing['project_revision'] === $project_revision &&
				$existing['brand'] === $brand &&
				$existing['description'] === $description &&
				$existing['copyright'] === $copyright ?
				self::response( $existing, true ) :
				new WP_Error( 'wphave_mcp_shell_conflict', 'The request ID belongs to another shell proposal.' );
		}
		$project = WPHAVE_AI_MCP_Free_Site_Project_Store::status( $project_id );
		$assignments = wphave_data_get( 'template_parts', '', array() );
		$base = self::base_part( $type );
		if ( is_wp_error( $project ) || $project['revision'] !== $project_revision ||
			! is_array( $assignments ) || ! empty( $assignments[ $type ] ) || null === $base ) {
			return new WP_Error( 'wphave_mcp_shell_stale', 'The shell context changed.' );
		}
		$home_id = $project['pages'][0]['targetPostId'];
		$services_id = $project['pages'][1]['targetPostId'];
		$markup = self::markup( $type, $brand, $description, $copyright, $home_id, $services_id );
		$reference = $project['designReference'];
		$catalog = WPHAVE_AI_MCP_Free_Design_Grammar::catalog();
		if ( null === $markup || is_wp_error( $catalog ) ||
			! hash_equals( $catalog['fingerprint'], $reference['fingerprint'] ) ||
			! hash_equals( WPHAVE_AI_MCP_Free_Job_Store::context_fingerprint() ?? '', $reference['contextHash'] ) ) {
			return new WP_Error( 'wphave_mcp_shell_stale', 'The design context changed.' );
		}
		$payload_hash = hash( 'sha256', $type . "\n" . $project_id . "\n" . $project_revision . "\n" . $brand . "\n" . $description . "\n" . $copyright );
		$result_hash = hash( 'sha256', $type . "\n" . $project_id . "\n" . $project_revision . "\n" . $markup );
		$previous_suppression = $wpdb->suppress_errors( true );
		$inserted = $wpdb->insert( self::table(), array(
			'job_id' => wp_generate_uuid4(),
			'site_id' => get_current_blog_id(),
			'actor_id' => get_current_user_id(),
			'request_id' => $request_id,
			'payload_hash' => $payload_hash,
			'project_id' => $project_id,
			'part_type' => $type,
			'project_revision' => $project_revision,
			'design_fingerprint' => $reference['fingerprint'],
			'context_hash' => $reference['contextHash'],
			'assignments_hash' => self::assignments_hash(),
			'base_hash' => hash( 'sha256', serialize_blocks( array( $base ) ) ),
			'brand' => $brand,
			'description' => $description,
			'copyright' => $copyright,
			'home_post_id' => $home_id,
			'services_post_id' => $services_id,
			'markup' => $markup,
			'result_hash' => $result_hash,
			'created_at' => gmdate( 'Y-m-d H:i:s' ),
		) );
		$wpdb->suppress_errors( $previous_suppression );
		$row = $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM ' . self::table() . ' WHERE site_id=%d AND actor_id=%d AND request_id=%s',
			get_current_blog_id(),
			get_current_user_id(),
			$request_id
		), ARRAY_A );
		if ( ! is_array( $row ) ) {
			return new WP_Error( 'wphave_mcp_shell_uncertain', 'The header state is uncertain.' );
		}
		if ( ! hash_equals( $payload_hash, $row['payload_hash'] ) ) {
			return new WP_Error( 'wphave_mcp_shell_conflict', 'The request ID belongs to another shell proposal.' );
		}
		return self::response( $row, 1 !== $inserted );
	}

	public static function status( string $job_id, string $type = 'header' ) {
		$row = self::can_manage() ? self::read_row( $job_id ) : null;
		return null === $row || $row['part_type'] !== $type ?
			new WP_Error( 'wphave_mcp_shell_forbidden', 'The shell proposal is unavailable.' ) :
			self::response( $row, false );
	}

	/** Recovery-only integrity read after the proposal has become active. */
	public static function activation_markup_matches( string $job_id, string $type, string $markup ): bool {
		$row = self::can_manage() ? self::read_row( $job_id ) : null;
		if ( ! $row || $row['part_type'] !== $type ) {
			return false;
		}
		$expected_hash = hash( 'sha256', $type . "\n" . $row['project_id'] . "\n" . $row['project_revision'] . "\n" . $row['markup'] );
		return hash_equals( $expected_hash, $row['result_hash'] ) &&
			hash_equals( $row['markup'], $markup ) &&
			hash_equals(
				self::markup( $type, $row['brand'], $row['description'], $row['copyright'], (int) $row['home_post_id'], (int) $row['services_post_id'] ) ?? '',
				$markup
			);
	}

	/** Compose a private preview from current saved draft content and two intact proposals. */
	public static function site_preview( string $project_id, string $header_job_id, string $footer_job_id, string $page_key ) {
		if ( ! self::can_manage() || ! in_array( $page_key, array( 'home', 'services' ), true ) ) {
			return new WP_Error( 'wphave_mcp_shell_forbidden', 'The site preview is unavailable.' );
		}
		$project = WPHAVE_AI_MCP_Free_Site_Project_Store::status( $project_id );
		$header = self::status( $header_job_id, 'header' );
		$footer = self::status( $footer_job_id, 'footer' );
		if ( is_wp_error( $project ) || is_wp_error( $header ) || is_wp_error( $footer ) ||
			$header['projectId'] !== $project_id || $footer['projectId'] !== $project_id ||
			$header['projectRevision'] !== $project['revision'] ||
			$footer['projectRevision'] !== $project['revision'] ||
			! hash_equals( $header['designFingerprint'], $footer['designFingerprint'] ) ) {
			return new WP_Error( 'wphave_mcp_shell_stale', 'The site preview is stale.' );
		}
		$page = $project['pages'][ 'home' === $page_key ? 0 : 1 ];
		$post_id = (int) $page['targetPostId'];
		$post = get_post( $post_id );
		if ( ! $post || 'page' !== $post->post_type || 'draft' !== $post->post_status ||
			! current_user_can( 'edit_post', $post_id ) || '' === trim( $post->post_content ) ) {
			return new WP_Error( 'wphave_mcp_shell_stale', 'The saved draft is unavailable.' );
		}
		$body = serialize_blocks( parse_blocks( $post->post_content ) );
		if ( '' === trim( $body ) ) {
			return new WP_Error( 'wphave_mcp_shell_stale', 'The saved draft is unavailable.' );
		}
		return array(
			'projectId' => $project_id,
			'projectRevision' => $project['revision'],
			'pageKey' => $page_key,
			'targetPostId' => $post_id,
			'pageTitle' => get_the_title( $post_id ),
			'headerJobId' => $header_job_id,
			'footerJobId' => $footer_job_id,
			'designFingerprint' => $header['designFingerprint'],
			'links' => $header['links'],
			'markup' => $header['markup'] . "\n" . $body . "\n" . $footer['markup'],
			'footerMarkup' => $footer['markup'],
			'bodyHash' => hash( 'sha256', $post->post_content ),
			'globalAssignmentChanged' => false,
		);
	}
}
