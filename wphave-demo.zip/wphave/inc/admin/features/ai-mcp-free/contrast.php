<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Independent, conservative contrast check for two opaque site color roles. */
final class WPHAVE_AI_MCP_Free_Contrast {
	private static function channels( string $token ): ?array {
		$globals = WPHAVE_Global_Data::get_base();
		$seen = array();
		for ( $depth = 0; $depth < 8; $depth++ ) {
			if ( ! preg_match( '/^var\(--wphave-site-color-([A-Za-z0-9-]+)\)$/', $token, $matches ) ||
				isset( $seen[ $matches[1] ] ) ) {
				return null;
			}
			$seen[ $matches[1] ] = true;
			$token = $globals['colors'][ $matches[1] ]['base'] ?? null;
			if ( ! is_string( $token ) ) {
				return null;
			}
			if ( 0 === strpos( $token, '#' ) ) {
				break;
			}
		}
		$hex = $token;
		if ( ! is_string( $hex ) || ! preg_match( '/^#(?:[a-fA-F0-9]{3}|[a-fA-F0-9]{6})$/', $hex ) ) {
			return null;
		}
		$digits = substr( $hex, 1 );
		if ( strlen( $digits ) === 3 ) {
			$digits = $digits[0] . $digits[0] . $digits[1] . $digits[1] . $digits[2] . $digits[2];
		}
		return array(
			hexdec( substr( $digits, 0, 2 ) ) / 255,
			hexdec( substr( $digits, 2, 2 ) ) / 255,
			hexdec( substr( $digits, 4, 2 ) ) / 255,
		);
	}

	private static function luminance( array $channels ): float {
		$linear = array_map( static function ( float $value ): float {
			return $value <= 0.04045 ? $value / 12.92 : pow( ( $value + 0.055 ) / 1.055, 2.4 );
		}, $channels );
		return 0.2126 * $linear[0] + 0.7152 * $linear[1] + 0.0722 * $linear[2];
	}

	public static function ratio( string $background, string $foreground ): ?float {
		$back = self::channels( $background );
		$front = self::channels( $foreground );
		if ( null === $back || null === $front ) {
			return null;
		}
		$lighter = max( self::luminance( $back ), self::luminance( $front ) );
		$darker = min( self::luminance( $back ), self::luminance( $front ) );
		return ( $lighter + 0.05 ) / ( $darker + 0.05 );
	}
}
