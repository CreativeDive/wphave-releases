<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Private coordination ledger. It never writes WordPress posts or design settings. */
final class WPHAVE_AI_MCP_Free_Site_Project_Store {
	private const SCHEMA_VERSION = 1;

	private static function table(): string {
		global $wpdb;
		return $wpdb->prefix . 'wphave_mcp_free_projects';
	}

	private static function bindings_table(): string {
		global $wpdb;
		return $wpdb->prefix . 'wphave_mcp_free_project_jobs';
	}

	private static function engine_is_innodb( string $table ): bool {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SHOW TABLE STATUS WHERE Name = %s', $table ), ARRAY_A );
		return is_array( $row ) && 0 === strcasecmp( (string) ( $row['Engine'] ?? '' ), 'InnoDB' );
	}

	private static function has_unique_index( string $table, string $index ): bool {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare(
			'SHOW INDEX FROM ' . $table . ' WHERE Key_name = %s AND Non_unique = 0',
			$index
		), ARRAY_A );
		return is_array( $row );
	}

	public static function ensure_schema(): bool {
		global $wpdb;
		if ( ! self::engine_is_innodb( $wpdb->posts ) ) {
			return false;
		}
		$table = self::table();
		if ( ! self::engine_is_innodb( $table ) ||
			! self::has_unique_index( $table, 'request_identity' ) ) {
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			$collate = $wpdb->get_charset_collate();
			dbDelta( "CREATE TABLE {$table} (
				project_id char(36) NOT NULL,
				site_id bigint(20) unsigned NOT NULL,
				actor_id bigint(20) unsigned NOT NULL,
				request_id varchar(80) NOT NULL,
				payload_hash char(64) NOT NULL,
				revision bigint(20) unsigned NOT NULL,
				home_post_id bigint(20) unsigned NOT NULL,
				services_post_id bigint(20) unsigned NOT NULL,
				design_fingerprint char(64) NOT NULL,
				context_hash char(64) NOT NULL,
				wphave_version varchar(80) NOT NULL,
				created_at datetime NOT NULL,
				updated_at datetime NOT NULL,
				PRIMARY KEY  (project_id),
				UNIQUE KEY request_identity (site_id,actor_id,request_id),
				KEY actor_projects (site_id,actor_id,created_at)
			) ENGINE=InnoDB {$collate};" );
		}
		$bindings = self::bindings_table();
		if ( ! self::engine_is_innodb( $bindings ) ||
			! self::has_unique_index( $bindings, 'unique_job' ) ) {
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			$collate = $wpdb->get_charset_collate();
			dbDelta( "CREATE TABLE {$bindings} (
				project_id char(36) NOT NULL,
				page_key varchar(16) NOT NULL,
				job_id char(36) NOT NULL,
				created_at datetime NOT NULL,
				updated_at datetime NOT NULL,
				PRIMARY KEY  (project_id,page_key),
				UNIQUE KEY unique_job (job_id)
			) ENGINE=InnoDB {$collate};" );
		}
		return self::engine_is_innodb( $table ) &&
			self::engine_is_innodb( $bindings ) &&
			self::has_unique_index( $table, 'request_identity' ) &&
			self::has_unique_index( $bindings, 'unique_job' );
	}

	private static function allowed_target( int $post_id ): bool {
		$post = get_post( $post_id );
		return $post instanceof WP_Post &&
			'page' === $post->post_type &&
			'draft' === $post->post_status &&
			'' === trim( $post->post_content ) &&
			current_user_can( 'edit_post', $post_id );
	}

	private static function design_reference(): ?array {
		$catalog = WPHAVE_AI_MCP_Free_Design_Grammar::catalog();
		$context = WPHAVE_AI_MCP_Free_Job_Store::context_fingerprint();
		if ( is_wp_error( $catalog ) || ! is_string( $context ) ||
			! preg_match( '/^[a-f0-9]{64}$/', $catalog['fingerprint'] ?? '' ) ) {
			return null;
		}
		return array(
			'fingerprint' => $catalog['fingerprint'],
			'contextHash' => $context,
			'wphaveVersion' => defined( 'WPHAVE_VERSION' ) ? (string) WPHAVE_VERSION : '',
		);
	}

	private static function visible( array $row ): bool {
		return (int) $row['site_id'] === get_current_blog_id() &&
			(int) $row['actor_id'] === get_current_user_id() &&
			current_user_can( 'wphave_access' ) &&
			current_user_can( 'edit_post', (int) $row['home_post_id'] ) &&
			current_user_can( 'edit_post', (int) $row['services_post_id'] );
	}

	private static function response( array $row, bool $replayed ): array {
		global $wpdb;
		$bindings = $wpdb->get_results( $wpdb->prepare(
			'SELECT page_key,job_id FROM ' . self::bindings_table() . ' WHERE project_id=%s',
			$row['project_id']
		), ARRAY_A );
		$job_ids = array();
		foreach ( $bindings as $binding ) {
			$job_ids[ $binding['page_key'] ] = $binding['job_id'];
		}
		return array(
			'schemaVersion' => self::SCHEMA_VERSION,
			'projectId' => $row['project_id'],
			'revision' => (int) $row['revision'],
			'siteId' => (int) $row['site_id'],
			'actorId' => (int) $row['actor_id'],
			'designReference' => array(
				'fingerprint' => $row['design_fingerprint'],
				'contextHash' => $row['context_hash'],
				'wphaveVersion' => $row['wphave_version'],
			),
			'pages' => array(
				array( 'pageKey' => 'home', 'targetPostId' => (int) $row['home_post_id'], 'jobId' => $job_ids['home'] ?? null ),
				array( 'pageKey' => 'services', 'targetPostId' => (int) $row['services_post_id'], 'jobId' => $job_ids['services'] ?? null ),
			),
			'replayed' => $replayed,
		);
	}

	public static function create( string $request_id, int $home_post_id, int $services_post_id ) {
		global $wpdb;
		if ( ! preg_match( '/^[A-Za-z0-9_-]{16,80}$/', $request_id ) ||
			$home_post_id < 1 || $services_post_id < 1 || $home_post_id === $services_post_id ||
			! current_user_can( 'wphave_access' ) ||
			! function_exists( 'wphave_get_block_editor_mode_by_role' ) ||
			'design' !== wphave_get_block_editor_mode_by_role() ) {
			return new WP_Error( 'wphave_mcp_project_forbidden', 'The project targets are unavailable.' );
		}
		if ( ! self::ensure_schema() ) {
			return new WP_Error( 'wphave_mcp_project_unavailable', 'The project ledger is unavailable.' );
		}
		$existing = $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM ' . self::table() . ' WHERE site_id=%d AND actor_id=%d AND request_id=%s',
			get_current_blog_id(),
			get_current_user_id(),
			$request_id
		), ARRAY_A );
		if ( is_array( $existing ) ) {
			if ( (int) $existing['home_post_id'] !== $home_post_id ||
				(int) $existing['services_post_id'] !== $services_post_id ) {
				return new WP_Error( 'wphave_mcp_project_conflict', 'The request ID belongs to another project.' );
			}
			return self::visible( $existing ) ?
				self::response( $existing, true ) :
				new WP_Error( 'wphave_mcp_project_forbidden', 'The project is unavailable.' );
		}
		if ( ! self::allowed_target( $home_post_id ) || ! self::allowed_target( $services_post_id ) ) {
			return new WP_Error( 'wphave_mcp_project_forbidden', 'The project targets are unavailable.' );
		}
		$reference = self::design_reference();
		if ( null === $reference ) {
			return new WP_Error( 'wphave_mcp_project_unavailable', 'The project context is unavailable.' );
		}
		$site_id = get_current_blog_id();
		$actor_id = get_current_user_id();
		$payload_hash = hash( 'sha256', $home_post_id . "\n" . $services_post_id . "\n" . $reference['fingerprint'] . "\n" . $reference['contextHash'] );
		$now = gmdate( 'Y-m-d H:i:s' );
		$previous_suppression = $wpdb->suppress_errors( true );
		$inserted = $wpdb->insert( self::table(), array(
			'project_id' => wp_generate_uuid4(),
			'site_id' => $site_id,
			'actor_id' => $actor_id,
			'request_id' => $request_id,
			'payload_hash' => $payload_hash,
			'revision' => 1,
			'home_post_id' => $home_post_id,
			'services_post_id' => $services_post_id,
			'design_fingerprint' => $reference['fingerprint'],
			'context_hash' => $reference['contextHash'],
			'wphave_version' => $reference['wphaveVersion'],
			'created_at' => $now,
			'updated_at' => $now,
		) );
		$wpdb->suppress_errors( $previous_suppression );
		$row = $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM ' . self::table() . ' WHERE site_id=%d AND actor_id=%d AND request_id=%s',
			$site_id,
			$actor_id,
			$request_id
		), ARRAY_A );
		if ( ! is_array( $row ) ) {
			return new WP_Error( 'wphave_mcp_project_uncertain', 'The project state is uncertain.' );
		}
		if ( ! hash_equals( $row['payload_hash'], $payload_hash ) ) {
			return new WP_Error( 'wphave_mcp_project_conflict', 'The request ID belongs to another project.' );
		}
		return self::response( $row, 1 !== $inserted );
	}

	public static function status( string $project_id ) {
		global $wpdb;
		if ( ! wp_is_uuid( $project_id ) || ! current_user_can( 'wphave_access' ) || ! self::ensure_schema() ) {
			return new WP_Error( 'wphave_mcp_project_forbidden', 'The project is unavailable.' );
		}
		$row = $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM ' . self::table() . ' WHERE project_id=%s AND site_id=%d AND actor_id=%d',
			$project_id,
			get_current_blog_id(),
			get_current_user_id()
		), ARRAY_A );
		return is_array( $row ) && self::visible( $row ) ?
			self::response( $row, false ) :
			new WP_Error( 'wphave_mcp_project_forbidden', 'The project is unavailable.' );
	}

	/** Bind one existing page job with a compare-and-swap project revision. */
	public static function bind_job( string $project_id, int $expected_revision, string $page_key, string $job_id ) {
		global $wpdb;
		if ( ! wp_is_uuid( $project_id ) || ! wp_is_uuid( $job_id ) ||
			$expected_revision < 1 || ! in_array( $page_key, array( 'home', 'services' ), true ) ||
			! current_user_can( 'wphave_access' ) || ! self::ensure_schema() ) {
			return new WP_Error( 'wphave_mcp_project_invalid', 'The job binding is invalid.' );
		}
		if ( false === $wpdb->query( 'START TRANSACTION' ) ) {
			return new WP_Error( 'wphave_mcp_project_uncertain', 'The project transaction is unavailable.' );
		}
		$committed = false;
		try {
			$row = $wpdb->get_row( $wpdb->prepare(
				'SELECT * FROM ' . self::table() . ' WHERE project_id=%s AND site_id=%d AND actor_id=%d FOR UPDATE',
				$project_id,
				get_current_blog_id(),
				get_current_user_id()
			), ARRAY_A );
			if ( ! is_array( $row ) || ! self::visible( $row ) ) {
				return new WP_Error( 'wphave_mcp_project_forbidden', 'The project is unavailable.' );
			}
			$existing = $wpdb->get_row( $wpdb->prepare(
				'SELECT job_id FROM ' . self::bindings_table() . ' WHERE project_id=%s AND page_key=%s',
				$project_id,
				$page_key
			), ARRAY_A );
			if ( is_array( $existing ) && hash_equals( $existing['job_id'], $job_id ) ) {
				$wpdb->query( 'COMMIT' );
				$committed = true;
				return self::response( $row, true );
			}
			if ( (int) $row['revision'] !== $expected_revision ) {
				return new WP_Error( 'wphave_mcp_project_revision_conflict', 'The project revision changed.' );
			}
			$snapshot = WPHAVE_AI_MCP_Free_Job_Store::binding_snapshot( $job_id );
			$target_id = (int) $row[ $page_key . '_post_id' ];
			$post = get_post( $target_id );
			if ( null === $snapshot || ! $post instanceof WP_Post ||
				$snapshot['siteId'] !== (int) $row['site_id'] ||
				$snapshot['actorId'] !== (int) $row['actor_id'] ||
				$snapshot['targetPostId'] !== $target_id ||
				! hash_equals( $row['design_fingerprint'], $snapshot['designFingerprint'] ) ||
				! hash_equals( $row['context_hash'], $snapshot['contextHash'] ) ||
				! hash_equals( hash( 'sha256', $post->post_content ), $snapshot['revisionHash'] ) ) {
				return new WP_Error( 'wphave_mcp_project_job_mismatch', 'The page job does not match this project slot.' );
			}
			$now = gmdate( 'Y-m-d H:i:s' );
			$previous_suppression = $wpdb->suppress_errors( true );
			if ( is_array( $existing ) ) {
				$changed = $wpdb->update(
					self::bindings_table(),
					array( 'job_id' => $job_id, 'updated_at' => $now ),
					array( 'project_id' => $project_id, 'page_key' => $page_key )
				);
			} else {
				$changed = $wpdb->insert( self::bindings_table(), array(
					'project_id' => $project_id,
					'page_key' => $page_key,
					'job_id' => $job_id,
					'created_at' => $now,
					'updated_at' => $now,
				) );
			}
			$wpdb->suppress_errors( $previous_suppression );
			if ( 1 !== $changed ) {
				return new WP_Error( 'wphave_mcp_project_job_conflict', 'The page job is already bound.' );
			}
			$advanced = $wpdb->query( $wpdb->prepare(
				'UPDATE ' . self::table() . ' SET revision=revision+1,updated_at=%s WHERE project_id=%s AND revision=%d',
				$now,
				$project_id,
				$expected_revision
			) );
			if ( 1 !== $advanced ) {
				return new WP_Error( 'wphave_mcp_project_revision_conflict', 'The project revision changed.' );
			}
			if ( false === $wpdb->query( 'COMMIT' ) ) {
				return new WP_Error( 'wphave_mcp_project_uncertain', 'The project commit is uncertain.' );
			}
			$committed = true;
			$row['revision'] = $expected_revision + 1;
			return self::response( $row, false );
		} finally {
			if ( ! $committed ) {
				$wpdb->query( 'ROLLBACK' );
			}
		}
	}
}
