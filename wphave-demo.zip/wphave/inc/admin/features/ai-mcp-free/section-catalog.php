<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Executable section recipes built from the existing native MCP grammar. */
final class WPHAVE_AI_MCP_Free_Section_Catalog {
	public static function example(): array {
		return array(
			'section' => array(
				'key' => 'intro',
				'layout' => 'stacked',
				'purpose' => 'Introduce the practice in a concise editorial opening',
				'type' => 'text-flow',
				'variant' => 'eyebrow-heading-copy',
			),
			'nodes' => array(
				array(
					'key' => 'intro',
					'parentKey' => null,
					'name' => 'wphave/group',
					'attributes' => new stdClass(),
					'design' => array( array( 'device' => 'Desktop', 'path' => 'layout.type', 'value' => 'stacked' ) ),
				),
				array(
					'key' => 'intro_eyebrow',
					'parentKey' => 'intro',
					'name' => 'wphave/paragraph',
					'attributes' => array( 'content' => 'A thoughtful introduction' ),
					'design' => array( array( 'device' => 'Desktop', 'path' => 'text.typeface.size', 'value' => array( 'type' => 'text-s' ) ) ),
				),
				array(
					'key' => 'intro_heading',
					'parentKey' => 'intro',
					'name' => 'wphave/heading',
					'attributes' => array( 'content' => 'A clear opening statement' ),
					'design' => array( array( 'device' => 'Desktop', 'path' => 'text.typeface.size', 'value' => array( 'type' => 'title-xl' ) ) ),
				),
				array(
					'key' => 'intro_copy',
					'parentKey' => 'intro',
					'name' => 'wphave/paragraph',
					'attributes' => array( 'content' => 'Explain the benefit in a few useful sentences.' ),
					'design' => array( array( 'device' => 'Desktop', 'path' => 'text.typeface.size', 'value' => array( 'type' => 'text-m' ) ) ),
				),
			),
		);
	}

	public static function definitions(): array {
		return array(
			'text-flow' => array(
				'purpose' => 'Editorial text without an inset surface',
				'layout' => 'stacked',
				'variants' => array( 'heading', 'eyebrow-heading', 'heading-copy', 'eyebrow-heading-copy', 'display-heading', 'stretch-heading' ),
				'slots' => array( 'eyebrow' => 'optional paragraph', 'heading' => 'required heading', 'copy' => 'optional paragraph' ),
				'fixed' => array( 'no section padding or background', 'direct text blocks follow the selected variant' ),
				'typography' => array(
					'eyebrow' => array( 'text-xs', 'text-s' ),
					'heading' => array( 'title-m', 'title-l', 'title-xl', 'title-xxl' ),
					'displayHeading' => array( 'title-3xl', 'title-4xl', 'title-5xl', 'title-6xl' ),
					'copy' => array( 'text-m', 'text-l' ),
				),
				'variable' => array( 'content', 'heading size within the allowed variant scale', 'eyebrow and copy size within their allowed scales' ),
			),
			'color-panel' => array(
				'purpose' => 'Text on a deliberate colored inset surface',
				'layout' => 'stacked',
				'variants' => array( 'heading-copy', 'eyebrow-heading-copy' ),
				'slots' => array( 'eyebrow' => 'optional paragraph', 'heading' => 'required heading', 'copy' => 'required paragraph' ),
				'fixed' => array( 'outer Group has background.color.base and dimensions.spacing.padding' ),
				'typography' => array(
					'eyebrow' => array( 'text-xs', 'text-s' ),
					'heading' => array( 'title-m', 'title-l', 'title-xl', 'title-xxl' ),
					'copy' => array( 'text-m', 'text-l' ),
				),
				'variable' => array( 'content', 'listed background color token', 'listed padding token', 'permitted text sizes and colors' ),
			),
			'color-section' => array(
				'purpose' => 'Colored outer section with one composable content slot',
				'layout' => 'stacked',
				'variants' => array( 'content' ),
				'slots' => array( 'content' => 'one child Group with native Stacked, Grid or Flex content' ),
				'fixed' => array( 'outer Group has background.color.base and dimensions.spacing.padding', 'inner Group has content' ),
				'variable' => array( 'listed background and padding tokens', 'nested Group layout and native child blocks' ),
			),
			'image-text' => array(
				'purpose' => 'Editorial image and copy split',
				'layout' => 'grid',
				'variants' => array( 'image-left', 'image-right' ),
				'slots' => array( 'image' => 'one verified image', 'copy' => 'one text Group' ),
				'fixed' => array( 'Desktop two-column Grid', 'Mobile one-column Grid', 'direct child order follows variant' ),
				'variable' => array( 'copy content', 'verified media ID and alt', 'section surface', 'column gap' ),
			),
			'card-grid' => array(
				'purpose' => 'Balanced peer cards',
				'layout' => 'grid',
				'variants' => array( 'two', 'three', 'four' ),
				'slots' => array( 'cards' => 'two to four direct child Groups with content' ),
				'fixed' => array( 'Desktop columns match variant and card count', 'Mobile one column' ),
				'variable' => array( 'card content', 'listed gap token', 'section surface' ),
			),
			'call-to-action' => array(
				'purpose' => 'Focused closing action',
				'layout' => 'stacked',
				'variants' => array( 'plain', 'color' ),
				'slots' => array( 'heading' => 'one heading', 'copy' => 'optional paragraph', 'action' => 'one button' ),
				'fixed' => array( 'heading precedes button', 'color variant uses outer Group background and padding' ),
				'variable' => array( 'heading and button content', 'optional copy', 'listed color and padding tokens' ),
			),
			'divider' => array(
				'purpose' => 'A minimal horizontal separator between content sections',
				'layout' => 'stacked',
				'variants' => array( 'solid' ),
				'slots' => array( 'line' => 'one native Line block' ),
				'fixed' => array( 'outer Group has no background or padding', 'Line style is solid' ),
				'variable' => array( 'lineCatalog size and optional site color token' ),
			),
		);
	}

	public static function valid( array $section, array $root, array $nodes ): bool {
		if ( ! is_string( $section['type'] ?? null ) ||
			! is_string( $section['variant'] ?? null ) ||
			! is_string( $section['layout'] ?? null ) ) {
			return false;
		}
		$definition = self::definitions()[ $section['type'] ] ?? null;
		if ( null === $definition ||
			! in_array( $section['variant'] ?? null, $definition['variants'], true ) ||
			$section['layout'] !== $definition['layout'] ) {
			return false;
		}
		$children = array_values( array_filter( $nodes, static function ( $node ) use ( $root ): bool {
			return ( $node['parentKey'] ?? null ) === $root['key'];
		} ) );
		$names = array_column( $children, 'name' );
		$operations = array();
		foreach ( $root['design'] ?? array() as $operation ) {
			$operations[ $operation['device'] . ':' . $operation['path'] ] = $operation['value'];
		}
		$has_surface = isset( $operations['Desktop:background.color.base'] );
		$has_padding = isset( $operations['Desktop:dimensions.spacing.padding'] ) &&
			'0' !== $operations['Desktop:dimensions.spacing.padding'];
		$type = $section['type'];
		$variant = $section['variant'];
		if ( 'text-flow' === $type || 'color-panel' === $type ) {
			if ( 'stretch-heading' === $variant ) {
				return 'text-flow' === $type &&
					$names === array( 'wphave/heading' ) &&
					! $has_surface && ! $has_padding &&
					isset( $children[0]['heading'] );
			}
			$patterns = array(
				'heading' => array( 'wphave/heading' ),
				'eyebrow-heading' => array( 'wphave/paragraph', 'wphave/heading' ),
				'heading-copy' => array( 'wphave/heading', 'wphave/paragraph' ),
				'eyebrow-heading-copy' => array( 'wphave/paragraph', 'wphave/heading', 'wphave/paragraph' ),
				'display-heading' => array( 'wphave/heading' ),
			);
			if ( $names !== $patterns[ $variant ] ||
				( 'text-flow' === $type && ( $has_surface || $has_padding ) ) ||
				( 'color-panel' === $type && ( ! $has_surface || ! $has_padding ) ) ) {
				return false;
			}
			$heading_index = str_starts_with( $variant, 'eyebrow-' ) ? 1 : 0;
			$heading_sizes = 'display-heading' === $variant ?
				$definition['typography']['displayHeading'] :
				$definition['typography']['heading'];
			if ( ! in_array( self::text_size( $children[ $heading_index ] ), $heading_sizes, true ) ) {
				return false;
			}
			if ( 1 === $heading_index &&
				! in_array( self::text_size( $children[0] ), $definition['typography']['eyebrow'], true ) ) {
				return false;
			}
			if ( str_ends_with( $variant, '-copy' ) &&
				! in_array( self::text_size( $children[ count( $children ) - 1 ] ), $definition['typography']['copy'], true ) ) {
				return false;
			}
			return true;
		}
		if ( 'image-text' === $type ) {
			$expected = 'image-left' === $variant ?
				array( 'wphave/image', 'wphave/group' ) :
				array( 'wphave/group', 'wphave/image' );
			return $names === $expected &&
				( $operations['Desktop:layout.grid.columns'] ?? null ) === 2 &&
				( $operations['Mobile:layout.grid.columns'] ?? null ) === 1 &&
				self::children_have_content( $children, $nodes );
		}
		if ( 'color-section' === $type ) {
			return $names === array( 'wphave/group' ) &&
				$has_surface && $has_padding &&
				self::children_have_content( $children, $nodes );
		}
		if ( 'card-grid' === $type ) {
			$count = array( 'two' => 2, 'three' => 3, 'four' => 4 )[ $variant ];
			return count( $children ) === $count &&
				count( array_filter( $names, static function ( $name ): bool {
					return 'wphave/group' === $name;
				} ) ) === $count &&
				( $operations['Desktop:layout.grid.columns'] ?? null ) === $count &&
				( $operations['Mobile:layout.grid.columns'] ?? null ) === 1 &&
				self::children_have_content( $children, $nodes );
		}
		if ( 'call-to-action' === $type ) {
			return in_array( $names, array(
				array( 'wphave/heading', 'wphave/button' ),
				array( 'wphave/heading', 'wphave/paragraph', 'wphave/button' ),
			), true ) &&
				( 'color' !== $variant || ( $has_surface && $has_padding ) ) &&
				( 'plain' !== $variant || ( ! $has_surface && ! $has_padding ) );
		}
		if ( 'divider' === $type ) {
			return $names === array( 'wphave/line' ) &&
				! $has_surface && ! $has_padding &&
				isset( $children[0]['line'] );
		}
		return false;
	}

	private static function text_size( array $node ): ?string {
		foreach ( $node['design'] ?? array() as $operation ) {
			if ( 'Desktop' === ( $operation['device'] ?? null ) &&
				'text.typeface.size' === ( $operation['path'] ?? null ) &&
				is_array( $operation['value'] ?? null ) ) {
				return $operation['value']['type'] ?? null;
			}
		}
		return null;
	}

	private static function children_have_content( array $children, array $nodes ): bool {
		foreach ( $children as $child ) {
			if ( 'wphave/group' !== $child['name'] ) {
				continue;
			}
			$has_content = false;
			foreach ( $nodes as $node ) {
				if ( ( $node['parentKey'] ?? null ) === $child['key'] ) {
					$has_content = true;
					break;
				}
			}
			if ( ! $has_content ) {
				return false;
			}
		}
		return true;
	}
}
