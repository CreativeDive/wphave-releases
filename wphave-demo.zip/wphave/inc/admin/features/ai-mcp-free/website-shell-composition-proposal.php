<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Private, versioned native shell proposals for multi-page draft projects. */
final class WPHAVE_AI_MCP_Free_Website_Shell_Composition_Proposal {
	private static function table(): string {
		global $wpdb;
		return $wpdb->prefix . 'wphave_mcp_free_site_shell_v1';
	}

	private static function can_manage(): bool {
		return wphave_mcp_free_create_feature_enabled() &&
			current_user_can( 'wphave_access' ) &&
			current_user_can( 'wphave_manage_template_parts' ) &&
			current_user_can( 'edit_pages' ) &&
			! wphave_use_fse();
	}

	private static function ensure_schema(): bool {
		global $wpdb;
		$table = self::table();
		$exists = $wpdb->get_row( $wpdb->prepare( 'SHOW TABLE STATUS WHERE Name = %s', $table ), ARRAY_A );
		if ( is_array( $exists ) ) {
			return self::table_ready( $exists );
		}
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$collate = $wpdb->get_charset_collate();
		dbDelta( "CREATE TABLE {$table} (
			proposal_id char(36) NOT NULL,
			site_id bigint(20) unsigned NOT NULL,
			actor_id bigint(20) unsigned NOT NULL,
			request_id varchar(80) NOT NULL,
			project_id char(36) NOT NULL,
			contract_version tinyint(3) unsigned NOT NULL,
			plan_hash char(64) NOT NULL,
			pages_hash char(64) NOT NULL,
			grammar_fingerprint char(64) NOT NULL,
			site_design_fingerprint char(64) NOT NULL,
			assignment_revision char(64) NOT NULL,
			header_markup longtext NOT NULL,
			footer_markup longtext NOT NULL,
			header_hash char(64) NOT NULL,
			footer_hash char(64) NOT NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY  (proposal_id),
			UNIQUE KEY request_identity (site_id,actor_id,request_id),
			KEY project_scope (site_id,actor_id,project_id)
		) ENGINE=InnoDB {$collate};" );
		$created = $wpdb->get_row(
			$wpdb->prepare( 'SHOW TABLE STATUS WHERE Name = %s', $table ),
			ARRAY_A
		);
		return is_array( $created ) && self::table_ready( $created );
	}

	private static function table_ready( array $status ): bool {
		global $wpdb;
		if ( 0 !== strcasecmp( (string) ( $status['Engine'] ?? '' ), 'InnoDB' ) ) {
			return false;
		}
		$index = $wpdb->get_var( $wpdb->prepare(
			'SHOW INDEX FROM ' . self::table() . ' WHERE Key_name = %s AND Non_unique = 0',
			'request_identity'
		) );
		return null !== $index;
	}

	private static function context( string $project_id ) {
		$status = WPHAVE_AI_MCP_Free_Website_Draft_Project::status( array( 'projectId' => $project_id ) );
		$identity = WPHAVE_AI_MCP_Free_Site_Design_Identity::snapshot();
		$grammar = WPHAVE_AI_MCP_Free_Design_Grammar::catalog();
		$assignment_revision = WPHAVE_Data_Resources::get_revision( 'template_parts' );
		if ( is_wp_error( $status ) || is_wp_error( $identity ) || is_wp_error( $grammar ) ||
			! is_string( $assignment_revision ) || '' === $assignment_revision ||
			! is_array( $status['designPlan'] ?? null ) ||
			4 !== ( $status['designPlan']['version'] ?? null ) ||
			! is_array( $status['siteShell'] ?? null ) ||
			! hash_equals( $status['designFingerprint'], $grammar['fingerprint'] ) ||
			! hash_equals(
				$identity['fingerprint'],
				$status['designPlan']['siteDesignContract']['siteDesignFingerprint'] ?? ''
			) ) {
			return new WP_Error( 'wphave_mcp_shell_stale', 'The private website shell context changed.' );
		}
		$pages = $status['pages'];
		$page_keys = array_column( $pages, 'pageKey' );
		if ( ! WPHAVE_AI_MCP_Free_Shell_Composition::valid(
			$status['designPlan']['shellComposition'] ?? null,
			$page_keys,
			$status['designPlan']['siteDesignContract']
		) ) {
			return new WP_Error( 'wphave_mcp_shell_stale', 'The private website shell plan changed.' );
		}
		$hashes = array();
		foreach ( $pages as $page ) {
			if ( 'draft' !== $page['status'] ||
				! current_user_can( 'edit_post', $page['postId'] ) ||
				! WPHAVE_AI_MCP_Create_Service::owns_created_draft( $page['postId'] ) ) {
				return new WP_Error( 'wphave_mcp_shell_stale', 'A private website page changed.' );
			}
			$hashes[ $page['pageKey'] ] = array(
				'postId' => $page['postId'],
				'markupHash' => $page['markupHash'],
			);
		}
		$plan_json = wp_json_encode( $status['designPlan'] );
		$pages_json = wp_json_encode( $hashes );
		if ( ! is_string( $plan_json ) || ! is_string( $pages_json ) ) {
			return new WP_Error( 'wphave_mcp_shell_stale', 'The private website shell state is unavailable.' );
		}
		return array(
			'status' => $status,
			'planHash' => hash( 'sha256', $plan_json ),
			'pagesHash' => hash( 'sha256', $pages_json ),
			'pageIds' => array_column( $pages, 'postId', 'pageKey' ),
			'grammarFingerprint' => $grammar['fingerprint'],
			'siteDesignFingerprint' => $identity['fingerprint'],
			'assignmentRevision' => $assignment_revision,
		);
	}

	private static function response( array $row, array $context ): array {
		return array(
			'proposalId' => $row['proposal_id'],
			'projectId' => $row['project_id'],
			'contractVersion' => (int) $row['contract_version'],
			'headerMarkup' => $row['header_markup'],
			'footerMarkup' => $row['footer_markup'],
			'headerHash' => $row['header_hash'],
			'footerHash' => $row['footer_hash'],
			'pageIds' => $context['pageIds'],
			'globalAssignmentChanged' => false,
		);
	}

	private static function current_row( array $row ) {
		$context = self::context( $row['project_id'] );
		if ( is_wp_error( $context ) ||
			1 !== (int) $row['contract_version'] ||
			! hash_equals( $row['plan_hash'], $context['planHash'] ) ||
			! hash_equals( $row['pages_hash'], $context['pagesHash'] ) ||
			! hash_equals( $row['grammar_fingerprint'], $context['grammarFingerprint'] ) ||
			! hash_equals( $row['site_design_fingerprint'], $context['siteDesignFingerprint'] ) ||
			! hash_equals( $row['assignment_revision'], $context['assignmentRevision'] ) ||
			! hash_equals( $row['header_hash'], hash( 'sha256', $row['header_markup'] ) ) ||
			! hash_equals( $row['footer_hash'], hash( 'sha256', $row['footer_markup'] ) ) ||
			serialize_blocks( parse_blocks( $row['header_markup'] ) ) !== $row['header_markup'] ||
			serialize_blocks( parse_blocks( $row['footer_markup'] ) ) !== $row['footer_markup'] ) {
			return new WP_Error( 'wphave_mcp_shell_stale', 'The private shell proposal is stale.' );
		}
		return self::response( $row, $context );
	}

	public static function prepare( $input ) {
		global $wpdb;
		if ( ! self::can_manage() || ! is_array( $input ) ||
			count( $input ) !== 2 || ! array_key_exists( 'requestId', $input ) ||
			! array_key_exists( 'projectId', $input ) ||
			! is_string( $input['requestId'] ) ||
			! preg_match( '/^[A-Za-z0-9_-]{16,80}$/D', $input['requestId'] ) ||
			! is_string( $input['projectId'] ) || ! wp_is_uuid( $input['projectId'] ) ||
			! self::ensure_schema() ) {
			return new WP_Error( 'wphave_mcp_shell_invalid', 'The shell proposal request is invalid.' );
		}
		$context = self::context( $input['projectId'] );
		if ( is_wp_error( $context ) ) {
			return $context;
		}
		$existing = $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM ' . self::table() . ' WHERE site_id=%d AND actor_id=%d AND request_id=%s',
			get_current_blog_id(),
			get_current_user_id(),
			$input['requestId']
		), ARRAY_A );
		if ( is_array( $existing ) ) {
			return $existing['project_id'] === $input['projectId'] &&
				hash_equals( $existing['plan_hash'], $context['planHash'] ) ?
				self::current_row( $existing ) :
				new WP_Error( 'wphave_mcp_shell_conflict', 'The request ID belongs to another shell plan.' );
		}
		$parts = array();
		foreach ( array( 'header', 'footer' ) as $part ) {
			$parts[ $part ] = WPHAVE_AI_MCP_Free_Shell_Composition::render_part(
				$context['status']['designPlan']['shellComposition'][ $part ],
				$part,
				$context['pageIds'],
				$context['grammarFingerprint']
			);
			if ( is_wp_error( $parts[ $part ] ) ) {
				return $parts[ $part ];
			}
		}
		$fresh = self::context( $input['projectId'] );
		if ( is_wp_error( $fresh ) ||
			! hash_equals( $context['planHash'], $fresh['planHash'] ) ||
			! hash_equals( $context['pagesHash'], $fresh['pagesHash'] ) ||
			! hash_equals( $context['siteDesignFingerprint'], $fresh['siteDesignFingerprint'] ) ||
			! hash_equals( $context['assignmentRevision'], $fresh['assignmentRevision'] ) ) {
			return new WP_Error( 'wphave_mcp_shell_stale', 'The private website shell context changed.' );
		}
		$proposal_id = wp_generate_uuid4();
		$previous_suppression = $wpdb->suppress_errors( true );
		$inserted = $wpdb->insert( self::table(), array(
			'proposal_id' => $proposal_id,
			'site_id' => get_current_blog_id(),
			'actor_id' => get_current_user_id(),
			'request_id' => $input['requestId'],
			'project_id' => $input['projectId'],
			'contract_version' => 1,
			'plan_hash' => $context['planHash'],
			'pages_hash' => $context['pagesHash'],
			'grammar_fingerprint' => $context['grammarFingerprint'],
			'site_design_fingerprint' => $context['siteDesignFingerprint'],
			'assignment_revision' => $context['assignmentRevision'],
			'header_markup' => $parts['header'],
			'footer_markup' => $parts['footer'],
			'header_hash' => hash( 'sha256', $parts['header'] ),
			'footer_hash' => hash( 'sha256', $parts['footer'] ),
			'created_at' => current_time( 'mysql', true ),
		) );
		$wpdb->suppress_errors( $previous_suppression );
		if ( false === $inserted ) {
			$replayed = $wpdb->get_row( $wpdb->prepare(
				'SELECT * FROM ' . self::table() . ' WHERE site_id=%d AND actor_id=%d AND request_id=%s',
				get_current_blog_id(),
				get_current_user_id(),
				$input['requestId']
			), ARRAY_A );
			if ( is_array( $replayed ) ) {
				return $replayed['project_id'] === $input['projectId'] &&
					hash_equals( $replayed['plan_hash'], $context['planHash'] ) ?
					self::current_row( $replayed ) :
					new WP_Error( 'wphave_mcp_shell_conflict', 'The request ID belongs to another shell plan.' );
			}
			return new WP_Error( 'wphave_mcp_shell_uncertain', 'The private shell proposal could not be committed.' );
		}
		return self::status( array( 'proposalId' => $proposal_id ) );
	}

	public static function status( $input ) {
		global $wpdb;
		if ( ! self::can_manage() || ! is_array( $input ) ||
			array_keys( $input ) !== array( 'proposalId' ) ||
			! is_string( $input['proposalId'] ) || ! wp_is_uuid( $input['proposalId'] ) ) {
			return new WP_Error( 'wphave_mcp_shell_forbidden', 'The shell proposal is unavailable.' );
		}
		$row = $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM ' . self::table() . ' WHERE proposal_id=%s AND site_id=%d AND actor_id=%d',
			$input['proposalId'],
			get_current_blog_id(),
			get_current_user_id()
		), ARRAY_A );
		return is_array( $row ) ?
			self::current_row( $row ) :
			new WP_Error( 'wphave_mcp_shell_forbidden', 'The shell proposal is unavailable.' );
	}

	public static function preview_url( $input ) {
		$proposal = self::status( $input );
		if ( is_wp_error( $proposal ) || ! is_int( $proposal['pageIds']['home'] ?? null ) ) {
			return new WP_Error( 'wphave_mcp_shell_forbidden', 'The shell preview is unavailable.' );
		}
		$url = WPHAVE_AI_MCP_Free_Visual_Preview::interactive_url(
			$proposal['projectId'],
			$proposal['pageIds']['home'],
			$proposal['proposalId']
		);
		return is_string( $url ) ?
			array( 'interactivePreviewUrl' => $url ) :
			new WP_Error( 'wphave_mcp_shell_forbidden', 'The shell preview is unavailable.' );
	}
}
