<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Shared fluid Spacer presets; fixed dimensions remain editor-only. */
final class WPHAVE_AI_MCP_Free_Spacer_Recipes {
	public static function specification(): ?array {
		$path = __DIR__ . '/spacer-recipes.json';
		$spec = is_readable( $path ) ? json_decode( (string) file_get_contents( $path ), true ) : null;
		return is_array( $spec ) && 1 === ( $spec['version'] ?? null ) &&
			is_array( $spec['presets'] ?? null ) ? $spec : null;
	}

	public static function options(): ?array {
		return self::specification();
	}

	public static function valid( $recipe ): bool {
		$spec = self::specification();
		return null !== $spec && is_array( $recipe ) &&
			array_keys( $recipe ) === array( 'size' ) &&
			is_string( $recipe['size'] ) &&
			isset( $spec['presets'][ $recipe['size'] ] );
	}

	public static function expected_attributes( array $recipe ): ?array {
		if ( ! self::valid( $recipe ) ) {
			return null;
		}
		return array( 'wphave' => array( 'settings' => array(
			'type' => 'aspectRatio',
			'aspectRatio' => self::specification()['presets'][ $recipe['size'] ],
		) ) );
	}
}
