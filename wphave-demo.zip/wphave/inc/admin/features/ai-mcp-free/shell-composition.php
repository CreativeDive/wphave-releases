<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** A bounded native Header/Footer plan for private website projects. */
final class WPHAVE_AI_MCP_Free_Shell_Composition {
	private const GROUP_PATHS = array(
		'layout.type',
		'layout.flex.flexDirection',
		'layout.flex.flexWrap',
		'layout.flex.alignHorizontal',
		'layout.flex.alignVertical',
		'layout.grid.columns',
		'layout.grid.gapX',
		'layout.grid.gapY',
		'dimensions.width.custom',
		'dimensions.spacing.padding',
		'background.color.base',
	);

	private static function exact_keys( array $value, array $keys ): bool {
		$actual = array_keys( $value );
		sort( $actual );
		sort( $keys );
		return $actual === $keys;
	}

	private static function valid_external_url( $url ): bool {
		if ( ! is_string( $url ) || strlen( $url ) > 2048 ||
			! preg_match( '~^https://[a-z0-9.-]+(?:/[a-zA-Z0-9._\~:/?#\[\]@!$&\'()*+,;=%-]*)?$~iD', $url ) ) {
			return false;
		}
		$parts = wp_parse_url( $url );
		$host = is_array( $parts ) ? ( $parts['host'] ?? '' ) : '';
		return is_string( $host ) &&
			(bool) preg_match( '/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/iD', $host ) &&
			! preg_match( '/(?:^|\.)(?:local|localhost|test|invalid)$/i', $host ) &&
			! filter_var( $host, FILTER_VALIDATE_IP ) &&
			! isset( $parts['user'] ) && ! isset( $parts['pass'] ) &&
			! isset( $parts['port'] );
	}

	private static function valid_links( $links, array $page_keys ): bool {
		if ( ! is_array( $links ) || count( $links ) < count( $page_keys ) ||
			count( $links ) > min( 16, count( $page_keys ) + 4 ) || ! array_is_list( $links ) ) {
			return false;
		}
		$seen = array();
		foreach ( $links as $link ) {
			if ( ! is_array( $link ) || ! self::exact_keys( $link, array( 'label', 'target' ) ) ||
				! is_string( $link['label'] ) || '' === trim( $link['label'] ) ||
				mb_strlen( $link['label'] ) > 40 || sanitize_text_field( $link['label'] ) !== $link['label'] ||
				! is_array( $link['target'] ) || ! isset( $link['target']['kind'] ) ) {
				return false;
			}
			$target = $link['target'];
			if ( 'projectPage' === $target['kind'] ) {
				$key = $target['pageKey'] ?? null;
				if ( ! self::exact_keys( $target, array( 'kind', 'pageKey' ) ) ||
					! is_string( $key ) || ! in_array( $key, $page_keys, true ) || isset( $seen[ $key ] ) ) {
					return false;
				}
				$seen[ $key ] = true;
			} elseif ( 'external' === $target['kind'] ) {
				if ( ! self::exact_keys( $target, array( 'kind', 'url' ) ) ||
					! self::valid_external_url( $target['url'] ?? null ) ) {
					return false;
				}
			} else {
				return false;
			}
		}
		return count( $seen ) === count( $page_keys );
	}

	private static function valid_navigation( array $node, array $page_keys, string $part ): bool {
		if ( ! self::exact_keys( $node, array( 'key', 'parentKey', 'name', 'settings', 'links' ) ) ||
			! is_array( $node['settings'] ) ||
			! self::exact_keys( $node['settings'], array( 'collapseBehavior', 'collapseBreakpoint', 'panelType', 'toggleStyle', 'orientation' ) ) ||
			! in_array( $node['settings']['collapseBehavior'], 'header' === $part ? array( 'auto', 'always' ) : array( 'never' ), true ) ||
			! in_array( $node['settings']['collapseBreakpoint'], array( 768, 992, 1200 ), true ) ||
			! in_array( $node['settings']['panelType'], array( 'overlay', 'drawer' ), true ) ||
			! in_array( $node['settings']['toggleStyle'], array( 'default', 'minimal', 'compact', 'staggered' ), true ) ||
			! in_array( $node['settings']['orientation'], array( 'horizontal', 'vertical' ), true ) ) {
			return false;
		}
		return self::valid_links( $node['links'], $page_keys );
	}

	private static function valid_part( $part, array $page_keys, array $contract, string $part_name ): bool {
		if ( ! is_array( $part ) || ! self::exact_keys( $part, array( 'nodes' ) ) ||
			! is_array( $part['nodes'] ) || ! array_is_list( $part['nodes'] ) ||
			count( $part['nodes'] ) < 3 || count( $part['nodes'] ) > 20 ) {
			return false;
		}
		$parents = array();
		$depths = array();
		$navigation_count = 0;
		foreach ( $part['nodes'] as $index => $node ) {
			if ( ! is_array( $node ) || ! is_string( $node['key'] ?? null ) ||
				! preg_match( '/^[a-z][a-z0-9_-]{0,31}$/D', $node['key'] ) ||
				isset( $parents[ $node['key'] ] ) ||
				! in_array( $node['name'] ?? null, array( 'wphave/group', 'wphave/paragraph', 'wphave/navigation' ), true ) ||
				! array_key_exists( 'parentKey', $node ) ||
				( 0 === $index && ( null !== $node['parentKey'] || 'wphave/group' !== $node['name'] ) ) ||
				( 0 !== $index && ( ! is_string( $node['parentKey'] ?? null ) ||
					( $parents[ $node['parentKey'] ] ?? null ) !== 'wphave/group' ||
					( $depths[ $node['parentKey'] ] ?? 3 ) >= 3 ) ) ) {
				return false;
			}
			$parents[ $node['key'] ] = $node['name'];
			$depths[ $node['key'] ] = 0 === $index ? 0 : $depths[ $node['parentKey'] ] + 1;
			if ( 'wphave/navigation' === $node['name'] ) {
				++$navigation_count;
				if ( ! self::valid_navigation( $node, $page_keys, $part_name ) ) {
					return false;
				}
				continue;
			}
			if ( 'wphave/group' === $node['name'] ) {
				if ( ! self::exact_keys( $node, array( 'key', 'parentKey', 'name', 'design' ) ) ||
					! is_array( $node['design'] ) ||
					! WPHAVE_AI_MCP_Free_Design_Grammar::valid_group_operations( $node['design'] ) ) {
					return false;
				}
				foreach ( $node['design'] as $operation ) {
					if ( ! in_array( $operation['path'], self::GROUP_PATHS, true ) ) {
						return false;
					}
				}
				continue;
			}
			if ( ! self::exact_keys( $node, array( 'key', 'parentKey', 'name', 'content', 'design' ) ) ||
				! is_string( $node['content'] ) || '' === trim( $node['content'] ) ||
				mb_strlen( $node['content'] ) > 240 ||
				sanitize_text_field( $node['content'] ) !== $node['content'] ||
				! is_array( $node['design'] ) ||
				( $node['design'] && ! WPHAVE_AI_MCP_Free_Design_Grammar::valid_text_operations( 'wphave/paragraph', $node['design'] ) ) ) {
				return false;
			}
		}
		return 1 === $navigation_count &&
			WPHAVE_AI_MCP_Free_Site_Design_Contract::matches_shell_colors( $contract, $part['nodes'] );
	}

	public static function valid( $composition, array $page_keys, array $contract ): bool {
		$encoded = wp_json_encode( $composition );
		if ( ! is_array( $composition ) ||
			! self::exact_keys( $composition, array( 'version', 'header', 'footer' ) ) ||
			1 !== $composition['version'] || ! is_string( $encoded ) || strlen( $encoded ) > 16384 ||
			! WPHAVE_AI_MCP_Free_Site_Design_Contract::valid( $contract, $page_keys ) ) {
			return false;
		}
		return self::valid_part( $composition['header'], $page_keys, $contract, 'header' ) &&
			self::valid_part( $composition['footer'], $page_keys, $contract, 'footer' );
	}

	private static function navigation_block( array $node, array $page_ids, string $part ): ?array {
		$links = array();
		foreach ( $node['links'] as $entry ) {
			$target = $entry['target'];
			if ( 'projectPage' === $target['kind'] ) {
				$post_id = $page_ids[ $target['pageKey'] ] ?? null;
				if ( ! is_int( $post_id ) || $post_id < 1 ) {
					return null;
				}
				$links[] = array( 'label' => $entry['label'], 'postId' => $post_id );
			} else {
				$links[] = array( 'label' => $entry['label'], 'url' => $target['url'] );
			}
		}
		$settings = array(
			'collapseBehavior' => $node['settings']['collapseBehavior'],
			'collapseBreakpoint' => $node['settings']['collapseBreakpoint'],
			'panelType' => $node['settings']['panelType'],
			'toggleStyle' => $node['settings']['toggleStyle'],
			'accessibleLabel' => 'header' === $part ? 'Primary navigation' : 'Footer navigation',
			'orientation' => $node['settings']['orientation'],
		);
		return WPHAVE_AI_MCP_Free_Site_Shell_Proposal::native_navigation_block( $part, $links, $settings );
	}

	private static function replace_navigation( array &$blocks, string $marker, array $navigation, int &$replacements ): void {
		foreach ( $blocks as &$block ) {
			if ( 'wphave/paragraph' === ( $block['blockName'] ?? null ) &&
				$marker === ( $block['attrs']['content'] ?? null ) ) {
				$block = $navigation;
				++$replacements;
				continue;
			}
			self::replace_navigation( $block['innerBlocks'], $marker, $navigation, $replacements );
		}
		unset( $block );
	}

	/** Let the existing native design host prepare Group/Text, then insert native Navigation. */
	public static function render_part( array $part, string $part_name, array $page_ids, string $design_fingerprint ) {
		if ( ! in_array( $part_name, array( 'header', 'footer' ), true ) ) {
			return new WP_Error( 'wphave_mcp_shell_invalid', 'The shell part is invalid.' );
		}
		$marker = 'wphave-private-navigation-' . wp_generate_uuid4();
		$host_nodes = array();
		$navigation = null;
		foreach ( $part['nodes'] as $node ) {
			if ( 'wphave/navigation' === $node['name'] ) {
				$navigation = self::navigation_block( $node, $page_ids, $part_name );
				$host_nodes[] = array(
					'key' => $node['key'],
					'parentKey' => $node['parentKey'],
					'name' => 'wphave/paragraph',
					'attributes' => array( 'content' => $marker ),
				);
				continue;
			}
			$host_node = array(
				'key' => $node['key'],
				'parentKey' => $node['parentKey'],
				'name' => $node['name'],
				'attributes' => 'wphave/group' === $node['name'] ?
					new stdClass() : array( 'content' => $node['content'] ),
			);
			if ( $node['design'] ) {
				$host_node['design'] = $node['design'];
			}
			$host_nodes[] = $host_node;
		}
		if ( null === $navigation ) {
			return new WP_Error( 'wphave_mcp_shell_invalid', 'The native navigation is unavailable.' );
		}
		$batch = array( 'version' => 2, 'designFingerprint' => $design_fingerprint, 'nodes' => $host_nodes );
		$context = WPHAVE_AI_MCP_Free_Host_Context::build( $batch );
		if ( is_wp_error( $context ) ) {
			return $context;
		}
		$markup = WPHAVE_AI_MCP_Free_Host_Runner::render( $host_nodes, $context );
		if ( is_wp_error( $markup ) ) {
			return $markup;
		}
		$blocks = parse_blocks( $markup );
		$replacements = 0;
		self::replace_navigation( $blocks, $marker, $navigation, $replacements );
		if ( 1 !== $replacements || 1 !== count( $blocks ) ||
			'wphave/group' !== ( $blocks[0]['blockName'] ?? null ) ) {
			return new WP_Error( 'wphave_mcp_shell_rejected', 'The native shell structure changed.' );
		}
		$result = serialize_blocks( $blocks );
		if ( ! is_string( $result ) || '' === $result || strlen( $result ) > 50000 ||
			str_contains( $result, $marker ) || serialize_blocks( parse_blocks( $result ) ) !== $result ) {
			return new WP_Error( 'wphave_mcp_shell_rejected', 'The native shell serialization failed.' );
		}
		return $result;
	}
}
