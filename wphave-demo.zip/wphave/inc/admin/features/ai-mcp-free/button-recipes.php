<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Curated native Button presentations for the MCP section catalog. */
final class WPHAVE_AI_MCP_Free_Button_Recipes {
	public static function specification(): ?array {
		$path = __DIR__ . '/button-recipes.json';
		$spec = is_readable( $path ) ? json_decode( (string) file_get_contents( $path ), true ) : null;
		return is_array( $spec ) && 1 === ( $spec['version'] ?? null ) ? $spec : null;
	}

	public static function icon_allowed(): bool {
		return function_exists( 'wphave_has_pro_access' ) && wphave_has_pro_access();
	}

	public static function options(): ?array {
		$spec = self::specification();
		if ( null === $spec ) {
			return null;
		}
		return array(
			'kinds' => self::icon_allowed() ? array( 'text', 'icon' ) : array( 'text' ),
			'sizes' => $spec['sizes'],
			'variants' => $spec['variants'],
			'icons' => self::icon_allowed() ? array_keys( $spec['icons'] ) : array(),
			'iconFixed' => array( 'aspectRatio' => '1/1', 'padding' => 'var(--wphave-site-padding-xs)', 'visibleLabel' => false ),
		);
	}

	public static function valid( $recipe ): bool {
		$spec = self::specification();
		if ( null === $spec || ! is_array( $recipe ) ||
			! in_array( $recipe['kind'] ?? null, array( 'text', 'icon' ), true ) ) {
			return false;
		}
		$icon = 'icon' === $recipe['kind'];
		$keys = array_keys( $recipe );
		$expected = $icon ? array( 'kind', 'size', 'variant', 'icon' ) : array( 'kind', 'size', 'variant' );
		sort( $keys );
		sort( $expected );
		return $keys === $expected &&
			is_string( $recipe['size'] ) && isset( $spec['sizes'][ $recipe['size'] ] ) &&
			in_array( $recipe['variant'], $spec['variants'], true ) &&
			( ! $icon || ( self::icon_allowed() &&
				is_string( $recipe['icon'] ) && isset( $spec['icons'][ $recipe['icon'] ] ) ) );
	}

	public static function expected_attributes( array $recipe ): ?array {
		if ( ! self::valid( $recipe ) ) {
			return null;
		}
		$spec = self::specification();
		$icon = 'icon' === $recipe['kind'];
		return array(
			'wphave' => array(
				'settings' => array(
					'variant' => $recipe['variant'],
					'size' => $spec['sizes'][ $recipe['size'] ],
					...( $icon ? array( 'hideLabel' => true ) : array() ),
				),
				...( $icon ? array( 'dimensions' => array(
					'aspectRatio' => array( 'ratio' => '1/1' ),
					'spacing' => array( 'padding' => 'var(--wphave-site-padding-xs)' ),
				) ) : array() ),
			),
			...( $icon ? array( 'icon' => $spec['icons'][ $recipe['icon'] ] ) : array() ),
		);
	}
}
