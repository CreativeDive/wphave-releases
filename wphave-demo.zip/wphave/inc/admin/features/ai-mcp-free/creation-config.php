<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Server-owned policy for MCP page creation. Invalid configuration fails closed. */
final class WPHAVE_AI_MCP_Free_Creation_Config {
	public static function get(): ?array {
		$path = __DIR__ . '/creation-config.json';
		if ( ! is_readable( $path ) ) {
			return null;
		}
		return self::parse( (string) file_get_contents( $path ) );
	}

	public static function parse( string $json ): ?array {
		$config = json_decode( $json, true );
		if ( ! is_array( $config ) ||
			! self::has_exact_keys( $config, array( 'version', 'checks', 'limits', 'guidance', 'catalog', 'capabilities', 'workflow' ) ) ||
			2 !== $config['version'] ||
			! is_array( $config['checks'] ) ||
			! self::has_exact_keys( $config['checks'], array( 'textContrast', 'compositionVariety', 'distinctSectionPrinciples', 'distinctPageRhythm' ) ) ||
			! is_array( $config['limits'] ) ||
			! self::has_exact_keys( $config['limits'], array( 'minimumSectionsPerPage' ) ) ||
			! is_int( $config['limits']['minimumSectionsPerPage'] ) ||
			$config['limits']['minimumSectionsPerPage'] < 1 ||
			$config['limits']['minimumSectionsPerPage'] > 8 ||
			! is_array( $config['guidance'] ) ||
			! self::has_exact_keys( $config['guidance'], array( 'compositionAtlas', 'mediaImport', 'visualReview', 'designHints', 'selfPlanning', 'mediaGeneration' ) ) ||
			! is_array( $config['catalog'] ) ||
			! self::has_exact_keys( $config['catalog'], array( 'mode' ) ) ||
			! in_array( $config['catalog']['mode'], array( 'off', 'optional', 'required' ), true ) ||
			! is_array( $config['capabilities'] ) ||
			! self::has_exact_keys( $config['capabilities'], array( 'customCss' ) ) ||
			! is_array( $config['workflow'] ) ||
			! self::has_exact_keys( $config['workflow'], array( 'required' ) ) ) {
			return null;
		}
		foreach ( array( 'checks', 'guidance', 'capabilities', 'workflow' ) as $group ) {
			foreach ( $config[ $group ] as $enabled ) {
				if ( ! is_bool( $enabled ) ) {
					return null;
				}
			}
		}
		return $config;
	}

	private static function has_exact_keys( array $value, array $expected ): bool {
		$keys = array_keys( $value );
		sort( $keys );
		sort( $expected );
		return $keys === $expected;
	}
}
