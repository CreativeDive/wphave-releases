<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Explicit, recoverable activation of two private native template-part proposals. */
final class WPHAVE_AI_MCP_Free_Site_Shell_Activation {
	private const IMPACT_ACK = 'global-wphave-header-footer-impact';

	private static function table(): string {
		global $wpdb;
		return $wpdb->prefix . 'wphave_mcp_shell_activations';
	}

	private static function can_activate(): bool {
		return current_user_can( 'manage_options' ) &&
			current_user_can( 'wphave_manage_template_parts' ) &&
			! wphave_use_fse() &&
			wphave_mcp_free_design_feature_enabled();
	}

	private static function ensure_schema(): bool {
		global $wpdb;
		$table = self::table();
		$row = $wpdb->get_row( $wpdb->prepare( 'SHOW TABLE STATUS WHERE Name = %s', $table ), ARRAY_A );
		if ( ! is_array( $row ) ) {
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			$collate = $wpdb->get_charset_collate();
			dbDelta( "CREATE TABLE {$table} (
				activation_id char(36) NOT NULL,
				site_id bigint(20) unsigned NOT NULL,
				actor_id bigint(20) unsigned NOT NULL,
				request_id varchar(80) NOT NULL,
				payload_hash char(64) NOT NULL,
				plan_hash char(64) NOT NULL,
				project_id char(36) NOT NULL,
				header_job_id char(36) NOT NULL,
				footer_job_id char(36) NOT NULL,
				assignment_before longtext NOT NULL,
				assignment_revision char(64) NOT NULL,
				header_part_id bigint(20) unsigned NOT NULL,
				footer_part_id bigint(20) unsigned NOT NULL,
				status varchar(16) NOT NULL,
				created_at datetime NOT NULL,
				updated_at datetime NOT NULL,
				PRIMARY KEY  (activation_id),
				UNIQUE KEY request_identity (site_id,actor_id,request_id)
			) ENGINE=InnoDB {$collate};" );
			$row = $wpdb->get_row( $wpdb->prepare( 'SHOW TABLE STATUS WHERE Name = %s', $table ), ARRAY_A );
		}
		$index = $wpdb->get_row( $wpdb->prepare(
			'SHOW INDEX FROM ' . $table . ' WHERE Key_name = %s AND Non_unique = 0',
			'request_identity'
		), ARRAY_A );
		return is_array( $row ) &&
			0 === strcasecmp( (string) ( $row['Engine'] ?? '' ), 'InnoDB' ) &&
			is_array( $index );
	}

	/** Revalidate every input before a global write; the proposal status is actor-bound. */
	public static function plan( string $project_id, string $header_job_id, string $footer_job_id ) {
		if ( ! self::can_activate() || ! wp_is_uuid( $project_id ) ||
			! wp_is_uuid( $header_job_id ) || ! wp_is_uuid( $footer_job_id ) ) {
			return new WP_Error( 'wphave_mcp_shell_activation_forbidden', 'The activation plan is unavailable.' );
		}
		$project = WPHAVE_AI_MCP_Free_Site_Project_Store::status( $project_id );
		$header = WPHAVE_AI_MCP_Free_Site_Shell_Proposal::status( $header_job_id, 'header' );
		$footer = WPHAVE_AI_MCP_Free_Site_Shell_Proposal::status( $footer_job_id, 'footer' );
		$assignments = WPHAVE_Data_Resources::get( 'template_parts', false );
		if ( is_wp_error( $project ) || is_wp_error( $header ) || is_wp_error( $footer ) ||
			$header['projectId'] !== $project_id || $footer['projectId'] !== $project_id ||
			$header['projectRevision'] !== $project['revision'] ||
			$footer['projectRevision'] !== $project['revision'] ||
			! hash_equals( $header['designFingerprint'], $footer['designFingerprint'] ) ||
			! is_array( $assignments ) || ! empty( $assignments['header'] ) ||
			! empty( $assignments['footer'] ) ) {
			return new WP_Error( 'wphave_mcp_shell_activation_stale', 'The activation context changed.' );
		}
		$revision = WPHAVE_Data_Resources::get_revision( 'template_parts' );
		$contract = array(
			'siteId' => get_current_blog_id(),
			'actorId' => get_current_user_id(),
			'projectId' => $project_id,
			'projectRevision' => $project['revision'],
			'designFingerprint' => $header['designFingerprint'],
			'headerJobId' => $header_job_id,
			'headerResultHash' => $header['resultHash'],
			'footerJobId' => $footer_job_id,
			'footerResultHash' => $footer['resultHash'],
			'assignmentRevision' => $revision,
			'assignmentBefore' => $assignments,
		);
		return array_merge( $contract, array(
			'planHash' => hash( 'sha256', wp_json_encode( $contract ) ),
			'impactWarning' => 'This can change the header and footer of every page using the global WPHAVE template-part assignment.',
			'impactAcknowledgment' => self::IMPACT_ACK,
		) );
	}

	private static function row( string $request_id ): ?array {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare(
			'SELECT * FROM ' . self::table() . ' WHERE site_id=%d AND actor_id=%d AND request_id=%s',
			get_current_blog_id(),
			get_current_user_id(),
			$request_id
		), ARRAY_A );
		return is_array( $row ) ? $row : null;
	}

	private static function response( array $row, bool $replayed ): array {
		$assignment = WPHAVE_Data_Resources::get( 'template_parts', false );
		return array(
			'activationId' => $row['activation_id'],
			'projectId' => $row['project_id'],
			'status' => $row['status'],
			'headerPartId' => (int) $row['header_part_id'],
			'footerPartId' => (int) $row['footer_part_id'],
			'assignmentRevisionBefore' => $row['assignment_revision'],
			'active' => 'completed' === $row['status'] &&
				(int) ( $assignment['header'] ?? 0 ) === (int) $row['header_part_id'] &&
				(int) ( $assignment['footer'] ?? 0 ) === (int) $row['footer_part_id'],
			'replayed' => $replayed,
		);
	}

	private static function make_part( string $type, string $markup, string $project_id ) {
		$post_id = wp_insert_post( array(
			'post_type' => WPHAVE_Template_Parts::POST_TYPE,
			'post_status' => 'draft',
			'post_title' => 'FORMA ' . ucfirst( $type ) . ' · ' . $project_id,
			'post_content' => wp_slash( $markup ),
		), true );
		if ( is_wp_error( $post_id ) || ! $post_id ) {
			return new WP_Error( 'wphave_mcp_shell_activation_part_failed', 'The template part could not be created.' );
		}
		if ( ! update_post_meta( $post_id, WPHAVE_Template_Parts::META_PART_TYPE, $type ) ) {
			wp_trash_post( $post_id );
			return new WP_Error( 'wphave_mcp_shell_activation_part_failed', 'The template-part type could not be saved.' );
		}
		$published = wp_update_post( array( 'ID' => $post_id, 'post_status' => 'publish' ), true );
		if ( is_wp_error( $published ) || $published !== $post_id ) {
			wp_trash_post( $post_id );
			return new WP_Error( 'wphave_mcp_shell_activation_part_failed', 'The template part could not be published.' );
		}
		return $post_id;
	}

	private static function fail_in_test( string $stage ): bool {
		return defined( 'WPHAVE_DISPOSABLE_TEST_SITE' ) && true === WPHAVE_DISPOSABLE_TEST_SITE &&
			true === apply_filters( 'wphave_mcp_shell_activation_fault', false, $stage );
	}

	private static function retire_parts( array $ids ): bool {
		$all_retired = true;
		foreach ( $ids as $post_id ) {
			if ( $post_id ) {
				$prior = get_post( $post_id );
				if ( $prior instanceof WP_Post && 'trash' === $prior->post_status ) {
					continue;
				}
				$trashed = wp_trash_post( $post_id );
				$stored = get_post( $post_id );
				$all_retired = $all_retired &&
					$trashed instanceof WP_Post &&
					$stored instanceof WP_Post &&
					'trash' === $stored->post_status;
			}
		}
		return $all_retired;
	}

	/** Resolve an interrupted activation without overwriting a third-party assignment. */
	public static function recover( string $request_id, bool $force_disposable = false ) {
		if ( $force_disposable &&
			( ! defined( 'WPHAVE_DISPOSABLE_TEST_SITE' ) || true !== WPHAVE_DISPOSABLE_TEST_SITE ) ) {
			return new WP_Error( 'wphave_mcp_shell_activation_forbidden', 'Immediate recovery requires a disposable testsite.' );
		}
		if ( class_exists( 'WPHAVE_Option_Mutations' ) ) {
			return WPHAVE_Option_Mutations::with_lock(
				WPHAVE_Data_Repository::mutation_lock_scope( 'wphave_data' ),
				static function () use ( $request_id, $force_disposable ) {
					WPHAVE_Data_Repository::clear_option_cache( 'wphave_data' );
					return self::recover_locked( $request_id, $force_disposable );
				}
			);
		}
		return new WP_Error( 'wphave_mcp_shell_activation_forbidden', 'The assignment lock is unavailable.' );
	}

	private static function recover_locked( string $request_id, bool $force_disposable ) {
		global $wpdb;
		if ( ! self::can_activate() || ! self::ensure_schema() ) {
			return new WP_Error( 'wphave_mcp_shell_activation_forbidden', 'Recovery is unavailable.' );
		}
		$row = self::row( $request_id );
		if ( ! $row || ! in_array( $row['status'], array( 'preparing', 'uncertain' ), true ) ) {
			return new WP_Error( 'wphave_mcp_shell_activation_invalid', 'No interrupted activation was found.' );
		}
		if ( ! $force_disposable && strtotime( $row['updated_at'] . ' UTC' ) > time() - 300 ) {
			return new WP_Error( 'wphave_mcp_shell_activation_in_progress', 'The activation may still be running.' );
		}
		$before = json_decode( $row['assignment_before'], true );
		$current = WPHAVE_Data_Resources::get( 'template_parts', false );
		$part_ids = array(
			'header' => (int) $row['header_part_id'],
			'footer' => (int) $row['footer_part_id'],
		);
		if ( ! is_array( $before ) || ! is_array( $current ) ) {
			return new WP_Error( 'wphave_mcp_shell_activation_uncertain', 'Recovery state is unreadable.' );
		}
		$next = array_merge( $before, $part_ids );
		if ( $current === $before ) {
			if ( ! self::retire_parts( $part_ids ) ) {
				return new WP_Error( 'wphave_mcp_shell_activation_uncertain', 'A staged part needs manual recovery.' );
			}
			$status = 'failed';
		} elseif ( $part_ids['header'] && $part_ids['footer'] && $current === $next ) {
			foreach ( array( 'header', 'footer' ) as $type ) {
				$post = get_post( $part_ids[ $type ] );
				if ( ! $post || 'publish' !== $post->post_status ||
					WPHAVE_Template_Parts::POST_TYPE !== $post->post_type ||
					get_post_meta( $post->ID, WPHAVE_Template_Parts::META_PART_TYPE, true ) !== $type ||
					! WPHAVE_AI_MCP_Free_Site_Shell_Proposal::activation_markup_matches(
						'header' === $type ? $row['header_job_id'] : $row['footer_job_id'],
						$type,
						$post->post_content
					) ) {
					return new WP_Error( 'wphave_mcp_shell_activation_uncertain', 'An assigned part needs manual recovery.' );
				}
			}
			$status = 'completed';
		} else {
			return new WP_Error( 'wphave_mcp_shell_activation_uncertain', 'The assignments changed outside this activation.' );
		}
		$updated = $wpdb->update( self::table(), array(
			'status' => $status,
			'updated_at' => gmdate( 'Y-m-d H:i:s' ),
		), array( 'activation_id' => $row['activation_id'], 'status' => $row['status'] ) );
		if ( 1 !== $updated ) {
			return new WP_Error( 'wphave_mcp_shell_activation_uncertain', 'Recovery ledger update failed.' );
		}
		WPHAVE_Template_Parts::clear_cache();
		return self::response( self::row( $request_id ), false );
	}

	/** One CAS assignment of both slots; staged parts remain unassigned on failure. */
	public static function commit( string $request_id, string $plan_hash, string $project_id, string $header_job_id, string $footer_job_id, string $impact_ack ) {
		global $wpdb;
		if ( ! self::can_activate() || ! preg_match( '/^[A-Za-z0-9_-]{16,80}$/', $request_id ) ||
			! preg_match( '/^[a-f0-9]{64}$/', $plan_hash ) || self::IMPACT_ACK !== $impact_ack ||
			! self::ensure_schema() ) {
			return new WP_Error( 'wphave_mcp_shell_activation_invalid', 'The activation request is invalid.' );
		}
		$payload_hash = hash( 'sha256', $plan_hash . "\n" . $project_id . "\n" . $header_job_id . "\n" . $footer_job_id );
		$existing = self::row( $request_id );
		if ( $existing ) {
			return hash_equals( $payload_hash, $existing['payload_hash'] ) ?
				self::response( $existing, true ) :
				new WP_Error( 'wphave_mcp_shell_activation_conflict', 'The request ID belongs to another activation.' );
		}
		$plan = self::plan( $project_id, $header_job_id, $footer_job_id );
		if ( is_wp_error( $plan ) || ! hash_equals( $plan_hash, $plan['planHash'] ) ) {
			return new WP_Error( 'wphave_mcp_shell_activation_stale', 'The activation plan is stale.' );
		}
		$activation_id = wp_generate_uuid4();
		$now = gmdate( 'Y-m-d H:i:s' );
		$inserted = $wpdb->insert( self::table(), array(
			'activation_id' => $activation_id,
			'site_id' => get_current_blog_id(),
			'actor_id' => get_current_user_id(),
			'request_id' => $request_id,
			'payload_hash' => $payload_hash,
			'plan_hash' => $plan_hash,
			'project_id' => $project_id,
			'header_job_id' => $header_job_id,
			'footer_job_id' => $footer_job_id,
			'assignment_before' => wp_json_encode( $plan['assignmentBefore'] ),
			'assignment_revision' => $plan['assignmentRevision'],
			'header_part_id' => 0,
			'footer_part_id' => 0,
			'status' => 'preparing',
			'created_at' => $now,
			'updated_at' => $now,
		) );
		if ( 1 !== $inserted ) {
			$race = self::row( $request_id );
			return $race && hash_equals( $payload_hash, $race['payload_hash'] ) ?
				self::response( $race, true ) :
				new WP_Error( 'wphave_mcp_shell_activation_uncertain', 'The activation state is uncertain.' );
		}
		$part_ids = array();
		$assignment_changed = false;
		$assignment_after_revision = '';
		$failure = null;
		foreach ( array( 'header', 'footer' ) as $type ) {
			$proposal = WPHAVE_AI_MCP_Free_Site_Shell_Proposal::status(
				'header' === $type ? $header_job_id : $footer_job_id,
				$type
			);
			if ( is_wp_error( $proposal ) ) {
				$failure = 'proposal_stale';
				break;
			}
			$part_id = self::make_part( $type, $proposal['markup'], $project_id );
			if ( is_wp_error( $part_id ) ) {
				$failure = 'part_failed';
				break;
			}
			$part_ids[ $type ] = $part_id;
			$wpdb->update( self::table(), array( $type . '_part_id' => $part_id ), array( 'activation_id' => $activation_id ) );
			if ( self::fail_in_test( 'abandon_after_' . $type . '_part' ) ) {
				return new WP_Error( 'wphave_mcp_shell_activation_uncertain', 'Simulated interrupted activation.' );
			}
			if ( self::fail_in_test( 'after_' . $type . '_part' ) ) {
				$failure = 'injected_failure';
				break;
			}
		}
		if ( null === $failure ) {
			foreach ( array( 'header', 'footer' ) as $type ) {
				$stored = get_post( $part_ids[ $type ] );
				$expected = WPHAVE_AI_MCP_Free_Site_Shell_Proposal::status(
					'header' === $type ? $header_job_id : $footer_job_id,
					$type
				);
				if ( ! $stored || is_wp_error( $expected ) ||
					'publish' !== $stored->post_status ||
					$stored->post_content !== $expected['markup'] ||
					get_post_meta( $stored->ID, WPHAVE_Template_Parts::META_PART_TYPE, true ) !== $type ) {
					$failure = 'part_changed';
					break;
				}
			}
		}
		if ( null === $failure ) {
			$rechecked = self::plan( $project_id, $header_job_id, $footer_job_id );
			if ( is_wp_error( $rechecked ) || ! hash_equals( $plan_hash, $rechecked['planHash'] ) ) {
				$failure = 'plan_changed';
			} elseif ( ! current_user_can( 'manage_options' ) || ! current_user_can( 'wphave_manage_template_parts' ) ) {
				$failure = 'permission_changed';
			} elseif ( self::fail_in_test( 'before_assignment' ) ) {
				$failure = 'injected_failure';
			} else {
				$next = array_merge( $plan['assignmentBefore'], $part_ids );
				$validation = WPHAVE_Template_Parts::validate_global_assignments( $next );
				$saved = is_wp_error( $validation ) ? $validation : WPHAVE_Data_Resources::save(
					'template_parts',
					$next,
					$plan['assignmentRevision']
				);
				if ( is_wp_error( $saved ) || empty( $saved['changed'] ) ) {
					$failure = 'assignment_failed';
				} else {
					$assignment_changed = true;
					$assignment_after_revision = hash( 'sha256', wp_json_encode( $next ) );
					if ( self::fail_in_test( 'abandon_after_assignment' ) ) {
						return new WP_Error( 'wphave_mcp_shell_activation_uncertain', 'Simulated interrupted activation.' );
					}
					if ( self::fail_in_test( 'after_assignment' ) ) {
						$failure = 'injected_failure';
					}
				}
			}
		}
		if ( null !== $failure ) {
			$recovered = true;
			if ( $assignment_changed ) {
				$rollback = WPHAVE_Data_Resources::save(
					'template_parts',
					$plan['assignmentBefore'],
					$assignment_after_revision
				);
				$recovered = ! is_wp_error( $rollback );
			}
			if ( $recovered ) {
				$recovered = self::retire_parts( $part_ids );
			}
			$wpdb->update( self::table(), array(
				'status' => $recovered ? 'failed' : 'uncertain',
				'updated_at' => gmdate( 'Y-m-d H:i:s' ),
			), array( 'activation_id' => $activation_id ) );
			return new WP_Error(
				$recovered ? 'wphave_mcp_shell_activation_failed' : 'wphave_mcp_shell_activation_uncertain',
				$recovered ? 'The activation failed and its global state was recovered.' : 'The activation requires manual recovery.'
			);
		}
		$updated = $wpdb->update( self::table(), array(
			'status' => 'completed',
			'updated_at' => gmdate( 'Y-m-d H:i:s' ),
		), array( 'activation_id' => $activation_id, 'status' => 'preparing' ) );
		if ( 1 !== $updated ) {
			return new WP_Error( 'wphave_mcp_shell_activation_uncertain', 'The assignment is active but its ledger state is uncertain.' );
		}
		WPHAVE_Template_Parts::clear_cache();
		return self::response( self::row( $request_id ), false );
	}
}
