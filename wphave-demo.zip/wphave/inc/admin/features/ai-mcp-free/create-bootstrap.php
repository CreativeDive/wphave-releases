<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/create-abilities.php';
require_once __DIR__ . '/section-plan.php';
require_once __DIR__ . '/section-catalog.php';
require_once __DIR__ . '/button-recipes.php';
require_once __DIR__ . '/line-recipes.php';
require_once __DIR__ . '/spacer-recipes.php';
require_once __DIR__ . '/heading-recipes.php';
require_once __DIR__ . '/creation-config.php';
require_once __DIR__ . '/custom-css.php';
require_once dirname( __DIR__ ) . '/ai/config.php';
require_once dirname( __DIR__ ) . '/ai/transport/schema.php';
require_once dirname( __DIR__ ) . '/ai/prompts.php';
require_once dirname( __DIR__ ) . '/ai/providers/openai.php';
require_once dirname( __DIR__ ) . '/ai/image-generation-service.php';
require_once dirname( __DIR__ ) . '/ai/media-import-service.php';
require_once dirname( __DIR__ ) . '/ai/task-catalog.php';
require_once __DIR__ . '/media-request-store.php';
require_once __DIR__ . '/media-request.php';
require_once __DIR__ . '/media-import.php';
require_once __DIR__ . '/host-context.php';
require_once __DIR__ . '/host-runner.php';
require_once __DIR__ . '/site-shell-proposal.php';
require_once __DIR__ . '/website-draft-project.php';
require_once __DIR__ . '/visual-preview.php';
require_once __DIR__ . '/visual-abilities.php';
require_once dirname( __DIR__ ) . '/ai-mcp/server-factory.php';

add_action( 'wp_abilities_api_categories_init', array( 'WPHAVE_AI_MCP_Free_Create_Abilities', 'register_category' ) );
add_action( 'wp_abilities_api_init', array( 'WPHAVE_AI_MCP_Free_Create_Abilities', 'register' ) );
add_action( 'wp_abilities_api_init', array( 'WPHAVE_AI_MCP_Free_Media_Import', 'register' ) );
add_action( 'wp_abilities_api_init', array( 'WPHAVE_AI_MCP_Free_Visual_Abilities', 'register' ) );
add_action( 'mcp_adapter_init', static function ( $adapter ): void {
	wphave_ai_mcp_register_server(
		$adapter,
		'wphave-free-create-server',
		'WPHAVE Native Draft Creation',
		WPHAVE_AI_MCP_Exposure_Contract::server_abilities( 'wphave-free-create-server' )
	);
} );
