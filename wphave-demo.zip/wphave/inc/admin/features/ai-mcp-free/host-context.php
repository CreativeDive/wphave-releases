<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Server-owned inputs for the independent native block host. */
final class WPHAVE_AI_MCP_Free_Host_Context {
	private const BLOCK_DIRECTORIES = array(
		'wphave/group' => 'group',
		'wphave/heading' => 'heading',
		'wphave/paragraph' => 'paragraph',
		'wphave/button' => 'button',
		'wphave/image' => 'image',
		'wphave/line' => 'line',
		'wphave/spacer' => 'spacer',
	);

	private static function registered_blocks_match_build(): bool {
		$root = dirname( __DIR__, 4 );
		$registry = WP_Block_Type_Registry::get_instance();
		foreach ( self::BLOCK_DIRECTORIES as $name => $directory ) {
			$path = $root . '/build/block-types/blocks/' . $directory . '/block.json';
			$definition = is_readable( $path ) ? json_decode( (string) file_get_contents( $path ), true ) : null;
			$registered = $registry->get_registered( $name );
			if ( ! is_array( $definition ) || ! $registered ||
				( $definition['name'] ?? null ) !== $name ||
				( $registered->supports['wphave'] ?? null ) !== ( $definition['supports']['wphave'] ?? null ) ) {
				return false;
			}
		}
		return true;
	}

	public static function build( array $batch ) {
		if ( ! wphave_mcp_free_create_feature_enabled() ||
			! current_user_can( 'wphave_access' ) ||
			! current_user_can( 'edit_pages' ) ||
			! function_exists( 'wphave_get_block_editor_mode_by_role' ) ||
			'design' !== wphave_get_block_editor_mode_by_role() ||
		! self::registered_blocks_match_build() ) {
			return new WP_Error( 'wphave_mcp_host_context_unavailable', 'The native design context is unavailable.' );
		}
		$catalog = WPHAVE_AI_MCP_Free_Design_Grammar::catalog();
		$media_ids = WPHAVE_AI_MCP_Free_Media::verified_ids( $batch );
		$runner = dirname( __DIR__, 4 ) . '/build/ai-mcp-design-host/runner.cjs';
		$runtime_hash = is_readable( $runner ) ? hash_file( 'sha256', $runner ) : false;
		$site_hash = WPHAVE_AI_MCP_Free_Job_Store::context_fingerprint();
		if ( is_wp_error( $catalog ) || is_wp_error( $media_ids ) ||
			! is_string( $runtime_hash ) || ! is_string( $site_hash ) ||
			( $batch['designFingerprint'] ?? null ) !== $catalog['fingerprint'] ) {
			return new WP_Error( 'wphave_mcp_host_context_unavailable', 'The native design context is unavailable.' );
		}
		$group_operations = array_column( $catalog['groupOperations'], null, 'path' );
		$color_values = array_values( array_unique( array_merge(
			$group_operations['background.color.base']['values'] ?? array(),
			$catalog['textColorOperation']['values'] ?? array()
		) ) );
		$paths = array_merge(
			array_column( $catalog['groupOperations'], 'path' ),
			array_column( $catalog['imageOperations'], 'path' ),
			array( 'text.typeface.size', 'colors.text', 'features.horizontalDirection' )
		);
		$context = array(
			'version' => 1,
			'canEdit' => true,
			'systemMode' => 'design',
			'userMode' => 'design',
			'blockDesignDisabled' => false,
			'designControls' => new stdClass(),
			'allowedPaths' => array_values( array_unique( $paths ) ),
			'allowedBlocks' => array_keys( self::BLOCK_DIRECTORIES ),
			'mediaIds' => $media_ids,
			'gapValues' => $group_operations['layout.grid.gapX']['values'] ?? array(),
			'paddingTokens' => $group_operations['dimensions.spacing.padding']['values'] ?? array(),
			'colorValues' => $color_values,
			'lineColorValues' => $catalog['lineCatalog']['colors'] ?? array(),
			'headingSizeKeys' => array_column( $catalog['textOperations']['wphave/heading']['values'] ?? array(), 'type' ),
			'textSizeKeys' => array_column( $catalog['textOperations']['wphave/paragraph']['values'] ?? array(), 'type' ),
			'proFeatures' => new stdClass(),
			'allowIconButtons' => WPHAVE_AI_MCP_Free_Button_Recipes::icon_allowed(),
		);
		$identity = array(
			'siteId' => get_current_blog_id(),
			'actorId' => get_current_user_id(),
			'siteHash' => $site_hash,
			'grammarHash' => $catalog['fingerprint'],
			'runtimeHash' => $runtime_hash,
			'batchHash' => hash( 'sha256', wp_json_encode( $batch ) ?: '' ),
		);
		$json = wp_json_encode( array( 'identity' => $identity, 'context' => $context ) );
		if ( ! is_string( $json ) ) {
			return new WP_Error( 'wphave_mcp_host_context_unavailable', 'The native design context is unavailable.' );
		}
		return array(
			'context' => $context,
			'fingerprint' => hash( 'sha256', $json ),
			'runner' => $runner,
		);
	}
}
