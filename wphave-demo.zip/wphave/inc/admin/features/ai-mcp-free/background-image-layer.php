<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Bounded native image-and-overlay layer; never accepts URLs or arbitrary CSS. */
final class WPHAVE_AI_MCP_Free_Background_Image_Layer {
	public static function allowed(): bool {
		return function_exists( 'wphave_has_pro_access' ) && wphave_has_pro_access();
	}

	public static function valid( $value, array $colors ): bool {
		if ( ! is_array( $value ) || count( $value ) !== 1 || ! is_array( $value[0] ?? null ) ) {
			return false;
		}
		$layer = $value[0];
		$media = $layer['media'] ?? null;
		$image = is_array( $media ) ? ( $media['image'] ?? null ) : null;
		$data = is_array( $image ) ? ( $image['data'] ?? null ) : null;
		$focal = is_array( $data ) ? ( $data['focal'] ?? null ) : null;
		$overlay = $layer['overlay'] ?? null;
		return self::keys( $layer, array( 'media', 'overlay' ) ) &&
			self::keys( $media, array( 'image' ) ) &&
			self::keys( $image, array( 'type', 'data', 'fit' ) ) &&
			'custom' === $image['type'] && 'cover' === $image['fit'] &&
			self::keys( $data, array( 'id', 'focal' ) ) &&
			is_int( $data['id'] ) && $data['id'] > 0 &&
			self::keys( $focal, array( 'top', 'left' ) ) &&
			50 === $focal['top'] && 50 === $focal['left'] &&
			self::keys( $overlay, array( 'mode', 'type', 'axis', 'color', 'opacity' ) ) &&
			'controlled' === $overlay['mode'] && 'cover' === $overlay['type'] &&
			'0%' === $overlay['axis'] &&
			'var(--wphave-site-color-overlay)' === $overlay['color'] &&
			in_array( $overlay['color'], $colors, true ) &&
			is_string( $overlay['opacity'] ) &&
			1 === preg_match( '/^0\.(?:[3-6]\d|70)$/', $overlay['opacity'] );
	}

	public static function image_id( $value ): ?int {
		$id = $value[0]['media']['image']['data']['id'] ?? null;
		return is_int( $id ) && $id > 0 ? $id : null;
	}

	private static function keys( $value, array $expected ): bool {
		if ( ! is_array( $value ) || count( $value ) !== count( $expected ) ) {
			return false;
		}
		$keys = array_keys( $value );
		sort( $keys );
		sort( $expected );
		return $keys === $expected;
	}
}
