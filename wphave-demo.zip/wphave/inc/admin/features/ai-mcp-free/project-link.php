<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Resolve only project-owned page identities into native Button link data. */
final class WPHAVE_AI_MCP_Free_Project_Link {
	public static function resolve( array $batch, int $source_post_id ) {
		$linked_nodes = array_values( array_filter( $batch['nodes'] ?? array(), static function ( $node ): bool {
			return is_array( $node ) && array_key_exists( 'linkTarget', $node );
		} ) );
		if ( array() === $linked_nodes ) {
			return ! array_key_exists( 'projectId', $batch ) ? array() :
				new WP_Error( 'wphave_mcp_free_link_invalid', 'The project link is invalid.' );
		}
		if ( 2 !== ( $batch['version'] ?? null ) || ! is_string( $batch['projectId'] ?? null ) ||
			! wp_is_uuid( $batch['projectId'] ) || count( $linked_nodes ) > 8 ) {
			return new WP_Error( 'wphave_mcp_free_link_invalid', 'The project link is invalid.' );
		}
		$project = WPHAVE_AI_MCP_Free_Site_Project_Store::status( $batch['projectId'] );
		if ( is_wp_error( $project ) ||
			! hash_equals( $project['designReference']['fingerprint'], $batch['designFingerprint'] ?? '' ) ) {
			return new WP_Error( 'wphave_mcp_free_link_invalid', 'The project link is unavailable.' );
		}
		$pages = array();
		$source_found = false;
		foreach ( $project['pages'] as $page ) {
			$pages[ $page['pageKey'] ] = $page['targetPostId'];
			$source_found = $source_found || $page['targetPostId'] === $source_post_id;
		}
		if ( ! $source_found ) {
			return new WP_Error( 'wphave_mcp_free_link_invalid', 'The source is outside the project.' );
		}
		$resolved = array();
		foreach ( $linked_nodes as $node ) {
			$target = $node['linkTarget'];
			if ( $node['name'] !== 'wphave/button' || ! is_array( $target ) ||
				array_keys( $target ) !== array( 'kind', 'pageKey' ) ||
				$target['kind'] !== 'projectPage' || ! is_string( $target['pageKey'] ) ||
				! isset( $pages[ $target['pageKey'] ] ) ) {
				return new WP_Error( 'wphave_mcp_free_link_invalid', 'The project link is invalid.' );
			}
			$link = self::link_data( $pages[ $target['pageKey'] ], $source_post_id );
			if ( is_wp_error( $link ) ) {
				return $link;
			}
			$resolved[ $node['key'] ] = $link;
		}
		return $resolved;
	}

	/** Resolve semantic Button targets against already verified website page bindings. */
	public static function resolve_website( array $nodes, int $source_post_id, array $pages ) {
		$resolved = array();
		foreach ( $nodes as $node ) {
			if ( ! isset( $node['linkTarget'] ) ) {
				continue;
			}
			$target = $node['linkTarget'];
			if ( 'wphave/button' !== ( $node['name'] ?? null ) ||
				! is_array( $target ) || array_keys( $target ) !== array( 'kind', 'pageKey' ) ||
				'projectPage' !== $target['kind'] || ! isset( $pages[ $target['pageKey'] ] ) ) {
				return new WP_Error( 'wphave_mcp_free_link_invalid', 'The website link is invalid.' );
			}
			$link = self::link_data( (int) $pages[ $target['pageKey'] ], $source_post_id );
			if ( is_wp_error( $link ) ) {
				return $link;
			}
			$resolved[ $node['key'] ] = $link;
		}
		return $resolved;
	}

	private static function link_data( int $post_id, int $source_post_id ) {
		$post = get_post( $post_id );
		$url = get_permalink( $post_id );
		if ( $post_id === $source_post_id || ! $post instanceof WP_Post ||
			'page' !== $post->post_type || ! in_array( $post->post_status, array( 'draft', 'publish' ), true ) ||
			! current_user_can( 'read_post', $post_id ) || ! is_string( $url ) || '' === $url ) {
			return new WP_Error( 'wphave_mcp_free_link_invalid', 'The project target is unavailable.' );
		}
		return array(
			'type' => 'internal',
			'internal' => array(
				'id' => $post_id,
				'url' => $url,
				'type' => 'page',
				'title' => wp_strip_all_tags( get_the_title( $post_id ) ),
			),
			'open' => 'self',
		);
	}
}
