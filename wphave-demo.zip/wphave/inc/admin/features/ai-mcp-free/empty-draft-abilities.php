<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once dirname( __DIR__ ) . '/ai-mcp-write/create-service.php';

/** Creates an empty private page target for the free design workflow. */
final class WPHAVE_AI_MCP_Free_Empty_Draft_Abilities {
	public static function register(): void {
		if ( ! wphave_mcp_free_design_feature_enabled() || ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		wp_register_ability( 'wphave/free-page-create-empty-draft', array(
			'category' => 'wphave-free-design',
			'label' => __( 'Create empty private page draft', 'wphave' ),
			'description' => __( 'Create one empty unpublished page for a subsequent WPHAVE design job. Supply a stable request ID; the result includes its page ID.', 'wphave' ),
			'input_schema' => array(
				'type' => 'object',
				'properties' => array(
					'requestId' => array( 'type' => 'string' ),
					'title' => array( 'type' => 'string' ),
				),
				'required' => array( 'requestId', 'title' ),
				'additionalProperties' => false,
			),
			'permission_callback' => array( __CLASS__, 'can_create' ),
			'execute_callback' => array( __CLASS__, 'create' ),
			'meta' => array(
				'public' => false,
				'show_in_rest' => false,
				'mcp' => array( 'public' => true ),
				'annotations' => array( 'readonly' => false, 'destructive' => false, 'idempotent' => true ),
			),
		) );
	}

	public static function can_create(): bool {
		return wphave_mcp_free_design_feature_enabled() &&
			current_user_can( 'wphave_access' ) &&
			current_user_can( 'edit_pages' ) &&
			function_exists( 'wphave_get_block_editor_mode_by_role' ) &&
			'design' === wphave_get_block_editor_mode_by_role();
	}

	public static function create( $input ) {
		if ( ! self::can_create() || ! is_array( $input ) ||
			array_diff( array_keys( $input ), array( 'requestId', 'title' ) ) ||
			! is_string( $input['requestId'] ?? null ) ||
			! is_string( $input['title'] ?? null ) ) {
			return new WP_Error( 'wphave_mcp_empty_draft_invalid', 'The empty draft request is invalid.' );
		}

		$title = trim( sanitize_text_field( $input['title'] ) );
		if ( '' === $title || mb_strlen( $title ) > 120 ) {
			return new WP_Error( 'wphave_mcp_empty_draft_title', 'A title of 1 to 120 characters is required.' );
		}

		$transaction_input = array(
			'requestId' => $input['requestId'],
			'title' => $title,
			'purpose' => 'wphave-free-design-empty-draft',
		);
		$result = WPHAVE_AI_MCP_Create_Service::create_validated_draft(
			$transaction_input,
			array( 'title' => $title, 'content' => '' ),
			array( __CLASS__, 'revalidate' )
		);
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$result['targetPostId'] = $result['postId'];
		$result['editorUrl'] = get_edit_post_link( $result['postId'], 'raw' );
		return $result;
	}

	public static function revalidate() {
		return self::can_create() ? true :
			new WP_Error( 'wphave_mcp_empty_draft_forbidden', 'Draft creation is no longer permitted.' );
	}
}
