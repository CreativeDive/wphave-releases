<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Signed, user-bound planning receipts for the direct MCP creation path. */
final class WPHAVE_AI_MCP_Free_Creation_Workflow {
	private const MAX_AGE = 86400;

	public static function content( $pages ) {
		if ( ! self::valid_pages( $pages, false ) ) {
			return self::invalid();
		}
		return array( 'contentToken' => self::sign( array(
			'stage' => 'content',
			'pages' => $pages,
			'qualityVersion' => self::quality_version( $pages ),
		) ) );
	}

	public static function options( $token ) {
		$content = self::read( $token, 'content' );
		if ( null === $content ) {
			return self::invalid();
		}
		$catalog = WPHAVE_AI_MCP_Free_Design_Grammar::discovery();
		if ( is_wp_error( $catalog ) ) {
			return $catalog;
		}
		$catalog['creationWorkflow'] = array(
			'order' => array( 'plan content', 'read design options', 'plan section layouts', 'create drafts' ),
			'nextAbility' => 'wphave/free-page-plan-layout',
			'contentPlan' => $content['pages'],
			'qualityContract' => array(
				'version' => $content['qualityVersion'] ?? 0,
				'rule' => 'Copy requiredActions unchanged into the layout plan. Each actionId must identify one native Button node in its page batch.',
			),
		);
		$catalog['designToken'] = self::sign( array(
			'stage' => 'design',
			'pages' => $content['pages'],
			'fingerprint' => $catalog['fingerprint'],
			'qualityVersion' => $content['qualityVersion'] ?? 0,
		) );
		return $catalog;
	}

	public static function layout( $token, $pages, $site_design_contract = null, $shell_composition = null ) {
		$design = self::read( $token, 'design' );
		$page_keys = is_array( $pages ) ? array_column( $pages, 'pageKey' ) : array();
		if ( null === $design || ! self::valid_pages( $pages, true ) ||
			! self::same_content( $design['pages'], $pages ) ||
			! self::current_fingerprint( $design['fingerprint'] ) ||
			( null !== $site_design_contract &&
				! WPHAVE_AI_MCP_Free_Site_Design_Contract::valid( $site_design_contract, $page_keys ) ) ||
			( null !== $shell_composition &&
				( null === $site_design_contract ||
					! WPHAVE_AI_MCP_Free_Shell_Composition::valid( $shell_composition, $page_keys, $site_design_contract ) ) ) ) {
			return self::invalid();
		}
		$payload = array(
			'stage' => 'layout',
			'pages' => $pages,
			'fingerprint' => $design['fingerprint'],
			'qualityVersion' => $design['qualityVersion'] ?? 0,
		);
		if ( null !== $site_design_contract ) {
			$payload['siteDesignContract'] = $site_design_contract;
		}
		if ( null !== $shell_composition ) {
			$payload['shellComposition'] = $shell_composition;
		}
		return array( 'layoutToken' => self::sign( $payload ) );
	}

	public static function matches_site_design_contract( $token, $contract, array $page_keys ): bool {
		$layout = self::read( $token, 'layout' );
		return is_array( $layout ) && is_array( $contract ) &&
			is_array( $layout['siteDesignContract'] ?? null ) &&
			WPHAVE_AI_MCP_Free_Site_Design_Contract::same( $layout['siteDesignContract'], $contract ) &&
			self::current_fingerprint( $layout['fingerprint'] ?? null ) &&
			WPHAVE_AI_MCP_Free_Site_Design_Contract::valid( $contract, $page_keys );
	}

	public static function matches_shell_composition( $token, $composition, $contract, array $page_keys ): bool {
		$layout = self::read( $token, 'layout' );
		return is_array( $layout ) && is_array( $composition ) &&
			is_array( $layout['shellComposition'] ?? null ) &&
			self::matches_site_design_contract( $token, $contract, $page_keys ) &&
			WPHAVE_AI_MCP_Free_Site_Design_Contract::same( $layout['shellComposition'], $composition ) &&
			WPHAVE_AI_MCP_Free_Shell_Composition::valid( $composition, $page_keys, $contract );
	}

	public static function website_page_token( $token, array $pages, int $index, array $batch, string $request_id ) {
		if ( ! self::matches_drafts( $token, $pages ) || ! isset( $pages[ $index ] ) ||
			! is_string( $pages[ $index ]['title'] ?? null ) ) {
			return self::invalid();
		}
		$layout = self::read( $token, 'layout' );
		$planned = $layout['pages'][ $index ];
		$planned['pageKey'] = 'page';
		if ( isset( $planned['requiredActions'] ) ) {
			foreach ( $planned['requiredActions'] as &$action ) {
				unset( $action['linkTarget'] );
			}
			unset( $action );
		}
		return self::sign( array(
			'stage' => 'layout',
			'pages' => array( $planned ),
			'fingerprint' => $layout['fingerprint'],
			'qualityVersion' => $layout['qualityVersion'] ?? 0,
			'websitePlanHash' => hash( 'sha256', $token ),
			'websitePageKey' => $pages[ $index ]['pageKey'],
			'titleHash' => hash( 'sha256', $pages[ $index ]['title'] ),
			'batchHash' => hash( 'sha256', wp_json_encode( $batch ) ),
			'requestIdHash' => hash( 'sha256', $request_id ),
		) );
	}

	/** Bind a read-only multi-page activation plan to one observed project state. */
	public static function site_plan_token( array $snapshot, string $impact_ack ): string {
		return self::sign( array(
			'stage' => 'site-plan',
			'snapshotHash' => hash( 'sha256', wp_json_encode( $snapshot ) ),
			'impactAck' => $impact_ack,
		) );
	}

	public static function matches_site_plan_token( $token, array $snapshot, string $impact_ack ): bool {
		$payload = self::read( $token, 'site-plan' );
		return is_array( $payload ) &&
			( $payload['impactAck'] ?? null ) === $impact_ack &&
			hash_equals(
				$payload['snapshotHash'] ?? '',
				hash( 'sha256', wp_json_encode( $snapshot ) )
			);
	}

	public static function site_ledger_token( array $ledger ): string {
		return self::sign( array(
			'stage' => 'site-ledger',
			'ledgerHash' => hash( 'sha256', wp_json_encode( $ledger ) ),
		) );
	}

	public static function matches_site_ledger_token( $token, array $ledger ): bool {
		$payload = self::read( $token, 'site-ledger' );
		return is_array( $payload ) && hash_equals(
			$payload['ledgerHash'] ?? '',
			hash( 'sha256', wp_json_encode( $ledger ) )
		);
	}

	public static function matches_drafts( $token, array $pages, ?string $title = null, ?string $request_id = null ): bool {
		$layout = self::read( $token, 'layout' );
		if ( null === $layout || ! self::current_fingerprint( $layout['fingerprint'] ) ||
			count( $pages ) !== count( $layout['pages'] ) ) {
			return false;
		}
		if ( isset( $layout['websitePlanHash'] ) ) {
			if ( 1 !== count( $pages ) || 'page' !== ( $pages[0]['pageKey'] ?? null ) ||
				! is_string( $title ) || ! is_string( $request_id ) ||
				! hash_equals( $layout['titleHash'] ?? '', hash( 'sha256', $title ) ) ||
				! hash_equals( $layout['requestIdHash'] ?? '', hash( 'sha256', $request_id ) ) ||
				! hash_equals( $layout['batchHash'] ?? '', hash( 'sha256', wp_json_encode( $pages[0]['batch'] ?? null ) ) ) ) {
				return false;
			}
		}
		foreach ( $pages as $index => $page ) {
			$planned = $layout['pages'][ $index ];
			$sections = array_map( static function ( $section ): array {
				return array(
					'key' => $section['key'],
					'layout' => $section['layout'],
					'purpose' => $section['purpose'],
				);
			}, $planned['sections'] );
			$actual_sections = $page['batch']['sections'] ?? null;
			if ( ! is_array( $actual_sections ) ) {
				return false;
			}
			$actual_sections = array_map( static function ( $section ): array {
				return array(
					'key' => $section['key'] ?? null,
					'layout' => $section['layout'] ?? null,
					'purpose' => $section['purpose'] ?? null,
				);
			}, $actual_sections );
			if ( ( $page['pageKey'] ?? null ) !== $planned['pageKey'] ||
				( $page['batch']['designFingerprint'] ?? null ) !== $layout['fingerprint'] ||
				$actual_sections !== $sections ||
				( 1 === ( $layout['qualityVersion'] ?? 0 ) &&
					! self::matches_required_actions( $planned, $page['batch'] ) ) ) {
				return false;
			}
		}
		return true;
	}

	public static function requires_quality_checks( $token ): bool {
		$layout = self::read( $token, 'layout' );
		return is_array( $layout ) && 1 === ( $layout['qualityVersion'] ?? 0 );
	}

	private static function valid_pages( $pages, bool $with_layout ): bool {
		if ( ! is_array( $pages ) || count( $pages ) < 1 || count( $pages ) > 12 ||
			array_keys( $pages ) !== range( 0, count( $pages ) - 1 ) ) {
			return false;
		}
		$keys = array();
		foreach ( $pages as $page ) {
			if ( ! is_array( $page ) || ! self::exact_keys(
				$page,
				isset( $page['requiredActions'] ) ? array( 'pageKey', 'goal', 'sections', 'requiredActions' ) : array( 'pageKey', 'goal', 'sections' )
			) ||
				! self::short_text( $page['pageKey'], 32 ) ||
				! preg_match( '/^[a-z][a-z0-9_-]*$/', $page['pageKey'] ) ||
				isset( $keys[ $page['pageKey'] ] ) || ! self::short_text( $page['goal'], 240 ) ||
				! is_array( $page['sections'] ) || count( $page['sections'] ) < 1 ||
				count( $page['sections'] ) > 12 ||
				array_keys( $page['sections'] ) !== range( 0, count( $page['sections'] ) - 1 ) ) {
				return false;
			}
			$keys[ $page['pageKey'] ] = true;
			if ( isset( $page['requiredActions'] ) && ! self::valid_actions( $page['requiredActions'] ) ) {
				return false;
			}
			$section_keys = array();
			foreach ( $page['sections'] as $section ) {
				$expected = $with_layout ?
					array( 'key', 'purpose', 'layout', 'structure', 'responsiveIntent' ) :
					array( 'key', 'purpose' );
				if ( ! is_array( $section ) || ! self::exact_keys( $section, $expected ) ||
					! self::short_text( $section['key'], 32 ) ||
					! preg_match( '/^[a-z][a-z0-9_-]*$/', $section['key'] ) ||
					isset( $section_keys[ $section['key'] ] ) ||
					! self::short_text( $section['purpose'], 240 ) ||
					( $with_layout && ( ! self::short_text( $section['structure'], 500 ) ||
						! self::short_text( $section['responsiveIntent'], 240 ) ) ) ||
					( $with_layout && ! in_array( $section['layout'], array( 'stacked', 'grid', 'flex' ), true ) ) ) {
					return false;
				}
				$section_keys[ $section['key'] ] = true;
			}
		}
		return true;
	}

	private static function same_content( array $content, array $layout ): bool {
		if ( count( $content ) !== count( $layout ) ) {
			return false;
		}
		foreach ( $content as $index => $page ) {
			if ( ! isset( $layout[ $index ] ) ||
				$page['pageKey'] !== $layout[ $index ]['pageKey'] ||
				$page['goal'] !== $layout[ $index ]['goal'] ||
				( $page['requiredActions'] ?? null ) !== ( $layout[ $index ]['requiredActions'] ?? null ) ||
				count( $page['sections'] ) !== count( $layout[ $index ]['sections'] ) ) {
				return false;
			}
			foreach ( $page['sections'] as $section_index => $section ) {
				if ( $section['key'] !== $layout[ $index ]['sections'][ $section_index ]['key'] ||
					$section['purpose'] !== $layout[ $index ]['sections'][ $section_index ]['purpose'] ) {
					return false;
				}
			}
		}
		return true;
	}

	private static function quality_version( array $pages ): int {
		foreach ( $pages as $page ) {
			if ( array_key_exists( 'requiredActions', $page ) ) {
				return 1;
			}
		}
		return 0;
	}

	private static function valid_actions( $actions ): bool {
		if ( ! is_array( $actions ) || count( $actions ) > 12 ||
			( $actions && array_keys( $actions ) !== range( 0, count( $actions ) - 1 ) ) ) {
			return false;
		}
		$ids = array();
		foreach ( $actions as $action ) {
			if ( ! is_array( $action ) || ! self::exact_keys(
				$action,
				isset( $action['linkTarget'] ) ? array( 'actionId', 'kind', 'linkTarget' ) : array( 'actionId', 'kind' )
			) || ! is_string( $action['actionId'] ?? null ) ||
				! preg_match( '/^[a-z][a-z0-9_]{0,31}$/', $action['actionId'] ) ||
				isset( $ids[ $action['actionId'] ] ) || 'native-button' !== ( $action['kind'] ?? null ) ||
				( isset( $action['linkTarget'] ) && (
					! is_array( $action['linkTarget'] ) ||
					! self::exact_keys( $action['linkTarget'], array( 'kind', 'pageKey' ) ) ||
					'projectPage' !== ( $action['linkTarget']['kind'] ?? null ) ||
					! is_string( $action['linkTarget']['pageKey'] ?? null ) ||
					! preg_match( '/^[a-z][a-z0-9_-]{0,31}$/', $action['linkTarget']['pageKey'] )
				) ) ) {
				return false;
			}
			$ids[ $action['actionId'] ] = true;
		}
		return true;
	}

	private static function matches_required_actions( array $planned, array $batch ): bool {
		$nodes = array();
		foreach ( $batch['nodes'] ?? array() as $node ) {
			$key = $node['key'] ?? null;
			if ( ! is_string( $key ) || isset( $nodes[ $key ] ) ) {
				return false;
			}
			$nodes[ $key ] = $node;
		}
		foreach ( $planned['requiredActions'] ?? array() as $action ) {
			$node = $nodes[ $action['actionId'] ] ?? null;
			if ( ! is_array( $node ) || 'wphave/button' !== ( $node['name'] ?? null ) ||
				( isset( $action['linkTarget'] ) &&
					( $node['linkTarget'] ?? null ) !== $action['linkTarget'] ) ) {
				return false;
			}
		}
		return true;
	}

	private static function short_text( $value, int $maximum ): bool {
		return is_string( $value ) && '' !== trim( $value ) && mb_strlen( $value ) <= $maximum &&
			! preg_match( '/[<>\x00-\x1F]/', $value );
	}

	private static function exact_keys( array $value, array $expected ): bool {
		$keys = array_keys( $value );
		sort( $keys );
		sort( $expected );
		return $keys === $expected;
	}

	private static function current_fingerprint( $fingerprint ): bool {
		$catalog = WPHAVE_AI_MCP_Free_Design_Grammar::catalog();
		return ! is_wp_error( $catalog ) && is_string( $fingerprint ) &&
			hash_equals( $catalog['fingerprint'], $fingerprint );
	}

	private static function sign( array $payload ): string {
		$payload['userId'] = get_current_user_id();
		$payload['siteId'] = get_current_blog_id();
		$payload['issuedAt'] = time();
		$data = rtrim( strtr( base64_encode( wp_json_encode( $payload ) ), '+/', '-_' ), '=' );
		return $data . '.' . hash_hmac( 'sha256', $data, wp_salt( 'auth' ) );
	}

	private static function read( $token, string $stage ): ?array {
		if ( ! is_string( $token ) || strlen( $token ) > 262144 ||
			! preg_match( '/^[A-Za-z0-9_-]+\.[a-f0-9]{64}$/', $token ) ) {
			return null;
		}
		list( $data, $signature ) = explode( '.', $token, 2 );
		if ( ! hash_equals( hash_hmac( 'sha256', $data, wp_salt( 'auth' ) ), $signature ) ) {
			return null;
		}
		$payload = json_decode( base64_decode( strtr( $data, '-_', '+/' ), true ), true );
		if ( ! is_array( $payload ) || ( $payload['stage'] ?? null ) !== $stage ||
			( $payload['userId'] ?? null ) !== get_current_user_id() ||
			( $payload['siteId'] ?? null ) !== get_current_blog_id() ||
			! is_int( $payload['issuedAt'] ?? null ) ||
			$payload['issuedAt'] > time() || time() - $payload['issuedAt'] > self::MAX_AGE ) {
			return null;
		}
		return $payload;
	}

	private static function invalid(): WP_Error {
		return new WP_Error( 'wphave_mcp_workflow_invalid', 'Follow the content, design-options, section-layout, creation sequence with current planning tokens.' );
	}
}
