<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Signed, user-bound planning receipts for the direct MCP creation path. */
final class WPHAVE_AI_MCP_Free_Creation_Workflow {
	private const MAX_AGE = 86400;

	public static function content( $pages ) {
		if ( ! self::valid_pages( $pages, false ) ) {
			return self::invalid();
		}
		return array( 'contentToken' => self::sign( array( 'stage' => 'content', 'pages' => $pages ) ) );
	}

	public static function options( $token ) {
		$content = self::read( $token, 'content' );
		if ( null === $content ) {
			return self::invalid();
		}
		$catalog = WPHAVE_AI_MCP_Free_Design_Grammar::discovery();
		if ( is_wp_error( $catalog ) ) {
			return $catalog;
		}
		$catalog['creationWorkflow'] = array(
			'order' => array( 'plan content', 'read design options', 'plan section layouts', 'create drafts' ),
			'nextAbility' => 'wphave/free-page-plan-layout',
			'contentPlan' => $content['pages'],
		);
		$catalog['designToken'] = self::sign( array(
			'stage' => 'design',
			'pages' => $content['pages'],
			'fingerprint' => $catalog['fingerprint'],
		) );
		return $catalog;
	}

	public static function layout( $token, $pages ) {
		$design = self::read( $token, 'design' );
		if ( null === $design || ! self::valid_pages( $pages, true ) ||
			! self::same_content( $design['pages'], $pages ) ||
			! self::current_fingerprint( $design['fingerprint'] ) ) {
			return self::invalid();
		}
		return array( 'layoutToken' => self::sign( array(
			'stage' => 'layout',
			'pages' => $pages,
			'fingerprint' => $design['fingerprint'],
		) ) );
	}

	public static function matches_drafts( $token, array $pages ): bool {
		$layout = self::read( $token, 'layout' );
		if ( null === $layout || ! self::current_fingerprint( $layout['fingerprint'] ) ||
			count( $pages ) !== count( $layout['pages'] ) ) {
			return false;
		}
		foreach ( $pages as $index => $page ) {
			$planned = $layout['pages'][ $index ];
			$sections = array_map( static function ( $section ): array {
				return array(
					'key' => $section['key'],
					'layout' => $section['layout'],
					'purpose' => $section['purpose'],
				);
			}, $planned['sections'] );
			$actual_sections = $page['batch']['sections'] ?? null;
			if ( ! is_array( $actual_sections ) ) {
				return false;
			}
			$actual_sections = array_map( static function ( $section ): array {
				return array(
					'key' => $section['key'] ?? null,
					'layout' => $section['layout'] ?? null,
					'purpose' => $section['purpose'] ?? null,
				);
			}, $actual_sections );
			if ( ( $page['pageKey'] ?? null ) !== $planned['pageKey'] ||
				( $page['batch']['designFingerprint'] ?? null ) !== $layout['fingerprint'] ||
				$actual_sections !== $sections ) {
				return false;
			}
		}
		return true;
	}

	private static function valid_pages( $pages, bool $with_layout ): bool {
		if ( ! is_array( $pages ) || count( $pages ) < 1 || count( $pages ) > 12 ||
			array_keys( $pages ) !== range( 0, count( $pages ) - 1 ) ) {
			return false;
		}
		$keys = array();
		foreach ( $pages as $page ) {
			if ( ! is_array( $page ) || ! self::exact_keys( $page, array( 'pageKey', 'goal', 'sections' ) ) ||
				! self::short_text( $page['pageKey'], 32 ) ||
				! preg_match( '/^[a-z][a-z0-9_-]*$/', $page['pageKey'] ) ||
				isset( $keys[ $page['pageKey'] ] ) || ! self::short_text( $page['goal'], 240 ) ||
				! is_array( $page['sections'] ) || count( $page['sections'] ) < 1 ||
				count( $page['sections'] ) > 12 ||
				array_keys( $page['sections'] ) !== range( 0, count( $page['sections'] ) - 1 ) ) {
				return false;
			}
			$keys[ $page['pageKey'] ] = true;
			$section_keys = array();
			foreach ( $page['sections'] as $section ) {
				$expected = $with_layout ?
					array( 'key', 'purpose', 'layout', 'structure', 'responsiveIntent' ) :
					array( 'key', 'purpose' );
				if ( ! is_array( $section ) || ! self::exact_keys( $section, $expected ) ||
					! self::short_text( $section['key'], 32 ) ||
					! preg_match( '/^[a-z][a-z0-9_-]*$/', $section['key'] ) ||
					isset( $section_keys[ $section['key'] ] ) ||
					! self::short_text( $section['purpose'], 240 ) ||
					( $with_layout && ( ! self::short_text( $section['structure'], 500 ) ||
						! self::short_text( $section['responsiveIntent'], 240 ) ) ) ||
					( $with_layout && ! in_array( $section['layout'], array( 'stacked', 'grid', 'flex' ), true ) ) ) {
					return false;
				}
				$section_keys[ $section['key'] ] = true;
			}
		}
		return true;
	}

	private static function same_content( array $content, array $layout ): bool {
		if ( count( $content ) !== count( $layout ) ) {
			return false;
		}
		foreach ( $content as $index => $page ) {
			if ( ! isset( $layout[ $index ] ) ||
				$page['pageKey'] !== $layout[ $index ]['pageKey'] ||
				$page['goal'] !== $layout[ $index ]['goal'] ||
				count( $page['sections'] ) !== count( $layout[ $index ]['sections'] ) ) {
				return false;
			}
			foreach ( $page['sections'] as $section_index => $section ) {
				if ( $section['key'] !== $layout[ $index ]['sections'][ $section_index ]['key'] ||
					$section['purpose'] !== $layout[ $index ]['sections'][ $section_index ]['purpose'] ) {
					return false;
				}
			}
		}
		return true;
	}

	private static function short_text( $value, int $maximum ): bool {
		return is_string( $value ) && '' !== trim( $value ) && mb_strlen( $value ) <= $maximum &&
			! preg_match( '/[<>\x00-\x1F]/', $value );
	}

	private static function exact_keys( array $value, array $expected ): bool {
		$keys = array_keys( $value );
		sort( $keys );
		sort( $expected );
		return $keys === $expected;
	}

	private static function current_fingerprint( $fingerprint ): bool {
		$catalog = WPHAVE_AI_MCP_Free_Design_Grammar::catalog();
		return ! is_wp_error( $catalog ) && is_string( $fingerprint ) &&
			hash_equals( $catalog['fingerprint'], $fingerprint );
	}

	private static function sign( array $payload ): string {
		$payload['userId'] = get_current_user_id();
		$payload['siteId'] = get_current_blog_id();
		$payload['issuedAt'] = time();
		$data = rtrim( strtr( base64_encode( wp_json_encode( $payload ) ), '+/', '-_' ), '=' );
		return $data . '.' . hash_hmac( 'sha256', $data, wp_salt( 'auth' ) );
	}

	private static function read( $token, string $stage ): ?array {
		if ( ! is_string( $token ) || strlen( $token ) > 262144 ||
			! preg_match( '/^[A-Za-z0-9_-]+\.[a-f0-9]{64}$/', $token ) ) {
			return null;
		}
		list( $data, $signature ) = explode( '.', $token, 2 );
		if ( ! hash_equals( hash_hmac( 'sha256', $data, wp_salt( 'auth' ) ), $signature ) ) {
			return null;
		}
		$payload = json_decode( base64_decode( strtr( $data, '-_', '+/' ), true ), true );
		if ( ! is_array( $payload ) || ( $payload['stage'] ?? null ) !== $stage ||
			( $payload['userId'] ?? null ) !== get_current_user_id() ||
			( $payload['siteId'] ?? null ) !== get_current_blog_id() ||
			! is_int( $payload['issuedAt'] ?? null ) ||
			$payload['issuedAt'] > time() || time() - $payload['issuedAt'] > self::MAX_AGE ) {
			return null;
		}
		return $payload;
	}

	private static function invalid(): WP_Error {
		return new WP_Error( 'wphave_mcp_workflow_invalid', 'Follow the content, design-options, section-layout, creation sequence with current planning tokens.' );
	}
}
