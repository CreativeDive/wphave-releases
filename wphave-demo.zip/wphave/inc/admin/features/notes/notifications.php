<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Notes_Notifications {

    /**
     * Marks a note as read for the current user.
     *
     * @param int $post_id Note post ID.
     * @return bool Whether the exact read marker was persisted.
     */

    protected static function mark_read( $post_id ) {
        $user_id = get_current_user_id();

        if( ! $user_id ) {
            return false;
        }

		$meta_key = self::META_READ_USER_PREFIX . $user_id;
		$read_at = current_time( 'mysql', true );
		update_post_meta( absint( $post_id ), $meta_key, $read_at );

		// DATA/COMMIT INVARIANT: A notification is read only when the exact
		// user-scoped marker is confirmed in canonical post metadata. Attempted
		// writes never authorize a success response or decrement unread state.
		return $read_at === get_post_meta( absint( $post_id ), $meta_key, true );
    }

    /**
     * Checks whether a note has unread changes for the current user.
     *
     * @param WP_Post $post Note post object.
     * @return bool
     */

    protected static function is_unread( $post ) {
        $user_id = get_current_user_id();

        if( ! $post || ! $user_id ) {
            return false;
        }

        $updated_by = absint( get_post_meta( $post->ID, self::META_UPDATED_BY, true ) ) ?: (int) $post->post_author;

        if( $updated_by === $user_id ) {
            return false;
        }

        $read_at = get_post_meta( $post->ID, self::META_READ_USER_PREFIX . $user_id, true );

        if( ! $read_at ) {
            return true;
        }

        return strtotime( $post->post_modified_gmt ) > strtotime( $read_at );
    }

    /**
     * Returns active note IDs that may have unread changes for the current user.
     *
     * @return array<int>
     */

    protected static function get_notification_note_ids() {
        $user_id = get_current_user_id();

        if( ! $user_id ) {
            return array();
        }

        $base_args = array(
            'post_type' => self::POST_TYPE,
            'post_status' => array( 'publish', 'draft', 'private' ),
            'posts_per_page' => -1,
            'fields' => 'ids',
            'no_found_rows' => true,
        );

        $own_query = new WP_Query( array_merge( $base_args, array(
            'author' => $user_id,
            'meta_query' => array(
                self::get_active_meta_query(),
            ),
        ) ) );

        $shared_query = new WP_Query( array_merge( $base_args, array(
            'meta_query' => array(
                'relation' => 'AND',
                array(
                    'key' => self::META_SHARED_USER_PREFIX . $user_id,
                    'value' => '1',
                    'compare' => '=',
                ),
                array(
                    'key' => self::META_VISIBILITY,
                    'value' => 'shared',
                    'compare' => '=',
                ),
                self::get_active_meta_query(),
            ),
        ) ) );

		$candidate_ids = array_values( array_unique( array_merge( $own_query->posts, $shared_query->posts ) ) );

		// AUTHORIZATION/INDEX INVARIANT: Notification query indexes select candidates
		// only. Canonical note ownership or the current recipient list must independently
		// authorize every candidate before it can affect counts or user-scoped metadata.
		return array_values( array_filter( $candidate_ids, array( __CLASS__, 'user_can_read_note' ) ) );
    }

    /**
     * Returns the unread notification count for the current user.
     *
     * @return int
     */

    protected static function get_notification_count() {
        $user_id = get_current_user_id();
        $note_ids = self::get_notification_note_ids();

        if( ! $user_id || empty( $note_ids ) ) {
            return 0;
        }

        _prime_post_caches( $note_ids, false, true );

        $count = 0;

        foreach( $note_ids as $post_id ) {
            $post = get_post( $post_id );

			// AUTHORIZATION/TOCTOU INVARIANT: A notification candidate is reauthorized
			// immediately before its state is observed; stale indexes and mid-request
			// revocation must not disclose that a foreign note has unread changes.
            if( ! $post || ! self::user_can_read_note( $post ) ) {
                continue;
            }

            $updated_by = absint( get_post_meta( $post->ID, self::META_UPDATED_BY, true ) ) ?: (int) $post->post_author;

            if( $updated_by === $user_id ) {
                continue;
            }

            $read_at = get_post_meta( $post->ID, self::META_READ_USER_PREFIX . $user_id, true );

            if( ! $read_at || strtotime( $post->post_modified_gmt ) > strtotime( $read_at ) ) {
                $count++;
            }
        }

        return $count;
    }

        /**
     * Checks whether the current user can read a specific note.
     *
     * @param int|WP_Post $post Note post object or ID.
     * @return bool
     */

    public static function user_can_read_note( $post ) {
        $post = get_post( $post );

        if( ! $post || $post->post_type !== self::POST_TYPE ) {
            return false;
        }

        $user_id = get_current_user_id();

		// AUTHORIZATION INVARIANT: Notes are private to their author unless the stored
		// visibility explicitly names the current user and that user still possesses
		// Notes access. Notification discovery never widens document visibility.

        if( (int) $post->post_author === $user_id ) {
            return self::current_user_can_access_notes();
        }

        $visibility = get_post_meta( $post->ID, self::META_VISIBILITY, true ) ?: 'private';
        $shared_user_ids = self::get_shared_user_ids( $post->ID );

        return $visibility === 'shared' && in_array( $user_id, $shared_user_ids, true ) && self::current_user_can_access_notes();
    }

    /**
     * REST callback: returns active notes shared with the current user.
     *
     * @param WP_REST_Request $request Current REST request.
     * @return WP_REST_Response|WP_Error
     */

    public static function get_notifications( WP_REST_Request $request ) {
        if( ! self::current_user_can_access_notes() ) {
            return new WP_Error( 'wphave_notes_forbidden', __( 'You are not allowed to access notes.', 'wphave' ), array( 'status' => 403 ) );
        }

        $user_id = get_current_user_id();

        if( ! $user_id ) {
            return rest_ensure_response( array(
                'count' => 0,
            ) );
        }

        return rest_ensure_response( array(
            'count' => self::get_notification_count(),
        ) );
    }

    /**
     * REST callback: marks active shared notes as read for the current user.
     *
     * @return WP_REST_Response|WP_Error
     */

    public static function mark_notifications_read( WP_REST_Request $request ) {
        if( ! self::current_user_can_access_notes() ) {
            return new WP_Error( 'wphave_notes_forbidden', __( 'You are not allowed to access notes.', 'wphave' ), array( 'status' => 403 ) );
        }

        $user_id = get_current_user_id();

        if( ! $user_id ) {
            return rest_ensure_response( array(
                'updated' => 0,
            ) );
        }

        $note_ids = self::get_notification_note_ids();
		$updated = 0;

        foreach( $note_ids as $post_id ) {
			// AUTHORIZATION/TOCTOU INVARIANT: Batch discovery never delegates write
			// authority. Recheck the exact note immediately before publishing this
			// user's read marker so revocation skips the object fail-closed.
			if ( ! self::user_can_read_note( $post_id ) ) {
				continue;
			}

            if ( ! self::mark_read( $post_id ) ) {
                return new WP_Error( 'wphave_notes_read_write_failed', __( 'The notification state could not be saved.', 'wphave' ), array( 'status' => 500 ) );
            }

			$updated++;
        }

        return rest_ensure_response( array(
			'updated' => $updated,
        ) );
    }

    /**
     * REST callback: marks a single note as read for the current user.
     *
     * @param WP_REST_Request $request Current REST request.
     * @return WP_REST_Response|WP_Error
     */

    public static function mark_note_read( WP_REST_Request $request ) {
        $post_id = absint( $request['id'] );
        $post = get_post( $post_id );

        if( ! self::user_can_read_note( $post ) ) {
            return new WP_Error( 'wphave_notes_forbidden', __( 'You are not allowed to access this note.', 'wphave' ), array( 'status' => 403 ) );
        }

        if ( ! self::mark_read( $post_id ) ) {
            return new WP_Error( 'wphave_notes_read_write_failed', __( 'The notification state could not be saved.', 'wphave' ), array( 'status' => 500 ) );
        }

        return rest_ensure_response( array(
            'read' => true,
            'id' => $post_id,
        ) );
    }

}
