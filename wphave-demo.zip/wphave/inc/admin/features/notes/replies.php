<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Notes_Replies {

    /**
     * Sanitizes reply content as plain textarea text with a hard length limit.
     *
     * @param mixed $content Raw reply content.
     * @return string
     */

    protected static function sanitize_reply_content( $content ) {
        $content = sanitize_textarea_field( (string) $content );

        return self::limit_text( $content, self::MAX_REPLY_LENGTH );
    }

    /**
     * Returns sanitized note replies.
     *
     * @param int $post_id Note post ID.
     * @return array<int,array>
     */

    protected static function get_replies( $post_id ) {
        $replies = get_post_meta( $post_id, self::META_REPLIES, true );

        if( ! is_array( $replies ) ) {
            return array();
        }

        return array_values( array_filter( array_map( function( $reply ) use ( $post_id ) {
            if( ! is_array( $reply ) ) {
                return null;
            }

            $user_id = absint( $reply['userId'] ?? $reply['user_id'] ?? 0 );
            $content = self::sanitize_reply_content( $reply['content'] ?? '' );

            if( ! $user_id || ! $content ) {
                return null;
            }

            $reply_id = sanitize_key( $reply['id'] ?? '' );
            $created = sanitize_text_field( $reply['created'] ?? '' );

            return array(
                'id' => $reply_id ?: wp_generate_uuid4(),
                'userId' => $user_id,
                'user' => self::prepare_user( $user_id ),
                'content' => $content,
                'created' => $created ?: mysql_to_rfc3339( current_time( 'mysql' ) ),
                'canDelete' => $user_id === get_current_user_id() || self::user_can_edit_note( $post_id ),
            );
        }, $replies ) ) );
    }

        /**
     * Strips computed reply fields before storing replies.
     *
     * @param array $replies Prepared or raw replies.
     * @return array<int,array>
     */

    protected static function prepare_replies_for_storage( $replies ) {
        if( ! is_array( $replies ) ) {
            return array();
        }

        return array_values( array_filter( array_map( function( $reply ) {
            if( ! is_array( $reply ) ) {
                return null;
            }

            $content = self::sanitize_reply_content( $reply['content'] ?? '' );
            $user_id = absint( $reply['userId'] ?? $reply['user_id'] ?? 0 );

            if( ! $user_id || ! $content ) {
                return null;
            }

            return array(
                'id' => sanitize_key( $reply['id'] ?? wp_generate_uuid4() ),
                'userId' => $user_id,
                'content' => $content,
                'created' => sanitize_text_field( $reply['created'] ?? mysql_to_rfc3339( current_time( 'mysql' ) ) ),
            );
        }, $replies ) ) );
    }

    /** Persist an already normalized reply collection or fail without reporting success. */

    private static function persist_replies( int $post_id, array $replies ): bool {
        $saved = update_post_meta( $post_id, self::META_REPLIES, $replies );

        // DATA-INTEGRITY INVARIANT: A reply mutation is complete only when the
        // exact collection is observable in post meta. WordPress' false return
        // and third-party metadata filters must never become a successful API
        // response for a create or delete that did not actually commit.
        return false !== $saved
            && $replies === get_post_meta( $post_id, self::META_REPLIES, true );
    }

    /**
     * REST callback: adds a reply to a readable note.
     *
     * @param WP_REST_Request $request Current REST request.
     * @return WP_REST_Response|WP_Error
     */

    public static function create_reply( WP_REST_Request $request ) {
        $post_id = absint( $request['id'] );
        $post = get_post( $post_id );

        if( ! self::user_can_read_note( $post ) ) {
            return new WP_Error( 'wphave_notes_forbidden', __( 'You are not allowed to reply to this note.', 'wphave' ), array( 'status' => 403 ) );
        }

        $content = self::sanitize_reply_content( $request->get_param( 'content' ) ?: '' );

        if( ! trim( wp_strip_all_tags( $content ) ) ) {
            return new WP_Error( 'wphave_notes_empty_reply', __( 'The reply is empty.', 'wphave' ), array( 'status' => 400 ) );
        }

        $replies = self::prepare_replies_for_storage( get_post_meta( $post_id, self::META_REPLIES, true ) );
        $replies[] = array(
            'id' => wp_generate_uuid4(),
            'userId' => get_current_user_id(),
            'content' => $content,
            'created' => mysql_to_rfc3339( current_time( 'mysql' ) ),
        );
		$replies = self::prepare_replies_for_storage( $replies );

		// AUTHORIZATION/TOCTOU INVARIANT: Reply sanitization and stored-reply
		// normalization are extension boundaries and must complete before the final
		// exact-note authority check. No WPHAVE transformation may occur between this
		// check and publication of the normalized reply collection.
		if ( ! self::user_can_read_note( $post_id ) ) {
			return new WP_Error( 'wphave_notes_forbidden', __( 'You are not allowed to reply to this note.', 'wphave' ), array( 'status' => 403 ) );
		}

        if ( ! self::persist_replies( $post_id, $replies ) ) {
            return new WP_Error(
                'wphave_notes_reply_write_failed',
                __( 'The reply could not be saved.', 'wphave' ),
                array( 'status' => 500 )
            );
        }

        update_post_meta( $post_id, self::META_UPDATED_BY, get_current_user_id() );
        wp_update_post( array(
            'ID' => $post_id,
            'post_modified' => current_time( 'mysql' ),
            'post_modified_gmt' => current_time( 'mysql', true ),
        ) );

        return rest_ensure_response( self::prepare_response( $post_id ) );
    }

    /**
     * REST callback: deletes a reply when owned by the user or note owner.
     *
     * @param WP_REST_Request $request Current REST request.
     * @return WP_REST_Response|WP_Error
     */

    public static function delete_reply( WP_REST_Request $request ) {
        $post_id = absint( $request['id'] );
        $reply_id = sanitize_key( $request['reply_id'] );
        $post = get_post( $post_id );

        if( ! self::user_can_read_note( $post ) ) {
            return new WP_Error( 'wphave_notes_forbidden', __( 'You are not allowed to access this note.', 'wphave' ), array( 'status' => 403 ) );
        }

        $replies = self::get_replies( $post_id );
        $next_replies = array();
        $deleted = false;
		$deleted_reply_user_id = 0;

        foreach( $replies as $reply ) {
            if( $reply['id'] === $reply_id ) {
                // SECURITY INVARIANT: Read access to a shared note permits discussion but
                // never deletion of another user's reply unless note ownership grants it.
                if( ! $reply['canDelete'] ) {
                    return new WP_Error( 'wphave_notes_forbidden', __( 'You are not allowed to delete this reply.', 'wphave' ), array( 'status' => 403 ) );
                }

                $deleted = true;
				$deleted_reply_user_id = absint( $reply['userId'] ?? 0 );
                continue;
            }

            $next_replies[] = $reply;
        }

        if( ! $deleted ) {
            return new WP_Error( 'wphave_notes_reply_not_found', __( 'The reply could not be found.', 'wphave' ), array( 'status' => 404 ) );
        }

		$next_replies = self::prepare_replies_for_storage( $next_replies );

		// AUTHORIZATION/TOCTOU INVARIANT: Reply deletion authority is object-specific
		// and must be recomputed after every filterable reply normalization. Read access
		// alone never authorizes deletion, and no further WPHAVE transformation may run
		// between this check and publication of the normalized collection.
		if (
			! self::user_can_read_note( $post_id )
			|| (
				$deleted_reply_user_id !== get_current_user_id()
				&& ! self::user_can_edit_note( $post_id )
			)
		) {
			return new WP_Error( 'wphave_notes_forbidden', __( 'You are not allowed to delete this reply.', 'wphave' ), array( 'status' => 403 ) );
		}

        if ( ! self::persist_replies( $post_id, $next_replies ) ) {
            return new WP_Error(
                'wphave_notes_reply_write_failed',
                __( 'The reply could not be deleted.', 'wphave' ),
                array( 'status' => 500 )
            );
        }

        update_post_meta( $post_id, self::META_UPDATED_BY, get_current_user_id() );
        wp_update_post( array(
            'ID' => $post_id,
            'post_modified' => current_time( 'mysql' ),
            'post_modified_gmt' => current_time( 'mysql', true ),
        ) );

        return rest_ensure_response( self::prepare_response( $post_id ) );
    }

}
