<?php

require_once __DIR__ . '/repository.php';
require_once __DIR__ . '/permissions.php';
require_once __DIR__ . '/rest.php';
require_once __DIR__ . '/replies.php';
require_once __DIR__ . '/attachments.php';
require_once __DIR__ . '/notifications.php';


if( ! defined('ABSPATH') ) {
	exit;
}

if( ! class_exists('WPHAVE_Notes_Manager') ) :

	/**
	 * Handles the internal WPHAVE notes feature.
	 *
	 * Registers the private notes post type, protects read/write access,
	 * exposes the REST API used by the React notes screen and keeps sharing
	 * metadata queryable.
	 */

	class WPHAVE_Notes_Manager {

	use WPHAVE_Notes_Repository,
		WPHAVE_Notes_Permissions,
		WPHAVE_Notes_REST,
		WPHAVE_Notes_Replies,
		WPHAVE_Notes_Attachments,
		WPHAVE_Notes_Notifications;

		const POST_TYPE = 'wphave_note';
		const META_VISIBILITY = '_wphave_note_visibility';
		const META_SHARED_USERS = '_wphave_note_shared_user_ids';
		const META_SHARED_USER_PREFIX = '_wphave_note_shared_user_';
		const META_READ_USER_PREFIX = '_wphave_note_read_user_';
		const META_PINNED = '_wphave_note_is_pinned';
		const META_ARCHIVED = '_wphave_note_is_archived';
		const META_COLOR = '_wphave_note_color';
		const META_UPDATED_BY = '_wphave_note_updated_by';
		const META_REPLIES = '_wphave_note_replies';
		const META_LINKS = '_wphave_note_links';
		const META_ATTACHMENTS = '_wphave_note_attachment_ids';
		const REST_NAMESPACE = 'wphave/v1';
		const MAX_TITLE_LENGTH = 160;
		const MAX_CONTENT_LENGTH = 20000;
		const MAX_REPLY_LENGTH = 5000;
		const MAX_SHARED_USERS = 50;
		const MAX_LINKS = 10;
		const MAX_ATTACHMENTS = 20;
		const MAX_PER_PAGE = 96;

		/**
		 * Registers WordPress hooks for the notes feature.
		 *
		 * @return void
		 */

		public static function init() {
			add_action( 'init', array( __CLASS__, 'register_post_type' ), 7 );
			add_action( 'rest_api_init', array( __CLASS__, 'register_rest_routes' ) );
		}

	}

	WPHAVE_Notes_Manager::init();

endif;
