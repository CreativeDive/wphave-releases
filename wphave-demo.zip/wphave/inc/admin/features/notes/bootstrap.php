<?php

/**
 * Bootstrap the notes feature when it is enabled for the current runtime.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

if( wphave_notes_feature_enabled() ) {
	require_once __DIR__ . '/manager.php';
}
