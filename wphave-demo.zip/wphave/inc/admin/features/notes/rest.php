<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Notes_REST {

    /**
     * Reads shared user IDs from the REST request across supported parameter names.
     *
     * @param WP_REST_Request $request Current REST request.
     * @return array<int>
     */

    protected static function get_shared_user_ids_from_request( WP_REST_Request $request ) {
        $json_params = $request->get_json_params();

        foreach( array( 'sharedUserIds', 'shared_user_ids' ) as $param ) {
            if( $request->has_param( $param ) ) {
                return self::sanitize_shared_user_ids( $request->get_param( $param ) );
            }

            if( is_array( $json_params ) && array_key_exists( $param, $json_params ) ) {
                return self::sanitize_shared_user_ids( $json_params[ $param ] );
            }
        }

        return array();
    }

    /**
     * Checks if the REST request contains shared user IDs.
     *
     * @param WP_REST_Request $request Current REST request.
     * @return bool
     */

    protected static function request_has_shared_user_ids( WP_REST_Request $request ) {
        $json_params = $request->get_json_params();

        return $request->has_param( 'sharedUserIds' ) || $request->has_param( 'shared_user_ids' ) || ( is_array( $json_params ) && ( array_key_exists( 'sharedUserIds', $json_params ) || array_key_exists( 'shared_user_ids', $json_params ) ) );
    }

    /**
     * Reads a request parameter from camelCase, snake_case or JSON payload.
     *
     * @param WP_REST_Request $request Current REST request.
     * @param string $camel Camel-case parameter name.
     * @param string $snake Snake-case parameter name.
     * @param mixed $default Default value.
     * @return mixed
     */

    protected static function get_request_value( WP_REST_Request $request, $camel, $snake, $default = null ) {
        $json_params = $request->get_json_params();

        foreach( array( $camel, $snake ) as $param ) {
            if( $request->has_param( $param ) ) {
                return $request->get_param( $param );
            }

            if( is_array( $json_params ) && array_key_exists( $param, $json_params ) ) {
                return $json_params[ $param ];
            }
        }

        return $default;
    }

    /**
     * Checks if the REST request contains a camelCase or snake_case parameter.
     *
     * @param WP_REST_Request $request Current REST request.
     * @param string $camel Camel-case parameter name.
     * @param string $snake Snake-case parameter name.
     * @return bool
     */

    protected static function request_has_value( WP_REST_Request $request, $camel, $snake ) {
        $json_params = $request->get_json_params();

        return $request->has_param( $camel ) || $request->has_param( $snake ) || ( is_array( $json_params ) && ( array_key_exists( $camel, $json_params ) || array_key_exists( $snake, $json_params ) ) );
    }

    /**
     * Converts a note post into the REST response payload used by the app.
     *
     * @param int|WP_Post $post Note post object or ID.
     * @return array
     */

    public static function prepare_response( $post ) {
        $post = get_post( $post );
        $shared_user_ids = self::get_shared_user_ids( $post->ID );

        $shared_users = array_values( array_filter( array_map( function( $user_id ) {
            return self::prepare_user( $user_id );
        }, $shared_user_ids ) ) );

        $updated_by = absint( get_post_meta( $post->ID, self::META_UPDATED_BY, true ) ) ?: (int) $post->post_author;
        $links = self::sanitize_links( get_post_meta( $post->ID, self::META_LINKS, true ) );
        $attachment_ids = self::sanitize_attachment_ids( get_post_meta( $post->ID, self::META_ATTACHMENTS, true ) );

        return array(
            'id' => (int) $post->ID,
            'title' => html_entity_decode( self::sanitize_title( $post->post_title ), ENT_QUOTES, get_bloginfo( 'charset' ) ),
            'content' => array(
                'raw' => $post->post_content,
                'rendered' => wpautop( esc_html( $post->post_content ) ),
            ),
            'excerpt' => wp_trim_words( wp_strip_all_tags( $post->post_content ), 28, '...' ),
            'visibility' => get_post_meta( $post->ID, self::META_VISIBILITY, true ) ?: 'private',
            'sharedUserIds' => $shared_user_ids,
            'sharedUsers' => $shared_users,
            'isPinned' => (bool) get_post_meta( $post->ID, self::META_PINNED, true ),
            'isArchived' => (bool) get_post_meta( $post->ID, self::META_ARCHIVED, true ),
            'color' => sanitize_hex_color( get_post_meta( $post->ID, self::META_COLOR, true ) ) ?: '',
            'author' => self::prepare_user( (int) $post->post_author ),
            'updatedBy' => self::prepare_user( $updated_by ),
            'activity' => array(
                'sharedBy' => self::prepare_user( (int) $post->post_author ),
                'updatedBy' => self::prepare_user( $updated_by ),
                'lastEdited' => mysql_to_rfc3339( $post->post_modified ),
                'isUnread' => self::is_unread( $post ),
            ),
            'replies' => self::get_replies( $post->ID ),
            'links' => $links,
            'attachmentIds' => $attachment_ids,
            'date' => mysql_to_rfc3339( $post->post_date ),
            'modified' => mysql_to_rfc3339( $post->post_modified ),
            'canEdit' => self::user_can_edit_note( $post ),
            'canDelete' => self::user_can_edit_note( $post ),
        );
    }

    /**
     * Registers all notes REST API routes.
     *
     * @return void
     */

    public static function register_rest_routes() {
        register_rest_route( self::REST_NAMESPACE, '/notes', array(
            array(
                'methods' => WP_REST_Server::READABLE,
                'callback' => array( __CLASS__, 'get_notes' ),
                'permission_callback' => array( __CLASS__, 'current_user_can_access_notes' ),
            ),
            array(
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => array( __CLASS__, 'create_note' ),
                'permission_callback' => array( __CLASS__, 'current_user_can_access_notes' ),
            ),
        ) );

        register_rest_route( self::REST_NAMESPACE, '/notes/users', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array( __CLASS__, 'get_note_users' ),
            'permission_callback' => array( __CLASS__, 'current_user_can_access_notes' ),
        ) );

        register_rest_route( self::REST_NAMESPACE, '/notes/notifications', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array( __CLASS__, 'get_notifications' ),
            'permission_callback' => array( __CLASS__, 'current_user_can_access_notes' ),
        ) );

        register_rest_route( self::REST_NAMESPACE, '/notes/notifications/read', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array( __CLASS__, 'mark_notifications_read' ),
            'permission_callback' => array( __CLASS__, 'current_user_can_access_notes' ),
        ) );

        register_rest_route( self::REST_NAMESPACE, '/notes/(?P<id>\d+)', array(
            array(
                'methods' => WP_REST_Server::EDITABLE,
                'callback' => array( __CLASS__, 'update_note' ),
                'permission_callback' => function( WP_REST_Request $request ) {
                    // SECURITY INVARIANT: Feature access and note visibility do not grant
                    // mutation authority; updates and deletion require exact note ownership.
                    return WPHAVE_Notes_Manager::user_can_edit_note( absint( $request['id'] ) );
                },
            ),
            array(
                'methods' => WP_REST_Server::DELETABLE,
                'callback' => array( __CLASS__, 'delete_note' ),
                'permission_callback' => function( WP_REST_Request $request ) {
                    return WPHAVE_Notes_Manager::user_can_edit_note( absint( $request['id'] ) );
                },
            ),
        ) );

        register_rest_route( self::REST_NAMESPACE, '/notes/(?P<id>\d+)/read', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array( __CLASS__, 'mark_note_read' ),
            'permission_callback' => function( WP_REST_Request $request ) {
                return WPHAVE_Notes_Manager::user_can_read_note( absint( $request['id'] ) );
            },
        ) );

        register_rest_route( self::REST_NAMESPACE, '/notes/(?P<id>\d+)/replies', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array( __CLASS__, 'create_reply' ),
			'args' => array( 'content' => array( 'type' => 'string', 'maxLength' => self::MAX_REPLY_LENGTH, 'required' => true ) ),
            'permission_callback' => function( WP_REST_Request $request ) {
                return WPHAVE_Notes_Manager::user_can_read_note( absint( $request['id'] ) );
            },
        ) );

        register_rest_route( self::REST_NAMESPACE, '/notes/(?P<id>\d+)/replies/(?P<reply_id>[a-zA-Z0-9_-]+)', array(
            'methods' => WP_REST_Server::DELETABLE,
            'callback' => array( __CLASS__, 'delete_reply' ),
            'permission_callback' => function( WP_REST_Request $request ) {
                return WPHAVE_Notes_Manager::user_can_read_note( absint( $request['id'] ) );
            },
        ) );
    }

}
