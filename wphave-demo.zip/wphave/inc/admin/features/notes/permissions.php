<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Notes_Permissions {

    /**
     * Sanitizes shared user IDs and removes the current user.
     *
     * @param mixed $value Raw user IDs value.
     * @return array<int>
     */

    public static function sanitize_shared_user_ids( $value ) {
        $current_user_id = get_current_user_id();
        $user_ids = array_slice( self::sanitize_user_ids( $value ), 0, self::MAX_SHARED_USERS );

        if( ! $current_user_id ) {
            return $user_ids;
        }

        return array_values( array_filter( $user_ids, function( $user_id ) use ( $current_user_id ) {
            return (int) $user_id !== (int) $current_user_id && self::user_id_can_access_notes( $user_id );
        } ) );
    }

    /**
     * Synchronizes per-user share meta keys used for efficient shared-note queries.
     *
     * @param int $post_id Note post ID.
     * @param array<int> $shared_user_ids Shared user IDs.
     * @return void
     */

    public static function sync_shared_user_meta( $post_id, $shared_user_ids = array() ) {
        $post_id = absint( $post_id );
        $shared_user_ids = self::sanitize_shared_user_ids( $shared_user_ids );
        $all_meta = get_post_meta( $post_id );
		$persisted = true;

        foreach( array_keys( $all_meta ) as $meta_key ) {
			// AUTHORIZATION/NAMESPACE INVARIANT: The canonical recipient-list key shares
			// the per-user index prefix but is never itself an index. Synchronization must
			// not delete it or demote authorization to the denormalized fallback projection.
            if(
				self::META_SHARED_USERS !== $meta_key
				&& self::string_starts_with( $meta_key, self::META_SHARED_USER_PREFIX )
			) {
				$deleted = delete_post_meta( $post_id, $meta_key );
				$persisted = ( $deleted || '' === get_post_meta( $post_id, $meta_key, true ) ) && $persisted;
            }
        }

        foreach( $shared_user_ids as $user_id ) {
			$meta_key = self::META_SHARED_USER_PREFIX . $user_id;
			$updated = update_post_meta( $post_id, $meta_key, 1 );
			$persisted = ( false !== $updated && 1 === (int) get_post_meta( $post_id, $meta_key, true ) ) && $persisted;
        }

		return $persisted;
    }

        /**
     * Stores shared user IDs and synchronizes query helper meta.
     *
     * @param int $post_id Note post ID.
     * @param array<int> $shared_user_ids Shared user IDs.
     * @return void
     */

    protected static function update_shared_users( $post_id, $shared_user_ids = array() ) {
        $shared_user_ids = self::sanitize_shared_user_ids( $shared_user_ids );

        delete_post_meta( $post_id, self::META_SHARED_USERS );
		$canonical_updated = update_post_meta( $post_id, self::META_SHARED_USERS, $shared_user_ids );
		$canonical_persisted = false !== $canonical_updated
			&& $shared_user_ids === get_post_meta( $post_id, self::META_SHARED_USERS, true );
		$indexes_persisted = self::sync_shared_user_meta( $post_id, $shared_user_ids );

		// AUTHORIZATION INVARIANT: Canonical recipients and query indexes are one
		// sharing projection. Callers may publish `shared` only after both exact
		// representations commit; stale per-user indexes never retain authority
		// after an attempted revocation.
		return $canonical_persisted && $indexes_persisted;
    }

    /**
     * Returns shared user IDs from array meta with per-user meta fallback.
     *
     * @param int $post_id Note post ID.
     * @return array<int>
     */

    protected static function get_shared_user_ids( $post_id ) {
        $shared_user_ids = self::sanitize_user_ids( get_post_meta( $post_id, self::META_SHARED_USERS, true ) );

        if( ! empty( $shared_user_ids ) ) {
            return $shared_user_ids;
        }

        $all_meta = get_post_meta( $post_id );
        $fallback_user_ids = array();

        foreach( array_keys( $all_meta ) as $meta_key ) {
			// AUTHORIZATION/NAMESPACE INVARIANT: The reserved canonical key is not a
			// per-user fallback index even though its historical name shares the prefix.
            if(
				self::META_SHARED_USERS !== $meta_key
				&& self::string_starts_with( $meta_key, self::META_SHARED_USER_PREFIX )
			) {
                $fallback_user_ids[] = str_replace( self::META_SHARED_USER_PREFIX, '', $meta_key );
            }
        }

        return self::sanitize_user_ids( $fallback_user_ids );
    }

    /**
     * Checks whether the current user can access the notes feature.
     *
     * @return bool
     */

    public static function current_user_can_access_notes() {
        return self::user_id_can_access_notes( get_current_user_id() );
    }

    /**
     * Checks whether a specific user can access the notes feature.
     *
     * @param int $user_id User ID.
     * @return bool
     */

    protected static function user_id_can_access_notes( $user_id ) {
        $user_id = absint( $user_id );

        if( ! $user_id ) {
            return false;
        }

        return user_can( $user_id, 'manage_options' ) || user_can( $user_id, 'wphave_manage_notes' );
    }

    /**
     * Checks whether the current user can edit or delete a specific note.
     *
     * @param int|WP_Post $post Note post object or ID.
     * @return bool
     */

    public static function user_can_edit_note( $post ) {
        $post = get_post( $post );

        if( ! $post || $post->post_type !== self::POST_TYPE ) {
            return false;
        }

        // SECURITY INVARIANT: Feature access does not imply object ownership.
        // Editing and deletion remain restricted to the authenticated note author.
        return (int) $post->post_author === get_current_user_id() && self::current_user_can_access_notes();
    }

}
