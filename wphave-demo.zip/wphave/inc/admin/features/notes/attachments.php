<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Notes_Attachments {

    /**
     * Sanitizes attachment IDs and keeps only existing attachments.
     *
     * @param mixed $value Raw attachment IDs value.
     * @return array<int>
     */

    protected static function sanitize_attachment_ids( $value ) {
        $attachment_ids = self::sanitize_user_ids( $value, self::MAX_ATTACHMENTS );

        return array_values( array_filter( $attachment_ids, function( $attachment_id ) {
            // MEDIA-REFERENCE INVARIANT: A note's share list cannot convert an
            // attachment ID into read authority. Check the exact object both
            // when accepting a reference and when projecting it to a reader.
            return get_post_type( $attachment_id ) === 'attachment'
                && current_user_can( 'read_post', $attachment_id );
        } ) );
    }

}
