<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Notes_Attachments {

    /**
     * Sanitizes attachment IDs and keeps only existing attachments.
     *
     * @param mixed $value Raw attachment IDs value.
     * @return array<int>
     */

    protected static function sanitize_attachment_ids( $value ) {
        $attachment_ids = array_slice( self::sanitize_user_ids( $value ), 0, self::MAX_ATTACHMENTS );

        return array_values( array_filter( $attachment_ids, function( $attachment_id ) {
            return get_post_type( $attachment_id ) === 'attachment';
        } ) );
    }

}
