<?php

require_once wphave_dir() . 'inc/features/security/boundaries/serialization.php';

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_Notes_Repository {

    /**
     * Registers the private notes post type and its protected meta fields.
     *
     * @return void
     */

    public static function register_post_type() {
        // SECURITY INVARIANT: Notes and their sharing metadata are private to the
        // WPHAVE domain API. Native public queries and generic REST meta mutation are
        // disabled so every read and write passes the note-specific access policy.
        register_post_type( self::POST_TYPE, array(
            'labels' => array(
                'name' => __('Notes', 'wphave'),
                'singular_name' => __('Note', 'wphave'),
            ),
            'public' => false,
            'publicly_queryable' => false,
            'exclude_from_search' => true,
            'show_ui' => false,
            'show_in_menu' => false,
            'show_in_rest' => false,
            'hierarchical' => false,
            'supports' => array( 'title', 'editor', 'author', 'revisions' ),
            'capability_type' => 'post',
            'map_meta_cap' => true,
            'rewrite' => false,
            'query_var' => false,
        ) );

        register_post_meta( self::POST_TYPE, self::META_VISIBILITY, array(
            'type' => 'string',
            'single' => true,
            'default' => 'private',
            'sanitize_callback' => 'sanitize_key',
            'auth_callback' => '__return_false',
        ) );

        register_post_meta( self::POST_TYPE, self::META_SHARED_USERS, array(
            'type' => 'array',
            'single' => true,
            'default' => array(),
            'sanitize_callback' => array( __CLASS__, 'sanitize_user_ids' ),
            'auth_callback' => '__return_false',
            'show_in_rest' => array(
                'schema' => array(
                    'type' => 'array',
                    'items' => array(
                        'type' => 'integer',
                    ),
                ),
            ),
        ) );

        foreach( array( self::META_PINNED, self::META_ARCHIVED ) as $meta_key ) {
            register_post_meta( self::POST_TYPE, $meta_key, array(
                'type' => 'boolean',
                'single' => true,
                'default' => false,
                'sanitize_callback' => 'rest_sanitize_boolean',
                'auth_callback' => '__return_false',
            ) );
        }

        register_post_meta( self::POST_TYPE, self::META_COLOR, array(
            'type' => 'string',
            'single' => true,
            'default' => '',
            'sanitize_callback' => 'sanitize_hex_color',
            'auth_callback' => '__return_false',
        ) );
    }

    /**
     * Sanitizes a user ID list from array, JSON or serialized input.
     *
     * @param mixed $value Raw user IDs value.
     * @return array<int>
     */

    public static function sanitize_user_ids( $value ) {
        if( is_string( $value ) ) {
            // SECURITY INVARIANT: Legacy sharing metadata may contain arrays, but
            // reading it must never construct a stored PHP object graph.
            $maybe_unserialized = wphave_maybe_unserialize_without_classes( $value );
            $maybe_json = json_decode( $value, true );

            if( is_array( $maybe_unserialized ) ) {
                $value = $maybe_unserialized;
            } else if( is_array( $maybe_json ) ) {
                $value = $maybe_json;
            }
        }

        if( ! is_array( $value ) ) {
            return array();
        }

        return array_values( array_unique( array_filter( array_map( 'absint', $value ) ) ) );
    }

    /**
     * Limits text length without requiring mbstring.
     *
     * @param string $value Text value.
     * @param int $length Maximum characters.
     * @return string
     */

    protected static function limit_text( $value, $length ) {
        $value = (string) $value;

        if( function_exists( 'mb_substr' ) ) {
            return mb_substr( $value, 0, absint( $length ) );
        }

        return substr( $value, 0, absint( $length ) );
    }

    /**
     * Checks string prefix without requiring PHP 8 str_starts_with().
     *
     * @param string $value Full string.
     * @param string $prefix Expected prefix.
     * @return bool
     */

    protected static function string_starts_with( $value, $prefix ) {
        return substr( (string) $value, 0, strlen( (string) $prefix ) ) === (string) $prefix;
    }

    /**
     * Sanitizes note titles and removes WordPress private-title prefixes.
     *
     * @param string $title Raw note title.
     * @return string
     */

    public static function sanitize_title( $title ) {
        $title = sanitize_text_field( $title );
        $title = self::limit_text( $title, self::MAX_TITLE_LENGTH );

        while( preg_match( '/^\s*(Private|Privat):\s*/i', $title ) ) {
            $title = preg_replace( '/^\s*(Private|Privat):\s*/i', '', $title );
        }

        return $title ?: __( 'Untitled note', 'wphave' );
    }

    /**
     * Sanitizes note content as plain textarea text with a hard length limit.
     *
     * @param mixed $content Raw note content.
     * @return string
     */

    protected static function sanitize_content( $content ) {
        $content = sanitize_textarea_field( (string) $content );

        return self::limit_text( $content, self::MAX_CONTENT_LENGTH );
    }

    /**
     * Sanitizes related note links.
     *
     * @param mixed $value Raw links value.
     * @return array<int,array>
     */

    protected static function sanitize_links( $value ) {
        if( ! is_array( $value ) ) {
            return array();
        }

        $links = array();

        foreach( array_slice( $value, 0, self::MAX_LINKS ) as $link ) {
            if( ! is_array( $link ) ) {
                continue;
            }

            $url = esc_url_raw( $link['url'] ?? '' );
            $id = absint( $link['id'] ?? 0 );

            if( ! $url && ! $id ) {
                continue;
            }

            $links[] = array(
                'id' => $id,
                'url' => $url,
                'type' => sanitize_key( $link['type'] ?? '' ),
                'title' => self::limit_text( sanitize_text_field( $link['title'] ?? $url ), 180 ),
            );
        }

        return array_values( $links );
    }

    /**
     * Returns a compact user payload.
     *
     * @param int $user_id User ID.
     * @return array|null
     */

    protected static function prepare_user( $user_id ) {
        $user = get_user_by( 'id', absint( $user_id ) );

        if( ! $user ) {
            return null;
        }

        return array(
            'id' => (int) $user->ID,
            'name' => $user->display_name,
            'email' => $user->user_email,
            'avatar' => wphave_get_avatar_url( $user->ID, array( 'size' => 48 ) ),
        );
    }

    /**
     * Returns the meta query fragment for active notes.
     *
     * @return array
     */

    protected static function get_active_meta_query() {
        return array(
            'relation' => 'OR',
            array(
                'key' => self::META_ARCHIVED,
                'compare' => 'NOT EXISTS',
            ),
            array(
                'key' => self::META_ARCHIVED,
                'value' => '1',
                'compare' => '!=',
            ),
        );
    }

    /**
     * Builds a notes query from REST request filters.
     *
     * @param WP_REST_Request $request Current REST request.
     * @param bool $shared Whether to query notes shared with the current user.
     * @return array
     */

    protected static function get_query_args( WP_REST_Request $request, $shared = false ) {
        $user_id = get_current_user_id();
        $search = sanitize_text_field( (string) $request->get_param( 'search' ) );
        $status = sanitize_key( $request->get_param( 'status' ) ?: 'active' );
        $visibility = sanitize_key( $request->get_param( 'visibility' ) ?: 'all' );
        $page = max( 1, absint( $request->get_param( 'page' ) ?: 1 ) );
        $per_page = min( self::MAX_PER_PAGE, max( 1, absint( $request->get_param( 'per_page' ) ?: 24 ) ) );

        $meta_query = array( 'relation' => 'AND' );

        if( $status === 'archived' ) {
            $meta_query[] = array(
                'key' => self::META_ARCHIVED,
                'value' => '1',
                'compare' => '=',
            );
        } else if( $status === 'active' ) {
            $meta_query[] = self::get_active_meta_query();
        }

        if( in_array( $visibility, array( 'private', 'shared' ), true ) ) {
            $meta_query[] = array(
                'key' => self::META_VISIBILITY,
                'value' => $visibility,
                'compare' => '=',
            );
        }

        if( $shared ) {
            $meta_query[] = array(
                'key' => self::META_SHARED_USER_PREFIX . $user_id,
                'value' => '1',
                'compare' => '=',
            );
        }

        $args = array(
            'post_type' => self::POST_TYPE,
            'post_status' => array( 'publish', 'draft', 'private' ),
            'posts_per_page' => $per_page,
            'paged' => $page,
            's' => $search,
            'orderby' => array(
                'modified' => 'DESC',
            ),
            'meta_query' => $meta_query,
            'no_found_rows' => false,
        );

        if( ! $shared ) {
            $args['author'] = $user_id;
        }

        return $args;
    }

    /**
     * REST callback: returns notes readable by the current user.
     *
     * @param WP_REST_Request $request Current REST request.
     * @return WP_REST_Response|WP_Error
     */

    public static function get_notes( WP_REST_Request $request ) {
        if( ! self::current_user_can_access_notes() ) {
            return new WP_Error( 'wphave_notes_forbidden', __( 'You are not allowed to access notes.', 'wphave' ), array( 'status' => 403 ) );
        }

        $page = max( 1, absint( $request->get_param( 'page' ) ?: 1 ) );
        $per_page = min( self::MAX_PER_PAGE, max( 1, absint( $request->get_param( 'per_page' ) ?: 24 ) ) );

        $own_args = self::get_query_args( $request, false );
        $own_args['posts_per_page'] = -1;
        $own_args['paged'] = 1;
        $own_args['fields'] = 'ids';
        $own_args['no_found_rows'] = true;
        $own_query = new WP_Query( $own_args );

        $shared_args = self::get_query_args( $request, true );
        unset( $shared_args['author'] );
        $shared_args['posts_per_page'] = -1;
        $shared_args['paged'] = 1;
        $shared_args['fields'] = 'ids';
        $shared_args['no_found_rows'] = true;
        $shared_query = new WP_Query( $shared_args );

        $unique = array();
        $post_ids = array_merge( $own_query->posts, $shared_query->posts );

        foreach( $post_ids as $post_id ) {
            $post = get_post( $post_id );

            if( ! self::user_can_read_note( $post ) ) {
                continue;
            }

            $unique[ $post->ID ] = $post;
        }

        $posts = array_values( $unique );

        usort( $posts, function( $a, $b ) {
            $a_is_pinned = (bool) get_post_meta( $a->ID, self::META_PINNED, true );
            $b_is_pinned = (bool) get_post_meta( $b->ID, self::META_PINNED, true );

            if( $a_is_pinned !== $b_is_pinned ) {
                return $a_is_pinned ? -1 : 1;
            }

            return strcmp( $b->post_modified, $a->post_modified );
        } );

        $total = count( $posts );
        $offset = ( $page - 1 ) * $per_page;
        $items = array_map( array( __CLASS__, 'prepare_response' ), array_slice( $posts, $offset, $per_page ) );

		// AUTHORIZATION/TOCTOU INVARIANT: Query admission does not survive response
		// materialization. Meta reads, reply normalization, text rendering and avatar
		// resolution are extension boundaries; immediately before release, the caller
		// must still hold Notes access and exact read authority for every object that
		// contributes either content or the aggregate count.
		if ( ! self::current_user_can_access_notes() ) {
			return new WP_Error( 'wphave_notes_forbidden', __( 'You are not allowed to access notes.', 'wphave' ), array( 'status' => 403 ) );
		}

		foreach ( $posts as $post ) {
			if ( ! self::user_can_read_note( $post ) ) {
				return new WP_Error( 'wphave_notes_forbidden', __( 'You are not allowed to access notes.', 'wphave' ), array( 'status' => 403 ) );
			}
		}

        return rest_ensure_response( array(
            'items' => $items,
            'total' => $total,
            'totalPages' => (int) max( 1, ceil( $total / $per_page ) ),
        ) );
    }

    /**
     * REST callback: creates a new note owned by the current user.
     *
     * @param WP_REST_Request $request Current REST request.
     * @return WP_REST_Response|WP_Error
     */

    public static function create_note( WP_REST_Request $request ) {
        if( ! self::current_user_can_access_notes() ) {
            return new WP_Error( 'wphave_notes_forbidden', __( 'You are not allowed to create notes.', 'wphave' ), array( 'status' => 403 ) );
        }

        $title = self::sanitize_title( $request->get_param( 'title' ) ?: __( 'Untitled note', 'wphave' ) );
        $content = self::sanitize_content( $request->get_param( 'content' ) ?: '' );
        $visibility = sanitize_key( $request->get_param( 'visibility' ) ?: 'private' );
        $visibility = $visibility === 'shared' ? 'shared' : 'private';
        $shared_user_ids = self::get_shared_user_ids_from_request( $request );
        $visibility = $visibility === 'shared' && ! empty( $shared_user_ids ) ? 'shared' : 'private';

		// AUTHORIZATION/TOCTOU INVARIANT: Title, content and recipient normalization
		// cross WordPress filters and user-capability lookups. Complete all of them
		// before the final Notes capability check, then create no object if authority
		// changed while the request was being prepared.
		if ( ! self::current_user_can_access_notes() ) {
			return new WP_Error( 'wphave_notes_forbidden', __( 'You are not allowed to create notes.', 'wphave' ), array( 'status' => 403 ) );
		}

        $post_id = wp_insert_post( array(
            'post_type' => self::POST_TYPE,
            'post_status' => 'private',
            'post_title' => $title,
            'post_content' => $content,
            'post_author' => get_current_user_id(),
        ), true );

        if( is_wp_error( $post_id ) ) {
            return $post_id;
        }

        // AUTHORIZATION/COMMIT INVARIANT: A new note remains private until its
        // complete canonical recipient list and per-user query indexes commit.
        // Failed sharing state rolls back only this request-created note; partial
        // metadata is never published as a successful authorization projection.
        update_post_meta( $post_id, self::META_VISIBILITY, 'private' );
        if (
            'private' !== get_post_meta( $post_id, self::META_VISIBILITY, true )
            || ! self::update_shared_users( $post_id, $visibility === 'shared' ? $shared_user_ids : array() )
        ) {
            wp_delete_post( $post_id, true );

            return new WP_Error( 'wphave_notes_create_write_failed', __( 'The note could not be saved.', 'wphave' ), array( 'status' => 500 ) );
        }

        if ( 'shared' === $visibility ) {
            update_post_meta( $post_id, self::META_VISIBILITY, 'shared' );
            if ( 'shared' !== get_post_meta( $post_id, self::META_VISIBILITY, true ) ) {
                wp_delete_post( $post_id, true );

                return new WP_Error( 'wphave_notes_create_write_failed', __( 'The note could not be saved.', 'wphave' ), array( 'status' => 500 ) );
            }
        }

        update_post_meta( $post_id, self::META_PINNED, rest_sanitize_boolean( $request->get_param( 'isPinned' ) ) ? 1 : 0 );
        update_post_meta( $post_id, self::META_ARCHIVED, rest_sanitize_boolean( $request->get_param( 'isArchived' ) ) ? 1 : 0 );
        update_post_meta( $post_id, self::META_COLOR, sanitize_hex_color( (string) $request->get_param( 'color' ) ) ?: '' );
        update_post_meta( $post_id, self::META_UPDATED_BY, get_current_user_id() );
        update_post_meta( $post_id, self::META_LINKS, self::sanitize_links( self::get_request_value( $request, 'links', 'links', array() ) ) );
        update_post_meta( $post_id, self::META_ATTACHMENTS, self::sanitize_attachment_ids( self::get_request_value( $request, 'attachmentIds', 'attachment_ids', array() ) ) );

        return rest_ensure_response( self::prepare_response( $post_id ) );
    }

    /**
     * REST callback: updates a note when the current user owns it.
     *
     * @param WP_REST_Request $request Current REST request.
     * @return WP_REST_Response|WP_Error
     */

    public static function update_note( WP_REST_Request $request ) {
        $post_id = absint( $request['id'] );
        $post = get_post( $post_id );

        if( ! self::user_can_edit_note( $post ) ) {
            return new WP_Error( 'wphave_notes_forbidden', __( 'You are not allowed to edit this note.', 'wphave' ), array( 'status' => 403 ) );
        }

        $updates = array(
            'ID' => $post_id,
        );

        if( $request->has_param( 'title' ) ) {
            $updates['post_title'] = self::sanitize_title( $request->get_param( 'title' ) );
        }

        if( $request->has_param( 'content' ) ) {
            $updates['post_content'] = self::sanitize_content( $request->get_param( 'content' ) );
        }

		// AUTHORIZATION/TOCTOU INVARIANT: Title and content normalization cross
		// WordPress filters. Recheck ownership and current Notes capability for the
		// exact post after normalization and immediately before changing post fields.
		if ( ! self::user_can_edit_note( $post_id ) ) {
			return new WP_Error( 'wphave_notes_forbidden', __( 'You are not allowed to edit this note.', 'wphave' ), array( 'status' => 403 ) );
		}

        $result = wp_update_post( $updates, true );

        if( is_wp_error( $result ) ) {
            return $result;
        }

        if( $request->has_param( 'visibility' ) && ! self::request_has_shared_user_ids( $request ) ) {
			$requested_visibility = sanitize_key( $request->get_param( 'visibility' ) ) === 'shared'
				? 'shared'
				: 'private';

			// AUTHORIZATION/REVOCATION INVARIANT: A visibility-only transition is
			// successful only when its exact canonical value is readable. In particular,
			// a failed shared-to-private write must never tell the owner that existing
			// recipients lost access when the prior sharing state is still authoritative.
			update_post_meta( $post_id, self::META_VISIBILITY, $requested_visibility );
			if ( $requested_visibility !== get_post_meta( $post_id, self::META_VISIBILITY, true ) ) {
				return new WP_Error(
					'wphave_notes_visibility_write_failed',
					__( 'The note visibility could not be saved.', 'wphave' ),
					array( 'status' => 500 )
				);
			}
        }

        $visibility = get_post_meta( $post_id, self::META_VISIBILITY, true ) ?: 'private';

        if( self::request_has_shared_user_ids( $request ) ) {
			$requested_visibility = $request->has_param( 'visibility' )
				? sanitize_key( $request->get_param( 'visibility' ) )
				: $visibility;
            $shared_user_ids = 'shared' === $requested_visibility ? self::get_shared_user_ids_from_request( $request ) : array();

			// AUTHORIZATION/TOCTOU INVARIANT: Recipient validation invokes capability
			// checks for other users and may cross extension code. Recompute exact note
			// ownership and the caller's live Notes capability immediately before changing
			// visibility, canonical recipients or their query indexes.
			if ( ! self::user_can_edit_note( $post_id ) ) {
				return new WP_Error( 'wphave_notes_forbidden', __( 'You are not allowed to edit this note.', 'wphave' ), array( 'status' => 403 ) );
			}

			// AUTHORIZATION/COMMIT INVARIANT: Revocation is published first. The
			// note remains private throughout a failed recipient-list transition and
			// becomes shared only after the complete projection is verified.
			update_post_meta( $post_id, self::META_VISIBILITY, 'private' );
			if ( 'private' !== get_post_meta( $post_id, self::META_VISIBILITY, true ) ) {
				return new WP_Error( 'wphave_notes_sharing_write_failed', __( 'The note sharing settings could not be saved.', 'wphave' ), array( 'status' => 500 ) );
			}

			if ( ! self::update_shared_users( $post_id, $shared_user_ids ) ) {
				return new WP_Error( 'wphave_notes_sharing_write_failed', __( 'The note sharing settings could not be saved.', 'wphave' ), array( 'status' => 500 ) );
			}

			if ( $shared_user_ids ) {
				update_post_meta( $post_id, self::META_VISIBILITY, 'shared' );
				if ( 'shared' !== get_post_meta( $post_id, self::META_VISIBILITY, true ) ) {
					return new WP_Error( 'wphave_notes_sharing_write_failed', __( 'The note sharing settings could not be saved.', 'wphave' ), array( 'status' => 500 ) );
				}
			}
        } else if( $request->has_param( 'visibility' ) && $visibility !== 'shared' ) {
			if ( ! self::update_shared_users( $post_id, array() ) ) {
				return new WP_Error( 'wphave_notes_sharing_write_failed', __( 'The note sharing settings could not be saved.', 'wphave' ), array( 'status' => 500 ) );
			}
        } else if( $request->has_param( 'visibility' ) && $visibility === 'shared' && empty( self::get_shared_user_ids( $post_id ) ) ) {
            update_post_meta( $post_id, self::META_VISIBILITY, 'private' );
        }

        foreach( array(
            'isPinned' => self::META_PINNED,
            'isArchived' => self::META_ARCHIVED,
        ) as $param => $meta_key ) {
            if( $request->has_param( $param ) ) {
                update_post_meta( $post_id, $meta_key, rest_sanitize_boolean( $request->get_param( $param ) ) ? 1 : 0 );
            }
        }

        if( $request->has_param( 'color' ) ) {
            update_post_meta( $post_id, self::META_COLOR, sanitize_hex_color( (string) $request->get_param( 'color' ) ) ?: '' );
        }

        if( self::request_has_value( $request, 'links', 'links' ) ) {
			$links = self::sanitize_links( self::get_request_value( $request, 'links', 'links', array() ) );

			// AUTHORIZATION/TOCTOU INVARIANT: Link URL and label normalization cross
			// WordPress filters. Finish normalization before recomputing exact note
			// ownership and live Notes capability immediately before the metadata write.
			if ( ! self::user_can_edit_note( $post_id ) ) {
				return new WP_Error( 'wphave_notes_forbidden', __( 'You are not allowed to edit this note.', 'wphave' ), array( 'status' => 403 ) );
			}

			update_post_meta( $post_id, self::META_LINKS, $links );
        }

        if( self::request_has_value( $request, 'attachmentIds', 'attachment_ids' ) ) {
            update_post_meta( $post_id, self::META_ATTACHMENTS, self::sanitize_attachment_ids( self::get_request_value( $request, 'attachmentIds', 'attachment_ids', array() ) ) );
        }

        update_post_meta( $post_id, self::META_UPDATED_BY, get_current_user_id() );

        return rest_ensure_response( self::prepare_response( $post_id ) );
    }

    /**
     * REST callback: trashes a note when the current user owns it.
     *
     * @param WP_REST_Request $request Current REST request.
     * @return WP_REST_Response|WP_Error
     */

    public static function delete_note( WP_REST_Request $request ) {
        $post_id = absint( $request['id'] );
        $post = get_post( $post_id );

        if( ! self::user_can_edit_note( $post ) ) {
            return new WP_Error( 'wphave_notes_forbidden', __( 'You are not allowed to delete this note.', 'wphave' ), array( 'status' => 403 ) );
        }

        $deleted = wp_trash_post( $post_id );

        if( ! $deleted ) {
            return new WP_Error( 'wphave_notes_delete_failed', __( 'The note could not be deleted.', 'wphave' ), array( 'status' => 500 ) );
        }

        return rest_ensure_response( array(
            'deleted' => true,
            'id' => $post_id,
        ) );
    }

    /**
     * REST callback: returns users that can be selected for note sharing.
     *
     * @param WP_REST_Request $request Current REST request.
     * @return WP_REST_Response|WP_Error
     */

    public static function get_note_users( WP_REST_Request $request ) {
        if( ! self::current_user_can_access_notes() ) {
            return new WP_Error( 'wphave_notes_forbidden', __( 'You are not allowed to access users.', 'wphave' ), array( 'status' => 403 ) );
        }

        $search = sanitize_text_field( (string) $request->get_param( 'search' ) );
        $current_user_id = get_current_user_id();
        $users = get_users( array(
            'number' => 100,
            'exclude' => $current_user_id ? array( $current_user_id ) : array(),
            'search' => $search ? '*' . $search . '*' : '',
            'search_columns' => array( 'user_login', 'user_nicename', 'user_email', 'display_name' ),
            'orderby' => 'display_name',
            'order' => 'ASC',
            'fields' => array( 'ID', 'display_name', 'user_email' ),
        ) );
        $users = array_values( array_filter( $users, function( $user ) {
            return self::user_id_can_access_notes( $user->ID );
        } ) );

		$items = array_map( function( $user ) {
			return array(
				'id' => (int) $user->ID,
				'name' => $user->display_name,
				'email' => $user->user_email,
				'avatar' => wphave_get_avatar_url( $user->ID, array( 'size' => 48 ) ),
			);
		}, $users );

		// AUTHORIZATION/TOCTOU INVARIANT: User queries, capability filtering and
		// avatar resolution are extension boundaries. Recheck Notes authority only
		// after the complete catalog is materialized and immediately before releasing
		// user IDs and email addresses.
		if ( ! self::current_user_can_access_notes() ) {
			return new WP_Error( 'wphave_notes_forbidden', __( 'You are not allowed to access users.', 'wphave' ), array( 'status' => 403 ) );
		}

		return rest_ensure_response( array(
			'items' => $items,
		) );
    }

}
