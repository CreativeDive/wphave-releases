<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Bounded, non-persistent composition preview and fail-closed creation boundary. */
final class WPHAVE_AI_MCP_Write_Abilities {
	public static function register_category(): void {
		if ( self::available() && function_exists( 'wp_register_ability_category' ) ) {
			wp_register_ability_category( 'wphave-editor-create', array(
				'label' => __( 'WPHAVE Page Creation', 'wphave' ),
				'description' => __( 'Curated native page preparation and gated creation.', 'wphave' ),
			) );
		}
	}

	public static function register(): void {
		if ( ! self::available() ) {
			return;
		}

		$common = array(
			'category' => 'wphave-editor-create',
			'meta' => array(
				'public' => false,
				'show_in_rest' => false,
				'mcp' => array( 'public' => true ),
			),
			'input_schema' => array(
				'type' => 'object',
				'properties' => array(
					'title' => array( 'type' => 'string' ),
					'sections' => array( 'type' => 'array', 'items' => array( 'type' => 'object' ) ),
					'sources' => array( 'type' => 'object' ),
					'mediaIds' => array( 'type' => 'array', 'items' => array( 'type' => 'integer' ) ),
				),
				'required' => array( 'title', 'sections', 'sources' ),
				'additionalProperties' => false,
			),
			'permission_callback' => array( __CLASS__, 'can_prepare' ),
		);

		wp_register_ability( 'wphave/prepare-private-page', array_merge( $common, array(
			'label' => __( 'Prepare WPHAVE private page', 'wphave' ),
			'description' => __( 'Validate a bounded pattern composition without creating a post.', 'wphave' ),
			'execute_callback' => array( __CLASS__, 'prepare' ),
			'meta' => array_merge( $common['meta'], array(
				'annotations' => array( 'readonly' => true, 'idempotent' => true ),
			) ),
		) ) );

		$create_schema = $common['input_schema'];
		$create_schema['properties']['requestId'] = array( 'type' => 'string' );
		$create_schema['required'][] = 'requestId';
		wp_register_ability( 'wphave/create-private-page', array_merge( $common, array(
			'label' => __( 'Create WPHAVE private page', 'wphave' ),
			'description' => __( 'Create a non-public draft from independently editor-approved patterns.', 'wphave' ),
			'execute_callback' => array( __CLASS__, 'create' ),
			'permission_callback' => array( __CLASS__, 'can_create' ),
			'input_schema' => $create_schema,
			'meta' => array_merge( $common['meta'], array(
				'annotations' => array( 'readonly' => false, 'destructive' => false, 'idempotent' => true ),
			) ),
		) ) );
	}

	private static function available(): bool {
		return function_exists( 'wp_register_ability' ) &&
			function_exists( 'wphave_release_feature_ready' ) &&
			wphave_release_feature_ready( 'aiMcpWrite' );
	}

	public static function can_prepare(): bool {
		return self::available() && current_user_can( 'edit_pages' );
	}

	public static function can_create(): bool {
		return self::can_prepare() && wphave_release_feature_ready( 'aiMcpCreate' ) && current_user_can( 'publish_pages' );
	}

	public static function prepare( $input ) {
		if ( ! self::can_prepare() ) {
			return new WP_Error( 'wphave_mcp_forbidden', 'Page preparation is not permitted.' );
		}

		$plan = self::compose( $input );
		if ( is_wp_error( $plan ) ) {
			return $plan;
		}
		$reviewed = true;
		foreach ( $input['sections'] as $section ) {
			if ( is_wp_error( WPHAVE_Website_Plan_Pattern_Registry::resolve_for_external(
				$section['patternId'],
				$section['version'],
				$section['variation'] ?? ''
			) ) ) {
				$reviewed = false;
				break;
			}
		}

		return array(
			'status' => $reviewed ? 'reviewed_pattern' : 'approval_required',
			'structuralValidation' => 'passed',
			'editorDesignReview' => $reviewed ? 'verified' : 'not_verified',
			'persisted' => false,
			'contentFingerprint' => hash( 'sha256', $plan['content'] ),
			'sections' => $plan['sections'],
			'preview' => array(
				'title' => $plan['title'],
				'blockCount' => count( $plan['blocks'] ),
				'sections' => self::preview_sections( $input ),
			),
		);
	}

	private static function preview_sections( array $input ): array {
		$preview = array();
		foreach ( $input['sections'] as $section ) {
			$labels = array();
			foreach ( $section['bindings'] as $slot => $binding ) {
				$source_id = $binding['sourceId'] ?? '';
				$value = $input['sources'][ $source_id ] ?? null;
				if ( is_string( $value ) ) {
					$labels[ $slot ] = mb_substr( sanitize_text_field( $value ), 0, 120 );
				} elseif ( is_array( $value ) && is_string( $value['label'] ?? null ) ) {
					$labels[ $slot ] = mb_substr( sanitize_text_field( $value['label'] ), 0, 80 );
				} elseif ( is_int( $value ) ) {
					$labels[ $slot ] = 'media:' . $value;
				}
			}
			$preview[] = array(
				'sectionId' => $section['sectionId'],
				'patternId' => $section['patternId'],
				'slots' => $labels,
			);
		}
		return $preview;
	}

	public static function create( $input ) {
		if ( ! self::can_create() ) {
			return new WP_Error( 'wphave_mcp_forbidden', 'Private page creation is not permitted.' );
		}

		$plan = self::compose( $input );
		if ( is_wp_error( $plan ) ) {
			return $plan;
		}

		foreach ( $input['sections'] as $section ) {
			$resolved = WPHAVE_Website_Plan_Pattern_Registry::resolve_for_external(
				$section['patternId'],
				$section['version'],
				$section['variation'] ?? ''
			);
			if ( is_wp_error( $resolved ) ) {
				return $resolved;
			}
		}

		if ( ! self::can_create() ) {
			return new WP_Error( 'wphave_mcp_forbidden', 'Private page creation is not available.' );
		}
		return WPHAVE_AI_MCP_Create_Service::create( $input, $plan );
	}

	private static function compose( $input ) {
		if ( ! is_array( $input ) ||
			array_diff( array( 'title', 'sections', 'sources' ), array_keys( $input ) ) !== array() ||
			array_diff( array_keys( $input ), array( 'title', 'sections', 'sources', 'mediaIds', 'requestId' ) ) !== array() ) {
			return new WP_Error( 'wphave_mcp_input', 'The page request shape is invalid.' );
		}
		$title = $input['title'];
		$sections = $input['sections'];
		$sources = $input['sources'];
		$media_ids = $input['mediaIds'] ?? array();
		if ( ! is_string( $title ) || trim( $title ) === '' || mb_strlen( $title ) > 120 ||
			! is_array( $sections ) || count( $sections ) < 1 || count( $sections ) > 8 ||
			! is_array( $sources ) || count( $sources ) > 80 ||
			! is_array( $media_ids ) || count( $media_ids ) > 12 ||
			strlen( (string) wp_json_encode( $input ) ) > 20000 ) {
			return new WP_Error( 'wphave_mcp_input', 'The page request exceeds its bounds.' );
		}
		foreach ( $media_ids as $id ) {
			if ( ! is_int( $id ) || $id < 1 || ! wp_attachment_is_image( $id ) || ! current_user_can( 'read_post', $id ) ) {
				return new WP_Error( 'wphave_mcp_media', 'A requested media item is not available.' );
			}
		}

		WPHAVE_Website_Plan_Pattern_Registry::register_bundled();
		foreach ( $sections as $section ) {
			if ( ! is_array( $section ) || array_diff( array_keys( $section ), array( 'sectionId', 'patternId', 'version', 'variation', 'bindings' ) ) !== array() ||
				! is_string( $section['patternId'] ?? null ) || ! is_int( $section['version'] ?? null ) ||
				! is_array( $section['bindings'] ?? null ) ||
				( isset( $section['variation'] ) && ! is_string( $section['variation'] ) ) ) {
				return new WP_Error( 'wphave_mcp_section', 'A section contract is invalid.' );
			}
			$resolved = WPHAVE_Website_Plan_Pattern_Registry::resolve(
				$section['patternId'],
				$section['version'],
				$section['variation'] ?? ''
			);
			if ( is_wp_error( $resolved ) ) {
				return $resolved;
			}
			$composed = WPHAVE_Website_Plan_Pattern_Composer::compose(
				$section['patternId'],
				$section['version'],
				$section['bindings'],
				$sources,
				$media_ids,
				$section['variation'] ?? ''
			);
			if ( is_wp_error( $composed ) ) {
				return $composed;
			}
			$delta = WPHAVE_Website_Plan_Pattern_Approval::inspect_slot_delta( $resolved, $composed );
			if ( is_wp_error( $delta ) ) {
				return $delta;
			}
		}

		$page = WPHAVE_Website_Plan_Pattern_Page_Composer::compose( $sections, $sources, $media_ids );
		if ( is_wp_error( $page ) ) {
			return $page;
		}
		$valid = WPHAVE_AI_MCP_Final_Validator::validate( $page['blocks'], $page['content'] );
		if ( is_wp_error( $valid ) ) {
			return $valid;
		}
		$page['title'] = sanitize_text_field( $title );
		return $page;
	}
}
