<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/final-validator.php';
require_once __DIR__ . '/create-service.php';
require_once __DIR__ . '/write-abilities.php';
require_once dirname( __DIR__ ) . '/ai-mcp/server-factory.php';
require_once dirname( __DIR__ ) . '/planner/generation/pattern-registry.php';
require_once dirname( __DIR__ ) . '/planner/generation/pattern-composer.php';
require_once dirname( __DIR__ ) . '/planner/generation/pattern-page-composer.php';

add_action( 'wp_abilities_api_categories_init', array( 'WPHAVE_AI_MCP_Write_Abilities', 'register_category' ) );
add_action( 'wp_abilities_api_init', array( 'WPHAVE_AI_MCP_Write_Abilities', 'register' ) );
add_action( 'mcp_adapter_init', static function ( $adapter ): void {
	wphave_ai_mcp_register_server(
		$adapter,
		'wphave-preview-server',
		'WPHAVE Page Preview',
		array( 'wphave/prepare-private-page' )
	);
	if ( wphave_release_feature_ready( 'aiMcpCreate' ) ) {
		wphave_ai_mcp_register_server(
			$adapter,
			'wphave-create-server',
			'WPHAVE Draft Creation',
			array( 'wphave/create-private-page' )
		);
	}
} );
