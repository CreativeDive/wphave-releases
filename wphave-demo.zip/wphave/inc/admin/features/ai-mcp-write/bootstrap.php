<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/final-validator.php';
require_once __DIR__ . '/create-service.php';
require_once __DIR__ . '/write-abilities.php';
require_once dirname( __DIR__ ) . '/ai/task-catalog.php';
require_once dirname( __DIR__ ) . '/ai/page-workflow.php';
require_once dirname( __DIR__ ) . '/ai-mcp/server-factory.php';
require_once dirname( __DIR__ ) . '/page-composition/bootstrap.php';

add_action( 'wp_abilities_api_categories_init', array( 'WPHAVE_AI_MCP_Write_Abilities', 'register_category' ) );
add_action( 'wp_abilities_api_init', array( 'WPHAVE_AI_MCP_Write_Abilities', 'register' ) );
add_action( 'mcp_adapter_init', static function ( $adapter ): void {
	wphave_ai_mcp_register_server(
		$adapter,
		'wphave-preview-server',
		'WPHAVE Page Preview',
		WPHAVE_AI_MCP_Exposure_Contract::server_abilities( 'wphave-preview-server' )
	);
	if ( wphave_release_feature_ready( 'aiMcpCreate' ) ) {
		wphave_ai_mcp_register_server(
			$adapter,
			'wphave-create-server',
			'WPHAVE Draft Creation',
			WPHAVE_AI_MCP_Exposure_Contract::server_abilities( 'wphave-create-server' )
		);
	}
} );
