<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'page.prepare_pattern' => array(
		'family' => 'page',
		'familySummary' => 'Plan and preview individual website pages.',
		'intentId' => 'page.create',
		'id' => 'wphave/prepare-private-page',
		'effect' => 'page_proposal',
		'completionMode' => 'synchronous',
		'resultContract' => array(
			'kind' => 'page_proposal',
			'description' => 'A page proposal was prepared; no page was saved.',
		),
		'stages' => array( 'validate', 'preview' ),
	),
	'page.create_pattern' => array(
		'family' => 'page',
		'familySummary' => 'Plan and create individual website page drafts.',
		'intentId' => 'page.create',
		'id' => 'wphave/create-private-page',
		'effect' => 'private_page_draft',
		'completionMode' => 'synchronous',
		'resultContract' => array(
			'kind' => 'private_page_draft',
			'description' => 'A private page draft was saved; it was not published.',
		),
		'stages' => array( 'validate', 'create', 'review' ),
	),
);
