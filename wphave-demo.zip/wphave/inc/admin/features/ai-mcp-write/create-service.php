<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** InnoDB-only, create-once draft persistence for a validated MCP composition. */
final class WPHAVE_AI_MCP_Create_Service {
	private static function table(): string {
		global $wpdb;
		return $wpdb->prefix . 'wphave_mcp_create_ledger';
	}

	private static function engine_is_innodb( string $table ): bool {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SHOW TABLE STATUS WHERE Name = %s', $table ), ARRAY_A );
		return is_array( $row ) && strcasecmp( (string) ( $row['Engine'] ?? '' ), 'InnoDB' ) === 0;
	}

	private static function has_source_identity( string $table ): bool {
		global $wpdb;
		$column = $wpdb->get_var( $wpdb->prepare( 'SHOW COLUMNS FROM ' . $table . ' LIKE %s', 'source_identity' ) );
		$index = $wpdb->get_var( $wpdb->prepare( 'SHOW INDEX FROM ' . $table . ' WHERE Key_name=%s AND Non_unique=0', 'source_identity' ) );
		return null !== $column && null !== $index;
	}

	private static function ensure_schema(): bool {
		global $wpdb;
		if ( ! self::engine_is_innodb( $wpdb->posts ) || ! self::engine_is_innodb( $wpdb->postmeta ) ) {
			return false;
		}
		$table = self::table();
		if ( ! self::engine_is_innodb( $table ) || ! self::has_source_identity( $table ) ) {
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			$collate = $wpdb->get_charset_collate();
			dbDelta( "CREATE TABLE {$table} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				site_id bigint(20) unsigned NOT NULL,
				actor_id bigint(20) unsigned NOT NULL,
				request_id varchar(80) NOT NULL,
				source_identity varchar(80) DEFAULT NULL,
				payload_hash char(64) NOT NULL,
				status varchar(16) NOT NULL,
				post_id bigint(20) unsigned NOT NULL DEFAULT 0,
				created_at datetime NOT NULL,
				updated_at datetime NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY request_identity (site_id,actor_id,request_id),
				UNIQUE KEY source_identity (site_id,actor_id,source_identity)
			) ENGINE=InnoDB {$collate};" );
		}
		return self::engine_is_innodb( $table ) && self::has_source_identity( $table );
	}

	private static function canonicalize( $value ) {
		if ( ! is_array( $value ) ) {
			return $value;
		}
		if ( array_keys( $value ) !== range( 0, count( $value ) - 1 ) ) {
			ksort( $value, SORT_STRING );
		}
		foreach ( $value as $key => $item ) {
			$value[ $key ] = self::canonicalize( $item );
		}
		return $value;
	}

	public static function create( array $input, array $plan ) {
		return self::persist( $input, $plan, static function () use ( $input, $plan ) {
			return self::revalidate_before_insert( $input, $plan );
		} );
	}

	/** Shares the same create-once transaction with separately qualified native drafts. */
	public static function create_validated_draft( array $input, array $plan, callable $revalidate ) {
		if ( ! is_string( $plan['title'] ?? null ) || ! is_string( $plan['content'] ?? null ) ) {
			return new WP_Error( 'wphave_mcp_payload', 'The validated draft plan is invalid.' );
		}
		return self::persist( $input, $plan, $revalidate );
	}

	/** Confirm that the current actor created this still-private page through the ledger. */
	public static function owns_created_draft( int $post_id ): bool {
		global $wpdb;
		if ( $post_id < 1 || ! self::ensure_schema() ) {
			return false;
		}
		$row = $wpdb->get_row( $wpdb->prepare(
			'SELECT status FROM ' . self::table() . ' WHERE site_id=%d AND actor_id=%d AND post_id=%d',
			get_current_blog_id(),
			get_current_user_id(),
			$post_id
		), ARRAY_A );
		$post = get_post( $post_id );
		return is_array( $row ) && 'completed' === $row['status'] &&
			$post instanceof WP_Post && 'page' === $post->post_type &&
			'draft' === $post->post_status && current_user_can( 'edit_post', $post_id );
	}

	/** Finalize only a ledger-owned private draft at an exact expected content hash. */
	public static function finalize_owned_draft( int $post_id, string $expected_hash, string $content, callable $revalidate ) {
		global $wpdb;
		if ( $post_id < 1 || ! preg_match( '/^[a-f0-9]{64}$/', $expected_hash ) ||
			'' === $content || strlen( $content ) > 120000 || ! self::ensure_schema() ||
			! current_user_can( 'edit_post', $post_id ) ) {
			return new WP_Error( 'wphave_mcp_finalize_invalid', 'The private draft cannot be finalized.' );
		}
		if ( false === $wpdb->query( 'START TRANSACTION' ) ) {
			return new WP_Error( 'wphave_mcp_transaction_unavailable', 'Transactional page finalization is unavailable.' );
		}
		$site_id = get_current_blog_id();
		$actor_id = get_current_user_id();
		$ledger = $wpdb->get_row( $wpdb->prepare(
			'SELECT status FROM ' . self::table() . ' WHERE site_id=%d AND actor_id=%d AND post_id=%d FOR UPDATE',
			$site_id,
			$actor_id,
			$post_id
		), ARRAY_A );
		$post = $wpdb->get_row( $wpdb->prepare(
			"SELECT post_type,post_status,post_author,post_content FROM {$wpdb->posts} WHERE ID=%d FOR UPDATE",
			$post_id
		), ARRAY_A );
		if ( ! is_array( $ledger ) || 'completed' !== $ledger['status'] ||
			! is_array( $post ) || 'page' !== $post['post_type'] || 'draft' !== $post['post_status'] ||
			(int) $post['post_author'] !== $actor_id ) {
			$wpdb->query( 'ROLLBACK' );
			return new WP_Error( 'wphave_mcp_finalize_stale', 'The private draft changed.' );
		}
		$current_hash = hash( 'sha256', $post['post_content'] );
		$new_hash = hash( 'sha256', $content );
		if ( hash_equals( $new_hash, $current_hash ) ) {
			$wpdb->query( 'COMMIT' );
			return array( 'markupHash' => $new_hash, 'replayed' => true );
		}
		if ( ! hash_equals( $expected_hash, $current_hash ) ) {
			$wpdb->query( 'ROLLBACK' );
			return new WP_Error( 'wphave_mcp_finalize_conflict', 'The draft revision changed.' );
		}
		$valid = $revalidate();
		if ( is_wp_error( $valid ) || true !== $valid ) {
			$wpdb->query( 'ROLLBACK' );
			return is_wp_error( $valid ) ? $valid :
				new WP_Error( 'wphave_mcp_finalize_invalid', 'The linked draft is invalid.' );
		}
		$updated = wp_update_post( array(
			'ID' => $post_id,
			'post_content' => wp_slash( $content ),
		), true, false );
		$fresh = $wpdb->get_row( $wpdb->prepare(
			"SELECT post_type,post_status,post_author,post_content FROM {$wpdb->posts} WHERE ID=%d",
			$post_id
		), ARRAY_A );
		if ( is_wp_error( $updated ) || $updated !== $post_id || ! is_array( $fresh ) ||
			'page' !== $fresh['post_type'] || 'draft' !== $fresh['post_status'] ||
			(int) $fresh['post_author'] !== $actor_id ||
			! hash_equals( $new_hash, hash( 'sha256', $fresh['post_content'] ) ) ) {
			$wpdb->query( 'ROLLBACK' );
			clean_post_cache( $post_id );
			return new WP_Error( 'wphave_mcp_finalize_failed', 'The linked draft was not saved.' );
		}
		if ( false === $wpdb->query( 'COMMIT' ) ) {
			$wpdb->query( 'ROLLBACK' );
			clean_post_cache( $post_id );
			return new WP_Error( 'wphave_mcp_commit_uncertain', 'The link finalization outcome is uncertain.' );
		}
		clean_post_cache( $post_id );
		return array( 'markupHash' => $new_hash, 'replayed' => false );
	}

	private static function persist( array $input, array $plan, callable $revalidate ) {
		global $wpdb;
		$request_id = $input['requestId'] ?? null;
		$source_identity = $input['sourceIdentity'] ?? null;
		if ( ! is_string( $request_id ) || ! preg_match( '/^[A-Za-z0-9_-]{16,80}$/', $request_id ) ) {
			return new WP_Error( 'wphave_mcp_request_id', 'A stable request ID of 16 to 80 characters is required.' );
		}
		if ( null !== $source_identity && ( ! is_string( $source_identity ) || ! preg_match( '/^[A-Za-z0-9_-]{16,80}$/', $source_identity ) ) ) {
			return new WP_Error( 'wphave_mcp_source_identity', 'The source identity is invalid.' );
		}
		if ( ! self::ensure_schema() ) {
			return new WP_Error( 'wphave_mcp_transaction_unavailable', 'Transactional page creation is unavailable.' );
		}
		$payload = $input;
		unset( $payload['requestId'] );
		$canonical_payload = wp_json_encode( self::canonicalize( $payload ) );
		if ( ! is_string( $canonical_payload ) ) {
			return new WP_Error( 'wphave_mcp_payload', 'The request could not be fingerprinted.' );
		}
		$fingerprint = hash( 'sha256', $canonical_payload );
		$table = self::table();
		$site_id = get_current_blog_id();
		$actor_id = get_current_user_id();
		$now = current_time( 'mysql', true );

		if ( false === $wpdb->query( 'START TRANSACTION' ) ) {
			return new WP_Error( 'wphave_mcp_transaction_unavailable', 'Transactional page creation is unavailable.' );
		}
		$previous_suppression = $wpdb->suppress_errors( true );
		$claimed = $wpdb->insert( $table, array(
			'site_id' => $site_id,
			'actor_id' => $actor_id,
			'request_id' => $request_id,
			'source_identity' => $source_identity,
			'payload_hash' => $fingerprint,
			'status' => 'creating',
			'post_id' => 0,
			'created_at' => $now,
			'updated_at' => $now,
		), array( '%d', '%d', '%s', '%s', '%s', '%s', '%d', '%s', '%s' ) );
		$wpdb->suppress_errors( $previous_suppression );
		if ( 1 !== $claimed ) {
			$wpdb->query( 'ROLLBACK' );
			if ( null !== $source_identity ) {
				$existing_request = $wpdb->get_var( $wpdb->prepare(
					'SELECT request_id FROM ' . $table . ' WHERE site_id=%d AND actor_id=%d AND source_identity=%s',
					$site_id,
					$actor_id,
					$source_identity
				) );
				if ( is_string( $existing_request ) && $existing_request !== $request_id ) {
					return new WP_Error( 'wphave_mcp_source_conflict', 'This source already created a draft.' );
				}
			}
			return self::replay( $table, $site_id, $actor_id, $request_id, $fingerprint, $plan );
		}
		if ( self::test_fault( 'after_claim' ) ) {
			$wpdb->query( 'ROLLBACK' );
			return new WP_Error( 'wphave_mcp_test_fault', 'Test fault after ledger claim.' );
		}
		$rechecked = $revalidate();
		if ( is_wp_error( $rechecked ) ) {
			$wpdb->query( 'ROLLBACK' );
			return $rechecked;
		}

		try {
			$post_id = wp_insert_post( array(
				'post_type' => 'page',
				'post_status' => 'draft',
				'post_author' => $actor_id,
				'post_title' => wp_slash( $plan['title'] ),
				'post_content' => wp_slash( $plan['content'] ),
			), true, false );
			if ( is_wp_error( $post_id ) || ! is_int( $post_id ) || $post_id < 1 ) {
				$wpdb->query( 'ROLLBACK' );
				return new WP_Error( 'wphave_mcp_post_insert', 'The draft could not be created.' );
			}
			if ( self::test_fault( 'after_insert' ) ) {
				$wpdb->query( 'ROLLBACK' );
				return new WP_Error( 'wphave_mcp_test_fault', 'Test fault after draft insert.' );
			}
			if ( ! add_post_meta( $post_id, '_wphave_mcp_request_id', $request_id, true ) ||
				1 !== $wpdb->update( $table, array(
					'status' => 'completed',
					'post_id' => $post_id,
					'updated_at' => current_time( 'mysql', true ),
				), array( 'site_id' => $site_id, 'actor_id' => $actor_id, 'request_id' => $request_id ) ) ||
				! self::matches_post( $post_id, $actor_id, $plan['title'], $plan['content'] ) ) {
				$wpdb->query( 'ROLLBACK' );
				return new WP_Error( 'wphave_mcp_post_verify', 'The draft did not pass post-insert verification.' );
			}
			if ( false === $wpdb->query( 'COMMIT' ) ) {
				$wpdb->query( 'ROLLBACK' );
				return new WP_Error( 'wphave_mcp_commit_uncertain', 'The commit outcome is uncertain; retry with the same request ID.' );
			}
			return array( 'status' => 'created', 'postId' => $post_id, 'postStatus' => 'draft', 'replayed' => false );
		} catch ( Throwable $error ) {
			$wpdb->query( 'ROLLBACK' );
			return new WP_Error( 'wphave_mcp_post_exception', 'The draft transaction failed.' );
		}
	}

	private static function revalidate_before_insert( array $input, array $plan ) {
		if ( ! WPHAVE_AI_MCP_Write_Abilities::can_create() ) {
			return new WP_Error( 'wphave_mcp_forbidden', 'Draft creation is no longer permitted.' );
		}
		foreach ( $input['sections'] as $section ) {
			$resolved = WPHAVE_Website_Plan_Pattern_Registry::resolve_for_external(
				$section['patternId'],
				$section['version'],
				$section['variation'] ?? ''
			);
			if ( is_wp_error( $resolved ) ) {
				return $resolved;
			}
		}
		foreach ( $input['mediaIds'] ?? array() as $media_id ) {
			if ( ! wp_attachment_is_image( $media_id ) || ! current_user_can( 'read_post', $media_id ) ) {
				return new WP_Error( 'wphave_mcp_media', 'A requested media item is no longer available.' );
			}
		}
		return WPHAVE_AI_MCP_Final_Validator::validate( $plan['blocks'], $plan['content'] );
	}

	private static function test_fault( string $stage ): bool {
		return defined( 'WPHAVE_DISPOSABLE_TEST_SITE' ) && true === WPHAVE_DISPOSABLE_TEST_SITE &&
			apply_filters( 'wphave_mcp_create_test_fault', '', $stage ) === $stage;
	}

	private static function replay( string $table, int $site_id, int $actor_id, string $request_id, string $fingerprint, array $plan ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT payload_hash,status,post_id FROM {$table} WHERE site_id=%d AND actor_id=%d AND request_id=%s",
			$site_id,
			$actor_id,
			$request_id
		), ARRAY_A );
		if ( ! is_array( $row ) ) {
			return new WP_Error( 'wphave_mcp_retry_uncertain', 'The request state is uncertain; no new draft was created.' );
		}
		if ( ! hash_equals( (string) $row['payload_hash'], $fingerprint ) ) {
			return new WP_Error( 'wphave_mcp_request_conflict', 'The request ID belongs to a different payload.' );
		}
		$post_id = (int) $row['post_id'];
		if ( $row['status'] !== 'completed' || $post_id < 1 ||
			! self::matches_post( $post_id, $actor_id, $plan['title'], $plan['content'] ) ) {
			return new WP_Error( 'wphave_mcp_retry_uncertain', 'The request state is uncertain; no new draft was created.' );
		}
		return array( 'status' => 'created', 'postId' => $post_id, 'postStatus' => 'draft', 'replayed' => true );
	}

	private static function matches_post( int $post_id, int $actor_id, ?string $title, ?string $content ): bool {
		global $wpdb;
		$post = $wpdb->get_row( $wpdb->prepare(
			"SELECT post_type,post_status,post_author,post_title,post_content FROM {$wpdb->posts} WHERE ID=%d",
			$post_id
		), ARRAY_A );
		return is_array( $post ) && $post['post_type'] === 'page' && $post['post_status'] === 'draft' &&
			(int) $post['post_author'] === $actor_id &&
			( null === $title || $post['post_title'] === $title ) &&
			( null === $content || $post['post_content'] === $content );
	}
}
