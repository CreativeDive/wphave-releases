<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Validates the exact native block tree assembled for an external page request. */
final class WPHAVE_AI_MCP_Final_Validator {
	public static function validate( array $blocks, string $content ) {
		if ( $blocks === array() || ! self::walk( $blocks, array() ) ) {
			return new WP_Error( 'wphave_mcp_invalid_block_tree', 'The composed block tree is not valid for this WordPress registry.' );
		}

		$canonical = wphave_serialize_blocks_canonical( $blocks );
		if ( ! hash_equals( $canonical, $content ) ||
			! hash_equals( $canonical, wphave_serialize_blocks_canonical( parse_blocks( $canonical ) ) ) ) {
			return new WP_Error( 'wphave_mcp_roundtrip_failed', 'The composed blocks did not survive canonical serialization.' );
		}

		return true;
	}

	private static function walk( array $blocks, array $ancestors ): bool {
		$registry = WP_Block_Type_Registry::get_instance();
		foreach ( $blocks as $block ) {
			$name = $block['blockName'] ?? null;
			if ( ! is_string( $name ) || ! str_starts_with( $name, 'wphave/' ) ) {
				return false;
			}

			$type = $registry->get_registered( $name );
			if ( ! $type instanceof WP_Block_Type ) {
				return false;
			}

			$parent = $ancestors === array() ? null : $ancestors[ count( $ancestors ) - 1 ];
			if ( null !== $parent ) {
				$parent_type = $registry->get_registered( $parent );
				$allowed = $parent_type instanceof WP_Block_Type && property_exists( $parent_type, 'allowed_blocks' )
					? $parent_type->allowed_blocks
					: null;
				if ( is_array( $allowed ) && ! in_array( $name, $allowed, true ) ) {
					return false;
				}
			}
			if ( is_array( $type->parent ) && ! in_array( $parent, $type->parent, true ) ) {
				return false;
			}
			if ( is_array( $type->ancestor ) && array_intersect( $ancestors, $type->ancestor ) === array() ) {
				return false;
			}

			$attrs = $block['attrs'] ?? array();
			if ( ! is_array( $attrs ) || ! is_array( $type->attributes ) ) {
				return false;
			}
			foreach ( $attrs as $key => $value ) {
				if ( ! is_string( $key ) || ! array_key_exists( $key, $type->attributes ) ) {
					return false;
				}
				$schema = $type->attributes[ $key ];
				if ( ! is_array( $schema ) || is_wp_error( rest_validate_value_from_schema( $value, $schema, $key ) ) ) {
					return false;
				}
			}

			$children = $block['innerBlocks'] ?? array();
			if ( ! is_array( $children ) || ! self::walk( $children, array_merge( $ancestors, array( $name ) ) ) ) {
				return false;
			}
		}

		return true;
	}
}
