<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Reviewed direct MCP inventory; server lists and the policy share this source. */
final class WPHAVE_AI_MCP_Exposure_Contract {
	private const PLAN_ABILITIES = array(
		'wphave/website-plan-create',
		'wphave/website-plan-read',
		'wphave/website-plan-update',
	);
	private const READ = array(
		'wphave/site-info', 'wphave/list-pages', 'wphave/inspect-page',
		'wphave/prepare-private-page', 'wphave/free-page-status',
		'wphave/free-page-plan-content', 'wphave/free-page-plan-layout',
		'wphave/free-page-design-options', 'wphave/site-composition-inspect',
		'wphave/site-design-identity',
		'wphave/website-plan-read',
		'wphave/site-project-status', 'wphave/site-shell-header-status',
		'wphave/site-shell-footer-status', 'wphave/website-drafts-status',
		'wphave/website-shell-composition-status',
		'wphave/website-shell-composition-preview',
		'wphave/website-activation-prepare', 'wphave/website-activation-plan',
		'wphave/site-image-request-status', 'wphave/site-visual-screenshot',
		'wphave/site-visual-report',
	);

	private const WRITE = array(
		'wphave/create-private-page', 'wphave/free-page-prepare',
		'wphave/free-page-revise', 'wphave/site-project-create',
		'wphave/site-shell-header-prepare', 'wphave/site-shell-footer-prepare',
		'wphave/free-page-create-empty-draft', 'wphave/free-page-create-draft',
		'wphave/free-page-create-complete-draft', 'wphave/website-create-drafts',
		'wphave/website-shell-composition-prepare',
		'wphave/site-image-import', 'wphave/site-image-generate',
		'wphave/site-image-request-recover',
		'wphave/website-plan-create', 'wphave/website-plan-update',
	);

	public static function effect( string $ability ): ?string {
		if ( in_array( $ability, self::PLAN_ABILITIES, true ) && ! self::planner_available() ) {
			return null;
		}
		if ( in_array( $ability, self::READ, true ) ) {
			return 'read';
		}
		return in_array( $ability, self::WRITE, true ) ? 'write' : null;
	}

	public static function ability_ids(): array {
		$abilities = array_merge( self::READ, self::WRITE );
		if ( ! self::planner_available() ) {
			$abilities = array_values( array_diff( $abilities, self::PLAN_ABILITIES ) );
		}
		return $abilities;
	}

	private static function planner_available(): bool {
		return function_exists( 'wphave_planner_feature_enabled' ) &&
			function_exists( 'wphave_mcp_free_design_feature_enabled' ) &&
			wphave_planner_feature_enabled() &&
			wphave_mcp_free_design_feature_enabled();
	}

	public static function server_abilities( string $server, bool $free_create = true ): array {
		$servers = array(
			'wphave-read-server' => array(
				'wphave/site-info', 'wphave/list-pages', 'wphave/inspect-page',
			),
			'wphave-preview-server' => array( 'wphave/prepare-private-page' ),
			'wphave-create-server' => array( 'wphave/create-private-page' ),
			'wphave-free-design-server' => array(
				'wphave/free-page-plan-content', 'wphave/free-page-plan-layout',
				'wphave/free-page-create-empty-draft',
				'wphave/free-page-prepare', 'wphave/free-page-status',
				'wphave/free-page-revise', 'wphave/free-page-design-options',
				'wphave/site-design-identity',
				'wphave/site-composition-inspect', 'wphave/site-project-create',
				'wphave/site-project-status', 'wphave/site-shell-header-prepare',
				'wphave/site-shell-header-status', 'wphave/site-shell-footer-prepare',
				'wphave/site-shell-footer-status',
			),
			'wphave-free-create-server' => array(
				'wphave/free-page-create-draft', 'wphave/free-page-create-complete-draft',
				'wphave/website-create-drafts', 'wphave/website-drafts-status',
						'wphave/website-shell-composition-prepare',
				'wphave/website-shell-composition-status',
				'wphave/website-shell-composition-preview',
				'wphave/website-activation-prepare', 'wphave/website-activation-plan',
				'wphave/site-image-import', 'wphave/site-image-request-status',
				'wphave/site-image-request-recover', 'wphave/site-image-generate',
				'wphave/site-visual-screenshot', 'wphave/site-visual-report',
			),
		);
		if ( ! array_key_exists( $server, $servers ) ) {
			throw new InvalidArgumentException( 'Unknown WPHAVE MCP server.' );
		}
		$abilities = $servers[ $server ];
		if ( 'wphave-free-design-server' === $server && self::planner_available() ) {
			$abilities = array_merge( $abilities, self::PLAN_ABILITIES );
		}
		if ( 'wphave-free-design-server' === $server && $free_create ) {
			$abilities = array_merge( $abilities, self::server_abilities( 'wphave-free-create-server' ) );
			$abilities = array_values( array_diff( $abilities, array( 'wphave/free-page-create-draft' ) ) );
		}
		return $abilities;
	}
}
