<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** A short-lived signal from a successful call on the curated HTTP read server. */
add_filter( 'rest_request_after_callbacks', static function ( $response, $handler, $request ) {
	if ( '/mcp/wphave-read-server' !== $request->get_route() ||
		'tools/call' !== ( $request->get_json_params()['method'] ?? null ) ||
		is_wp_error( $response ) ||
		! current_user_can( 'edit_pages' ) ) {
		return $response;
	}

	$data = $response instanceof WP_REST_Response ? $response->get_data() : null;
	if ( $response instanceof WP_REST_Response &&
		$response->get_status() < 400 &&
		is_array( $data ) &&
		isset( $data['result'] ) &&
		is_array( $data['result'] ) &&
		! ( $data['result']['isError'] ?? false ) ) {
		set_transient( 'wphave_mcp_seen_' . get_current_user_id(), time(), 15 * MINUTE_IN_SECONDS );
	}

	return $response;
}, 10, 3 );

/** Read-only setup state. Never reports a client connection from server availability. */
add_action( 'rest_api_init', static function (): void {
	register_rest_route( 'wphave/v1', '/ai-mcp/setup', array(
		'methods' => 'GET',
		'permission_callback' => static fn(): bool => current_user_can( 'manage_options' ),
		'callback' => static function (): array {
			$adapter_ready = class_exists( \WP\MCP\Core\McpAdapter::class ) &&
				class_exists( \WP\MCP\Transport\HttpTransport::class );
			$read_ready = $adapter_ready && wphave_release_feature_ready( 'aiMcpRead' );
			$free_page_ready = $adapter_ready && wphave_mcp_free_design_feature_enabled();
			$free_create_available = $free_page_ready &&
				wphave_release_feature_ready( 'aiMcpFreeCreate' ) &&
				is_readable( wphave_dir() . 'build/ai-mcp-design-host/runner.cjs' );
			$local_codex_command = $free_page_ready ?
				'codex mcp add wphave_local_design -- wp --path=' . escapeshellarg( ABSPATH ) .
					' --user=' . get_current_user_id() .
					' mcp-adapter serve --server=wphave-free-design-server' : null;

			return array(
				'adapterReady' => $adapter_ready,
				'readReady' => $read_ready,
				'previewReady' => $adapter_ready && wphave_release_feature_ready( 'aiMcpWrite' ),
				'createReady' => $adapter_ready && wphave_release_feature_ready( 'aiMcpWrite' ) && wphave_release_feature_ready( 'aiMcpCreate' ),
				'freePageReady' => $free_page_ready,
				'freeCreateAvailable' => $free_create_available,
				'freeCreateEnabled' => $free_create_available && wphave_mcp_free_create_feature_enabled(),
				'designUrl' => $free_page_ready ? rest_url( 'mcp/wphave-free-design-server' ) : null,
				'localCodexCommand' => $local_codex_command,
				'readUrl' => $read_ready ? rest_url( 'mcp/wphave-read-server' ) : null,
				'profileUrl' => admin_url( 'profile.php' ),
				'recentMcpCall' => $read_ready && (bool) get_transient( 'wphave_mcp_seen_' . get_current_user_id() ),
			);
		},
	) );
	register_rest_route( 'wphave/v1', '/ai-mcp/free-create-enabled', array(
		'methods' => 'POST',
		'permission_callback' => static fn(): bool => current_user_can( 'manage_options' ),
		'args' => array(
			'enabled' => array( 'required' => true, 'type' => 'boolean' ),
		),
		'callback' => static function ( WP_REST_Request $request ) {
			if ( ! wphave_mcp_free_design_feature_enabled() ||
				! wphave_release_feature_ready( 'aiMcpFreeCreate' ) ||
				! is_readable( wphave_dir() . 'build/ai-mcp-design-host/runner.cjs' ) ) {
				return new WP_Error( 'wphave_mcp_free_create_unavailable', 'Direct native draft creation is unavailable.', array( 'status' => 409 ) );
			}
			$enabled = true === $request->get_param( 'enabled' );
			update_option( 'wphave_mcp_free_create_enabled', $enabled ? '1' : '0', false );
			return array( 'enabled' => wphave_mcp_free_create_feature_enabled() );
		},
	) );
} );
