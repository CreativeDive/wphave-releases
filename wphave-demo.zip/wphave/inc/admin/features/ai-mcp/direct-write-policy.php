<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/exposure-contract.php';

/** Explicit WPHAVE MCP exposure policy, checked again at the adapter call boundary. */
final class WPHAVE_AI_MCP_Direct_Write_Policy {
	private static array $trusted = array();

	public static function allowed( $ability ): bool {
		$name = $ability->get_name();
		$annotations = $ability->get_meta_item( 'annotations', array() );
		$schema = $ability->get_input_schema();
		if ( 'read' === WPHAVE_AI_MCP_Exposure_Contract::effect( $name ) ) {
			return true === ( $annotations['readonly'] ?? null ) &&
				true !== ( $annotations['destructive'] ?? false );
		}
		return 'write' === WPHAVE_AI_MCP_Exposure_Contract::effect( $name ) &&
			false === ( $annotations['readonly'] ?? null ) &&
			false === ( $annotations['destructive'] ?? null ) &&
			true === ( $annotations['idempotent'] ?? null ) &&
			is_array( $schema ) &&
			in_array( 'requestId', $schema['required'] ?? array(), true );
	}

	/** Snapshot the actual WPHAVE registrations before the adapter starts. */
	public static function capture(): void {
		if ( ! function_exists( 'wp_get_abilities' ) ) {
			return;
		}
		foreach ( wp_get_abilities() as $ability ) {
			$name = $ability->get_name();
			$mcp = $ability->get_meta_item( 'mcp', array() );
			if ( str_starts_with( $name, 'wphave/' ) && true === ( $mcp['public'] ?? false ) &&
				self::allowed( $ability ) ) {
				self::$trusted[ $name ] = $ability;
			}
		}
		self::enforce();
	}

	/** Fail closed before adapter discovery, including its default server. */
	public static function enforce(): void {
		if ( ! function_exists( 'wp_get_abilities' ) || ! function_exists( 'wp_unregister_ability' ) ) {
			return;
		}
		foreach ( wp_get_abilities() as $ability ) {
			$name = $ability->get_name();
			$mcp = $ability->get_meta_item( 'mcp', array() );
			if ( ! str_starts_with( $name, 'wphave/' ) || true !== ( $mcp['public'] ?? false ) ) {
				continue;
			}
			if ( ! self::allowed( $ability ) || ! isset( self::$trusted[ $name ] ) ||
				self::$trusted[ $name ] !== $ability ) {
				wp_unregister_ability( $name );
			}
		}
	}

	private static function exposed( string $name ): bool {
		$ability = function_exists( 'wp_get_ability' ) ? wp_get_ability( $name ) : null;
		if ( ! $ability ) {
			return false;
		}
		$mcp = $ability->get_meta_item( 'mcp', array() );
		return true === ( $mcp['public'] ?? false ) && self::allowed( $ability ) &&
			isset( self::$trusted[ $name ] ) && self::$trusted[ $name ] === $ability;
	}

	/** Adapter tools may have been cached before a late ability registration. */
	public static function before_tool_call( $args, $tool_name, $tool ) {
		self::enforce();
		$metadata = is_object( $tool ) && method_exists( $tool, 'get_adapter_meta' ) ?
			$tool->get_adapter_meta() : array();
		$ability = $metadata['ability'] ?? null;
		if ( is_string( $ability ) && str_starts_with( $ability, 'wphave/' ) && ! self::exposed( $ability ) ) {
			return new WP_Error( 'wphave_mcp_ability_blocked', 'This WPHAVE ability is not approved for direct MCP exposure.' );
		}
		if ( is_string( $tool_name ) && str_starts_with( $tool_name, 'wphave-' ) &&
			( ! is_string( $ability ) || ! str_starts_with( $ability, 'wphave/' ) ) ) {
			return new WP_Error( 'wphave_mcp_tool_blocked', 'This WPHAVE tool is not ability-backed.' );
		}
		if ( is_array( $args ) ) {
			$target = $args['ability_name'] ?? null;
			if ( is_string( $target ) && str_starts_with( $target, 'wphave/' ) && ! self::exposed( $target ) ) {
				return new WP_Error( 'wphave_mcp_ability_blocked', 'This WPHAVE ability is not approved for direct MCP exposure.' );
			}
		}
		return $args;
	}

	public static function visible_tools( $tools, $server ) {
		self::enforce();
		if ( ! is_array( $tools ) || ! is_object( $server ) || ! method_exists( $server, 'get_mcp_tool' ) ) {
			return array();
		}
		return array_values( array_filter( $tools, static function ( $record ) use ( $server ): bool {
			if ( ! is_object( $record ) || ! method_exists( $record, 'getName' ) ) {
				return false;
			}
			$name = $record->getName();
			$tool = $server->get_mcp_tool( $name );
			$metadata = is_object( $tool ) && method_exists( $tool, 'get_adapter_meta' ) ?
				$tool->get_adapter_meta() : array();
			$ability = $metadata['ability'] ?? null;
			if ( is_string( $ability ) && str_starts_with( $ability, 'wphave/' ) ) {
				return self::exposed( $ability );
			}
			return ! str_starts_with( $name, 'wphave-' ) || is_string( $ability );
		} ) );
	}
}

add_action( 'wp_abilities_api_init', array( WPHAVE_AI_MCP_Direct_Write_Policy::class, 'capture' ), PHP_INT_MAX );
add_action( 'mcp_adapter_init', array( WPHAVE_AI_MCP_Direct_Write_Policy::class, 'enforce' ), -1000 );
add_filter( 'mcp_adapter_tools_list', array( WPHAVE_AI_MCP_Direct_Write_Policy::class, 'visible_tools' ), PHP_INT_MAX, 2 );
add_filter( 'mcp_adapter_pre_tool_call', array( WPHAVE_AI_MCP_Direct_Write_Policy::class, 'before_tool_call' ), PHP_INT_MAX, 3 );
