<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Register a narrowly scoped, ability-backed server with the optional adapter. */
function wphave_ai_mcp_register_server( $adapter, string $id, string $name, array $abilities ): void {
	if ( ! $adapter instanceof \WP\MCP\Core\McpAdapter ||
		! class_exists( \WP\MCP\Transport\HttpTransport::class ) ) {
		return;
	}

	$adapter->create_server(
		$id,
		'mcp',
		$id,
		$name,
		'WPHAVE abilities with operation-specific MCP tool annotations.',
		'v1.0.0',
		array( \WP\MCP\Transport\HttpTransport::class ),
		null,
		null,
		$abilities
	);
}
