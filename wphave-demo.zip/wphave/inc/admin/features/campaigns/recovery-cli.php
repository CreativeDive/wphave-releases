<?php
/** Server-side recovery operations, intentionally absent from public REST. */
if (!defined('WP_CLI') || !WP_CLI) {
	return;
}
WP_CLI::add_command('wphave campaigns recovery', static function (array $args, array $assoc): void {
	$action = $args[0] ?? 'status';
	$id = (string) ($assoc['restore'] ?? '');
	if ('status' === $action) {
		$result = WPHAVE_Campaigns_Authority::run(
			static fn() => WPHAVE_Campaigns_Authority::current()
		);
		if (is_wp_error($result)) {
			WP_CLI::error($result->get_error_message());
		}
		WP_CLI::line(
			wp_json_encode(['restore' => $result['restore'], 'ready' => $result['ready']])
		);
		return;
	}
	if (
		!in_array($action, ['acknowledge', 'recover-failed'], true) ||
		!isset($assoc['reviewed']) ||
		'' === $id
	) {
		WP_CLI::error(
			'Use status, acknowledge --restore=ID --reviewed or recover-failed --restore=ID --reviewed. Review delivery history, opt-outs and site recovery before acknowledging.'
		);
	}
	if ('recover-failed' === $action) {
		require_once __DIR__ . '/../backup/runtime.php';
		WPHAVE_Backup_Runtime::load_worker();
		$restore = WPHAVE_Backup_Storage::read_full_restore_state($id);
		// RECOVERY INVARIANT: Manual failure recovery cannot unlock a running job.
		// --reviewed explicitly attests operator repair of any unsuccessful rollback.
		if ('failed' !== ($restore['status'] ?? '')) {
			WP_CLI::error('Only a failed restore can be recovered this way.');
		}
		WPHAVE_Campaigns_Authority::finish_restore($id);
	}
	$result = WPHAVE_Campaigns_Authority::acknowledge($id);
	if (is_wp_error($result)) {
		WP_CLI::error($result->get_error_message());
	}
	WP_CLI::success('New mailings are enabled. Restored campaigns remain unauthorized.');
});
WP_CLI::add_command('wphave campaigns unsubscribe-keys', static function (
	array $args,
	array $assoc
): void {
	try {
		$action = $args[0] ?? '';
		$path = $assoc['file'] ?? '';
		if ('rotate' === $action) {
			WPHAVE_Campaigns_Unsubscribe_Tokens::rotate();
		} elseif (
			in_array($action, ['export', 'import'], true) &&
			is_string($path) &&
			str_starts_with($path, '/')
		) {
			if ('export' === $action) {
				WPHAVE_Campaigns_Unsubscribe_Tokens::export_to($path);
			} else {
				WPHAVE_Campaigns_Unsubscribe_Tokens::import_from($path);
			}
		} else {
			throw new RuntimeException(
				'Use rotate, export --file=/private/new.php or import --file=/private/saved.php.'
			);
		}
		WP_CLI::success('Unsubscribe keys updated. Keep an independent private off-host export.');
	} catch (Throwable $error) {
		WP_CLI::error($error->getMessage());
	}
});
