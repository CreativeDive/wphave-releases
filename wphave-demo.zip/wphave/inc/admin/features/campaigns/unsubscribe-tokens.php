<?php
/** Durable, purpose-limited unsubscribe grants; login salts do not own their lifetime. */
if (!defined('ABSPATH')) {
	exit();
}
require_once __DIR__ . '/../../../data/operational-state.php';

final class WPHAVE_Campaigns_Unsubscribe_Tokens {
	private const STORE = 'campaign-unsubscribe-keys';

	private static function keys(): array {
		$ring = WPHAVE_Operational_State::read(self::STORE);
		if (null === $ring) {
			$ring = [
				'version' => 1,
				'keys' => [bin2hex(random_bytes(32))]
			];
			WPHAVE_Operational_State::write(self::STORE, $ring);
		}
		self::validate($ring);
		return $ring;
	}

	private static function validate($ring): void {
		if (
			!is_array($ring) ||
			1 !== ($ring['version'] ?? null) ||
			!is_array($ring['keys'] ?? null) ||
			!$ring['keys'] ||
			array_diff(array_keys($ring), ['version', 'keys']) !== [] ||
			!array_is_list($ring['keys']) ||
			count($ring['keys']) > 32
		) {
			throw new RuntimeException('Invalid unsubscribe key ring.');
		}
		foreach ($ring['keys'] as $key) {
			if (!is_string($key) || !preg_match('/^[a-f0-9]{64}$/', $key)) {
				throw new RuntimeException('Invalid unsubscribe key.');
			}
		}
	}

	public static function url(string $email, string $purpose): string {
		global $wpdb;
		return WPHAVE_Operational_State::run(self::STORE, static function () use (
			$email,
			$purpose,
			$wpdb
		): string {
			$ring = self::keys();
			// WIRE INVARIANT: Base64url is unchanged by WordPress query parsing; sign exactly the received bytes.
			$payload = rtrim(
				strtr(
					base64_encode(
						wp_json_encode([
							'version' => 2,
							'site' => hash('sha256', $wpdb->prefix),
							'email' => $email,
							'purpose' => $purpose
						])
					),
					'+/',
					'-_'
				),
				'='
			);

			$signature = hash_hmac(
				'sha256',
				'campaign-unsubscribe:v2:' . $payload,
				$ring['keys'][0]
			);
			// GRANT INVARIANT: This permanent token authorizes only suppression.
			// It cannot subscribe, authenticate, reveal data or execute another action.
			return add_query_arg(
				['payload' => $payload, 'signature' => $signature],
				rest_url('wphave/v1/campaigns/unsubscribe')
			);
		});
	}

	public static function verify(string $payload, string $signature): array|WP_Error {
		global $wpdb;
		$invalid = new WP_Error(
			'wphave_campaign_unsubscribe_invalid',
			__('The unsubscribe link is invalid.', 'wphave'),
			['status' => 400]
		);
		if (
			strlen($payload) > 4096 ||
			!preg_match('/^[A-Za-z0-9_-]+$/', $payload) ||
			!preg_match('/^[a-f0-9]{64}$/', $signature)
		) {
			return $invalid;
		}
		$decoded = base64_decode(strtr($payload, '-_', '+/'), true);
		$data = is_string($decoded) ? json_decode($decoded, true) : null;
		if (
			!is_array($data) ||
			!is_string($data['email'] ?? null) ||
			!is_email($data['email']) ||
			!is_string($data['purpose'] ?? null)
		) {
			return $invalid;
		}
		try {
			return WPHAVE_Operational_State::run(self::STORE, static function () use (
				$payload,
				$signature,
				$data,
				$invalid,
				$wpdb
			) {
				$ring = self::keys();
				// TOKEN INVARIANT: Only the current domain-separated, site-bound grant is valid.
				if (
					2 !== ($data['version'] ?? null) ||
					($data['site'] ?? '') !== hash('sha256', $wpdb->prefix)
				) {
					return $invalid;
				}
				foreach ($ring['keys'] as $key) {
					if (
						hash_equals(
							hash_hmac('sha256', 'campaign-unsubscribe:v2:' . $payload, $key),
							$signature
						)
					) {
						return $data;
					}
				}
				return $invalid;
			});
		} catch (RuntimeException $error) {
			return new WP_Error(
				'wphave_campaign_unsubscribe_unavailable',
				__('Unsubscribe verification is temporarily unavailable. Please retry.', 'wphave'),
				['status' => 503]
			);
		}
	}

	public static function rotate(): void {
		WPHAVE_Operational_State::run(self::STORE, static function (): void {
			$ring = self::keys();
			array_unshift($ring['keys'], bin2hex(random_bytes(32)));
			self::validate($ring);
			// RETENTION INVARIANT: Rotation never invalidates mail already delivered.
			WPHAVE_Operational_State::write(self::STORE, $ring);
		});
	}

	public static function export_to(string $path): void {
		WPHAVE_Operational_State::run(self::STORE, static function () use ($path): void {
			$ring = self::keys();
			WPHAVE_Security_Atomic_File::write_new(
				$path,
				"<?php exit; ?>\n" . wp_json_encode($ring),
				'Unsubscribe keys could not be exported.'
			);
		});
	}

	public static function import_from(string $path): void {
		$file = WPHAVE_Security_File_Identity::read_bounded(
			$path,
			65537,
			false,
			'Unsubscribe keys could not be read.'
		);
		if (
			strlen($file['content']) > 65536 ||
			!str_starts_with($file['content'], "<?php exit; ?>\n")
		) {
			throw new RuntimeException('Invalid key export.');
		}
		$imported = json_decode(substr($file['content'], 14), true);
		self::validate($imported);
		WPHAVE_Operational_State::run(self::STORE, static function () use ($imported): void {
			$ring = WPHAVE_Operational_State::read(self::STORE) ?? $imported;
			self::validate($ring);
			$ring['keys'] = array_values(
				array_unique(array_merge($ring['keys'], $imported['keys']))
			);
			self::validate($ring);
			WPHAVE_Operational_State::write(self::STORE, $ring);
		});
	}
}
