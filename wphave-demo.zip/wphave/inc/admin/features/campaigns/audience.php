<?php

/**
 * Deliverable Audience projections and immutable campaign snapshots.
 *
 * @package wphave
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WPHAVE_Campaigns_Audience {
	/** Return a stable site-scoped email hash without persisting raw addresses elsewhere. */
	public static function email_hash( string $email ): string {
		return hash_hmac( 'sha256', strtolower( sanitize_email( $email ) ), wp_salt( 'wphave-campaigns' ) );
	}

	/**
	 * Resolve confirmed, consented subscribers for a bounded segment.
	 *
	 * Supported filters intentionally map to indexed Audience columns.
	 */
	public static function recipients(array $segment): array {
		global $wpdb;

		$table = $wpdb->prefix . 'wphave_audience_subscribers';
		if (
			$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table))) !==
			$table
		) {
			return [];
		}

		$where = ["status = 'subscribed'", 'consent = 1', 'confirmed_at IS NOT NULL'];
		$values = [];
		foreach (['purpose', 'source', 'campaign'] as $field) {
			if (empty($segment[$field])) {
				continue;
			}
			$where[] = "{$field} = %s";
			$values[] = sanitize_text_field($segment[$field]);
		}

		$sql =
			"SELECT id, email, first_name, last_name, purpose, consent_at FROM {$table} WHERE " .
			implode(' AND ', $where) .
			' ORDER BY id ASC';
		if ($values) {
			$sql = $wpdb->prepare($sql, ...$values);
		}

		$rows = $wpdb->get_results($sql, ARRAY_A);
		return array_values(
			array_filter(
				array_map(static function (array $row): array {
					$row['email'] = sanitize_email($row['email']);
					$row['email_hash'] = self::email_hash($row['email']);
					return $row;
				}, $rows),
				static fn(array $row): bool => (bool) $row['email'] &&
					!WPHAVE_Campaigns_Repository::is_suppressed($row['email_hash'], $row['email'])
			)
		);
	}
}
