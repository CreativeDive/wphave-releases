<?php

/** Accessible plain-text alternative generation. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WPHAVE_Campaigns_Plain_Text {
	public static function from_html( string $html ): string {
		$html = preg_replace_callback(
			'/<a\s[^>]*href=("|\')(.*?)\1[^>]*>(.*?)<\/a>/is',
			static function ( array $match ): string {
				$label = trim( wp_strip_all_tags( $match[3] ) );
				$url = esc_url_raw( html_entity_decode( $match[2], ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
				return $label && $url ? $label . ' (' . $url . ')' : $label;
			},
			$html
		);
		$html = preg_replace( '/<\/(p|div|h[1-6]|li|tr|blockquote)>/i', "\n\n", (string) $html );
		$html = preg_replace( '/<br\s*\/?>/i', "\n", (string) $html );
		$text = html_entity_decode( wp_strip_all_tags( (string) $html ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$text = preg_replace( "/[ \t]+\n/", "\n", $text );
		$text = preg_replace( "/\n{3,}/", "\n\n", (string) $text );

		return trim( (string) $text );
	}
}
