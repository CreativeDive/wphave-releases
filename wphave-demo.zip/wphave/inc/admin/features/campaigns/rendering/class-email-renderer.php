<?php

/** Canonical renderer shared by preview, tests and production delivery. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WPHAVE_Campaigns_Email_Renderer {
	public const ARTIFACT_VERSION = 1;

	/** Render and sign an immutable, recipient-neutral artifact. */
	public static function artifact( array $campaign, ?string $content_override = null ) {
		$source = self::source( $campaign, $content_override );
		if ( is_wp_error( $source ) ) {
			return $source;
		}

		$content = WPHAVE_Campaigns_Email_Sanitizer::sanitize( $source['html'] );
		if ( '' === trim( wp_strip_all_tags( $content ) ) && false === stripos( $content, '<img' ) ) {
			return new WP_Error( 'wphave_campaign_empty_content', __( 'Mailing content is required.', 'wphave' ), array( 'status' => 400 ) );
		}

		$html = WPHAVE_Campaigns_Email_Template::render(
			$content,
			array_merge(
				$campaign['config'],
				array(
					'document_wrapped' => 'document' === $source['type'],
					'document_settings' => $source['settings'] ?? array(),
				)
			)
		);
		$artifact = array(
			'version' => self::ARTIFACT_VERSION,
			'source' => $source['type'],
			'subject' => sanitize_text_field( $campaign['config']['subject'] ?? '' ),
			'html' => $html,
			'text' => $source['text'] ?: WPHAVE_Campaigns_Plain_Text::from_html( $html ),
			'created_at' => current_time( 'mysql', true ),
		);
		$artifact['hash'] = self::hash( $artifact );

		return $artifact;
	}

	/** Verify that persisted output still matches the prepared bytes. */
	public static function verify( array $artifact ): bool {
		// DATA INTEGRITY INVARIANT: Queue workers may personalize only the exact
		// recipient-neutral artifact frozen by the preparing process. Persisted HTML,
		// text or metadata changed afterward invalidates the complete artifact.
		return self::ARTIFACT_VERSION === (int) ( $artifact['version'] ?? 0 )
			&& isset( $artifact['hash'] )
			&& hash_equals( (string) $artifact['hash'], self::hash( $artifact ) );
	}

	/** Personalize an artifact without changing its frozen structure. */
	public static function message( array $campaign, array $recipient, array $artifact ): array|WP_Error {
		if ( ! self::verify( $artifact ) ) {
			return new WP_Error( 'wphave_campaign_artifact_invalid', __( 'The prepared email artifact is missing or invalid.', 'wphave' ) );
		}

		$merge = json_decode( (string) ( $recipient['merge_data'] ?? '{}' ), true );
		$merge = is_array( $merge ) ? $merge : array();
		$unsubscribe = $recipient['unsubscribe_url'] ?? WPHAVE_Campaigns_Service::unsubscribe_url( (string) $recipient['email'], $campaign['config']['purpose'] ?? 'newsletter' );
		$plain = array(
			'{{first_name}}' => sanitize_text_field( $merge['first_name'] ?? '' ),
			'{{last_name}}' => sanitize_text_field( $merge['last_name'] ?? '' ),
			'{{unsubscribe_url}}' => esc_url_raw( $unsubscribe ),
		);
		$html = array_map( 'esc_html', $plain );
		$html['{{unsubscribe_url}}'] = esc_url( $unsubscribe );

		return array(
			'to' => sanitize_email( $recipient['email'] ?? '' ),
			'subject' => strtr( $artifact['subject'], $plain ),
			'html' => strtr( $artifact['html'], $html ),
			'text' => strtr( $artifact['text'], $plain ),
			'from_name' => $campaign['config']['from_name'] ?? '',
			'from_email' => $campaign['config']['from_email'] ?? '',
			'reply_to' => $campaign['config']['reply_to'] ?? '',
			'headers' => array(
				'List-Unsubscribe: <' . esc_url_raw( $unsubscribe ) . '>',
				'List-Unsubscribe-Post: List-Unsubscribe=One-Click',
			),
		);
	}

	private static function source( array $campaign, ?string $content_override ) {
		$post_id = (int) ( $campaign['id'] ?? 0 );
		$post_type = get_post_type( $post_id );
		if (
			$post_type
			&& class_exists( 'WPHAVE_Documents_Storage' )
			&& WPHAVE_Documents_Storage::supports( $post_type )
			&& metadata_exists( 'post', $post_id, WPHAVE_Documents_Storage::META_KEY )
		) {
			$document = WPHAVE_Documents_Storage::get( $post_id );
			if ( is_wp_error( $document ) ) {
				return $document;
			}
			$html = wphave_render_document(
				$document,
				'email',
				array(
					'campaign_id' => $post_id,
					'mailingDesign' => $campaign['config']['design'] ?? array(),
				)
			);
			$text = wphave_render_document( $document, 'plain-text', array( 'campaign_id' => $post_id ) );
			if ( is_wp_error( $html ) || is_wp_error( $text ) ) {
				return is_wp_error( $html ) ? $html : $text;
			}
			return array(
				'type' => 'document',
				'html' => $html,
				'text' => $text,
				'settings' => $document['settings'] ?? array(),
			);
		}

		return array( 'type' => 'html', 'html' => null === $content_override ? (string) ( $campaign['content'] ?? '' ) : $content_override, 'text' => '' );
	}

	private static function hash( array $artifact ): string {
		unset( $artifact['hash'] );
		return hash_hmac( 'sha256', wp_json_encode( $artifact, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ), wp_salt( 'wphave-campaign-artifact' ) );
	}
}
