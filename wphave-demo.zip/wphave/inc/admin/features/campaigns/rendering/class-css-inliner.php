<?php

/** Deterministic inliner for WPHAVE-owned email template styles. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WPHAVE_Campaigns_CSS_Inliner {
	/**
	 * Inline simple class and element selectors emitted by our template.
	 *
	 * Authored CSS is never accepted here. Keeping this compiler deliberately
	 * bounded makes output reproducible and avoids treating CSS as executable input.
	 */
	public static function inline( string $html, array $rules ): string {
		foreach ( $rules as $selector => $declarations ) {
			$declarations = safecss_filter_attr( (string) $declarations );
			if ( '' === $declarations ) {
				continue;
			}

			if ( str_starts_with( $selector, '.' ) ) {
				$class = preg_quote( substr( $selector, 1 ), '/' );
				$pattern = '/<([a-z0-9]+)([^>]*\bclass=(?:"[^"]*\b' . $class . '\b[^"]*"|\'[^\']*\b' . $class . '\b[^\']*\'))([^>]*)>/i';
			} else {
				$tag = preg_quote( sanitize_key( $selector ), '/' );
				$pattern = '/<(' . $tag . ')([^>]*)>/i';
			}

			$html = preg_replace_callback(
				$pattern,
				static function ( array $matches ) use ( $declarations ): string {
					$attributes = $matches[2] . ( $matches[3] ?? '' );
					if ( preg_match( '/\bstyle=("|\')(.*?)\1/i', $attributes, $style_match ) ) {
						$style = safecss_filter_attr( rtrim( $style_match[2], ';' ) . ';' . $declarations );
						$attributes = preg_replace( '/\bstyle=("|\')(.*?)\1/i', 'style="' . esc_attr( $style ) . '"', $attributes, 1 );
					} else {
						$attributes .= ' style="' . esc_attr( $declarations ) . '"';
					}

					return '<' . $matches[1] . $attributes . '>';
				},
				$html
			);
		}

		return $html;
	}
}
