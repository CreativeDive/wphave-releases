<?php

/** Complete, client-tolerant HTML email document template. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WPHAVE_Campaigns_Email_Template {
	public static function render( string $content, array $config ): string {
		$site_name = get_bloginfo( 'name' );
		$preview = sanitize_text_field( $config['preview_text'] ?? '' );
		$design = WPHAVE_Campaigns_Design::sanitize( (array) ( $config['design'] ?? array() ) );
		$document_settings = is_array( $config['document_settings'] ?? null ) ? $config['document_settings'] : array();
		$canvas_spacing = ! empty( $config['document_wrapped'] )
			? min( 80, absint( $document_settings['canvasSpacing'] ?? $design['layout']['canvasSpacing'] ) )
			: (int) $design['layout']['canvasSpacing'];
		$content_padding = ! empty( $config['document_wrapped'] )
			? 0
			: (int) $design['layout']['contentPadding'];
		$spacing_css = '';
		foreach ( $design['spacing'] as $key => $preset ) {
			$spacing_css .= '.wphave-email-spacer-' . $key . ' td{height:' . (int) $preset['mobile'] . 'px!important;line-height:' . (int) $preset['mobile'] . 'px!important;}';
		}
		$responsive_css = '<style>@media only screen and (max-width:640px){.wphave-email-columns.is-mobile-stacked>tbody>tr>.wphave-email-column,.wphave-email-columns.is-mobile-stacked>tr>.wphave-email-column{display:block!important;width:100%!important;padding-left:0!important;padding-top:16px!important}.wphave-email-columns.is-mobile-stacked>tbody>tr>.wphave-email-column:first-child,.wphave-email-columns.is-mobile-stacked>tr>.wphave-email-column:first-child{padding-top:0!important}' . $spacing_css . '}</style>';
		$html = '<!doctype html><html lang="' . esc_attr( get_bloginfo( 'language' ) ) . '"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="x-apple-disable-message-reformatting"><title>' . esc_html( $config['subject'] ?? $site_name ) . '</title>' . $responsive_css . '</head><body class="wphave-email-body"><div class="wphave-email-preheader">' . esc_html( $preview ) . '</div><table class="wphave-email-shell" role="presentation" width="100%" cellpadding="0" cellspacing="0"><tbody><tr><td class="wphave-email-shell-cell" align="center"><table class="wphave-email-card" role="presentation" width="100%" cellpadding="0" cellspacing="0"><tbody><tr><td class="wphave-email-content">' . $content . '</td></tr><tr><td class="wphave-email-footer"><p>' . esc_html( $site_name ) . '</p><p><a href="{{unsubscribe_url}}">' . esc_html__( 'Unsubscribe', 'wphave' ) . '</a></p></td></tr></tbody></table></td></tr></tbody></table></body></html>';

		return WPHAVE_Campaigns_CSS_Inliner::inline(
			$html,
			array(
				'.wphave-email-body' => 'margin:0;padding:0;background-color:' . $design['colors']['canvas'] . ';color:' . $design['colors']['text'] . ';font-family:' . $design['typography']['fontFamily'] . ';',
				'.wphave-email-preheader' => 'display:none;max-height:0;overflow:hidden;opacity:0;color:transparent;',
				'.wphave-email-shell' => 'width:100%;border-collapse:collapse;background-color:' . $design['colors']['canvas'] . ';',
				'.wphave-email-shell-cell' => 'padding:' . $canvas_spacing . 'px;',
				'.wphave-email-card' => 'width:100%;max-width:' . $design['layout']['contentWidth'] . 'px;border-collapse:collapse;background-color:' . $design['colors']['content'] . ';',
				'.wphave-email-content' => 'padding:' . $content_padding . 'px;color:' . $design['colors']['text'] . ';font-size:' . $design['typography']['baseSize'] . 'px;line-height:' . $design['typography']['lineHeight'] . ';',
				'.wphave-email-content a' => 'color:' . $design['colors']['link'] . ';',
				'.wphave-email-content h1' => 'color:' . $design['colors']['heading'] . ';font-size:' . $design['typography']['h1Size'] . 'px;',
				'.wphave-email-content h2' => 'color:' . $design['colors']['heading'] . ';font-size:' . $design['typography']['h2Size'] . 'px;',
				'.wphave-email-content h3' => 'color:' . $design['colors']['heading'] . ';font-size:' . $design['typography']['h3Size'] . 'px;',
				'.wphave-email-footer' => 'padding:24px 32px;background-color:' . $design['colors']['footerBackground'] . ';color:' . $design['colors']['footerText'] . ';font-size:13px;line-height:1.5;',
				'.wphave-document-button' => 'display:inline-block;padding:' . $design['button']['paddingY'] . 'px ' . $design['button']['paddingX'] . 'px;background-color:' . $design['button']['primaryBackground'] . ';color:' . $design['button']['primaryText'] . ';text-decoration:none;border-radius:' . $design['button']['radius'] . 'px;font-weight:600;',
				'.wphave-document-button-secondary' => 'background-color:' . $design['button']['secondaryBackground'] . ';color:' . $design['button']['secondaryText'] . ';',
				'.wphave-document-button-tertiary' => 'padding-left:0;padding-right:0;background-color:transparent;color:' . $design['colors']['link'] . ';',
				'.wphave-document-button-ghost' => 'border:1px solid ' . $design['colors']['link'] . ';background-color:transparent;color:' . $design['colors']['link'] . ';',
				'.wphave-document-line' => 'border:0;border-top:1px solid #dcdcde;margin:24px 0;',
				'.wphave-email-list' => 'margin:0;padding-left:24px;',
				'.wphave-email-list li' => 'margin:0 0 8px;',
				'img' => 'max-width:100%;height:auto;border:0;',
			)
		);
	}
}
