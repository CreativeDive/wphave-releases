<?php

/** Email-specific HTML security boundary. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WPHAVE_Campaigns_Email_Sanitizer {
	/** Sanitize authored markup with an intentionally small email-safe contract. */
	public static function sanitize( string $html ): string {
		$global = array(
			'class' => true,
			'id' => true,
			'style' => true,
			'title' => true,
			'align' => true,
		);
		$allowed = array_fill_keys(
			array( 'article', 'blockquote', 'br', 'center', 'div', 'em', 'figcaption', 'figure', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'hr', 'li', 'ol', 'p', 'section', 'span', 'strong', 's', 'table', 'tbody', 'td', 'tfoot', 'th', 'thead', 'tr', 'ul' ),
			$global
		);
		$allowed['a'] = array_merge( $global, array( 'href' => true, 'target' => true, 'rel' => true ) );
		$allowed['img'] = array_merge( $global, array( 'src' => true, 'alt' => true, 'width' => true, 'height' => true, 'border' => true ) );
		$allowed['table'] = array_merge( $global, array( 'width' => true, 'border' => true, 'cellpadding' => true, 'cellspacing' => true, 'role' => true ) );
		$allowed['td'] = array_merge( $global, array( 'width' => true, 'height' => true, 'colspan' => true, 'rowspan' => true, 'valign' => true ) );
		$allowed['th'] = $allowed['td'];

		return wp_kses( $html, $allowed, array( 'http', 'https', 'mailto', 'tel' ) );
	}
}
