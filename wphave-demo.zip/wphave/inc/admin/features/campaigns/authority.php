<?php
/** Campaign execution authority survives database time travel. */
if (!defined('ABSPATH')) {
	exit();
}
require_once __DIR__ . '/../../../data/operational-state.php';

final class WPHAVE_Campaigns_Authority {
	public const SUPPRESSIONS_TABLE = 'wphave_email_suppressions';
	private const STORE = 'campaign-execution';

	/** Internal workflows retain their domain exceptions across the shared mutex. */
	public static function exclusive(callable $callback) {
		return WPHAVE_Operational_State::run(self::STORE, $callback);
	}

	public static function run(callable $callback) {
		try {
			return self::exclusive($callback);
		} catch (WPHAVE_Security_File_Mutex_Exception $error) {
			return new WP_Error(
				'wphave_campaign_busy',
				__(
					'A mailing operation is in progress. Retry after the current message finishes.',
					'wphave'
				),
				['status' => 409]
			);
		} catch (RuntimeException $error) {
			return new WP_Error(
				'wphave_campaign_authority_unavailable',
				__(
					'Mailing authority is unavailable. Check protected operational storage before continuing.',
					'wphave'
				),
				['status' => 503]
			);
		}
	}

	public static function current(): array {
		$state = WPHAVE_Operational_State::read(self::STORE);
		if (null === $state) {
			// MISSING-STATE INVARIANT: A new epoch cannot authorize any pre-existing queue.
			$state = [
				'version' => 1,
				'epoch' => bin2hex(random_bytes(32)),
				'restore' => '',
				'ready' => false
			];
			WPHAVE_Operational_State::write(self::STORE, $state);
		}
		if (
			1 !== ($state['version'] ?? null) ||
			!is_string($state['epoch'] ?? null) ||
			!preg_match('/^[a-f0-9]{64}$/', $state['epoch']) ||
			!is_string($state['restore'] ?? null) ||
			!is_bool($state['ready'] ?? null)
		) {
			throw new RuntimeException('Invalid campaign execution authority.');
		}
		return $state;
	}

	public static function authorize_new(int $id): true|WP_Error {
		$authority = self::current();
		if ($authority['restore'] !== '') {
			return self::blocked();
		}
		$state = WPHAVE_Campaigns_Repository::state($id);
		// REPLAY INVARIANT: Preparing a restored/previously prepared campaign cannot
		// manufacture fresh authority for old recipients. Create a new mailing instead.
		if (
			($state['status'] ?? '') !== 'draft' ||
			!hash_equals(
				$authority['epoch'],
				(string) get_post_meta($id, WPHAVE_Campaigns_Repository::META_ORIGIN, true)
			)
		) {
			return self::blocked();
		}
		$saved = WPHAVE_Campaigns_Repository::set_state($id, [
			'execution_epoch' => $authority['epoch']
		]);
		return is_wp_error($saved) ? $saved : true;
	}

	public static function allows(int $id): bool {
		$authority = self::current();
		wp_cache_delete($id, 'post_meta');
		$state = WPHAVE_Campaigns_Repository::state($id);
		return '' === $authority['restore'] &&
			hash_equals($authority['epoch'], (string) ($state['execution_epoch'] ?? ''));
	}

	public static function review_required(int $id): bool {
		$state = WPHAVE_Campaigns_Repository::state($id);
		if (in_array($state['status'], ['completed', 'completed_with_errors', 'cancelled'], true)) {
			return false;
		}
		$result = self::run(static function () use ($id, $state): bool {
			$authority = self::current();
			return '' !== $authority['restore'] ||
				('draft' === $state['status']
					? !hash_equals(
						$authority['epoch'],
						(string) get_post_meta($id, WPHAVE_Campaigns_Repository::META_ORIGIN, true)
					)
					: !self::allows($id));
		});
		return true === $result;
	}

	public static function blocked(): WP_Error {
		return new WP_Error(
			'wphave_campaign_recovery_review_required',
			__(
				'This mailing has no current execution authority. Complete restore review and create a new mailing; restored queues cannot be resumed.',
				'wphave'
			),
			['status' => 409]
		);
	}

	public static function fence_restore(string $id): void {
		$result = self::run(static function () use ($id): void {
			$state = self::current();
			if ($state['restore'] === $id) {
				return;
			}
			// RESTORE INVARIANT: Fence and drain senders before any live mutation.
			// No database snapshot can undo this epoch or unlock the installation.
			$state['epoch'] = bin2hex(random_bytes(32));
			$state['restore'] = $id;
			$state['ready'] = false;
			WPHAVE_Operational_State::write(self::STORE, $state);
		});
		if (is_wp_error($result)) {
			throw new RuntimeException($result->get_error_message());
		}
	}

	public static function finish_restore(string $id): void {
		$result = self::run(static function () use ($id): void {
			$state = self::current();
			if ($state['restore'] !== $id) {
				throw new RuntimeException('Restore authority mismatch.');
			}
			$state['ready'] = true;
			WPHAVE_Operational_State::write(self::STORE, $state);
		});
		if (is_wp_error($result)) {
			throw new RuntimeException($result->get_error_message());
		}
	}

	public static function acknowledge(string $id): true|WP_Error {
		return self::run(static function () use ($id) {
			$state = self::current();
			if (!$state['ready'] || '' === $id || $id !== $state['restore']) {
				return self::blocked();
			}
			$state['restore'] = '';
			$state['ready'] = false;
			WPHAVE_Operational_State::write(self::STORE, $state);
			// Old campaign epochs remain invalid even after operator acknowledgement.
			return true;
		});
	}

	/** Merge live opt-outs into staged tables while the same mutex excludes writers. */
	public static function preserve_suppressions(array $table_map): void {
		global $wpdb;
		foreach ($table_map as $live => $stage) {
			if (!str_ends_with($live, self::SUPPRESSIONS_TABLE)) {
				continue;
			}
			foreach ([$live, $stage] as $table) {
				if (!preg_match('/^[A-Za-z0-9_$]+$/', $table)) {
					throw new RuntimeException('Invalid suppression table identity.');
				}
			}
			// CONSENT INVARIANT: Union both timelines; an old backup never removes a
			// newer opt-out. Surrogate ids are regenerated; email_hash owns identity.
			$sql = "INSERT INTO `{$stage}` (email_hash,email,reason,source,created_at) SELECT email_hash,email,reason,source,created_at FROM `{$live}` WHERE 1 ON DUPLICATE KEY UPDATE email_hash=VALUES(email_hash)";
			if (false === $wpdb->query($sql)) {
				throw new RuntimeException('Live suppressions could not be preserved.');
			}
		}
	}
}
