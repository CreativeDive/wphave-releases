<?php

/** Campaigns administration and REST runtime. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/rest-controller.php';

// MANAGEMENT INVARIANT: Editor profiles and presentation filters are not part
// of Campaigns delivery or queue processing and therefore never load in Cron.
wphave_campaigns_register_editor_integration();
WPHAVE_Campaigns_REST_Controller::init();
