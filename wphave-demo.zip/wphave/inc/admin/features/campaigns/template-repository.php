<?php

/**
 * Editable mailing-template persistence and idempotent starter content.
 *
 * Templates deliberately use a separate hidden post type so they never enter
 * mailing delivery queries. Their canonical content uses the same email
 * document profile as mailings, which makes cloning lossless and keeps both
 * records editable through the shared WPHAVE mail editor.
 *
 * @package wphave
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WPHAVE_Campaigns_Template_Repository {
	public const POST_TYPE = 'wphave-mail-template';
	private const SEED_VERSION = 1;
	private const SEED_VERSION_OPTION = 'wphave_mailing_template_seed_version';
	private const META_DESCRIPTION = '_wphave_mail_template_description';

	/** Register the internal revision-enabled template record. */
	public static function register(): void {
		register_post_type(
			self::POST_TYPE,
			array(
				'label' => __( 'Mailing templates', 'wphave' ),
				'public' => false,
				'show_ui' => false,
				'show_in_rest' => true,
				'rest_base' => 'wphave-mail-template-content',
				'supports' => array( 'title', 'editor', 'revisions' ),
				'map_meta_cap' => true,
				'capabilities' => WPHAVE_Campaigns_Repository::post_type_capabilities(),
			)
		);

		register_rest_field(
			self::POST_TYPE,
			'wphave_template_description',
			array(
				'get_callback' => static fn ( array $item ): string => (string) get_post_meta( (int) $item['id'], self::META_DESCRIPTION, true ),
				'schema' => array(
					'type' => 'string',
					'context' => array( 'edit' ),
					'readonly' => true,
				),
			)
		);
		register_rest_field(
			self::POST_TYPE,
			'wphave_template_preview_html',
			array(
				'get_callback' => static function ( array $item ): string {
					$post = get_post( (int) $item['id'] );

					return $post instanceof WP_Post ? self::preview_html( $post ) : '';
				},
				'schema' => array(
					'type' => 'string',
					'context' => array( 'edit' ),
					'readonly' => true,
				),
			)
		);
	}

	/** Create the three bundled templates once without replacing user edits. */
	public static function seed(): void {
		// PERSISTENCE INVARIANT: The seed version advances only after every bundled
		// template and its canonical document are committed. Partial creation is rolled
		// back per template and remains retryable on the next request.
		if ( self::SEED_VERSION <= (int) get_option( self::SEED_VERSION_OPTION, 0 ) ) {
			return;
		}

		if ( ! class_exists( 'WPHAVE_Documents_Storage' ) || ! WPHAVE_Documents_Storage::supports( self::POST_TYPE ) ) {
			return;
		}

		$seeded = true;
		foreach ( self::definitions() as $definition ) {
			$existing = get_page_by_path( $definition['slug'], OBJECT, self::POST_TYPE );
			if ( $existing ) {
				continue;
			}

			$post_id = wp_insert_post(
				array(
					'post_type' => self::POST_TYPE,
					'post_status' => 'private',
					'post_name' => $definition['slug'],
					'post_title' => $definition['title'],
				),
				true
			);
			if ( is_wp_error( $post_id ) ) {
				$seeded = false;
				continue;
			}

			update_post_meta( $post_id, self::META_DESCRIPTION, $definition['description'] );
			$state = WPHAVE_Documents_Storage::get_state( (int) $post_id );
			if ( is_wp_error( $state ) ) {
				wp_delete_post( (int) $post_id, true );
				$seeded = false;
				continue;
			}

			$updated = WPHAVE_Documents_Storage::update(
					(int) $post_id,
					$definition['document'],
					$state['revision']
				);
			if ( is_wp_error( $updated ) ) {
				wp_delete_post( (int) $post_id, true );
				$seeded = false;
			}
		}

		if ( $seeded ) {
			update_option( self::SEED_VERSION_OPTION, self::SEED_VERSION, false );
		}
	}

	/** Return the small projection used by the templates DataView. */
	public static function all(): array {
		$posts = get_posts(
			array(
				'post_type' => self::POST_TYPE,
				'post_status' => array( 'private', 'publish', 'draft' ),
				'posts_per_page' => 100,
				'orderby' => array( 'menu_order' => 'ASC', 'title' => 'ASC' ),
			)
		);

		return array_map(
			static fn ( WP_Post $post ): array => array(
				'id' => (int) $post->ID,
				'title' => $post->post_title,
				'description' => (string) get_post_meta( $post->ID, self::META_DESCRIPTION, true ),
				'previewHtml' => self::preview_html( $post ),
				'modified' => mysql_to_rfc3339( $post->post_modified_gmt ),
			),
			$posts
		);
	}

	/** Render the same isolated HTML document used by a real mailing. */
	private static function preview_html( WP_Post $post ): string {
		$mailing = array(
			'id' => (int) $post->ID,
			'content' => '',
			'config' => array(
				'subject' => $post->post_title,
				'preview_text' => '',
				'purpose' => 'newsletter',
			),
		);
		$artifact = WPHAVE_Campaigns_Email_Renderer::artifact( $mailing );
		if ( is_wp_error( $artifact ) ) {
			return WPHAVE_Campaigns_Email_Template::render(
				'<p>' . esc_html__( 'This template is empty. Open it to start designing.', 'wphave' ) . '</p>',
				array_merge(
					$mailing['config'],
					array( 'design' => WPHAVE_Campaigns_Design::current() )
				)
			);
		}

		$message = WPHAVE_Campaigns_Email_Renderer::message(
			$mailing,
			array(
				'email' => 'preview@example.invalid',
				'merge_data' => wp_json_encode(
					array(
						'first_name' => __( 'Preview', 'wphave' ),
						'last_name' => __( 'Recipient', 'wphave' ),
					)
				),
				'unsubscribe_url' => '#unsubscribe',
			),
			$artifact
		);

		return is_wp_error( $message ) ? '' : (string) $message['html'];
	}

	/** Clone a template document into a new draft mailing with rollback on failure. */
	public static function create_mailing( int $template_id, $authorization_guard = null ) {
		$template = get_post( $template_id );
		if ( ! $template || self::POST_TYPE !== $template->post_type ) {
			return new WP_Error( 'wphave_mailing_template_not_found', __( 'Mailing template not found.', 'wphave' ), array( 'status' => 404 ) );
		}

		$document = WPHAVE_Documents_Storage::get( $template_id );
		if ( is_wp_error( $document ) ) {
			return $document;
		}

		$mailing = WPHAVE_Campaigns_Repository::save(
			array(
				'title' => sprintf( __( '%s mailing', 'wphave' ), $template->post_title ),
				'content' => '',
				'config' => array(
					'subject' => $template->post_title,
					'from_name' => get_bloginfo( 'name' ),
					'from_email' => get_option( 'admin_email' ),
					'purpose' => 'newsletter',
					'segment' => array( 'purpose' => 'newsletter' ),
				),
			),
			0,
			$authorization_guard
		);
		if ( is_wp_error( $mailing ) ) {
			return $mailing;
		}

		$state = WPHAVE_Documents_Storage::get_state( (int) $mailing['id'] );
		// AUTHORIZATION/COMMIT INVARIANT: Creating a mailing from a template is one
		// privileged clone. The caller policy guards both the normalized Campaign
		// shell and its canonical template-document commit; denial of either stage
		// removes the incomplete mailing.
		$updated = is_wp_error( $state )
			? $state
			: WPHAVE_Documents_Storage::update( (int) $mailing['id'], $document, $state['revision'], $authorization_guard );
		if ( is_wp_error( $updated ) ) {
			wp_delete_post( (int) $mailing['id'], true );
			return $updated;
		}

		return WPHAVE_Campaigns_Repository::get( (int) $mailing['id'] );
	}

	/** Clone a template and its private canonical document as one operation. */
	public static function duplicate( int $template_id, string $title, $authorization_guard = null ) {
		$template = get_post( $template_id );
		if ( ! $template || self::POST_TYPE !== $template->post_type ) {
			return new WP_Error( 'wphave_mailing_template_not_found', __( 'Mailing template not found.', 'wphave' ), array( 'status' => 404 ) );
		}

		$document = WPHAVE_Documents_Storage::get( $template_id );
		if ( is_wp_error( $document ) ) {
			return $document;
		}

		$title = sanitize_text_field( $title );
		if ( '' === $title ) {
			return new WP_Error( 'wphave_mailing_template_title_required', __( 'A template title is required.', 'wphave' ), array( 'status' => 400 ) );
		}

		// AUTHORIZATION/COMMIT INVARIANT: Template source reads and title
		// normalization precede creation of a new private object. A caller-owned
		// policy must still succeed immediately before that first mutation and again
		// when the cloned document is committed; a denial leaves no partial copy.
		if ( is_callable( $authorization_guard ) ) {
			$authorization = call_user_func( $authorization_guard );
			if ( true !== $authorization ) {
				return is_wp_error( $authorization )
					? $authorization
					: new WP_Error( 'wphave_campaign_forbidden', __( 'You are not allowed to manage campaigns.', 'wphave' ), array( 'status' => 403 ) );
			}
		}

		$post_id = wp_insert_post(
			array(
				'post_type' => self::POST_TYPE,
				'post_status' => 'draft',
				'post_title' => $title,
			),
			true
		);
		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}

		update_post_meta(
			(int) $post_id,
			self::META_DESCRIPTION,
			(string) get_post_meta( $template_id, self::META_DESCRIPTION, true )
		);
		$state = WPHAVE_Documents_Storage::get_state( (int) $post_id );
		$updated = is_wp_error( $state )
			? $state
			: WPHAVE_Documents_Storage::update( (int) $post_id, $document, $state['revision'], $authorization_guard );
		if ( is_wp_error( $updated ) ) {
			wp_delete_post( (int) $post_id, true );

			return $updated;
		}

		return array(
			'id' => (int) $post_id,
			'type' => self::POST_TYPE,
			'status' => 'draft',
			'title' => array(
				'raw' => $title,
				'rendered' => $title,
			),
		);
	}

	/** Bundled documents use canonical WPHAVE block names and remain fully editable. */
	private static function definitions(): array {
		return array(
			self::definition(
				'welcome-newsletter',
				__( 'Welcome newsletter', 'wphave' ),
				__( 'A warm introduction with a clear next step.', 'wphave' ),
				array(
					self::section(
						'welcome-section',
						array(
							self::heading( 'welcome-heading', __( 'Welcome to our newsletter', 'wphave' ), 'h1' ),
							self::paragraph( 'welcome-copy', __( 'Thanks for joining us. We are glad you are here and look forward to sharing useful updates with you.', 'wphave' ) ),
							self::spacer( 'welcome-spacer', 16 ),
							self::button( 'welcome-button', __( 'Visit our website', 'wphave' ) ),
						),
						'#f2f5ff'
					),
				)
			),
			self::definition(
				'product-announcement',
				__( 'Product announcement', 'wphave' ),
				__( 'Introduce a new product, service or important update.', 'wphave' ),
				array(
					self::heading( 'announcement-heading', __( 'Something new is here', 'wphave' ), 'h1' ),
					self::paragraph( 'announcement-copy', __( 'Share what changed, why it matters and how your readers benefit from it.', 'wphave' ) ),
					self::spacer( 'announcement-spacer', 24 ),
					self::line( 'announcement-line' ),
					self::button( 'announcement-button', __( 'Discover what is new', 'wphave' ) ),
				)
			),
			self::definition(
				'weekly-digest',
				__( 'Weekly digest', 'wphave' ),
				__( 'Summarize several stories in a compact recurring format.', 'wphave' ),
				array(
					self::heading( 'digest-heading', __( 'Your weekly update', 'wphave' ), 'h1' ),
					self::paragraph( 'digest-intro', __( 'Here are the most important stories and updates from this week.', 'wphave' ) ),
					self::email_list(
						'digest-list',
						array(
							__( 'First highlight: add a short summary and link to the full story.', 'wphave' ),
							__( 'Second highlight: share another useful update or recommendation.', 'wphave' ),
						)
					),
				)
			),
		);
	}

	private static function definition( string $slug, string $title, string $description, array $blocks ): array {
		return array(
			'slug' => $slug,
			'title' => $title,
			'description' => $description,
			'document' => array( 'schemaVersion' => 1, 'profile' => 'email', 'blocks' => $blocks ),
		);
	}

	private static function paragraph( string $id, string $content ): array {
		return array( 'id' => $id, 'type' => 'wphave/paragraph', 'version' => 1, 'attributes' => array( 'content' => $content ) );
	}

	private static function heading( string $id, string $content, string $level = 'h2' ): array {
		return array( 'id' => $id, 'type' => 'wphave/heading', 'version' => 1, 'attributes' => array( 'content' => $content, 'wphave' => array( 'settings' => array( 'headingLevel' => $level ) ) ) );
	}

	private static function button( string $id, string $content ): array {
		return array( 'id' => $id, 'type' => 'wphave/button', 'version' => 1, 'attributes' => array( 'content' => $content, 'link' => array( 'type' => 'external', 'external' => array( 'url' => home_url( '/' ) ) ) ) );
	}

	private static function line( string $id ): array {
		return array( 'id' => $id, 'type' => 'wphave/line', 'version' => 1, 'attributes' => array() );
	}

	private static function section( string $id, array $inner_blocks, string $background ): array {
		return array(
			'id' => $id,
			'type' => 'wphave/email-section',
			'version' => 1,
			'attributes' => array( 'backgroundColor' => $background, 'padding' => 32, 'width' => 'full' ),
			'innerBlocks' => $inner_blocks,
		);
	}

	private static function spacer( string $id, int $height ): array {
		return array( 'id' => $id, 'type' => 'wphave/email-spacer', 'version' => 1, 'attributes' => array( 'preset' => 'custom', 'height' => $height ) );
	}

	private static function email_list( string $id, array $items ): array {
		return array( 'id' => $id, 'type' => 'wphave/email-list', 'version' => 1, 'attributes' => array( 'ordered' => false, 'items' => $items ) );
	}
}
