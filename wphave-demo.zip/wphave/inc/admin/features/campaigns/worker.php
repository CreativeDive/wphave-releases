<?php

/** Campaign queue worker runtime. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/processor.php';

add_action( WPHAVE_Campaigns_Service::WORK_HOOK, array( 'WPHAVE_Campaigns_Processor', 'run' ), 10, 1 );
