<?php

/** Mailing design defaults and persistence-boundary sanitization. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WPHAVE_Campaigns_Design {
	/** Return the versioned design contract used for new mailing snapshots. */
	public static function defaults(): array {
		return array(
			'version' => 3,
			'layout' => array(
				'contentWidth' => 640,
				'contentPadding' => 32,
				'canvasSpacing' => 24,
				'blockGap' => 16,
			),
			'colors' => array(
				'canvas' => '#f3f4f6',
				'content' => '#ffffff',
				'text' => '#1f2937',
				'heading' => '#111827',
				'link' => '#3858e9',
				'footerBackground' => '#f9fafb',
				'footerText' => '#6b7280',
			),
			'typography' => array(
				'fontFamily' => '-apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif',
				'baseSize' => 16,
				'lineHeight' => 1.6,
				'h1Size' => 36,
				'h2Size' => 30,
				'h3Size' => 24,
			),
			'button' => array(
				'radius' => 4,
				'paddingX' => 20,
				'paddingY' => 12,
				'primaryBackground' => '#3858e9',
				'primaryText' => '#ffffff',
				'secondaryBackground' => '#e5e7eb',
				'secondaryText' => '#1f2937',
			),
			'spacing' => array(
				'xs' => array( 'desktop' => 8, 'mobile' => 8 ),
				's' => array( 'desktop' => 16, 'mobile' => 12 ),
				'm' => array( 'desktop' => 24, 'mobile' => 16 ),
				'l' => array( 'desktop' => 40, 'mobile' => 24 ),
				'xl' => array( 'desktop' => 64, 'mobile' => 40 ),
			),
		);
	}

	/** Sanitize a complete or partial design while retaining forward-safe defaults. */
	public static function sanitize( array $design ): array {
		$defaults = self::defaults();
		$layout = is_array( $design['layout'] ?? null ) ? $design['layout'] : array();
		$colors = is_array( $design['colors'] ?? null ) ? $design['colors'] : array();
		$typography = is_array( $design['typography'] ?? null ) ? $design['typography'] : array();
		$button = is_array( $design['button'] ?? null ) ? $design['button'] : array();
		$spacing = is_array( $design['spacing'] ?? null ) ? $design['spacing'] : array();

		$defaults['layout']['contentWidth'] = min( 800, max( 320, absint( $layout['contentWidth'] ?? 640 ) ) );
		$defaults['layout']['contentPadding'] = min( 80, max( 0, absint( $layout['contentPadding'] ?? 32 ) ) );
		$defaults['layout']['canvasSpacing'] = min( 80, max( 0, absint( $layout['canvasSpacing'] ?? 24 ) ) );
		$defaults['layout']['blockGap'] = min( 80, max( 0, absint( $layout['blockGap'] ?? 16 ) ) );

		foreach ( $defaults['colors'] as $key => $fallback ) {
			$value = sanitize_hex_color( (string) ( $colors[ $key ] ?? $fallback ) );
			$defaults['colors'][ $key ] = $value ?: $fallback;
		}

		$allowed_fonts = array(
			'-apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif',
			'Arial, Helvetica, sans-serif',
			'Georgia, Times New Roman, serif',
			'Tahoma, Verdana, sans-serif',
			'Trebuchet MS, Arial, sans-serif',
		);
		$font_family = sanitize_text_field( (string) ( $typography['fontFamily'] ?? $defaults['typography']['fontFamily'] ) );
		$defaults['typography']['fontFamily'] = in_array( $font_family, $allowed_fonts, true ) ? $font_family : $defaults['typography']['fontFamily'];
		$defaults['typography']['baseSize'] = min( 22, max( 12, absint( $typography['baseSize'] ?? 16 ) ) );
		$defaults['typography']['lineHeight'] = min( 2, max( 1, (float) ( $typography['lineHeight'] ?? 1.6 ) ) );
		foreach ( array( 'h1Size', 'h2Size', 'h3Size' ) as $key ) {
			$defaults['typography'][ $key ] = min( 64, max( 16, absint( $typography[ $key ] ?? $defaults['typography'][ $key ] ) ) );
		}

		foreach ( array( 'primaryBackground', 'primaryText', 'secondaryBackground', 'secondaryText' ) as $key ) {
			$value = sanitize_hex_color( (string) ( $button[ $key ] ?? $defaults['button'][ $key ] ) );
			$defaults['button'][ $key ] = $value ?: $defaults['button'][ $key ];
		}
		$defaults['button']['radius'] = min( 32, absint( $button['radius'] ?? 4 ) );
		$defaults['button']['paddingX'] = min( 48, max( 4, absint( $button['paddingX'] ?? 20 ) ) );
		$defaults['button']['paddingY'] = min( 32, max( 4, absint( $button['paddingY'] ?? 12 ) ) );

		foreach ( $defaults['spacing'] as $key => $preset ) {
			$input = is_array( $spacing[ $key ] ?? null ) ? $spacing[ $key ] : array();
			$defaults['spacing'][ $key ] = array(
				'desktop' => min( 160, max( 0, absint( $input['desktop'] ?? $preset['desktop'] ) ) ),
				'mobile' => min( 160, max( 0, absint( $input['mobile'] ?? $preset['mobile'] ) ) ),
			);
		}

		return $defaults;
	}

	/** Read the current defaults used only when creating a new mailing. */
	public static function current(): array {
		return self::sanitize( (array) wphave_data_get( 'campaign_settings', 'design', array() ) );
	}
}
