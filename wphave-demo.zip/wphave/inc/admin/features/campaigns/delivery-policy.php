<?php

/**
 * Provider-aware campaign delivery limits and cooldown state.
 *
 * The policy is global for a provider, not scoped to a campaign. This prevents
 * two concurrent campaigns from independently consuming the same SMTP quota.
 * Persisted delivery rows are the source of truth for completed sends, while a
 * token-owned lock serializes quota checks and sends across campaign workers.
 *
 * @package wphave
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WPHAVE_Campaigns_Delivery_Policy {
	private const LOCK_OPTION = 'wphave_campaign_delivery_lock';
	private const COOLDOWN_OPTION = 'wphave_campaign_delivery_cooldowns';
	private const LOCK_TTL = 120;

	/** Return the normalized policy stored with the central mail settings. */
	public static function settings( string $provider = 'wordpress' ): array {
		$campaigns = (array) wphave_data_get( 'campaign_settings', '', array() );
		$providers = is_array( $campaigns['providers'] ?? null ) ? $campaigns['providers'] : array();
		$provider_settings = is_array( $providers[ sanitize_key( $provider ) ] ?? null ) ? $providers[ sanitize_key( $provider ) ] : array();
		$saved = is_array( $provider_settings['delivery'] ?? null ) ? $provider_settings['delivery'] : array();
		if ( ! $saved && 'wordpress' === sanitize_key( $provider ) && is_array( $campaigns['delivery'] ?? null ) ) {
			$saved = $campaigns['delivery'];
		}

		return array(
			'enabled' => isset( $saved['enabled'] ) ? (bool) $saved['enabled'] : true,
			'per_minute' => self::bounded( $saved['per_minute'] ?? 10, 1, 1000 ),
			'per_hour' => self::bounded( $saved['per_hour'] ?? 100, 1, 100000 ),
			'per_day' => self::bounded( $saved['per_day'] ?? 500, 1, 1000000 ),
			'cooldown_minutes' => self::bounded( $saved['cooldown_minutes'] ?? 15, 1, 1440 ),
		);
	}

	/** Acquire the global campaign-mail lease before checking or consuming quota. */
	public static function acquire(): string|false {
		return WPHAVE_Background_Job_Lock::acquire( self::LOCK_OPTION, self::LOCK_TTL );
	}

	/** Revalidate ownership before another recipient can be sent. */
	public static function refresh(string $token): bool {
		return WPHAVE_Background_Job_Lock::refresh(self::LOCK_OPTION, $token);
	}

	/** Release a lease only when the current worker still owns it. */
	public static function release( string $token ): void {
		WPHAVE_Background_Job_Lock::release( self::LOCK_OPTION, $token );
	}

	/**
	 * Return the number of messages currently available and the next safe delay.
	 *
	 * API providers retain their own upstream enforcement. The locally configured
	 * campaign limits are applied to WordPress mail because it may transparently
	 * use a quota-constrained shared SMTP account.
	 */
	public static function allowance( string $provider, int $requested ): array {
		// CONCURRENCY INVARIANT: Provider quota is global across campaigns. Callers
		// must hold the shared delivery lease while calculating allowance and sending,
		// so parallel workers cannot each consume the same remaining capacity.
		$provider = sanitize_key( $provider );
		$requested = max( 0, $requested );
		$settings = self::settings( $provider );
		$cooldown = self::cooldown_remaining( $provider );

		if ( $cooldown > 0 ) {
			return array( 'available' => 0, 'retry_after' => $cooldown, 'reason' => 'cooldown' );
		}

		if ( ! $settings['enabled'] ) {
			return array( 'available' => $requested, 'retry_after' => 0, 'reason' => '' );
		}

		$windows = array(
			array( 'seconds' => MINUTE_IN_SECONDS, 'limit' => $settings['per_minute'] ),
			array( 'seconds' => HOUR_IN_SECONDS, 'limit' => $settings['per_hour'] ),
			array( 'seconds' => DAY_IN_SECONDS, 'limit' => $settings['per_day'] ),
		);
		$available = $requested;
		$retry_after = 0;

		foreach ( $windows as $window ) {
			$usage = self::window_usage( $provider, $window['seconds'] );

			if ( is_wp_error( $usage ) ) {
				// DELIVERY INVARIANT: Unknown provider usage is never spare quota.
				// No external send may start until the complete local usage window is
				// readable under the shared provider lease.
				return array(
					'available' => 0,
					'retry_after' => 30,
					'reason' => 'storage_unavailable',
				);
			}

			$remaining = max( 0, $window['limit'] - $usage['count'] );
			$available = min( $available, $remaining );

			if ( 0 === $remaining && $usage['oldest'] ) {
				$oldest = strtotime( $usage['oldest'] . ' UTC' );
				$retry_after = max( $retry_after, max( 1, $oldest + $window['seconds'] - time() + 1 ) );
			}
		}

		return array(
			'available' => $available,
			'retry_after' => $available > 0 ? 0 : max( 30, $retry_after ),
			'reason' => $available > 0 ? '' : 'quota',
		);
	}

	/** Start a provider cooldown after a transient rejection or rate-limit error. */
	public static function register_transient_failure( string $provider, ?int $retry_after = null ): void {
		$settings = self::settings( $provider );
		$delay = $retry_after ?? $settings['cooldown_minutes'] * MINUTE_IN_SECONDS;
		$cooldowns = get_option( self::COOLDOWN_OPTION, array() );
		$cooldowns = is_array( $cooldowns ) ? $cooldowns : array();
		$cooldowns[ sanitize_key( $provider ) ] = time() + max( 30, $delay );
		update_option( self::COOLDOWN_OPTION, $cooldowns, false );
	}

	/** Identify failures that should stop a burst instead of consuming all retries. */
	public static function is_transient_error( WP_Error $error ): bool {
		$haystack = strtolower( $error->get_error_code() . ' ' . $error->get_error_message() );

		return (bool) preg_match(
			'/\b(421|450|451|452|429)\b|rate.?limit|too many|temporar|try again|quota/',
			$haystack
		);
	}

	/** Return the remaining provider cooldown and discard expired entries. */
	private static function cooldown_remaining( string $provider ): int {
		$cooldowns = get_option( self::COOLDOWN_OPTION, array() );
		$cooldowns = is_array( $cooldowns ) ? $cooldowns : array();
		$until = absint( $cooldowns[ $provider ] ?? 0 );

		if ( $until <= time() ) {
			if ( isset( $cooldowns[ $provider ] ) ) {
				unset( $cooldowns[ $provider ] );
				update_option( self::COOLDOWN_OPTION, $cooldowns, false );
			}

			return 0;
		}

		return $until - time();
	}

	/** Count accepted and possibly accepted messages inside a provider quota window. */
	private static function window_usage(string $provider, int $seconds): array|WP_Error {
		global $wpdb;
		$table = $wpdb->prefix . WPHAVE_Campaigns_Repository::DELIVERIES_TABLE;
		$since = gmdate('Y-m-d H:i:s', time() - $seconds);
		$wpdb->last_error = '';
		$row = $wpdb->get_row(
			$wpdb->prepare(
				// RESERVATION INVARIANT: The pre-send uncertain claim consumes quota.
				// Only a definitive rejection releases it; a lost result is not spare capacity.
				"SELECT COUNT(*) AS total, MIN(CASE WHEN status = 'sent' THEN sent_at ELSE updated_at END) AS oldest FROM {$table} WHERE provider = %s AND status IN ('sent','uncertain') AND (CASE WHEN status = 'sent' THEN sent_at ELSE updated_at END) >= %s",
				$provider,
				$since
			),
			ARRAY_A
		);

		if (!is_array($row) || $wpdb->last_error) {
			return new WP_Error(
				'wphave_campaign_quota_unavailable',
				__('Campaign delivery quota could not be read.', 'wphave')
			);
		}

		return [
			'count' => absint($row['total'] ?? 0),
			'oldest' => sanitize_text_field($row['oldest'] ?? '')
		];
	}

	/** Clamp persisted numeric settings to their public validation contract. */
	private static function bounded( mixed $value, int $minimum, int $maximum ): int {
		return min( $maximum, max( $minimum, absint( $value ) ) );
	}
}
