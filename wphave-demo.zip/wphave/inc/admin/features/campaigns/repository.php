<?php

/**
 * Campaign persistence, snapshot, delivery and event repository.
 *
 * @package wphave
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WPHAVE_Campaigns_Repository {
	public const POST_TYPE = 'wphave-campaign';
	public const DB_VERSION = '1.2.0';
	public const SNAPSHOTS_TABLE = 'wphave_campaign_recipients';
	public const DELIVERIES_TABLE = 'wphave_campaign_deliveries';
	public const EVENTS_TABLE = 'wphave_campaign_events';
	public const SUPPRESSIONS_TABLE = WPHAVE_Campaigns_Authority::SUPPRESSIONS_TABLE;
	public const META_CONFIG = '_wphave_campaign_config';
	public const META_STATE = '_wphave_campaign_state';
	public const META_ORIGIN = '_wphave_campaign_origin';
	public const META_STATUS = '_wphave_campaign_status';
	public const META_ARTIFACT = '_wphave_campaign_artifact';

	/** Register the hidden campaign record and revisioned meta contracts. */
	public static function register(): void {
		register_post_type(
			self::POST_TYPE,
			array(
				'label' => __( 'Mailings', 'wphave' ),
				'public' => false,
				'show_ui' => false,
				// Core Data powers the shared WPHAVE content edit screen. The post
				// type remains hidden from WordPress navigation and generic lists.
				'show_in_rest' => true,
				'rest_base' => 'wphave-campaign-content',
				'supports' => array( 'title', 'editor', 'revisions' ),
				'map_meta_cap' => true,
				'capabilities' => self::post_type_capabilities(),
			)
		);

		register_rest_field(
			self::POST_TYPE,
			'wphave_campaign_summary',
			array(
				'get_callback' => static function ( array $item ): array {
					$post = get_post( (int) $item['id'] );

					return $post instanceof WP_Post ? self::list_item( $post ) : array();
				},
				'schema' => array(
					'type' => 'object',
					'context' => array( 'edit' ),
					'readonly' => true,
				),
			)
		);
		register_rest_field(
			self::POST_TYPE,
			'wphave_campaign_preview_html',
			array(
				'get_callback' => static fn ( array $item ): string => self::preview_html( (int) $item['id'] ),
				'schema' => array(
					'type' => 'string',
					'context' => array( 'edit' ),
					'readonly' => true,
				),
			)
		);

		add_filter( 'rest_pre_insert_' . self::POST_TYPE, array( __CLASS__, 'guard_content_update' ), 10, 2 );
		add_filter( 'rest_' . self::POST_TYPE . '_collection_params', array( __CLASS__, 'collection_params' ) );
		add_filter( 'rest_' . self::POST_TYPE . '_query', array( __CLASS__, 'collection_query' ), 10, 2 );

		foreach ( array( self::META_CONFIG, self::META_STATE, self::META_ARTIFACT ) as $key ) {
			register_post_meta(
				self::POST_TYPE,
				$key,
				array(
					'type' => 'object',
					'single' => true,
					'show_in_rest' => false,
					'revisions_enabled' => true,
					'auth_callback' => static fn (): bool => current_user_can( 'manage_options' ),
				)
			);
		}

		register_post_meta(
			self::POST_TYPE,
			self::META_STATUS,
			array(
				'type' => 'string',
				'single' => true,
				'show_in_rest' => false,
				'auth_callback' => static fn (): bool => current_user_can( 'manage_options' ),
			)
		);
	}

	/**
	 * Return the Core post capability map for Campaign-owned records.
	 *
	 * @return array<string,string> Post type capabilities.
	 */
	public static function post_type_capabilities(): array {
		$capability = 'wphave_manage_audience';

		// AUTHORIZATION INVARIANT: Core REST is an independent entry point. Hidden
		// Campaign records must retain the same domain capability there as on every
		// WPHAVE route; generic edit_posts authority never crosses this boundary.
		return array(
			'edit_post' => 'edit_wphave_campaign',
			'read_post' => 'read_wphave_campaign',
			'delete_post' => 'delete_wphave_campaign',
			'edit_posts' => $capability,
			'edit_others_posts' => $capability,
			'delete_posts' => $capability,
			'delete_others_posts' => $capability,
			'publish_posts' => $capability,
			'read_private_posts' => $capability,
			'create_posts' => $capability,
			'delete_private_posts' => $capability,
			'delete_published_posts' => $capability,
			'edit_private_posts' => $capability,
			'edit_published_posts' => $capability,
		);
	}

	/** Add the operational Campaign status to the Core post collection contract. */
	public static function collection_params( array $params ): array {
		$params['wphave_campaign_status'] = array(
			'description' => __( 'Limit mailings to an operational Campaign status.', 'wphave' ),
			'type' => 'string',
			'enum' => array( 'draft', 'scheduled', 'queued', 'sending', 'paused', 'completed', 'completed_with_errors', 'failed', 'cancelled' ),
			'required' => false,
		);

		return $params;
	}

	/** Translate the public collection parameter to the indexed status projection. */
	public static function collection_query( array $args, WP_REST_Request $request ): array {
		$status = sanitize_key( (string) $request->get_param( 'wphave_campaign_status' ) );
		if ( '' === $status ) {
			return $args;
		}

		$args['meta_query'] = array_merge(
			(array) ( $args['meta_query'] ?? array() ),
			array(
				array(
					'key' => self::META_STATUS,
					'value' => $status,
					'compare' => '=',
				),
			)
		);

		return $args;
	}

	/** Persist the prepared render exactly once at the draft boundary. */
	public static function freeze_artifact( int $campaign_id, array $artifact ): true|WP_Error {
		if ( 'draft' !== self::state( $campaign_id )['status'] ) {
			return new WP_Error( 'wphave_campaign_artifact_locked', __( 'A prepared mailing artifact cannot be replaced.', 'wphave' ), array( 'status' => 409 ) );
		}
		if ( ! WPHAVE_Campaigns_Email_Renderer::verify( $artifact ) ) {
			return new WP_Error( 'wphave_campaign_artifact_invalid', __( 'The email artifact failed its integrity check.', 'wphave' ) );
		}
		return update_post_meta( $campaign_id, self::META_ARTIFACT, $artifact ) ? true : ( get_post_meta( $campaign_id, self::META_ARTIFACT, true ) === $artifact ? true : new WP_Error( 'wphave_campaign_artifact_write_failed', __( 'The email artifact could not be persisted.', 'wphave' ) ) );
	}

	/** Return a verified prepared artifact. */
	public static function artifact( int $campaign_id ): array|WP_Error {
		$artifact = (array) get_post_meta( $campaign_id, self::META_ARTIFACT, true );
		return WPHAVE_Campaigns_Email_Renderer::verify( $artifact )
			? $artifact
			: new WP_Error( 'wphave_campaign_artifact_invalid', __( 'The prepared email artifact is missing or invalid.', 'wphave' ) );
	}

	/** Prevent the generic content endpoint from mutating a frozen campaign. */
	public static function guard_content_update($prepared_post, WP_REST_Request $request) {
		$campaign_id = absint($request['id'] ?? 0);
		if (!$campaign_id && !is_wp_error($prepared_post)) {
			return WPHAVE_Campaigns_Authority::run(static function () use ($prepared_post) {
				$prepared_post->meta_input = (array) ($prepared_post->meta_input ?? []);
				$prepared_post->meta_input[
					self::META_ORIGIN
				] = WPHAVE_Campaigns_Authority::current()['epoch'];
				return $prepared_post;
			});
		}

		if ($campaign_id && 'draft' !== self::state($campaign_id)['status']) {
			return new WP_Error(
				'wphave_campaign_content_locked',
				__(
					'Prepared mailings cannot be edited because their audience is already frozen.',
					'wphave'
				),
				['status' => 409]
			);
		}

		return $prepared_post;
	}

	/** Create or update custom tables through the central schema manager. */
	public static function install(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();
		$recipients = $wpdb->prefix . self::SNAPSHOTS_TABLE;
		$deliveries = $wpdb->prefix . self::DELIVERIES_TABLE;
		$events = $wpdb->prefix . self::EVENTS_TABLE;
		$suppressions = $wpdb->prefix . self::SUPPRESSIONS_TABLE;

		dbDelta( "CREATE TABLE {$recipients} (
			id bigint unsigned NOT NULL AUTO_INCREMENT,
			campaign_id bigint unsigned NOT NULL,
			subscriber_id bigint unsigned NOT NULL DEFAULT 0,
			email varchar(190) NOT NULL,
			email_hash char(64) NOT NULL,
			merge_data longtext DEFAULT NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY campaign_email (campaign_id,email_hash),
			KEY campaign_id (campaign_id)
		) {$charset};" );

		dbDelta( "CREATE TABLE {$deliveries} (
			id bigint unsigned NOT NULL AUTO_INCREMENT,
			campaign_id bigint unsigned NOT NULL,
			recipient_id bigint unsigned NOT NULL,
			provider varchar(50) NOT NULL,
			provider_message_id varchar(190) NOT NULL DEFAULT '',
			idempotency_key char(64) NOT NULL,
			status varchar(30) NOT NULL DEFAULT 'queued',
			attempts smallint unsigned NOT NULL DEFAULT 0,
			next_attempt_at datetime DEFAULT NULL,
			last_error text DEFAULT NULL,
			sent_at datetime DEFAULT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY idempotency_key (idempotency_key),
			KEY campaign_status_retry (campaign_id,status,next_attempt_at),
			KEY provider_message (provider,provider_message_id),
			KEY provider_status_sent (provider,status,sent_at)
		) {$charset};" );

		dbDelta( "CREATE TABLE {$events} (
			id bigint unsigned NOT NULL AUTO_INCREMENT,
			delivery_id bigint unsigned NOT NULL DEFAULT 0,
			provider varchar(50) NOT NULL,
			provider_event_id varchar(190) NOT NULL,
			type varchar(40) NOT NULL,
			payload longtext DEFAULT NULL,
			occurred_at datetime NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY provider_event (provider,provider_event_id),
			KEY delivery_type (delivery_id,type)
		) {$charset};" );

		dbDelta( "CREATE TABLE {$suppressions} (
			id bigint unsigned NOT NULL AUTO_INCREMENT,
			email_hash char(64) NOT NULL,
			email varchar(190) NOT NULL DEFAULT '',
			reason varchar(40) NOT NULL,
			source varchar(50) NOT NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY email_hash (email_hash),
			KEY reason (reason)
		) {$charset};" );

		self::backfill_status_projection();
	}

	/** Backfill the query projection introduced after the initial schema release. */
	private static function backfill_status_projection(): void {
		$campaign_ids = get_posts(
			array(
				'post_type' => self::POST_TYPE,
				'post_status' => array( 'draft', 'publish', 'private' ),
				'posts_per_page' => -1,
				'fields' => 'ids',
				'no_found_rows' => true,
			)
		);

		foreach ( $campaign_ids as $campaign_id ) {
			if ( ! metadata_exists( 'post', $campaign_id, self::META_STATUS ) ) {
				update_post_meta( $campaign_id, self::META_STATUS, self::state( (int) $campaign_id )['status'] );
			}
		}
	}

	/** Verify that every required operational table exists. */
	public static function schema_ready(): bool {
		global $wpdb;
		foreach ( array( self::SNAPSHOTS_TABLE, self::DELIVERIES_TABLE, self::EVENTS_TABLE, self::SUPPRESSIONS_TABLE ) as $table ) {
			$name = $wpdb->prefix . $table;
			if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $name ) ) ) !== $name ) {
				return false;
			}
		}
		return true;
	}

	/** Normalize mutable campaign configuration at the persistence boundary. */
	public static function sanitize_config( array $config ): array {
		return array(
			'subject' => sanitize_text_field( $config['subject'] ?? '' ),
			'preview_text' => sanitize_text_field( $config['preview_text'] ?? '' ),
			'from_name' => sanitize_text_field( $config['from_name'] ?? get_bloginfo( 'name' ) ),
			'from_email' => sanitize_email( $config['from_email'] ?? get_option( 'admin_email' ) ),
			'reply_to' => sanitize_email( $config['reply_to'] ?? '' ),
			'purpose' => sanitize_key( $config['purpose'] ?? 'newsletter' ),
			'segment' => array_intersect_key(
				array_map( 'sanitize_text_field', (array) ( $config['segment'] ?? array() ) ),
				array_flip( array( 'purpose', 'source', 'campaign' ) )
			),
			'scheduled_at' => sanitize_text_field( $config['scheduled_at'] ?? '' ),
			'design' => WPHAVE_Campaigns_Design::sanitize(
				(array) ( $config['design'] ?? WPHAVE_Campaigns_Design::current() )
			),
		);
	}

	/** Freeze the globally selected provider at the preparation boundary. */
	public static function freeze_provider( int $campaign_id, string $provider ): true|WP_Error {
		$config = (array) get_post_meta( $campaign_id, self::META_CONFIG, true );
		$config['provider'] = sanitize_key( $provider );
		update_post_meta( $campaign_id, self::META_CONFIG, $config );

		// DATA INTEGRITY INVARIANT: Queue rows and the worker configuration must
		// name the same frozen provider. A failed config write stops preparation
		// before any provider-specific delivery identity can be materialized.
		if ( $config !== get_post_meta( $campaign_id, self::META_CONFIG, true ) ) {
			return new WP_Error(
				'wphave_campaign_provider_write_failed',
				__( 'The mailing provider could not be frozen.', 'wphave' )
			);
		}

		return true;
	}

	/** Return the canonical read model for a campaign post. */
	public static function get(int $campaign_id): array|WP_Error {
		$post = get_post($campaign_id);
		if (!$post || self::POST_TYPE !== $post->post_type) {
			return new WP_Error('wphave_campaign_not_found', __('Mailing not found.', 'wphave'), [
				'status' => 404
			]);
		}
		return [
			'id' => $campaign_id,
			'title' => $post->post_title,
			'content' => $post->post_content,
			'status' => $post->post_status,
			'config' => (array) get_post_meta($campaign_id, self::META_CONFIG, true),
			'state' => self::state($campaign_id),
			'recoveryReviewRequired' => WPHAVE_Campaigns_Authority::review_required($campaign_id),
			'revision' => hash(
				'sha256',
				$post->post_modified_gmt .
					':' .
					wp_json_encode(get_post_meta($campaign_id, self::META_CONFIG, true))
			),
			'created_at' => $post->post_date_gmt,
			'updated_at' => $post->post_modified_gmt
		];
	}

	/**
	 * Return the compact projection used by campaign collection screens.
	 *
	 * Campaign HTML is deliberately excluded so list requests remain bounded as
	 * the number and size of campaigns grows.
	 */
	public static function list_item(WP_Post $post): array {
		$config = (array) get_post_meta($post->ID, self::META_CONFIG, true);
		$state = self::state($post->ID);

		return [
			'id' => $post->ID,
			'title' => $post->post_title,
			'subject' => (string) ($config['subject'] ?? ''),
			'provider' => (string) ($config['provider'] ?? 'wordpress'),
			'purpose' => (string) ($config['segment']['purpose'] ?? ($config['purpose'] ?? '')),
			'scheduled_at' => (string) ($config['scheduled_at'] ?? ''),
			'status' => (string) $state['status'],
			'recoveryReviewRequired' => WPHAVE_Campaigns_Authority::review_required($post->ID),
			'total' => (int) $state['total'],
			'processed' => (int) $state['processed'],
			'sent' => (int) $state['sent'],
			'failed' => (int) $state['failed'],
			'dead' => (int) $state['dead'],
			'created_at' => $post->post_date_gmt,
			'updated_at' => $post->post_modified_gmt
		];
	}

	/** Render the recipient-facing preview projected into PostManager collections. */
	public static function preview_html( int $campaign_id ): string {
		$campaign = self::get( $campaign_id );
		if ( is_wp_error( $campaign ) ) {
			return '';
		}

		$artifact = 'draft' === $campaign['state']['status']
			? WPHAVE_Campaigns_Email_Renderer::artifact( $campaign )
			: self::artifact( $campaign_id );
		if ( is_wp_error( $artifact ) ) {
			return '';
		}

		$message = WPHAVE_Campaigns_Email_Renderer::message(
			$campaign,
			array(
				'email' => 'preview@example.invalid',
				'merge_data' => wp_json_encode(
					array(
						'first_name' => __( 'Preview', 'wphave' ),
						'last_name' => __( 'Recipient', 'wphave' ),
					)
				),
				'unsubscribe_url' => '#unsubscribe',
			),
			$artifact
		);

		return is_wp_error( $message ) ? '' : (string) $message['html'];
	}

	/** Duplicate one mailing as an editable draft with rollback-safe document cloning. */
	public static function duplicate( int $campaign_id, string $title, $authorization_guard = null ) {
		$campaign = self::get( $campaign_id );
		if ( is_wp_error( $campaign ) ) {
			return $campaign;
		}

		$title = sanitize_text_field( $title );
		if ( '' === $title ) {
			return new WP_Error( 'wphave_campaign_title_required', __( 'A mailing title is required.', 'wphave' ), array( 'status' => 400 ) );
		}

		$document = WPHAVE_Documents_Storage::get( $campaign_id );
		if ( is_wp_error( $document ) ) {
			return $document;
		}

		$copy = self::save(
			array(
				'title' => $title,
				'content' => $campaign['content'],
				'config' => $campaign['config'],
			),
			0,
			$authorization_guard
		);
		if ( is_wp_error( $copy ) ) {
			return $copy;
		}

		$copy_id = (int) $copy['id'];
		$state = WPHAVE_Documents_Storage::get_state( $copy_id );
		// AUTHORIZATION/COMMIT INVARIANT: Duplication is one privileged workflow.
		// The same live caller policy guards both creation of the draft shell and
		// publication of its cloned canonical document; a denied document commit
		// rolls the incomplete shell back.
		$updated = is_wp_error( $state )
			? $state
			: WPHAVE_Documents_Storage::update( $copy_id, $document, $state['revision'], $authorization_guard );
		if ( is_wp_error( $updated ) ) {
			wp_delete_post( $copy_id, true );

			return $updated;
		}

		return array(
			'id' => $copy_id,
			'type' => self::POST_TYPE,
			'status' => 'draft',
			'title' => array(
				'raw' => $title,
				'rendered' => $title,
			),
		);
	}

	/** Persist a draft and allow WordPress to retain its native revisions. */
	public static function save(
		array $data,
		int $campaign_id = 0,
		$authorization_guard = null
	): array|WP_Error {
		return WPHAVE_Campaigns_Authority::run(
			static fn() => self::save_locked($data, $campaign_id, $authorization_guard)
		);
	}

	private static function save_locked(
		array $data,
		int $campaign_id,
		$authorization_guard
	): array|WP_Error {
		$is_new = !$campaign_id;
		$previous_post = $campaign_id ? get_post($campaign_id) : null;
		$previous_config_exists = $campaign_id
			? metadata_exists('post', $campaign_id, self::META_CONFIG)
			: false;
		$previous_config = $campaign_id
			? get_post_meta($campaign_id, self::META_CONFIG, true)
			: null;
		if ($campaign_id && 'draft' !== self::state($campaign_id)['status']) {
			return new WP_Error(
				'wphave_campaign_locked',
				__(
					'Prepared mailings cannot be edited because their audience is already frozen.',
					'wphave'
				),
				['status' => 409]
			);
		}
		$incoming_config = (array) ($data['config'] ?? []);
		if ($campaign_id) {
			$stored_config = (array) get_post_meta($campaign_id, self::META_CONFIG, true);
			$incoming_config['design'] =
				$stored_config['design'] ?? WPHAVE_Campaigns_Design::current();
		}
		$config = self::sanitize_config($incoming_config);
		$post_data = [
			'ID' => $campaign_id,
			'post_type' => self::POST_TYPE,
			'post_status' => 'draft',
			'post_title' => sanitize_text_field($data['title'] ?? ''),
			'post_content' => wp_kses_post($data['content'] ?? '')
		];

		// AUTHORIZATION/COMMIT INVARIANT: Draft normalization crosses sanitization
		// and configuration extension boundaries. A caller-owned policy must still
		// succeed after preparation and immediately before the first persistent post
		// mutation; every non-true result fails closed.
		if (is_callable($authorization_guard)) {
			$authorization = call_user_func($authorization_guard);
			if (true !== $authorization) {
				return is_wp_error($authorization)
					? $authorization
					: new WP_Error(
						'wphave_campaign_forbidden',
						__('You are not allowed to manage campaigns.', 'wphave'),
						['status' => 403]
					);
			}
		}

		// BIRTH INVARIANT: Only creation, never preparation or editing, assigns
		// origin authority. A restored old draft cannot impersonate a fresh mailing.
		if ($is_new) {
			$post_data['meta_input'] = [
				self::META_ORIGIN => WPHAVE_Campaigns_Authority::current()['epoch']
			];
		}
		$id = wp_insert_post($post_data, true);
		if (is_wp_error($id)) {
			return $id;
		}
		if (
			$is_new &&
			get_post_meta($id, self::META_ORIGIN, true) !==
				$post_data['meta_input'][self::META_ORIGIN]
		) {
			wp_delete_post($id, true);
			return WPHAVE_Campaigns_Authority::blocked();
		}
		update_post_meta($id, self::META_CONFIG, $config);

		// DATA/ROLLBACK INVARIANT: Campaign post fields and sanitized configuration
		// are one editable draft projection. Do not expose or retain a draft whose
		// exact config cannot be read back; create rolls back the post and update
		// restores the previous post/config snapshot before returning an error.
		if ($config !== get_post_meta($id, self::META_CONFIG, true)) {
			if ($is_new) {
				wp_delete_post($id, true);
			} elseif ($previous_post) {
				global $wpdb;
				$wpdb->update(
					$wpdb->posts,
					[
						'post_title' => $previous_post->post_title,
						'post_content' => $previous_post->post_content,
						'post_status' => $previous_post->post_status,
						'post_modified' => $previous_post->post_modified,
						'post_modified_gmt' => $previous_post->post_modified_gmt
					],
					['ID' => $id]
				);

				if ($previous_config_exists) {
					update_post_meta($id, self::META_CONFIG, $previous_config);
				} else {
					delete_post_meta($id, self::META_CONFIG);
				}

				clean_post_cache($id);
			}

			return new WP_Error(
				'wphave_campaign_config_write_failed',
				__('The mailing draft could not be saved.', 'wphave'),
				['status' => 500]
			);
		}

		delete_post_meta($id, self::META_ARTIFACT);
		if (!get_post_meta($id, self::META_STATE, true)) {
			self::set_state($id, ['status' => 'draft']);
		}
		if ($is_new && class_exists('WPHAVE_Documents_Storage')) {
			$document_state = WPHAVE_Documents_Storage::get_state((int) $id);
			if (!is_wp_error($document_state)) {
				$document = $document_state['document'];
				$document['settings']['design'] = $config['design'];
				$document['settings']['contentWidth'] = $config['design']['layout']['contentWidth'];
				$document['settings']['contentPadding'] =
					$config['design']['layout']['contentPadding'];
				$document['settings']['canvasSpacing'] =
					$config['design']['layout']['canvasSpacing'];
				$document['settings']['blockGap'] = $config['design']['layout']['blockGap'];
				$document['settings']['contentBackgroundColor'] =
					$config['design']['colors']['content'];
				WPHAVE_Documents_Storage::update((int) $id, $document, $document_state['revision']);
			}
		}
		return self::get($id);
	}

	/** Read the operational state with stable defaults. */
	public static function state(int $campaign_id): array {
		// READ INVARIANT: A worker cannot reuse metadata cached before a transition.
		wp_cache_delete($campaign_id, 'post_meta');
		return array_merge(
			[
				'status' => 'draft',
				'total' => 0,
				'processed' => 0,
				'sent' => 0,
				'failed' => 0,
				'dead' => 0
			],
			(array) get_post_meta($campaign_id, self::META_STATE, true)
		);
	}

	/** Apply a partial operational state update. */
	public static function set_state(int $campaign_id, array $patch): array|WP_Error {
		return WPHAVE_Campaigns_Authority::run(
			static fn() => self::set_state_locked($campaign_id, $patch)
		);
	}

	private static function set_state_locked(int $campaign_id, array $patch): array|WP_Error {
		$previous_state_exists = metadata_exists('post', $campaign_id, self::META_STATE);
		$previous_status_exists = metadata_exists('post', $campaign_id, self::META_STATUS);
		$previous_state = get_post_meta($campaign_id, self::META_STATE, true);
		$previous_status = get_post_meta($campaign_id, self::META_STATUS, true);
		$state = array_merge(self::state($campaign_id), $patch, [
			'updated_at' => current_time('mysql', true)
		]);
		$status = sanitize_key($state['status']);
		update_post_meta($campaign_id, self::META_STATE, $state);
		update_post_meta($campaign_id, self::META_STATUS, $status);

		// DATA/ROLLBACK INVARIANT: Operational Campaign state and its indexed status
		// are one lifecycle projection. Jobs and transitions may consume it only
		// after both exact values are canonical; a partial write restores value and
		// metadata-presence state before returning a fail-closed error.
		if (
			$state !== get_post_meta($campaign_id, self::META_STATE, true) ||
			$status !== get_post_meta($campaign_id, self::META_STATUS, true)
		) {
			$previous_state_exists
				? update_post_meta($campaign_id, self::META_STATE, $previous_state)
				: delete_post_meta($campaign_id, self::META_STATE);
			$previous_status_exists
				? update_post_meta($campaign_id, self::META_STATUS, $previous_status)
				: delete_post_meta($campaign_id, self::META_STATUS);

			return new WP_Error(
				'wphave_campaign_state_write_failed',
				__('The mailing state could not be saved.', 'wphave'),
				['status' => 500]
			);
		}

		return $state;
	}

	/** Replace an unsent audience snapshot atomically enough for a draft boundary. */
	public static function snapshot(int $campaign_id, array $recipients): int|WP_Error {
		global $wpdb;
		$table = $wpdb->prefix . self::SNAPSHOTS_TABLE;
		$deliveries = $wpdb->prefix . self::DELIVERIES_TABLE;
		$wpdb->last_error = '';
		$existing = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$deliveries} WHERE campaign_id = %d",
				$campaign_id
			)
		);
		// IDENTITY INVARIANT: A preparation retry cannot replace recipient ids to
		// which an already-materialized delivery queue still refers.
		if ($wpdb->last_error || null === $existing || (int) $existing > 0) {
			return new WP_Error(
				'wphave_campaign_snapshot_frozen',
				__(
					'This mailing already has delivery records. Create a new mailing instead of replacing its audience.',
					'wphave'
				),
				['status' => 409]
			);
		}

		// TRANSACTION INVARIANT: Replacing the previous audience may begin only
		// after the database confirms a real rollback boundary. A best-effort
		// ROLLBACK cannot recover deletes performed outside a transaction.
		if (false === $wpdb->query('START TRANSACTION')) {
			return new WP_Error(
				'wphave_campaign_snapshot_failed',
				__('The audience snapshot could not be created.', 'wphave')
			);
		}

		try {
			if (false === $wpdb->delete($table, ['campaign_id' => $campaign_id], ['%d'])) {
				throw new RuntimeException('snapshot_delete_failed');
			}

			foreach ($recipients as $recipient) {
				$merge_data = wp_json_encode([
					'first_name' => sanitize_text_field($recipient['first_name'] ?? ''),
					'last_name' => sanitize_text_field($recipient['last_name'] ?? '')
				]);
				if (false === $merge_data) {
					throw new RuntimeException('snapshot_encoding_failed');
				}

				$inserted = $wpdb->insert($table, [
					'campaign_id' => $campaign_id,
					'subscriber_id' => absint($recipient['id'] ?? 0),
					'email' => sanitize_email($recipient['email'] ?? ''),
					'email_hash' => sanitize_text_field($recipient['email_hash'] ?? ''),
					'merge_data' => $merge_data,
					'created_at' => current_time('mysql', true)
				]);
				if (false === $inserted) {
					throw new RuntimeException('snapshot_insert_failed');
				}
			}

			if (false === $wpdb->query('COMMIT')) {
				throw new RuntimeException('snapshot_commit_failed');
			}

			return count($recipients);
		} catch (Throwable $error) {
			$wpdb->query('ROLLBACK');
			return new WP_Error(
				'wphave_campaign_snapshot_failed',
				__('The audience snapshot could not be created.', 'wphave')
			);
		}
	}

	/** IDEMPOTENCY INVARIANT: Materialize one queued delivery per snapshot recipient. */
	public static function queue_deliveries( int $campaign_id, string $provider ): int|WP_Error {
		global $wpdb;
		$recipients = $wpdb->prefix . self::SNAPSHOTS_TABLE;
		$deliveries = $wpdb->prefix . self::DELIVERIES_TABLE;
		$now = current_time( 'mysql', true );
		$wpdb->last_error = '';
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT id, email_hash FROM {$recipients} WHERE campaign_id = %d", $campaign_id ), ARRAY_A );
		if ( ! is_array( $rows ) || $wpdb->last_error || false === $wpdb->query( 'START TRANSACTION' ) ) {
			return new WP_Error( 'wphave_campaign_queue_failed', __( 'The delivery queue could not be created.', 'wphave' ) );
		}

		/*
		 * DATA INTEGRITY INVARIANT: One preparation attempt commits either every
		 * snapshot delivery or none. A partial queue must never be advertised as
		 * ready or scheduled, because omitted recipients cannot be reconstructed by
		 * the worker from the reported total.
		 */
		try {
			foreach ( $rows as $row ) {
				$inserted = $wpdb->query(
					$wpdb->prepare(
						"INSERT IGNORE INTO {$deliveries} (campaign_id,recipient_id,provider,idempotency_key,status,attempts,next_attempt_at,updated_at) VALUES (%d,%d,%s,%s,'queued',0,%s,%s)",
						$campaign_id,
						$row['id'],
						$provider,
						hash( 'sha256', $campaign_id . ':' . $row['email_hash'] ),
						$now,
						$now
					)
				);

				if ( false === $inserted ) {
					throw new RuntimeException( 'delivery_insert_failed' );
				}
			}

			$materialized = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*) FROM {$deliveries} d INNER JOIN {$recipients} r ON r.id=d.recipient_id WHERE d.campaign_id=%d AND r.campaign_id=%d",
					$campaign_id,
					$campaign_id
				)
			);
			if ( $wpdb->last_error || count( $rows ) !== $materialized || false === $wpdb->query( 'COMMIT' ) ) {
				throw new RuntimeException( 'delivery_commit_failed' );
			}

			return $materialized;
		} catch ( Throwable $error ) {
			$wpdb->query( 'ROLLBACK' );

			return new WP_Error( 'wphave_campaign_queue_failed', __( 'The delivery queue could not be created.', 'wphave' ) );
		}
	}

	/** Check the global suppression ledger. */
	public static function is_suppressed(string $email_hash, ?string $email = null): bool|WP_Error {
		global $wpdb;
		$table = $wpdb->prefix . self::SUPPRESSIONS_TABLE;
		$wpdb->last_error = '';
		// CONSENT IDENTITY INVARIANT: Historical HMACs may use retired login salts.
		// The canonical email retained in the ledger bridges salt changes and imports.
		$query =
			null === $email
				? $wpdb->prepare(
					"SELECT 1 FROM {$table} WHERE email_hash = %s LIMIT 1",
					$email_hash
				)
				: $wpdb->prepare(
					"SELECT 1 FROM {$table} WHERE email_hash = %s OR LOWER(email) = %s LIMIT 1",
					$email_hash,
					strtolower($email)
				);
		$suppressed = $wpdb->get_var($query);

		// CONSENT INVARIANT: Failure to read the global suppression ledger is
		// unknown recipient authority, never evidence that sending is permitted.
		if ($wpdb->last_error) {
			return new WP_Error(
				'wphave_campaign_suppression_unavailable',
				__('Recipient suppression state could not be verified.', 'wphave')
			);
		}

		return (bool) $suppressed;
	}

	/** Upsert a durable global suppression. */
	public static function suppress(string $email, string $reason, string $source): bool {
		// CONSENT INVARIANT: No opt-out can commit between preservation and table swap.
		$result = WPHAVE_Campaigns_Authority::run(static function () use (
			$email,
			$reason,
			$source
		) {
			$authority = WPHAVE_Campaigns_Authority::current();
			// Acknowledged opt-outs cannot land on a table awaiting possible rollback.
			if ('' !== $authority['restore'] && !$authority['ready']) {
				return false;
			}
			return self::suppress_locked($email, $reason, $source);
		});
		return true === $result;
	}

	private static function suppress_locked(string $email, string $reason, string $source): bool {
		global $wpdb;
		$table = $wpdb->prefix . self::SUPPRESSIONS_TABLE;
		$normalized_email = sanitize_email($email);

		// DATA INTEGRITY INVARIANT: A suppression is successful only when the exact
		// canonical recipient identity is durably committed. Callers use this result
		// to withhold notifications and preserve retry authority on write failure.
		if ($normalized_email !== $email || !is_email($normalized_email)) {
			return false;
		}

		$written = $wpdb->replace($table, [
			'email_hash' => WPHAVE_Campaigns_Audience::email_hash($normalized_email),
			'email' => $normalized_email,
			'reason' => sanitize_key($reason),
			'source' => sanitize_key($source),
			'created_at' => current_time('mysql', true)
		]);

		return false !== $written;
	}
}
