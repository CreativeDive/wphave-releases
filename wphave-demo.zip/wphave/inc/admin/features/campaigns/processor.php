<?php

/**
 * IDEMPOTENCY INVARIANT: Delivery identity makes this campaign batch processor retryable.
 *
 * @package wphave
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WPHAVE_Campaigns_Processor {
	// STOP INVARIANT: One provider call per non-expiring authority section lets
	// lifecycle requests linearize between recipients, never halfway through a send.
	private const BATCH_SIZE = 1;
	private const MAX_ATTEMPTS = 5;

	/** Process one bounded batch and schedule continuation when work remains. */
	public static function run(int $campaign_id): void {
		$result = WPHAVE_Campaigns_Authority::run(static function () use ($campaign_id): void {
			if (!WPHAVE_Campaigns_Authority::allows($campaign_id)) {
				return;
			}
			self::run_authorized($campaign_id);
		});
		if (is_wp_error($result)) {
			WPHAVE_Background_Job_Scheduler::ensure_continuation(
				WPHAVE_Campaigns_Service::WORK_HOOK,
				[$campaign_id],
				30
			);
		}
	}

	private static function run_authorized(int $campaign_id): void {
		global $wpdb;
		$state = WPHAVE_Campaigns_Repository::state($campaign_id);
		if (!in_array($state['status'], ['scheduled', 'queued', 'sending', 'failed'], true)) {
			return;
		}
		$campaign = WPHAVE_Campaigns_Repository::get($campaign_id);
		if (is_wp_error($campaign)) {
			return;
		}
		$artifact = WPHAVE_Campaigns_Repository::artifact($campaign_id);
		if (is_wp_error($artifact)) {
			self::set_worker_state($campaign_id, ['status' => 'failed']);
			return;
		}
		$provider = WPHAVE_Campaigns_Provider_Registry::get(
			$campaign['config']['provider'] ?? 'wordpress'
		);
		if (!$provider) {
			self::set_worker_state($campaign_id, ['status' => 'failed']);
			return;
		}
		$lock_token = WPHAVE_Campaigns_Delivery_Policy::acquire();
		if (!$lock_token) {
			WPHAVE_Background_Job_Scheduler::ensure_continuation(
				WPHAVE_Campaigns_Service::WORK_HOOK,
				[$campaign_id],
				10
			);
			return;
		}

		try {
			self::run_locked($campaign_id, $campaign, $artifact, $provider, $lock_token);
		} finally {
			WPHAVE_Campaigns_Delivery_Policy::release($lock_token);
		}
	}

	/** Process a batch while holding the global campaign delivery lease. */
	private static function run_locked(
		int $campaign_id,
		array $campaign,
		array $artifact,
		WPHAVE_Campaigns_Email_Provider_Interface $provider,
		string $lock_token
	): void {
		global $wpdb;
		$provider_key = $provider->key();
		$allowance = WPHAVE_Campaigns_Delivery_Policy::allowance($provider_key, self::BATCH_SIZE);
		if ($allowance['available'] < 1) {
			self::set_worker_state($campaign_id, ['status' => 'sending']);
			WPHAVE_Background_Job_Scheduler::ensure_continuation(
				WPHAVE_Campaigns_Service::WORK_HOOK,
				[$campaign_id],
				(int) $allowance['retry_after']
			);
			return;
		}

		$deliveries = $wpdb->prefix . WPHAVE_Campaigns_Repository::DELIVERIES_TABLE;
		$recipients = $wpdb->prefix . WPHAVE_Campaigns_Repository::SNAPSHOTS_TABLE;
		$now = current_time('mysql', true);
		$wpdb->last_error = '';
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT d.*, r.email, r.email_hash, r.merge_data FROM {$deliveries} d INNER JOIN {$recipients} r ON r.id = d.recipient_id WHERE d.campaign_id = %d AND d.status IN ('queued','retry') AND (d.next_attempt_at IS NULL OR d.next_attempt_at <= %s) ORDER BY d.id ASC LIMIT %d",
				$campaign_id,
				$now,
				(int) $allowance['available']
			),
			ARRAY_A
		);

		// DATA INTEGRITY INVARIANT: Unknown queue state is never an empty queue.
		// A failed batch read must preserve all delivery rows and cannot advance the
		// campaign toward completion; a bounded retry remains scheduled instead.
		if (!is_array($rows) || $wpdb->last_error) {
			self::set_worker_state($campaign_id, ['status' => 'failed']);
			WPHAVE_Background_Job_Scheduler::ensure_continuation(
				WPHAVE_Campaigns_Service::WORK_HOOK,
				[$campaign_id],
				30
			);
			return;
		}

		$state_update = self::set_worker_state($campaign_id, [
			'status' => 'sending'
		]);
		// DELIVERY/COMMIT INVARIANT: Provider delivery begins only after the exact
		// sending projection is durable. Unknown lifecycle state remains queued and
		// receives a bounded retry without crossing the external side-effect boundary.
		if (is_wp_error($state_update)) {
			WPHAVE_Background_Job_Scheduler::ensure_continuation(
				WPHAVE_Campaigns_Service::WORK_HOOK,
				[$campaign_id],
				30
			);
			return;
		}

		// LIVENESS INVARIANT: Schedule recovery before the first irreversible send,
		// so a terminated PHP process cannot strand the remaining queued recipients.
		if (
			$rows &&
			!WPHAVE_Background_Job_Scheduler::ensure_continuation(
				WPHAVE_Campaigns_Service::WORK_HOOK,
				[$campaign_id],
				1
			)
		) {
			self::set_worker_state($campaign_id, ['status' => 'failed']);
			return;
		}

		foreach ($rows as $row) {
			// LEASE INVARIANT: A slow transport cannot grant this worker authority
			// over later recipients after a successor has acquired the delivery lease.
			if (!WPHAVE_Campaigns_Delivery_Policy::refresh($lock_token)) {
				return;
			}
			$suppressed = WPHAVE_Campaigns_Repository::is_suppressed(
				$row['email_hash'],
				$row['email']
			);
			if (is_wp_error($suppressed)) {
				// DELIVERY INVARIANT: The provider boundary is reachable only after a
				// successful consent/suppression read for this exact recipient.
				self::set_worker_state($campaign_id, ['status' => 'failed']);
				WPHAVE_Background_Job_Scheduler::ensure_continuation(
					WPHAVE_Campaigns_Service::WORK_HOOK,
					[$campaign_id],
					30
				);
				return;
			}

			if ($suppressed) {
				if (
					!self::mark(
						(int) $row['id'],
						'suppressed',
						(int) $row['attempts'],
						'',
						__('Recipient is suppressed.', 'wphave')
					)
				) {
					self::defer_after_unknown_delivery_commit($campaign_id);
					return;
				}
				continue;
			}
			$message = WPHAVE_Campaigns_Service::message($campaign, $row, $artifact);
			if (is_wp_error($message)) {
				if (
					!self::mark(
						(int) $row['id'],
						'dead',
						self::MAX_ATTEMPTS,
						'',
						$message->get_error_message()
					)
				) {
					self::defer_after_unknown_delivery_commit($campaign_id);
					return;
				}
				continue;
			}
			// IDEMPOTENCY INVARIANT: Provider retries reuse the persisted delivery key;
			// a retry never manufactures a second logical message identity.
			$message['idempotency_key'] = $row['idempotency_key'];
			$attempts = (int) $row['attempts'] + 1;
			// DELIVERY INVARIANT: Persist uncertainty BEFORE the external side effect.
			// A crash, timeout or failed result commit leaves an observable record
			// which ordinary queue retries and campaign resume can never resend.
			$claimed = $wpdb->query(
				$wpdb->prepare(
					"UPDATE {$deliveries} SET status = 'uncertain', attempts = %d, updated_at = %s, next_attempt_at = NULL WHERE id = %d AND status IN ('queued','retry') AND attempts = %d",
					$attempts,
					current_time('mysql', true),
					(int) $row['id'],
					(int) $row['attempts']
				)
			);
			if (1 !== $claimed) {
				self::defer_after_unknown_delivery_commit($campaign_id);
				return;
			}
			try {
				$result = $provider->send($message);
			} catch (Throwable $error) {
				self::defer_after_unknown_delivery_commit($campaign_id);
				return;
			}
			// RESPONSE INVARIANT: An adapter's malformed success response is still an
			// unknown delivery. It cannot authorize a sent projection or another send.
			if (
				!is_wp_error($result) &&
				(!is_array($result) ||
					!is_string($result['message_id'] ?? null) ||
					'' === $result['message_id'])
			) {
				self::defer_after_unknown_delivery_commit($campaign_id);
				return;
			}
			if (is_wp_error($result)) {
				if (WPHAVE_Campaigns_Delivery_Policy::is_transient_error($result)) {
					$error_data = $result->get_error_data();
					$retry_after = is_array($error_data)
						? absint($error_data['retry_after'] ?? 0)
						: 0;
					WPHAVE_Campaigns_Delivery_Policy::register_transient_failure(
						$provider_key,
						$retry_after > 0 ? $retry_after : null
					);
				}
				$error_data = $result->get_error_data();
				// PROVIDER CONTRACT: Errors are ambiguous unless the adapter positively
				// proves rejection before acceptance. A stable message key alone does
				// not promise deduplication by SMTP or an arbitrary registered provider.
				$rejected =
					is_array($error_data) &&
					true === ($error_data['delivery_not_accepted'] ?? false);
				$status = $rejected
					? ($attempts >= self::MAX_ATTEMPTS
						? 'dead'
						: 'retry')
					: 'uncertain';
				if (
					!self::mark(
						(int) $row['id'],
						$status,
						$attempts,
						'',
						$result->get_error_message()
					)
				) {
					self::defer_after_unknown_delivery_commit($campaign_id);
					return;
				}
				if (WPHAVE_Campaigns_Delivery_Policy::is_transient_error($result)) {
					break;
				}
				continue;
			}
			if (
				!self::mark(
					(int) $row['id'],
					'sent',
					$attempts,
					sanitize_text_field($result['message_id'] ?? ''),
					''
				)
			) {
				self::defer_after_unknown_delivery_commit($campaign_id);
				return;
			}
		}

		$wpdb->last_error = '';
		$counts = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT status, COUNT(*) total FROM {$deliveries} WHERE campaign_id = %d GROUP BY status",
				$campaign_id
			),
			OBJECT_K
		);
		// COMPLETION INVARIANT: Completion is derived only from a successful full
		// status projection. A database error is unknown work, never zero pending.
		if (!is_array($counts) || $wpdb->last_error) {
			self::set_worker_state($campaign_id, ['status' => 'failed']);
			WPHAVE_Background_Job_Scheduler::ensure_continuation(
				WPHAVE_Campaigns_Service::WORK_HOOK,
				[$campaign_id],
				30
			);
			return;
		}

		$pending = (int) ($counts['queued']->total ?? 0) + (int) ($counts['retry']->total ?? 0);
		$sent = (int) ($counts['sent']->total ?? 0);
		$dead = (int) ($counts['dead']->total ?? 0);
		$uncertain = (int) ($counts['uncertain']->total ?? 0);
		$failed = $dead + $uncertain + (int) ($counts['suppressed']->total ?? 0);
		$status = $pending
			? 'sending'
			: ($dead || $uncertain
				? 'completed_with_errors'
				: 'completed');
		self::set_worker_state($campaign_id, [
			'status' => $status,
			'processed' => $sent + $failed,
			'sent' => $sent,
			'failed' => $failed,
			'dead' => $dead,
			'uncertain' => $uncertain
		]);
		if ($pending) {
			WPHAVE_Background_Job_Scheduler::ensure_continuation(
				WPHAVE_Campaigns_Service::WORK_HOOK,
				[$campaign_id],
				1
			);
		}
	}

	/** Persist a delivery result and exponential retry deadline. */
	private static function mark(
		int $delivery_id,
		string $status,
		int $attempts,
		string $message_id,
		string $error
	): bool {
		global $wpdb;
		$delay = min(HOUR_IN_SECONDS, 30 * 2 ** max(0, $attempts - 1));
		$result = $wpdb->update(
			$wpdb->prefix . WPHAVE_Campaigns_Repository::DELIVERIES_TABLE,
			[
				'status' => $status,
				'attempts' => $attempts,
				'provider_message_id' => $message_id,
				'last_error' => $error,
				'next_attempt_at' =>
					'retry' === $status ? gmdate('Y-m-d H:i:s', time() + $delay) : null,
				'sent_at' => 'sent' === $status ? current_time('mysql', true) : null,
				'updated_at' => current_time('mysql', true)
			],
			['id' => $delivery_id]
		);

		// DELIVERY/COMMIT INVARIANT: After any provider decision, the exact delivery
		// row must acknowledge its result before this batch may touch another recipient
		// or derive completion. An unknown write stops the batch at this boundary.
		return 1 === $result;
	}

	/** Extension callbacks cannot make a stopped campaign runnable again. */
	private static function set_worker_state(int $campaign_id, array $patch): array|WP_Error {
		$state = WPHAVE_Campaigns_Repository::state($campaign_id);
		// STOP INVARIANT: Preserve a pause/cancel acknowledged by an in-process
		// provider callback too; reentrant code shares the lock but not stop authority.
		if (!in_array($state['status'], ['scheduled', 'queued', 'sending', 'failed'], true)) {
			return new WP_Error(
				'wphave_campaign_stopped',
				__('This mailing has stopped.', 'wphave'),
				['status' => 409]
			);
		}
		return WPHAVE_Campaigns_Repository::set_state($campaign_id, $patch);
	}

	/** Stop a batch whose last delivery decision could not be persisted. */
	private static function defer_after_unknown_delivery_commit(int $campaign_id): void {
		self::set_worker_state($campaign_id, ['status' => 'failed']);
		WPHAVE_Background_Job_Scheduler::ensure_continuation(
			WPHAVE_Campaigns_Service::WORK_HOOK,
			[$campaign_id],
			30
		);
	}
}
