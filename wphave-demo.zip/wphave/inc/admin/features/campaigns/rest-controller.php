<?php

/** Campaign administration, test-send and provider-event REST boundary. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WPHAVE_Campaigns_REST_Controller {
	/** Maximum encoded one-click unsubscribe grant accepted publicly. */
	private const MAX_UNSUBSCRIBE_PAYLOAD_BYTES = 4096;

	/** Maximum raw provider-event document retained for diagnostics. */
	private const MAX_PROVIDER_EVENT_PAYLOAD_BYTES = 65536;

	/** Maximum external event and message identifier length. */
	private const MAX_PROVIDER_IDENTIFIER_BYTES = 255;

	public static function init(): void {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	/** Register capability-scoped administration routes and narrow public callbacks. */
	public static function routes(): void {
		$manage = array( __CLASS__, 'can_manage' );
		register_rest_route(
			'wphave/v1',
			'/campaigns',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'list' ),
					'permission_callback' => $manage,
					'args'                => self::list_args(),
				),
				array(
					'methods' => 'POST',
					'callback' => array( __CLASS__, 'save' ),
					'permission_callback' => $manage,
					'args' => self::campaign_args(),
				),
			)
		);
		register_rest_route(
			'wphave/v1',
			'/campaigns/(?P<id>\d+)',
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'get' ), 'permission_callback' => $manage ),
				array(
					'methods' => 'POST',
					'callback' => array( __CLASS__, 'save' ),
					'permission_callback' => $manage,
					'args' => array_merge( self::id_args(), self::campaign_args() ),
				),
			)
		);
		register_rest_route( 'wphave/v1', '/campaigns/(?P<id>\d+)/prepare', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'prepare' ), 'permission_callback' => $manage, 'args' => self::id_args() ) );
		register_rest_route( 'wphave/v1', '/campaigns/(?P<id>\d+)/transition', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'transition' ), 'permission_callback' => $manage, 'args' => array_merge( self::id_args(), array( 'action' => array( 'type' => 'string', 'enum' => array( 'pause', 'resume', 'cancel' ), 'required' => true ) ) ) ) );
		register_rest_route( 'wphave/v1', '/campaigns/(?P<id>\d+)/test', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'test_send' ), 'permission_callback' => $manage, 'args' => array_merge( self::id_args(), array( 'email' => array( 'type' => 'string', 'format' => 'email', 'required' => true ) ) ) ) );
		register_rest_route(
			'wphave/v1',
			'/campaigns/(?P<id>\d+)/preview',
			array(
				'methods' => 'POST',
				'callback' => array( __CLASS__, 'preview' ),
				'permission_callback' => $manage,
				'args' => array_merge(
					self::id_args(),
					array( 'content' => array( 'type' => 'string', 'required' => false ) )
				),
			)
		);
		register_rest_route( 'wphave/v1', '/campaigns/(?P<id>\d+)/report', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'report' ), 'permission_callback' => $manage ) );
		register_rest_route( 'wphave/v1', '/campaigns/(?P<id>\d+)/revisions', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'revisions' ), 'permission_callback' => $manage ) );
		register_rest_route(
			'wphave/v1',
			'/campaigns/(?P<id>\d+)/duplicate',
			array(
				'methods' => 'POST',
				'callback' => array( __CLASS__, 'duplicate' ),
				'permission_callback' => $manage,
				'args' => array_merge(
					self::id_args(),
					array(
						'title' => array(
							'type' => 'string',
							'minLength' => 1,
							'required' => true,
						),
					)
				),
			)
		);
		register_rest_route( 'wphave/v1', '/campaigns/providers', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'providers' ), 'permission_callback' => $manage ) );
		register_rest_route( 'wphave/v1', '/campaigns/templates', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'templates' ), 'permission_callback' => $manage ) );
		register_rest_route(
			'wphave/v1',
			'/campaigns/templates/(?P<id>\d+)/duplicate',
			array(
				'methods' => 'POST',
				'callback' => array( __CLASS__, 'duplicate_template' ),
				'permission_callback' => $manage,
				'args' => array_merge(
					self::id_args(),
					array(
						'title' => array(
							'type' => 'string',
							'minLength' => 1,
							'required' => true,
						),
					)
				),
			)
		);
		register_rest_route(
			'wphave/v1',
			'/campaigns/templates/(?P<id>\d+)/create-mailing',
			array(
				'methods' => 'POST',
				'callback' => array( __CLASS__, 'create_from_template' ),
				'permission_callback' => $manage,
				'args' => self::id_args(),
			)
		);
		register_rest_route(
			'wphave/v1',
			'/campaigns/unsubscribe',
			array(
				'methods' => array( 'GET', 'POST' ),
				'callback' => array( __CLASS__, 'unsubscribe' ),
				'permission_callback' => '__return_true',
				'args' => array(
					'payload' => array( 'type' => 'string', 'maxLength' => self::MAX_UNSUBSCRIBE_PAYLOAD_BYTES, 'required' => true ),
					'signature' => array( 'type' => 'string', 'pattern' => '^[a-f0-9]{64}$', 'required' => true ),
				),
			)
		);
		register_rest_route(
			'wphave/v1',
			'/campaigns/provider-events/(?P<provider>[a-z0-9_-]+)',
			array(
				'methods' => 'POST',
				'callback' => array( __CLASS__, 'provider_event' ),
				'permission_callback' => '__return_true',
				'args' => array(
					'provider' => array( 'type' => 'string', 'pattern' => '^[a-z0-9_-]+$', 'maxLength' => 64, 'required' => true ),
					'id' => array( 'type' => 'string', 'maxLength' => self::MAX_PROVIDER_IDENTIFIER_BYTES, 'required' => true ),
					'message_id' => array( 'type' => 'string', 'maxLength' => self::MAX_PROVIDER_IDENTIFIER_BYTES, 'required' => true ),
					'type' => array( 'type' => 'string', 'enum' => array( 'delivered', 'opened', 'clicked', 'bounced', 'complained' ), 'required' => true ),
				),
			)
		);
	}

	/** Return the canonical Campaign administration policy. */
	public static function can_manage(): bool {
		return current_user_can( 'manage_options' ) || current_user_can( 'wphave_manage_audience' );
	}

	/** Require Campaign administration at a final callback boundary. */
	private static function require_manage() {
		// AUTHORIZATION INVARIANT: Campaign callbacks never inherit authority from
		// REST dispatch. This final check protects persistence, queue transitions,
		// audience freezing, duplication and externally visible test delivery.
		return self::can_manage()
			? true
			: new WP_Error( 'wphave_campaign_forbidden', __( 'You are not allowed to manage campaigns.', 'wphave' ), array( 'status' => 403 ) );
	}

	/** REST schema for campaign path identities. */
	private static function id_args(): array {
		return array( 'id' => array( 'type' => 'integer', 'minimum' => 1, 'required' => true ) );
	}

	/** REST schema for mutable draft fields. */
	private static function campaign_args(): array {
		return array(
			'title' => array( 'type' => 'string', 'required' => true ),
			'content' => array( 'type' => 'string', 'required' => true ),
			'config' => array( 'type' => 'object', 'required' => true ),
		);
	}

	/** REST schema for the server-side campaign collection. */
	private static function list_args(): array {
		return array(
			'page'     => array( 'type' => 'integer', 'minimum' => 1, 'default' => 1 ),
			'per_page' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 100, 'default' => 20 ),
			's'        => array( 'type' => 'string', 'default' => '' ),
			'status'   => array(
				'type'    => 'string',
				'enum'    => array( '', 'draft', 'scheduled', 'queued', 'sending', 'paused', 'completed', 'completed_with_errors', 'failed', 'cancelled' ),
				'default' => '',
			),
			'orderby'  => array(
				'type'    => 'string',
				'enum'    => array( 'modified', 'date', 'title' ),
				'default' => 'modified',
			),
			'order'    => array( 'type' => 'string', 'enum' => array( 'asc', 'desc' ), 'default' => 'desc' ),
		);
	}

	/** Return a bounded campaign collection and a status summary for navigation. */
	public static function list( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		// AUTHORIZATION INVARIANT: Administrative Campaign reads repeat the same domain capability at every executable callback before querying content, configuration, providers or delivery state.
		$permission = self::require_manage();
		if ( is_wp_error( $permission ) ) {
			return $permission;
		}

		$status = sanitize_key( (string) $request->get_param( 'status' ) );
		$args   = array(
			'post_type'      => WPHAVE_Campaigns_Repository::POST_TYPE,
			'post_status'    => array( 'draft', 'publish', 'private' ),
			'paged'          => max( 1, absint( $request->get_param( 'page' ) ) ),
			'posts_per_page' => min( 100, max( 1, absint( $request->get_param( 'per_page' ) ) ) ),
			's'              => sanitize_text_field( (string) $request->get_param( 's' ) ),
			'orderby'        => sanitize_key( (string) $request->get_param( 'orderby' ) ),
			'order'          => 'asc' === strtolower( (string) $request->get_param( 'order' ) ) ? 'ASC' : 'DESC',
		);

		if ( $status ) {
			$args['meta_query'] = array(
				array(
					'key' => WPHAVE_Campaigns_Repository::META_STATUS,
					'value' => $status,
				),
			);
		}

		$query = new WP_Query( $args );
		$payload = array(
			'items'   => array_map( array( 'WPHAVE_Campaigns_Repository', 'list_item' ), $query->posts ),
			'total'   => (int) $query->found_posts,
			'pages'   => (int) $query->max_num_pages,
			'page'    => (int) $args['paged'],
			'summary' => self::campaign_status_summary(),
		);

		// AUTHORIZATION/DISCLOSURE INVARIANT: Campaign collection queries, item
		// projection and status aggregation cross filterable WordPress and database
		// boundaries. Management authority must remain valid after the complete
		// payload exists and immediately before any private catalog data is released.
		$permission = self::require_manage();
		if ( is_wp_error( $permission ) ) {
			return $permission;
		}

		return rest_ensure_response( $payload );
	}

	/** Count operational states without loading campaign content into memory. */
	private static function campaign_status_summary(): array {
		global $wpdb;
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT pm.meta_value AS status, COUNT(*) AS total
				FROM {$wpdb->posts} p
				INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = %s
				WHERE p.post_type = %s AND p.post_status IN ('draft','publish','private')
				GROUP BY pm.meta_value",
				WPHAVE_Campaigns_Repository::META_STATUS,
				WPHAVE_Campaigns_Repository::POST_TYPE
			),
			ARRAY_A
		);
		$summary = array( 'all' => 0 );

		foreach ( $rows as $row ) {
			$status = sanitize_key( $row['status'] );
			$total = (int) $row['total'];
			$summary[ $status ] = $total;
			$summary['all'] += $total;
		}

		return $summary;
	}

	public static function get( WP_REST_Request $request ) {
		$permission = self::require_manage();
		if ( is_wp_error( $permission ) ) {
			return $permission;
		}

		$campaign = WPHAVE_Campaigns_Repository::get( absint( $request['id'] ) );
		if ( is_wp_error( $campaign ) ) {
			return $campaign;
		}

		// AUTHORIZATION/DISCLOSURE INVARIANT: A Campaign item is assembled across
		// filterable post and metadata reads. Revalidate management authority after
		// that complete private projection and immediately before publishing it.
		$permission = self::require_manage();
		if ( is_wp_error( $permission ) ) {
			return $permission;
		}

		return rest_ensure_response( $campaign );
	}

	public static function save( WP_REST_Request $request ) {
		$permission = self::require_manage();
		if ( is_wp_error( $permission ) ) {
			return $permission;
		}
		$result = WPHAVE_Campaigns_Repository::save(
			(array) $request->get_json_params(),
			absint( $request['id'] ?? 0 ),
			static function () {
				return self::require_manage();
			}
		);
		return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
	}

	public static function prepare( WP_REST_Request $request ) {
		$permission = self::require_manage();
		if ( is_wp_error( $permission ) ) {
			return $permission;
		}
		$result = WPHAVE_Campaigns_Service::prepare(
			absint( $request['id'] ),
			static function () {
				return self::require_manage();
			}
		);
		return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
	}

	public static function transition( WP_REST_Request $request ) {
		$permission = self::require_manage();
		if ( is_wp_error( $permission ) ) {
			return $permission;
		}

		$action = sanitize_key( $request->get_param( 'action' ) );
		// AUTHORIZATION/COMMIT INVARIANT: Transition normalization is a filterable
		// boundary before queue state changes. Campaign authority must remain valid
		// after the action is canonicalized and immediately before the lifecycle
		// service mutates status or schedules resumed delivery.
		$permission = self::require_manage();
		if ( is_wp_error( $permission ) ) {
			return $permission;
		}

		$result = WPHAVE_Campaigns_Service::transition( absint( $request['id'] ), $action );
		return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
	}

	public static function test_send( WP_REST_Request $request ) {
		$permission = self::require_manage();
		if ( is_wp_error( $permission ) ) {
			return $permission;
		}
		$campaign = WPHAVE_Campaigns_Repository::get( absint( $request['id'] ) );
		if ( is_wp_error( $campaign ) ) {
			return $campaign;
		}
		$email = sanitize_email( $request->get_param( 'email' ) );
		if ( ! is_email( $email ) ) {
			return new WP_Error( 'wphave_campaign_test_email_invalid', __( 'A valid test address is required.', 'wphave' ), array( 'status' => 400 ) );
		}
		$artifact = 'draft' === $campaign['state']['status']
			? WPHAVE_Campaigns_Email_Renderer::artifact( $campaign )
			: WPHAVE_Campaigns_Repository::artifact( (int) $campaign['id'] );
		if ( is_wp_error( $artifact ) ) {
			return $artifact;
		}
		$message = WPHAVE_Campaigns_Service::message( $campaign, array( 'email' => $email, 'merge_data' => '{}' ), $artifact );
		if ( is_wp_error( $message ) ) {
			return $message;
		}
		$provider_key = 'draft' === $campaign['state']['status']
			? WPHAVE_Campaigns_Provider_Registry::default_key()
			: ( $campaign['config']['provider'] ?? WPHAVE_Campaigns_Provider_Registry::default_key() );
		// AUTHORIZATION/DELIVERY INVARIANT: Recipient normalization, document
		// rendering and provider selection are extensible preparation boundaries.
		// Campaign authority must still be live immediately before the externally
		// visible test message is handed to its delivery provider.
		$permission = self::require_manage();
		if ( is_wp_error( $permission ) ) {
			return $permission;
		}
		$result = WPHAVE_Campaigns_Service::send_transactional( $message, $provider_key );
		return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
	}

	/** Render an isolated sample through the exact production renderer. */
	public static function preview( WP_REST_Request $request ) {
		$permission = self::require_manage();
		if ( is_wp_error( $permission ) ) {
			return $permission;
		}

		$campaign = WPHAVE_Campaigns_Repository::get( absint( $request['id'] ) );
		if ( is_wp_error( $campaign ) ) {
			return $campaign;
		}
		$content = $request->has_param( 'content' ) ? (string) $request->get_param( 'content' ) : null;
		$artifact = 'draft' === $campaign['state']['status']
			? WPHAVE_Campaigns_Email_Renderer::artifact( $campaign, $content )
			: WPHAVE_Campaigns_Repository::artifact( (int) $campaign['id'] );
		if ( is_wp_error( $artifact ) ) {
			return $artifact;
		}
		$message = WPHAVE_Campaigns_Email_Renderer::message(
			$campaign,
			array(
				'email' => 'preview@example.invalid',
				'merge_data' => wp_json_encode( array( 'first_name' => __( 'Preview', 'wphave' ), 'last_name' => __( 'Recipient', 'wphave' ) ) ),
				'unsubscribe_url' => '#unsubscribe',
			),
			$artifact
		);
		if ( is_wp_error( $message ) ) {
			return $message;
		}

		// AUTHORIZATION/DISCLOSURE INVARIANT: Campaign rendering and recipient
		// projection cross extension boundaries. Revalidate management authority
		// after they finish and immediately before releasing subject, HTML, text or
		// artifact metadata to the caller.
		$permission = self::require_manage();
		if ( is_wp_error( $permission ) ) {
			return $permission;
		}

		return rest_ensure_response(
			array(
				'subject' => $message['subject'],
				'html' => $message['html'],
				'text' => $message['text'],
				'artifactHash' => $artifact['hash'],
				'source' => $artifact['source'],
			)
		);
	}

	public static function providers(): WP_REST_Response|WP_Error {
		$permission = self::require_manage();
		if ( is_wp_error( $permission ) ) {
			return $permission;
		}

		$statuses = WPHAVE_Campaigns_Provider_Registry::statuses();

		// AUTHORIZATION/DISCLOSURE INVARIANT: Provider health inspection crosses
		// adapter and credential-filter boundaries. Revalidate Campaign authority
		// after every status is materialized and before configuration state leaves
		// the administrative provider registry.
		$permission = self::require_manage();
		if ( is_wp_error( $permission ) ) {
			return $permission;
		}

		return rest_ensure_response( $statuses );
	}

	/** Return editable mailing templates for the grid workspace. */
	public static function templates(): WP_REST_Response|WP_Error {
		$permission = self::require_manage();
		if ( is_wp_error( $permission ) ) {
			return $permission;
		}

		$templates = WPHAVE_Campaigns_Template_Repository::all();

		// AUTHORIZATION/DISCLOSURE INVARIANT: Template discovery and preview
		// rendering cross filterable post, metadata and rendering boundaries.
		// Campaign authority must remain valid after the full catalog is projected
		// and immediately before private template data is released.
		$permission = self::require_manage();
		if ( is_wp_error( $permission ) ) {
			return $permission;
		}

		return rest_ensure_response( $templates );
	}

	/** Create a new draft without mutating any existing mailing content. */
	public static function create_from_template( WP_REST_Request $request ) {
		$permission = self::require_manage();
		if ( is_wp_error( $permission ) ) {
			return $permission;
		}
		$result = WPHAVE_Campaigns_Template_Repository::create_mailing(
			absint( $request['id'] ),
			static function () {
				return self::require_manage();
			}
		);

		return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
	}

	/** Duplicate one template without exposing its private document metadata. */
	public static function duplicate_template( WP_REST_Request $request ) {
		$permission = self::require_manage();
		if ( is_wp_error( $permission ) ) {
			return $permission;
		}
		$result = WPHAVE_Campaigns_Template_Repository::duplicate(
			absint( $request['id'] ),
			(string) $request->get_param( 'title' ),
			static function () {
				return self::require_manage();
			}
		);

		return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
	}

	/** Create an editable mailing copy through the Campaigns domain boundary. */
	public static function duplicate( WP_REST_Request $request ) {
		$permission = self::require_manage();
		if ( is_wp_error( $permission ) ) {
			return $permission;
		}
		$result = WPHAVE_Campaigns_Repository::duplicate(
			absint( $request['id'] ),
			(string) $request->get_param( 'title' ),
			static function () {
				return self::require_manage();
			}
		);

		return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
	}

	/** Aggregate delivery and engagement facts without exposing recipient PII. */
	public static function report( WP_REST_Request $request ) {
		$permission = self::require_manage();
		if ( is_wp_error( $permission ) ) {
			return $permission;
		}

		global $wpdb;
		$campaign_id = absint( $request['id'] );
		$campaign = WPHAVE_Campaigns_Repository::get( $campaign_id );
		if ( is_wp_error( $campaign ) ) {
			return $campaign;
		}
		$deliveries = $wpdb->prefix . WPHAVE_Campaigns_Repository::DELIVERIES_TABLE;
		$events = $wpdb->prefix . WPHAVE_Campaigns_Repository::EVENTS_TABLE;
		$delivery_counts = $wpdb->get_results( $wpdb->prepare( "SELECT status, COUNT(*) total FROM {$deliveries} WHERE campaign_id=%d GROUP BY status", $campaign_id ), OBJECT_K );
		$event_counts = $wpdb->get_results( $wpdb->prepare( "SELECT e.type, COUNT(*) total FROM {$events} e INNER JOIN {$deliveries} d ON d.id=e.delivery_id WHERE d.campaign_id=%d GROUP BY e.type", $campaign_id ), OBJECT_K );

		// AUTHORIZATION/DISCLOSURE INVARIANT: Report aggregation crosses the
		// filterable database-query boundary. Revalidate Campaign authority after
		// both projections complete and immediately before publishing private
		// delivery and engagement totals.
		$permission = self::require_manage();
		if ( is_wp_error( $permission ) ) {
			return $permission;
		}

		return rest_ensure_response(
			array(
				'deliveries' => array_map( static fn ( object $row ): int => (int) $row->total, $delivery_counts ),
				'events' => array_map( static fn ( object $row ): int => (int) $row->total, $event_counts ),
			)
		);
	}

	/** Return native WordPress campaign revision summaries. */
	public static function revisions( WP_REST_Request $request ) {
		$permission = self::require_manage();
		if ( is_wp_error( $permission ) ) {
			return $permission;
		}

		$campaign_id = absint( $request['id'] );
		$campaign = WPHAVE_Campaigns_Repository::get( $campaign_id );
		if ( is_wp_error( $campaign ) ) {
			return $campaign;
		}

		// AUTHORIZATION INVARIANT: A Campaign capability grants authority over the
		// Campaign domain, not over an arbitrary WordPress object whose numeric ID
		// was placed into a Campaign URL. Type ownership is proven before Core's
		// generic revision API can project any cross-object metadata.
		$items = wp_get_post_revisions( $campaign_id, array( 'posts_per_page' => 50 ) );
		$items = array_values(
			array_map(
				static fn ( WP_Post $revision ): array => array(
					'id' => $revision->ID,
					'title' => $revision->post_title,
					'created_at' => $revision->post_modified_gmt,
				),
				$items
			)
		);

		// AUTHORIZATION/DISCLOSURE INVARIANT: Native revision queries are a
		// filterable boundary over private historical Campaign state. Authority must
		// remain valid after projection and immediately before history metadata is
		// released to the caller.
		$permission = self::require_manage();
		if ( is_wp_error( $permission ) ) {
			return $permission;
		}

		return rest_ensure_response(
			$items
		);
	}

	/** Honor a signed one-click opt-out and add it to the global suppression ledger. */
	public static function unsubscribe(WP_REST_Request $request) {
		$data = WPHAVE_Campaigns_Unsubscribe_Tokens::verify(
			(string) $request->get_param('payload'),
			(string) $request->get_param('signature')
		);
		if (is_wp_error($data)) {
			return $data;
		}
		if (!WPHAVE_Campaigns_Repository::suppress($data['email'], 'unsubscribe', 'campaign')) {
			return new WP_Error(
				'wphave_campaign_suppression_failed',
				__('The unsubscribe request could not be stored. Please try again.', 'wphave'),
				['status' => 503]
			);
		}
		do_action(
			'wphave_campaigns_unsubscribed',
			$data['email'],
			sanitize_key($data['purpose'] ?? '')
		);
		return rest_ensure_response(['unsubscribed' => true]);
	}

	/** Store deduplicated provider events after adapter-specific signature verification. */
	public static function provider_event(WP_REST_Request $request) {
		// TRANSACTION INVARIANT: Restore exclusion spans suppression AND event COMMIT.
		return WPHAVE_Campaigns_Authority::run(
			static fn() => self::provider_event_locked($request)
		);
	}

	private static function provider_event_locked(WP_REST_Request $request) {
		// AUTHORIZATION INVARIANT: Public provider input remains inert until the
		// configured adapter verifies its signature. Valid field syntax alone never
		// authorizes a delivery-state transition.
		$provider = sanitize_key($request['provider']);
		$data = (array) $request->get_json_params();
		$encoded_payload = wp_json_encode($data);

		/*
		 * SECURITY AND AVAILABILITY INVARIANT: Provider signatures authorize an
		 * event transition, not unbounded database storage. Reject oversized or
		 * unencodable documents before resolving a delivery or writing any row.
		 */
		if (
			false === $encoded_payload ||
			strlen($encoded_payload) > self::MAX_PROVIDER_EVENT_PAYLOAD_BYTES
		) {
			return new WP_Error(
				'wphave_campaign_event_payload_too_large',
				__('Provider event payload is too large.', 'wphave'),
				['status' => 413]
			);
		}
		$event_id = sanitize_text_field($data['id'] ?? '');
		$message_id = sanitize_text_field($data['message_id'] ?? '');
		$type = sanitize_key($data['type'] ?? '');
		if (
			!$provider ||
			strlen($provider) > 64 ||
			!$event_id ||
			strlen($event_id) > self::MAX_PROVIDER_IDENTIFIER_BYTES ||
			!$message_id ||
			strlen($message_id) > self::MAX_PROVIDER_IDENTIFIER_BYTES ||
			!in_array($type, ['delivered', 'opened', 'clicked', 'bounced', 'complained'], true)
		) {
			return new WP_Error(
				'wphave_campaign_event_invalid',
				__('Provider event payload is invalid.', 'wphave'),
				['status' => 400]
			);
		}
		$verified = apply_filters(
			'wphave_campaigns_verify_provider_event',
			false,
			$provider,
			$request
		);
		if (!$verified) {
			return new WP_Error(
				'wphave_campaign_event_unauthorized',
				__('Provider event signature verification failed.', 'wphave'),
				['status' => 401]
			);
		}
		global $wpdb;
		$deliveries = $wpdb->prefix . WPHAVE_Campaigns_Repository::DELIVERIES_TABLE;
		$events = $wpdb->prefix . WPHAVE_Campaigns_Repository::EVENTS_TABLE;
		/*
		 * OBJECT-BINDING INVARIANT: A provider message identifier must resolve to
		 * exactly one local delivery. A valid provider signature authenticates the
		 * event source; it does not authorize choosing an arbitrary duplicate row.
		 */
		$matching_deliveries = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT d.id, r.email FROM {$deliveries} d INNER JOIN {$wpdb->prefix}wphave_campaign_recipients r ON r.id=d.recipient_id WHERE d.provider=%s AND d.provider_message_id=%s LIMIT 2",
				$provider,
				$message_id
			),
			ARRAY_A
		);
		if (!$matching_deliveries) {
			return new WP_Error(
				'wphave_campaign_delivery_not_found',
				__('Delivery not found.', 'wphave'),
				['status' => 404]
			);
		}
		if (1 !== count($matching_deliveries)) {
			return new WP_Error(
				'wphave_campaign_delivery_ambiguous',
				__('Provider event delivery is ambiguous.', 'wphave'),
				['status' => 409]
			);
		}
		$delivery = $matching_deliveries[0];
		$requires_suppression = in_array($type, ['bounced', 'complained'], true);

		// CONSENT/ATOMICITY INVARIANT: For bounce and complaint events, replay
		// identity and the global suppression are one database transaction. A
		// compensating DELETE is not sufficient because that recovery write can
		// fail and permanently turn every authenticated retry into an inert replay.
		if ($requires_suppression && false === $wpdb->query('START TRANSACTION')) {
			return new WP_Error(
				'wphave_campaign_event_persistence_failed',
				__('Provider event could not be stored.', 'wphave'),
				['status' => 503]
			);
		}

		$inserted = $wpdb->query(
			$wpdb->prepare(
				"INSERT IGNORE INTO {$events} (delivery_id,provider,provider_event_id,type,payload,occurred_at) VALUES (%d,%s,%s,%s,%s,%s)",
				$delivery['id'],
				$provider,
				$event_id,
				$type,
				$encoded_payload,
				current_time('mysql', true)
			)
		);
		if (false === $inserted) {
			if ($requires_suppression) {
				$wpdb->query('ROLLBACK');
			}

			return new WP_Error(
				'wphave_campaign_event_persistence_failed',
				__('Provider event could not be stored.', 'wphave'),
				['status' => 503]
			);
		}

		/*
		 * REPLAY INVARIANT: State-changing consequences belong to the first durable
		 * event insert. INSERT IGNORE returning zero is an accepted replay, never a
		 * second authorization to execute suppression or another later side effect.
		 */
		if (0 === $inserted) {
			if ($requires_suppression) {
				$wpdb->query('ROLLBACK');
			}

			return rest_ensure_response(['accepted' => true]);
		}
		if ($requires_suppression) {
			// RECOVERY INVARIANT: Event deduplication and its suppression effect
			// commit together. Any suppression or COMMIT failure rolls the event back,
			// so an authenticated provider retry remains executable rather than being
			// misclassified as an already-completed replay.
			if (!WPHAVE_Campaigns_Repository::suppress($delivery['email'], $type, $provider)) {
				$wpdb->query('ROLLBACK');

				return new WP_Error(
					'wphave_campaign_suppression_failed',
					__('Provider event suppression could not be stored.', 'wphave'),
					['status' => 503]
				);
			}

			if (false === $wpdb->query('COMMIT')) {
				$wpdb->query('ROLLBACK');

				return new WP_Error(
					'wphave_campaign_event_persistence_failed',
					__('Provider event could not be stored.', 'wphave'),
					['status' => 503]
				);
			}
		}
		return rest_ensure_response(['accepted' => true]);
	}
}
