<?php

/** Campaigns domain bootstrap. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once wphave_dir() . 'inc/data/database-schema-manager.php';
require_once wphave_dir() . 'inc/background-jobs/functions.php';
require_once wphave_dir() . 'inc/background-jobs/lock.php';
require_once __DIR__ . '/authority.php';
require_once __DIR__ . '/unsubscribe-tokens.php';
require_once __DIR__ . '/design.php';
require_once __DIR__ . '/provider.php';
require_once __DIR__ . '/repository.php';
require_once __DIR__ . '/template-repository.php';
require_once __DIR__ . '/delivery-policy.php';
require_once __DIR__ . '/audience.php';
require_once __DIR__ . '/rendering/class-email-sanitizer.php';
require_once __DIR__ . '/rendering/class-css-inliner.php';
require_once __DIR__ . '/rendering/class-plain-text.php';
require_once __DIR__ . '/rendering/class-email-template.php';
require_once __DIR__ . '/rendering/class-email-renderer.php';
require_once __DIR__ . '/service.php';
require_once __DIR__ . '/functions.php';

WPHAVE_Database_Schema_Manager::register(
	array(
		'id' => 'campaigns',
		'label' => 'Mailing delivery tables',
		'version' => WPHAVE_Campaigns_Repository::DB_VERSION,
		'option' => 'wphave_campaigns_db_version',
		'tables' => array(
			WPHAVE_Campaigns_Repository::SNAPSHOTS_TABLE,
			WPHAVE_Campaigns_Repository::DELIVERIES_TABLE,
			WPHAVE_Campaigns_Repository::EVENTS_TABLE,
			WPHAVE_Campaigns_Repository::SUPPRESSIONS_TABLE,
		),
		'callback' => array( 'WPHAVE_Campaigns_Repository', 'install' ),
		'validator' => array( 'WPHAVE_Campaigns_Repository', 'schema_ready' ),
	)
);

if ( ! WPHAVE_Database_Schema_Manager::runtime_compatible( 'campaigns' ) ) {
	return;
}

WPHAVE_Campaigns_Provider_Registry::register( new WPHAVE_Campaigns_WordPress_Mail_Provider() );
WPHAVE_Campaigns_Provider_Registry::register( new WPHAVE_Campaigns_Resend_Provider() );
WPHAVE_Campaigns_Provider_Registry::register( new WPHAVE_Campaigns_Postmark_Provider() );
do_action( 'wphave_campaigns_register_email_providers' );

add_action( 'init', array( 'WPHAVE_Campaigns_Repository', 'register' ), 5 );
add_action( 'init', array( 'WPHAVE_Campaigns_Template_Repository', 'register' ), 5 );
add_action( 'init', array( 'WPHAVE_Campaigns_Template_Repository', 'seed' ), 25 );

/** Register Campaigns integration with the WPHAVE document editor. */
function wphave_campaigns_register_editor_integration(): void {
	static $registered = false;
	if ( $registered ) {
		return;
	}

	$registered = true;
	if ( ! defined( 'WPHAVE_CAMPAIGNS_EDITOR_RUNTIME' ) ) {
		define( 'WPHAVE_CAMPAIGNS_EDITOR_RUNTIME', true );
	}

	add_action(
		'init',
		static function (): void {
			if ( function_exists( 'wphave_register_document_support' ) ) {
				wphave_register_document_support(
					WPHAVE_Campaigns_Repository::POST_TYPE,
					array( 'profile' => 'email' )
				);
				wphave_register_document_support(
					WPHAVE_Campaigns_Template_Repository::POST_TYPE,
					array( 'profile' => 'email' )
				);
			}
		},
		9
	);

	add_filter(
		'use_block_editor_for_post_type',
		static function ( bool $use_block_editor, string $post_type ): bool {
			if (
				in_array(
					$post_type,
					array(
						WPHAVE_Campaigns_Repository::POST_TYPE,
						WPHAVE_Campaigns_Template_Repository::POST_TYPE,
					),
					true
				)
			) {
				return false;
			}

			return $use_block_editor;
		},
		10,
		2
	);

	add_filter(
		'wphave_post_type_editor_capabilities',
		static function ( array $capabilities ): array {
			$capabilities[ WPHAVE_Campaigns_Repository::POST_TYPE ] = array(
				'supports_editor' => true,
				'uses_block_editor' => false,
			);
			$capabilities[ WPHAVE_Campaigns_Template_Repository::POST_TYPE ] = array(
				'supports_editor' => true,
				'uses_block_editor' => false,
			);

			return $capabilities;
		}
	);

	add_filter(
		'wphave_post_type_edit_profiles',
		static function ( array $profiles ): array {
			$profiles[ WPHAVE_Campaigns_Repository::POST_TYPE ] = array(
				'contentOnly' => true,
				'draftOnly' => true,
				'returnScreen' => 'campaigns',
				'returnParams' => array( 'section' => 'campaigns', 'view' => 'list' ),
				'documentEditor' => function_exists( 'wphave_register_document_support' ),
				'emailPreview' => true,
			);
			$profiles[ WPHAVE_Campaigns_Template_Repository::POST_TYPE ] = array(
				'contentOnly' => true,
				'draftOnly' => false,
				'returnScreen' => 'campaigns',
				'returnParams' => array( 'section' => 'templates', 'view' => 'grid' ),
				'documentEditor' => function_exists( 'wphave_register_document_support' ),
				'emailPreview' => true,
			);

			return $profiles;
		}
	);
}

add_action(
	'wphave_campaigns_unsubscribed',
	static function ( string $email, string $purpose ): void {
		global $wpdb;
		$table = $wpdb->prefix . 'wphave_audience_subscribers';
		$wpdb->update(
			$table,
			array(
				'status' => 'unsubscribed',
				'consent' => 0,
				'unsubscribed_at' => current_time( 'mysql', true ),
				'updated_at' => current_time( 'mysql', true ),
			),
			array( 'email' => sanitize_email( $email ), 'purpose' => sanitize_key( $purpose ) )
		);
	},
	10,
	2
);

if (defined('WP_CLI') && WP_CLI) {
    require_once __DIR__ . '/recovery-cli.php';
}
