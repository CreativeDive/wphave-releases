<?php

/** Public Campaigns extension contracts. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Register an email provider without coupling it to Campaigns internals. */
function wphave_register_email_provider( WPHAVE_Campaigns_Email_Provider_Interface $provider ): void {
	WPHAVE_Campaigns_Provider_Registry::register( $provider );
}

/**
 * Send a non-marketing system message through the shared provider contract.
 *
 * Transactional sends deliberately bypass campaign snapshots, engagement
 * tracking and marketing suppression semantics. Their caller remains
 * responsible for choosing a lawful operational purpose.
 */
function wphave_send_transactional_email( array $message, string $provider = 'wordpress' ) {
	return WPHAVE_Campaigns_Service::send_transactional( $message, $provider );
}
