<?php

/**
 * Campaign validation, lifecycle and rendering application service.
 *
 * @package wphave
 */

if (!defined('ABSPATH')) {
	exit();
}

final class WPHAVE_Campaigns_Service {
	public const WORK_HOOK = 'wphave_campaigns_process';

	/** Parse persisted absolute schedules; legacy zone-free timestamps are UTC. */
	private static function scheduled_timestamp($value): int|WP_Error {
		if ($value === '' || $value === null) {
			return 0;
		}
		if (
			is_string($value) &&
			preg_match(
				'/^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(?::\d{2}(?:\.\d{3})?)?(?:Z|[+-](?:[01]\d|2[0-3]):[0-5]\d)?$/D',
				$value,
			)
		) {
			$formats = [
				'!Y-m-d H:i:s',
				'!Y-m-d\TH:i',
				'!Y-m-d\TH:i:s',
				'!Y-m-d\TH:iP',
				'!Y-m-d\TH:i:sP',
				'!Y-m-d\TH:i:s.vP',
			];
			foreach ($formats as $format) {
				$date = DateTimeImmutable::createFromFormat(
					$format,
					$value,
					new DateTimeZone('UTC'),
				);
				$errors = DateTimeImmutable::getLastErrors();
				if (
					$date &&
					($errors === false || (!$errors['warning_count'] && !$errors['error_count']))
				) {
					return $date->getTimestamp();
				}
			}
		}
		return new WP_Error(
			'wphave_campaign_invalid_schedule',
			__('The mailing schedule is invalid. Choose a valid date and time.', 'wphave'),
			['status' => 400],
		);
	}

	/** Validate every invariant required before an audience can be frozen. */
	public static function validate(array $campaign, ?string $provider_key = null): true|WP_Error {
		$config = (array) ($campaign['config'] ?? []);
		if (
			empty($config['subject']) ||
			empty($config['from_email']) ||
			!is_email($config['from_email'])
		) {
			return new WP_Error(
				'wphave_campaign_invalid_sender',
				__('Subject and a valid sender address are required.', 'wphave'),
				['status' => 400],
			);
		}
		$artifact = WPHAVE_Campaigns_Email_Renderer::artifact($campaign);
		if (is_wp_error($artifact)) {
			return $artifact;
		}
		$provider_key = $provider_key ?? WPHAVE_Campaigns_Provider_Registry::default_key();
		$provider = WPHAVE_Campaigns_Provider_Registry::get($provider_key);
		if (!$provider) {
			return new WP_Error(
				'wphave_campaign_provider_missing',
				__('The configured mailing provider is unavailable.', 'wphave'),
				['status' => 400],
			);
		}
		$status = $provider->connection_status();
		if (empty($status['configured']) || empty($status['healthy'])) {
			return new WP_Error(
				'wphave_campaign_provider_unhealthy',
				__('The configured mailing provider is not ready.', 'wphave'),
				['status' => 503],
			);
		}
		return true;
	}

	/** DATA INTEGRITY INVARIANT: Freeze the audience before queuing idempotent delivery records. */
	public static function prepare(int $campaign_id, $authorization_guard = null): array|WP_Error {
		return WPHAVE_Campaigns_Authority::run(static function () use (
			$campaign_id,
			$authorization_guard,
		) {
			if ('draft' !== WPHAVE_Campaigns_Repository::state($campaign_id)['status']) {
				return WPHAVE_Campaigns_Authority::blocked();
			}
			return self::prepare_locked($campaign_id, $authorization_guard);
		});
	}

	private static function prepare_locked(int $campaign_id, $authorization_guard): array|WP_Error {
		$campaign = WPHAVE_Campaigns_Repository::get($campaign_id);
		if (is_wp_error($campaign)) {
			return $campaign;
		}
		$scheduled_at = self::scheduled_timestamp($campaign['config']['scheduled_at'] ?? '');
		if (is_wp_error($scheduled_at)) {
			return $scheduled_at;
		}
		$provider_key = WPHAVE_Campaigns_Provider_Registry::default_key();
		$valid = self::validate($campaign, $provider_key);
		if (is_wp_error($valid)) {
			return $valid;
		}
		$campaign['config']['provider'] = $provider_key;
		$artifact = WPHAVE_Campaigns_Email_Renderer::artifact($campaign);
		if (is_wp_error($artifact)) {
			return $artifact;
		}

		// AUTHORIZATION/COMMIT INVARIANT: Provider validation and artifact
		// rendering are extensible preparation boundaries. A caller-owned policy
		// must still succeed immediately before artifact, audience, delivery and
		// scheduling state begins to freeze; every supplied non-true result fails closed.
		if (is_callable($authorization_guard)) {
			$authorization = call_user_func($authorization_guard);
			if (true !== $authorization) {
				return is_wp_error($authorization)
					? $authorization
					: new WP_Error(
						'wphave_campaign_forbidden',
						__('You are not allowed to manage campaigns.', 'wphave'),
						['status' => 403],
					);
			}
		}

		// AUTHORIZATION INVARIANT: The final caller guard precedes even the epoch write.
		$authorized = WPHAVE_Campaigns_Authority::authorize_new($campaign_id);
		if (is_wp_error($authorized)) {
			return $authorized;
		}
		$frozen = WPHAVE_Campaigns_Repository::freeze_artifact($campaign_id, $artifact);
		if (is_wp_error($frozen)) {
			return $frozen;
		}

		$recipients = WPHAVE_Campaigns_Audience::recipients(
			(array) ($campaign['config']['segment'] ?? []),
		);
		if (!$recipients) {
			return new WP_Error(
				'wphave_campaign_empty_audience',
				__('The selected audience contains no deliverable subscribers.', 'wphave'),
				['status' => 400],
			);
		}
		$count = WPHAVE_Campaigns_Repository::snapshot($campaign_id, $recipients);
		if (is_wp_error($count)) {
			return $count;
		}
		$provider_frozen = WPHAVE_Campaigns_Repository::freeze_provider(
			$campaign_id,
			$provider_key,
		);
		if (is_wp_error($provider_frozen)) {
			return $provider_frozen;
		}
		// COMMIT INVARIANT: Ready state and background scheduling are consequences
		// of a complete delivery batch, never of snapshot size or partial inserts.
		$queued = WPHAVE_Campaigns_Repository::queue_deliveries($campaign_id, $provider_key);
		if (is_wp_error($queued)) {
			return $queued;
		}
		$status = $scheduled_at && $scheduled_at > time() ? 'scheduled' : 'queued';
		$state = WPHAVE_Campaigns_Repository::set_state($campaign_id, [
			'status' => $status,
			'total' => $count,
			'processed' => 0,
			'sent' => 0,
			'failed' => 0,
			'dead' => 0,
		]);
		if (is_wp_error($state)) {
			return $state;
		}
		WPHAVE_Background_Job_Scheduler::ensure_single_event(
			self::WORK_HOOK,
			[$campaign_id],
			$scheduled_at && $scheduled_at > time() ? $scheduled_at : time() + 1,
		);
		return $state;
	}

	/** Pause, resume or cancel a prepared campaign without changing its snapshot. */
	public static function transition(int $campaign_id, string $action): array|WP_Error {
		return WPHAVE_Campaigns_Authority::run(static function () use ($campaign_id, $action) {
			// STOP INVARIANT: A successful pause/cancel is ordered after any in-flight
			// provider call. Busy is an explicit error, never a false acknowledgement.
			if ('resume' === $action && !WPHAVE_Campaigns_Authority::allows($campaign_id)) {
				return WPHAVE_Campaigns_Authority::blocked();
			}
			return self::transition_locked($campaign_id, $action);
		});
	}

	private static function transition_locked(int $campaign_id, string $action): array|WP_Error {
		$state = WPHAVE_Campaigns_Repository::state($campaign_id);
		$allowed = [
			'pause' => ['queued', 'sending', 'scheduled'],
			'resume' => ['paused', 'failed'],
			'cancel' => ['queued', 'sending', 'scheduled', 'paused', 'failed'],
		];
		if (!isset($allowed[$action]) || !in_array($state['status'], $allowed[$action], true)) {
			return new WP_Error(
				'wphave_campaign_transition_invalid',
				__('This mailing transition is not allowed.', 'wphave'),
				['status' => 409],
			);
		}
		$status = ['pause' => 'paused', 'resume' => 'queued', 'cancel' => 'cancelled'][$action];
		$state = WPHAVE_Campaigns_Repository::set_state($campaign_id, ['status' => $status]);
		if (is_wp_error($state)) {
			return $state;
		}
		if ('resume' === $action) {
			WPHAVE_Background_Job_Scheduler::ensure_continuation(
				self::WORK_HOOK,
				[$campaign_id],
				1,
			);
		}
		return $state;
	}

	/** Create a signed, single-recipient unsubscribe URL. */
	public static function unsubscribe_url(string $email, string $purpose): string {
		return WPHAVE_Campaigns_Unsubscribe_Tokens::url($email, $purpose);
	}

	/** Personalize the same canonical artifact used by every delivery path. */
	public static function message(
		array $campaign,
		array $recipient,
		?array $artifact = null,
	): array|WP_Error {
		$artifact = $artifact ?? WPHAVE_Campaigns_Email_Renderer::artifact($campaign);
		return is_wp_error($artifact)
			? $artifact
			: WPHAVE_Campaigns_Email_Renderer::message($campaign, $recipient, $artifact);
	}

	/** Send a transactional message through the shared provider without campaign tracking. */
	public static function send_transactional(array $message, string $provider_key = 'wordpress') {
		$provider = WPHAVE_Campaigns_Provider_Registry::get($provider_key);
		return $provider
			? $provider->send($message)
			: new WP_Error(
				'wphave_email_provider_missing',
				__('Email provider unavailable.', 'wphave'),
			);
	}
}
