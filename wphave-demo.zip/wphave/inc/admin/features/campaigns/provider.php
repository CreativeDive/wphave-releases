<?php

/**
 * Provider-neutral email delivery contracts.
 *
 * @package wphave
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

interface WPHAVE_Campaigns_Email_Provider_Interface {
	/** Return the stable provider key used in persisted deliveries. */
	public function key(): string;

	/** Check whether the provider is configured and reachable. */
	public function connection_status(): array;

	/**
	 * Send one already-rendered message.
	 *
	 * DELIVERY INVARIANT: Success contains a nonempty string message_id. An error
	 * permits automatic retry only when its data contains delivery_not_accepted
	 * exactly true, proving the transport did not accept the message. Timeouts,
	 * malformed responses and unknown outcomes must never assert that guarantee.
	 *
	 * @return array<string, mixed>|WP_Error Provider message identity or error.
	 */
	public function send( array $message );
}

/** Shared transport policy for credential-bearing Campaign provider requests. */
final class WPHAVE_Campaigns_Provider_Transport {
	private const MAX_RESPONSE_BYTES = 262144;

	/** Return fail-closed HTTP arguments shared by every API provider adapter. */
	public static function request_args( array $headers, array $payload ): array {
		// TRANSPORT INVARIANT: Provider credentials are scoped to the adapter's fixed
		// endpoint. Redirects cannot inherit them, TLS remains verified, and an
		// upstream response cannot allocate unbounded WordPress process memory.
		return array(
			'timeout' => 20,
			'redirection' => 0,
			'sslverify' => true,
			'limit_response_size' => self::MAX_RESPONSE_BYTES + 1,
			'headers' => $headers,
			'body' => wp_json_encode( $payload ),
		);
	}

	/** Reject the sentinel byte proving that Core truncated an oversized response. */
	public static function response_is_oversized( $response ): bool {
		return strlen( (string) wp_remote_retrieve_body( $response ) ) > self::MAX_RESPONSE_BYTES;
	}
}

final class WPHAVE_Campaigns_Provider_Registry {
	/** @var array<string, WPHAVE_Campaigns_Email_Provider_Interface> */
	private static array $providers = array();

	/** Register or replace a provider adapter by stable key. */
	public static function register( WPHAVE_Campaigns_Email_Provider_Interface $provider ): void {
		self::$providers[ $provider->key() ] = $provider;
	}

	/** Resolve a configured provider without leaking adapter details. */
	public static function get( string $key ): ?WPHAVE_Campaigns_Email_Provider_Interface {
		return self::$providers[ sanitize_key( $key ) ] ?? null;
	}

	/** Return the single provider selected for new Campaigns deliveries. */
	public static function default_key(): string {
		return sanitize_key( (string) wphave_data_get( 'campaign_settings', 'default_provider', 'wordpress' ) );
	}

	/** Return connection summaries safe for the administration API. */
	public static function statuses(): array {
		$default_provider = self::default_key();
		return array_map(
			static fn ( WPHAVE_Campaigns_Email_Provider_Interface $provider ): array => array_merge(
				array(
					'key' => $provider->key(),
					'is_default' => $provider->key() === $default_provider,
				),
				$provider->connection_status()
			),
			array_values( self::$providers )
		);
	}
}

/**
 * WordPress mail adapter used as the safe built-in baseline.
 *
 * SMTP plugins may transparently replace its transport. API providers can be
 * registered without changing Campaigns, Audience or the queue contract.
 */
final class WPHAVE_Campaigns_WordPress_Mail_Provider implements WPHAVE_Campaigns_Email_Provider_Interface {
	public function key(): string {
		return 'wordpress';
	}

	public function connection_status(): array {
		$enabled = 'wordpress' === WPHAVE_Campaigns_Provider_Registry::default_key();
		return array(
			'configured' => $enabled,
			'healthy' => $enabled,
			'label' => __( 'WordPress mail', 'wphave' ),
			'type' => 'smtp',
		);
	}

	public function send( array $message ) {
		$mail_error = null;
		$capture_error = static function ( $error ) use ( &$mail_error ): void {
			if ( is_wp_error( $error ) ) {
				$mail_error = $error;
			}
		};
		add_action( 'wp_mail_failed', $capture_error );
		$headers = array( 'Content-Type: text/html; charset=UTF-8' );
		if ( ! empty( $message['from_email'] ) ) {
			$from_name = sanitize_text_field( $message['from_name'] ?? '' );
			$headers[] = 'From: ' . $from_name . ' <' . sanitize_email( $message['from_email'] ) . '>';
		}
		if ( ! empty( $message['reply_to'] ) ) {
			$headers[] = 'Reply-To: ' . sanitize_email( $message['reply_to'] );
		}
		foreach ( $message['headers'] ?? array() as $header ) {
			$headers[] = sanitize_text_field( $header );
		}

		$configure_mailer = static function ( $phpmailer ) use ( $message ): void {
			self::configure_mailer( $phpmailer, $message );
		};
		add_action( 'phpmailer_init', $configure_mailer, PHP_INT_MAX );

		try {
			$sent = wp_mail(
				sanitize_email( $message['to'] ?? '' ),
				sanitize_text_field( $message['subject'] ?? '' ),
				(string) ( $message['html'] ?? '' ),
				$headers
			);
		} finally {
			remove_action( 'phpmailer_init', $configure_mailer, PHP_INT_MAX );
			remove_action( 'wp_mail_failed', $capture_error );
		}

		if ( ! $sent ) {
			if ( is_wp_error( $mail_error ) ) {
				return new WP_Error(
					'wphave_campaign_provider_send_failed',
					$mail_error->get_error_message(),
					$mail_error->get_error_data()
				);
			}

			return new WP_Error( 'wphave_campaign_provider_send_failed', __( 'The email provider rejected the message.', 'wphave' ) );
		}

		return array( 'message_id' => wp_generate_uuid4() );
	}

	/** Let PHPMailer construct and encode the multipart/alternative message. */
	private static function configure_mailer( $phpmailer, array $message ): void {
		$phpmailer->isHTML( true );
		$phpmailer->CharSet = 'UTF-8';
		$phpmailer->Encoding = 'quoted-printable';
		$phpmailer->Body = (string) ( $message['html'] ?? '' );
		$phpmailer->AltBody = (string) ( $message['text'] ?? '' );
	}
}

/** Resend HTTP API adapter with server-only credential ownership. */
final class WPHAVE_Campaigns_Resend_Provider implements WPHAVE_Campaigns_Email_Provider_Interface {
	private const ENDPOINT = 'https://api.resend.com/emails';

	public function key(): string {
		return 'resend';
	}

	/** Resolve a deployment secret without persisting it in Campaigns records. */
	private function api_key(): string {
		$settings = (array) wphave_data_get( 'campaign_settings', 'providers.resend', array() );
		$key = defined( 'WPHAVE_RESEND_API_KEY' ) && WPHAVE_RESEND_API_KEY
			? WPHAVE_RESEND_API_KEY
			: ( $settings['api_key'] ?? '' );
		return (string) apply_filters( 'wphave_campaigns_resend_api_key', $key, $settings );
	}

	public function connection_status(): array {
		$settings = (array) wphave_data_get( 'campaign_settings', 'providers.resend', array() );
		$enabled = 'resend' === WPHAVE_Campaigns_Provider_Registry::default_key();
		$configured = $enabled && '' !== $this->api_key();
		return array(
			'configured' => $configured,
			'healthy' => $configured,
			'label' => 'Resend',
			'type' => 'api',
		);
	}

	public function send(array $message) {
		// SECRET-LIFECYCLE INVARIANT: Provider credentials remain server-owned and
		// leave the process only as authorization headers to this fixed HTTPS endpoint;
		// delivery records and returned errors never persist the credential itself.
		if (!$this->api_key()) {
			return new WP_Error(
				'wphave_resend_not_configured',
				__('Resend is not configured.', 'wphave')
			);
		}
		$from_email = sanitize_email($message['from_email'] ?? '');
		$from_name = sanitize_text_field($message['from_name'] ?? '');
		$payload = [
			'from' => $from_name ? $from_name . ' <' . $from_email . '>' : $from_email,
			'to' => [sanitize_email($message['to'] ?? '')],
			'subject' => sanitize_text_field($message['subject'] ?? ''),
			'html' => (string) ($message['html'] ?? ''),
			'text' => (string) ($message['text'] ?? ''),
			'headers' => self::header_map($message['headers'] ?? [])
		];
		if (!empty($message['reply_to'])) {
			$payload['reply_to'] = sanitize_email($message['reply_to']);
		}
		$response = wp_safe_remote_post(
			self::ENDPOINT,
			WPHAVE_Campaigns_Provider_Transport::request_args(
				[
					'Authorization' => 'Bearer ' . $this->api_key(),
					'Content-Type' => 'application/json',
					'Idempotency-Key' => sanitize_text_field(
						$message['idempotency_key'] ?? wp_generate_uuid4()
					)
				],
				$payload
			)
		);
		if (is_wp_error($response)) {
			return $response;
		}
		if (WPHAVE_Campaigns_Provider_Transport::response_is_oversized($response)) {
			return new WP_Error(
				'wphave_resend_response_too_large',
				__('Resend returned an oversized response.', 'wphave')
			);
		}
		$status = wp_remote_retrieve_response_code($response);
		$body = json_decode(wp_remote_retrieve_body($response), true);
		if ($status < 200 || $status >= 300 || empty($body['id'])) {
			$retry_after = absint(wp_remote_retrieve_header($response, 'retry-after'));
			return new WP_Error(
				429 === $status ? 'wphave_resend_rate_limited' : 'wphave_resend_rejected',
				sanitize_text_field(
					$body['message'] ?? __('Resend rejected the message.', 'wphave')
				),
				[
					'status' => $status,
					'retry_after' => $retry_after,
					'delivery_not_accepted' => $status >= 400 && $status < 500 && 408 !== $status
				]
			);
		}
		return ['message_id' => sanitize_text_field($body['id'])];
	}

	/** Convert RFC-style header lines into the provider's header object. */
	private static function header_map( array $headers ): array {
		$result = array();
		foreach ( $headers as $header ) {
			$parts = explode( ':', (string) $header, 2 );
			if ( 2 === count( $parts ) ) {
				$result[ sanitize_text_field( trim( $parts[0] ) ) ] = sanitize_text_field( trim( $parts[1] ) );
			}
		}
		return $result;
	}
}

/** Postmark HTTP API adapter with server-only credential ownership. */
final class WPHAVE_Campaigns_Postmark_Provider implements WPHAVE_Campaigns_Email_Provider_Interface {
	private const ENDPOINT = 'https://api.postmarkapp.com/email';

	public function key(): string {
		return 'postmark';
	}

	/** Resolve a deployment secret without persisting it in Campaigns records. */
	private function server_token(): string {
		$settings = (array) wphave_data_get( 'campaign_settings', 'providers.postmark', array() );
		$token = defined( 'WPHAVE_POSTMARK_SERVER_TOKEN' ) && WPHAVE_POSTMARK_SERVER_TOKEN
			? WPHAVE_POSTMARK_SERVER_TOKEN
			: ( $settings['server_token'] ?? '' );

		return (string) apply_filters( 'wphave_campaigns_postmark_server_token', $token, $settings );
	}

	public function connection_status(): array {
		$settings = (array) wphave_data_get( 'campaign_settings', 'providers.postmark', array() );
		$enabled = 'postmark' === WPHAVE_Campaigns_Provider_Registry::default_key();
		$message_stream = trim( (string) ( $settings['message_stream'] ?? 'broadcasts' ) );
		$configured = $enabled && '' !== $this->server_token() && '' !== $message_stream;

		return array(
			'configured' => $configured,
			'healthy' => $configured,
			'label' => 'Postmark',
			'type' => 'api',
		);
	}

	public function send(array $message) {
		$settings = (array) wphave_data_get('campaign_settings', 'providers.postmark', []);
		$token = $this->server_token();
		$message_stream = sanitize_key($settings['message_stream'] ?? 'broadcasts');
		if (!$token || !$message_stream) {
			return new WP_Error(
				'wphave_postmark_not_configured',
				__('Postmark is not configured.', 'wphave')
			);
		}

		$from_email = sanitize_email($message['from_email'] ?? '');
		$from_name = sanitize_text_field($message['from_name'] ?? '');
		$payload = [
			'From' => $from_name ? $from_name . ' <' . $from_email . '>' : $from_email,
			'To' => sanitize_email($message['to'] ?? ''),
			'Subject' => sanitize_text_field($message['subject'] ?? ''),
			'HtmlBody' => (string) ($message['html'] ?? ''),
			'TextBody' => (string) ($message['text'] ?? ''),
			'Headers' => self::header_list($message['headers'] ?? []),
			'MessageStream' => $message_stream,
			'Metadata' => [
				'wphave_delivery_key' => sanitize_text_field(
					$message['idempotency_key'] ?? wp_generate_uuid4()
				)
			]
		];
		if (!empty($message['reply_to'])) {
			$payload['ReplyTo'] = sanitize_email($message['reply_to']);
		}

		$response = wp_safe_remote_post(
			self::ENDPOINT,
			WPHAVE_Campaigns_Provider_Transport::request_args(
				[
					'Accept' => 'application/json',
					'Content-Type' => 'application/json',
					'X-Postmark-Server-Token' => $token
				],
				$payload
			)
		);
		if (is_wp_error($response)) {
			return $response;
		}
		if (WPHAVE_Campaigns_Provider_Transport::response_is_oversized($response)) {
			return new WP_Error(
				'wphave_postmark_response_too_large',
				__('Postmark returned an oversized response.', 'wphave')
			);
		}

		$status = wp_remote_retrieve_response_code($response);
		$body = json_decode(wp_remote_retrieve_body($response), true);
		if ($status < 200 || $status >= 300 || empty($body['MessageID'])) {
			$retry_after = absint(wp_remote_retrieve_header($response, 'retry-after'));
			$error_code =
				429 === $status
					? 'wphave_postmark_rate_limited'
					: (in_array($status, [500, 503], true)
						? 'wphave_postmark_temporary_failure'
						: 'wphave_postmark_rejected');

			return new WP_Error(
				$error_code,
				sanitize_text_field(
					$body['Message'] ?? __('Postmark rejected the message.', 'wphave')
				),
				[
					'status' => $status,
					'retry_after' => $retry_after,
					'delivery_not_accepted' => $status >= 400 && $status < 500 && 408 !== $status
				]
			);
		}

		return ['message_id' => sanitize_text_field($body['MessageID'])];
	}

	/** Convert RFC-style header lines into Postmark's name/value collection. */
	private static function header_list( array $headers ): array {
		$result = array();
		foreach ( $headers as $header ) {
			$parts = explode( ':', (string) $header, 2 );
			if ( 2 === count( $parts ) ) {
				$result[] = array(
					'Name' => sanitize_text_field( trim( $parts[0] ) ),
					'Value' => sanitize_text_field( trim( $parts[1] ) ),
				);
			}
		}

		return $result;
	}
}
