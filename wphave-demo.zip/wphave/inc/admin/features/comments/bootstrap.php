<?php

/**
 * Manage WordPress comments through the WPHAVE admin interface.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once dirname(__DIR__, 3) . '/features/security/exact-id-list.php';

class WPHAVE_Comments_Manager {
	const MAX_BULK_COMMENTS = 100;

	/**
	 * Registers REST routes for reading and moderating comments.
	 */

	public static function init() {
		add_action( 'rest_api_init', [ __CLASS__, 'register_rest_routes' ] );
	}

	/**
	 * Determine whether read comments.
	 *
	 * @return bool
	 */

	public static function can_read_comments() {
		return self::can_access_feature() && current_user_can( 'moderate_comments' );
	}

	/**
	 * Determine whether the current user may enter the Engagement feature.
	 *
	 * @return bool
	 */

	public static function can_access_feature() {
		return current_user_can( 'wphave_view_engagement' ) || current_user_can( 'wphave_manage_options' ) || current_user_can( 'manage_options' );
	}

	/**
	 * Return the status labels.
	 *
	 * @return array
	 */

	public static function get_status_labels() {
		return [
			'all' => __( 'All', 'wphave' ),
			'hold' => __( 'Pending', 'wphave' ),
			'approve' => __( 'Approved', 'wphave' ),
			'spam' => __( 'Spam', 'wphave' ),
			'trash' => __( 'Trash', 'wphave' ),
		];
	}

	/**
	 * Normalize the status.
	 *
	 * @param string $status
	 * @return string
	 */

	public static function normalize_status( $status ) {
		$status = sanitize_key( $status );
		$allowed = array_keys( self::get_status_labels() );

		return in_array( $status, $allowed, true ) ? $status : 'all';
	}

	/**
	 * Normalize comment type filter.
	 *
	 * @param string $type Type.
	 */

	public static function normalize_comment_type_filter( $type ) {
		$type = sanitize_key( $type );
		$allowed = [ 'all', 'comment', 'pingback', 'trackback' ];

		return in_array( $type, $allowed, true ) ? $type : 'all';
	}

	/**
	 * Normalize post status filter.
	 *
	 * @param string $post_status Post status.
	 */

	public static function normalize_post_status_filter( $post_status ) {
		$post_status = sanitize_key( $post_status );
		$allowed = [ 'all', 'publish', 'draft', 'pending', 'private', 'future', 'trash' ];

		return in_array( $post_status, $allowed, true ) ? $post_status : 'all';
	}

	/**
	 * Normalize date range filter.
	 *
	 * @param mixed $date_range Date range.
	 */

	public static function normalize_date_range_filter( $date_range ) {
		$date_range = sanitize_key( $date_range );
		$allowed = [ 'all', 'today', 'last_7_days', 'last_30_days' ];

		return in_array( $date_range, $allowed, true ) ? $date_range : 'all';
	}

	/**
	 * Return date query for range.
	 *
	 * @param mixed $date_range Date range.
	 */

	public static function get_date_query_for_range( $date_range ) {
		$date_range = self::normalize_date_range_filter( $date_range );

		if ( $date_range === 'all' ) {
			return [];
		}

		$now = current_time( 'timestamp' );

		if ( $date_range === 'today' ) {
			return [
				[
					'column' => 'comment_date',
					'after' => [
						'year' => (int) wp_date( 'Y', $now ),
						'month' => (int) wp_date( 'm', $now ),
						'day' => (int) wp_date( 'd', $now ),
					],
					'inclusive' => true,
				],
			];
		}

		$days = $date_range === 'last_7_days' ? 7 : 30;

		return [
			[
				'column' => 'comment_date',
				'after' => wp_date( 'Y-m-d H:i:s', $now - ( $days * DAY_IN_SECONDS ) ),
				'inclusive' => true,
			],
		];
	}

	/**
	 * Normalize the comment status.
	 *
	 * @param string|int $approved
	 * @return string
	 */

	public static function normalize_comment_status( $approved ) {
		if ( $approved === '1' || $approved === 1 ) {
			return 'approve';
		}

		if ( $approved === '0' || $approved === 0 ) {
			return 'hold';
		}

		return sanitize_key( $approved );
	}

	/**
	 * Prepare the comment item.
	 *
	 * @param WP_Comment|int $comment
	 * @return array|null
	 */

	public static function prepare_comment_item( $comment ) {
		$comment = $comment instanceof WP_Comment ? $comment : get_comment( $comment );

		if ( ! $comment ) {
			return null;
		}

		$post = $comment->comment_post_ID ? get_post( $comment->comment_post_ID ) : null;
		$status = self::normalize_comment_status( $comment->comment_approved );
		$type = $comment->comment_type ?: 'comment';

		return [
			'id' => (int) $comment->comment_ID,
			'postId' => (int) $comment->comment_post_ID,
			'postTitle' => $post ? get_the_title( $post ) : '',
			'postType' => $post ? $post->post_type : '',
				'authorName' => $comment->comment_author,
				'authorEmail' => $comment->comment_author_email,
				'authorUrl' => $comment->comment_author_url,
				'avatarUrl' => $type === 'comment' ? wphave_get_avatar_url( $comment, [ 'size' => 48 ] ) : '',
				'authorIp' => $comment->comment_author_IP,
				'content' => $comment->comment_content,
			'status' => $status,
			'type' => $type,
			'date' => mysql_to_rfc3339( $comment->comment_date ),
			'dateGmt' => mysql_to_rfc3339( $comment->comment_date_gmt ),
				// edit_comment is a meta capability and must be checked per comment.
				'permissions' => [
					'canEdit' => current_user_can( 'edit_comment', $comment->comment_ID ),
					'canDelete' => self::current_user_can_delete_comment( $comment->comment_ID ),
					'canModerate' => current_user_can( 'moderate_comments' ),
				],
			];
		}

			/**
			 * Current user can delete comment.
			 *
			 * @param mixed $comment_id Comment ID.
			 */

			public static function current_user_can_delete_comment( $comment_id ) {
				return self::can_access_feature() && ( current_user_can( 'moderate_comments' ) || current_user_can( 'edit_comment', absint( $comment_id ) ) );
			}

			/**
			 * Current user can moderate comment.
			 *
			 * @param mixed $comment_id Comment ID.
			 */

			public static function current_user_can_moderate_comment( $comment_id ) {
				return self::can_access_feature() && ( current_user_can( 'moderate_comments' ) || current_user_can( 'edit_comment', absint( $comment_id ) ) );
			}

	/**
	 * Return the comments.
	 *
	 * @param array $args
	 * @return array
	 */

	public static function get_comments( $args = [] ) {
		$defaults = [
			'status' => 'all',
			'number' => 50,
			'paged' => 1,
			'search' => '',
			'type' => 'all',
			'post_id' => 0,
			'post_status' => 'all',
			'date_range' => 'all',
			'orderby' => 'comment_date_gmt',
			'order' => 'desc',
		];

		$args = wp_parse_args( $args, $defaults );
		$status = self::normalize_status( $args['status'] );
		$type = self::normalize_comment_type_filter( $args['type'] );
		$post_status = self::normalize_post_status_filter( $args['post_status'] );
		$date_range = self::normalize_date_range_filter( $args['date_range'] );
		$post_id = absint( $args['post_id'] );
		$number = absint( $args['number'] );
		$paged = absint( $args['paged'] );
		$sortable_columns = [ 'comment_date_gmt', 'comment_author', 'comment_type', 'comment_approved' ];
		$requested_orderby = sanitize_key( $args['orderby'] );
		$orderby = in_array( $requested_orderby, $sortable_columns, true ) ? $requested_orderby : $defaults['orderby'];
		$order = strtolower( sanitize_key( $args['order'] ) ) === 'asc' ? 'ASC' : 'DESC';

		$query_args = [
			'status' => $status,
			'number' => $number ? min( $number, 200 ) : $defaults['number'],
			'paged' => $paged ?: $defaults['paged'],
			'orderby' => $orderby,
			'order' => $order,
			'search' => sanitize_text_field( $args['search'] ),
		];

		if ( $type !== 'all' ) {
			$query_args['type'] = $type;
		}

		if ( $post_id ) {
			$query_args['post_id'] = $post_id;
		}

		if ( $post_status !== 'all' ) {
			$query_args['post_status'] = $post_status;
		}

		if ( $date_range !== 'all' ) {
			$query_args['date_query'] = self::get_date_query_for_range( $date_range );
		}

		$query = new WP_Comment_Query();
		$comments = $query->query( $query_args );

		$count_args = $query_args;
		unset( $count_args['number'], $count_args['paged'], $count_args['orderby'], $count_args['order'] );
		$count_args['count'] = true;

		$total = get_comments( $count_args );
		$counts = wp_count_comments();

		return [
			'items' => array_values( array_filter( array_map( [ __CLASS__, 'prepare_comment_item' ], $comments ) ) ),
			'total' => (int) $total,
			'settings' => self::get_comment_settings(),
			'stats' => [
				'all' => (int) $counts->all,
				'hold' => (int) $counts->moderated,
				'approve' => (int) $counts->approved,
				'spam' => (int) $counts->spam,
				'trash' => (int) $counts->trash,
			],
			'statuses' => self::get_status_labels(),
		];
	}

	/**
	 * Return comment stats.
	 *
	 * @return array Return comment stats.
	 */

	public static function get_comment_stats(): array {
		$counts = wp_count_comments();

		return [
			'all' => (int) $counts->all,
			'hold' => (int) $counts->moderated,
			'approve' => (int) $counts->approved,
			'spam' => (int) $counts->spam,
			'trash' => (int) $counts->trash,
		];
	}

	/**
	 * Return the comment settings.
	 *
	 * @return array
	 */

	public static function get_comment_settings() {
		return [
			'commentsDisabled' => (bool) wphave_data_get(
				'site_settings',
				'general.comments.disabled',
				false
			),
			'defaultStatus' => get_option( 'default_comment_status', 'open' ),
			'requireNameEmail' => (bool) get_option( 'require_name_email' ),
			'commentRegistration' => (bool) get_option( 'comment_registration' ),
			'threadComments' => (bool) get_option( 'thread_comments' ),
			'threadCommentsDepth' => (int) get_option( 'thread_comments_depth' ),
			'closeCommentsForOldPosts' => (bool) get_option( 'close_comments_for_old_posts' ),
			'closeCommentsDaysOld' => (int) get_option( 'close_comments_days_old' ),
			'commentModeration' => (bool) get_option( 'comment_moderation' ),
			'commentPrevioulsyApproved' => (bool) get_option( 'comment_previously_approved' ),
			'commentsNotify' => (bool) get_option( 'comments_notify' ),
			'moderationNotify' => (bool) get_option( 'moderation_notify' ),
			'pageComments' => (bool) get_option( 'page_comments' ),
			'commentsPerPage' => (int) get_option( 'comments_per_page' ),
		];
	}

	/**
	 * Update the comment.
	 *
	 * @param int $comment_id
	 * @param array $data
	 * @return array|WP_Error|null
	 */

	public static function update_comment( $comment_id, $data ) {
		$comment_id = absint( $comment_id );
		$comment = get_comment( $comment_id );

		if ( ! $comment ) {
			return new WP_Error( 'invalid_comment', __( 'Invalid comment.', 'wphave' ), [ 'status' => 404 ] );
		}

		// AUTHORIZATION INVARIANT: Engagement feature access authorizes the workspace,
		// not an arbitrary comment ID. The native per-comment meta capability is
		// re-evaluated at the mutation boundary before any submitted field is applied.
		if ( ! self::current_user_can_moderate_comment( $comment_id ) ) {
			return new WP_Error( 'cannot_edit_comment', __( 'You are not allowed to edit this comment.', 'wphave' ), [ 'status' => 403 ] );
		}

		$args = [
			'comment_ID' => $comment_id,
		];

		if ( isset( $data['authorName'] ) ) {
			$args['comment_author'] = sanitize_text_field( $data['authorName'] );
		}

		if ( isset( $data['authorEmail'] ) ) {
			$args['comment_author_email'] = sanitize_email( $data['authorEmail'] );
		}

		if ( isset( $data['authorUrl'] ) ) {
			$args['comment_author_url'] = esc_url_raw( $data['authorUrl'] );
		}

		if ( isset( $data['content'] ) ) {
			$args['comment_content'] = wp_kses_post( $data['content'] );
		}

		// AUTHORIZATION/TOCTOU INVARIANT: Submitted comment fields cross WordPress
		// sanitizers and KSES filters. Re-evaluate both Engagement feature access and
		// the exact comment meta capability after normalization and immediately before
		// applying the prepared fields.
		if ( ! self::current_user_can_moderate_comment( $comment_id ) ) {
			return new WP_Error( 'cannot_edit_comment', __( 'You are not allowed to edit this comment.', 'wphave' ), [ 'status' => 403 ] );
		}

		$result = wp_update_comment( $args, true );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		if ( ! empty( $data['status'] ) ) {
			$status = self::normalize_status( $data['status'] );

			if ( $status !== 'all' ) {
				$status_result = self::set_comment_status( $comment_id, $status );

				if ( is_wp_error( $status_result ) ) {
					return $status_result;
				}
			}
		}

		return self::prepare_comment_item( get_comment( $comment_id ) );
	}

	/**
	 * Set the comment status.
	 *
	 * @param int $comment_id
	 * @param string $status
	 * @return array|WP_Error|null
	 */

	public static function set_comment_status( $comment_id, $status ) {
		$comment_id = absint( $comment_id );
		$comment = get_comment( $comment_id );

		if ( ! $comment ) {
			return new WP_Error( 'invalid_comment', __( 'Invalid comment.', 'wphave' ), [ 'status' => 404 ] );
		}

			if ( ! self::current_user_can_moderate_comment( $comment_id ) ) {
				return new WP_Error( 'cannot_moderate_comment', __( 'You are not allowed to moderate this comment.', 'wphave' ), [ 'status' => 403 ] );
			}

		$status = self::normalize_status( $status );

		if ( $status === 'all' ) {
			return new WP_Error( 'invalid_comment_status', __( 'Invalid comment status.', 'wphave' ), [ 'status' => 400 ] );
		}

		// AUTHORIZATION/TOCTOU INVARIANT: Status normalization crosses the filterable
		// sanitize_key boundary. Recheck Engagement access and the exact comment meta
		// capability after normalization and immediately before any moderation effect.
		if ( ! self::current_user_can_moderate_comment( $comment_id ) ) {
			return new WP_Error( 'cannot_moderate_comment', __( 'You are not allowed to moderate this comment.', 'wphave' ), [ 'status' => 403 ] );
		}

			// WordPress uses edit_comment/moderate_comments for deleting and trashing comments.
			if ( $status === 'trash' && ! self::current_user_can_delete_comment( $comment_id ) ) {
				return new WP_Error( 'cannot_delete_comment', __( 'You are not allowed to delete this comment.', 'wphave' ), [ 'status' => 403 ] );
			}

		$result = wp_set_comment_status( $comment_id, $status, true );
		$updated = get_comment( $comment_id );
		// MODERATION-COMMIT INVARIANT: Core may return false for a failed write
		// or a no-op; with WP_Error requested it also reports a no-op as an error.
		// Only the exact persisted status proves the requested effect.
		if ( ! $updated || self::normalize_comment_status( $updated->comment_approved ) !== $status ) {
			if ( is_wp_error( $result ) ) {
				return $result;
			}
			return new WP_Error(
				'wphave_comment_status_failed',
				__( 'The comment status could not be saved.', 'wphave' ),
				[ 'status' => 503 ]
			);
		}

		return self::prepare_comment_item( $updated );
	}

	/**
	 *  $force is true.
	 *
	 * @param int $comment_id
	 * @param bool $force
	 * @return array|WP_Error
	 */

	public static function delete_comment( $comment_id, $force = false ) {
		$comment_id = absint( $comment_id );
		$comment = get_comment( $comment_id );

		if ( ! $comment ) {
			return new WP_Error( 'invalid_comment', __( 'Invalid comment.', 'wphave' ), [ 'status' => 404 ] );
		}

			if ( ! self::current_user_can_delete_comment( $comment_id ) ) {
				return new WP_Error( 'cannot_delete_comment', __( 'You are not allowed to delete this comment.', 'wphave' ), [ 'status' => 403 ] );
			}

		$deleted = wp_delete_comment( $comment_id, (bool) $force );

		// DELETION-COMMIT INVARIANT: A false Core result must never be exposed as
		// successful access removal to single or bulk moderation clients.
		if ( ! $deleted ) {
			return new WP_Error(
				'wphave_comment_delete_failed',
				__( 'The comment could not be deleted.', 'wphave' ),
				[ 'status' => 503 ]
			);
		}

		return [
			'id' => $comment_id,
			'deleted' => true,
		];
	}

	/**
	 * Apply the requested bulk action.
	 *
	 * @param array $ids
	 * @param string $action
	 * @return array|WP_Error
	 */

	public static function bulk_action( $ids, $action ) {
		$action = sanitize_key( $action );
		$allowed = [ 'approve', 'hold', 'spam', 'trash', 'delete' ];

		if ( ! in_array( $action, $allowed, true ) ) {
			return new WP_Error( 'invalid_comment_action', __( 'Invalid bulk action.', 'wphave' ), [ 'status' => 400 ] );
		}
		// BULK-WORK INVARIANT: One authorized HTTP request may cause only a bounded
		// number of irreversible Core moderation operations.
		$normalized_ids = WPHAVE_Exact_ID_List::normalize( $ids, self::MAX_BULK_COMMENTS );
		if ( null === $normalized_ids ) {
			return new WP_Error(
				'invalid_comment_ids',
				__( 'Select no more than 100 valid comments.', 'wphave' ),
				[ 'status' => 400 ]
			);
		}

		$results = [];

		foreach ( $normalized_ids as $comment_id ) {
			$result = $action === 'delete'
				? self::delete_comment( $comment_id, true )
				: self::set_comment_status( $comment_id, $action );

			$results[] = [
				'id' => $comment_id,
				'success' => ! is_wp_error( $result ) && null !== $result,
				'message' => is_wp_error( $result ) ? $result->get_error_message() : '',
			];
		}

		return [
			'items' => $results,
		];
	}

	/**
	 * Registers the REST routes used by the React comments manager.
	 */

	public static function register_rest_routes() {
		register_rest_route( 'wphave/v1', '/comments', [
			'methods' => WP_REST_Server::READABLE,
			'callback' => [ __CLASS__, 'rest_get_comments' ],
			'permission_callback' => [ __CLASS__, 'can_read_comments' ],
			'args' => [
				'status' => [
					'default' => 'all',
					'sanitize_callback' => 'sanitize_key',
				],
				'search' => [
					'sanitize_callback' => 'sanitize_text_field',
				],
				'type' => [
					'default' => 'all',
					'sanitize_callback' => 'sanitize_key',
				],
				'post_id' => [
					'default' => 0,
					'sanitize_callback' => 'absint',
				],
				'post_status' => [
					'default' => 'all',
					'sanitize_callback' => 'sanitize_key',
				],
				'date_range' => [
					'default' => 'all',
					'sanitize_callback' => 'sanitize_key',
				],
				'orderby' => [
					'default' => 'comment_date_gmt',
					'sanitize_callback' => 'sanitize_key',
				],
				'order' => [
					'default' => 'desc',
					'sanitize_callback' => 'sanitize_key',
				],
				'page' => [
					'default' => 1,
					'sanitize_callback' => 'absint',
				],
				'per_page' => [
					'default' => 50,
					'sanitize_callback' => 'absint',
				],
			],
		]);

		register_rest_route( 'wphave/v1', '/comments/stats', [
			'methods' => WP_REST_Server::READABLE,
			'callback' => [ __CLASS__, 'rest_get_comment_stats' ],
			'permission_callback' => [ __CLASS__, 'can_read_comments' ],
		]);

		register_rest_route( 'wphave/v1', '/comments/(?P<id>\d+)', [
			'methods' => WP_REST_Server::EDITABLE,
			'callback' => [ __CLASS__, 'rest_update_comment' ],
				'permission_callback' => [ __CLASS__, 'can_moderate_comment' ],
			'args' => self::get_comment_route_args(),
		]);

		register_rest_route( 'wphave/v1', '/comments/(?P<id>\d+)/status', [
			'methods' => WP_REST_Server::EDITABLE,
			'callback' => [ __CLASS__, 'rest_update_comment_status' ],
			'permission_callback' => [ __CLASS__, 'can_edit_comment' ],
			'args' => [
				'id' => [
					'required' => true,
					'sanitize_callback' => 'absint',
				],
				'status' => [
					'required' => true,
					'sanitize_callback' => 'sanitize_key',
				],
			],
		]);

		register_rest_route( 'wphave/v1', '/comments/(?P<id>\d+)', [
			'methods' => WP_REST_Server::DELETABLE,
			'callback' => [ __CLASS__, 'rest_delete_comment' ],
			'permission_callback' => [ __CLASS__, 'can_delete_comment' ],
			'args' => [
				'id' => [
					'required' => true,
					'sanitize_callback' => 'absint',
				],
				'force' => [
					'default' => false,
					'sanitize_callback' => 'rest_sanitize_boolean',
				],
			],
		]);

		register_rest_route( 'wphave/v1', '/comments/bulk', [
			'methods' => WP_REST_Server::EDITABLE,
			'callback' => [ __CLASS__, 'rest_bulk_action' ],
			'permission_callback' => [ __CLASS__, 'can_read_comments' ],
			'args' => [
				'ids' => [
					'required' => true,
					'type' => 'array',
					'maxItems' => self::MAX_BULK_COMMENTS,
				],
				'action' => [
					'required' => true,
					'sanitize_callback' => 'sanitize_key',
				],
			],
		]);
	}

	/**
	 * Return the comment route args.
	 *
	 * @return array
	 */

	public static function get_comment_route_args() {
		return [
			'id' => [
				'required' => true,
				'sanitize_callback' => 'absint',
			],
			'authorName' => [
				'sanitize_callback' => 'sanitize_text_field',
			],
			'authorEmail' => [
				'sanitize_callback' => 'sanitize_email',
			],
			'authorUrl' => [
				'sanitize_callback' => 'esc_url_raw',
			],
			'content' => [
				'sanitize_callback' => 'wp_kses_post',
			],
			'status' => [
				'sanitize_callback' => 'sanitize_key',
			],
		];
	}

	/**
	 * Determine whether edit comment.
	 *
	 * @param WP_REST_Request $request
	 * @return bool
	 */

		public static function can_edit_comment( WP_REST_Request $request ) {
			return self::can_access_feature() && current_user_can( 'edit_comment', absint( $request['id'] ) );
		}

		/**
		 * Determine whether the current user can moderate comment.
		 *
		 * @param WP_REST_Request $request REST request.
		 */

		public static function can_moderate_comment( WP_REST_Request $request ) {
			return self::current_user_can_moderate_comment( $request['id'] );
		}

	/**
	 * Determine whether delete comment.
	 *
	 * @param WP_REST_Request $request
	 * @return bool
	 */

	public static function can_delete_comment( WP_REST_Request $request ) {
		return self::current_user_can_delete_comment( $request['id'] );
	}

	/**
	 * Handle the get comments REST request.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */

	public static function rest_get_comments( WP_REST_Request $request ) {
		// AUTHORIZATION INVARIANT: REST permission is only an early dispatch gate.
		// Repeat both Engagement feature access and Core moderation authority before
		// exposing comment content, author email, IP address, settings or counts.
		if ( ! self::can_read_comments() ) {
			return new WP_Error(
				'wphave_comments_forbidden',
				__( 'You are not allowed to view comments.', 'wphave' ),
				[ 'status' => 403 ]
			);
		}

		$status = self::normalize_status( $request->get_param( 'status' ) );
		$per_page = absint( $request->get_param( 'per_page' ) );
		$is_count_request = $per_page === 1 && $status !== 'all' && ! $request->get_param( 'search' ) && ! $request->get_param( 'post_id' ) && self::normalize_comment_type_filter( $request->get_param( 'type' ) ) === 'all' && self::normalize_post_status_filter( $request->get_param( 'post_status' ) ) === 'all' && self::normalize_date_range_filter( $request->get_param( 'date_range' ) ) === 'all';

		if ( $is_count_request ) {
			$stats = self::get_comment_stats();

			if ( ! self::can_read_comments() ) {
				return new WP_Error(
					'wphave_comments_forbidden',
					__( 'You are not allowed to view comments.', 'wphave' ),
					[ 'status' => 403 ]
				);
			}

			return rest_ensure_response( [
				'items' => [],
				'total' => (int) ( $stats[ $status ] ?? 0 ),
				'settings' => [],
				'stats' => $stats,
				'statuses' => self::get_status_labels(),
			] );
		}

		$payload = self::get_comments([
			'status' => $request->get_param( 'status' ),
			'search' => $request->get_param( 'search' ),
			'type' => $request->get_param( 'type' ),
			'post_id' => $request->get_param( 'post_id' ),
			'post_status' => $request->get_param( 'post_status' ),
			'date_range' => $request->get_param( 'date_range' ),
			'orderby' => $request->get_param( 'orderby' ),
			'order' => $request->get_param( 'order' ),
			'paged' => $request->get_param( 'page' ),
			'number' => $request->get_param( 'per_page' ),
		]);

		// AUTHORIZATION/TOCTOU INVARIANT: Comment queries, post-title lookup and
		// avatar/payload filters are untrusted extension boundaries. Recheck combined
		// Engagement and moderation authority only after materialization and
		// immediately before releasing content, author email, IP, settings or counts.
		if ( ! self::can_read_comments() ) {
			return new WP_Error(
				'wphave_comments_forbidden',
				__( 'You are not allowed to view comments.', 'wphave' ),
				[ 'status' => 403 ]
			);
		}

		return rest_ensure_response( $payload );
	}

	/**
	 * Handle the get comment stats REST request.
	 *
	 * @param WP_REST_Request $request REST request.
	 */

	public static function rest_get_comment_stats( WP_REST_Request $request ) {
		if ( ! self::can_read_comments() ) {
			return new WP_Error(
				'wphave_comments_forbidden',
				__( 'You are not allowed to view comments.', 'wphave' ),
				[ 'status' => 403 ]
			);
		}

		$stats = self::get_comment_stats();

		if ( ! self::can_read_comments() ) {
			return new WP_Error(
				'wphave_comments_forbidden',
				__( 'You are not allowed to view comments.', 'wphave' ),
				[ 'status' => 403 ]
			);
		}

		return rest_ensure_response( [
			'stats' => $stats,
		] );
	}

	/**
	 * Handle the update comment REST request.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response|WP_Error
	 */

	public static function rest_update_comment( WP_REST_Request $request ) {
		$result = self::update_comment( $request['id'], $request->get_params() );

		return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
	}

	/**
	 * Handle the update comment status REST request.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response|WP_Error
	 */

	public static function rest_update_comment_status( WP_REST_Request $request ) {
		$result = self::set_comment_status( $request['id'], $request->get_param( 'status' ) );

		return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
	}

	/**
	 * Handle the delete comment REST request.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response|WP_Error
	 */

	public static function rest_delete_comment( WP_REST_Request $request ) {
		$result = self::delete_comment( $request['id'], rest_sanitize_boolean( $request->get_param( 'force' ) ) );

		return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
	}

	/**
	 * Handle the bulk action REST request.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response|WP_Error
	 */

	public static function rest_bulk_action( WP_REST_Request $request ) {
		$result = self::bulk_action( $request->get_param( 'ids' ), $request->get_param( 'action' ) );

		return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
	}
}

add_action( 'init', [ 'WPHAVE_Comments_Manager', 'init' ] );
