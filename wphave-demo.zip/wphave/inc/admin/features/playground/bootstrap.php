<?php

if (!defined('ABSPATH')) {
	exit();
}

require_once __DIR__ . '/demo/class-demo-seeder.php';
require_once __DIR__ . '/demo/class-demo-settings-seeder.php';
require_once __DIR__ . '/demo/class-demo-composition-seeder.php';
require_once __DIR__ . '/demo/class-demo-reference-page.php';
require_once __DIR__ . '/demo/class-demo-style-guide.php';
require_once __DIR__ . '/demo/class-demo-block-styling.php';
require_once __DIR__ . '/demo/class-demo-content-seeder.php';
require_once __DIR__ . '/demo/class-demo-structure-seeder.php';
require_once __DIR__ . '/demo/class-demo-insights-seeder.php';
require_once __DIR__ . '/demo/class-demo-operations-seeder.php';
require_once __DIR__ . '/demo/class-demo-installer.php';

require_once __DIR__ . '/demo/class-demo-navigation.php';

WPHAVE_Playground_Demo_Installer::init();
WPHAVE_Playground_Demo_Navigation::init();
