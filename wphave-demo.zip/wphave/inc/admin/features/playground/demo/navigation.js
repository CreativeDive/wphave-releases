/**
 * Embedded Playground cannot reliably serve its scoped URLs in a separate tab.
 * This adapter is injected only by the opt-in demo bootstrap (see docs/playground-demo.md).
 */
(() => {
	if (window.__wphaveDemoNavigationInstalled) {
		return;
	}

	const current = new URL(window.location.href);
	const scope = current.pathname.match(/^\/scope:[^/]+(?=\/|$)/)?.[0];

	// Fail closed outside a scoped, embedded WordPress document.
	if (!scope || window.parent === window) {
		return;
	}

	window.__wphaveDemoNavigationInstalled = true;
	const nativeOpen = window.open;

	function demoUrl(value) {
		try {
			const url = new URL(value, document.baseURI);
			if (
				url.origin === current.origin &&
				(url.pathname === scope || url.pathname.startsWith(`${scope}/`))
			) {
				return url;
			}
		} catch {
			// Invalid URLs retain the browser's native behavior.
		}
		return null;
	}

	function handleLink(event) {
		if (event.defaultPrevented || (event.button !== 0 && event.button !== 1)) {
			return;
		}

		const link = event.target.closest?.('a[href]');
		if (!link || link.hasAttribute('download')) {
			return;
		}

		const target = (
			link.getAttribute('target') ||
			document.querySelector('base[target]')?.getAttribute('target') ||
			'_self'
		).toLowerCase();
		const leavesDocument =
			target !== '_self' ||
			event.button === 1 ||
			event.ctrlKey ||
			event.metaKey ||
			event.shiftKey;
		const url = demoUrl(link.href);
		if (!leavesDocument || !url || event.altKey) {
			return;
		}

		event.preventDefault();
		event.stopPropagation();
		window.location.assign(url.href);
	}

	// Delegation also covers links rendered later by React, without observing the DOM.
	document.addEventListener('click', handleLink, true);
	document.addEventListener('auxclick', handleLink, true);
	window.open = function (url, target, features) {
		const destination = url ? demoUrl(url) : null;
		if (destination) {
			window.location.assign(destination.href);
			// No new browsing context exists; callers must not receive a fake popup handle.
			return null;
		}
		return nativeOpen.apply(this, arguments);
	};
})();
