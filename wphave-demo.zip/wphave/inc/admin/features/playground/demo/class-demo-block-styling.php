<?php

if (!defined('ABSPATH')) {
	exit();
}

/** Localized copy for the editable block styling reference. Design lives in the template. */
class WPHAVE_Playground_Demo_Block_Styling {
	public static function render() {
		return WPHAVE_Playground_Demo_Reference_Page::render(
			'block-styling',
			static fn() => self::copy(),
		);
	}

	private static function copy(): array {
		return [
			'title' => _x('Block Styling', 'Playground block styling', 'wphave'),
			'excerpt' => _x(
				'Explore editable backgrounds, frames, shadows and layout effects.',
				'Playground block styling',
				'wphave',
			),
			'intro' => _x('One block. Many expressions.', 'Playground block styling', 'wphave'),
			'instructions' => _x(
				'Open this page in the editor, select an example surface and explore its design controls. Change one setting, compare the result and copy a block into your own page.',
				'Playground block styling',
				'wphave',
			),
			'backgrounds' => _x('01 / Backgrounds', 'Playground block styling', 'wphave'),
			'frames' => _x('02 / Frames and corners', 'Playground block styling', 'wphave'),
			'shadows' => _x('03 / Shadows and light', 'Playground block styling', 'wphave'),
			'layout' => _x('04 / Spacing and effects', 'Playground block styling', 'wphave'),
			'combinations' => _x('05 / Bringing it together', 'Playground block styling', 'wphave'),
			'sample' => _x('Room for ideas', 'Playground block styling', 'wphave'),
			'closing' => _x('Make it yours.', 'Playground block styling', 'wphave'),
			'closing-copy' => _x(
				'These examples are a starting point. Combine settings and use the global colors, typography and spacing from the Style Guide to keep your pages consistent.',
				'Playground block styling',
				'wphave',
			),
			'solid' => _x('Solid color', 'Playground block styling', 'wphave'),
			'solid-copy' => _x(
				'Background → Color. Change the global accent to see this surface follow.',
				'Playground block styling',
				'wphave',
			),
			'linear' => _x('Linear gradient', 'Playground block styling', 'wphave'),
			'linear-copy' => _x(
				'Background → Gradient. Adjust the colors and direction.',
				'Playground block styling',
				'wphave',
			),
			'radial' => _x('Radial gradient', 'Playground block styling', 'wphave'),
			'radial-copy' => _x(
				'Background → Gradient. Adjust the colors and direction.',
				'Playground block styling',
				'wphave',
			),
			'layered' => _x('Layered gradients', 'Playground block styling', 'wphave'),
			'layered-copy' => _x(
				'Background → Layers. Combine gradients and change their order.',
				'Playground block styling',
				'wphave',
			),
			'border-solid' => _x('Solid border', 'Playground block styling', 'wphave'),
			'border-solid-copy' => _x(
				'Frame → Border. Explore width, line style and color.',
				'Playground block styling',
				'wphave',
			),
			'border-dashed' => _x('Dashed border', 'Playground block styling', 'wphave'),
			'border-dashed-copy' => _x(
				'Frame → Border. Explore width, line style and color.',
				'Playground block styling',
				'wphave',
			),
			'corners' => _x('Individual corners', 'Playground block styling', 'wphave'),
			'corners-copy' => _x(
				'Frame → Corners. Give each corner its own radius.',
				'Playground block styling',
				'wphave',
			),
			'outline' => _x('Offset outline', 'Playground block styling', 'wphave'),
			'outline-copy' => _x(
				'Frame → Outline. Separate the outline from the surface.',
				'Playground block styling',
				'wphave',
			),
			'soft' => _x('Soft shadow', 'Playground block styling', 'wphave'),
			'soft-copy' => _x(
				'Shadow → Outset. Compare offset, blur and opacity.',
				'Playground block styling',
				'wphave',
			),
			'hard' => _x('Hard shadow', 'Playground block styling', 'wphave'),
			'hard-copy' => _x(
				'Shadow → Outset. Compare offset, blur and opacity.',
				'Playground block styling',
				'wphave',
			),
			'inset' => _x('Inset shadow', 'Playground block styling', 'wphave'),
			'inset-copy' => _x(
				'Shadow → Inset. Compare offset, blur and opacity.',
				'Playground block styling',
				'wphave',
			),
			'glow' => _x('Back Glow', 'Playground block styling', 'wphave'),
			'glow-copy' => _x(
				'Shadow → Back Glow. A colored glow behind the surface; keep overflow visible.',
				'Playground block styling',
				'wphave',
			),
			'compact' => _x('Compact spacing', 'Playground block styling', 'wphave'),
			'compact-copy' => _x(
				'Dimensions → Padding. The same content with a different amount of breathing room.',
				'Playground block styling',
				'wphave',
			),
			'spacious' => _x('Generous spacing', 'Playground block styling', 'wphave'),
			'spacious-copy' => _x(
				'Dimensions → Padding. The same content with a different amount of breathing room.',
				'Playground block styling',
				'wphave',
			),
			'opacity' => _x('Transparency', 'Playground block styling', 'wphave'),
			'opacity-copy' => _x(
				'Visibility → Opacity. The entire block becomes translucent, including its content.',
				'Playground block styling',
				'wphave',
			),
			'rotate' => _x('Rotation', 'Playground block styling', 'wphave'),
			'rotate-copy' => _x(
				'Dimensions → Transform. Give a surface a subtle tilt.',
				'Playground block styling',
				'wphave',
			),
			'combined' => _x('Gradient, border and shadow', 'Playground block styling', 'wphave'),
			'combined-copy' => _x(
				'Combine familiar controls into a reusable card. Change one value at a time.',
				'Playground block styling',
				'wphave',
			),
			'hover' => _x('Hover color', 'Playground block styling', 'wphave'),
			'hover-copy' => _x(
				'Select the hover state in the editor and change the background. Move the pointer over this surface to compare; on touch screens, inspect the state in the editor.',
				'Playground block styling',
				'wphave',
			),
		];
	}
}
