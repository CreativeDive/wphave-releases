<?php

if (!defined('ABSPATH')) {
	exit();
}

/**
 * Builds deterministic synthetic Analytics and Audience data for a rolling thirty-day demo window.
 */

class WPHAVE_Playground_Demo_Insights_Seeder extends WPHAVE_Playground_Demo_Seeder {
	/**
	 * Refresh synthetic Analytics and Audience inventories and record their date windows.
	 *
	 * @param array $state Shared installer state containing fixture IDs and completion summaries.
	 * @return array|WP_Error Updated installer state or a domain setup error.
	 */

	public function seed(array $state) {
		if (!WPHAVE_Analytics_Schema::validate()) {
			WPHAVE_Analytics_Schema::install(WPHAVE_Analytics_Schema::DB_VERSION);
		}

		$audience = wphave_audience_manager();

		if (!$audience->schema_ready()) {
			$audience->install();
		}

		try {
			$this->seed_goals();
			$state['analytics'] = $this->seed_analytics($state['pages'] ?? []);
			$state['audience'] = $this->seed_audience($state['pages'] ?? []);
		} catch (Throwable $error) {
			return new WP_Error('wphave_demo_insights_failed', $error->getMessage());
		}

		update_option('wphave_playground_demo_data_notice', 'synthetic', false);

		return $state;
	}

	/**
	 * Initialize synthetic conversion goals only when no goal option is already stored.
	 *
	 * @return void
	 */

	private function seed_goals(): void {
		if (false !== get_option(WPHAVE_Analytics_Goals::OPTION)) {
			return;
		}

		update_option(
			WPHAVE_Analytics_Goals::OPTION,
			[
				[
					'id' => 'contact_request',
					'label' => 'Kontaktanfrage',
					'type' => 'form_submit',
					'enabled' => true,
					'match' => 'demo_contact',
					'value' => 90,
				],
				[
					'id' => 'project_request',
					'label' => 'Projektanfrage',
					'type' => 'form_submit',
					'enabled' => true,
					'match' => 'demo_project',
					'value' => 240,
				],
				[
					'id' => 'primary_cta',
					'label' => 'Primärer CTA',
					'type' => 'click',
					'enabled' => true,
					'match' => 'projekt',
					'value' => 25,
				],
			],
			false,
		);
	}

	/**
	 * Replace demo-owned Analytics rows with a deterministic thirty-day traffic window.
	 *
	 * @param array $pages Demo page IDs keyed by fixture identity.
	 * @return array Window summary containing from, to and days.
	 */

	private function seed_analytics(array $pages): array {
		global $wpdb;
		$events_table = $wpdb->prefix . WPHAVE_Analytics::EVENT_TABLE;
		$daily_table = $wpdb->prefix . WPHAVE_Analytics::DAILY_TABLE;
		$privacy_table = $wpdb->prefix . WPHAVE_Analytics::PRIVACY_DAILY_TABLE;

		$wpdb->query("DELETE FROM {$events_table} WHERE campaign LIKE 'wphave-demo%'");
		$wpdb->query("DELETE FROM {$daily_table} WHERE campaign LIKE 'wphave-demo%'");
		$wpdb->query("DELETE FROM {$privacy_table} WHERE object_key LIKE 'demo:%'");

		$page_weights = [
			'home' => 38,
			'services' => 23,
			'projects' => 18,
			'about' => 11,
			'contact' => 10,
		];

		$channels = [
			[
				'source' => 'google',
				'medium' => 'organic',
				'referrer' => 'google.com',
				'campaign' => 'wphave-demo-search',
				'weight' => 46,
			],
			[
				'source' => 'direct',
				'medium' => 'none',
				'referrer' => '',
				'campaign' => 'wphave-demo-direct',
				'weight' => 25,
			],
			[
				'source' => 'linkedin',
				'medium' => 'social',
				'referrer' => 'linkedin.com',
				'campaign' => 'wphave-demo-social',
				'weight' => 17,
			],
			[
				'source' => 'newsletter',
				'medium' => 'email',
				'referrer' => '',
				'campaign' => 'wphave-demo-newsletter',
				'weight' => 12,
			],
		];

		$devices = [
			['type' => 'desktop', 'weight' => 55, 'browser' => 'Chrome', 'os' => 'Windows'],
			['type' => 'mobile', 'weight' => 38, 'browser' => 'Safari', 'os' => 'iOS'],
			['type' => 'tablet', 'weight' => 7, 'browser' => 'Safari', 'os' => 'iPadOS'],
		];

		$daily_totals = [];
		$end_date = DateTimeImmutable::createFromInterface(current_datetime());

		foreach (self::build_date_range($end_date) as $date) {
			$daily_views = 0;
			$traffic_factor = self::traffic_factor($date);

			foreach ($page_weights as $key => $weight) {
				$post_id = (int) ($pages[$key] ?? 0);

				if (!$post_id) {
					continue;
				}

				$page_views = max(1, (int) round($weight * $traffic_factor));
				$daily_views += $page_views;

				foreach (
					self::allocate($page_views, $channels)
					as $channel_index => $channel_views
				) {
					if ($channel_views < 1) {
						continue;
					}

					$channel = $channels[$channel_index];

					foreach (self::allocate($channel_views, $devices) as $device_index => $views) {
						if ($views < 1) {
							continue;
						}

						$device = $devices[$device_index];

						$row = [
							'post_id' => $post_id,
							'object_type' => 'post',
							'object_id' => $post_id,
							'object_subtype' => 'page',
							'object_key' => 'post:' . $post_id,
							'object_label' => get_the_title($post_id),
							'object_url' => get_permalink($post_id),
							'view_date' => $date->format('Y-m-d'),
							'views' => $views,
							'unique_visitors' => min($views, (int) round($views * 0.69)),
							'sessions' => min($views, (int) round($views * 0.82)),
							'source' => $channel['source'],
							'medium' => $channel['medium'],
							'campaign' => $channel['campaign'],
							'referrer_domain' => $channel['referrer'],
							'device_type' => $device['type'],
							'browser' => $device['browser'],
							'os' => $device['os'],
						];

						$row['dimension_hash'] = hash('sha256', wp_json_encode($row));
						$wpdb->insert($daily_table, $row);
					}
				}
			}

			$daily_totals[$date->format('Y-m-d')] = $daily_views;
		}

		$this->seed_404_daily($daily_table, $daily_totals);
		$this->seed_privacy_countries($privacy_table, $pages, $daily_totals);
		$this->seed_session_events($events_table, $pages, $daily_totals);

		return [
			'from' => array_key_first($daily_totals),
			'to' => array_key_last($daily_totals),
			'days' => count($daily_totals),
		];
	}

	/**
	 * Insert representative session journeys and their associated conversion events.
	 *
	 * @param string $events_table Canonical Analytics events table name, including the site prefix.
	 * @param array $pages Demo page IDs keyed by fixture identity.
	 * @param array $daily_totals Daily view counts keyed by Y-m-d date.
	 * @return void
	 */

	private function seed_session_events(
		string $events_table,
		array $pages,
		array $daily_totals,
	): void {
		$sources = [
			['google', 'organic', 'desktop', 'Chrome', 'Windows', 'wphave-demo-search'],
			['direct', 'none', 'mobile', 'Safari', 'iOS', 'wphave-demo-direct'],
			['linkedin', 'social', 'desktop', 'Chrome', 'macOS', 'wphave-demo-social'],
			['newsletter', 'email', 'mobile', 'Safari', 'iOS', 'wphave-demo-newsletter'],
		];

		$page_keys = ['home', 'services', 'projects', 'about', 'contact'];
		$session_index = 0;

		foreach ($daily_totals as $date => $views) {
			$session_count = max(2, (int) round($views * 0.035));

			for ($daily_index = 0; $daily_index < $session_count; $daily_index++) {
				$source = $sources[$session_index % count($sources)];
				$visitor_id = hash('sha256', 'demo-visitor-' . $date . '-' . $daily_index);
				$session_id = hash('sha256', 'demo-session-' . $date . '-' . $daily_index);
				$hour = 8 + (($daily_index * 3 + $session_index) % 12);
				$path = [
					'home',
					$page_keys[($session_index % 3) + 1],
					0 === $session_index % 2 ? 'contact' : 'projects',
				];

				foreach ($path as $step => $page_key) {
					$post_id = (int) ($pages[$page_key] ?? 0);

					if (!$post_id) {
						continue;
					}

					$this->insert_event(
						$events_table,
						[
							'post_id' => $post_id,
							'object_type' => 'post',
							'object_id' => $post_id,
							'object_subtype' => 'page',
							'object_key' => 'post:' . $post_id,
							'object_label' => get_the_title($post_id),
							'object_url' => get_permalink($post_id),
							'page_url' => get_permalink($post_id),
							'event_type' => 'pageview',
							'viewed_at' => sprintf('%s %02d:%02d:00', $date, $hour, 5 + $step * 7),
							'visitor_id' => $visitor_id,
							'session_id' => $session_id,
							'dedupe_hash' => hash(
								'sha256',
								'demo-pageview-' . $date . '-' . $daily_index . '-' . $step,
							),
						],
						$source,
					);
				}

				if (0 !== $session_index % 4) {
					$this->insert_event(
						$events_table,
						[
							'post_id' => (int) ($pages['projects'] ?? 0),
							'object_type' => 'post',
							'object_id' => (int) ($pages['projects'] ?? 0),
							'object_subtype' => 'page',
							'object_key' => 'post:' . (int) ($pages['projects'] ?? 0),
							'object_label' => get_the_title($pages['projects'] ?? 0),
							'event_type' => 'engagement',
							'viewed_at' => sprintf('%s %02d:32:00', $date, $hour),
							'visitor_id' => $visitor_id,
							'session_id' => $session_id,
							'dedupe_hash' => hash(
								'sha256',
								'demo-engagement-' . $date . '-' . $daily_index,
							),
						],
						$source,
					);
				}

				$this->seed_session_conversion_events(
					$events_table,
					$pages,
					$source,
					$date,
					$daily_index,
					$session_index,
					$visitor_id,
					$session_id,
					$hour,
				);
				$session_index++;
			}
		}
	}

	/**
	 * Insert form and goal events associated with one synthetic session.
	 *
	 * @param string $events_table Canonical Analytics events table name, including the site prefix.
	 * @param array $pages Demo page IDs keyed by fixture identity.
	 * @param array $source Positional source, medium, device, browser, OS and campaign tuple.
	 * @param string $date Session date formatted as Y-m-d.
	 * @param int $daily_index Zero-based session index within the day.
	 * @param int $session_index Running synthetic session index used to vary fixtures deterministically.
	 * @param string $visitor_id Synthetic hashed visitor identifier.
	 * @param string $session_id Synthetic hashed session identifier.
	 * @param int $hour Hour of day for the synthetic event.
	 * @return void
	 */

	private function seed_session_conversion_events(
		string $events_table,
		array $pages,
		array $source,
		string $date,
		int $daily_index,
		int $session_index,
		string $visitor_id,
		string $session_id,
		int $hour,
	): void {
		$form_key = 0 === $session_index % 3 ? 'demo_project' : 'demo_contact';
		$form_label = 'demo_project' === $form_key ? 'Projektanfrage' : 'Kontaktanfrage';
		$goal_id = 'demo_project' === $form_key ? 'project_request' : 'contact_request';
		$contact_id = (int) ($pages['contact'] ?? 0);

		$base = [
			'post_id' => $contact_id,
			'object_type' => 'form',
			'object_id' => 0,
			'object_subtype' => 'wphave_form',
			'object_key' => $form_key,
			'object_label' => $form_label,
			'object_url' => get_permalink($contact_id),
			'page_url' => get_permalink($contact_id),
			'visitor_id' => $visitor_id,
			'session_id' => $session_id,
		];

		$this->insert_event(
			$events_table,
			array_merge($base, [
				'event_type' => 'form_start',
				'viewed_at' => sprintf('%s %02d:38:00', $date, $hour),
				'dedupe_hash' => hash('sha256', 'demo-form-start-' . $date . '-' . $daily_index),
			]),
			$source,
		);

		if (0 === $session_index % 5) {
			$this->insert_event(
				$events_table,
				array_merge($base, [
					'event_type' => 'form_error',
					'viewed_at' => sprintf('%s %02d:40:00', $date, $hour),
					'dedupe_hash' => hash(
						'sha256',
						'demo-form-error-' . $date . '-' . $daily_index,
					),
				]),
				$source,
			);
		}

		if (0 !== $session_index % 4) {
			$this->insert_event(
				$events_table,
				array_merge($base, [
					'event_type' => 'form_submit',
					'goal_id' => $goal_id,
					'viewed_at' => sprintf('%s %02d:43:00', $date, $hour),
					'dedupe_hash' => hash(
						'sha256',
						'demo-form-submit-' . $date . '-' . $daily_index,
					),
				]),
				$source,
			);
		}

		if (0 === $session_index % 3) {
			$this->insert_event(
				$events_table,
				[
					'post_id' => (int) ($pages['services'] ?? 0),
					'object_type' => 'download',
					'object_key' => 'download:demo-guide.pdf',
					'object_label' => 'WPHAVE Demo-Leitfaden',
					'object_url' => home_url('/demo/wphave-leitfaden.pdf'),
					'event_type' => 'download',
					'viewed_at' => sprintf('%s %02d:46:00', $date, $hour),
					'visitor_id' => $visitor_id,
					'session_id' => $session_id,
					'dedupe_hash' => hash('sha256', 'demo-download-' . $date . '-' . $daily_index),
				],
				$source,
			);
		}

		if (0 === $session_index % 2) {
			$this->insert_event(
				$events_table,
				[
					'post_id' => (int) ($pages['projects'] ?? 0),
					'object_type' => 'link',
					'object_key' => 'projekt',
					'object_label' => 'Projekt starten',
					'object_url' => get_permalink($pages['contact'] ?? 0),
					'event_type' => 'click',
					'goal_id' => 'primary_cta',
					'viewed_at' => sprintf('%s %02d:47:00', $date, $hour),
					'visitor_id' => $visitor_id,
					'session_id' => $session_id,
					'dedupe_hash' => hash('sha256', 'demo-cta-' . $date . '-' . $daily_index),
				],
				$source,
			);
		}

		if (0 === $session_index % 4) {
			$this->insert_event(
				$events_table,
				[
					'post_id' => (int) ($pages['about'] ?? 0),
					'object_type' => 'outbound',
					'object_key' => 'outbound:wordpress.org',
					'object_label' => 'WordPress.org',
					'object_url' => 'https://wordpress.org/',
					'event_type' => 'outbound',
					'viewed_at' => sprintf('%s %02d:48:00', $date, $hour),
					'visitor_id' => $visitor_id,
					'session_id' => $session_id,
					'dedupe_hash' => hash('sha256', 'demo-outbound-' . $date . '-' . $daily_index),
				],
				$source,
			);
		}

		if (0 === $session_index % 5) {
			$search_term = 0 === $session_index % 10 ? 'Analytics' : 'Formulare';
			$this->insert_event(
				$events_table,
				[
					'object_type' => 'search',
					'object_subtype' => 'search',
					'object_key' => 'search:' . sanitize_key($search_term),
					'object_label' => $search_term,
					'event_type' => 'search',
					'viewed_at' => sprintf('%s %02d:50:00', $date, $hour),
					'visitor_id' => $visitor_id,
					'session_id' => $session_id,
					'dedupe_hash' => hash('sha256', 'demo-search-' . $date . '-' . $daily_index),
				],
				$source,
			);
		}
	}

	/**
	 * Insert an Analytics event after adding its synthetic traffic-source dimensions.
	 *
	 * @param string $events_table Canonical Analytics events table name, including the site prefix.
	 * @param array $event Analytics event fields before source dimensions are added.
	 * @param array $source Positional source, medium, device, browser, OS and campaign tuple.
	 * @return void
	 */

	private function insert_event(string $events_table, array $event, array $source): void {
		global $wpdb;

		$defaults = [
			'post_id' => 0,
			'object_type' => '',
			'object_id' => 0,
			'object_subtype' => '',
			'object_key' => '',
			'object_label' => '',
			'object_url' => '',
			'page_url' => '',
			'event_type' => 'pageview',
			'goal_id' => null,
			'source' => $source[0],
			'medium' => $source[1],
			'campaign' => $source[5],
			'device_type' => $source[2],
			'browser' => $source[3],
			'os' => $source[4],
			'language' => 'de-DE',
		];

		$wpdb->insert($events_table, array_merge($defaults, $event));
	}

	/**
	 * Insert synthetic missing-page aggregates into the daily Analytics table.
	 *
	 * @param string $daily_table Canonical Analytics daily table name, including the site prefix.
	 * @param array $daily_totals Daily view counts keyed by Y-m-d date.
	 * @return void
	 */

	private function seed_404_daily(string $daily_table, array $daily_totals): void {
		global $wpdb;

		$paths = [
			'/leistungen-alt/' => 4,
			'/referenzen/' => 3,
			'/kontaktformular/' => 2,
			'/ueber-das-projekt/' => 1,
		];

		foreach ($daily_totals as $date => $views) {
			if (0 !== (int) substr(str_replace('-', '', $date), -2) % 3) {
				continue;
			}

			foreach ($paths as $path => $weight) {
				$count = max(1, (int) round($weight * max(0.5, $views / 100)));
				$row = [
					'post_id' => 0,
					'object_type' => '404',
					'object_id' => 0,
					'object_subtype' => '404',
					'object_key' => $path,
					'object_label' => $path,
					'object_url' => home_url($path),
					'view_date' => $date,
					'views' => $count,
					'unique_visitors' => $count,
					'sessions' => $count,
					'source' => 'google',
					'medium' => 'organic',
					'campaign' => 'wphave-demo-search',
					'referrer_domain' => 'google.com',
					'device_type' => 'mobile',
					'browser' => 'Safari',
					'os' => 'iOS',
				];

				$row['dimension_hash'] = hash('sha256', wp_json_encode($row));
				$wpdb->insert($daily_table, $row);
			}
		}
	}

	/**
	 * Insert synthetic country aggregates into the privacy-safe daily table.
	 *
	 * @param string $privacy_table Canonical privacy-safe daily table name, including the site prefix.
	 * @param array $pages Demo page IDs keyed by fixture identity.
	 * @param array $daily_totals Daily view counts keyed by Y-m-d date.
	 * @return void
	 */

	private function seed_privacy_countries(
		string $privacy_table,
		array $pages,
		array $daily_totals,
	): void {
		global $wpdb;
		$countries = ['DE' => 58, 'AT' => 14, 'CH' => 12, 'NL' => 7, 'FR' => 5, 'GB' => 4];
		$post_id = (int) ($pages['home'] ?? 0);

		foreach ($daily_totals as $date => $views) {
			foreach ($countries as $country => $weight) {
				$count = max(1, (int) round(($views * $weight) / 100));
				$object_key = 'demo:geography';

				$dimension_hash = hash(
					'sha256',
					implode('|', [$object_key, $date, 'country', $country]),
				);

				$wpdb->insert($privacy_table, [
					'post_id' => $post_id,
					'object_type' => 'post',
					'object_id' => $post_id,
					'object_subtype' => 'page',
					'object_key' => $object_key,
					'view_date' => $date,
					'dimension_type' => 'country',
					'dimension_value' => $country,
					'dimension_hash' => $dimension_hash,
					'views' => $count,
				]);
			}
		}
	}

	/**
	 * Build the inclusive thirty-day window ending on the supplied date.
	 *
	 * @param DateTimeImmutable $end_date Inclusive end of the demo date window, with its intended timezone.
	 * @return DateTimeImmutable[] Dates in ascending order, starting twenty-nine days before the end.
	 */

	private static function build_date_range(DateTimeImmutable $end_date): array {
		$dates = [];
		$end_date = $end_date->setTime(12, 0);

		foreach (range(29, 0) as $days_ago) {
			$dates[] = $end_date->modify('-' . $days_ago . ' days');
		}

		return $dates;
	}

	/**
	 * Calculate stable daily noise and occasional traffic spikes or dips.
	 *
	 * @param DateTimeInterface $date Session date formatted as Y-m-d.
	 * @return float Traffic multiplier for the supplied date.
	 */

	private static function traffic_factor(DateTimeInterface $date): float {
		$weekday_factors = [
			1 => 1.0,
			2 => 1.02,
			3 => 1.04,
			4 => 1.05,
			5 => 1.03,
			6 => 0.99,
			7 => 0.97,
		];

		// Separate hash segments keep everyday noise independent of the outlier magnitude.
		// Calendar dates preserve overlapping days when the rolling demo window advances.
		$seed = hash('sha256', 'wphave-demo-traffic:' . $date->format('Y-m-d'));
		$variation = (hexdec(substr($seed, 0, 4)) / 65535 - 0.5) * 0.5;
		$event = hexdec(substr($seed, 4, 4)) / 65535;
		$intensity = hexdec(substr($seed, 8, 4)) / 65535;
		$outlier = 1.0;

		if ($event < 0.15) {
			$outlier = 0.35 + $intensity * 0.2;
		} elseif ($event > 0.85) {
			$outlier = 1.65 + $intensity * 0.55;
		}

		return $weekday_factors[(int) $date->format('N')] * (1 + $variation) * $outlier;
	}

	/**
	 * Distribute integer totals by percentage weight and assign rounding remainders deterministically.
	 *
	 * @param int $total Nonnegative integer count to distribute.
	 * @param array $weighted_items Ordered items with percentage weights totaling one hundred.
	 * @return int[] Allocations in input order.
	 */

	private static function allocate(int $total, array $weighted_items): array {
		$allocations = array_fill(0, count($weighted_items), 0);
		$remainders = [];
		$allocated = 0;

		foreach ($weighted_items as $index => $item) {
			$exact = $total * ((float) $item['weight'] / 100);
			$allocations[$index] = (int) floor($exact);
			$remainders[$index] = $exact - $allocations[$index];
			$allocated += $allocations[$index];
		}

		arsort($remainders, SORT_NUMERIC);

		foreach (array_keys($remainders) as $index) {
			if ($allocated >= $total) {
				break;
			}
			$allocations[$index]++;
			$allocated++;
		}

		return $allocations;
	}

	/**
	 * Replace the owned synthetic Audience campaign before creating its new contact graph.
	 *
	 * @param array $pages Demo page IDs keyed by fixture identity.
	 * @return array Audience inventory and date-window summary.
	 * @throws RuntimeException When the previous owned Audience campaign cannot be removed safely.
	 */

	private function seed_audience(array $pages): array {
		$audience = wphave_audience_manager();
		$cleanup = $audience->delete_internal_campaign('wphave-demo');

		// DATA INTEGRITY INVARIANT: Never seed a second synthetic graph when
		// cleanup could not atomically remove the previous owned fixture graph.
		if (is_wp_error($cleanup)) {
			throw new RuntimeException('Existing Audience demo data could not be removed safely.');
		}

		$profiles = self::audience_profiles();
		$lead_fixtures = self::audience_lead_fixtures();
		$subscriber_fixtures = self::audience_subscriber_fixtures();
		$end_date = DateTimeImmutable::createFromInterface(current_datetime());
		$lead_ids = [];
		$lead_ids_by_profile = [];
		$contact_ids = [];

		foreach ($lead_fixtures as $index => $fixture) {
			$profile = $profiles[$fixture['profile']];
			$email = self::audience_email($profile);

			$occurred_at = self::audience_timestamp(
				$end_date,
				$fixture['days_ago'],
				9 + ($index % 8),
			);

			$is_project = 'project_request' === $fixture['goal'];
			$lead = $audience->record_internal_lead([
				'type' => $fixture['type'],
				'event' => $is_project ? 'form_submit:demo_project' : 'form_submit:demo_contact',
				'email' => $email,
				'first_name' => $profile[0],
				'last_name' => $profile[1],
				'source' => $fixture['source'],
				'medium' => $fixture['medium'],
				'campaign' => 'wphave-demo',
				'consent' => 0,
				'consent_label' => 'Synthetischer Demo-Datensatz – keine echte Einwilligung',
				'landing_url' => get_permalink($pages['home'] ?? 0),
				'current_url' => get_permalink($pages['contact'] ?? 0),
				'object_type' => 'form',
				'object_key' => $is_project ? 'demo_project' : 'demo_contact',
				'object_label' => $is_project ? 'Projektanfrage' : 'Kontaktanfrage',
				'goal_id' => $fixture['goal'],
				'data' => [
					'_demo' => true,
					'message' => $is_project
						? 'Synthetische Projektanfrage für die WPHAVE Live-Demo.'
						: 'Synthetische Kontaktanfrage für die WPHAVE Live-Demo.',
				],
				'submission_id' => 'wphave-demo-lead-' . $index,
				'occurred_at' => $occurred_at,
			]);

			if (is_wp_error($lead)) {
				continue;
			}

			$lead_ids[] = (int) $lead['id'];
			$lead_ids_by_profile[$fixture['profile']] = (int) $lead['id'];
			$contact_ids[] = (int) $lead['contact_id'];
			$audience->configure_internal_lead((int) $lead['id'], 'wphave-demo', [
				'status' => $fixture['status'],
				'stage' => $fixture['stage'],
				'priority' => $fixture['priority'],
				'lost_reason' => $fixture['lost_reason'] ?? '',
				'occurred_at' => $occurred_at,
			]);
		}

		$subscriber_ids = [];

		foreach ($subscriber_fixtures as $index => $fixture) {
			$profile = $profiles[$fixture['profile']];

			$occurred_at = self::audience_timestamp(
				$end_date,
				$fixture['days_ago'],
				10 + ($index % 7),
			);

			$subscriber = $audience->record_internal_subscriber([
				'email' => self::audience_email($profile),
				'first_name' => $profile[0],
				'last_name' => $profile[1],
				'status' => $fixture['status'],
				'purpose' => $fixture['purpose'],
				'source' => $fixture['source'],
				'medium' => $fixture['medium'],
				'campaign' => 'wphave-demo',
				'lead_id' => (int) ($lead_ids_by_profile[$fixture['profile']] ?? 0),
				'consent' => 'subscribed' === $fixture['status'] ? 1 : 0,
				'consent_action' => 'granted',
				'consent_source' => 'wphave_playground_demo',
				'consent_label' => 'Synthetischer Demo-Datensatz – keine echte Einwilligung',
				'occurred_at' => $occurred_at,
			]);

			if (!is_wp_error($subscriber)) {
				$subscriber_ids[] = (int) $subscriber['id'];
				$contact_ids[] = (int) $subscriber['contact_id'];
			}
		}

		$this->seed_audience_extensions($profiles);

		return [
			'from' => $end_date->modify('-29 days')->format('Y-m-d'),
			'to' => $end_date->format('Y-m-d'),
			'contacts' => count(array_unique(array_filter($contact_ids))),
			'leads' => count($lead_ids),
			'subscribers' => count($subscriber_ids),
		];
	}

	/**
	 * Seed Audience tags and related fixtures for the supplied synthetic profiles.
	 *
	 * @param array $profiles Synthetic Audience profile tuples.
	 * @return void
	 */

	private function seed_audience_extensions(array $profiles): void {
		global $wpdb;
		$tags_table = $wpdb->prefix . WPHAVE_Audience_Manager::TAGS_TABLE;
		$entity_tags_table = $wpdb->prefix . WPHAVE_Audience_Manager::ENTITY_TAGS_TABLE;
		$field_definitions_table = $wpdb->prefix . WPHAVE_Audience_Manager::FIELD_DEFINITIONS_TABLE;
		$field_values_table = $wpdb->prefix . WPHAVE_Audience_Manager::FIELD_VALUES_TABLE;
		$identities_table = $wpdb->prefix . WPHAVE_Audience_Manager::IDENTITIES_TABLE;
		$now = current_time('mysql');

		$tags = [
			['demo-prospect', 'Demo: Interessent', '#6366f1'],
			['demo-customer', 'Demo: Kunde', '#10b981'],
			['demo-newsletter', 'Demo: Newsletter', '#f59e0b'],
		];

		foreach ($tags as $tag) {
			$wpdb->query(
				$wpdb->prepare(
					"INSERT INTO {$tags_table} (tag_key, label, color, created_at, updated_at) VALUES (%s, %s, %s, %s, %s) ON DUPLICATE KEY UPDATE label = VALUES(label), color = VALUES(color), updated_at = VALUES(updated_at)",
					$tag[0],
					$tag[1],
					$tag[2],
					$now,
					$now,
				),
			);
		}

		$wpdb->query(
			$wpdb->prepare(
				"INSERT INTO {$field_definitions_table} (field_key, label, scope, field_type, privacy_class, validation, is_active, created_at, updated_at) VALUES ('demo_interest', %s, 'contact', 'select', 'personal', %s, 1, %s, %s) ON DUPLICATE KEY UPDATE label = VALUES(label), validation = VALUES(validation), is_active = 1, updated_at = VALUES(updated_at)",
				'Demo: Interesse',
				wp_json_encode(['options' => ['Beratung', 'Website-Relaunch', 'Newsletter']]),
				$now,
				$now,
			),
		);

		$definition_id = (int) $wpdb->get_var(
			"SELECT id FROM {$field_definitions_table} WHERE scope = 'contact' AND field_key = 'demo_interest' LIMIT 1",
		);

		$tag_ids = $wpdb->get_results(
			"SELECT tag_key, id FROM {$tags_table} WHERE tag_key LIKE 'demo-%'",
			OBJECT_K,
		);
		$interests = ['Website-Relaunch', 'Beratung', 'Newsletter'];

		foreach ($profiles as $index => $profile) {
			$email = self::audience_email($profile);
			$contact_id = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT contact_id FROM {$identities_table} WHERE type = 'email' AND value = %s LIMIT 1",
					$email,
				),
			);

			if (!$contact_id) {
				continue;
			}

			$tag_key =
				0 === $index % 5
					? 'demo-customer'
					: (0 === $index % 3
						? 'demo-newsletter'
						: 'demo-prospect');
			$tag_id = (int) ($tag_ids[$tag_key]->id ?? 0);

			if ($tag_id) {
				$wpdb->query(
					$wpdb->prepare(
						"INSERT IGNORE INTO {$entity_tags_table} (tag_id, entity_type, entity_id, created_at) VALUES (%d, 'contact', %d, %s)",
						$tag_id,
						$contact_id,
						$now,
					),
				);
			}

			if ($definition_id) {
				$wpdb->query(
					$wpdb->prepare(
						"INSERT INTO {$field_values_table} (definition_id, entity_type, entity_id, value, created_at, updated_at) VALUES (%d, 'contact', %d, %s, %s, %s) ON DUPLICATE KEY UPDATE value = VALUES(value), updated_at = VALUES(updated_at)",
						$definition_id,
						$contact_id,
						$interests[$index % count($interests)],
						$now,
						$now,
					),
				);
			}
		}
	}

	/**
	 * Define deterministic synthetic identities without real visitor contact details.
	 *
	 * @return array Positional profile tuples used by the Audience fixtures.
	 */

	private static function audience_profiles(): array {
		return [
			['Mara', 'Beispiel'],
			['Noah', 'Muster'],
			['Elif', 'Demo'],
			['Jonas', 'Beispiel'],
			['Mina', 'Muster'],
			['Theo', 'Demo'],
			['Lina', 'Beispiel'],
			['Sam', 'Muster'],
			['Aylin', 'Demo'],
			['David', 'Beispiel'],
			['Paula', 'Muster'],
			['Karim', 'Demo'],
		];
	}

	/**
	 * Define lead scenarios covering acquisition channels and workflow states.
	 *
	 * @return array Lead fixture definitions.
	 */

	private static function audience_lead_fixtures(): array {
		return [
			[
				'profile' => 0,
				'days_ago' => 29,
				'type' => 'form',
				'goal' => 'project_request',
				'source' => 'google',
				'medium' => 'organic',
				'status' => 'won',
				'stage' => 'won',
				'priority' => 'high',
			],
			[
				'profile' => 1,
				'days_ago' => 26,
				'type' => 'form',
				'goal' => 'contact_request',
				'source' => 'direct',
				'medium' => 'none',
				'status' => 'open',
				'stage' => 'new',
				'priority' => 'normal',
			],
			[
				'profile' => 2,
				'days_ago' => 23,
				'type' => 'form',
				'goal' => 'project_request',
				'source' => 'linkedin',
				'medium' => 'social',
				'status' => 'qualified',
				'stage' => 'qualified',
				'priority' => 'high',
			],
			[
				'profile' => 3,
				'days_ago' => 20,
				'type' => 'form',
				'goal' => 'contact_request',
				'source' => 'newsletter',
				'medium' => 'email',
				'status' => 'lost',
				'stage' => 'lost',
				'priority' => 'low',
				'lost_reason' => 'Demo: Zeitrahmen passt nicht',
			],
			[
				'profile' => 4,
				'days_ago' => 17,
				'type' => 'download',
				'goal' => 'primary_cta',
				'source' => 'google',
				'medium' => 'organic',
				'status' => 'open',
				'stage' => 'new',
				'priority' => 'normal',
			],
			[
				'profile' => 5,
				'days_ago' => 14,
				'type' => 'form',
				'goal' => 'project_request',
				'source' => 'linkedin',
				'medium' => 'social',
				'status' => 'qualified',
				'stage' => 'qualified',
				'priority' => 'high',
			],
			[
				'profile' => 6,
				'days_ago' => 11,
				'type' => 'form',
				'goal' => 'contact_request',
				'source' => 'newsletter',
				'medium' => 'email',
				'status' => 'open',
				'stage' => 'new',
				'priority' => 'normal',
			],
			[
				'profile' => 7,
				'days_ago' => 8,
				'type' => 'click',
				'goal' => 'primary_cta',
				'source' => 'direct',
				'medium' => 'none',
				'status' => 'open',
				'stage' => 'new',
				'priority' => 'low',
			],
			[
				'profile' => 0,
				'days_ago' => 6,
				'type' => 'form',
				'goal' => 'contact_request',
				'source' => 'newsletter',
				'medium' => 'email',
				'status' => 'qualified',
				'stage' => 'qualified',
				'priority' => 'normal',
			],
			[
				'profile' => 2,
				'days_ago' => 4,
				'type' => 'download',
				'goal' => 'primary_cta',
				'source' => 'google',
				'medium' => 'organic',
				'status' => 'won',
				'stage' => 'won',
				'priority' => 'high',
			],
			[
				'profile' => 8,
				'days_ago' => 2,
				'type' => 'form',
				'goal' => 'project_request',
				'source' => 'linkedin',
				'medium' => 'social',
				'status' => 'open',
				'stage' => 'new',
				'priority' => 'high',
			],
			[
				'profile' => 9,
				'days_ago' => 0,
				'type' => 'form',
				'goal' => 'contact_request',
				'source' => 'google',
				'medium' => 'organic',
				'status' => 'open',
				'stage' => 'new',
				'priority' => 'normal',
			],
		];
	}

	/**
	 * Define subscription scenarios covering consent states and purposes.
	 *
	 * @return array Subscriber fixture definitions.
	 */

	private static function audience_subscriber_fixtures(): array {
		return [
			[
				'profile' => 0,
				'days_ago' => 28,
				'status' => 'subscribed',
				'purpose' => 'newsletter',
				'source' => 'google',
				'medium' => 'organic',
			],
			[
				'profile' => 1,
				'days_ago' => 25,
				'status' => 'pending',
				'purpose' => 'newsletter',
				'source' => 'direct',
				'medium' => 'none',
			],
			[
				'profile' => 2,
				'days_ago' => 22,
				'status' => 'subscribed',
				'purpose' => 'product_updates',
				'source' => 'linkedin',
				'medium' => 'social',
			],
			[
				'profile' => 3,
				'days_ago' => 19,
				'status' => 'unsubscribed',
				'purpose' => 'newsletter',
				'source' => 'newsletter',
				'medium' => 'email',
			],
			[
				'profile' => 4,
				'days_ago' => 16,
				'status' => 'subscribed',
				'purpose' => 'download_follow_up',
				'source' => 'google',
				'medium' => 'organic',
			],
			[
				'profile' => 5,
				'days_ago' => 13,
				'status' => 'subscribed',
				'purpose' => 'product_updates',
				'source' => 'linkedin',
				'medium' => 'social',
			],
			[
				'profile' => 6,
				'days_ago' => 10,
				'status' => 'pending',
				'purpose' => 'webinar',
				'source' => 'newsletter',
				'medium' => 'email',
			],
			[
				'profile' => 7,
				'days_ago' => 7,
				'status' => 'unsubscribed',
				'purpose' => 'newsletter',
				'source' => 'direct',
				'medium' => 'none',
			],
			[
				'profile' => 10,
				'days_ago' => 3,
				'status' => 'subscribed',
				'purpose' => 'newsletter',
				'source' => 'google',
				'medium' => 'organic',
			],
			[
				'profile' => 11,
				'days_ago' => 1,
				'status' => 'subscribed',
				'purpose' => 'waitlist',
				'source' => 'linkedin',
				'medium' => 'social',
			],
		];
	}

	/**
	 * Derive a synthetic example.invalid address from the profile name.
	 *
	 * @param array $profile Positional profile tuple with first and last name at indexes zero and one.
	 * @return string Lowercase synthetic email address.
	 */

	private static function audience_email(array $profile): string {
		return strtolower($profile[0] . '.' . $profile[1] . '@example.invalid');
	}

	/**
	 * Derive a stable SQL datetime relative to the end of the demo window.
	 *
	 * @param DateTimeImmutable $end_date Inclusive end of the demo date window, with its intended timezone.
	 * @param int $days_ago Nonnegative number of days before the end date.
	 * @param int $hour Hour of day for the synthetic event.
	 * @return string Timestamp formatted as Y-m-d H:i:s in the supplied date timezone.
	 */

	private static function audience_timestamp(
		DateTimeImmutable $end_date,
		int $days_ago,
		int $hour,
	): string {
		return $end_date
			->modify('-' . $days_ago . ' days')
			->setTime($hour, ($days_ago * 7) % 60)
			->format('Y-m-d H:i:s');
	}
}
