<?php

if (!defined('ABSPATH')) {
	exit();
}

/**
 * Seeds project definitions, example content, comments and forms using production services.
 */

class WPHAVE_Playground_Demo_Content_Seeder extends WPHAVE_Playground_Demo_Seeder {
	/**
	 * Seed definitions, terms, projects, forms and comments into the shared fixture state.
	 *
	 * @param array $state Shared installer state containing fixture IDs and completion summaries.
	 * @return array|WP_Error Updated installer state or a domain setup error.
	 */

	public function seed(array $state) {
		$style_guide = $this->seed_style_guide();

		if (is_wp_error($style_guide)) {
			return $style_guide;
		}

		$state['pages']['style-guide'] = $style_guide;

		if (wphave_release_feature_ready('playgroundBlockStyling')) {
			$block_styling = $this->seed_block_styling();
			if (is_wp_error($block_styling)) {
				return $block_styling;
			}
			$state['pages']['block-styling'] = $block_styling;
		}

		$state['terms'] = [];
		$state['projects'] = [];
		if (wphave_release_feature_ready('playgroundExampleContent')) {
			$definition = $this->seed_project_definition();

			if (is_wp_error($definition)) {
				return $definition;
			}

			$taxonomy = $this->seed_discipline_definition();

			if (is_wp_error($taxonomy)) {
				return $taxonomy;
			}

			WPHAVE_Content_Types::clear_definition_cache();
			WPHAVE_Content_Types::register_post_types();
			WPHAVE_Content_Types::clear_definition_cache();
			WPHAVE_Content_Types::register_taxonomies();

			$state['terms'] = $this->seed_terms();
			$state['projects'] = $this->seed_projects($state['terms'], $state['media'] ?? []);
		}
		$state['forms'] = $this->seed_forms();

		if (is_wp_error($state['projects'])) {
			return $state['projects'];
		}

		if (is_wp_error($state['forms'])) {
			return $state['forms'];
		}

		$state['comments'] = $this->seed_comments($state['pages'], $state['projects']);

		if (is_wp_error($state['comments'])) {
			return $state['comments'];
		}

		return $state;
	}

	/** Seed the styling gallery through the shared reference-page ownership contract. */
	private function seed_block_styling() {
		return $this->seed_reference_page(
			'block-styling',
			WPHAVE_Playground_Demo_Block_Styling::render(),
			11,
		);
	}

	/** Seed the design reference through the shared reference-page ownership contract. */
	private function seed_style_guide() {
		return $this->seed_reference_page(
			'style-guide',
			WPHAVE_Playground_Demo_Style_Guide::render(),
			10,
		);
	}

	/**
	 * Create a reference fixture once; repairs preserve visitor edits and renamed slugs.
	 *
	 * @param string $slug Stable bundled fixture identity.
	 * @param array|WP_Error $page Localized post fields or a rendering error.
	 * @param int $menu_order Position among the demo pages.
	 * @return int|WP_Error Existing/new page ID or a rendering/persistence error.
	 */
	private function seed_reference_page(string $slug, $page, int $menu_order) {
		if (is_wp_error($page)) {
			return $page;
		}
		// Reference pages are seeded after the composition, but should appear below
		// its homepage in the default newest-first page list. Only new fixtures
		// receive these dates; upsert_post preserves existing visitor edits.
		$home_id = (int) get_option('page_on_front');
		$home_timestamp = $home_id > 0 ? get_post_time('U', true, $home_id) : false;
		$reference_date_gmt = gmdate(
			'Y-m-d H:i:s',
			($home_timestamp !== false ? (int) $home_timestamp : time()) -
				$menu_order * DAY_IN_SECONDS,
		);
		return $this->upsert_post(
			'page-' . $slug,
			[
				'post_type' => 'page',
				'post_status' => 'publish',
				'post_title' => $page['title'],
				'post_name' => $slug,
				'post_content' => $page['content'],
				'post_excerpt' => $page['excerpt'],
				'comment_status' => 'closed',
				'menu_order' => $menu_order,
				'post_date_gmt' => $reference_date_gmt,
				'post_date' => get_date_from_gmt($reference_date_gmt),
			],
			true,
		);
	}

	/**
	 * Create or reuse fixture comments for demo pages and projects.
	 *
	 * @param array $pages Demo page IDs keyed by fixture identity.
	 * @param array $projects Demo project IDs keyed by fixture identity.
	 * @return array|WP_Error Comment fixture IDs or an insertion/update error.
	 */

	private static function comment_fixtures(): array {
		return [
			[
				'home',
				'Mara Beispiel',
				'mara.beispiel@example.invalid',
				'Die gemeinsame Oberfläche macht den vollständigen Ablauf sehr gut nachvollziehbar.',
				'1',
				12,
				0,
			],
			[
				'home',
				'Noah Muster',
				'noah.muster@example.invalid',
				'Besonders hilfreich finde ich, dass Inhalte und technische Hinweise nicht voneinander getrennt sind.',
				'1',
				11,
				1,
			],
			[
				'services',
				'Elif Demo',
				'elif.demo@example.invalid',
				'Die Übersicht der Werkzeuge vermittelt einen guten Eindruck vom gesamten Workspace.',
				'1',
				8,
				0,
			],
			[
				'contact',
				'Jonas Beispiel',
				'jonas.beispiel@example.invalid',
				'Das Formular und seine Auswertung sind in der Demo gut miteinander verbunden.',
				'1',
				5,
				0,
			],
			[
				'project:aurora',
				'Mina Muster',
				'mina.muster@example.invalid',
				'Ein überzeugendes Beispiel für wiederverwendbare Inhalte und ein konsistentes Designsystem.',
				'1',
				4,
				0,
			],
			[
				'project:fjord',
				'Theo Demo',
				'theo.demo@example.invalid',
				'Ich würde gerne noch mehr über den Automatisierungsablauf erfahren.',
				'0',
				2,
				0,
			],
			[
				'project:kinetic',
				'Demo Redaktion',
				'redaktion@example.invalid',
				'Diese Nachricht demonstriert die Moderationsansicht und wartet auf Freigabe.',
				'0',
				1,
				0,
			],
			[
				'services',
				'Unpassender Demo-Kommentar',
				'spam@example.invalid',
				'Synthetischer Spam-Eintrag zur Demonstration der Moderationsfilter.',
				'spam',
				1,
				0,
			],
		];
	}

	private static function comment_target(array $fixture, array $pages, array $projects): int {
		$key = $fixture[0];
		return str_starts_with($key, 'project:')
			? (int) ($projects[substr($key, 8)] ?? 0)
			: (int) ($pages[$key] ?? 0);
	}

	/** Completeness and seeding must use the same currently materialized targets. */
	public static function expected_comment_count(array $pages, array $projects): int {
		return count(
			array_filter(
				self::comment_fixtures(),
				static fn(array $fixture): bool => self::comment_target(
					$fixture,
					$pages,
					$projects,
				) > 0,
			),
		);
	}

	private function seed_comments(array $pages, array $projects) {
		$fixtures = self::comment_fixtures();
		$result = [];
		$parent_ids = [];
		$now = DateTimeImmutable::createFromInterface(current_datetime());

		foreach ($fixtures as $index => $fixture) {
			$post_id = self::comment_target($fixture, $pages, $projects);

			if (!$post_id) {
				continue;
			}

			$existing = get_comments([
				'post_id' => $post_id,
				'meta_key' => self::META_KEY,
				'meta_value' => 'comment-' . $index,
				'number' => 1,
				'status' => 'all',
			]);

			$comment_data = [
				'comment_ID' => $existing ? (int) $existing[0]->comment_ID : 0,
				'comment_post_ID' => $post_id,
				'comment_author' => $fixture[1],
				'comment_author_email' => $fixture[2],
				'comment_content' => $fixture[3],
				'comment_approved' => $fixture[4],
				'comment_date' => $now->modify('-' . $fixture[5] . ' days')->format('Y-m-d H:i:s'),
				'comment_parent' => $fixture[6] ? (int) ($parent_ids[$fixture[6] - 1] ?? 0) : 0,
			];

			if ($existing) {
				$updated = wp_update_comment(wp_slash($comment_data), true);
				$comment_id = is_wp_error($updated) ? $updated : (int) $comment_data['comment_ID'];
			} else {
				$comment_id = wp_insert_comment(wp_slash($comment_data));
			}

			if (is_wp_error($comment_id)) {
				return $comment_id;
			}

			if (!$comment_id) {
				return new WP_Error(
					'wphave_demo_comment_failed',
					'A WPHAVE demo comment could not be created.',
				);
			}

			update_comment_meta($comment_id, self::META_KEY, 'comment-' . $index);
			update_comment_meta($comment_id, '_wphave_playground_demo', 1);

			$parent_ids[$index] = $comment_id;
			$result[] = $comment_id;
		}

		return $result;
	}

	/**
	 * Create or update the example project content-type definition.
	 *
	 * @return int|WP_Error Definition post ID or an insertion error.
	 */

	private function seed_project_definition() {
		$config = WPHAVE_Content_Type_Validator::sanitize_post_type([
			'singularName' => 'Beispiel',
			'description' => 'Synthetische Anwendungsbeispiele für die WPHAVE Live-Demo.',
			'supports' => ['title', 'editor', 'excerpt', 'thumbnail', 'revisions'],
			'taxonomies' => ['project_discipline'],
			'menuIcon' => 'portfolio',
			'rewrite' => ['enabled' => true, 'slug' => 'beispiele'],
		]);

		return $this->upsert_post('definition-project', [
			'post_type' => WPHAVE_Content_Types::POST_TYPE,
			'post_status' => 'publish',
			'post_title' => 'Beispiele',
			'post_name' => 'project',
			'post_content' => wp_json_encode($config, JSON_UNESCAPED_UNICODE),
		]);
	}

	/**
	 * Create or update the project-discipline taxonomy definition.
	 *
	 * @return int|WP_Error Definition post ID or an insertion error.
	 */

	private function seed_discipline_definition() {
		$config = WPHAVE_Content_Type_Validator::sanitize_taxonomy([
			'singularName' => 'Thema',
			'objectTypes' => ['project'],
			'hierarchical' => true,
			'showAdminColumn' => true,
			'rewrite' => ['enabled' => true, 'slug' => 'thema', 'hierarchical' => true],
		]);

		return $this->upsert_post('definition-project-discipline', [
			'post_type' => WPHAVE_Content_Types::TAXONOMY,
			'post_status' => 'publish',
			'post_title' => 'Themen',
			'post_name' => 'project_discipline',
			'post_content' => wp_json_encode($config, JSON_UNESCAPED_UNICODE),
		]);
	}

	/**
	 * Create or reuse project-discipline terms, omitting terms that fail insertion.
	 *
	 * @return int[] Term IDs keyed by sanitized discipline name.
	 */

	private function seed_terms(): array {
		$result = [];
		foreach (['Inhalte', 'Design', 'Automatisierung', 'Betrieb'] as $name) {
			$term = term_exists($name, 'project_discipline');

			if (!$term) {
				$term = wp_insert_term($name, 'project_discipline');
			}

			if (!is_wp_error($term)) {
				$result[sanitize_key($name)] = (int) (is_array($term) ? $term['term_id'] : $term);
			}
		}

		return $result;
	}

	/**
	 * Create or update example projects and assign their disciplines and media.
	 *
	 * @param array $terms Discipline term IDs keyed by sanitized name.
	 * @param array $media Attachment IDs keyed by demo asset identity.
	 * @return array|WP_Error Project IDs keyed by fixture identity, or a creation error.
	 */

	private function seed_projects(array $terms, array $media) {
		$items = [
			'aurora' => [
				'Service Website',
				'Ein klarer Auftritt führt Besucher von der ersten Orientierung bis zur qualifizierten Anfrage.',
				['inhalte', 'design'],
			],
			'fjord' => [
				'Product Showcase',
				'Ein modulares Produkterlebnis verbindet Storytelling, Funktionen und direkte Handlungswege.',
				['design', 'automatisierung'],
			],
			'kinetic' => [
				'Knowledge Hub',
				'Strukturierte Inhaltstypen machen umfangreiches Fachwissen dauerhaft auffindbar und pflegbar.',
				['inhalte', 'betrieb'],
			],
			'mira' => [
				'Campaign Launch',
				'Eine fokussierte Landingpage kombiniert eine starke Botschaft mit messbaren Konversionen.',
				['design', 'betrieb'],
			],
			'north' => [
				'Editorial Platform',
				'Wiederverwendbare Patterns schaffen einen flexiblen Rahmen für Artikel, Dossiers und Serien.',
				['inhalte', 'automatisierung'],
			],
			'solis' => [
				'Member Portal',
				'Rollen, Inhalte und individuelle Bereiche werden in einer konsistenten Erfahrung zusammengeführt.',
				['automatisierung', 'betrieb'],
			],
		];

		$result = [];
		foreach ($items as $key => $item) {
			$content = $this->pattern('hero', 'hero-11', [
				'eyebrow' => 'WPHAVE Anwendungsbeispiel',
				'heading' => $item[0],
				'body' => $item[1],
				'actions' => [['label' => 'Beispiel erkunden'], ['label' => 'Weitere Beispiele']],
			]);

			$content .=
				"\n\n" .
				$this->pattern('stats', 'stats-section-1', [
					'heading' => 'Ein System, das mit den Anforderungen wächst.',
					'body' =>
						'Inhalte, Designregeln und wiederverwendbare Komponenten bleiben in einem gemeinsamen Arbeitsfluss verbunden.',
					'actions' => [['label' => 'Details ansehen'], ['label' => 'Kontakt']],
					'stats' => [
						['value' => '1', 'suffix' => '×', 'text' => 'Zentrale Designquelle'],
						['value' => '100', 'suffix' => '%', 'text' => 'Strukturierte Inhalte'],
						['value' => '6', 'suffix' => '', 'text' => 'Responsive Ansichten'],
						['value' => '0', 'suffix' => '', 'text' => 'Demo-Abhängigkeiten'],
					],
				]);

			if (!trim($content)) {
				return new WP_Error(
					'wphave_demo_pattern_missing',
					'A required WPHAVE demo pattern is unavailable.',
				);
			}

			$post_id = $this->upsert_post('project-' . $key, [
				'post_type' => 'project',
				'post_status' => 'publish',
				'post_title' => $item[0],
				'post_excerpt' => $item[1],
				'post_content' => $content,
				'meta_input' => isset($media[$key]) ? ['_thumbnail_id' => $media[$key]] : [],
			]);

			if (is_wp_error($post_id)) {
				return $post_id;
			}

			wp_set_object_terms(
				$post_id,
				array_values(array_intersect_key($terms, array_flip($item[2]))),
				'project_discipline',
			);

			$result[$key] = $post_id;
		}

		return $result;
	}

	/**
	 * Create or update demo forms and persist their production form configuration.
	 *
	 * @return array|WP_Error Form IDs keyed by fixture identity, or a persistence error.
	 */

	private function seed_forms() {
		$forms = [
			'contact' => ['Kontaktanfrage', 'demo_contact', 'Nachricht'],
			'project' => ['Demo-Anfrage', 'demo_project', 'Vorhaben und Ziel'],
		];

		$result = [];
		foreach ($forms as $key => $form) {
			$existing = get_posts([
				'post_type' => WPHAVE_Form_Manager::POST_TYPE,
				'post_status' => 'any',
				'posts_per_page' => 1,
				'fields' => 'ids',
				'meta_key' => self::META_KEY,
				'meta_value' => 'form-' . $key,
			]);

			if ($existing && get_post_meta($existing[0], '_wphave_demo_form_defaults', true)) {
				$result[$key] = (int) $existing[0];
				continue;
			}

			$content = $this->form_content($form);

			if ($existing) {
				$blocks = parse_blocks((string) get_post_field('post_content', $existing[0]));
				foreach ($blocks as &$block) {
					if ('wphave/form' === ($block['blockName'] ?? '')) {
						$block['attrs'] = array_replace(
							self::form_defaults(),
							$block['attrs'] ?? [],
						);
					}
				}
				unset($block);
				$content = serialize_blocks($blocks);
			}

			$post_id = $this->upsert_post('form-' . $key, [
				'post_type' => WPHAVE_Form_Manager::POST_TYPE,
				'post_status' => $existing ? get_post_status($existing[0]) : 'publish',
				'post_title' => $existing ? get_post_field('post_title', $existing[0]) : $form[0],
				'post_content' => $content,
			]);

			if (is_wp_error($post_id)) {
				return $post_id;
			}

			if (
				!update_post_meta($post_id, '_wphave_demo_form_defaults', true) &&
				!get_post_meta($post_id, '_wphave_demo_form_defaults', true)
			) {
				return new WP_Error(
					'wphave_demo_form_marker_failed',
					'Cannot persist demo form initialization.',
				);
			}

			$result[$key] = $post_id;
		}

		return $result;
	}
	/**
	 *  Production form attributes shared by new fixtures and legacy migration.
	 *
	 * @return array Default form settings.
	 */

	private static function form_defaults(): array {
		return [
			'emailNotificationEnabled' => false,
			'audienceLeadEnabled' => true,
			'successMessage' =>
				'Deine Testanfrage wurde in dieser Demo unter Audience gespeichert.',
		];
	}

	/**
	 * Build demo form block markup from the supplied form definition.
	 * Leave layout attributes unset so the Form block's registered defaults apply.
	 *
	 * @param array $form Demo form definition and its field/content values.
	 * @return string Serialized form block markup.
	 */

	private function form_content(array $form): string {
		$attributes = array_merge(self::form_defaults(), [
			'formId' => $form[1],
		]);

		$content =
			'<!-- wp:wphave/form ' .
			wp_json_encode($attributes, JSON_UNESCAPED_UNICODE) .
			' -->' .
			"\n";

		$content .=
			'<!-- wp:wphave/form-input {"name":"first_name","inputId":"' .
			$form[1] .
			'-name","label":"Name","required":true} /-->' .
			"\n\n";

		$content .=
			'<!-- wp:wphave/form-input {"name":"email","inputId":"' .
			$form[1] .
			'-email","label":"E-Mail","required":true,"inputType":"email"} /-->' .
			"\n\n";

		$content .=
			'<!-- wp:wphave/form-textarea {"name":"message","inputId":"' .
			$form[1] .
			'-message","label":"' .
			$form[2] .
			'","required":true} /-->' .
			"\n\n";

		$content .= '<!-- wp:wphave/form-submit-button /-->' . "\n" . '<!-- /wp:wphave/form -->';

		return $content;
	}
}
