<?php

if (!defined('ABSPATH')) {
	exit();
}

/**
 * Seeds example redirects and activity records for the demo operations screens.
 */

class WPHAVE_Playground_Demo_Operations_Seeder extends WPHAVE_Playground_Demo_Seeder {
	/**
	 * Seed redirect and activity inventories into the shared fixture state.
	 *
	 * @param array $state Shared installer state containing fixture IDs and completion summaries.
	 * @return array|WP_Error Updated installer state or a domain setup error.
	 */

	public function seed(array $state) {
		$redirects = $this->seed_redirects($state['pages'] ?? []);
		if (is_wp_error($redirects)) {
			return $redirects;
		}
		$state['redirects'] = $redirects;
		$state['activity'] = $this->seed_activity($state);

		return $state;
	}

	/**
	 * Create or update example redirects through the production REST save handler.
	 *
	 * @param array $pages Demo page IDs keyed by fixture identity.
	 * @return array|WP_Error Saved redirect IDs or a schema/save error.
	 */

	private function seed_redirects(array $pages) {
		if (!WPHAVE_Redirect_Manager::schema_ready()) {
			WPHAVE_Redirect_Manager::install();
		}
		if (!WPHAVE_Redirect_Manager::schema_ready()) {
			return new WP_Error(
				'wphave_demo_redirect_schema',
				'The redirect schema is unavailable for WPHAVE demo data.',
			);
		}

		$fixtures = [
			[
				'/start-alt/',
				'home',
				301,
				'Ein früherer Startseitenpfad führt zur Signal-Studio-Demo.',
			],
			[
				'/leistungen-alt/',
				'services',
				301,
				'Eine frühere Leistungsseite führt zur aktuellen Funktionsübersicht.',
			],
			[
				'/referenzen/',
				'projects',
				301,
				'Ein früherer Referenzpfad führt zu den aktuellen Beispielen.',
			],
			['/kontaktformular/', 'contact', 302, 'Temporäre Weiterleitung zum Demoformular.'],
			[
				'/ueber-das-projekt/',
				'about',
				301,
				'Ein ehemaliger Projektpfad führt zur Seite über WPHAVE.',
			],
		];

		$result = [];
		foreach ($fixtures as $fixture) {
			$target = !empty($pages[$fixture[1]]) ? get_permalink($pages[$fixture[1]]) : '';
			if (!$target) {
				continue;
			}
			$existing = WPHAVE_Redirect_Manager::match_url($fixture[0]);
			$request = new WP_REST_Request('POST', '/wphave/v1/redirects');
			$request->set_header('Content-Type', 'application/json');
			$request->set_body(
				wp_json_encode([
					'id' => (int) ($existing['id'] ?? 0),
					'source_path' => $fixture[0],
					'target_url' => $target,
					'status_code' => $fixture[2],
					'match_type' => 'exact',
					'preserve_query' => true,
					'enabled' => true,
					'notes' => 'WPHAVE Live-Demo: ' . $fixture[3],
				]),
			);
			$response = WPHAVE_Redirect_Manager::save_endpoint($request);
			if (is_wp_error($response)) {
				return $response;
			}
			$data = $response instanceof WP_REST_Response ? $response->get_data() : [];
			$id = (int) ($data['item']['id'] ?? 0);
			if ($id) {
				$result[] = $id;
			}
		}

		return $result;
	}

	/**
	 * Replace demo-owned activity records when the activity feature and schema are available.
	 *
	 * @param array $state Shared installer state containing fixture IDs and completion summaries.
	 * @return int[] Activity record IDs, or an empty list when the feature is unavailable.
	 */

	private function seed_activity(array $state): array {
		if (
			!function_exists('wphave_activity_feature_enabled') ||
			!wphave_activity_feature_enabled() ||
			!class_exists('WPHAVE_Activity_Schema') ||
			!class_exists('WPHAVE_Activity_Log')
		) {
			return [];
		}

		if (!WPHAVE_Activity_Schema::validate()) {
			WPHAVE_Activity_Schema::install();
		}

		if (!WPHAVE_Activity_Schema::validate()) {
			return [];
		}

		global $wpdb;
		$table = $wpdb->prefix . WPHAVE_Activity_Log::TABLE;
		$wpdb->delete($table, ['object_subtype' => 'playground_demo'], ['%s']);

		$fixtures = [
			['composition.applied', 'design', 'updated', 'site_composition', 0, 'WPHAVE Demo', 13],
			['content_type.created', 'content', 'created', 'content_type', 0, 'Beispiele', 11],
			[
				'analytics.goal_created',
				'analytics',
				'created',
				'analytics_goal',
				0,
				'Kontaktanfrage',
				8,
			],
			[
				'content.updated',
				'content',
				'updated',
				'form',
				(int) ($state['forms']['contact'] ?? 0),
				'Kontaktanfrage',
				5,
			],
			[
				'redirect.created',
				'redirects',
				'created',
				'redirect',
				(int) ($state['redirects'][0] ?? 0),
				'/leistungen-alt/',
				3,
			],
			[
				'media.details_updated',
				'media',
				'updated',
				'attachment',
				(int) ($state['media']['aurora'] ?? 0),
				'Demo-Medium',
				1,
			],
		];

		$result = [];
		$now = DateTimeImmutable::createFromInterface(current_datetime())->setTimezone(
			new DateTimeZone('UTC'),
		);

		foreach ($fixtures as $fixture) {
			$event_id = WPHAVE_Activity_Log::record($fixture[0], [
				'category' => $fixture[1],
				'action' => $fixture[2],
				'object_type' => $fixture[3],
				'object_id' => $fixture[4],
				'object_subtype' => 'playground_demo',
				'object_label' => $fixture[5],
				'source' => 'system',
				'context' => ['synthetic' => true, 'campaign' => 'wphave-demo'],
			]);

			if (!$event_id) {
				continue;
			}

			$occurred_at = $now->modify('-' . $fixture[6] . ' days')->format('Y-m-d H:i:s');

			$wpdb->update(
				$table,
				['occurred_at' => $occurred_at],
				['id' => $event_id],
				['%s'],
				['%d'],
			);

			$result[] = $event_id;
		}

		wp_cache_delete('facets', 'wphave-activity');

		return $result;
	}
}
