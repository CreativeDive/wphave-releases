<?php

if (!defined('ABSPATH')) {
	exit();
}

/**
 * Defines shared fixture identity, post upserts and production-pattern rendering for demo seeders.
 */

abstract class WPHAVE_Playground_Demo_Seeder {
	/**
	 * Stable fixture identity stored in post metadata.
	 *
	 * @var string
	 */

	const META_KEY = '_wphave_playground_demo_key';

	/**
	 * Seed one part of the demo and return created object IDs.
	 *
	 * @param array $state Shared installer state containing fixture IDs and completion summaries.
	 * @return array|WP_Error Updated installer state or a domain setup error.
	 */

	abstract public function seed(array $state);

	/**
	 * Create or update a fixture post identified independently of its database ID.
	 *
	 * @param string $key Stable fixture or defaults-group key.
	 * @param array $postarr WordPress post fields for the fixture.
	 * @param bool $preserve_existing Keep visitor edits when a fixture already exists.
	 * @return int|WP_Error Post ID or an insertion error.
	 */

	protected function upsert_post(string $key, array $postarr, bool $preserve_existing = false) {
		// IDEMPOTENCY INVARIANT: Demo objects are identified by a stable fixture key,
		// never by installation-specific IDs; rerunning setup updates instead of duplicating.
		$existing = get_posts([
			'post_type' => $postarr['post_type'] ?? 'post',
			'post_status' => $preserve_existing
				? ['publish', 'future', 'draft', 'pending', 'private', 'trash']
				: 'any',
			'posts_per_page' => 1,
			'fields' => 'ids',
			'meta_key' => self::META_KEY,
			'meta_value' => $key,
			'no_found_rows' => true,
		]);

		if ($preserve_existing && $existing) {
			return (int) $existing[0];
		}

		$postarr['meta_input'] = array_merge($postarr['meta_input'] ?? [], [
			self::META_KEY => $key,
			'_wphave_playground_demo' => 1,
		]);

		if ($existing) {
			$postarr['ID'] = (int) $existing[0];
		}

		return wp_insert_post(wp_slash($postarr), true);
	}

	/**
	 * Materialize one production pattern with deterministic demo copy.
	 *
	 * Demo pages deliberately use the same editor-exported pattern source as
	 * the inserter and planner. Never introduce a separate demo-only block
	 * builder here; it would drift from responsive and style-system changes.
	 *
	 * @param string $collection Registered production pattern collection key.
	 * @param string $key Stable fixture or defaults-group key.
	 * @param array $slots Slot values supplied to the production pattern renderer.
	 * @return string Block markup, or an empty string when the collection or pattern is unavailable.
	 */

	protected function pattern(string $collection, string $key, array $slots): string {
		$collections = [
			'hero' => 'wphave_block_pattern_collection_hero',
			'process' => 'wphave_block_pattern_collection_process',
			'stats' => 'wphave_block_pattern_collection_stats',
			'testimonials' => 'wphave_block_pattern_collection_testimonials',
		];

		$callback = $collections[$collection] ?? '';

		if (!$callback || !is_callable($callback)) {
			return '';
		}

		foreach (call_user_func($callback, ['slots' => $slots]) as $pattern) {
			if (($pattern['key'] ?? '') === $key) {
				return trim((string) ($pattern['content'] ?? ''));
			}
		}

		return '';
	}
}
