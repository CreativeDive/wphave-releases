<?php

if (!defined('ABSPATH')) {
	exit();
}

/**
 * One-time defaults, independent of synthetic fixture dates and versions.
 */

class WPHAVE_Playground_Demo_Settings_Seeder extends WPHAVE_Playground_Demo_Seeder {
	/**
	 * Run a defaults callback once and mark completion only when it returns without WP_Error.
	 *
	 * @param string $key Stable fixture or defaults-group key.
	 * @param callable $callback Defaults callback; WP_Error prevents the completion marker from being written.
	 * @return true|WP_Error Already completed or newly persisted completion, or a callback/marker error.
	 */

	public static function once(string $key, callable $callback) {
		$marker = 'wphave_playground_demo_defaults_' . $key;

		if (get_option($marker)) {
			return true;
		}

		$result = $callback();

		if (is_wp_error($result)) {
			return $result;
		}

		if (!update_option($marker, true, false) && !get_option($marker)) {
			return new WP_Error(
				'wphave_demo_defaults_marker_failed',
				'Cannot persist demo defaults completion.',
			);
		}

		return true;
	}

	/**
	 *  Preserve explicit settings, including false, empty lists and blank strings.
	 *
	 * @param string $resource Canonical data resource identifier.
	 * @param string $path Setting path within the resource.
	 * @param mixed $value Value to persist.
	 * @return true|array|WP_Error True for a preserved value, the resource write result, or a write error.
	 */

	public static function set_missing(string $resource, string $path, $value) {
		if (null !== wphave_data_get($resource, $path, null)) {
			return true;
		}

		return wphave_data_set($resource, $path, $value);
	}

	/**
	 * Persist a WordPress option and accept an unchanged value as success.
	 *
	 * @param string $name WordPress option name.
	 * @param mixed $value Value to persist.
	 * @return true|WP_Error Successful persistence or an option verification error.
	 */

	private static function set_option(string $name, $value) {
		if (
			!update_option($name, $value, false) &&
			(string) get_option($name) !== (string) $value
		) {
			return new WP_Error(
				'wphave_demo_option_failed',
				'Cannot persist demo option: ' . $name,
			);
		}

		return true;
	}

	/**
	 * Apply environment defaults once while leaving language-pack provisioning to the Blueprint.
	 *
	 * @return true|WP_Error Completed environment defaults or a persistence error.
	 */

	public static function seed_environment() {
		return self::once('environment', static function () {
			// The Blueprint owns language-pack installation and locale selection.
			// Older Blueprints must still seed content when no language pack exists.
			$options = [
				'timezone_string' => 'Europe/Berlin',
				'date_format' => 'd.m.Y',
				'time_format' => 'H:i',
				'start_of_week' => 1,
			];

			// Existing demos may already have visitor-owned identity and permalinks.
			if (!get_option(WPHAVE_Playground_Demo_Installer::VERSION_OPTION)) {
				$options['blogname'] = 'Live Demo';
				$options['permalink_structure'] = '/%postname%/';
			}

			foreach ($options as $name => $value) {
				$result = self::set_option($name, $value);
				if (is_wp_error($result)) {
					return $result;
				}
			}

			return true;
		});
	}

	/**
	 * Apply editor and branding defaults once, returning the existing fixture state on success.
	 *
	 * @param array $state Shared installer state containing fixture IDs and completion summaries.
	 * @return array|WP_Error Updated installer state or a domain setup error.
	 */

	public function seed(array $state) {
		$result = self::once('editor_and_brand', function () {
			foreach ($this->editor_defaults() as $path => $value) {
				if ('editor.blocks.coreEmbed' === $path) {
					$existing = wphave_data_get('site_settings', $path, []);

					if (!is_array($existing)) {
						return new WP_Error(
							'wphave_demo_invalid_embeds',
							'Expected an embed visibility map.',
						);
					}

					$result = wphave_data_set(
						'site_settings',
						$path,
						array_replace($value, $existing),
					);
				} else {
					$result = self::set_missing('site_settings', $path, $value);
				}

				if (is_wp_error($result)) {
					return $result;
				}
			}

			return $this->seed_brand();
		});

		return is_wp_error($result) ? $result : $state;
	}

	/**
	 * Build the canonical editor defaults and explicit hidden embed-provider map.
	 *
	 * @return array Setting values keyed by their site-settings resource path.
	 */

	private function editor_defaults(): array {
		// Explicit provider snapshot: new Core providers retain normal availability.
		$hidden_embeds = [
			'twitter',
			'facebook',
			'instagram',
			'spotify',
			'flickr',
			'animoto',
			'cloudup',
			'collegehumor',
			'crowdsignal',
			'dailymotion',
			'imgur',
			'issuu',
			'kickstarter',
			'mixcloud',
			'pocket-casts',
			'reddit',
			'reverbnation',
			'scribd',
			'smugmug',
			'speaker-deck',
			'tiktok',
			'ted',
			'tumblr',
			'videopress',
			'wordpress-tv',
			'amazon-kindle',
			'pinterest',
			'wolfram-cloud',
			'bluesky',
		];

		$embeds = array_fill_keys($hidden_embeds, false);
		foreach (['youtube', 'vimeo', 'wordpress', 'soundcloud'] as $provider) {
			$embeds[$provider] = true;
		}

		$defaults = [
			'advanced.ui.frontendAdminBar' => true,
			'seo.titleSuffix' => 'WPHAVE Demo',
			'seo.titleSeparator' => '|',
			'editor.presets.gradients' => [
				[
					'id' => 'demo-signal-accent',
					'name' => 'Signal · Akzent',
					'gradient' => [
						'type' => 'linear',
						'angle' => 135,
						'colorStops' => [
							['color' => '#12e3c4', 'position' => 0],
							['color' => '#111111', 'position' => 100],
						],
					],
				],
				[
					'id' => 'demo-signal-paper',
					'name' => 'Signal · Papier',
					'gradient' => [
						'type' => 'linear',
						'angle' => 180,
						'colorStops' => [
							['color' => '#f7f7f5', 'position' => 0],
							['color' => '#d8d8d8', 'position' => 100],
						],
					],
				],
			],
			'editor.presets.borders' => [
				[
					'id' => 'demo-signal-line',
					'name' => 'Signal · Kontur',
					'width' => '2px',
					'style' => 'solid',
					'color' => '#111111',
				],
				[
					'id' => 'demo-signal-highlight',
					'name' => 'Signal · Akzent',
					'width' => '2px',
					'style' => 'solid',
					'color' => '#12e3c4',
				],
			],
			'editor.presets.shadows' => [
				[
					'id' => 'demo-signal-shadow',
					'name' => 'Signal · Sanft',
					'type' => 'outset',
					'multiple' => false,
					'value' => [
						'shift' => ['x' => '0px', 'y' => '8px'],
						'blur' => '24px',
						'spread' => '0px',
						'color' => '#111111',
						'opacity' => 0.12,
					],
				],
				[
					'id' => 'demo-signal-offset',
					'name' => 'Signal · Versatz',
					'type' => 'outset',
					'multiple' => false,
					'value' => [
						'shift' => ['x' => '6px', 'y' => '6px'],
						'blur' => '0px',
						'spread' => '0px',
						'color' => '#12e3c4',
						'opacity' => 1,
					],
				],
			],
		];

		$defaults['editor.blocks.coreEmbed'] = $embeds;

		return $defaults;
	}

	/**
	 * Import demo branding and assign the logo and site icon through their owning services.
	 *
	 * @return true|array|WP_Error Completion or resource write result, or an asset/settings error.
	 */

	private function seed_brand() {
		foreach (['logo', 'contrastLogo'] as $key) {
			if (null !== wphave_data_get('site_settings', 'brand.' . $key, null)) {
				continue;
			}
			$attachment = $this->import_brand_asset($key);
			if (is_wp_error($attachment)) {
				return $attachment;
			}
			$result = self::set_missing('site_settings', 'brand.' . $key, $attachment);
			if (is_wp_error($result)) {
				return $result;
			}
		}

		if (!get_option('site_icon')) {
			$icon = $this->import_brand_asset('icon');

			if (is_wp_error($icon)) {
				return $icon;
			}

			return self::set_option('site_icon', $icon);
		}

		return true;
	}

	/**
	 *  Import a closed set of bundled brand files without changing visitor upload policy.
	 *
	 * @param string $key Stable fixture or defaults-group key.
	 * @return int|WP_Error Attachment ID or an asset import error.
	 */

	private function import_brand_asset(string $key) {
		$files = [
			'logo' => 'wphave-logo.svg',
			'contrastLogo' => 'wphave-logo-white.svg',
			'icon' => 'wphave-icon.png',
		];
		if (!isset($files[$key])) {
			return new WP_Error('wphave_demo_brand_unknown', 'Unknown bundled brand asset.');
		}
		$filename = $files[$key];
		$source = wphave_dir() . 'assets/img/' . $filename;

		$existing = get_posts([
			'post_type' => 'attachment',
			'post_status' => 'inherit',
			'posts_per_page' => 1,
			'fields' => 'ids',
			'meta_key' => self::META_KEY,
			'meta_value' => 'brand-' . $key,
		]);

		if ($existing && is_file((string) get_attached_file($existing[0]))) {
			return (int) $existing[0];
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		// Trusted bundled SVGs are sanitized, then registered directly. This does
		// not relax the separate policy for files uploaded by demo visitors.
		if ('svg' === pathinfo($filename, PATHINFO_EXTENSION)) {
			$svg = is_file($source) ? file_get_contents($source) : false;
			$safe = $svg ? WPHAVE_Safe_SVG::sanitize_markup($svg) : false;
			if (!$safe) {
				return new WP_Error('wphave_demo_brand_svg_invalid', 'Invalid bundled SVG logo.');
			}
			$allow_bundled_svg = static function ($mimes) {
				$mimes['svg'] = 'image/svg+xml';
				return $mimes;
			};
			add_filter('upload_mimes', $allow_bundled_svg);
			try {
				$upload = wp_upload_bits($filename, null, $safe);
			} finally {
				remove_filter('upload_mimes', $allow_bundled_svg);
			}
			if (!empty($upload['error'])) {
				return new WP_Error('wphave_demo_brand_upload_failed', $upload['error']);
			}
			$id = wp_insert_attachment(
				[
					'post_mime_type' => 'image/svg+xml',
					'post_title' => 'WPHAVE Demo ' . $key,
					'post_status' => 'inherit',
				],
				$upload['file'],
				0,
				true,
			);
			if (is_wp_error($id)) {
				wp_delete_file($upload['file']);
				return $id;
			}
			wp_update_attachment_metadata(
				$id,
				wp_generate_attachment_metadata($id, $upload['file']),
			);
		} else {
			$temp = wp_tempnam($filename);

			if (!$temp || !copy($source, $temp)) {
				if ($temp) {
					wp_delete_file($temp);
				}

				return new WP_Error(
					'wphave_demo_brand_copy_failed',
					'Cannot stage a bundled demo brand asset.',
				);
			}

			$id = media_handle_sideload(
				['name' => $filename, 'tmp_name' => $temp],
				0,
				'WPHAVE Demo ' . $key,
			);

			if (is_wp_error($id)) {
				wp_delete_file($temp);
				return $id;
			}
		}

		update_post_meta($id, self::META_KEY, 'brand-' . $key);
		update_post_meta($id, '_wphave_playground_demo', 1);
		update_post_meta($id, '_wp_attachment_image_alt', 'WPHAVE');

		return $id;
	}
}
