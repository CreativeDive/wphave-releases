<?php

if (!defined('ABSPATH')) {
	exit();
}

/**
 * Localizes the exported Style Guide without rebuilding its design or block tree.
 *
 * The editor-authored content/style-guide.html file owns the block hierarchy and
 * all design attributes. This class owns only the plain-text copy, its gettext
 * context and the insertion-time WordPress site title. Named slots connect both
 * sources without parsing and reserializing the complete block document.
 *
 * The Content Seeder consumes the returned post fields through the shared fixture
 * upsert. Demo eligibility, persistence, stable fixture identity and preservation
 * of visitor edits belong to the installer and seeders, not to this renderer.
 * Calling render() does not create or update a page or change site settings.
 *
 * Localization is an insertion-time snapshot, not a frontend translation filter.
 * Later locale or site-title changes do not automatically rewrite existing pages.
 * The only temporary global state change is WordPress's active translation locale;
 * render() restores it when this class successfully switched it.
 *
 * Extension contract: add a literal contextual gettext message to copy(), use its
 * stable key as a complete quoted content slot in the exported template, and
 * update the translation catalogs. Preserve the approved design when editing the
 * template; do not move layout generation or post writes into this class.
 *
 * @see WPHAVE_Playground_Demo_Content_Seeder For fixture creation and error propagation.
 * @see WPHAVE_Playground_Demo_Seeder For upsert and visitor-ownership behavior.
 */

class WPHAVE_Playground_Demo_Style_Guide {
	/**
	 * Render localized post fields within the site's translation context.
	 *
	 * Requests the locale returned by get_locale(), so a different installing user's
	 * language does not determine fixture copy. WordPress controls whether the locale
	 * is available and whether a switch is needed. Missing gettext translations use
	 * the English source messages.
	 *
	 * Only a successful switch is restored. The finally block also runs when template
	 * rendering returns WP_Error or an exception propagates from a WordPress callback.
	 * Exceptions are not converted into template errors here.
	 *
	 * The result is post data, not an HTML response: title and excerpt are plain
	 * translated strings, while content is serialized block markup with escaped text.
	 * The caller remains responsible for the appropriate WordPress persistence API.
	 *
	 * @return array{title: string, excerpt: string, content: string}|WP_Error
	 *         Localized post fields, or a missing-template/unknown-slot error.
	 */

	public static function render() {
		return WPHAVE_Playground_Demo_Reference_Page::render(
			'style-guide',
			static fn() => self::copy(),
		);
	}

	/**
	 * Resolve the plain-text messages and site identity for one render operation.
	 *
	 * Stable array keys identify template slots; they are not translation message IDs.
	 * Literal English strings use the "Playground style guide" gettext context and
	 * the "wphave" domain so the normal extraction pipeline can discover them and
	 * translators can distinguish this copy from similarly named interface labels.
	 * Calls are evaluated on each render after the locale has been selected; no
	 * translated copy or site identity is cached across requests or locale changes.
	 *
	 * The brand message interpolates the current raw WordPress site title into a
	 * translator-controlled sentence. Escaping belongs to WPHAVE_Playground_Demo_Reference_Page::render(), after
	 * interpolation, rather than to individual messages. Keep these values as plain
	 * text; rich HTML translations are intentionally displayed as literal text.
	 *
	 * The title key serves both the page title and its visible template heading.
	 * Excerpt supplies post metadata even though it has no visible template slot.
	 * Other keys may appear more than once in the exported block document.
	 *
	 * @return array<string, string> Slot keys mapped to unescaped localized text,
	 *                              including the title and excerpt metadata entries.
	 */

	private static function copy(): array {
		return [
			// Site identity and introductory copy.
			// translators: %s: WordPress site title.
			'brand' => sprintf(
				_x('%s / DESIGN REFERENCE', 'Playground style guide', 'wphave'),
				get_bloginfo('name', 'raw'),
			),
			'title' => _x('Style Guide', 'Playground style guide', 'wphave'),
			'tagline' => _x('One design. Many possibilities.', 'Playground style guide', 'wphave'),
			'intro' => _x(
				'Colors, typography and components of our demo — editable building blocks to explore and experiment with.',
				'Playground style guide',
				'wphave',
			),
			// Palette labels and their intended visual roles.
			'colors-label' => _x('01 / Colors', 'Playground style guide', 'wphave'),
			'colors-title' => _x('Colors', 'Playground style guide', 'wphave'),
			'colors-intro' => _x(
				'These swatches use the global website colors. Changes to the design appear here automatically.',
				'Playground style guide',
				'wphave',
			),
			'accent-title' => _x('Accent', 'Playground style guide', 'wphave'),
			'accent-description' => _x(
				'Highlights and primary actions',
				'Playground style guide',
				'wphave',
			),
			'primary-title' => _x('Primary', 'Playground style guide', 'wphave'),
			'primary-description' => _x(
				'Strong contrasts and clear outlines',
				'Playground style guide',
				'wphave',
			),
			'secondary-title' => _x('Secondary', 'Playground style guide', 'wphave'),
			'secondary-description' => _x('Supporting accents', 'Playground style guide', 'wphave'),
			'background-title' => _x('Background', 'Playground style guide', 'wphave'),
			'background-description' => _x(
				'The calm foundation of every page',
				'Playground style guide',
				'wphave',
			),
			'headings-title' => _x('Headings', 'Playground style guide', 'wphave'),
			'headings-description' => _x(
				'Orientation and hierarchy',
				'Playground style guide',
				'wphave',
			),
			'body-title' => _x('Body text', 'Playground style guide', 'wphave'),
			'body-description' => _x('Easy-to-read content', 'Playground style guide', 'wphave'),
			// Typography specimens; headings-title and body-title are reused above.
			'typography-label' => _x('02 / Typography', 'Playground style guide', 'wphave'),
			'typography-title' => _x('Typography', 'Playground style guide', 'wphave'),
			'typography-intro' => _x(
				'A shared type system for strong headings, readable text and small details.',
				'Playground style guide',
				'wphave',
			),
			'large-heading' => _x('Big ideas.', 'Playground style guide', 'wphave'),
			'medium-heading' => _x('Clear words.', 'Playground style guide', 'wphave'),
			'small-heading' => _x('Fine details.', 'Playground style guide', 'wphave'),
			'lead' => _x('Design provides direction.', 'Playground style guide', 'wphave'),
			'body-example' => _x(
				'Good design combines a clear hierarchy with plenty of space. Headings set the direction, while short paragraphs make content easy to follow.',
				'Playground style guide',
				'wphave',
			),
			'caption' => _x(
				'Small text for captions and additional information.',
				'Playground style guide',
				'wphave',
			),
			// Action examples and their accompanying explanations.
			'buttons-label' => _x('03 / Buttons', 'Playground style guide', 'wphave'),
			'buttons-title' => _x('Buttons', 'Playground style guide', 'wphave'),
			'buttons-intro' => _x(
				'Primary actions draw attention. Secondary actions remain deliberately understated.',
				'Playground style guide',
				'wphave',
			),
			'primary-action' => _x('Primary action', 'Playground style guide', 'wphave'),
			'primary-action-description' => _x(
				'For the most important next step.',
				'Playground style guide',
				'wphave',
			),
			'secondary-action' => _x('Secondary action', 'Playground style guide', 'wphave'),
			'secondary-action-description' => _x(
				'For an additional option.',
				'Playground style guide',
				'wphave',
			),
			// Combined card example and guidance for exploring global design values.
			'composition-label' => _x(
				'04 / Bringing it together',
				'Playground style guide',
				'wphave',
			),
			'composition-title' => _x('Bringing it together', 'Playground style guide', 'wphave'),
			'composition-intro' => _x(
				'Global spacing and recurring elements give different content a shared rhythm.',
				'Playground style guide',
				'wphave',
			),
			'card-label' => _x('EXAMPLE / CARD', 'Playground style guide', 'wphave'),
			'card-title' => _x('Room for good ideas.', 'Playground style guide', 'wphave'),
			'card-description' => _x(
				'A calm surface, clear typography and one distinct action. This is how the building blocks work together.',
				'Playground style guide',
				'wphave',
			),
			'card-action' => _x('Explore more', 'Playground style guide', 'wphave'),
			'principle-title' => _x(
				'Fewer individual values. More consistency.',
				'Playground style guide',
				'wphave',
			),
			'principle-description' => _x(
				'Colors, type sizes and spacing follow the website settings. This keeps the design cohesive as you develop it further.',
				'Playground style guide',
				'wphave',
			),
			'try-it' => _x(
				'Try it: change a global color or font and see how the examples adapt.',
				'Playground style guide',
				'wphave',
			),
			// Page metadata, not a visible block-content slot.
			'excerpt' => _x(
				'Colors, typography and components of the demo at a glance.',
				'Playground style guide',
				'wphave',
			),
		];
	}
}
