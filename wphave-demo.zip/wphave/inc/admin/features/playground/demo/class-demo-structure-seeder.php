<?php

if (!defined('ABSPATH')) {
	exit();
}

/**
 * Seeds navigation, reusable design resources and settings for the demo workspace.
 */

class WPHAVE_Playground_Demo_Structure_Seeder extends WPHAVE_Playground_Demo_Seeder {
	/**
	 * Seed navigation and reusable design resources, then apply one-time structural defaults.
	 *
	 * @param array $state Shared installer state containing fixture IDs and completion summaries.
	 * @return array|WP_Error Updated installer state or a domain setup error.
	 */

	public function seed(array $state) {
		$block_visibility = $this->seed_block_visibility();

		if (is_wp_error($block_visibility)) {
			return $block_visibility;
		}

		$navigations = $this->seed_navigations($state['pages'] ?? []);

		if (is_wp_error($navigations)) {
			return $navigations;
		}

		$state['navigations'] = $navigations;

		$css_classes = $this->seed_css_classes();

		if (is_wp_error($css_classes)) {
			return $css_classes;
		}

		$state['cssClasses'] = $css_classes;

		$block_styles = $this->seed_block_styles();

		if (is_wp_error($block_styles)) {
			return $block_styles;
		}

		// Retire only the third fixture owned by older demos, never visitor-created styles.
		$legacy_styles = get_posts([
			'post_type' => WPHAVE_Block_Styles::POST_TYPE,
			'post_status' => 'any',
			'posts_per_page' => -1,
			'fields' => 'ids',
			'meta_key' => self::META_KEY,
			'meta_value' => 'block-style-demo-section',
		]);

		$state['blockStyles'] = $block_styles;

		$cleanup = $this->remove_legacy_block_style_assignments(
			$state['pages'] ?? [],
			array_merge($block_styles, $legacy_styles),
		);

		if (is_wp_error($cleanup)) {
			return $cleanup;
		}

		if ($legacy_styles && defined('EMPTY_TRASH_DAYS') && !EMPTY_TRASH_DAYS) {
			return new WP_Error(
				'wphave_demo_style_trash_disabled',
				'Cannot retire the legacy demo block style without a recoverable trash.',
			);
		}

		foreach ($legacy_styles as $legacy_style_id) {
			if (!wp_trash_post($legacy_style_id)) {
				return new WP_Error(
					'wphave_demo_style_retirement_failed',
					'Cannot retire the legacy demo block style.',
				);
			}
		}

		$templates = $this->seed_templates();

		if (is_wp_error($templates)) {
			return $templates;
		}

		$state['templates'] = $templates;

		$add_ons = $this->seed_add_ons();

		if (is_wp_error($add_ons)) {
			return $add_ons;
		}

		$state['addOns'] = $add_ons;

		$settings = WPHAVE_Playground_Demo_Settings_Seeder::once('structure', function () {
			return $this->seed_settings();
		});

		if (is_wp_error($settings)) {
			return $settings;
		}

		$state['customCode'] = ['locations' => 2, 'enabled' => 0];

		delete_transient('post_type_features_data');

		return $state;
	}

	/** Seed the singleton add-on without replacing visitor content or status. */

	private function seed_add_ons() {
		$existing = get_posts([
			'post_type' => WPHAVE_Add_On_Manager::POST_TYPE,
			'post_status' => ['publish', 'future', 'draft', 'pending', 'private', 'trash'],
			'posts_per_page' => 1,
			'fields' => 'ids',
			'meta_key' => 'wphave_add_on_id',
			'meta_value' => 'scroll-to-top',
			'no_found_rows' => true,
		]);

		if ($existing) {
			return ['scroll-to-top' => (int) $existing[0]];
		}

		$post_id = $this->upsert_post(
			'add-on-scroll-to-top',
			[
				'post_type' => WPHAVE_Add_On_Manager::POST_TYPE,
				'post_status' => 'publish',
				'post_title' => 'Scroll to Top',
				'post_content' => '<!-- wp:wphave/scroll-to-top /-->',
				'meta_input' => ['wphave_add_on_id' => 'scroll-to-top'],
			],
			true,
		);

		return is_wp_error($post_id) ? $post_id : ['scroll-to-top' => (int) $post_id];
	}

	/**
	 * Apply structural site defaults through canonical resource APIs.
	 *
	 * @return true|WP_Error Completed defaults or a resource write error.
	 */

	private function seed_settings() {
		$seo = WPHAVE_Playground_Demo_Settings_Seeder::set_missing(
			'site_settings',
			'seo.isEnabled',
			true,
		);

		if (is_wp_error($seo)) {
			return $seo;
		}

		$analytics = WPHAVE_Playground_Demo_Settings_Seeder::set_missing(
			'site_settings',
			'advanced.analytics.enabled',
			true,
		);

		if (is_wp_error($analytics)) {
			return $analytics;
		}

		$social_profiles = WPHAVE_Playground_Demo_Settings_Seeder::set_missing(
			'site_settings',
			'social.profiles',
			$this->social_profiles(),
		);

		if (is_wp_error($social_profiles)) {
			return $social_profiles;
		}

		$schema = WPHAVE_Playground_Demo_Settings_Seeder::set_missing('site_settings', 'schema', [
			'isEnabled' => true,
			'breadcrumbs' => ['isEnabled' => true],
			'articles' => ['isEnabled' => true, 'type' => 'Article'],
			'faq' => ['isEnabled' => true],
			'identity' => [
				'type' => 'Organization',
				'name' => 'WPHAVE Demo',
				'description' => 'Synthetische Beispielwebsite der WPHAVE Live-Demo.',
				'email' => 'demo@example.invalid',
				'telephone' => '+49 000 000000',
				'address' => [
					'street' => 'Beispielweg 1',
					'postalCode' => '00000',
					'locality' => 'Demostadt',
					'country' => 'DE',
				],
			],
		]);

		if (is_wp_error($schema)) {
			return $schema;
		}

		$custom_code = WPHAVE_Playground_Demo_Settings_Seeder::set_missing(
			'site_settings',
			'advanced.code',
			[
				// EXECUTION INVARIANT: Demo snippets remain persisted examples only; setup
				// must never enable imported HTML or JavaScript in a public rendering context.
				'header' =>
					"<!-- WPHAVE Demo: deaktivierte Metadaten -->\n<meta name=\"theme-color\" content=\"#3157d5\">",
				'headerEnabled' => false,
				'bodyOpen' => '',
				'bodyOpenEnabled' => false,
				'footer' =>
					"<!-- WPHAVE Demo: deaktiviertes JavaScript -->\n<script>document.documentElement.dataset.demoReady = 'true';</script>",
				'footerEnabled' => false,
			],
		);

		if (is_wp_error($custom_code)) {
			return $custom_code;
		}

		return true;
	}

	/**
	 * Apply the curated inserter defaults once, independently of fixture versions.
	 *
	 * OWNERSHIP INVARIANT: After initialization, Block Types belongs to the demo
	 * visitor. Repairs and upgrades must not restore entries the visitor removed.
	 * Explicit existing choices win even when retrying an interrupted setup.
	 * Structural child blocks remain governed by the shared visibility policy.
	 *
	 * @return true|WP_Error Completed visibility settings or a validation/persistence error.
	 */

	private function seed_block_visibility() {
		$marker = 'wphave_playground_demo_block_visibility_seeded';

		if (get_option($marker)) {
			return true;
		}

		$disabled_blocks = [
			'core/paragraph',
			'core/heading',
			'core/list',
			'core/image',
			'core/buttons',
			'core/group',
			'core/columns',
			'core/cover',
			'core/media-text',
			'core/spacer',
			'core/separator',
			'core/icon',
			'core/accordion',
			'core/details',
			'core/tabs',
			'core/code',
			'core/html',
			'core/social-links',
			'core/navigation',
			'core/breadcrumbs',
			'core/site-logo',
			'core/search',
			'core/query',
			'core/latest-posts',
			'core/post-title',
			'core/post-content',
			'core/post-excerpt',
			'core/post-featured-image',
			'core/post-date',
			'core/post-author',
			'core/post-author-name',
			'core/avatar',
			'core/post-terms',
			'core/post-time-to-read',
			'core/read-more',
			'core/comments',
			'core/post-comments-count',
			'core/template-part',
			'core/gallery',
			'core/quote',
			'core/pullquote',
			'core/verse',
			'core/preformatted',
		];

		$existing = wphave_data_get('site_settings', 'editor.blocks.core', []);

		if (!is_array($existing)) {
			return new WP_Error(
				'wphave_demo_invalid_block_visibility',
				'Cannot initialize demo block visibility: expected a block settings map.',
			);
		}

		$result = wphave_data_set(
			'site_settings',
			'editor.blocks.core',
			array_replace(array_fill_keys($disabled_blocks, false), $existing),
		);

		if (is_wp_error($result)) {
			return $result;
		}

		if (!update_option($marker, true, false) && !get_option($marker)) {
			return new WP_Error(
				'wphave_demo_block_visibility_marker_failed',
				'Cannot persist the demo block visibility initialization marker.',
			);
		}

		return true;
	}

	/**
	 * Return complete, fictional profiles for every social-profile consumer.
	 *
	 * The reserved example domains keep the demo non-attributable while icons
	 * make the fixtures immediately usable by the Social block and Social Bar.
	 *
	 * @return array Demo social profile definitions.
	 */

	private function social_profiles(): array {
		$icons = [
			'linkedin' =>
				'<svg viewBox="0 0 24 24"><path fill="currentColor" d="M5.4 3.5A1.9 1.9 0 1 1 5.4 7.3a1.9 1.9 0 0 1 0-3.8ZM3.8 9h3.3v11H3.8V9Zm5.3 0h3.2v1.5h.1c.5-.9 1.6-1.9 3.3-1.9 3.5 0 4.2 2.3 4.2 5.3V20h-3.4v-5.4c0-1.3 0-3-1.8-3s-2.1 1.4-2.1 2.9V20H9.1V9Z"/></svg>',
			'instagram' =>
				'<svg viewBox="0 0 24 24"><path fill="currentColor" d="M7.5 2h9A5.5 5.5 0 0 1 22 7.5v9a5.5 5.5 0 0 1-5.5 5.5h-9A5.5 5.5 0 0 1 2 16.5v-9A5.5 5.5 0 0 1 7.5 2Zm0 2A3.5 3.5 0 0 0 4 7.5v9A3.5 3.5 0 0 0 7.5 20h9a3.5 3.5 0 0 0 3.5-3.5v-9A3.5 3.5 0 0 0 16.5 4h-9Zm9.8 1.5a1.2 1.2 0 1 1 0 2.4 1.2 1.2 0 0 1 0-2.4ZM12 7a5 5 0 1 1 0 10 5 5 0 0 1 0-10Zm0 2a3 3 0 1 0 0 6 3 3 0 0 0 0-6Z"/></svg>',
			'youtube' =>
				'<svg viewBox="0 0 24 24"><path fill="currentColor" d="M21.6 7.2a3 3 0 0 0-2.1-2.1C17.6 4.6 12 4.6 12 4.6s-5.6 0-7.5.5a3 3 0 0 0-2.1 2.1A31 31 0 0 0 2 12a31 31 0 0 0 .4 4.8 3 3 0 0 0 2.1 2.1c1.9.5 7.5.5 7.5.5s5.6 0 7.5-.5a3 3 0 0 0 2.1-2.1A31 31 0 0 0 22 12a31 31 0 0 0-.4-4.8ZM10 15.4V8.6l6 3.4-6 3.4Z"/></svg>',
		];

		return [
			[
				'id' => 'wphave-demo-linkedin',
				'label' => 'LinkedIn',
				'url' => 'https://linkedin.example/wphave-demo',
				'icon' => [
					'key' => 'linkedin',
					'svg' => $icons['linkedin'],
				],
			],
			[
				'id' => 'wphave-demo-instagram',
				'label' => 'Instagram',
				'url' => 'https://instagram.example/wphave-demo',
				'icon' => [
					'key' => 'instagram',
					'svg' => $icons['instagram'],
				],
			],
			[
				'id' => 'wphave-demo-youtube',
				'label' => 'YouTube',
				'url' => 'https://youtube.example/wphave-demo',
				'icon' => [
					'key' => 'youtube',
					'svg' => $icons['youtube'],
				],
			],
		];
	}

	/**
	 * Create or update reusable navigation documents from available demo pages.
	 *
	 * @param array $pages Demo page IDs keyed by fixture identity.
	 * @return array|WP_Error Navigation IDs keyed by fixture identity, or a post error.
	 */

	private function seed_navigations(array $pages) {
		$items = [
			'primary' => [
				'title' => 'Hauptnavigation',
				'links' => [
					'home' => 'Startseite',
					'services' => 'Leistungen',
					'projects' => 'Beispiele',
					'about' => 'Über uns',
					'contact' => 'Kontakt',
				],
			],
			'footer' => [
				'title' => 'Footer-Navigation',
				'links' => [
					'contact' => 'Kontakt',
					'imprint' => 'Impressum',
					'privacy' => 'Datenschutz',
					'style-guide' => 'Style Guide',
				],
			],
		];

		if (
			wphave_release_feature_ready('playgroundBlockStyling') &&
			!empty($pages['block-styling'])
		) {
			$items['footer']['links']['block-styling'] = 'Block Styling';
		}

		$result = [];
		foreach ($items as $key => $item) {
			$content = '';
			foreach ($item['links'] as $page_key => $label) {
				$url = isset($pages[$page_key]) ? get_permalink($pages[$page_key]) : '#';
				$link = [
					'type' => 'external',
					'external' => ['url' => esc_url($url)],
				];
				$attributes = [
					'link' => $link,
					'content' => $label,
				];
				$content .=
					'<!-- wp:wphave/navigation-link ' .
					wp_json_encode($attributes) .
					' /-->' .
					"\n\n";
			}

			$post_id = $this->upsert_post('navigation-' . $key, [
				'post_type' => WPHAVE_Navigation_Manager::POST_TYPE,
				'post_status' => 'publish',
				'post_title' => $item['title'],
				'post_content' => trim($content),
			]);

			if (is_wp_error($post_id)) {
				return $post_id;
			}

			$result[$key] = $post_id;
		}

		return $result;
	}

	/**
	 * Create or update the reusable CSS class fixtures.
	 *
	 * @return array|WP_Error CSS class post IDs keyed by fixture identity, or a post error.
	 */

	private function seed_css_classes() {
		$items = [
			'demo-card' =>
				'$class {' .
				"\n  border: 1px solid rgba(15, 23, 42, 0.12);\n  border-radius: 16px;\n  box-shadow: 0 12px 30px rgba(15, 23, 42, 0.08);\n}",
			'demo-highlight' =>
				'$class {' .
				"\n  background: #fff7d6;\n  border-left: 4px solid #f2b705;\n  padding: 1rem;\n}",
			'demo-muted' => '$class {' . "\n  color: #64748b;\n  opacity: 0.85;\n}",
		];

		$result = [];
		foreach ($items as $suffix => $css) {
			$post_id = $this->upsert_post('css-class-' . $suffix, [
				'post_type' => WPHAVE_CSS_Class_Manager::POST_TYPE,
				'post_status' => 'publish',
				'post_title' => $suffix,
				'post_content' => $css,
			]);

			if (is_wp_error($post_id)) {
				return $post_id;
			}

			$result[$suffix] = $post_id;
		}

		return $result;
	}

	/**
	 * Create or update the reusable block style fixtures.
	 *
	 * @return array|WP_Error Block style IDs keyed by fixture identity, or a post error.
	 */

	private function seed_block_styles() {
		$items = [
			'demo-card' => ['New Block Style', 'block-style-grass.html'],
			'demo-highlight' => ['my cool block style', 'block-style-dashed.html'],
		];

		$result = [];
		foreach ($items as $key => $item) {
			$content = file_get_contents(__DIR__ . '/content/' . $item[1]);
			if (false === $content || '' === trim($content)) {
				return new WP_Error(
					'wphave_demo_style_missing',
					'The demo block style source is unavailable.',
				);
			}

			$post_id = $this->upsert_post('block-style-' . $key, [
				'post_type' => WPHAVE_Block_Styles::POST_TYPE,
				'post_status' => 'publish',
				'post_title' => $item[0],
				'post_content' => trim($content),
			]);

			if (is_wp_error($post_id)) {
				return $post_id;
			}

			$result[$key] = $post_id;
		}

		return $result;
	}

	/**
	 * Remove assignments created by Playground demo versions before 4.2.0.
	 *
	 * The old seeder attached a demo style to the first compatible block on
	 * selected pages. Composition content must stay authoritative, so cleanup is
	 * limited to the known demo style IDs and preserves every other assignment.
	 *
	 * @param array $pages Demo page IDs keyed by fixture identity.
	 * @param array $block_styles Legacy demo block-style IDs keyed by fixture identity.
	 * @return true|WP_Error Completed cleanup or a page update error.
	 */

	private function remove_legacy_block_style_assignments(array $pages, array $block_styles) {
		$demo_style_ids = array_values(array_filter(array_map('intval', $block_styles)));

		if (empty($demo_style_ids)) {
			return true;
		}

		foreach ($pages as $page_id) {
			$page_id = (int) $page_id;
			$post = $page_id ? get_post($page_id) : null;

			if (!$post) {
				continue;
			}

			$changed = false;
			$blocks = $this->remove_block_style_ids(
				parse_blocks($post->post_content),
				$demo_style_ids,
				$changed,
			);

			if (!$changed) {
				continue;
			}

			$updated = wp_update_post(
				wp_slash([
					'ID' => $page_id,
					'post_content' => serialize_blocks($blocks),
				]),
				true,
			);

			if (is_wp_error($updated)) {
				return $updated;
			}
		}

		return true;
	}

	/**
	 * Recursively remove only the supplied legacy block-style IDs from parsed blocks.
	 *
	 * @param array $blocks Parsed WordPress block tree.
	 * @param array $style_ids Legacy style IDs that this cleanup is allowed to remove.
	 * @param bool $changed Output flag set to true when any assignment is removed; existing true values are preserved.
	 * @return array Updated block tree; unrelated settings and style assignments remain intact.
	 */

	private function remove_block_style_ids(
		array $blocks,
		array $style_ids,
		bool &$changed,
	): array {
		foreach ($blocks as $index => $block) {
			$style_id = (int) ($block['attrs']['wphave']['useBlockStyle'] ?? 0);
			if ($style_id && in_array($style_id, $style_ids, true)) {
				unset($blocks[$index]['attrs']['wphave']['useBlockStyle']);
				$changed = true;
			}

			if (!empty($block['innerBlocks'])) {
				$blocks[$index]['innerBlocks'] = $this->remove_block_style_ids(
					$block['innerBlocks'],
					$style_ids,
					$changed,
				);
			}
		}

		return $blocks;
	}

	/**
	 * Create or update reusable template fixtures for the demo site.
	 *
	 * @return array|WP_Error Template IDs keyed by fixture identity, or a post error.
	 */

	private function seed_templates() {
		$items = [
			'page' => ['Standardseite', 'post_type_page'],
			'project' => ['Beispiel', 'post_type_project'],
			'project-archive' => ['Beispielarchiv', 'archive'],
		];

		$result = [];
		$content = '<!-- wp:wphave/content /-->';
		foreach ($items as $key => $item) {
			$post_id = $this->upsert_post('template-' . $key, [
				'post_type' => WPHAVE_Templates::POST_TYPE,
				'post_status' => 'publish',
				'post_title' => $item[0],
				'post_content' => $content,
				'meta_input' => [
					WPHAVE_Templates::META_TEMPLATE_ID => $item[1],
					WPHAVE_Templates::META_CUSTOM_TEMPLATE => 1,
				],
			]);

			if (is_wp_error($post_id)) {
				return $post_id;
			}

			$result[$key] = $post_id;
		}

		return $result;
	}
}
