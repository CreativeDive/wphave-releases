<?php

if (!defined('ABSPATH')) {
	exit();
}

/**
 * Keep demo-owned navigation in the document connected to the Playground runtime.
 */
class WPHAVE_Playground_Demo_Navigation {
	public static function init(): void {
		if (!WPHAVE_Playground_Demo_Installer::is_enabled()) {
			return;
		}

		add_action('admin_head', [__CLASS__, 'render'], 0);
		add_action('wp_head', [__CLASS__, 'render'], 0);
	}

	/**
	 * Install before application scripts; no production bundle or per-link policy is needed.
	 */
	public static function render(): void {
		wp_print_inline_script_tag(file_get_contents(__DIR__ . '/navigation.js'), [
			'id' => 'wphave-playground-demo-navigation',
		]);
	}
}
