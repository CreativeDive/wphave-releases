<?php

if (!defined('ABSPATH')) {
	exit();
}

/**
 * Installs the Playground website through the production Site Composition flow.
 */

class WPHAVE_Playground_Demo_Composition_Seeder extends WPHAVE_Playground_Demo_Seeder {
	/**
	 * Bundled Composition used as the initial demo website.
	 *
	 * @var string
	 */

	private const COMPOSITION_ID = 'signal-studio';

	/**
	 * Apply or reuse Signal Studio and record its pages, template parts, media and folders.
	 *
	 * @param array $state Shared installer state containing fixture IDs and completion summaries.
	 * @return array|WP_Error Updated installer state or a domain setup error.
	 */

	public function seed(array $state) {
		if (
			($state['composition'] ?? '') === self::COMPOSITION_ID &&
			$this->has_materialized_state($state)
		) {
			$media_folders = $this->seed_media_folders($state['media'] ?? []);

			if (is_wp_error($media_folders)) {
				return $media_folders;
			}

			$state['mediaFolders'] = $media_folders;

			return $state;
		}

		$composition = WPHAVE_Site_Composition_Service::find(self::COMPOSITION_ID);

		if (!is_array($composition)) {
			return new WP_Error(
				'wphave_demo_composition_missing',
				__('The Signal Studio demo composition is unavailable.', 'wphave'),
			);
		}

		$first_install =
			!get_option('wphave_playground_demo_composition_initialized') &&
			empty($state['composition']);

		if (!$first_install) {
			// Repair content without reassigning the visitor's homepage.
			unset($composition['site']['frontPage']);
		}

		$result = WPHAVE_Site_Composition_Applier::apply($composition, [
			'content' => true,
			'header' => true,
			'footer' => true,
			'globalStyles' => $first_install,
			'fonts' => false,
			'siteIdentity' => $first_install,
			'designSettings' => $first_install,
			'seoSchema' => $first_install,
			'generalSettings' => $first_install,
		]);

		if (is_wp_error($result)) {
			return $result;
		}

		if (
			!update_option('wphave_playground_demo_composition_initialized', true, false) &&
			!get_option('wphave_playground_demo_composition_initialized')
		) {
			return new WP_Error(
				'wphave_demo_composition_marker_failed',
				'Cannot persist demo composition initialization.',
			);
		}

		$state['composition'] = self::COMPOSITION_ID;

		$state['pages'] = [];
		foreach ((array) ($result['pages'] ?? []) as $page) {
			$key = preg_replace('/^page-/', '', sanitize_key((string) ($page['key'] ?? '')));
			$post_id = absint($page['id'] ?? 0);

			if (!$key || !$post_id) {
				continue;
			}

			wp_update_post(['ID' => $post_id, 'post_status' => 'publish']);
			update_post_meta($post_id, '_wphave_playground_demo', 1);

			$state['pages'][$key] = $post_id;
		}

		$state['templateParts'] = array_map('absint', (array) ($result['templateParts'] ?? []));

		$state['media'] = [];
		foreach ((array) ($result['assets'] ?? []) as $asset) {
			$key = sanitize_key((string) ($asset['key'] ?? ''));
			$attachment_id = absint($asset['id'] ?? 0);
			if (!$key || !$attachment_id) {
				continue;
			}
			update_post_meta($attachment_id, '_wphave_playground_demo', 1);
			$state['media'][$key] = $attachment_id;
		}

		$media_folders = $this->seed_media_folders($state['media']);

		if (is_wp_error($media_folders)) {
			return $media_folders;
		}

		$state['mediaFolders'] = $media_folders;

		if (empty($state['pages']['home'])) {
			return new WP_Error(
				'wphave_demo_composition_home_missing',
				__('The Signal Studio composition did not create its homepage.', 'wphave'),
			);
		}

		return $state;
	}

	/**
	 * Create the demo's canonical Media Folder structure and assignments.
	 *
	 * Folder slugs and composition asset keys are stable across repeated imports,
	 * while the generated term and attachment IDs remain installation-specific.
	 *
	 * @param array $media Attachment IDs keyed by demo asset identity.
	 * @return array|WP_Error Folder IDs keyed by fixture identity, or a taxonomy/assignment error.
	 */

	private function seed_media_folders(array $media) {
		if (!class_exists('WPHAVE_Media_Folders')) {
			return new WP_Error(
				'wphave_demo_media_folders_unavailable',
				__('The Media Folder service is unavailable for WPHAVE demo data.', 'wphave'),
			);
		}

		if (!taxonomy_exists(WPHAVE_Media_Folders::TAXONOMY)) {
			WPHAVE_Media_Folders::register_taxonomy();
		}

		$fixtures = [
			'logos' => [
				'name' => 'Logos',
				'assets' => [],
			],
			'backgrounds' => [
				'name' => 'Hintergründe',
				'assets' => ['attachment-158'],
			],
			'people' => [
				'name' => 'Personen',
				'assets' => ['attachment-110', 'attachment-111', 'attachment-159'],
			],
		];

		$result = [];
		foreach ($fixtures as $order => $fixture) {
			$slug = 'wphave-demo-' . $order;
			$term = term_exists($slug, WPHAVE_Media_Folders::TAXONOMY);

			if (!$term) {
				$term = wp_insert_term($fixture['name'], WPHAVE_Media_Folders::TAXONOMY, [
					'slug' => $slug,
				]);
			}

			if (is_wp_error($term)) {
				return $term;
			}

			$term_id = (int) (is_array($term) ? $term['term_id'] : $term);
			update_term_meta($term_id, 'wphave_order', count($result));
			update_term_meta($term_id, '_wphave_playground_demo', 1);
			$result[$order] = $term_id;

			foreach ($fixture['assets'] as $asset_key) {
				$attachment_id = (int) ($media[$asset_key] ?? 0);

				if (!$attachment_id || 'attachment' !== get_post_type($attachment_id)) {
					continue;
				}

				$assigned = wp_set_object_terms(
					$attachment_id,
					[$term_id],
					WPHAVE_Media_Folders::TAXONOMY,
					false,
				);

				if (is_wp_error($assigned)) {
					return $assigned;
				}
			}
		}

		return $result;
	}

	/**
	 * Check the saved homepage and imported attachment inventory before reusing Composition state.
	 *
	 * @param array $state Shared installer state containing fixture IDs and completion summaries.
	 * @return bool Whether the saved homepage and nonempty attachment inventory still exist.
	 */

	private function has_materialized_state(array $state): bool {
		if (empty($state['pages']['home']) || !get_post_status((int) $state['pages']['home'])) {
			return false;
		}

		foreach ((array) ($state['media'] ?? []) as $attachment_id) {
			if (get_post_type((int) $attachment_id) !== 'attachment') {
				return false;
			}
		}

		return !empty($state['media']);
	}
}
