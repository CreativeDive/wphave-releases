<?php

if (!defined('ABSPATH')) {
	exit();
}

require_once wphave_dir() . 'inc/features/security/boundaries/index.php';

/**
 * Coordinates the opt-in Playground lifecycle, schema readiness and versioned demo installation.
 */

class WPHAVE_Playground_Demo_Installer {
	/**
	 * Version of the synthetic fixture inventory and completion contract.
	 *
	 * @var string
	 */

	const VERSION = '4.8.3';

	/**
	 * WordPress option recording the completed fixture version.
	 *
	 * @var string
	 */

	const VERSION_OPTION = 'wphave_playground_demo_version';

	/**
	 * WordPress option storing the fixture IDs and data-window summaries.
	 *
	 * @var string
	 */

	const STATE_OPTION = 'wphave_playground_demo_state';

	/**
	 * Register the isolated Playground demo lifecycle.
	 *
	 * @return void
	 */

	public static function init(): void {
		if (!self::is_enabled()) {
			return;
		}

		// Core can snapshot wp-date settings while registering blocks at init:10.
		// Seed before theme setup as well, so the first workspace request sees
		// the same formats/timezone as subsequent Core editor requests.
		add_action(
			'setup_theme',
			[WPHAVE_Playground_Demo_Settings_Seeder::class, 'seed_environment'],
			0,
		);

		// Theme PHP and editor-style hooks must belong to the activated theme
		// in the very first app request, not only after a browser reload.
		add_action('setup_theme', [__CLASS__, 'prepare_theme'], 1);
		add_action('init', [__CLASS__, 'install'], 60);
		add_action('admin_notices', [__CLASS__, 'render_demo_notice']);
		add_filter('pre_wp_mail', '__return_false', PHP_INT_MAX);
		add_filter('image_editor_output_format', [__CLASS__, 'image_output_formats']);
		// Playground remembers isolation per session: opening Core's isolated editor
		// makes later empty.html canvas documents isolated even in our non-isolated
		// workspace. Keep all demo editors on server-side media processing so their
		// documents remain compatible. Normal WordPress installations are unaffected.
		add_filter('wp_client_side_media_processing_enabled', '__return_false', PHP_INT_MAX);
	}

	/**
	 * Playground's AVIF encoder can report successful saves with empty output.
	 * Use WordPress's supported output mapping for generated images; uploaded
	 * originals remain available through WordPress's original-image lifecycle.
	 * This policy is registered only for the explicitly enabled Playground demo.
	 *
	 * @param array $formats Current source-to-output MIME mapping from WordPress.
	 * @return array MIME-to-MIME output mapping, preserving explicit alternative formats.
	 */

	public static function image_output_formats(array $formats): array {
		if (!isset($formats['image/avif']) || 'image/avif' === $formats['image/avif']) {
			$formats['image/avif'] = 'image/webp';
		}

		return $formats;
	}

	/**
	 * Activate the bundled theme through the same explicit setup service used by the app.
	 *
	 * The Blueprint flag is the explicit user intent for this disposable environment.
	 *
	 * @return void
	 */

	public static function prepare_theme(): void {
		if (!class_exists('WPHAVE_Theme_Setup') || WPHAVE_Theme_Setup::is_active()) {
			return;
		}

		$result = WPHAVE_Theme_Setup::setup_default_theme();

		if (is_wp_error($result)) {
			update_option(
				'wphave_playground_demo_error',
				[
					'code' => $result->get_error_code(),
					'message' => WPHAVE_Security_Redactor::error_text($result->get_error_message()),
				],
				false,
			);
		}
	}

	/**
	 * Require both explicit demo intent and a recognized Playground runtime.
	 *
	 * The WordPress site runs against playground.internal even when the outer
	 * browser URL uses playground.wordpress.net. Checking only the visible host
	 * prevents the installer from ever registering in current Playground builds.
	 *
	 * @return bool Whether demo initialization is permitted.
	 */

	public static function is_enabled(): bool {
		if (!defined('WPHAVE_PLAYGROUND_DEMO') || true !== WPHAVE_PLAYGROUND_DEMO) {
			return false;
		}

		if (defined('IS_WP_PLAYGROUND') && true === IS_WP_PLAYGROUND) {
			return true;
		}

		return in_array(
			wp_parse_url(home_url(), PHP_URL_HOST),
			['playground.internal', 'playground.wordpress.net'],
			true,
		);
	}

	/**
	 * Remove WordPress starter pages only before the first demo fixtures exist.
	 *
	 * This belongs to the versioned PHP installer, not duplicated Blueprint code.
	 * Existing/legacy sessions are never cleaned on upgrades or repairs. A separate
	 * marker also protects visitor pages when later fixture installation fails.
	 * Failed deletions stop setup and may be retried before any fixtures are seeded.
	 *
	 * @return true|WP_Error Whether fresh-demo cleanup completed or was unnecessary.
	 */

	private static function remove_default_pages() {
		if (
			!self::is_enabled() ||
			get_option('wphave_playground_demo_defaults_cleaned') ||
			get_option(self::STATE_OPTION) ||
			get_option(self::VERSION_OPTION) ||
			get_option('wphave_playground_demo_composition_initialized')
		) {
			return true;
		}

		$pages = get_posts([
			'post_type' => 'page',
			'post_status' => ['publish', 'draft'],
			'post_name__in' => [
				'sample-page',
				'privacy-policy',
				'beispiel-seite',
				'datenschutzerklaerung',
			],
			'numberposts' => -1,
		]);

		foreach ($pages as $page) {
			if (!wp_delete_post($page->ID, true)) {
				return new WP_Error(
					'playground_default_page_cleanup_failed',
					'Cannot remove a default Playground page.',
				);
			}
			if ((int) get_option('wp_page_for_privacy_policy') === (int) $page->ID) {
				update_option('wp_page_for_privacy_policy', 0);
			}
		}

		if (!update_option('wphave_playground_demo_defaults_cleaned', true, false)) {
			return new WP_Error(
				'playground_default_page_cleanup_marker_failed',
				'Cannot record Playground default-page cleanup.',
			);
		}

		return true;
	}

	/**
	 * Install or upgrade the complete synthetic fixture set once per version.
	 *
	 * @return void
	 */

	public static function install(): void {
		self::register_runtime_taxonomies();

		if (get_option(self::VERSION_OPTION) === self::VERSION && self::is_complete()) {
			self::refresh_insights();
			return;
		}

		if (!post_type_exists('page') || !post_type_exists(WPHAVE_Form_Manager::POST_TYPE)) {
			return;
		}

		$schema_result = self::prepare_database_schema();

		if (is_wp_error($schema_result)) {
			update_option(
				'wphave_playground_demo_error',
				[
					'code' => $schema_result->get_error_code(),
					'message' => WPHAVE_Security_Redactor::error_text(
						$schema_result->get_error_message(),
					),
				],
				false,
			);
			return;
		}

		$cleanup = self::remove_default_pages();

		if (is_wp_error($cleanup)) {
			self::record_error($cleanup);
			return;
		}

		$state = get_option(self::STATE_OPTION);

		if (!is_array($state)) {
			$state = ['synthetic' => true];
		}

		$state['version'] = self::VERSION;

		if (empty($state['activatedAt'])) {
			$state['activatedAt'] = current_datetime()
				->setTimezone(new DateTimeZone('UTC'))
				->format('Y-m-d\TH:i:s\Z');
		}

		// URL INVARIANT: Content and navigation fixtures must resolve against the
		// same human-readable permalink contract visitors experience afterwards.
		$environment = WPHAVE_Playground_Demo_Settings_Seeder::seed_environment();

		if (is_wp_error($environment)) {
			self::record_error($environment);
			return;
		}

		$seeders = [
			new WPHAVE_Playground_Demo_Composition_Seeder(),
			new WPHAVE_Playground_Demo_Settings_Seeder(),
			new WPHAVE_Playground_Demo_Content_Seeder(),
			new WPHAVE_Playground_Demo_Structure_Seeder(),
			new WPHAVE_Playground_Demo_Insights_Seeder(),
			new WPHAVE_Playground_Demo_Operations_Seeder(),
		];

		foreach ($seeders as $seeder) {
			$state = $seeder->seed($state);

			if (is_wp_error($state)) {
				update_option(
					'wphave_playground_demo_error',
					[
						'code' => $state->get_error_code(),
						'message' => WPHAVE_Security_Redactor::error_text(
							$state->get_error_message(),
						),
					],
					false,
				);
				return;
			}

			update_option(self::STATE_OPTION, $state, false);
		}

		self::seed_client_role();
		$users = self::seed_demo_users($state['activatedAt']);

		if (is_wp_error($users)) {
			update_option(
				'wphave_playground_demo_error',
				[
					'code' => $users->get_error_code(),
					'message' => WPHAVE_Security_Redactor::error_text($users->get_error_message()),
				],
				false,
			);
			return;
		}

		$state['users'] = $users;

		update_option(self::STATE_OPTION, $state, false);
		update_option(self::VERSION_OPTION, self::VERSION, false);
		delete_option('wphave_playground_demo_error');
		flush_rewrite_rules(false);
	}

	/**
	 *  Refresh only dated synthetic records; settings and content belong to visitors.
	 *
	 * @return void
	 */

	private static function refresh_insights(): void {
		$state = get_option(self::STATE_OPTION);
		$today = current_datetime()->format('Y-m-d');

		if (
			($state['analytics']['to'] ?? '') === $today &&
			($state['audience']['to'] ?? '') === $today
		) {
			return;
		}

		$result = self::prepare_database_schema();

		if (!is_wp_error($result)) {
			$result = (new WPHAVE_Playground_Demo_Insights_Seeder())->seed($state);
		}

		if (is_wp_error($result)) {
			self::record_error($result);
			return;
		}

		if (
			!update_option(self::STATE_OPTION, $result, false) &&
			get_option(self::STATE_OPTION) !== $result
		) {
			self::record_error(
				new WP_Error(
					'wphave_demo_refresh_state_failed',
					'Cannot persist the refreshed demo state.',
				),
			);
			return;
		}

		delete_option('wphave_playground_demo_error');
	}

	/**
	 * Persist a redacted setup failure for the demo admin notice.
	 *
	 * @param WP_Error $error Setup error to redact and persist.
	 * @return void
	 */

	private static function record_error(WP_Error $error): void {
		update_option(
			'wphave_playground_demo_error',
			[
				'code' => $error->get_error_code(),
				'message' => WPHAVE_Security_Redactor::error_text($error->get_error_message()),
			],
			false,
		);
	}

	/**
	 * Register taxonomy dependencies before validating persisted fixture terms.
	 *
	 * LIFECYCLE INVARIANT: The fast-path completeness check must run against the
	 * same registered object model as the seeders. Feature bootstrap can be
	 * deferred or reordered in constrained runtimes such as Playground; treating
	 * an unregistered taxonomy as missing data would turn every request into a
	 * complete, synchronous demo rebuild and can exhaust the request deadline.
	 *
	 * Registration is idempotent in WordPress and remains isolated to the
	 * explicitly enabled disposable demo lifecycle.
	 *
	 * @return void
	 */

	private static function register_runtime_taxonomies(): void {
		if (
			class_exists('WPHAVE_Media_Folders') &&
			!taxonomy_exists(WPHAVE_Media_Folders::TAXONOMY)
		) {
			WPHAVE_Media_Folders::register_taxonomy();
		}
	}

	/**
	 * Provision every registered table before seeders write synthetic records.
	 *
	 * Plugin activation can run before a Playground request has completed its
	 * complete feature bootstrap. The canonical manager coordinates schema updates.
	 * IDEMPOTENCY INVARIANT: Repeated setup converges on the production schema
	 * contract.
	 *
	 * @return array|WP_Error Schema update results or a readiness failure.
	 */

	private static function prepare_database_schema() {
		if (!class_exists('WPHAVE_Database_Schema_Manager')) {
			return new WP_Error(
				'wphave_demo_schema_manager_unavailable',
				__('The database schema manager is unavailable for WPHAVE demo data.', 'wphave'),
			);
		}

		return WPHAVE_Database_Schema_Manager::update_all([
			'context' => 'playground-demo',
		]);
	}

	/**
	 * Verify the persisted fixture graph instead of trusting its version marker.
	 *
	 * Playground sites may be restored from snapshots or interrupted between
	 * seeder steps. A matching version must therefore never suppress repair when
	 * content or the static front-page assignment is incomplete.
	 *
	 * @return bool Whether required resources and rolling data inventories are present.
	 */

	private static function is_complete(): bool {
		$state = get_option(self::STATE_OPTION);

		if (
			!is_array($state) ||
			empty($state['pages']['home']) ||
			empty($state['pages']['style-guide']) ||
			(wphave_release_feature_ready('playgroundBlockStyling') &&
				empty($state['pages']['block-styling'])) ||
			empty($state['activatedAt'])
		) {
			return false;
		}

		// Disabled rollout fixtures do not trigger repairs, even after a visitor deletes one.
		// Only the validation copy changes; existing pages and persisted ownership stay intact.
		if (!wphave_release_feature_ready('playgroundBlockStyling')) {
			unset($state['pages']['block-styling']);
		}

		$required_posts = [
			'media' => 1,
			'forms' => 2,
			'pages' => 1,
			'templateParts' => 2,
			'templates' => 3,
			'navigations' => 2,
			'cssClasses' => 3,
			'blockStyles' => 2,
			'addOns' => 1,
		];

		if (wphave_release_feature_ready('playgroundExampleContent')) {
			$required_posts['projects'] = 6;
		}

		foreach ($required_posts as $key => $minimum) {
			if (empty($state[$key]) || !is_array($state[$key]) || count($state[$key]) < $minimum) {
				return false;
			}

			foreach ($state[$key] as $post_id) {
				if (!get_post_status((int) $post_id)) {
					return false;
				}
			}
		}

		$expected_comments = WPHAVE_Playground_Demo_Content_Seeder::expected_comment_count(
			$state['pages'],
			wphave_release_feature_ready('playgroundExampleContent')
				? (array) ($state['projects'] ?? [])
				: [],
		);
		foreach (['comments' => $expected_comments, 'redirects' => 1] as $key => $minimum) {
			if (empty($state[$key]) || !is_array($state[$key]) || count($state[$key]) < $minimum) {
				return false;
			}
		}

		$required_media_folders = ['logos', 'backgrounds', 'people'];

		// VALIDATION INVARIANT: This predicate only inspects fixtures after
		// install() has established their taxonomy dependency. It never repairs or
		// normalizes persisted state while deciding whether a rebuild is required.
		if (
			!class_exists('WPHAVE_Media_Folders') ||
			!taxonomy_exists(WPHAVE_Media_Folders::TAXONOMY)
		) {
			return false;
		}

		if (
			array_diff($required_media_folders, array_keys((array) ($state['mediaFolders'] ?? [])))
		) {
			return false;
		}

		foreach ((array) $state['mediaFolders'] as $folder_id) {
			$folder = get_term((int) $folder_id, WPHAVE_Media_Folders::TAXONOMY);

			if (!$folder || is_wp_error($folder)) {
				return false;
			}
		}

		if (empty($state['users']) || !is_array($state['users']) || count($state['users']) < 3) {
			return false;
		}

		foreach ($state['users'] as $user_id) {
			if (!get_user_by('id', (int) $user_id)) {
				return false;
			}

			if (!get_user_meta((int) $user_id, 'wphave_last_login', true)) {
				return false;
			}
		}

		$analytics = $state['analytics'] ?? [];
		$audience = $state['audience'] ?? [];

		return 30 === (int) ($analytics['days'] ?? 0) &&
			12 === (int) ($audience['contacts'] ?? 0) &&
			12 === (int) ($audience['leads'] ?? 0) &&
			10 === (int) ($audience['subscribers'] ?? 0);
	}

	/**
	 * Add a role that demonstrates a deliberately reduced client environment.
	 *
	 * @return void
	 */

	private static function seed_client_role(): void {
		$role = get_role('wphave_client');

		if ($role) {
			$role->add_cap('wphave_access');
		}
	}

	/**
	 * Create a small role-diverse team through stable, non-login fixture keys.
	 *
	 * Existing users are updated so interrupted installs and version upgrades
	 * converge without creating duplicates. Passwords are intentionally random:
	 * Playground visitors use the Blueprint administrator account instead.
	 *
	 * @param string $activated_at Demo activation datetime used as the reference for synthetic last logins.
	 * @return int[]|WP_Error User IDs keyed by login, or a user creation error.
	 */

	private static function seed_demo_users(string $activated_at) {
		$fixtures = [
			[
				'login' => 'demo-editor',
				'email' => 'editor@wphave-demo.invalid',
				'first_name' => 'Mira',
				'last_name' => 'Redaktion',
				'role' => 'editor',
				'last_login_offset' => '-2 hours',
			],
			[
				'login' => 'demo-author',
				'email' => 'author@wphave-demo.invalid',
				'first_name' => 'Noah',
				'last_name' => 'Content',
				'role' => 'author',
				'last_login_offset' => '-1 day -3 hours',
			],
			[
				'login' => 'demo-client',
				'email' => 'client@wphave-demo.invalid',
				'first_name' => 'Lea',
				'last_name' => 'Kundin',
				'role' => 'wphave_client',
				'last_login_offset' => '-4 days -5 hours',
			],
		];

		$user_ids = [];
		$activation_time = new DateTimeImmutable($activated_at);

		foreach ($fixtures as $fixture) {
			$existing = get_user_by('login', $fixture['login']);

			$user_data = [
				'user_login' => $fixture['login'],
				'user_email' => $fixture['email'],
				'first_name' => $fixture['first_name'],
				'last_name' => $fixture['last_name'],
				'display_name' => $fixture['first_name'] . ' ' . $fixture['last_name'],
				'role' => $fixture['role'],
			];

			if ($existing) {
				$user_data['ID'] = $existing->ID;
				$user_id = wp_update_user($user_data);
			} else {
				$user_data['user_pass'] = wp_generate_password(32, true, true);
				$user_id = wp_insert_user($user_data);
			}

			if (is_wp_error($user_id)) {
				return $user_id;
			}

			update_user_meta($user_id, '_wphave_playground_demo', 1);
			update_user_meta(
				$user_id,
				'wphave_last_login',
				$activation_time->modify($fixture['last_login_offset'])->format('Y-m-d\TH:i:s\Z'),
			);

			$user_ids[$fixture['login']] = (int) $user_id;
		}

		return $user_ids;
	}

	/**
	 * Keep the synthetic and disposable nature of all fixtures visible.
	 *
	 * @return void
	 */

	public static function render_demo_notice(): void {
		$screen = function_exists('get_current_screen') ? get_current_screen() : null;
		$is_dashboard = $screen && 'dashboard' === $screen->id;
		$is_wphave =
			!empty($_GET['page']) &&
			WPHAVE_ADMIN_PAGE_SLUG === sanitize_key(wphave_request_string($_GET, 'page'));

		if (!$is_dashboard && !$is_wphave) {
			return;
		}

		$error = get_option('wphave_playground_demo_error');

		if (is_array($error) && !empty($error['message'])) {
			echo '<div class="notice notice-error"><p><strong>' .
				esc_html__('WPHAVE demo setup could not be completed.', 'wphave') .
				'</strong> ' .
				esc_html($error['message']) .
				'</p></div>';
			return;
		}

		if ($is_dashboard) {
			$is_ready = self::is_complete();
			echo '<div class="notice notice-info"><p><strong>' .
				esc_html__('Welcome to the WPHAVE live demo.', 'wphave') .
				'</strong> ';
			echo $is_ready
				? esc_html__(
					'The sample website and synthetic demo data are ready. Start with the new WPHAVE experience or inspect the generated website first.',
					'wphave',
				)
				: esc_html__(
					'The sample website is being prepared. Reload this page in a moment if the WPHAVE experience is not available yet.',
					'wphave',
				);
			echo '</p>';
			if ($is_ready) {
				echo '<p><a class="button button-primary" href="' .
					esc_url(admin_url('admin.php?page=workspace')) .
					'">' .
					esc_html__('Open WPHAVE', 'wphave') .
					'</a> ';
				// Keep navigation inside the running Playground frame. Its scoped URL
				// cannot be opened as a standalone website in a new browser tab.
				echo '<a class="button" href="' .
					esc_url(home_url('/')) .
					'" target="_self">' .
					esc_html__('View demo website', 'wphave') .
					'</a></p>';
			}
			echo '</div>';
			return;
		}

		echo '<div class="notice notice-info"><p><strong>' .
			esc_html__('WPHAVE live demo:', 'wphave') .
			'</strong> ' .
			esc_html__(
				'All contacts, statistics, projects and media are synthetic sample data. This temporary environment is discarded when you close it.',
				'wphave',
			) .
			'</p></div>';
	}
}
