<?php

if (!defined('ABSPATH')) {
	exit();
}

/**
 * Materializes bundled reference pages without changing their block design.
 * Text slots are complete JSON strings; translated rich text remains literal text.
 * Persistence and visitor ownership belong to the shared demo seeder.
 */
class WPHAVE_Playground_Demo_Reference_Page {
	/**
	 * @param string $slug Trusted bundled template name, never request input.
	 * @param callable $get_copy Resolves literal gettext messages in the site locale.
	 * @return array{title: string, excerpt: string, content: string}|WP_Error
	 */
	public static function render(string $slug, callable $get_copy) {
		$switched = switch_to_locale(get_locale());
		try {
			$path = __DIR__ . '/content/' . $slug . '.html';
			$template = is_readable($path) ? file_get_contents($path) : false;
			if (false === $template || '' === trim($template)) {
				return new WP_Error(
					'wphave_demo_' . str_replace('-', '_', $slug) . '_missing',
					'The demo reference page content is unavailable.',
				);
			}
			$copy = $get_copy();
			preg_match_all(
				'/"\{\{' . preg_quote($slug, '/') . '\.([a-z-]+)\}\}"/',
				$template,
				$matches,
			);
			$replacements = [];
			foreach ($matches[1] as $key) {
				if (!array_key_exists($key, $copy)) {
					return new WP_Error(
						'wphave_demo_' . str_replace('-', '_', $slug) . '_unknown_text',
						'The demo reference page contains an unknown text slot.',
					);
				}
				$replacements['"{{' . $slug . '.' . $key . '}}"'] = wp_json_encode(
					esc_html($copy[$key]),
					JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT,
				);
			}
			return [
				'title' => $copy['title'],
				'excerpt' => $copy['excerpt'],
				'content' => trim(strtr($template, $replacements)),
			];
		} finally {
			if ($switched) {
				restore_previous_locale();
			}
		}
	}
}
