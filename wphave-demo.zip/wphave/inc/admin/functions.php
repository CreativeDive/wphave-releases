<?php

/**
 * Add custom favicon for WordPress admin backend.
 */

include_once ( __DIR__ . '/user/presence/lifecycle.php' );
if( wphave_presence_feature_enabled() ) {
	include_once ( __DIR__ . '/user/presence/functions.php' );
}
include_once ( __DIR__ . '/user/functions.php' );


/**
 * Add custom favicon for WordPress admin backend.
 */

if ( ! function_exists( 'wphave_admin_favicon' ) ) :

	function wphave_admin_favicon() {

        $path = wphave_asset_url( 'assets/img/favicon.ico' );
        if( wphave_use_fse() ) {
            $path = wphave_asset_url( 'assets/img/favicon-wp.ico' );
        }

		echo '<link rel="shortcut icon" href="' . esc_url( $path ) . '" />';

	}

endif;

add_action('admin_head', 'wphave_admin_favicon');


/**
 * Add plugin links.
 *
 * @param mixed $actions Actions.
 * @param mixed $plugin_file Plugin file.
 */

function wphave_add_plugin_links( $actions, $plugin_file ) {

	static $plugin;

	if( ! isset( $plugin ) ) {
		$plugin = WPHAVE_BASENAME;
	}

	$overview_screen = add_query_arg(
		array( 'page' => WPHAVE_ADMIN_PAGE_SLUG ),
		admin_url( 'admin.php' )
	);
	$settings_screen = add_query_arg(
		array(
			'page'   => WPHAVE_ADMIN_PAGE_SLUG,
			'screen' => 'settings',
		),
		admin_url( 'admin.php' )
	);

	if( $plugin === $plugin_file ) {
		$settings = array(
			'settings' => '<a href="' . esc_url( $settings_screen ) . '">' . __( 'Settings', 'wphave' ) . '</a>',
			'license'  => '<a href="' . esc_url( $overview_screen ) . '">' . __( 'Enter license key', 'wphave' ) . '</a>',
		);

		$actions = array_merge( $settings, $actions );
	}

	return $actions;

}

add_filter( 'plugin_action_links_' . WPHAVE_BASENAME, 'wphave_add_plugin_links', 10, 5 );


/**
 * Add plugin help links.
 *
 * @param mixed $links Links.
 * @param mixed $file File.
 */

function wphave_add_plugin_help_links( $links, $file ) {

	if( WPHAVE_BASENAME === $file ) {
		$row_meta = array(
			'docs' => '<a href="https://wphave.com/documentation/" target="_blank" rel="noopener noreferrer">' . __( 'Documentation', 'wphave' ) . '<span class="screen-reader-text"> ' . __( '(opens in a new tab)', 'wphave' ) . '</span></a>',
        );

        return array_merge( $links, $row_meta );
    }

    return (array) $links;

}

add_filter( 'plugin_row_meta', 'wphave_add_plugin_help_links', 10, 2 );
