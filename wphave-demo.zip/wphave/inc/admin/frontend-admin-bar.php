<?php

require_once dirname(__DIR__) . '/features/security/safe-link.php';

/**
 * Own frontend toolbar visibility, destinations, assets and rendering.
 *
 * Loaded by core runtime; management interface methods delegate here. Historical
 * restricted-admin-bar handles and DOM IDs remain stable for export consumers.
 */
class WPHAVE_Frontend_Admin_Bar {
	/**
	 * Register the shared frontend hooks once during core runtime loading.
	 *
	 * @return void
	 */

	public static function init() {
		add_filter('show_admin_bar', [__CLASS__, 'filter_admin_bar_visibility'], 20);
		add_filter('body_class', [__CLASS__, 'filter_restricted_body_classes']);
		add_action('wp_enqueue_scripts', [__CLASS__, 'enqueue_restricted_admin_bar_assets']);
		add_action('wp_body_open', [__CLASS__, 'render_restricted_admin_bar'], 0);
		add_action('wp_footer', [__CLASS__, 'render_restricted_admin_bar'], 0);
	}

	/**
	 * Determine whether the current request receives the custom toolbar.
	 *
	 * Previews and anonymous requests are excluded first. Restricted users retain
	 * their toolbar independently of the optional setting and personal preference.
	 * Other users require site opt-in and personal toolbar visibility. This grants no permissions.
	 *
	 * @return bool Whether to render toolbar markup and enqueue its assets.
	 */

	public static function should_render() {
		if (is_admin() || !is_user_logged_in()) {
			return false;
		}
		if (
			WPHAVE_Site_Preview_Context::is_current_request() ||
			WPHAVE_Site_Preview_Context::is_post_preview()
		) {
			return false;
		}
		if (self::is_restricted_user()) {
			return true;
		}
		return wphave_data_get('site_settings', 'advanced.ui.frontendAdminBar', false) === true &&
			get_user_option('show_admin_bar_front') !== 'false';
	}

	/**
	 * Determine whether the current user belongs to an explicitly restricted role.
	 *
	 * Administrators remain unrestricted even if one of their roles appears in
	 * the saved role list.
	 *
	 * @return bool
	 */

	public static function is_restricted_user() {
		if (current_user_can('manage_options')) {
			return false;
		}

		$mode_type = wphave_data_get('site_settings', 'advanced.ui.mode.type');
		$mode_roles = wphave_data_get('site_settings', 'advanced.ui.mode.roles', []) ?: [];

		if ($mode_type !== 'wphave') {
			return false;
		}

		$user = wp_get_current_user();

		if (!$user || empty($user->roles)) {
			return false;
		}

		foreach ($user->roles as $role) {
			if (in_array($role, $mode_roles, true)) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Hide native WordPress chrome when restrictions or the replacement require it.
	 *
	 * @param bool $show Whether the admin bar should be shown.
	 * @return bool
	 */

	public static function filter_admin_bar_visibility($show) {
		if (self::is_restricted_user() || self::should_render()) {
			return false;
		}

		return $show;
	}

	/**
	 * Preserve restricted-user identity and add spacing only for a visible toolbar.
	 *
	 * @param array $classes Frontend body classes.
	 * @return array
	 */

	public static function filter_restricted_body_classes($classes) {
		if (self::is_restricted_user() && is_user_logged_in()) {
			$classes[] = 'wphave-restricted-user';
		}

		if (self::should_render()) {
			$classes[] = 'wphave-frontend-admin-bar';
		}

		return $classes;
	}

	/**
	 * Enqueue toolbar styles, interactions and shared tooltips for visible toolbars.
	 *
	 * @return void
	 */

	public static function enqueue_restricted_admin_bar_assets() {
		if (!self::should_render()) {
			return;
		}

		// Toolbar markup bypasses the content scanner, so request its shared tooltip assets explicitly.
		wp_enqueue_script('wphave-tooltip');
		wp_enqueue_style('wphave-tooltip');

		$style_path = 'inc/admin/pages/restricted-admin-bar.css';
		wp_enqueue_style(
			'wphave-restricted-admin-bar',
			wphave_asset_url($style_path),
			[],
			WPHAVE_Asset_Registry::version($style_path),
		);
		$script_path = 'inc/admin/pages/frontend-admin-bar.js';
		wp_enqueue_script(
			'wphave-restricted-admin-bar',
			wphave_asset_url($script_path),
			[],
			WPHAVE_Asset_Registry::version($script_path),
			true,
		);
	}

	/**
	 * Render the frontend replacement for WordPress' hidden native admin bar.
	 *
	 * wp_body_open is preferred, while wp_footer supports themes that omit it.
	 * A request-local guard prevents duplicate output when both hooks run.
	 *
	 * @return void
	 */

	public static function render_restricted_admin_bar() {
		static $rendered = false;

		if ($rendered || !self::should_render()) {
			return;
		}

		$rendered = true;
		$user = wp_get_current_user();
		$site_title = get_bloginfo('name');
		$site_icon = get_site_icon_url(32);
		$avatar = wphave_get_avatar_url($user->ID, ['size' => 64]);
		$role_names = [];
		foreach ($user->roles as $role) {
			$role_name = wp_roles()->roles[$role]['name'] ?? '';
			if ($role_name) {
				$role_names[] = wphave_get_role_label($role, $role_name);
			}
		}
		$preferences =
			WPHAVE_User_Preferences_Manager::get_preferences()['ui']['frontendAdminBar'] ?? null;
		$classic_admin_url = self::classic_admin_url();
		$links = self::workspace_links();
		$edit = self::current_edit_link();
		include __DIR__ . '/pages/frontend-admin-bar-view.php';
	}

	/**
	 * Build website-menu destinations from workspace routes and capabilities.
	 *
	 * Pages and Media have dedicated entries. Other configured public post types
	 * require their own edit_posts capability; internal types remain excluded.
	 *
	 * @return array<int, array{label: string, url: string}> Ordered menu links.
	 */

	public static function workspace_links() {
		$links = [['label' => __('Overview', 'wphave'), 'url' => self::workspace_url('overview')]];
		if (current_user_can('edit_pages')) {
			$links[] = ['label' => __('Pages', 'wphave'), 'url' => self::workspace_url('pages')];
		}
		$screens = WPHAVE_Frontend_Editor_Routing::get_post_type_screens();
		foreach ($screens as $name => $screen) {
			// Pages and Media have dedicated entries; internal workspace types are not public content.
			if (in_array($name, ['page', 'attachment'], true)) {
				continue;
			}
			$post_type = get_post_type_object($name);
			if (
				!$post_type ||
				!$post_type->public ||
				!current_user_can($post_type->cap->edit_posts)
			) {
				continue;
			}
			$links[] = [
				'label' => $post_type->labels->name,
				'url' => self::workspace_url($screen),
			];
		}
		if (current_user_can('upload_files')) {
			$links[] = ['label' => __('Media', 'wphave'), 'url' => self::workspace_url('media')];
		}
		return $links;
	}

	/**
	 * Resolve native administration access using the shared restriction policy.
	 *
	 * @return string Current site's admin URL, or an empty string when unavailable.
	 */

	public static function classic_admin_url() {
		return is_user_logged_in() && !self::is_restricted_user() ? admin_url() : '';
	}

	/**
	 * Build a link to a registered workspace screen on the current site.
	 *
	 * Callers own destination authorization; the URL grants no access itself.
	 *
	 * @param string $screen Registered workspace screen identifier.
	 * @return string Unescaped URL; escape when rendering an HTML attribute.
	 */

	public static function workspace_url($screen) {
		return add_query_arg(
			['page' => WPHAVE_ADMIN_PAGE_SLUG, 'screen' => $screen],
			admin_url('admin.php'),
		);
	}

	/**
	 * Resolve the editable singular document without using incidental loop items.
	 *
	 * Requires edit_post for the queried object. Explicitly builds the Workspace
	 * destination; unsupported types retain their native editor fallback.
	 *
	 * @return array{url: string, label: string}|null Authorized edit action or null.
	 */

	public static function current_edit_link() {
		if (!is_singular()) {
			return null;
		}
		$post = get_queried_object();
		// AUTHORIZATION INVARIANT: Workspace links require the exact object's edit_post capability.
		if (!($post instanceof WP_Post) || !current_user_can('edit_post', $post->ID)) {
			return null;
		}
		$url =
			WPHAVE_Frontend_Editor_Routing::get_editor_url($post->ID, $post->post_type) ?:
			get_edit_post_link($post->ID, 'raw');
		$type = get_post_type_object($post->post_type);
		// TOOLBAR LINK INVARIANT: Editor routing and Core edit-link filters must
		// produce a safe HTTP(S) destination before the toolbar renders an action.
		$url = WPHAVE_Safe_Link::local_or_http($url);
		return $url && $type ? ['url' => $url, 'label' => $type->labels->edit_item] : null;
	}
}

WPHAVE_Frontend_Admin_Bar::init();
