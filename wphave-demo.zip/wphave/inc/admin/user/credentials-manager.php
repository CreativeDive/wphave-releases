<?php

/**
 * Manages password changes and the confirmed email-change workflow.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPHAVE_User_Credentials_Manager {

	const PENDING_EMAIL_META = '_wphave_pending_email';
	const EMAIL_TOKEN_META = '_wphave_email_change_token';
	const EMAIL_EXPIRY_META = '_wphave_email_change_expires';

	/**
	 * Register REST routes and email-confirmation hooks.
	 */

	public static function init() {
		add_action( 'rest_api_init', [ __CLASS__, 'register_rest_routes' ] );
		add_action( 'init', [ __CLASS__, 'confirm_email_change' ] );
		add_filter( 'login_message', [ __CLASS__, 'add_email_change_success_message' ] );
	}

	/**
	 * Register the credential-management REST routes.
	 */

	public static function register_rest_routes() {
		$authenticated = [ __CLASS__, 'is_user_logged_in' ];

		register_rest_route( 'wphave/v1', '/user/change-password', [
			'methods' => 'POST',
			'permission_callback' => $authenticated,
			'callback' => [ __CLASS__, 'change_password' ],
		] );

		register_rest_route( 'wphave/v1', '/user/change-email', [
			'methods' => 'POST',
			'permission_callback' => $authenticated,
			'callback' => [ __CLASS__, 'request_email_change' ],
		] );

		register_rest_route( 'wphave/v1', '/user/change-email/cancel', [
			'methods' => 'POST',
			'permission_callback' => $authenticated,
			'callback' => [ __CLASS__, 'cancel_email_change' ],
		] );

		register_rest_route( 'wphave/v1', '/user/change-email/status', [
			'methods' => 'GET',
			'permission_callback' => $authenticated,
			'callback' => [ __CLASS__, 'get_email_change_status' ],
		] );
	}

	/**
	 * Determine whether a REST request has an authenticated user.
	 *
	 * @return bool
	 */

	public static function is_user_logged_in() {
		return is_user_logged_in();
	}

	/**
	 * Change the current user's password and invalidate existing sessions.
	 *
	 * @param WP_REST_Request $request
	 * @return array|WP_Error
	 */

	public static function change_password( $request ) {
		$user = wp_get_current_user();
		$current_password = (string) $request->get_param( 'currentPassword' );
		$new_password = (string) $request->get_param( 'newPassword' );

		if ( ! wp_check_password( $current_password, $user->user_pass, $user->ID ) ) {
			return new WP_Error( 'invalid_password', __( 'Current password is incorrect.', 'wphave' ), [ 'status' => 403 ] );
		}

		if ( $current_password === $new_password ) {
			return new WP_Error( 'password_unchanged', __( 'The new password must be different from the current password.', 'wphave' ), [ 'status' => 400 ] );
		}

		if ( ! self::is_secure_password( $new_password ) ) {
			return new WP_Error( 'weak_password', __( 'The new password does not meet the security requirements.', 'wphave' ), [ 'status' => 400 ] );
		}

		// IDENTITY INVARIANT: Password verification invokes filters and must not
		// authorize a later credential commit after the request loses or replaces
		// the exact authenticated account captured at callback entry.
		$identity = self::require_same_authenticated_user( (int) $user->ID );
		if( is_wp_error( $identity ) ) {
			return $identity;
		}

		wp_set_password( $new_password, $user->ID );
		$updated_user = get_user_by( 'id', $user->ID );

		// CREDENTIAL/COMMIT INVARIANT: Session invalidation is a consequence only
		// of an exactly persisted password replacement. wp_set_password() has no
		// return value, so canonical hash verification is the commit boundary.
		if( ! $updated_user || ! wp_check_password( $new_password, $updated_user->user_pass, $user->ID ) ) {
			return new WP_Error(
				'password_persistence_failed',
				__( 'The new password could not be saved. Your existing password is unchanged.', 'wphave' ),
				[ 'status' => 500 ]
			);
		}

		self::destroy_user_sessions( (int) $user->ID );

		return [ 'success' => true ];
	}

	/**
	 * Store and send a confirmed email-change request.
	 *
	 * @param WP_REST_Request $request
	 * @return array|WP_Error
	 */

	public static function request_email_change( WP_REST_Request $request ) {
		$user = wp_get_current_user();
		$user_id = get_current_user_id();
		$new_email = sanitize_email( $request->get_param( 'email' ) );

		// IDENTITY INVARIANT: Self-service credential changes remain bound to the
		// exact authenticated user captured at entry. Email normalization invokes
		// filters; identity loss or replacement before grant persistence fails closed.
		$identity = self::require_same_authenticated_user( $user_id );
		if( is_wp_error( $identity ) || (int) $user->ID !== $user_id ) {
			return is_wp_error( $identity )
				? $identity
				: self::credentials_forbidden();
		}

		if ( ! is_email( $new_email ) ) {
			return new WP_Error( 'invalid_email', __( 'Invalid email address.', 'wphave' ), [ 'status' => 400 ] );
		}

		if ( $new_email === $user->user_email ) {
			return new WP_Error( 'email_unchanged', __( 'This is already your current email address.', 'wphave' ), [ 'status' => 400 ] );
		}

		if ( email_exists( $new_email ) ) {
			// PRIVACY INVARIANT: Self-service credential routes must not become an
			// account directory. Occupied addresses receive a generic rejection that
			// does not confirm whether another WordPress user owns the submitted email.
			return new WP_Error( 'email_unavailable', __( 'This email address cannot be used.', 'wphave' ), [ 'status' => 400 ] );
		}

		$previous_change = [
			'email' => get_user_meta( $user_id, self::PENDING_EMAIL_META, true ),
			'token' => get_user_meta( $user_id, self::EMAIL_TOKEN_META, true ),
			'expires' => get_user_meta( $user_id, self::EMAIL_EXPIRY_META, true ),
		];
		$token = wp_generate_password( 32, false );
		$token_hash = wp_hash_password( $token );
		$expires = time() + DAY_IN_SECONDS;
		update_user_meta( $user_id, self::PENDING_EMAIL_META, $new_email );
		update_user_meta( $user_id, self::EMAIL_TOKEN_META, $token_hash );
		update_user_meta( $user_id, self::EMAIL_EXPIRY_META, $expires );

		/*
		 * SECURITY AND RECOVERY INVARIANT: Destination, token hash and expiry are
		 * one bearer grant. Mail delivery may begin only after all three exact values
		 * are durably readable; a partial metadata write restores the prior complete
		 * request and never distributes authority that the server cannot validate.
		 */
		if (
			$new_email !== get_user_meta( $user_id, self::PENDING_EMAIL_META, true )
			|| $token_hash !== get_user_meta( $user_id, self::EMAIL_TOKEN_META, true )
			|| $expires !== (int) get_user_meta( $user_id, self::EMAIL_EXPIRY_META, true )
		) {
			self::restore_email_change( $user_id, $previous_change );

			return new WP_Error(
				'email_change_persistence_failed',
				__( 'The email change could not be saved. Please try again.', 'wphave' ),
				[ 'status' => 500 ]
			);
		}

		if ( ! self::send_email_change_confirmation( $user, $new_email, $token ) ) {
			self::restore_email_change( $user_id, $previous_change );

			return new WP_Error( 'email_delivery_failed', __( 'The confirmation email could not be sent. No email change was saved.', 'wphave' ), [ 'status' => 500 ] );
		}

		return [ 'status' => 'pending' ];
	}

	/**
	 * Send the email-change confirmation message.
	 *
	 * @param WP_User $user
	 * @param string  $new_email
	 * @param string  $token
	 */

	private static function send_email_change_confirmation( $user, $new_email, $token ) {
		$site_name = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		$confirm_url = add_query_arg( [ 'wphave_confirm_email' => 1, 'user' => $user->ID, 'token' => $token ], site_url( '/confirm-email' ) );
		$subject = '[' . $site_name . '] ' . __( 'Email Change Request', 'wphave' );
		$content = sprintf( /* translators: %s: contextual value. */
		__( 'Howdy %s,', 'wphave' ), $user->user_login ) . "\n\n";
		$content .= __( 'You recently requested to have the email address on your account changed.', 'wphave' ) . "\n\n";
		$content .= __( 'If this is correct, please click on the following link to change it:', 'wphave' ) . "\n";
		// Keep the URL unescaped because the shared template receives plain text content.
		$content .= $confirm_url . "\n\n";
		$content .= __( 'You can safely ignore and delete this email if you do not want to take this action.', 'wphave' ) . "\n\n";
		$content .= sprintf( /* translators: %s: contextual value. */
		__( 'This email has been sent to %s', 'wphave' ), $new_email ) . "\n\n";
		$message = wphave_build_email_template( [
			'title' => __( 'Email Change Request', 'wphave' ),
			'content' => $content,
		] );

		return wp_mail( $new_email, $subject, $message, wphave_email_template_headers() );
	}

	/**
	 * Cancel the current user's pending email change.
	 *
	 * @return array
	 */

	public static function cancel_email_change() {
		$cleared = self::clear_email_change( get_current_user_id(), true );
		if( is_wp_error( $cleared ) ) {
			return $cleared;
		}
		if( ! $cleared ) {
			return new WP_Error(
				'email_change_cancel_failed',
				__( 'The pending email change could not be cancelled. Please try again.', 'wphave' ),
				[ 'status' => 500 ]
			);
		}

		return [ 'status' => 'cancelled' ];
	}

	/**
	 * Return the current user's pending email-change status.
	 *
	 * @return array
	 */

	public static function get_email_change_status() {
		$user_id = get_current_user_id();
		$pending_email = get_user_meta( $user_id, self::PENDING_EMAIL_META, true );
		$expires = (int) get_user_meta( $user_id, self::EMAIL_EXPIRY_META, true );

		// IDENTITY INVARIANT: Pending destinations are private credential state and
		// user-meta reads are filterable. Revalidate the exact authenticated owner
		// after collection, before either disclosure or expiry-driven deletion.
		$identity = self::require_same_authenticated_user( $user_id );
		if( is_wp_error( $identity ) ) {
			return $identity;
		}

		if ( ! $pending_email || ! $expires || time() > $expires ) {
			if ( $pending_email || $expires ) {
				$cleared = self::clear_email_change( $user_id, true );
				if( is_wp_error( $cleared ) ) {
					return $cleared;
				}
			}

			return [ 'pending' => false ];
		}

		return [
			'pending' => true,
			'email' => $pending_email,
		];
	}

	/**
	 * Validate an email confirmation request and apply the pending address.
	 */

	public static function confirm_email_change() {
		if ( ! isset( $_GET['wphave_confirm_email'] ) ) {
			return;
		}

		$user_id = absint( wphave_request_string( $_GET, 'user' ) );
		$token = wphave_request_string( $_GET, 'token' );

		// SECURITY/PRIVACY INVARIANT: Before a complete bearer grant succeeds,
		// every public failure is indistinguishable. User IDs must not become an
		// oracle for missing, pending, expired or malformed credential workflows,
		// and lossy text sanitization must never repair a submitted token.
		if ( ! $user_id || 1 !== preg_match( '/\A[A-Za-z0-9]{32}\z/D', $token ) ) {
			self::deny_email_change_confirmation();
		}

		$pending_email = get_user_meta( $user_id, self::PENDING_EMAIL_META, true );
		$token_hash = get_user_meta( $user_id, self::EMAIL_TOKEN_META, true );
		$expires = (int) get_user_meta( $user_id, self::EMAIL_EXPIRY_META, true );

		// SECURITY INVARIANT: An email change is authorized only by the unexpired
		// one-time secret stored for this exact user; the raw token is never persisted.
		if (
			! $pending_email
			|| ! $token_hash
			|| ! $expires
			|| time() > $expires
			|| ! wp_check_password( $token, $token_hash )
		) {
			self::deny_email_change_confirmation();
		}

		$result = wp_update_user( [
			'ID' => $user_id,
			'user_email' => $pending_email,
		] );

		if ( is_wp_error( $result ) ) {
			wp_die( esc_html( $result->get_error_message() ) );
		}

		// CREDENTIAL/COMMIT INVARIANT: A numeric wp_update_user result is not proof
		// that the requested identity was committed. Filters may rewrite the value,
		// so reload and verify the canonical record before consuming the one-time
		// grant or invalidating sessions. A mismatch remains retryable and fails closed.
		clean_user_cache( $user_id );
		$updated_user = get_userdata( $user_id );
		if ( ! $updated_user || (string) $updated_user->user_email !== (string) $pending_email ) {
			wp_die( esc_html__( 'The email change could not be committed safely. Please try again.', 'wphave' ) );
		}

		$cleared = self::clear_email_change( $user_id );
		if( is_wp_error( $cleared ) || ! $cleared ) {
			wp_die( esc_html__( 'The email change was applied, but its confirmation grant could not be consumed safely.', 'wphave' ) );
		}
		// SECURITY INVARIANT: Changing the login identity consumes the pending request
		// and invalidates every existing session of the exact target account before
		// control returns to a login URL. Anonymous confirmation context is irrelevant.
		self::destroy_user_sessions( $user_id );

		wp_safe_redirect( add_query_arg( 'wphave_email_confirmed', '1', wp_login_url() ) );
		exit;
	}

	/** Terminate an untrusted email-change confirmation without exposing state. */
	private static function deny_email_change_confirmation(): void {
		wp_die( __( 'This confirmation link is invalid or no longer available.', 'wphave' ) );
	}

	/**
	 * Invalidate every session belonging to an exact credential owner.
	 *
	 * @param int $user_id Credential owner.
	 */

	private static function destroy_user_sessions( int $user_id ): void {
		// SECURITY/IDENTITY INVARIANT: Credential rotation targets the supplied
		// account, never whichever user happens to own the current HTTP request.
		WP_Session_Tokens::get_instance( $user_id )->destroy_all();
	}

	/** Require one stable authenticated identity across a self-service operation. */
	private static function require_same_authenticated_user( int $user_id ) {
		if( $user_id > 0 && is_user_logged_in() && get_current_user_id() === $user_id ) {
			return true;
		}

		return self::credentials_forbidden();
	}

	/** Return the stable denial shared by credential identity boundaries. */
	private static function credentials_forbidden(): WP_Error {
		return new WP_Error(
			'wphave_credentials_forbidden',
			__( 'Your authenticated account changed during this request.', 'wphave' ),
			array( 'status' => 403 )
		);
	}

	/**
	 * Delete all state belonging to a pending email change.
	 *
	 * @param int $user_id
	 */

	private static function clear_email_change( $user_id, bool $require_owner = false ) {
		$keys = array( self::PENDING_EMAIL_META, self::EMAIL_TOKEN_META, self::EMAIL_EXPIRY_META );
		$previous = array();

		foreach( $keys as $meta_key ) {
			$previous[ $meta_key ] = array(
				'exists' => metadata_exists( 'user', $user_id, $meta_key ),
				'value' => get_user_meta( $user_id, $meta_key, true ),
			);
		}

		// IDENTITY/ROLLBACK INVARIANT: Self-service cancellation snapshots the
		// complete bearer grant before deletion. Filterable metadata access and
		// delete hooks may not consume it after the exact owner identity is lost.
		if( $require_owner ) {
			$identity = self::require_same_authenticated_user( (int) $user_id );
			if( is_wp_error( $identity ) ) {
				return $identity;
			}
		}

		foreach( $keys as $meta_key ) {
			if( $require_owner ) {
				$identity = self::require_same_authenticated_user( (int) $user_id );
				if( is_wp_error( $identity ) ) {
					self::restore_email_change_snapshot( $user_id, $previous );
					return $identity;
				}
			}
			delete_user_meta( $user_id, $meta_key );
		}

		if( $require_owner ) {
			$identity = self::require_same_authenticated_user( (int) $user_id );
			if( is_wp_error( $identity ) ) {
				self::restore_email_change_snapshot( $user_id, $previous );
				return $identity;
			}
		}

		foreach( $keys as $meta_key ) {
			if( ! metadata_exists( 'user', $user_id, $meta_key ) ) {
				continue;
			}

			// SECRET/ROLLBACK INVARIANT: Pending destination, token hash and expiry
			// are one bearer grant. Cancellation/consumption deletes all three or
			// restores their exact prior presence so the operation remains retryable.
			self::restore_email_change_snapshot( $user_id, $previous );

			return false;
		}

		return true;
	}

	/** Restore one exact pending-email grant snapshot. */
	private static function restore_email_change_snapshot( $user_id, array $snapshot ): void {
		foreach( $snapshot as $meta_key => $state ) {
			if( $state['exists'] ) {
				update_user_meta( $user_id, $meta_key, $state['value'] );
			} else {
				delete_user_meta( $user_id, $meta_key );
			}
		}
	}

	/**
	 * Restore the previous pending request when replacement email delivery fails.
	 *
	 * @param int   $user_id
	 * @param array $change
	 */

	private static function restore_email_change( $user_id, $change ) {
		self::clear_email_change( $user_id );

		if ( empty( $change['email'] ) || empty( $change['token'] ) || empty( $change['expires'] ) ) {
			return;
		}

		update_user_meta( $user_id, self::PENDING_EMAIL_META, $change['email'] );
		update_user_meta( $user_id, self::EMAIL_TOKEN_META, $change['token'] );
		update_user_meta( $user_id, self::EMAIL_EXPIRY_META, $change['expires'] );
	}

	/**
	 * Enforce the same minimum password policy at the trusted server boundary.
	 *
	 * @param string $password
	 * @return bool
	 */

	private static function is_secure_password( $password ) {
		return strlen( $password ) >= 8
			&& preg_match( '/[A-Z]/', $password )
			&& preg_match( '/[a-z]/', $password )
			&& preg_match( '/\d/', $password )
			&& preg_match( '/[^A-Za-z0-9]/', $password );
	}

	/**
	 * Add the confirmation result to the WordPress login screen.
	 *
	 * @param string $message
	 * @return string
	 */

	public static function add_email_change_success_message( $message ) {
		if ( isset( $_GET['wphave_email_confirmed'] ) ) {
			$message .= '<p class="message">' . __( 'Your email address has been successfully updated. Please sign in again.', 'wphave' ) . '</p>';
		}

		return $message;
	}
}
