<?php

require_once wphave_dir() . 'inc/features/security/rate-limiter.php';
require_once __DIR__ . '/runtime.php';
require_once __DIR__ . '/stream.php';
require_once __DIR__ . '/repository.php';
require_once __DIR__ . '/rest.php';
require_once __DIR__ . '/sessions.php';


/**
 * WPHAVE Presence System
 *
 * Architecture:
 *
 * - Writes:
 *   - lightweight, throttled
 *   - no blocking, no heavy response
 *
 * - Reads:
 *   - cached (object cache)
 *   - limited dataset
 *
 * - Transport:
 *   - Polling (default, reliable)
 *   - SSE (optional, best-effort)
 *
 * Design Goals:
 * - Never block UI
 * - Work on shared hosting
 * - Scale safely
 * - Degrade gracefully
 *
 * Notes:
 * - Presence is NOT critical data
 * - System is "eventually consistent"
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class WPHAVE_Presence {

	use WPHAVE_User_Presence_Runtime,
		WPHAVE_User_Presence_Stream,
		WPHAVE_User_Presence_Repository,
		WPHAVE_User_Presence_REST,
		WPHAVE_User_Presence_Sessions;

	const VERSION = '1.0.0';
	const DB_VERSION = '1.0.3';
	const OPTION_DB_VER = 'wphave_presence_db_version';
	const SCHEDULE_OPTION = 'wphave_presence_cleanup_schedule_signature';

    const DEFAULT_TTL = 60;
    const CACHE_TTL = 4;
    const RATE_LIMIT_SECONDS = 2;
    const MAX_ENTRIES = 100;
    const SSE_MAX_TIME = 20;
    const SSE_INTERVAL = 2;
    const CLEANUP_BATCH_SIZE = 1000;
    const CLEANUP_MAX_BATCHES = 5;

	private static array $instances = [];

	private string $table;

    /**
     * Singleton instance accessor
     *
     * Ensures only one instance of the presence system exists.
     */

	public static function instance(): self {
		$blog_id = get_current_blog_id();
		if( ! isset( self::$instances[$blog_id] ) ) {
			self::$instances[$blog_id] = new self();
		}

		return self::$instances[$blog_id];
	}

    /**
     * Constructor
     *
     * Initializes:
     * - DB table reference
     * - REST routes
     * - cleanup cron hook
     */

	private function __construct() {
		global $wpdb;

		$this->table = $wpdb->prefix . 'wphave_presence';

		// RUNTIME INVARIANT: Cron composes only the persisted cleanup callback.
		// Interactive Presence routes remain owned by management/REST requests.
		if ( ! wp_doing_cron() ) {
			add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );
		}

		add_action( 'wphave_presence_cleanup', array( $this, 'delete_expired' ) );
	}
}

/**
 * Register the Presence schema and compose its compatible runtime.
 *
 * SCHEDULING INVARIANT: Presence owns the cleanup workflow, while the shared
 * background-job scheduler owns and validates the platform recurrence. Keeping
 * interval registration centralized prevents feature load order from changing
 * whether an existing cleanup event can be reconciled.
 */

WPHAVE_Database_Schema_Manager::register( [
	'id' => 'presence',
    'enabled' => 'wphave_presence_feature_enabled',
	'label' => 'Presence table',
	'version' => WPHAVE_Presence::DB_VERSION,
	'option' => WPHAVE_Presence::OPTION_DB_VER,
	'tables' => [ 'wphave_presence' ],
	'callback' => function() {
		WPHAVE_Presence::activate();
	},
	'validator' => function() {
		return WPHAVE_Presence::instance()->schema_ready();
	},
] );

if ( WPHAVE_Database_Schema_Manager::runtime_compatible( 'presence' ) ) {
	// BOOTSTRAP INVARIANT: A worker entrypoint may load after plugins_loaded.
	// Register the persisted cleanup callback immediately so Cron never executes
	// a Presence event without its consumer.
	WPHAVE_Presence::instance();
	add_action( 'init', [ 'WPHAVE_Presence', 'ensure_cleanup_schedule' ] );
}

/**
 * Plugin activation hook
 *
 * When triggered:
 * - On plugin activation (once)
 *
 * What it does:
 * - Creates / updates database table
 * - Registers cron cleanup job
 *
 * Important:
 * - MUST NOT rely on runtime hooks (like plugins_loaded)
 * - Runs in isolated activation context
 * - Uses static method → safe without instance
 */

/**
 * Plugin deactivation hook
 *
 * When triggered:
 * - On plugin deactivation
 *
 * What it does:
 * - Removes scheduled cron job
 *
 * Why important:
 * - Prevents orphaned cron jobs
 * - Avoids unnecessary background execution
 *
 * Note:
 * - Does NOT delete data (by design)
 * - Presence data expires automatically via TTL
 */

register_deactivation_hook( WPHAVE_FILE_PATH, array( 'WPHAVE_Presence', 'deactivate' ) );
