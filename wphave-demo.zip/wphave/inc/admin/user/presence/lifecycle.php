<?php

/**
 * Presence feature lifecycle boundary.
 *
 * This compact lifecycle remains loaded while Presence is unavailable so a
 * schedule created by an earlier release cannot continue running orphaned.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Remove every scheduled Presence cleanup occurrence.
 *
 * @return void
 */

function wphave_presence_deactivate(): void {
	// LIFECYCLE INVARIANT: Deactivation removes executable Presence schedules and
	// their authorization signature while preserving customer content. A disabled
	// feature must never leave an orphaned background worker with stale authority.

	wp_clear_scheduled_hook( 'wphave_presence_cleanup' );
	delete_option( 'wphave_presence_cleanup_schedule_signature' );

}

if( ! wphave_presence_feature_enabled() ) {
	add_action( 'init', 'wphave_presence_deactivate', 1 );
}
