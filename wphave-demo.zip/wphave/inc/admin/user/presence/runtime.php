<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_User_Presence_Runtime {

    /**
     * Plugin activation hook
     *
     * - Creates database table
     * - Registers cleanup cron job
     */

	public static function activate(): void {
		self::instance()->install();
		self::ensure_cleanup_schedule();
	}

	/** Restore the cleanup schedule independently from schema migrations. */
	public static function ensure_cleanup_schedule(): void {
		WPHAVE_Background_Job_Scheduler::sync_recurring(
			'wphave_presence_cleanup',
			self::SCHEDULE_OPTION,
			true,
			'wphave_minutely',
			time() + MINUTE_IN_SECONDS,
			'presence-cleanup-v1'
		);
	}

    /**
     * Plugin deactivation hook
     *
     * - Removes scheduled cleanup job
     */

	public static function deactivate(): void {
		WPHAVE_Background_Job_Scheduler::sync_recurring(
			'wphave_presence_cleanup',
			self::SCHEDULE_OPTION,
			false,
			'wphave_minutely',
			time() + MINUTE_IN_SECONDS,
			'presence-cleanup-v1'
		);
	}

    /**
     * Install / upgrade database table
     *
     * Uses dbDelta:
     * - Creates table if missing
     * - Updates schema if needed
     */

	public function install(): void {
		global $wpdb;

		$current = get_option( self::OPTION_DB_VER );

		if( self::DB_VERSION === $current && $this->table_exists() ) {
			return;
		}

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$this->table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			room VARCHAR(191) NOT NULL DEFAULT '',
			session_id VARCHAR(191) NOT NULL DEFAULT '',
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			data LONGTEXT NOT NULL,
			date_gmt DATETIME NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY room_client (room, session_id),
			KEY user_id (user_id),
			KEY date_gmt (date_gmt),
			KEY room_date (room, date_gmt),
            KEY room_date_gmt (room, date_gmt)
		) {$charset_collate};";

		dbDelta( $sql );

		// The central schema manager writes the marker after this table validates.
	}

    /**
     * Check whether the presence table contains the columns used by runtime code.
     *
     * @return bool True when required columns exist.
     */

	private function required_columns_exist(): bool {
		global $wpdb;

		$columns = $wpdb->get_col( "SHOW COLUMNS FROM {$this->table}", 0 );

		if( ! is_array( $columns ) ) {
			return false;
		}

		foreach( [ 'id', 'room', 'session_id', 'user_id', 'data', 'date_gmt' ] as $column ) {
			if( ! in_array( $column, $columns, true ) ) {
				return false;
			}
		}

		global $wpdb;
		$indexes = array_unique( (array) $wpdb->get_col( "SHOW INDEX FROM {$this->table}", 2 ) );
		return in_array( 'PRIMARY', $indexes, true ) && in_array( 'room_client', $indexes, true ) && in_array( 'date_gmt', $indexes, true );
	}

    /**
     * Sanitize arbitrary presence data
     *
     * Rules:
     * - max nesting depth (3)
     * - only safe scalar types allowed
     * - recursively sanitized
     */

	private function sanitize_data( array $data, int $depth = 0 ): array {
		if( $depth > 3 ) {
			return array();
		}

        if( count($data) > 50 ) {
            $data = array_slice($data, 0, 50, true);
        }

		$allowed = array();

		foreach( $data as $key => $value ) {
			$key = preg_replace( '/[^a-zA-Z0-9_\-]/', '', (string) $key );

			if( '' === $key ) {
				continue;
			}

			if( is_bool( $value ) ) {
				$allowed[ $key ] = $value;
				continue;
			}

			if( is_int( $value ) || is_float( $value ) ) {
				$allowed[ $key ] = $value;
				continue;
			}

			if( null === $value ) {
				$allowed[ $key ] = null;
				continue;
			}

			if( is_string( $value ) ) {
				$allowed[ $key ] = sanitize_text_field( $value );
				continue;
			}

			if( is_array( $value ) ) {
				$allowed[ $key ] = $this->sanitize_data( $value, $depth + 1 );
			}
		}

		return $allowed;
	}

    /**
     * Get TTL for presence entries
     *
     * Filterable:
     * - wphave_presence_ttl
     *
     * Minimum:
     * - 15 seconds
     */

	private function get_ttl(): int {
		return max(
			15,
			absint(
				apply_filters( 'wphave_presence_ttl', self::DEFAULT_TTL )
			)
		);
	}

}
