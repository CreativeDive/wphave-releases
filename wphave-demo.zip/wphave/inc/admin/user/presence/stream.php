<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_User_Presence_Stream {

        /**
     * Check if SSE is enabled
     *
     * IMPORTANT:
     * - Disabled by default for compatibility
     * - Can be enabled via filter on capable servers
     */

    private function is_sse_enabled(): bool {
        return (bool) apply_filters( 'wphave_presence_enable_sse', false );
    }

	/**
	 * Apply the shared atomic rate limit without surfacing a hard UI error.
	 */

	private function passes_rate_limit( string $session_id ): bool {
		$key = 'wphave_presence_rate_' . md5( $session_id );

		// PERFORMANCE INVARIANT: Every storage backend observes the same window;
		// a database fallback must not turn each browser heartbeat into a write.
		return WPHAVE_Rate_Limiter::increment( $key, self::RATE_LIMIT_SECONDS ) <= 1;
	}

}
