<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_User_Presence_Sessions {

    /**
     * Sanitize session ID
     *
     * Removes unsafe characters
     */

	public function sanitize_session_id( string $session_id ): string {
		$session_id = trim( wp_unslash( $session_id ) );
		$session_id = preg_replace( '/[^a-zA-Z0-9_\-\:\.\|]/', '', $session_id );

		return substr( (string) $session_id, 0, 191 );
	}

    /**
     * Sign session ID
     *
     * Adds HMAC signature to prevent tampering
     */

	private function sign_session_id( string $raw_id, int $user_id ): string {
		$raw_id = strtolower( $raw_id );
        $user_id = absint( $user_id );

        $payload = $raw_id . '|' . $user_id;
        $hash = hash_hmac( 'sha256', $payload, wp_salt( 'auth' ) );

        return $payload . ':' . $hash;
	}

    /**
     * Validate signed session ID
     *
     * Ensures:
     * - integrity
     * - authenticity
     */

     private function is_valid_signed_session_id( string $session_id ): bool {
        if( ! str_contains( $session_id, ':' ) ) {
            return false;
        }

        list( $payload, $hash ) = explode( ':', $session_id, 2 );

        if( ! str_contains( $payload, '|' ) ) {
            return false;
        }

        list( $raw_id, $user_id ) = explode( '|', $payload, 2 );

        $raw_id = trim($raw_id);
        $user_id = absint( $user_id );

        // USER BINDING CHECK
		// SECURITY INVARIANT: A valid HMAC is not transferable between accounts; the
		// signed payload must name the currently authenticated user before comparison.
        if( $user_id !== get_current_user_id() ) {
            return false;
        }

        $expected = hash_hmac(
            'sha256',
            $raw_id . '|' . $user_id,
            wp_salt( 'auth' )
        );

		// SECURITY INVARIANT: Presence accepts only a session ID whose exact normalized
		// identifier and user binding are authenticated by the WordPress auth salt.
		return hash_equals( $expected, $hash );
    }

}
