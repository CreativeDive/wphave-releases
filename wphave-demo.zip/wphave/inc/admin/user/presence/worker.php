<?php

/**
 * Presence background-worker entrypoint.
 *
 * WORKER INVARIANT: Persisted Presence cleanup events must enter through a
 * canonical feature-loader boundary. The shared composition registers only the
 * cleanup callback during Cron and therefore does not expose interactive REST
 * routes in the worker runtime.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/functions.php';
