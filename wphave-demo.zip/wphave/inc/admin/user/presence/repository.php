<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_User_Presence_Repository {

    /**
     * Check whether the presence table exists.
     *
     * @return bool True when the table exists.
     */

	private function table_exists(): bool {
		return WPHAVE_Database_Metadata::table_exists( $this->table );
	}

    /**
     * Public schema validator for the central database schema manager.
     *
     * @return bool True when the presence table exists.
     */

	public function schema_ready(): bool {
		return $this->table_exists() && $this->required_columns_exist();
	}

    /**
     * Low-level presence write
     *
     * Behavior:
     * - Upserts presence entry (session-based)
     * - Updates timestamp (heartbeat)
     * - Invalidates cache
     *
     * Important:
     * - Must be fast (called frequently)
     * - No heavy logic here
     */

	public function set_presence( string $room, string $session_id, array $data = array(), int $user_id = 0 ): bool {
		global $wpdb;

		$room = $this->sanitize_room( $room );
		$session_id = $this->sanitize_session_id( $session_id );
		$user_id = absint( $user_id ?: get_current_user_id() );
		$data = $this->sanitize_data( $data );

		if( ! $room || ! $session_id || ! $user_id ) {
			return false;
		}

		if( ! $this->is_valid_signed_session_id( $session_id ) ) {
			return false;
		}

		$json = wp_json_encode( $data );

		if( false === $json || strlen( $json ) > 2000 ) {
			$json = '{}';
		}

		$now = gmdate( 'Y-m-d H:i:s' );

		$result = $wpdb->query(
			$wpdb->prepare(
				"INSERT INTO {$this->table} (room, session_id, user_id, data, date_gmt)
				VALUES (%s, %s, %d, %s, %s)
				ON DUPLICATE KEY UPDATE
					user_id = VALUES(user_id),
					data = VALUES(data),
					date_gmt = VALUES(date_gmt)",
				$room,
				$session_id,
				$user_id,
				$json,
				$now
			)
		);

		if( false !== $result ) {
			$this->delete_presence_cache( $room );
		}

		return false !== $result;
	}

    /**
     * Get presence entries for a room
     *
     * Behavior:
     * - Uses object cache (fast)
     * - Falls back to DB query if needed
     * - Only returns recent entries (TTL)
     * - Hard limited to MAX_ENTRIES for performance
     *
     * Important:
     * - This is called frequently (polling / SSE)
     * - Must be extremely fast
     */

	public function get_presence( string $room, bool $force_refresh = false ): array {
		global $wpdb;

		$room = $this->sanitize_room( $room );

		if( ! $room ) {
			return array();
		}

		$cache_key = $this->get_presence_cache_key( $room );

		if( ! $force_refresh ) {
			$cached = wp_cache_get( $cache_key, 'wphave_presence' );

			if( is_array( $cached ) ) {
				return $cached;
			}
		}

		$cutoff = gmdate( 'Y-m-d H:i:s', time() - $this->get_ttl() );

        /**
         * LIMIT "LIMIT %d" is critical:
         * - prevents large datasets
         * - ensures constant query time
         */

		$rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT room, session_id, user_id, data, date_gmt
                FROM {$this->table}
                WHERE room = %s
                AND date_gmt > %s
                ORDER BY date_gmt DESC
                LIMIT %d",
                $room,
                $cutoff,
                self::MAX_ENTRIES
            ),
            ARRAY_A
        );

		if( ! $rows ) {
			wp_cache_set( $cache_key, array(), 'wphave_presence', self::CACHE_TTL );
			return array();
		}

		$entries = array_map( array( $this, 'normalize_row' ), $rows );

		wp_cache_set( $cache_key, $entries, 'wphave_presence', self::CACHE_TTL );

		return $entries;
	}

    public function get_active_rooms(): array {
		global $wpdb;

		$cutoff = gmdate( 'Y-m-d H:i:s', time() - $this->get_ttl() );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT room, COUNT(*) AS entries, COUNT(DISTINCT user_id) AS users, MAX(date_gmt) AS last_seen_gmt
				FROM {$this->table}
				WHERE date_gmt > %s
				GROUP BY room
				ORDER BY last_seen_gmt DESC",
				$cutoff
			),
			ARRAY_A
		);

		if( ! $rows ) {
			return array();
		}

		return array_map(
			static function ( array $row ): array {
				return array(
					'room' => (string) $row['room'],
					'entries' => absint( $row['entries'] ),
					'users' => absint( $row['users'] ),
					'last_seen_gmt' => (string) $row['last_seen_gmt'],
				);
			},
			$rows
		);
	}

    /**
     * Remove a single presence entry
     *
     * Also clears cache for the room
     */

	public function remove_presence( string $room, string $session_id ): bool {
		global $wpdb;

		$room = $this->sanitize_room( $room );
		$session_id = $this->sanitize_session_id( $session_id );

		if( ! $room || ! $session_id ) {
			return false;
		}

		$result = $wpdb->delete(
			$this->table,
			array(
				'room'       => $room,
				'session_id' => $session_id,
			),
			array( '%s', '%s' )
		);

		if( false !== $result ) {
			$this->delete_presence_cache( $room );
		}

		return false !== $result;
	}

    /**
     * Remove all presence entries for a user
     *
     * Useful for:
     * - logout
     * - forced cleanup
     */

	public function remove_user_presence( int $user_id ): bool {
		global $wpdb;

		$result = $wpdb->delete(
			$this->table,
			array( 'user_id' => absint( $user_id ) ),
			array( '%d' )
		);

		return false !== $result;
	}

    /**
     * Cleanup expired presence entries
     *
     * Runs via cron:
     * - deletes entries older than TTL
     * - limited batch size for performance
     */

     public function delete_expired(): ?int {
        global $wpdb;

        $total_deleted = 0;
        $cutoff = gmdate( 'Y-m-d H:i:s', time() - $this->get_ttl() );

        for( $batch = 0; $batch < self::CLEANUP_MAX_BATCHES; $batch++ ) {
            $deleted = $wpdb->query(
                $wpdb->prepare(
                    "DELETE FROM {$this->table}
                    WHERE date_gmt < %s
                    LIMIT %d",
                    $cutoff,
                    self::CLEANUP_BATCH_SIZE
                )
            );

            /*
             * RESILIENCE INVARIANT: A partial count followed by a database error
             * is an unknown cleanup result, not a successful partial batch. The
             * minutely worker will retry without allowing one run to grow unbounded.
             */
            if( false === $deleted ) {
                return null;
            }

            $total_deleted += $deleted;

            if( self::CLEANUP_BATCH_SIZE !== $deleted ) {
                break;
            }
        }

        return $total_deleted;
    }

        /**
     * Check if user can access a room
     *
     * Rules:
     * - must be logged in
     * - must have edit_posts capability
     * - optional post-based permission check
     *
     * Filterable via:
     * - wphave_presence_can_access_room
     */

	public function can_access_room( string $room, int $user_id = 0 ): bool {
		$room = $this->sanitize_room( $room );
		$user_id = absint( $user_id ?: get_current_user_id() );

		if( ! $room || ! $user_id || ! user_can( $user_id, 'edit_posts' ) ) {
			return false;
		}

		$can_access = true;
		$post_id = $this->extract_post_id_from_room( $room );

		if( $post_id ) {
			// AUTHORIZATION INVARIANT: Knowledge of a collaboration room name is not
			// authority to observe its occupants. Post-backed rooms inherit edit_post
			// from the exact document for every read, write and streaming request.
			$can_access = user_can( $user_id, 'edit_post', $post_id );
		}

		return (bool) apply_filters(
			'wphave_presence_can_access_room',
			$can_access,
			$room,
			$user_id,
			$post_id
		);
	}

    /**
     * Generate room identifier for a post
     *
     * Format:
     * - postType/{type}:{id}
     */

	public function post_room( int|WP_Post $post ): string {
		$post = get_post( $post );

		if( ! $post ) {
			return '';
		}

		return 'postType/' . sanitize_key( $post->post_type ) . ':' . absint( $post->ID );
	}

    /**
     * Sanitize room identifier
     *
     * Ensures:
     * - safe characters only
     * - max length (191)
     */

	public function sanitize_room( string $room ): string {
		$room = trim( wp_unslash( $room ) );
		$room = preg_replace( '/[^a-zA-Z0-9_\-\/:\.]/', '', $room );

		return substr( (string) $room, 0, 191 );
	}

    /**
     * Normalize DB row to API format
     *
     * Converts:
     * - JSON data → array
     * - date → ISO8601
     */

	private function normalize_row( array $row ): array {
		$data = json_decode( (string) $row['data'], true );

		return array(
			'room' => (string) $row['room'],
			'session_id' => (string) $row['session_id'],
			'user_id' => absint( $row['user_id'] ),
			'data' => is_array( $data ) ? $data : array(),
			'date_gmt' => gmdate( 'c', strtotime( $row['date_gmt'] ) ),
		);
	}

    /**
     * Extract post ID from room string
     *
     * Format:
     * - postType/{type}:{id}
     */

	private function extract_post_id_from_room( string $room ): int {
		if( preg_match( '#^postType/[a-zA-Z0-9_\-]+:(\d+)$#', $room, $matches ) ) {
			return absint( $matches[1] );
		}

		return 0;
	}

    /**
     * Generate cache key for room
     */

	private function get_presence_cache_key( string $room ): string {
		return 'room_' . md5( $room );
	}

    /**
     * Delete cached presence for room
     */

	private function delete_presence_cache( string $room ): void {
		wp_cache_delete( $this->get_presence_cache_key( $room ), 'wphave_presence' );
	}

}
