<?php

/**
 * Isolate one responsibility of the public facade.
 */

trait WPHAVE_User_Presence_REST {

    /**
     * Register all REST API endpoints
     *
     * Includes:
     * - presence (GET / POST / DELETE)
     * - session creation
     * - room listing
     * - optional SSE stream
     */

	public function register_rest_routes(): void {
		register_rest_route( 'wphave/v1', '/presence', array(
            array(
                'methods' => WP_REST_Server::READABLE,
                'callback' => array( $this, 'rest_get_presence' ),
                'permission_callback' => array( $this, 'rest_can_read' ),
                'args' => array(
                    'room' => array(
                        'required' => true,
                        'type' => 'string',
                        'sanitize_callback' => array( $this, 'sanitize_room' ),
                    ),
                ),
            ),
            array(
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => array( $this, 'rest_set_presence' ),
                'permission_callback' => array( $this, 'rest_can_write' ),
                'args' => array(
                    'room' => array(
                        'required' => true,
                        'type' => 'string',
                        'sanitize_callback' => array( $this, 'sanitize_room' ),
                    ),
                    'session_id' => array(
                        'required' => true,
                        'type' => 'string',
                        'sanitize_callback' => array( $this, 'sanitize_session_id' ),
                    ),
                    'data' => array(
                        'required' => false,
                        'type' => 'object',
                        'default' => array(),
                    ),
                ),
            ),
            array(
                'methods' => WP_REST_Server::DELETABLE,
                'callback' => array( $this, 'rest_remove_presence' ),
                'permission_callback' => array( $this, 'rest_can_write' ),
                'args' => array(
                    'room' => array(
                        'required' => true,
                        'type' => 'string',
                        'sanitize_callback' => array( $this, 'sanitize_room' ),
                    ),
                    'session_id' => array(
                        'required' => true,
                        'type' => 'string',
                        'sanitize_callback' => array( $this, 'sanitize_session_id' ),
                    ),
                ),
            ),
        ));

		register_rest_route( 'wphave/v1', '/presence/session', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array( $this, 'rest_create_session' ),
            'permission_callback' => array( $this, 'rest_can_create_session' ),
        ));

		register_rest_route( 'wphave/v1', '/presence/rooms', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array( $this, 'rest_get_rooms' ),
            'permission_callback' => array( $this, 'rest_can_read_rooms' ),
        ));

        if ( $this->is_sse_enabled() ) {
            register_rest_route( 'wphave/v1', '/presence/stream', array(
                'methods' => WP_REST_Server::READABLE,
                'callback' => array( $this, 'rest_stream_presence' ),
                'permission_callback' => array( $this, 'rest_can_read' ),
                'args' => array(
                    'room' => array(
                        'required' => true,
                        'type' => 'string',
                        'sanitize_callback' => array( $this, 'sanitize_room' ),
                    ),
                ),
            ));
        }
	}

    /**
     * REST: Create presence session
     *
     * Returns:
     * - signed session_id (tamper-proof)
     */

     public function rest_create_session( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        // AUTHORIZATION INVARIANT: A signed Presence session delegates identity
        // inside collaborative workspace rooms. Route dispatch is not authority;
        // the callback repeats edit_posts before issuing that credential.
        if ( ! $this->rest_can_create_session() ) {
            return new WP_Error(
                'wphave_presence_forbidden',
                'You cannot create a presence session.',
                array( 'status' => 403 )
            );
        }

        $user_id = get_current_user_id();

        if ( ! $user_id ) {
            return new WP_Error(
                'wphave_presence_no_user',
                'User required for session.',
                array( 'status' => 401 )
            );
        }

        $raw_id = wp_generate_uuid4();
        $session_id = $this->sign_session_id( $raw_id, $user_id );

        return rest_ensure_response(
            array(
                'session_id' => $session_id,
            )
        );
    }

    /**
     * REST: Fetch presence data for a room
     *
     * Returns:
     * - current entries
     * - TTL info
     *
     * Uses cache internally for performance
     */

	public function rest_get_presence( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$room = $this->sanitize_room( (string) $request->get_param( 'room' ) );

		if( ! $this->can_access_room( $room ) ) {
			return new WP_Error( 'wphave_presence_forbidden', 'You cannot access this presence room.', array( 'status' => 403 ) );
		}

		$ttl = $this->get_ttl();
		$entries = $this->get_presence( $room );
		$supports_sse = $this->is_sse_enabled();

		// AUTHORIZATION/TOCTOU INVARIANT: Presence resolution crosses cache,
		// database, TTL and SSE extension points. Exact room authority must still
		// exist immediately before occupant and session metadata is disclosed.
		if ( ! $this->can_access_room( $room ) ) {
			return new WP_Error( 'wphave_presence_forbidden', 'You cannot access this presence room.', array( 'status' => 403 ) );
		}

		return rest_ensure_response(
			array(
				'room' => $room,
				'ttl' => $ttl,
				'entries' => $entries,
                'supports_sse' => $supports_sse,
			)
		);
	}

    /**
     * REST: Write presence (heartbeat / activity update)
     *
     * IMPORTANT:
     * - This endpoint is "best effort"
     * - It must NEVER block or break UI
     * - Rate limiting is soft (no 429 errors)
     *
     * Behavior:
     * - Updates or inserts current session
     * - Returns minimal response (no entries)
     */

	public function rest_set_presence( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		// AUTHORIZATION INVARIANT: A presence write requires both current room access
		// and a server-signed session identity. The repository revalidates the signature
		// at persistence time; a client-chosen session string cannot impersonate a peer.
		$room = $this->sanitize_room( (string) $request->get_param( 'room' ) );
		$session_id = $this->sanitize_session_id( (string) $request->get_param( 'session_id' ) );
		$data = $request->get_param( 'data' );

		if( ! $room || ! $session_id ) {
			return new WP_Error( 'wphave_presence_invalid_request', 'Room and session_id are required.', array( 'status' => 400 ) );
		}

		if( ! $this->can_access_room( $room ) ) {
			return new WP_Error( 'wphave_presence_forbidden', 'You cannot access this presence room.', array( 'status' => 403 ) );
		}

        /**
         * Soft rate limiting:
         * - No hard error (429)
         * - Prevents flooding without breaking UX
         */

        if( ! $this->passes_rate_limit( $session_id ) ) {
            return rest_ensure_response(
                array(
                    'success' => false,
                    'rate_limited' => true,
                    'room' => $room,
                )
            );
        }

		$data = is_array( $data ) ? $this->sanitize_data( $data ) : array();

		// AUTHORIZATION/TOCTOU INVARIANT: Room admission is filterable and precedes
		// rate limiting plus payload normalization. Re-evaluate the exact room and
		// object authority immediately before the canonical Presence database write.
		if ( ! $this->can_access_room( $room ) ) {
			return new WP_Error( 'wphave_presence_forbidden', 'You cannot access this presence room.', array( 'status' => 403 ) );
		}

		$ok = $this->set_presence(
			$room,
			$session_id,
			$data,
			get_current_user_id()
		);

		if( ! $ok ) {
			return new WP_Error( 'wphave_presence_write_failed', 'Could not update presence.', array( 'status' => 500 ) );
		}

		return rest_ensure_response(
            array(
                'success' => true,
                'room' => $room,
            )
        );
	}

    /**
     * REST: Remove presence entry
     *
     * Used when:
     * - user leaves page
     * - session is destroyed
     */

	public function rest_remove_presence( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$room = $this->sanitize_room( (string) $request->get_param( 'room' ) );
		$session_id = $this->sanitize_session_id( (string) $request->get_param( 'session_id' ) );

		if( ! $room || ! $session_id ) {
			return new WP_Error( 'wphave_presence_invalid_request', 'Room and session_id are required.', array( 'status' => 400 ) );
		}

		if( ! $this->is_valid_signed_session_id( $session_id ) ) {
			return new WP_Error( 'wphave_presence_invalid_session', 'Invalid presence session.', array( 'status' => 400 ) );
		}

		if( ! $this->can_access_room( $room ) ) {
			return new WP_Error( 'wphave_presence_forbidden', 'You cannot access this presence room.', array( 'status' => 403 ) );
		}

		// AUTHORIZATION/TOCTOU INVARIANT: A valid signed session identifies the
		// caller but does not preserve room authority. Recheck the exact room after
		// every filterable admission step and immediately before deleting its row.
		if ( ! $this->can_access_room( $room ) ) {
			return new WP_Error( 'wphave_presence_forbidden', 'You cannot access this presence room.', array( 'status' => 403 ) );
		}

		// DATA/COMMIT INVARIANT: Leaving an already-empty room is idempotent, but
		// a database failure must remain distinguishable from zero affected rows;
		// never publish successful departure while canonical Presence state is unknown.
		if( ! $this->remove_presence( $room, $session_id ) ) {
			return new WP_Error(
				'wphave_presence_delete_failed',
				'Could not remove presence.',
				array( 'status' => 500 )
			);
		}

		return rest_ensure_response(
			array(
				'success' => true,
				'room' => $room,
			)
		);
	}

    /**
     * REST: Get active rooms overview
     *
     * Returns:
     * - rooms with counts and last activity
     */

     public function rest_get_rooms( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        // PRIVACY INVARIANT: The active-room catalog reveals collaborative
        // workspace activity across objects. Repeat edit_posts at the data sink;
        // a route permission callback alone never authorizes this disclosure.
        if ( ! $this->rest_can_read_rooms() ) {
            return new WP_Error(
                'wphave_presence_forbidden',
                'You cannot inspect presence rooms.',
                array( 'status' => 403 )
            );
        }

        $rooms = array_values(
            array_filter(
                $this->get_active_rooms(),
                function( $room ) {
                    // PRIVACY/OBJECT INVARIANT: General workspace admission never
                    // reveals a post-backed room. Each catalog row must satisfy the
                    // same exact-object policy as polling, writes and SSE streaming.
                    return is_array( $room )
                        && $this->can_access_room( (string) ( $room['room'] ?? '' ) );
                }
            )
        );

		// AUTHORIZATION/TOCTOU INVARIANT: Per-room filters may change authority
		// after an earlier row was admitted. Recheck global catalog authority after
		// the complete object pass and immediately before disclosing any room row.
		if ( ! $this->rest_can_read_rooms() ) {
			return new WP_Error(
				'wphave_presence_forbidden',
				'You cannot inspect presence rooms.',
				array( 'status' => 403 )
			);
		}

        return rest_ensure_response(
            array(
                'ttl' => $this->get_ttl(),
                'rooms' => $rooms,
            )
        );
    }

    /**
     * Permission: Create session
     */

	public function rest_can_create_session(): bool {
		return current_user_can( 'edit_posts' );
	}

    /**
     * Permission: Read presence
     */

	public function rest_can_read( WP_REST_Request $request ): bool {
		$room = $this->sanitize_room( (string) $request->get_param( 'room' ) );

		return $this->can_access_room( $room );
	}

    /**
     * Permission: Write presence
     */

	public function rest_can_write( WP_REST_Request $request ): bool {
		$room = $this->sanitize_room( (string) $request->get_param( 'room' ) );

		return $this->can_access_room( $room );
	}

    /**
     * Permission: Read rooms overview
     */

	public function rest_can_read_rooms(): bool {
		return current_user_can( 'edit_posts' );
	}

    /**
     * SSE Stream (optional)
     *
     * IMPORTANT:
     * - Disabled by default (shared hosting unsafe)
     * - Can block PHP workers
     * - Should only be enabled on capable servers
     *
     * Behavior:
     * - Sends updates every SSE_INTERVAL seconds
     * - Stops after SSE_MAX_TIME
     * - Uses hash comparison to avoid unnecessary updates
     */

    public function rest_stream_presence( WP_REST_Request $request ): void {
        // Safety: Allow SSE only in genuine HTTP requests
        if( wp_doing_cron() || wp_doing_ajax() ) {
            status_header( 400 );
            exit;
        }

        $room = $this->sanitize_room( (string) $request->get_param( 'room' ) );

        if( ! $this->can_access_room( $room ) ) {
            status_header( 403 );
            exit;
        }

        // Disable buffering
        if( function_exists( 'apache_setenv' ) ) {
            apache_setenv( 'no-gzip', '1' );
        }

        @ini_set( 'zlib.output_compression', '0' );
        @ini_set( 'implicit_flush', '1' );

        $max_time = (int) ini_get('max_execution_time');

        if( $max_time !== 0 && $max_time < 30 ) {
            status_header(500);
            exit;
        }

        nocache_headers();

        header( 'Content-Type: text/event-stream; charset=utf-8' );
        header( 'Cache-Control: no-cache, no-transform' );
        header( 'Connection: keep-alive' );
        header( 'X-Accel-Buffering: no' );

        while( ob_get_level() > 0 ) {
            @ob_end_flush();
        }

        echo "retry: 3000\n\n";

        $last_hash = null;
        $started = time();

        while( ! connection_aborted() && ( time() - $started ) < self::SSE_MAX_TIME ) {
            $entries = $this->get_presence( $room, true );

            $payload = array(
                'room' => $room,
                'entries' => $entries,
                'ttl' => $this->get_ttl(),
            );

            $json = wp_json_encode( $payload );
            $hash = crc32( $json );

            if( $hash !== $last_hash ) {
                echo "event: presence\n";
                echo 'data: ' . $json . "\n\n";

                $last_hash = $hash;
            } else {
                echo ": ping\n\n";
            }

            @ob_flush();
            flush();

            sleep( self::SSE_INTERVAL );
        }

        exit;
    }

}
