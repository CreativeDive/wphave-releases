<?php

/**
 * Class to manage user roles access to WPHAVE features.
 */

if( ! defined('ABSPATH') ) {
	exit;
}

class WPHAVE_Access_Manager {

    /**
     * Register the component hooks.
     *
     *  - Injects dynamic feature capabilities via `user_has_cap`
     *  - Registers REST API routes for feature and role access data
     */

	public static function init() {
		add_filter('user_has_cap', [__CLASS__, 'inject_dynamic_caps'], 20, 4);
		add_filter('rest_pre_dispatch', [__CLASS__, 'guard_core_pattern_routes'], 10, 3);
		add_filter('rest_pre_dispatch', [__CLASS__, 'guard_core_design_resource_routes'], 10, 3);
		add_action('rest_api_init', [__CLASS__, 'register_rest_routes']);
	}

	/**
	 * Apply the WPHAVE Pattern grant to the WordPress Core pattern endpoints.
	 *
	 * Core reusable patterns use the shared edit_posts capabilities. Restricted
	 * WPHAVE users must not be able to bypass the app feature map by requesting
	 * the Core block or pattern-category routes directly.
	 *
	 * @param mixed           $result  Pre-dispatch result.
	 * @param WP_REST_Server  $server  REST server instance.
	 * @param WP_REST_Request $request Current request.
	 * @return mixed|WP_Error
	 */
	public static function guard_core_pattern_routes( $result, $server, $request ) {
		// AUTHORIZATION INVARIANT: Core REST routes are an alternate entry point into
		// WPHAVE-managed patterns. They must enforce the same dedicated capability as
		// the Workspace instead of inheriting generic post editing rights.
		if( ! $request instanceof WP_REST_Request ) return $result;
		$route = (string) $request->get_route();
		if( ! preg_match( '#^/wp/v2/(?:blocks|wp_pattern_category)(?:/|$)#', $route ) ) return $result;
		if( ! is_user_logged_in() ) return new WP_Error( 'wphave_pattern_authentication_required', __( 'Authentication is required to access patterns.', 'wphave' ), array( 'status' => 401 ) );

		$user = wp_get_current_user();
		if( empty( $user->allcaps['wphave_access'] ) || ! empty( $user->allcaps['manage_options'] ) || current_user_can( 'wphave_manage_patterns' ) ) return $result;

		return new WP_Error( 'wphave_pattern_access_denied', __( 'You are not allowed to access patterns.', 'wphave' ), array( 'status' => 403 ) );
	}

	/**
	 * Protect WPHAVE design post types where Core collection reads are permissive.
	 *
	 * @param mixed           $result  Pre-dispatch result.
	 * @param WP_REST_Server  $server  REST server instance.
	 * @param WP_REST_Request $request Current request.
	 * @return mixed|WP_Error
	 */
	public static function guard_core_design_resource_routes( $result, $server, $request ) {
		if( is_wp_error( $result ) || ! $request instanceof WP_REST_Request ) return $result;
		$route = (string) $request->get_route();
		$is_css_class_route = (bool) preg_match( '#^/wp/v2/wphave-css-classes(?:/|$)#', $route );
		$capability = '';
		if( preg_match( '#^/wp/v2/wphave-block-styles(?:/|$)#', $route ) ) $capability = 'wphave_manage_block_styles';
		if( $is_css_class_route ) $capability = 'wphave_manage_css_classes';
		if( ! $capability ) return $result;
		if( ! is_user_logged_in() ) return new WP_Error( 'wphave_design_resource_authentication_required', __( 'Authentication is required to access design resources.', 'wphave' ), array( 'status' => 401 ) );
		$can_manage = current_user_can( $capability ) || current_user_can( 'wphave_manage_options' ) || current_user_can( 'manage_options' );
		if( ! $can_manage ) return new WP_Error( 'wphave_design_resource_access_denied', __( 'You are not allowed to access this design resource.', 'wphave' ), array( 'status' => 403 ) );
		if( $is_css_class_route && ! in_array( $request->get_method(), array( 'GET', 'HEAD', 'OPTIONS', 'DELETE' ), true ) && ( ! function_exists( 'wphave_has_pro_access' ) || ! wphave_has_pro_access() ) ) {
			$status_only = class_exists( 'WPHAVE_CSS_Class_Manager' ) && WPHAVE_CSS_Class_Manager::is_status_only_request( $request );
			if( ! $status_only ) return new WP_Error( 'wphave_css_class_pro_required', __( 'A Pro license is required to change reusable CSS classes.', 'wphave' ), array( 'status' => 403 ) );
		}
		return $result;
	}

    /**
     * Ensures that a default feature access map is stored in the
     * feature settings if none exists yet.
     *
     * This is required for first-time usage of the system to avoid
     * empty permissions which would result in no accessible features.
     *
     * The defaults are only applied once and will not override
     * existing configurations.
     */

    public static function maybe_init_defaults() {
		$data = wphave_data_get( 'access_settings' );

		// Missing settings receive the product defaults once. An explicitly empty
		// map is a valid deny-all policy and must never be repopulated implicitly.
		if ( ! array_key_exists( 'features', $data ) ) {
			wphave_data_set( 'access_settings', 'features', self::get_default_role_feature_access() );
		}

		if ( ! array_key_exists( 'editorMode', $data ) ) {
			wphave_data_set( 'access_settings', 'editorMode', self::get_default_role_editor_modes() );
		}

		if ( ! array_key_exists( 'canChangeLayout', $data ) ) {
			wphave_data_set( 'access_settings', 'canChangeLayout', self::get_default_role_layout_access() );
		}
    }

	/**
	 *  `wphave/register_features` filter.
	 *
	 * @return array
	 */

	public static function get_features() {
		$features = [
			[
				'id'          => 'wphave_view_activity_log',
				'label'       => __('Activity Log', 'wphave'),
				'description' => __('View recorded user, content, configuration, and system activity.', 'wphave'),
				'group'       => 'system',
			],
			[
				'id'          => 'wphave_manage_activity_log',
				'label'       => __('Manage Activity Log', 'wphave'),
				'description' => __('Change activity retention settings and permanently clear recorded activity.', 'wphave'),
				'group'       => 'system',
			],
			[
				'id'          => 'wphave_manage_content_types',
				'label'       => __('Content Types', 'wphave'),
				'description' => __('Create and configure custom post types and taxonomies.', 'wphave'),
				'group'       => 'content-management',
			],
			[
				'id'          => 'wphave_view_content_models',
				'label'       => __('View Content Fields', 'wphave'),
				'description' => __('View Content Field groups and their schemas.', 'wphave'),
				'group'       => 'content-management',
			],
			[
				'id'          => 'wphave_edit_content_models',
				'label'       => __('Edit Content Fields', 'wphave'),
				'description' => __('Create, edit, and archive Content Field groups.', 'wphave'),
				'group'       => 'content-management',
			],
			[
				'id'          => 'wphave_activate_content_models',
				'label'       => __('Activate Content Fields', 'wphave'),
				'description' => __('Activate schemas that become available to content editors.', 'wphave'),
				'group'       => 'content-management',
			],
			[
				'id'          => 'wphave_edit_content_model_values',
				'label'       => __('Edit Content Field Values', 'wphave'),
				'description' => __('Edit assigned Content Field values on content you can edit.', 'wphave'),
				'group'       => 'editor',
			],
            // Components
			[
				'id'          => 'wphave_manage_patterns',
				'label'       => __('Patterns', 'wphave'),
				'description' => __('Create and manage reusable patterns.', 'wphave'),
				'group'       => 'components',
			],
			[
				'id'          => 'wphave_manage_forms',
				'label'       => __('Forms', 'wphave'),
				'description' => __('Create and manage website forms.', 'wphave'),
				'group'       => 'components',
			],
			[
				'id'          => 'wphave_manage_notes',
				'label'       => __('Notes', 'wphave'),
				'description' => __('Create and manage internal website notes.', 'wphave'),
				'group'       => 'content-management',
			],
            // Structure
			[
				'id'          => 'wphave_manage_navigations',
				'label'       => __('Navigations', 'wphave'),
				'description' => __('Create and manage website navigations.', 'wphave'),
				'group'       => 'structure',
			],
			[
				'id'          => 'wphave_manage_templates',
				'label'       => __('Templates', 'wphave'),
				'description' => __('Create and manage website templates.', 'wphave'),
				'group'       => 'structure',
			],
			[
				'id'          => 'wphave_manage_template_parts',
				'label'       => __('Template Parts', 'wphave'),
				'description' => __('Create and manage shared structural parts for your website.', 'wphave'),
				'group'       => 'structure',
			],
			[
				'id'          => 'wphave_manage_addons',
				'label'       => __('Add-Ons', 'wphave'),
				'description' => __('View and manage WPHAVE add-ons.', 'wphave'),
				'group'       => 'components',
			],
            // Settings
[
    'id'          => 'wphave_manage_settings',
    'label'       => __('Settings', 'wphave'),
    'description' => __('Access all WPHAVE settings areas.', 'wphave'),
    'group'       => 'settings',
],
			[
				'id'          => 'wphave_manage_settings_general',
				'label'       => __('General Settings', 'wphave'),
				'description' => __('Manage general website settings.', 'wphave'),
				'group'       => 'settings',
			],
			[
				'id'          => 'wphave_manage_settings_brand',
				'label'       => __('Brand Settings', 'wphave'),
				'description' => __('Manage website identity and brand settings.', 'wphave'),
				'group'       => 'settings',
			],
			[
				'id'          => 'wphave_manage_settings_fonts',
				'label'       => __('Font Settings', 'wphave'),
				'description' => __('Manage fonts, font loading, and typography resources.', 'wphave'),
				'group'       => 'settings',
			],
			[
				'id'          => 'wphave_manage_settings_icons',
				'label'       => __('Icon Settings', 'wphave'),
				'description' => __('Manage icon libraries and icon settings.', 'wphave'),
				'group'       => 'settings',
			],
			[
				'id'          => 'wphave_manage_settings_social',
				'label'       => __('Social Settings', 'wphave'),
				'description' => __('Manage social profiles and social settings.', 'wphave'),
				'group'       => 'settings',
			],
			[
				'id'          => 'wphave_manage_settings_media',
				'label'       => __('Media Settings', 'wphave'),
				'description' => __('Manage media handling and upload settings.', 'wphave'),
				'group'       => 'settings',
			],
			[
				'id'          => 'wphave_manage_settings_seo',
				'label'       => __('SEO Settings', 'wphave'),
				'description' => __('Manage website-wide search engine settings.', 'wphave'),
				'group'       => 'settings',
			],
			[
				'id'          => 'wphave_manage_settings_schema',
				'label'       => __('Schema Settings', 'wphave'),
				'description' => __('Manage website-wide structured data settings.', 'wphave'),
				'group'       => 'settings',
			],
			[
				'id'          => 'wphave_manage_settings_forms',
				'label'       => __('Forms Settings', 'wphave'),
				'description' => __('Manage site-wide form delivery defaults.', 'wphave'),
				'group'       => 'settings',
			],
			[
				'id'          => 'wphave_manage_settings_mail',
				'label'       => __('Mail Settings', 'wphave'),
				'description' => __('Manage outgoing email and SMTP settings.', 'wphave'),
				'group'       => 'settings',
			],
			[
				'id'          => 'wphave_manage_settings_security',
				'label'       => __('Security Settings', 'wphave'),
				'description' => __('Manage website security settings and protections.', 'wphave'),
				'group'       => 'settings',
			],
			[
				'id'          => 'wphave_manage_settings_privacy',
				'label'       => __('Privacy Settings', 'wphave'),
				'description' => __('Manage privacy, consent, and related compliance settings.', 'wphave'),
				'group'       => 'settings',
			],
			[
				'id'          => 'wphave_manage_settings_tracking',
				'label'       => __('Tracking Settings', 'wphave'),
				'description' => __('Manage analytics, tracking, and URL parameter settings.', 'wphave'),
				'group'       => 'settings',
			],
			[
				'id'          => 'wphave_manage_settings_editor',
				'label'       => __('Editor Settings', 'wphave'),
				'description' => __('Manage global block availability and reusable editor presets.', 'wphave'),
				'group'       => 'settings',
			],
			[
				'id'          => 'wphave_manage_settings_ai',
				'label'       => __('AI Settings', 'wphave'),
				'description' => __('Manage AI providers, models, and related settings.', 'wphave'),
				'group'       => 'settings',
			],
            // Tools
            [
                'id'          => 'wphave_manage_image_regeneration',
                'label'       => __('Image Regeneration', 'wphave'),
                'description' => __('Regenerate image sizes for existing media.', 'wphave'),
				'group'       => 'tools',
            ],[
                'id'          => 'wphave_manage_screenshots',
                'label'       => __('Take Screenshots', 'wphave'),
                'description' => __('Create screenshots of website pages.', 'wphave'),
				'group'       => 'tools',
            ],
            [
                'id'          => 'wphave_manage_transients',
                'label'       => __('Transient Manager', 'wphave'),
                'description' => __('View and manage temporary WordPress data stored as transients.', 'wphave'),
				'group'       => 'technical',
            ],
            [
                'id'          => 'wphave_manage_redirects',
                'label'       => __('Redirect Manager', 'wphave'),
                'description' => __('Create and manage website redirects.', 'wphave'),
				'group'       => 'technical',
            ],
            // Insights
			[
				'id'          => 'view_wphave_analytics',
				'label'       => __('Analytics', 'wphave'),
				'description' => __('View website analytics reports.', 'wphave'),
				'group'       => 'insights',
            ],
            [
                'id'          => 'wphave_view_conversions',
                'label'       => __('Conversions', 'wphave'),
				'description' => __('View conversion reports and conversion-focused insights.', 'wphave'),
                'group'       => 'insights',
            ],
            [
                'id'          => 'wphave_view_engagement',
                'label'       => __('Engagement', 'wphave'),
				'description' => __('View engagement reports across analytics, comments, ratings, likes, and audience signals.', 'wphave'),
                'group'       => 'insights',
            ],
            [
                'id'          => 'wphave_manage_content_audit',
                'label'       => __('Content Audit', 'wphave'),
				'description' => __('Run and review website-wide content audits.', 'wphave'),
                'group'       => 'insights',
            ],
            [
                'id'          => 'wphave_view_audience',
                'label'       => __('Audience', 'wphave'),
				'description' => __('View contacts, leads, subscriptions, attribution, and audience history.', 'wphave'),
                'group'       => 'insights',
            ],
            [
                'id'          => 'wphave_manage_audience',
                'label'       => __('Manage Audience', 'wphave'),
                'description' => __('Edit contacts, leads, pipelines, tags, and notes.', 'wphave'),
                'group'       => 'insights',
            ],
            [
                'id'          => 'wphave_manage_subscriptions',
                'label'       => __('Manage subscriptions', 'wphave'),
                'description' => __('Manage subscription purposes and communication states.', 'wphave'),
                'group'       => 'insights',
            ],
            [
                'id'          => 'wphave_export_audience',
                'label'       => __('Export Audience data', 'wphave'),
                'description' => __('Export personal Audience and lead data.', 'wphave'),
                'group'       => 'insights',
            ],
            [
                'id'          => 'wphave_delete_audience',
                'label'       => __('Delete Audience data', 'wphave'),
                'description' => __('Delete or anonymize contacts, leads, and subscription records.', 'wphave'),
                'group'       => 'insights',
            ],
            [
                'id'          => 'wphave_manage_performance',
                'label'       => __('Optimization', 'wphave'),
				'description' => __('Manage performance settings such as caching and lazy loading.', 'wphave'),
                'group'       => 'settings',
            ],
            [
                'id'          => 'wphave_manage_custom_code',
                'label'       => __('Custom code', 'wphave'),
				'description' => __('Add custom code to the website header and footer.', 'wphave'),
				'group'       => 'technical',
            ],
            // Design
			[
				'id'          => 'wphave_manage_website_planner',
				'label'       => __('Website Planner', 'wphave'),
				'description' => __('Open and manage the Website Planner.', 'wphave'),
				'group'       => 'structure',
			],
			[
				'id'          => 'wphave_manage_global_styles',
				'label'       => __('Global Styles', 'wphave'),
				'description' => __('Manage website-wide colors, typography, spacing, and other global styles.', 'wphave'),
				'group'       => 'design',
			],
			[
				'id'          => 'wphave_manage_block_styles',
				'label'       => __('Block Styles', 'wphave'),
				'description' => __('Create and manage reusable global block styles.', 'wphave'),
				'group'       => 'design',
			],
			[
				'id'          => 'wphave_manage_css_classes',
				'label'       => __('CSS Classes', 'wphave'),
				'description' => __('Create and manage reusable CSS classes.', 'wphave'),
				'group'       => 'design',
			],
			[
				'id'          => 'wphave_manage_block_defaults',
				'label'       => __('Block Type Defaults', 'wphave'),
				'description' => __('Edit default settings for WPHAVE block types.', 'wphave'),
				'group'       => 'design',
			],
            // Editor
			[
				'id'          => 'wphave_manage_seo',
				'label'       => __('Edit Content SEO', 'wphave'),
				'description' => __('Edit page-specific search appearance and SEO settings.', 'wphave'),
				'group'       => 'editor',
			],
			[
				'id'          => 'wphave_manage_schema',
				'label'       => __('Edit Content Schema', 'wphave'),
				'description' => __('Edit page-specific structured data.', 'wphave'),
				'group'       => 'editor',
			],
			[
				'id'          => 'wphave_manage_block_css',
				'label'       => __('Edit Block CSS', 'wphave'),
				'description' => __('Add custom CSS that applies to individual block types.', 'wphave'),
				'group'       => 'editor',
			],
			[
				'id'          => 'wphave_manage_block_classnames',
				'label'       => __('Edit Block Class Names', 'wphave'),
				'description' => __('Add or assign CSS class names to individual blocks in the editor.', 'wphave'),
				'group'       => 'editor',
			],
			[
				'id'          => 'wphave_use_editor_code_view',
				'label'       => __('Editor Code View', 'wphave'),
				'description' => __('Open and edit content using the editor code view.', 'wphave'),
				'group'       => 'editor',
			],
            // System
			[
				'id'          => 'wphave_manage_backups',
				'label'       => __('Backups', 'wphave'),
				'description' => __('Manage backup plans, schedules, restore points, downloads, logs, and notifications.', 'wphave'),
				'group'       => 'system',
			],
			[
				'id'          => 'wphave_manage_license',
				'label'       => __('License Panel', 'wphave'),
				'description' => __('View license status and account information.', 'wphave'),
				'group'       => 'system',
			],
			[
				'id'          => 'wphave_view_system_status',
				'label'       => __('Site Health', 'wphave'),
				'description' => __('View diagnostics and the current website system status.', 'wphave'),
				'group'       => 'system',
			],
            [
				'id'          => 'wphave_create_support_ticket',
				'label'       => __('Support Tickets', 'wphave'),
				'description' => __('Create WPHAVE support tickets for this website.', 'wphave'),
				'group'       => 'system',
			],
		];

		/**
		 * Returns a flat list of all registered feature IDs.
		 *
		 * This is primarily used for validation and filtering to ensure
		 * only valid feature capabilities are processed.
		 *
		 * @return array
		 */

		$features = apply_filters('wphave/register_features', $features);

		$normalized = [];
		foreach( $features as $feature ) {
			if( empty($feature['id']) ) {
				continue;
			}

			$normalized[] = wp_parse_args($feature, [
				'label' => $feature['id'],
				'description' => '',
				'group' => 'general',
			]);
		}

		return $normalized;
	}

    /**
     * Return the feature IDs.
     *
     * @return array
     */

	public static function get_feature_ids() {
		return wp_list_pluck(self::get_features(), 'id');
	}

	/**
	 * Return the default role feature access.
	 *
	 * @return array
	 */

	public static function get_default_role_feature_access() {
		$defaults = [
			'editor' => [
				'wphave_view_content_models',
				'wphave_edit_content_models',
				'wphave_activate_content_models',
				'wphave_edit_content_model_values',
                'wphave_manage_patterns',
                'wphave_manage_block_styles',
                'wphave_manage_css_classes',
                'wphave_manage_forms',
                'wphave_manage_notes',
                'wphave_manage_navigations',
                'wphave_manage_templates',
                'wphave_manage_template_parts',
                'wphave_manage_addons',
                'wphave_manage_website_planner',

                'wphave_manage_settings_brand',
                'wphave_manage_settings_fonts',
                'wphave_manage_settings_icons',
                'wphave_manage_settings_social',
                'wphave_manage_settings_media',
                'wphave_manage_settings_seo',
                'wphave_manage_settings_schema',
				'wphave_manage_settings_forms',
                'wphave_manage_settings_editor',

                'wphave_manage_global_styles',
                'wphave_manage_block_defaults',

                'wphave_manage_screenshots',
                'wphave_manage_seo',
				'wphave_manage_schema',
				'wphave_manage_block_css',
				'wphave_manage_block_classnames',
				'wphave_use_editor_code_view',
			],
			'author' => [
				'wphave_edit_content_model_values',
                'wphave_manage_seo',
				'wphave_manage_schema',
			],
			'contributor' => [
				'wphave_edit_content_model_values',
				'wphave_manage_seo',
				'wphave_manage_schema',
			],
			'wphave_client' => [
                'wphave_manage_settings_brand',
                'wphave_manage_settings_social',
			],
            'wphave_client_pro' => [
                'wphave_manage_forms',
                'wphave_manage_notes',
                'wphave_manage_patterns',
                'wphave_manage_block_styles',
                'wphave_manage_css_classes',

                'wphave_manage_settings_brand',
                'wphave_manage_settings_fonts',
                'wphave_manage_settings_icons',
                'wphave_manage_settings_social',

                'wphave_manage_screenshots',
                'wphave_manage_website_planner',
                'wphave_manage_global_styles',
				'wphave_edit_content_model_values',
				'wphave_manage_seo',
				'wphave_manage_schema',
				'wphave_manage_block_css',
				'wphave_manage_block_classnames',
            ]
		];

		return apply_filters('wphave/default_role_feature_access', $defaults);
	}

	/**
	 * Return the default editor experience for supported roles.
	 *
	 * WordPress roles keep their native publishing authority. These modes only
	 * narrow the WPHAVE editor interface and never elevate WordPress capabilities.
	 *
	 * @return array
	 */
	public static function get_default_role_editor_modes() {
		$defaults = [
			'editor'            => 'design',
			'author'            => 'write',
			'contributor'       => 'write',
			'wphave_client'     => 'view',
			'wphave_client_pro' => 'design',
		];

		return apply_filters( 'wphave/default_role_editor_modes', $defaults );
	}

	/**
	 * Return whether Write mode starts with structural changes unlocked.
	 *
	 * Layout changes are restricted by default. Design mode remains unrestricted
	 * by definition, while administrators bypass the role map entirely.
	 *
	 * @return array
	 */
	public static function get_default_role_layout_access() {
		$defaults = [
			'editor'            => false,
			'author'            => false,
			'contributor'       => false,
			'wphave_client'     => false,
			'wphave_client_pro' => false,
		];

		return apply_filters( 'wphave/default_role_layout_access', $defaults );
	}

    /**
     * Return an all roles.
     *
     * @return array
     */

	public static function get_all_roles() {
		if( ! function_exists('wp_roles') ) {
			return [];
		}

			$wp_roles = wp_roles();
			$result = [];

			foreach( (array) $wp_roles->roles as $role_key => $role_data ) {
				$result[] = [
					'key' => $role_key,
					'label' => isset( $role_data['name'] ) ? $role_data['name'] : $role_key,
	                'description' => wphave_get_role_description( $role_key )
				];
			}

		return $result;
	}

    /**
     * Return an user feature caps.
     *
     * @param WP_User|null $user
     * @return array
     */

	public static function get_user_feature_caps( $user = null ) {
		$user = $user instanceof WP_User ? $user : wp_get_current_user();

        if (!$user || empty($user->ID)) {
            return [];
        }

        return array_values( array_filter(
            self::get_feature_ids(),
            static function ( $capability ) use ( $user ) {
                return user_can( $user, $capability );
            }
        ) );
	}

	/**
	 * Inject the dynamic caps.
	 *
	 *  - Reads feature permissions from feature settings
	 *  - Validates feature IDs
	 *  - Maps them to WordPress capabilities dynamically
	 *
	 * @param array $allcaps
	 * @param array $caps
	 * @param array $args
	 * @param WP_User $user
	 * @return array
	 */

	public static function inject_dynamic_caps( $allcaps, $caps, $args, $user ) {
        if (!$user || empty($user->roles)) {
			return $allcaps;
	}

        if (!empty($allcaps['manage_options']) || !empty($allcaps['wphave_manage_options'])) {
            foreach (self::get_feature_ids() as $cap) {
                $allcaps[$cap] = true;
            }

            return $allcaps;
        }

        if (empty($allcaps['wphave_access'])) {
            return $allcaps;
        }

        $valid_features = self::get_feature_ids();
		$data = wphave_data_get( 'access_settings' );
        $map = $data['features'] ?? [];

        foreach ($user->roles as $role) {
            if (empty($map[$role])) {
                continue;
            }

            foreach ($map[$role] as $cap) {
                if (!in_array($cap, $valid_features, true)) {
                    continue;
                }

                $allcaps[$cap] = true;
            }
        }

        return $allcaps;
	}

    /**
     * Return user all caps.
     *
     * @param mixed $user User.
     */

    public static function get_user_all_caps( $user = null ) {
        $user = $user instanceof WP_User ? $user : wp_get_current_user();

        if (!$user || empty($user->ID)) {
            return [];
        }

        // Enumerate known primitive capabilities, but let WordPress decide every grant.
        // Super admins need no local role; raw allcaps also misses runtime filters.
        $candidates = $user->allcaps;
        foreach ( wp_roles()->roles as $role ) {
            $candidates = array_merge( $candidates, $role['capabilities'] );
        }
        foreach ( self::get_feature_ids() as $capability ) {
            $candidates[$capability] = true;
        }
        $network_caps = array(
            'manage_sites',
            'manage_network',
            'manage_network_themes',
            'manage_network_users',
            'manage_network_plugins',
            'manage_network_options',
            'upgrade_network',
            'setup_network',
            'delete_sites',
        );
        foreach ( $network_caps as $capability ) {
            $candidates[$capability] = true;
        }

        // Object-dependent capabilities must remain live checks with an object ID.
        $object_caps = array(
            'edit_post',
            'read_post',
            'delete_post',
            'edit_user',
            'delete_user',
            'remove_user',
            'promote_user',
            'edit_term',
            'delete_term',
            'assign_term',
        );
        foreach ( get_post_types( array(), 'objects' ) as $post_type ) {
            foreach ( array( 'edit_post', 'read_post', 'delete_post' ) as $key ) {
                $object_caps[] = $post_type->cap->$key;
            }
            foreach ( (array) $post_type->cap as $capability ) {
                $candidates[$capability] = true;
            }
        }
        foreach ( get_taxonomies( array(), 'objects' ) as $taxonomy ) {
            foreach ( (array) $taxonomy->cap as $capability ) {
                $candidates[$capability] = true;
            }
        }

        return array_values( array_filter(
            array_diff( array_keys( $candidates ), $object_caps ),
            static function ( $capability ) use ( $user ) {
                return user_can( $user, $capability );
            }
        ) );
    }

    /**
     * Determine whether the current user can manage taxonomies.
     */

    public static function can_manage_taxonomies() {
        if ( current_user_can( 'manage_options' ) ) {
            return true;
        }

        $taxonomies = get_taxonomies([
            'public' => true,
            'show_ui' => true,
        ], 'objects');

        foreach ( $taxonomies as $taxonomy ) {
            if ( empty( $taxonomy->cap ) || ! is_object( $taxonomy->cap ) ) {
                continue;
            }

            foreach ( [ 'manage_terms', 'edit_terms', 'delete_terms' ] as $cap_key ) {
                if ( isset( $taxonomy->cap->$cap_key ) && current_user_can( $taxonomy->cap->$cap_key ) ) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Determine whether the current user can manage comments.
     */

    public static function can_manage_comments() {
        return current_user_can( 'moderate_comments' ) || current_user_can( 'manage_options' );
    }

	/**
	 * Return current user access payload.
	 */

	public static function get_current_user_access_payload() {
		$user = wp_get_current_user();
		$can_manage_feature_access = current_user_can( 'manage_options' );

		if ( ! $user || empty( $user->ID ) ) {
			return array(
				'currentUser' => array(
					'id'          => null,
					'roles'       => array(),
					'caps'        => array(),
					'featureCaps' => array(),
				),
				'roles'                  => array(),
				'features'               => array(),
				'canManageFeatureAccess' => false,
				'canManageTaxonomies'    => false,
				'canManageComments'      => false,
				'canSetupTheme' => false,
				'themeManagementUrl' => '',
				'networkSitesUrl' => '',
				'isRestrictedUser'       => false,
			);
		}

		return array(
			'currentUser' => array(
				'id'          => $user->ID,
				'roles'       => (array) $user->roles,
				'caps'        => self::get_user_all_caps( $user ),
				'featureCaps' => self::get_user_feature_caps( $user ),
			),
			'roles'                  => $can_manage_feature_access ? self::get_all_roles() : array(),
			'features'               => $can_manage_feature_access ? self::get_features() : array(),
			'canManageFeatureAccess' => $can_manage_feature_access,
			'canManageTaxonomies' => self::can_manage_taxonomies(),
			'canManageComments' => self::can_manage_comments(),
			'canSetupTheme' => WPHAVE_Theme_Setup::can_manage_theme(),
			'themeManagementUrl' => current_user_can( 'switch_themes' ) ? admin_url( 'themes.php' ) : '',
			'networkSitesUrl' => is_multisite() && current_user_can( 'manage_sites' ) ? network_admin_url( 'sites.php' ) : '',
			'isRestrictedUser' => class_exists( 'WPHAVE_Admin_Interface' ) && WPHAVE_Admin_Interface::is_restricted_user(),
		);
	}

    /**
     * Register the REST routes.
     *
     *  - Feature definitions
     *  - Role information
     *  - Current user access data
     */

	public static function register_rest_routes() {
		register_rest_route('wphave/v1', '/access/features', [
			'methods' => WP_REST_Server::READABLE,
			'callback' => [__CLASS__, 'rest_get_access_payload'],
			'permission_callback' => function() {
				return is_user_logged_in();
			},
		]);

		register_rest_route('wphave/v1', '/access/role-map', [
			'methods' => WP_REST_Server::READABLE,
			'callback' => [__CLASS__, 'rest_get_role_map'],
			'permission_callback' => [ __CLASS__, 'can_manage_role_map' ],
		]);
	}

	/**
	 * Determine whether the current user may inspect delegated feature access.
	 *
	 * @return bool Whether the role map is visible.
	 */
	public static function can_manage_role_map() {
		return current_user_can( 'manage_options' );
	}

    /**
     * Handle the get access payload REST request.
     *
     *  - User ID
     *  - Assigned roles
     *  - Granted feature capabilities
     *  - All available features
     *  - All available roles
     *  - Permission to manage feature access
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */

	public static function rest_get_access_payload( WP_REST_Request $request ) {
		// AUTHORIZATION/ACCESS-PAYLOAD INVARIANT: This projection belongs to one
		// authenticated current user. Its intentionally empty anonymous domain shape
		// is not permission to bypass the REST route through direct PHP invocation.
		if ( ! is_user_logged_in() ) {
			return new WP_Error(
				'wphave_access_payload_forbidden',
				__( 'You must be logged in to inspect access information.', 'wphave' ),
				array( 'status' => 401 )
			);
		}

        return rest_ensure_response( self::get_current_user_access_payload() );
    }

	/**
	 * Return the configured role-to-feature map for administrators.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @return WP_REST_Response
	 */

	public static function rest_get_role_map( WP_REST_Request $request ) {
		// AUTHORIZATION INVARIANT: Delegated feature-access policy is administrative data; the executable callback repeats manage_options before loading it.
		if ( ! self::can_manage_role_map() ) {
			return new WP_Error(
				'wphave_access_role_map_forbidden',
				__( 'You are not allowed to inspect feature access settings.', 'wphave' ),
				array( 'status' => 403 )
			);
		}

		$data = wphave_data_get( 'access_settings' );

		return rest_ensure_response( is_array( $data['features'] ?? null ) ? $data['features'] : array() );
	}
}

add_action('init', ['WPHAVE_Access_Manager', 'init']);

add_action('init', function() {
    if (is_admin()) {
        WPHAVE_Access_Manager::maybe_init_defaults();
    }
});
