<?php

/**
 * Class to manage WordPress user roles capabilities.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPHAVE_Role_Manager {

	/** Password authorization shared by Roles and Access mutations. */

	public const AUTHORIZATION_ACTION = 'user.permissions.manage';

	/** Stable resource binding for the permission administration workspace. */

	public const AUTHORIZATION_RESOURCE = 'roles-access';

	/**
	 * Registers all REST routes required for the role manager.
	 *
	 * The role manager is responsible for reading and updating
	 * native WordPress role capabilities exposed through the
	 * wphave admin interface.
	 */

	public static function init() {
		WPHAVE_Action_Authorization::register_action( self::AUTHORIZATION_ACTION, 'manage_options' );
		add_action( 'rest_api_init', [ __CLASS__, 'register_rest_routes' ] );
	}

	/**
	 *  ...
	 *
	 * @return array
	 */

    public static function get_public_post_types() {
        $post_types = get_post_types([
            'public' => true,
        ], 'objects');

        $result = [];

        foreach ($post_types as $pt) {
            $result[$pt->name] = [
                'name' => $pt->name,
                'label' => $pt->labels->name,
                'cap' => $pt->cap,
            ];
        }

        return $result;
    }

	/**
	 * Return the manageable caps.
	 *
	 * @return array
	 */

	public static function get_manageable_caps() {

        $features = [];



        $base_caps = [
            [
                'id' => 'upload_files',
                'label' => __('Upload Files', 'wphave'),
                'description' => __('Allows uploading media files.', 'wphave'),
                'group' => 'media',
            ],
            [
                'id' => 'moderate_comments',
                'label' => __('Moderate Comments', 'wphave'),
                'description' => __('Allows viewing, editing, approving, marking as spam and deleting comments.', 'wphave'),
                'group' => 'comments',
            ],
            [
                'id' => 'list_users',
                'label' => __('List Users', 'wphave'),
                'description' => __('Allows viewing users.', 'wphave'),
                'group' => 'users',
            ],
            [
                'id' => 'create_users',
                'label' => __('Create Users', 'wphave'),
                'description' => __('Allows creating users.', 'wphave'),
                'group' => 'users',
            ],
            [
                'id' => 'add_users',
                'label' => __('Add Existing Users', 'wphave'),
                'description' => __('Allows adding existing users to a site in multisite installations.', 'wphave'),
                'group' => 'users',
            ],
            [
                'id' => 'edit_users',
                'label' => __('Edit Users', 'wphave'),
                'description' => __('Allows editing users.', 'wphave'),
                'group' => 'users',
            ],
            [
                'id' => 'promote_users',
                'label' => __('Change User Roles', 'wphave'),
                'description' => __('Allows changing user roles.', 'wphave'),
                'group' => 'users',
            ],
            [
                'id' => 'delete_users',
                'label' => __('Delete Users', 'wphave'),
                'description' => __('Allows deleting users.', 'wphave'),
                'group' => 'users',
            ],
            [
                'id' => 'remove_users',
                'label' => __('Remove Users', 'wphave'),
                'description' => __('Allows removing users from a site in multisite installations.', 'wphave'),
                'group' => 'users',
            ],
        ];

        $features = array_merge($features, $base_caps);



        $post_types = self::get_public_post_types();
        $post_type_edit_caps = [];

        foreach ($post_types as $post_type) {

            if ($post_type['name'] === 'attachment') {
                continue;
            }

            if (empty($post_type['cap']) || !is_object($post_type['cap'])) {
                continue;
            }

            $caps = $post_type['cap'];
            $group = $post_type['name'];
            $label = $post_type['label'];

            if (isset($caps->edit_posts)) {
                $post_type_edit_caps[] = $caps->edit_posts;
            }

	            $map = [
	                'create_posts' => __('Create', 'wphave'),
	                'edit_posts' => __('Edit Own', 'wphave'),
	                'edit_others_posts' => __('Edit Others’', 'wphave'),
	                'edit_published_posts' => __('Edit Published', 'wphave'),
	                'edit_private_posts' => __('Edit Private', 'wphave'),

	                'publish_posts' => __('Publish', 'wphave'),
	                'read_private_posts' => __('Read Private', 'wphave'),

	                'delete_posts' => __('Delete Own', 'wphave'),
	                'delete_others_posts' => __('Delete Others’', 'wphave'),
	                'delete_published_posts' => __('Delete Published', 'wphave'),
	                'delete_private_posts' => __('Delete Private', 'wphave'),
	            ];

	            $description_map = [
	                'create_posts' => __('Create new %s.', 'wphave'),
	                'edit_posts' => __('Edit %s authored by this role’s users.', 'wphave'),
	                'edit_others_posts' => __('Edit %s authored by other users.', 'wphave'),
	                'edit_published_posts' => __('Edit published %s.', 'wphave'),
	                'edit_private_posts' => __('Edit private %s.', 'wphave'),
	                'publish_posts' => __('Publish %s.', 'wphave'),
	                'read_private_posts' => __('View private %s.', 'wphave'),
	                'delete_posts' => __('Delete %s authored by this role’s users.', 'wphave'),
	                'delete_others_posts' => __('Delete %s authored by other users.', 'wphave'),
	                'delete_published_posts' => __('Delete published %s.', 'wphave'),
	                'delete_private_posts' => __('Delete private %s.', 'wphave'),
	            ];

            foreach ($map as $key => $action_label) {

                if (!isset($caps->$key)) {
                    continue;
                }

                $features[] = [
                    'id' => $caps->$key,
                    'label' => $action_label . ' ' . $label,
	                    'description' => sprintf(
	                        /* translators: %s: managed post type label. */
	                        $description_map[$key],
	                        $label
                    ),
                    'group' => $group,
                    'groupLabel' => $label,
                    'groupDescription' => __(
                        'Permissions related to managing this content type.',
                        'wphave'
                    ),
                ];
            }
        }



        $taxonomies = get_taxonomies([
            'public' => true,
            'show_ui' => true,
        ], 'objects');

	        foreach ($taxonomies as $taxonomy) {

            if (empty($taxonomy->cap) || !is_object($taxonomy->cap)) {
                continue;
            }

            $caps = $taxonomy->cap;
            $label = $taxonomy->labels->name ?? $taxonomy->label ?? $taxonomy->name;

            $map = [
                'manage_terms' => __('Manage', 'wphave'),
                'edit_terms' => __('Edit', 'wphave'),
                'delete_terms' => __('Delete', 'wphave'),
                'assign_terms' => __('Assign', 'wphave'),
            ];

	            foreach ($map as $key => $action_label) {

	                if (!isset($caps->$key)) {
	                    continue;
	                }

	                if ($key === 'assign_terms' && in_array($caps->$key, $post_type_edit_caps, true)) {
	                    continue;
	                }

	                $cap_id = $caps->$key;
	                $is_derived = false;

	                if (in_array($cap_id, [ 'edit_categories', 'delete_categories', 'edit_post_tags', 'delete_post_tags', 'manage_post_tags' ], true)) {
	                    $cap_id = 'manage_categories';
	                    $is_derived = true;
	                }

	                if (in_array($cap_id, [ 'assign_categories', 'assign_post_tags' ], true)) {
	                    $cap_id = 'edit_posts';
	                    $is_derived = true;
	                }

	                $features[] = [
	                    'key' => 'taxonomy:' . $taxonomy->name . ':' . $key,
	                    'id' => $cap_id,
	                    'originalId' => $caps->$key,
	                    'isDerived' => $is_derived,
	                    'action' => $key,
                    'actionLabel' => $action_label,
                    'label' => $action_label . ' ' . $label,
                    'description' => sprintf(
                        /* translators: 1: capability action, 2: managed object label. */
                        __('Allows "%1$s" for %2$s.', 'wphave'),
                        strtolower($action_label),
                        $label
                    ),
                    'group' => 'taxonomy:' . $taxonomy->name,
                    'groupLabel' => $label,
                    'groupDescription' => sprintf(
                        /* translators: %s: contextual value. */
                        __('Permissions related to the "%s" taxonomy.', 'wphave'),
                        $label
                    ),
                ];
            }
        }

        $features = apply_filters('wphave/manageable_role_caps', $features);
        $normalized = [];
        $seen = [];
        $multisite_only_caps = [
            'add_users',
            'manage_network',
            'manage_sites',
            'manage_network_users',
            'manage_network_plugins',
            'manage_network_themes',
            'manage_network_options',
            'upgrade_network',
            'setup_network',
            'delete_sites',
            'remove_users',
        ];

        foreach( $features as $feature ) {
            if( empty( $feature['id'] ) ) {
                continue;
            }

            $cap_id = sanitize_key( $feature['id'] );
            $display_key = ! empty( $feature['key'] ) ? sanitize_key( $feature['key'] ) : $cap_id;

            if( ( ! class_exists( 'WPHAVE_Multisite' ) || ! WPHAVE_Multisite::is_enabled() ) && in_array( $cap_id, $multisite_only_caps, true ) ) {
                continue;
            }

            if( empty( $cap_id ) || empty( $display_key ) || isset( $seen[ $display_key ] ) ) {
                continue;
            }

            $seen[ $display_key ] = true;
            $feature['key'] = $display_key;
            $feature['id'] = $cap_id;
            $normalized[] = $feature;
        }

        return $normalized;
    }

	/**
	 * Return the manageable cap IDs.
	 *
	 * @return array
	 */

	public static function get_manageable_cap_ids() {
		$cap_ids = wp_list_pluck( self::get_manageable_caps(), 'id' );

		return array_values( array_unique( array_filter( array_map( 'sanitize_key', $cap_ids ) ) ) );
	}

	/**
	 * Return an all roles.
	 *
	 * @return array
	 */

	public static function get_all_roles() {
		if ( ! function_exists( 'wp_roles' ) ) {
			return [];
		}

		$wp_roles = wp_roles();
		$result   = [];

		foreach ( (array) $wp_roles->roles as $role_key => $role_data ) {
			$result[] = [
				'key' => $role_key,
				'label' => isset( $role_data['name'] ) ? $role_data['name'] : $role_key,
				'description' => wphave_get_role_description( $role_key ),
			];
		}

		return $result;
	}

	/**
	 * Return the role caps map.
	 *
	 * @return array
	 */

	public static function get_role_caps_map() {
		$cap_ids = self::get_manageable_cap_ids();
		$roles   = wp_roles();
		$map     = [];

		foreach ( (array) $roles->roles as $role_key => $role_data ) {
			$role_caps = isset( $role_data['capabilities'] ) ? (array) $role_data['capabilities'] : [];

			$map[ $role_key ] = [];

			foreach ( $cap_ids as $cap_id ) {
				if ( ! empty( $role_caps[ $cap_id ] ) ) {
					$map[ $role_key ][] = $cap_id;
				}
			}
		}

		return $map;
	}

	/**
	 * Update the role caps.
	 *
	 * @param string $role_key
	 * @param array $caps
	 * @return bool|WP_Error
	 */

	public static function update_role_caps( $role_key, $caps ) {
		$role_key = sanitize_key( $role_key );
		$caps     = array_map( 'sanitize_key', (array) $caps );

		if ( $role_key === 'administrator' ) {
			return new WP_Error(
				'wphave_forbidden_role',
				__( 'The administrator role cannot be edited in the role manager.', 'wphave' ),
				[ 'status' => 403 ]
			);
		}

		$role = get_role( $role_key );

		if ( ! $role ) {
			return new WP_Error(
				'wphave_invalid_role',
				__( 'Invalid role.', 'wphave' ),
				[ 'status' => 400 ]
			);
		}

		$allowed_caps = self::get_manageable_cap_ids();
		$new_caps     = array_values( array_intersect( $caps, $allowed_caps ) );

		/*
		 * SECURITY INVARIANT: Role administration is closed over the platform's
		 * declared manageable capability set, and the administrator role is immutable.
		 * Submitted capability names can never introduce arbitrary WordPress powers.
		 *
		 * AUTHORIZATION/ATOMICITY INVARIANT: The complete role projection is one
		 * authorization commit. Never publish it through sequential add_cap/remove_cap
		 * writes, and never report success until the exact canonical option is readable.
		 */
		$wp_roles = wp_roles();
		$stored_roles = get_option( $wp_roles->role_key, array() );
		if ( ! is_array( $stored_roles ) || ! isset( $stored_roles[ $role_key ]['capabilities'] ) ) {
			return new WP_Error(
				'wphave_role_caps_write_failed',
				__( 'The role capabilities could not be saved. Please try again.', 'wphave' ),
				array( 'status' => 500 )
			);
		}

		$next_roles = $stored_roles;
		foreach ( $allowed_caps as $cap_id ) {
			if ( in_array( $cap_id, $new_caps, true ) ) {
				$next_roles[ $role_key ]['capabilities'][ $cap_id ] = true;
			} else {
				unset( $next_roles[ $role_key ]['capabilities'][ $cap_id ] );
			}
		}

		update_option( $wp_roles->role_key, $next_roles );
		$committed_roles = get_option( $wp_roles->role_key, array() );
		$wp_roles->for_site( get_current_blog_id() );

		if ( $next_roles !== $committed_roles ) {
			return new WP_Error(
				'wphave_role_caps_write_failed',
				__( 'The role capabilities could not be saved. Please try again.', 'wphave' ),
				array( 'status' => 500 )
			);
		}

		return true;
	}

	/**
	 * Registers all REST routes required for managing WordPress role
	 * capabilities through the wphave UI.
	 */

	public static function register_rest_routes() {
		register_rest_route( 'wphave/v1', '/roles/caps', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ __CLASS__, 'rest_get_role_caps_payload' ],
			'permission_callback' => [ __CLASS__, 'can_manage_role_caps' ],
		] );

		register_rest_route( 'wphave/v1', '/roles/caps', [
			'methods'             => WP_REST_Server::EDITABLE,
			'callback'            => [ __CLASS__, 'rest_update_role_caps' ],
			'permission_callback' => [ __CLASS__, 'can_manage_role_caps' ],
			'args' => [
				'role' => [
					'required' => true,
					'type'     => 'string',
				],
				'caps' => [
					'required' => true,
					'type'     => 'array',
				],
			],
		] );
	}

	/**
	 * Determine whether the current user may inspect or change role capabilities.
	 *
	 * @return bool Whether role capability management is authorized.
	 */
	public static function can_manage_role_caps() {
		return current_user_can( 'manage_options' );
	}

	/**
	 * Return the stable authorization failure for role capability operations.
	 *
	 * @return WP_Error Authorization failure.
	 */
	private static function role_caps_forbidden() {
		return new WP_Error(
			'wphave_role_caps_forbidden',
			__( 'You are not allowed to manage role capabilities.', 'wphave' ),
			array( 'status' => 403 )
		);
	}

	/**
	 * Handle the get role caps payload REST request.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */

	public static function rest_get_role_caps_payload( WP_REST_Request $request ) {
		// AUTHORIZATION INVARIANT: The role-capability model is administrative data; executable callbacks repeat the exact route policy before enumerating it.
		if ( ! self::can_manage_role_caps() ) {
			return self::role_caps_forbidden();
		}

		return rest_ensure_response( [
			'roles' => self::get_all_roles(),
			'caps'  => self::get_manageable_caps(),
			'map'   => self::get_role_caps_map(),
		] );
	}

	/**
	 * Handle the update role caps REST request.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response|WP_Error
	 */

	public static function rest_update_role_caps( WP_REST_Request $request ) {
		// AUTHORIZATION INVARIANT: A protected-action proof supplements administrative authority and is never consumed as a substitute for it.
		if ( ! self::can_manage_role_caps() ) {
			return self::role_caps_forbidden();
		}

		try {
			WPHAVE_Action_Authorization::consume(
				self::AUTHORIZATION_ACTION,
				self::AUTHORIZATION_RESOURCE,
				(string) $request->get_header( 'X-WPHAVE-Action-Proof' )
			);
		} catch ( WPHAVE_Action_Authorization_Exception $error ) {
			return new WP_Error(
				$error->error_code(),
				$error->getMessage(),
				[ 'status' => $error->http_status() ]
			);
		}

		$role = sanitize_key( $request->get_param( 'role' ) );
		$caps = (array) $request->get_param( 'caps' );

		$result = self::update_role_caps( $role, $caps );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return rest_ensure_response( [
			'success' => true,
			'role'    => $role,
			'map'     => self::get_role_caps_map(),
		] );
	}
}

add_action( 'init', [ 'WPHAVE_Role_Manager', 'init' ] );
