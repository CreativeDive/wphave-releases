<?php

/**
 * Resolve a role label in the current request locale without rewriting stored roles.
 *
 * Platform role keys are stable even when their persisted names were translated
 * in another locale. Third-party and Core role names retain WordPress behavior.
 *
 * @param string $role_key Stable role identifier.
 * @param string $stored_name Persisted display name for non-platform roles.
 * @return string Localized display label.
 */

function wphave_get_role_label(string $role_key, string $stored_name = ''): string {
	if ($role_key === 'wphave_client') {
		return _x('Client', 'User role', 'wphave');
	}
	if ($role_key === 'wphave_client_pro') {
		return _x('Experienced Client', 'User role', 'wphave');
	}
	return translate_user_role($stored_name ?: $role_key);
}
