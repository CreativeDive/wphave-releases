<?php

require_once __DIR__ . '/role-labels.php';

/**
 * Return the role descriptions.
 *
 * @return array
 */

if (!function_exists('wphave_get_role_descriptions')):
	function wphave_get_role_descriptions() {
		$descriptions = [
			'administrator' => __(
				'Should have full access to all settings and features.',
				'wphave',
			),
			'editor' => __(
				'Should be able to manage and publish content, including posts from other users.',
				'wphave',
			),
			'author' => __('Should be able to write, edit, and publish their own posts.', 'wphave'),
			'contributor' => __(
				'Should be able to write and edit their own posts but not publish them.',
				'wphave',
			),
			'subscriber' => __(
				'Should be able to manage their profile and read content.',
				'wphave',
			),
			'wphave_client' => __(
				'Should have limited access, typically restricted to specific assigned content or features.',
				'wphave',
			),
			'wphave_client_pro' => __(
				'Should have extended access compared to clients, including additional premium features or content.',
				'wphave',
			),
		];

		return apply_filters('wphave/role_descriptions', $descriptions);
	}
endif;

/**
 * Return roles that must never be assigned through public membership registration.
 *
 * WPHAVE client roles are intended for deliberately created and configured client
 * accounts. They are not public membership tiers.
 *
 * @return array
 */

if (!function_exists('wphave_membership_excluded_roles')):
	function wphave_membership_excluded_roles() {
		return ['wphave_client', 'wphave_client_pro'];
	}
endif;

/**
 * Remove WPHAVE client roles from WordPress default-role selectors.
 *
 * @param array $roles Excluded role keys.
 * @return array
 */

if (!function_exists('wphave_exclude_client_roles_from_membership')):
	function wphave_exclude_client_roles_from_membership($roles) {
		return array_values(
			array_unique(array_merge((array) $roles, wphave_membership_excluded_roles())),
		);
	}
endif;

add_filter('default_role_dropdown_excluded_roles', 'wphave_exclude_client_roles_from_membership');

/**
 * Keep public registration on a membership-safe role even if an excluded role
 * was stored previously or submitted outside the settings UI.
 *
 * @param string $role Role key.
 * @return string
 */

if (!function_exists('wphave_membership_safe_default_role')):
	function wphave_membership_safe_default_role($role) {
		return in_array($role, wphave_membership_excluded_roles(), true) ? 'subscriber' : $role;
	}
endif;

add_filter('option_default_role', 'wphave_membership_safe_default_role');
add_filter('pre_update_option_default_role', 'wphave_membership_safe_default_role');

/**
 * Keep persisted WPHAVE client-role titles concise and product-neutral.
 *
 * WordPress stores role titles when a role is first registered. Updating the
 * add_role() label alone therefore does not rename roles on existing sites.
 * This synchronization changes only the display names and preserves every
 * capability assigned to the roles.
 *
 * @return void
 */

if (!function_exists('wphave_sync_client_role_names')):
	function wphave_sync_client_role_names() {
		$wp_roles = wp_roles();
		$role_keys = ['wphave_client', 'wphave_client_pro'];
		$has_changes = false;

		foreach ($role_keys as $role_key) {
			if (!isset($wp_roles->roles[$role_key])) {
				continue;
			}

			$current_name = (string) ($wp_roles->roles[$role_key]['name'] ?? '');
			$role_name = preg_replace('/\s*\(wphave\)\s*$/i', '', $current_name);

			if (!is_string($role_name) || $role_name === $current_name) {
				continue;
			}

			$wp_roles->roles[$role_key]['name'] = $role_name;
			$wp_roles->role_names[$role_key] = $role_name;
			$has_changes = true;
		}

		if ($has_changes && $wp_roles->use_db) {
			update_option($wp_roles->role_key, $wp_roles->roles);
		}
	}
endif;

add_action('init', 'wphave_sync_client_role_names', 5);

/**
 * Return the role description.
 *
 * @param string $role_key
 * @return string
 */

if (!function_exists('wphave_get_role_description')):
	function wphave_get_role_description($role_key) {
		$descriptions = wphave_get_role_descriptions();
		$role_key = sanitize_key($role_key);

		return $descriptions[$role_key] ??
			__(
				'This role should have a custom set of capabilities defined by the system or administrator.',
				'wphave',
			);
	}
endif;

/**
 * Determine whether the current user can access a feature.
 *
 * @param string $feature_cap
 * @return bool
 */

if (!function_exists('wphave_current_user_can_feature')):
	function wphave_current_user_can_feature($feature_cap) {
		return current_user_can($feature_cap);
	}
endif;

/**
 * Whether the current user bypasses WPHAVE's role-based editor restrictions.
 *
 * Invariant: a Multisite super admin needs no local site role to use Design
 * mode or unlock layout in Write mode. Resolve network authority before any
 * missing-role fallback; never create site membership to obtain editor access.
 *
 * This is an editor UI policy, not an authorization grant. Every operation must
 * still use WordPress capability checks (with an object ID where applicable).
 * Core can deny even super admins through map_meta_cap's do_not_allow.
 *
 * @return bool
 */
function wphave_current_user_has_full_editor_mode() {
	$user = wp_get_current_user();

	if (!$user->exists()) {
		return false;
	}

	if (is_multisite() && is_super_admin($user->ID)) {
		return true;
	}

	return ($user->roles[0] ?? null) === 'administrator';
}

/**
 * Return the block editor mode by role.
 *
 *  - Administrators and Multisite super admins receive full "design" access.
 *  - Unknown roles use "view"; the existing no-role fallback remains "write".
 *
 *  - design : Full access to layout, styling, and all block settings.
 *  - write  : Content-only editing, without access to design controls.
 *  - view   : Read-only mode, no editing allowed.
 *
 * @return string Editor mode ("design" | "write" | "view").
 */

if (!function_exists('wphave_get_block_editor_mode_by_role')):
	function wphave_get_block_editor_mode_by_role() {
		if (wphave_current_user_has_full_editor_mode()) {
			return 'design';
		}

		// Get current user role if none provided
		$user = wp_get_current_user();
		$roles = (array) $user->roles;
		$role = !empty($roles) ? $roles[0] : null;

		// Fallback if no role found
		if (empty($role)) {
			return 'write';
		}

		// Get stored permissions (adjust option key if needed)
		$data = wphave_data_get('access_settings');
		$mode = $data['editorMode'] ?? [];

		// Get role-specific mode
		$editing_mode = $mode[$role] ?? 'view';

		// Sanitize / whitelist
		if (!in_array($editing_mode, ['design', 'write', 'view'], true)) {
			$editing_mode = 'view';
		}

		return $editing_mode;
	}
endif;

/**
 * Return the write mode layout permission by role.
 *
 *  - Administrators and Multisite super admins have full layout access (true).
 *  - Unknown or undefined roles default to "false" (safe fallback).
 *
 * @return bool True if layout changes are allowed, false otherwise.
 */

if (!function_exists('wphave_get_write_mode_layout_permission_by_role')):
	function wphave_get_write_mode_layout_permission_by_role() {
		if (wphave_current_user_has_full_editor_mode()) {
			return true;
		}

		// Get current user role if none provided
		$user = wp_get_current_user();
		$roles = (array) $user->roles;
		$role = !empty($roles) ? $roles[0] : null;

		// Fallback if no role found
		if (empty($role)) {
			return false;
		}

		// Get stored permissions
		$data = wphave_data_get('access_settings');
		$permissions = $data['canChangeLayout'] ?? [];

		// Get role-specific permission
		$can_unlock = $permissions[$role] ?? false;

		return (bool) $can_unlock;
	}
endif;

/**
 * Ensures that all relevant user roles have the required "wphave_access" capability assigned.
 *
 * This capability acts as the main entry point to the wphave
 * application. Without it, users will not see the wphave menu
 * in the WordPress admin and cannot access the app.
 *
 * This runs on every init to guarantee consistency even if
 * roles were modified externally or the activation hook
 * was not triggered.
 */

if (!function_exists('wphave_ensure_access_capability')):
	function wphave_ensure_access_capability() {
		$roles = [
			'administrator',
			'editor',
			'author',
			'contributor',
			'wphave_client',
			'wphave_client_pro',
		];

		foreach ($roles as $role_key) {
			$role = get_role($role_key);

			if ($role && !$role->has_cap('wphave_access')) {
				$role->add_cap('wphave_access');
			}
		}

		$admin = get_role('administrator');

		if ($admin && !$admin->has_cap('wphave_manage_options')) {
			$admin->add_cap('wphave_manage_options');
		}
	}
endif;

add_action('admin_init', 'wphave_ensure_access_capability');

/**
 *  `wphave_access` is the global WordPress-level app entry capability used for
 *
 *  `wphave_manage_options`.
 *
 * @return array
 */

if (!function_exists('wphave_get_caps')):
	function wphave_get_caps() {
		return [
			'access' => 'wphave_access',
		];
	}
endif;

/**
 * Configure the roles and caps.
 *
 *  - Administrator: full access
 *  - Editor: limited access
 *  - Client: minimal access (custom role)
 */

if (!function_exists('wphave_setup_roles_and_caps')):
	function wphave_setup_roles_and_caps() {
		$caps = wphave_get_caps();

		// ADMIN ROLE (full access)
		$admin = get_role('administrator');

		if ($admin) {
			$admin->add_cap($caps['access']);

			// Add system level caps for admin only
			// Ensures the "administrator" role has access to all limited features.
			$admin->add_cap('wphave_manage_options'); // <-- Allrounder capability only for "administrator" is set here !
		}

		// EDITOR ROLE
		$editor = get_role('editor');

		if ($editor) {
			$editor_caps = ['access'];

			foreach ($editor_caps as $key) {
				$editor->add_cap($caps[$key]);
			}
		}

		// CONTRIBUTOR ROLE
		$contributor = get_role('contributor');

		if ($contributor) {
			$contributor->add_cap($caps['access']);
		}

		// CLIENT ROLE
		add_role('wphave_client', wphave_get_role_label('wphave_client'), [
			'read' => true,
		]);

		$client = get_role('wphave_client');

		if ($client) {
			$client_caps = ['access'];

			foreach ($client_caps as $key) {
				$client->add_cap($caps[$key]);
			}
		}

		// CLIENT PRO ROLE
		add_role('wphave_client_pro', wphave_get_role_label('wphave_client_pro'), [
			'read' => true,
		]);

		$client_pro = get_role('wphave_client_pro');

		if ($client_pro) {
			$client_pro_caps = ['access'];

			foreach ($client_pro_caps as $key) {
				$client_pro->add_cap($caps[$key]);
			}
		}
	}
endif;

register_activation_hook(WPHAVE_FILE_PATH, 'wphave_setup_roles_and_caps');

/**
 *  (`/wp/v2/users/me`) by including the user's roles.
 *
 * @param WP_REST_Response $response
 * @param WP_User $user
 * @param WP_REST_Request $request
 * @return WP_REST_Response
 */

if (!function_exists('wphave_add_user_roles_to_wp_user_rest_api_route')):
	function wphave_add_user_roles_to_wp_user_rest_api_route($response, $user, $request) {
		$route = $request instanceof WP_REST_Request ? $request->get_route() : '';
		$is_current_user_route = '/wp/v2/users/me' === untrailingslashit($route);
		$is_current_user = $user instanceof WP_User && (int) $user->ID === get_current_user_id();

		// PRIVACY INVARIANT: WPHAVE supplements roles only for the authenticated
		// user's own /users/me projection. The global rest_prepare_user filter must
		// never add role membership to another user's public Core REST response.
		if ($is_current_user_route && $is_current_user && !empty($response->data)) {
			$response->data['roles'] = array_values((array) $user->roles);
		}

		return $response;
	}
endif;

add_filter('rest_prepare_user', 'wphave_add_user_roles_to_wp_user_rest_api_route', 10, 3);

/**
 * Return the available WordPress user roles.
 *
 * @return array
 */

if (!function_exists('wphave_user_roles')):
	function wphave_user_roles() {
		$all = [];

		// Get user roles
		$roles = wp_roles();
		$roles = isset($roles->role_names) ? $roles->role_names : '';

		if ($roles) {
			foreach ($roles as $key => $name) {
				$all[$key] = wphave_get_role_label($key, $name);
			}
		}

		return $all;
	}
endif;

/**
 * Return the roles assigned to the current user.
 *
 * @return array
 */

if (!function_exists('wphave_current_user_roles')):
	function wphave_current_user_roles() {
		if (!is_user_logged_in()) {
			return [];
		}

		$user = wp_get_current_user();
		$roles = (array) $user->roles;

		return $roles;
	}
endif;
