<?php

/**
 * Provides REST-backed user listing, creation, deletion, bulk role changes
 * and user metadata used by the WPHAVE user manager UI.
 */

if (!defined('ABSPATH')) {
	exit();
}

class WPHAVE_Users_Manager {
	const MAX_BULK_USER_IDS = 100;

	/**
	 * Registers REST routes and user login tracking hooks.
	 */

	public static function init() {
		add_action('rest_api_init', [__CLASS__, 'register_rest_routes']);
		add_action('wp_login', [__CLASS__, 'track_last_login'], 10, 2);
	}

	/**
	 * Store the user timestamp after a successful login.
	 *
	 * @param string $user_login
	 * @param WP_User $user
	 */

	public static function track_last_login($user_login, $user) {
		if (!($user instanceof WP_User)) {
			return;
		}

		update_user_meta($user->ID, 'wphave_last_login', gmdate('Y-m-d\TH:i:s\Z'));
	}

	/**
	 * Return an users.
	 *
	 * @param array $args
	 * @return array
	 */

	public static function get_users($args = []) {
		$defaults = [
			'number' => 20,
			'paged' => 1,
			'search' => '',
			'role' => 'all',
			'orderby' => 'login',
			'order' => 'ASC',
		];

		$args = wp_parse_args($args, $defaults);
		$number = absint($args['number']);
		$paged = absint($args['paged']);
		$role = sanitize_key($args['role']);
		$orderby = sanitize_key($args['orderby']);
		$order = strtoupper(sanitize_key($args['order']));
		$allowed_orderby = ['login', 'email', 'registered', 'display_name'];

		$args['number'] = $number ? min($number, 100) : $defaults['number'];
		$args['paged'] = $paged ?: $defaults['paged'];
		$args['search'] = sanitize_text_field($args['search']);
		$args['orderby'] = in_array($orderby, $allowed_orderby, true)
			? $orderby
			: $defaults['orderby'];
		$args['order'] = in_array($order, ['ASC', 'DESC'], true) ? $order : $defaults['order'];

		$query_args = [
			'number' => $args['number'],
			'paged' => $args['paged'],
			'search' => $args['search'] ? '*' . esc_attr($args['search']) . '*' : '',
			'search_columns' => ['user_login', 'user_email', 'display_name'],
			'orderby' => $args['orderby'],
			'order' => $args['order'],
			'count_total' => true,
		];

		if ($role && $role !== 'all') {
			if ($role === 'none') {
				$query_args['role__not_in'] = array_keys(wp_roles()->roles);
			} elseif (get_role($role)) {
				$query_args['role'] = $role;
			}
		}

		$query = new WP_User_Query($query_args);

		$query_users = $query->get_results();
		// Fetch counts for the current page in one pass to avoid per-row SQL.
		$content_counts = self::get_user_content_counts(wp_list_pluck($query_users, 'ID'));
		$users = [];

		foreach ($query_users as $user) {
			$user_id = (int) $user->ID;
			$users[] = self::prepare_user_item($user, $content_counts[$user_id] ?? 0);
		}

		return [
			'items' => $users,
			'total' => $query->get_total(),
			'roles' => self::get_editable_roles(),
			'reassignUsers' => self::get_reassign_users(),
			'stats' => self::get_user_stats(),
		];
	}

	/**
	 * Return an user stats.
	 *
	 * @return array
	 */

	public static function get_user_stats() {
		$count = count_users();
		$roles = [];

		foreach ((array) ($count['avail_roles'] ?? []) as $role => $total) {
			$roles[$role] = (int) $total;
		}

		return [
			'total' => (int) ($count['total_users'] ?? 0),
			'roles' => $roles,
		];
	}

	/**
	 * Return an editable roles.
	 *
	 * @return array
	 */

	public static function get_editable_roles() {
		if (!function_exists('get_editable_roles')) {
			require_once ABSPATH . 'wp-admin/includes/user.php';
		}

		$roles = [];

		foreach (get_editable_roles() as $role_key => $role_data) {
			$roles[] = [
				'key' => $role_key,
				'value' => $role_key,
				'label' => wphave_get_role_label($role_key, $role_data['name'] ?? $role_key),
			];
		}

		return $roles;
	}

	/**
	 * Prepare an user item.
	 *
	 * @param WP_User|int $user
	 * @param int|null $content_count
	 * @return array|null
	 */

	public static function prepare_user_item($user, $content_count = null) {
		$user = $user instanceof WP_User ? $user : get_user_by('id', $user);

		if (!$user) {
			return null;
		}

		$user_id = (int) $user->ID;
		$is_current_user = $user_id === get_current_user_id();
		$content_count =
			$content_count === null ? self::count_user_content($user_id) : (int) $content_count;

		return [
			'id' => $user_id,
			'user_login' => $user->user_login,
			'user_email' => $user->user_email,
			'display_name' => $user->display_name,
			'first_name' => get_user_meta($user_id, 'first_name', true),
			'last_name' => get_user_meta($user_id, 'last_name', true),
			'user_registered' => $user->user_registered,
			'last_login' => get_user_meta($user_id, 'wphave_last_login', true),
			'roles' => array_values((array) $user->roles),
			'avatar_url' => wphave_get_avatar_url($user_id),
			'avatar_gradient' => WPHAVE_User_Profile::sanitize_avatar_gradient(
				get_user_meta($user_id, 'wphave_avatar_gradient', true),
			),
			'contentCount' => $content_count,
			'permissions' => [
				'isCurrentUser' => $is_current_user,
				// These flags mirror WordPress' meta capabilities for row-level UI actions.
				'canEdit' => current_user_can('edit_user', $user_id),
				'canDelete' => !$is_current_user && current_user_can('delete_user', $user_id),
				'canChangeRole' => !$is_current_user && current_user_can('promote_user', $user_id),
			],
		];
	}

	/**
	 * Return the reassign users.
	 *
	 * @return array
	 */

	public static function get_reassign_users() {
		$query = new WP_User_Query([
			'number' => 500,
			'orderby' => 'display_name',
			'order' => 'ASC',
			'fields' => ['ID', 'display_name', 'user_login', 'user_email'],
		]);

		return array_values(
			array_map(function ($user) {
				return [
					'id' => (int) $user->ID,
					'value' => (int) $user->ID,
					'label' => $user->display_name ?: $user->user_login,
					'description' => $user->user_email,
				];
			}, $query->get_results()),
		);
	}

	/**
	 * Count an user content.
	 *
	 * @param int $user_id
	 * @return int
	 */

	public static function count_user_content($user_id) {
		global $wpdb;

		$user_id = absint($user_id);
		$post_count = (int) $wpdb->get_var(
			$wpdb->prepare("SELECT COUNT(*) FROM $wpdb->posts WHERE post_author = %d", $user_id),
		);

		$link_count = (int) $wpdb->get_var(
			$wpdb->prepare("SELECT COUNT(*) FROM $wpdb->links WHERE link_owner = %d", $user_id),
		);

		return $post_count + $link_count;
	}

	/**
	 * Return an user content counts.
	 *
	 * @param array $user_ids
	 * @return array
	 */

	public static function get_user_content_counts($user_ids) {
		global $wpdb;

		$user_ids = array_values(array_filter(array_map('absint', (array) $user_ids)));

		if (empty($user_ids)) {
			return [];
		}

		$counts = array_fill_keys($user_ids, 0);
		$id_list = implode(',', $user_ids);

		$post_counts = $wpdb->get_results(
			"SELECT post_author AS user_id, COUNT(*) AS total FROM $wpdb->posts WHERE post_author IN ($id_list) GROUP BY post_author",
		);

		foreach ((array) $post_counts as $row) {
			$counts[(int) $row->user_id] += (int) $row->total;
		}

		$link_counts = $wpdb->get_results(
			"SELECT link_owner AS user_id, COUNT(*) AS total FROM $wpdb->links WHERE link_owner IN ($id_list) GROUP BY link_owner",
		);

		foreach ((array) $link_counts as $row) {
			$counts[(int) $row->user_id] += (int) $row->total;
		}

		return $counts;
	}

	/**
	 * Validate the role.
	 *
	 * @param string $role
	 * @return string|WP_Error
	 */

	public static function validate_role($role) {
		$role = sanitize_key($role);

		if (!$role) {
			return new WP_Error('missing_role', 'Missing role.', ['status' => 400]);
		}

		$editable_roles = array_column(self::get_editable_roles(), 'key');

		if (!in_array($role, $editable_roles, true)) {
			return new WP_Error('invalid_role', 'Invalid role.', ['status' => 403]);
		}

		return $role;
	}

	/**
	 * Create an user.
	 *
	 * @param array $data
	 * @return array|WP_Error
	 */

	public static function create_user($data) {
		$username = sanitize_user($data['username'] ?? '');
		$email = sanitize_email($data['email'] ?? '');
		$password = $data['password'] ?? wp_generate_password();
		$role = self::get_create_user_role($data['role'] ?? '');

		if (is_wp_error($role)) {
			return $role;
		}

		if (username_exists($username)) {
			return new WP_Error(
				'username_exists',
				__('This username is already in use.', 'wphave'),
				['status' => 409],
			);
		}

		if (email_exists($email)) {
			return new WP_Error(
				'email_exists',
				__('This email address is already in use.', 'wphave'),
				['status' => 409],
			);
		}

		// AUTHORIZATION/USER-CREATE INVARIANT: Role projection and duplicate
		// discovery cross filterable WordPress boundaries. The REST permission
		// decision is not a lease; create_users must still hold immediately before
		// the account and its authorization identity are persisted.
		if (!current_user_can('create_users')) {
			return new WP_Error('cannot_create_user', 'You are not allowed to create users.', [
				'status' => 403,
			]);
		}

		$user_id = wp_insert_user([
			'user_login' => $username,
			'user_email' => $email,
			'user_pass' => $password,
			'role' => $role,
		]);

		if (is_wp_error($user_id)) {
			return $user_id;
		}

		// AUTHORIZATION/CREATION INVARIANT: create_users authorizes exactly the
		// server-selected role, never a stronger role introduced by a later Core or
		// extension hook. Reload after user_register and remove any account whose
		// canonical authorization projection differs before publishing its identity.
		clean_user_cache($user_id);
		$created_user = get_userdata($user_id);
		if (!$created_user || [$role] !== array_values($created_user->roles)) {
			require_once ABSPATH . 'wp-admin/includes/user.php';
			wp_delete_user($user_id);

			return new WP_Error(
				'wphave_user_role_commit_failed',
				__('The user account could not be created safely.', 'wphave'),
				['status' => 500],
			);
		}

		return ['id' => $user_id];
	}

	/**
	 * Return the create user role.
	 *
	 * @param string $requested_role
	 * @return string|WP_Error
	 */

	public static function get_create_user_role($requested_role = '') {
		if (current_user_can('promote_users')) {
			$role = self::validate_role(
				$requested_role ?: get_option('default_role', 'subscriber'),
			);

			return is_wp_error($role) ? $role : $role;
		}

		$default_role = sanitize_key(get_option('default_role', 'subscriber'));

		return get_role($default_role) ? $default_role : 'subscriber';
	}

	/**
	 * Delete an user.
	 *
	 * @param int $user_id
	 * @param int|null $reassign
	 * @return array|WP_Error
	 */

	public static function delete_user($user_id, $reassign = null) {
		require_once ABSPATH . 'wp-admin/includes/user.php';

		$user_id = (int) $user_id;
		$reassign = $reassign ? absint($reassign) : null;

		if ($user_id === get_current_user_id()) {
			return new WP_Error('cannot_delete_self', 'You cannot delete yourself', [
				'status' => 400,
			]);
		}

		if (!current_user_can('delete_user', $user_id)) {
			return new WP_Error('cannot_delete_user', 'You are not allowed to delete this user.', [
				'status' => 403,
			]);
		}

		if (self::count_user_content($user_id) > 0) {
			// Require an explicit recipient so posts, drafts and links are not deleted by accident.
			if (!$reassign) {
				return new WP_Error(
					'missing_reassign_user',
					'Please select a user to receive this user\'s content.',
					['status' => 400],
				);
			}

			if ($reassign === $user_id || !get_user_by('id', $reassign)) {
				return new WP_Error('invalid_reassign_user', 'Invalid reassignment user.', [
					'status' => 400,
				]);
			}
		}

		// AUTHORIZATION/USER-DELETE INVARIANT: Content and reassignment discovery
		// cross filterable database and identity boundaries. Revalidate both the
		// self-delete prohibition and mapped authority for this exact account
		// immediately before the irreversible Core deletion/reassignment effect.
		if ($user_id === get_current_user_id()) {
			return new WP_Error('cannot_delete_self', 'You cannot delete yourself', [
				'status' => 400,
			]);
		}

		if (!current_user_can('delete_user', $user_id)) {
			return new WP_Error('cannot_delete_user', 'You are not allowed to delete this user.', [
				'status' => 403,
			]);
		}

		$deleted = wp_delete_user($user_id, $reassign);

		return [
			'id' => $user_id,
			'deleted' => (bool) $deleted,
		];
	}

	/**
	 * Apply the requested bulk action.
	 *
	 * @param string $action
	 * @param array $ids
	 * @param array $extra
	 * @return array|WP_Error
	 */

	public static function bulk_action($action, $ids, $extra = []) {
		require_once ABSPATH . 'wp-admin/includes/user.php';

		$ids = array_map('intval', (array) $ids);

		if (empty($ids)) {
			return new WP_Error('no_ids', 'No users provided', ['status' => 400]);
		}

		if (count($ids) > self::MAX_BULK_USER_IDS) {
			return new WP_Error('too_many_users', 'Too many users selected for one bulk action.', [
				'status' => 400,
			]);
		}

		$result = [];

		// SECURITY INVARIANT: Route-level access permits entry to the mixed bulk
		// workflow only. Each action and each target user must independently pass
		// its native delete_user or promote_user capability before mutation.
		switch ($action) {
			case 'delete':
				if (!current_user_can('delete_users')) {
					return new WP_Error(
						'cannot_delete_users',
						'You are not allowed to delete users.',
						['status' => 403],
					);
				}

				$reassign = !empty($extra['reassign']) ? absint($extra['reassign']) : null;

				foreach ($ids as $id) {
					if ($id === get_current_user_id() || !current_user_can('delete_user', $id)) {
						$result[$id] = false;
						continue;
					}

					if (self::count_user_content($id) > 0 && !$reassign) {
						$result[$id] = false;
						continue;
					}

					$result[$id] = !is_wp_error(self::delete_user($id, $reassign));
				}
				break;

			case 'change_role':
				if (!current_user_can('promote_users')) {
					return new WP_Error(
						'cannot_promote_users',
						'You are not allowed to change user roles.',
						['status' => 403],
					);
				}

				$role = self::validate_role($extra['role'] ?? '');

				if (is_wp_error($role)) {
					return $role;
				}

				foreach ($ids as $id) {
					if ($id === get_current_user_id() || !current_user_can('promote_user', $id)) {
						$result[$id] = false;
						continue;
					}

					$user = new WP_User($id);
					if (!$user->exists()) {
						$result[$id] = false;
						continue;
					}
					$user->set_role($role);

					// AUTHORIZATION/COMMIT INVARIANT: A requested role mutation is successful
					// only when the exact canonical capability projection contains that one
					// role. WP_User mutates its in-memory object even when the metadata write
					// is filtered or rejected, so authorization state must be reloaded.
					clean_user_cache($id);
					$updated_user = get_userdata($id);
					$result[$id] = $updated_user && [$role] === array_values($updated_user->roles);
				}
				break;

			default:
				return new WP_Error('invalid_action', 'Invalid bulk action', ['status' => 400]);
		}

		return [
			'action' => $action,
			'results' => $result,
		];
	}

	/**
	 * Registers user manager REST endpoints.
	 */

	public static function register_rest_routes() {
		// GET Users
		register_rest_route('wphave/v1', '/users', [
			'methods' => WP_REST_Server::READABLE,
			'callback' => [__CLASS__, 'rest_get_users'],
			'permission_callback' => [__CLASS__, 'can_list_users'],
		]);

		register_rest_route('wphave/v1', '/users/stats', [
			'methods' => WP_REST_Server::READABLE,
			'callback' => [__CLASS__, 'rest_get_user_stats'],
			'permission_callback' => [__CLASS__, 'can_list_users'],
		]);

		// CREATE User
		register_rest_route('wphave/v1', '/users', [
			'methods' => WP_REST_Server::CREATABLE,
			'callback' => [__CLASS__, 'rest_create_user'],
			'permission_callback' => [__CLASS__, 'can_create_users'],
		]);

		// DELETE User
		register_rest_route('wphave/v1', '/users/(?P<id>\d+)', [
			'methods' => WP_REST_Server::DELETABLE,
			'callback' => [__CLASS__, 'rest_delete_user'],
			'permission_callback' => function (WP_REST_Request $request) {
				$user_id = (int) $request['id'];

				return $user_id !== get_current_user_id() &&
					current_user_can('delete_user', $user_id);
			},
			'args' => [
				'reassign' => [
					'sanitize_callback' => 'absint',
				],
			],
		]);

		// BULK
		register_rest_route('wphave/v1', '/users/bulk', [
			'methods' => WP_REST_Server::CREATABLE,
			'callback' => [__CLASS__, 'rest_bulk_action'],
			'permission_callback' => function () {
				return current_user_can('delete_users') || current_user_can('promote_users');
			},
		]);
	}

	/**
	 * Determine whether the current user may enumerate account records.
	 *
	 * @return bool Whether user-directory access is authorized.
	 */
	public static function can_list_users() {
		return current_user_can('list_users');
	}

	/**
	 * Determine whether the current user may create WordPress accounts.
	 *
	 * @return bool Whether account creation is authorized.
	 */
	public static function can_create_users() {
		return current_user_can('create_users');
	}

	/**
	 * Return the stable authorization failure for user-management callbacks.
	 *
	 * @return WP_Error Authorization failure.
	 */
	private static function users_forbidden() {
		return new WP_Error(
			'wphave_users_forbidden',
			__('You are not allowed to manage users.', 'wphave'),
			['status' => 403],
		);
	}

	/**
	 * Handle the get users REST request.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */

	public static function rest_get_users(WP_REST_Request $request) {
		// AUTHORIZATION INVARIANT: Account records include private identity data; executable callbacks repeat list_users before querying or projecting them.
		if (!self::can_list_users()) {
			return self::users_forbidden();
		}

		$data = self::get_users([
			'search' => $request->get_param('search'),
			'paged' => $request->get_param('page'),
			'number' => $request->get_param('per_page'),
			'role' => $request->get_param('role'),
			'orderby' => $request->get_param('orderby'),
			'order' => $request->get_param('order'),
		]);

		// AUTHORIZATION/USER-DIRECTORY-RESPONSE INVARIANT: User queries, metadata,
		// role projection and permission flags cross filterable boundaries. Private
		// account data may leave the server only while list_users still holds after
		// the complete projection.
		if (!self::can_list_users()) {
			return self::users_forbidden();
		}

		return rest_ensure_response($data);
	}

	/**
	 * Handle the user statistics request.
	 *
	 * @return WP_REST_Response
	 */

	public static function rest_get_user_stats() {
		// AUTHORIZATION INVARIANT: Aggregate account and role statistics remain behind the same list_users boundary as the underlying directory.
		if (!self::can_list_users()) {
			return self::users_forbidden();
		}

		$data = [
			'stats' => self::get_user_stats(),
			'roles' => self::get_editable_roles(),
		];

		// AUTHORIZATION/USER-STATS-RESPONSE INVARIANT: Aggregate account counts and
		// editable-role projection are private directory data and invoke filterable
		// WordPress boundaries. Revalidate list_users before releasing the payload.
		if (!self::can_list_users()) {
			return self::users_forbidden();
		}

		return rest_ensure_response($data);
	}

	/**
	 * Handle the create user REST request.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response|WP_Error
	 */

	public static function rest_create_user(WP_REST_Request $request) {
		// AUTHORIZATION INVARIANT: Role normalization cannot grant account-creation authority; create_users is rechecked immediately before consuming request data.
		if (!self::can_create_users()) {
			return self::users_forbidden();
		}

		$result = self::create_user($request->get_params());

		return is_wp_error($result) ? $result : rest_ensure_response($result);
	}

	/**
	 * Handle the delete user REST request.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response|WP_Error
	 */

	public static function rest_delete_user(WP_REST_Request $request) {
		$result = self::delete_user($request['id'], $request->get_param('reassign'));

		return is_wp_error($result) ? $result : rest_ensure_response($result);
	}

	/**
	 * Handle the bulk action REST request.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response|WP_Error
	 */

	public static function rest_bulk_action(WP_REST_Request $request) {
		$result = self::bulk_action(
			$request->get_param('action'),
			$request->get_param('ids'),
			$request->get_params(),
		);

		return is_wp_error($result) ? $result : rest_ensure_response($result);
	}
}

add_action('init', ['WPHAVE_Users_Manager', 'init']);
