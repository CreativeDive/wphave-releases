<?php

/**
 * Registers WPHAVE user metadata and exposes normalized current-user data.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPHAVE_User_Profile {
	const AVATAR_GRADIENT_COUNT = 8;

	/**
	 * Register the user profile hooks.
	 */

	public static function init() {
		add_action( 'init', [ __CLASS__, 'register_meta' ] );
	}

	/**
	 * Register user metadata used by the editor and credential workflows.
	 */

	public static function register_meta() {
		register_meta( 'user', 'wphave_avatar_custom', [
			'type' => 'integer',
			'single' => true,
			'show_in_rest' => true,
			'auth_callback' => [ __CLASS__, 'can_edit_user_meta' ],
		] );

		register_meta( 'user', 'wphave_avatar_gradient', [
			'type' => 'integer',
			'description' => 'Preferred WPHAVE avatar placeholder gradient (1-8, or 0 for automatic).',
			'single' => true,
			'default' => 0,
			'sanitize_callback' => [ __CLASS__, 'sanitize_avatar_gradient' ],
			'show_in_rest' => true,
			'auth_callback' => [ __CLASS__, 'can_edit_user_meta' ],
		] );

		register_meta( 'user', '_wphave_pending_email', [
			'type' => 'string',
			'description' => 'Pending email address awaiting confirmation.',
			'single' => true,
			'sanitize_callback' => 'sanitize_email',
			'auth_callback' => [ __CLASS__, 'can_edit_current_user_meta' ],
			'show_in_rest' => false,
		] );

		register_meta( 'user', '_wphave_email_change_token', [
			'type' => 'string',
			'description' => 'Hashed token for email change confirmation.',
			'single' => true,
			'sanitize_callback' => 'sanitize_text_field',
			'auth_callback' => [ __CLASS__, 'can_edit_current_user_meta' ],
			'show_in_rest' => false,
		] );

		register_meta( 'user', '_wphave_email_change_expires', [
			'type' => 'integer',
			'description' => 'Expiration timestamp for email change confirmation.',
			'single' => true,
			'sanitize_callback' => 'absint',
			'auth_callback' => [ __CLASS__, 'can_edit_current_user_meta' ],
			'show_in_rest' => false,
		] );
	}

	/**
	 * Determine whether the current user may edit metadata for a user.
	 *
	 * @param bool   $allowed
	 * @param string $meta_key
	 * @param int    $object_id
	 * @return bool
	 */

	public static function can_edit_user_meta( $allowed, $meta_key, $object_id ) {
		// AUTHORIZATION INVARIANT: Profile metadata follows WordPress's exact edit_user
		// meta capability. Authentication or access to one's own profile screen cannot
		// authorize changes to a different account selected by object ID.
		return current_user_can( 'edit_user', $object_id );
	}

	/**
	 * Determine whether the current user may edit their private metadata.
	 *
	 * @return bool
	 */

	public static function can_edit_current_user_meta() {
		return current_user_can( 'edit_user', get_current_user_id() );
	}

	/**
	 * Sanitize a personal avatar gradient selection.
	 *
	 * @param mixed $value Submitted value.
	 * @return int Gradient number, or zero for automatic selection.
	 */

	public static function sanitize_avatar_gradient( $value ) {
		$value = (int) $value;

		return $value >= 1 && $value <= self::AVATAR_GRADIENT_COUNT ? $value : 0;
	}

	/**
	 * Return normalized data for the current user.
	 *
	 * @return array
	 */

	public static function get_current_user_info() {
		$current_user = wp_get_current_user();

		return [
			'id' => $current_user->ID,
			'login' => $current_user->user_login,
			'nicename' => $current_user->user_nicename,
			'display_name' => $current_user->display_name,
			'email' => $current_user->user_email,
			'role' => $current_user->roles,
			'avatar_small' => wphave_get_avatar_url( $current_user->ID, [ 'size' => 24 ] ),
			'avatar_medium' => wphave_get_avatar_url( $current_user->ID, [ 'size' => 48 ] ),
			'avatar_large' => wphave_get_avatar_url( $current_user->ID, [ 'size' => 96 ] ),
			'avatar_gradient' => self::sanitize_avatar_gradient( get_user_meta( $current_user->ID, 'wphave_avatar_gradient', true ) ),
		];
	}
}
