<?php

/**
 * Stores personal WPHAVE UI preferences for the currently logged-in user.
 * These values are intentionally separate from site settings and profile
 * fields because they describe individual interface behavior only.
 */

if (!defined('ABSPATH')) {
	exit();
}

class WPHAVE_User_Preferences_Manager {
	const META_KEY = '_wphave_user_preferences';
	const VERSION = 1;

	/**
	 * Upgrade preferences before allowlist sanitization can discard old fields.
	 * COMPATIBILITY INVARIANT: Unknown newer versions fail closed and are never rewritten by save().
	 *
	 * @return array|WP_Error Migrated preferences or a schema error.
	 */

	public static function migrate($preferences) {
		$preferences = is_array($preferences) ? $preferences : [];
		$version = max(1, absint($preferences['version'] ?? 1));
		if ($version > self::VERSION) {
			return new WP_Error(
				'wphave_preferences_schema_newer',
				__(
					'These preferences were created by a newer WPHAVE version and cannot be changed safely.',
					'wphave',
				),
				['status' => 409],
			);
		}

		while ($version < self::VERSION) {
			switch ($version) {
				// Add the v1-to-v2 preferences transformation before raising VERSION.
				default:
					return new WP_Error(
						'wphave_preferences_migration_missing',
						__('These preferences cannot be migrated safely.', 'wphave'),
					);
			}
			$version++;
			$preferences['version'] = $version;
		}

		return $preferences;
	}

	/**
	 * Registers REST routes used by the personal preferences store.
	 */

	public static function init() {
		add_action('rest_api_init', [__CLASS__, 'register_rest_routes']);
	}

	/**
	 * Return the defaults.
	 *
	 * @return array
	 */

	public static function get_defaults() {
		return [
			'version' => self::VERSION,
			'appearance' => [
				'colorMode' => 'bright',
				'accentColor' => '',
			],
			'ui' => [
				'frontendAdminBar' => null,
				'iconbarExpanded' => false,
				'borderIntensity' => 'balanced',
				'externalConnections' => [
					'googleFonts' => false,
					'adobeFonts' => false,
				],
				'performanceMonitor' => [
					'isOpen' => false,
					'view' => 'compact',
				],
			],
			'editor' => [
				'inserterWidth' => 330,
				'sidebarWidth' => 330,
				'listViewWidth' => 330,
				'listViewInitiallyOpen' => false,
				'blockInspectorPopover' => true,
				'canvasTools' => [
					'enabled' => true,
				],
			],
			'messages' => [
				'dismissed' => [],
			],
			'views' => [],
		];
	}

	/**
	 * Return the preferences.
	 *
	 * @param int|null $user_id
	 * @return array
	 */

	public static function get_preferences($user_id = null) {
		$user_id = $user_id ? absint($user_id) : get_current_user_id();
		$stored = $user_id ? get_user_meta($user_id, self::META_KEY, true) : [];
		$stored = self::migrate(is_array($stored) ? $stored : []);

		return self::sanitize_preferences(is_wp_error($stored) ? [] : $stored);
	}

	public static function get_revision($user_id = null) {
		return hash('sha256', wp_json_encode(self::get_preferences($user_id)));
	}

	/**
	 * Save the preferences.
	 *
	 * @param array $preferences
	 * @param int|null $user_id
	 * @return array|WP_Error
	 */

	public static function save_preferences(
		$preferences,
		$user_id = null,
		$expected_revision = null,
		$force = false,
		$lock = true,
	) {
		$user_id = $user_id ? absint($user_id) : get_current_user_id();

		if (!$user_id) {
			return new WP_Error('missing_user', 'A logged-in user is required.', ['status' => 401]);
		}

		if ($lock && class_exists('WPHAVE_Option_Mutations')) {
			return WPHAVE_Option_Mutations::with_lock(
				'user_preferences_' . $user_id,
				function () use ($preferences, $user_id, $expected_revision, $force) {
					wp_cache_delete($user_id, 'user_meta');

					return self::save_preferences(
						$preferences,
						$user_id,
						$expected_revision,
						$force,
						false,
					);
				},
			);
		}

		// Inspect the raw record before merging defaults. get_preferences() fails
		// closed for a newer schema, but its defaults must never be allowed to
		// replace that unknown record when an older runtime subsequently saves.
		$stored = get_user_meta($user_id, self::META_KEY, true);
		$stored = self::migrate(is_array($stored) ? $stored : []);
		if (is_wp_error($stored)) {
			return $stored;
		}

		$current_revision = self::get_revision($user_id);
		// SECURITY INVARIANT: Non-forced preference writes replace only the revision
		// CONCURRENCY INVARIANT: The revision is the one observed by the caller; a stale update never persists.
		if (
			!$force &&
			$expected_revision !== null &&
			!hash_equals($current_revision, (string) $expected_revision)
		) {
			return new WP_Error(
				'wphave_preferences_conflict',
				__(
					'Your preferences were changed in another tab. Reload them before saving again.',
					'wphave',
				),
				['status' => 409, 'revision' => $current_revision],
			);
		}

		$current = self::get_preferences($user_id);
		$preferences = self::migrate(is_array($preferences) ? $preferences : []);
		if (is_wp_error($preferences)) {
			return $preferences;
		}
		$preferences = self::sanitize_preferences($preferences);
		$preferences = self::preserve_pro_appearance_preferences($preferences, $current);
		update_user_meta($user_id, self::META_KEY, $preferences);

		// DATA/COMMIT INVARIANT: A returned preference revision describes only the
		// exact canonical user-meta projection. update_user_meta() returning false
		// may mean either unchanged data or failure, so authority comes from readback.
		if ($preferences !== get_user_meta($user_id, self::META_KEY, true)) {
			return new WP_Error(
				'wphave_preferences_write_failed',
				__('Your preferences could not be saved. Please try again.', 'wphave'),
				['status' => 500],
			);
		}

		return [
			'data' => self::get_preferences($user_id),
			'revision' => self::get_revision($user_id),
			'changed' => $current !== $preferences,
		];
	}

	/**
	 * Preserve paid appearance choices when Pro access is unavailable.
	 *
	 * Personal interface choices already stored for a former Pro account keep
	 * rendering after a downgrade. Free requests may still save unrelated user
	 * preferences, but cannot replace or clear the protected appearance values.
	 *
	 * @param array $preferences Sanitized submitted preferences.
	 * @param array $current Current stored preferences.
	 * @return array Preferences with protected appearance values restored.
	 */

	private static function preserve_pro_appearance_preferences($preferences, $current) {
		if (function_exists('wphave_has_pro_access') && wphave_has_pro_access()) {
			return $preferences;
		}

		$protected_color_modes = ['warm', 'dim', 'dark'];
		$current_color_mode = $current['appearance']['colorMode'];
		$submitted_color_mode = $preferences['appearance']['colorMode'];

		if (
			in_array($submitted_color_mode, $protected_color_modes, true) ||
			(in_array($current_color_mode, $protected_color_modes, true) &&
				$submitted_color_mode !== 'contrast')
		) {
			$preferences['appearance']['colorMode'] = $current_color_mode;
		}
		$preferences['appearance']['accentColor'] = $current['appearance']['accentColor'];

		return $preferences;
	}

	/**
	 * Normalize personal frontend-toolbar appearance and preferred coordinates.
	 *
	 * Null permits one-time adoption of older browser-local preferences. Invalid
	 * modes fall back to dark/docked; coordinates must be finite and bounded.
	 * Viewport-specific clamping belongs to the frontend and does not rewrite
	 * the user's preferred position when visiting from a smaller device.
	 *
	 * @param mixed $value Submitted or stored toolbar preferences.
	 * @return array{floating: bool, colorMode: string, position: array{x: int|float, y: int|float}}|null
	 */

	public static function sanitize_frontend_admin_bar($value) {
		if (!is_array($value)) {
			return null;
		}
		$position = is_array($value['position'] ?? null) ? $value['position'] : [];
		$coordinate = static function ($value) {
			return is_numeric($value) && is_finite((float) $value)
				? max(8, min(100000, (float) $value))
				: 12;
		};
		return [
			'floating' => ($value['floating'] ?? false) === true,
			'colorMode' => ($value['colorMode'] ?? 'dark') === 'bright' ? 'bright' : 'dark',
			'position' => [
				'x' => $coordinate($position['x'] ?? 12),
				'y' => $coordinate($position['y'] ?? 12),
			],
		];
	}

	/**
	 * Sanitize the submitted user preferences.
	 *
	 * @param array $preferences
	 * @return array
	 */

	public static function sanitize_preferences($preferences) {
		$defaults = self::get_defaults();
		$appearance =
			isset($preferences['appearance']) && is_array($preferences['appearance'])
				? $preferences['appearance']
				: [];
		$ui = isset($preferences['ui']) && is_array($preferences['ui']) ? $preferences['ui'] : [];
		$editor =
			isset($preferences['editor']) && is_array($preferences['editor'])
				? $preferences['editor']
				: [];
		$messages =
			isset($preferences['messages']) && is_array($preferences['messages'])
				? $preferences['messages']
				: [];
		$views =
			isset($preferences['views']) && is_array($preferences['views'])
				? $preferences['views']
				: [];
		$color_mode = sanitize_key(
			$appearance['colorMode'] ?? $defaults['appearance']['colorMode'],
		);
		$border_intensity = sanitize_key(
			$ui['borderIntensity'] ?? $defaults['ui']['borderIntensity'],
		);
		$performance_monitor =
			isset($ui['performanceMonitor']) && is_array($ui['performanceMonitor'])
				? $ui['performanceMonitor']
				: [];
		$external_connections =
			isset($ui['externalConnections']) && is_array($ui['externalConnections'])
				? $ui['externalConnections']
				: [];
		$canvas_tools =
			isset($editor['canvasTools']) && is_array($editor['canvasTools'])
				? $editor['canvasTools']
				: [];
		$performance_monitor_view = sanitize_key(
			$performance_monitor['view'] ?? $defaults['ui']['performanceMonitor']['view'],
		);

		return [
			'version' => self::VERSION,
			'appearance' => [
				'colorMode' => in_array(
					$color_mode,
					['bright', 'warm', 'dim', 'dark', 'contrast'],
					true,
				)
					? $color_mode
					: $defaults['appearance']['colorMode'],
				'accentColor' => self::sanitize_accent_color($appearance['accentColor'] ?? ''),
			],
			'ui' => [
				'frontendAdminBar' => self::sanitize_frontend_admin_bar(
					$ui['frontendAdminBar'] ?? null,
				),
				'iconbarExpanded' => rest_sanitize_boolean(
					$ui['iconbarExpanded'] ?? $defaults['ui']['iconbarExpanded'],
				),
				'borderIntensity' => in_array(
					$border_intensity,
					['subtle', 'balanced', 'strong'],
					true,
				)
					? $border_intensity
					: $defaults['ui']['borderIntensity'],
				'externalConnections' => [
					// PRIVACY INVARIANT: Personal consent controls only previews in the authenticated WPHAVE UI.
					// It must never be interpreted as visitor consent for frontend resources.
					'googleFonts' => rest_sanitize_boolean(
						$external_connections['googleFonts'] ??
							$defaults['ui']['externalConnections']['googleFonts'],
					),
					'adobeFonts' => rest_sanitize_boolean(
						$external_connections['adobeFonts'] ??
							$defaults['ui']['externalConnections']['adobeFonts'],
					),
				],
				'performanceMonitor' => [
					'isOpen' => rest_sanitize_boolean(
						$performance_monitor['isOpen'] ??
							$defaults['ui']['performanceMonitor']['isOpen'],
					),
					'view' => in_array($performance_monitor_view, ['compact', 'expanded'], true)
						? $performance_monitor_view
						: $defaults['ui']['performanceMonitor']['view'],
				],
			],
			'editor' => [
				'inserterWidth' => self::sanitize_editor_width(
					$editor['inserterWidth'] ?? $defaults['editor']['inserterWidth'],
					250,
					330,
					$defaults['editor']['inserterWidth'],
				),
				'sidebarWidth' => self::sanitize_editor_width(
					$editor['sidebarWidth'] ?? $defaults['editor']['sidebarWidth'],
					330,
					450,
					$defaults['editor']['sidebarWidth'],
				),
				'listViewWidth' => self::sanitize_editor_width(
					$editor['listViewWidth'] ?? $defaults['editor']['listViewWidth'],
					330,
					450,
					$defaults['editor']['listViewWidth'],
				),
				'listViewInitiallyOpen' => rest_sanitize_boolean(
					$editor['listViewInitiallyOpen'] ??
						$defaults['editor']['listViewInitiallyOpen'],
				),
				'blockInspectorPopover' => rest_sanitize_boolean(
					$editor['blockInspectorPopover'] ??
						$defaults['editor']['blockInspectorPopover'],
				),
				'canvasTools' => [
					'enabled' => rest_sanitize_boolean(
						$canvas_tools['enabled'] ?? $defaults['editor']['canvasTools']['enabled'],
					),
				],
			],
			'messages' => [
				'dismissed' => self::sanitize_dismissed_messages($messages['dismissed'] ?? []),
			],
			'views' => self::sanitize_views($views),
		];
	}

	/**
	 * Sanitize the stored user accent color.
	 *
	 * @param string $color
	 * @return string
	 */

	public static function sanitize_accent_color($color) {
		$color = sanitize_hex_color($color);

		return $color ?: '';
	}

	/**
	 * Sanitize the stored editor width preference.
	 *
	 * @param int $width
	 * @param int $min
	 * @param int $max
	 * @param int $default
	 * @return int
	 */

	public static function sanitize_editor_width($width, $min, $max, $default) {
		$width = absint($width);

		if (!$width) {
			return absint($default);
		}

		return min(max($width, absint($min)), absint($max));
	}

	/**
	 * Sanitize the collection of dismissed user messages.
	 *
	 * @param array $dismissed
	 * @return array
	 */

	public static function sanitize_dismissed_messages($dismissed) {
		$sanitized = [];

		foreach ((array) $dismissed as $message_id => $value) {
			$message_id = sanitize_text_field($message_id);

			if (!$message_id || strlen($message_id) > 160 || !rest_sanitize_boolean($value)) {
				continue;
			}

			$sanitized[$message_id] = true;
		}

		return $sanitized;
	}

	/**
	 * Sanitize the stored user view preferences.
	 *
	 * @param array $views
	 * @return array
	 */

	public static function sanitize_views($views) {
		$sanitized = [];

		foreach ((array) $views as $view_key => $view) {
			$view_key = sanitize_key($view_key);

			if (!$view_key || !is_array($view)) {
				continue;
			}

			$next_view = [];
			$default_view = sanitize_key($view['defaultView'] ?? '');

			if (in_array($default_view, ['list', 'table', 'grid', 'masonry'], true)) {
				$next_view['defaultView'] = $default_view;
			}

			if (isset($view['sort']) && is_array($view['sort'])) {
				$next_view['sort'] = [
					'field' => sanitize_key($view['sort']['field'] ?? ''),
					'direction' => in_array(
						strtoupper(sanitize_key($view['sort']['direction'] ?? '')),
						['ASC', 'DESC'],
						true,
					)
						? strtoupper(sanitize_key($view['sort']['direction']))
						: 'ASC',
				];
			}

			if (isset($view['columns']) && is_array($view['columns'])) {
				$next_view['columns'] = array_values(
					array_filter(array_map('sanitize_key', $view['columns'])),
				);
			}

			$items_per_page = absint($view['itemsPerPage'] ?? 0);

			if ($items_per_page >= 1 && $items_per_page <= 200) {
				$next_view['itemsPerPage'] = $items_per_page;
			}

			if (isset($view['asideCollapsed']) && is_bool($view['asideCollapsed'])) {
				$next_view['asideCollapsed'] = $view['asideCollapsed'];
			}

			if (!empty($next_view)) {
				$sanitized[$view_key] = $next_view;
			}
		}

		return $sanitized;
	}

	/**
	 * Determine whether access preferences.
	 *
	 * @return bool
	 */

	public static function can_access_preferences() {
		return is_user_logged_in();
	}

	/**
	 * Require the authenticated personal-preferences boundary.
	 *
	 * @return true|WP_Error True when authenticated, otherwise a stable error.
	 */

	private static function require_preferences_access() {
		if (self::can_access_preferences()) {
			return true;
		}

		return new WP_Error(
			'wphave_preferences_forbidden',
			__('You must be logged in to access workspace preferences.', 'wphave'),
			['status' => 403],
		);
	}

	/**
	 * Registers personal preference read and save endpoints.
	 */

	public static function register_rest_routes() {
		register_rest_route('wphave/v1', '/user-preferences', [
			'methods' => WP_REST_Server::READABLE,
			'callback' => [__CLASS__, 'rest_get_preferences'],
			'permission_callback' => [__CLASS__, 'can_access_preferences'],
		]);

		register_rest_route('wphave/v1', '/user-preferences', [
			'methods' => WP_REST_Server::CREATABLE,
			'callback' => [__CLASS__, 'rest_save_preferences'],
			'permission_callback' => [__CLASS__, 'can_access_preferences'],
		]);
	}

	/**
	 * Handle the get preferences REST request.
	 *
	 * @return WP_REST_Response
	 */

	public static function rest_get_preferences() {
		// PRIVACY INVARIANT: Personal preference schema, values and concurrency
		// revisions belong to the authenticated current user. The executable
		// callback repeats that boundary instead of inheriting REST dispatch state.
		$authorization = self::require_preferences_access();
		if (is_wp_error($authorization)) {
			return $authorization;
		}

		return rest_ensure_response([
			'data' => self::get_preferences(),
			'revision' => self::get_revision(),
		]);
	}

	/**
	 * Handle the save preferences REST request.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response|WP_Error
	 */

	public static function rest_save_preferences(WP_REST_Request $request) {
		// AUTHORIZATION INVARIANT: Route permission is only an early transport
		// gate. Reject anonymous direct invocation before parsing force, revision
		// or preference data and before entering the personal persistence service.
		$authorization = self::require_preferences_access();
		if (is_wp_error($authorization)) {
			return $authorization;
		}

		$params = $request->get_json_params() ?: $request->get_params();
		$revision = isset($params['revision']) ? (string) $params['revision'] : '';
		$force = !empty($params['force']);

		if (!$force && $revision === '') {
			return new WP_Error(
				'wphave_missing_revision',
				__('Reload your preferences before saving again.', 'wphave'),
				['status' => 409],
			);
		}

		$result = self::save_preferences(
			is_array($params['data'] ?? null) ? $params['data'] : [],
			null,
			$revision ?: null,
			$force,
		);

		return is_wp_error($result) ? $result : rest_ensure_response($result);
	}
}

add_action('init', ['WPHAVE_User_Preferences_Manager', 'init']);
