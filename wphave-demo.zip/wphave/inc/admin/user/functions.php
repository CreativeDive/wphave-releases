<?php

/**
 * Load the user administration modules and register their hooks.
 */

include_once ( __DIR__ . '/access/roles.php' );
include_once ( __DIR__ . '/access/role-manager.php' );
include_once ( __DIR__ . '/access/manager.php' );
include_once ( __DIR__ . '/users-manager.php' );
include_once ( __DIR__ . '/preferences-manager.php' );
include_once ( __DIR__ . '/profile.php' );
include_once ( __DIR__ . '/credentials-manager.php' );

WPHAVE_User_Profile::init();
WPHAVE_User_Credentials_Manager::init();
