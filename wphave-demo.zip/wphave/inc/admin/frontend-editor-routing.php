<?php

if (!defined('ABSPATH')) {
	exit();
}

/**
 * Builds explicit Workspace editor destinations for frontend and restricted routing.
 *
 * This service registers no hooks and leaves native WordPress edit links intact.
 * Callers choose Workspace routing explicitly and retain responsibility for access.
 */

class WPHAVE_Frontend_Editor_Routing {
	/**
	 * Return the WPHAVE screen assigned to each editable post type.
	 *
	 * @return array
	 */

	public static function get_post_type_screens() {
		$post_type_screens = [
			'page' => 'pages',
			'wp_block' => 'patterns',
			'wphave-add-ons' => 'addons',
			'wphave-templates' => 'templates',
			'wphave-navigations' => 'navigations',
			'wphave-template-part' => 'template-parts',
		];
		$ui_post_types = WPHAVE_Generic_Content_Post_Type_Policy::filter_selection(
			wphave_data_get('site_settings', 'advanced.ui.postTypes', []) ?: [],
		);

		foreach ($ui_post_types as $post_type) {
			$post_type = sanitize_key($post_type);
			if ($post_type) {
				$post_type_screens[$post_type] = $post_type;
			}
		}

		return $post_type_screens;
	}

	/**
	 * Build the WPHAVE editor URL for one supported post.
	 *
	 * This is a URL builder, not an authorization boundary; callers must check edit_post.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $post_type Post type.
	 * @return string
	 */

	public static function get_editor_url($post_id, $post_type) {
		$post_id = absint($post_id);
		$post_type = sanitize_key($post_type);
		$post_type_screens = self::get_post_type_screens();

		if (!$post_id || !isset($post_type_screens[$post_type])) {
			return '';
		}

		return add_query_arg(
			[
				'page' => WPHAVE_ADMIN_PAGE_SLUG,
				'screen' => $post_type_screens[$post_type],
				'postId' => $post_id,
				'postType' => $post_type,
			],
			admin_url('admin.php'),
		);
	}
}
