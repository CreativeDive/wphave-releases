<?php

/**
 * Validates dynamic data tokens and resolves them through the field provider.
 */

class WPHAVE_Dynamic_Data_Resolver {

    /**
     * Registered field provider.
     *
     * @var WPHAVE_Dynamic_Data_Fields
     */

    protected $fields;

    /**
     * Creates the resolver and its field provider.
     */

    public function __construct() {
        $this->fields = new WPHAVE_Dynamic_Data_Fields( $this );
    }

    /**
     * Returns the registered dynamic data fields.
     *
     * @return array Registered fields grouped by source.
     */

    public function get_fields() {
        return $this->fields->get_fields();
    }

    /**
     * Returns resolver keys restricted to custom field sources.
     *
     * @return string[] Custom field resolver keys.
     */

    public function get_custom_field_resolver_keys() {
        return $this->fields->get_custom_field_resolver_keys();
    }

    /**
     * Exposes source validation to the REST controller.
     *
     * @param string $source Public source key.
     * @return bool Whether the source is supported.
     */

    public function is_source_allowed( $source ) {
        return $this->is_allowed_source( $source );
    }

    /**
     * Exposes source-specific field validation to the REST controller.
     *
     * @param string $field Field key.
     * @param string $source Public source key.
     * @return bool Whether the field is supported for the source.
     */

    public function is_source_field_allowed( $field, $source ) {
        return $this->is_field_allowed_for_source( $field, $source );
    }

    /**
     * Reads nested values through the field provider.
     *
     * @param mixed $data Source data.
     * @param string $path Dot-notated path.
     * @return mixed|null Resolved value or null.
     */

    public function get_value_by_path( $data, string $path ) {
        return $this->fields->get_value_by_path( $data, $path );
    }

    /**
     * Converts a resolved value into its output string.
     *
     * @param mixed $value Resolved value.
     * @return string Stringified value.
     */

    public function stringify_value( $value ) : string {
        return $this->fields->stringify_value( $value );
    }

    /**
     * Returns the public source keys accepted by stored tokens and REST previews.
     *
     * @return string[] Allowed source keys.
     */

    public function get_allowed_sources() {
        return apply_filters( 'wphave_dynamic_data_allowed_sources', [
            'general',
            'current_post',
            'other_post',
            'post',
            'custom_fields',
			'content_fields',
            'audience',
        ] );
    }

    /**
     * Resolves a single dynamic data token into a string value.
     *
     * @param array $args {
     *     Token arguments.
     *
     * @type string $field Registered field key, for example post_title.
     * @type string $field_name Optional meta or ACF field key, with optional dot path.
     * @type string $source Token source: general, current_post, other_post or custom_fields.
     * @type int $post_id Explicit target post id for other_post.
     * @type int $context_post_id Context post id from the rendered block/editor.
     * }
     * @return string Resolved and stringified token value.
     */

    public function resolve_token( $args = [] ) {
        $args = wp_parse_args( $args, [
            'field' => '',
            'field_name' => '',
            'source' => 'general',
            'post_id' => 0,
            'context_post_id' => 0,
        ] );

        $args['field'] = sanitize_key( $args['field'] );
        $args['source'] = sanitize_key( $args['source'] );
        $args['field_name'] = $this->sanitize_field_name( $args['field_name'] );
        $args['post_id'] = absint( $args['post_id'] );
        $args['context_post_id'] = absint( $args['context_post_id'] );

        if ( ! $args['field'] ) {
            return '';
        }

        if ( ! $this->is_allowed_source( $args['source'] ) || ! $this->is_field_allowed_for_source( $args['field'], $args['source'] ) ) {
            return '';
        }

        $source_group = $this->normalize_source_group( $args['source'] );
        $fields = $this->get_fields();
        $resolver = $fields[ $source_group ][ $args['field'] ]['callback'] ?? null;

        if ( is_callable( $resolver ) ) {
            $value = call_user_func( $resolver, $args );
            return apply_filters( 'wphave_dynamic_data_token_value', $this->stringify_value( $value ), $args );
        }

        return apply_filters( 'wphave_dynamic_data_token_value', '', $args );
    }

    /**
     * Maps public source names to the internal resolver group.
     *
     * @param string $source Public token source.
     * @return string Resolver group key.
     */

    protected function normalize_source_group( $source ) {
        if ( $source === 'general' ) {
            return 'general';
        }

		if ( in_array( $source, [ 'current_post', 'other_post', 'post', 'custom_fields', 'content_fields' ], true ) ) {
            return 'post';
        }

        return $source;
    }

    /**
     * Checks whether a public source key is allowed.
     *
     * @param string $source Public source key.
     * @return bool Whether the source is allowed.
     */

    protected function is_allowed_source( $source ) {
        return in_array( $source, $this->get_allowed_sources(), true );
    }

    /**
     * Checks whether a field may be resolved for a source.
     *
     * This prevents stored or manually crafted spans from resolving custom field readers
     * through non-custom-field sources.
     *
     * @param string $field Field key.
     * @param string $source Public source key.
     * @return bool Whether the field is allowed for the source.
     */

    protected function is_field_allowed_for_source( $field, $source ) {
        if ( ! $field || ! $this->is_allowed_source( $source ) ) {
            return false;
        }

        $source_group = $this->normalize_source_group( $source );
        $fields = $this->get_fields();

        if ( empty( $fields[ $source_group ][ $field ] ) ) {
            return false;
        }

        $custom_field_resolvers = $this->get_custom_field_resolver_keys();
        $is_custom_field_resolver = in_array( $field, $custom_field_resolvers, true );

		if ( $source === 'custom_fields' ) {
			return $is_custom_field_resolver && 'content_model' !== $field;
		}

		if ( $source === 'content_fields' ) {
			return 'content_model' === $field && $is_custom_field_resolver;
        }

        if ( in_array( $source, [ 'current_post', 'other_post', 'post' ], true ) ) {
            return ! $is_custom_field_resolver;
        }

        return true;
    }

    /**
     * Returns a safe current post context.
     *
     * Resolution order is an invariant: explicit block/REST context, the scoped WPH Loop
     * item, the singular queried object, then WordPress's current loop post.
     * This prevents an outer page from leaking into repeated content while retaining the
     * normal singular-page fallback. Archive queried objects remain ignored because they
     * may be terms rather than posts.
     *
     * @param int|null $fallback Optional explicit fallback post id.
     * @return int Context post id or 0.
     */

    public function get_context_post_id( $fallback = null ) {
        $fallback = absint( $fallback );

        if ( $fallback ) {
            return $fallback;
        }

        $loop_post_id = absint( $GLOBALS['wphave_loop_post_id'] ?? 0 );

        if ( $loop_post_id ) {
            return $loop_post_id;
        }

        if ( is_singular() ) {
            $queried_object_id = get_queried_object_id();

            if ( $queried_object_id ) {
                return absint( $queried_object_id );
            }
        }

        return absint( get_the_ID() );
    }

    /**
     * Sanitizes meta/ACF field names while preserving dot paths.
     *
     * Examples: "my_key", "group.field", "repeater.0.title".
     *
     * @param mixed $field_name Raw field name.
     * @return string Sanitized field name/path.
     */

    public function sanitize_field_name( $field_name ) {
        if ( is_array( $field_name ) || is_object( $field_name ) ) {
            return '';
        }

        $field_name = trim( (string) $field_name );
        $field_name = preg_replace( '/[^A-Za-z0-9_\-.:]/', '', $field_name );

        return (string) $field_name;
    }

}
