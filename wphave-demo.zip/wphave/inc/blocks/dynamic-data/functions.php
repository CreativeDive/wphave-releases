<?php

require_once __DIR__ . '/runtime-context.php';
require_once __DIR__ . '/fields.php';
require_once __DIR__ . '/resolver.php';
require_once __DIR__ . '/rest.php';
require_once __DIR__ . '/dynamic-data.php';

WPHAVE_Dynamic_Data::init();
