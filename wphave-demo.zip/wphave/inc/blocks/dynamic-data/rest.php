<?php

/**
 * Provides the protected editor-preview REST endpoint for dynamic data.
 */

class WPHAVE_Dynamic_Data_REST {

    /**
     * Shared dynamic data resolver.
     *
     * @var WPHAVE_Dynamic_Data_Resolver
     */

    protected $resolver;

    /**
     * Creates the REST controller.
     *
     * @param WPHAVE_Dynamic_Data_Resolver $resolver Shared resolver.
     */

    public function __construct( $resolver ) {
        $this->resolver = $resolver;
    }

    /**
     * Registers the editor preview REST endpoint.
     *
     * The endpoint intentionally uses the same resolver as frontend rendering so the
     * value shown in the editor matches the saved page output.
     *
     * @return void
     */

    public function register_rest_routes() {
        register_rest_route( 'wphave/v1', '/dynamic-data/preview', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [ $this, 'rest_preview' ],
            'permission_callback' => [ $this, 'rest_preview_permissions' ],
            'args' => [
                'source' => [
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_key',
                    'validate_callback' => [ $this, 'validate_rest_source' ],
                ],
                'field' => [
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_key',
                    'validate_callback' => [ $this, 'validate_rest_field' ],
                ],
                'field_name' => [
                    'type' => 'string',
                    'sanitize_callback' => [ $this, 'sanitize_field_name' ],
                ],
                'post_id' => [
                    'type' => 'integer',
                    'sanitize_callback' => 'absint',
                ],
                'context_post_id' => [
                    'type' => 'integer',
                    'sanitize_callback' => 'absint',
                ],
            ],
        ] );
    }

    /**
     * Checks whether the current user may preview a dynamic data token.
     *
     * General site data only requires editing capability. Post-specific data additionally
     * requires access to the target post when a target post can be determined.
     *
     * @param WP_REST_Request $request REST request containing token arguments.
     * @return bool
     */

    public function rest_preview_permissions( $request ) {
        if ( ! current_user_can( 'edit_posts' ) ) {
            return false;
        }

        $source = sanitize_key( $request->get_param( 'source' ) ?: 'general' );

        if ( ! $this->resolver->is_source_allowed( $source ) ) {
            return false;
        }

		if ( in_array( $source, [ 'general', 'audience' ], true ) ) {
            return true;
        }

        $post_id = absint( $request->get_param( 'post_id' ) );
        $context_post_id = absint( $request->get_param( 'context_post_id' ) );
        $target_post_id = $post_id ?: $context_post_id;

        // SECURITY INVARIANT: Dynamic post fields may reveal unpublished or private
        // content. Preview access follows the resolved target object's edit capability,
        // not merely the caller's general ability to edit some posts.
        return $target_post_id ? current_user_can( 'edit_post', $target_post_id ) : false;
    }

    /**
     * Resolves a dynamic data token for the editor preview endpoint.
     *
     * @param WP_REST_Request $request REST request containing source, field, field_name and post ids.
     * @return WP_REST_Response
     */

    public function rest_preview( $request ) {
        // AUTHORIZATION INVARIANT: Dynamic preview resolution repeats the exact source and target-object policy at the executable callback; transport validation alone never grants access to stored or contextual data.
        if ( ! $this->rest_preview_permissions( $request ) ) {
            return new WP_Error(
                'wphave_dynamic_data_forbidden',
                __( 'You are not allowed to preview this dynamic data.', 'wphave' ),
                [ 'status' => 403 ]
            );
        }

        $args = [
            'source' => $request->get_param( 'source' ) ?: 'general',
            'field' => $request->get_param( 'field' ) ?: '',
            'field_name' => $request->get_param( 'field_name' ) ?: '',
            'post_id' => absint( $request->get_param( 'post_id' ) ),
            'context_post_id' => absint( $request->get_param( 'context_post_id' ) ),
        ];

        if ( ! $this->resolver->is_source_field_allowed( $args['field'], $args['source'] ) ) {
            return new WP_Error( 'wphave_dynamic_data_invalid_field', __( 'This dynamic data field is not available for the selected source.', 'wphave' ), [ 'status' => 400 ] );
        }

        return rest_ensure_response( [
            'value' => $this->resolver->resolve_token( $args ),
        ] );
    }

    /**
     * Validates REST preview source arguments.
     *
     * @param mixed $value Raw source value.
     * @return bool Whether the source is supported.
     */

    public function validate_rest_source( $value ) {
        return $this->resolver->is_source_allowed( sanitize_key( $value ) );
    }

    /**
     * Validates REST preview field arguments against the selected source.
     *
     * @param mixed $value Raw field value.
     * @param WP_REST_Request $request REST request containing the source.
     * @return bool Whether the field is available for the selected source.
     */

    public function validate_rest_field( $value, $request ) {
        $source = sanitize_key( $request->get_param( 'source' ) ?: 'general' );
        return $this->resolver->is_source_field_allowed( sanitize_key( $value ), $source );
    }

    /**
     * Sanitizes a custom field name through the shared resolver.
     *
     * @param mixed $value Raw custom field name.
     * @return string Sanitized field name.
     */

    public function sanitize_field_name( $value ) {
        return $this->resolver->sanitize_field_name( $value );
    }

}
