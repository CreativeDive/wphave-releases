<?php

/**
 * Request-scoped runtime values for system-owned dynamic data sources.
 *
 * @package wphave
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/** Stores trusted runtime context without persisting request-specific values. */

class WPHAVE_Dynamic_Data_Runtime_Context {

    /** @var array<string,mixed> */

    private static array $values = [];

    /**
     * Replaces one namespaced runtime context.
     *
     * @param string $namespace Dot-notated namespace.
     * @param array  $values Trusted request-scoped values.
     */

    public static function set( string $namespace, array $values ): void {
        $segments = self::sanitize_path( $namespace );

        if ( ! $segments ) {
            return;
        }

        $target =& self::$values;

        foreach ( $segments as $segment ) {
            if ( ! isset( $target[ $segment ] ) || ! is_array( $target[ $segment ] ) ) {
                $target[ $segment ] = [];
            }

            $target =& $target[ $segment ];
        }

        $target = $values;
    }

    /**
     * Reads one runtime value by its dot-notated path.
     *
     * @param string $path Dot-notated value path.
     * @param mixed  $default Fallback value.
     * @return mixed Runtime value or fallback.
     */

    public static function get( string $path, $default = '' ) {
        $segments = self::sanitize_path( $path );
        $value = self::$values;

        foreach ( $segments as $segment ) {
            if ( ! is_array( $value ) || ! array_key_exists( $segment, $value ) ) {
                return $default;
            }

            $value = $value[ $segment ];
        }

        return $value;
    }

    /** @return string[] Safe path segments. */
    
    private static function sanitize_path( string $path ): array {
        return array_values(
            array_filter(
                array_map( 'sanitize_key', explode( '.', $path ) )
            )
        );
    }
}
