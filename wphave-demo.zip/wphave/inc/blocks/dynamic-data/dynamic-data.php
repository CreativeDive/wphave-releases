<?php

/**
 * Coordinates block rendering and the editor preview for dynamic data tokens.
 */

class WPHAVE_Dynamic_Data extends WPHAVE_Dynamic_Data_Resolver {

    const FORMAT_CLASS = 'rt-dyd';

    protected static $instance = null;

    /**
     * REST controller sharing this resolver instance.
     *
     * @var WPHAVE_Dynamic_Data_REST
     */

    protected $rest;

    /**
     * Creates the dynamic data service graph.
     */

    public function __construct() {
        parent::__construct();
        $this->rest = new WPHAVE_Dynamic_Data_REST( $this );
    }

    /**
     * Returns the singleton instance.
     *
     * @return WPHAVE_Dynamic_Data
     */

    public static function instance() {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Bootstraps the dynamic data feature.
     *
     * @return void
     */

    public static function init() {
        self::instance()->register_hooks();
    }

    /**
     * Registers frontend rendering and REST preview hooks.
     *
     * @return void
     */

    public function register_hooks() {
        add_filter( 'render_block_data', [ $this, 'resolve_public_tokens_in_block_data' ], 10, 1 );
        add_filter( 'render_block', [ $this, 'convert_block_dynamic_data' ], 10, 3 );
        add_action( 'rest_api_init', [ $this->rest, 'register_rest_routes' ] );
    }

    /**
     * Returns block names whose rendered HTML may contain dynamic data spans.
     *
     * @return string[] Supported block names.
     */

    public function get_supported_blocks() {
        return apply_filters( 'wphave_dynamic_data_supported_blocks', [
            'wphave/paragraph',
            'wphave/heading',
        ] );
    }

    /**
     * Returns public dot-notated tokens backed by registered resolver fields.
     *
     * @return array<string,array{source:string,field:string}> Public token map.
     */
    public function get_public_tokens() {
        // PRIVACY INVARIANT: Anonymous rendering resolves only this explicit public-token
        // allowlist; registering a resolver field does not make that field publicly readable.
        return apply_filters( 'wphave_dynamic_data_public_tokens', [
            'audience.subscriber.confirmation.state' => [
                'source' => 'audience',
                'field' => 'subscriber_confirmation_state',
            ],
            'audience.subscriber.confirmation.title' => [
                'source' => 'audience',
                'field' => 'subscriber_confirmation_title',
            ],
            'audience.subscriber.confirmation.message' => [
                'source' => 'audience',
                'field' => 'subscriber_confirmation_message',
            ],
            'audience.subscriber.confirmation.action_label' => [
                'source' => 'audience',
                'field' => 'subscriber_confirmation_action_label',
            ],
            'audience.subscriber.confirmation.action_url' => [
                'source' => 'audience',
                'field' => 'subscriber_confirmation_action_url',
            ],
        ] );
    }

    /**
     * Resolves registered public tokens inside serialized block attributes.
     *
     * Parsing and reserializing blocks keeps quotes and other characters valid
     * JSON instead of interpolating runtime values into serialized markup.
     *
     * @param string $content Serialized block content.
     * @return string Content with supported attribute tokens resolved.
     */
    public function resolve_public_tokens_in_block_content( $content ) {
        if ( ! is_string( $content ) || $content === '' || ! str_contains( $content, '{{' ) ) {
            return $content;
        }

        $replacements = $this->get_public_token_replacements();

        $blocks = parse_blocks( $content );
        $blocks = array_map(
            fn( $block ) => $this->resolve_public_tokens_in_block( $block, $replacements ),
            $blocks
        );

        return serialize_blocks( $blocks );
    }

    /**
     * Resolves registered public tokens before an individual block is rendered.
     *
     * This is the shared runtime path for tokens stored in arbitrary block
     * attributes, including URLs, labels and nested configuration objects. The
     * block renderer remains responsible for applying context-appropriate
     * escaping to the resolved attribute value.
     *
     * @param array $parsed_block Parsed block data.
     * @return array Block data with supported attribute tokens resolved.
     */
    public function resolve_public_tokens_in_block_data( $parsed_block ) {
        if ( ! is_array( $parsed_block ) || empty( $parsed_block['attrs'] ) ) {
            return $parsed_block;
        }

        $serialized_attrs = wp_json_encode( $parsed_block['attrs'] );

        if ( ! is_string( $serialized_attrs ) || ! str_contains( $serialized_attrs, '{{' ) ) {
            return $parsed_block;
        }

        $parsed_block['attrs'] = $this->resolve_public_tokens_in_value(
            $parsed_block['attrs'],
            $this->get_public_token_replacements()
        );

        return $parsed_block;
    }

    /**
     * Resolves public tokens recursively within one parsed block's attributes.
     *
     * @param array $block Parsed block.
     * @param array $replacements Token replacements.
     * @return array Updated block.
     */
    private function resolve_public_tokens_in_block( array $block, array $replacements ): array {
        $block['attrs'] = $this->resolve_public_tokens_in_value( $block['attrs'] ?? [], $replacements );
        $block['innerBlocks'] = array_map(
            fn( $inner_block ) => $this->resolve_public_tokens_in_block( $inner_block, $replacements ),
            $block['innerBlocks'] ?? []
        );

        return $block;
    }

    /**
     * Resolves tokens within nested attribute values.
     *
     * @param mixed $value Attribute value.
     * @param array $replacements Token replacements.
     * @return mixed Updated value.
     */
    private function resolve_public_tokens_in_value( $value, array $replacements ) {
        if ( is_string( $value ) ) {
            return strtr( $value, $replacements );
        }

        if ( ! is_array( $value ) ) {
            return $value;
        }

        foreach ( $value as $key => $item ) {
            $value[ $key ] = $this->resolve_public_tokens_in_value( $item, $replacements );
        }

        return $value;
    }

    /**
     * Resolves the allowlisted public token map for the current request.
     *
     * @return array<string,string> Token strings mapped to resolved values.
     */
    private function get_public_token_replacements(): array {
        $replacements = [];

        foreach ( $this->get_public_tokens() as $token => $args ) {
            $replacements[ '{{' . $token . '}}' ] = $this->resolve_token( $args );
        }

        return $replacements;
    }

    /**
     * Replaces dynamic data RichText spans inside an HTML string.
     *
     * Only spans with the configured rich-text format class are processed. Resolved values
     * are escaped as text by default and can be adjusted via wphave_dynamic_inline_sanitized.
     *
     * @param string $html Rendered block HTML.
     * @param int|null $context_post_id Optional post context for current_post tokens.
     * @return string HTML with dynamic spans replaced by resolved values.
     */

    public function convert_to_dynamic_data( $html, $context_post_id = null ) {
        if ( ! is_string( $html ) || $html === '' || stripos( $html, self::FORMAT_CLASS ) === false ) {
            return $html;
        }

        $pattern = '/<span\b(?P<attrs>[^>]*\bclass=(["\'])(?:(?!\2).)*\b' . preg_quote( self::FORMAT_CLASS, '/' ) . '\b(?:(?!\2).)*\2[^>]*)>(?P<inner>.*?)<\/span>/is';

        return preg_replace_callback( $pattern, function( $match ) use ( $context_post_id ) {
            $attrs = $this->parse_dynamic_data_attrs( $match['attrs'] );
            $attrs['context_post_id'] = absint( $context_post_id );
            $attrs['post_id'] = $attrs['post_id'] ?: $this->get_context_post_id( $context_post_id );

            $value = $this->resolve_token( $attrs );

            return apply_filters(
                'wphave_dynamic_inline_sanitized',
                esc_html( $value ),
                [
                    'field' => $attrs['field'],
                    'field_name' => $attrs['field_name'],
                    'source' => $attrs['source'],
                    'post_id' => $attrs['post_id'],
                    'context_post_id' => $attrs['context_post_id'],
                ]
            );
        }, $html );
    }

    /**
     * WordPress render_block filter callback for supported blocks.
     *
     * @param string $block_content Rendered block HTML.
     * @param array $block Parsed block data from WordPress.
     * @param WP_Block|null $instance Runtime block instance carrying inherited Core Query Loop context.
     * @return string Rendered block HTML with dynamic data values injected.
     */

    public function convert_block_dynamic_data( $block_content, $block, $instance = null ) {
        $block_name = $block['blockName'] ?? '';

        if ( ! $block_name || ! in_array( $block_name, $this->get_supported_blocks(), true ) ) {
            return $block_content;
        }

        $context_post_id = $this->get_block_context_post_id( $block, $instance );

        return $this->convert_to_dynamic_data( $block_content, $context_post_id );
    }

    /**
     * Extracts supported data-* attributes from a formatted RichText span.
     *
     * @param string $attrs_raw Raw HTML attribute string from the matched span.
     * @return array{field:string,field_name:string,source:string,post_id:int}
     */

    protected function parse_dynamic_data_attrs( $attrs_raw ) {
        $attrs = [
            'field' => '',
            'field_name' => '',
            'source' => 'general',
            'post_id' => 0,
        ];

        if ( preg_match( '/\bdata-source=(["\'])(.*?)\1/i', $attrs_raw, $match ) ) {
            $attrs['source'] = sanitize_key( $match[2] );
        }

        if ( preg_match( '/\bdata-field=(["\'])(.*?)\1/i', $attrs_raw, $match ) ) {
            $attrs['field'] = sanitize_key( $match[2] );
        }

        if ( preg_match( '/\bdata-field-name=(["\'])(.*?)\1/i', $attrs_raw, $match ) ) {
            $attrs['field_name'] = $this->sanitize_field_name( html_entity_decode( $match[2], ENT_QUOTES, get_bloginfo( 'charset' ) ) );
        }

        if ( preg_match( '/\bdata-post-id=(["\'])(.*?)\1/i', $attrs_raw, $match ) ) {
            $attrs['post_id'] = absint( $match[2] );
        }

        return $attrs;
    }

    /**
     * Determines the post context from parsed block data.
     *
     * The runtime WP_Block instance is authoritative because WordPress attaches inherited
     * Core Query Loop context there rather than to the parsed block array. WPH Loop
     * runtime is handled by get_context_post_id() as the next scoped fallback. Attribute
     * context remains supported for explicit integrations and older stored blocks.
     *
     * @param array $block Parsed block data.
     * @param WP_Block|null $instance Runtime block instance.
     * @return int Context post id or 0.
     */

    protected function get_block_context_post_id( $block, $instance = null ) {
        if ( is_object( $instance ) && isset( $instance->context['postId'] ) ) {
            return absint( $instance->context['postId'] );
        }

        if ( isset( $block['context']['postId'] ) ) {
            return absint( $block['context']['postId'] );
        }

        if ( isset( $block['attrs']['postId'] ) ) {
            return absint( $block['attrs']['postId'] );
        }

        return $this->get_context_post_id();
    }

}
