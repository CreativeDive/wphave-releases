<?php

/**
 * Provides the registered dynamic data fields and their concrete value resolvers.
 */

class WPHAVE_Dynamic_Data_Fields {

    /**
     * Resolver used to determine the current post context.
     *
     * @var WPHAVE_Dynamic_Data_Resolver
     */

    protected $context;

    /**
     * Creates the field provider.
     *
     * @param WPHAVE_Dynamic_Data_Resolver $context Dynamic data resolver.
     */

    public function __construct( $context ) {
        $this->context = $context;
    }

    /**
     * Returns the registered dynamic data field resolvers grouped by source type.
     *
     * The UI uses public source names like current_post, other_post and custom_fields,
     * while the resolver groups all post-based sources under the internal "post" group.
     *
     * @return array<string,array<string,array{callback:callable}>>
     */

    public function get_fields() {
        $fields = [
            'general' => [
                'current_date' => [ 'callback' => [ $this, 'resolve_current_date' ] ],
                'current_year' => [ 'callback' => [ $this, 'resolve_current_year' ] ],
                'site_title' => [ 'callback' => [ $this, 'resolve_site_title' ] ],
                'site_tagline' => [ 'callback' => [ $this, 'resolve_site_tagline' ] ],
                'site_url' => [ 'callback' => [ $this, 'resolve_site_url' ] ],
                'site_language' => [ 'callback' => [ $this, 'resolve_site_language' ] ],
            ],
            'post' => [
                'post_title' => [ 'callback' => [ $this, 'resolve_post_title' ] ],
                'post_url' => [ 'callback' => [ $this, 'resolve_post_url' ] ],
                'post_id' => [ 'callback' => [ $this, 'resolve_post_id' ] ],
                'post_slug' => [ 'callback' => [ $this, 'resolve_post_slug' ] ],
                'post_excerpt' => [ 'callback' => [ $this, 'resolve_post_excerpt' ] ],
                'post_date' => [ 'callback' => [ $this, 'resolve_post_date' ] ],
                'post_date_modified' => [ 'callback' => [ $this, 'resolve_post_date_modified' ] ],
                'post_type' => [ 'callback' => [ $this, 'resolve_post_type' ] ],
                'post_status' => [ 'callback' => [ $this, 'resolve_post_status' ] ],
                'author_name' => [ 'callback' => [ $this, 'resolve_author_name' ] ],
                'author_id' => [ 'callback' => [ $this, 'resolve_author_id' ] ],
                'author_url' => [ 'callback' => [ $this, 'resolve_author_url' ] ],
                'author_first_name' => [ 'callback' => [ $this, 'resolve_author_first_name' ] ],
                'author_last_name' => [ 'callback' => [ $this, 'resolve_author_last_name' ] ],
                'author_bio' => [ 'callback' => [ $this, 'resolve_author_bio' ] ],
                'comment_number' => [ 'callback' => [ $this, 'resolve_comment_number' ] ],
                'post_meta' => [ 'callback' => [ $this, 'resolve_post_meta' ] ],
                'acf' => [ 'callback' => [ $this, 'resolve_acf' ] ],
				'content_model' => [ 'callback' => [ $this, 'resolve_content_model' ] ],
            ],
            'audience' => [
                'subscriber_confirmation_state' => [ 'callback' => [ $this, 'resolve_subscriber_confirmation_state' ] ],
                'subscriber_confirmation_title' => [ 'callback' => [ $this, 'resolve_subscriber_confirmation_title' ] ],
                'subscriber_confirmation_message' => [ 'callback' => [ $this, 'resolve_subscriber_confirmation_message' ] ],
                'subscriber_confirmation_action_label' => [ 'callback' => [ $this, 'resolve_subscriber_confirmation_action_label' ] ],
                'subscriber_confirmation_action_url' => [ 'callback' => [ $this, 'resolve_subscriber_confirmation_action_url' ] ],
            ],
        ];

        return apply_filters( 'wphave_dynamic_data_fields', $fields );
    }

    /**
     * Returns post resolver fields that are only allowed through the custom_fields source.
     *
     * ACF is intentionally included here but not allowlisted by field name; the user decides
     * which ACF fields are appropriate to expose.
     *
     * @return string[] Field keys limited to the custom_fields source.
     */

    public function get_custom_field_resolver_keys() {
		return apply_filters( 'wphave_dynamic_data_custom_field_resolver_keys', [
			'post_meta',
			'acf',
			'content_model',
		] );
    }

    /**
     * Loads the target post for post-based token resolvers.
     *
     * @param array $args Token arguments.
     * @return WP_Post|null Target post or null when unavailable.
     */

    protected function get_post_from_args( $args ) {
        $post_id = absint( $args['post_id'] ?? 0 );
        $post_id = $post_id ?: $this->context->get_context_post_id( $args['context_post_id'] ?? 0 );
		$post = $post_id ? get_post( $post_id ) : null;

		if ( ! $post ) {
			return null;
		}

		// SECURITY INVARIANT: Dynamic resolution may expose post fields only when the
		// object is public or WordPress grants read access to that exact private post.
		if ( is_post_publicly_viewable( $post ) || current_user_can( 'read_post', $post->ID ) ) {
			return $post;
		}

		return null;
    }

    /**
     * Returns a post author's user id.
     *
     * @param WP_Post|null $post Target post.
     * @return int Author user id or 0.
     */

    protected function get_author_id( $post ) {
        return $post ? absint( $post->post_author ) : 0;
    }

    /**
     * Reads nested values from arrays/objects using dot notation.
     *
     * Numeric array indexes are supported, for example "items.0.title".
     *
     * @param mixed $data Source data.
     * @param string $path Dot-notated value path.
     * @return mixed|null Nested value, original data for an empty path, or null when missing.
     */

    public function get_value_by_path( $data, string $path ) {
        if ( $path === '' ) {
            return $data;
        }

        $segments = explode( '.', $path );

        foreach ( $segments as $segment ) {
            if ( is_array( $data ) ) {
                if ( array_key_exists( $segment, $data ) ) {
                    $data = $data[ $segment ];
                    continue;
                }

                if ( ctype_digit( $segment ) ) {
                    $index = (int) $segment;
                    if ( array_key_exists( $index, $data ) ) {
                        $data = $data[ $index ];
                        continue;
                    }
                }

                return null;
            }

            if ( is_object( $data ) ) {
                if ( isset( $data->{$segment} ) ) {
                    $data = $data->{$segment};
                    continue;
                }

                return null;
            }

            return null;
        }

        return $data;
    }

    /**
     * Converts resolved values to frontend-safe string values.
     *
     * Non-scalar values are JSON encoded so array/object meta values remain inspectable
     * instead of causing PHP notices.
     *
     * @param mixed $value Raw resolver value.
     * @return string Stringified value.
     */

    public function stringify_value( $value ) : string {
        if ( is_null( $value ) ) {
            return '';
        }

        if ( is_bool( $value ) ) {
            return $value ? '1' : '0';
        }

        if ( is_scalar( $value ) ) {
            return (string) $value;
        }

        return (string) wp_json_encode( $value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
    }

    /**
     * Resolves the current localized date using the site's date format.
     *
     * @return string Current localized date.
     */

    public function resolve_current_date() {
        return date_i18n( get_option( 'date_format' ) ?: 'Y-m-d', current_time( 'timestamp' ) );
    }

    /**
     * Resolves the current year.
     *
     * @return string Current year.
     */

    public function resolve_current_year() {
        return date_i18n( 'Y', current_time( 'timestamp' ) );
    }

    /**
     * Resolves the site title.
     *
     * @return string Site title.
     */

    public function resolve_site_title() {
        return get_bloginfo( 'name' );
    }

    /**
     * Resolves the site tagline.
     *
     * @return string Site tagline.
     */

    public function resolve_site_tagline() {
        return get_bloginfo( 'description' );
    }

    /**
     * Resolves the site's home URL.
     *
     * @return string Site home URL.
     */

    public function resolve_site_url() {
        return home_url( '/' );
    }

    /**
     * Resolves the site's configured language.
     *
     * @return string Site language code.
     */

    public function resolve_site_language() {
        return get_bloginfo( 'language' );
    }

    /** Returns the current subscriber confirmation state. */
    public function resolve_subscriber_confirmation_state() {
        return WPHAVE_Dynamic_Data_Runtime_Context::get( 'audience.subscriber.confirmation.state', 'confirmed' );
    }

    /** Returns the localized subscriber confirmation title. */
    public function resolve_subscriber_confirmation_title() {
        return WPHAVE_Dynamic_Data_Runtime_Context::get(
            'audience.subscriber.confirmation.title',
            __( 'Subscription confirmed', 'wphave' )
        );
    }

    /** Returns the localized subscriber confirmation message. */
    public function resolve_subscriber_confirmation_message() {
        return WPHAVE_Dynamic_Data_Runtime_Context::get(
            'audience.subscriber.confirmation.message',
            __( 'Thank you. Your email address has been confirmed successfully.', 'wphave' )
        );
    }

    /** Returns the localized subscriber confirmation action label. */
    public function resolve_subscriber_confirmation_action_label() {
        return WPHAVE_Dynamic_Data_Runtime_Context::get(
            'audience.subscriber.confirmation.action_label',
            __( 'Back to website', 'wphave' )
        );
    }

    /** Returns the subscriber confirmation action URL. */
    public function resolve_subscriber_confirmation_action_url() {
        return WPHAVE_Dynamic_Data_Runtime_Context::get(
            'audience.subscriber.confirmation.action_url',
            home_url( '/' )
        );
    }

    /**
     * Resolves the target post title.
     *
     * @param array $args Token arguments.
     * @return string Post title or empty string.
     */

    public function resolve_post_title( $args ) {
        $post = $this->get_post_from_args( $args );
        return $post ? get_the_title( $post ) : '';
    }

    /**
     * Resolves the target post permalink.
     *
     * @param array $args Token arguments.
     * @return string Post permalink or empty string.
     */

    public function resolve_post_url( $args ) {
        $post = $this->get_post_from_args( $args );
        return $post ? get_permalink( $post ) : '';
    }

    /**
     * Resolves the target post id.
     *
     * @param array $args Token arguments.
     * @return string Post id or empty string.
     */

    public function resolve_post_id( $args ) {
        $post = $this->get_post_from_args( $args );
        return $post ? (string) $post->ID : '';
    }

    /**
     * Resolves the target post slug.
     *
     * @param array $args Token arguments.
     * @return string Post slug or empty string.
     */

    public function resolve_post_slug( $args ) {
        $post = $this->get_post_from_args( $args );
        return $post ? (string) $post->post_name : '';
    }

    /**
     * Resolves the target post excerpt.
     *
     * Uses the manual excerpt when present, otherwise trims the post content.
     *
     * @param array $args Token arguments.
     * @return string Plain-text excerpt or empty string.
     */

    public function resolve_post_excerpt( $args ) {
        $post = $this->get_post_from_args( $args );

        if ( ! $post ) {
            return '';
        }

        if ( ! empty( $post->post_excerpt ) ) {
            return wp_strip_all_tags( $post->post_excerpt );
        }

        return wp_trim_words( wp_strip_all_tags( $post->post_content ), 30 );
    }

    /**
     * Resolves the target post publish date using the site's date format.
     *
     * @param array $args Token arguments.
     * @return string Formatted publish date or empty string.
     */

    public function resolve_post_date( $args ) {
        $post = $this->get_post_from_args( $args );
        return $post ? mysql2date( get_option( 'date_format' ) ?: 'Y-m-d', $post->post_date, true ) : '';
    }

    /**
     * Resolves the target post modified date using the site's date format.
     *
     * @param array $args Token arguments.
     * @return string Formatted modified date or empty string.
     */

    public function resolve_post_date_modified( $args ) {
        $post = $this->get_post_from_args( $args );
        return $post ? mysql2date( get_option( 'date_format' ) ?: 'Y-m-d', $post->post_modified, true ) : '';
    }

    /**
     * Resolves the target post type.
     *
     * @param array $args Token arguments.
     * @return string Post type or empty string.
     */

    public function resolve_post_type( $args ) {
        $post = $this->get_post_from_args( $args );
        return $post ? ( get_post_type( $post ) ?: '' ) : '';
    }

    /**
     * Resolves the target post status.
     *
     * @param array $args Token arguments.
     * @return string Post status or empty string.
     */

    public function resolve_post_status( $args ) {
        $post = $this->get_post_from_args( $args );
        return $post ? ( get_post_status( $post ) ?: '' ) : '';
    }

    /**
     * Resolves the target post author's display name.
     *
     * @param array $args Token arguments.
     * @return string Author display name or empty string.
     */

    public function resolve_author_name( $args ) {
        $post = $this->get_post_from_args( $args );
        $author_id = $this->get_author_id( $post );
        return $author_id ? (string) get_the_author_meta( 'display_name', $author_id ) : '';
    }

    /**
     * Resolves the target post author's user id.
     *
     * @param array $args Token arguments.
     * @return string Author id or empty string.
     */

    public function resolve_author_id( $args ) {
        $post = $this->get_post_from_args( $args );
        $author_id = $this->get_author_id( $post );
        return $author_id ? (string) $author_id : '';
    }

    /**
     * Resolves the target post author's archive URL.
     *
     * @param array $args Token arguments.
     * @return string Author archive URL or empty string.
     */

    public function resolve_author_url( $args ) {
        $post = $this->get_post_from_args( $args );
        $author_id = $this->get_author_id( $post );
        return $author_id ? (string) get_author_posts_url( $author_id ) : '';
    }

    /**
     * Resolves the target post author's first name.
     *
     * @param array $args Token arguments.
     * @return string Author first name or empty string.
     */

    public function resolve_author_first_name( $args ) {
        $post = $this->get_post_from_args( $args );
        $author_id = $this->get_author_id( $post );
        return $author_id ? (string) get_the_author_meta( 'first_name', $author_id ) : '';
    }

    /**
     * Resolves the target post author's last name.
     *
     * @param array $args Token arguments.
     * @return string Author last name or empty string.
     */

    public function resolve_author_last_name( $args ) {
        $post = $this->get_post_from_args( $args );
        $author_id = $this->get_author_id( $post );
        return $author_id ? (string) get_the_author_meta( 'last_name', $author_id ) : '';
    }

    /**
     * Resolves the target post author's biography as plain text.
     *
     * @param array $args Token arguments.
     * @return string Author biography or empty string.
     */

    public function resolve_author_bio( $args ) {
        $post = $this->get_post_from_args( $args );
        $author_id = $this->get_author_id( $post );
        return $author_id ? wp_strip_all_tags( (string) get_the_author_meta( 'description', $author_id ) ) : '';
    }

    /**
     * Resolves the target post comment count.
     *
     * @param array $args Token arguments.
     * @return string Comment count or empty string.
     */

    public function resolve_comment_number( $args ) {
        $post = $this->get_post_from_args( $args );
        return $post ? (string) get_comments_number( $post->ID ) : '';
    }

    /**
     * Resolves a custom post meta value by key and optional dot path.
     *
     * Protected meta keys are blocked by default and can be allowed through the
     * wphave_dynamic_data_can_read_meta_key filter.
     *
     * @param array $args Token arguments containing field_name.
     * @return mixed Post meta value or empty string.
     */

    public function resolve_post_meta( $args ) {
        $post = $this->get_post_from_args( $args );
        $field_name = $args['field_name'] ?? '';

        if ( ! $post || ! $field_name ) {
            return '';
        }

        $parts = explode( '.', $field_name, 2 );
        $key = $parts[0];
        $path = $parts[1] ?? '';

        if ( ! $this->can_read_meta_key( $key, $post->ID, $args ) ) {
            return '';
        }

        $value = get_post_meta( $post->ID, $key, true );

        if ( $path !== '' ) {
            $value = $this->get_value_by_path( $value, $path );
        }

        return $value;
    }

	/**
	 * Resolve a registered WPHAVE Content Field for the target post.
	 *
	 * Unlike the compatibility post_meta resolver, this path accepts no arbitrary
	 * meta key. The active field-group assignment is checked again at render time,
	 * so stale or manually crafted tokens fail closed.
	 *
	 * @param array $args Token arguments containing the stable field key.
	 * @return string Registered value, field default or an empty string.
	 */
	public function resolve_content_model( $args ) {
		$post = $this->get_post_from_args( $args );
		$key = sanitize_key( $args['field_name'] ?? '' );

		if (
			! $post
			|| ! $key
			|| ! class_exists( 'WPHAVE_Content_Models' )
			|| ! wphave_content_models_feature_enabled()
		) {
			return '';
		}

		$field = WPHAVE_Content_Model_Registry::field( $post->post_type, $key );
		if ( ! $field ) {
			return '';
		}

		return WPHAVE_Content_Model_Value_Repository::get( $post, $key );
	}

    /**
     * Resolves an ACF field value by field name and optional dot path.
     *
     * Returns an empty string when ACF is not active.
     *
     * @param array $args Token arguments containing field_name.
     * @return mixed ACF field value or empty string.
     */

    public function resolve_acf( $args ) {
        $post = $this->get_post_from_args( $args );
        $field_name = $args['field_name'] ?? '';

        if ( ! $post || ! $field_name || ! function_exists( 'get_field' ) ) {
            return '';
        }

        $parts = explode( '.', $field_name, 2 );
        $key = $parts[0];
        $path = $parts[1] ?? '';
        $value = get_field( $key, $post->ID );

        if ( $path !== '' ) {
            $value = $this->get_value_by_path( $value, $path );
        }

        return $value;
    }

    /**
     * Checks whether a post meta key may be exposed through dynamic data.
     *
     * This protects private/protected meta by default. Projects can opt in specific
     * keys through the wphave_dynamic_data_can_read_meta_key filter.
     *
     * @param string $key Meta key.
     * @param int $post_id Target post id.
     * @param array $args Token arguments.
     * @return bool Whether the key may be read.
     */

    protected function can_read_meta_key( $key, $post_id, $args ) {
        $allowed = $key && ! is_protected_meta( $key, 'post' );

        return (bool) apply_filters( 'wphave_dynamic_data_can_read_meta_key', $allowed, $key, $post_id, $args );
    }

}
