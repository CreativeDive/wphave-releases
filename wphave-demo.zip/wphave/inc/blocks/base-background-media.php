<?php

/** The content-owned base medium is rendered before design-owned layers. */
final class WPHAVE_Base_Background_Media {
	public static function active( $media ): bool {
		if ( ! is_array( $media ) ) {
			return false;
		}

		$image = is_array( $media['image'] ?? null ) ? $media['image'] : array();
		$video = is_array( $media['video'] ?? null ) ? $media['video'] : array();
		$data  = is_array( $image['data'] ?? null ) ? $image['data'] : array();

		return 'featured' === ( $image['type'] ?? '' )
			|| ! empty( $data['id'] )
			|| ! empty( $data['url'] )
			|| ! empty( $video['file'] )
			|| ! empty( $video['fileAlternate'] )
			|| ! empty( $video['url'] )
			|| ! empty( $video['urlAlternate'] );
	}

	public static function classes( $media ): string {
		return '';
	}

	public static function style( $media ): string {
		$image = is_array( $media['image'] ?? null ) ? $media['image'] : array();
		$css   = array();
		$fit   = $image['fit'] ?? null;

		if ( in_array( $fit, array( 'cover', 'contain', 'fill', 'none', 'scale-down' ), true ) ) {
			$css[] = '--bg-mda-img-fit:' . $fit;
		}

		$focal = is_array( $image['data']['focal'] ?? null ) ? $image['data']['focal'] : array();
		if ( isset( $focal['left'], $focal['top'] ) && is_numeric( $focal['left'] ) && is_numeric( $focal['top'] ) ) {
			$left  = min( 100, max( 0, (float) $focal['left'] ) );
			$top   = min( 100, max( 0, (float) $focal['top'] ) );
			$css[] = '--bg-mda-img-pos:' . $left . '% ' . $top . '%';
		}

		return implode( ';', $css );
	}
}
