<?php

/**
 * Render the SVG filters required by duotone-enabled blocks.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Build SVG filter definitions for the requested duotone presets.
 *
 * @param array|string $filters Preset identifiers or all available presets.
 * @return string|null SVG filter markup when presets are available.
 */

if ( ! function_exists( 'wphave_svg_duotones_filter' ) ) :

	function wphave_svg_duotones_filter( $filters ) {
		$alpha = '0 1';
		$matrix = '.33 .33 .33 0 0 .33 .33 .33 0 0 .33 .33 .33 0 0 0 0 0 1 0';
		$args = 'all' === $filters ? array( 'output' => 'all' ) : array( 'load' => $filters );
		$filters = wphave_duotones( $args );

		if( ! $filters ) {
			return null;
		}

		ob_start();
		?>
		<svg class="duotones-filter" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" focusable="false" role="none">
			<defs>
				<?php foreach( $filters as $key => $data ) {
					$color1 = explode( ',', $data[0] );
					$color2 = explode( ',', $data[1] );
					$r = ( (int) ( $color1[0] ?? 0 ) / 255 ) . ' ' . ( (int) ( $color2[0] ?? 0 ) / 255 );
					$g = ( (int) ( $color1[1] ?? 0 ) / 255 ) . ' ' . ( (int) ( $color2[1] ?? 0 ) / 255 );
					$b = ( (int) ( $color1[2] ?? 0 ) / 255 ) . ' ' . ( (int) ( $color2[2] ?? 0 ) / 255 );
					$id = sanitize_html_class( 'duotone-filter-' . $key );
					// sRGB keeps SVG filters consistent with CSS gradient color interpolation.
					?>
					<filter id="<?php echo esc_attr( $id ); ?>" x="-10%" y="-10%" width="120%" height="120%" filterUnits="objectBoundingBox" primitiveUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
						<feColorMatrix type="matrix" values="<?php echo esc_attr( $matrix ); ?>" in="SourceGraphic" result="colormatrix" />
						<feComponentTransfer in="colormatrix" result="componentTransfer">
							<feFuncR type="table" tableValues="<?php echo esc_attr( $r ); ?>" />
							<feFuncG type="table" tableValues="<?php echo esc_attr( $g ); ?>" />
							<feFuncB type="table" tableValues="<?php echo esc_attr( $b ); ?>" />
							<feFuncA type="table" tableValues="<?php echo esc_attr( $alpha ); ?>" />
						</feComponentTransfer>
					</filter>
				<?php } ?>
			</defs>
		</svg>
		<?php
		$output = ob_get_clean();

		return $output;
	}

endif;

/**
 * Create the deterministic identifier shared by editor and frontend filters.
 *
 * Only the color pair is part of the identifier. Derived state is deliberately
 * not persisted in block data, so copied and legacy values remain renderable.
 *
 * @param string $shadow Shadow color.
 * @param string $highlight Highlight color.
 * @return string CSS-safe filter identifier.
 */

if ( ! function_exists( 'wphave_custom_duotone_filter_id' ) ) :

	function wphave_custom_duotone_filter_id( $shadow, $highlight ) {
		$value = (string) $shadow . "\0" . (string) $highlight;
		$hash = 5381;
		$length = strlen( $value );

		for( $index = 0; $index < $length; $index++ ) {
			$hash = ( ( $hash * 33 ) ^ ord( $value[$index] ) ) & 0xffffffff;
		}

		return 'wphave-custom-duotone-' . base_convert( sprintf( '%u', $hash ), 10, 36 );
	}

endif;

/**
 * Validate a custom duotone color without silently accepting invalid input.
 *
 * @param mixed $color Requested color.
 * @return string Validated color, or an empty string.
 */

if ( ! function_exists( 'wphave_sanitize_duotone_color' ) ) :

	function wphave_sanitize_duotone_color( $color ) {
		$input = trim( (string) $color );
		$sanitized = WPHAVE_Safe_SVG::sanitize_color( $input );

		if( 'currentColor' === $sanitized && 'currentcolor' !== strtolower( $input ) ) {
			return '';
		}

		return $sanitized;
	}

endif;

/**
 * Resolve the SVG filter identifier for preset or custom duotone data.
 *
 * @param array $duotone Duotone feature data.
 * @return string Filter identifier, or an empty string.
 */

if ( ! function_exists( 'wphave_resolve_svg_duotone_filter_id' ) ) :

	function wphave_resolve_svg_duotone_filter_id( $duotone ) {
		$custom_colors = $duotone['customColors'] ?? array();
		$shadow = wphave_sanitize_duotone_color( $custom_colors['shadow'] ?? '' );
		$highlight = wphave_sanitize_duotone_color( $custom_colors['highlight'] ?? '' );

		if( $shadow && $highlight ) {
			return wphave_custom_duotone_filter_id( $shadow, $highlight );
		}

		$colors = $duotone['colors'] ?? '';
		return '' !== (string) $colors ? sanitize_html_class( 'duotone-filter-' . $colors ) : '';
	}

endif;

/**
 * Compile SVG filter URL variables for one block and its backgrounds.
 *
 * @param string $id Block wrapper ID.
 * @param array $wphave WPHAVE block settings.
 * @return string CSS declarations referencing SVG filters.
 */

if ( ! function_exists( 'wphave_duotone_style_overrides' ) ) :

	function wphave_duotone_style_overrides( $id, $wphave ) {
		$id = sanitize_html_class( $id );

		if( ! $id || ! is_array( $wphave ) ) {
			return '';
		}

		$rules = array();
		$image_duotone = $wphave['features']['duotones'] ?? array();
		$image_filter_id = wphave_resolve_svg_duotone_filter_id( $image_duotone );

		if( $image_filter_id ) {
			$rules[] = sprintf( '#%s{--duo-img-svg:url(#%s);}', $id, $image_filter_id );
		}

		$layers = $wphave['background']['layers'] ?? array();
		foreach( is_array( $layers ) ? $layers : array() as $index => $layer ) {
			if( ! is_array( $layer ) ) {
				continue;
			}

			$background_duotone = $layer['duotones'] ?? array();
			$background_filter_id = wphave_resolve_svg_duotone_filter_id( $background_duotone );
			if( $background_filter_id ) {
				$rules[] = sprintf(
					'#%s>.bbg.bgly-%d{--bg-duo-svg:url(#%s);}',
					$id,
					$index,
					$background_filter_id
				);
			}
		}

		return implode( '', $rules );
	}

endif;

/**
 * Build the required SVG definition for preset or custom duotone data.
 *
 * @param array $duotone Duotone feature data.
 * @return string SVG definition markup, or an empty string.
 */

if ( ! function_exists( 'wphave_svg_duotone_filter_for_value' ) ) :

	function wphave_svg_duotone_filter_for_value( $duotone ) {
		$custom_filter = wphave_svg_custom_duotone_filter( $duotone );
		if( $custom_filter ) {
			return $custom_filter;
		}

		$colors = $duotone['colors'] ?? '';
		return '' !== (string) $colors ? (string) wphave_svg_duotones_filter( array( $colors ) ) : '';
	}

endif;

/**
 * Build an SVG filter definition for a custom duotone color pair.
 *
 * Editor and frontend derive the identifier from the same color pair, avoiding
 * migrations and render-order coupling.
 *
 * @param array $duotone Duotone feature data.
 * @return string Custom SVG filter markup, or an empty string for invalid data.
 */

if ( ! function_exists( 'wphave_svg_custom_duotone_filter' ) ) :

	function wphave_svg_custom_duotone_filter( $duotone ) {
		$custom_colors = $duotone['customColors'] ?? array();
		$shadow = wphave_sanitize_duotone_color( $custom_colors['shadow'] ?? '' );
		$highlight = wphave_sanitize_duotone_color( $custom_colors['highlight'] ?? '' );

		if( ! $shadow || ! $highlight ) {
			return '';
		}

		$filter_id = wphave_custom_duotone_filter_id( $shadow, $highlight );

		$luminance_matrix = '0.2126 0.7152 0.0722 0 0 0.2126 0.7152 0.0722 0 0 0.2126 0.7152 0.0722 0 0 0 0 1 0';

		ob_start();
		?>
		<svg class="duotones-filter" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" focusable="false" role="none">
			<defs>
				<filter id="<?php echo esc_attr( $filter_id ); ?>" x="-10%" y="-10%" width="120%" height="120%" filterUnits="objectBoundingBox" primitiveUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
					<feColorMatrix type="matrix" values="<?php echo esc_attr( $luminance_matrix ); ?>" in="SourceGraphic" result="luminance" />
					<feColorMatrix in="luminance" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 -1 0 0 0 1" result="shadowMask" />
					<feColorMatrix in="luminance" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0" result="highlightMask" />
					<feFlood flood-color="<?php echo esc_attr( $shadow ); ?>" result="shadow" />
					<feFlood flood-color="<?php echo esc_attr( $highlight ); ?>" result="highlight" />
					<feComposite in="shadow" in2="shadowMask" operator="in" result="shadowTone" />
					<feComposite in="highlight" in2="highlightMask" operator="in" result="highlightTone" />
					<feComposite in="shadowTone" in2="highlightTone" operator="arithmetic" k2="1" k3="1" result="duotone" />
					<feComposite in="duotone" in2="SourceGraphic" operator="in" />
				</filter>
			</defs>
		</svg>
		<?php
		return ob_get_clean();
	}

endif;

/**
 * Append collected duotone filters to the rendered block output.
 *
 * @param string $content Rendered content.
 * @return string Content with the required SVG filters.
 */

if ( ! function_exists( 'wphave_render_duotones_filter' ) ) :

	function wphave_render_duotones_filter( $content ) {
		$duotones = apply_filters( 'wphave_post_duotones', array() ) ?: array();

		if( $duotones ) {
			$content .= wphave_svg_duotones_filter( array_unique( $duotones ) );
		}

		return $content;
	}

endif;

add_filter( 'wphave_post_render_after', 'wphave_render_duotones_filter', 10, 1 );
