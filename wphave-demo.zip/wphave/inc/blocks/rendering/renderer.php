<?php

/**
 * Resolve block templates and coordinate server-side WPHAVE block rendering.
 */

class WPHAVE_Block_Renderer {
	/**
	 * Resolve and validate the render template path for a WPHAVE block.
	 *
	 * @param string $block_name Registered block name.
	 * @return string
	 */

	public static function render_path($block_name) {
		if (!is_string($block_name) || !preg_match('/^wphave\/[a-z0-9-]+$/', $block_name)) {
			return '';
		}

		$paths = WPHAVE_Block_Registry::block_directories();
		$block_slug = str_replace('wphave/', '', $block_name);

		$render = '';
		foreach ($paths as $key => $path) {
			$base_path = realpath($path);
			if (!$base_path) {
				continue;
			}

			$block_path = $base_path . '/' . $block_slug;
			$block_render = $block_path . '/render.php';
			$real_render = realpath($block_render);
			// SECURITY INVARIANT: A registered block name selects executable PHP
			// only after the resolved file remains canonically below a registered
			// block root. Slug validation alone never authorizes an include path.
			if (
				$real_render &&
				str_starts_with($real_render, $base_path . DIRECTORY_SEPARATOR) &&
				file_exists($real_render)
			) {
				$render = $real_render;
			}
		}

		return $render;
	}

	/**
	 * Render a dynamic WPHAVE block through its validated template and wrapper pipeline.
	 *
	 * @param array $attr Block attributes.
	 * @param string $content Saved or rendered inner content.
	 * @param WP_Block $wp_block Runtime block instance.
	 * @return string|null
	 */

	public static function render($attr, $content, $wp_block) {
		$parsed_block = (array) $wp_block;
		$block_name = $parsed_block['name'] ?? '';
		$block_render = self::render_path($block_name);

		// Prefer the block context inside loops; the global post is only a fallback.
		$block_context = (array) ($parsed_block['context'] ?? []);
		$post_id = absint($block_context['postId'] ?? get_the_ID());

		/*
		 * WPHAVE blocks persist their name and attributes, but deliberately render
		 * frontend HTML here instead of treating React save() markup as canonical.
		 * PHP markup can therefore evolve without Gutenberg HTML deprecations. Keep
		 * previously released attribute names/semantics readable here (normalize a
		 * legacy key when necessary), because those values remain in post content.
		 */
		$block = $attr ?? [];
		$block['name'] = $block['name'] ?? $block_name;

		// Get the block anchor
		$anchor = $block['anchor'] ?? '';

		// Get the wrapper tag name
		$tag_name = $block['tagName'] ?? 'div';

		// Get custom classes (core feature) entered by the user
		$user_classes = $block['className'] ?? '';

		// Get the block link
		$link = $attr['link'] ?? '';

		// Make wphave attributes available by [$wphave]
		$wphave = $attr['wphave'] ?? [];
		$local_wphave = $wphave;

		$global_block_style_id = absint($wphave['useBlockStyle'] ?? 0);
		$global_block_style_is_compatible = $global_block_style_id
			? WPHAVE_Block_Styles::is_compatible($global_block_style_id, $block_name)
			: false;

		if ($global_block_style_is_compatible) {
			$global_block_style_attrs = WPHAVE_Block_Styles::get_attrs($global_block_style_id);
			$local_wphave = WPHAVE_Block_Styles::strip_owned_attrs(
				$local_wphave,
				$global_block_style_attrs,
			);
			$wphave = WPHAVE_Block_Styles::apply_attrs($wphave, $block_name);
			WPHAVE_Block_Styles::enqueue_style_css($global_block_style_id);
		}

		// Check the block features
		$features = $wphave['features'] ?? [];

		// Check if this block is marked as draft
		$is_draft = $wphave['features']['draft'] ?? false;

		// Make wphave block specific settings attributes available by [$settings]
		$settings = $wphave['settings'] ?? [];

		// Make block context available by [$context]
		$context = $block_context;

		// Get block support
		$supports = WPHAVE_Block_Inspector::block_type_support($block_name);

		// Check if the block contains inner blocks
		$has_inner_blocks = trim($content) !== '';

		// Get the block tooltip
		$block_tooltip = $block['tooltip'] ?? '';
		$block_tooltip_placement = $settings['tooltip']['placement'] ?? 'top';

		/*
		 * Check the block access
		 * 1. Access may be restricted by a user-role condition.
		 * 2. Access may be limited by a schedule condition.
		 * 3. Access may be resctriced by block draft.
		 * ! Important: This check must be performed before using the block cache.
		 * ! Otherwise, the restricted block by user role or with timing will not be displayed correctly.
		 */

		$access = wphave_allow_block_access($wphave);

		if (!$access || $is_draft) {
			return;
		}

		// Get block specific wphave styles
		$block_styles_general = $local_wphave['styles'] ?? '';
		$block_styles_layout = $local_wphave['stylesLayout'] ?? '';
		$block_styles_child = $local_wphave['stylesChild'] ?? '';
		$block_styles_backgrounds = $local_wphave['stylesBackgrounds'] ?? [];
		$block_styles_custom_source = $local_wphave['features']['css'] ?? '';

		// Get block specific wphave class names
		$block_class_names = $wphave['classNames'] ?? [];
		$block_class_names = !is_array($block_class_names)
			? [$block_class_names]
			: $block_class_names;
		$local_block_class_names = $local_wphave['classNames'] ?? [];
		$local_block_class_names = !is_array($local_block_class_names)
			? [$local_block_class_names]
			: $local_block_class_names;
		$block_class_names = array_merge($block_class_names, $local_block_class_names);
		$block_class_names = array_merge(
			$block_class_names,
			wphave_block_manual_class_names_from_wphave($wphave),
		);
		$block_class_names = array_merge(
			$block_class_names,
			wphave_css_class_names_from_ids(wphave_css_class_ids_from_wphave($wphave)),
		);

		// Derived class caches may predate today's defaults. Match the editor's
		// layout mode before CSS determines intrinsic flex-item dimensions.
		$block_class_names = wphave_block_wrapper_layout_classes(
			$block_class_names,
			$wphave,
			$supports,
		);

		if ($global_block_style_is_compatible) {
			$block_class_names[] = WPHAVE_Block_Styles::style_class($global_block_style_id);
		}

		// Generate a unique block id
		// If an "anchor" is used, we set the anchor as id, instead of our generated block id.
		// ! Important: If the user use the same anchor text multiple times, this could break the custom block style assignment.
		/*
		 * The same ID is used in HTML and as a CSS selector. Normalize anchors
		 * before composing CSS so an edited block payload cannot escape the
		 * selector and append arbitrary declarations.
		 */

		$id = $anchor ? sanitize_html_class($anchor) : '';
		$id = $id ?: 'block-' . uniqid();

		// Generate block styles selector
		$block_styles_selector = '#' . $id;

		$styles_general = $block_styles_general
			? WPHAVE_CSS_Compiler::scope_source($block_styles_general, $block_styles_selector)
			: '';
		$styles_layout = $block_styles_layout
			? WPHAVE_CSS_Compiler::scope_layout_source(
				$block_styles_layout,
				$block_styles_selector . ' > .ly-con',
			)
			: '';
		$styles_child = $block_styles_child
			? WPHAVE_CSS_Compiler::scope_source(
				$block_styles_child,
				$block_styles_selector . ' > *',
			)
			: '';
		$styles_custom_source = is_string($block_styles_custom_source)
			? $block_styles_custom_source
			: '';
		$styles_custom = WPHAVE_CSS_Compiler::scope_source(
			$styles_custom_source,
			$block_styles_selector,
		);

		$block_backgrounds_index = 0;
		$block_backgrounds_styles = [];
		foreach ($block_styles_backgrounds as $layer_css) {
			$block_background_style = $layer_css
				? WPHAVE_CSS_Compiler::scope_source(
					$layer_css,
					$block_styles_selector . ' > .bgly-' . $block_backgrounds_index,
				)
				: '';
			$block_backgrounds_styles[] = $block_background_style;
			$block_backgrounds_index++;
		}

		$block_styles =
			$styles_general .
			$styles_layout .
			$styles_child .
			implode('', $block_backgrounds_styles) .
			$styles_custom;
		$global_class_styles = function_exists('wphave_css_class_fallback_styles_from_wphave')
			? wphave_css_class_fallback_styles_from_wphave($wphave)
			: '';
		if ($global_class_styles) {
			WPHAVE_Style_Engine::instance()->print_inline_styles($global_class_styles);
		}

		// [$block_args] can be modified within the render.php file
		$block_args = [];
		$block_args['postId'] = $post_id;
		$block_args['id'] = $id;
		$block_args['block'] = $block;
		$block_args['block_name'] = $block_name;
		$block_args['supports'] = $supports;
		$block_args['class'] = $block_class_names;
		$block_args['defaultClasses'] = $wphave['classNames'] ?? '';
		$block_args['css'] = $block_styles;
		$block_args['blockWrapper'] = true;
		$block_args['tag'] = $tag_name;
		$block_args['closeButton'] = false;
		$block_args['contentBefore'] = false;
		$block_args['contentAfter'] = false;
		$block_args['beforeInnerBlocks'] = false;
		$block_args['afterInnerBlocks'] = false;
		$block_args['preventOutput'] = false;
		$block_args['preventBlockClasses'] = false;
		$block_args['preventBlockBackgroundOutput'] = false;
		$block_args['beforeLayoutContainer'] = false;
		$block_args['renderContentInTemplate'] = false;
		$block_args['dataAttributes'] = [];
		$block_args['linkAttributes'] = [];

		$color_context = sanitize_key($wphave['features']['colorContext'] ?? '');

		if ($color_context) {
			$block_args['dataAttributes'][] =
				'data-wphave-color-context="' . esc_attr($color_context) . '"';
		}

		/*
		 * Add block tooltip
		 */

		if ($block_tooltip) {
			$block_args['dataAttributes'][] = 'data-tooltip="' . esc_attr($block_tooltip) . '"';
			$block_args['dataAttributes'][] =
				'data-placement="' . esc_attr($block_tooltip_placement) . '"';
		}

		/*
		 * Call block clip path shapes
		 * See: "wp_footer" -> "wphave_output_block_clip_path_html" action
		 */

		$foreground = $wphave['foreground'] ?? [];
		if ($foreground) {
			wphave_call_block_clip_path_masks($foreground);
		}

		$background_layers_value = $wphave['background']['layers'] ?? [];
		$background_layers = is_array($background_layers_value)
			? array_filter($background_layers_value, 'is_array')
			: [];
		if ($background_layers) {
			foreach ($background_layers as $layer) {
				wphave_call_block_clip_path_masks($layer);
			}
		}

		/*
		 * Include the block template
		 */

		ob_start();
		if (file_exists($block_render)) {
			include $block_render;
		}
		if (!$block_args['renderContentInTemplate']) {
			// ! Inner block content or text content is automatically outputted here without defining a "render.php" file.
			// Set "renderContentInTemplate" to "true" inside of the "render.php" file, to work with the "content" in the "render.php" itself.
			echo $content;
		}
		$block_content = ob_get_clean();

		if ($block_args['preventOutput']) {
			return;
		}

		$before = $block_args['contentBefore'] ?? '';
		$after = $block_args['contentAfter'] ?? '';

		ob_start();

		if ($before) {
			echo $before;
		}
		do_action('block_wrapper_start', $wphave, $block_args);
		echo $block_content;
		do_action('block_wrapper_end', $wphave, $block_args);
		if ($after) {
			echo $after;
		}

		$block_output = ob_get_clean();

		return $block_output;
	}

	/**
	 * Determine whether WordPress is handling a block-renderer REST request.
	 *
	 * @return bool
	 */

	public static function is_server_side_render_request() {
		if (!defined('REST_REQUEST') || !REST_REQUEST) {
			return false;
		}

		$route = $_SERVER['REQUEST_URI'] ?? '';
		return strpos($route, '/wp/v2/block-renderer/') !== false;
	}
}

/**
 * Preserve the established request helper used by render templates and the style engine.
 *
 * @return bool Whether this is a block-renderer REST request.
 */

function wphave_is_server_side_render_block_request() {
	return WPHAVE_Block_Renderer::is_server_side_render_request();
}
