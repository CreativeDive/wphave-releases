<?php

/**
 * Resolve only known decorative animation classes from persisted layer values.
 * Unknown modes remain visible as static effects.
 */
function wphave_background_effect_animation_classes(
	$value,
	$allowed_modes,
	$animation_prefix,
	$loop_class,
) {
	if (!is_array($value)) {
		return '';
	}

	$mode = $value['animation'] ?? 'none';
	if (!is_string($mode) || !in_array($mode, $allowed_modes, true)) {
		return '';
	}

	$classes = [$animation_prefix . $mode];
	if (($value['loop'] ?? true) !== false) {
		$classes[] = $loop_class;
	}

	return implode(' ', $classes);
}
