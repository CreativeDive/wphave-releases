<?php

/**
 * Output SVG clip paths collected while rendering blocks.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Print the clip-path definitions collected during the current request.
 *
 * The collector lives in the design-system renderer because it knows when a
 * definition is used. This frontend integration owns only final placement.
 *
 * @return void
 */

if ( ! function_exists( 'wphave_output_block_clip_path_html' ) ) :

	function wphave_output_block_clip_path_html() {
		global $wphave_clip_path_shape_html;

		if( ! empty( $wphave_clip_path_shape_html ) ) {
			echo implode( '', $wphave_clip_path_shape_html );
		}
	}

endif;

add_action( 'wp_footer', 'wphave_output_block_clip_path_html', 9999 );
