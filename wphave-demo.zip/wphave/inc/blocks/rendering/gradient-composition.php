<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Render a versioned Gradient Composition snapshot.
 *
 * Random composition happens once in the editor. The frontend consumes only
 * materialized geometry, preventing generator updates from changing published
 * designs and avoiding a second generator implementation in PHP.
 */
function wphave_render_gradient_composition( $composition ) {
	if( ! is_array( $composition ) || ! is_array( $composition['snapshot'] ?? null ) ) {
		return '';
	}

	$snapshot = $composition['snapshot'];
	if( 6 !== ( $snapshot['generatorVersion'] ?? null ) || ! is_array( $snapshot['blobs'] ?? null ) || ! array_is_list( $snapshot['blobs'] ) ) {
		return '';
	}

	$number = static function( $value, $min, $max, $fallback = 0 ) {
		$value = is_numeric( $value ) ? (float) $value : (float) $fallback;
		if ( ! is_finite( $value ) ) {
			$value = (float) $fallback;
		}
		return max( $min, min( $max, $value ) );
	};
	$color = static function( $value ) {
		$value = is_string( $value ) ? trim( $value ) : '';
		$pattern = '/^(#[\da-f]{3,8}|(?:rgb|hsl)a?\([\d\s.,%+\-\/]+\)|var\(--[\w-]+(?:\s*,\s*[^;{}]+)?\)|transparent|currentColor)$/i';
		return preg_match( $pattern, $value ) ? $value : 'transparent';
	};
	$roles = array( 'ambient', 'color', 'accent' );
	$rotation = $number( $composition['rotation'] ?? 0, -180, 180 );
	$zoom = $number( $composition['zoom'] ?? 1.15, 1, 3, 1.15 );
	$stretch = $number( $composition['stretch'] ?? 1, 0.5, 3, 1 );
	$scale_y = $zoom * $stretch;
	$output = '';

	foreach( array_slice( $snapshot['blobs'], 0, 7 ) as $index => $blob ) {
		if( ! is_array( $blob ) ) {
			continue;
		}

		$role = sanitize_key( $blob['role'] ?? '' );
		$role = in_array( $role, $roles, true ) ? $role : $roles[$index % count( $roles )];
		$blob_color = $color( $blob['color'] ?? '' );
		$fade = $number( $blob['fade'] ?? 75, 45, 98, 75 );
		$shape = 'round' === ( $blob['shape'] ?? '' ) ? 'circle' : 'ellipse';
		$motion = is_array( $blob['motion'] ?? null ) ? $blob['motion'] : array();
		$gradient = sprintf(
			'radial-gradient(%1$s at center,color-mix(in srgb,%2$s 82%%,white) 0%%,%2$s 18%%,color-mix(in srgb,%2$s 48%%,transparent) 48%%,transparent %3$s%%)',
			$shape,
			$blob_color,
			$fade
		);
		$styles = array(
			'left:' . $number( $blob['x'] ?? 50, -180, 280, 50 ) . '%',
			'top:' . $number( $blob['y'] ?? 50, -180, 280, 50 ) . '%',
			'width:' . $number( $blob['width'] ?? 40, 8, 180, 40 ) . '%',
			'height:' . $number( $blob['height'] ?? 40, 8, 180, 40 ) . '%',
			'opacity:' . $number( $blob['opacity'] ?? 1, 0, 1, 1 ),
			'background:' . $gradient,
			'transform:translate(-50%,-50%) rotate(' . ( $number( $blob['rotation'] ?? 0, -180, 180 ) + $rotation ) . 'deg) scale(' . $zoom . ',' . $scale_y . ')',
			'--gradient-composition-motion-x:' . $number( $motion['x'] ?? 0, -24, 24 ) . '%',
			'--gradient-composition-motion-y:' . $number( $motion['y'] ?? 0, -24, 24 ) . '%',
			'--gradient-composition-motion-rotation:' . $number( $motion['rotation'] ?? 0, -12, 12 ) . 'deg',
			'--gradient-composition-motion-scale:' . $number( $motion['scale'] ?? 1, 1, 1.15, 1 ),
			'--gradient-composition-motion-delay:' . $number( $motion['delay'] ?? 0, -30, 0 ) . 's',
			'--gradient-composition-blob-duration:' . $number( $motion['duration'] ?? 18, 6, 150, 18 ) . 's',
		);
		// Every component above is independently allow-listed or range-clamped.
		// safecss_filter_attr() cannot parse color-mix() reliably and would remove
		// the controlled radial gradient, so escape the assembled declaration.
		$output .= '<span class="gradient-composition-blob" data-depth="' . esc_attr( $role ) . '" style="' . esc_attr( implode( ';', $styles ) ) . '"></span>';
	}

	return $output ? '<div class="gradient-composition" aria-hidden="true">' . $output . '</div>' : '';
}
