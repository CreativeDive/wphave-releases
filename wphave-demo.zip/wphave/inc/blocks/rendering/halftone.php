<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Render a compact banded SVG whose point size follows the tone direction.
 */
function wphave_render_halftone( $value, $id_prefix = 'halftone' ) {
	if( ! is_array( $value ) ) {
		return '';
	}

	$number = static function( $input, $min, $max, $fallback ) {
		$input = is_numeric( $input ) ? (float) $input : (float) $fallback;
		if ( ! is_finite( $input ) ) {
			$input = (float) $fallback;
		}
		return round( max( $min, min( $max, $input ) ), 6 );
	};
	$color = static function( $input, $fallback ) {
		$input = is_string( $input ) ? trim( $input ) : '';
		$pattern = '/^(#[\da-f]{3,8}|(?:rgb|hsl)a?\([\d\s.,%+\-\/]+\)|var\(--[\w-]+(?:\s*,\s*[^;{}]+)?\)|transparent|currentColor)$/i';
		return preg_match( $pattern, $input ) ? $input : $fallback;
	};
	$shape = 'square' === ( $value['shape'] ?? '' ) ? 'square' : 'round';
	$dot_color = $color( $value['color'] ?? '', 'var(--wphave-site-color-primary)' );
	$cell_size = $number( $value['cellSize'] ?? 16, 6, 80, 16 );
	$dot_size = $number( $value['dotSize'] ?? 6, 1, $cell_size, 6 );
	$tone_angle = $number( $value['toneAngle'] ?? 135, -180, 180, 135 );
	$tone_start = $number( $value['toneStart'] ?? 15, 0, 80, 15 );
	$tone_end = $number( $value['toneEnd'] ?? 85, 20, 100, 85 );
	if( $tone_end - $tone_start < 20 ) {
		$tone_end = min( 100, $tone_start + 20 );
		$tone_start = max( 0, $tone_end - 20 );
	}
	$tone_start /= 100;
	$tone_end /= 100;
	$prefix = wp_unique_id( sanitize_html_class( $id_prefix, 'halftone' ) . '-' );
	$band_count = 20;
	$patterns = '';
	$bands = '';

	for( $index = 0; $index < $band_count; $index++ ) {
		$progress = ( $index + 0.5 ) / $band_count;
		$normalized = min( 1, max( 0, ( $progress - $tone_start ) / ( $tone_end - $tone_start ) ) );
		$eased = $normalized * $normalized * ( 3 - 2 * $normalized );
		$size = max( 0.01, $dot_size * $eased );
		$pattern_id = $prefix . '-' . $index;
		$shape_markup = 'square' === $shape
			? '<rect x="' . esc_attr( ( $cell_size - $size ) / 2 ) . '" y="' . esc_attr( ( $cell_size - $size ) / 2 ) . '" width="' . esc_attr( $size ) . '" height="' . esc_attr( $size ) . '" fill="' . esc_attr( $dot_color ) . '"/>'
			: '<circle cx="' . esc_attr( $cell_size / 2 ) . '" cy="' . esc_attr( $cell_size / 2 ) . '" r="' . esc_attr( $size / 2 ) . '" fill="' . esc_attr( $dot_color ) . '"/>';
		$patterns .= '<pattern id="' . esc_attr( $pattern_id ) . '" width="' . esc_attr( $cell_size ) . '" height="' . esc_attr( $cell_size ) . '" patternUnits="userSpaceOnUse">' . $shape_markup . '</pattern>';
		$y = -300 + ( 1600 / $band_count ) * $index;
		$bands .= '<rect x="-300" y="' . esc_attr( $y ) . '" width="1600" height="' . esc_attr( 1600 / $band_count + 1 ) . '" fill="url(#' . esc_attr( $pattern_id ) . ')"/>';
	}

	return '<svg viewBox="-300 -300 1600 1600" preserveAspectRatio="xMidYMid slice" focusable="false" aria-hidden="true"><defs>' . $patterns . '</defs><g transform="rotate(' . esc_attr( $tone_angle - 90 ) . ' 500 500)">' . $bands . '</g></svg>';
}
