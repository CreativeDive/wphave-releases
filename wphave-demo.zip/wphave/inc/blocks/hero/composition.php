<?php

/**
 * Determine whether the leading page Hero asks to overlay the global header.
 * Synced references are transparent roots; real layout parents are not.
 */
final class WPHAVE_Hero_Composition {
	private const MAX_SOURCE_BYTES = 2 * 1024 * 1024;

	private static function leading_hero($blocks, $seen = []) {
		foreach ($blocks as $block) {
			$name = $block['blockName'] ?? null;

			if (!$name && trim($block['innerHTML'] ?? '') === '') {
				continue;
			}

			if ($name === 'wphave/hero') {
				return !empty($block['attrs']['wphave']['settings']['attachHeader']);
			}

			if ($name !== 'core/block' || count($seen) >= 32) {
				return false;
			}

			$ref = (int) ($block['attrs']['ref'] ?? 0);
			if (!$ref || isset($seen[$ref])) {
				return false;
			}

			$post = get_post($ref);
			if (
				!$post ||
				$post->post_type !== 'wp_block' ||
				$post->post_status !== 'publish' ||
				$post->post_password ||
				strlen($post->post_content) > self::MAX_SOURCE_BYTES
			) {
				return false;
			}

			$seen[$ref] = true;
			return self::leading_hero(parse_blocks($post->post_content), $seen);
		}

		return false;
	}

	/**
	 * Keep both regions in their normal document order. Only mark the header for
	 * page-specific overlay styling. Dynamic title slots are evaluated once so
	 * their actual visibility determines whether the Hero is the first content.
	 */
	public static function compose($content, $header) {
		$unchanged = ['content' => $content, 'header' => $header];
		if (
			!$header ||
			!is_string($content) ||
			strlen($content) > self::MAX_SOURCE_BYTES
		) {
			return $unchanged;
		}

		$blocks = parse_blocks($content);
		$evaluated_slot = false;
		$leading = null;

		foreach ($blocks as $index => $block) {
			$name = $block['blockName'] ?? null;
			if (!$name && trim($block['innerHTML'] ?? '') === '') {
				continue;
			}

			if (in_array($name, ['wphave/title', 'wphave/subtitle'], true)) {
				$html = render_block($block);
				$blocks[$index] = self::rendered_block($html);
				$evaluated_slot = true;
				if (trim($html) === '') {
					continue;
				}
			}

			$leading = $block;
			break;
		}

		$result_content = $evaluated_slot ? wphave_serialize_blocks_canonical($blocks) : $content;
		if (!$leading || !self::leading_hero([$leading])) {
			return ['content' => $result_content, 'header' => $header];
		}

		$tags = new WP_HTML_Tag_Processor($header);
		if (!$tags->next_tag('header') || !$tags->has_class('wp-block-wphave-slot-header')) {
			return ['content' => $result_content, 'header' => $header];
		}

		$tags->add_class('has-hero-overlay');
		return ['content' => $result_content, 'header' => $tags->get_updated_html()];
	}

	private static function rendered_block($html) {
		return [
			'blockName' => null,
			'attrs' => [],
			'innerBlocks' => [],
			'innerHTML' => $html,
			'innerContent' => [$html],
		];
	}
}
