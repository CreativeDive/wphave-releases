<?php

/**
 * Hero-owned composition boundary. Synced references are transparent page roots;
 * real layout blocks are not. Core still renders references and their bindings.
 */

final class WPHAVE_Hero_Composition {
	private const ROOT_MARKER = '__wphave_hero_composition_root';
	private const MAX_COMPOSITION_SOURCE_BYTES = 2 * 1024 * 1024;

	/** Resolve only the leading effective block, with bounded reference traversal. */

	private static function leading_hero($blocks, $seen = []) {
		foreach ($blocks as $block) {
			$name = $block['blockName'] ?? null;

			if (!$name && trim($block['innerHTML'] ?? '') === '') {
				continue;
			}

			if ($name === 'wphave/hero') {
				return !empty($block['attrs']['wphave']['settings']['attachHeader']);
			}

			if ($name !== 'core/block' || count($seen) >= 32) {
				return false;
			}

			$ref = (int) ($block['attrs']['ref'] ?? 0);
			if (!$ref || isset($seen[$ref])) {
				return false;
			}

			$post = get_post($ref);

			if (
				!$post ||
				$post->post_type !== 'wp_block' ||
				$post->post_status !== 'publish' ||
				$post->post_password
			) {
				return false;
			}

			$seen[$ref] = true;
			if (strlen($post->post_content) > self::MAX_COMPOSITION_SOURCE_BYTES) {
				return false;
			}

			return self::leading_hero(parse_blocks($post->post_content), $seen);
		}

		return false;
	}

	/**
	 * Return header/main together so extraction cannot duplicate or lose the Hero.
	 * No database mutation or pattern expansion is persisted. The scoped marker is
	 * parsed-block metadata, never a saved attribute or a binding/context override.
	 */

	public static function compose($content, $header) {
		$unchanged = ['content' => $content, 'header' => $header];
		// COMPOSITION WORK INVARIANT: Optional header attachment may not parse
		// oversized public page content or synchronized references on every hit.
		if (
			!$header ||
			!is_string($content) ||
			strlen($content) > self::MAX_COMPOSITION_SOURCE_BYTES
		) {
			return $unchanged;
		}
		$blocks = parse_blocks($content);

		$index = 0;
		foreach ($blocks as $index => $block) {
			$name = $block['blockName'] ?? null;
			if (!$name && trim($block['innerHTML'] ?? '') === '') {
				continue;
			}

			// Page templates prepend these dynamic slots before post content. A hidden
			// title is not a visible predecessor of the Hero. Ask the real renderer
			// (including filters/visibility rules), rather than duplicating its policy.
			// Only these template slots are transparent; never skip arbitrary content
			// or a real layout parent merely because its current output looks empty.
			if (in_array($name, ['wphave/title', 'wphave/subtitle'], true)) {
				$html = render_block($block);
				// Keep the evaluated result even on fallback: dynamic blocks must not
				// run twice in the same page pass or repeat rendering side effects.
				$blocks[$index] = self::rendered_block($html);
				if (trim($html) === '') {
					continue;
				}
			}

			break;
		}

		if (!isset($blocks[$index]) || !self::leading_hero([$blocks[$index]])) {
			return ['content' => serialize_blocks($blocks), 'header' => $header];
		}

		$root = $blocks[$index];
		$root[self::ROOT_MARKER] = true;
		$captured = null;
		// Core dequeues assets for empty block output (including reference parents).
		// Keep a private non-empty placeholder until the entire root has rendered;
		// only then remove it, since the captured Hero still needs those assets.
		$placeholder = '<!-- ' . wp_unique_id('wphave-composed-hero-') . ' -->';
		$rendered_header = do_blocks($header);

		$mark_root = static function ($parsed, $source, $parent = null) {
			if (
				$parent &&
				$parent->name === 'core/block' &&
				!empty($parent->parsed_block[self::ROOT_MARKER])
			) {
				$parsed[self::ROOT_MARKER] = true;
			}

			return $parsed;
		};

		$capture = static function ($html, $parsed) use (
			&$captured,
			$rendered_header,
			$placeholder,
		) {
			if (
				$captured !== null ||
				empty($parsed[self::ROOT_MARKER]) ||
				empty($parsed['attrs']['wphave']['settings']['attachHeader'])
			) {
				return $html;
			}

			// Fail closed if another renderer replaces the expected root element.
			$tags = new WP_HTML_Tag_Processor($html);
			if (!$tags->next_tag() || !$tags->has_class('wp-block-wphave-hero')) {
				return $html;
			}

			$tags->add_class('has-attached-header');
			$hero = $tags->get_updated_html();

			// Require the Hero opening tag at the start, not a leading comment or text.
			if (!preg_match('/^\s*<[a-z][^>]*>/i', $hero)) {
				return $html;
			}

			$captured = preg_replace_callback(
				'/^(\s*<[a-z][^>]*>)/i',
				static function ($match) use ($rendered_header) {
					return $match[1] . $rendered_header;
				},
				$hero,
				1,
			);

			return $placeholder;
		};

		// Let core/block own override bindings, context, hooks and cycle protection.
		// Only transparent reference parents propagate the eligible-root marker.
		add_filter('render_block_data', $mark_root, PHP_INT_MAX, 3);
		add_filter('render_block_wphave/hero', $capture, PHP_INT_MAX, 2);

		try {
			$remaining = str_replace($placeholder, '', render_block($root));
		} finally {
			remove_filter('render_block_data', $mark_root, PHP_INT_MAX);
			remove_filter('render_block_wphave/hero', $capture, PHP_INT_MAX);
		}

		// The reference has already rendered once. Keep its other roots as HTML,
		// rather than rendering it again and repeating dynamic-block side effects.
		$blocks[$index] = self::rendered_block($remaining);

		return [
			'content' => serialize_blocks($blocks),
			'header' => $captured ?? $header,
		];
	}

	/** Retain output without asking Core to render an already evaluated block again. */
	private static function rendered_block($html) {
		return [
			'blockName' => null,
			'attrs' => [],
			'innerBlocks' => [],
			'innerHTML' => $html,
			'innerContent' => [$html],
		];
	}
}
