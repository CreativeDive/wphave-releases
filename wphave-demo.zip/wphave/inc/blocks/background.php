<?php

/**
 * Render configured background layers and collect their generated styles.
 *
 * Layer order is significant because visual stacking, responsive images, video
 * posters, overlays, and inline styles must remain synchronized.
 *
 * @param array $wphave WPHAVE block settings.
 * @param array $args Block-render arguments.
 * @return void
 */

require_once __DIR__ . '/background-image.php';
require_once __DIR__ . '/background-media-persistence.php';

add_action(
	'block_background',
	function ($wphave, $args = []) {
		$tag = $args['tag'] ?? '';
		$block = $args['block'] ?? '';
		$hold_inline_styles =
			isset($args['holdInlineStyles']) && $args['holdInlineStyles'] ? true : false;

		$bg_layers_value = $wphave['background']['layers'] ?? [];
		$bg_layers = is_array($bg_layers_value) ? array_filter($bg_layers_value, 'is_array') : [];
		$bg_classes = $wphave['classNamesBackground'] ?? [];

		$css = [];
		$tagName = $tag === 'p' ? 'span' : 'div'; // If the block tagName is an inline-element, we should not use a "div-tag" for the background container!

		// Background layers
		$layer_index = 0;
		foreach ($bg_layers as $layer) {
			$is_image = false;
			$bg_image = '';
			$video_type = '';
			$video = '';
			$video_alt = '';
			$video_poster = '';

			// ! Important: Keep the "layerElements" in this order.
			$layerElements = [];

			// Bakground types
			$mask = $layer['mask'] ?? '';
			$text = $layer['text'] ?? '';
			$color = $layer['color'] ?? '';
			$media = $layer['media'] ?? '';
			$shine = $layer['shine'] ?? '';
			$filter = $layer['filter'] ?? '';
			$overlay = $layer['overlay'] ?? '';
			$noise = $layer['noise'] ?? '';
			$gradient = $layer['gradient'] ?? '';
			$gradient_composition = $layer['gradientComposition'] ?? '';
			$halftone = $layer['halftone'] ?? '';
			$duotones = $layer['duotones'] ?? '';
			$decoration = $layer['decoration'] ?? '';
			$cssPattern = $layer['cssPattern'] ?? '';
			$ribbons =
				wphave_release_feature_ready('ribbonBackground') && !empty($layer['ribbons']);
			$svgPattern = $layer['svgPattern'] ?? '';
			$photo_filter = $layer['photoFilter'] ?? '';
			$gradient_border = $layer['gradientBorder'] ?? '';
			$canvas_animation = $layer['canvasAnimation'] ?? '';

			$has_bg =
				(wphave_release_feature_ready('canvasAnimationBackground') && $canvas_animation) ||
				$text ||
				$mask ||
				$media ||
				$color ||
				$shine ||
				$filter ||
				$overlay ||
				$noise ||
				$gradient ||
				$gradient_composition ||
				$halftone ||
				$duotones ||
				$decoration ||
				$svgPattern ||
				$cssPattern ||
				$ribbons ||
				$photo_filter ||
				$gradient_border;

			if (!$has_bg) {
				$layer_index++;
				continue;
			}

			if ($media) {
				if (is_array($media['video'] ?? null)) {
					$media['video'] = WPHAVE_Background_Media_Persistence::video($media['video']);
				}
				$video_type = $media['video']['type'] ?? '';
				$image_type = $media['image']['type'] ?? '';
				$is_image = in_array($image_type, ['custom', 'featured', 'url'], true);

				// IMAGE
				if ($is_image) {
					$source = wphave_resolve_background_image(
						$media['image'],
						$wphave,
						$args['postId'] ?? null,
					);
					$bg_image = wphave_render_background_image($source, $media['image']);
					// VIDEO
				} elseif ($video_type) {
					$video_id = $media['video']['file'] ?? '';
					$video_alt_id = $media['video']['fileAlternate'] ?? '';
					$video_poster_id = $media['video']['poster'] ?? '';

					$video_extern = $media['video']['url'] ?? '';
					$video_extern_alt = $media['video']['urlAlternate'] ?? '';

					$poster_resolution = WPHAVE_Block_Image_Size::resolve($wphave, [
						'image' => $video_poster_id,
						'size' => 'auto',
					]);
					$video_poster = $video_poster_id
						? wphave_image_src($video_poster_id, $poster_resolution['size'])
						: '';
					$video_file = $video_id ? wp_get_attachment_url($video_id) : '';
					$video_file_alt = $video_alt_id ? wp_get_attachment_url($video_alt_id) : '';

					$video = $video_type === 'extern' ? $video_extern : $video_file;
					$video_alt = $video_type === 'extern' ? $video_extern_alt : $video_file_alt;
				}
			}

			if (
				wphave_release_feature_ready('canvasAnimationBackground') &&
				is_array($canvas_animation)
			) {
				// The runtime is registered globally but loaded only when a rendered layer needs it.
				if (!is_admin()) {
					wp_enqueue_script('wphave-canvas-animation');
				}

				$canvas_animation_json = wp_json_encode(
					$canvas_animation,
					JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT,
				);

				$fallback_color =
					sanitize_hex_color($canvas_animation['settings']['background'] ?? '#07132d') ?:
					'#07132d';

				$layerElements[] = sprintf(
					'<canvas class="wphave-canvas-animation" aria-hidden="true" data-wphave-canvas-animation="%s" style="--wphave-canvas-animation-fallback:%s"></canvas>',
					esc_attr($canvas_animation_json ?: '{}'),
					esc_attr($fallback_color),
				);
			}

			$text_label = $text['label'] ?? '';

			$deco_items = is_array($decoration) ? array_filter($decoration, 'is_array') : [];

			$i = 0;
			$decos = '';
			foreach ($deco_items as $item => $value) {
				$deco = $value['deco'] ?? null;
				if (!is_array($deco)) {
					continue;
				}
				$raw_type = $deco['type'] ?? null;
				$type = is_string($raw_type) || is_int($raw_type) ? (string) $raw_type : '0';
				$backgroundDecorationSVGOutput = wphave_svg_decoratives(['style' => $type]) ?? '';
				if (!$backgroundDecorationSVGOutput) {
					continue;
				}
				$decoStyles = wphave_decoration_styles($deco);

				$decoStyle = safecss_filter_attr(
					implode(
						'; ',
						array_map(
							function ($key, $value) {
								return $key . ': ' . $value;
							},
							array_keys($decoStyles),
							$decoStyles,
						),
					),
				);
				$decos .=
					'<div' .
					($decoStyle ? ' style="' . esc_attr($decoStyle) . '"' : '') .
					' class="deco-bg-item">' .
					$backgroundDecorationSVGOutput .
					'</div>';

				$i++;
			}

			if ($media) {
				ob_start(); ?>
            <div class="mda">
                <?php if ($is_image && $bg_image) {
					echo $bg_image;
                } elseif ($video_type) { ?>
                    <video autoplay loop playsinline muted aria-hidden="true" data-wphave-decorative-autoplay<?php if (
						$video_poster
                    ) { ?> poster="<?php echo esc_attr($video_poster); ?>"<?php } ?>>
                        <?php
                        if ($video) { ?>
                            <source src="<?php echo esc_url($video); ?>" type="video/mp4" />
                        <?php }
                        if ($video_alt) { ?>
                            <source src="<?php echo esc_url($video_alt); ?>" type="video/webm" />
                        <?php }
                        ?>
                    </video>
                <?php } ?>
            </div>

            <?php
            $output = ob_get_contents();
            ob_end_clean();

            $layerElements[] = $output;

			}

			if ($gradient) {
				$layerElements[] = '<div class="grd"></div>';
			} // Gradient
			if ($gradient_composition) {
				$gradient_composition_markup = wphave_render_gradient_composition(
					$gradient_composition,
				);
				if ($gradient_composition_markup) {
					$layerElements[] = $gradient_composition_markup;
				}
			}
			if ($halftone) {
				$halftone_markup = wphave_render_halftone($halftone, 'halftone-' . $layer_index);
				if ($halftone_markup) {
					$layerElements[] =
						'<div class="halftone" aria-hidden="true">' . $halftone_markup . '</div>';
				}
			}
			if ($ribbons) {
				$layerElements[] = '<div class="wph-ribbon-artwork" aria-hidden="true"></div>';
			}
			if ($cssPattern) {
				$layerElements[] = '<div class="cssp"></div>';
			} // CSS pattern
			if ($svgPattern) {
				$layerElements[] = '<div class="svgp"></div>';
			} // SVG pattern
			if ($text) {
				$layerElements[] =
					'<div class="txtbg"><span>' . esc_html($text_label) . '</span></div>';
			} // Text
			if ($decoration) {
				$layerElements[] =
					'<div class="deco" aria-hidden="true">' . wp_kses_post($decos) . '</div>';
			} // Decoration
			if ($photo_filter) {
				$layerElements[] = '<div class="phfi"></div>';
			} // Photo filter
			if ($shine) {
				$layerElements[] = '<div class="shi"></div>';
			} // Shine
			if ($overlay) {
				$layerElements[] = '<div class="ov"></div>';
			} // Overlay
			if ($noise) {
				$layerElements[] = '<div class="noi"></div>';
			} // Noise
			if ($filter) {
				$layerElements[] = '<div class="fil"></div>';
			} // Filter
			if ($duotones) {
				$duotone_filter = wphave_svg_duotone_filter_for_value($duotones);
				if ($duotone_filter) {
					$layerElements[] = $duotone_filter;
				}
			}
			if ($gradient_border) {
				$layerElements[] = '<div class="grd-bo"></div>';
			} // Gradient border

			// Background layer classes
			$classes = [];
			$classes[] = 'bbg';
			$classes[] = 'bgly-' . $layer_index;
			$classes[] = $bg_classes[$layer_index] ?? '';

			// Output
			if ($has_bg) { ?>
            <<?php echo esc_html($tagName); ?> class="<?php echo esc_attr(
	 implode(' ', $classes),
 ); ?>">
        <?php }
			if ($layerElements) {
				echo implode('', $layerElements); // All parts are already escaped above !
			}
			if ($has_bg) { ?>
            </<?php echo esc_html($tagName); ?>>
        <?php }

			$layer_index++;
		}

		// Print inline styles
		if ($css) {
			if ($hold_inline_styles) {
				WPHAVE_Style_Engine::instance()->print_inline_styles($css, [
					'stay_here' => true, // <-- We have to print the inline style here without using the filter, otherwise the style will lose the "id" assignment, if the parent block is cached
				]);
			} else {
				WPHAVE_Style_Engine::instance()->print_inline_styles($css);
			}
		}
	},
	10,
	2,
);
