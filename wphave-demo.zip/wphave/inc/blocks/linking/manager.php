<?php

if (!defined('ABSPATH')) {
	exit();
}

/**
 * Central block-link resolver and compatibility facade.
 */

class WPHAVE_Block_Linking {
	private static ?self $instance = null;
	private array $cache = [];
	private WPHAVE_Block_Link_Layers $layers;
	private WPHAVE_Block_Dynamic_Links $dynamic_links;

	/**
	 * Return the request-scoped block-linking instance.
	 *
	 * @return self
	 */

	public static function instance(): self {
		return self::$instance ??= new self();
	}

	/**
	 * Initialize the layer renderer and dynamic-link converter.
	 */

	private function __construct() {
		$this->layers = new WPHAVE_Block_Link_Layers();
		$this->dynamic_links = new WPHAVE_Block_Dynamic_Links();
	}

	/**
	 * Register the WordPress integration points.
	 *
	 * The class-owned callbacks share the same implementations as direct calls.
	 * This method must only be called once during bootstrap.
	 *
	 * @return void
	 */

	public function boot() {
		add_action('wp_footer', [$this->layers, 'output'], 9999);
		add_filter('render_block', [$this->dynamic_links, 'filter_block'], 10, 2);
	}

	/**
	 * Return the request-scoped layer renderer and collector.
	 *
	 * @return WPHAVE_Block_Link_Layers
	 */

	public function layers(): WPHAVE_Block_Link_Layers {
		return $this->layers;
	}

	/**
	 * Return the dynamic rich-text link converter.
	 *
	 * @return WPHAVE_Block_Dynamic_Links
	 */

	public function dynamic_links(): WPHAVE_Block_Dynamic_Links {
		return $this->dynamic_links;
	}

	/**
	 * Build an anchor opening tag from the established WPHAVE link arguments.
	 *
	 * @param array $args Link resolver arguments. An explicit href may override
	 *                    the URL returned by the resolver. An explicit anchor_id controls
	 *                    only the anchor DOM ID; id still identifies layer targets.
	 * @return string|null Anchor opening tag, or null when no link is resolved.
	 */

	public function open_link($args = []) {
		$data = $this->get_link($args);
		if (!$data) {
			return null;
		}

		// Add the standard anchor attributes in a predictable order.
		$href = $args['href'] ?? '';
		$attrs = [];
		$values = [
			// The resolver ID owns layer targets; a nested anchor can omit its DOM ID.
			'id' => $args['anchor_id'] ?? ($data['id'] ?? ''),
			'class' => $data['class'] ?? '',
			'title' => $data['title'] ?? '',
			'target' => $data['target'] ?? '',
		];

		foreach ($values as $name => $value) {
			if ($value) {
				$attrs[] = $name . '="' . esc_attr($value) . '"';
			}
		}

		// An explicit href supplied by the caller takes precedence.
		$url = $href ?: $data['url'] ?? '';
		if ($url) {
			$attrs[] = 'href="' . esc_url($url) . '"';
		}

		$rel = $data['rel'] ?? [];
		if ($rel) {
			$attrs[] = 'rel="' . esc_attr(implode(' ', $rel)) . '"';
		}

		// Append resolver-specific attributes such as layer and tracking data.
		$attributes = $data['attribute'] ?? [];
		foreach (is_array($attributes) ? $attributes : [$attributes] as $attribute) {
			$attrs[] = $attribute;
		}

		return '<a ' . implode(' ', $attrs) . '>';
	}

	/**
	 * Return a closing tag only when the arguments resolve to a link.
	 *
	 * @param array $args Link resolver arguments.
	 * @return string|null Anchor closing tag, or null when no link is resolved.
	 */

	public function close_link($args = []) {
		return $this->get_link($args) ? '</a>' : null;
	}

	/**
	 * Resolve normalized link data for every supported WPHAVE link type.
	 *
	 * The returned array shape is consumed by legacy helpers and block rendering.
	 * Layer links additionally register their rendered panel with the collector.
	 *
	 * @param array $args Link, element, content and placeholder arguments.
	 * @return array|null Normalized link data, or null for non-renderable links.
	 */

	public function get_link($args = []) {
		// Validate the requested link type before doing any additional work.
		$link = isset($args['link']) && is_array($args['link']) ? $args['link'] : [];
		$link_type = $link['type'] ?? 'none';
		$placeholder = $args['placeholder'] ?? '';

		if (($link_type === 'none' && !$placeholder) || $link_type === 'lightbox') {
			return null;
		}

		// Keep json_encode() here because its exact byte output is part of the
		// established fallback layer ID and therefore externally observable.
		$cache_key = md5(json_encode($args));
		$memoized_value = wphave_request_memoization_read($this->cache, $cache_key);
		if ($memoized_value) {
			return $memoized_value;
		}

		// Collect the shared values used by every type-specific resolver.
		$id = $args['id'] ?? '';
		$class = $args['class'] ?? '';
		$content = $args['content'] ?? '';
		$attributes = $args['attributes'] ?? [];
		$title = sanitize_text_field($link['title'] ?? '');
		$rel = $link['rel'] ?? [];
		$rel = is_array($rel) ? $rel : explode(',', $rel);
		$rel = array_values(array_filter(array_map('sanitize_html_class', $rel)));
		$target = ($link['open'] ?? '') === 'new' ? '_blank' : '_self';
		$base = [
			'title' => $title,
			'id' => $id,
			'class' => $class,
			'attribute' => $attributes,
		];

		// Delegate complex link types and resolve the simple types inline.
		if (in_array($link_type, ['internal', 'external', 'file'], true)) {
			$data = $this->resolve_url_link($link_type, $link, $base, $target);
		} elseif ($link_type === 'mail') {
			$data = $this->resolve_mail_link($link, $base);
		} elseif ($link_type === 'taxonomy') {
			$data = $this->resolve_taxonomy_link($link, $base, $target);
		} elseif (in_array($link_type, ['modal', 'side-panel', 'popover'], true)) {
			$data = $this->resolve_layer_link($link_type, $base, $content, $cache_key);
		} elseif ($link_type === 'popup') {
			$data = $this->resolve_popup_link($link, $base);
		} elseif ($link_type === 'consent-preferences') {
			$data = $this->resolve_consent_preferences_link($base);
		} elseif ($link_type === 'privacy-policy') {
			$data = $this->resolve_privacy_policy_link($base, $target);
		} elseif ($link_type === 'dynamic-content') {
			$data = $this->resolve_dynamic_content_link($link, $base, $target);
		} elseif ($link_type === 'site-destination') {
			$data = $this->resolve_site_destination_link($link, $base, $target);
		} elseif ($link_type === 'woocommerce') {
			$data = $this->resolve_woocommerce_link($link, $base, $target);
		} elseif ($link_type === 'phone') {
			$phone_number = $this->sanitize_phone_number($link['phone']['number'] ?? '');
			$data = array_merge($base, [
				'url' => $phone_number ? 'tel:' . $phone_number : '',
				'target' => $target,
			]);
		} elseif ($link_type === 'anchor') {
			$anchor = sanitize_title($link['anchor'] ?? '');
			$data = array_merge($base, [
				'url' => $anchor ? '#' . $anchor : '',
				'target' => $target,
				'class' => $class ? $class . ' section-scroll' : 'section-scroll',
			]);
		} elseif ($link_type === 'string') {
			$data = array_merge($base, ['url' => $link['string'] ?? '{###}', 'target' => $target]);
		} elseif ($link_type === 'none') {
			$data = array_merge($base, ['url' => '#', 'target' => '', 'title' => '']);
		} else {
			$data = [];
		}

		// Normalize the shared result shape and append tracking attributes.
		$data['url'] = $data['url'] ?? '#';
		$data['rel'] = $this->format_rel($data['url'], $target, $rel);

		$link_attributes = $data['attribute'] ?? [];
		$link_attributes = is_array($link_attributes) ? $link_attributes : [$link_attributes];
		$data['attribute'] = array_merge(
			$link_attributes,
			$this->get_tracking_attributes($link, $data),
		);

		// Cache the complete normalized result for repeated calls in this request.
		$this->cache[$cache_key] = $data;

		return $data;
	}

	/**
	 * Resolve internal, external and attachment link data.
	 *
	 * @param string $type Link type.
	 * @param array $link WPHAVE link attributes.
	 * @param array $base Shared normalized link data.
	 * @param string $target Browser target value.
	 * @return array Resolved link data.
	 */

	private function resolve_url_link($type, $link, $base, $target) {
		// Select the URL source defined by the requested link type.
		$url = $link['internal']['url'] ?? '';
		if ($type === 'external') {
			$url = $link['external']['url'] ?? '';
		} elseif ($type === 'file') {
			$url = wp_get_attachment_url($link['file']['id'] ?? '');
		}

		// Merge optional query parameters with the resolved URL.
		$parameter = $link['parameter'] ?? '';
		if ($parameter) {
			$parameter_array = [];
			parse_str(
				str_replace('?', '', str_replace(' ', '%20', htmlspecialchars_decode($parameter))),
				$parameter_array,
			);
			$url = add_query_arg($parameter_array, $url);
		}

		return array_merge($base, ['url' => esc_url($url), 'target' => $target]);
	}

	/**
	 * Resolve an email link including its optional subject and body query.
	 *
	 * @param array $link WPHAVE link attributes.
	 * @param array $base Shared normalized link data.
	 * @return array Resolved email link data.
	 */

	private function resolve_mail_link($link, $base) {
		$mail = isset($link['mail']) && is_array($link['mail']) ? $link['mail'] : [];
		$raw_address = trim((string) ($mail['address'] ?? ''));
		$address = sanitize_email($raw_address);

		// Reject malformed input instead of silently turning it into a different address.
		if (!$address || $address !== $raw_address || !is_email($address)) {
			return array_merge($base, ['url' => '', 'target' => '']);
		}

		$query = array_filter(
			[
				'body' => sanitize_textarea_field($mail['body'] ?? ''),
				'subject' => sanitize_text_field($mail['subject'] ?? ''),
			],
			static fn($value) => $value !== '',
		);
		$url = 'mailto:' . $address;
		if ($query) {
			$url = add_query_arg($query, $url);
		}

		return array_merge($base, ['url' => $url, 'target' => '']);
	}

	/**
	 * Normalize a telephone destination without allowing it to terminate the
	 * generated href attribute.
	 *
	 * @param string $number User-supplied telephone number.
	 * @return string Safe telephone destination.
	 */

	private function sanitize_phone_number($number) {
		return trim(preg_replace('/[^0-9+().\\-\\s]/', '', sanitize_text_field($number)));
	}

	/**
	 * Sanitize one or more whitespace-separated class name groups.
	 *
	 * @param array|string $classes Class names or class name groups.
	 * @return string Safe whitespace-separated class names.
	 */

	private function sanitize_classes($classes) {
		$groups = is_array($classes) ? $classes : [$classes];
		$tokens = [];
		foreach ($groups as $group) {
			$tokens = array_merge($tokens, preg_split('/\\s+/', (string) $group));
		}

		return implode(' ', array_filter(array_map('sanitize_html_class', $tokens)));
	}

	/**
	 * Resolve a taxonomy term link without exposing WordPress error objects.
	 *
	 * @param array $link WPHAVE link attributes.
	 * @param array $base Shared normalized link data.
	 * @param string $target Browser target value.
	 * @return array Resolved taxonomy link data.
	 */

	private function resolve_taxonomy_link($link, $base, $target) {
		// Only resolve the term when the stored value has the expected object shape.
		$taxonomy = $link['taxonomy']['url'] ?? null;
		$term =
			is_object($taxonomy) && isset($taxonomy->term_id, $taxonomy->taxonomy)
				? get_term($taxonomy->term_id, $taxonomy->taxonomy)
				: null;
		$link_url = $term && !is_wp_error($term) ? get_term_link($term) : '';

		return array_merge($base, [
			'url' => !is_wp_error($link_url) && $link_url ? esc_url($link_url) : '#',
			'target' => $target,
			'title' => $term && !is_wp_error($term) ? $term->name ?? '' : '',
		]);
	}

	/**
	 * Resolve and register a modal, side-panel or popover link.
	 *
	 * The cache key is also the source of the stable fallback layer ID. Its
	 * derivation in get_link() is therefore compatibility-sensitive.
	 *
	 * @param string $type Layer link type.
	 * @param array $base Shared normalized link data.
	 * @param string $content Rendered layer content.
	 * @param string $cache_key Request cache key for the complete link arguments.
	 * @return array Resolved layer trigger data including the collected HTML.
	 */

	private function resolve_layer_link($type, $base, $content, $cache_key) {
		// Prefer the block ID and fall back to a stable ID derived from link data.
		$layer_id = sanitize_html_class($base['id']);
		if (!$layer_id) {
			$layer_id = 'wphave-layer-' . substr($cache_key, 0, 12);
		}

		// Keep trigger attributes and target suffixes aligned for every layer type.
		$config = [
			'modal' => ['suffix' => '-modal', 'attribute' => 'data-modal'],
			'side-panel' => ['suffix' => '-side-panel', 'attribute' => 'data-panel'],
			'popover' => ['suffix' => '-popover', 'attribute' => 'data-popover'],
		];
		$target_id = $layer_id . $config[$type]['suffix'];

		// Build the accessible trigger contract consumed by the frontend scripts.
		$data = array_merge($base, [
			'url' => '#',
			'attribute' => [
				$config[$type]['attribute'] .
				'="#' .
				$target_id .
				'" aria-haspopup="dialog" aria-controls="' .
				$target_id .
				'" aria-expanded="false"',
			],
		]);

		// Register the matching layer output with the request-scoped collector.
		$data['html'] = $this->layers->render([
			'id' => $layer_id,
			'type' => $type,
			'label' => $base['title'],
			'content' => $content,
		]);

		return $data;
	}

	/**
	 * Resolve a trigger for an independently managed popup block.
	 *
	 * Unlike an inline modal link, this resolver does not collect or duplicate
	 * content. It targets the stable ID persisted by the popup definition.
	 *
	 * @param array $link Link configuration.
	 * @param array $base Shared normalized link data.
	 * @return array Resolved popup trigger data.
	 */

	private function resolve_popup_link($link, $base) {
		$popup_id = sanitize_html_class($link['popup']['id'] ?? '');

		if (!$popup_id) {
			return array_merge($base, [
				'url' => '#',
				'target' => '',
				'attribute' => ['aria-disabled="true"'],
			]);
		}

		return array_merge($base, [
			'url' => '#',
			'target' => '',
			'attribute' => [
				'data-modal="#' .
				esc_attr($popup_id) .
				'" aria-haspopup="dialog" aria-controls="' .
				esc_attr($popup_id) .
				'" aria-expanded="false"',
			],
		]);
	}

	/**
	 * Resolve the stable trigger for the centrally rendered consent dialog.
	 *
	 * The semantic link type keeps privacy-policy links independent from the
	 * consent implementation's markup while sharing the standard modal runtime.
	 *
	 * @param array $base Shared normalized link data.
	 * @return array Resolved consent-preferences trigger data.
	 */

	private function resolve_consent_preferences_link($base) {
		$target_id = 'wphave-consent-preferences';

		return array_merge($base, [
			'url' => '#' . $target_id,
			'target' => '',
			'attribute' => [
				'data-modal="#' .
				$target_id .
				'" aria-haspopup="dialog" aria-controls="' .
				$target_id .
				'" aria-expanded="false"',
			],
		]);
	}

	/**
	 * Resolve the privacy-policy page configured in WordPress.
	 *
	 * @param array $base Shared normalized link data.
	 * @param string $target Browser target value.
	 * @return array Resolved privacy-policy link data.
	 */

	private function resolve_privacy_policy_link($base, $target) {
		$url = function_exists('get_privacy_policy_url') ? get_privacy_policy_url() : '';

		return array_merge($base, ['url' => $url ?: '#', 'target' => $target]);
	}

	/**
	 * Resolve a destination from the current WordPress content context.
	 *
	 * @param array $link Link configuration.
	 * @param array $base Shared normalized link data.
	 * @param string $target Browser target value.
	 * @return array Resolved dynamic-content link data.
	 */

	private function resolve_dynamic_content_link($link, $base, $target) {
		$destination = sanitize_key($link['dynamic']['destination'] ?? 'current');
		$post_id = get_the_ID();
		$url = '';

		if ($destination === 'current') {
			$url = $post_id ? get_permalink($post_id) : '';
		} elseif ($destination === 'author') {
			$author_id = $post_id ? (int) get_post_field('post_author', $post_id) : 0;
			$url = $author_id ? get_author_posts_url($author_id) : '';
		} elseif ($destination === 'archive') {
			$post_type = $post_id ? get_post_type($post_id) : get_post_type();
			$url = $post_type ? get_post_type_archive_link($post_type) : '';
		} elseif ($destination === 'term') {
			$url = $this->resolve_current_term_url($post_id);
		} elseif ($destination === 'previous') {
			$previous_post = get_previous_post();
			$url = $previous_post ? get_permalink($previous_post) : '';
		} elseif ($destination === 'next') {
			$next_post = get_next_post();
			$url = $next_post ? get_permalink($next_post) : '';
		}

		return array_merge($base, ['url' => $url ?: '#', 'target' => $target]);
	}

	/**
	 * Resolve the first public taxonomy term assigned to the current content.
	 *
	 * @param int $post_id Current post ID.
	 * @return string Resolved term URL, or an empty string.
	 */

	private function resolve_current_term_url($post_id) {
		if (!$post_id) {
			return '';
		}

		$taxonomies = get_object_taxonomies(get_post_type($post_id), 'objects');
		foreach ($taxonomies as $taxonomy) {
			if (!$taxonomy->public) {
				continue;
			}

			$terms = get_the_terms($post_id, $taxonomy->name);
			if (!$terms || is_wp_error($terms)) {
				continue;
			}

			$url = get_term_link(reset($terms));
			return is_wp_error($url) ? '' : $url;
		}

		return '';
	}

	/**
	 * Resolve stable site-level destinations managed by WordPress.
	 *
	 * @param array $link Link configuration.
	 * @param array $base Shared normalized link data.
	 * @param string $target Browser target value.
	 * @return array Resolved site destination link data.
	 */

	private function resolve_site_destination_link($link, $base, $target) {
		$destination = sanitize_key($link['site']['destination'] ?? 'home');
		$url = home_url('/');

		if ($destination === 'posts') {
			$posts_page_id = (int) get_option('page_for_posts');
			$url = $posts_page_id ? get_permalink($posts_page_id) : '';
		}

		return array_merge($base, ['url' => $url ?: '#', 'target' => $target]);
	}

	/**
	 * Resolve WooCommerce system pages without persisting their page IDs.
	 *
	 * @param array $link Link configuration.
	 * @param array $base Shared normalized link data.
	 * @param string $target Browser target value.
	 * @return array Resolved WooCommerce link data.
	 */

	private function resolve_woocommerce_link($link, $base, $target) {
		$allowed = ['shop', 'cart', 'checkout', 'myaccount'];
		$destination = sanitize_key($link['woocommerce']['destination'] ?? '');
		$candidates = in_array($destination, $allowed, true)
			? array_merge([$destination], $allowed)
			: $allowed;
		$url = '';

		if (function_exists('wc_get_page_id') && function_exists('wc_get_page_permalink')) {
			foreach (array_unique($candidates) as $candidate) {
				$page_id = wc_get_page_id($candidate);
				if ($page_id > 0 && get_post_status($page_id) === 'publish') {
					$url = wc_get_page_permalink($candidate);
					break;
				}
			}
		}

		return array_merge($base, ['url' => $url ?: '#', 'target' => $target]);
	}

	/**
	 * Create standardized Analytics and Audience data attributes.
	 *
	 * @param array $link Link attributes containing the tracking configuration.
	 * @param array $data Resolved link data used for URL and label fallbacks.
	 * @return array Escaped HTML attribute strings.
	 */

	public function get_tracking_attributes($link = [], $data = []) {
		// Stop early when tracking is explicitly disabled or not configured.
		$tracking =
			isset($link['tracking']) && is_array($link['tracking']) ? $link['tracking'] : [];
		$mode = sanitize_key($tracking['mode'] ?? 'none');
		$enabled = isset($tracking['enabled']) ? (bool) $tracking['enabled'] : $mode !== 'none';
		if (!$enabled || !$mode || $mode === 'none') {
			return [];
		}

		// Normalize all values before they are converted to HTML attributes.
		$link_type = sanitize_key($link['type'] ?? 'none');
		$url = esc_url_raw($data['url'] ?? '');
		$label = sanitize_text_field($tracking['label'] ?? ($data['title'] ?? ''));
		$goal_id = sanitize_key($tracking['goalId'] ?? '');
		$goal_type = sanitize_key($tracking['goalType'] ?? '');
		$value = isset($tracking['value']) ? max(0, (float) $tracking['value']) : 0;

		if ($mode === 'goal' && !$goal_id) {
			return [];
		}
		if (!$label) {
			$label = $goal_id ?: $link_type;
		}

		// Resolve automatic tracking and reject unsupported modes.
		if ($mode === 'auto') {
			$mode =
				$link_type === 'file'
					? 'download'
					: ($link_type === 'external'
						? 'outbound'
						: 'click');
		}
		if (!in_array($mode, ['click', 'download', 'outbound', 'goal'], true)) {
			return [];
		}

		// A goal may override the event type while retaining goal metadata.
		$event_type =
			$mode === 'goal' && in_array($goal_type, ['click', 'download', 'outbound'], true)
				? $goal_type
				: ($mode === 'goal'
					? 'click'
					: $mode);

		// Empty optional attributes are removed from the final output.
		return array_filter([
			'data-wphave-track="1"',
			$mode === 'goal' ? 'data-wphave-track-mode="goal"' : '',
			'data-wphave-track-type="' . esc_attr($event_type) . '"',
			'data-wphave-track-label="' . esc_attr($label) . '"',
			$goal_id ? 'data-wphave-goal-id="' . esc_attr($goal_id) . '"' : '',
			$goal_type ? 'data-wphave-goal-type="' . esc_attr($goal_type) . '"' : '',
			$value ? 'data-wphave-value="' . esc_attr($value) . '"' : '',
			$url ? 'data-wphave-track-url="' . esc_url($url) . '"' : '',
			!empty($tracking['audience']) ? 'data-wphave-audience="1"' : '',
		]);
	}

	/**
	 * Add the established external, noopener and author relationship values.
	 *
	 * @param string|false $url Resolved link URL.
	 * @param string $target Browser target value.
	 * @param array|string $rel Existing relationship values.
	 * @return array Unique relationship values.
	 */

	public function format_rel($url, $target, $rel = []) {
		if (is_string($rel)) {
			$rel = explode(',', $rel);
		}

		// External blank-target links always receive the security relationship.
		$is_fragment = is_string($url) && strpos($url, '#') === 0;
		if (!$is_fragment && !wphave_str_contains($url, home_url()) && $url !== false) {
			$rel[] = 'external';
			if ($target === '_blank') {
				$rel[] = 'noopener';
			}
		}

		// WordPress author archive links expose their semantic relationship.
		if (wphave_str_contains($url, '/author/')) {
			$rel[] = 'author';
		}

		return array_unique($rel);
	}

	/**
	 * Build block-wrapper link settings in their established compatibility shape.
	 *
	 * The returned keys are consumed directly by block wrapper rendering. Layer
	 * content must remain in the template while its trigger attributes stay on
	 * the wrapper or overlay selected by the caller.
	 *
	 * @param array $args Block ID, link, content, classes and wrapper arguments.
	 * @return array Link label and normalized block wrapper arguments.
	 */

	public function get_block_link_data($args = []) {
		// Read caller options and preserve all established defaults.
		$id = $args['id'] ?? '';
		$link = $args['link'] ?? [];
		$type = $link['type'] ?? 'none';
		$label = $args['label'] ?? '';
		$output = $args['output'] ?? 'default';
		$classes = $args['classes'] ?? [];
		$content = $args['content'] ?? [];
		$block_args = $args['block_args'] ?? [];
		$default_tag = $args['defaultTag'] ?? 'button';
		$none_tag = $args['noneTag'] ?? $default_tag;
		$invalid_tag = $args['invalidTag'] ?? 'span';
		$data_attributes = $args['dataAttributes'] ?? [];

		// Resolve the link once and unpack its normalized wrapper values.
		$link_data = $this->get_link(['id' => $id, 'link' => $link, 'content' => $content]);
		$url = $link_data['url'] ?? '#';
		$title = $link_data['title'] ?? '';
		$target = $link_data['target'] ?? '_self';
		$class = $link_data['class'] ?? '';
		$rel = $link_data['rel'] ?? [];
		$attribute = $link_data['attribute'] ?? '';

		// Extend phone labels with the visible destination when available.
		$phone_number = $this->sanitize_phone_number($link['phone']['number'] ?? '');
		if ($type === 'phone' && $phone_number) {
			$label = $label ? $label . ': ' . $phone_number : $phone_number;
		}

		// Select the wrapper mode and decide where content must be rendered.
		$is_panel_content = in_array($type, ['modal', 'side-panel', 'popover'], true);
		$is_dialog_trigger = $is_panel_content || $type === 'popup';
		$attributes_string = is_array($attribute) ? implode(' ', $attribute) : $attribute;
		$has_interaction_attribute =
			wphave_str_contains($attributes_string, 'data-modal=') ||
			wphave_str_contains($attributes_string, 'data-panel=') ||
			wphave_str_contains($attributes_string, 'data-popover=');
		$is_invalid_destination =
			$type !== 'none' && (!$url || $url === '#') && !$has_interaction_attribute;
		if ($output !== 'overlay') {
			$block_args['tag'] = $is_invalid_destination
				? $invalid_tag
				: ($type === 'none'
					? $none_tag
					: ($is_dialog_trigger
						? $default_tag
						: 'a'));
		}
		if ($output === 'overlay' && $type !== 'none') {
			$block_args['linkOverlay'] = true;
		}
		if ($is_panel_content || (!$is_panel_content && $content)) {
			$block_args['renderContentInTemplate'] = true;
		}

		// A linked block rendered as a button is always a UI trigger, never a
		// form submission control. Defining the type prevents accidental submits
		// when a block is placed inside third-party form markup.
		if (($block_args['tag'] ?? '') === 'button') {
			$block_args['linkAttributes'][] = 'type="button"';
		}

		// Assemble wrapper attributes without changing their string-based shape.
		if ($title) {
			$block_args['linkAttributes'][] = 'title="' . esc_attr($title) . '"';
		}
		if ($data_attributes) {
			$block_args['linkAttributes'][] = implode(' ', $data_attributes);
		}
		if ($url && $url !== '#') {
			$block_args['linkAttributes'][] = 'href="' . esc_url($url) . '"';
			$block_args['linkAttributes'][] = 'target="' . esc_attr($target) . '"';
			if ($rel && in_array($type, ['internal', 'external', 'file'], true)) {
				$block_args['linkAttributes'][] = 'rel="' . esc_attr(implode(' ', $rel)) . '"';
			}
		}

		$block_args['linkAttributes'][] = $attributes_string;

		// Append resolver and caller classes after all link attributes.
		if ($class) {
			$block_args['class'][] = $this->sanitize_classes($class);
		}
		if ($classes) {
			$block_args['class'][] = $this->sanitize_classes($classes);
		}

		return ['label' => $label, 'block_args' => $block_args];
	}
}
