<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Collects and outputs request-scoped layers created by block links.
 */

class WPHAVE_Block_Link_Layers {

	private array $layers = array();

	/**
	 * Create and collect one layer while preserving the established type/id key.
	 *
	 * @param array $args Layer configuration.
	 * @return string|null
	 */

	public function render( $args = array() ) {
		$id = $args['id'] ?? '';
		$type = $args['type'] ?? '';
		$label = ! empty( $args['label'] ) ? $args['label'] : __( 'Dialog', 'wphave' );
		$content = wp_kses_post( $args['content'] ?? '' );
		$output = '';

		if( $type === 'modal' ) {
			$output = wphave_render_modal( array(
				'id' => $id . '-modal',
				'label' => $label,
				'variant' => 'panel',
			), $content );
		} elseif( $type === 'side-panel' ) {
			$output = wphave_render_side_panel( array(
				'id' => $id . '-side-panel',
				'label' => $label,
				'class' => 'with-panel-block',
			), $content );
		} elseif( $type === 'popover' ) {
			$output = wphave_render_popover( array(
				'id' => $id . '-popover',
				'label' => $label,
				'class' => 'with-panel-block',
			), $content );
		}

		if( ! $output ) {
			return null;
		}

		$this->layers[$type . ':' . $id] = $output;

		return $output;
	}

	/**
	 * Return the collected layers for diagnostics and integration tests.
	 *
	 * @return array
	 */

	public function all() {
		return $this->layers;
	}

	/**
	 * Print collected layers in insertion order.
	 *
	 * @return void
	 */

	public function output() {
		if( ! empty( $this->layers ) ) {
			echo implode( '', $this->layers );
		}
	}

}
