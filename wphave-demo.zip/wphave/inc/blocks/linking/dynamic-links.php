<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Converts numeric rich-text links into current WordPress permalinks.
 */

class WPHAVE_Block_Dynamic_Links {

	private const SUPPORTED_BLOCKS = array(
		'wphave/paragraph',
		'wphave/heading',
		'wphave/list-item',
	);

	/**
	 * Convert numeric href values while retaining the existing attribute output.
	 *
	 * @param string $content Rendered block content.
	 * @return string
	 */

	public function convert( $content ) {
		$processor = new WP_HTML_Tag_Processor( $content );
		while( $processor->next_tag( 'A' ) ) {
			$href = (string) $processor->get_attribute( 'href' );
			if( ! ctype_digit( $href ) ) {
				continue;
			}

			$permalink = get_permalink( (int) $href );
			if( ! $permalink ) {
				continue;
			}

			$params = (string) $processor->get_attribute( 'params' );
			if( $params !== '' ) {
				$query = array();
				parse_str( ltrim( html_entity_decode( $params ), '?' ), $query );
				$permalink = add_query_arg( $query, $permalink );
			}

			// Change only owned attributes; the processor preserves all other markup.
			$processor->set_attribute( 'href', esc_url_raw( $permalink ) );
			$processor->remove_attribute( 'params' );
			$processor->remove_attribute( 'data-type' );
		}

		return $this->convert_semantic_links( $processor->get_updated_html() );
	}

	/**
	 * Convert semantic rich-text destinations into their current URLs.
	 *
	 * Rich-text formats cannot use the regular block-link resolver. Applying
	 * the resolver during rendering keeps stored content portable and ensures
	 * system page changes never leave persisted links pointing at stale URLs.
	 *
	 * @param string $content Rendered block content.
	 * @return string
	 */

	private function convert_semantic_links( $content ) {
		$processor = new WP_HTML_Tag_Processor( $content );
		$supported_types = array( 'privacy-policy', 'dynamic-content', 'site-destination', 'woocommerce', 'consent-preferences' );

		while( $processor->next_tag( 'A' ) ) {
			$link_type = $processor->get_attribute( 'data-type' );
			if( ! in_array( $link_type, $supported_types, true ) ) {
				continue;
			}

			$destination = sanitize_key( $processor->get_attribute( 'data-destination' ) ?? '' );
			$stored_rel = preg_split( '/\s+/', trim( (string) $processor->get_attribute( 'rel' ) ), -1, PREG_SPLIT_NO_EMPTY );
			$link = array(
				'type' => $link_type,
				'open' => $processor->get_attribute( 'target' ) === '_blank' ? 'new' : 'self',
				'rel' => $stored_rel ?: array(),
			);
			if( $link_type === 'dynamic-content' ) {
				$link['dynamic']['destination'] = $destination;
				$link['dynamic']['fieldKey'] = sanitize_key( $processor->get_attribute( 'data-field-key' ) ?? '' );
			} elseif( $link_type === 'site-destination' ) {
				$link['site']['destination'] = $destination;
			} elseif( $link_type === 'woocommerce' ) {
				$link['woocommerce']['destination'] = $destination;
			}

			$data = WPHAVE_Block_Linking::instance()->get_link( array( 'link' => $link ) );
			if ( $data && ! empty( $data['url'] ) ) {
				$processor->set_attribute( 'href', $data['url'] );
				$rel = $data['rel'] ?? array();
				if ( $rel ) {
					$processor->set_attribute( 'rel', implode( ' ', $rel ) );
				} else {
					$processor->remove_attribute( 'rel' );
				}
			} else {
				$processor->remove_attribute( 'href' );
				$processor->remove_attribute( 'rel' );
			}

			if( $link_type === 'consent-preferences' ) {
				$target_id = 'wphave-consent-preferences';
				$processor->set_attribute( 'data-modal', '#' . $target_id );
				$processor->set_attribute( 'aria-haspopup', 'dialog' );
				$processor->set_attribute( 'aria-controls', $target_id );
				$processor->set_attribute( 'aria-expanded', 'false' );
			}

			$processor->remove_attribute( 'data-type' );
			$processor->remove_attribute( 'data-destination' );
			$processor->remove_attribute( 'data-field-key' );
		}

		return $processor->get_updated_html();
	}

	/**
	 * Render-block filter callback.
	 *
	 * @param string $block_content Rendered block markup.
	 * @param array $block Parsed block data.
	 * @return string
	 */

	public function filter_block( $block_content, $block ) {
		$block_name = $block['blockName'] ?? '';

		return in_array( $block_name, self::SUPPORTED_BLOCKS, true ) ? $this->convert( $block_content ) : $block_content;
	}

}
