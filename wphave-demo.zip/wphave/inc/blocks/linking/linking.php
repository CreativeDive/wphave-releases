<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/link-layers.php';
require_once __DIR__ . '/dynamic-links.php';
require_once __DIR__ . '/manager.php';

// API INVARIANT: All WPHAVE consumers use the class API; no prerelease aliases are published.

WPHAVE_Block_Linking::instance()->boot();
