<?php

if (!defined('ABSPATH')) {
	exit;
}

/** Resolve only an active URL Content Field belonging to the rendered post. */
function wphave_resolve_content_field_link_url($field_key, $post_id) {
	$field_key = is_string($field_key) ? sanitize_key($field_key) : '';
	$post = $post_id ? get_post(absint($post_id)) : null;

	if (
		!$field_key ||
		!$post ||
		!function_exists('wphave_content_models_feature_enabled') ||
		!wphave_content_models_feature_enabled() ||
		!class_exists('WPHAVE_Content_Model_Registry') ||
		!class_exists('WPHAVE_Content_Model_Value_Repository') ||
		!class_exists('WPHAVE_Content_Model_Field_Type_Registry')
	) {
		return '';
	}

	$field = WPHAVE_Content_Model_Registry::field($post->post_type, $field_key);
	if (($field['type'] ?? '') !== 'url') {
		return '';
	}

	$value = WPHAVE_Content_Model_Value_Repository::get($post, $field_key);
	return is_string($value)
		? WPHAVE_Content_Model_Field_Type_Registry::sanitize('url', $value, $field)
		: '';
}
