<?php

/**
 * Manage shared WPHAVE block assets and compatibility-mode block detection.
 */

class WPHAVE_Block_Assets {

	/**
	 * Register block asset hooks.
	 *
	 * @return void
	 */

	public static function init() {
		add_action( 'enqueue_block_assets', array( __CLASS__, 'enqueue' ), 1 );
	}

	/**
	 * Enqueue shared block assets for the editor and compatibility frontend.
	 *
	 * @return void
	 */

    public static function enqueue() {

        if( ! is_admin() ) {
            if( self::should_enqueue_compatibility_assets() ) {
                wp_enqueue_script('wphave');
                wp_enqueue_style('wphave');
                self::enqueue_shared_interaction_assets();
            }

            return;
        }

        wp_enqueue_script('wphave'); // General scripts for frontend + editor

        self::enqueue_editor_canvas_styles();

        self::enqueue_shared_interaction_assets();

        // Extra block assets were moved from a procedural callback into their
        // own service. Check that service directly so editor-only previews keep
        // receiving device frames, navigation variants and vendor assets.
        if( class_exists( 'WPHAVE_Extra_Block_Assets' ) ) {
            WPHAVE_Extra_Block_Assets::enqueue();
        }

        /*
        * INFO: All wphave block type specific assets are
        * automatically loaded via block.json definition.
        */

	}

    /**
     * Enqueue the complete shared stylesheet contract for editor canvases.
     *
     * WordPress resolves an iframe's document assets from enqueue_block_assets.
     * Keeping every shared canvas stylesheet on that hook means Gutenberg can
     * place it in __unstableResolvedAssets before creating its Blob document.
     * The parent-document compatibility scanner is deliberately not part of
     * this contract: it caches its first result and is unsafe across SPA editor
     * remounts when a stylesheet was still loading at that point.
     *
     * @return void
     */

    public static function enqueue_editor_canvas_styles() {
        $style_handles = array(
            'wphave',
            'wphave-editor',
            'wphave-block-ui',
            'wphave-post-editor',
            'wphave-block-editor',
        );

        foreach( $style_handles as $style_handle ) {
            wp_enqueue_style( $style_handle );
        }

        if( function_exists( 'wp_enqueue_global_styles_css_custom_properties' ) ) {
            wp_enqueue_global_styles_css_custom_properties();
        }
    }

	/**
	 * Determine whether a third-party theme request contains WPHAVE blocks.
	 *
	 * @return bool
	 */

	public static function should_enqueue_compatibility_assets() {


        if( ! function_exists( 'wphave_use_fse' ) || ! wphave_use_fse() ) {
            return false;
        }

        return self::current_request_has_blocks();

	}

	/**
	 * Enqueue interaction assets shared by generic WPHAVE block features.
	 *
	 * @return void
	 */

	public static function enqueue_shared_interaction_assets() {

        wp_enqueue_script('wphave-text-writer');
        wp_enqueue_script('wphave-tooltip');
        wp_enqueue_script('wphave-lightbox');
        wp_enqueue_script('wphave-fit-text');
        wp_enqueue_script('wphave-text-mask');
        wp_enqueue_script('wphave-modal');
        wp_enqueue_script('wphave-popover');
        wp_enqueue_script('wphave-side-panel');
        wp_enqueue_script('wphave-swiper');
        wp_enqueue_script('wphave-parallax');
        wp_enqueue_script('wphave-scroll-nav');
        wp_enqueue_script('wphave-flex-scroll');
        wp_enqueue_script('wphave-flex-animation');
        wp_enqueue_script('wphave-animate-in');
        wp_enqueue_script('wphave-sticky');
        wp_enqueue_style('wphave-tooltip');
        wp_enqueue_style('wphave-lightbox');
        wp_enqueue_style('wphave-modal');
        wp_enqueue_style('wphave-popover');
        wp_enqueue_style('wphave-side-panel');

	}

	/**
	 * Inspect the current query and template content for WPHAVE blocks.
	 *
	 * @return bool
	 */

	public static function current_request_has_blocks() {

        $post_ids = array();

        if( is_singular() ) {
            $post_ids[] = get_queried_object_id();
        }

        global $wp_query;

        if( isset( $wp_query->posts ) && is_array( $wp_query->posts ) ) {
            foreach( $wp_query->posts as $post ) {
                $post_id = is_object( $post ) && isset( $post->ID ) ? (int) $post->ID : 0;

                if( $post_id ) {
                    $post_ids[] = $post_id;
                }
            }
        }

        $post_ids = array_values( array_unique( array_filter( array_map( 'absint', $post_ids ) ) ) );

        foreach( $post_ids as $post_id ) {
            if( self::content_has_blocks( get_post_field( 'post_content', $post_id ) ) ) {
                return true;
            }
        }

        global $_wp_current_template_content;

        if( ! empty( $_wp_current_template_content ) && self::content_has_blocks( $_wp_current_template_content ) ) {
            return true;
        }

        return false;

	}

	/**
	 * Parse serialized content and detect nested WPHAVE blocks.
	 *
	 * @param string $content Serialized block content.
	 * @param int[] $seen_reusable_blocks Reusable block IDs already traversed.
	 * @param array $seen_template_parts Template part IDs already traversed.
	 * @return bool
	 */

	public static function content_has_blocks( $content, $seen_reusable_blocks = array(), $seen_template_parts = array() ) {

        if( ! is_string( $content ) ) {
            return false;
        }

        if(
            ! str_contains( $content, '<!-- wp:wphave/' ) &&
            ! str_contains( $content, '<!-- wp:block' ) &&
            ! str_contains( $content, '<!-- wp:template-part' )
        ) {
            return false;
        }

        $blocks = parse_blocks( $content );

        return self::parsed_blocks_have_blocks( $blocks, $seen_reusable_blocks, $seen_template_parts );

	}

	/**
	 * Recursively inspect parsed blocks, reusable blocks and template parts.
	 *
	 * @param array $blocks Parsed block tree.
	 * @param int[] $seen_reusable_blocks Reusable block IDs already traversed.
	 * @param array $seen_template_parts Template part IDs already traversed.
	 * @return bool
	 */

	public static function parsed_blocks_have_blocks( $blocks, $seen_reusable_blocks = array(), $seen_template_parts = array() ) {

        if( ! is_array( $blocks ) ) {
            return false;
        }

        foreach( $blocks as $block ) {
            $block_name = $block['blockName'] ?? '';

            if( is_string( $block_name ) && str_starts_with( $block_name, 'wphave/' ) ) {
                return true;
            }

            if( $block_name === 'core/block' ) {
                $ref_id = absint( $block['attrs']['ref'] ?? 0 );

                if( $ref_id && ! in_array( $ref_id, $seen_reusable_blocks, true ) ) {
                    $seen_reusable_blocks[] = $ref_id;
                    $reusable_block = get_post( $ref_id );

                    if( $reusable_block && $reusable_block->post_type === 'wp_block' && self::content_has_blocks( $reusable_block->post_content ?? '', $seen_reusable_blocks, $seen_template_parts ) ) {
                        return true;
                    }
                }
            }

            if( $block_name === 'core/template-part' && function_exists( 'get_block_template' ) ) {
                $template_part_slug = sanitize_key( $block['attrs']['slug'] ?? '' );
                $template_part_theme = sanitize_key( $block['attrs']['theme'] ?? get_stylesheet() );
                $template_part_id = $template_part_slug ? $template_part_theme . '//' . $template_part_slug : '';

                if( $template_part_id && ! in_array( $template_part_id, $seen_template_parts, true ) ) {
                    $seen_template_parts[] = $template_part_id;
                    $template_part = get_block_template( $template_part_id, 'wp_template_part' );

                    if( $template_part && ! empty( $template_part->content ) && self::content_has_blocks( $template_part->content, $seen_reusable_blocks, $seen_template_parts ) ) {
                        return true;
                    }
                }
            }

            if( ! empty( $block['innerBlocks'] ) && self::parsed_blocks_have_blocks( $block['innerBlocks'], $seen_reusable_blocks, $seen_template_parts ) ) {
                return true;
            }
        }

        return false;

	}
}
