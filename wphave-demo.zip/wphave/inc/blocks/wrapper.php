<?php

if (!function_exists('wphave_block_wrapper_has_layout_container')):
	/**
	 * Determine whether a block requires its layout container.
	 *
	 * Keep this condition synchronized with the editor's `hasLayoutContainer`.
	 *
	 * @param array $wphave WPHAVE block settings.
	 * @param array $supports Registered block supports.
	 * @return bool Whether the layout container is required.
	 */

	function wphave_block_wrapper_has_layout_container(array $wphave, array $supports): bool {
		// Keep this condition in sync with src/block-runtime/core/supports/get-block-conditions.js -> hasLayoutContainer.
		$layout = $wphave['layout'] ?? null;
		$has_layout_support = !empty($supports['wphave']['layout']['types']);

		return !empty($layout) || $has_layout_support;
	}
endif;

if (!function_exists('wphave_block_wrapper_layout_classes')):
	/**
	 * Complete missing generated layout classes for old/default block attributes.
	 *
	 * Editor create-block-styles resolves an unspecified layout as stacked.
	 * PHP must do the same even when the saved classNames cache only contains ly.
	 * Existing mode classes remain authoritative (including global styles).
	 * Responsive modifiers alone do not define a desktop layout mode.
	 *
	 * @param array $classes Persisted/effective class names.
	 * @param array $wphave Effective settings after global-style resolution.
	 * @param array $supports Registered block supports.
	 * @return array Classes with missing layout defaults completed.
	 */
	function wphave_block_wrapper_layout_classes(
		array $classes,
		array $wphave,
		array $supports,
	): array {
		if (!wphave_block_wrapper_has_layout_container($wphave, $supports)) {
			return $classes;
		}
		$tokens = preg_split('/\s+/', trim(implode(' ', $classes)), -1, PREG_SPLIT_NO_EMPTY);
		if (!in_array('ly', $tokens, true)) {
			$tokens[] = 'ly';
		}
		$modes = [
			'stacked' => 'ly-stk',
			'grid' => 'ly-gr',
			'gridAreas' => 'ly-gra',
			'flex' => 'ly-fl',
			'swiper' => 'ly-sw',
			'masonry' => 'ly-mry',
			'alternately' => 'ly-alt',
		];
		if (!array_intersect($tokens, array_values($modes))) {
			$type = $wphave['layout']['type'] ?? 'stacked';
			if (is_string($type) && isset($modes[$type])) {
				$tokens[] = $modes[$type];
				if ($type === 'swiper') {
					$tokens[] = 'is-swiper';
					$tokens[] = 'swiper';
				}
			}
		}
		return array_values(array_unique($tokens));
	}
endif;

if (!function_exists('wphave_block_wrapper_has_scroll_container')):
	/**
	 * Determine whether a block requires its scroll container.
	 *
	 * Keep this condition synchronized with the editor's `hasScrollContainer`.
	 *
	 * @param array $wphave WPHAVE block settings.
	 * @param string $block_name Block name.
	 * @return bool Whether the scroll container is required.
	 */

	function wphave_block_wrapper_has_scroll_container(array $wphave, string $block_name): bool {
		// Keep this condition in sync with src/block-runtime/core/supports/get-block-conditions.js -> hasScrollContainer.
		$dimensions_height = $wphave['dimensions']['height'] ?? null;
		$overflow = $wphave['dimensions']['overflow'] ?? '';
		$has_scroll_option = in_array($overflow, ['auto', 'scroll-x', 'scroll-y'], true);

		return (!empty($dimensions_height) && $has_scroll_option) ||
			$block_name === 'wphave/popup' ||
			$block_name === 'wphave/cta-slide-in';
	}
endif;

if (!function_exists('wphave_block_wrapper_context')):
	/**
	 * Resolve the shared wrapper structure used by opening and closing output.
	 *
	 * Calculating this once through a common helper prevents mismatched wrapper
	 * markup when layout or scroll-container conditions change.
	 *
	 * @param array $wphave WPHAVE block settings.
	 * @param array $args Block-render arguments.
	 * @return array Wrapper-state flags and attributes.
	 */

	function wphave_block_wrapper_context(array $wphave, array $args): array {
		$block_name = $args['block_name'] ?? '';
		$supports = $args['supports'] ?? [];
		$layout_type = $wphave['layout']['type'] ?? 'stacked';
		$flex_motion = $wphave['layout']['flex']['flexMotion'] ?? 'static';
		$has_layout_container = wphave_block_wrapper_has_layout_container($wphave, $supports);
		$has_scroll_container = wphave_block_wrapper_has_scroll_container($wphave, $block_name);

		return [
			'flex_motion' => $flex_motion,
			'scroll_target_id' => $wphave['layout'][$layout_type]['scrollTargetId'] ?? '',
			'is_flex' => $layout_type === 'flex',
			'is_swiper' => $layout_type === 'swiper',
			'has_layout_container' => $has_layout_container,
			'has_scroll_container' => $has_scroll_container,
			'has_inner_container' => $has_layout_container || $has_scroll_container,
		];
	}
endif;

if (!function_exists('wphave_block_wrapper_tag_name')):
	/**
	 * Resolve an allowed frontend block wrapper tag.
	 *
	 * Dynamic blocks may choose a semantic tag, but arbitrary tag fragments
	 * must never reach the generated opening or closing markup.
	 *
	 * @param string $tag Requested tag name.
	 * @return string Allowed tag name.
	 */

	function wphave_block_wrapper_tag_name($tag): string {
		// Heading blocks deliberately select their semantic level at render time.
		// Keep every supported wrapper explicit so arbitrary element names still
		// fall back safely without flattening valid headings to a div.
		$allowed_tags = [
			'a',
			'article',
			'aside',
			'blockquote',
			'button',
			'div',
			'figure',
			'footer',
			'form',
			'h1',
			'h2',
			'h3',
			'h4',
			'h5',
			'h6',
			'header',
			'li',
			'main',
			'nav',
			'ol',
			'p',
			'section',
			'span',
			'time',
			'ul',
		];
		$tag = strtolower(sanitize_key((string) $tag));

		return in_array($tag, $allowed_tags, true) ? $tag : 'div';
	}
endif;

if (!function_exists('wphave_parse_html_attribute_string')):
	/**
	 * Parse a legacy attribute string into a structured attribute map.
	 *
	 * Existing block renderers still provide escaped attribute fragments. The
	 * WordPress HTML parser lets the wrapper retain that API without printing
	 * the fragments directly. New code should pass associative arrays instead.
	 *
	 * @param string $attributes Attribute fragment.
	 * @return array Parsed attribute map.
	 */

	function wphave_parse_html_attribute_string($attributes): array {
		$processor = new WP_HTML_Tag_Processor('<div ' . trim((string) $attributes) . '></div>');
		if (!$processor->next_tag('DIV')) {
			return [];
		}

		$parsed = [];
		foreach ($processor->get_attribute_names_with_prefix('') ?? [] as $name) {
			$parsed[$name] = $processor->get_attribute($name);
		}

		return $parsed;
	}
endif;

if (!function_exists('wphave_serialize_html_attributes')):
	/**
	 * Serialize structured and legacy HTML attributes safely.
	 *
	 * @param array $attribute_groups Attribute arrays or escaped legacy strings.
	 * @return string Serialized attributes without leading whitespace.
	 */

	function wphave_serialize_html_attributes($attribute_groups): string {
		$attribute_groups = is_array($attribute_groups) ? $attribute_groups : [$attribute_groups];
		$attributes = [];
		$standard_attributes = [
			'accesskey',
			'action',
			'autocapitalize',
			'autocomplete',
			'autofocus',
			'charset',
			'checked',
			'cite',
			'class',
			'contenteditable',
			'crossorigin',
			'datetime',
			'dir',
			'disabled',
			'download',
			'draggable',
			'enctype',
			'enterkeyhint',
			'for',
			'form',
			'formaction',
			'formenctype',
			'formmethod',
			'formnovalidate',
			'formtarget',
			'height',
			'hidden',
			'href',
			'hreflang',
			'id',
			'inert',
			'inputmode',
			'integrity',
			'is',
			'itemprop',
			'lang',
			'max',
			'maxlength',
			'media',
			'method',
			'min',
			'minlength',
			'multiple',
			'name',
			'nonce',
			'novalidate',
			'open',
			'part',
			'pattern',
			'ping',
			'placeholder',
			'popover',
			'popovertarget',
			'popovertargetaction',
			'poster',
			'readonly',
			'referrerpolicy',
			'rel',
			'required',
			'role',
			'rows',
			'selected',
			'sizes',
			'slot',
			'spellcheck',
			'src',
			'step',
			'style',
			'tabindex',
			'target',
			'title',
			'translate',
			'type',
			'value',
			'width',
			'wrap',
		];

		foreach ($attribute_groups as $key => $value) {
			$group = is_int($key)
				? (is_array($value)
					? $value
					: wphave_parse_html_attribute_string($value))
				: [$key => $value];
			foreach ($group as $name => $attribute_value) {
				$name = strtolower((string) $name);
				$is_extended_attribute =
					str_starts_with($name, 'aria-') || str_starts_with($name, 'data-');
				if (
					!preg_match('/^[a-z][a-z0-9:._-]*$/', $name) ||
					(!$is_extended_attribute && !in_array($name, $standard_attributes, true))
				) {
					continue;
				}

				if ($attribute_value === true) {
					$attributes[$name] = $name;
					continue;
				}

				if ($attribute_value === false || $attribute_value === null) {
					unset($attributes[$name]);
					continue;
				}

				$attribute_value = (string) $attribute_value;
				if ($name === 'class') {
					$attribute_value = implode(
						' ',
						array_filter(
							array_map(
								'sanitize_html_class',
								preg_split('/\s+/', trim($attribute_value)),
							),
						),
					);
				} elseif (in_array($name, ['href', 'src', 'action', 'formaction'], true)) {
					$attribute_value = esc_url($attribute_value);
				} elseif ($name === 'style') {
					$attribute_value = safecss_filter_attr($attribute_value);
				}

				$attributes[$name] = $name . '="' . esc_attr($attribute_value) . '"';
			}
		}

		return implode(' ', array_values($attributes));
	}
endif;

/**
 * Render the opening wrapper structure for a WPHAVE block.
 *
 * @param array $wphave WPHAVE block settings.
 * @param array $args Block-render arguments.
 * @return void
 */

add_action(
	'block_wrapper_start',
	function ($wphave, $args = []) {
		$id = $args['id'] ?? '';
		$css = $args['css'] ?? '';
		$tag = wphave_block_wrapper_tag_name($args['tag'] ?? 'div');
		$class = $args['class'] ?? [];
		$link_overlay = $args['linkOverlay'] ?? false;
		$block_wrapper = $args['blockWrapper'] ?? true;
		$data_attributes = $args['dataAttributes'] ?? [];
		$link_attributes = $args['linkAttributes'] ?? [];
		$before_inner_blocks = $args['beforeInnerBlocks'] ?? '';
		$before_layout_container = $args['beforeLayoutContainer'] ?? '';
		$inner_container_tag = wphave_block_wrapper_tag_name($args['innerContainerTag'] ?? 'div');
		$inner_container_class = $args['innerContainerClass'] ?? '';
		$inner_container_attributes = $args['innerContainerAttributes'] ?? [];
		$prevent_block_classes = $args['preventBlockClasses'] ? true : '';
		$prevent_block_background = $args['preventBlockBackgroundOutput'] ?? '';

		$back_glow = $wphave['shadow']['backGlow'] ?? '';
		$image_duotones = $wphave['features']['duotones'] ?? [];

		$has_close_button = $args['closeButton'] ?? '';
		$wrapper_context = wphave_block_wrapper_context($wphave, $args);

		// Build block classes before serializing the wrapper attributes.

		$classes = [];

		// Block classes
		$block_classes = wphave_block_wrapper_classes($args);

		if ($block_classes) {
			$classes[] = $block_classes;
		}

		// Build wrapper attributes separately so their output order stays predictable.

		$attributes = [];

		// Classes
		if ($class && !$prevent_block_classes) {
			if (is_array($class)) {
				$classes[] = implode(' ', $class);
			} else {
				$classes[] = $class;
			}
		}

		$attributes['class'] = implode(' ', $classes);

		// Id
		if ($id) {
			$attributes['id'] = $id;
		}

		// Data attributes
		if ($data_attributes) {
			foreach ($data_attributes as $data_attribute) {
				$attributes[] = $data_attribute;
			}
		}

		// Link attributes
		if ($link_attributes && !$link_overlay) {
			foreach ($link_attributes as $link_attribute) {
				$attributes[] = $link_attribute;
			}
		}

		// Render the outer block wrapper before optional decoration and layout layers.

		if ($block_wrapper) { ?>
		<<?php echo esc_html($tag); ?> <?php echo wphave_serialize_html_attributes($attributes); ?>>
	<?php }

		$duotone_css = wphave_duotone_style_overrides($id, $wphave);
		if ($css || $duotone_css) {
			if (is_array($css)) {
				$css = WPHAVE_Global_Styles::build_css_from_array($css);
			}

			$css = (string) $css . $duotone_css;

			WPHAVE_Style_Engine::instance()->print_inline_styles($css);
		}

		// Use the link overlay, to link e.g. the whole wphave/group block
		if ($link_overlay) {

			$has_accessible_name = preg_grep(
				'/^(aria-label|aria-labelledby|title)="/',
				$link_attributes,
			);
			if (!$has_accessible_name) {
				$link_attributes[] =
					'aria-label="' . esc_attr__('Open linked content', 'wphave') . '"';
			}
			?>
		<a class="wph-b-link-overlay" <?php echo wphave_serialize_html_attributes(
			$link_attributes,
		); ?>></a>
	<?php
		}

		if ($image_duotones) {
			echo wphave_svg_duotone_filter_for_value($image_duotones);
		}

		// Paint the block color above its glow, below background layers and content.
		if ($back_glow) { ?>
		<div class="bglw-con" aria-hidden="true"></div>
		<div class="bglw-surface" aria-hidden="true"></div>
	<?php }

		if (!$prevent_block_background) {
			do_action('block_background', $wphave, $args);
		}

		do_action(
			'wphave_block_content_notices',
			array_merge($args, ['renderWphave' => $wphave]),
			'before',
		);

		if ($before_inner_blocks) {
			echo wp_kses_post($before_inner_blocks);
		}

		if ($before_layout_container) {
			echo wp_kses_post($before_layout_container);
		}

		if ($has_close_button) {
			$close_button_args = is_array($has_close_button) ? $has_close_button : [];
			$close_button_args['class'] = trim(
				'wph-b-close-button ' . ($close_button_args['class'] ?? ''),
			);
			echo wphave_close_button($close_button_args);
		}

		$block_wrapper_classes = [];
		if ($wrapper_context['has_layout_container']) {
			$block_wrapper_classes[] = 'ly-con';
		}
		if ($wrapper_context['has_scroll_container']) {
			$block_wrapper_classes[] = 'scroll-con';
		}
		if ($wrapper_context['is_swiper']) {
			$block_wrapper_classes[] = 'slider-container';
		}

		$block_wrapper_attributes = [];
		if ($wrapper_context['scroll_target_id']) {
			$block_wrapper_attributes[] =
				'data-wphave-scroll-target="' .
				esc_attr(sanitize_title($wrapper_context['scroll_target_id'])) .
				'"';
		}
		if ($inner_container_class) {
			$inner_container_classes = preg_split('/\s+/', trim((string) $inner_container_class));
			$inner_container_classes = array_filter(
				array_map('sanitize_html_class', $inner_container_classes),
			);
			if ($inner_container_classes) {
				$block_wrapper_classes[] = implode(' ', $inner_container_classes);
			}
		}
		if ($inner_container_attributes) {
			$block_wrapper_attributes[] = $inner_container_attributes;
		}

		// ! Note: The layout container is generally used because it clearly separates the specified global CSS variables, thus targeting the correct scope.
		// The container is necessary to apply CSS container queries based on the container width
		if ($wrapper_context['has_inner_container']) { ?>
		<<?php echo esc_html($inner_container_tag); ?> class="<?php echo esc_attr(
	implode(' ', $block_wrapper_classes),
 ); ?>" <?php echo wphave_serialize_html_attributes($block_wrapper_attributes); ?>>
			<?php if (
				$wrapper_context['is_flex'] &&
				$wrapper_context['flex_motion'] === 'animated'
			) { ?>
				<div class="ly-ani-items">
			<?php }}
	},
	10,
	2,
);

/**
 * Render the closing wrapper structure for a WPHAVE block.
 *
 * This must use the same resolved wrapper context as the opening callback.
 *
 * @param array $wphave WPHAVE block settings.
 * @param array $args Block-render arguments.
 * @return void
 */

add_action(
	'block_wrapper_end',
	function ($wphave, $args = []) {
		$tag = wphave_block_wrapper_tag_name($args['tag'] ?? 'div');
		$block_wrapper = $args['blockWrapper'] ?? true;
		$after_inner_blocks = $args['afterInnerBlocks'] ?? '';
		$inner_container_tag = wphave_block_wrapper_tag_name($args['innerContainerTag'] ?? 'div');
		$wrapper_context = wphave_block_wrapper_context($wphave, $args);

		if ($wrapper_context['has_inner_container']) {
			if ($wrapper_context['is_flex'] && $wrapper_context['flex_motion'] === 'animated') { ?>
			</div>
		<?php } ?>
		</<?php echo esc_html($inner_container_tag); ?>>
	<?php
		}

		do_action(
			'wphave_block_content_notices',
			array_merge($args, ['renderWphave' => $wphave]),
			'after',
		);

		if ($after_inner_blocks) {
			echo wp_kses_post($after_inner_blocks);
		}

		if ($block_wrapper) { ?>
		</<?php echo esc_html($tag); ?>>
	<?php }
	},
	10,
	2,
);
