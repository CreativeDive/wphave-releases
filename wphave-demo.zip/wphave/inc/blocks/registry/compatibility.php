<?php

/**
 * Define the explicit block policy for third-party theme compatibility mode.
 */

class WPHAVE_Block_Compatibility {

	/**
	 * Return blocks that require the bundled WPHAVE theme runtime.
	 *
	 * @return string[]
	 */

	public static function disallowed_blocks() {

    return array(
        // Hero placement and output are controlled by the WPHAVE theme render engine.
        'wphave/hero',

        // Site logo placement is part of the WPHAVE theme header/navigation structure.
        'wphave/site-logo',

        // These template slots are owned by the WPHAVE theme; third-party themes provide their own equivalents.
        'wphave/comments',
        'wphave/content',

        // The add-on post type and its site-wide render pipeline are unavailable in compatibility mode.
		'wphave/announcement-bar',
        'wphave/coming-soon',
        'wphave/maintenance',
        'wphave/cta-slide-in',
        'wphave/popup',
        'wphave/open-graph',
        'wphave/pin-button',
        'wphave/scroll-to-top',
        'wphave/social-bar',
        'wphave/x-card',

        // Internal style carrier used by the WPHAVE editor/render engine, not a standalone content block.
        'wphave/style',
    );

	}
}
