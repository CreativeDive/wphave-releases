<?php

/**
 * Register WPHAVE block metadata, render callbacks and excerpt support.
 */

class WPHAVE_Block_Registry {
	/**
	 * Register block metadata and initialization hooks.
	 *
	 * @return void
	 */

	public static function init() {
		add_filter('block_type_metadata_settings', [__CLASS__, 'filter_metadata_settings'], 10, 2);
		add_action('init', [__CLASS__, 'register_all'], 0);
		add_filter('excerpt_allowed_blocks', [__CLASS__, 'filter_excerpt_allowed_blocks']);
	}

	/**
	 * Return generated directories containing registerable WPHAVE blocks.
	 *
	 * @return string[]
	 */

	public static function block_directories() {
		return [
			wphave_dir() . 'build/block-types/blocks',
			wphave_dir() . 'build/block-types/blocks-form',
			wphave_dir() . 'build/block-types/blocks-layout',
			wphave_dir() . 'build/block-types/blocks-add-ons',
			wphave_dir() . 'build/block-types/blocks-templates',
		];
	}

	/**
	 * Add shared WPHAVE attributes and context mappings to block metadata.
	 *
	 * @param array $settings Resolved block settings.
	 * @param array $metadata Raw block.json metadata.
	 * @return array
	 */

	public static function filter_metadata_settings($settings, $metadata) {
		$block_name = $settings['name'] ?? ($metadata['name'] ?? '');

		if (!is_string($block_name) || strpos($block_name, 'wphave/') !== 0) {
			return $settings;
		}

		// Metadata scripts are registered by WordPress before this filter runs.
		// The shared registration filter and its translation catalog must execute
		// before any block entry, regardless of the order editors enqueue them.
		// Only editor scripts depend on this bootstrap; frontend assets stay separate.
		$scripts = wp_scripts();
		foreach ($settings['editor_script_handles'] ?? [] as $handle) {
			$script = $scripts->registered[$handle] ?? null;
			if ($script && 'wphave-block-editor' !== $handle) {
				$script->deps = array_values(
					array_unique(array_merge($script->deps, ['wphave-block-editor'])),
				);
			}
		}

		if (
			in_array($block_name, ['wphave/guide', 'wphave/guide-step'], true) &&
			!wphave_release_feature_ready('interactiveGuide')
		) {
			$settings['category'] = 'wphave-experiments';
			$settings['supports'] = array_merge($settings['supports'] ?? [], ['inserter' => false]);
		}

		if ('wphave/shape' === $block_name && !wphave_release_feature_ready('shapeDesigner')) {
			$settings['category'] = 'wphave-experiments';
			$settings['supports'] = array_merge($settings['supports'] ?? [], ['inserter' => false]);
		}

		$settings['attributes'] = array_merge($settings['attributes'] ?? [], [
			'name' => [
				'type' => 'string',
				'default' => $block_name,
			],
		]);

		$provides_context = [
			'wphave/wphave' => 'wphave',
			'wphave/blockName' => 'name',
		];

		if ($block_name === 'wphave/form') {
			$provides_context['wphave/form/id'] = 'formId';
		}

		$settings['provides_context'] = array_merge(
			$settings['provides_context'] ?? [],
			$provides_context,
		);

		return $settings;
	}

	/**
	 * Register all valid block metadata found in one generated directory.
	 *
	 * @param string $directory Generated block directory.
	 * @return void
	 */

	public static function register_blocks($directory) {
		if (!file_exists($directory)) {
			return;
		}

		$disallowed_for_fse = WPHAVE_Block_Compatibility::disallowed_blocks();

		$block_directories = glob($directory . '/*');
		$blocks = is_array($block_directories) ? array_filter($block_directories, 'is_dir') : [];

		foreach ($blocks as $folder) {
			$block_json = $folder . '/block.json';
			// Block names remain persisted even though WPHAVE renders frontend HTML
			// dynamically in PHP. Never rename/remove one without a compatibility
			// registration and an explicit content migration.
			$block_name = 'wphave/' . basename($folder); // Keep the folder name aligned with block.json.

			if (wphave_use_fse() && in_array($block_name, $disallowed_for_fse, true)) {
				continue; // Do not register these type of blocks if the user has been enabled FSE!
			}

			if (file_exists($block_json)) {
				register_block_type($block_json, [
					'render_callback' => ['WPHAVE_Block_Renderer', 'render'],
				]);
			}
		}
	}

	/**
	 * Register the generated WordPress block metadata manifest when supported.
	 *
	 * @return void
	 */

	public static function register_metadata_collection() {
		if (!function_exists('wp_register_block_metadata_collection')) {
			return;
		}

		$base_path = wphave_dir() . 'build/block-types';
		$manifest = $base_path . '/blocks-manifest.php';

		if (!file_exists($manifest)) {
			return;
		}

		wp_register_block_metadata_collection($base_path, $manifest);
	}

	/**
	 * Register the metadata collection and every generated WPHAVE block directory.
	 *
	 * @return void
	 */

	public static function register_all() {
		self::register_metadata_collection();

		$directories = self::block_directories();

		foreach ($directories as $directory) {
			self::register_blocks($directory);
		}
	}

	/**
	 * Allow text-producing WPHAVE blocks in WordPress automatic excerpts.
	 *
	 * @param string[] $blocks Existing excerpt-compatible block names.
	 * @return array
	 */

	public static function filter_excerpt_allowed_blocks($blocks) {
		return array_merge($blocks, ['wphave/paragraph', 'wphave/heading', 'wphave/button']);
	}
}
