<?php

/**
 * Provide registered block type metadata to the protected editor settings UI.
 */

class WPHAVE_Block_Types_REST {

	/**
	 * Register the REST lifecycle hook.
	 *
	 * @return void
	 */

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * Register the block type metadata endpoint.
	 *
	 * @return void
	 */

	public static function register_routes() {
		register_rest_route( 'wphave/v1', '/block_types_registered', array(
			'methods' => WP_REST_Server::READABLE,
			'callback' => array( __CLASS__, 'get_registered_block_types' ),
			'permission_callback' => array( __CLASS__, 'permissions' ),
		) );
	}

	/**
	 * Restrict block configuration data to site administrators.
	 *
	 * @return bool Whether the current user may inspect block settings.
	 */

	public static function permissions() {
		// INFORMATION-DISCLOSURE INVARIANT: The complete server block registry exposes
		// feature availability and callback metadata and therefore remains an
		// administrator diagnostic rather than a general editor endpoint.
		return current_user_can( 'manage_options' );
	}

	/**
	 * Return editor-safe metadata for every registered block type.
	 *
	 * @return array
	 */

	public static function get_registered_block_types() {
		// AUTHORIZATION INVARIANT: The executable registry callback repeats administrative authority before enumerating server feature and block metadata.
		if( ! self::permissions() ) {
			return new WP_Error(
				'wphave_block_registry_forbidden',
				__( 'You are not allowed to inspect the block registry.', 'wphave' ),
				array( 'status' => 403 )
			);
		}

        $block_types = WP_Block_Type_Registry::get_instance()->get_all_registered();
        $registered_block_types = array();

        foreach( $block_types as $block_name => $block_type ) {
            if( ! is_string( $block_name ) || ! $block_name ) {
                continue;
            }

            $registered_block_types[ $block_name ] = array(
                'name' => $block_type->name ?? $block_name,
                'title' => $block_type->title ?? $block_name,
                'icon' => is_scalar( $block_type->icon ?? null ) ? $block_type->icon : '',
                'category' => $block_type->category ?? '',
                'description' => $block_type->description ?? '',
                'parent' => $block_type->parent ?? array(),
                'ancestor' => $block_type->ancestor ?? array(),
            );
        }

        return $registered_block_types;

	}

}
