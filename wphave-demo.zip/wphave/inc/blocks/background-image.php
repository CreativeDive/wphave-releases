<?php

/**
 * CSS-background settings for decorative images. Keep in sync with
 * src/general/js/background-image/settings.js.
 */
function wphave_background_image_settings($image) {
	$image = is_array($image) ? $image : [];
	$value = $image['background'] ?? null;
	if (!is_array($value) || !$value || ($image['animation']['type'] ?? '') === 'parallax') {
		return null;
	}
	$legacy = [
		'cover' => 'cover',
		'contain' => 'contain',
		'fill' => 'stretch',
		'none' => 'auto',
		'scale-down' => 'contain',
	];
	$fit = $image['fit'] ?? 'cover';
	$default_size = is_string($fit) ? $legacy[$fit] ?? 'cover' : 'cover';
	$size = $value['size'] ?? $default_size;
	if (!in_array($size, ['cover', 'contain', 'auto', 'stretch', 'custom'], true)) {
		$size = $default_size;
	}
	$dimension = static function ($input) {
		return is_string($input) &&
			preg_match(
				'/^(?:auto|(?:\d+(?:\.\d+)?|\.\d+)(?:px|em|rem|%|vw|vh|vmin|vmax))$/D',
				$input,
			)
			? $input
			: 'auto';
	};
	$repeat = $value['repeat'] ?? 'no-repeat';
	$attachment = $value['attachment'] ?? 'scroll';
	return [
		'background-size' =>
			$size === 'custom'
				? $dimension($value['width'] ?? 'auto') .
					' ' .
					$dimension($value['height'] ?? 'auto')
				: ($size === 'stretch'
					? '100% 100%'
					: $size),
		'background-repeat' => in_array(
			$repeat,
			['no-repeat', 'repeat', 'repeat-x', 'repeat-y', 'space', 'round'],
			true,
		)
			? $repeat
			: 'no-repeat',
		'background-attachment' => in_array($attachment, ['scroll', 'fixed', 'local'], true)
			? $attachment
			: 'scroll',
	];
}

/** CSS rendering is reserved for formatting that object-fit cannot express. */
function wphave_background_image_uses_css($image) {
	$settings = wphave_background_image_settings($image);
	return $settings &&
		(($image['background']['size'] ?? '') === 'custom' ||
			$settings['background-repeat'] !== 'no-repeat' ||
			$settings['background-attachment'] !== 'scroll');
}

/** Resolve the attachment and resolution before choosing either output format. */
function wphave_resolve_background_image($image, $wphave = [], $post_id = null) {
	$type = $image['type'] ?? 'custom';
	$id =
		$type === 'featured'
			? get_post_thumbnail_id($post_id ?? get_the_ID())
			: absint($image['data']['id'] ?? 0);
	$resolution = WPHAVE_Block_Image_Size::resolve($wphave, [
		'image' => $id,
		'size' => $image['size'] ?? 'auto',
	]);
	$url =
		$type === 'url'
			? $image['data']['url'] ?? ''
			: ($id
				? wphave_image_src($id, $resolution['size'])
				: '');
	return [
		'id' => $type === 'url' ? 0 : $id,
		'url' => esc_url_raw((string) $url, ['http', 'https']),
		'size' => $resolution['size'],
		'sizes' => $resolution['sizes'] ?? '',
	];
}

/** Render from resolved source data, preserving responsive img output where possible. */
function wphave_render_background_image($source, $image) {
	if (empty($source['url'])) {
		return '';
	}
	$settings = wphave_background_image_settings($image);
	if (!wphave_background_image_uses_css($image)) {
		$fit = '';
		if ($settings) {
			$fit =
				[
					'cover' => 'cover',
					'contain' => 'contain',
					'auto' => 'none',
					'100% 100%' => 'fill',
				][$settings['background-size']] ?? '';
		}
		$attr = ['alt' => '', 'role' => 'presentation', 'sizes' => $source['sizes']];
		if ($fit) {
			$attr['style'] = 'object-fit:' . $fit;
		}
		if ($source['id']) {
			return wphave_image($source['id'], $source['size'], $attr, ['pin_button' => false]);
		}
		return '<img src="' .
			esc_url($source['url']) .
			'" alt="" role="presentation" decoding="async"' .
			($fit ? ' style="object-fit:' . esc_attr($fit) . '"' : '') .
			' />';
	}
	$style =
		'background-image:url(' .
		wp_json_encode($source['url'], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) .
		');';
	foreach ($settings as $property => $value) {
		$style .= $property . ':' . $value . ';';
	}
	return '<span class="wphave-background-image" aria-hidden="true" style="' .
		esc_attr($style) .
		'"></span>';
}
