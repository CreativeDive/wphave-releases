<?php

/**
 * WPHAVE Block Styles Attribute Assignments domain implementation.
 *
 * @internal Composed by WPHAVE_Block_Styles to preserve its public API.
 */

if ( ! trait_exists( 'WPHAVE_Block_Styles_Attribute_Assignments' ) ) :

	trait WPHAVE_Block_Styles_Attribute_Assignments {

	/**
	 * Merges global block style attributes into a block's wphave data.
	 *
	 * @param mixed $wphave Existing wphave attribute data.
	 * @param string $block_name Optional full block name for compatibility checks.
	 * @return mixed Updated wphave data or the original value when not applicable.
	 */

	public static function apply_attrs( $wphave, $block_name = '' ) {

		if( ! is_array( $wphave ) ) {
			return $wphave;
		}

		$style_id = absint( $wphave['useBlockStyle'] ?? 0 );

		if( ! $style_id ) {
			return $wphave;
		}

		if( $block_name && ! self::is_compatible( $style_id, $block_name ) ) {
			return $wphave;
		}

		$global_attrs = self::get_attrs( $style_id );

		if( ! $global_attrs ) {
			return $wphave;
		}

		foreach( self::controlled_attribute_keys() as $key ) {
			if( array_key_exists( $key, $global_attrs ) ) {
				$wphave[$key] = self::merge_style_value(
					$wphave[$key] ?? null,
					$global_attrs[$key]
				);
			}
		}

		$generated_keys = array_diff( self::style_keys(), self::controlled_attribute_keys() );
		foreach( $generated_keys as $key ) {
			if( array_key_exists( $key, $global_attrs ) ) {
				$wphave[$key] = $global_attrs[$key];
			}
		}

		foreach( self::state_group_keys() as $state_key ) {
			$state = is_array( $wphave[$state_key] ?? null ) ? $wphave[$state_key] : array();
			$global_state = is_array( $global_attrs[$state_key] ?? null ) ? $global_attrs[$state_key] : array();

			foreach( self::controlled_attribute_keys() as $key ) {
				if( array_key_exists( $key, $global_state ) ) {
					$state[$key] = self::merge_style_value(
						$state[$key] ?? null,
						$global_state[$key]
					);
				}
			}

			if( $state ) {
				$wphave[$state_key] = $state;
			} else {
				unset( $wphave[$state_key] );
			}
		}

		$wphave['useBlockStyle'] = $style_id;

		return $wphave;

	}

	/**
	 * Remove values at paths now owned by a global Block Style.
	 *
	 * @param mixed $local Local value.
	 * @param mixed $global Global owner shape.
	 * @return mixed|null Remaining local value.
	 */

	protected static function remove_owned_value( $local, $global ) {
		if( ! is_array( $local ) || ! is_array( $global ) || array_is_list( $local ) || array_is_list( $global ) ) {
			return null;
		}

		$next = $local;
		foreach( $global as $key => $global_value ) {
			if( ! array_key_exists( $key, $next ) ) {
				continue;
			}
			if( ! self::has_value( $global_value ) ) {
				continue;
			}

			if( is_array( $global_value ) && ! array_is_list( $global_value ) ) {
				$remaining = self::remove_owned_value( $next[$key], $global_value );
				if( is_array( $remaining ) && $remaining ) {
					$next[$key] = $remaining;
				} else {
					unset( $next[$key] );
				}
			} else {
				unset( $next[$key] );
			}
		}

		return $next;
	}

	/** Return custom-property names declared by generated CSS. */

	protected static function css_property_names( $css ) {
		if( ! is_string( $css ) || $css === '' ) {
			return array();
		}

		preg_match_all( '/(?:^|;)\s*(--[A-Za-z0-9_-]+)\s*:/', $css, $matches );
		return array_values( array_unique( $matches[1] ?? array() ) );
	}

	/** Remove generated declarations owned by global CSS without touching siblings. */

	protected static function remove_css_properties( $css, $property_names ) {
		if( ! is_string( $css ) || ! $property_names ) {
			return $css;
		}

		$owned = array_fill_keys( $property_names, true );
		$declarations = preg_split( '/;(?=\s*--[A-Za-z0-9_-]+\s*:|\s*$)/', $css );
		$remaining = array();
		foreach( $declarations as $declaration ) {
			$declaration = trim( $declaration );
			if( $declaration === '' ) {
				continue;
			}

			if( preg_match( '/^(--[A-Za-z0-9_-]+)\s*:/', $declaration, $match ) && isset( $owned[$match[1]] ) ) {
				continue;
			}
			$remaining[] = $declaration;
		}

		return implode( ';', $remaining );
	}

	/** Flatten generated class output into unique whitespace-delimited tokens. */

	protected static function class_name_tokens( $class_names ) {
		$values = is_array( $class_names ) ? $class_names : array( $class_names );
		$tokens = array();

		array_walk_recursive( $values, static function( $value ) use ( &$tokens ) {
			if( ! is_scalar( $value ) ) {
				return;
			}

			foreach( preg_split( '/\s+/', trim( (string) $value ) ) ?: array() as $token ) {
				if( $token !== '' ) {
					$tokens[$token] = $token;
				}
			}
		} );

		return array_values( $tokens );
	}

	/** Remove only generated class tokens owned by a global style. */

	protected static function remove_class_names( $local, $global ) {
		$local_tokens = self::class_name_tokens( $local );
		$owned_tokens = array_fill_keys( self::class_name_tokens( $global ), true );

		return implode( ' ', array_values( array_filter(
			$local_tokens,
			static fn( $token ) => ! isset( $owned_tokens[$token] )
		) ) );
	}

	/** Strip semantic and generated values now owned by a style. */

	protected static function normalize_assigned_attrs( $local, $global ) {
		$next = is_array( $local ) ? $local : array();
		foreach( self::controlled_attribute_keys() as $key ) {
			if( ! array_key_exists( $key, $global ) || ! array_key_exists( $key, $next ) ) {
				continue;
			}

			$remaining = self::remove_owned_value( $next[$key], $global[$key] );
			if( is_array( $remaining ) && $remaining ) {
				$next[$key] = $remaining;
			} else {
				unset( $next[$key] );
			}
		}

		foreach( self::state_group_keys() as $state_key ) {
			if( ! is_array( $next[$state_key] ?? null ) || ! is_array( $global[$state_key] ?? null ) ) {
				continue;
			}

			foreach( self::controlled_attribute_keys() as $key ) {
				if( ! array_key_exists( $key, $global[$state_key] ) || ! array_key_exists( $key, $next[$state_key] ) ) {
					continue;
				}
				$remaining = self::remove_owned_value( $next[$state_key][$key], $global[$state_key][$key] );
				if( is_array( $remaining ) && $remaining ) {
					$next[$state_key][$key] = $remaining;
				} else {
					unset( $next[$state_key][$key] );
				}
			}
			if( ! $next[$state_key] ) {
				unset( $next[$state_key] );
			}
		}

		foreach( array( 'styles', 'stylesLayout', 'stylesChild' ) as $css_key ) {
			$next[$css_key] = self::remove_css_properties(
				$next[$css_key] ?? '',
				self::css_property_names( $global[$css_key] ?? '' )
			);
			if( $next[$css_key] === '' ) {
				unset( $next[$css_key] );
			}
		}

		foreach( (array) ( $global['stylesBackgrounds'] ?? array() ) as $index => $global_css ) {
			if( ! isset( $next['stylesBackgrounds'][$index] ) ) {
				continue;
			}
			$next['stylesBackgrounds'][$index] = self::remove_css_properties(
				$next['stylesBackgrounds'][$index],
				self::css_property_names( $global_css )
			);
		}

		if( array_key_exists( 'classNames', $global ) && array_key_exists( 'classNames', $next ) ) {
			$next['classNames'] = self::remove_class_names(
				$next['classNames'],
				$global['classNames']
			);
			if( $next['classNames'] === '' ) {
				unset( $next['classNames'] );
			}
		}

		foreach( (array) ( $global['classNamesBackground'] ?? array() ) as $index => $global_classes ) {
			if( ! isset( $next['classNamesBackground'][$index] ) ) {
				continue;
			}
			$next['classNamesBackground'][$index] = self::remove_class_names(
				$next['classNamesBackground'][$index],
				$global_classes
			);
		}

		return $next;
	}

	/**
	 * Remove local values owned by a resolved style before runtime rendering.
	 *
	 * This is the defensive counterpart to save-time normalization. Imports,
	 * direct database writes and stale serialized content must not let a local
	 * id-scoped CSS declaration override the assigned global class selector.
	 *
	 * @param mixed $local Local WPHAVE block attributes.
	 * @param mixed $global Resolved global Block Style attributes.
	 * @return array Local attributes with only owned values removed.
	 */

	public static function strip_owned_attrs( $local, $global ) {
		return self::normalize_assigned_attrs(
			is_array( $local ) ? $local : array(),
			is_array( $global ) ? $global : array()
		);
	}

	/** Materialize the effective local and global design for a safe detach. */

	public static function detach_attrs( $wphave, $block_name = '' ) {
		// DATA INTEGRITY INVARIANT: Detaching a global style materializes the effective
		// appearance while preserving unrelated local attributes. Only values owned by
		// the style contract may be removed or replaced.
		if( ! is_array( $wphave ) ) {
			return array();
		}

		$style_id = absint( $wphave['useBlockStyle'] ?? 0 );
		if( ! $style_id || ( $block_name && ! self::is_compatible( $style_id, $block_name ) ) ) {
			unset( $wphave['useBlockStyle'] );
			return $wphave;
		}

		$global = self::get_attrs( $style_id );
		$local = self::normalize_assigned_attrs( $wphave, $global );
		$effective = self::apply_attrs( $wphave, $block_name );

		foreach( array( 'styles', 'stylesLayout', 'stylesChild' ) as $key ) {
			$parts = array_filter(
				array( $local[$key] ?? '', $global[$key] ?? '' ),
				array( self::class, 'has_value' )
			);
			if( $parts ) {
				$effective[$key] = implode( ';', $parts );
			} else {
				unset( $effective[$key] );
			}
		}

		$class_names = array_unique( array_merge(
			self::class_name_tokens( $local['classNames'] ?? '' ),
			self::class_name_tokens( $global['classNames'] ?? '' )
		) );
		if( $class_names ) {
			$effective['classNames'] = implode( ' ', $class_names );
		} else {
			unset( $effective['classNames'] );
		}

		foreach( array( 'stylesBackgrounds', 'classNamesBackground' ) as $key ) {
			$local_values = is_array( $local[$key] ?? null ) ? $local[$key] : array();
			$global_values = is_array( $global[$key] ?? null ) ? $global[$key] : array();
			$values = array();
			$count = max( count( $local_values ), count( $global_values ) );
			for( $index = 0; $index < $count; $index++ ) {
				if( $key === 'stylesBackgrounds' ) {
					$parts = array_filter(
						array( $local_values[$index] ?? '', $global_values[$index] ?? '' ),
						array( self::class, 'has_value' )
					);
					$values[$index] = implode( ';', $parts );
				} else {
					$values[$index] = implode( ' ', array_unique( array_merge(
						self::class_name_tokens( $local_values[$index] ?? '' ),
						self::class_name_tokens( $global_values[$index] ?? '' )
					) ) );
				}
			}
			if( $values ) {
				$effective[$key] = $values;
			} else {
				unset( $effective[$key] );
			}
		}

		unset( $effective['useBlockStyle'] );
		return $effective;
	}

	/** Normalize one parsed tree and report whether serialized state changed. */

	protected static function normalize_blocks_for_style( &$blocks, $style_id, $global_attrs ) {
		$changed = false;
		foreach( $blocks as &$block ) {
			$block_name = (string) ( $block['blockName'] ?? '' );
			if(
				absint( $block['attrs']['wphave']['useBlockStyle'] ?? 0 ) === $style_id &&
				self::is_compatible( $style_id, $block_name )
			) {
				$normalized = self::normalize_assigned_attrs( $block['attrs']['wphave'], $global_attrs );
				if( $normalized !== $block['attrs']['wphave'] ) {
					$block['attrs']['wphave'] = $normalized;
					$changed = true;
				}
			}

			if( ! empty( $block['innerBlocks'] ) && self::normalize_blocks_for_style( $block['innerBlocks'], $style_id, $global_attrs ) ) {
				$changed = true;
			}
		}
		unset( $block );

		return $changed;
	}

	/**
	 * Permanently discard local values whenever a style takes ownership.
	 *
	 * No shadow values are retained. Removing the property from the style later
	 * therefore reveals the normal unset/default behavior, never an old value.
	 */

	public static function normalize_style_assignments( $style_id ) {
		$style_id = absint( $style_id );
		if( ! $style_id || get_post_status( $style_id ) !== 'publish' ) {
			return;
		}

		$global_attrs = self::get_attrs( $style_id );
		$sources = self::get_usage()[$style_id]['sources'] ?? array();
		foreach( $sources as $source ) {
			$post = get_post( absint( $source['id'] ?? 0 ) );
			if(
				! self::is_usage_source( $post ) ||
				! current_user_can( 'edit_post', $post->ID )
			) {
				continue;
			}

			$blocks = parse_blocks( $post->post_content );
			if( self::normalize_blocks_for_style( $blocks, $style_id, $global_attrs ) ) {
				wp_update_post( array( 'ID' => $post->ID, 'post_content' => wp_slash( serialize_blocks( $blocks ) ) ) );
			}
		}

		self::refresh_usage_sources( $sources );
	}

	/** Refresh known source contributions after style compatibility changes. */

	protected static function refresh_usage_sources( $sources ) {
		if( ! is_array( $sources ) || ! $sources ) {
			return;
		}

		$lock_token = self::acquire_usage_lock();
		if( ! $lock_token ) {
			delete_option( self::USAGE_OPTION_KEY );
			return;
		}

		try {
			$index = get_option( self::USAGE_OPTION_KEY, null );
			if( ! is_array( $index ) || ( $index['version'] ?? 0 ) !== self::contract()['version'] ) {
				return;
			}

			foreach( $sources as $source ) {
				$post = get_post( absint( $source['id'] ?? 0 ) );
				if( ! $post instanceof WP_Post ) {
					continue;
				}

				$key = $post->post_type . ':' . $post->ID;
				$contribution = self::source_usage( $post );
				if( $contribution ) {
					$index['sources'][$key] = $contribution;
				} else {
					unset( $index['sources'][$key] );
				}
			}

			if( self::refresh_usage_lock( $lock_token ) ) {
				self::persist_usage_index( $index['sources'] );
			} else {
				delete_option( self::USAGE_OPTION_KEY );
			}
		} finally {
			self::release_usage_lock( $lock_token );
		}
	}

	}

endif;
