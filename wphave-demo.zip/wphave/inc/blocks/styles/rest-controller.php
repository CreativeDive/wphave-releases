<?php

/**
 * REST boundary for global Block Style usage and assignment workflows.
 */

class WPHAVE_Block_Styles_REST_Controller {

	/** Register Block Style workspace routes. */

	public static function register_routes() {
		register_rest_route( 'wphave/v1', '/block-styles/usage', array(
			'methods' => WP_REST_Server::READABLE,
			'callback' => array( __CLASS__, 'usage' ),
			'permission_callback' => array( __CLASS__, 'permissions' ),
		) );

		register_rest_route( 'wphave/v1', '/block-styles/usage/rebuild', array(
			'methods' => WP_REST_Server::CREATABLE,
			'callback' => array( __CLASS__, 'rebuild_usage' ),
			'permission_callback' => array( __CLASS__, 'permissions' ),
		) );

		register_rest_route( 'wphave/v1', '/block-styles/repair', array(
			'methods' => WP_REST_Server::CREATABLE,
			'callback' => array( __CLASS__, 'repair_assignments' ),
			'permission_callback' => array( __CLASS__, 'permissions' ),
			'args' => array(
				'styleId' => array( 'required' => true, 'sanitize_callback' => 'absint' ),
				'mode' => array(
					'required' => true,
					'validate_callback' => static function( $value ) {
						return in_array( $value, array( 'detach', 'replace' ), true );
					},
				),
				'replacementId' => array( 'sanitize_callback' => 'absint', 'default' => 0 ),
			),
		) );
	}

	/** Return the current derived usage projection. */

	public static function usage() {
		// AUTHORIZATION INVARIANT: Global Block Style usage is feature-private metadata; executable callbacks repeat the feature capability before reading the derived index.
		if ( ! self::permissions() ) {
			return self::forbidden();
		}

		return rest_ensure_response(
			self::filter_visible_sources( WPHAVE_Block_Styles::get_usage() )
		);
	}

	/** Rebuild usage from canonical serialized block content. */

	public static function rebuild_usage() {
		// AUTHORIZATION INVARIANT: Rebuilding usage writes shared derived state and must authorize before acquiring locks, scanning content or changing the index.
		if ( ! self::permissions() ) {
			return self::forbidden();
		}

		$index = WPHAVE_Block_Styles::rebuild_usage_index();
		if(
			get_option( WPHAVE_Block_Styles::USAGE_LOCK_OPTION_KEY, false ) ||
			! isset( $index['usage'], $index['updatedAt'], $index['sources'] )
		) {
			return new WP_Error(
				'wphave_block_style_usage_busy',
				__( 'Block Style usage is currently being updated. Try again shortly.', 'wphave' ),
				array( 'status' => 409 )
			);
		}

		return rest_ensure_response( array(
			'usage' => self::filter_visible_sources( $index['usage'] ),
			'updatedAt' => $index['updatedAt'],
			'sourceCount' => count( $index['sources'] ),
		) );
	}

	/** Validate transport input and run a domain-level assignment repair. */

	public static function repair_assignments( $request ) {
		// AUTHORIZATION INVARIANT: Per-document edit checks narrow a repair after global Block Style authority; they never replace the feature capability at entry.
		if ( ! self::permissions() ) {
			return self::forbidden();
		}

		$result = WPHAVE_Block_Styles::repair_assignments(
			absint( $request['styleId'] ),
			(string) $request['mode'],
			absint( $request['replacementId'] )
		);

		return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
	}

	/** Require the dedicated feature capability for every route. */

	public static function permissions() {
		return current_user_can( WPHAVE_Block_Styles::CAPABILITY );
	}

	/** Return the stable denial shared by final Block Style callbacks. */

	protected static function forbidden() {
		return new WP_Error(
			'wphave_block_styles_forbidden',
			__( 'You are not allowed to manage Block Styles.', 'wphave' ),
			array( 'status' => 403 )
		);
	}

	/** Hide source identities the current user cannot read. */

	protected static function filter_visible_sources( $usage ) {
		// PRIVACY INVARIANT: A Block Style capability exposes aggregate usage, not the
		// identity of documents the caller cannot read. Source IDs cross the REST
		// boundary only after an exact read_post check.
		$usage = is_array( $usage ) ? $usage : array();

		foreach( $usage as &$item ) {
			$sources = is_array( $item['sources'] ?? null ) ? $item['sources'] : array();
			$visible_sources = array_values( array_filter(
				$sources,
				static function( $source ) {
					$source_id = absint( $source['id'] ?? 0 );
					return $source_id && current_user_can( 'read_post', $source_id );
				}
			) );

			$item['sources'] = $visible_sources;
			$item['hiddenSourceCount'] = count( $sources ) - count( $visible_sources );
		}
		unset( $item );

		return $usage;
	}
}
