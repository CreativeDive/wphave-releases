<?php

/**
 * WPHAVE Block Styles Registry Contract domain implementation.
 *
 * @internal Composed by WPHAVE_Block_Styles to preserve its public API.
 */

if ( ! trait_exists( 'WPHAVE_Block_Styles_Registry_Contract' ) ) :

	trait WPHAVE_Block_Styles_Registry_Contract {

	/**
	 * Return the generated contract shared with the editor runtime.
	 *
	 * @return array
	 */

	public static function contract() {
		if( self::$contract === null ) {
			self::$contract = require wphave_dir() . 'inc/generated/block-style-contract.php';
		}

		return self::$contract;
	}

	/**
	 * Registers the hidden post type used to store global block styles.
	 *
	 * @return void
	 */

	public static function register_post_type() {

		/*
		* Reusable block styles belong to WPHAVE blocks rather than the active
		* theme and must remain available in compatibility mode.
		*/

		register_post_type( self::POST_TYPE,
			array(
				'label' => __( 'Styles', 'wphave' ),
				'description' => __( 'Create multiple block styles and reuse them in your blocks.', 'wphave' ),
				'menu_icon' => 'data:image/svg+xml;base64,' . base64_encode( wphave_svg_ui_icon( 'grid' ) ),
				'menu_position' => 46,
				'supports' => array(
					'title',
					'editor',
				),
				'public' => false,
				'show_ui' => true,
				'capabilities' => self::capabilities(),
				'map_meta_cap' => false,
				'rewrite' => false,
				'show_in_menu' => false,
				'show_in_rest' => true,
				'has_archive' => false,
				'exclude_from_search' => true,
				'show_in_nav_menus' => false,
				'show_in_admin_bar' => false,
				'publicly_queryable' => false,
				'query_var' => false,
			)
		);

	}

	/**
	 * Use the feature capability for every stored Block Style operation.
	 *
	 * @return array<string,string> Post type capability map.
	 */

	public static function capabilities() {
		// AUTHORIZATION INVARIANT: Hidden Block Style posts expose no generic post
		// capability fallback. Core CRUD, revisions and WPHAVE routes all resolve to
		// the same dedicated feature capability.
		return array(
			'edit_post' => self::CAPABILITY,
			'read_post' => self::CAPABILITY,
			'delete_post' => self::CAPABILITY,
			'edit_posts' => self::CAPABILITY,
			'edit_others_posts' => self::CAPABILITY,
			'delete_posts' => self::CAPABILITY,
			'delete_others_posts' => self::CAPABILITY,
			'publish_posts' => self::CAPABILITY,
			'read_private_posts' => self::CAPABILITY,
			'create_posts' => self::CAPABILITY,
		);
	}

	/**
	 * Returns all reusable block style attributes indexed by post id.
	 *
	 * @return array<int,array> Block style attributes indexed by style post id.
	 */

	public static function get_styles() {

		$block_styles = get_posts( array(
			'post_type' => self::POST_TYPE,
			'numberposts' => -1,
			'post_status' => 'publish',
			'suppress_filters' => false,
			'cache_results'	=> true,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
		) );

		$styles = array();

		foreach( $block_styles as $block_style ) {
			$post_id = absint( $block_style->ID ?? 0 );

			if( $post_id ) {
				$styles[$post_id] = self::get_attrs( $post_id );
			}
		}

		return $styles;

	}

	/**
	 * Returns the CSS class used by a block assigned to a global style.
	 *
	 * @param int|string $style_id Global block style post id.
	 * @return string CSS class name or an empty string.
	 */

	public static function style_class( $style_id ) {

		$style_id = absint( $style_id );

		return $style_id ? 'wph-gbs-' . $style_id : '';

	}

	/**
	 * Returns all attribute keys that are copied from a global style.
	 *
	 * @return string[] Attribute keys controlled by global block styles.
	 */

	public static function style_keys() {
		$contract = self::contract();
		return array_merge( $contract['inheritedGroups'], $contract['generatedKeys'] );

	}

	/**
	 * Returns the attribute groups that require matching block support.
	 *
	 * @return string[] Attribute group keys checked against block supports.
	 */

	public static function controlled_attribute_keys() {
		return self::contract()['inheritedGroups'];

	}

	/**
	 * Returns responsive and interaction states controlled by Block Styles.
	 *
	 * @return string[] State group keys.
	 */

	public static function state_group_keys() {
		return array_values( array_filter( self::contract()['states'] ) );

	}

	/**
	 * Loads the attributes stored inside a global block style post.
	 *
	 * @param int|string $style_id Global block style post id.
	 * @return array Global block style attributes.
	 */

	public static function get_attrs( $style_id ) {

		$style_id = absint( $style_id );

		if( ! $style_id ) {
			return array();
		}

		if( array_key_exists( $style_id, self::$attrs_cache ) ) {
			return self::$attrs_cache[$style_id];
		}

		$post = get_post( $style_id );

		if(
			! $post ||
			$post->post_type !== self::POST_TYPE ||
			$post->post_status !== 'publish'
		) {
			self::$attrs_cache[$style_id] = array();
			return self::$attrs_cache[$style_id];
		}

		$attrs = WPHAVE_Block_Inspector::block_data( 'wphave/style', false, $post->post_content );
		self::$attrs_cache[$style_id] = is_array( $attrs ) ? $attrs : array();

		return self::$attrs_cache[$style_id];

	}

	/**
	 * Return whether an id identifies an assignable, published Block Style.
	 *
	 * Attribute data may legitimately be empty while a new style is being
	 * authored, so publication state must not be inferred from truthiness.
	 *
	 * @param int|string $style_id Global block style post id.
	 * @return bool
	 */

	public static function is_published_style( $style_id ) {
		$post = get_post( absint( $style_id ) );

		return $post instanceof WP_Post &&
			$post->post_type === self::POST_TYPE &&
			$post->post_status === 'publish';
	}

	/**
	 * Checks whether a style attribute group contains meaningful data.
	 *
	 * @param array $attrs Global block style attributes.
	 * @param string $key Attribute group key.
	 * @return bool True when the group is present and non-empty.
	 */

	public static function uses_attribute_group( $attrs, $key ) {

		if( ! is_array( $attrs ) || ! array_key_exists( $key, $attrs ) ) {
			return false;
		}

		return self::has_value( $attrs[$key] );

	}

	/**
	 * Recursively checks whether a style value contains meaningful data.
	 *
	 * @param mixed $value Value to inspect.
	 * @return bool True when meaningful data exists.
	 */

	public static function has_value( $value ) {

		if( is_array( $value ) ) {
			foreach( $value as $child ) {
				if( self::has_value( $child ) ) {
					return true;
				}
			}

			return false;
		}

		return $value !== null && $value !== '';

	}

	/**
	 * Merge an owned style shape without removing unrelated local siblings.
	 *
	 * Lists and scalar values are atomic. Associative arrays are merged
	 * recursively, matching the editor runtime's ownership semantics.
	 *
	 * @param mixed $target Existing local value.
	 * @param mixed $source Global style value.
	 * @return mixed
	 */

	public static function merge_style_value( $target, $source ) {
		if( ! self::has_value( $source ) ) {
			return $target;
		}

		if( ! is_array( $source ) || array_is_list( $source ) ) {
			return $source;
		}

		$next = is_array( $target ) && ! array_is_list( $target ) ? $target : array();
		foreach( $source as $key => $value ) {
			$next[$key] = self::merge_style_value( $next[$key] ?? null, $value );
		}

		return $next;
	}

	/**
	 * Recursively validate style values against registered block supports.
	 *
	 * @param mixed $value Style value.
	 * @param mixed $support Corresponding support definition.
	 * @param string[]|null $allowed_paths Paths available in the active state.
	 * @param string $path Current attribute path.
	 * @return bool
	 */

	public static function is_value_supported( $value, $support, $allowed_paths = null, $path = '' ) {
		if( ! self::has_value( $value ) ) {
			return true;
		}

		$allowed_paths = is_array( $allowed_paths ) ? $allowed_paths : self::contract()['stateAllowedPaths']['Desktop'];
		if( ! self::is_style_path_allowed( $path, $allowed_paths ) ) {
			return false;
		}

		if( $support === true ) {
			if( ! is_array( $value ) || array_is_list( $value ) ) {
				return true;
			}

			foreach( $value as $key => $child ) {
				$child_path = $path ? $path . '.' . $key : $key;
				if( ! self::is_value_supported( $child, true, $allowed_paths, $child_path ) ) {
					return false;
				}
			}

			return true;
		}

		if( ! is_array( $support ) ) {
			return false;
		}

		if( is_array( $value ) && array_is_list( $value ) ) {
			foreach( $value as $item ) {
				if( ! is_array( $item ) ) {
					continue;
				}

				if( isset( $item['type'] ) && empty( $support[$item['type']] ) ) {
					return false;
				}

				if( ! isset( $item['type'] ) && ! self::is_value_supported( $item, $support, $allowed_paths, $path ) ) {
					return false;
				}
			}

			return true;
		}

		if( ! is_array( $value ) ) {
			return false;
		}

		$aliases = self::contract()['supportKeyAliases'];
		foreach( $value as $key => $child ) {
			$support_key = $aliases[$key] ?? $key;
			$child_path = $path ? $path . '.' . $key : $key;
			if( ! self::is_value_supported( $child, $support[$support_key] ?? false, $allowed_paths, $child_path ) ) {
				return false;
			}
		}

		return true;
	}

	/** Return whether a path is available in the active Block Style state. */

	protected static function is_style_path_allowed( $path, $allowed_paths ) {
		if( in_array( '*', $allowed_paths, true ) ) {
			return true;
		}

		foreach( $allowed_paths as $allowed_path ) {
			if(
				$allowed_path === $path ||
				str_starts_with( $allowed_path, $path . '.' ) ||
				str_starts_with( $path, $allowed_path . '.' )
			) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Checks whether a global style can be applied to a block type.
	 *
	 * @param int|string $style_id Global block style post id.
	 * @param string $block_name Full block name, e.g. "wphave/group".
	 * @return bool True when the block supports all used style groups.
	 */

	public static function is_compatible( $style_id, $block_name ) {

		$style_id = absint( $style_id );

		if( ! $style_id || ! $block_name ) {
			return false;
		}

		$cache_key = $style_id . ':' . $block_name;
		if( array_key_exists( $cache_key, self::$compatibility_cache ) ) {
			return self::$compatibility_cache[$cache_key];
		}

		if( ! self::is_published_style( $style_id ) ) {
			self::$compatibility_cache[$cache_key] = false;
			return self::$compatibility_cache[$cache_key];
		}

		$attrs = self::get_attrs( $style_id );

		$supports = WPHAVE_Block_Inspector::block_type_support( $block_name );
		$wphave_supports = $supports['wphave'] ?? array();
		self::$compatibility_cache[$cache_key] = self::are_attrs_compatible_with_supports( $attrs, $wphave_supports );
		return self::$compatibility_cache[$cache_key];
	}

	/**
	 * Validate attributes against an explicit support tree.
	 *
	 * This public seam is shared by parity fixtures and avoids requiring a
	 * registered block when testing the cross-runtime contract.
	 *
	 * @param array $attrs Style attributes.
	 * @param array $wphave_supports WPHAVE block support tree.
	 * @return bool
	 */

	public static function are_attrs_compatible_with_supports( $attrs, $wphave_supports ) {
		$allowed_paths_by_state = self::contract()['stateAllowedPaths'];

		foreach( self::controlled_attribute_keys() as $key ) {
			if( ! self::is_value_supported( $attrs[$key] ?? null, $wphave_supports[$key] ?? false, $allowed_paths_by_state['Desktop'], $key ) ) {
				return false;
			}
		}

		foreach( self::contract()['states'] as $state_type => $state_key ) {
			if( ! $state_key ) {
				continue;
			}

			$state_attrs = $attrs[$state_key] ?? array();

			foreach( self::controlled_attribute_keys() as $key ) {
				if( ! self::is_value_supported( $state_attrs[$key] ?? null, $wphave_supports[$key] ?? false, $allowed_paths_by_state[$state_type], $key ) ) {
					return false;
				}
			}
		}

		return true;
	}

	}

endif;
