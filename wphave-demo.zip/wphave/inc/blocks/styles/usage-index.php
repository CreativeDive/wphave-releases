<?php

/**
 * WPHAVE Block Styles Usage Index domain implementation.
 *
 * @internal Composed by WPHAVE_Block_Styles to preserve its public API.
 */

if ( ! trait_exists( 'WPHAVE_Block_Styles_Usage_Index' ) ) :

	trait WPHAVE_Block_Styles_Usage_Index {

	/**
	 * Collects compatible global style ids from a parsed block tree.
	 *
	 * @param array $blocks Parsed block array.
	 * @param array $style_ids Existing style id map.
	 * @return array<int,int> Style ids indexed by id.
	 */

	public static function collect_ids_from_blocks( $blocks, $style_ids = array() ) {

		if( ! is_array( $blocks ) ) {
			return $style_ids;
		}

		foreach( $blocks as $block ) {
			if( ! is_array( $block ) ) {
				continue;
			}

			$style_id = absint( $block['attrs']['wphave']['useBlockStyle'] ?? 0 );
			$block_name = $block['blockName'] ?? '';

			if( $style_id && self::is_compatible( $style_id, $block_name ) ) {
				$style_ids[$style_id] = $style_id;
			}

			if( ! empty( $block['innerBlocks'] ) ) {
				$style_ids = self::collect_ids_from_blocks( $block['innerBlocks'], $style_ids );
			}
		}

		return $style_ids;

	}

	/**
	 * Collects compatible global style ids from serialized block content.
	 *
	 * @param string $content Serialized block content.
	 * @return int[] Global block style ids used by the content.
	 */

	public static function collect_ids( $content ) {

		if( ! is_string( $content ) || $content === '' ) {
			return array();
		}

		$blocks = parse_blocks( $content );
		$style_ids = self::collect_ids_from_blocks( $blocks );

		return array_values( $style_ids );

	}

	/**
	 * Collects usage metadata for global style ids in a parsed block tree.
	 *
	 * @param array $blocks Parsed block array.
	 * @param array $source Optional source metadata for the block content.
	 * @param array $usage Existing usage map.
	 * @return array Usage data indexed by global block style id.
	 */

	public static function collect_usage_from_blocks( $blocks, $source = array(), $usage = array() ) {

		if( ! is_array( $blocks ) ) {
			return $usage;
		}

		foreach( $blocks as $block ) {
			if( ! is_array( $block ) ) {
				continue;
			}

			$style_id = absint( $block['attrs']['wphave']['useBlockStyle'] ?? 0 );
			$block_name = $block['blockName'] ?? '';

			if( $style_id ) {
				if( ! isset( $usage[$style_id] ) ) {
					$usage[$style_id] = array(
						'count' => 0,
						'compatibleCount' => 0,
						'incompatibleCount' => 0,
						'sources' => array(),
						'blockTypes' => array(),
					);
				}

				$is_compatible = self::is_compatible( $style_id, $block_name );

				$usage[$style_id]['count']++;
				$usage[$style_id][$is_compatible ? 'compatibleCount' : 'incompatibleCount']++;

				if( $block_name ) {
					$usage[$style_id]['blockTypes'][$block_name] = $block_name;
				}

				$source_key = ! empty( $source['id'] ) ? ( $source['type'] ?? 'post' ) . ':' . $source['id'] : '';

				if( $source_key && ! isset( $usage[$style_id]['sources'][$source_key] ) ) {
					$usage[$style_id]['sources'][$source_key] = $source;
				}
			}

			if( ! empty( $block['innerBlocks'] ) ) {
				$usage = self::collect_usage_from_blocks( $block['innerBlocks'], $source, $usage );
			}
		}

		return $usage;

	}

	/**
	 * Scans editable content sources and returns global block style usage.
	 *
	 * @return array Usage data indexed by global block style id.
	 */

	public static function get_usage() {
		$index = get_option( self::USAGE_OPTION_KEY, null );

		if( ! is_array( $index ) || ( $index['version'] ?? 0 ) !== self::contract()['version'] ) {
			$index = self::rebuild_usage_index();
		}

		return is_array( $index['usage'] ?? null ) ? $index['usage'] : array();
	}

	/**
	 * Return whether a post is an editable Block Style reference source.
	 *
	 * @param WP_Post $post Post to inspect.
	 * @return bool
	 */

	protected static function is_usage_source( $post ) {
		if( ! $post instanceof WP_Post ) {
			return false;
		}

		if( in_array( $post->post_type, array( 'attachment', 'revision', self::POST_TYPE ), true ) ) {
			return false;
		}

		return in_array( $post->post_status, array( 'publish', 'draft', 'private', 'pending', 'future' ), true );
	}

	/**
	 * Build one source contribution without touching persistent state.
	 *
	 * @param WP_Post $post Source post.
	 * @return array|null
	 */

	protected static function source_usage( $post ) {
		if( ! self::is_usage_source( $post ) || ! str_contains( (string) $post->post_content, 'useBlockStyle' ) ) {
			return null;
		}

		$source = array(
			'id' => $post->ID,
			'type' => $post->post_type,
			'title' => get_the_title( $post ),
			'status' => $post->post_status,
		);
		$usage = self::collect_usage_from_blocks( parse_blocks( $post->post_content ), $source );

		return $usage ? array(
			'signature' => md5( $post->post_content . '|' . $post->post_status . '|' . $post->post_title ),
			'usage' => $usage,
		) : null;
	}

	/**
	 * Aggregate independently replaceable source contributions.
	 *
	 * @param array $sources Indexed source contributions.
	 * @return array
	 */

	protected static function aggregate_usage_sources( $sources ) {
		$usage = array();

		foreach( $sources as $contribution ) {
			foreach( (array) ( $contribution['usage'] ?? array() ) as $style_id => $data ) {
				if( ! isset( $usage[$style_id] ) ) {
					$usage[$style_id] = array(
						'count' => 0,
						'compatibleCount' => 0,
						'incompatibleCount' => 0,
						'sources' => array(),
						'blockTypes' => array(),
					);
				}

				$usage[$style_id]['count'] += absint( $data['count'] ?? 0 );
				$usage[$style_id]['compatibleCount'] += absint( $data['compatibleCount'] ?? 0 );
				$usage[$style_id]['incompatibleCount'] += absint( $data['incompatibleCount'] ?? 0 );
				foreach( (array) ( $data['sources'] ?? array() ) as $source_key => $source ) {
					$usage[$style_id]['sources'][$source_key] = $source;
				}
				foreach( (array) ( $data['blockTypes'] ?? array() ) as $block_name ) {
					$usage[$style_id]['blockTypes'][$block_name] = $block_name;
				}
			}
		}

		foreach( $usage as $style_id => $data ) {
			$usage[$style_id]['sources'] = array_values( $data['sources'] );
			$usage[$style_id]['blockTypes'] = array_values( $data['blockTypes'] );
		}

		return $usage;
	}

	/**
	 * Persist a complete usage index atomically through the options API.
	 *
	 * @param array $sources Source contributions.
	 * @return array
	 */

	protected static function persist_usage_index( $sources ) {
		$index = array(
			'version' => self::contract()['version'],
			'updatedAt' => gmdate( 'c' ),
			'sources' => $sources,
			'usage' => self::aggregate_usage_sources( $sources ),
		);

		update_option( self::USAGE_OPTION_KEY, $index, false );
		return $index;
	}

	/** Acquire an atomic, short-lived cross-request index mutation lease. */

	protected static function acquire_usage_lock() {
		return WPHAVE_Background_Job_Lock::acquire(
			self::USAGE_LOCK_OPTION_KEY,
			self::USAGE_LOCK_TTL
		);
	}

	/** Renew only the usage-index lease owned by the supplied token. */

	protected static function refresh_usage_lock( $token ) {
		return WPHAVE_Background_Job_Lock::refresh(
			self::USAGE_LOCK_OPTION_KEY,
			(string) $token
		);
	}

	/** Release only the usage-index lease owned by the supplied token. */

	protected static function release_usage_lock( $token ) {
		// CONCURRENCY INVARIANT: An expired worker must never release a newer
		// owner's lease after that worker recovered the same option name.
		return WPHAVE_Background_Job_Lock::release(
			self::USAGE_LOCK_OPTION_KEY,
			(string) $token
		);
	}

	/**
	 * Rebuild the derived index from canonical serialized content.
	 *
	 * @return array
	 */

	public static function rebuild_usage_index() {
		$lock_token = self::acquire_usage_lock();
		if( ! $lock_token ) {
			$existing = get_option( self::USAGE_OPTION_KEY, array() );
			return is_array( $existing ) ? $existing : array();
		}

		try {
			$ui_post_types = get_post_types( array( 'show_ui' => true ), 'names' );
			$rest_post_types = get_post_types( array( 'show_in_rest' => true ), 'names' );
			$post_types = array_unique( array_merge(
				array_values( $ui_post_types ),
				array_values( $rest_post_types ),
				array(
				'page',
				'post',
				'wp_block',
				'wp_navigation',
				'wp_template',
				'wp_template_part',
				'wphave-templates',
				'wphave-template-part',
				'wphave-add-ons',
				'wphave-forms',
				'wphave-navigations',
				)
			) );

			$post_types = array_values( array_diff( $post_types, array(
				'attachment',
				self::POST_TYPE,
			) ) );

			$sources = array();
			$page = 1;

			do {
				$posts = get_posts( array(
					'post_type' => $post_types,
					'posts_per_page' => self::USAGE_REBUILD_BATCH_SIZE,
					'paged' => $page,
					'orderby' => 'ID',
					'order' => 'ASC',
					'post_status' => array( 'publish', 'draft', 'private', 'pending', 'future' ),
					'suppress_filters' => false,
					'cache_results' => false,
					'update_post_meta_cache' => false,
					'update_post_term_cache' => false,
				) );

				foreach( $posts as $post ) {
					$contribution = self::source_usage( $post );
					if( $contribution ) {
						$sources[$post->post_type . ':' . $post->ID] = $contribution;
					}
				}

				// CONCURRENCY INVARIANT: A worker that lost its lease may not
				// publish a partial or stale usage snapshot.
				if( ! self::refresh_usage_lock( $lock_token ) ) {
					$existing = get_option( self::USAGE_OPTION_KEY, array() );
					return is_array( $existing ) ? $existing : array();
				}

				$page++;
			} while( count( $posts ) === self::USAGE_REBUILD_BATCH_SIZE );

			return self::persist_usage_index( $sources );
		} finally {
			self::release_usage_lock( $lock_token );
		}
	}

	/** Update only the contribution owned by a saved post. */

	public static function update_usage_for_saved_post( $post_id, $post, $update ) {
		if( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) || $post->post_type === self::POST_TYPE ) {
			return;
		}

		$lock_token = self::acquire_usage_lock();
		if( ! $lock_token ) {
			delete_option( self::USAGE_OPTION_KEY );
			return;
		}

		$index = get_option( self::USAGE_OPTION_KEY, null );
		if( ! is_array( $index ) || ( $index['version'] ?? 0 ) !== self::contract()['version'] ) {
			self::release_usage_lock( $lock_token );
			return;
		}

		$key = $post->post_type . ':' . $post_id;
		$contribution = self::source_usage( $post );
		if( $contribution ) {
			$index['sources'][$key] = $contribution;
			update_post_meta( $post_id, self::SOURCE_USAGE_META_KEY, array_map( 'absint', array_keys( $contribution['usage'] ) ) );
		} else {
			unset( $index['sources'][$key] );
			delete_post_meta( $post_id, self::SOURCE_USAGE_META_KEY );
		}

		if( self::refresh_usage_lock( $lock_token ) ) {
			self::persist_usage_index( $index['sources'] );
		} else {
			delete_option( self::USAGE_OPTION_KEY );
		}
		self::release_usage_lock( $lock_token );
	}

	/** Remove a deleted post contribution. */

	public static function remove_usage_for_deleted_post( $post_id, $post ) {
		self::remove_usage_source( $post_id, $post );
	}

	/** Remove a trashed post contribution. */

	public static function remove_usage_for_trashed_post( $post_id, $previous_status ) {
		self::remove_usage_source( $post_id, get_post( $post_id ) );
	}

	/** Remove one source from an existing index. */

	protected static function remove_usage_source( $post_id, $post ) {
		if( ! $post instanceof WP_Post || $post->post_type === self::POST_TYPE ) {
			return;
		}

		$lock_token = self::acquire_usage_lock();
		if( ! $lock_token ) {
			delete_option( self::USAGE_OPTION_KEY );
			return;
		}

		$index = get_option( self::USAGE_OPTION_KEY, null );
		$key = $post->post_type . ':' . absint( $post_id );
		if( is_array( $index ) && isset( $index['sources'][$key] ) ) {
			unset( $index['sources'][$key] );
			if( self::refresh_usage_lock( $lock_token ) ) {
				self::persist_usage_index( $index['sources'] );
			} else {
				delete_option( self::USAGE_OPTION_KEY );
			}
		}
		self::release_usage_lock( $lock_token );
	}

	/**
	 * Checks whether a style is assigned to at least one block.
	 *
	 * @param int|string $style_id Global block style post id.
	 * @return bool True when the style is in use.
	 */

	public static function is_in_use( $style_id ) {

		$style_id = absint( $style_id );

		if( ! $style_id ) {
			return false;
		}

		$usage = self::get_usage();
		if( empty( $usage[$style_id]['count'] ) ) {
			// Destructive operations are rare and must fail closed even when an
			// importer bypassed save hooks or the derived projection is stale.
			$index = self::rebuild_usage_index();
			$usage = $index['usage'] ?? array();
			if( get_option( self::USAGE_LOCK_OPTION_KEY, false ) ) {
				return true;
			}
		}

		return ! empty( $usage[$style_id]['count'] );

	}

	/**
	 * Prevents permanent deletion while a style is assigned.
	 *
	 * @param mixed $delete Existing short-circuit value.
	 * @param WP_Post $post Post being deleted.
	 * @param bool $force_delete Whether deletion is permanent.
	 * @return mixed Short-circuit value.
	 */

	public static function prevent_deleting_used_style( $delete, $post, $force_delete ) {

		// SECURITY INVARIANT: A referenced global style remains published and
		// undeletable so existing blocks never resolve to missing design state.
		if( $post instanceof WP_Post && $post->post_type === self::POST_TYPE && self::is_in_use( $post->ID ) ) {
			return false;
		}

		return $delete;

	}

	/**
	 * Prevents moving an assigned style to the trash.
	 *
	 * @param mixed $trash Existing short-circuit value.
	 * @param WP_Post $post Post being trashed.
	 * @return mixed Short-circuit value.
	 */

	public static function prevent_trashing_used_style( $trash, $post ) {

		if( $post instanceof WP_Post && $post->post_type === self::POST_TYPE && self::is_in_use( $post->ID ) ) {
			return false;
		}

		return $trash;

	}

	/**
	 * Keeps an assigned style published so existing blocks never lose it.
	 *
	 * @param array $data Sanitized post data.
	 * @param array $postarr Raw post data.
	 * @return array Filtered post data.
	 */

	public static function keep_used_style_published( $data, $postarr ) {

		$post_id = absint( $postarr['ID'] ?? 0 );

		if(
			$post_id &&
			( $data['post_type'] ?? '' ) === self::POST_TYPE &&
			( $data['post_status'] ?? '' ) !== 'publish' &&
			get_post_status( $post_id ) === 'publish' &&
			self::is_in_use( $post_id )
		) {
			$data['post_status'] = 'publish';
		}

		return $data;

	}

	}

endif;
