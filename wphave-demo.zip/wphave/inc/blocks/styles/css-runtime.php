<?php

/**
 * WPHAVE Block Styles CSS Runtime domain implementation.
 *
 * @internal Composed by WPHAVE_Block_Styles to preserve its public API.
 */

if (!trait_exists('WPHAVE_Block_Styles_CSS_Runtime')):
	trait WPHAVE_Block_Styles_CSS_Runtime {
		/**
		 * Compiles and caches the CSS output for one global block style.
		 *
		 * @param int|string $style_id Global block style post id.
		 * @return string Compiled CSS, or an empty string.
		 */

		public static function compile_css($style_id) {
			// CACHE INVARIANT: CSS post meta is derived solely from the current style
			// attributes and compiler version; it is never an independent source of truth.

			$style_id = absint($style_id);

			if (!$style_id) {
				return '';
			}

			$attrs = self::get_attrs($style_id);

			if (!$attrs) {
				return '';
			}

			$hash = md5('v6|' . wp_json_encode($attrs));
			$cached_hash = get_post_meta($style_id, self::CSS_HASH_META_KEY, true);
			$cached_css = get_post_meta($style_id, self::CSS_META_KEY, true);

			if ($cached_hash === $hash && metadata_exists('post', $style_id, self::CSS_META_KEY)) {
				return $cached_css;
			}

			$selector = '.wph-b.' . self::style_class($style_id);

			$css_general = $attrs['styles'] ?? '';
			$css_layout = $attrs['stylesLayout'] ?? '';
			$css_child = $attrs['stylesChild'] ?? '';
			$css_backgrounds = $attrs['stylesBackgrounds'] ?? [];

			$styles = '';
			$styles .= $css_general
				? WPHAVE_CSS_Compiler::scope_source($css_general, $selector)
				: '';
			$styles .= $css_layout
				? WPHAVE_CSS_Compiler::scope_layout_source($css_layout, $selector . ' > .ly-con')
				: '';
			$styles .= $css_child
				? WPHAVE_CSS_Compiler::scope_source($css_child, $selector . ' > *')
				: '';

			if (is_array($css_backgrounds)) {
				foreach ($css_backgrounds as $index => $layer_css) {
					$styles .= $layer_css
						? WPHAVE_CSS_Compiler::scope_source(
							$layer_css,
							$selector . ' > .bgly-' . absint($index),
						)
						: '';
				}
			}

			update_post_meta($style_id, self::CSS_HASH_META_KEY, $hash);
			update_post_meta($style_id, self::CSS_META_KEY, $styles);

			return $styles;
		}

		/**
		 * Compiles CSS for a list of global block style ids.
		 *
		 * @param array $style_ids Global block style post ids.
		 * @return string Combined CSS output.
		 */

		public static function compile_used_css($style_ids) {
			if (!is_array($style_ids) || !$style_ids) {
				return '';
			}

			$style_ids = array_unique(array_filter(array_map('absint', $style_ids)));
			$styles = '';

			foreach ($style_ids as $style_id) {
				$styles .= self::compile_css($style_id);
			}

			return $styles;
		}

		/** Queue one compiled style at most once per request in every render mode. */

		public static function enqueue_style_css($style_id) {
			$style_id = absint($style_id);
			if (!$style_id || isset(self::$queued_css_ids[$style_id])) {
				return;
			}

			self::$queued_css_ids[$style_id] = true;
			$css = self::compile_css($style_id);
			if ($css) {
				WPHAVE_Style_Engine::instance()->print_inline_styles($css);
			}
		}

		/**
		 * Enqueues compiled CSS for global styles used in serialized content.
		 *
		 * @param string $content Serialized block content.
		 * @return void
		 */

		public static function enqueue_used_css($content) {
			$style_ids = self::collect_ids($content);

			if (!$style_ids) {
				return;
			}

			$styles = self::compile_used_css($style_ids);

			if ($styles) {
				WPHAVE_Style_Engine::instance()->add($styles);
			}
		}

		/**
		 * Clears and refreshes the compiled CSS cache for one style post.
		 *
		 * @param int|string $post_id Saved global block style post id.
		 * @return void
		 */

		public static function refresh_css_cache($post_id) {
			$post_id = absint($post_id);

			if (!$post_id || get_post_type($post_id) !== self::POST_TYPE) {
				return;
			}

			unset(self::$attrs_cache[$post_id]);
			unset(self::$queued_css_ids[$post_id]);
			foreach (array_keys(self::$compatibility_cache) as $cache_key) {
				if (str_starts_with($cache_key, $post_id . ':')) {
					unset(self::$compatibility_cache[$cache_key]);
				}
			}

			delete_post_meta($post_id, self::CSS_HASH_META_KEY);
			delete_post_meta($post_id, self::CSS_META_KEY);

			if (get_post_status($post_id) === 'publish') {
				self::compile_css($post_id);
			}
		}
	}
endif;
