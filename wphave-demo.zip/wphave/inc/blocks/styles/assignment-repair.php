<?php

/**
 * WPHAVE Block Styles Assignment Repair domain implementation.
 *
 * @internal Composed by WPHAVE_Block_Styles to preserve its public API.
 */

if ( ! trait_exists( 'WPHAVE_Block_Styles_Assignment_Repair' ) ) :

	trait WPHAVE_Block_Styles_Assignment_Repair {

        /**
         * Detach or replace all indexed assignments for a style.
         *
         * @param int $style_id Source Block Style id.
         * @param string $mode Either "detach" or "replace".
         * @param int $replacement_id Replacement Block Style id.
         * @return array|WP_Error
         */

        public static function repair_assignments( $style_id, $mode, $replacement_id = 0 ) {
            $style_id = absint( $style_id );
            $mode = (string) $mode;
            $replacement_id = absint( $replacement_id );

            if( ! in_array( $mode, array( 'detach', 'replace' ), true ) ) {
                return new WP_Error( 'wphave_block_style_invalid_repair_mode', __( 'Select a valid Block Style repair operation.', 'wphave' ), array( 'status' => 400 ) );
            }

            if( ! self::is_published_style( $style_id ) ) {
                return new WP_Error( 'wphave_block_style_invalid_source', __( 'The source Block Style is not published.', 'wphave' ), array( 'status' => 400 ) );
            }

            if(
                $mode === 'replace' &&
                (
                    ! $replacement_id ||
                    $replacement_id === $style_id ||
                    ! self::is_published_style( $replacement_id )
                )
            ) {
                return new WP_Error( 'wphave_block_style_invalid_replacement', __( 'Select a published replacement Block Style.', 'wphave' ), array( 'status' => 400 ) );
            }

            $repair_token = WPHAVE_Background_Job_Lock::acquire(
                self::REPAIR_LOCK_OPTION_KEY,
                self::REPAIR_LOCK_TTL
            );

            if( ! $repair_token ) {
                return new WP_Error(
                    'wphave_block_style_repair_busy',
                    __( 'Another Block Style repair is already running. Try again shortly.', 'wphave' ),
                    array( 'status' => 409 )
                );
            }

            try {
                return self::repair_assignments_locked(
                    $style_id,
                    $mode,
                    $replacement_id,
                    $repair_token
                );
            } finally {
                WPHAVE_Background_Job_Lock::release(
                    self::REPAIR_LOCK_OPTION_KEY,
                    $repair_token
                );
            }
        }

        /** Run one validated assignment repair while holding the operation lease. */

        protected static function repair_assignments_locked( $style_id, $mode, $replacement_id, $repair_token ) {

            $index = self::rebuild_usage_index();

            if(
                get_option( self::USAGE_LOCK_OPTION_KEY, false ) ||
                ! isset( $index['usage'] ) ||
                ! WPHAVE_Background_Job_Lock::refresh( self::REPAIR_LOCK_OPTION_KEY, $repair_token )
            ) {
                return new WP_Error(
                    'wphave_block_style_usage_busy',
                    __( 'Block Style assignments are currently being indexed. Try again shortly.', 'wphave' ),
                    array( 'status' => 409 )
                );
            }

            $sources = $index['usage'][$style_id]['sources'] ?? array();
            $result = array(
                'updatedSources' => 0,
                'updatedBlocks' => 0,
                'skippedBlocks' => 0,
                'skippedSources' => 0,
                'failedSources' => 0,
            );

            foreach( $sources as $source ) {
                if( ! WPHAVE_Background_Job_Lock::refresh( self::REPAIR_LOCK_OPTION_KEY, $repair_token ) ) {
                    return new WP_Error(
                        'wphave_block_style_repair_lease_lost',
                        __( 'The Block Style repair lease expired. Review the remaining usage and try again.', 'wphave' ),
                        array( 'status' => 409 )
                    );
                }

                $post = get_post( absint( $source['id'] ?? 0 ) );

                // AUTHORIZATION INVARIANT: Global style-management authority permits the
                // repair workflow, not mutation of every indexed document. Each source must
                // still pass edit_post immediately before its serialized blocks are replaced.
                if( ! self::is_usage_source( $post ) || ! current_user_can( 'edit_post', $post->ID ) ) {
                    $result['skippedSources']++;
                    continue;
                }

                $blocks = parse_blocks( $post->post_content );
                $source_result = array( 'updatedBlocks' => 0, 'skippedBlocks' => 0 );
                $changed = self::repair_blocks( $blocks, $style_id, $mode, $replacement_id, $source_result );
                $result['skippedBlocks'] += $source_result['skippedBlocks'];

                if( ! $changed ) {
                    continue;
                }

                $updated = wp_update_post( array( 'ID' => $post->ID, 'post_content' => wp_slash( serialize_blocks( $blocks ) ) ), true );
                
                if( ! is_wp_error( $updated ) ) {
                    $result['updatedSources']++;
                    $result['updatedBlocks'] += $source_result['updatedBlocks'];
                } else {
                    $result['failedSources']++;
                }
            }

            self::rebuild_usage_index();
            return $result;
        }

        /** Mutate parsed block assignments while preserving unrelated content. */

        protected static function repair_blocks( &$blocks, $style_id, $mode, $replacement_id, &$result ) {
            $changed = false;
            foreach( $blocks as &$block ) {
                $current_id = absint( $block['attrs']['wphave']['useBlockStyle'] ?? 0 );
                if( $current_id === $style_id ) {
                    if( $mode === 'replace' ) {
                        $block_name = (string) ( $block['blockName'] ?? '' );
                        if( ! self::is_compatible( $replacement_id, $block_name ) ) {
                            $result['skippedBlocks']++;
                        } else {
                            $wphave = is_array( $block['attrs']['wphave'] ?? null )
                                ? $block['attrs']['wphave']
                                : array();

                            // Transfer ownership explicitly. Compatible source-owned
                            // shadows must not reappear, and values claimed by the
                            // replacement must not remain redundantly persisted.
                            if( self::is_compatible( $style_id, $block_name ) ) {
                                $wphave = self::normalize_assigned_attrs(
                                    $wphave,
                                    self::get_attrs( $style_id )
                                );
                            }
                            $wphave = self::normalize_assigned_attrs(
                                $wphave,
                                self::get_attrs( $replacement_id )
                            );
                            $block['attrs']['wphave'] = $wphave;
                            $block['attrs']['wphave']['useBlockStyle'] = $replacement_id;
                            $result['updatedBlocks']++;
                            $changed = true;
                        }
                    } else {
                        $block_name = (string) ( $block['blockName'] ?? '' );
                        if( self::is_compatible( $style_id, $block_name ) ) {
                            $block['attrs']['wphave'] = self::detach_attrs(
                                $block['attrs']['wphave'],
                                $block_name
                            );
                        }
                        unset( $block['attrs']['wphave']['useBlockStyle'] );
                        $result['updatedBlocks']++;
                        $changed = true;
                    }
                }

                if( ! empty( $block['innerBlocks'] ) && self::repair_blocks( $block['innerBlocks'], $style_id, $mode, $replacement_id, $result ) ) {
                    $changed = true;
                }
            }
            unset( $block );

            return $changed;
        }

	}

endif;
