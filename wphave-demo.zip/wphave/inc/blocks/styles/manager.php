<?php

require_once wphave_dir() . 'inc/background-jobs/lock.php';
require_once wphave_dir() . 'inc/blocks/styles/rest-controller.php';
require_once wphave_dir() . 'inc/blocks/styles/registry-contract.php';
require_once wphave_dir() . 'inc/blocks/styles/attribute-assignments.php';
require_once wphave_dir() . 'inc/blocks/styles/usage-index.php';
require_once wphave_dir() . 'inc/blocks/styles/assignment-repair.php';
require_once wphave_dir() . 'inc/blocks/styles/css-runtime.php';

if ( ! class_exists( 'WPHAVE_Block_Styles' ) ) :

	/**
	 * Manages reusable global block styles.
	 *
	 * The block style editor stores one "wphave/style" block inside the
	 * "wphave-block-styles" post type. Frontend blocks reference those styles
	 * through "wphave.useBlockStyle"; this class resolves, validates, compiles
	 * and enqueues the assigned style data at runtime.
	 */

	class WPHAVE_Block_Styles {

		const POST_TYPE = 'wphave-block-styles';
		const CAPABILITY = 'wphave_manage_block_styles';
		const CSS_HASH_META_KEY = '_wphave_global_block_style_css_hash';
		const CSS_META_KEY = '_wphave_global_block_style_css';
		const USAGE_OPTION_KEY = 'wphave_global_block_style_usage_v1';
		const SOURCE_USAGE_META_KEY = '_wphave_global_block_style_ids';
		const USAGE_LOCK_OPTION_KEY = 'wphave_global_block_style_usage_lock_v1';
		const USAGE_LOCK_TTL = 300;
		const REPAIR_LOCK_OPTION_KEY = 'wphave_global_block_style_repair_lock_v1';
		const REPAIR_LOCK_TTL = 300;
		const USAGE_REBUILD_BATCH_SIZE = 100;

		/**
		 * Tracks whether WordPress hooks were already registered.
		 *
		 * @var bool
		 */

		protected static $initialized = false;

		/**
		 * Request-local style attribute cache.
		 *
		 * @var array<int,array>
		 */

		protected static $attrs_cache = array();

		/** @var array<string,bool> Request-local style/block compatibility cache. */

		protected static $compatibility_cache = array();

		/** @var array<int,bool> Style IDs already queued or printed in this request. */

		protected static $queued_css_ids = array();

		/** @var array|null Generated cross-runtime Block Style contract. */

		protected static $contract = null;

		/**
		 * Registers WordPress hooks for reusable block styles.
		 *
		 * @return void
		 */

		public static function init() {

			if( self::$initialized ) {
				return;
			}

			self::$initialized = true;

			add_action( 'init', array( __CLASS__, 'register_post_type' ), 16 );
			add_action( 'rest_api_init', array( 'WPHAVE_Block_Styles_REST_Controller', 'register_routes' ) );
			add_action( 'save_post_' . self::POST_TYPE, array( __CLASS__, 'refresh_css_cache' ), 20 );
			add_action( 'save_post_' . self::POST_TYPE, array( __CLASS__, 'normalize_style_assignments' ), 30 );
			add_action( 'save_post', array( __CLASS__, 'update_usage_for_saved_post' ), 30, 3 );
			add_action( 'before_delete_post', array( __CLASS__, 'remove_usage_for_deleted_post' ), 30, 2 );
			add_action( 'trashed_post', array( __CLASS__, 'remove_usage_for_trashed_post' ), 30, 2 );
			add_filter( 'pre_delete_post', array( __CLASS__, 'prevent_deleting_used_style' ), 10, 3 );
			add_filter( 'pre_trash_post', array( __CLASS__, 'prevent_trashing_used_style' ), 10, 2 );
			add_filter( 'wp_insert_post_data', array( __CLASS__, 'keep_used_style_published' ), 20, 2 );

		}

		use WPHAVE_Block_Styles_Registry_Contract;
		use WPHAVE_Block_Styles_Attribute_Assignments;
		use WPHAVE_Block_Styles_Usage_Index;
		use WPHAVE_Block_Styles_Assignment_Repair;
		use WPHAVE_Block_Styles_CSS_Runtime;

	}

endif;

WPHAVE_Block_Styles::init();
