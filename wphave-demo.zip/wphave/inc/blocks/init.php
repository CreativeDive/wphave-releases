<?php

/*
 * Bootstrap block helpers and runtime services.
 * Business logic lives in the dedicated classes loaded at the end of this file.
 */

include_once __DIR__ . '/bindings.php';

include_once __DIR__ . '/rendering/clip-paths.php';
include_once __DIR__ . '/rendering/duotones.php';

wphave_include_file(wphave_dir() . 'build/block-types/blocks-form/form/functions.php');
wphave_include_file(wphave_dir() . 'build/block-types/blocks/image/functions.php');
wphave_include_file(wphave_dir() . 'build/block-types/blocks/code/functions.php');
wphave_include_file(wphave_dir() . 'build/block-types/blocks/code-snippet/functions.php');
wphave_include_file(wphave_dir() . 'build/block-types/blocks/media-copyright/functions.php');

require_once __DIR__ . '/assets/assets.php';
require_once __DIR__ . '/inspection/inspector.php';
require_once __DIR__ . '/patterns/patterns.php';
require_once __DIR__ . '/registry/compatibility.php';
require_once __DIR__ . '/registry/types-rest.php';
require_once __DIR__ . '/rendering/renderer.php';
require_once __DIR__ . '/registry/registry.php';

WPHAVE_Block_Assets::init();
WPHAVE_Block_Registry::init();
WPHAVE_Block_Types_REST::init();

// Load the shared block render pipeline after block services are initialized.
require_once __DIR__ . '/visibility.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/conditions/runtime.php';
require_once __DIR__ . '/conditions/projection.php';
require_once __DIR__ . '/conditions/persistence.php';
add_filter('wp_insert_post_data', [WPHAVE_Block_Conditions_Persistence::class, 'protect'], 32, 2);
add_filter('render_block_data', [WPHAVE_Block_Conditions_Runtime::class, 'observe']);
add_filter('render_block', [WPHAVE_Block_Conditions_Runtime::class, 'annotate'], 10, 2);
require_once __DIR__ . '/wrapper.php';
require_once __DIR__ . '/rendering/gradient-composition.php';
require_once __DIR__ . '/rendering/halftone.php';
require_once __DIR__ . '/background.php';
require_once __DIR__ . '/background-media-persistence.php';
add_filter('wp_insert_post_data', [WPHAVE_Background_Media_Persistence::class, 'save'], 33);
require_once __DIR__ . '/image/functions.php';
require_once __DIR__ . '/image/attachment-primer.php';
require_once __DIR__ . '/image/renderer.php';
require_once __DIR__ . '/hero/composition.php';
require_once __DIR__ . '/image/image.php';
require_once __DIR__ . '/linking/linking.php';
require_once __DIR__ . '/dynamic-data/functions.php';
