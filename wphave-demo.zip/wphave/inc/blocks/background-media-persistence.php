<?php

/** Normalize older media keys and remove the superseded persisted editor drafts. */
final class WPHAVE_Background_Media_Persistence {
	public static function video(array $video): array {
		foreach (['file_alt' => 'fileAlternate', 'url_alt' => 'urlAlternate'] as $old => $new) {
			if (array_key_exists($old, $video)) {
				$video[$new] = $video[$new] ?? $video[$old];
				unset($video[$old]);
			}
		}
		return $video;
	}

	public static function normalize($value, $in_background = false) {
		if (!is_array($value)) {
			return $value;
		}
		foreach ($value as $key => $item) {
			if ($in_background && $key === 'media' && is_array($item)) {
				unset($item['inactive']);
				if (is_array($item['video'] ?? null)) {
					$item['video'] = self::video($item['video']);
				}
				$value[$key] = $item;
			} else {
				$value[$key] = self::normalize($item, $in_background || $key === 'background');
			}
		}
		return $value;
	}

	private static function blocks(array $blocks): array {
		foreach ($blocks as &$block) {
			if (isset($block['attrs']['wphave'])) {
				$block['attrs']['wphave'] = self::normalize($block['attrs']['wphave']);
			}
			$block['innerBlocks'] = self::blocks($block['innerBlocks'] ?? []);
		}
		unset($block);
		return $blocks;
	}

	public static function save(array $data): array {
		$content = wp_unslash($data['post_content'] ?? '');
		if (
			!str_contains($content, '"inactive"') &&
			!str_contains($content, '"file_alt"') &&
			!str_contains($content, '"url_alt"')
		) {
			return $data;
		}
		$blocks = parse_blocks($content);
		$next = self::blocks($blocks);
		if ($next !== $blocks) {
			$data['post_content'] = wp_slash(serialize_blocks($next));
		}
		return $data;
	}
}
