<?php

/**
 * Read the legacy serialized block patterns used by the WPHAVE theme render engine.
 *
 * These methods intentionally preserve the established regular-expression behavior.
 * Replacing it with parse_blocks() requires dedicated nested-pattern compatibility tests.
 */

class WPHAVE_Block_Patterns {

	/**
	 * Return a matching parent, child-content or self-closing block pattern.
	 *
	 * @param string $block_name Block name.
	 * @param string $content Serialized content.
	 * @return string|null
	 */

	public static function find( $block_name, $content ) {

        $block = self::find_parent( $block_name, $content );

        if( ! $block ) {
            $block = self::find_children( $block_name, $content );
        }

        if( ! $block ) {
            $block = self::find_single( $block_name, $content );
        }

        return $block;

	}

	/**
	 * Return the complete matching parent block markup.
	 *
	 * @param string $block_name Block name.
	 * @param string $content Serialized content.
	 * @return string|null
	 */

	public static function find_parent( $block_name, $content ) {

        $content = $content ?? '';
        $block_name = wphave_replace('/', '\/', $block_name);

        preg_match_all('/<!-- wp:' . $block_name . ' (.*)<!-- \/wp:' . $block_name . ' -->/s', $content, $matches);

        foreach( $matches[0] as $match ) {
            if( $match ) {
                return $match;
            }
        }

	}

	/**
	 * Return the inner markup of a matching parent block.
	 *
	 * @param string $block_name Block name.
	 * @param string $content Serialized content.
	 * @return string|null
	 */

	public static function find_children( $block_name, $content ) {

        $content = $content ?? '';
        $block_name = wphave_replace('/', '\/', $block_name);

        preg_match_all('/<!-- wp:' . $block_name . ' .*?-->(.*)<!-- \/wp:' . $block_name . ' -->/s', $content, $matches);

        foreach( $matches[1] as $match ) {
            if( $match ) {
                return $match;
            }
        }

	}

	/**
	 * Return matching self-closing block markup.
	 *
	 * @param string $block_name Block name.
	 * @param string $content Serialized content.
	 * @return string|null
	 */

	public static function find_single( $block_name, $content ) {

        $content = $content ?? '';
        $block_name = wphave_replace('/', '\/', $block_name);

        preg_match_all('/<!-- wp:' . $block_name . ' (.*)\/-->/Usim', $content, $matches);

        foreach( $matches[0] as $match ) {
            if( $match ) {
                return $match;
            }
        }

	}

	/**
	 * Read a legacy data attribute from matching serialized block markup.
	 *
	 * @param string $block_name Block name.
	 * @param string $option_name Data option name.
	 * @param string $content Serialized content.
	 * @return mixed
	 */

	public static function data( $block_name, $option_name, $content ) {

        $content = $content ?? '';
        $block_name = wphave_replace('/', '\/', $block_name);

        /*
        * ! Note: In order for the regex pattern to work properly, we need to consider two cases:
        *
        * Case 1: Block has NO inner blocks [ <!-- wp:wphave/block-name {...} /--> ]
        * Ends with: [ /--> ]
        *
        * Case 2: Block has inner blocks [ <!-- wp:wphave/block-name {...} --> ... <!-- /wp:wphave/block-name --> ]
        * Ends with: [ --> ]
        */

		preg_match_all('/<!-- wp:' . $block_name . '.*?({.*?})[^}]*?-->/s', $content, $matches);

		foreach( $matches[1] as $match ) {
			if( $match ) {
				$data = json_decode( $match, true );
				$option = isset( $data['data'][$option_name] ) ? $data['data'][$option_name] : '';

				if( $option ) {
					return $option;
				}
			}
		}
	}

}
