<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Makes selected WPHAVE content attributes available to Block Bindings
 * and Synced Pattern Overrides.
 *
 * Design attributes such as "wphave", generated styles and class names
 * intentionally remain excluded.
 */

function wphave_block_bindings_supported_attributes( $supported_attributes, $block_type ) {
	// One reviewed attribute contract is shared with the editor. Cache per request.
	static $wphave_attributes = null;
	if ( null === $wphave_attributes ) {
		$contract = json_decode( file_get_contents( __DIR__ . '/bindings-contract.json' ), true );
		$wphave_attributes = is_array( $contract ) ? $contract : array();
	}

	if( ! is_string( $block_type ) || ! isset( $wphave_attributes[$block_type] ) ) {
		return $supported_attributes;
	}

	return array_values( array_unique( array_merge( $supported_attributes, $wphave_attributes[$block_type] ) ) );
}

/**
 * Register the deliberately scoped Pattern Overrides integration.
 *
 * Structural changes to a synced pattern immediately affect every existing
 * instance, while newly added overridable content falls back to the pattern
 * default until each instance is reviewed. Keep this capability behind the
 * shared release gate until that lifecycle is covered by the product UI.
 *
 * @return bool Whether the integration was registered.
 */

function wphave_register_synced_pattern_override_attributes(): bool {
	if(
		! function_exists( 'wphave_release_feature_ready' )
		|| ! wphave_release_feature_ready( 'syncedPatternOverrides' )
	) {
		return false;
	}

	add_filter( 'block_bindings_supported_attributes', 'wphave_block_bindings_supported_attributes', 10, 2 );

	return true;
}

wphave_register_synced_pattern_override_attributes();
