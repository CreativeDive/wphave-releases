<?php

if (!defined('ABSPATH')) {
	exit();
}

require_once wphave_dir() . 'inc/features/security/boundaries/index.php';

/**
 * CSS Class Manager.
 *
 * Owns the complete server-side lifecycle for reusable CSS classes:
 * - Registers the hidden CSS class post type.
 * - Normalizes class slugs and exposes preload data.
 * - Compiles scoped CSS for frontend usage and editor preview usage.
 * - Scans block content for class assignments.
 * - Writes and enqueues the editor-wide CSS file.
 *
 * Public wrapper functions are kept at the bottom of this file so existing
 * call sites can continue to use the old procedural API.
 */

if (!class_exists('WPHAVE_CSS_Class_Manager')):
	class WPHAVE_CSS_Class_Manager {
		const POST_TYPE = 'wphave-css-classes';
		const CAPABILITY = 'wphave_manage_css_classes';
		const CLASS_PREFIX = 'wph-css-';
		const CSS_HASH_META = '_wphave_css_class_css_hash';
		const CSS_CACHE_META = '_wphave_css_class_css';
		const USAGE_CACHE_TRANSIENT = 'wphave_css_classes_usage';
		const EDITOR_CSS_HASH_OPTION = 'wphave_css_classes_editor_css_hash';
		const EDITOR_CSS_ERROR_OPTION = 'wphave_css_classes_editor_css_error';
		const EDITOR_CSS_RELATIVE_PATH = 'wphave/css-classes/editor.css';
		const EDITOR_CSS_HANDLE = 'wphave-global-css-classes-all';

		private static $fallback_printed_class_ids = [];
		private static $suffix_locks = [];

		/**
		 * Register WordPress hooks for the CSS class manager.
		 */

		public static function register_hooks() {
			add_action('init', [__CLASS__, 'register_post_type'], 16);
			add_action('rest_api_init', [__CLASS__, 'register_rest_routes']);
			add_filter(
				'rest_pre_insert_' . self::POST_TYPE,
				[__CLASS__, 'validate_rest_class'],
				10,
				2,
			);
			add_filter(
				'wp_insert_post_empty_content',
				[__CLASS__, 'reject_invalid_class_insert'],
				10,
				2,
			);
			add_filter('wp_insert_post_data', [__CLASS__, 'sync_slug'], 10, 2);
			add_action('enqueue_block_assets', [__CLASS__, 'enqueue_editor_styles'], 20);
			add_action('save_post', [__CLASS__, 'clear_usage_cache'], 20, 1);
			add_action('save_post_' . self::POST_TYPE, [__CLASS__, 'refresh_css_cache'], 20);
			add_action('deleted_post', [__CLASS__, 'clear_usage_cache'], 20, 2);
			add_action('trashed_post', [__CLASS__, 'clear_usage_cache'], 20, 1);
			add_action('untrashed_post', [__CLASS__, 'clear_usage_cache'], 20, 1);
			add_action('deleted_post', [__CLASS__, 'refresh_editor_css_file_on_delete'], 20, 2);
			add_action('save_post_' . self::POST_TYPE, [__CLASS__, 'release_suffix_locks'], 100);
			add_action('shutdown', [__CLASS__, 'release_suffix_locks']);
		}

		/**
		 * Register the CSS class post type.
		 *
		 * The post type is hidden from normal navigation but available through the
		 * REST API and the custom manager screen.
		 */

		public static function register_post_type() {
			register_post_type(self::POST_TYPE, [
				'label' => __('CSS Classes', 'wphave'),
				'description' => __(
					'Create reusable CSS classes and assign them to blocks.',
					'wphave',
				),
				'menu_icon' =>
					'data:image/svg+xml;base64,' . base64_encode(wphave_svg_ui_icon('code')),
				'menu_position' => 47,
				'supports' => ['title', 'editor'],
				'public' => false,
				'show_ui' => true,
				'capabilities' => self::capabilities(),
				'map_meta_cap' => false,
				'rewrite' => false,
				'show_in_menu' => false,
				'show_in_rest' => true,
				'has_archive' => false,
				'exclude_from_search' => true,
				'show_in_nav_menus' => false,
				'show_in_admin_bar' => false,
				'publicly_queryable' => false,
				'query_var' => false,
			]);

			register_rest_field(self::POST_TYPE, 'wphave_css_error', [
				'get_callback' => function () {
					return current_user_can(self::CAPABILITY)
						? (string) get_option(self::EDITOR_CSS_ERROR_OPTION, '')
						: '';
				},
				'schema' => [
					'description' => __(
						'The latest CSS class stylesheet generation error.',
						'wphave',
					),
					'type' => 'string',
					'context' => ['edit'],
					'readonly' => true,
				],
			]);
		}

		/**
		 * Capabilities used by the CSS class post type.
		 *
		 * A dedicated capability keeps access control independent from normal post
		 * editing permissions.
		 */

		public static function capabilities() {
			return [
				'edit_post' => self::CAPABILITY,
				'read_post' => self::CAPABILITY,
				'delete_post' => self::CAPABILITY,
				'edit_posts' => self::CAPABILITY,
				'edit_others_posts' => self::CAPABILITY,
				'delete_posts' => self::CAPABILITY,
				'delete_others_posts' => self::CAPABILITY,
				'publish_posts' => self::CAPABILITY,
				'read_private_posts' => self::CAPABILITY,
				'create_posts' => self::CAPABILITY,
			];
		}

		/**
		 * Register REST endpoints used by the CSS class manager screen.
		 */

		public static function register_rest_routes() {
			register_rest_route('wphave/v1', '/css-classes/usage', [
				'methods' => 'GET',
				'permission_callback' => [__CLASS__, 'can_view_usage'],
				'callback' => [__CLASS__, 'rest_usage'],
			]);
		}

		/** Determine whether the current user may inspect CSS-class usage. */
		public static function can_view_usage() {
			return current_user_can(self::CAPABILITY) || current_user_can('wphave_manage_options');
		}

		/** Return CSS-class usage after repeating the final authorization gate. */
		public static function rest_usage() {
			// AUTHORIZATION INVARIANT: The usage graph exposes internal post IDs and
			// content relationships. Direct/composed callback dispatch repeats the
			// exact route policy before cache access or content scanning.
			if (!self::can_view_usage()) {
				return new WP_Error(
					'wphave_css_classes_forbidden',
					__('You are not allowed to inspect CSS class usage.', 'wphave'),
					['status' => 403],
				);
			}

			return rest_ensure_response(self::get_usage());
		}

		/** Determine whether CSS class definitions may be changed. */

		public static function has_pro_access() {
			return function_exists('wphave_has_pro_access') && wphave_has_pro_access();
		}

		/**
		 * Determine whether a Free request only changes the publication status.
		 *
		 * This gives former Pro users a safe way to deactivate an existing class
		 * without permitting changes to its name or CSS rules.
		 */

		public static function is_status_only_request($request) {
			if (!($request instanceof WP_REST_Request) || !$request->has_param('status')) {
				return false;
			}

			$allowed = ['id', 'status', 'context', '_locale'];
			$params = array_merge(
				(array) $request->get_body_params(),
				(array) $request->get_json_params(),
			);

			return !array_diff(array_keys($params), $allowed);
		}

		/**
		 * Keep post_name in sync with the visible class name.
		 *
		 * In this manager the user-facing title and class suffix intentionally have
		 * the same meaning. Renaming a class therefore also renames its CSS suffix.
		 */

		public static function sync_slug($data, $postarr) {
			if (($data['post_type'] ?? '') !== self::POST_TYPE) {
				return $data;
			}

			$title = $data['post_title'] ?? '';

			if (!$title) {
				return $data;
			}

			$data['post_title'] = self::normalize_suffix($title);
			$data['post_name'] = $data['post_title'];

			return $data;
		}

		/**
		 * Normalize a user-facing class suffix to its canonical stored value.
		 */

		public static function normalize_suffix($value) {
			$value = preg_replace(
				'/^\.?' . preg_quote(self::CLASS_PREFIX, '/') . '/i',
				'',
				(string) $value,
			);

			return sanitize_title($value);
		}

		/**
		 * Check whether a class suffix is already assigned to another class post.
		 */

		public static function suffix_exists($suffix, $exclude_id = 0) {
			$suffix = self::normalize_suffix($suffix);

			if (!$suffix) {
				return false;
			}

			$ids = get_posts([
				'post_type' => self::POST_TYPE,
				'post_status' => ['publish', 'draft', 'private', 'pending', 'future'],
				'name' => $suffix,
				'post__not_in' => $exclude_id ? [absint($exclude_id)] : [],
				'fields' => 'ids',
				'posts_per_page' => 1,
				'no_found_rows' => true,
				'suppress_filters' => false,
			]);

			return !empty($ids);
		}

		/**
		 * Serialize suffix validation until the matching post write completes.
		 *
		 * MySQL named locks are connection-scoped and therefore cover the gap
		 * between WordPress REST validation and the subsequent INSERT or UPDATE.
		 *
		 * @param string $suffix Normalized CSS class suffix.
		 * @return bool Whether the lock was acquired.
		 */

		private static function acquire_suffix_lock($suffix) {
			global $wpdb;

			$lock_name = 'wphave_css_class_' . md5(self::normalize_suffix($suffix));

			if (isset(self::$suffix_locks[$lock_name])) {
				return true;
			}

			$acquired = (int) $wpdb->get_var(
				$wpdb->prepare('SELECT GET_LOCK(%s, %d)', $lock_name, 5),
			);

			if (1 === $acquired) {
				self::$suffix_locks[$lock_name] = true;
				return true;
			}

			return false;
		}

		/**
		 * Release all suffix locks owned by the current database connection.
		 *
		 * @return void
		 */

		public static function release_suffix_locks() {
			global $wpdb;

			foreach (array_keys(self::$suffix_locks) as $lock_name) {
				$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lock_name));
				unset(self::$suffix_locks[$lock_name]);
			}
		}

		/**
		 * Enforce the CSS class naming contract for REST creates and updates.
		 */

		public static function validate_rest_class($prepared_post, $request) {
			if (!self::has_pro_access() && !self::is_status_only_request($request)) {
				return new WP_Error(
					'wphave_css_class_pro_required',
					__('A Pro license is required to change reusable CSS classes.', 'wphave'),
					['status' => 403],
				);
			}

			if (!self::has_pro_access()) {
				return $prepared_post;
			}

			$post_id = absint($request->get_param('id'));
			$title = $prepared_post->post_title ?? '';

			if ($post_id && !$request->has_param('title')) {
				$existing_post = get_post($post_id);
				$title =
					$existing_post && self::POST_TYPE === $existing_post->post_type
						? $existing_post->post_title
						: '';
			}

			$suffix = self::normalize_suffix($title);

			if (!$suffix) {
				return new WP_Error(
					'wphave_css_class_invalid_suffix',
					__('Enter a valid CSS class suffix.', 'wphave'),
					['status' => 400],
				);
			}

			if (!self::acquire_suffix_lock($suffix)) {
				return new WP_Error(
					'wphave_css_class_suffix_locked',
					__('This class suffix is currently being saved. Try again.', 'wphave'),
					['status' => 409],
				);
			}

			if (self::suffix_exists($suffix, $post_id)) {
				self::release_suffix_locks();
				return new WP_Error(
					'wphave_css_class_duplicate_suffix',
					__('This class suffix is already in use.', 'wphave'),
					['status' => 409],
				);
			}

			$prepared_post->post_title = $suffix;
			$prepared_post->post_name = $suffix;

			return $prepared_post;
		}

		/**
		 * Reject invalid programmatic inserts outside the REST API.
		 */

		public static function reject_invalid_class_insert($maybe_empty, $postarr) {
			if ($maybe_empty || ($postarr['post_type'] ?? '') !== self::POST_TYPE) {
				return $maybe_empty;
			}

			$suffix = self::normalize_suffix($postarr['post_title'] ?? '');
			$post_id = absint($postarr['ID'] ?? 0);

			if (!$suffix || !self::acquire_suffix_lock($suffix)) {
				return true;
			}

			$invalid = self::suffix_exists($suffix, $post_id);

			if ($invalid) {
				self::release_suffix_locks();
			}

			return $invalid;
		}

		/**
		 * Return the public CSS class slug for a class post.
		 */

		public static function class_slug($post) {
			$post = is_numeric($post) ? get_post(absint($post)) : $post;

			if (!$post) {
				return '';
			}

			$slug = $post->post_name ?: sanitize_title($post->post_title);

			return $slug ? self::CLASS_PREFIX . sanitize_html_class($slug) : '';
		}

		/**
		 * Return manager data used by preloaded JavaScript state.
		 */

		public static function get_classes() {
			$posts = get_posts([
				'post_type' => self::POST_TYPE,
				'numberposts' => -1,
				'post_status' => ['publish', 'draft', 'private', 'pending', 'future'],
				'suppress_filters' => false,
				'cache_results' => true,
				'update_post_meta_cache' => true,
				'update_post_term_cache' => false,
			]);

			$output = [];

			foreach ($posts as $post) {
				$output[$post->ID] = [
					'id' => $post->ID,
					'title' => get_the_title($post),
					'slug' => self::class_slug($post),
					'css' => $post->post_content,
					'status' => $post->post_status,
				];
			}

			return $output;
		}

		/**
		 * Extract assigned global CSS class IDs from a wphave block attribute tree.
		 */

		public static function ids_from_wphave($wphave) {
			$ids = $wphave['features']['classes']['global'] ?? [];

			if (!is_array($ids)) {
				$ids = [$ids];
			}

			return array_values(array_unique(array_filter(array_map('absint', $ids))));
		}

		/**
		 * Resolve CSS class post IDs to frontend class names.
		 *
		 * Only published class posts are returned.
		 */

		public static function class_names_from_ids($ids) {
			$class_names = [];

			foreach ($ids as $id) {
				$post = get_post(absint($id));

				if (
					!$post ||
					$post->post_type !== self::POST_TYPE ||
					$post->post_status !== 'publish'
				) {
					continue;
				}

				$class_names[] = self::class_slug($post);
			}

			return array_values(array_filter($class_names));
		}

		/**
		 * Compile and cache one CSS class post.
		 */

		public static function compile_class_css($class_id) {
			$class_id = absint($class_id);

			if (!$class_id) {
				return '';
			}

			$post = get_post($class_id);

			if (
				!$post ||
				$post->post_type !== self::POST_TYPE ||
				$post->post_status !== 'publish'
			) {
				return '';
			}

			$source = WPHAVE_CSS_Compiler::sanitize_source($post->post_content);
			$selector = '.' . self::class_slug($post);
			$hash = md5('v5|' . $selector . '|' . $source);
			$cached_hash = get_post_meta($class_id, self::CSS_HASH_META, true);
			$cached_css = get_post_meta($class_id, self::CSS_CACHE_META, true);

			if ($cached_css && $cached_hash === $hash) {
				return $cached_css;
			}

			$css = WPHAVE_CSS_Compiler::scope_source($source, $selector);

			update_post_meta($class_id, self::CSS_HASH_META, $hash);
			update_post_meta($class_id, self::CSS_CACHE_META, $css);

			return $css;
		}

		/**
		 * Compile all published class CSS for the editor-wide stylesheet.
		 */

		public static function compile_editor_css() {
			$posts = get_posts([
				'post_type' => self::POST_TYPE,
				'numberposts' => -1,
				'post_status' => 'publish',
				'suppress_filters' => false,
				'fields' => 'ids',
				'cache_results' => true,
				'update_post_meta_cache' => true,
				'update_post_term_cache' => false,
			]);

			$styles = '';

			foreach ($posts as $post_id) {
				$styles .= self::compile_class_css($post_id);
			}

			return $styles;
		}

		/**
		 * Return filesystem path and URL for the generated editor CSS file.
		 */

		public static function editor_css_file() {
			$upload_dir = wp_upload_dir(null, false);
			$base_dir = $upload_dir['basedir'] ?? '';
			$base_url = wphave_public_url($upload_dir['baseurl'] ?? '');

			if (!$base_dir || !$base_url) {
				return [];
			}

			return [
				'path' => trailingslashit($base_dir) . self::EDITOR_CSS_RELATIVE_PATH,
				'url' => trailingslashit($base_url) . self::EDITOR_CSS_RELATIVE_PATH,
				'dir' => trailingslashit($base_dir) . 'wphave/css-classes',
			];
		}

		/**
		 * Write the editor-wide CSS file.
		 *
		 * The editor loads this file as a normal stylesheet. React only adds a
		 * temporary override when the manager saves changes inside an open editor.
		 */

		public static function write_editor_css_file($force = false) {
			$file = self::editor_css_file();

			if (empty($file['path']) || empty($file['dir'])) {
				self::record_editor_css_error(
					__('The CSS class stylesheet path is unavailable.', 'wphave'),
				);
				return false;
			}

			$css = self::compile_editor_css();
			$hash = md5($css);
			$stored_hash = get_option(self::EDITOR_CSS_HASH_OPTION, '');

			if (!$force && file_exists($file['path']) && $stored_hash === $hash) {
				return $file;
			}

			if (!wp_mkdir_p($file['dir'])) {
				self::record_editor_css_error(
					__('The CSS class stylesheet directory could not be created.', 'wphave'),
				);
				return false;
			}

			try {
				// PUBLICATION INVARIANT: Editor CSS is a served asset, not a private
				// tempnam file. Publish complete bytes with local directory permissions.
				WPHAVE_Security_Atomic_File::write(
					$file['path'],
					$css,
					'Editor stylesheet could not be published.',
					WPHAVE_Security_File_Permissions::for_new_public_file($file['path']),
				);
			} catch (RuntimeException $error) {
				self::record_editor_css_error(
					__('The CSS class stylesheet could not be activated.', 'wphave'),
				);
				return false;
			}

			// SECURITY INVARIANT: The public stylesheet and its identifying hash become
			// current only after complete temporary bytes are atomically published. A
			// failed compilation or move leaves the last valid stylesheet authoritative.
			update_option(self::EDITOR_CSS_HASH_OPTION, $hash, false);
			delete_option(self::EDITOR_CSS_ERROR_OPTION);

			return $file;
		}

		/**
		 * Persist and report a stylesheet generation error without replacing the last valid file.
		 */

		public static function record_editor_css_error($message) {
			$message = WPHAVE_Security_Redactor::error_text($message, 1000);
			update_option(self::EDITOR_CSS_ERROR_OPTION, $message, false);
			do_action('wphave_css_class_stylesheet_error', $message);
			error_log('wphave CSS Classes: ' . $message);
		}

		/**
		 * Enqueue the generated editor stylesheet in block editor contexts.
		 */

		public static function enqueue_editor_styles() {
			if (!is_admin()) {
				return;
			}

			$file = self::write_editor_css_file();

			if (
				!$file ||
				empty($file['path']) ||
				empty($file['url']) ||
				!file_exists($file['path'])
			) {
				return;
			}

			wp_enqueue_style(
				self::EDITOR_CSS_HANDLE,
				$file['url'],
				[],
				filemtime($file['path']),
				'all',
			);
		}

		/**
		 * Collect all assigned global CSS class IDs from parsed blocks.
		 */

		public static function collect_ids_from_blocks($blocks, $class_ids = []) {
			if (!is_array($blocks)) {
				return $class_ids;
			}

			foreach ($blocks as $block) {
				if (!is_array($block)) {
					continue;
				}

				$ids = self::ids_from_wphave($block['attrs']['wphave'] ?? []);

				foreach ($ids as $id) {
					$class_ids[$id] = $id;
				}

				if (!empty($block['innerBlocks'])) {
					$class_ids = self::collect_ids_from_blocks($block['innerBlocks'], $class_ids);
				}
			}

			return $class_ids;
		}

		/**
		 * Build usage data for the CSS class manager screen.
		 */

		public static function collect_usage_from_blocks($blocks, $source = [], $usage = []) {
			if (!is_array($blocks)) {
				return $usage;
			}

			foreach ($blocks as $block) {
				if (!is_array($block)) {
					continue;
				}

				$class_ids = self::ids_from_wphave($block['attrs']['wphave'] ?? []);
				$block_name = $block['blockName'] ?? '';

				foreach ($class_ids as $class_id) {
					if (!isset($usage[$class_id])) {
						$usage[$class_id] = [
							'count' => 0,
							'sources' => [],
							'blockTypes' => [],
						];
					}

					$usage[$class_id]['count']++;

					if ($block_name) {
						$usage[$class_id]['blockTypes'][$block_name] = $block_name;
					}

					$source_key = !empty($source['id'])
						? ($source['type'] ?? 'post') . ':' . $source['id']
						: '';

					if ($source_key && !isset($usage[$class_id]['sources'][$source_key])) {
						$usage[$class_id]['sources'][$source_key] = $source;
					}
				}

				if (!empty($block['innerBlocks'])) {
					$usage = self::collect_usage_from_blocks(
						$block['innerBlocks'],
						$source,
						$usage,
					);
				}
			}

			return $usage;
		}

		/**
		 * Scan editor-managed post content and return class usage data.
		 */

		public static function get_usage($force = false) {
			$cached = !$force ? get_transient(self::USAGE_CACHE_TRANSIENT) : false;

			if (is_array($cached)) {
				return $cached;
			}

			$post_types = self::usage_post_types();
			$usage = [];
			$page = 1;
			$batch_size = 200;

			do {
				$query = new WP_Query([
					'post_type' => $post_types,
					'posts_per_page' => $batch_size,
					'paged' => $page,
					'post_status' => ['publish', 'draft', 'private', 'pending', 'future'],
					'fields' => 'ids',
					'orderby' => 'ID',
					'order' => 'ASC',
					'no_found_rows' => true,
					'cache_results' => true,
					'update_post_meta_cache' => false,
					'update_post_term_cache' => false,
				]);
				$post_ids = $query->posts;

				foreach ($post_ids as $post_id) {
					$post = get_post($post_id);
					$content = $post->post_content ?? '';

					if (!$content || !str_contains($content, '"classes"')) {
						continue;
					}

					$source = [
						'id' => $post->ID,
						'type' => $post->post_type,
						'title' => get_the_title($post),
						'slug' => $post->post_name,
						'status' => $post->post_status,
					];

					$usage = self::collect_usage_from_blocks(
						parse_blocks($content),
						$source,
						$usage,
					);
				}

				$page++;
			} while (count($post_ids) === $batch_size);

			foreach ($usage as $class_id => $data) {
				$usage[$class_id]['sources'] = array_values($data['sources']);
				$usage[$class_id]['blockTypes'] = array_values($data['blockTypes']);
			}

			set_transient(self::USAGE_CACHE_TRANSIENT, $usage, HOUR_IN_SECONDS);

			return $usage;
		}

		/**
		 * Return post types whose block content may reference global CSS classes.
		 */

		public static function usage_post_types() {
			$post_types = get_post_types(['show_ui' => true], 'names');
			$post_types = array_unique(
				array_merge(array_values($post_types), [
					'page',
					'post',
					'wp_block',
					'wphave-templates',
					'wphave-template-part',
					'wphave-add-ons',
					'wphave-forms',
					'wphave-navigations',
				]),
			);

			return array_values(
				array_diff($post_types, ['attachment', 'wphave-block-styles', self::POST_TYPE]),
			);
		}

		/**
		 * Enqueue only used CSS classes on the frontend render path.
		 */

		public static function enqueue_used_classes($content) {
			if (!is_string($content) || $content === '' || !str_contains($content, '"classes"')) {
				return;
			}

			$class_ids = self::collect_ids_from_blocks(parse_blocks($content));

			if (!$class_ids) {
				return;
			}

			$styles = '';

			foreach ($class_ids as $class_id) {
				$styles .= self::compile_class_css($class_id);
			}

			if ($styles) {
				WPHAVE_Style_Engine::instance()->add($styles);
			}
		}

		/**
		 * Return CSS for class IDs on a single block render fallback path.
		 *
		 * The main site render engine enqueues used classes from raw page content
		 * before rendering. This fallback covers normal WordPress render_callback
		 * contexts where that engine is bypassed.
		 */

		public static function fallback_styles_from_wphave($wphave) {
			if (
				function_exists('wphave_render_engine_is_rendering') &&
				wphave_render_engine_is_rendering()
			) {
				return '';
			}

			$class_ids = self::ids_from_wphave($wphave);

			if (!$class_ids) {
				return '';
			}

			$styles = '';

			foreach ($class_ids as $class_id) {
				if (isset(self::$fallback_printed_class_ids[$class_id])) {
					continue;
				}

				self::$fallback_printed_class_ids[$class_id] = $class_id;
				$styles .= self::compile_class_css($class_id);
			}

			return $styles;
		}

		/**
		 * Clear cached class usage data.
		 */

		public static function clear_usage_cache($post_id = 0, $post = null) {
			$post_type = $post->post_type ?? get_post_type($post_id);

			if ($post_type && !in_array($post_type, self::usage_post_types(), true)) {
				return;
			}

			delete_transient(self::USAGE_CACHE_TRANSIENT);
		}

		/**
		 * Refresh per-class CSS cache and editor CSS file after class saves.
		 */

		public static function refresh_css_cache($post_id) {
			$post_id = absint($post_id);

			if (!$post_id || get_post_type($post_id) !== self::POST_TYPE) {
				return;
			}

			delete_post_meta($post_id, self::CSS_HASH_META);
			delete_post_meta($post_id, self::CSS_CACHE_META);

			if (get_post_status($post_id) === 'publish') {
				self::compile_class_css($post_id);
			}

			self::write_editor_css_file(true);
		}

		/**
		 * Refresh editor CSS after a class post is deleted.
		 */

		public static function refresh_editor_css_file_on_delete($post_id, $post = null) {
			if (($post->post_type ?? '') !== self::POST_TYPE) {
				return;
			}

			self::write_editor_css_file(true);
		}
	}
endif;

WPHAVE_CSS_Class_Manager::register_hooks();

if (!function_exists('wphave_get_css_classes')):
	/**
	 * Get CSS classes.
	 */

	function wphave_get_css_classes() {
		return WPHAVE_CSS_Class_Manager::get_classes();
	}
endif;

if (!function_exists('wphave_css_class_ids_from_wphave')):
	/**
	 * CSS class IDs from wphave.
	 *
	 * @param mixed $wphave WPHAVE.
	 */

	function wphave_css_class_ids_from_wphave($wphave) {
		return WPHAVE_CSS_Class_Manager::ids_from_wphave($wphave);
	}
endif;

if (!function_exists('wphave_css_class_names_from_ids')):
	/**
	 * CSS class names from IDs.
	 *
	 * @param mixed $ids IDs.
	 */

	function wphave_css_class_names_from_ids($ids) {
		return WPHAVE_CSS_Class_Manager::class_names_from_ids($ids);
	}
endif;

if (!function_exists('wphave_get_css_class_usage')):
	/**
	 * Get CSS class usage.
	 */

	function wphave_get_css_class_usage() {
		return WPHAVE_CSS_Class_Manager::get_usage();
	}
endif;

if (!function_exists('wphave_enqueue_used_css_classes')):
	/**
	 * Enqueue used CSS classes.
	 *
	 * @param string $content Content to process.
	 */

	function wphave_enqueue_used_css_classes($content) {
		WPHAVE_CSS_Class_Manager::enqueue_used_classes($content);
	}
endif;

if (!function_exists('wphave_css_class_fallback_styles_from_wphave')):
	/**
	 * CSS class fallback styles from wphave.
	 *
	 * @param mixed $wphave WPHAVE.
	 */

	function wphave_css_class_fallback_styles_from_wphave($wphave) {
		return WPHAVE_CSS_Class_Manager::fallback_styles_from_wphave($wphave);
	}
endif;
