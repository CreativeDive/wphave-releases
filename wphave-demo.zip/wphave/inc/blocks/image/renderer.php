<?php

/**
 * Render WordPress attachment images and manage their cached markup.
 */

class WPHAVE_Image_Renderer {
	/** Final image output: SVG parsing is never used for regular IMG markup. */
	public static function output(string $image): string {
		if (!preg_match('/^\s*<svg(?:\s|>)/i', $image)) {
			return wp_kses_post($image);
		}
		require_once wphave_dir() . 'inc/features/security/svg-output.php';
		return WPHAVE_SVG_Output::sanitize($image);
	}

	/**
	 * Request-local attachment post cache, including negative lookups.
	 *
	 * WordPress object caching covers valid posts, but stale media IDs can still
	 * trigger the same missing-post lookup from mime, image and source helpers.
	 * Retaining null explicitly prevents those harmless misses becoming N+1 noise.
	 *
	 * @var array<int, WP_Post|null>
	 */

	private static array $attachment_cache = [];

	/**
	 * Attachment alt text already read during this request.
	 *
	 * @var array<int,string>
	 */

	private static array $alt_cache = [];

	/**
	 * Request-local alt revisions used by deferred post-cache collectors.
	 *
	 * @var array<int,int>
	 */

	private static array $alt_revisions = [];

	/**
	 * Return attachment alt text from the shared post image cache.
	 *
	 * Empty alt text is a valid cached value because it deliberately marks an
	 * image as decorative. Use array_key_exists() for both cache layers so an
	 * empty value never falls through to another metadata query.
	 *
	 * @param int $attachment_id Attachment ID.
	 * @return string|false Alt text, or false without an attachment ID.
	 */

	public static function alt($attachment_id) {
		$attachment_id = absint($attachment_id);
		if (!$attachment_id) {
			return false;
		}

		if (array_key_exists($attachment_id, self::$alt_cache)) {
			return self::$alt_cache[$attachment_id];
		}

		$cache_key = md5(wp_json_encode(['id' => $attachment_id, 'type' => 'alt']));
		$cache = WPHAVE_Post_Cache::get_cache() ?: [];
		$cached_entry = $cache['images'][$cache_key] ?? [];
		if (is_array($cached_entry) && array_key_exists('alt', $cached_entry)) {
			self::$alt_cache[$attachment_id] = (string) $cached_entry['alt'];
			return self::$alt_cache[$attachment_id];
		}

		self::$alt_cache[$attachment_id] = (string) get_post_meta(
			$attachment_id,
			'_wp_attachment_image_alt',
			true,
		);
		if (WPHAVE_Post_Cache::is_enabled()) {
			$alt = self::$alt_cache[$attachment_id];
			$revision = self::$alt_revisions[$attachment_id] ?? 0;
			add_filter(
				'wphave_post_images',
				static function ($images) use ($alt, $attachment_id, $cache_key, $revision) {
					$images = is_array($images) ? $images : [];
					if ((self::$alt_revisions[$attachment_id] ?? 0) !== $revision) {
						return $images;
					}

					$images[$cache_key]['alt'] = $alt;
					return $images;
				},
				10,
			);
		}

		return self::$alt_cache[$attachment_id];
	}

	/**
	 * Forget request-local alt output after its attachment meta changes.
	 *
	 * @param int $attachment_id Attachment ID.
	 * @return void
	 */

	public static function invalidate_alt($attachment_id): void {
		$attachment_id = absint($attachment_id);
		unset(self::$alt_cache[$attachment_id]);
		self::$alt_revisions[$attachment_id] = (self::$alt_revisions[$attachment_id] ?? 0) + 1;
	}

	/**
	 * Return attachment image markup with WPHAVE SVG and pin-button support.
	 *
	 * @param int $attachment_id Attachment ID.
	 * @param string|array $size Registered size slug or dimensions.
	 * @param array $attr Image HTML attributes.
	 * @param array $options WPHAVE output options.
	 * @return string|false Image markup or false when no attachment is available.
	 */

	public static function render($attachment_id, $size = '', $attr = [], $options = []) {
		$attachment_id = absint($attachment_id);
		$attachment = self::attachment($attachment_id);

		if (!$attachment) {
			return false;
		}

		// Keep HTML attributes separate from WPHAVE rendering options. This
		// prevents internal controls from leaking into the generated IMG tag.
		$attr = is_array($attr) ? $attr : [];

		$options = wp_parse_args(is_array($options) ? $options : [], [
			'inline_svg' => false,
			'pin_button' => true,
		]);

		$inline_svg = (bool) $options['inline_svg'];

		// A resolved sizes value is passed directly to WordPress so its native
		// srcset calculation remains the single source of responsive candidates.
		if (isset($attr['sizes']) && is_string($attr['sizes'])) {
			$attr['sizes'] = sanitize_text_field($attr['sizes']);
		}

		if (empty($attr['sizes'])) {
			unset($attr['sizes']);
		}

		$size = $size ?: 'full';
		$wp_image_class = 'wp-image-' . $attachment_id;

		// WordPress uses this class to discover attachment IDs while filtering
		// content images and priming attachment metadata caches.
		$attr['class'] = isset($attr['class'])
			? $wp_image_class . ' ' . $attr['class']
			: $wp_image_class;

		// The pin button is intentionally not part of the cached image markup.
		// Its availability can change independently from the attachment output.
		$pin_button = '';
		if (WPHAVE_Add_On_Manager::has('pin-button') && $options['pin_button']) {
			$pin_button = wphave_pin_button(false, $attachment_id);
		}

		// Every value that changes the actual image tag must be represented in
		// the key. The separately appended pin button must not affect this cache.
		$cache_key = md5(
			wp_json_encode([
				'id' => $attachment_id,
				'size' => $size,
				'attr' => $attr,
				'inline_svg' => $inline_svg,
				'svg_policy' => 1,
			]),
		);

		if (WPHAVE_Post_Cache::is_enabled()) {
			$cache = WPHAVE_Post_Cache::get_cache() ?: [];
			$cached_image = $cache['images'][$cache_key]['tag'] ?? '';
			if ($cached_image) {
				// Inline SVG output is already complete and must not receive adjacent
				// controls. Regular IMG markup receives the current pin-button output.
				return wphave_str_contains($cached_image, '<svg') && $inline_svg
					? $cached_image
					: $cached_image . $pin_button;
			}
		}

		if ($attachment->post_mime_type === 'image/svg+xml') {
			$attr['class'] .= ' svg-image';
		}

		// Let WordPress generate width, height, srcset, sizes and its normal
		// accessibility attributes before applying the optional SVG conversion.
		$image = wp_get_attachment_image($attachment_id, $size, false, $attr);
		$is_svg_image = wphave_is_svg_image($image);
		if ($is_svg_image && $inline_svg) {
			$svg_tag = self::inline_svg($attachment_id, $attr);
			$image = $svg_tag ?: $image;
		}

		if (WPHAVE_Post_Cache::is_enabled()) {
			// Store only stable attachment markup. Request-dependent controls are
			// appended after cache retrieval and therefore never become stale here.
			add_filter(
				'wphave_post_images',
				static function ($images) use ($image, $cache_key) {
					$images = is_array($images) ? $images : [];
					$images[$cache_key]['tag'] = $image;
					return $images;
				},
				10,
			);
		}

		return $is_svg_image && $inline_svg ? $image : $image . $pin_button;
	}

	/**
	 * Return an attachment image URL and reuse the post image cache when active.
	 *
	 * @param int $attachment_id Attachment ID.
	 * @param string|array $size Registered size slug or dimensions.
	 * @return string|false Image URL or false when unavailable.
	 */

	public static function src($attachment_id, $size = '') {
		$attachment_id = absint($attachment_id);

		if (!self::attachment($attachment_id)) {
			return false;
		}

		$size = $size ?: 'full';

		// Named and array-based WordPress sizes require a structured cache key;
		// string concatenation would make different size inputs ambiguous.
		$cache = WPHAVE_Post_Cache::get_cache() ?: [];
		$cache_key = md5(wp_json_encode(['id' => $attachment_id, 'size' => $size]));

		if (isset($cache['images'][$cache_key]['src'])) {
			return $cache['images'][$cache_key]['src'];
		}

		$image_src = wp_get_attachment_image_src($attachment_id, $size);
		$image_src = $image_src[0] ?? '';

		if (WPHAVE_Post_Cache::is_enabled()) {
			// Feed the resolved URL into the shared post cache without introducing
			// another persistent cache or a separate invalidation lifecycle.
			add_filter(
				'wphave_post_images',
				static function ($images) use ($image_src, $cache_key) {
					$images = is_array($images) ? $images : [];
					$images[$cache_key]['src'] = $image_src;
					return $images;
				},
				10,
			);
		}

		return $image_src ?: false;
	}

	/**
	 * Resolve one attachment while preserving failed lookups for this request.
	 *
	 * @param int $attachment_id Candidate attachment ID.
	 * @return WP_Post|null Attachment post, or null for invalid and stale IDs.
	 */

	private static function attachment(int $attachment_id): ?WP_Post {
		if (!$attachment_id) {
			return null;
		}

		if (array_key_exists($attachment_id, self::$attachment_cache)) {
			return self::$attachment_cache[$attachment_id];
		}

		$post = get_post($attachment_id);
		self::$attachment_cache[$attachment_id] =
			$post instanceof WP_Post && $post->post_type === 'attachment' ? $post : null;

		return self::$attachment_cache[$attachment_id];
	}

	/**
	 * Return a sanitized SVG attachment as inline markup.
	 *
	 * @param int $attachment_id Attachment ID.
	 * @param array $attr Attributes for the root SVG element.
	 * @return string|false Sanitized SVG markup or false when unavailable.
	 */

	public static function inline_svg($attachment_id, $attr = []) {
		// Only local SVG attachments may be inlined. Remote or non-SVG sources
		// must continue through the normal WordPress image path.
		$file = get_attached_file($attachment_id);
		if (
			!$file ||
			!file_exists($file) ||
			strtolower(pathinfo($file, PATHINFO_EXTENSION)) !== 'svg'
		) {
			return false;
		}

		require_once wphave_dir() . 'inc/features/security/svg-output.php';
		require_once wphave_dir() . 'inc/features/security/file-identity.php';
		try {
			// SVG RENDER MEMORY INVARIANT: Legacy attachments and replaced files
			// may exceed today's upload cap. A public page must not load their full
			// contents before the SVG parser applies its byte limit.
			$source = WPHAVE_Security_File_Identity::read_bounded(
				$file,
				WPHAVE_Safe_SVG::MAX_FILE_SIZE + 1,
				false,
				__('The SVG attachment could not be read safely.', 'wphave'),
			);
		} catch (RuntimeException $error) {
			return false;
		}
		if ($source['truncated'] || $source['sizeBytes'] > WPHAVE_Safe_SVG::MAX_FILE_SIZE) {
			return false;
		}
		$svg = $source['content'];
		if ($svg === '' || stripos($svg, '<svg') === false) {
			return false;
		}

		$alt = wphave_image_alt($attachment_id);
		if ($alt) {
			$attr['role'] = 'img';
			$attr['aria-label'] = $alt;
		} else {
			$attr['aria-hidden'] = 'true';
			$attr['focusable'] = 'false';
		}

		// Cache only canonical markup. IDs are scoped at each actual output.
		return WPHAVE_SVG_Output::sanitize($svg, $attr, false) ?: false;
	}
}
