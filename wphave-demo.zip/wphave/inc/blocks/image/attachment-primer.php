<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Batch-prime attachment posts required by one WPHAVE render pass.
 *
 * Dynamic image blocks otherwise resolve every attachment independently while
 * rendering. Collecting their explicit media attributes before `the_content`
 * turns that N+1 access pattern into one bounded post-cache query without
 * changing WordPress' canonical attachment APIs or cache invalidation rules.
 */
final class WPHAVE_Attachment_Primer {

	private const MAX_ATTACHMENTS = 200;

	/**
	 * Explicit media attributes owned by supported block contracts.
	 *
	 * Numeric layout settings are intentionally excluded. New media-bearing block
	 * contracts must opt in here so unrelated post IDs are never loaded by guesswork.
	 */
	private const BLOCK_ATTRIBUTES = [
		'core/image' => [ 'id' ],
		'wphave/hotspots' => [ 'image' ],
		'wphave/image' => [ 'image' ],
		'wphave/image-compare' => [ 'imageLeftId', 'imageRightId' ],
		'wphave/image-magnifier' => [ 'image' ],
		'wphave/scrollable-image' => [ 'image' ],
	];

	/**
	 * Prime attachments referenced by rendered blocks and global presentation data.
	 *
	 * @param string $content Serialized block content for the complete page canvas.
	 * @return array<int, int> Attachment IDs supplied to WordPress' post cache.
	 */
	public static function prime_content( string $content ): array {
		$ids = self::collect_ids( function_exists( 'parse_blocks' ) ? parse_blocks( $content ) : [] );
		$ids = array_merge( $ids, self::global_ids() );
		$ids = array_slice( array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) ), 0, self::MAX_ATTACHMENTS );

		if ( $ids !== [] && function_exists( '_prime_post_caches' ) ) {
			_prime_post_caches( $ids, true, true );
		}

		return $ids;
	}

	/**
	 * Collect explicit attachment IDs from parsed blocks and their descendants.
	 *
	 * @param array<int, array<string, mixed>> $blocks Parsed WordPress blocks.
	 * @return array<int, int> Attachment IDs.
	 */
	public static function collect_ids( array $blocks ): array {
		$ids = [];
		$stack = array_reverse( $blocks );

		// ROBUSTNESS INVARIANT: The render-pass attachment limit also bounds
		// traversal work. Never recurse through the remainder of a pathological
		// block tree after enough unique dependencies have been collected.
		while ( $stack !== [] && count( $ids ) < self::MAX_ATTACHMENTS ) {
			$block = array_pop( $stack );
			if ( ! is_array( $block ) ) {
				continue;
			}

			$name = (string) ( $block['blockName'] ?? '' );
			$attributes = is_array( $block['attrs'] ?? null ) ? $block['attrs'] : [];

			foreach ( self::BLOCK_ATTRIBUTES[ $name ] ?? [] as $attribute ) {
				$value = $attributes[ $attribute ] ?? 0;
				$values = is_array( $value ) ? $value : [ $value ];

				foreach ( $values as $candidate ) {
					$attachment_id = absint( $candidate );
					if ( $attachment_id ) {
						$ids[ $attachment_id ] = $attachment_id;
					}

					if ( count( $ids ) >= self::MAX_ATTACHMENTS ) {
						break 2;
					}
				}
			}

			$inner_blocks = is_array( $block['innerBlocks'] ?? null ) ? $block['innerBlocks'] : [];
			for ( $index = count( $inner_blocks ) - 1; $index >= 0; $index-- ) {
				$stack[] = $inner_blocks[ $index ];
			}
		}

		return array_values( $ids );
	}

	/** Collect attachment settings consumed outside serialized image blocks. */
	private static function global_ids(): array {
		$brand = function_exists( 'wphave_data_get' ) ? wphave_data_get( 'site_settings', 'brand', [] ) : [];
		$brand = is_array( $brand ) ? $brand : [];
		$queried_id = function_exists( 'get_queried_object_id' ) ? absint( get_queried_object_id() ) : 0;

		return [
			absint( $brand['logo'] ?? 0 ),
			absint( $brand['contrastLogo'] ?? 0 ),
			function_exists( 'get_option' ) ? absint( get_option( 'site_icon', 0 ) ) : 0,
			$queried_id && function_exists( 'get_post_thumbnail_id' ) ? absint( get_post_thumbnail_id( $queried_id ) ) : 0,
		];
	}
}
