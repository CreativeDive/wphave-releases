<?php

require_once __DIR__ . '/size.php';


/**
 * Register image sizes owned by WPHAVE without changing theme defaults.
 *
 * @return void
 */

if ( ! function_exists( 'wphave_register_image_sizes' ) ) :

	function wphave_register_image_sizes() {

		// Never override the active theme's global post-thumbnail dimensions.
		add_image_size( 'wphave_full', 1280, 0, false );

	}

endif;

add_action( 'after_setup_theme', 'wphave_register_image_sizes' );


/**
 * Add WPHAVE sizes to WordPress' named image-size choices.
 *
 * @param array $sizes Named image sizes.
 * @return array Filtered image sizes.
 */

if ( ! function_exists( 'wphave_register_image_size_names' ) ) :

	function wphave_register_image_size_names( $sizes ) {

		$sizes['wphave_full'] = __( 'WPHAVE Full', 'wphave' );

		return $sizes;

	}

endif;

add_filter( 'image_size_names_choose', 'wphave_register_image_size_names', 11, 1 );


/**
 * Return editor choices for all named and registered image sizes.
 *
 * @return array Image size choices keyed by slug.
 */

if ( ! function_exists( 'wphave_get_image_sizes' ) ) :

	function wphave_get_image_sizes() {

		$sizes = array(
			'auto' => __( 'Automatically', 'wphave' ),
		);

		$subsizes = wp_get_registered_image_subsizes();

		$names = apply_filters( 'image_size_names_choose', array(
			'thumbnail' => __( 'Thumbnail', 'wphave' ),
			'medium' => __( 'Medium', 'wphave' ),
			'medium_large' => __( 'Medium Large', 'wphave' ),
			'large' => __( 'Large', 'wphave' ),
		) );

		// Mirror WordPress' named-size filter so third-party registered choices
		// remain available without exposing internal or unnamed subsizes.
		foreach( $names as $key => $name ) {
			if( ! isset( $subsizes[$key] ) ) {
				continue;
		    }

			$width = $subsizes[$key]['width'] ?? 'n/a';
			$height = $subsizes[$key]['height'] ?? 'n/a';
			$sizes[$key] = $name . ' (' . $width . ' x ' . $height . 'px)';
		}

		$sizes['full'] = __( 'Full', 'wphave' ) . ' (' . __( 'Original Size', 'wphave' ) . ')';

		return $sizes;

	}

endif;
