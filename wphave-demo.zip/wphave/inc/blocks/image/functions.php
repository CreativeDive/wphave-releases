<?php

/**
 * Shared image rendering functions used by blocks and frontend features.
 */

if (!defined('ABSPATH')) {
	exit();
}

if (!function_exists('wphave_block_image_source_id')):
	/**
	 * Resolve the attachment for image blocks in the current render context.
	 * URL sources have no attachment; absent dynamic sources never fall back to a saved custom ID.
	 */
	function wphave_block_image_source_id($type, $image_id, $post_id) {
		if ($type === 'url') {
			return 0;
		}

		if ($type === 'featured') {
			return absint(get_post_thumbnail_id($post_id));
		}

		if ($type === 'loop-item') {
			$loop_post_id = absint($GLOBALS['wphave_loop_post_id'] ?? 0);
			$mime_type = $loop_post_id ? get_post_mime_type($loop_post_id) : '';
			return $loop_post_id &&
				get_post_type($loop_post_id) === 'attachment' &&
				is_string($mime_type) &&
				strpos($mime_type, 'image/') === 0
				? $loop_post_id
				: 0;
		}

		return absint($image_id);
	}
endif;

if (!function_exists('wphave_block_external_image_url')):
	/** Validate an external image URL for HTML attributes or a CSS URL token. */
	function wphave_block_external_image_url($url, $raw = false) {
		if (!is_string($url)) {
			return '';
		}

		return $raw ? esc_url_raw($url) : esc_url($url);
	}
endif;

if (!function_exists('wphave_block_external_image')):
	/** Render an external image once, with escaping at the HTML attribute boundary. */
	function wphave_block_external_image($url, $alt = '', $class = '') {
		$src = wphave_block_external_image_url($url);
		if (!$src) {
			return '';
		}

		$class_attribute = is_string($class) && $class
			? ' class="' . esc_attr(sanitize_html_class($class)) . '"'
			: '';

		return sprintf(
			'<img%s src="%s" alt="%s" loading="lazy" decoding="async">',
			$class_attribute,
			$src,
			esc_attr(sanitize_text_field(is_string($alt) ? $alt : '')),
		);
	}
endif;

if (!function_exists('wphave_image')):
	/**
	 * Return attachment image markup with WPHAVE SVG, pin-button and cache support.
	 *
	 * @param int $attachment_id Attachment ID.
	 * @param string|array $size Registered size slug or dimensions.
	 * @param array $attr Image HTML attributes.
	 * @param array $options WPHAVE output options.
	 * @return string|false Image markup or false when no attachment is available.
	 */

	function wphave_image($attachment_id, $size = '', $attr = [], $options = []) {
		return WPHAVE_Image_Renderer::render($attachment_id, $size, $attr, $options);
	}
endif;

/**
 * Return the alternative text assigned to an attachment.
 *
 * @param int $attachment_id Attachment ID.
 * @return string Attachment alternative text.
 */

if (!function_exists('wphave_image_alt')):
	function wphave_image_alt($attachment_id) {
		return WPHAVE_Image_Renderer::alt($attachment_id);
	}
endif;

if (!function_exists('wphave_image_src')):
	/**
	 * Return an attachment image URL for a registered or custom image size.
	 *
	 * @param int $attachment_id Attachment ID.
	 * @param string|array $size Registered size slug or dimensions.
	 * @return string|false Image URL or false when unavailable.
	 */

	function wphave_image_src($attachment_id, $size = '') {
		return WPHAVE_Image_Renderer::src($attachment_id, $size);
	}
endif;

/**
 * Return placeholder image markup.
 *
 * @param array|string $args Placeholder image arguments.
 * @return string Placeholder image markup.
 */

if (!function_exists('wphave_placeholder_image')):
	function wphave_placeholder_image($args = '') {
		$class = isset($args['class']) ? ' ' . sanitize_html_class($args['class']) : '';

		return '<div class="wphave-site-placeholder"><svg class="wphave-placeholder-image placeholder' .
			esc_attr($class) .
			'" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 373.7 374" role="img" aria-label="' .
			esc_attr__('No Thumbnail', 'wphave') .
			'"><path vector-effect="non-scaling-stroke" d="M187.7 203c8.8 0 16-7.2 16-16s-7.2-16-16-16-16 7.2-16 16 7.2 16 16 16zm-15-66l-9.1 10h-15.9c-5.5 0-10 4.5-10 10v60c0 5.5 4.5 10 10 10h80c5.5 0 10-4.5 10-10v-60c0-5.5-4.5-10-10-10h-15.9l-9.1-10h-30zm15 75c-13.8 0-25-11.2-25-25s11.2-25 25-25 25 11.2 25 25-11.2 25-25 25z" fill="none" /></svg></div>';
	}
endif;

/**
 * Determine whether image markup references an SVG source.
 *
 * @param string $image Image markup.
 * @return bool Whether the source is an SVG image.
 */

if (!function_exists('wphave_is_svg_image')):
	function wphave_is_svg_image($image) {
		if (!is_string($image) || $image === '') {
			return false;
		}

		if (stripos(ltrim($image), '<svg') === 0) {
			return true;
		}

		$processor = new WP_HTML_Tag_Processor($image);
		if (!$processor->next_tag('IMG')) {
			return false;
		}

		$src = $processor->get_attribute('src');
		$path = is_string($src) ? wp_parse_url($src, PHP_URL_PATH) : '';

		return is_string($path) && strtolower(pathinfo($path, PATHINFO_EXTENSION)) === 'svg';
	}
endif;
