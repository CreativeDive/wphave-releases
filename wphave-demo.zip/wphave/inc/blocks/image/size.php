<?php

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Resolve responsive image output settings from current WPHAVE block data.
 */

class WPHAVE_Block_Image_Size {

	/**
	 * Automatic resolutions already read or calculated during this request.
	 *
	 * @var array<string,array>
	 */

	private static array $request_cache = array();

	/**
	 * Resolve the source size and HTML sizes attribute for a block image.
	 *
	 * Explicitly selected image sizes always take precedence. Automatic sizes
	 * use only a concrete pixel width or a known site layout width, then select
	 * the smallest registered WordPress subsize that covers that width.
	 *
	 * @param array $wphave WPHAVE block design attributes.
	 * @param array $args Image and selected size arguments.
	 * @return array Resolved size slug, sizes attribute and estimated width.
	 */

	public static function resolve( $wphave, $args = array() ) {
		$wphave = is_array( $wphave ) ? $wphave : array();
		$args = is_array( $args ) ? $args : array();
		$selected_size = $args['size'] ?? 'auto';

		if( $selected_size && $selected_size !== 'auto' ) {
			return array(
				'size' => $selected_size,
				'sizes' => self::resolve_sizes_attribute( $wphave ),
				'width' => self::resolve_display_width( $wphave ),
			);
		}

		$display_width = self::resolve_display_width( $wphave );
		$display_width = (int) apply_filters( 'wphave_block_image_display_width', $display_width, $wphave, $args );
		$display_width = max( 1, $display_width );
		$attachment_id = absint( $args['image'] ?? 0 );
		$cache_key = ! self::is_full_width( $wphave ) && $attachment_id ? self::resolution_cache_key( $attachment_id, $display_width, $wphave ) : '';

		if( $cache_key && isset( self::$request_cache[$cache_key] ) ) {
			return apply_filters( 'wphave_block_image_size', self::$request_cache[$cache_key], $wphave, $args );
		}

		if( $cache_key ) {
			$cache = WPHAVE_Post_Cache::get_cache() ?: array();
			$cached_resolution = $cache['images'][$cache_key]['resolution'] ?? null;
			if( is_array( $cached_resolution ) ) {
				self::$request_cache[$cache_key] = $cached_resolution;
				return apply_filters( 'wphave_block_image_size', self::$request_cache[$cache_key], $wphave, $args );
			}
		}

		$size = self::is_full_width( $wphave ) ? 'full' : self::find_registered_size( $display_width, $attachment_id );

		$result = array(
			'size' => $size,
			'sizes' => self::resolve_sizes_attribute( $wphave ),
			'width' => $display_width,
		);

		if( $cache_key ) {
			self::$request_cache[$cache_key] = $result;
			if( WPHAVE_Post_Cache::is_enabled() ) {
				add_filter('wphave_post_images', static function ( $images ) use ( $cache_key, $result ) {
					$images = is_array( $images ) ? $images : array();
					$images[$cache_key]['resolution'] = $result;
					return $images;
				}, 10 );
			}
		}

		return apply_filters( 'wphave_block_image_size', $result, $wphave, $args );
	}

	/**
	 * Build a key for attachment-dependent automatic size selection.
	 *
	 * The registered subsize map and relevant global layout values are part of
	 * the key because either can change the selected source without changing the
	 * block itself. Attachment metadata changes invalidate all post image caches
	 * through WPHAVE_Post_Cache.
	 *
	 * @param int $attachment_id Attachment ID.
	 * @param int $display_width Estimated display width.
	 * @param array $wphave WPHAVE block design attributes.
	 * @return string Cache key in the shared post image namespace.
	 */

	private static function resolution_cache_key( $attachment_id, $display_width, $wphave ) {
		return md5( wp_json_encode(array(
			'type' => 'resolution',
			'image' => $attachment_id,
			'displayWidth' => $display_width,
			'wphave' => $wphave,
			'registeredSizes' => wp_get_registered_image_subsizes(),
			'layout' => wphave_data_get( 'site_globals', 'layout', array() ),
			'mobileBreakpoint' => self::mobile_breakpoint(),
			'tabletBreakpoint' => self::tablet_breakpoint(),
		)) );
	}

	/**
	 * Resolve a reliable pixel width or fall back to the configured content width.
	 *
	 * @param array $wphave WPHAVE block design attributes.
	 * @return int Estimated CSS width in pixels.
	 */

	private static function resolve_display_width( $wphave ) {
		$widths = self::responsive_widths( $wphave );
		return max( $widths );
	}

	/**
	 * Resolve the effective desktop, tablet and mobile image widths.
	 *
	 * Device widths inherit from the preceding state. Relative or complex CSS
	 * values use the respective viewport limit instead of being guessed.
	 *
	 * @param array $wphave WPHAVE block design attributes.
	 * @return array Responsive widths keyed by device.
	 */

	private static function responsive_widths( $wphave ) {
		$block_size = $wphave['features']['size'] ?? '';
		if( $block_size === 'wide' ) {
			$desktop_fallback = self::site_layout_width( 'wideWidth', self::content_width() );
		} elseif( $block_size === 'medium' ) {
			$desktop_fallback = self::site_layout_width( 'mediumWidth', self::content_width() );
		} elseif( $block_size === 'narrow' ) {
			$desktop_fallback = self::site_layout_width( 'narrowWidth', self::content_width() );
		} elseif( $block_size === 'content' || $block_size === 'full' ) {
			$desktop_fallback = self::content_width();
		} else {
			$desktop_fallback = self::default_auto_width();
		}

		$desktop = self::state_width( $wphave['dimensions']['width'] ?? array(), $desktop_fallback );
		$tablet_limit = self::tablet_breakpoint() - 1;
		$tablet = self::state_width( $wphave['tablet']['dimensions']['width'] ?? array(), min( $desktop, $tablet_limit ) );
		$mobile_limit = self::mobile_breakpoint() - 1;
		$mobile = self::state_width( $wphave['mobile']['dimensions']['width'] ?? array(), min( $tablet, $mobile_limit ) );

		return array(
			'desktop' => max( 1, $desktop ),
			'tablet' => max( 1, $tablet ),
			'mobile' => max( 1, $mobile ),
		);
	}

	/**
	 * Return a conservative automatic width when the layout is unknown.
	 *
	 * The registered large width mirrors WordPress' established general-purpose
	 * fallback without pretending that the block spans the full content area.
	 *
	 * @return int Conservative automatic width in pixels.
	 */

	private static function default_auto_width() {
		$registered = wp_get_registered_image_subsizes();
		$large_width = (int) ( $registered['large']['width'] ?? 1024 );

		return max( 1, min( $large_width ?: 1024, self::content_width() ) );
	}

	/**
	 * Determine whether WPHAVE knows enough to publish an explicit sizes value.
	 *
	 * @param array $wphave WPHAVE block design attributes.
	 * @return bool Whether the layout width is explicit and reliable.
	 */

	private static function has_reliable_width( $wphave ) {
		if( ! empty( $wphave['features']['size'] ) ) {
			return true;
		}

		$states = array( $wphave, $wphave['tablet'] ?? array(), $wphave['mobile'] ?? array() );
		foreach( $states as $state ) {
			$width = $state['dimensions']['width'] ?? array();
			foreach( array( 'custom', 'min', 'max' ) as $key ) {
				if( self::parse_pixel_width( $width[$key] ?? '' ) ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Resolve all concrete pixel constraints for one responsive state.
	 *
	 * Taking the largest concrete constraint is intentionally conservative: a
	 * min-width may make the rendered block wider than its custom or max width.
	 *
	 * @param mixed $width Device width attributes.
	 * @param int $fallback Inherited or viewport-limited width.
	 * @return int Effective width in pixels.
	 */

	private static function state_width( $width, $fallback ) {
		if( ! is_array( $width ) || ! $width ) {
			return $fallback;
		}

		$pixel_values = array_filter( array_map( array( self::class, 'parse_pixel_width' ), array(
			$width['custom'] ?? '',
			$width['min'] ?? '',
			$width['max'] ?? '',
		) ) );

		return $pixel_values ? max( $pixel_values ) : $fallback;
	}

	/**
	 * Parse an explicit pixel width without guessing relative CSS units.
	 *
	 * @param mixed $width CSS width value.
	 * @return int Pixel estimate, or zero when the value cannot be inferred.
	 */

	private static function parse_pixel_width( $width ) {
		if( ! is_string( $width ) || ! preg_match( '/^([0-9]*\.?[0-9]+)\s*px$/', trim( $width ), $matches ) ) {
			return 0;
		}

		return (int) ceil( (float) $matches[1] );
	}

	/**
	 * Return the content width from the active WPHAVE site globals.
	 *
	 * @return int Content width in pixels.
	 */

	private static function content_width() {
		$fallback = defined( 'WPHAVE_DEFAULT_WIDTH' ) ? WPHAVE_DEFAULT_WIDTH : 1170;
		$width = wphave_data_get( 'site_globals', 'layout.width', $fallback );
		$width = is_numeric( $width ) ? (int) $width : self::parse_pixel_width( $width );

		return max( 1, (int) apply_filters( 'wphave_block_image_content_width', $width ?: $fallback ) );
	}

	/**
	 * Return a configured WPHAVE layout width in pixels.
	 *
	 * @param string $key Site-global layout key.
	 * @param int $fallback Fallback width.
	 * @return int Layout width in pixels.
	 */

	private static function site_layout_width( $key, $fallback ) {
		$width = wphave_data_get( 'site_globals', 'layout.' . $key, $fallback );
		$width = is_numeric( $width ) ? (int) $width : self::parse_pixel_width( $width );

		return $width ?: $fallback;
	}

	/**
	 * Return the active WPHAVE mobile breakpoint.
	 *
	 * @return int Mobile min-width breakpoint in pixels.
	 */

	private static function mobile_breakpoint() {
		$breakpoint = defined( 'WPHAVE_BREAKPOINT_MOBILE' ) ? WPHAVE_BREAKPOINT_MOBILE : 768;

		return max( 1, (int) apply_filters( 'wphave_block_image_mobile_breakpoint', $breakpoint ) );
	}

	/**
	 * Return the active WPHAVE tablet breakpoint.
	 *
	 * @return int Tablet min-width breakpoint in pixels.
	 */

	private static function tablet_breakpoint() {
		$breakpoint = defined( 'WPHAVE_BREAKPOINT_TABLET' ) ? WPHAVE_BREAKPOINT_TABLET : 992;

		return max( self::mobile_breakpoint() + 1, (int) apply_filters( 'wphave_block_image_tablet_breakpoint', $breakpoint ) );
	}

	/**
	 * Determine whether the block explicitly uses the full WPHAVE block size.
	 *
	 * @param array $wphave WPHAVE block design attributes.
	 * @return bool Whether the image spans the viewport.
	 */

	private static function is_full_width( $wphave ) {
		return ( $wphave['features']['size'] ?? '' ) === 'full';
	}

	/**
	 * Select the smallest available registered subsize covering a width.
	 *
	 * @param int $display_width Estimated CSS width.
	 * @param mixed $attachment_id Optional attachment ID used to verify generated sizes.
	 * @return string Registered image size slug or full.
	 */

	private static function find_registered_size( $display_width, $attachment_id ) {
		$registered = wp_get_registered_image_subsizes();
		$metadata = is_numeric( $attachment_id ) ? wp_get_attachment_metadata( (int) $attachment_id ) : array();
		$generated = isset( $metadata['sizes'] ) && is_array( $metadata['sizes'] ) ? $metadata['sizes'] : array();
		$candidates = array();

			foreach( $registered as $name => $data ) {
				$width = (int) ( $data['width'] ?? 0 );
				$is_cropped = ! empty( $data['crop'] );

				// Automatic selection must not change the image composition. Cropped
				// sizes remain available when a user selects their slug explicitly.
				if( ! $width || $is_cropped || ( $generated && ! isset( $generated[$name] ) ) ) {
					continue;
				}
			$candidates[$name] = $width;
		}

		asort( $candidates, SORT_NUMERIC );
		foreach( $candidates as $name => $width ) {
			if( $width >= $display_width ) {
				return $name;
			}
		}

		return 'full';
	}

	/**
	 * Build a browser-facing sizes attribute from the estimated display width.
	 *
	 * @param array $wphave WPHAVE block design attributes.
	 * @return string Responsive sizes attribute.
	 */

	private static function resolve_sizes_attribute( $wphave ) {
		if( ! self::has_reliable_width( $wphave ) ) {
			return '';
		}

		if( self::is_full_width( $wphave ) ) {
			return '100vw';
		}

		$widths = self::responsive_widths( $wphave );
		$mobile_max_width = self::mobile_breakpoint() - 1;
		$tablet_max_width = self::tablet_breakpoint() - 1;

		return '(max-width: ' . $mobile_max_width . 'px) ' . $widths['mobile'] . 'px, (max-width: ' . $tablet_max_width . 'px) ' . $widths['tablet'] . 'px, ' . $widths['desktop'] . 'px';
	}

}
