<?php

/**
 * Inspect registered blocks, serialized block content and rendered WPHAVE output.
 */

class WPHAVE_Block_Inspector {

	/**
	 * Return the support configuration of a registered block.
	 *
	 * @param string $block_name Registered block name.
	 * @return array
	 */

	public static function block_type_support( $block_name ) {

        // Get all registered blocks.
        $reg_blocks = WP_Block_Type_Registry::get_instance()->get_all_registered();

        foreach( $reg_blocks as $reg_block ) {
            if( $block_name !== $reg_block->name ) {
                continue;
            }

            return $reg_block->supports;
        }

        return [];

	}

	/**
	 * Parse the effective content for a post or the current request context.
	 *
	 * @param int|string $post_id Optional post ID.
	 * @return array|false
	 */

	public static function blocks_content( $post_id = '' ) {

        $post_id = $post_id ?: get_the_ID();

        // WooCommerce shop base ID
        // ! Notice: It's neccassry to get block data on the shop base page
        $woo = WPHAVE_WooCommerce::context();
        if( $woo['is_shop'] ) {
            $post_id = WPHAVE_WooCommerce::shop_page_id();
        }

        // Check if exchanged content exists by the "wphave_main_content" filter
        $main_content = apply_filters('wphave_main_content', false, false);

        if( $main_content ) {
            // Get exchanged content
            $post_content = $main_content;
        } else {
            // Get post content
            $post = get_post( $post_id );
            $post_content = isset( $post->post_content ) ? $post->post_content : '';
        }

        // Parse blocks
        if( $post_content ) {
            return parse_blocks( $post_content );
        }

        // Blocks content not found
        return false;

	}

	/**
	 * Determine whether the selected content contains a block.
	 *
	 * @param string $block_name Block name.
	 * @param int|string $post_id Optional post ID.
	 * @param string $content Optional serialized content.
	 * @return bool
	 */

	public static function has_block( $block_name, $post_id = '', $content = '' ) {

        // If we pass the content directly without the post id, we can check if the passed content contains a specific block
        if( ! $post_id && $content ) {
            if( self::content_has_block( $block_name, '', $content ) ) {
                // Block was found
                return true;
            }
        }

        // WooCommerce shop base ID
        // ! Notice: It's neccassry to get block data on the shop base page
        $woo = WPHAVE_WooCommerce::context();
        if( $woo['is_shop'] ) {
            $post_id = WPHAVE_WooCommerce::shop_page_id();

            // WORKAROUND: The default has_block() check dosen't work correct in the case of the shop base page
            // --> Therefore we use our of "has block check", to determine if a block was found
            if( self::content_has_block( $block_name, $post_id ) ) {
                // Block was found
                return true;
            }
        }

        // Parse blocks
        if( $post_id ) {
            //$has_block = has_block( $block_name, $post_id );
            $has_block = self::content_has_block( $block_name, $post_id );
        } else {
            //$has_block = has_block( $block_name );
            $has_block = self::content_has_block( $block_name );
        }

        if( $has_block ) {
            // Block was found
            return true;
        }

        // Block not found
        return false;

	}

	/**
	 * Inspect serialized post content for a block comment.
	 *
	 * @param string $block_name Block name.
	 * @param int|string $post_id Optional post ID.
	 * @param string $post_content Optional serialized content.
	 * @return bool
	 */

	public static function content_has_block( $block_name, $post_id = '', $post_content = '' ) {

        if( ! $post_id ) {
            $post_id = get_the_ID();
        }

        // If no post id and no content passed, we check the content of the current post id
        if( ! $post_content && $post_id ) {
            // Get post content
            $post = get_post( $post_id );
            $post_content = isset( $post->post_content ) ? $post->post_content : '';
        }

        if( wphave_str_contains( $post_content, '<!-- wp:' . $block_name . ' ' ) ) {
            // Block has been found
            return true;
        }

        $serialized_block_name = strip_core_block_namespace( $block_name );
        if ( $serialized_block_name !== $block_name ) {
            if( wphave_str_contains( $post_content, '<!-- wp:' . $serialized_block_name . ' ' ) ) {
                // Block has been found
                return true;
            }
        }

        // Block not found
        return false;

	}

	/**
	 * Return WPHAVE attributes from the first matching top-level block.
	 *
	 * @param string $block_name Block name.
	 * @param int|string $post_id Optional post ID.
	 * @param string $content Optional serialized content.
	 * @return array|null|false
	 */

	public static function block_data( $block_name, $post_id = '', $content = '' ) {

        $blocks = $content ? parse_blocks( $content ) : self::blocks_content( $post_id );

        if( ! $blocks ) {
            // Block not found
            return false;
        }

        foreach( $blocks as $block ) {
            if( $block['blockName'] !== $block_name ) {
                continue;
            }

            if( $block['blockName'] === $block_name ) {
                $attributes = is_array( $block['attrs'] ?? null ) ? $block['attrs'] : array();
                $block_type = WP_Block_Type_Registry::get_instance()->get_registered( $block_name );

                if( $block_type instanceof WP_Block_Type ) {
                    $attributes = $block_type->prepare_attributes_for_render( $attributes );
                }

                if( isset( $attributes['wphave'] ) ) {
                    return $attributes['wphave'];
                }
            }
        }

        return;

	}

	/**
	 * Check the collected rendered block content for a string.
	 *
	 * @param string $string Search expression.
	 * @return bool
	 */

	public static function rendered_content_contains( $string ) {

        $block_content = apply_filters('wphave_load_assets_by_content', $block_content = '');

        preg_match_all('/' . $string . '/Usim', $block_content, $matches);

        foreach( $matches[0] as $match ) {
            if( $match ) {
                return true;
            }
        }

        return false;

	}

	/**
	 * Compare a block context with an expected WPHAVE parent.
	 *
	 * @param string $parent_block_name Expected parent block name.
	 * @param array $context Block context.
	 * @return bool
	 */

	public static function has_parent( $parent_block_name, $context ) {

        // Get the parent block name from $context if provided in block.json [ "providesContext": { "wphave/blockName": "name" } ]
        $context = isset( $context['wphave/blockName'] ) ? $context['wphave/blockName'] : '';

        if( $parent_block_name === $context ) {
            return true;
        }

        return false;

	}

}
