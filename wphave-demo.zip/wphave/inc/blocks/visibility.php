<?php

/**
 * Block visibility helpers shared by server-side block rendering.
 */

if (!defined('ABSPATH')) {
	exit();
}

require_once __DIR__ . '/conditions/evaluator.php';

/**
 * Determine whether the current site-local time matches a visibility range.
 *
 * Invalid configured dates deny access instead of accidentally exposing timed
 * content. All comparisons use the WordPress site timezone.
 *
 * @param string $type Range type: `from`, `until`, or `fromUntil`.
 * @param string $time_start Optional site-local start date.
 * @param string $time_end Optional site-local end date.
 * @return bool Whether the current time matches the range.
 */

if (!function_exists('wphave_time_in_range')):
	function wphave_time_in_range($type, $time_start = '', $time_end = '') {
		return WPHAVE_Block_Conditions::rule_matches(
			[
				'type' => 'schedule',
				'operator' => $type === 'fromUntil' ? 'between' : $type,
				'value' => ['from' => $time_start, 'until' => $time_end],
			],
			[],
			current_datetime()->getTimestamp(),
			wp_timezone(),
		);
	}
endif;
