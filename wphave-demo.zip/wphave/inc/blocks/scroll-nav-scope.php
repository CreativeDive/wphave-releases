<?php

/**
 * Give each rendered synced Component its own Scroll Nav target namespace.
 *
 * The authored target ID remains stable in the reusable block. Only the HTML
 * for a rendered instance receives a scope token. Nested Components keep their
 * own token, and incomplete or ambiguous pairs are left untouched.
 */
final class WPHAVE_Scroll_Nav_Scope {
	public static function annotate( string $html ): string {
		if (
			! str_contains( $html, 'data-wphave-scroll-nav-target' ) ||
			! str_contains( $html, 'data-wphave-scroll-target' )
		) {
			return $html;
		}

		$nav_ids    = array();
		$target_ids = array();
		$tags       = new WP_HTML_Tag_Processor( $html );

		while ( $tags->next_tag() ) {
			if ( null !== $tags->get_attribute( 'data-wphave-scroll-scope' ) ) {
				continue;
			}

			$nav_id = $tags->get_attribute( 'data-wphave-scroll-nav-target' );
			if ( is_string( $nav_id ) && '' !== $nav_id ) {
				$nav_ids[ $nav_id ] = ( $nav_ids[ $nav_id ] ?? 0 ) + 1;
			}

			$target_id = $tags->get_attribute( 'data-wphave-scroll-target' );
			if ( is_string( $target_id ) && '' !== $target_id ) {
				$target_ids[ $target_id ] = ( $target_ids[ $target_id ] ?? 0 ) + 1;
			}
		}

		$pairs = array();
		foreach ( $nav_ids as $id => $count ) {
			if ( $count > 0 && 1 === ( $target_ids[ $id ] ?? 0 ) ) {
				$pairs[ $id ] = true;
			}
		}

		if ( ! $pairs ) {
			return $html;
		}

		$scope = 'component-' . wp_generate_uuid4();
		$tags  = new WP_HTML_Tag_Processor( $html );
		while ( $tags->next_tag() ) {
			if ( null !== $tags->get_attribute( 'data-wphave-scroll-scope' ) ) {
				continue;
			}

			$nav_id    = $tags->get_attribute( 'data-wphave-scroll-nav-target' );
			$target_id = $tags->get_attribute( 'data-wphave-scroll-target' );
			// SCOPE INVARIANT: Only a non-empty authored target ID can acquire
			// this instance's scope. Missing attributes are not array keys.
			if (
				( is_string( $nav_id ) && isset( $pairs[ $nav_id ] ) ) ||
				( is_string( $target_id ) && isset( $pairs[ $target_id ] ) )
			) {
				$tags->set_attribute( 'data-wphave-scroll-scope', $scope );
			}
		}

		return $tags->get_updated_html();
	}
}

add_filter( 'render_block_core/block', array( WPHAVE_Scroll_Nav_Scope::class, 'annotate' ), 20 );
