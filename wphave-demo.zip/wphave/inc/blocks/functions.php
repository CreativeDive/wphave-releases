<?php

require_once __DIR__ . '/conditions/evaluator.php';

/**
 * Build the CSS class list for a WPHAVE block wrapper.
 *
 * The generated classes ensure consistent styling and structure for blocks, while also allowing
 * flexibility for customization through the block editor.
 *
 * @param array $block_args Block data and wrapper options.
 * @return string Space-separated wrapper classes.
 */

if (!function_exists('wphave_block_wrapper_classes')):
	function wphave_block_wrapper_classes($block_args = []) {
		$block = $block_args['block'] ?? [];
		$block_name = $block_args['block_name'] ?? '';
		$prevent_block_classes = $block_args['preventBlockClasses'] ? true : '';

		$classes = [];
		$classes[] = !$prevent_block_classes ? 'wph-b' : '';
		$classes[] = 'wp-block-' . esc_attr(str_replace('/', '-', $block_name));

		// Attribute "Block specific and custom class names"
		$class_names = $block['className'] ?? '';

		if ($class_names && !$prevent_block_classes) {
			$classes[] = $class_names;
		}

		return implode(' ', $classes);
	}
endif;

/**
 * Serialize icon/text/link colors from the platform block-state structure.
 *
 * Navigation presentation states map onto WPHAVE state types: current uses
 * selected and open uses active. Empty values are omitted so CSS custom-
 * property inheritance remains intact.
 *
 * @param array  $wphave Block attributes.
 * @param string $prefix CSS custom-property prefix without trailing dash.
 * @return string CSS custom-property declarations, or an empty string.
 */

if (!function_exists('wphave_interaction_color_style_properties')):
	function wphave_interaction_color_style_properties($wphave, $prefix) {
		$states = [
			'default' => null,
			'hover' => 'hover',
			'focus' => 'focus',
			'current' => 'selected',
			'open' => 'active',
		];
		$properties = '';

		foreach ($states as $state => $state_type) {
			$state_data = null === $state_type ? $wphave : $wphave[$state_type] ?? [];
			$state_colors = is_array($state_data['settings']['colors'] ?? null)
				? $state_data['settings']['colors']
				: [];
			$suffix = 'default' === $state ? '' : '-' . $state;
			foreach (['icon', 'text', 'link'] as $color_type) {
				if (!empty($state_colors[$color_type])) {
					$properties .=
						'--' .
						sanitize_key($prefix) .
						'-' .
						$color_type .
						'-color' .
						$suffix .
						':' .
						esc_attr($state_colors[$color_type]) .
						';';
				}
			}
		}

		return $properties;
	}
endif;

/**
 * Wrap interaction color properties in an inline style attribute.
 *
 * @param array  $wphave Block attributes.
 * @param string $prefix CSS custom-property prefix without trailing dash.
 * @return string Inline style attribute fragment, or an empty string.
 */

if (!function_exists('wphave_interaction_color_style_attribute')):
	function wphave_interaction_color_style_attribute($wphave, $prefix) {
		$properties = wphave_interaction_color_style_properties($wphave, $prefix);

		return $properties ? 'style="' . $properties . '"' : '';
	}
endif;

/**
 * Normalize manually configured WPHAVE class names.
 *
 * Dot prefixes, whitespace, duplicates, and invalid class-name characters are
 * removed before the values reach wrapper output.
 *
 * @param array $wphave WPHAVE block settings.
 * @return array Normalized unique class names.
 */

if (!function_exists('wphave_block_manual_class_names_from_wphave')):
	function wphave_block_manual_class_names_from_wphave($wphave) {
		$class_names = $wphave['features']['classes']['manual'] ?? [];

		if (!is_array($class_names)) {
			$class_names = [$class_names];
		}

		$output = [];

		foreach ($class_names as $class_name) {
			$items = preg_split('/\s+/', (string) $class_name);

			foreach ($items as $item) {
				$item = ltrim(trim($item), '.');
				$item = sanitize_html_class($item);

				if ($item) {
					$output[$item] = $item;
				}
			}
		}

		return array_values($output);
	}
endif;

/**
 * Determine block access from schedule and user-role conditions.
 *
 * Editor requests always retain access so restricted blocks remain editable.
 *
 * @param array $wphave WPHAVE block settings.
 * @return bool Whether the block may be rendered.
 */

if (!function_exists('wphave_allow_block_access')):
	function wphave_allow_block_access($wphave) {
		if (is_admin()) {
			// The content is always visible in the editor
			return true;
		}

		return wphave_match_block_conditions($wphave['conditions'] ?? []);
	}
endif;

/** Evaluate a complete rule against the current visitor and website clock. */
if (!function_exists('wphave_evaluate_block_condition_rule')):
	function wphave_evaluate_block_condition_rule($rule) {
		return is_array($rule) &&
			WPHAVE_Block_Conditions::rule_matches(
				$rule,
				is_user_logged_in() ? (array) wp_get_current_user()->roles : [],
				current_datetime()->getTimestamp(),
				wp_timezone(),
				is_user_logged_in(),
			);
	}
endif;

/** Stored conditions remain effective regardless of editor rollout and Pro entitlement. */
if (!function_exists('wphave_match_block_conditions')):
	function wphave_match_block_conditions($conditions) {
		return WPHAVE_Block_Conditions::matches(
			$conditions,
			is_user_logged_in() ? (array) wp_get_current_user()->roles : [],
			current_datetime()->getTimestamp(),
			wp_timezone(),
			is_user_logged_in(),
		);
	}
endif;

/**
 * Register a block's complex mask shape for deferred SVG output.
 *
 * Registered clip paths are emitted in the footer by
 * `wphave_output_block_clip_path_html()`.
 *
 * @param array $base Block base-style settings.
 * @return void
 */

if (!function_exists('wphave_call_block_clip_path_masks')):
	function wphave_call_block_clip_path_masks($base = []) {
		$mask_complex_shape = $base['mask']['complex']['shapes'] ?? '';

		if ($mask_complex_shape) {
			wphave_clip_path_shape([
				'name' => $mask_complex_shape,
				//'icon' => $mask_complex_icon,
			]);
		}
	}
endif;
