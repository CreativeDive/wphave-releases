<?php

if (!defined('ABSPATH')) {
	exit();
}

/** Tracks time-dependent output, including currently hidden blocks and reusable content. */
final class WPHAVE_Block_Conditions_Runtime {
	private static bool $scheduled = false;

	public static function observe(array $block): array {
		if (WPHAVE_Block_Conditions::has_schedule($block['attrs']['wphave']['conditions'] ?? [])) {
			self::$scheduled = true;
			// Also tell third-party page caches that this response is dynamic.
			if (!defined('DONOTCACHEPAGE')) {
				define('DONOTCACHEPAGE', true);
			}
			if (!headers_sent() && !is_admin()) {
				// Append revalidation without replacing an existing private/no-store directive.
				header('Cache-Control: no-cache, max-age=0, must-revalidate', false);
				header('X-WPHAVE-Scheduled-Blocks: 1');
			}
		}
		return $block;
	}

	/** A value-free marker also reaches static exporters when a scheduled block is hidden. */
	public static function annotate($content, array $block): string {
		return WPHAVE_Block_Conditions::has_schedule($block['attrs']['wphave']['conditions'] ?? [])
			? '<!-- wphave:scheduled-block -->' . $content
			: (string) $content;
	}

	public static function has_scheduled_output(): bool {
		return self::$scheduled;
	}
}
