<?php

if (!defined('ABSPATH')) {
	exit();
}

/** Keeps stored condition settings read-only after a Pro downgrade, across post write APIs. */
final class WPHAVE_Block_Conditions_Persistence {
	/** Index stored blocks by durable identity, with a structural fallback for pre-release content. */
	private static function index(array $blocks, string $path = ''): array {
		$result = [];
		foreach ($blocks as $offset => $block) {
			$key = $path . '/' . $offset;
			$attrs = $block['attrs']['wphave'] ?? [];
			$entry = ['name' => $block['blockName'], 'attrs' => $attrs];
			$result['path:' . $key] = $entry;
			$id = $attrs['conditionsId'] ?? null;
			if (is_string($id) && $id !== '' && !isset($result['id:' . $id])) {
				$result['id:' . $id] = $entry;
			}
			$result += self::index($block['innerBlocks'] ?? [], $key);
		}
		return $result;
	}

	/** Reordering follows stored IDs. Deleting a block remains possible; its rules are not recreated. */
	public static function reconcile(array $blocks, array $stored, bool $can_edit): array {
		$seen = [];
		return self::walk($blocks, self::index($stored), $can_edit, $seen);
	}

	private static function walk(
		array $blocks,
		array $stored,
		bool $can_edit,
		array &$seen,
		string $path = '',
	): array {
		foreach ($blocks as $offset => &$block) {
			$key = $path . '/' . $offset;
			if (str_starts_with((string) ($block['blockName'] ?? ''), 'wphave/')) {
				$attrs = is_array($block['attrs']['wphave'] ?? null)
					? $block['attrs']['wphave']
					: [];
				$id = is_string($attrs['conditionsId'] ?? null) ? $attrs['conditionsId'] : '';
				$previous =
					($id !== '' ? $stored['id:' . $id] ?? null : null) ??
					($stored['path:' . $key] ?? null);
				if (!$can_edit) {
					unset($attrs['conditions'], $attrs['conditionsId']);
					if (
						$previous &&
						$previous['name'] === $block['blockName'] &&
						array_key_exists('conditions', $previous['attrs'])
					) {
						$attrs['conditions'] = $previous['attrs']['conditions'];
						$attrs['conditionsId'] =
							$previous['attrs']['conditionsId'] ?? wp_generate_uuid4();
					}
				}
				// Identify unrestricted siblings too, so deletion/reordering cannot transfer rules.
				$identity = $attrs['conditionsId'] ?? ($previous['attrs']['conditionsId'] ?? $id);
				$attrs['conditionsId'] =
					$identity && !isset($seen[$identity]) ? $identity : wp_generate_uuid4();
				$seen[$attrs['conditionsId']] = true;
				if ($attrs || isset($block['attrs']['wphave'])) {
					$block['attrs']['wphave'] = $attrs;
				}
			}
			$block['innerBlocks'] = self::walk(
				$block['innerBlocks'] ?? [],
				$stored,
				$can_edit,
				$seen,
				$key,
			);
		}
		unset($block);
		return $blocks;
	}

	public static function protect(array $data, array $postarr): array {
		$content = wp_unslash($data['post_content'] ?? '');
		$id = (int) ($postarr['ID'] ?? 0);
		if (!$id && 'revision' === ($data['post_type'] ?? '')) {
			$id = (int) ($postarr['post_parent'] ?? 0);
		}
		$previous = $id ? (string) get_post_field('post_content', $id, 'raw') : '';
		if (!str_contains($content, '"conditions"') && !str_contains($previous, '"conditions"')) {
			return $data;
		}
		$blocks = parse_blocks($content);
		$next = self::reconcile(
			$blocks,
			parse_blocks($previous),
			function_exists('wphave_has_pro_access') && wphave_has_pro_access(),
		);
		if ($next !== $blocks) {
			$data['post_content'] = wp_slash(serialize_blocks($next));
		}
		return $data;
	}
}
