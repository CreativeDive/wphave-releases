<?php

if (!defined('ABSPATH')) {
	exit();
}

/** Read an active, explicitly stored Content Field from the rendered content only. */
final class WPHAVE_Block_Condition_Content_Field {
	private const SCALAR_TYPES = [
		'text', 'textarea', 'number', 'select', 'radio', 'toggle', 'url', 'email',
		'date', 'datetime', 'post_reference', 'term_reference', 'user_reference',
		'image', 'file',
	];
	private const MULTIPLE_TYPES = ['multi_select', 'checkbox_group'];
	/** @var int[] Explicit content identities while nested Template Parts render. */
	private static array $render_context = [];

	public static function with_render_context(int $post_id, callable $render): mixed {
		self::$render_context[] = $post_id > 0 ? $post_id : 0;
		try {
			return $render();
		} finally {
			array_pop(self::$render_context);
		}
	}

	/** A Loop item overrides the containing Template Part's content identity. */
	public static function rendered_post_id(int $candidate): int {
		if (!self::$render_context || $candidate <= 0) {
			return $candidate;
		}
		$post_type = get_post_type($candidate);
		return in_array($post_type, ['wphave-template-part', 'wphave-templates'], true)
			? end(self::$render_context)
			: $candidate;
	}

	public static function reader($post_id): callable {
		$post_id = is_int($post_id) && $post_id > 0 ? $post_id : 0;

		return static function (string $field_key) use ($post_id): string|array|null {
			if (
				!$post_id ||
				!function_exists('wphave_content_models_feature_enabled') ||
				!wphave_content_models_feature_enabled() ||
				!class_exists('WPHAVE_Content_Model_Registry') ||
				!class_exists('WPHAVE_Content_Model_Value_Repository')
			) {
				return null;
			}

			$post = get_post($post_id);
			if (!$post || 'publish' !== $post->post_status) {
				return null;
			}

			$field = WPHAVE_Content_Model_Registry::field($post->post_type, $field_key);
			$type = $field['type'] ?? null;
			if (
				!in_array($type, self::SCALAR_TYPES, true) &&
				!in_array($type, self::MULTIPLE_TYPES, true)
			) {
				return null;
			}
			$meta_key = WPHAVE_Content_Model_Value_Repository::meta_key($field_key);
			if (!metadata_exists('post', $post_id, $meta_key)) {
				return null;
			}
			$raw_value = get_post_meta($post_id, $meta_key, true);
			if ('toggle' === $type && !in_array($raw_value, ['1', '0'], true)) {
				return null;
			}

			$value = WPHAVE_Content_Model_Value_Repository::get($post, $field_key, false);
			if ('toggle' === $type) {
				return in_array($value, ['1', '0'], true) ? $value : null;
			}
			if (in_array($type, self::MULTIPLE_TYPES, true)) {
				if (
					!is_string($raw_value) ||
					!is_string($value) ||
					$raw_value !== $value ||
					strlen($value) > 16384
				) {
					return null;
				}
				$values = json_decode($value, true);
				return JSON_ERROR_NONE === json_last_error() && is_array($values) && array_is_list($values) &&
					count($values) <= 200 &&
					!array_filter($values, static fn($item) => !is_string($item)) &&
					count($values) === count(array_unique($values, SORT_STRING))
					? $values
					: null;
			}
			return is_string($value) && '' !== $value ? $value : null;
		};
	}

	/** Compare a rule using the active field contract after the fail-closed read. */
	public static function matcher(int $post_id): callable {
		$read = self::reader($post_id);
		return static function (string $field_key, string $operator, string $expected) use ($post_id, $read): bool {
			$actual = $read($field_key);
			if (null === $actual) {
				return false;
			}
			if ('contains' === $operator) {
				return is_array($actual) && in_array($expected, $actual, true);
			}
			if ('is' !== $operator || !is_string($actual)) {
				return false;
			}
			$post = get_post($post_id);
			$field = $post ? WPHAVE_Content_Model_Registry::field($post->post_type, $field_key) : null;
			$type = $field['type'] ?? null;
			if (in_array($type, ['number', 'datetime'], true)) {
				if (!class_exists('WPHAVE_Content_Model_Field_Type_Registry')) {
					return false;
				}
				$expected = WPHAVE_Content_Model_Field_Type_Registry::sanitize($type, $expected, $field);
			}
			return '' !== $expected && $actual === $expected;
		};
	}
}
