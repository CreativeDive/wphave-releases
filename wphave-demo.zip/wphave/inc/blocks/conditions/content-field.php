<?php

if (!defined('ABSPATH')) {
	exit();
}

/** Read an active single-choice Content Field from the rendered content only. */
final class WPHAVE_Block_Condition_Content_Field {
	/** @var int[] Explicit content identities while nested Template Parts render. */
	private static array $render_context = [];

	public static function with_render_context(int $post_id, callable $render): mixed {
		self::$render_context[] = $post_id > 0 ? $post_id : 0;
		try {
			return $render();
		} finally {
			array_pop(self::$render_context);
		}
	}

	/** A Loop item overrides the containing Template Part's content identity. */
	public static function rendered_post_id(int $candidate): int {
		if (!self::$render_context || $candidate <= 0) {
			return $candidate;
		}
		$post_type = get_post_type($candidate);
		return in_array($post_type, ['wphave-template-part', 'wphave-templates'], true)
			? end(self::$render_context)
			: $candidate;
	}

	public static function reader($post_id): callable {
		$post_id = is_int($post_id) && $post_id > 0 ? $post_id : 0;

		return static function (string $field_key) use ($post_id): ?string {
			if (
				!$post_id ||
				!function_exists('wphave_content_models_feature_enabled') ||
				!wphave_content_models_feature_enabled() ||
				!class_exists('WPHAVE_Content_Model_Registry') ||
				!class_exists('WPHAVE_Content_Model_Value_Repository')
			) {
				return null;
			}

			$post = get_post($post_id);
			if (!$post || 'publish' !== $post->post_status) {
				return null;
			}

			$field = WPHAVE_Content_Model_Registry::field($post->post_type, $field_key);
			if (!in_array($field['type'] ?? null, ['select', 'radio'], true)) {
				return null;
			}

			$value = WPHAVE_Content_Model_Value_Repository::get($post, $field_key, false);
			return is_string($value) && '' !== $value ? $value : null;
		};
	}
}
