<?php

if (!defined('ABSPATH')) {
	exit();
}

require_once __DIR__ . '/evaluator.php';

/** Shared visibility boundary for secondary block outputs, never editor bypasses. */
final class WPHAVE_Block_Projection {
	private static int $public_render_depth = 0;

	public static function visible(array $settings, bool $public = true): bool {
		if (($settings['visibility']['visually'] ?? 'visible') === 'hidden') {
			return false;
		}
		// Nested dynamic text resolution cannot inherit editor roles during public FAQ export.
		$logged_in = !$public && self::$public_render_depth === 0 && is_user_logged_in();
		return WPHAVE_Block_Conditions::matches(
			$settings['conditions'] ?? [],
			$logged_in ? (array) wp_get_current_user()->roles : [],
			current_datetime()->getTimestamp(),
			wp_timezone(),
			$logged_in,
		);
	}

	public static function allows(array $block, bool $public = true): bool {
		$settings = $block['attrs']['wphave'] ?? [];
		return self::visible(is_array($settings) ? $settings : [], $public);
	}

	/** FAQ needs actual rendering; keep this extra anonymous boundary strictly scoped. */
	public static function render_public(array $blocks): string {
		$filter = static function ($previous, array $block) {
			return self::allows($block) ? $previous : '';
		};
		add_filter('pre_render_block', $filter, PHP_INT_MAX, 2);
		self::$public_render_depth++;
		try {
			return do_blocks(serialize_blocks($blocks));
		} finally {
			// INVARIANT: neither successful output nor renderer failures affect later rendering.
			remove_filter('pre_render_block', $filter, PHP_INT_MAX);
			self::$public_render_depth--;
		}
	}

	/** Project saved text without executing dynamic blocks or recursively rendering excerpts. */
	public static function text(array $blocks, bool $public = true): string {
		$parts = [];
		foreach ($blocks as $block) {
			// INVARIANT: a denied parent removes its complete subtree, before reading text.
			if (!self::allows($block, $public)) {
				continue;
			}
			if (!empty($block['innerBlocks'])) {
				$parts[] = self::text($block['innerBlocks'], $public);
				continue;
			}
			$name = $block['blockName'] ?? null;
			if (
				in_array(
					$name,
					[
						'wphave/paragraph',
						'wphave/heading',
						'wphave/button',
						'wphave/accordion-title',
					],
					true,
				)
			) {
				$parts[] = (string) ($block['attrs']['content'] ?? '');
			} elseif (
				$name === null ||
				in_array(
					$name,
					[
						'core/paragraph',
						'core/heading',
						'core/list-item',
						'core/list',
						'core/quote',
						'core/pullquote',
						'core/preformatted',
						'core/verse',
						'core/code',
						'core/table',
						'core/freeform',
						'core/html',
					],
					true,
				)
			) {
				$parts[] = (string) ($block['innerHTML'] ?? '');
			}
			// Unknown/dynamic leaf blocks have no safe automatic text projection.
		}
		return trim(wp_strip_all_tags(strip_shortcodes(implode(' ', $parts))));
	}

	public static function excerpt(int $post_id, bool $public = true): string {
		$post = $post_id > 0 ? get_post($post_id) : null;
		if (!$post) {
			return '';
		}
		// Public export never inherits viewer access; local text still requires the
		// normal post/password boundary before consulting manual or automatic text.
		if ($public && ($post->post_password !== '' || !is_post_publicly_viewable($post))) {
			return '';
		}
		if (
			!$public &&
			(post_password_required($post) ||
				(!is_post_publicly_viewable($post) && !current_user_can('read_post', $post_id)))
		) {
			return '';
		}

		// Explicit excerpts are authored summaries. Automatic summaries use only permitted
		// saved text; an empty projection MUST NOT fall back to unfiltered post_content.
		return $post->post_excerpt !== ''
			? wp_strip_all_tags(strip_shortcodes($post->post_excerpt))
			: self::text(parse_blocks($post->post_content), $public);
	}
}
