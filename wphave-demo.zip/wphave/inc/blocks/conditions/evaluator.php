<?php

if (!defined('ABSPATH')) {
	exit();
}

/** Pure visitor/time rule contract; release readiness and entitlement never disable stored rules. */
final class WPHAVE_Block_Conditions {
	const MAX_RULES = 50;

	/** Parse an absolute calendar date. Local dates belong to the website timezone. */
	public static function timestamp($value, DateTimeZone $timezone): ?int {
		if (
			!is_string($value) ||
			!preg_match(
				'/^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(?::\d{2}(?:\.\d{1,3})?)?(?:Z|[+-]\d{2}:\d{2})?$/D',
				$value,
			)
		) {
			return null;
		}
		try {
			$date = new DateTimeImmutable($value, $timezone);
			$errors = DateTimeImmutable::getLastErrors();
			if ($errors && ($errors['warning_count'] || $errors['error_count'])) {
				return null;
			}
			// Reject calendar normalization, including nonexistent local times during DST jumps.
			if ($date->format('Y-m-d H:i') !== str_replace('T', ' ', substr($value, 0, 16))) {
				return null;
			}
			$timestamp = $date->getTimestamp();
			if (!preg_match('/(?:Z|[+-]\d{2}:\d{2})$/D', $value)) {
				// Repeated wall-clock times consistently use their first occurrence.
				foreach ([-7200, -3600, -1800] as $offset) {
					$candidate = $date->setTimestamp($date->getTimestamp() + $offset);
					if ($candidate->format('Y-m-d H:i:s') === $date->format('Y-m-d H:i:s')) {
						$timestamp = min($timestamp, $candidate->getTimestamp());
					}
				}
			}
			return $timestamp;
		} catch (Exception $error) {
			return null;
		}
	}

	/** Return a stable validation code, or null for a complete supported rule. */
	public static function rule_error($rule, DateTimeZone $timezone): ?string {
		if (!is_array($rule)) {
			return 'invalid_rule';
		}
		$type = $rule['type'] ?? null;
		$operator = $rule['operator'] ?? null;
		$value = $rule['value'] ?? null;
		if ('login' === $type) {
			return 'is' === $operator && in_array($value, ['guest', 'logged-in'], true)
				? null
				: 'login_required';
		}
		if ('role' === $type) {
			if ('in' !== $operator || !is_array($value) || !array_is_list($value) || !$value) {
				return 'roles_required';
			}
			foreach ($value as $role) {
				if (!is_string($role) || !preg_match('/^[a-z0-9_-]+$/D', $role)) {
					return 'invalid_role';
				}
			}
			return null;
		}
		if (
			'schedule' !== $type ||
			!in_array($operator, ['from', 'until', 'between'], true) ||
			!is_array($value)
		) {
			return 'invalid_rule';
		}
		$from = self::timestamp($value['from'] ?? null, $timezone);
		$until = self::timestamp($value['until'] ?? null, $timezone);
		if (in_array($operator, ['from', 'between'], true) && null === $from) {
			return 'start_required';
		}
		if (in_array($operator, ['until', 'between'], true) && null === $until) {
			return 'end_required';
		}
		return 'between' === $operator && $until < $from ? 'reversed_range' : null;
	}

	public static function rule_matches(
		array $rule,
		array $roles,
		int $now,
		DateTimeZone $timezone,
		?bool $logged_in = null,
	): bool {
		if (null !== self::rule_error($rule, $timezone)) {
			return false;
		}
		if ('login' === $rule['type']) {
			return null !== $logged_in && $logged_in === ('logged-in' === $rule['value']);
		}
		if ('role' === $rule['type']) {
			return (bool) array_intersect($rule['value'], $roles);
		}
		$operator = $rule['operator'];
		$value = $rule['value'];
		return ('until' === $operator || $now >= self::timestamp($value['from'], $timezone)) &&
			('from' === $operator || $now <= self::timestamp($value['until'], $timezone));
	}

	/** Empty configuration is unrestricted; a malformed configured group denies output. */
	public static function matches(
		$conditions,
		array $roles,
		int $now,
		DateTimeZone $timezone,
		?bool $logged_in = null,
	): bool {
		if (null === $conditions || [] === $conditions) {
			return true;
		}
		if (
			!is_array($conditions) ||
			!in_array($conditions['match'] ?? 'all', ['all', 'any'], true)
		) {
			return false;
		}
		$rules = $conditions['rules'] ?? [];
		if (!is_array($rules) || !array_is_list($rules) || count($rules) > self::MAX_RULES) {
			return false;
		}
		$results = [];
		foreach ($rules as $rule) {
			if (null !== self::rule_error($rule, $timezone)) {
				return false;
			}
			$results[] = self::rule_matches($rule, $roles, $now, $timezone, $logged_in);
		}
		if (!$results) {
			return true;
		}
		return 'any' === ($conditions['match'] ?? 'all')
			? in_array(true, $results, true)
			: !in_array(false, $results, true);
	}

	public static function has_schedule($conditions): bool {
		foreach (is_array($conditions['rules'] ?? null) ? $conditions['rules'] : [] as $rule) {
			if (is_array($rule) && 'schedule' === ($rule['type'] ?? null)) {
				return true;
			}
		}
		return false;
	}
}
