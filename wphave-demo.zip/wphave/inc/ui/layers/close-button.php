<?php

/**
 * Shared close-button output for WPHAVE frontend UI layers.
 */

if( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Render the shared close button used by frontend overlays.
 *
 * @param array $args Optional button configuration.
 * @return string Close button markup.
 */

if ( ! function_exists( 'wphave_close_button' ) ) :

	function wphave_close_button( $args = [] ) {
		$args = wp_parse_args( $args, [
			'label' => __( 'Close', 'wphave' ),
			'class' => '',
			'attributes' => [],
		] );
		$label = sanitize_text_field( $args['label'] );
		$classes = preg_split( '/\s+/', trim( 'wphave-close-button ' . $args['class'] ) );
		$class = implode( ' ', array_filter( array_map( 'sanitize_html_class', $classes ) ) );
		$attributes = '';

		foreach( is_array( $args['attributes'] ) ? $args['attributes'] : [] as $name => $value ) {
			if( ! is_string( $name ) || ! preg_match( '/^data-[a-z0-9-]+$/', $name ) ) {
				continue;
			}

			$attributes .= $value === true || $value === '' ? ' ' . $name : sprintf( ' %s="%s"', $name, esc_attr( $value ) );
		}

		$button = sprintf(
			'<button type="button" class="%1$s"%2$s aria-label="%3$s" data-tooltip="%3$s">%4$s</button>',
			esc_attr( $class ),
			$attributes,
			esc_attr( $label ),
			wphave_svg_ui_icon( 'close', [ 'inline' => true ] )
		);

		return apply_filters( 'wphave_close_button', $button, $args );
	}

endif;
