<?php

/**
 * Shared modal, side-panel and popover rendering for WPHAVE frontend UI layers.
 */

if (!defined('ABSPATH')) {
    exit();
}

/**
 * Sanitize a whitespace-separated list of frontend layer classes.
 *
 * @param string $classes Class list.
 * @return string Sanitized class list.
 */

if (!function_exists('wphave_layer_class_names')):
    function wphave_layer_class_names($classes) {
        $classes = preg_split('/\s+/', trim((string) $classes));
        return implode(' ', array_filter(array_map('sanitize_html_class', $classes)));
    }
endif;

/**
 * Resolve layer content from markup or a rendering callback.
 *
 * String content may come from integrations and is therefore sanitized.
 * Callbacks are an explicit trusted-renderer boundary used by WPHAVE and
 * third-party integrations that need to output complete form markup.
 *
 * @param callable|string $content Content or trusted rendering callback.
 * @return string Rendered layer content.
 */

if (!function_exists('wphave_render_layer_content')):
    function wphave_render_layer_content($content) {
        // LAYER CONTENT INVARIANT: Persisted block text is data even if it
        // happens to name a PHP function. Only a non-string callable supplied
        // explicitly by trusted PHP code may execute while rendering a layer.
        if (is_string($content) || !is_callable($content)) {
            return wp_kses_post((string) $content);
        }

        ob_start();
        call_user_func($content);
        return ob_get_clean();
    }
endif;

/**
 * Render an accessible frontend side panel.
 *
 * @param array           $args    Side panel configuration.
 * @param callable|string $content Side panel content or trusted callback.
 * @return string Side panel markup or an empty string for an invalid ID.
 */

if (!function_exists('wphave_render_side_panel')):
    function wphave_render_side_panel($args = [], $content = '') {
        $args = wp_parse_args($args, [
            'id' => '',
            'label' => '',
            'labelledby' => '',
            'class' => '',
            'wrapper_class' => '',
            'direction' => 'right',
        ]);
        $args = apply_filters('wphave_side_panel_args', $args);
        $id = sanitize_html_class($args['id']);

        if (!$id) {
            return '';
        }

        $direction = in_array($args['direction'], ['left', 'right'], true)
            ? $args['direction']
            : 'right';
        $panel_class = wphave_layer_class_names(
            trim('wphave-side-panel-layer from-' . $direction . ' ' . $args['class']),
        );
        $wrapper_class = wphave_layer_class_names(
            trim('wphave-side-panel-layer-wrapper ' . $args['wrapper_class']),
        );
        $labelledby = sanitize_html_class($args['labelledby']);
        $label = sanitize_text_field($args['label']);
        $content = wphave_render_layer_content($content);

        ob_start();
        ?>
		<div class="<?php echo esc_attr(
      $panel_class,
  ); ?>" data-panel-id="<?php echo esc_attr($id); ?>" id="<?php echo esc_attr($id); ?>" role="dialog" aria-modal="true"<?php if ($labelledby) { ?> aria-labelledby="<?php echo esc_attr($labelledby); ?>"<?php } elseif ($label) { ?> aria-label="<?php echo esc_attr($label); ?>"<?php } ?> aria-hidden="true" hidden>
			<?php echo wphave_close_button([
       'class' => 'wphave-side-panel-layer-close',
       'attributes' => ['data-panel-close' => true],
   ]); ?>
			<div class="<?php echo esc_attr($wrapper_class); ?>">
				<?php echo $content;// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Trusted renderer or pre-sanitized side panel content.
        ?>
			</div>
		</div>
		<?php
  $panel = ob_get_clean();

  return apply_filters('wphave_side_panel_html', $panel, $args, $content);
    }
endif;

/**
 * Render an accessible frontend popover.
 *
 * Set args.portal to true to move the open layer outside clipped ancestors.
 * The runtime uses the nearest modal as its host, or the document body, and
 * restores the original node position when the layer closes or unmounts.
 *
 * @param array           $args    Popover configuration.
 * @param callable|string $content Popover content or trusted callback.
 * @return string Popover markup or an empty string for an invalid ID.
 */

if (!function_exists('wphave_render_popover')):
    function wphave_render_popover($args = [], $content = '') {
        $args = wp_parse_args($args, [
            'id' => '',
            'label' => '',
            'labelledby' => '',
            'class' => '',
            'content_class' => '',
            'portal' => false,
        ]);
        $args = apply_filters('wphave_popover_args', $args);
        $id = sanitize_html_class($args['id']);

        if (!$id) {
            return '';
        }

        $popover_class = wphave_layer_class_names(trim('wphave-popover-layer ' . $args['class']));
        $content_class = wphave_layer_class_names(
            trim('wphave-popover-layer-content ' . $args['content_class']),
        );
        $labelledby = sanitize_html_class($args['labelledby']);
        $label = sanitize_text_field($args['label']);
        $content = wphave_render_layer_content($content);

        ob_start();
        ?>
		<div class="<?php echo esc_attr(
      $popover_class,
  ); ?>" data-popover-id="<?php echo esc_attr($id); ?>" id="<?php echo esc_attr($id); ?>"<?php if ($args['portal'] === true) { ?> data-popover-portal="true"<?php } ?> role="dialog"<?php if ($labelledby) { ?> aria-labelledby="<?php echo esc_attr($labelledby); ?>"<?php } elseif ($label) { ?> aria-label="<?php echo esc_attr($label); ?>"<?php } ?> aria-hidden="true" hidden>
			<div class="<?php echo esc_attr($content_class); ?>">
				<?php echo $content;// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Trusted renderer or pre-sanitized popover content.
        ?>
			</div>
			<div class="wphave-popover-layer-arrow" aria-hidden="true"></div>
		</div>
		<?php
  $popover = ob_get_clean();

  return apply_filters('wphave_popover_html', $popover, $args, $content);
    }
endif;

/**
 * Render an accessible frontend modal shell.
 *
 * @param array           $args    Modal configuration.
 * @param callable|string $content Modal content or trusted callback.
 * @return string Modal markup or an empty string for an invalid ID.
 */

if (!function_exists('wphave_render_modal')):
    function wphave_render_modal($args = [], $content = '') {
        $args = wp_parse_args($args, [
            'id' => '',
            'html_id' => '',
            'label' => '',
            'labelledby' => '',
            'describedby' => '',
            'class' => '',
            'wrapper_class' => '',
            'content_class' => '',
            'variant' => 'default',
        ]);

        $args = apply_filters('wphave_modal_args', $args);
        $id = sanitize_html_class($args['id']);

        if (!$id) {
            return '';
        }

        $variant = in_array($args['variant'], ['default', 'bare', 'panel'], true)
            ? $args['variant']
            : 'default';
        $modal_class = wphave_layer_class_names(
            trim(
                'wphave-modal-layer ' .
                    $args['class'] .
                    ($variant !== 'default' ? ' is-' . $variant : ''),
            ),
        );
        $wrapper_class = wphave_layer_class_names(
            trim('wphave-modal-layer-wrapper ' . $args['wrapper_class']),
        );
        $content_class = wphave_layer_class_names(
            trim('wphave-modal-layer-content ' . $args['content_class']),
        );
        $labelledby = sanitize_html_class($args['labelledby']);
        $describedby = sanitize_html_class($args['describedby']);
        $label = sanitize_text_field($args['label']);
        $html_id = sanitize_html_class($args['html_id'] ?: $id);
        $content = wphave_render_layer_content($content);

        ob_start();
        ?>
		<?php // A neutral div accepts the dialog role; aside only permits complementary landmark semantics.
        ?>
		<div class="<?php echo esc_attr(
      $modal_class,
  ); ?>" data-modal-id="<?php echo esc_attr($id); ?>" role="dialog" aria-modal="true"<?php
if ($labelledby) { ?> aria-labelledby="<?php echo esc_attr($labelledby); ?>"<?php } elseif (
    $label
) { ?> aria-label="<?php echo esc_attr($label); ?>"<?php }
if ($describedby) { ?> aria-describedby="<?php echo esc_attr($describedby); ?>"<?php }
?> aria-hidden="true" id="<?php echo esc_attr($html_id); ?>" hidden>
			<?php echo wphave_close_button([
       'class' => 'wphave-modal-close',
       'attributes' => ['data-modal-close' => true],
   ]); ?>
			<div class="<?php echo esc_attr($wrapper_class); ?>">
				<?php if ($variant === 'default') { ?><div class="<?php echo esc_attr(
    $content_class,
); ?>"><?php } ?>
					<?php echo $content;// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Trusted renderer or pre-sanitized modal content.
        ?>
				<?php if ($variant === 'default') { ?></div><?php } ?>
			</div>
		</div>
		<?php
  $modal = ob_get_clean();

  return apply_filters('wphave_modal_html', $modal, $args, $content);
    }
endif;
