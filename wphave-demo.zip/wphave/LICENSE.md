# WPHAVE Licensing

WPHAVE is distributed under a split-license model. The license of a component depends on its ownership and the scope described below; the presence of multiple components in one distribution does not replace their individual terms.

## PHP and WordPress integration

WPHAVE-owned PHP code and PHP components that integrate with WordPress are licensed under the GNU General Public License, version 2 or any later version (`GPL-2.0-or-later`). The text of GPL version 2 is included in [LICENSE](LICENSE).

## WPHAVE application

WPHAVE-owned React, JavaScript and TypeScript application source code is proprietary software and is not licensed under the GNU General Public License. Copyright © WPHAVE. All rights reserved.

Use and distribution of the compiled WPHAVE application are governed by the applicable WPHAVE Software License and Terms of Service for WPHAVE Free or WPHAVE Pro. See [LICENSE-PROPRIETARY.md](LICENSE-PROPRIETARY.md). These terms do not grant a right to receive unpublished proprietary source code. References to external WordPress JavaScript APIs, including externalized `@wordpress/*` packages, do not change this WPHAVE-owned application notice.

## Themes and other WPHAVE components

The bundled WPHAVE parent and child themes identify `GPL-2.0-or-later` in their own headers. Earlier distributed versions that identified `GPL-3.0-or-later` retain their existing grants. The scope of each WPHAVE-owned component is determined by its own notice and the sections above; no blanket license is asserted for unrelated assets.

## Third-party software

Third-party libraries, frameworks, fonts, icon data and other components remain subject exclusively to their respective original licenses. Nothing in WPHAVE's licenses changes or restricts rights granted by those licenses. Preserve their copyright, license, notice and attribution information. See [THIRD-PARTY-NOTICES.md](THIRD-PARTY-NOTICES.md) and the notices shipped with individual components.

## Previously distributed versions

This notice applies to the WPHAVE-owned components of the version with which it is distributed. It does not revoke or limit rights already granted to recipients of earlier GPL-covered WPHAVE versions.

WPHAVE names and logos are addressed separately in [TRADEMARKS.md](TRADEMARKS.md).
