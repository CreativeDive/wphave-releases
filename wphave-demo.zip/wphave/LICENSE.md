# WPHAVE License Notice

Copyright (c) 2025–2026 Martin Jost.

The original WPHAVE WordPress plugin code is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 2 of the License, or (at your option) any later version (`GPL-2.0-or-later`).

WPHAVE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

The complete text of version 2 of the GNU General Public License is included in [LICENSE](LICENSE).

The bundled WPHAVE parent and child themes identify `GPL-3.0-or-later` in their own headers. That compatible later-version license applies to those theme files.

## Commercial subscriptions

Solo, Creator and Agency are commercial product and service plans with the same WPHAVE functionality. They differ by the number of production installations covered by an active subscription. The public release ZIP is one shared GPL package; it is not a separate Free edition. Official license activation, support and future hosted services follow their respective subscription terms. Security and compatibility updates remain publicly available through the official updater.

The installation allowance of a paid plan determines how many production installations can simultaneously use those official subscription services. The unmodified official build uses a signed activation to enable WPHAVE-managed workspace writes. This is a technical behavior of that build, not a restriction on the GPL rights to run, study, modify or redistribute received code, including its activation checks. A recipient of a GPL-covered copy does not need an official subscription to exercise those GPL rights. Official activation credentials, hosted services and support remain separate services.

Expiry or termination of a subscription can end signed access to WPHAVE-managed workspace writes in the unmodified official build and end support, while existing website output and recovery remain available. It does not require deletion of copies lawfully received under the GPL and does not remove the GPL rights attached to those copies.

## Trademarks and third-party components

The GPL license for the software does not grant permission to use the WPHAVE name, logo or other source-identifying brand elements in a way that suggests an unofficial or modified version is the original product or is endorsed by WPHAVE. See [TRADEMARKS.md](TRADEMARKS.md).

Third-party components remain subject to their respective licenses. See [THIRD-PARTY-NOTICES.md](THIRD-PARTY-NOTICES.md) and license notices shipped with individual files.
